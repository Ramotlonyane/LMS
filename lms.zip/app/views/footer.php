	<footer> 
        <p class="text-center">&copy; 2016 Leave Management System</p>                  
    </footer>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="assets/js/jquery.min.js"><\/script>')</script>
    
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/custom.js"></script>

    <script src="http://code.jquery.com/jquery-2.1.1.js"></script>  
    <script src="//code.jquery.com/ui/1.11.1/jquery-ui.js"></script>
  </body>
</html>
