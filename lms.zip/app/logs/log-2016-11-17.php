<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-17 20:38:49 --> Config Class Initialized
INFO - 2016-11-17 20:38:49 --> Hooks Class Initialized
DEBUG - 2016-11-17 20:38:49 --> UTF-8 Support Enabled
INFO - 2016-11-17 20:38:49 --> Utf8 Class Initialized
INFO - 2016-11-17 20:38:49 --> URI Class Initialized
DEBUG - 2016-11-17 20:38:49 --> No URI present. Default controller set.
INFO - 2016-11-17 20:38:49 --> Router Class Initialized
INFO - 2016-11-17 20:38:49 --> Output Class Initialized
INFO - 2016-11-17 20:38:49 --> Security Class Initialized
DEBUG - 2016-11-17 20:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 20:38:49 --> Input Class Initialized
INFO - 2016-11-17 20:38:49 --> Language Class Initialized
INFO - 2016-11-17 20:38:49 --> Loader Class Initialized
INFO - 2016-11-17 20:38:50 --> Helper loaded: url_helper
INFO - 2016-11-17 20:38:50 --> Helper loaded: form_helper
INFO - 2016-11-17 20:38:50 --> Database Driver Class Initialized
INFO - 2016-11-17 20:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 20:38:50 --> Controller Class Initialized
INFO - 2016-11-17 20:38:50 --> Model Class Initialized
INFO - 2016-11-17 20:38:50 --> Model Class Initialized
INFO - 2016-11-17 20:38:50 --> Model Class Initialized
INFO - 2016-11-17 20:38:50 --> Model Class Initialized
INFO - 2016-11-17 20:38:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 20:38:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-17 20:38:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 20:38:50 --> Final output sent to browser
DEBUG - 2016-11-17 20:38:50 --> Total execution time: 1.5545
INFO - 2016-11-17 20:39:04 --> Config Class Initialized
INFO - 2016-11-17 20:39:04 --> Hooks Class Initialized
DEBUG - 2016-11-17 20:39:04 --> UTF-8 Support Enabled
INFO - 2016-11-17 20:39:04 --> Utf8 Class Initialized
INFO - 2016-11-17 20:39:04 --> URI Class Initialized
INFO - 2016-11-17 20:39:04 --> Router Class Initialized
INFO - 2016-11-17 20:39:04 --> Output Class Initialized
INFO - 2016-11-17 20:39:04 --> Security Class Initialized
DEBUG - 2016-11-17 20:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 20:39:04 --> Input Class Initialized
INFO - 2016-11-17 20:39:04 --> Language Class Initialized
INFO - 2016-11-17 20:39:04 --> Loader Class Initialized
INFO - 2016-11-17 20:39:04 --> Helper loaded: url_helper
INFO - 2016-11-17 20:39:04 --> Helper loaded: form_helper
INFO - 2016-11-17 20:39:04 --> Database Driver Class Initialized
INFO - 2016-11-17 20:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 20:39:04 --> Controller Class Initialized
INFO - 2016-11-17 20:39:04 --> Model Class Initialized
INFO - 2016-11-17 20:39:04 --> Model Class Initialized
INFO - 2016-11-17 20:39:04 --> Model Class Initialized
INFO - 2016-11-17 20:39:04 --> Model Class Initialized
DEBUG - 2016-11-17 20:39:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-17 20:39:04 --> Model Class Initialized
INFO - 2016-11-17 20:39:05 --> Final output sent to browser
DEBUG - 2016-11-17 20:39:05 --> Total execution time: 0.5754
INFO - 2016-11-17 20:39:05 --> Config Class Initialized
INFO - 2016-11-17 20:39:05 --> Hooks Class Initialized
DEBUG - 2016-11-17 20:39:05 --> UTF-8 Support Enabled
INFO - 2016-11-17 20:39:05 --> Utf8 Class Initialized
INFO - 2016-11-17 20:39:05 --> URI Class Initialized
DEBUG - 2016-11-17 20:39:05 --> No URI present. Default controller set.
INFO - 2016-11-17 20:39:05 --> Router Class Initialized
INFO - 2016-11-17 20:39:05 --> Output Class Initialized
INFO - 2016-11-17 20:39:05 --> Security Class Initialized
DEBUG - 2016-11-17 20:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 20:39:05 --> Input Class Initialized
INFO - 2016-11-17 20:39:05 --> Language Class Initialized
INFO - 2016-11-17 20:39:05 --> Loader Class Initialized
INFO - 2016-11-17 20:39:05 --> Helper loaded: url_helper
INFO - 2016-11-17 20:39:05 --> Helper loaded: form_helper
INFO - 2016-11-17 20:39:05 --> Database Driver Class Initialized
INFO - 2016-11-17 20:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 20:39:05 --> Controller Class Initialized
INFO - 2016-11-17 20:39:05 --> Model Class Initialized
INFO - 2016-11-17 20:39:05 --> Model Class Initialized
INFO - 2016-11-17 20:39:05 --> Model Class Initialized
INFO - 2016-11-17 20:39:05 --> Model Class Initialized
INFO - 2016-11-17 20:39:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 20:39:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 20:39:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 20:39:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 20:39:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 20:39:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 20:39:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 20:39:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 20:39:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 20:39:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 20:39:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 20:39:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 20:39:06 --> Final output sent to browser
DEBUG - 2016-11-17 20:39:06 --> Total execution time: 1.1239
INFO - 2016-11-17 20:39:16 --> Config Class Initialized
INFO - 2016-11-17 20:39:16 --> Hooks Class Initialized
DEBUG - 2016-11-17 20:39:16 --> UTF-8 Support Enabled
INFO - 2016-11-17 20:39:16 --> Utf8 Class Initialized
INFO - 2016-11-17 20:39:16 --> URI Class Initialized
INFO - 2016-11-17 20:39:16 --> Router Class Initialized
INFO - 2016-11-17 20:39:16 --> Output Class Initialized
INFO - 2016-11-17 20:39:16 --> Security Class Initialized
DEBUG - 2016-11-17 20:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 20:39:16 --> Input Class Initialized
INFO - 2016-11-17 20:39:16 --> Language Class Initialized
INFO - 2016-11-17 20:39:16 --> Loader Class Initialized
INFO - 2016-11-17 20:39:16 --> Helper loaded: url_helper
INFO - 2016-11-17 20:39:16 --> Helper loaded: form_helper
INFO - 2016-11-17 20:39:16 --> Database Driver Class Initialized
INFO - 2016-11-17 20:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 20:39:16 --> Controller Class Initialized
INFO - 2016-11-17 20:39:16 --> Model Class Initialized
INFO - 2016-11-17 20:39:16 --> Form Validation Class Initialized
INFO - 2016-11-17 20:39:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 20:39:16 --> Final output sent to browser
DEBUG - 2016-11-17 20:39:16 --> Total execution time: 0.2489
INFO - 2016-11-17 20:39:18 --> Config Class Initialized
INFO - 2016-11-17 20:39:18 --> Hooks Class Initialized
DEBUG - 2016-11-17 20:39:18 --> UTF-8 Support Enabled
INFO - 2016-11-17 20:39:18 --> Utf8 Class Initialized
INFO - 2016-11-17 20:39:18 --> URI Class Initialized
DEBUG - 2016-11-17 20:39:18 --> No URI present. Default controller set.
INFO - 2016-11-17 20:39:18 --> Router Class Initialized
INFO - 2016-11-17 20:39:18 --> Output Class Initialized
INFO - 2016-11-17 20:39:18 --> Security Class Initialized
DEBUG - 2016-11-17 20:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 20:39:18 --> Input Class Initialized
INFO - 2016-11-17 20:39:18 --> Language Class Initialized
INFO - 2016-11-17 20:39:18 --> Loader Class Initialized
INFO - 2016-11-17 20:39:18 --> Helper loaded: url_helper
INFO - 2016-11-17 20:39:18 --> Helper loaded: form_helper
INFO - 2016-11-17 20:39:18 --> Database Driver Class Initialized
INFO - 2016-11-17 20:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 20:39:18 --> Controller Class Initialized
INFO - 2016-11-17 20:39:18 --> Model Class Initialized
INFO - 2016-11-17 20:39:18 --> Model Class Initialized
INFO - 2016-11-17 20:39:18 --> Model Class Initialized
INFO - 2016-11-17 20:39:18 --> Model Class Initialized
INFO - 2016-11-17 20:39:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 20:39:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 20:39:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 20:39:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 20:39:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 20:39:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 20:39:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 20:39:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 20:39:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 20:39:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 20:39:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 20:39:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 20:39:19 --> Final output sent to browser
DEBUG - 2016-11-17 20:39:19 --> Total execution time: 0.3609
INFO - 2016-11-17 20:41:32 --> Config Class Initialized
INFO - 2016-11-17 20:41:32 --> Hooks Class Initialized
DEBUG - 2016-11-17 20:41:32 --> UTF-8 Support Enabled
INFO - 2016-11-17 20:41:32 --> Utf8 Class Initialized
INFO - 2016-11-17 20:41:32 --> URI Class Initialized
DEBUG - 2016-11-17 20:41:32 --> No URI present. Default controller set.
INFO - 2016-11-17 20:41:32 --> Router Class Initialized
INFO - 2016-11-17 20:41:32 --> Output Class Initialized
INFO - 2016-11-17 20:41:32 --> Security Class Initialized
DEBUG - 2016-11-17 20:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 20:41:32 --> Input Class Initialized
INFO - 2016-11-17 20:41:32 --> Language Class Initialized
INFO - 2016-11-17 20:41:32 --> Loader Class Initialized
INFO - 2016-11-17 20:41:32 --> Helper loaded: url_helper
INFO - 2016-11-17 20:41:32 --> Helper loaded: form_helper
INFO - 2016-11-17 20:41:32 --> Database Driver Class Initialized
INFO - 2016-11-17 20:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 20:41:32 --> Controller Class Initialized
INFO - 2016-11-17 20:41:32 --> Model Class Initialized
INFO - 2016-11-17 20:41:32 --> Model Class Initialized
INFO - 2016-11-17 20:41:32 --> Model Class Initialized
INFO - 2016-11-17 20:41:32 --> Model Class Initialized
INFO - 2016-11-17 20:41:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 20:41:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 20:41:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 20:41:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 20:41:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 20:41:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 20:41:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 20:41:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 20:41:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 20:41:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 20:41:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 20:41:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 20:41:32 --> Final output sent to browser
DEBUG - 2016-11-17 20:41:32 --> Total execution time: 0.3180
INFO - 2016-11-17 20:42:21 --> Config Class Initialized
INFO - 2016-11-17 20:42:21 --> Hooks Class Initialized
DEBUG - 2016-11-17 20:42:21 --> UTF-8 Support Enabled
INFO - 2016-11-17 20:42:21 --> Utf8 Class Initialized
INFO - 2016-11-17 20:42:21 --> URI Class Initialized
INFO - 2016-11-17 20:42:21 --> Router Class Initialized
INFO - 2016-11-17 20:42:21 --> Output Class Initialized
INFO - 2016-11-17 20:42:21 --> Security Class Initialized
DEBUG - 2016-11-17 20:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 20:42:21 --> Input Class Initialized
INFO - 2016-11-17 20:42:21 --> Language Class Initialized
INFO - 2016-11-17 20:42:21 --> Loader Class Initialized
INFO - 2016-11-17 20:42:21 --> Helper loaded: url_helper
INFO - 2016-11-17 20:42:21 --> Helper loaded: form_helper
INFO - 2016-11-17 20:42:21 --> Database Driver Class Initialized
INFO - 2016-11-17 20:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 20:42:21 --> Controller Class Initialized
INFO - 2016-11-17 20:42:21 --> Model Class Initialized
INFO - 2016-11-17 20:42:21 --> Form Validation Class Initialized
INFO - 2016-11-17 20:42:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 20:42:21 --> Final output sent to browser
DEBUG - 2016-11-17 20:42:21 --> Total execution time: 0.1999
INFO - 2016-11-17 20:42:33 --> Config Class Initialized
INFO - 2016-11-17 20:42:33 --> Hooks Class Initialized
DEBUG - 2016-11-17 20:42:33 --> UTF-8 Support Enabled
INFO - 2016-11-17 20:42:33 --> Utf8 Class Initialized
INFO - 2016-11-17 20:42:33 --> URI Class Initialized
INFO - 2016-11-17 20:42:33 --> Router Class Initialized
INFO - 2016-11-17 20:42:33 --> Output Class Initialized
INFO - 2016-11-17 20:42:33 --> Security Class Initialized
DEBUG - 2016-11-17 20:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 20:42:33 --> Input Class Initialized
INFO - 2016-11-17 20:42:33 --> Language Class Initialized
INFO - 2016-11-17 20:42:33 --> Loader Class Initialized
INFO - 2016-11-17 20:42:33 --> Helper loaded: url_helper
INFO - 2016-11-17 20:42:33 --> Helper loaded: form_helper
INFO - 2016-11-17 20:42:33 --> Database Driver Class Initialized
INFO - 2016-11-17 20:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 20:42:33 --> Controller Class Initialized
INFO - 2016-11-17 20:42:33 --> Model Class Initialized
INFO - 2016-11-17 20:42:33 --> Form Validation Class Initialized
INFO - 2016-11-17 20:42:33 --> Final output sent to browser
DEBUG - 2016-11-17 20:42:33 --> Total execution time: 0.1750
INFO - 2016-11-17 20:42:41 --> Config Class Initialized
INFO - 2016-11-17 20:42:41 --> Hooks Class Initialized
DEBUG - 2016-11-17 20:42:41 --> UTF-8 Support Enabled
INFO - 2016-11-17 20:42:41 --> Utf8 Class Initialized
INFO - 2016-11-17 20:42:41 --> URI Class Initialized
DEBUG - 2016-11-17 20:42:41 --> No URI present. Default controller set.
INFO - 2016-11-17 20:42:41 --> Router Class Initialized
INFO - 2016-11-17 20:42:41 --> Output Class Initialized
INFO - 2016-11-17 20:42:41 --> Security Class Initialized
DEBUG - 2016-11-17 20:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 20:42:41 --> Input Class Initialized
INFO - 2016-11-17 20:42:41 --> Language Class Initialized
INFO - 2016-11-17 20:42:41 --> Loader Class Initialized
INFO - 2016-11-17 20:42:41 --> Helper loaded: url_helper
INFO - 2016-11-17 20:42:41 --> Helper loaded: form_helper
INFO - 2016-11-17 20:42:41 --> Database Driver Class Initialized
INFO - 2016-11-17 20:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 20:42:41 --> Controller Class Initialized
INFO - 2016-11-17 20:42:41 --> Model Class Initialized
INFO - 2016-11-17 20:42:41 --> Model Class Initialized
INFO - 2016-11-17 20:42:41 --> Model Class Initialized
INFO - 2016-11-17 20:42:41 --> Model Class Initialized
INFO - 2016-11-17 20:42:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 20:42:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 20:42:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 20:42:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 20:42:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 20:42:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 20:42:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 20:42:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 20:42:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 20:42:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 20:42:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 20:42:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 20:42:41 --> Final output sent to browser
DEBUG - 2016-11-17 20:42:41 --> Total execution time: 0.2994
INFO - 2016-11-17 20:42:51 --> Config Class Initialized
INFO - 2016-11-17 20:42:51 --> Hooks Class Initialized
DEBUG - 2016-11-17 20:42:51 --> UTF-8 Support Enabled
INFO - 2016-11-17 20:42:51 --> Utf8 Class Initialized
INFO - 2016-11-17 20:42:51 --> URI Class Initialized
INFO - 2016-11-17 20:42:51 --> Router Class Initialized
INFO - 2016-11-17 20:42:51 --> Output Class Initialized
INFO - 2016-11-17 20:42:51 --> Security Class Initialized
DEBUG - 2016-11-17 20:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 20:42:51 --> Input Class Initialized
INFO - 2016-11-17 20:42:51 --> Language Class Initialized
INFO - 2016-11-17 20:42:51 --> Loader Class Initialized
INFO - 2016-11-17 20:42:51 --> Helper loaded: url_helper
INFO - 2016-11-17 20:42:51 --> Helper loaded: form_helper
INFO - 2016-11-17 20:42:51 --> Database Driver Class Initialized
INFO - 2016-11-17 20:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 20:42:51 --> Controller Class Initialized
INFO - 2016-11-17 20:42:51 --> Model Class Initialized
INFO - 2016-11-17 20:42:51 --> Form Validation Class Initialized
ERROR - 2016-11-17 20:42:51 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-17 20:42:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-17 20:42:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 20:42:51 --> Final output sent to browser
DEBUG - 2016-11-17 20:42:51 --> Total execution time: 0.5022
INFO - 2016-11-17 20:50:19 --> Config Class Initialized
INFO - 2016-11-17 20:50:19 --> Hooks Class Initialized
DEBUG - 2016-11-17 20:50:19 --> UTF-8 Support Enabled
INFO - 2016-11-17 20:50:19 --> Utf8 Class Initialized
INFO - 2016-11-17 20:50:19 --> URI Class Initialized
DEBUG - 2016-11-17 20:50:19 --> No URI present. Default controller set.
INFO - 2016-11-17 20:50:19 --> Router Class Initialized
INFO - 2016-11-17 20:50:19 --> Output Class Initialized
INFO - 2016-11-17 20:50:19 --> Security Class Initialized
DEBUG - 2016-11-17 20:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 20:50:19 --> Input Class Initialized
INFO - 2016-11-17 20:50:19 --> Language Class Initialized
INFO - 2016-11-17 20:50:19 --> Loader Class Initialized
INFO - 2016-11-17 20:50:19 --> Helper loaded: url_helper
INFO - 2016-11-17 20:50:19 --> Helper loaded: form_helper
INFO - 2016-11-17 20:50:19 --> Database Driver Class Initialized
INFO - 2016-11-17 20:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 20:50:19 --> Controller Class Initialized
INFO - 2016-11-17 20:50:19 --> Model Class Initialized
INFO - 2016-11-17 20:50:19 --> Model Class Initialized
INFO - 2016-11-17 20:50:19 --> Model Class Initialized
INFO - 2016-11-17 20:50:19 --> Model Class Initialized
INFO - 2016-11-17 20:50:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 20:50:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 20:50:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 20:50:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 20:50:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 20:50:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 20:50:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 20:50:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 20:50:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 20:50:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 20:50:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 20:50:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 20:50:19 --> Final output sent to browser
DEBUG - 2016-11-17 20:50:19 --> Total execution time: 0.3340
INFO - 2016-11-17 20:50:27 --> Config Class Initialized
INFO - 2016-11-17 20:50:27 --> Hooks Class Initialized
DEBUG - 2016-11-17 20:50:27 --> UTF-8 Support Enabled
INFO - 2016-11-17 20:50:27 --> Utf8 Class Initialized
INFO - 2016-11-17 20:50:27 --> URI Class Initialized
INFO - 2016-11-17 20:50:27 --> Router Class Initialized
INFO - 2016-11-17 20:50:27 --> Output Class Initialized
INFO - 2016-11-17 20:50:27 --> Security Class Initialized
DEBUG - 2016-11-17 20:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 20:50:27 --> Input Class Initialized
INFO - 2016-11-17 20:50:27 --> Language Class Initialized
INFO - 2016-11-17 20:50:27 --> Loader Class Initialized
INFO - 2016-11-17 20:50:27 --> Helper loaded: url_helper
INFO - 2016-11-17 20:50:27 --> Helper loaded: form_helper
INFO - 2016-11-17 20:50:27 --> Database Driver Class Initialized
INFO - 2016-11-17 20:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 20:50:27 --> Controller Class Initialized
INFO - 2016-11-17 20:50:27 --> Model Class Initialized
INFO - 2016-11-17 20:50:27 --> Form Validation Class Initialized
INFO - 2016-11-17 20:50:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 20:50:27 --> Final output sent to browser
DEBUG - 2016-11-17 20:50:27 --> Total execution time: 0.1891
INFO - 2016-11-17 20:50:30 --> Config Class Initialized
INFO - 2016-11-17 20:50:30 --> Hooks Class Initialized
DEBUG - 2016-11-17 20:50:30 --> UTF-8 Support Enabled
INFO - 2016-11-17 20:50:30 --> Utf8 Class Initialized
INFO - 2016-11-17 20:50:30 --> URI Class Initialized
INFO - 2016-11-17 20:50:30 --> Router Class Initialized
INFO - 2016-11-17 20:50:30 --> Output Class Initialized
INFO - 2016-11-17 20:50:30 --> Security Class Initialized
DEBUG - 2016-11-17 20:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 20:50:30 --> Input Class Initialized
INFO - 2016-11-17 20:50:30 --> Language Class Initialized
INFO - 2016-11-17 20:50:30 --> Loader Class Initialized
INFO - 2016-11-17 20:50:30 --> Helper loaded: url_helper
INFO - 2016-11-17 20:50:30 --> Helper loaded: form_helper
INFO - 2016-11-17 20:50:31 --> Database Driver Class Initialized
INFO - 2016-11-17 20:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 20:50:31 --> Controller Class Initialized
INFO - 2016-11-17 20:50:31 --> Model Class Initialized
INFO - 2016-11-17 20:50:31 --> Form Validation Class Initialized
INFO - 2016-11-17 20:50:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 20:50:31 --> Final output sent to browser
DEBUG - 2016-11-17 20:50:31 --> Total execution time: 0.2159
INFO - 2016-11-17 20:50:32 --> Config Class Initialized
INFO - 2016-11-17 20:50:32 --> Hooks Class Initialized
DEBUG - 2016-11-17 20:50:32 --> UTF-8 Support Enabled
INFO - 2016-11-17 20:50:32 --> Utf8 Class Initialized
INFO - 2016-11-17 20:50:32 --> URI Class Initialized
INFO - 2016-11-17 20:50:32 --> Router Class Initialized
INFO - 2016-11-17 20:50:32 --> Output Class Initialized
INFO - 2016-11-17 20:50:32 --> Security Class Initialized
DEBUG - 2016-11-17 20:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 20:50:32 --> Input Class Initialized
INFO - 2016-11-17 20:50:32 --> Language Class Initialized
INFO - 2016-11-17 20:50:32 --> Loader Class Initialized
INFO - 2016-11-17 20:50:32 --> Helper loaded: url_helper
INFO - 2016-11-17 20:50:32 --> Helper loaded: form_helper
INFO - 2016-11-17 20:50:32 --> Database Driver Class Initialized
INFO - 2016-11-17 20:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 20:50:32 --> Controller Class Initialized
INFO - 2016-11-17 20:50:32 --> Model Class Initialized
INFO - 2016-11-17 20:50:32 --> Form Validation Class Initialized
INFO - 2016-11-17 20:50:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 20:50:32 --> Final output sent to browser
DEBUG - 2016-11-17 20:50:32 --> Total execution time: 0.2492
INFO - 2016-11-17 20:50:34 --> Config Class Initialized
INFO - 2016-11-17 20:50:34 --> Hooks Class Initialized
DEBUG - 2016-11-17 20:50:34 --> UTF-8 Support Enabled
INFO - 2016-11-17 20:50:34 --> Utf8 Class Initialized
INFO - 2016-11-17 20:50:34 --> URI Class Initialized
INFO - 2016-11-17 20:50:34 --> Router Class Initialized
INFO - 2016-11-17 20:50:34 --> Output Class Initialized
INFO - 2016-11-17 20:50:34 --> Security Class Initialized
DEBUG - 2016-11-17 20:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 20:50:35 --> Input Class Initialized
INFO - 2016-11-17 20:50:35 --> Language Class Initialized
INFO - 2016-11-17 20:50:35 --> Loader Class Initialized
INFO - 2016-11-17 20:50:35 --> Helper loaded: url_helper
INFO - 2016-11-17 20:50:35 --> Helper loaded: form_helper
INFO - 2016-11-17 20:50:35 --> Database Driver Class Initialized
INFO - 2016-11-17 20:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 20:50:35 --> Controller Class Initialized
INFO - 2016-11-17 20:50:35 --> Model Class Initialized
INFO - 2016-11-17 20:50:35 --> Form Validation Class Initialized
INFO - 2016-11-17 20:50:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 20:50:35 --> Final output sent to browser
DEBUG - 2016-11-17 20:50:35 --> Total execution time: 0.2252
INFO - 2016-11-17 20:50:36 --> Config Class Initialized
INFO - 2016-11-17 20:50:36 --> Hooks Class Initialized
DEBUG - 2016-11-17 20:50:36 --> UTF-8 Support Enabled
INFO - 2016-11-17 20:50:36 --> Utf8 Class Initialized
INFO - 2016-11-17 20:50:36 --> URI Class Initialized
INFO - 2016-11-17 20:50:36 --> Router Class Initialized
INFO - 2016-11-17 20:50:36 --> Output Class Initialized
INFO - 2016-11-17 20:50:36 --> Security Class Initialized
DEBUG - 2016-11-17 20:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 20:50:36 --> Input Class Initialized
INFO - 2016-11-17 20:50:36 --> Language Class Initialized
INFO - 2016-11-17 20:50:36 --> Loader Class Initialized
INFO - 2016-11-17 20:50:36 --> Helper loaded: url_helper
INFO - 2016-11-17 20:50:36 --> Helper loaded: form_helper
INFO - 2016-11-17 20:50:36 --> Database Driver Class Initialized
INFO - 2016-11-17 20:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 20:50:36 --> Controller Class Initialized
INFO - 2016-11-17 20:50:36 --> Model Class Initialized
INFO - 2016-11-17 20:50:36 --> Form Validation Class Initialized
INFO - 2016-11-17 20:50:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 20:50:36 --> Final output sent to browser
DEBUG - 2016-11-17 20:50:36 --> Total execution time: 0.2176
INFO - 2016-11-17 20:50:49 --> Config Class Initialized
INFO - 2016-11-17 20:50:49 --> Hooks Class Initialized
DEBUG - 2016-11-17 20:50:49 --> UTF-8 Support Enabled
INFO - 2016-11-17 20:50:49 --> Utf8 Class Initialized
INFO - 2016-11-17 20:50:49 --> URI Class Initialized
INFO - 2016-11-17 20:50:49 --> Router Class Initialized
INFO - 2016-11-17 20:50:49 --> Output Class Initialized
INFO - 2016-11-17 20:50:49 --> Security Class Initialized
DEBUG - 2016-11-17 20:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 20:50:49 --> Input Class Initialized
INFO - 2016-11-17 20:50:49 --> Language Class Initialized
INFO - 2016-11-17 20:50:49 --> Loader Class Initialized
INFO - 2016-11-17 20:50:49 --> Helper loaded: url_helper
INFO - 2016-11-17 20:50:49 --> Helper loaded: form_helper
INFO - 2016-11-17 20:50:49 --> Database Driver Class Initialized
INFO - 2016-11-17 20:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 20:50:49 --> Controller Class Initialized
INFO - 2016-11-17 20:50:49 --> Model Class Initialized
INFO - 2016-11-17 20:50:49 --> Form Validation Class Initialized
INFO - 2016-11-17 20:50:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 20:50:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 20:50:50 --> Final output sent to browser
DEBUG - 2016-11-17 20:50:50 --> Total execution time: 0.2981
INFO - 2016-11-17 20:51:04 --> Config Class Initialized
INFO - 2016-11-17 20:51:04 --> Hooks Class Initialized
DEBUG - 2016-11-17 20:51:04 --> UTF-8 Support Enabled
INFO - 2016-11-17 20:51:04 --> Utf8 Class Initialized
INFO - 2016-11-17 20:51:04 --> URI Class Initialized
DEBUG - 2016-11-17 20:51:04 --> No URI present. Default controller set.
INFO - 2016-11-17 20:51:04 --> Router Class Initialized
INFO - 2016-11-17 20:51:04 --> Output Class Initialized
INFO - 2016-11-17 20:51:04 --> Security Class Initialized
DEBUG - 2016-11-17 20:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 20:51:04 --> Input Class Initialized
INFO - 2016-11-17 20:51:04 --> Language Class Initialized
INFO - 2016-11-17 20:51:04 --> Loader Class Initialized
INFO - 2016-11-17 20:51:04 --> Helper loaded: url_helper
INFO - 2016-11-17 20:51:04 --> Helper loaded: form_helper
INFO - 2016-11-17 20:51:04 --> Database Driver Class Initialized
INFO - 2016-11-17 20:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 20:51:04 --> Controller Class Initialized
INFO - 2016-11-17 20:51:04 --> Model Class Initialized
INFO - 2016-11-17 20:51:04 --> Model Class Initialized
INFO - 2016-11-17 20:51:04 --> Model Class Initialized
INFO - 2016-11-17 20:51:04 --> Model Class Initialized
INFO - 2016-11-17 20:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 20:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 20:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 20:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 20:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 20:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 20:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 20:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 20:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 20:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 20:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 20:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 20:51:04 --> Final output sent to browser
DEBUG - 2016-11-17 20:51:04 --> Total execution time: 0.3310
INFO - 2016-11-17 20:57:55 --> Config Class Initialized
INFO - 2016-11-17 20:57:55 --> Hooks Class Initialized
DEBUG - 2016-11-17 20:57:55 --> UTF-8 Support Enabled
INFO - 2016-11-17 20:57:55 --> Utf8 Class Initialized
INFO - 2016-11-17 20:57:55 --> URI Class Initialized
INFO - 2016-11-17 20:57:55 --> Router Class Initialized
INFO - 2016-11-17 20:57:55 --> Output Class Initialized
INFO - 2016-11-17 20:57:55 --> Security Class Initialized
DEBUG - 2016-11-17 20:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 20:57:55 --> Input Class Initialized
INFO - 2016-11-17 20:57:55 --> Language Class Initialized
INFO - 2016-11-17 20:57:55 --> Loader Class Initialized
INFO - 2016-11-17 20:57:55 --> Helper loaded: url_helper
INFO - 2016-11-17 20:57:55 --> Helper loaded: form_helper
INFO - 2016-11-17 20:57:55 --> Database Driver Class Initialized
INFO - 2016-11-17 20:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 20:57:55 --> Controller Class Initialized
INFO - 2016-11-17 20:57:55 --> Model Class Initialized
INFO - 2016-11-17 20:57:55 --> Form Validation Class Initialized
INFO - 2016-11-17 20:57:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 20:57:55 --> Final output sent to browser
DEBUG - 2016-11-17 20:57:55 --> Total execution time: 0.1901
INFO - 2016-11-17 20:58:07 --> Config Class Initialized
INFO - 2016-11-17 20:58:07 --> Hooks Class Initialized
DEBUG - 2016-11-17 20:58:07 --> UTF-8 Support Enabled
INFO - 2016-11-17 20:58:07 --> Utf8 Class Initialized
INFO - 2016-11-17 20:58:07 --> URI Class Initialized
INFO - 2016-11-17 20:58:07 --> Router Class Initialized
INFO - 2016-11-17 20:58:07 --> Output Class Initialized
INFO - 2016-11-17 20:58:07 --> Security Class Initialized
DEBUG - 2016-11-17 20:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 20:58:07 --> Input Class Initialized
INFO - 2016-11-17 20:58:07 --> Language Class Initialized
INFO - 2016-11-17 20:58:07 --> Loader Class Initialized
INFO - 2016-11-17 20:58:07 --> Helper loaded: url_helper
INFO - 2016-11-17 20:58:07 --> Helper loaded: form_helper
INFO - 2016-11-17 20:58:07 --> Database Driver Class Initialized
INFO - 2016-11-17 20:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 20:58:07 --> Controller Class Initialized
INFO - 2016-11-17 20:58:07 --> Model Class Initialized
INFO - 2016-11-17 20:58:07 --> Form Validation Class Initialized
INFO - 2016-11-17 20:58:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 20:58:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 20:58:07 --> Final output sent to browser
DEBUG - 2016-11-17 20:58:07 --> Total execution time: 0.3423
INFO - 2016-11-17 20:58:35 --> Config Class Initialized
INFO - 2016-11-17 20:58:35 --> Hooks Class Initialized
DEBUG - 2016-11-17 20:58:35 --> UTF-8 Support Enabled
INFO - 2016-11-17 20:58:35 --> Utf8 Class Initialized
INFO - 2016-11-17 20:58:35 --> URI Class Initialized
DEBUG - 2016-11-17 20:58:35 --> No URI present. Default controller set.
INFO - 2016-11-17 20:58:35 --> Router Class Initialized
INFO - 2016-11-17 20:58:35 --> Output Class Initialized
INFO - 2016-11-17 20:58:35 --> Security Class Initialized
DEBUG - 2016-11-17 20:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 20:58:35 --> Input Class Initialized
INFO - 2016-11-17 20:58:35 --> Language Class Initialized
INFO - 2016-11-17 20:58:35 --> Loader Class Initialized
INFO - 2016-11-17 20:58:35 --> Helper loaded: url_helper
INFO - 2016-11-17 20:58:35 --> Helper loaded: form_helper
INFO - 2016-11-17 20:58:35 --> Database Driver Class Initialized
INFO - 2016-11-17 20:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 20:58:35 --> Controller Class Initialized
INFO - 2016-11-17 20:58:35 --> Model Class Initialized
INFO - 2016-11-17 20:58:35 --> Model Class Initialized
INFO - 2016-11-17 20:58:35 --> Model Class Initialized
INFO - 2016-11-17 20:58:35 --> Model Class Initialized
INFO - 2016-11-17 20:58:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 20:58:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 20:58:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 20:58:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 20:58:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 20:58:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 20:58:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 20:58:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 20:58:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 20:58:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 20:58:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 20:58:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 20:58:35 --> Final output sent to browser
DEBUG - 2016-11-17 20:58:35 --> Total execution time: 0.3369
INFO - 2016-11-17 21:00:34 --> Config Class Initialized
INFO - 2016-11-17 21:00:34 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:00:34 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:00:34 --> Utf8 Class Initialized
INFO - 2016-11-17 21:00:34 --> URI Class Initialized
DEBUG - 2016-11-17 21:00:34 --> No URI present. Default controller set.
INFO - 2016-11-17 21:00:34 --> Router Class Initialized
INFO - 2016-11-17 21:00:34 --> Output Class Initialized
INFO - 2016-11-17 21:00:34 --> Security Class Initialized
DEBUG - 2016-11-17 21:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:00:34 --> Input Class Initialized
INFO - 2016-11-17 21:00:34 --> Language Class Initialized
INFO - 2016-11-17 21:00:34 --> Loader Class Initialized
INFO - 2016-11-17 21:00:34 --> Helper loaded: url_helper
INFO - 2016-11-17 21:00:34 --> Helper loaded: form_helper
INFO - 2016-11-17 21:00:34 --> Database Driver Class Initialized
INFO - 2016-11-17 21:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:00:34 --> Controller Class Initialized
INFO - 2016-11-17 21:00:34 --> Model Class Initialized
INFO - 2016-11-17 21:00:34 --> Model Class Initialized
INFO - 2016-11-17 21:00:34 --> Model Class Initialized
INFO - 2016-11-17 21:00:34 --> Model Class Initialized
INFO - 2016-11-17 21:00:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 21:00:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 21:00:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 21:00:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 21:00:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 21:00:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 21:00:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 21:00:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 21:00:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 21:00:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 21:00:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 21:00:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 21:00:34 --> Final output sent to browser
DEBUG - 2016-11-17 21:00:34 --> Total execution time: 0.3353
INFO - 2016-11-17 21:00:40 --> Config Class Initialized
INFO - 2016-11-17 21:00:40 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:00:40 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:00:40 --> Utf8 Class Initialized
INFO - 2016-11-17 21:00:40 --> URI Class Initialized
INFO - 2016-11-17 21:00:40 --> Router Class Initialized
INFO - 2016-11-17 21:00:40 --> Output Class Initialized
INFO - 2016-11-17 21:00:40 --> Security Class Initialized
DEBUG - 2016-11-17 21:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:00:40 --> Input Class Initialized
INFO - 2016-11-17 21:00:40 --> Language Class Initialized
INFO - 2016-11-17 21:00:40 --> Loader Class Initialized
INFO - 2016-11-17 21:00:40 --> Helper loaded: url_helper
INFO - 2016-11-17 21:00:40 --> Helper loaded: form_helper
INFO - 2016-11-17 21:00:40 --> Database Driver Class Initialized
INFO - 2016-11-17 21:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:00:40 --> Controller Class Initialized
INFO - 2016-11-17 21:00:40 --> Model Class Initialized
INFO - 2016-11-17 21:00:40 --> Config Class Initialized
INFO - 2016-11-17 21:00:40 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:00:40 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:00:41 --> Utf8 Class Initialized
INFO - 2016-11-17 21:00:41 --> URI Class Initialized
INFO - 2016-11-17 21:00:41 --> Router Class Initialized
INFO - 2016-11-17 21:00:41 --> Output Class Initialized
INFO - 2016-11-17 21:00:41 --> Security Class Initialized
DEBUG - 2016-11-17 21:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:00:41 --> Input Class Initialized
INFO - 2016-11-17 21:00:41 --> Language Class Initialized
INFO - 2016-11-17 21:00:41 --> Loader Class Initialized
INFO - 2016-11-17 21:00:41 --> Helper loaded: url_helper
INFO - 2016-11-17 21:00:41 --> Helper loaded: form_helper
INFO - 2016-11-17 21:00:41 --> Database Driver Class Initialized
INFO - 2016-11-17 21:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:00:41 --> Controller Class Initialized
INFO - 2016-11-17 21:00:41 --> Config Class Initialized
INFO - 2016-11-17 21:00:41 --> Model Class Initialized
INFO - 2016-11-17 21:00:41 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:00:41 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:00:41 --> Utf8 Class Initialized
INFO - 2016-11-17 21:00:41 --> URI Class Initialized
INFO - 2016-11-17 21:00:41 --> Router Class Initialized
INFO - 2016-11-17 21:00:41 --> Output Class Initialized
INFO - 2016-11-17 21:00:41 --> Security Class Initialized
DEBUG - 2016-11-17 21:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:00:41 --> Input Class Initialized
INFO - 2016-11-17 21:00:41 --> Language Class Initialized
INFO - 2016-11-17 21:00:41 --> Loader Class Initialized
INFO - 2016-11-17 21:00:41 --> Helper loaded: url_helper
INFO - 2016-11-17 21:00:41 --> Helper loaded: form_helper
INFO - 2016-11-17 21:00:41 --> Database Driver Class Initialized
INFO - 2016-11-17 21:00:41 --> Config Class Initialized
INFO - 2016-11-17 21:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:00:41 --> Hooks Class Initialized
INFO - 2016-11-17 21:00:41 --> Controller Class Initialized
DEBUG - 2016-11-17 21:00:41 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:00:41 --> Utf8 Class Initialized
INFO - 2016-11-17 21:00:41 --> Model Class Initialized
INFO - 2016-11-17 21:00:41 --> URI Class Initialized
INFO - 2016-11-17 21:00:41 --> Router Class Initialized
INFO - 2016-11-17 21:00:41 --> Output Class Initialized
INFO - 2016-11-17 21:00:41 --> Security Class Initialized
DEBUG - 2016-11-17 21:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:00:41 --> Input Class Initialized
INFO - 2016-11-17 21:00:41 --> Language Class Initialized
INFO - 2016-11-17 21:00:41 --> Loader Class Initialized
INFO - 2016-11-17 21:00:41 --> Helper loaded: url_helper
INFO - 2016-11-17 21:00:41 --> Helper loaded: form_helper
INFO - 2016-11-17 21:00:41 --> Config Class Initialized
INFO - 2016-11-17 21:00:41 --> Hooks Class Initialized
INFO - 2016-11-17 21:00:41 --> Database Driver Class Initialized
DEBUG - 2016-11-17 21:00:41 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:00:41 --> Utf8 Class Initialized
INFO - 2016-11-17 21:00:41 --> Controller Class Initialized
INFO - 2016-11-17 21:00:41 --> URI Class Initialized
INFO - 2016-11-17 21:00:41 --> Model Class Initialized
INFO - 2016-11-17 21:00:41 --> Router Class Initialized
INFO - 2016-11-17 21:00:41 --> Output Class Initialized
INFO - 2016-11-17 21:00:41 --> Security Class Initialized
DEBUG - 2016-11-17 21:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:00:41 --> Input Class Initialized
INFO - 2016-11-17 21:00:41 --> Language Class Initialized
INFO - 2016-11-17 21:00:41 --> Loader Class Initialized
INFO - 2016-11-17 21:00:41 --> Helper loaded: url_helper
INFO - 2016-11-17 21:00:41 --> Helper loaded: form_helper
INFO - 2016-11-17 21:00:41 --> Database Driver Class Initialized
INFO - 2016-11-17 21:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:00:41 --> Controller Class Initialized
INFO - 2016-11-17 21:00:41 --> Model Class Initialized
INFO - 2016-11-17 21:00:42 --> Config Class Initialized
INFO - 2016-11-17 21:00:42 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:00:42 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:00:42 --> Utf8 Class Initialized
INFO - 2016-11-17 21:00:42 --> URI Class Initialized
INFO - 2016-11-17 21:00:42 --> Router Class Initialized
INFO - 2016-11-17 21:00:42 --> Output Class Initialized
INFO - 2016-11-17 21:00:42 --> Security Class Initialized
DEBUG - 2016-11-17 21:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:00:42 --> Input Class Initialized
INFO - 2016-11-17 21:00:42 --> Language Class Initialized
INFO - 2016-11-17 21:00:42 --> Loader Class Initialized
INFO - 2016-11-17 21:00:42 --> Helper loaded: url_helper
INFO - 2016-11-17 21:00:42 --> Helper loaded: form_helper
INFO - 2016-11-17 21:00:42 --> Database Driver Class Initialized
INFO - 2016-11-17 21:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:00:42 --> Controller Class Initialized
INFO - 2016-11-17 21:00:42 --> Model Class Initialized
INFO - 2016-11-17 21:00:42 --> Config Class Initialized
INFO - 2016-11-17 21:00:42 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:00:42 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:00:42 --> Utf8 Class Initialized
INFO - 2016-11-17 21:00:42 --> URI Class Initialized
INFO - 2016-11-17 21:00:42 --> Router Class Initialized
INFO - 2016-11-17 21:00:42 --> Output Class Initialized
INFO - 2016-11-17 21:00:42 --> Security Class Initialized
DEBUG - 2016-11-17 21:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:00:42 --> Input Class Initialized
INFO - 2016-11-17 21:00:42 --> Language Class Initialized
INFO - 2016-11-17 21:00:42 --> Loader Class Initialized
INFO - 2016-11-17 21:00:42 --> Helper loaded: url_helper
INFO - 2016-11-17 21:00:42 --> Helper loaded: form_helper
INFO - 2016-11-17 21:00:42 --> Database Driver Class Initialized
INFO - 2016-11-17 21:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:00:42 --> Controller Class Initialized
INFO - 2016-11-17 21:00:42 --> Model Class Initialized
INFO - 2016-11-17 21:00:43 --> Config Class Initialized
INFO - 2016-11-17 21:00:43 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:00:43 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:00:43 --> Utf8 Class Initialized
INFO - 2016-11-17 21:00:43 --> URI Class Initialized
INFO - 2016-11-17 21:00:43 --> Router Class Initialized
INFO - 2016-11-17 21:00:43 --> Output Class Initialized
INFO - 2016-11-17 21:00:43 --> Security Class Initialized
DEBUG - 2016-11-17 21:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:00:43 --> Input Class Initialized
INFO - 2016-11-17 21:00:43 --> Language Class Initialized
INFO - 2016-11-17 21:00:43 --> Loader Class Initialized
INFO - 2016-11-17 21:00:43 --> Helper loaded: url_helper
INFO - 2016-11-17 21:00:43 --> Helper loaded: form_helper
INFO - 2016-11-17 21:00:43 --> Database Driver Class Initialized
INFO - 2016-11-17 21:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:00:43 --> Controller Class Initialized
INFO - 2016-11-17 21:00:43 --> Model Class Initialized
INFO - 2016-11-17 21:00:43 --> Config Class Initialized
INFO - 2016-11-17 21:00:43 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:00:43 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:00:43 --> Utf8 Class Initialized
INFO - 2016-11-17 21:00:43 --> URI Class Initialized
INFO - 2016-11-17 21:00:43 --> Router Class Initialized
INFO - 2016-11-17 21:00:43 --> Output Class Initialized
INFO - 2016-11-17 21:00:43 --> Security Class Initialized
DEBUG - 2016-11-17 21:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:00:43 --> Input Class Initialized
INFO - 2016-11-17 21:00:43 --> Language Class Initialized
INFO - 2016-11-17 21:00:43 --> Loader Class Initialized
INFO - 2016-11-17 21:00:43 --> Helper loaded: url_helper
INFO - 2016-11-17 21:00:43 --> Helper loaded: form_helper
INFO - 2016-11-17 21:00:43 --> Database Driver Class Initialized
INFO - 2016-11-17 21:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:00:43 --> Controller Class Initialized
INFO - 2016-11-17 21:00:43 --> Config Class Initialized
INFO - 2016-11-17 21:00:43 --> Model Class Initialized
INFO - 2016-11-17 21:00:43 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:00:43 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:00:43 --> Utf8 Class Initialized
INFO - 2016-11-17 21:00:43 --> URI Class Initialized
INFO - 2016-11-17 21:00:43 --> Router Class Initialized
INFO - 2016-11-17 21:00:43 --> Output Class Initialized
INFO - 2016-11-17 21:00:43 --> Security Class Initialized
DEBUG - 2016-11-17 21:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:00:43 --> Input Class Initialized
INFO - 2016-11-17 21:00:43 --> Language Class Initialized
INFO - 2016-11-17 21:00:43 --> Loader Class Initialized
INFO - 2016-11-17 21:00:43 --> Helper loaded: url_helper
INFO - 2016-11-17 21:00:43 --> Helper loaded: form_helper
INFO - 2016-11-17 21:00:43 --> Database Driver Class Initialized
INFO - 2016-11-17 21:00:44 --> Config Class Initialized
INFO - 2016-11-17 21:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:00:44 --> Hooks Class Initialized
INFO - 2016-11-17 21:00:44 --> Controller Class Initialized
DEBUG - 2016-11-17 21:00:44 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:00:44 --> Model Class Initialized
INFO - 2016-11-17 21:00:44 --> Utf8 Class Initialized
INFO - 2016-11-17 21:00:44 --> URI Class Initialized
INFO - 2016-11-17 21:00:44 --> Router Class Initialized
INFO - 2016-11-17 21:00:44 --> Output Class Initialized
INFO - 2016-11-17 21:00:44 --> Security Class Initialized
DEBUG - 2016-11-17 21:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:00:44 --> Input Class Initialized
INFO - 2016-11-17 21:00:44 --> Language Class Initialized
INFO - 2016-11-17 21:00:44 --> Loader Class Initialized
INFO - 2016-11-17 21:00:44 --> Helper loaded: url_helper
INFO - 2016-11-17 21:00:44 --> Helper loaded: form_helper
INFO - 2016-11-17 21:00:44 --> Database Driver Class Initialized
INFO - 2016-11-17 21:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:00:44 --> Controller Class Initialized
INFO - 2016-11-17 21:00:44 --> Config Class Initialized
INFO - 2016-11-17 21:00:44 --> Model Class Initialized
INFO - 2016-11-17 21:00:44 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:00:44 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:00:44 --> Utf8 Class Initialized
INFO - 2016-11-17 21:00:44 --> URI Class Initialized
INFO - 2016-11-17 21:00:44 --> Router Class Initialized
INFO - 2016-11-17 21:00:44 --> Output Class Initialized
INFO - 2016-11-17 21:00:44 --> Security Class Initialized
DEBUG - 2016-11-17 21:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:00:44 --> Input Class Initialized
INFO - 2016-11-17 21:00:44 --> Language Class Initialized
INFO - 2016-11-17 21:00:44 --> Loader Class Initialized
INFO - 2016-11-17 21:00:44 --> Helper loaded: url_helper
INFO - 2016-11-17 21:00:44 --> Helper loaded: form_helper
INFO - 2016-11-17 21:00:44 --> Database Driver Class Initialized
INFO - 2016-11-17 21:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:00:44 --> Controller Class Initialized
INFO - 2016-11-17 21:00:44 --> Model Class Initialized
INFO - 2016-11-17 21:00:44 --> Config Class Initialized
INFO - 2016-11-17 21:00:44 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:00:44 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:00:44 --> Utf8 Class Initialized
INFO - 2016-11-17 21:00:44 --> URI Class Initialized
INFO - 2016-11-17 21:00:44 --> Router Class Initialized
INFO - 2016-11-17 21:00:44 --> Output Class Initialized
INFO - 2016-11-17 21:00:44 --> Security Class Initialized
DEBUG - 2016-11-17 21:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:00:44 --> Input Class Initialized
INFO - 2016-11-17 21:00:44 --> Language Class Initialized
INFO - 2016-11-17 21:00:44 --> Loader Class Initialized
INFO - 2016-11-17 21:00:44 --> Helper loaded: url_helper
INFO - 2016-11-17 21:00:44 --> Helper loaded: form_helper
INFO - 2016-11-17 21:00:44 --> Config Class Initialized
INFO - 2016-11-17 21:00:44 --> Database Driver Class Initialized
INFO - 2016-11-17 21:00:44 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:00:44 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:00:44 --> Utf8 Class Initialized
INFO - 2016-11-17 21:00:44 --> Controller Class Initialized
INFO - 2016-11-17 21:00:44 --> URI Class Initialized
INFO - 2016-11-17 21:00:44 --> Model Class Initialized
INFO - 2016-11-17 21:00:44 --> Router Class Initialized
INFO - 2016-11-17 21:00:44 --> Output Class Initialized
INFO - 2016-11-17 21:00:44 --> Security Class Initialized
DEBUG - 2016-11-17 21:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:00:44 --> Input Class Initialized
INFO - 2016-11-17 21:00:44 --> Language Class Initialized
INFO - 2016-11-17 21:00:44 --> Loader Class Initialized
INFO - 2016-11-17 21:00:44 --> Helper loaded: url_helper
INFO - 2016-11-17 21:00:44 --> Helper loaded: form_helper
INFO - 2016-11-17 21:00:44 --> Database Driver Class Initialized
INFO - 2016-11-17 21:00:44 --> Config Class Initialized
INFO - 2016-11-17 21:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:00:44 --> Hooks Class Initialized
INFO - 2016-11-17 21:00:44 --> Controller Class Initialized
DEBUG - 2016-11-17 21:00:44 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:00:44 --> Model Class Initialized
INFO - 2016-11-17 21:00:44 --> Utf8 Class Initialized
INFO - 2016-11-17 21:00:44 --> URI Class Initialized
INFO - 2016-11-17 21:00:44 --> Router Class Initialized
INFO - 2016-11-17 21:00:44 --> Output Class Initialized
INFO - 2016-11-17 21:00:44 --> Security Class Initialized
DEBUG - 2016-11-17 21:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:00:44 --> Input Class Initialized
INFO - 2016-11-17 21:00:44 --> Language Class Initialized
INFO - 2016-11-17 21:00:44 --> Loader Class Initialized
INFO - 2016-11-17 21:00:44 --> Helper loaded: url_helper
INFO - 2016-11-17 21:00:44 --> Helper loaded: form_helper
INFO - 2016-11-17 21:00:44 --> Database Driver Class Initialized
INFO - 2016-11-17 21:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:00:44 --> Controller Class Initialized
INFO - 2016-11-17 21:00:44 --> Model Class Initialized
INFO - 2016-11-17 21:00:44 --> Config Class Initialized
INFO - 2016-11-17 21:00:44 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:00:44 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:00:44 --> Utf8 Class Initialized
INFO - 2016-11-17 21:00:44 --> URI Class Initialized
INFO - 2016-11-17 21:00:44 --> Router Class Initialized
INFO - 2016-11-17 21:00:44 --> Output Class Initialized
INFO - 2016-11-17 21:00:44 --> Security Class Initialized
DEBUG - 2016-11-17 21:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:00:44 --> Input Class Initialized
INFO - 2016-11-17 21:00:44 --> Language Class Initialized
INFO - 2016-11-17 21:00:44 --> Loader Class Initialized
INFO - 2016-11-17 21:00:44 --> Helper loaded: url_helper
INFO - 2016-11-17 21:00:44 --> Helper loaded: form_helper
INFO - 2016-11-17 21:00:44 --> Database Driver Class Initialized
INFO - 2016-11-17 21:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:00:44 --> Config Class Initialized
INFO - 2016-11-17 21:00:44 --> Controller Class Initialized
INFO - 2016-11-17 21:00:44 --> Hooks Class Initialized
INFO - 2016-11-17 21:00:44 --> Model Class Initialized
DEBUG - 2016-11-17 21:00:44 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:00:45 --> Utf8 Class Initialized
INFO - 2016-11-17 21:00:45 --> URI Class Initialized
INFO - 2016-11-17 21:00:45 --> Router Class Initialized
INFO - 2016-11-17 21:00:45 --> Output Class Initialized
INFO - 2016-11-17 21:00:45 --> Security Class Initialized
DEBUG - 2016-11-17 21:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:00:45 --> Input Class Initialized
INFO - 2016-11-17 21:00:45 --> Language Class Initialized
INFO - 2016-11-17 21:00:45 --> Loader Class Initialized
INFO - 2016-11-17 21:00:45 --> Helper loaded: url_helper
INFO - 2016-11-17 21:00:45 --> Helper loaded: form_helper
INFO - 2016-11-17 21:00:45 --> Database Driver Class Initialized
INFO - 2016-11-17 21:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:00:45 --> Controller Class Initialized
INFO - 2016-11-17 21:00:45 --> Model Class Initialized
INFO - 2016-11-17 21:01:33 --> Config Class Initialized
INFO - 2016-11-17 21:01:33 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:01:33 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:01:33 --> Utf8 Class Initialized
INFO - 2016-11-17 21:01:33 --> URI Class Initialized
DEBUG - 2016-11-17 21:01:33 --> No URI present. Default controller set.
INFO - 2016-11-17 21:01:33 --> Router Class Initialized
INFO - 2016-11-17 21:01:33 --> Output Class Initialized
INFO - 2016-11-17 21:01:33 --> Security Class Initialized
DEBUG - 2016-11-17 21:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:01:33 --> Input Class Initialized
INFO - 2016-11-17 21:01:33 --> Language Class Initialized
INFO - 2016-11-17 21:01:33 --> Loader Class Initialized
INFO - 2016-11-17 21:01:33 --> Helper loaded: url_helper
INFO - 2016-11-17 21:01:33 --> Helper loaded: form_helper
INFO - 2016-11-17 21:01:33 --> Database Driver Class Initialized
INFO - 2016-11-17 21:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:01:33 --> Controller Class Initialized
INFO - 2016-11-17 21:01:33 --> Model Class Initialized
INFO - 2016-11-17 21:01:33 --> Model Class Initialized
INFO - 2016-11-17 21:01:33 --> Model Class Initialized
INFO - 2016-11-17 21:01:33 --> Model Class Initialized
INFO - 2016-11-17 21:01:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 21:01:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 21:01:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 21:01:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 21:01:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 21:01:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 21:01:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 21:01:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 21:01:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 21:01:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 21:01:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 21:01:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 21:01:33 --> Final output sent to browser
DEBUG - 2016-11-17 21:01:33 --> Total execution time: 0.3646
INFO - 2016-11-17 21:01:39 --> Config Class Initialized
INFO - 2016-11-17 21:01:39 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:01:39 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:01:39 --> Utf8 Class Initialized
INFO - 2016-11-17 21:01:39 --> URI Class Initialized
INFO - 2016-11-17 21:01:39 --> Router Class Initialized
INFO - 2016-11-17 21:01:39 --> Output Class Initialized
INFO - 2016-11-17 21:01:39 --> Security Class Initialized
DEBUG - 2016-11-17 21:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:01:39 --> Input Class Initialized
INFO - 2016-11-17 21:01:39 --> Language Class Initialized
INFO - 2016-11-17 21:01:39 --> Loader Class Initialized
INFO - 2016-11-17 21:01:39 --> Helper loaded: url_helper
INFO - 2016-11-17 21:01:39 --> Helper loaded: form_helper
INFO - 2016-11-17 21:01:39 --> Database Driver Class Initialized
INFO - 2016-11-17 21:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:01:39 --> Controller Class Initialized
INFO - 2016-11-17 21:01:39 --> Model Class Initialized
INFO - 2016-11-17 21:01:39 --> Form Validation Class Initialized
INFO - 2016-11-17 21:01:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:01:39 --> Final output sent to browser
DEBUG - 2016-11-17 21:01:39 --> Total execution time: 0.2219
INFO - 2016-11-17 21:05:41 --> Config Class Initialized
INFO - 2016-11-17 21:05:41 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:05:41 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:05:41 --> Utf8 Class Initialized
INFO - 2016-11-17 21:05:41 --> URI Class Initialized
DEBUG - 2016-11-17 21:05:41 --> No URI present. Default controller set.
INFO - 2016-11-17 21:05:41 --> Router Class Initialized
INFO - 2016-11-17 21:05:41 --> Output Class Initialized
INFO - 2016-11-17 21:05:41 --> Security Class Initialized
DEBUG - 2016-11-17 21:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:05:41 --> Input Class Initialized
INFO - 2016-11-17 21:05:41 --> Language Class Initialized
INFO - 2016-11-17 21:05:41 --> Loader Class Initialized
INFO - 2016-11-17 21:05:41 --> Helper loaded: url_helper
INFO - 2016-11-17 21:05:41 --> Helper loaded: form_helper
INFO - 2016-11-17 21:05:41 --> Database Driver Class Initialized
INFO - 2016-11-17 21:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:05:41 --> Controller Class Initialized
INFO - 2016-11-17 21:05:41 --> Model Class Initialized
INFO - 2016-11-17 21:05:41 --> Model Class Initialized
INFO - 2016-11-17 21:05:41 --> Model Class Initialized
INFO - 2016-11-17 21:05:41 --> Model Class Initialized
INFO - 2016-11-17 21:05:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 21:05:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 21:05:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 21:05:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 21:05:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 21:05:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 21:05:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 21:05:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 21:05:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 21:05:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 21:05:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 21:05:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 21:05:42 --> Final output sent to browser
DEBUG - 2016-11-17 21:05:42 --> Total execution time: 0.3947
INFO - 2016-11-17 21:05:46 --> Config Class Initialized
INFO - 2016-11-17 21:05:46 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:05:46 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:05:46 --> Utf8 Class Initialized
INFO - 2016-11-17 21:05:46 --> URI Class Initialized
INFO - 2016-11-17 21:05:46 --> Router Class Initialized
INFO - 2016-11-17 21:05:46 --> Output Class Initialized
INFO - 2016-11-17 21:05:46 --> Security Class Initialized
DEBUG - 2016-11-17 21:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:05:46 --> Input Class Initialized
INFO - 2016-11-17 21:05:46 --> Language Class Initialized
INFO - 2016-11-17 21:05:46 --> Loader Class Initialized
INFO - 2016-11-17 21:05:46 --> Helper loaded: url_helper
INFO - 2016-11-17 21:05:46 --> Helper loaded: form_helper
INFO - 2016-11-17 21:05:46 --> Database Driver Class Initialized
INFO - 2016-11-17 21:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:05:46 --> Controller Class Initialized
INFO - 2016-11-17 21:05:46 --> Model Class Initialized
INFO - 2016-11-17 21:05:46 --> Form Validation Class Initialized
INFO - 2016-11-17 21:05:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:05:46 --> Final output sent to browser
DEBUG - 2016-11-17 21:05:46 --> Total execution time: 0.1993
INFO - 2016-11-17 21:05:56 --> Config Class Initialized
INFO - 2016-11-17 21:05:56 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:05:57 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:05:57 --> Utf8 Class Initialized
INFO - 2016-11-17 21:05:57 --> URI Class Initialized
INFO - 2016-11-17 21:05:57 --> Router Class Initialized
INFO - 2016-11-17 21:05:57 --> Output Class Initialized
INFO - 2016-11-17 21:05:57 --> Security Class Initialized
DEBUG - 2016-11-17 21:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:05:57 --> Input Class Initialized
INFO - 2016-11-17 21:05:57 --> Language Class Initialized
INFO - 2016-11-17 21:05:57 --> Loader Class Initialized
INFO - 2016-11-17 21:05:57 --> Helper loaded: url_helper
INFO - 2016-11-17 21:05:57 --> Helper loaded: form_helper
INFO - 2016-11-17 21:05:57 --> Database Driver Class Initialized
INFO - 2016-11-17 21:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:05:57 --> Controller Class Initialized
INFO - 2016-11-17 21:05:57 --> Model Class Initialized
INFO - 2016-11-17 21:05:57 --> Form Validation Class Initialized
INFO - 2016-11-17 21:05:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:05:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 21:05:57 --> Final output sent to browser
DEBUG - 2016-11-17 21:05:57 --> Total execution time: 0.3570
INFO - 2016-11-17 21:06:28 --> Config Class Initialized
INFO - 2016-11-17 21:06:28 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:06:28 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:06:28 --> Utf8 Class Initialized
INFO - 2016-11-17 21:06:28 --> URI Class Initialized
DEBUG - 2016-11-17 21:06:28 --> No URI present. Default controller set.
INFO - 2016-11-17 21:06:28 --> Router Class Initialized
INFO - 2016-11-17 21:06:28 --> Output Class Initialized
INFO - 2016-11-17 21:06:28 --> Security Class Initialized
DEBUG - 2016-11-17 21:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:06:28 --> Input Class Initialized
INFO - 2016-11-17 21:06:28 --> Language Class Initialized
INFO - 2016-11-17 21:06:28 --> Loader Class Initialized
INFO - 2016-11-17 21:06:28 --> Helper loaded: url_helper
INFO - 2016-11-17 21:06:28 --> Helper loaded: form_helper
INFO - 2016-11-17 21:06:28 --> Database Driver Class Initialized
INFO - 2016-11-17 21:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:06:28 --> Controller Class Initialized
INFO - 2016-11-17 21:06:28 --> Model Class Initialized
INFO - 2016-11-17 21:06:28 --> Model Class Initialized
INFO - 2016-11-17 21:06:28 --> Model Class Initialized
INFO - 2016-11-17 21:06:28 --> Model Class Initialized
INFO - 2016-11-17 21:06:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 21:06:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 21:06:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 21:06:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 21:06:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 21:06:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 21:06:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 21:06:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 21:06:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 21:06:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 21:06:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 21:06:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 21:06:28 --> Final output sent to browser
DEBUG - 2016-11-17 21:06:28 --> Total execution time: 0.3837
INFO - 2016-11-17 21:06:39 --> Config Class Initialized
INFO - 2016-11-17 21:06:39 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:06:39 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:06:39 --> Utf8 Class Initialized
INFO - 2016-11-17 21:06:39 --> URI Class Initialized
INFO - 2016-11-17 21:06:39 --> Router Class Initialized
INFO - 2016-11-17 21:06:39 --> Output Class Initialized
INFO - 2016-11-17 21:06:39 --> Security Class Initialized
DEBUG - 2016-11-17 21:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:06:39 --> Input Class Initialized
INFO - 2016-11-17 21:06:39 --> Language Class Initialized
INFO - 2016-11-17 21:06:39 --> Loader Class Initialized
INFO - 2016-11-17 21:06:39 --> Helper loaded: url_helper
INFO - 2016-11-17 21:06:39 --> Helper loaded: form_helper
INFO - 2016-11-17 21:06:39 --> Database Driver Class Initialized
INFO - 2016-11-17 21:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:06:39 --> Controller Class Initialized
INFO - 2016-11-17 21:06:39 --> Model Class Initialized
INFO - 2016-11-17 21:06:39 --> Form Validation Class Initialized
INFO - 2016-11-17 21:06:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:06:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 21:06:39 --> Final output sent to browser
DEBUG - 2016-11-17 21:06:39 --> Total execution time: 0.3957
INFO - 2016-11-17 21:06:44 --> Config Class Initialized
INFO - 2016-11-17 21:06:44 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:06:44 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:06:44 --> Utf8 Class Initialized
INFO - 2016-11-17 21:06:44 --> URI Class Initialized
DEBUG - 2016-11-17 21:06:44 --> No URI present. Default controller set.
INFO - 2016-11-17 21:06:44 --> Router Class Initialized
INFO - 2016-11-17 21:06:44 --> Output Class Initialized
INFO - 2016-11-17 21:06:44 --> Security Class Initialized
DEBUG - 2016-11-17 21:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:06:44 --> Input Class Initialized
INFO - 2016-11-17 21:06:44 --> Language Class Initialized
INFO - 2016-11-17 21:06:44 --> Loader Class Initialized
INFO - 2016-11-17 21:06:44 --> Helper loaded: url_helper
INFO - 2016-11-17 21:06:44 --> Helper loaded: form_helper
INFO - 2016-11-17 21:06:44 --> Database Driver Class Initialized
INFO - 2016-11-17 21:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:06:44 --> Controller Class Initialized
INFO - 2016-11-17 21:06:44 --> Model Class Initialized
INFO - 2016-11-17 21:06:44 --> Model Class Initialized
INFO - 2016-11-17 21:06:44 --> Model Class Initialized
INFO - 2016-11-17 21:06:44 --> Model Class Initialized
INFO - 2016-11-17 21:06:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 21:06:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 21:06:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 21:06:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 21:06:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 21:06:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 21:06:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 21:06:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 21:06:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 21:06:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 21:06:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 21:06:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 21:06:45 --> Final output sent to browser
DEBUG - 2016-11-17 21:06:45 --> Total execution time: 0.3565
INFO - 2016-11-17 21:08:46 --> Config Class Initialized
INFO - 2016-11-17 21:08:46 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:08:46 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:08:46 --> Utf8 Class Initialized
INFO - 2016-11-17 21:08:46 --> URI Class Initialized
INFO - 2016-11-17 21:08:46 --> Router Class Initialized
INFO - 2016-11-17 21:08:46 --> Output Class Initialized
INFO - 2016-11-17 21:08:46 --> Security Class Initialized
DEBUG - 2016-11-17 21:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:08:46 --> Input Class Initialized
INFO - 2016-11-17 21:08:46 --> Language Class Initialized
INFO - 2016-11-17 21:08:46 --> Loader Class Initialized
INFO - 2016-11-17 21:08:46 --> Helper loaded: url_helper
INFO - 2016-11-17 21:08:46 --> Helper loaded: form_helper
INFO - 2016-11-17 21:08:46 --> Database Driver Class Initialized
INFO - 2016-11-17 21:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:08:46 --> Controller Class Initialized
INFO - 2016-11-17 21:08:46 --> Model Class Initialized
INFO - 2016-11-17 21:08:46 --> Form Validation Class Initialized
INFO - 2016-11-17 21:08:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:08:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 21:08:46 --> Final output sent to browser
DEBUG - 2016-11-17 21:08:46 --> Total execution time: 0.3068
INFO - 2016-11-17 21:08:52 --> Config Class Initialized
INFO - 2016-11-17 21:08:52 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:08:52 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:08:52 --> Utf8 Class Initialized
INFO - 2016-11-17 21:08:52 --> URI Class Initialized
DEBUG - 2016-11-17 21:08:52 --> No URI present. Default controller set.
INFO - 2016-11-17 21:08:52 --> Router Class Initialized
INFO - 2016-11-17 21:08:52 --> Output Class Initialized
INFO - 2016-11-17 21:08:52 --> Security Class Initialized
DEBUG - 2016-11-17 21:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:08:52 --> Input Class Initialized
INFO - 2016-11-17 21:08:52 --> Language Class Initialized
INFO - 2016-11-17 21:08:52 --> Loader Class Initialized
INFO - 2016-11-17 21:08:52 --> Helper loaded: url_helper
INFO - 2016-11-17 21:08:52 --> Helper loaded: form_helper
INFO - 2016-11-17 21:08:52 --> Database Driver Class Initialized
INFO - 2016-11-17 21:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:08:52 --> Controller Class Initialized
INFO - 2016-11-17 21:08:52 --> Model Class Initialized
INFO - 2016-11-17 21:08:52 --> Model Class Initialized
INFO - 2016-11-17 21:08:52 --> Model Class Initialized
INFO - 2016-11-17 21:08:52 --> Model Class Initialized
INFO - 2016-11-17 21:08:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 21:08:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 21:08:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 21:08:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 21:08:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 21:08:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 21:08:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 21:08:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 21:08:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 21:08:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 21:08:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 21:08:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 21:08:52 --> Final output sent to browser
DEBUG - 2016-11-17 21:08:52 --> Total execution time: 0.3737
INFO - 2016-11-17 21:08:56 --> Config Class Initialized
INFO - 2016-11-17 21:08:56 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:08:56 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:08:56 --> Utf8 Class Initialized
INFO - 2016-11-17 21:08:56 --> URI Class Initialized
INFO - 2016-11-17 21:08:56 --> Router Class Initialized
INFO - 2016-11-17 21:08:56 --> Output Class Initialized
INFO - 2016-11-17 21:08:56 --> Security Class Initialized
DEBUG - 2016-11-17 21:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:08:56 --> Input Class Initialized
INFO - 2016-11-17 21:08:56 --> Language Class Initialized
INFO - 2016-11-17 21:08:56 --> Loader Class Initialized
INFO - 2016-11-17 21:08:56 --> Helper loaded: url_helper
INFO - 2016-11-17 21:08:57 --> Helper loaded: form_helper
INFO - 2016-11-17 21:08:57 --> Database Driver Class Initialized
INFO - 2016-11-17 21:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:08:57 --> Controller Class Initialized
INFO - 2016-11-17 21:08:57 --> Model Class Initialized
INFO - 2016-11-17 21:08:57 --> Form Validation Class Initialized
INFO - 2016-11-17 21:08:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:08:57 --> Final output sent to browser
DEBUG - 2016-11-17 21:08:57 --> Total execution time: 0.2004
INFO - 2016-11-17 21:09:11 --> Config Class Initialized
INFO - 2016-11-17 21:09:11 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:09:11 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:09:11 --> Utf8 Class Initialized
INFO - 2016-11-17 21:09:11 --> URI Class Initialized
INFO - 2016-11-17 21:09:11 --> Router Class Initialized
INFO - 2016-11-17 21:09:11 --> Output Class Initialized
INFO - 2016-11-17 21:09:11 --> Security Class Initialized
DEBUG - 2016-11-17 21:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:09:11 --> Input Class Initialized
INFO - 2016-11-17 21:09:11 --> Language Class Initialized
INFO - 2016-11-17 21:09:11 --> Loader Class Initialized
INFO - 2016-11-17 21:09:11 --> Helper loaded: url_helper
INFO - 2016-11-17 21:09:11 --> Helper loaded: form_helper
INFO - 2016-11-17 21:09:11 --> Database Driver Class Initialized
INFO - 2016-11-17 21:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:09:11 --> Controller Class Initialized
INFO - 2016-11-17 21:09:11 --> Model Class Initialized
INFO - 2016-11-17 21:09:11 --> Form Validation Class Initialized
INFO - 2016-11-17 21:09:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:09:11 --> Final output sent to browser
DEBUG - 2016-11-17 21:09:11 --> Total execution time: 0.2036
INFO - 2016-11-17 21:09:27 --> Config Class Initialized
INFO - 2016-11-17 21:09:27 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:09:27 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:09:27 --> Utf8 Class Initialized
INFO - 2016-11-17 21:09:27 --> URI Class Initialized
INFO - 2016-11-17 21:09:27 --> Router Class Initialized
INFO - 2016-11-17 21:09:27 --> Output Class Initialized
INFO - 2016-11-17 21:09:27 --> Security Class Initialized
DEBUG - 2016-11-17 21:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:09:27 --> Input Class Initialized
INFO - 2016-11-17 21:09:27 --> Language Class Initialized
INFO - 2016-11-17 21:09:27 --> Loader Class Initialized
INFO - 2016-11-17 21:09:27 --> Helper loaded: url_helper
INFO - 2016-11-17 21:09:27 --> Helper loaded: form_helper
INFO - 2016-11-17 21:09:27 --> Database Driver Class Initialized
INFO - 2016-11-17 21:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:09:27 --> Controller Class Initialized
INFO - 2016-11-17 21:09:27 --> Model Class Initialized
INFO - 2016-11-17 21:09:27 --> Form Validation Class Initialized
INFO - 2016-11-17 21:09:27 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-17 21:09:27 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-17 21:09:27 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-10', '2016-11-11', '3', '1', '2016-11-17 21:09:27', '1', '')
INFO - 2016-11-17 21:09:27 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:09:28 --> Config Class Initialized
INFO - 2016-11-17 21:09:28 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:09:28 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:09:28 --> Utf8 Class Initialized
INFO - 2016-11-17 21:09:28 --> URI Class Initialized
INFO - 2016-11-17 21:09:28 --> Router Class Initialized
INFO - 2016-11-17 21:09:28 --> Output Class Initialized
INFO - 2016-11-17 21:09:28 --> Security Class Initialized
DEBUG - 2016-11-17 21:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:09:28 --> Input Class Initialized
INFO - 2016-11-17 21:09:28 --> Language Class Initialized
INFO - 2016-11-17 21:09:28 --> Loader Class Initialized
INFO - 2016-11-17 21:09:28 --> Helper loaded: url_helper
INFO - 2016-11-17 21:09:28 --> Helper loaded: form_helper
INFO - 2016-11-17 21:09:28 --> Database Driver Class Initialized
INFO - 2016-11-17 21:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:09:28 --> Controller Class Initialized
INFO - 2016-11-17 21:09:28 --> Config Class Initialized
INFO - 2016-11-17 21:09:28 --> Model Class Initialized
INFO - 2016-11-17 21:09:28 --> Hooks Class Initialized
INFO - 2016-11-17 21:09:28 --> Form Validation Class Initialized
DEBUG - 2016-11-17 21:09:28 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:09:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:09:28 --> Utf8 Class Initialized
ERROR - 2016-11-17 21:09:28 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-17 21:09:28 --> URI Class Initialized
INFO - 2016-11-17 21:09:28 --> Router Class Initialized
INFO - 2016-11-17 21:09:28 --> Output Class Initialized
INFO - 2016-11-17 21:09:28 --> Security Class Initialized
DEBUG - 2016-11-17 21:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:09:28 --> Config Class Initialized
INFO - 2016-11-17 21:09:28 --> Input Class Initialized
INFO - 2016-11-17 21:09:28 --> Hooks Class Initialized
INFO - 2016-11-17 21:09:28 --> Language Class Initialized
DEBUG - 2016-11-17 21:09:28 --> UTF-8 Support Enabled
ERROR - 2016-11-17 21:09:28 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-10', '2016-11-11', '3', '1', '2016-11-17 21:09:28', '1', '')
INFO - 2016-11-17 21:09:28 --> Utf8 Class Initialized
INFO - 2016-11-17 21:09:28 --> Loader Class Initialized
INFO - 2016-11-17 21:09:28 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:09:28 --> Helper loaded: url_helper
INFO - 2016-11-17 21:09:28 --> URI Class Initialized
INFO - 2016-11-17 21:09:28 --> Router Class Initialized
INFO - 2016-11-17 21:09:28 --> Helper loaded: form_helper
INFO - 2016-11-17 21:09:28 --> Output Class Initialized
INFO - 2016-11-17 21:09:28 --> Database Driver Class Initialized
INFO - 2016-11-17 21:09:28 --> Security Class Initialized
INFO - 2016-11-17 21:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:09:28 --> Controller Class Initialized
DEBUG - 2016-11-17 21:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:09:29 --> Input Class Initialized
INFO - 2016-11-17 21:09:29 --> Config Class Initialized
INFO - 2016-11-17 21:09:29 --> Model Class Initialized
INFO - 2016-11-17 21:09:29 --> Language Class Initialized
INFO - 2016-11-17 21:09:29 --> Hooks Class Initialized
INFO - 2016-11-17 21:09:29 --> Form Validation Class Initialized
DEBUG - 2016-11-17 21:09:29 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:09:29 --> Loader Class Initialized
INFO - 2016-11-17 21:09:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:09:29 --> Utf8 Class Initialized
INFO - 2016-11-17 21:09:29 --> Helper loaded: url_helper
INFO - 2016-11-17 21:09:29 --> URI Class Initialized
ERROR - 2016-11-17 21:09:29 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-17 21:09:29 --> Helper loaded: form_helper
INFO - 2016-11-17 21:09:29 --> Router Class Initialized
INFO - 2016-11-17 21:09:29 --> Database Driver Class Initialized
INFO - 2016-11-17 21:09:29 --> Output Class Initialized
INFO - 2016-11-17 21:09:29 --> Security Class Initialized
DEBUG - 2016-11-17 21:09:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-11-17 21:09:29 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-10', '2016-11-11', '3', '1', '2016-11-17 21:09:29', '1', '')
INFO - 2016-11-17 21:09:29 --> Input Class Initialized
INFO - 2016-11-17 21:09:29 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:09:29 --> Language Class Initialized
INFO - 2016-11-17 21:09:29 --> Config Class Initialized
INFO - 2016-11-17 21:09:29 --> Loader Class Initialized
INFO - 2016-11-17 21:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:09:29 --> Hooks Class Initialized
INFO - 2016-11-17 21:09:29 --> Controller Class Initialized
DEBUG - 2016-11-17 21:09:29 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:09:29 --> Helper loaded: url_helper
INFO - 2016-11-17 21:09:29 --> Utf8 Class Initialized
INFO - 2016-11-17 21:09:29 --> Model Class Initialized
INFO - 2016-11-17 21:09:29 --> Helper loaded: form_helper
INFO - 2016-11-17 21:09:29 --> Form Validation Class Initialized
INFO - 2016-11-17 21:09:29 --> URI Class Initialized
INFO - 2016-11-17 21:09:29 --> Database Driver Class Initialized
INFO - 2016-11-17 21:09:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:09:29 --> Router Class Initialized
ERROR - 2016-11-17 21:09:29 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-17 21:09:29 --> Output Class Initialized
INFO - 2016-11-17 21:09:29 --> Security Class Initialized
DEBUG - 2016-11-17 21:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:09:29 --> Input Class Initialized
INFO - 2016-11-17 21:09:29 --> Language Class Initialized
INFO - 2016-11-17 21:09:29 --> Loader Class Initialized
INFO - 2016-11-17 21:09:29 --> Config Class Initialized
INFO - 2016-11-17 21:09:29 --> Helper loaded: url_helper
INFO - 2016-11-17 21:09:29 --> Hooks Class Initialized
ERROR - 2016-11-17 21:09:29 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-10', '2016-11-11', '3', '1', '2016-11-17 21:09:29', '1', '')
INFO - 2016-11-17 21:09:29 --> Helper loaded: form_helper
DEBUG - 2016-11-17 21:09:29 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:09:29 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:09:29 --> Utf8 Class Initialized
INFO - 2016-11-17 21:09:29 --> Database Driver Class Initialized
INFO - 2016-11-17 21:09:29 --> URI Class Initialized
INFO - 2016-11-17 21:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:09:29 --> Controller Class Initialized
INFO - 2016-11-17 21:09:29 --> Router Class Initialized
INFO - 2016-11-17 21:09:29 --> Model Class Initialized
INFO - 2016-11-17 21:09:29 --> Output Class Initialized
INFO - 2016-11-17 21:09:29 --> Form Validation Class Initialized
INFO - 2016-11-17 21:09:29 --> Security Class Initialized
INFO - 2016-11-17 21:09:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-17 21:09:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-11-17 21:09:29 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-17 21:09:29 --> Input Class Initialized
INFO - 2016-11-17 21:09:29 --> Language Class Initialized
INFO - 2016-11-17 21:09:29 --> Config Class Initialized
INFO - 2016-11-17 21:09:29 --> Loader Class Initialized
INFO - 2016-11-17 21:09:29 --> Hooks Class Initialized
ERROR - 2016-11-17 21:09:29 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-10', '2016-11-11', '3', '1', '2016-11-17 21:09:29', '1', '')
DEBUG - 2016-11-17 21:09:29 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:09:29 --> Helper loaded: url_helper
INFO - 2016-11-17 21:09:29 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:09:29 --> Utf8 Class Initialized
INFO - 2016-11-17 21:09:29 --> Helper loaded: form_helper
INFO - 2016-11-17 21:09:29 --> URI Class Initialized
INFO - 2016-11-17 21:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:09:29 --> Database Driver Class Initialized
INFO - 2016-11-17 21:09:29 --> Controller Class Initialized
INFO - 2016-11-17 21:09:29 --> Router Class Initialized
INFO - 2016-11-17 21:09:29 --> Model Class Initialized
INFO - 2016-11-17 21:09:29 --> Output Class Initialized
INFO - 2016-11-17 21:09:29 --> Form Validation Class Initialized
INFO - 2016-11-17 21:09:29 --> Security Class Initialized
INFO - 2016-11-17 21:09:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-17 21:09:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-11-17 21:09:29 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-17 21:09:29 --> Input Class Initialized
INFO - 2016-11-17 21:09:29 --> Language Class Initialized
INFO - 2016-11-17 21:09:29 --> Loader Class Initialized
INFO - 2016-11-17 21:09:29 --> Helper loaded: url_helper
INFO - 2016-11-17 21:09:29 --> Helper loaded: form_helper
INFO - 2016-11-17 21:09:29 --> Database Driver Class Initialized
ERROR - 2016-11-17 21:09:29 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-10', '2016-11-11', '3', '1', '2016-11-17 21:09:29', '1', '')
INFO - 2016-11-17 21:09:29 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:09:29 --> Controller Class Initialized
INFO - 2016-11-17 21:09:29 --> Model Class Initialized
INFO - 2016-11-17 21:09:29 --> Form Validation Class Initialized
INFO - 2016-11-17 21:09:29 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-17 21:09:29 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-17 21:09:29 --> Config Class Initialized
INFO - 2016-11-17 21:09:29 --> Hooks Class Initialized
ERROR - 2016-11-17 21:09:29 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-10', '2016-11-11', '3', '1', '2016-11-17 21:09:29', '1', '')
DEBUG - 2016-11-17 21:09:29 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:09:29 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:09:29 --> Utf8 Class Initialized
INFO - 2016-11-17 21:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:09:29 --> URI Class Initialized
INFO - 2016-11-17 21:09:29 --> Controller Class Initialized
INFO - 2016-11-17 21:09:29 --> Router Class Initialized
INFO - 2016-11-17 21:09:29 --> Model Class Initialized
INFO - 2016-11-17 21:09:29 --> Output Class Initialized
INFO - 2016-11-17 21:09:29 --> Form Validation Class Initialized
INFO - 2016-11-17 21:09:29 --> Security Class Initialized
INFO - 2016-11-17 21:09:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-17 21:09:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-11-17 21:09:29 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-17 21:09:29 --> Input Class Initialized
INFO - 2016-11-17 21:09:29 --> Language Class Initialized
INFO - 2016-11-17 21:09:29 --> Loader Class Initialized
INFO - 2016-11-17 21:09:29 --> Helper loaded: url_helper
INFO - 2016-11-17 21:09:29 --> Helper loaded: form_helper
ERROR - 2016-11-17 21:09:29 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-10', '2016-11-11', '3', '1', '2016-11-17 21:09:29', '1', '')
INFO - 2016-11-17 21:09:29 --> Database Driver Class Initialized
INFO - 2016-11-17 21:09:29 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:09:29 --> Config Class Initialized
INFO - 2016-11-17 21:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:09:29 --> Hooks Class Initialized
INFO - 2016-11-17 21:09:29 --> Controller Class Initialized
DEBUG - 2016-11-17 21:09:29 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:09:30 --> Model Class Initialized
INFO - 2016-11-17 21:09:30 --> Utf8 Class Initialized
INFO - 2016-11-17 21:09:30 --> URI Class Initialized
INFO - 2016-11-17 21:09:30 --> Form Validation Class Initialized
INFO - 2016-11-17 21:09:30 --> Router Class Initialized
INFO - 2016-11-17 21:09:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:09:30 --> Output Class Initialized
ERROR - 2016-11-17 21:09:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-17 21:09:30 --> Security Class Initialized
DEBUG - 2016-11-17 21:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:09:30 --> Input Class Initialized
INFO - 2016-11-17 21:09:30 --> Language Class Initialized
INFO - 2016-11-17 21:09:30 --> Config Class Initialized
ERROR - 2016-11-17 21:09:30 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-10', '2016-11-11', '3', '1', '2016-11-17 21:09:30', '1', '')
INFO - 2016-11-17 21:09:30 --> Loader Class Initialized
INFO - 2016-11-17 21:09:30 --> Hooks Class Initialized
INFO - 2016-11-17 21:09:30 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-11-17 21:09:30 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:09:30 --> Helper loaded: url_helper
INFO - 2016-11-17 21:09:30 --> Utf8 Class Initialized
INFO - 2016-11-17 21:09:30 --> Helper loaded: form_helper
INFO - 2016-11-17 21:09:30 --> URI Class Initialized
INFO - 2016-11-17 21:09:30 --> Database Driver Class Initialized
INFO - 2016-11-17 21:09:30 --> Router Class Initialized
INFO - 2016-11-17 21:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:09:30 --> Output Class Initialized
INFO - 2016-11-17 21:09:30 --> Controller Class Initialized
INFO - 2016-11-17 21:09:30 --> Model Class Initialized
INFO - 2016-11-17 21:09:30 --> Security Class Initialized
INFO - 2016-11-17 21:09:30 --> Form Validation Class Initialized
DEBUG - 2016-11-17 21:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:09:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:09:30 --> Input Class Initialized
INFO - 2016-11-17 21:09:30 --> Language Class Initialized
ERROR - 2016-11-17 21:09:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-17 21:09:30 --> Config Class Initialized
INFO - 2016-11-17 21:09:30 --> Loader Class Initialized
INFO - 2016-11-17 21:09:30 --> Hooks Class Initialized
INFO - 2016-11-17 21:09:30 --> Helper loaded: url_helper
DEBUG - 2016-11-17 21:09:30 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:09:30 --> Helper loaded: form_helper
INFO - 2016-11-17 21:09:30 --> Utf8 Class Initialized
ERROR - 2016-11-17 21:09:30 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-10', '2016-11-11', '3', '1', '2016-11-17 21:09:30', '1', '')
INFO - 2016-11-17 21:09:30 --> URI Class Initialized
INFO - 2016-11-17 21:09:30 --> Database Driver Class Initialized
INFO - 2016-11-17 21:09:30 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:09:30 --> Router Class Initialized
INFO - 2016-11-17 21:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:09:30 --> Output Class Initialized
INFO - 2016-11-17 21:09:30 --> Controller Class Initialized
INFO - 2016-11-17 21:09:30 --> Model Class Initialized
INFO - 2016-11-17 21:09:30 --> Security Class Initialized
INFO - 2016-11-17 21:09:30 --> Form Validation Class Initialized
DEBUG - 2016-11-17 21:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:09:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:09:30 --> Input Class Initialized
INFO - 2016-11-17 21:09:30 --> Language Class Initialized
ERROR - 2016-11-17 21:09:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-17 21:09:30 --> Loader Class Initialized
INFO - 2016-11-17 21:09:30 --> Helper loaded: url_helper
INFO - 2016-11-17 21:09:30 --> Config Class Initialized
ERROR - 2016-11-17 21:09:30 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-10', '2016-11-11', '3', '1', '2016-11-17 21:09:30', '1', '')
INFO - 2016-11-17 21:09:30 --> Hooks Class Initialized
INFO - 2016-11-17 21:09:30 --> Helper loaded: form_helper
INFO - 2016-11-17 21:09:30 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-11-17 21:09:30 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:09:30 --> Database Driver Class Initialized
INFO - 2016-11-17 21:09:30 --> Utf8 Class Initialized
INFO - 2016-11-17 21:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:09:30 --> URI Class Initialized
INFO - 2016-11-17 21:09:30 --> Controller Class Initialized
INFO - 2016-11-17 21:09:30 --> Model Class Initialized
INFO - 2016-11-17 21:09:30 --> Router Class Initialized
INFO - 2016-11-17 21:09:30 --> Form Validation Class Initialized
INFO - 2016-11-17 21:09:30 --> Output Class Initialized
INFO - 2016-11-17 21:09:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:09:30 --> Security Class Initialized
ERROR - 2016-11-17 21:09:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
DEBUG - 2016-11-17 21:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:09:30 --> Config Class Initialized
INFO - 2016-11-17 21:09:30 --> Hooks Class Initialized
INFO - 2016-11-17 21:09:30 --> Input Class Initialized
INFO - 2016-11-17 21:09:30 --> Language Class Initialized
DEBUG - 2016-11-17 21:09:30 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:09:30 --> Loader Class Initialized
INFO - 2016-11-17 21:09:30 --> Utf8 Class Initialized
INFO - 2016-11-17 21:09:30 --> URI Class Initialized
INFO - 2016-11-17 21:09:30 --> Helper loaded: url_helper
ERROR - 2016-11-17 21:09:30 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-10', '2016-11-11', '3', '1', '2016-11-17 21:09:30', '1', '')
INFO - 2016-11-17 21:09:30 --> Router Class Initialized
INFO - 2016-11-17 21:09:30 --> Helper loaded: form_helper
INFO - 2016-11-17 21:09:30 --> Output Class Initialized
INFO - 2016-11-17 21:09:30 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:09:30 --> Database Driver Class Initialized
INFO - 2016-11-17 21:09:30 --> Security Class Initialized
INFO - 2016-11-17 21:09:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-17 21:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:09:30 --> Controller Class Initialized
INFO - 2016-11-17 21:09:30 --> Input Class Initialized
INFO - 2016-11-17 21:09:30 --> Model Class Initialized
INFO - 2016-11-17 21:09:30 --> Language Class Initialized
INFO - 2016-11-17 21:09:30 --> Config Class Initialized
INFO - 2016-11-17 21:09:30 --> Form Validation Class Initialized
INFO - 2016-11-17 21:09:30 --> Loader Class Initialized
INFO - 2016-11-17 21:09:30 --> Hooks Class Initialized
INFO - 2016-11-17 21:09:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:09:30 --> Helper loaded: url_helper
DEBUG - 2016-11-17 21:09:30 --> UTF-8 Support Enabled
ERROR - 2016-11-17 21:09:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-17 21:09:30 --> Utf8 Class Initialized
INFO - 2016-11-17 21:09:30 --> Helper loaded: form_helper
INFO - 2016-11-17 21:09:30 --> URI Class Initialized
INFO - 2016-11-17 21:09:30 --> Database Driver Class Initialized
INFO - 2016-11-17 21:09:30 --> Router Class Initialized
INFO - 2016-11-17 21:09:30 --> Output Class Initialized
ERROR - 2016-11-17 21:09:30 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-10', '2016-11-11', '3', '1', '2016-11-17 21:09:30', '1', '')
INFO - 2016-11-17 21:09:30 --> Security Class Initialized
INFO - 2016-11-17 21:09:30 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-11-17 21:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:09:30 --> Input Class Initialized
INFO - 2016-11-17 21:09:30 --> Controller Class Initialized
INFO - 2016-11-17 21:09:30 --> Language Class Initialized
INFO - 2016-11-17 21:09:30 --> Model Class Initialized
INFO - 2016-11-17 21:09:30 --> Config Class Initialized
INFO - 2016-11-17 21:09:30 --> Loader Class Initialized
INFO - 2016-11-17 21:09:30 --> Form Validation Class Initialized
INFO - 2016-11-17 21:09:30 --> Hooks Class Initialized
INFO - 2016-11-17 21:09:30 --> Helper loaded: url_helper
DEBUG - 2016-11-17 21:09:30 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:09:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:09:30 --> Utf8 Class Initialized
INFO - 2016-11-17 21:09:30 --> Helper loaded: form_helper
ERROR - 2016-11-17 21:09:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-17 21:09:30 --> URI Class Initialized
INFO - 2016-11-17 21:09:30 --> Database Driver Class Initialized
INFO - 2016-11-17 21:09:30 --> Router Class Initialized
INFO - 2016-11-17 21:09:30 --> Output Class Initialized
INFO - 2016-11-17 21:09:31 --> Security Class Initialized
ERROR - 2016-11-17 21:09:31 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-10', '2016-11-11', '3', '1', '2016-11-17 21:09:30', '1', '')
DEBUG - 2016-11-17 21:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:09:31 --> Input Class Initialized
INFO - 2016-11-17 21:09:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:09:31 --> Language Class Initialized
INFO - 2016-11-17 21:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:09:31 --> Loader Class Initialized
INFO - 2016-11-17 21:09:31 --> Controller Class Initialized
INFO - 2016-11-17 21:09:31 --> Config Class Initialized
INFO - 2016-11-17 21:09:31 --> Helper loaded: url_helper
INFO - 2016-11-17 21:09:31 --> Model Class Initialized
INFO - 2016-11-17 21:09:31 --> Hooks Class Initialized
INFO - 2016-11-17 21:09:31 --> Helper loaded: form_helper
DEBUG - 2016-11-17 21:09:31 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:09:31 --> Form Validation Class Initialized
INFO - 2016-11-17 21:09:31 --> Database Driver Class Initialized
INFO - 2016-11-17 21:09:31 --> Utf8 Class Initialized
INFO - 2016-11-17 21:09:31 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-17 21:09:31 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-17 21:09:31 --> URI Class Initialized
INFO - 2016-11-17 21:09:31 --> Router Class Initialized
INFO - 2016-11-17 21:09:31 --> Output Class Initialized
INFO - 2016-11-17 21:09:31 --> Security Class Initialized
ERROR - 2016-11-17 21:09:31 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-10', '2016-11-11', '3', '1', '2016-11-17 21:09:31', '1', '')
DEBUG - 2016-11-17 21:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:09:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:09:31 --> Input Class Initialized
INFO - 2016-11-17 21:09:31 --> Language Class Initialized
INFO - 2016-11-17 21:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:09:31 --> Config Class Initialized
INFO - 2016-11-17 21:09:31 --> Controller Class Initialized
INFO - 2016-11-17 21:09:31 --> Loader Class Initialized
INFO - 2016-11-17 21:09:31 --> Hooks Class Initialized
INFO - 2016-11-17 21:09:31 --> Model Class Initialized
DEBUG - 2016-11-17 21:09:31 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:09:31 --> Helper loaded: url_helper
INFO - 2016-11-17 21:09:31 --> Form Validation Class Initialized
INFO - 2016-11-17 21:09:31 --> Utf8 Class Initialized
INFO - 2016-11-17 21:09:31 --> Helper loaded: form_helper
INFO - 2016-11-17 21:09:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:09:31 --> URI Class Initialized
INFO - 2016-11-17 21:09:31 --> Database Driver Class Initialized
INFO - 2016-11-17 21:09:31 --> Router Class Initialized
ERROR - 2016-11-17 21:09:31 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-17 21:09:31 --> Output Class Initialized
INFO - 2016-11-17 21:09:31 --> Security Class Initialized
DEBUG - 2016-11-17 21:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:09:31 --> Input Class Initialized
INFO - 2016-11-17 21:09:31 --> Language Class Initialized
ERROR - 2016-11-17 21:09:31 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-10', '2016-11-11', '3', '1', '2016-11-17 21:09:31', '1', '')
INFO - 2016-11-17 21:09:31 --> Loader Class Initialized
INFO - 2016-11-17 21:09:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:09:31 --> Helper loaded: url_helper
INFO - 2016-11-17 21:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:09:31 --> Helper loaded: form_helper
INFO - 2016-11-17 21:09:31 --> Config Class Initialized
INFO - 2016-11-17 21:09:31 --> Controller Class Initialized
INFO - 2016-11-17 21:09:31 --> Hooks Class Initialized
INFO - 2016-11-17 21:09:31 --> Model Class Initialized
INFO - 2016-11-17 21:09:31 --> Database Driver Class Initialized
DEBUG - 2016-11-17 21:09:31 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:09:31 --> Form Validation Class Initialized
INFO - 2016-11-17 21:09:31 --> Utf8 Class Initialized
INFO - 2016-11-17 21:09:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:09:31 --> URI Class Initialized
ERROR - 2016-11-17 21:09:31 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-17 21:09:31 --> Router Class Initialized
INFO - 2016-11-17 21:09:31 --> Output Class Initialized
INFO - 2016-11-17 21:09:31 --> Security Class Initialized
DEBUG - 2016-11-17 21:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:09:31 --> Input Class Initialized
INFO - 2016-11-17 21:09:31 --> Language Class Initialized
INFO - 2016-11-17 21:09:31 --> Loader Class Initialized
INFO - 2016-11-17 21:09:31 --> Helper loaded: url_helper
INFO - 2016-11-17 21:09:31 --> Config Class Initialized
INFO - 2016-11-17 21:09:31 --> Hooks Class Initialized
INFO - 2016-11-17 21:09:31 --> Helper loaded: form_helper
ERROR - 2016-11-17 21:09:31 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-10', '2016-11-11', '3', '1', '2016-11-17 21:09:31', '1', '')
DEBUG - 2016-11-17 21:09:31 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:09:31 --> Database Driver Class Initialized
INFO - 2016-11-17 21:09:31 --> Utf8 Class Initialized
INFO - 2016-11-17 21:09:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:09:31 --> URI Class Initialized
INFO - 2016-11-17 21:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:09:31 --> Router Class Initialized
INFO - 2016-11-17 21:09:31 --> Controller Class Initialized
INFO - 2016-11-17 21:09:31 --> Model Class Initialized
INFO - 2016-11-17 21:09:31 --> Output Class Initialized
INFO - 2016-11-17 21:09:31 --> Form Validation Class Initialized
INFO - 2016-11-17 21:09:31 --> Security Class Initialized
INFO - 2016-11-17 21:09:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-17 21:09:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-11-17 21:09:31 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-17 21:09:31 --> Input Class Initialized
INFO - 2016-11-17 21:09:31 --> Language Class Initialized
INFO - 2016-11-17 21:09:31 --> Loader Class Initialized
INFO - 2016-11-17 21:09:31 --> Helper loaded: url_helper
INFO - 2016-11-17 21:09:31 --> Helper loaded: form_helper
ERROR - 2016-11-17 21:09:31 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-10', '2016-11-11', '3', '1', '2016-11-17 21:09:31', '1', '')
INFO - 2016-11-17 21:09:31 --> Database Driver Class Initialized
INFO - 2016-11-17 21:09:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:09:31 --> Controller Class Initialized
INFO - 2016-11-17 21:09:31 --> Model Class Initialized
INFO - 2016-11-17 21:09:31 --> Form Validation Class Initialized
INFO - 2016-11-17 21:09:31 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-17 21:09:31 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-17 21:09:31 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-10', '2016-11-11', '3', '1', '2016-11-17 21:09:31', '1', '')
INFO - 2016-11-17 21:09:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:09:31 --> Controller Class Initialized
INFO - 2016-11-17 21:09:31 --> Model Class Initialized
INFO - 2016-11-17 21:09:31 --> Form Validation Class Initialized
INFO - 2016-11-17 21:09:31 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-17 21:09:31 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-17 21:09:32 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-10', '2016-11-11', '3', '1', '2016-11-17 21:09:31', '1', '')
INFO - 2016-11-17 21:09:32 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:09:33 --> Config Class Initialized
INFO - 2016-11-17 21:09:33 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:09:33 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:09:33 --> Utf8 Class Initialized
INFO - 2016-11-17 21:09:33 --> URI Class Initialized
DEBUG - 2016-11-17 21:09:33 --> No URI present. Default controller set.
INFO - 2016-11-17 21:09:33 --> Router Class Initialized
INFO - 2016-11-17 21:09:33 --> Output Class Initialized
INFO - 2016-11-17 21:09:33 --> Security Class Initialized
DEBUG - 2016-11-17 21:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:09:33 --> Input Class Initialized
INFO - 2016-11-17 21:09:33 --> Language Class Initialized
INFO - 2016-11-17 21:09:33 --> Loader Class Initialized
INFO - 2016-11-17 21:09:33 --> Helper loaded: url_helper
INFO - 2016-11-17 21:09:33 --> Helper loaded: form_helper
INFO - 2016-11-17 21:09:33 --> Database Driver Class Initialized
INFO - 2016-11-17 21:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:09:33 --> Controller Class Initialized
INFO - 2016-11-17 21:09:33 --> Model Class Initialized
INFO - 2016-11-17 21:09:33 --> Model Class Initialized
INFO - 2016-11-17 21:09:33 --> Model Class Initialized
INFO - 2016-11-17 21:09:33 --> Model Class Initialized
INFO - 2016-11-17 21:09:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 21:09:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 21:09:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 21:09:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 21:09:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 21:09:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 21:09:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 21:09:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 21:09:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 21:09:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 21:09:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 21:09:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 21:09:33 --> Final output sent to browser
DEBUG - 2016-11-17 21:09:33 --> Total execution time: 0.5068
INFO - 2016-11-17 21:09:57 --> Config Class Initialized
INFO - 2016-11-17 21:09:57 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:09:57 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:09:57 --> Utf8 Class Initialized
INFO - 2016-11-17 21:09:57 --> URI Class Initialized
INFO - 2016-11-17 21:09:57 --> Router Class Initialized
INFO - 2016-11-17 21:09:57 --> Output Class Initialized
INFO - 2016-11-17 21:09:57 --> Security Class Initialized
DEBUG - 2016-11-17 21:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:09:57 --> Input Class Initialized
INFO - 2016-11-17 21:09:57 --> Language Class Initialized
INFO - 2016-11-17 21:09:57 --> Loader Class Initialized
INFO - 2016-11-17 21:09:57 --> Helper loaded: url_helper
INFO - 2016-11-17 21:09:57 --> Helper loaded: form_helper
INFO - 2016-11-17 21:09:57 --> Database Driver Class Initialized
INFO - 2016-11-17 21:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:09:57 --> Controller Class Initialized
INFO - 2016-11-17 21:09:57 --> Model Class Initialized
INFO - 2016-11-17 21:09:57 --> Form Validation Class Initialized
INFO - 2016-11-17 21:09:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:09:57 --> Final output sent to browser
DEBUG - 2016-11-17 21:09:57 --> Total execution time: 0.2150
INFO - 2016-11-17 21:10:12 --> Config Class Initialized
INFO - 2016-11-17 21:10:12 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:10:12 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:10:12 --> Utf8 Class Initialized
INFO - 2016-11-17 21:10:12 --> URI Class Initialized
INFO - 2016-11-17 21:10:12 --> Router Class Initialized
INFO - 2016-11-17 21:10:12 --> Output Class Initialized
INFO - 2016-11-17 21:10:12 --> Security Class Initialized
DEBUG - 2016-11-17 21:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:10:12 --> Input Class Initialized
INFO - 2016-11-17 21:10:12 --> Language Class Initialized
INFO - 2016-11-17 21:10:12 --> Loader Class Initialized
INFO - 2016-11-17 21:10:12 --> Helper loaded: url_helper
INFO - 2016-11-17 21:10:12 --> Helper loaded: form_helper
INFO - 2016-11-17 21:10:12 --> Database Driver Class Initialized
INFO - 2016-11-17 21:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:10:12 --> Controller Class Initialized
INFO - 2016-11-17 21:10:12 --> Model Class Initialized
INFO - 2016-11-17 21:10:12 --> Form Validation Class Initialized
INFO - 2016-11-17 21:10:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:10:12 --> Final output sent to browser
DEBUG - 2016-11-17 21:10:12 --> Total execution time: 0.2498
INFO - 2016-11-17 21:10:16 --> Config Class Initialized
INFO - 2016-11-17 21:10:16 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:10:16 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:10:16 --> Utf8 Class Initialized
INFO - 2016-11-17 21:10:16 --> URI Class Initialized
INFO - 2016-11-17 21:10:16 --> Router Class Initialized
INFO - 2016-11-17 21:10:16 --> Output Class Initialized
INFO - 2016-11-17 21:10:16 --> Security Class Initialized
DEBUG - 2016-11-17 21:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:10:16 --> Input Class Initialized
INFO - 2016-11-17 21:10:16 --> Language Class Initialized
INFO - 2016-11-17 21:10:16 --> Loader Class Initialized
INFO - 2016-11-17 21:10:16 --> Helper loaded: url_helper
INFO - 2016-11-17 21:10:16 --> Helper loaded: form_helper
INFO - 2016-11-17 21:10:16 --> Database Driver Class Initialized
INFO - 2016-11-17 21:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:10:16 --> Controller Class Initialized
INFO - 2016-11-17 21:10:16 --> Model Class Initialized
INFO - 2016-11-17 21:10:16 --> Form Validation Class Initialized
INFO - 2016-11-17 21:10:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:10:16 --> Final output sent to browser
DEBUG - 2016-11-17 21:10:16 --> Total execution time: 0.2521
INFO - 2016-11-17 21:10:18 --> Config Class Initialized
INFO - 2016-11-17 21:10:18 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:10:18 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:10:18 --> Utf8 Class Initialized
INFO - 2016-11-17 21:10:18 --> URI Class Initialized
INFO - 2016-11-17 21:10:18 --> Router Class Initialized
INFO - 2016-11-17 21:10:18 --> Output Class Initialized
INFO - 2016-11-17 21:10:18 --> Security Class Initialized
DEBUG - 2016-11-17 21:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:10:18 --> Input Class Initialized
INFO - 2016-11-17 21:10:18 --> Language Class Initialized
INFO - 2016-11-17 21:10:18 --> Loader Class Initialized
INFO - 2016-11-17 21:10:18 --> Helper loaded: url_helper
INFO - 2016-11-17 21:10:18 --> Helper loaded: form_helper
INFO - 2016-11-17 21:10:18 --> Database Driver Class Initialized
INFO - 2016-11-17 21:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:10:18 --> Controller Class Initialized
INFO - 2016-11-17 21:10:18 --> Model Class Initialized
INFO - 2016-11-17 21:10:18 --> Form Validation Class Initialized
INFO - 2016-11-17 21:10:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:10:18 --> Final output sent to browser
DEBUG - 2016-11-17 21:10:18 --> Total execution time: 0.2322
INFO - 2016-11-17 21:10:20 --> Config Class Initialized
INFO - 2016-11-17 21:10:20 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:10:20 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:10:20 --> Utf8 Class Initialized
INFO - 2016-11-17 21:10:20 --> URI Class Initialized
INFO - 2016-11-17 21:10:20 --> Router Class Initialized
INFO - 2016-11-17 21:10:20 --> Output Class Initialized
INFO - 2016-11-17 21:10:20 --> Security Class Initialized
DEBUG - 2016-11-17 21:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:10:20 --> Input Class Initialized
INFO - 2016-11-17 21:10:20 --> Language Class Initialized
INFO - 2016-11-17 21:10:20 --> Loader Class Initialized
INFO - 2016-11-17 21:10:20 --> Helper loaded: url_helper
INFO - 2016-11-17 21:10:20 --> Helper loaded: form_helper
INFO - 2016-11-17 21:10:20 --> Database Driver Class Initialized
INFO - 2016-11-17 21:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:10:20 --> Controller Class Initialized
INFO - 2016-11-17 21:10:20 --> Model Class Initialized
INFO - 2016-11-17 21:10:20 --> Form Validation Class Initialized
INFO - 2016-11-17 21:10:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:10:20 --> Final output sent to browser
DEBUG - 2016-11-17 21:10:20 --> Total execution time: 0.2619
INFO - 2016-11-17 21:10:26 --> Config Class Initialized
INFO - 2016-11-17 21:10:26 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:10:26 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:10:26 --> Utf8 Class Initialized
INFO - 2016-11-17 21:10:26 --> URI Class Initialized
DEBUG - 2016-11-17 21:10:26 --> No URI present. Default controller set.
INFO - 2016-11-17 21:10:26 --> Router Class Initialized
INFO - 2016-11-17 21:10:26 --> Output Class Initialized
INFO - 2016-11-17 21:10:26 --> Security Class Initialized
DEBUG - 2016-11-17 21:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:10:26 --> Input Class Initialized
INFO - 2016-11-17 21:10:26 --> Language Class Initialized
INFO - 2016-11-17 21:10:26 --> Loader Class Initialized
INFO - 2016-11-17 21:10:26 --> Helper loaded: url_helper
INFO - 2016-11-17 21:10:26 --> Helper loaded: form_helper
INFO - 2016-11-17 21:10:26 --> Database Driver Class Initialized
INFO - 2016-11-17 21:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:10:26 --> Controller Class Initialized
INFO - 2016-11-17 21:10:26 --> Model Class Initialized
INFO - 2016-11-17 21:10:26 --> Model Class Initialized
INFO - 2016-11-17 21:10:26 --> Model Class Initialized
INFO - 2016-11-17 21:10:26 --> Model Class Initialized
INFO - 2016-11-17 21:10:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 21:10:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 21:10:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 21:10:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 21:10:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 21:10:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 21:10:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 21:10:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 21:10:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 21:10:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 21:10:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 21:10:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 21:10:27 --> Final output sent to browser
DEBUG - 2016-11-17 21:10:27 --> Total execution time: 0.4507
INFO - 2016-11-17 21:11:11 --> Config Class Initialized
INFO - 2016-11-17 21:11:11 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:11:11 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:11:11 --> Utf8 Class Initialized
INFO - 2016-11-17 21:11:11 --> URI Class Initialized
INFO - 2016-11-17 21:11:11 --> Router Class Initialized
INFO - 2016-11-17 21:11:11 --> Output Class Initialized
INFO - 2016-11-17 21:11:11 --> Security Class Initialized
DEBUG - 2016-11-17 21:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:11:11 --> Input Class Initialized
INFO - 2016-11-17 21:11:11 --> Language Class Initialized
INFO - 2016-11-17 21:11:11 --> Loader Class Initialized
INFO - 2016-11-17 21:11:11 --> Helper loaded: url_helper
INFO - 2016-11-17 21:11:11 --> Helper loaded: form_helper
INFO - 2016-11-17 21:11:11 --> Database Driver Class Initialized
INFO - 2016-11-17 21:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:11:11 --> Controller Class Initialized
INFO - 2016-11-17 21:11:11 --> Model Class Initialized
INFO - 2016-11-17 21:11:11 --> Form Validation Class Initialized
INFO - 2016-11-17 21:11:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:11:11 --> Final output sent to browser
DEBUG - 2016-11-17 21:11:11 --> Total execution time: 0.2481
INFO - 2016-11-17 21:11:13 --> Config Class Initialized
INFO - 2016-11-17 21:11:13 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:11:13 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:11:13 --> Utf8 Class Initialized
INFO - 2016-11-17 21:11:13 --> URI Class Initialized
DEBUG - 2016-11-17 21:11:13 --> No URI present. Default controller set.
INFO - 2016-11-17 21:11:13 --> Router Class Initialized
INFO - 2016-11-17 21:11:13 --> Output Class Initialized
INFO - 2016-11-17 21:11:13 --> Security Class Initialized
DEBUG - 2016-11-17 21:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:11:13 --> Input Class Initialized
INFO - 2016-11-17 21:11:13 --> Language Class Initialized
INFO - 2016-11-17 21:11:13 --> Loader Class Initialized
INFO - 2016-11-17 21:11:13 --> Helper loaded: url_helper
INFO - 2016-11-17 21:11:13 --> Helper loaded: form_helper
INFO - 2016-11-17 21:11:13 --> Database Driver Class Initialized
INFO - 2016-11-17 21:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:11:13 --> Controller Class Initialized
INFO - 2016-11-17 21:11:13 --> Model Class Initialized
INFO - 2016-11-17 21:11:13 --> Model Class Initialized
INFO - 2016-11-17 21:11:13 --> Model Class Initialized
INFO - 2016-11-17 21:11:13 --> Model Class Initialized
INFO - 2016-11-17 21:11:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 21:11:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 21:11:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 21:11:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 21:11:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 21:11:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 21:11:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 21:11:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 21:11:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 21:11:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 21:11:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 21:11:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 21:11:13 --> Final output sent to browser
DEBUG - 2016-11-17 21:11:13 --> Total execution time: 0.4537
INFO - 2016-11-17 21:11:15 --> Config Class Initialized
INFO - 2016-11-17 21:11:15 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:11:15 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:11:15 --> Utf8 Class Initialized
INFO - 2016-11-17 21:11:15 --> URI Class Initialized
DEBUG - 2016-11-17 21:11:15 --> No URI present. Default controller set.
INFO - 2016-11-17 21:11:15 --> Router Class Initialized
INFO - 2016-11-17 21:11:15 --> Output Class Initialized
INFO - 2016-11-17 21:11:15 --> Security Class Initialized
DEBUG - 2016-11-17 21:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:11:15 --> Input Class Initialized
INFO - 2016-11-17 21:11:15 --> Language Class Initialized
INFO - 2016-11-17 21:11:15 --> Loader Class Initialized
INFO - 2016-11-17 21:11:15 --> Helper loaded: url_helper
INFO - 2016-11-17 21:11:15 --> Helper loaded: form_helper
INFO - 2016-11-17 21:11:15 --> Database Driver Class Initialized
INFO - 2016-11-17 21:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:11:15 --> Controller Class Initialized
INFO - 2016-11-17 21:11:15 --> Model Class Initialized
INFO - 2016-11-17 21:11:15 --> Model Class Initialized
INFO - 2016-11-17 21:11:15 --> Model Class Initialized
INFO - 2016-11-17 21:11:15 --> Model Class Initialized
INFO - 2016-11-17 21:11:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 21:11:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 21:11:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 21:11:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 21:11:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 21:11:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 21:11:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 21:11:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 21:11:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 21:11:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 21:11:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 21:11:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 21:11:15 --> Final output sent to browser
DEBUG - 2016-11-17 21:11:15 --> Total execution time: 0.4989
INFO - 2016-11-17 21:11:20 --> Config Class Initialized
INFO - 2016-11-17 21:11:20 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:11:20 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:11:20 --> Utf8 Class Initialized
INFO - 2016-11-17 21:11:20 --> URI Class Initialized
INFO - 2016-11-17 21:11:20 --> Router Class Initialized
INFO - 2016-11-17 21:11:20 --> Output Class Initialized
INFO - 2016-11-17 21:11:20 --> Security Class Initialized
DEBUG - 2016-11-17 21:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:11:20 --> Input Class Initialized
INFO - 2016-11-17 21:11:20 --> Language Class Initialized
INFO - 2016-11-17 21:11:20 --> Loader Class Initialized
INFO - 2016-11-17 21:11:20 --> Helper loaded: url_helper
INFO - 2016-11-17 21:11:20 --> Helper loaded: form_helper
INFO - 2016-11-17 21:11:20 --> Database Driver Class Initialized
INFO - 2016-11-17 21:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:11:20 --> Controller Class Initialized
INFO - 2016-11-17 21:11:20 --> Model Class Initialized
INFO - 2016-11-17 21:11:20 --> Form Validation Class Initialized
INFO - 2016-11-17 21:11:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:11:20 --> Final output sent to browser
DEBUG - 2016-11-17 21:11:20 --> Total execution time: 0.2274
INFO - 2016-11-17 21:14:11 --> Config Class Initialized
INFO - 2016-11-17 21:14:11 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:14:11 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:14:11 --> Utf8 Class Initialized
INFO - 2016-11-17 21:14:11 --> URI Class Initialized
DEBUG - 2016-11-17 21:14:11 --> No URI present. Default controller set.
INFO - 2016-11-17 21:14:11 --> Router Class Initialized
INFO - 2016-11-17 21:14:11 --> Output Class Initialized
INFO - 2016-11-17 21:14:11 --> Security Class Initialized
DEBUG - 2016-11-17 21:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:14:11 --> Input Class Initialized
INFO - 2016-11-17 21:14:11 --> Language Class Initialized
INFO - 2016-11-17 21:14:11 --> Loader Class Initialized
INFO - 2016-11-17 21:14:11 --> Helper loaded: url_helper
INFO - 2016-11-17 21:14:11 --> Helper loaded: form_helper
INFO - 2016-11-17 21:14:11 --> Database Driver Class Initialized
INFO - 2016-11-17 21:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:14:11 --> Controller Class Initialized
INFO - 2016-11-17 21:14:11 --> Model Class Initialized
INFO - 2016-11-17 21:14:11 --> Model Class Initialized
INFO - 2016-11-17 21:14:11 --> Model Class Initialized
INFO - 2016-11-17 21:14:12 --> Model Class Initialized
INFO - 2016-11-17 21:14:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 21:14:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 21:14:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 21:14:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 21:14:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 21:14:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 21:14:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 21:14:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 21:14:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 21:14:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 21:14:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 21:14:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 21:14:12 --> Final output sent to browser
DEBUG - 2016-11-17 21:14:12 --> Total execution time: 0.4269
INFO - 2016-11-17 21:14:35 --> Config Class Initialized
INFO - 2016-11-17 21:14:35 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:14:35 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:14:35 --> Utf8 Class Initialized
INFO - 2016-11-17 21:14:35 --> URI Class Initialized
INFO - 2016-11-17 21:14:35 --> Router Class Initialized
INFO - 2016-11-17 21:14:35 --> Output Class Initialized
INFO - 2016-11-17 21:14:35 --> Security Class Initialized
DEBUG - 2016-11-17 21:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:14:35 --> Input Class Initialized
INFO - 2016-11-17 21:14:35 --> Language Class Initialized
INFO - 2016-11-17 21:14:35 --> Loader Class Initialized
INFO - 2016-11-17 21:14:35 --> Helper loaded: url_helper
INFO - 2016-11-17 21:14:35 --> Helper loaded: form_helper
INFO - 2016-11-17 21:14:35 --> Database Driver Class Initialized
INFO - 2016-11-17 21:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:14:35 --> Controller Class Initialized
INFO - 2016-11-17 21:14:35 --> Model Class Initialized
INFO - 2016-11-17 21:14:35 --> Model Class Initialized
INFO - 2016-11-17 21:14:35 --> Model Class Initialized
INFO - 2016-11-17 21:14:35 --> Model Class Initialized
DEBUG - 2016-11-17 21:14:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-17 21:14:35 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-17 21:14:35 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-17 21:14:35 --> Config Class Initialized
INFO - 2016-11-17 21:14:35 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:14:35 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:14:35 --> Utf8 Class Initialized
INFO - 2016-11-17 21:14:35 --> URI Class Initialized
DEBUG - 2016-11-17 21:14:35 --> No URI present. Default controller set.
INFO - 2016-11-17 21:14:35 --> Router Class Initialized
INFO - 2016-11-17 21:14:35 --> Output Class Initialized
INFO - 2016-11-17 21:14:35 --> Security Class Initialized
DEBUG - 2016-11-17 21:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:14:35 --> Input Class Initialized
INFO - 2016-11-17 21:14:35 --> Language Class Initialized
INFO - 2016-11-17 21:14:35 --> Loader Class Initialized
INFO - 2016-11-17 21:14:35 --> Helper loaded: url_helper
INFO - 2016-11-17 21:14:35 --> Helper loaded: form_helper
INFO - 2016-11-17 21:14:35 --> Database Driver Class Initialized
INFO - 2016-11-17 21:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:14:35 --> Controller Class Initialized
INFO - 2016-11-17 21:14:35 --> Model Class Initialized
INFO - 2016-11-17 21:14:35 --> Model Class Initialized
INFO - 2016-11-17 21:14:35 --> Model Class Initialized
INFO - 2016-11-17 21:14:35 --> Model Class Initialized
INFO - 2016-11-17 21:14:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 21:14:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-17 21:14:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 21:14:35 --> Final output sent to browser
DEBUG - 2016-11-17 21:14:35 --> Total execution time: 0.2996
INFO - 2016-11-17 21:14:43 --> Config Class Initialized
INFO - 2016-11-17 21:14:43 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:14:43 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:14:43 --> Utf8 Class Initialized
INFO - 2016-11-17 21:14:43 --> URI Class Initialized
INFO - 2016-11-17 21:14:43 --> Router Class Initialized
INFO - 2016-11-17 21:14:43 --> Output Class Initialized
INFO - 2016-11-17 21:14:43 --> Security Class Initialized
DEBUG - 2016-11-17 21:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:14:43 --> Input Class Initialized
INFO - 2016-11-17 21:14:43 --> Language Class Initialized
INFO - 2016-11-17 21:14:43 --> Loader Class Initialized
INFO - 2016-11-17 21:14:43 --> Helper loaded: url_helper
INFO - 2016-11-17 21:14:43 --> Helper loaded: form_helper
INFO - 2016-11-17 21:14:43 --> Database Driver Class Initialized
INFO - 2016-11-17 21:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:14:43 --> Controller Class Initialized
INFO - 2016-11-17 21:14:43 --> Model Class Initialized
INFO - 2016-11-17 21:14:43 --> Model Class Initialized
INFO - 2016-11-17 21:14:43 --> Model Class Initialized
INFO - 2016-11-17 21:14:43 --> Model Class Initialized
DEBUG - 2016-11-17 21:14:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-17 21:14:43 --> Model Class Initialized
INFO - 2016-11-17 21:14:43 --> Final output sent to browser
DEBUG - 2016-11-17 21:14:43 --> Total execution time: 0.2331
INFO - 2016-11-17 21:14:43 --> Config Class Initialized
INFO - 2016-11-17 21:14:43 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:14:43 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:14:43 --> Utf8 Class Initialized
INFO - 2016-11-17 21:14:43 --> URI Class Initialized
DEBUG - 2016-11-17 21:14:43 --> No URI present. Default controller set.
INFO - 2016-11-17 21:14:43 --> Router Class Initialized
INFO - 2016-11-17 21:14:43 --> Output Class Initialized
INFO - 2016-11-17 21:14:43 --> Security Class Initialized
DEBUG - 2016-11-17 21:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:14:43 --> Input Class Initialized
INFO - 2016-11-17 21:14:43 --> Language Class Initialized
INFO - 2016-11-17 21:14:43 --> Loader Class Initialized
INFO - 2016-11-17 21:14:43 --> Helper loaded: url_helper
INFO - 2016-11-17 21:14:43 --> Helper loaded: form_helper
INFO - 2016-11-17 21:14:43 --> Database Driver Class Initialized
INFO - 2016-11-17 21:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:14:43 --> Controller Class Initialized
INFO - 2016-11-17 21:14:43 --> Model Class Initialized
INFO - 2016-11-17 21:14:43 --> Model Class Initialized
INFO - 2016-11-17 21:14:43 --> Model Class Initialized
INFO - 2016-11-17 21:14:43 --> Model Class Initialized
INFO - 2016-11-17 21:14:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 21:14:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 21:14:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 21:14:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 21:14:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 21:14:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 21:14:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 21:14:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 21:14:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 21:14:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 21:14:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 21:14:44 --> Final output sent to browser
DEBUG - 2016-11-17 21:14:44 --> Total execution time: 0.7561
INFO - 2016-11-17 21:14:56 --> Config Class Initialized
INFO - 2016-11-17 21:14:56 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:14:56 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:14:56 --> Utf8 Class Initialized
INFO - 2016-11-17 21:14:56 --> URI Class Initialized
INFO - 2016-11-17 21:14:56 --> Router Class Initialized
INFO - 2016-11-17 21:14:56 --> Output Class Initialized
INFO - 2016-11-17 21:14:56 --> Security Class Initialized
DEBUG - 2016-11-17 21:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:14:56 --> Input Class Initialized
INFO - 2016-11-17 21:14:56 --> Language Class Initialized
INFO - 2016-11-17 21:14:56 --> Loader Class Initialized
INFO - 2016-11-17 21:14:56 --> Helper loaded: url_helper
INFO - 2016-11-17 21:14:56 --> Helper loaded: form_helper
INFO - 2016-11-17 21:14:56 --> Database Driver Class Initialized
INFO - 2016-11-17 21:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:14:56 --> Controller Class Initialized
INFO - 2016-11-17 21:14:56 --> Model Class Initialized
INFO - 2016-11-17 21:14:56 --> Form Validation Class Initialized
INFO - 2016-11-17 21:14:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:14:56 --> Final output sent to browser
DEBUG - 2016-11-17 21:14:56 --> Total execution time: 0.2371
INFO - 2016-11-17 21:15:16 --> Config Class Initialized
INFO - 2016-11-17 21:15:16 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:15:16 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:16 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:16 --> URI Class Initialized
INFO - 2016-11-17 21:15:16 --> Router Class Initialized
INFO - 2016-11-17 21:15:16 --> Output Class Initialized
INFO - 2016-11-17 21:15:16 --> Security Class Initialized
DEBUG - 2016-11-17 21:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:16 --> Input Class Initialized
INFO - 2016-11-17 21:15:16 --> Language Class Initialized
INFO - 2016-11-17 21:15:16 --> Loader Class Initialized
INFO - 2016-11-17 21:15:16 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:16 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:16 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:16 --> Controller Class Initialized
INFO - 2016-11-17 21:15:16 --> Model Class Initialized
INFO - 2016-11-17 21:15:16 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:16 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-17 21:15:16 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:16 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:15:18 --> Config Class Initialized
INFO - 2016-11-17 21:15:18 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:15:18 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:18 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:18 --> URI Class Initialized
INFO - 2016-11-17 21:15:18 --> Router Class Initialized
INFO - 2016-11-17 21:15:18 --> Output Class Initialized
INFO - 2016-11-17 21:15:18 --> Security Class Initialized
DEBUG - 2016-11-17 21:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:18 --> Input Class Initialized
INFO - 2016-11-17 21:15:18 --> Language Class Initialized
INFO - 2016-11-17 21:15:18 --> Loader Class Initialized
INFO - 2016-11-17 21:15:18 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:18 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:18 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:18 --> Controller Class Initialized
INFO - 2016-11-17 21:15:18 --> Model Class Initialized
INFO - 2016-11-17 21:15:18 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:18 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-17 21:15:18 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:18 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:15:19 --> Config Class Initialized
INFO - 2016-11-17 21:15:19 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:15:19 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:19 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:19 --> URI Class Initialized
INFO - 2016-11-17 21:15:19 --> Router Class Initialized
INFO - 2016-11-17 21:15:19 --> Output Class Initialized
INFO - 2016-11-17 21:15:19 --> Security Class Initialized
DEBUG - 2016-11-17 21:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:19 --> Input Class Initialized
INFO - 2016-11-17 21:15:19 --> Language Class Initialized
INFO - 2016-11-17 21:15:19 --> Loader Class Initialized
INFO - 2016-11-17 21:15:19 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:19 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:19 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:19 --> Config Class Initialized
INFO - 2016-11-17 21:15:19 --> Controller Class Initialized
INFO - 2016-11-17 21:15:19 --> Hooks Class Initialized
INFO - 2016-11-17 21:15:19 --> Model Class Initialized
DEBUG - 2016-11-17 21:15:19 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:19 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:19 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:15:19 --> URI Class Initialized
ERROR - 2016-11-17 21:15:19 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:19 --> Router Class Initialized
INFO - 2016-11-17 21:15:19 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:15:19 --> Output Class Initialized
INFO - 2016-11-17 21:15:19 --> Security Class Initialized
DEBUG - 2016-11-17 21:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:19 --> Input Class Initialized
INFO - 2016-11-17 21:15:19 --> Language Class Initialized
INFO - 2016-11-17 21:15:19 --> Loader Class Initialized
INFO - 2016-11-17 21:15:19 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:19 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:19 --> Config Class Initialized
INFO - 2016-11-17 21:15:19 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:19 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:15:19 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:19 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:19 --> Controller Class Initialized
INFO - 2016-11-17 21:15:19 --> URI Class Initialized
INFO - 2016-11-17 21:15:19 --> Model Class Initialized
INFO - 2016-11-17 21:15:19 --> Router Class Initialized
INFO - 2016-11-17 21:15:19 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:19 --> Output Class Initialized
INFO - 2016-11-17 21:15:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:15:19 --> Security Class Initialized
ERROR - 2016-11-17 21:15:19 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
DEBUG - 2016-11-17 21:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:19 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:15:19 --> Input Class Initialized
INFO - 2016-11-17 21:15:19 --> Config Class Initialized
INFO - 2016-11-17 21:15:19 --> Language Class Initialized
INFO - 2016-11-17 21:15:19 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:15:19 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:19 --> Loader Class Initialized
INFO - 2016-11-17 21:15:19 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:19 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:19 --> URI Class Initialized
INFO - 2016-11-17 21:15:19 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:19 --> Router Class Initialized
INFO - 2016-11-17 21:15:19 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:19 --> Output Class Initialized
INFO - 2016-11-17 21:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:19 --> Security Class Initialized
INFO - 2016-11-17 21:15:19 --> Controller Class Initialized
INFO - 2016-11-17 21:15:19 --> Model Class Initialized
INFO - 2016-11-17 21:15:19 --> Config Class Initialized
DEBUG - 2016-11-17 21:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:19 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:19 --> Hooks Class Initialized
INFO - 2016-11-17 21:15:19 --> Input Class Initialized
INFO - 2016-11-17 21:15:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-17 21:15:19 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:19 --> Language Class Initialized
INFO - 2016-11-17 21:15:19 --> Utf8 Class Initialized
ERROR - 2016-11-17 21:15:19 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:19 --> Loader Class Initialized
INFO - 2016-11-17 21:15:19 --> URI Class Initialized
INFO - 2016-11-17 21:15:19 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:15:19 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:19 --> Router Class Initialized
INFO - 2016-11-17 21:15:19 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:19 --> Output Class Initialized
INFO - 2016-11-17 21:15:19 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:19 --> Security Class Initialized
INFO - 2016-11-17 21:15:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-17 21:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:20 --> Controller Class Initialized
INFO - 2016-11-17 21:15:20 --> Input Class Initialized
INFO - 2016-11-17 21:15:20 --> Model Class Initialized
INFO - 2016-11-17 21:15:20 --> Config Class Initialized
INFO - 2016-11-17 21:15:20 --> Language Class Initialized
INFO - 2016-11-17 21:15:20 --> Hooks Class Initialized
INFO - 2016-11-17 21:15:20 --> Form Validation Class Initialized
DEBUG - 2016-11-17 21:15:20 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:20 --> Loader Class Initialized
INFO - 2016-11-17 21:15:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:15:20 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:20 --> Helper loaded: url_helper
ERROR - 2016-11-17 21:15:20 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:20 --> URI Class Initialized
INFO - 2016-11-17 21:15:20 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:20 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:15:20 --> Router Class Initialized
INFO - 2016-11-17 21:15:20 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:20 --> Output Class Initialized
INFO - 2016-11-17 21:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:20 --> Security Class Initialized
INFO - 2016-11-17 21:15:20 --> Controller Class Initialized
INFO - 2016-11-17 21:15:20 --> Model Class Initialized
DEBUG - 2016-11-17 21:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:20 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:20 --> Input Class Initialized
INFO - 2016-11-17 21:15:20 --> Language Class Initialized
INFO - 2016-11-17 21:15:20 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-17 21:15:20 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:20 --> Loader Class Initialized
INFO - 2016-11-17 21:15:20 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:15:20 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:20 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:20 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:20 --> Controller Class Initialized
INFO - 2016-11-17 21:15:20 --> Model Class Initialized
INFO - 2016-11-17 21:15:20 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:20 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-17 21:15:20 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:20 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:15:21 --> Config Class Initialized
INFO - 2016-11-17 21:15:21 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:15:21 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:21 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:21 --> URI Class Initialized
INFO - 2016-11-17 21:15:21 --> Router Class Initialized
INFO - 2016-11-17 21:15:21 --> Output Class Initialized
INFO - 2016-11-17 21:15:21 --> Security Class Initialized
DEBUG - 2016-11-17 21:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:21 --> Input Class Initialized
INFO - 2016-11-17 21:15:21 --> Language Class Initialized
INFO - 2016-11-17 21:15:21 --> Loader Class Initialized
INFO - 2016-11-17 21:15:21 --> Config Class Initialized
INFO - 2016-11-17 21:15:21 --> Hooks Class Initialized
INFO - 2016-11-17 21:15:21 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:21 --> Helper loaded: form_helper
DEBUG - 2016-11-17 21:15:21 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:21 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:21 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:21 --> URI Class Initialized
INFO - 2016-11-17 21:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:21 --> Router Class Initialized
INFO - 2016-11-17 21:15:21 --> Controller Class Initialized
INFO - 2016-11-17 21:15:21 --> Model Class Initialized
INFO - 2016-11-17 21:15:21 --> Output Class Initialized
INFO - 2016-11-17 21:15:21 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:21 --> Security Class Initialized
INFO - 2016-11-17 21:15:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-17 21:15:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-11-17 21:15:21 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:21 --> Input Class Initialized
INFO - 2016-11-17 21:15:21 --> Config Class Initialized
INFO - 2016-11-17 21:15:21 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:15:21 --> Language Class Initialized
INFO - 2016-11-17 21:15:21 --> Hooks Class Initialized
INFO - 2016-11-17 21:15:21 --> Loader Class Initialized
DEBUG - 2016-11-17 21:15:21 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:21 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:21 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:21 --> URI Class Initialized
INFO - 2016-11-17 21:15:21 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:21 --> Router Class Initialized
INFO - 2016-11-17 21:15:21 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:21 --> Output Class Initialized
INFO - 2016-11-17 21:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:21 --> Security Class Initialized
INFO - 2016-11-17 21:15:21 --> Controller Class Initialized
INFO - 2016-11-17 21:15:21 --> Model Class Initialized
DEBUG - 2016-11-17 21:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:21 --> Config Class Initialized
INFO - 2016-11-17 21:15:21 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:21 --> Hooks Class Initialized
INFO - 2016-11-17 21:15:21 --> Input Class Initialized
INFO - 2016-11-17 21:15:21 --> Language Class Initialized
INFO - 2016-11-17 21:15:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-17 21:15:21 --> UTF-8 Support Enabled
ERROR - 2016-11-17 21:15:21 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:21 --> Loader Class Initialized
INFO - 2016-11-17 21:15:21 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:21 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:15:21 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:21 --> URI Class Initialized
INFO - 2016-11-17 21:15:21 --> Router Class Initialized
INFO - 2016-11-17 21:15:21 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:21 --> Output Class Initialized
INFO - 2016-11-17 21:15:21 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:21 --> Security Class Initialized
INFO - 2016-11-17 21:15:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-17 21:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:22 --> Controller Class Initialized
INFO - 2016-11-17 21:15:22 --> Input Class Initialized
INFO - 2016-11-17 21:15:22 --> Model Class Initialized
INFO - 2016-11-17 21:15:22 --> Language Class Initialized
INFO - 2016-11-17 21:15:22 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:22 --> Loader Class Initialized
INFO - 2016-11-17 21:15:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:15:22 --> Helper loaded: url_helper
ERROR - 2016-11-17 21:15:22 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:22 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:22 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:15:22 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:22 --> Controller Class Initialized
INFO - 2016-11-17 21:15:22 --> Model Class Initialized
INFO - 2016-11-17 21:15:22 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:22 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-17 21:15:22 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:22 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:15:23 --> Config Class Initialized
INFO - 2016-11-17 21:15:23 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:15:23 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:23 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:23 --> URI Class Initialized
INFO - 2016-11-17 21:15:23 --> Router Class Initialized
INFO - 2016-11-17 21:15:23 --> Output Class Initialized
INFO - 2016-11-17 21:15:23 --> Security Class Initialized
DEBUG - 2016-11-17 21:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:23 --> Input Class Initialized
INFO - 2016-11-17 21:15:23 --> Language Class Initialized
INFO - 2016-11-17 21:15:23 --> Loader Class Initialized
INFO - 2016-11-17 21:15:23 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:23 --> Config Class Initialized
INFO - 2016-11-17 21:15:23 --> Hooks Class Initialized
INFO - 2016-11-17 21:15:23 --> Helper loaded: form_helper
DEBUG - 2016-11-17 21:15:23 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:23 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:23 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:23 --> URI Class Initialized
INFO - 2016-11-17 21:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:23 --> Router Class Initialized
INFO - 2016-11-17 21:15:23 --> Controller Class Initialized
INFO - 2016-11-17 21:15:23 --> Model Class Initialized
INFO - 2016-11-17 21:15:23 --> Output Class Initialized
INFO - 2016-11-17 21:15:23 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:23 --> Security Class Initialized
INFO - 2016-11-17 21:15:23 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-17 21:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:23 --> Config Class Initialized
INFO - 2016-11-17 21:15:23 --> Hooks Class Initialized
ERROR - 2016-11-17 21:15:23 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:23 --> Input Class Initialized
INFO - 2016-11-17 21:15:23 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:15:23 --> Language Class Initialized
DEBUG - 2016-11-17 21:15:23 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:23 --> Loader Class Initialized
INFO - 2016-11-17 21:15:23 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:24 --> URI Class Initialized
INFO - 2016-11-17 21:15:24 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:24 --> Router Class Initialized
INFO - 2016-11-17 21:15:24 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:24 --> Output Class Initialized
INFO - 2016-11-17 21:15:24 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:24 --> Config Class Initialized
INFO - 2016-11-17 21:15:24 --> Security Class Initialized
INFO - 2016-11-17 21:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:24 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:24 --> Controller Class Initialized
DEBUG - 2016-11-17 21:15:24 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:24 --> Input Class Initialized
INFO - 2016-11-17 21:15:24 --> Model Class Initialized
INFO - 2016-11-17 21:15:24 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:24 --> Language Class Initialized
INFO - 2016-11-17 21:15:24 --> URI Class Initialized
INFO - 2016-11-17 21:15:24 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:24 --> Loader Class Initialized
INFO - 2016-11-17 21:15:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:15:24 --> Router Class Initialized
INFO - 2016-11-17 21:15:24 --> Helper loaded: url_helper
ERROR - 2016-11-17 21:15:24 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:24 --> Output Class Initialized
INFO - 2016-11-17 21:15:24 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:24 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:15:24 --> Security Class Initialized
INFO - 2016-11-17 21:15:24 --> Config Class Initialized
INFO - 2016-11-17 21:15:24 --> Database Driver Class Initialized
DEBUG - 2016-11-17 21:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:24 --> Hooks Class Initialized
INFO - 2016-11-17 21:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:24 --> Input Class Initialized
DEBUG - 2016-11-17 21:15:24 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:24 --> Controller Class Initialized
INFO - 2016-11-17 21:15:24 --> Language Class Initialized
INFO - 2016-11-17 21:15:24 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:24 --> Model Class Initialized
INFO - 2016-11-17 21:15:24 --> URI Class Initialized
INFO - 2016-11-17 21:15:24 --> Loader Class Initialized
INFO - 2016-11-17 21:15:24 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:24 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:24 --> Router Class Initialized
INFO - 2016-11-17 21:15:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:15:24 --> Output Class Initialized
INFO - 2016-11-17 21:15:24 --> Helper loaded: form_helper
ERROR - 2016-11-17 21:15:24 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:24 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:24 --> Config Class Initialized
INFO - 2016-11-17 21:15:24 --> Security Class Initialized
INFO - 2016-11-17 21:15:24 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:15:24 --> Hooks Class Initialized
INFO - 2016-11-17 21:15:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-17 21:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-17 21:15:24 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:24 --> Controller Class Initialized
INFO - 2016-11-17 21:15:24 --> Input Class Initialized
INFO - 2016-11-17 21:15:24 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:24 --> Model Class Initialized
INFO - 2016-11-17 21:15:24 --> Language Class Initialized
INFO - 2016-11-17 21:15:24 --> URI Class Initialized
INFO - 2016-11-17 21:15:24 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:24 --> Loader Class Initialized
INFO - 2016-11-17 21:15:24 --> Router Class Initialized
INFO - 2016-11-17 21:15:24 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:15:24 --> Output Class Initialized
ERROR - 2016-11-17 21:15:24 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:24 --> Config Class Initialized
INFO - 2016-11-17 21:15:24 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:24 --> Security Class Initialized
INFO - 2016-11-17 21:15:24 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:15:24 --> Hooks Class Initialized
INFO - 2016-11-17 21:15:24 --> Database Driver Class Initialized
DEBUG - 2016-11-17 21:15:24 --> UTF-8 Support Enabled
DEBUG - 2016-11-17 21:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:24 --> Input Class Initialized
INFO - 2016-11-17 21:15:24 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:24 --> Controller Class Initialized
INFO - 2016-11-17 21:15:24 --> Language Class Initialized
INFO - 2016-11-17 21:15:24 --> URI Class Initialized
INFO - 2016-11-17 21:15:24 --> Model Class Initialized
INFO - 2016-11-17 21:15:24 --> Router Class Initialized
INFO - 2016-11-17 21:15:24 --> Loader Class Initialized
INFO - 2016-11-17 21:15:24 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:24 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:24 --> Output Class Initialized
INFO - 2016-11-17 21:15:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:15:24 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:24 --> Config Class Initialized
ERROR - 2016-11-17 21:15:24 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:24 --> Security Class Initialized
INFO - 2016-11-17 21:15:24 --> Hooks Class Initialized
INFO - 2016-11-17 21:15:24 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:24 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-11-17 21:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-17 21:15:24 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:24 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:24 --> Input Class Initialized
INFO - 2016-11-17 21:15:24 --> Controller Class Initialized
INFO - 2016-11-17 21:15:24 --> URI Class Initialized
INFO - 2016-11-17 21:15:24 --> Language Class Initialized
INFO - 2016-11-17 21:15:24 --> Model Class Initialized
INFO - 2016-11-17 21:15:24 --> Loader Class Initialized
INFO - 2016-11-17 21:15:24 --> Router Class Initialized
INFO - 2016-11-17 21:15:24 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:24 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:24 --> Output Class Initialized
INFO - 2016-11-17 21:15:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:15:24 --> Security Class Initialized
INFO - 2016-11-17 21:15:24 --> Helper loaded: form_helper
ERROR - 2016-11-17 21:15:24 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:24 --> Database Driver Class Initialized
DEBUG - 2016-11-17 21:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:24 --> Config Class Initialized
INFO - 2016-11-17 21:15:24 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:15:24 --> Input Class Initialized
INFO - 2016-11-17 21:15:24 --> Hooks Class Initialized
INFO - 2016-11-17 21:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:24 --> Language Class Initialized
DEBUG - 2016-11-17 21:15:24 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:24 --> Controller Class Initialized
INFO - 2016-11-17 21:15:24 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:24 --> Loader Class Initialized
INFO - 2016-11-17 21:15:24 --> Model Class Initialized
INFO - 2016-11-17 21:15:24 --> URI Class Initialized
INFO - 2016-11-17 21:15:24 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:24 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:24 --> Router Class Initialized
INFO - 2016-11-17 21:15:24 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:15:24 --> Output Class Initialized
INFO - 2016-11-17 21:15:24 --> Database Driver Class Initialized
ERROR - 2016-11-17 21:15:24 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:24 --> Security Class Initialized
INFO - 2016-11-17 21:15:25 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-11-17 21:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:25 --> Input Class Initialized
INFO - 2016-11-17 21:15:25 --> Controller Class Initialized
INFO - 2016-11-17 21:15:25 --> Language Class Initialized
INFO - 2016-11-17 21:15:25 --> Model Class Initialized
INFO - 2016-11-17 21:15:25 --> Loader Class Initialized
INFO - 2016-11-17 21:15:25 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:25 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:15:25 --> Helper loaded: form_helper
ERROR - 2016-11-17 21:15:25 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:25 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:25 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:25 --> Controller Class Initialized
INFO - 2016-11-17 21:15:25 --> Model Class Initialized
INFO - 2016-11-17 21:15:25 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:25 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-17 21:15:25 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:25 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:15:25 --> Config Class Initialized
INFO - 2016-11-17 21:15:25 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:15:25 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:25 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:25 --> URI Class Initialized
INFO - 2016-11-17 21:15:25 --> Router Class Initialized
INFO - 2016-11-17 21:15:25 --> Output Class Initialized
INFO - 2016-11-17 21:15:25 --> Security Class Initialized
DEBUG - 2016-11-17 21:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:25 --> Input Class Initialized
INFO - 2016-11-17 21:15:25 --> Language Class Initialized
INFO - 2016-11-17 21:15:25 --> Loader Class Initialized
INFO - 2016-11-17 21:15:25 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:25 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:25 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:25 --> Controller Class Initialized
INFO - 2016-11-17 21:15:25 --> Model Class Initialized
INFO - 2016-11-17 21:15:25 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:25 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-17 21:15:26 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:26 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:15:26 --> Config Class Initialized
INFO - 2016-11-17 21:15:26 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:15:26 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:26 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:26 --> URI Class Initialized
INFO - 2016-11-17 21:15:26 --> Router Class Initialized
INFO - 2016-11-17 21:15:26 --> Output Class Initialized
INFO - 2016-11-17 21:15:26 --> Security Class Initialized
DEBUG - 2016-11-17 21:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:26 --> Input Class Initialized
INFO - 2016-11-17 21:15:26 --> Language Class Initialized
INFO - 2016-11-17 21:15:26 --> Loader Class Initialized
INFO - 2016-11-17 21:15:26 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:26 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:26 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:26 --> Controller Class Initialized
INFO - 2016-11-17 21:15:26 --> Model Class Initialized
INFO - 2016-11-17 21:15:26 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:26 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-17 21:15:26 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:26 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:15:26 --> Config Class Initialized
INFO - 2016-11-17 21:15:26 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:15:26 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:26 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:26 --> URI Class Initialized
INFO - 2016-11-17 21:15:26 --> Router Class Initialized
INFO - 2016-11-17 21:15:26 --> Output Class Initialized
INFO - 2016-11-17 21:15:26 --> Security Class Initialized
DEBUG - 2016-11-17 21:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:26 --> Input Class Initialized
INFO - 2016-11-17 21:15:26 --> Language Class Initialized
INFO - 2016-11-17 21:15:26 --> Loader Class Initialized
INFO - 2016-11-17 21:15:26 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:26 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:26 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:26 --> Config Class Initialized
INFO - 2016-11-17 21:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:26 --> Hooks Class Initialized
INFO - 2016-11-17 21:15:26 --> Controller Class Initialized
DEBUG - 2016-11-17 21:15:26 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:26 --> Model Class Initialized
INFO - 2016-11-17 21:15:26 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:26 --> URI Class Initialized
INFO - 2016-11-17 21:15:26 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:26 --> Router Class Initialized
INFO - 2016-11-17 21:15:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:15:26 --> Output Class Initialized
ERROR - 2016-11-17 21:15:26 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:26 --> Security Class Initialized
INFO - 2016-11-17 21:15:26 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-11-17 21:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:26 --> Input Class Initialized
INFO - 2016-11-17 21:15:26 --> Language Class Initialized
INFO - 2016-11-17 21:15:26 --> Config Class Initialized
INFO - 2016-11-17 21:15:26 --> Loader Class Initialized
INFO - 2016-11-17 21:15:26 --> Hooks Class Initialized
INFO - 2016-11-17 21:15:26 --> Helper loaded: url_helper
DEBUG - 2016-11-17 21:15:26 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:26 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:26 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:26 --> URI Class Initialized
INFO - 2016-11-17 21:15:26 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:26 --> Router Class Initialized
INFO - 2016-11-17 21:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:26 --> Output Class Initialized
INFO - 2016-11-17 21:15:26 --> Controller Class Initialized
INFO - 2016-11-17 21:15:26 --> Model Class Initialized
INFO - 2016-11-17 21:15:26 --> Security Class Initialized
INFO - 2016-11-17 21:15:26 --> Form Validation Class Initialized
DEBUG - 2016-11-17 21:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:26 --> Input Class Initialized
INFO - 2016-11-17 21:15:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:15:27 --> Config Class Initialized
ERROR - 2016-11-17 21:15:27 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:27 --> Hooks Class Initialized
INFO - 2016-11-17 21:15:27 --> Language Class Initialized
INFO - 2016-11-17 21:15:27 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-11-17 21:15:27 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:27 --> Loader Class Initialized
INFO - 2016-11-17 21:15:27 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:27 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:27 --> URI Class Initialized
INFO - 2016-11-17 21:15:27 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:27 --> Router Class Initialized
INFO - 2016-11-17 21:15:27 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:27 --> Output Class Initialized
INFO - 2016-11-17 21:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:27 --> Security Class Initialized
INFO - 2016-11-17 21:15:27 --> Controller Class Initialized
INFO - 2016-11-17 21:15:27 --> Model Class Initialized
DEBUG - 2016-11-17 21:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:27 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:27 --> Input Class Initialized
INFO - 2016-11-17 21:15:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:15:27 --> Language Class Initialized
ERROR - 2016-11-17 21:15:27 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:27 --> Loader Class Initialized
INFO - 2016-11-17 21:15:27 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:15:27 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:27 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:27 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:27 --> Controller Class Initialized
INFO - 2016-11-17 21:15:27 --> Model Class Initialized
INFO - 2016-11-17 21:15:27 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:27 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-17 21:15:27 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:27 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:15:31 --> Config Class Initialized
INFO - 2016-11-17 21:15:31 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:15:31 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:31 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:31 --> URI Class Initialized
INFO - 2016-11-17 21:15:31 --> Router Class Initialized
INFO - 2016-11-17 21:15:31 --> Output Class Initialized
INFO - 2016-11-17 21:15:31 --> Security Class Initialized
DEBUG - 2016-11-17 21:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:31 --> Input Class Initialized
INFO - 2016-11-17 21:15:31 --> Language Class Initialized
INFO - 2016-11-17 21:15:31 --> Loader Class Initialized
INFO - 2016-11-17 21:15:31 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:31 --> Config Class Initialized
INFO - 2016-11-17 21:15:31 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:31 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:15:31 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:31 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:31 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:31 --> URI Class Initialized
INFO - 2016-11-17 21:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:31 --> Router Class Initialized
INFO - 2016-11-17 21:15:31 --> Controller Class Initialized
INFO - 2016-11-17 21:15:31 --> Model Class Initialized
INFO - 2016-11-17 21:15:31 --> Output Class Initialized
INFO - 2016-11-17 21:15:31 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:31 --> Security Class Initialized
INFO - 2016-11-17 21:15:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-17 21:15:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-11-17 21:15:31 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:31 --> Input Class Initialized
INFO - 2016-11-17 21:15:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:15:31 --> Language Class Initialized
INFO - 2016-11-17 21:15:31 --> Loader Class Initialized
INFO - 2016-11-17 21:15:31 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:31 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:31 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:31 --> Controller Class Initialized
INFO - 2016-11-17 21:15:31 --> Model Class Initialized
INFO - 2016-11-17 21:15:31 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:31 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-17 21:15:31 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Sick', '3', 'Sick Leave')
INFO - 2016-11-17 21:15:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-17 21:15:37 --> Config Class Initialized
INFO - 2016-11-17 21:15:37 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:15:37 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:37 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:37 --> URI Class Initialized
DEBUG - 2016-11-17 21:15:37 --> No URI present. Default controller set.
INFO - 2016-11-17 21:15:37 --> Router Class Initialized
INFO - 2016-11-17 21:15:37 --> Output Class Initialized
INFO - 2016-11-17 21:15:37 --> Security Class Initialized
DEBUG - 2016-11-17 21:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:37 --> Input Class Initialized
INFO - 2016-11-17 21:15:37 --> Language Class Initialized
INFO - 2016-11-17 21:15:37 --> Loader Class Initialized
INFO - 2016-11-17 21:15:37 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:37 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:37 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:38 --> Controller Class Initialized
INFO - 2016-11-17 21:15:38 --> Model Class Initialized
INFO - 2016-11-17 21:15:38 --> Model Class Initialized
INFO - 2016-11-17 21:15:38 --> Model Class Initialized
INFO - 2016-11-17 21:15:38 --> Model Class Initialized
INFO - 2016-11-17 21:15:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 21:15:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 21:15:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 21:15:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 21:15:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 21:15:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 21:15:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 21:15:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 21:15:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 21:15:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 21:15:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 21:15:38 --> Final output sent to browser
DEBUG - 2016-11-17 21:15:38 --> Total execution time: 0.4403
INFO - 2016-11-17 21:15:43 --> Config Class Initialized
INFO - 2016-11-17 21:15:43 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:15:43 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:43 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:43 --> URI Class Initialized
DEBUG - 2016-11-17 21:15:43 --> No URI present. Default controller set.
INFO - 2016-11-17 21:15:43 --> Router Class Initialized
INFO - 2016-11-17 21:15:43 --> Output Class Initialized
INFO - 2016-11-17 21:15:43 --> Security Class Initialized
DEBUG - 2016-11-17 21:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:43 --> Input Class Initialized
INFO - 2016-11-17 21:15:43 --> Language Class Initialized
INFO - 2016-11-17 21:15:43 --> Loader Class Initialized
INFO - 2016-11-17 21:15:43 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:43 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:43 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:43 --> Controller Class Initialized
INFO - 2016-11-17 21:15:43 --> Model Class Initialized
INFO - 2016-11-17 21:15:43 --> Model Class Initialized
INFO - 2016-11-17 21:15:43 --> Model Class Initialized
INFO - 2016-11-17 21:15:43 --> Model Class Initialized
INFO - 2016-11-17 21:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 21:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 21:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 21:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 21:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 21:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 21:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 21:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 21:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 21:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 21:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 21:15:43 --> Final output sent to browser
DEBUG - 2016-11-17 21:15:43 --> Total execution time: 0.4532
INFO - 2016-11-17 21:15:55 --> Config Class Initialized
INFO - 2016-11-17 21:15:55 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:15:55 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:15:55 --> Utf8 Class Initialized
INFO - 2016-11-17 21:15:55 --> URI Class Initialized
INFO - 2016-11-17 21:15:55 --> Router Class Initialized
INFO - 2016-11-17 21:15:55 --> Output Class Initialized
INFO - 2016-11-17 21:15:55 --> Security Class Initialized
DEBUG - 2016-11-17 21:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:15:55 --> Input Class Initialized
INFO - 2016-11-17 21:15:55 --> Language Class Initialized
INFO - 2016-11-17 21:15:55 --> Loader Class Initialized
INFO - 2016-11-17 21:15:55 --> Helper loaded: url_helper
INFO - 2016-11-17 21:15:55 --> Helper loaded: form_helper
INFO - 2016-11-17 21:15:55 --> Database Driver Class Initialized
INFO - 2016-11-17 21:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:15:55 --> Controller Class Initialized
INFO - 2016-11-17 21:15:55 --> Model Class Initialized
INFO - 2016-11-17 21:15:55 --> Form Validation Class Initialized
INFO - 2016-11-17 21:15:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:15:55 --> Final output sent to browser
DEBUG - 2016-11-17 21:15:55 --> Total execution time: 0.2466
INFO - 2016-11-17 21:16:22 --> Config Class Initialized
INFO - 2016-11-17 21:16:22 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:16:22 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:16:22 --> Utf8 Class Initialized
INFO - 2016-11-17 21:16:22 --> URI Class Initialized
DEBUG - 2016-11-17 21:16:22 --> No URI present. Default controller set.
INFO - 2016-11-17 21:16:22 --> Router Class Initialized
INFO - 2016-11-17 21:16:22 --> Output Class Initialized
INFO - 2016-11-17 21:16:22 --> Security Class Initialized
DEBUG - 2016-11-17 21:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:16:22 --> Input Class Initialized
INFO - 2016-11-17 21:16:22 --> Language Class Initialized
INFO - 2016-11-17 21:16:22 --> Loader Class Initialized
INFO - 2016-11-17 21:16:22 --> Helper loaded: url_helper
INFO - 2016-11-17 21:16:22 --> Helper loaded: form_helper
INFO - 2016-11-17 21:16:22 --> Database Driver Class Initialized
INFO - 2016-11-17 21:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:16:22 --> Controller Class Initialized
INFO - 2016-11-17 21:16:22 --> Model Class Initialized
INFO - 2016-11-17 21:16:22 --> Model Class Initialized
INFO - 2016-11-17 21:16:22 --> Model Class Initialized
INFO - 2016-11-17 21:16:22 --> Model Class Initialized
INFO - 2016-11-17 21:16:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 21:16:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 21:16:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 21:16:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 21:16:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 21:16:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 21:16:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 21:16:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 21:16:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 21:16:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 21:16:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 21:16:22 --> Final output sent to browser
DEBUG - 2016-11-17 21:16:22 --> Total execution time: 0.5153
INFO - 2016-11-17 21:16:28 --> Config Class Initialized
INFO - 2016-11-17 21:16:28 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:16:28 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:16:28 --> Utf8 Class Initialized
INFO - 2016-11-17 21:16:28 --> URI Class Initialized
INFO - 2016-11-17 21:16:28 --> Router Class Initialized
INFO - 2016-11-17 21:16:28 --> Output Class Initialized
INFO - 2016-11-17 21:16:28 --> Security Class Initialized
DEBUG - 2016-11-17 21:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:16:28 --> Input Class Initialized
INFO - 2016-11-17 21:16:28 --> Language Class Initialized
INFO - 2016-11-17 21:16:28 --> Loader Class Initialized
INFO - 2016-11-17 21:16:28 --> Helper loaded: url_helper
INFO - 2016-11-17 21:16:28 --> Helper loaded: form_helper
INFO - 2016-11-17 21:16:28 --> Database Driver Class Initialized
INFO - 2016-11-17 21:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:16:28 --> Controller Class Initialized
INFO - 2016-11-17 21:16:28 --> Model Class Initialized
INFO - 2016-11-17 21:16:28 --> Form Validation Class Initialized
INFO - 2016-11-17 21:16:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:16:28 --> Final output sent to browser
DEBUG - 2016-11-17 21:16:28 --> Total execution time: 0.2514
INFO - 2016-11-17 21:56:59 --> Config Class Initialized
INFO - 2016-11-17 21:56:59 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:56:59 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:56:59 --> Utf8 Class Initialized
INFO - 2016-11-17 21:56:59 --> URI Class Initialized
DEBUG - 2016-11-17 21:56:59 --> No URI present. Default controller set.
INFO - 2016-11-17 21:56:59 --> Router Class Initialized
INFO - 2016-11-17 21:56:59 --> Output Class Initialized
INFO - 2016-11-17 21:57:00 --> Security Class Initialized
DEBUG - 2016-11-17 21:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:57:00 --> Input Class Initialized
INFO - 2016-11-17 21:57:00 --> Language Class Initialized
INFO - 2016-11-17 21:57:00 --> Loader Class Initialized
INFO - 2016-11-17 21:57:00 --> Helper loaded: url_helper
INFO - 2016-11-17 21:57:00 --> Helper loaded: form_helper
INFO - 2016-11-17 21:57:00 --> Database Driver Class Initialized
INFO - 2016-11-17 21:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:57:01 --> Controller Class Initialized
INFO - 2016-11-17 21:57:01 --> Model Class Initialized
INFO - 2016-11-17 21:57:02 --> Model Class Initialized
INFO - 2016-11-17 21:57:02 --> Model Class Initialized
INFO - 2016-11-17 21:57:02 --> Model Class Initialized
INFO - 2016-11-17 21:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 21:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 21:57:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 21:57:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 21:57:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 21:57:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 21:57:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 21:57:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 21:57:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 21:57:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 21:57:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 21:57:03 --> Final output sent to browser
DEBUG - 2016-11-17 21:57:03 --> Total execution time: 4.4701
INFO - 2016-11-17 21:57:10 --> Config Class Initialized
INFO - 2016-11-17 21:57:10 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:57:10 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:57:10 --> Utf8 Class Initialized
INFO - 2016-11-17 21:57:10 --> URI Class Initialized
INFO - 2016-11-17 21:57:10 --> Router Class Initialized
INFO - 2016-11-17 21:57:10 --> Output Class Initialized
INFO - 2016-11-17 21:57:10 --> Security Class Initialized
DEBUG - 2016-11-17 21:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:57:10 --> Input Class Initialized
INFO - 2016-11-17 21:57:10 --> Language Class Initialized
INFO - 2016-11-17 21:57:10 --> Loader Class Initialized
INFO - 2016-11-17 21:57:10 --> Helper loaded: url_helper
INFO - 2016-11-17 21:57:10 --> Helper loaded: form_helper
INFO - 2016-11-17 21:57:10 --> Database Driver Class Initialized
INFO - 2016-11-17 21:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:57:10 --> Controller Class Initialized
INFO - 2016-11-17 21:57:10 --> Model Class Initialized
INFO - 2016-11-17 21:57:10 --> Form Validation Class Initialized
INFO - 2016-11-17 21:57:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 21:57:10 --> Final output sent to browser
DEBUG - 2016-11-17 21:57:10 --> Total execution time: 0.4497
INFO - 2016-11-17 21:57:31 --> Config Class Initialized
INFO - 2016-11-17 21:57:31 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:57:31 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:57:31 --> Utf8 Class Initialized
INFO - 2016-11-17 21:57:31 --> URI Class Initialized
DEBUG - 2016-11-17 21:57:31 --> No URI present. Default controller set.
INFO - 2016-11-17 21:57:31 --> Router Class Initialized
INFO - 2016-11-17 21:57:31 --> Output Class Initialized
INFO - 2016-11-17 21:57:31 --> Security Class Initialized
DEBUG - 2016-11-17 21:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:57:31 --> Input Class Initialized
INFO - 2016-11-17 21:57:31 --> Language Class Initialized
INFO - 2016-11-17 21:57:31 --> Loader Class Initialized
INFO - 2016-11-17 21:57:31 --> Helper loaded: url_helper
INFO - 2016-11-17 21:57:32 --> Helper loaded: form_helper
INFO - 2016-11-17 21:57:32 --> Database Driver Class Initialized
INFO - 2016-11-17 21:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:57:32 --> Controller Class Initialized
INFO - 2016-11-17 21:57:32 --> Model Class Initialized
INFO - 2016-11-17 21:57:32 --> Model Class Initialized
INFO - 2016-11-17 21:57:32 --> Model Class Initialized
INFO - 2016-11-17 21:57:32 --> Model Class Initialized
INFO - 2016-11-17 21:57:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 21:57:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 21:57:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 21:57:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 21:57:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 21:57:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 21:57:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 21:57:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 21:57:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 21:57:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 21:57:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 21:57:32 --> Final output sent to browser
DEBUG - 2016-11-17 21:57:32 --> Total execution time: 0.6184
INFO - 2016-11-17 21:57:39 --> Config Class Initialized
INFO - 2016-11-17 21:57:39 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:57:39 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:57:39 --> Utf8 Class Initialized
INFO - 2016-11-17 21:57:39 --> URI Class Initialized
INFO - 2016-11-17 21:57:39 --> Router Class Initialized
INFO - 2016-11-17 21:57:39 --> Output Class Initialized
INFO - 2016-11-17 21:57:39 --> Security Class Initialized
DEBUG - 2016-11-17 21:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:57:39 --> Input Class Initialized
INFO - 2016-11-17 21:57:39 --> Language Class Initialized
INFO - 2016-11-17 21:57:39 --> Loader Class Initialized
INFO - 2016-11-17 21:57:39 --> Helper loaded: url_helper
INFO - 2016-11-17 21:57:39 --> Helper loaded: form_helper
INFO - 2016-11-17 21:57:39 --> Database Driver Class Initialized
INFO - 2016-11-17 21:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:57:39 --> Controller Class Initialized
INFO - 2016-11-17 21:57:39 --> Model Class Initialized
INFO - 2016-11-17 21:57:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 21:57:39 --> Final output sent to browser
DEBUG - 2016-11-17 21:57:39 --> Total execution time: 0.5668
INFO - 2016-11-17 21:57:43 --> Config Class Initialized
INFO - 2016-11-17 21:57:43 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:57:43 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:57:43 --> Utf8 Class Initialized
INFO - 2016-11-17 21:57:43 --> URI Class Initialized
DEBUG - 2016-11-17 21:57:43 --> No URI present. Default controller set.
INFO - 2016-11-17 21:57:43 --> Router Class Initialized
INFO - 2016-11-17 21:57:43 --> Output Class Initialized
INFO - 2016-11-17 21:57:43 --> Security Class Initialized
DEBUG - 2016-11-17 21:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:57:43 --> Input Class Initialized
INFO - 2016-11-17 21:57:43 --> Language Class Initialized
INFO - 2016-11-17 21:57:43 --> Loader Class Initialized
INFO - 2016-11-17 21:57:43 --> Helper loaded: url_helper
INFO - 2016-11-17 21:57:43 --> Helper loaded: form_helper
INFO - 2016-11-17 21:57:43 --> Database Driver Class Initialized
INFO - 2016-11-17 21:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:57:43 --> Controller Class Initialized
INFO - 2016-11-17 21:57:43 --> Model Class Initialized
INFO - 2016-11-17 21:57:43 --> Model Class Initialized
INFO - 2016-11-17 21:57:43 --> Model Class Initialized
INFO - 2016-11-17 21:57:43 --> Model Class Initialized
INFO - 2016-11-17 21:57:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 21:57:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 21:57:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 21:57:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 21:57:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 21:57:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 21:57:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 21:57:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 21:57:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 21:57:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 21:57:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 21:57:43 --> Final output sent to browser
DEBUG - 2016-11-17 21:57:43 --> Total execution time: 0.4950
INFO - 2016-11-17 21:57:51 --> Config Class Initialized
INFO - 2016-11-17 21:57:51 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:57:51 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:57:51 --> Utf8 Class Initialized
INFO - 2016-11-17 21:57:51 --> URI Class Initialized
INFO - 2016-11-17 21:57:51 --> Router Class Initialized
INFO - 2016-11-17 21:57:51 --> Output Class Initialized
INFO - 2016-11-17 21:57:51 --> Security Class Initialized
DEBUG - 2016-11-17 21:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:57:51 --> Input Class Initialized
INFO - 2016-11-17 21:57:51 --> Language Class Initialized
INFO - 2016-11-17 21:57:51 --> Loader Class Initialized
INFO - 2016-11-17 21:57:51 --> Helper loaded: url_helper
INFO - 2016-11-17 21:57:51 --> Helper loaded: form_helper
INFO - 2016-11-17 21:57:51 --> Database Driver Class Initialized
INFO - 2016-11-17 21:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:57:51 --> Controller Class Initialized
INFO - 2016-11-17 21:57:51 --> Model Class Initialized
INFO - 2016-11-17 21:57:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 21:57:51 --> Final output sent to browser
DEBUG - 2016-11-17 21:57:51 --> Total execution time: 0.3578
INFO - 2016-11-17 21:57:55 --> Config Class Initialized
INFO - 2016-11-17 21:57:55 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:57:55 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:57:55 --> Utf8 Class Initialized
INFO - 2016-11-17 21:57:55 --> URI Class Initialized
DEBUG - 2016-11-17 21:57:55 --> No URI present. Default controller set.
INFO - 2016-11-17 21:57:55 --> Router Class Initialized
INFO - 2016-11-17 21:57:55 --> Output Class Initialized
INFO - 2016-11-17 21:57:55 --> Security Class Initialized
DEBUG - 2016-11-17 21:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:57:55 --> Input Class Initialized
INFO - 2016-11-17 21:57:55 --> Language Class Initialized
INFO - 2016-11-17 21:57:56 --> Loader Class Initialized
INFO - 2016-11-17 21:57:56 --> Helper loaded: url_helper
INFO - 2016-11-17 21:57:56 --> Helper loaded: form_helper
INFO - 2016-11-17 21:57:56 --> Database Driver Class Initialized
INFO - 2016-11-17 21:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:57:56 --> Controller Class Initialized
INFO - 2016-11-17 21:57:56 --> Model Class Initialized
INFO - 2016-11-17 21:57:56 --> Model Class Initialized
INFO - 2016-11-17 21:57:56 --> Model Class Initialized
INFO - 2016-11-17 21:57:56 --> Model Class Initialized
INFO - 2016-11-17 21:57:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 21:57:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 21:57:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 21:57:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 21:57:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 21:57:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 21:57:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 21:57:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 21:57:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 21:57:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 21:57:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 21:57:56 --> Final output sent to browser
DEBUG - 2016-11-17 21:57:56 --> Total execution time: 0.5298
INFO - 2016-11-17 21:58:15 --> Config Class Initialized
INFO - 2016-11-17 21:58:15 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:58:15 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:58:15 --> Utf8 Class Initialized
INFO - 2016-11-17 21:58:15 --> URI Class Initialized
INFO - 2016-11-17 21:58:15 --> Router Class Initialized
INFO - 2016-11-17 21:58:15 --> Output Class Initialized
INFO - 2016-11-17 21:58:15 --> Security Class Initialized
DEBUG - 2016-11-17 21:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:58:15 --> Input Class Initialized
INFO - 2016-11-17 21:58:15 --> Language Class Initialized
INFO - 2016-11-17 21:58:15 --> Loader Class Initialized
INFO - 2016-11-17 21:58:15 --> Helper loaded: url_helper
INFO - 2016-11-17 21:58:15 --> Helper loaded: form_helper
INFO - 2016-11-17 21:58:15 --> Database Driver Class Initialized
INFO - 2016-11-17 21:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:58:15 --> Controller Class Initialized
INFO - 2016-11-17 21:58:15 --> Model Class Initialized
INFO - 2016-11-17 21:58:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 21:58:15 --> Final output sent to browser
DEBUG - 2016-11-17 21:58:15 --> Total execution time: 0.3962
INFO - 2016-11-17 21:58:18 --> Config Class Initialized
INFO - 2016-11-17 21:58:18 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:58:18 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:58:18 --> Utf8 Class Initialized
INFO - 2016-11-17 21:58:18 --> URI Class Initialized
DEBUG - 2016-11-17 21:58:18 --> No URI present. Default controller set.
INFO - 2016-11-17 21:58:18 --> Router Class Initialized
INFO - 2016-11-17 21:58:18 --> Output Class Initialized
INFO - 2016-11-17 21:58:18 --> Security Class Initialized
DEBUG - 2016-11-17 21:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:58:18 --> Input Class Initialized
INFO - 2016-11-17 21:58:18 --> Language Class Initialized
INFO - 2016-11-17 21:58:18 --> Loader Class Initialized
INFO - 2016-11-17 21:58:18 --> Helper loaded: url_helper
INFO - 2016-11-17 21:58:18 --> Helper loaded: form_helper
INFO - 2016-11-17 21:58:19 --> Database Driver Class Initialized
INFO - 2016-11-17 21:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:58:19 --> Controller Class Initialized
INFO - 2016-11-17 21:58:19 --> Model Class Initialized
INFO - 2016-11-17 21:58:19 --> Model Class Initialized
INFO - 2016-11-17 21:58:19 --> Model Class Initialized
INFO - 2016-11-17 21:58:19 --> Model Class Initialized
INFO - 2016-11-17 21:58:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 21:58:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 21:58:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 21:58:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 21:58:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 21:58:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 21:58:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 21:58:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 21:58:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 21:58:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 21:58:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 21:58:19 --> Final output sent to browser
DEBUG - 2016-11-17 21:58:19 --> Total execution time: 0.5094
INFO - 2016-11-17 21:59:37 --> Config Class Initialized
INFO - 2016-11-17 21:59:37 --> Hooks Class Initialized
DEBUG - 2016-11-17 21:59:37 --> UTF-8 Support Enabled
INFO - 2016-11-17 21:59:37 --> Utf8 Class Initialized
INFO - 2016-11-17 21:59:37 --> URI Class Initialized
DEBUG - 2016-11-17 21:59:37 --> No URI present. Default controller set.
INFO - 2016-11-17 21:59:37 --> Router Class Initialized
INFO - 2016-11-17 21:59:37 --> Output Class Initialized
INFO - 2016-11-17 21:59:37 --> Security Class Initialized
DEBUG - 2016-11-17 21:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 21:59:37 --> Input Class Initialized
INFO - 2016-11-17 21:59:37 --> Language Class Initialized
INFO - 2016-11-17 21:59:37 --> Loader Class Initialized
INFO - 2016-11-17 21:59:37 --> Helper loaded: url_helper
INFO - 2016-11-17 21:59:37 --> Helper loaded: form_helper
INFO - 2016-11-17 21:59:37 --> Database Driver Class Initialized
INFO - 2016-11-17 21:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 21:59:37 --> Controller Class Initialized
INFO - 2016-11-17 21:59:37 --> Model Class Initialized
INFO - 2016-11-17 21:59:37 --> Model Class Initialized
INFO - 2016-11-17 21:59:37 --> Model Class Initialized
INFO - 2016-11-17 21:59:37 --> Model Class Initialized
INFO - 2016-11-17 21:59:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 21:59:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 21:59:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 21:59:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 21:59:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 21:59:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 21:59:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 21:59:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 21:59:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 21:59:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 21:59:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 21:59:37 --> Final output sent to browser
DEBUG - 2016-11-17 21:59:37 --> Total execution time: 0.5952
INFO - 2016-11-17 22:00:10 --> Config Class Initialized
INFO - 2016-11-17 22:00:10 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:00:10 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:00:10 --> Utf8 Class Initialized
INFO - 2016-11-17 22:00:10 --> URI Class Initialized
INFO - 2016-11-17 22:00:10 --> Router Class Initialized
INFO - 2016-11-17 22:00:10 --> Output Class Initialized
INFO - 2016-11-17 22:00:10 --> Security Class Initialized
DEBUG - 2016-11-17 22:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:00:10 --> Input Class Initialized
INFO - 2016-11-17 22:00:10 --> Language Class Initialized
INFO - 2016-11-17 22:00:10 --> Loader Class Initialized
INFO - 2016-11-17 22:00:10 --> Helper loaded: url_helper
INFO - 2016-11-17 22:00:10 --> Helper loaded: form_helper
INFO - 2016-11-17 22:00:10 --> Database Driver Class Initialized
INFO - 2016-11-17 22:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:00:10 --> Controller Class Initialized
INFO - 2016-11-17 22:00:10 --> Model Class Initialized
INFO - 2016-11-17 22:00:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 22:00:11 --> Final output sent to browser
DEBUG - 2016-11-17 22:00:11 --> Total execution time: 0.4022
INFO - 2016-11-17 22:00:14 --> Config Class Initialized
INFO - 2016-11-17 22:00:14 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:00:14 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:00:14 --> Utf8 Class Initialized
INFO - 2016-11-17 22:00:14 --> URI Class Initialized
DEBUG - 2016-11-17 22:00:14 --> No URI present. Default controller set.
INFO - 2016-11-17 22:00:14 --> Router Class Initialized
INFO - 2016-11-17 22:00:14 --> Output Class Initialized
INFO - 2016-11-17 22:00:14 --> Security Class Initialized
DEBUG - 2016-11-17 22:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:00:14 --> Input Class Initialized
INFO - 2016-11-17 22:00:14 --> Language Class Initialized
INFO - 2016-11-17 22:00:14 --> Loader Class Initialized
INFO - 2016-11-17 22:00:14 --> Helper loaded: url_helper
INFO - 2016-11-17 22:00:14 --> Helper loaded: form_helper
INFO - 2016-11-17 22:00:14 --> Database Driver Class Initialized
INFO - 2016-11-17 22:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:00:14 --> Controller Class Initialized
INFO - 2016-11-17 22:00:14 --> Model Class Initialized
INFO - 2016-11-17 22:00:14 --> Model Class Initialized
INFO - 2016-11-17 22:00:14 --> Model Class Initialized
INFO - 2016-11-17 22:00:14 --> Model Class Initialized
INFO - 2016-11-17 22:00:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:00:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:00:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:00:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 22:00:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 22:00:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 22:00:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 22:00:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 22:00:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 22:00:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:00:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:00:14 --> Final output sent to browser
DEBUG - 2016-11-17 22:00:15 --> Total execution time: 0.5080
INFO - 2016-11-17 22:01:46 --> Config Class Initialized
INFO - 2016-11-17 22:01:46 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:01:46 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:01:46 --> Utf8 Class Initialized
INFO - 2016-11-17 22:01:46 --> URI Class Initialized
DEBUG - 2016-11-17 22:01:46 --> No URI present. Default controller set.
INFO - 2016-11-17 22:01:46 --> Router Class Initialized
INFO - 2016-11-17 22:01:46 --> Output Class Initialized
INFO - 2016-11-17 22:01:46 --> Security Class Initialized
DEBUG - 2016-11-17 22:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:01:46 --> Input Class Initialized
INFO - 2016-11-17 22:01:46 --> Language Class Initialized
INFO - 2016-11-17 22:01:46 --> Loader Class Initialized
INFO - 2016-11-17 22:01:46 --> Helper loaded: url_helper
INFO - 2016-11-17 22:01:46 --> Helper loaded: form_helper
INFO - 2016-11-17 22:01:46 --> Database Driver Class Initialized
INFO - 2016-11-17 22:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:01:46 --> Controller Class Initialized
INFO - 2016-11-17 22:01:46 --> Model Class Initialized
INFO - 2016-11-17 22:01:46 --> Model Class Initialized
INFO - 2016-11-17 22:01:46 --> Model Class Initialized
INFO - 2016-11-17 22:01:46 --> Model Class Initialized
INFO - 2016-11-17 22:01:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:01:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:01:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:01:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 22:01:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 22:01:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 22:01:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 22:01:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 22:01:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 22:01:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:01:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:01:47 --> Final output sent to browser
DEBUG - 2016-11-17 22:01:47 --> Total execution time: 0.5320
INFO - 2016-11-17 22:02:05 --> Config Class Initialized
INFO - 2016-11-17 22:02:05 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:02:05 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:02:05 --> Utf8 Class Initialized
INFO - 2016-11-17 22:02:05 --> URI Class Initialized
INFO - 2016-11-17 22:02:05 --> Router Class Initialized
INFO - 2016-11-17 22:02:05 --> Output Class Initialized
INFO - 2016-11-17 22:02:05 --> Security Class Initialized
DEBUG - 2016-11-17 22:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:02:05 --> Input Class Initialized
INFO - 2016-11-17 22:02:05 --> Language Class Initialized
INFO - 2016-11-17 22:02:05 --> Loader Class Initialized
INFO - 2016-11-17 22:02:05 --> Helper loaded: url_helper
INFO - 2016-11-17 22:02:06 --> Helper loaded: form_helper
INFO - 2016-11-17 22:02:06 --> Database Driver Class Initialized
INFO - 2016-11-17 22:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:02:06 --> Controller Class Initialized
INFO - 2016-11-17 22:02:06 --> Model Class Initialized
INFO - 2016-11-17 22:02:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 22:02:06 --> Final output sent to browser
DEBUG - 2016-11-17 22:02:06 --> Total execution time: 0.3581
INFO - 2016-11-17 22:02:09 --> Config Class Initialized
INFO - 2016-11-17 22:02:09 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:02:09 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:02:09 --> Utf8 Class Initialized
INFO - 2016-11-17 22:02:09 --> URI Class Initialized
DEBUG - 2016-11-17 22:02:09 --> No URI present. Default controller set.
INFO - 2016-11-17 22:02:09 --> Router Class Initialized
INFO - 2016-11-17 22:02:09 --> Output Class Initialized
INFO - 2016-11-17 22:02:09 --> Security Class Initialized
DEBUG - 2016-11-17 22:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:02:09 --> Input Class Initialized
INFO - 2016-11-17 22:02:09 --> Language Class Initialized
INFO - 2016-11-17 22:02:09 --> Loader Class Initialized
INFO - 2016-11-17 22:02:09 --> Helper loaded: url_helper
INFO - 2016-11-17 22:02:09 --> Helper loaded: form_helper
INFO - 2016-11-17 22:02:09 --> Database Driver Class Initialized
INFO - 2016-11-17 22:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:02:09 --> Controller Class Initialized
INFO - 2016-11-17 22:02:10 --> Model Class Initialized
INFO - 2016-11-17 22:02:10 --> Model Class Initialized
INFO - 2016-11-17 22:02:10 --> Model Class Initialized
INFO - 2016-11-17 22:02:10 --> Model Class Initialized
INFO - 2016-11-17 22:02:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:02:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:02:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:02:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 22:02:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 22:02:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 22:02:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 22:02:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 22:02:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 22:02:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:02:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:02:10 --> Final output sent to browser
DEBUG - 2016-11-17 22:02:10 --> Total execution time: 0.5193
INFO - 2016-11-17 22:02:29 --> Config Class Initialized
INFO - 2016-11-17 22:02:29 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:02:29 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:02:29 --> Utf8 Class Initialized
INFO - 2016-11-17 22:02:29 --> URI Class Initialized
INFO - 2016-11-17 22:02:29 --> Router Class Initialized
INFO - 2016-11-17 22:02:29 --> Output Class Initialized
INFO - 2016-11-17 22:02:29 --> Security Class Initialized
DEBUG - 2016-11-17 22:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:02:29 --> Input Class Initialized
INFO - 2016-11-17 22:02:29 --> Language Class Initialized
INFO - 2016-11-17 22:02:29 --> Loader Class Initialized
INFO - 2016-11-17 22:02:29 --> Helper loaded: url_helper
INFO - 2016-11-17 22:02:29 --> Helper loaded: form_helper
INFO - 2016-11-17 22:02:29 --> Database Driver Class Initialized
INFO - 2016-11-17 22:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:02:29 --> Controller Class Initialized
INFO - 2016-11-17 22:02:29 --> Model Class Initialized
INFO - 2016-11-17 22:02:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 22:02:29 --> Final output sent to browser
DEBUG - 2016-11-17 22:02:29 --> Total execution time: 0.2843
INFO - 2016-11-17 22:02:32 --> Config Class Initialized
INFO - 2016-11-17 22:02:32 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:02:32 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:02:32 --> Utf8 Class Initialized
INFO - 2016-11-17 22:02:32 --> URI Class Initialized
DEBUG - 2016-11-17 22:02:32 --> No URI present. Default controller set.
INFO - 2016-11-17 22:02:32 --> Router Class Initialized
INFO - 2016-11-17 22:02:32 --> Output Class Initialized
INFO - 2016-11-17 22:02:32 --> Security Class Initialized
DEBUG - 2016-11-17 22:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:02:32 --> Input Class Initialized
INFO - 2016-11-17 22:02:32 --> Language Class Initialized
INFO - 2016-11-17 22:02:32 --> Loader Class Initialized
INFO - 2016-11-17 22:02:33 --> Helper loaded: url_helper
INFO - 2016-11-17 22:02:33 --> Helper loaded: form_helper
INFO - 2016-11-17 22:02:33 --> Database Driver Class Initialized
INFO - 2016-11-17 22:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:02:33 --> Controller Class Initialized
INFO - 2016-11-17 22:02:33 --> Model Class Initialized
INFO - 2016-11-17 22:02:33 --> Model Class Initialized
INFO - 2016-11-17 22:02:33 --> Model Class Initialized
INFO - 2016-11-17 22:02:33 --> Model Class Initialized
INFO - 2016-11-17 22:02:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:02:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:02:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:02:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 22:02:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 22:02:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 22:02:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 22:02:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 22:02:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 22:02:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:02:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:02:33 --> Final output sent to browser
DEBUG - 2016-11-17 22:02:33 --> Total execution time: 0.5227
INFO - 2016-11-17 22:02:36 --> Config Class Initialized
INFO - 2016-11-17 22:02:36 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:02:36 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:02:36 --> Utf8 Class Initialized
INFO - 2016-11-17 22:02:37 --> URI Class Initialized
INFO - 2016-11-17 22:02:37 --> Router Class Initialized
INFO - 2016-11-17 22:02:37 --> Output Class Initialized
INFO - 2016-11-17 22:02:37 --> Security Class Initialized
DEBUG - 2016-11-17 22:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:02:37 --> Input Class Initialized
INFO - 2016-11-17 22:02:37 --> Language Class Initialized
INFO - 2016-11-17 22:02:37 --> Loader Class Initialized
INFO - 2016-11-17 22:02:37 --> Helper loaded: url_helper
INFO - 2016-11-17 22:02:37 --> Helper loaded: form_helper
INFO - 2016-11-17 22:02:37 --> Database Driver Class Initialized
INFO - 2016-11-17 22:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:02:37 --> Controller Class Initialized
INFO - 2016-11-17 22:02:37 --> Model Class Initialized
INFO - 2016-11-17 22:02:37 --> Form Validation Class Initialized
INFO - 2016-11-17 22:02:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:02:37 --> Final output sent to browser
DEBUG - 2016-11-17 22:02:37 --> Total execution time: 0.2961
INFO - 2016-11-17 22:08:18 --> Config Class Initialized
INFO - 2016-11-17 22:08:18 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:08:18 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:08:18 --> Utf8 Class Initialized
INFO - 2016-11-17 22:08:18 --> URI Class Initialized
DEBUG - 2016-11-17 22:08:18 --> No URI present. Default controller set.
INFO - 2016-11-17 22:08:18 --> Router Class Initialized
INFO - 2016-11-17 22:08:18 --> Output Class Initialized
INFO - 2016-11-17 22:08:18 --> Security Class Initialized
DEBUG - 2016-11-17 22:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:08:18 --> Input Class Initialized
INFO - 2016-11-17 22:08:18 --> Language Class Initialized
INFO - 2016-11-17 22:08:18 --> Loader Class Initialized
INFO - 2016-11-17 22:08:18 --> Helper loaded: url_helper
INFO - 2016-11-17 22:08:18 --> Helper loaded: form_helper
INFO - 2016-11-17 22:08:19 --> Database Driver Class Initialized
INFO - 2016-11-17 22:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:08:19 --> Controller Class Initialized
INFO - 2016-11-17 22:08:19 --> Model Class Initialized
INFO - 2016-11-17 22:08:19 --> Model Class Initialized
INFO - 2016-11-17 22:08:19 --> Model Class Initialized
INFO - 2016-11-17 22:08:19 --> Model Class Initialized
INFO - 2016-11-17 22:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 22:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 22:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 22:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 22:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 22:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 22:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:08:19 --> Final output sent to browser
DEBUG - 2016-11-17 22:08:19 --> Total execution time: 0.5241
INFO - 2016-11-17 22:08:23 --> Config Class Initialized
INFO - 2016-11-17 22:08:23 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:08:23 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:08:23 --> Utf8 Class Initialized
INFO - 2016-11-17 22:08:23 --> URI Class Initialized
DEBUG - 2016-11-17 22:08:23 --> No URI present. Default controller set.
INFO - 2016-11-17 22:08:23 --> Router Class Initialized
INFO - 2016-11-17 22:08:23 --> Output Class Initialized
INFO - 2016-11-17 22:08:23 --> Security Class Initialized
DEBUG - 2016-11-17 22:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:08:23 --> Input Class Initialized
INFO - 2016-11-17 22:08:23 --> Language Class Initialized
INFO - 2016-11-17 22:08:23 --> Loader Class Initialized
INFO - 2016-11-17 22:08:23 --> Helper loaded: url_helper
INFO - 2016-11-17 22:08:23 --> Helper loaded: form_helper
INFO - 2016-11-17 22:08:23 --> Database Driver Class Initialized
INFO - 2016-11-17 22:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:08:23 --> Controller Class Initialized
INFO - 2016-11-17 22:08:23 --> Model Class Initialized
INFO - 2016-11-17 22:08:23 --> Model Class Initialized
INFO - 2016-11-17 22:08:23 --> Model Class Initialized
INFO - 2016-11-17 22:08:23 --> Model Class Initialized
INFO - 2016-11-17 22:08:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:08:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:08:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:08:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 22:08:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 22:08:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 22:08:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 22:08:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 22:08:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 22:08:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:08:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:08:23 --> Final output sent to browser
DEBUG - 2016-11-17 22:08:23 --> Total execution time: 0.5078
INFO - 2016-11-17 22:08:31 --> Config Class Initialized
INFO - 2016-11-17 22:08:31 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:08:31 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:08:31 --> Utf8 Class Initialized
INFO - 2016-11-17 22:08:31 --> URI Class Initialized
DEBUG - 2016-11-17 22:08:31 --> No URI present. Default controller set.
INFO - 2016-11-17 22:08:32 --> Router Class Initialized
INFO - 2016-11-17 22:08:32 --> Output Class Initialized
INFO - 2016-11-17 22:08:32 --> Security Class Initialized
DEBUG - 2016-11-17 22:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:08:32 --> Input Class Initialized
INFO - 2016-11-17 22:08:32 --> Language Class Initialized
INFO - 2016-11-17 22:08:32 --> Loader Class Initialized
INFO - 2016-11-17 22:08:32 --> Helper loaded: url_helper
INFO - 2016-11-17 22:08:32 --> Helper loaded: form_helper
INFO - 2016-11-17 22:08:32 --> Database Driver Class Initialized
INFO - 2016-11-17 22:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:08:32 --> Controller Class Initialized
INFO - 2016-11-17 22:08:32 --> Model Class Initialized
INFO - 2016-11-17 22:08:32 --> Model Class Initialized
INFO - 2016-11-17 22:08:32 --> Model Class Initialized
INFO - 2016-11-17 22:08:32 --> Model Class Initialized
INFO - 2016-11-17 22:08:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:08:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:08:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:08:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 22:08:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 22:08:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 22:08:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 22:08:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 22:08:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 22:08:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:08:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:08:32 --> Final output sent to browser
DEBUG - 2016-11-17 22:08:32 --> Total execution time: 0.5356
INFO - 2016-11-17 22:08:36 --> Config Class Initialized
INFO - 2016-11-17 22:08:36 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:08:36 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:08:36 --> Utf8 Class Initialized
INFO - 2016-11-17 22:08:36 --> URI Class Initialized
DEBUG - 2016-11-17 22:08:36 --> No URI present. Default controller set.
INFO - 2016-11-17 22:08:36 --> Router Class Initialized
INFO - 2016-11-17 22:08:36 --> Output Class Initialized
INFO - 2016-11-17 22:08:37 --> Security Class Initialized
DEBUG - 2016-11-17 22:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:08:37 --> Input Class Initialized
INFO - 2016-11-17 22:08:37 --> Language Class Initialized
INFO - 2016-11-17 22:08:37 --> Loader Class Initialized
INFO - 2016-11-17 22:08:37 --> Helper loaded: url_helper
INFO - 2016-11-17 22:08:37 --> Helper loaded: form_helper
INFO - 2016-11-17 22:08:37 --> Database Driver Class Initialized
INFO - 2016-11-17 22:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:08:37 --> Controller Class Initialized
INFO - 2016-11-17 22:08:37 --> Model Class Initialized
INFO - 2016-11-17 22:08:37 --> Model Class Initialized
INFO - 2016-11-17 22:08:37 --> Model Class Initialized
INFO - 2016-11-17 22:08:37 --> Model Class Initialized
INFO - 2016-11-17 22:08:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:08:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:08:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:08:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 22:08:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 22:08:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 22:08:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 22:08:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 22:08:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 22:08:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:08:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:08:37 --> Final output sent to browser
DEBUG - 2016-11-17 22:08:37 --> Total execution time: 0.5109
INFO - 2016-11-17 22:08:40 --> Config Class Initialized
INFO - 2016-11-17 22:08:40 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:08:40 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:08:40 --> Utf8 Class Initialized
INFO - 2016-11-17 22:08:40 --> URI Class Initialized
DEBUG - 2016-11-17 22:08:40 --> No URI present. Default controller set.
INFO - 2016-11-17 22:08:40 --> Router Class Initialized
INFO - 2016-11-17 22:08:40 --> Output Class Initialized
INFO - 2016-11-17 22:08:40 --> Security Class Initialized
DEBUG - 2016-11-17 22:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:08:40 --> Input Class Initialized
INFO - 2016-11-17 22:08:40 --> Language Class Initialized
INFO - 2016-11-17 22:08:40 --> Loader Class Initialized
INFO - 2016-11-17 22:08:40 --> Helper loaded: url_helper
INFO - 2016-11-17 22:08:40 --> Helper loaded: form_helper
INFO - 2016-11-17 22:08:40 --> Database Driver Class Initialized
INFO - 2016-11-17 22:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:08:40 --> Controller Class Initialized
INFO - 2016-11-17 22:08:40 --> Model Class Initialized
INFO - 2016-11-17 22:08:40 --> Model Class Initialized
INFO - 2016-11-17 22:08:40 --> Model Class Initialized
INFO - 2016-11-17 22:08:40 --> Model Class Initialized
INFO - 2016-11-17 22:08:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:08:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:08:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:08:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 22:08:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 22:08:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 22:08:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 22:08:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 22:08:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 22:08:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:08:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:08:40 --> Final output sent to browser
DEBUG - 2016-11-17 22:08:40 --> Total execution time: 0.5475
INFO - 2016-11-17 22:08:43 --> Config Class Initialized
INFO - 2016-11-17 22:08:43 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:08:43 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:08:43 --> Utf8 Class Initialized
INFO - 2016-11-17 22:08:43 --> URI Class Initialized
INFO - 2016-11-17 22:08:43 --> Router Class Initialized
INFO - 2016-11-17 22:08:43 --> Output Class Initialized
INFO - 2016-11-17 22:08:43 --> Security Class Initialized
DEBUG - 2016-11-17 22:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:08:43 --> Input Class Initialized
INFO - 2016-11-17 22:08:43 --> Language Class Initialized
INFO - 2016-11-17 22:08:43 --> Loader Class Initialized
INFO - 2016-11-17 22:08:43 --> Helper loaded: url_helper
INFO - 2016-11-17 22:08:43 --> Helper loaded: form_helper
INFO - 2016-11-17 22:08:43 --> Database Driver Class Initialized
INFO - 2016-11-17 22:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:08:43 --> Controller Class Initialized
INFO - 2016-11-17 22:08:43 --> Model Class Initialized
INFO - 2016-11-17 22:08:43 --> Form Validation Class Initialized
INFO - 2016-11-17 22:08:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:08:43 --> Final output sent to browser
DEBUG - 2016-11-17 22:08:43 --> Total execution time: 0.2956
INFO - 2016-11-17 22:09:14 --> Config Class Initialized
INFO - 2016-11-17 22:09:14 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:09:14 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:09:14 --> Utf8 Class Initialized
INFO - 2016-11-17 22:09:14 --> URI Class Initialized
DEBUG - 2016-11-17 22:09:14 --> No URI present. Default controller set.
INFO - 2016-11-17 22:09:14 --> Router Class Initialized
INFO - 2016-11-17 22:09:14 --> Output Class Initialized
INFO - 2016-11-17 22:09:14 --> Security Class Initialized
DEBUG - 2016-11-17 22:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:09:14 --> Input Class Initialized
INFO - 2016-11-17 22:09:14 --> Language Class Initialized
INFO - 2016-11-17 22:09:14 --> Loader Class Initialized
INFO - 2016-11-17 22:09:14 --> Helper loaded: url_helper
INFO - 2016-11-17 22:09:14 --> Helper loaded: form_helper
INFO - 2016-11-17 22:09:14 --> Database Driver Class Initialized
INFO - 2016-11-17 22:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:09:14 --> Controller Class Initialized
INFO - 2016-11-17 22:09:14 --> Model Class Initialized
INFO - 2016-11-17 22:09:14 --> Model Class Initialized
INFO - 2016-11-17 22:09:14 --> Model Class Initialized
INFO - 2016-11-17 22:09:14 --> Model Class Initialized
INFO - 2016-11-17 22:09:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:09:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:09:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:09:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 22:09:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 22:09:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 22:09:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 22:09:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 22:09:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 22:09:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:09:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:09:15 --> Final output sent to browser
DEBUG - 2016-11-17 22:09:15 --> Total execution time: 0.5174
INFO - 2016-11-17 22:09:15 --> Config Class Initialized
INFO - 2016-11-17 22:09:15 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:09:15 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:09:15 --> Utf8 Class Initialized
INFO - 2016-11-17 22:09:15 --> URI Class Initialized
DEBUG - 2016-11-17 22:09:15 --> No URI present. Default controller set.
INFO - 2016-11-17 22:09:15 --> Router Class Initialized
INFO - 2016-11-17 22:09:15 --> Output Class Initialized
INFO - 2016-11-17 22:09:15 --> Security Class Initialized
DEBUG - 2016-11-17 22:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:09:15 --> Input Class Initialized
INFO - 2016-11-17 22:09:15 --> Language Class Initialized
INFO - 2016-11-17 22:09:15 --> Loader Class Initialized
INFO - 2016-11-17 22:09:15 --> Helper loaded: url_helper
INFO - 2016-11-17 22:09:15 --> Helper loaded: form_helper
INFO - 2016-11-17 22:09:15 --> Database Driver Class Initialized
INFO - 2016-11-17 22:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:09:15 --> Controller Class Initialized
INFO - 2016-11-17 22:09:15 --> Model Class Initialized
INFO - 2016-11-17 22:09:15 --> Model Class Initialized
INFO - 2016-11-17 22:09:15 --> Model Class Initialized
INFO - 2016-11-17 22:09:15 --> Model Class Initialized
INFO - 2016-11-17 22:09:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:09:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:09:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:09:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 22:09:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 22:09:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 22:09:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 22:09:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 22:09:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 22:09:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:09:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:09:15 --> Final output sent to browser
DEBUG - 2016-11-17 22:09:15 --> Total execution time: 0.5344
INFO - 2016-11-17 22:09:17 --> Config Class Initialized
INFO - 2016-11-17 22:09:17 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:09:17 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:09:17 --> Utf8 Class Initialized
INFO - 2016-11-17 22:09:17 --> URI Class Initialized
DEBUG - 2016-11-17 22:09:17 --> No URI present. Default controller set.
INFO - 2016-11-17 22:09:17 --> Router Class Initialized
INFO - 2016-11-17 22:09:17 --> Output Class Initialized
INFO - 2016-11-17 22:09:17 --> Security Class Initialized
DEBUG - 2016-11-17 22:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:09:18 --> Input Class Initialized
INFO - 2016-11-17 22:09:18 --> Language Class Initialized
INFO - 2016-11-17 22:09:18 --> Loader Class Initialized
INFO - 2016-11-17 22:09:18 --> Helper loaded: url_helper
INFO - 2016-11-17 22:09:18 --> Helper loaded: form_helper
INFO - 2016-11-17 22:09:18 --> Database Driver Class Initialized
INFO - 2016-11-17 22:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:09:18 --> Controller Class Initialized
INFO - 2016-11-17 22:09:18 --> Model Class Initialized
INFO - 2016-11-17 22:09:18 --> Model Class Initialized
INFO - 2016-11-17 22:09:18 --> Model Class Initialized
INFO - 2016-11-17 22:09:18 --> Model Class Initialized
INFO - 2016-11-17 22:09:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:09:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:09:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:09:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 22:09:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 22:09:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 22:09:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 22:09:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 22:09:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 22:09:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:09:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:09:18 --> Final output sent to browser
DEBUG - 2016-11-17 22:09:18 --> Total execution time: 0.5507
INFO - 2016-11-17 22:09:47 --> Config Class Initialized
INFO - 2016-11-17 22:09:47 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:09:47 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:09:47 --> Utf8 Class Initialized
INFO - 2016-11-17 22:09:47 --> URI Class Initialized
INFO - 2016-11-17 22:09:47 --> Router Class Initialized
INFO - 2016-11-17 22:09:48 --> Output Class Initialized
INFO - 2016-11-17 22:09:48 --> Security Class Initialized
DEBUG - 2016-11-17 22:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:09:48 --> Input Class Initialized
INFO - 2016-11-17 22:09:48 --> Language Class Initialized
INFO - 2016-11-17 22:09:48 --> Loader Class Initialized
INFO - 2016-11-17 22:09:48 --> Helper loaded: url_helper
INFO - 2016-11-17 22:09:48 --> Helper loaded: form_helper
INFO - 2016-11-17 22:09:48 --> Database Driver Class Initialized
INFO - 2016-11-17 22:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:09:48 --> Controller Class Initialized
INFO - 2016-11-17 22:09:48 --> Model Class Initialized
INFO - 2016-11-17 22:09:48 --> Form Validation Class Initialized
INFO - 2016-11-17 22:09:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:09:48 --> Final output sent to browser
DEBUG - 2016-11-17 22:09:48 --> Total execution time: 0.2983
INFO - 2016-11-17 22:09:58 --> Config Class Initialized
INFO - 2016-11-17 22:09:58 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:09:58 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:09:58 --> Utf8 Class Initialized
INFO - 2016-11-17 22:09:58 --> URI Class Initialized
DEBUG - 2016-11-17 22:09:58 --> No URI present. Default controller set.
INFO - 2016-11-17 22:09:58 --> Router Class Initialized
INFO - 2016-11-17 22:09:58 --> Output Class Initialized
INFO - 2016-11-17 22:09:58 --> Security Class Initialized
DEBUG - 2016-11-17 22:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:09:58 --> Input Class Initialized
INFO - 2016-11-17 22:09:58 --> Language Class Initialized
INFO - 2016-11-17 22:09:58 --> Loader Class Initialized
INFO - 2016-11-17 22:09:58 --> Helper loaded: url_helper
INFO - 2016-11-17 22:09:58 --> Helper loaded: form_helper
INFO - 2016-11-17 22:09:58 --> Database Driver Class Initialized
INFO - 2016-11-17 22:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:09:58 --> Controller Class Initialized
INFO - 2016-11-17 22:09:58 --> Model Class Initialized
INFO - 2016-11-17 22:09:58 --> Model Class Initialized
INFO - 2016-11-17 22:09:58 --> Model Class Initialized
INFO - 2016-11-17 22:09:58 --> Model Class Initialized
INFO - 2016-11-17 22:09:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:09:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:09:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:09:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 22:09:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 22:09:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 22:09:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 22:09:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 22:09:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 22:09:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:09:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:09:58 --> Final output sent to browser
DEBUG - 2016-11-17 22:09:58 --> Total execution time: 0.5646
INFO - 2016-11-17 22:10:24 --> Config Class Initialized
INFO - 2016-11-17 22:10:24 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:10:24 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:10:24 --> Utf8 Class Initialized
INFO - 2016-11-17 22:10:25 --> URI Class Initialized
INFO - 2016-11-17 22:10:25 --> Router Class Initialized
INFO - 2016-11-17 22:10:25 --> Output Class Initialized
INFO - 2016-11-17 22:10:25 --> Security Class Initialized
DEBUG - 2016-11-17 22:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:10:25 --> Input Class Initialized
INFO - 2016-11-17 22:10:25 --> Language Class Initialized
INFO - 2016-11-17 22:10:25 --> Loader Class Initialized
INFO - 2016-11-17 22:10:25 --> Helper loaded: url_helper
INFO - 2016-11-17 22:10:25 --> Helper loaded: form_helper
INFO - 2016-11-17 22:10:25 --> Database Driver Class Initialized
INFO - 2016-11-17 22:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:10:25 --> Controller Class Initialized
INFO - 2016-11-17 22:10:25 --> Model Class Initialized
INFO - 2016-11-17 22:10:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 22:10:25 --> Final output sent to browser
DEBUG - 2016-11-17 22:10:25 --> Total execution time: 0.3944
INFO - 2016-11-17 22:10:27 --> Config Class Initialized
INFO - 2016-11-17 22:10:27 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:10:27 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:10:27 --> Utf8 Class Initialized
INFO - 2016-11-17 22:10:27 --> URI Class Initialized
DEBUG - 2016-11-17 22:10:27 --> No URI present. Default controller set.
INFO - 2016-11-17 22:10:27 --> Router Class Initialized
INFO - 2016-11-17 22:10:27 --> Output Class Initialized
INFO - 2016-11-17 22:10:27 --> Security Class Initialized
DEBUG - 2016-11-17 22:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:10:27 --> Input Class Initialized
INFO - 2016-11-17 22:10:27 --> Language Class Initialized
INFO - 2016-11-17 22:10:27 --> Loader Class Initialized
INFO - 2016-11-17 22:10:27 --> Helper loaded: url_helper
INFO - 2016-11-17 22:10:27 --> Helper loaded: form_helper
INFO - 2016-11-17 22:10:27 --> Database Driver Class Initialized
INFO - 2016-11-17 22:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:10:28 --> Controller Class Initialized
INFO - 2016-11-17 22:10:28 --> Model Class Initialized
INFO - 2016-11-17 22:10:28 --> Model Class Initialized
INFO - 2016-11-17 22:10:28 --> Model Class Initialized
INFO - 2016-11-17 22:10:28 --> Model Class Initialized
INFO - 2016-11-17 22:10:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:10:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:10:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:10:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 22:10:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 22:10:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 22:10:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 22:10:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 22:10:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 22:10:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:10:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:10:28 --> Final output sent to browser
DEBUG - 2016-11-17 22:10:28 --> Total execution time: 0.5163
INFO - 2016-11-17 22:12:16 --> Config Class Initialized
INFO - 2016-11-17 22:12:16 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:12:16 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:12:16 --> Utf8 Class Initialized
INFO - 2016-11-17 22:12:16 --> URI Class Initialized
DEBUG - 2016-11-17 22:12:16 --> No URI present. Default controller set.
INFO - 2016-11-17 22:12:16 --> Router Class Initialized
INFO - 2016-11-17 22:12:16 --> Output Class Initialized
INFO - 2016-11-17 22:12:16 --> Security Class Initialized
DEBUG - 2016-11-17 22:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:12:16 --> Input Class Initialized
INFO - 2016-11-17 22:12:16 --> Language Class Initialized
INFO - 2016-11-17 22:12:17 --> Loader Class Initialized
INFO - 2016-11-17 22:12:17 --> Helper loaded: url_helper
INFO - 2016-11-17 22:12:17 --> Helper loaded: form_helper
INFO - 2016-11-17 22:12:17 --> Database Driver Class Initialized
INFO - 2016-11-17 22:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:12:17 --> Controller Class Initialized
INFO - 2016-11-17 22:12:17 --> Model Class Initialized
INFO - 2016-11-17 22:12:17 --> Model Class Initialized
INFO - 2016-11-17 22:12:17 --> Model Class Initialized
INFO - 2016-11-17 22:12:17 --> Model Class Initialized
INFO - 2016-11-17 22:12:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:12:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:12:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:12:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 22:12:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 22:12:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 22:12:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 22:12:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 22:12:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 22:12:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:12:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:12:17 --> Final output sent to browser
DEBUG - 2016-11-17 22:12:17 --> Total execution time: 0.5311
INFO - 2016-11-17 22:12:25 --> Config Class Initialized
INFO - 2016-11-17 22:12:25 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:12:26 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:12:26 --> Utf8 Class Initialized
INFO - 2016-11-17 22:12:26 --> URI Class Initialized
INFO - 2016-11-17 22:12:26 --> Router Class Initialized
INFO - 2016-11-17 22:12:26 --> Output Class Initialized
INFO - 2016-11-17 22:12:26 --> Security Class Initialized
DEBUG - 2016-11-17 22:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:12:26 --> Input Class Initialized
INFO - 2016-11-17 22:12:26 --> Language Class Initialized
INFO - 2016-11-17 22:12:26 --> Loader Class Initialized
INFO - 2016-11-17 22:12:26 --> Helper loaded: url_helper
INFO - 2016-11-17 22:12:26 --> Helper loaded: form_helper
INFO - 2016-11-17 22:12:26 --> Database Driver Class Initialized
INFO - 2016-11-17 22:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:12:26 --> Controller Class Initialized
INFO - 2016-11-17 22:12:26 --> Model Class Initialized
INFO - 2016-11-17 22:12:32 --> Config Class Initialized
INFO - 2016-11-17 22:12:32 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:12:32 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:12:32 --> Utf8 Class Initialized
INFO - 2016-11-17 22:12:32 --> URI Class Initialized
DEBUG - 2016-11-17 22:12:32 --> No URI present. Default controller set.
INFO - 2016-11-17 22:12:32 --> Router Class Initialized
INFO - 2016-11-17 22:12:32 --> Output Class Initialized
INFO - 2016-11-17 22:12:32 --> Security Class Initialized
DEBUG - 2016-11-17 22:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:12:32 --> Input Class Initialized
INFO - 2016-11-17 22:12:32 --> Language Class Initialized
INFO - 2016-11-17 22:12:32 --> Loader Class Initialized
INFO - 2016-11-17 22:12:32 --> Helper loaded: url_helper
INFO - 2016-11-17 22:12:32 --> Helper loaded: form_helper
INFO - 2016-11-17 22:12:32 --> Database Driver Class Initialized
INFO - 2016-11-17 22:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:12:32 --> Controller Class Initialized
INFO - 2016-11-17 22:12:32 --> Model Class Initialized
INFO - 2016-11-17 22:12:32 --> Model Class Initialized
INFO - 2016-11-17 22:12:32 --> Model Class Initialized
INFO - 2016-11-17 22:12:32 --> Model Class Initialized
INFO - 2016-11-17 22:12:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:12:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:12:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:12:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 22:12:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 22:12:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 22:12:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 22:12:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 22:12:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 22:12:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:12:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:12:32 --> Final output sent to browser
DEBUG - 2016-11-17 22:12:32 --> Total execution time: 0.5315
INFO - 2016-11-17 22:13:07 --> Config Class Initialized
INFO - 2016-11-17 22:13:07 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:13:07 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:13:07 --> Utf8 Class Initialized
INFO - 2016-11-17 22:13:07 --> URI Class Initialized
DEBUG - 2016-11-17 22:13:07 --> No URI present. Default controller set.
INFO - 2016-11-17 22:13:07 --> Router Class Initialized
INFO - 2016-11-17 22:13:07 --> Output Class Initialized
INFO - 2016-11-17 22:13:07 --> Security Class Initialized
DEBUG - 2016-11-17 22:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:13:07 --> Input Class Initialized
INFO - 2016-11-17 22:13:08 --> Language Class Initialized
INFO - 2016-11-17 22:13:08 --> Loader Class Initialized
INFO - 2016-11-17 22:13:08 --> Helper loaded: url_helper
INFO - 2016-11-17 22:13:08 --> Helper loaded: form_helper
INFO - 2016-11-17 22:13:08 --> Database Driver Class Initialized
INFO - 2016-11-17 22:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:13:08 --> Controller Class Initialized
INFO - 2016-11-17 22:13:08 --> Model Class Initialized
INFO - 2016-11-17 22:13:08 --> Model Class Initialized
INFO - 2016-11-17 22:13:08 --> Model Class Initialized
INFO - 2016-11-17 22:13:08 --> Model Class Initialized
INFO - 2016-11-17 22:13:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:13:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:13:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:13:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 22:13:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 22:13:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 22:13:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 22:13:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 22:13:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 22:13:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:13:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:13:08 --> Final output sent to browser
DEBUG - 2016-11-17 22:13:08 --> Total execution time: 0.5441
INFO - 2016-11-17 22:13:14 --> Config Class Initialized
INFO - 2016-11-17 22:13:14 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:13:14 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:13:14 --> Utf8 Class Initialized
INFO - 2016-11-17 22:13:14 --> URI Class Initialized
INFO - 2016-11-17 22:13:14 --> Router Class Initialized
INFO - 2016-11-17 22:13:14 --> Output Class Initialized
INFO - 2016-11-17 22:13:14 --> Security Class Initialized
DEBUG - 2016-11-17 22:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:13:14 --> Input Class Initialized
INFO - 2016-11-17 22:13:14 --> Language Class Initialized
INFO - 2016-11-17 22:13:14 --> Loader Class Initialized
INFO - 2016-11-17 22:13:14 --> Helper loaded: url_helper
INFO - 2016-11-17 22:13:14 --> Helper loaded: form_helper
INFO - 2016-11-17 22:13:14 --> Database Driver Class Initialized
INFO - 2016-11-17 22:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:13:14 --> Controller Class Initialized
INFO - 2016-11-17 22:13:14 --> Model Class Initialized
INFO - 2016-11-17 22:13:24 --> Config Class Initialized
INFO - 2016-11-17 22:13:24 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:13:24 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:13:24 --> Utf8 Class Initialized
INFO - 2016-11-17 22:13:24 --> URI Class Initialized
DEBUG - 2016-11-17 22:13:24 --> No URI present. Default controller set.
INFO - 2016-11-17 22:13:24 --> Router Class Initialized
INFO - 2016-11-17 22:13:24 --> Output Class Initialized
INFO - 2016-11-17 22:13:24 --> Security Class Initialized
DEBUG - 2016-11-17 22:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:13:24 --> Input Class Initialized
INFO - 2016-11-17 22:13:24 --> Language Class Initialized
INFO - 2016-11-17 22:13:24 --> Loader Class Initialized
INFO - 2016-11-17 22:13:24 --> Helper loaded: url_helper
INFO - 2016-11-17 22:13:24 --> Helper loaded: form_helper
INFO - 2016-11-17 22:13:24 --> Database Driver Class Initialized
INFO - 2016-11-17 22:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:13:24 --> Controller Class Initialized
INFO - 2016-11-17 22:13:24 --> Model Class Initialized
INFO - 2016-11-17 22:13:24 --> Model Class Initialized
INFO - 2016-11-17 22:13:24 --> Model Class Initialized
INFO - 2016-11-17 22:13:24 --> Model Class Initialized
INFO - 2016-11-17 22:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-17 22:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-17 22:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-17 22:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-17 22:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-17 22:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-17 22:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:13:24 --> Final output sent to browser
DEBUG - 2016-11-17 22:13:25 --> Total execution time: 0.5510
INFO - 2016-11-17 22:13:29 --> Config Class Initialized
INFO - 2016-11-17 22:13:29 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:13:29 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:13:29 --> Utf8 Class Initialized
INFO - 2016-11-17 22:13:29 --> URI Class Initialized
INFO - 2016-11-17 22:13:29 --> Router Class Initialized
INFO - 2016-11-17 22:13:29 --> Output Class Initialized
INFO - 2016-11-17 22:13:29 --> Security Class Initialized
DEBUG - 2016-11-17 22:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:13:29 --> Input Class Initialized
INFO - 2016-11-17 22:13:29 --> Language Class Initialized
INFO - 2016-11-17 22:13:29 --> Loader Class Initialized
INFO - 2016-11-17 22:13:29 --> Helper loaded: url_helper
INFO - 2016-11-17 22:13:29 --> Helper loaded: form_helper
INFO - 2016-11-17 22:13:29 --> Database Driver Class Initialized
INFO - 2016-11-17 22:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:13:29 --> Controller Class Initialized
INFO - 2016-11-17 22:13:29 --> Model Class Initialized
INFO - 2016-11-17 22:14:06 --> Config Class Initialized
INFO - 2016-11-17 22:14:06 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:14:06 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:14:06 --> Utf8 Class Initialized
INFO - 2016-11-17 22:14:06 --> URI Class Initialized
INFO - 2016-11-17 22:14:06 --> Router Class Initialized
INFO - 2016-11-17 22:14:06 --> Output Class Initialized
INFO - 2016-11-17 22:14:06 --> Security Class Initialized
DEBUG - 2016-11-17 22:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:14:06 --> Input Class Initialized
INFO - 2016-11-17 22:14:06 --> Language Class Initialized
INFO - 2016-11-17 22:14:06 --> Loader Class Initialized
INFO - 2016-11-17 22:14:06 --> Helper loaded: url_helper
INFO - 2016-11-17 22:14:06 --> Helper loaded: form_helper
INFO - 2016-11-17 22:14:06 --> Database Driver Class Initialized
INFO - 2016-11-17 22:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:14:06 --> Controller Class Initialized
INFO - 2016-11-17 22:14:06 --> Model Class Initialized
INFO - 2016-11-17 22:14:06 --> Model Class Initialized
INFO - 2016-11-17 22:14:06 --> Model Class Initialized
INFO - 2016-11-17 22:14:06 --> Model Class Initialized
DEBUG - 2016-11-17 22:14:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-17 22:14:07 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-17 22:14:07 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-17 22:14:07 --> Config Class Initialized
INFO - 2016-11-17 22:14:07 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:14:07 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:14:07 --> Utf8 Class Initialized
INFO - 2016-11-17 22:14:07 --> URI Class Initialized
DEBUG - 2016-11-17 22:14:07 --> No URI present. Default controller set.
INFO - 2016-11-17 22:14:07 --> Router Class Initialized
INFO - 2016-11-17 22:14:07 --> Output Class Initialized
INFO - 2016-11-17 22:14:07 --> Security Class Initialized
DEBUG - 2016-11-17 22:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:14:07 --> Input Class Initialized
INFO - 2016-11-17 22:14:07 --> Language Class Initialized
INFO - 2016-11-17 22:14:07 --> Loader Class Initialized
INFO - 2016-11-17 22:14:07 --> Helper loaded: url_helper
INFO - 2016-11-17 22:14:07 --> Helper loaded: form_helper
INFO - 2016-11-17 22:14:07 --> Database Driver Class Initialized
INFO - 2016-11-17 22:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:14:07 --> Controller Class Initialized
INFO - 2016-11-17 22:14:07 --> Model Class Initialized
INFO - 2016-11-17 22:14:07 --> Model Class Initialized
INFO - 2016-11-17 22:14:07 --> Model Class Initialized
INFO - 2016-11-17 22:14:07 --> Model Class Initialized
INFO - 2016-11-17 22:14:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:14:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-17 22:14:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:14:07 --> Final output sent to browser
DEBUG - 2016-11-17 22:14:07 --> Total execution time: 0.4179
INFO - 2016-11-17 22:14:17 --> Config Class Initialized
INFO - 2016-11-17 22:14:17 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:14:17 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:14:17 --> Utf8 Class Initialized
INFO - 2016-11-17 22:14:17 --> URI Class Initialized
INFO - 2016-11-17 22:14:17 --> Router Class Initialized
INFO - 2016-11-17 22:14:17 --> Output Class Initialized
INFO - 2016-11-17 22:14:18 --> Security Class Initialized
DEBUG - 2016-11-17 22:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:14:18 --> Input Class Initialized
INFO - 2016-11-17 22:14:18 --> Language Class Initialized
INFO - 2016-11-17 22:14:18 --> Loader Class Initialized
INFO - 2016-11-17 22:14:19 --> Helper loaded: url_helper
INFO - 2016-11-17 22:14:19 --> Helper loaded: form_helper
INFO - 2016-11-17 22:14:19 --> Database Driver Class Initialized
INFO - 2016-11-17 22:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:14:19 --> Controller Class Initialized
INFO - 2016-11-17 22:14:19 --> Model Class Initialized
INFO - 2016-11-17 22:14:19 --> Model Class Initialized
INFO - 2016-11-17 22:14:19 --> Model Class Initialized
INFO - 2016-11-17 22:14:19 --> Model Class Initialized
DEBUG - 2016-11-17 22:14:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-17 22:14:19 --> Model Class Initialized
INFO - 2016-11-17 22:14:19 --> Final output sent to browser
DEBUG - 2016-11-17 22:14:19 --> Total execution time: 3.2637
INFO - 2016-11-17 22:14:20 --> Config Class Initialized
INFO - 2016-11-17 22:14:20 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:14:20 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:14:20 --> Utf8 Class Initialized
INFO - 2016-11-17 22:14:20 --> URI Class Initialized
DEBUG - 2016-11-17 22:14:20 --> No URI present. Default controller set.
INFO - 2016-11-17 22:14:20 --> Router Class Initialized
INFO - 2016-11-17 22:14:20 --> Output Class Initialized
INFO - 2016-11-17 22:14:20 --> Security Class Initialized
DEBUG - 2016-11-17 22:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:14:20 --> Input Class Initialized
INFO - 2016-11-17 22:14:20 --> Language Class Initialized
INFO - 2016-11-17 22:14:20 --> Loader Class Initialized
INFO - 2016-11-17 22:14:20 --> Helper loaded: url_helper
INFO - 2016-11-17 22:14:20 --> Helper loaded: form_helper
INFO - 2016-11-17 22:14:20 --> Database Driver Class Initialized
INFO - 2016-11-17 22:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:14:20 --> Controller Class Initialized
INFO - 2016-11-17 22:14:20 --> Model Class Initialized
INFO - 2016-11-17 22:14:20 --> Model Class Initialized
INFO - 2016-11-17 22:14:20 --> Model Class Initialized
INFO - 2016-11-17 22:14:20 --> Model Class Initialized
INFO - 2016-11-17 22:14:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:14:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:14:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:14:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 22:14:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 22:14:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 22:14:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 22:14:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 22:14:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:14:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 22:14:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:14:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:14:20 --> Final output sent to browser
DEBUG - 2016-11-17 22:14:20 --> Total execution time: 0.8617
INFO - 2016-11-17 22:14:27 --> Config Class Initialized
INFO - 2016-11-17 22:14:27 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:14:27 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:14:27 --> Utf8 Class Initialized
INFO - 2016-11-17 22:14:27 --> URI Class Initialized
INFO - 2016-11-17 22:14:27 --> Router Class Initialized
INFO - 2016-11-17 22:14:27 --> Output Class Initialized
INFO - 2016-11-17 22:14:27 --> Security Class Initialized
DEBUG - 2016-11-17 22:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:14:27 --> Input Class Initialized
INFO - 2016-11-17 22:14:27 --> Language Class Initialized
INFO - 2016-11-17 22:14:28 --> Loader Class Initialized
INFO - 2016-11-17 22:14:28 --> Helper loaded: url_helper
INFO - 2016-11-17 22:14:28 --> Helper loaded: form_helper
INFO - 2016-11-17 22:14:28 --> Database Driver Class Initialized
INFO - 2016-11-17 22:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:14:28 --> Controller Class Initialized
INFO - 2016-11-17 22:14:28 --> Model Class Initialized
INFO - 2016-11-17 22:14:28 --> Config Class Initialized
INFO - 2016-11-17 22:14:28 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:14:28 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:14:28 --> Utf8 Class Initialized
INFO - 2016-11-17 22:14:28 --> URI Class Initialized
INFO - 2016-11-17 22:14:28 --> Router Class Initialized
INFO - 2016-11-17 22:14:28 --> Output Class Initialized
INFO - 2016-11-17 22:14:28 --> Security Class Initialized
DEBUG - 2016-11-17 22:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:14:28 --> Input Class Initialized
INFO - 2016-11-17 22:14:28 --> Config Class Initialized
INFO - 2016-11-17 22:14:28 --> Language Class Initialized
INFO - 2016-11-17 22:14:28 --> Hooks Class Initialized
INFO - 2016-11-17 22:14:28 --> Loader Class Initialized
DEBUG - 2016-11-17 22:14:28 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:14:28 --> Helper loaded: url_helper
INFO - 2016-11-17 22:14:28 --> Utf8 Class Initialized
INFO - 2016-11-17 22:14:28 --> Helper loaded: form_helper
INFO - 2016-11-17 22:14:28 --> URI Class Initialized
INFO - 2016-11-17 22:14:28 --> Database Driver Class Initialized
INFO - 2016-11-17 22:14:28 --> Router Class Initialized
INFO - 2016-11-17 22:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:14:28 --> Config Class Initialized
INFO - 2016-11-17 22:14:28 --> Output Class Initialized
INFO - 2016-11-17 22:14:28 --> Controller Class Initialized
INFO - 2016-11-17 22:14:28 --> Hooks Class Initialized
INFO - 2016-11-17 22:14:28 --> Model Class Initialized
INFO - 2016-11-17 22:14:28 --> Security Class Initialized
DEBUG - 2016-11-17 22:14:28 --> UTF-8 Support Enabled
DEBUG - 2016-11-17 22:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:14:28 --> Utf8 Class Initialized
INFO - 2016-11-17 22:14:28 --> Input Class Initialized
INFO - 2016-11-17 22:14:28 --> URI Class Initialized
INFO - 2016-11-17 22:14:28 --> Language Class Initialized
INFO - 2016-11-17 22:14:28 --> Router Class Initialized
INFO - 2016-11-17 22:14:28 --> Config Class Initialized
INFO - 2016-11-17 22:14:28 --> Loader Class Initialized
INFO - 2016-11-17 22:14:28 --> Output Class Initialized
INFO - 2016-11-17 22:14:28 --> Hooks Class Initialized
INFO - 2016-11-17 22:14:28 --> Helper loaded: url_helper
DEBUG - 2016-11-17 22:14:28 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:14:28 --> Security Class Initialized
INFO - 2016-11-17 22:14:29 --> Utf8 Class Initialized
INFO - 2016-11-17 22:14:29 --> Helper loaded: form_helper
DEBUG - 2016-11-17 22:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:14:29 --> Database Driver Class Initialized
INFO - 2016-11-17 22:14:29 --> URI Class Initialized
INFO - 2016-11-17 22:14:29 --> Input Class Initialized
INFO - 2016-11-17 22:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:14:29 --> Router Class Initialized
INFO - 2016-11-17 22:14:29 --> Config Class Initialized
INFO - 2016-11-17 22:14:29 --> Controller Class Initialized
INFO - 2016-11-17 22:14:29 --> Language Class Initialized
INFO - 2016-11-17 22:14:29 --> Output Class Initialized
INFO - 2016-11-17 22:14:29 --> Hooks Class Initialized
INFO - 2016-11-17 22:14:29 --> Model Class Initialized
INFO - 2016-11-17 22:14:29 --> Loader Class Initialized
INFO - 2016-11-17 22:14:29 --> Security Class Initialized
DEBUG - 2016-11-17 22:14:29 --> UTF-8 Support Enabled
DEBUG - 2016-11-17 22:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:14:29 --> Helper loaded: url_helper
INFO - 2016-11-17 22:14:29 --> Utf8 Class Initialized
INFO - 2016-11-17 22:14:29 --> Input Class Initialized
INFO - 2016-11-17 22:14:29 --> Helper loaded: form_helper
INFO - 2016-11-17 22:14:29 --> URI Class Initialized
INFO - 2016-11-17 22:14:29 --> Language Class Initialized
INFO - 2016-11-17 22:14:29 --> Config Class Initialized
INFO - 2016-11-17 22:14:29 --> Database Driver Class Initialized
INFO - 2016-11-17 22:14:29 --> Router Class Initialized
INFO - 2016-11-17 22:14:29 --> Hooks Class Initialized
INFO - 2016-11-17 22:14:29 --> Loader Class Initialized
INFO - 2016-11-17 22:14:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-17 22:14:29 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:14:29 --> Helper loaded: url_helper
INFO - 2016-11-17 22:14:29 --> Controller Class Initialized
INFO - 2016-11-17 22:14:29 --> Output Class Initialized
INFO - 2016-11-17 22:14:29 --> Utf8 Class Initialized
INFO - 2016-11-17 22:14:29 --> Helper loaded: form_helper
INFO - 2016-11-17 22:14:29 --> Model Class Initialized
INFO - 2016-11-17 22:14:29 --> Security Class Initialized
INFO - 2016-11-17 22:14:29 --> URI Class Initialized
INFO - 2016-11-17 22:14:29 --> Database Driver Class Initialized
DEBUG - 2016-11-17 22:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:14:29 --> Router Class Initialized
INFO - 2016-11-17 22:14:29 --> Input Class Initialized
INFO - 2016-11-17 22:14:29 --> Config Class Initialized
INFO - 2016-11-17 22:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:14:29 --> Output Class Initialized
INFO - 2016-11-17 22:14:29 --> Hooks Class Initialized
INFO - 2016-11-17 22:14:29 --> Language Class Initialized
INFO - 2016-11-17 22:14:29 --> Controller Class Initialized
INFO - 2016-11-17 22:14:29 --> Model Class Initialized
INFO - 2016-11-17 22:14:29 --> Security Class Initialized
DEBUG - 2016-11-17 22:14:29 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:14:29 --> Loader Class Initialized
INFO - 2016-11-17 22:14:29 --> Utf8 Class Initialized
DEBUG - 2016-11-17 22:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:14:29 --> Helper loaded: url_helper
INFO - 2016-11-17 22:14:29 --> URI Class Initialized
INFO - 2016-11-17 22:14:29 --> Input Class Initialized
INFO - 2016-11-17 22:14:29 --> Helper loaded: form_helper
INFO - 2016-11-17 22:14:29 --> Language Class Initialized
INFO - 2016-11-17 22:14:29 --> Router Class Initialized
INFO - 2016-11-17 22:14:29 --> Database Driver Class Initialized
INFO - 2016-11-17 22:14:29 --> Loader Class Initialized
INFO - 2016-11-17 22:14:29 --> Output Class Initialized
INFO - 2016-11-17 22:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:14:29 --> Security Class Initialized
INFO - 2016-11-17 22:14:29 --> Helper loaded: url_helper
INFO - 2016-11-17 22:14:29 --> Controller Class Initialized
INFO - 2016-11-17 22:14:29 --> Model Class Initialized
INFO - 2016-11-17 22:14:29 --> Helper loaded: form_helper
DEBUG - 2016-11-17 22:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:14:29 --> Input Class Initialized
INFO - 2016-11-17 22:14:29 --> Database Driver Class Initialized
INFO - 2016-11-17 22:14:29 --> Language Class Initialized
INFO - 2016-11-17 22:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:14:29 --> Loader Class Initialized
INFO - 2016-11-17 22:14:29 --> Controller Class Initialized
INFO - 2016-11-17 22:14:29 --> Config Class Initialized
INFO - 2016-11-17 22:14:29 --> Model Class Initialized
INFO - 2016-11-17 22:14:29 --> Helper loaded: url_helper
INFO - 2016-11-17 22:14:29 --> Hooks Class Initialized
INFO - 2016-11-17 22:14:29 --> Helper loaded: form_helper
DEBUG - 2016-11-17 22:14:29 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:14:29 --> Database Driver Class Initialized
INFO - 2016-11-17 22:14:29 --> Utf8 Class Initialized
INFO - 2016-11-17 22:14:29 --> URI Class Initialized
INFO - 2016-11-17 22:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:14:29 --> Router Class Initialized
INFO - 2016-11-17 22:14:29 --> Controller Class Initialized
INFO - 2016-11-17 22:14:29 --> Model Class Initialized
INFO - 2016-11-17 22:14:29 --> Output Class Initialized
INFO - 2016-11-17 22:14:29 --> Security Class Initialized
INFO - 2016-11-17 22:14:29 --> Config Class Initialized
DEBUG - 2016-11-17 22:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:14:29 --> Hooks Class Initialized
INFO - 2016-11-17 22:14:29 --> Input Class Initialized
DEBUG - 2016-11-17 22:14:29 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:14:29 --> Language Class Initialized
INFO - 2016-11-17 22:14:29 --> Utf8 Class Initialized
INFO - 2016-11-17 22:14:29 --> URI Class Initialized
INFO - 2016-11-17 22:14:29 --> Loader Class Initialized
INFO - 2016-11-17 22:14:29 --> Router Class Initialized
INFO - 2016-11-17 22:14:29 --> Helper loaded: url_helper
INFO - 2016-11-17 22:14:29 --> Output Class Initialized
INFO - 2016-11-17 22:14:29 --> Helper loaded: form_helper
INFO - 2016-11-17 22:14:29 --> Config Class Initialized
INFO - 2016-11-17 22:14:29 --> Security Class Initialized
INFO - 2016-11-17 22:14:29 --> Database Driver Class Initialized
INFO - 2016-11-17 22:14:29 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-17 22:14:30 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:14:30 --> Input Class Initialized
INFO - 2016-11-17 22:14:30 --> Utf8 Class Initialized
INFO - 2016-11-17 22:14:30 --> Controller Class Initialized
INFO - 2016-11-17 22:14:30 --> Language Class Initialized
INFO - 2016-11-17 22:14:30 --> Model Class Initialized
INFO - 2016-11-17 22:14:30 --> URI Class Initialized
INFO - 2016-11-17 22:14:30 --> Loader Class Initialized
INFO - 2016-11-17 22:14:30 --> Router Class Initialized
INFO - 2016-11-17 22:14:30 --> Helper loaded: url_helper
INFO - 2016-11-17 22:14:30 --> Output Class Initialized
INFO - 2016-11-17 22:14:30 --> Helper loaded: form_helper
INFO - 2016-11-17 22:14:30 --> Config Class Initialized
INFO - 2016-11-17 22:14:30 --> Security Class Initialized
INFO - 2016-11-17 22:14:30 --> Database Driver Class Initialized
INFO - 2016-11-17 22:14:30 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-17 22:14:30 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:14:30 --> Input Class Initialized
INFO - 2016-11-17 22:14:30 --> Controller Class Initialized
INFO - 2016-11-17 22:14:30 --> Utf8 Class Initialized
INFO - 2016-11-17 22:14:30 --> Language Class Initialized
INFO - 2016-11-17 22:14:30 --> Model Class Initialized
INFO - 2016-11-17 22:14:30 --> URI Class Initialized
INFO - 2016-11-17 22:14:30 --> Loader Class Initialized
INFO - 2016-11-17 22:14:30 --> Router Class Initialized
INFO - 2016-11-17 22:14:30 --> Helper loaded: url_helper
INFO - 2016-11-17 22:14:30 --> Output Class Initialized
INFO - 2016-11-17 22:14:30 --> Helper loaded: form_helper
INFO - 2016-11-17 22:14:30 --> Security Class Initialized
INFO - 2016-11-17 22:14:30 --> Database Driver Class Initialized
DEBUG - 2016-11-17 22:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:14:30 --> Config Class Initialized
INFO - 2016-11-17 22:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:14:30 --> Input Class Initialized
INFO - 2016-11-17 22:14:30 --> Hooks Class Initialized
INFO - 2016-11-17 22:14:30 --> Controller Class Initialized
INFO - 2016-11-17 22:14:30 --> Language Class Initialized
INFO - 2016-11-17 22:14:30 --> Model Class Initialized
DEBUG - 2016-11-17 22:14:30 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:14:30 --> Loader Class Initialized
INFO - 2016-11-17 22:14:30 --> Utf8 Class Initialized
INFO - 2016-11-17 22:14:30 --> URI Class Initialized
INFO - 2016-11-17 22:14:30 --> Helper loaded: url_helper
INFO - 2016-11-17 22:14:30 --> Router Class Initialized
INFO - 2016-11-17 22:14:30 --> Helper loaded: form_helper
INFO - 2016-11-17 22:14:30 --> Output Class Initialized
INFO - 2016-11-17 22:14:30 --> Database Driver Class Initialized
INFO - 2016-11-17 22:14:30 --> Security Class Initialized
INFO - 2016-11-17 22:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:14:30 --> Config Class Initialized
INFO - 2016-11-17 22:14:30 --> Hooks Class Initialized
INFO - 2016-11-17 22:14:30 --> Controller Class Initialized
DEBUG - 2016-11-17 22:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:14:30 --> Input Class Initialized
INFO - 2016-11-17 22:14:30 --> Model Class Initialized
DEBUG - 2016-11-17 22:14:30 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:14:30 --> Utf8 Class Initialized
INFO - 2016-11-17 22:14:30 --> Language Class Initialized
INFO - 2016-11-17 22:14:30 --> URI Class Initialized
INFO - 2016-11-17 22:14:30 --> Loader Class Initialized
INFO - 2016-11-17 22:14:30 --> Router Class Initialized
INFO - 2016-11-17 22:14:30 --> Helper loaded: url_helper
INFO - 2016-11-17 22:14:30 --> Output Class Initialized
INFO - 2016-11-17 22:14:30 --> Helper loaded: form_helper
INFO - 2016-11-17 22:14:30 --> Security Class Initialized
INFO - 2016-11-17 22:14:30 --> Database Driver Class Initialized
DEBUG - 2016-11-17 22:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:14:30 --> Input Class Initialized
INFO - 2016-11-17 22:14:30 --> Controller Class Initialized
INFO - 2016-11-17 22:14:30 --> Language Class Initialized
INFO - 2016-11-17 22:14:30 --> Model Class Initialized
INFO - 2016-11-17 22:14:30 --> Loader Class Initialized
INFO - 2016-11-17 22:14:30 --> Helper loaded: url_helper
INFO - 2016-11-17 22:14:30 --> Helper loaded: form_helper
INFO - 2016-11-17 22:14:30 --> Database Driver Class Initialized
INFO - 2016-11-17 22:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:14:30 --> Controller Class Initialized
INFO - 2016-11-17 22:14:30 --> Model Class Initialized
INFO - 2016-11-17 22:15:41 --> Config Class Initialized
INFO - 2016-11-17 22:15:41 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:15:41 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:15:41 --> Utf8 Class Initialized
INFO - 2016-11-17 22:15:41 --> URI Class Initialized
DEBUG - 2016-11-17 22:15:41 --> No URI present. Default controller set.
INFO - 2016-11-17 22:15:41 --> Router Class Initialized
INFO - 2016-11-17 22:15:41 --> Output Class Initialized
INFO - 2016-11-17 22:15:41 --> Security Class Initialized
DEBUG - 2016-11-17 22:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:15:42 --> Input Class Initialized
INFO - 2016-11-17 22:15:42 --> Language Class Initialized
INFO - 2016-11-17 22:15:42 --> Loader Class Initialized
INFO - 2016-11-17 22:15:42 --> Helper loaded: url_helper
INFO - 2016-11-17 22:15:42 --> Helper loaded: form_helper
INFO - 2016-11-17 22:15:42 --> Database Driver Class Initialized
INFO - 2016-11-17 22:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:15:42 --> Controller Class Initialized
INFO - 2016-11-17 22:15:42 --> Model Class Initialized
INFO - 2016-11-17 22:15:42 --> Model Class Initialized
INFO - 2016-11-17 22:15:42 --> Model Class Initialized
INFO - 2016-11-17 22:15:42 --> Model Class Initialized
INFO - 2016-11-17 22:15:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:15:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:15:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:15:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 22:15:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 22:15:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 22:15:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 22:15:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 22:15:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:15:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 22:15:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:15:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:15:42 --> Final output sent to browser
DEBUG - 2016-11-17 22:15:42 --> Total execution time: 0.5868
INFO - 2016-11-17 22:15:47 --> Config Class Initialized
INFO - 2016-11-17 22:15:47 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:15:47 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:15:47 --> Utf8 Class Initialized
INFO - 2016-11-17 22:15:47 --> URI Class Initialized
INFO - 2016-11-17 22:15:47 --> Router Class Initialized
INFO - 2016-11-17 22:15:47 --> Output Class Initialized
INFO - 2016-11-17 22:15:47 --> Security Class Initialized
DEBUG - 2016-11-17 22:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:15:47 --> Input Class Initialized
INFO - 2016-11-17 22:15:47 --> Language Class Initialized
INFO - 2016-11-17 22:15:47 --> Loader Class Initialized
INFO - 2016-11-17 22:15:47 --> Helper loaded: url_helper
INFO - 2016-11-17 22:15:47 --> Helper loaded: form_helper
INFO - 2016-11-17 22:15:47 --> Database Driver Class Initialized
INFO - 2016-11-17 22:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:15:47 --> Controller Class Initialized
INFO - 2016-11-17 22:15:47 --> Model Class Initialized
INFO - 2016-11-17 22:15:48 --> Config Class Initialized
INFO - 2016-11-17 22:15:48 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:15:48 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:15:48 --> Utf8 Class Initialized
INFO - 2016-11-17 22:15:48 --> URI Class Initialized
INFO - 2016-11-17 22:15:48 --> Router Class Initialized
INFO - 2016-11-17 22:15:48 --> Output Class Initialized
INFO - 2016-11-17 22:15:48 --> Security Class Initialized
DEBUG - 2016-11-17 22:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:15:48 --> Input Class Initialized
INFO - 2016-11-17 22:15:48 --> Language Class Initialized
INFO - 2016-11-17 22:15:48 --> Config Class Initialized
INFO - 2016-11-17 22:15:48 --> Loader Class Initialized
INFO - 2016-11-17 22:15:48 --> Hooks Class Initialized
INFO - 2016-11-17 22:15:48 --> Helper loaded: url_helper
DEBUG - 2016-11-17 22:15:48 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:15:48 --> Utf8 Class Initialized
INFO - 2016-11-17 22:15:48 --> Helper loaded: form_helper
INFO - 2016-11-17 22:15:48 --> URI Class Initialized
INFO - 2016-11-17 22:15:48 --> Database Driver Class Initialized
INFO - 2016-11-17 22:15:48 --> Router Class Initialized
INFO - 2016-11-17 22:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:15:48 --> Output Class Initialized
INFO - 2016-11-17 22:15:48 --> Controller Class Initialized
INFO - 2016-11-17 22:15:48 --> Model Class Initialized
INFO - 2016-11-17 22:15:48 --> Security Class Initialized
INFO - 2016-11-17 22:15:48 --> Config Class Initialized
INFO - 2016-11-17 22:15:48 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-17 22:15:48 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:15:48 --> Input Class Initialized
INFO - 2016-11-17 22:15:48 --> Utf8 Class Initialized
INFO - 2016-11-17 22:15:48 --> Language Class Initialized
INFO - 2016-11-17 22:15:48 --> URI Class Initialized
INFO - 2016-11-17 22:15:48 --> Loader Class Initialized
INFO - 2016-11-17 22:15:48 --> Router Class Initialized
INFO - 2016-11-17 22:15:48 --> Helper loaded: url_helper
INFO - 2016-11-17 22:15:48 --> Config Class Initialized
INFO - 2016-11-17 22:15:48 --> Helper loaded: form_helper
INFO - 2016-11-17 22:15:48 --> Output Class Initialized
INFO - 2016-11-17 22:15:48 --> Hooks Class Initialized
INFO - 2016-11-17 22:15:48 --> Database Driver Class Initialized
DEBUG - 2016-11-17 22:15:48 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:15:48 --> Security Class Initialized
INFO - 2016-11-17 22:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:15:48 --> Utf8 Class Initialized
INFO - 2016-11-17 22:15:48 --> Controller Class Initialized
DEBUG - 2016-11-17 22:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:15:48 --> URI Class Initialized
INFO - 2016-11-17 22:15:48 --> Input Class Initialized
INFO - 2016-11-17 22:15:48 --> Model Class Initialized
INFO - 2016-11-17 22:15:48 --> Router Class Initialized
INFO - 2016-11-17 22:15:48 --> Language Class Initialized
INFO - 2016-11-17 22:15:48 --> Output Class Initialized
INFO - 2016-11-17 22:15:48 --> Loader Class Initialized
INFO - 2016-11-17 22:15:48 --> Security Class Initialized
INFO - 2016-11-17 22:15:48 --> Config Class Initialized
INFO - 2016-11-17 22:15:48 --> Helper loaded: url_helper
INFO - 2016-11-17 22:15:48 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-17 22:15:48 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:15:48 --> Helper loaded: form_helper
INFO - 2016-11-17 22:15:48 --> Input Class Initialized
INFO - 2016-11-17 22:15:48 --> Utf8 Class Initialized
INFO - 2016-11-17 22:15:48 --> Language Class Initialized
INFO - 2016-11-17 22:15:48 --> Database Driver Class Initialized
INFO - 2016-11-17 22:15:48 --> URI Class Initialized
INFO - 2016-11-17 22:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:15:48 --> Loader Class Initialized
INFO - 2016-11-17 22:15:48 --> Router Class Initialized
INFO - 2016-11-17 22:15:48 --> Helper loaded: url_helper
INFO - 2016-11-17 22:15:48 --> Controller Class Initialized
INFO - 2016-11-17 22:15:48 --> Output Class Initialized
INFO - 2016-11-17 22:15:48 --> Model Class Initialized
INFO - 2016-11-17 22:15:48 --> Config Class Initialized
INFO - 2016-11-17 22:15:48 --> Helper loaded: form_helper
INFO - 2016-11-17 22:15:48 --> Security Class Initialized
INFO - 2016-11-17 22:15:48 --> Hooks Class Initialized
INFO - 2016-11-17 22:15:48 --> Database Driver Class Initialized
DEBUG - 2016-11-17 22:15:48 --> UTF-8 Support Enabled
DEBUG - 2016-11-17 22:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:15:48 --> Input Class Initialized
INFO - 2016-11-17 22:15:48 --> Utf8 Class Initialized
INFO - 2016-11-17 22:15:48 --> Controller Class Initialized
INFO - 2016-11-17 22:15:48 --> URI Class Initialized
INFO - 2016-11-17 22:15:48 --> Language Class Initialized
INFO - 2016-11-17 22:15:48 --> Model Class Initialized
INFO - 2016-11-17 22:15:48 --> Config Class Initialized
INFO - 2016-11-17 22:15:48 --> Loader Class Initialized
INFO - 2016-11-17 22:15:48 --> Router Class Initialized
INFO - 2016-11-17 22:15:49 --> Hooks Class Initialized
INFO - 2016-11-17 22:15:49 --> Helper loaded: url_helper
INFO - 2016-11-17 22:15:49 --> Output Class Initialized
DEBUG - 2016-11-17 22:15:49 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:15:49 --> Utf8 Class Initialized
INFO - 2016-11-17 22:15:49 --> Helper loaded: form_helper
INFO - 2016-11-17 22:15:49 --> Security Class Initialized
INFO - 2016-11-17 22:15:49 --> URI Class Initialized
DEBUG - 2016-11-17 22:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:15:49 --> Database Driver Class Initialized
INFO - 2016-11-17 22:15:49 --> Router Class Initialized
INFO - 2016-11-17 22:15:49 --> Input Class Initialized
INFO - 2016-11-17 22:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:15:49 --> Output Class Initialized
INFO - 2016-11-17 22:15:49 --> Language Class Initialized
INFO - 2016-11-17 22:15:49 --> Controller Class Initialized
INFO - 2016-11-17 22:15:49 --> Model Class Initialized
INFO - 2016-11-17 22:15:49 --> Loader Class Initialized
INFO - 2016-11-17 22:15:49 --> Security Class Initialized
INFO - 2016-11-17 22:15:49 --> Config Class Initialized
INFO - 2016-11-17 22:15:49 --> Helper loaded: url_helper
DEBUG - 2016-11-17 22:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:15:49 --> Hooks Class Initialized
INFO - 2016-11-17 22:15:49 --> Input Class Initialized
DEBUG - 2016-11-17 22:15:49 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:15:49 --> Helper loaded: form_helper
INFO - 2016-11-17 22:15:49 --> Language Class Initialized
INFO - 2016-11-17 22:15:49 --> Utf8 Class Initialized
INFO - 2016-11-17 22:15:49 --> Database Driver Class Initialized
INFO - 2016-11-17 22:15:49 --> Loader Class Initialized
INFO - 2016-11-17 22:15:49 --> URI Class Initialized
INFO - 2016-11-17 22:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:15:49 --> Config Class Initialized
INFO - 2016-11-17 22:15:49 --> Helper loaded: url_helper
INFO - 2016-11-17 22:15:49 --> Controller Class Initialized
INFO - 2016-11-17 22:15:49 --> Router Class Initialized
INFO - 2016-11-17 22:15:49 --> Hooks Class Initialized
INFO - 2016-11-17 22:15:49 --> Output Class Initialized
INFO - 2016-11-17 22:15:49 --> Model Class Initialized
INFO - 2016-11-17 22:15:49 --> Helper loaded: form_helper
DEBUG - 2016-11-17 22:15:49 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:15:49 --> Security Class Initialized
INFO - 2016-11-17 22:15:49 --> Database Driver Class Initialized
INFO - 2016-11-17 22:15:49 --> Utf8 Class Initialized
INFO - 2016-11-17 22:15:49 --> URI Class Initialized
DEBUG - 2016-11-17 22:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:15:49 --> Router Class Initialized
INFO - 2016-11-17 22:15:49 --> Controller Class Initialized
INFO - 2016-11-17 22:15:49 --> Input Class Initialized
INFO - 2016-11-17 22:15:49 --> Language Class Initialized
INFO - 2016-11-17 22:15:49 --> Model Class Initialized
INFO - 2016-11-17 22:15:49 --> Output Class Initialized
INFO - 2016-11-17 22:15:49 --> Loader Class Initialized
INFO - 2016-11-17 22:15:49 --> Security Class Initialized
INFO - 2016-11-17 22:15:49 --> Config Class Initialized
INFO - 2016-11-17 22:15:49 --> Hooks Class Initialized
INFO - 2016-11-17 22:15:49 --> Helper loaded: url_helper
DEBUG - 2016-11-17 22:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-17 22:15:49 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:15:49 --> Input Class Initialized
INFO - 2016-11-17 22:15:49 --> Helper loaded: form_helper
INFO - 2016-11-17 22:15:49 --> Utf8 Class Initialized
INFO - 2016-11-17 22:15:49 --> Language Class Initialized
INFO - 2016-11-17 22:15:49 --> Database Driver Class Initialized
INFO - 2016-11-17 22:15:49 --> URI Class Initialized
INFO - 2016-11-17 22:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:15:49 --> Loader Class Initialized
INFO - 2016-11-17 22:15:49 --> Router Class Initialized
INFO - 2016-11-17 22:15:49 --> Controller Class Initialized
INFO - 2016-11-17 22:15:49 --> Helper loaded: url_helper
INFO - 2016-11-17 22:15:49 --> Output Class Initialized
INFO - 2016-11-17 22:15:49 --> Model Class Initialized
INFO - 2016-11-17 22:15:49 --> Helper loaded: form_helper
INFO - 2016-11-17 22:15:49 --> Security Class Initialized
INFO - 2016-11-17 22:15:49 --> Database Driver Class Initialized
DEBUG - 2016-11-17 22:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:15:49 --> Input Class Initialized
INFO - 2016-11-17 22:15:49 --> Controller Class Initialized
INFO - 2016-11-17 22:15:49 --> Language Class Initialized
INFO - 2016-11-17 22:15:49 --> Model Class Initialized
INFO - 2016-11-17 22:15:49 --> Loader Class Initialized
INFO - 2016-11-17 22:15:49 --> Helper loaded: url_helper
INFO - 2016-11-17 22:15:49 --> Helper loaded: form_helper
INFO - 2016-11-17 22:15:49 --> Database Driver Class Initialized
INFO - 2016-11-17 22:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:15:49 --> Controller Class Initialized
INFO - 2016-11-17 22:15:49 --> Model Class Initialized
INFO - 2016-11-17 22:16:33 --> Config Class Initialized
INFO - 2016-11-17 22:16:33 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:16:33 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:16:33 --> Utf8 Class Initialized
INFO - 2016-11-17 22:16:33 --> URI Class Initialized
DEBUG - 2016-11-17 22:16:33 --> No URI present. Default controller set.
INFO - 2016-11-17 22:16:33 --> Router Class Initialized
INFO - 2016-11-17 22:16:33 --> Output Class Initialized
INFO - 2016-11-17 22:16:33 --> Security Class Initialized
DEBUG - 2016-11-17 22:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:16:33 --> Input Class Initialized
INFO - 2016-11-17 22:16:33 --> Language Class Initialized
INFO - 2016-11-17 22:16:33 --> Loader Class Initialized
INFO - 2016-11-17 22:16:33 --> Helper loaded: url_helper
INFO - 2016-11-17 22:16:33 --> Helper loaded: form_helper
INFO - 2016-11-17 22:16:33 --> Database Driver Class Initialized
INFO - 2016-11-17 22:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:16:33 --> Controller Class Initialized
INFO - 2016-11-17 22:16:33 --> Model Class Initialized
INFO - 2016-11-17 22:16:33 --> Model Class Initialized
INFO - 2016-11-17 22:16:33 --> Model Class Initialized
INFO - 2016-11-17 22:16:33 --> Model Class Initialized
INFO - 2016-11-17 22:16:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:16:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:16:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:16:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 22:16:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 22:16:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 22:16:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 22:16:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 22:16:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:16:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 22:16:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:16:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:16:33 --> Final output sent to browser
DEBUG - 2016-11-17 22:16:33 --> Total execution time: 0.5420
INFO - 2016-11-17 22:16:37 --> Config Class Initialized
INFO - 2016-11-17 22:16:37 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:16:37 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:16:37 --> Utf8 Class Initialized
INFO - 2016-11-17 22:16:37 --> URI Class Initialized
INFO - 2016-11-17 22:16:37 --> Router Class Initialized
INFO - 2016-11-17 22:16:37 --> Output Class Initialized
INFO - 2016-11-17 22:16:37 --> Security Class Initialized
DEBUG - 2016-11-17 22:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:16:37 --> Input Class Initialized
INFO - 2016-11-17 22:16:37 --> Language Class Initialized
INFO - 2016-11-17 22:16:37 --> Loader Class Initialized
INFO - 2016-11-17 22:16:37 --> Helper loaded: url_helper
INFO - 2016-11-17 22:16:37 --> Helper loaded: form_helper
INFO - 2016-11-17 22:16:37 --> Database Driver Class Initialized
INFO - 2016-11-17 22:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:16:37 --> Controller Class Initialized
INFO - 2016-11-17 22:16:37 --> Model Class Initialized
INFO - 2016-11-17 22:16:37 --> Config Class Initialized
INFO - 2016-11-17 22:16:37 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:16:37 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:16:37 --> Utf8 Class Initialized
INFO - 2016-11-17 22:16:37 --> URI Class Initialized
INFO - 2016-11-17 22:16:37 --> Router Class Initialized
INFO - 2016-11-17 22:16:37 --> Output Class Initialized
INFO - 2016-11-17 22:16:37 --> Security Class Initialized
DEBUG - 2016-11-17 22:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:16:37 --> Input Class Initialized
INFO - 2016-11-17 22:16:37 --> Language Class Initialized
INFO - 2016-11-17 22:16:37 --> Config Class Initialized
INFO - 2016-11-17 22:16:37 --> Loader Class Initialized
INFO - 2016-11-17 22:16:37 --> Hooks Class Initialized
INFO - 2016-11-17 22:16:37 --> Helper loaded: url_helper
DEBUG - 2016-11-17 22:16:37 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:16:37 --> Utf8 Class Initialized
INFO - 2016-11-17 22:16:37 --> Helper loaded: form_helper
INFO - 2016-11-17 22:16:37 --> URI Class Initialized
INFO - 2016-11-17 22:16:37 --> Database Driver Class Initialized
INFO - 2016-11-17 22:16:37 --> Router Class Initialized
INFO - 2016-11-17 22:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:16:37 --> Output Class Initialized
INFO - 2016-11-17 22:16:37 --> Controller Class Initialized
INFO - 2016-11-17 22:16:37 --> Config Class Initialized
INFO - 2016-11-17 22:16:37 --> Model Class Initialized
INFO - 2016-11-17 22:16:37 --> Security Class Initialized
INFO - 2016-11-17 22:16:37 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-17 22:16:37 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:16:37 --> Input Class Initialized
INFO - 2016-11-17 22:16:38 --> Utf8 Class Initialized
INFO - 2016-11-17 22:16:38 --> Language Class Initialized
INFO - 2016-11-17 22:16:38 --> URI Class Initialized
INFO - 2016-11-17 22:16:38 --> Loader Class Initialized
INFO - 2016-11-17 22:16:38 --> Router Class Initialized
INFO - 2016-11-17 22:16:38 --> Helper loaded: url_helper
INFO - 2016-11-17 22:16:38 --> Config Class Initialized
INFO - 2016-11-17 22:16:38 --> Hooks Class Initialized
INFO - 2016-11-17 22:16:38 --> Output Class Initialized
INFO - 2016-11-17 22:16:38 --> Helper loaded: form_helper
DEBUG - 2016-11-17 22:16:38 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:16:38 --> Security Class Initialized
INFO - 2016-11-17 22:16:38 --> Database Driver Class Initialized
INFO - 2016-11-17 22:16:38 --> Utf8 Class Initialized
DEBUG - 2016-11-17 22:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:16:38 --> URI Class Initialized
INFO - 2016-11-17 22:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:16:38 --> Input Class Initialized
INFO - 2016-11-17 22:16:38 --> Controller Class Initialized
INFO - 2016-11-17 22:16:38 --> Router Class Initialized
INFO - 2016-11-17 22:16:38 --> Language Class Initialized
INFO - 2016-11-17 22:16:38 --> Model Class Initialized
INFO - 2016-11-17 22:16:38 --> Config Class Initialized
INFO - 2016-11-17 22:16:38 --> Loader Class Initialized
INFO - 2016-11-17 22:16:38 --> Output Class Initialized
INFO - 2016-11-17 22:16:38 --> Hooks Class Initialized
INFO - 2016-11-17 22:16:38 --> Security Class Initialized
INFO - 2016-11-17 22:16:38 --> Helper loaded: url_helper
DEBUG - 2016-11-17 22:16:38 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:16:38 --> Helper loaded: form_helper
DEBUG - 2016-11-17 22:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:16:38 --> Utf8 Class Initialized
INFO - 2016-11-17 22:16:38 --> Input Class Initialized
INFO - 2016-11-17 22:16:38 --> Database Driver Class Initialized
INFO - 2016-11-17 22:16:38 --> URI Class Initialized
INFO - 2016-11-17 22:16:38 --> Language Class Initialized
INFO - 2016-11-17 22:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:16:38 --> Router Class Initialized
INFO - 2016-11-17 22:16:38 --> Controller Class Initialized
INFO - 2016-11-17 22:16:38 --> Loader Class Initialized
INFO - 2016-11-17 22:16:38 --> Config Class Initialized
INFO - 2016-11-17 22:16:38 --> Output Class Initialized
INFO - 2016-11-17 22:16:38 --> Model Class Initialized
INFO - 2016-11-17 22:16:38 --> Hooks Class Initialized
INFO - 2016-11-17 22:16:38 --> Helper loaded: url_helper
INFO - 2016-11-17 22:16:38 --> Helper loaded: form_helper
INFO - 2016-11-17 22:16:38 --> Security Class Initialized
DEBUG - 2016-11-17 22:16:38 --> UTF-8 Support Enabled
DEBUG - 2016-11-17 22:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:16:38 --> Utf8 Class Initialized
INFO - 2016-11-17 22:16:38 --> Database Driver Class Initialized
INFO - 2016-11-17 22:16:38 --> Input Class Initialized
INFO - 2016-11-17 22:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:16:38 --> URI Class Initialized
INFO - 2016-11-17 22:16:38 --> Controller Class Initialized
INFO - 2016-11-17 22:16:38 --> Router Class Initialized
INFO - 2016-11-17 22:16:38 --> Config Class Initialized
INFO - 2016-11-17 22:16:38 --> Language Class Initialized
INFO - 2016-11-17 22:16:38 --> Model Class Initialized
INFO - 2016-11-17 22:16:38 --> Hooks Class Initialized
INFO - 2016-11-17 22:16:38 --> Output Class Initialized
INFO - 2016-11-17 22:16:38 --> Loader Class Initialized
DEBUG - 2016-11-17 22:16:38 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:16:38 --> Security Class Initialized
INFO - 2016-11-17 22:16:38 --> Helper loaded: url_helper
INFO - 2016-11-17 22:16:38 --> Utf8 Class Initialized
INFO - 2016-11-17 22:16:38 --> URI Class Initialized
INFO - 2016-11-17 22:16:38 --> Helper loaded: form_helper
DEBUG - 2016-11-17 22:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:16:38 --> Router Class Initialized
INFO - 2016-11-17 22:16:38 --> Input Class Initialized
INFO - 2016-11-17 22:16:38 --> Database Driver Class Initialized
INFO - 2016-11-17 22:16:38 --> Language Class Initialized
INFO - 2016-11-17 22:16:38 --> Output Class Initialized
INFO - 2016-11-17 22:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:16:38 --> Loader Class Initialized
INFO - 2016-11-17 22:16:38 --> Security Class Initialized
INFO - 2016-11-17 22:16:38 --> Controller Class Initialized
INFO - 2016-11-17 22:16:38 --> Config Class Initialized
DEBUG - 2016-11-17 22:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:16:38 --> Model Class Initialized
INFO - 2016-11-17 22:16:38 --> Helper loaded: url_helper
INFO - 2016-11-17 22:16:38 --> Input Class Initialized
INFO - 2016-11-17 22:16:38 --> Hooks Class Initialized
INFO - 2016-11-17 22:16:38 --> Language Class Initialized
INFO - 2016-11-17 22:16:38 --> Helper loaded: form_helper
DEBUG - 2016-11-17 22:16:38 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:16:38 --> Loader Class Initialized
INFO - 2016-11-17 22:16:38 --> Utf8 Class Initialized
INFO - 2016-11-17 22:16:38 --> Database Driver Class Initialized
INFO - 2016-11-17 22:16:38 --> URI Class Initialized
INFO - 2016-11-17 22:16:38 --> Helper loaded: url_helper
INFO - 2016-11-17 22:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:16:38 --> Helper loaded: form_helper
INFO - 2016-11-17 22:16:38 --> Router Class Initialized
INFO - 2016-11-17 22:16:38 --> Controller Class Initialized
INFO - 2016-11-17 22:16:38 --> Model Class Initialized
INFO - 2016-11-17 22:16:38 --> Output Class Initialized
INFO - 2016-11-17 22:16:38 --> Database Driver Class Initialized
INFO - 2016-11-17 22:16:38 --> Security Class Initialized
INFO - 2016-11-17 22:16:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-17 22:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:16:38 --> Controller Class Initialized
INFO - 2016-11-17 22:16:38 --> Input Class Initialized
INFO - 2016-11-17 22:16:38 --> Model Class Initialized
INFO - 2016-11-17 22:16:38 --> Language Class Initialized
INFO - 2016-11-17 22:16:38 --> Loader Class Initialized
INFO - 2016-11-17 22:16:38 --> Helper loaded: url_helper
INFO - 2016-11-17 22:16:38 --> Helper loaded: form_helper
INFO - 2016-11-17 22:16:38 --> Database Driver Class Initialized
INFO - 2016-11-17 22:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:16:39 --> Controller Class Initialized
INFO - 2016-11-17 22:16:39 --> Model Class Initialized
INFO - 2016-11-17 22:16:39 --> Config Class Initialized
INFO - 2016-11-17 22:16:39 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:16:39 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:16:39 --> Utf8 Class Initialized
INFO - 2016-11-17 22:16:39 --> URI Class Initialized
INFO - 2016-11-17 22:16:39 --> Router Class Initialized
INFO - 2016-11-17 22:16:39 --> Output Class Initialized
INFO - 2016-11-17 22:16:39 --> Security Class Initialized
DEBUG - 2016-11-17 22:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:16:39 --> Input Class Initialized
INFO - 2016-11-17 22:16:39 --> Language Class Initialized
INFO - 2016-11-17 22:16:39 --> Config Class Initialized
INFO - 2016-11-17 22:16:39 --> Hooks Class Initialized
INFO - 2016-11-17 22:16:39 --> Loader Class Initialized
INFO - 2016-11-17 22:16:39 --> Helper loaded: url_helper
DEBUG - 2016-11-17 22:16:39 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:16:39 --> Utf8 Class Initialized
INFO - 2016-11-17 22:16:39 --> Helper loaded: form_helper
INFO - 2016-11-17 22:16:39 --> URI Class Initialized
INFO - 2016-11-17 22:16:39 --> Database Driver Class Initialized
INFO - 2016-11-17 22:16:39 --> Router Class Initialized
INFO - 2016-11-17 22:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:16:39 --> Output Class Initialized
INFO - 2016-11-17 22:16:39 --> Controller Class Initialized
INFO - 2016-11-17 22:16:39 --> Config Class Initialized
INFO - 2016-11-17 22:16:39 --> Model Class Initialized
INFO - 2016-11-17 22:16:39 --> Security Class Initialized
INFO - 2016-11-17 22:16:39 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-17 22:16:39 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:16:39 --> Input Class Initialized
INFO - 2016-11-17 22:16:39 --> Utf8 Class Initialized
INFO - 2016-11-17 22:16:39 --> Language Class Initialized
INFO - 2016-11-17 22:16:39 --> URI Class Initialized
INFO - 2016-11-17 22:16:39 --> Loader Class Initialized
INFO - 2016-11-17 22:16:39 --> Router Class Initialized
INFO - 2016-11-17 22:16:40 --> Helper loaded: url_helper
INFO - 2016-11-17 22:16:40 --> Output Class Initialized
INFO - 2016-11-17 22:16:40 --> Helper loaded: form_helper
INFO - 2016-11-17 22:16:40 --> Security Class Initialized
INFO - 2016-11-17 22:16:40 --> Database Driver Class Initialized
DEBUG - 2016-11-17 22:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:16:40 --> Input Class Initialized
INFO - 2016-11-17 22:16:40 --> Controller Class Initialized
INFO - 2016-11-17 22:16:40 --> Language Class Initialized
INFO - 2016-11-17 22:16:40 --> Model Class Initialized
INFO - 2016-11-17 22:16:40 --> Loader Class Initialized
INFO - 2016-11-17 22:16:40 --> Config Class Initialized
INFO - 2016-11-17 22:16:40 --> Helper loaded: url_helper
INFO - 2016-11-17 22:16:40 --> Hooks Class Initialized
INFO - 2016-11-17 22:16:40 --> Helper loaded: form_helper
DEBUG - 2016-11-17 22:16:40 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:16:40 --> Database Driver Class Initialized
INFO - 2016-11-17 22:16:40 --> Utf8 Class Initialized
INFO - 2016-11-17 22:16:40 --> URI Class Initialized
INFO - 2016-11-17 22:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:16:40 --> Router Class Initialized
INFO - 2016-11-17 22:16:40 --> Controller Class Initialized
INFO - 2016-11-17 22:16:40 --> Model Class Initialized
INFO - 2016-11-17 22:16:40 --> Output Class Initialized
INFO - 2016-11-17 22:16:40 --> Security Class Initialized
DEBUG - 2016-11-17 22:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:16:40 --> Input Class Initialized
INFO - 2016-11-17 22:16:40 --> Language Class Initialized
INFO - 2016-11-17 22:16:40 --> Loader Class Initialized
INFO - 2016-11-17 22:16:40 --> Helper loaded: url_helper
INFO - 2016-11-17 22:16:40 --> Helper loaded: form_helper
INFO - 2016-11-17 22:16:40 --> Database Driver Class Initialized
INFO - 2016-11-17 22:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:16:40 --> Controller Class Initialized
INFO - 2016-11-17 22:16:40 --> Model Class Initialized
INFO - 2016-11-17 22:25:58 --> Config Class Initialized
INFO - 2016-11-17 22:25:58 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:25:58 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:25:58 --> Utf8 Class Initialized
INFO - 2016-11-17 22:25:58 --> URI Class Initialized
DEBUG - 2016-11-17 22:25:58 --> No URI present. Default controller set.
INFO - 2016-11-17 22:25:58 --> Router Class Initialized
INFO - 2016-11-17 22:25:58 --> Output Class Initialized
INFO - 2016-11-17 22:25:58 --> Security Class Initialized
DEBUG - 2016-11-17 22:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:25:58 --> Input Class Initialized
INFO - 2016-11-17 22:25:58 --> Language Class Initialized
INFO - 2016-11-17 22:25:58 --> Loader Class Initialized
INFO - 2016-11-17 22:25:58 --> Helper loaded: url_helper
INFO - 2016-11-17 22:25:58 --> Helper loaded: form_helper
INFO - 2016-11-17 22:25:58 --> Database Driver Class Initialized
INFO - 2016-11-17 22:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:25:58 --> Controller Class Initialized
INFO - 2016-11-17 22:25:58 --> Model Class Initialized
INFO - 2016-11-17 22:25:58 --> Model Class Initialized
INFO - 2016-11-17 22:25:58 --> Model Class Initialized
INFO - 2016-11-17 22:25:58 --> Model Class Initialized
INFO - 2016-11-17 22:25:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:25:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:25:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:25:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 22:25:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 22:25:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 22:25:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 22:25:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 22:25:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:25:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 22:25:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:25:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:25:58 --> Final output sent to browser
DEBUG - 2016-11-17 22:25:59 --> Total execution time: 0.5983
INFO - 2016-11-17 22:26:04 --> Config Class Initialized
INFO - 2016-11-17 22:26:04 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:26:04 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:04 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:04 --> URI Class Initialized
INFO - 2016-11-17 22:26:04 --> Router Class Initialized
INFO - 2016-11-17 22:26:04 --> Output Class Initialized
INFO - 2016-11-17 22:26:04 --> Security Class Initialized
DEBUG - 2016-11-17 22:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:04 --> Input Class Initialized
INFO - 2016-11-17 22:26:04 --> Language Class Initialized
INFO - 2016-11-17 22:26:04 --> Loader Class Initialized
INFO - 2016-11-17 22:26:04 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:04 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:04 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:04 --> Controller Class Initialized
INFO - 2016-11-17 22:26:04 --> Model Class Initialized
INFO - 2016-11-17 22:26:05 --> Config Class Initialized
INFO - 2016-11-17 22:26:05 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:26:05 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:05 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:05 --> URI Class Initialized
INFO - 2016-11-17 22:26:05 --> Router Class Initialized
INFO - 2016-11-17 22:26:05 --> Output Class Initialized
INFO - 2016-11-17 22:26:05 --> Security Class Initialized
DEBUG - 2016-11-17 22:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:05 --> Input Class Initialized
INFO - 2016-11-17 22:26:05 --> Language Class Initialized
INFO - 2016-11-17 22:26:05 --> Loader Class Initialized
INFO - 2016-11-17 22:26:05 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:05 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:05 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:05 --> Controller Class Initialized
INFO - 2016-11-17 22:26:05 --> Model Class Initialized
INFO - 2016-11-17 22:26:06 --> Config Class Initialized
INFO - 2016-11-17 22:26:06 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:26:06 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:06 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:06 --> URI Class Initialized
INFO - 2016-11-17 22:26:06 --> Router Class Initialized
INFO - 2016-11-17 22:26:06 --> Output Class Initialized
INFO - 2016-11-17 22:26:06 --> Security Class Initialized
DEBUG - 2016-11-17 22:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:06 --> Input Class Initialized
INFO - 2016-11-17 22:26:06 --> Config Class Initialized
INFO - 2016-11-17 22:26:06 --> Language Class Initialized
INFO - 2016-11-17 22:26:06 --> Hooks Class Initialized
INFO - 2016-11-17 22:26:06 --> Loader Class Initialized
DEBUG - 2016-11-17 22:26:06 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:06 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:06 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:06 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:06 --> URI Class Initialized
INFO - 2016-11-17 22:26:06 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:06 --> Config Class Initialized
INFO - 2016-11-17 22:26:06 --> Router Class Initialized
INFO - 2016-11-17 22:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:06 --> Hooks Class Initialized
INFO - 2016-11-17 22:26:06 --> Output Class Initialized
INFO - 2016-11-17 22:26:06 --> Controller Class Initialized
DEBUG - 2016-11-17 22:26:06 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:06 --> Security Class Initialized
INFO - 2016-11-17 22:26:06 --> Model Class Initialized
INFO - 2016-11-17 22:26:06 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:06 --> URI Class Initialized
DEBUG - 2016-11-17 22:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:06 --> Input Class Initialized
INFO - 2016-11-17 22:26:06 --> Router Class Initialized
INFO - 2016-11-17 22:26:06 --> Language Class Initialized
INFO - 2016-11-17 22:26:06 --> Output Class Initialized
INFO - 2016-11-17 22:26:06 --> Loader Class Initialized
INFO - 2016-11-17 22:26:06 --> Config Class Initialized
INFO - 2016-11-17 22:26:06 --> Security Class Initialized
INFO - 2016-11-17 22:26:06 --> Hooks Class Initialized
INFO - 2016-11-17 22:26:06 --> Helper loaded: url_helper
DEBUG - 2016-11-17 22:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-17 22:26:06 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:06 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:06 --> Input Class Initialized
INFO - 2016-11-17 22:26:06 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:06 --> Language Class Initialized
INFO - 2016-11-17 22:26:06 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:06 --> URI Class Initialized
INFO - 2016-11-17 22:26:06 --> Loader Class Initialized
INFO - 2016-11-17 22:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:06 --> Router Class Initialized
INFO - 2016-11-17 22:26:06 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:06 --> Controller Class Initialized
INFO - 2016-11-17 22:26:06 --> Output Class Initialized
INFO - 2016-11-17 22:26:06 --> Config Class Initialized
INFO - 2016-11-17 22:26:06 --> Model Class Initialized
INFO - 2016-11-17 22:26:06 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:06 --> Security Class Initialized
INFO - 2016-11-17 22:26:06 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:07 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:07 --> Input Class Initialized
DEBUG - 2016-11-17 22:26:07 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:07 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:07 --> Language Class Initialized
INFO - 2016-11-17 22:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:07 --> URI Class Initialized
INFO - 2016-11-17 22:26:07 --> Controller Class Initialized
INFO - 2016-11-17 22:26:07 --> Loader Class Initialized
INFO - 2016-11-17 22:26:07 --> Model Class Initialized
INFO - 2016-11-17 22:26:07 --> Router Class Initialized
INFO - 2016-11-17 22:26:07 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:07 --> Config Class Initialized
INFO - 2016-11-17 22:26:07 --> Hooks Class Initialized
INFO - 2016-11-17 22:26:07 --> Output Class Initialized
INFO - 2016-11-17 22:26:07 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:07 --> Security Class Initialized
DEBUG - 2016-11-17 22:26:07 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:07 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:07 --> Utf8 Class Initialized
DEBUG - 2016-11-17 22:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:07 --> URI Class Initialized
INFO - 2016-11-17 22:26:07 --> Input Class Initialized
INFO - 2016-11-17 22:26:07 --> Controller Class Initialized
INFO - 2016-11-17 22:26:07 --> Language Class Initialized
INFO - 2016-11-17 22:26:07 --> Router Class Initialized
INFO - 2016-11-17 22:26:07 --> Model Class Initialized
INFO - 2016-11-17 22:26:07 --> Loader Class Initialized
INFO - 2016-11-17 22:26:07 --> Output Class Initialized
INFO - 2016-11-17 22:26:07 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:07 --> Security Class Initialized
INFO - 2016-11-17 22:26:07 --> Helper loaded: form_helper
DEBUG - 2016-11-17 22:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:07 --> Input Class Initialized
INFO - 2016-11-17 22:26:07 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:07 --> Language Class Initialized
INFO - 2016-11-17 22:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:07 --> Loader Class Initialized
INFO - 2016-11-17 22:26:07 --> Controller Class Initialized
INFO - 2016-11-17 22:26:07 --> Model Class Initialized
INFO - 2016-11-17 22:26:07 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:07 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:07 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:07 --> Controller Class Initialized
INFO - 2016-11-17 22:26:07 --> Model Class Initialized
INFO - 2016-11-17 22:26:07 --> Config Class Initialized
INFO - 2016-11-17 22:26:07 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:26:08 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:08 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:08 --> URI Class Initialized
INFO - 2016-11-17 22:26:08 --> Router Class Initialized
INFO - 2016-11-17 22:26:08 --> Output Class Initialized
INFO - 2016-11-17 22:26:08 --> Security Class Initialized
DEBUG - 2016-11-17 22:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:08 --> Input Class Initialized
INFO - 2016-11-17 22:26:08 --> Language Class Initialized
INFO - 2016-11-17 22:26:08 --> Loader Class Initialized
INFO - 2016-11-17 22:26:08 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:08 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:08 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:08 --> Controller Class Initialized
INFO - 2016-11-17 22:26:08 --> Model Class Initialized
INFO - 2016-11-17 22:26:08 --> Config Class Initialized
INFO - 2016-11-17 22:26:08 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:26:08 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:08 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:08 --> URI Class Initialized
INFO - 2016-11-17 22:26:08 --> Router Class Initialized
INFO - 2016-11-17 22:26:08 --> Output Class Initialized
INFO - 2016-11-17 22:26:08 --> Security Class Initialized
DEBUG - 2016-11-17 22:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:08 --> Input Class Initialized
INFO - 2016-11-17 22:26:08 --> Language Class Initialized
INFO - 2016-11-17 22:26:08 --> Loader Class Initialized
INFO - 2016-11-17 22:26:08 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:08 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:08 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:08 --> Controller Class Initialized
INFO - 2016-11-17 22:26:08 --> Model Class Initialized
INFO - 2016-11-17 22:26:08 --> Config Class Initialized
INFO - 2016-11-17 22:26:08 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:26:08 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:08 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:08 --> URI Class Initialized
INFO - 2016-11-17 22:26:08 --> Router Class Initialized
INFO - 2016-11-17 22:26:08 --> Output Class Initialized
INFO - 2016-11-17 22:26:08 --> Security Class Initialized
DEBUG - 2016-11-17 22:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:08 --> Input Class Initialized
INFO - 2016-11-17 22:26:08 --> Language Class Initialized
INFO - 2016-11-17 22:26:09 --> Loader Class Initialized
INFO - 2016-11-17 22:26:09 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:09 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:09 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:09 --> Controller Class Initialized
INFO - 2016-11-17 22:26:09 --> Model Class Initialized
INFO - 2016-11-17 22:26:31 --> Config Class Initialized
INFO - 2016-11-17 22:26:31 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:26:31 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:31 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:31 --> URI Class Initialized
DEBUG - 2016-11-17 22:26:31 --> No URI present. Default controller set.
INFO - 2016-11-17 22:26:31 --> Router Class Initialized
INFO - 2016-11-17 22:26:31 --> Output Class Initialized
INFO - 2016-11-17 22:26:31 --> Security Class Initialized
DEBUG - 2016-11-17 22:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:31 --> Input Class Initialized
INFO - 2016-11-17 22:26:31 --> Language Class Initialized
INFO - 2016-11-17 22:26:31 --> Loader Class Initialized
INFO - 2016-11-17 22:26:31 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:31 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:31 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:31 --> Controller Class Initialized
INFO - 2016-11-17 22:26:31 --> Model Class Initialized
INFO - 2016-11-17 22:26:31 --> Model Class Initialized
INFO - 2016-11-17 22:26:31 --> Model Class Initialized
INFO - 2016-11-17 22:26:31 --> Model Class Initialized
INFO - 2016-11-17 22:26:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:26:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:26:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:26:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 22:26:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 22:26:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 22:26:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 22:26:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 22:26:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:26:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 22:26:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:26:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:26:32 --> Final output sent to browser
DEBUG - 2016-11-17 22:26:32 --> Total execution time: 0.5637
INFO - 2016-11-17 22:26:34 --> Config Class Initialized
INFO - 2016-11-17 22:26:34 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:26:34 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:34 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:34 --> URI Class Initialized
INFO - 2016-11-17 22:26:34 --> Router Class Initialized
INFO - 2016-11-17 22:26:34 --> Output Class Initialized
INFO - 2016-11-17 22:26:35 --> Security Class Initialized
DEBUG - 2016-11-17 22:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:35 --> Input Class Initialized
INFO - 2016-11-17 22:26:35 --> Language Class Initialized
INFO - 2016-11-17 22:26:35 --> Loader Class Initialized
INFO - 2016-11-17 22:26:35 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:35 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:35 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:35 --> Controller Class Initialized
INFO - 2016-11-17 22:26:35 --> Model Class Initialized
INFO - 2016-11-17 22:26:38 --> Config Class Initialized
INFO - 2016-11-17 22:26:38 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:26:38 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:38 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:38 --> URI Class Initialized
INFO - 2016-11-17 22:26:38 --> Router Class Initialized
INFO - 2016-11-17 22:26:38 --> Output Class Initialized
INFO - 2016-11-17 22:26:38 --> Security Class Initialized
DEBUG - 2016-11-17 22:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:38 --> Input Class Initialized
INFO - 2016-11-17 22:26:38 --> Language Class Initialized
INFO - 2016-11-17 22:26:38 --> Loader Class Initialized
INFO - 2016-11-17 22:26:38 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:38 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:38 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:38 --> Controller Class Initialized
INFO - 2016-11-17 22:26:38 --> Model Class Initialized
INFO - 2016-11-17 22:26:38 --> Config Class Initialized
INFO - 2016-11-17 22:26:38 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:26:38 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:38 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:38 --> URI Class Initialized
INFO - 2016-11-17 22:26:38 --> Router Class Initialized
INFO - 2016-11-17 22:26:38 --> Output Class Initialized
INFO - 2016-11-17 22:26:38 --> Security Class Initialized
DEBUG - 2016-11-17 22:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:38 --> Input Class Initialized
INFO - 2016-11-17 22:26:38 --> Language Class Initialized
INFO - 2016-11-17 22:26:38 --> Loader Class Initialized
INFO - 2016-11-17 22:26:38 --> Config Class Initialized
INFO - 2016-11-17 22:26:38 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:38 --> Hooks Class Initialized
INFO - 2016-11-17 22:26:38 --> Helper loaded: form_helper
DEBUG - 2016-11-17 22:26:38 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:38 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:38 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:38 --> URI Class Initialized
INFO - 2016-11-17 22:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:38 --> Router Class Initialized
INFO - 2016-11-17 22:26:38 --> Controller Class Initialized
INFO - 2016-11-17 22:26:38 --> Model Class Initialized
INFO - 2016-11-17 22:26:38 --> Output Class Initialized
INFO - 2016-11-17 22:26:38 --> Security Class Initialized
DEBUG - 2016-11-17 22:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:38 --> Input Class Initialized
INFO - 2016-11-17 22:26:38 --> Config Class Initialized
INFO - 2016-11-17 22:26:38 --> Language Class Initialized
INFO - 2016-11-17 22:26:38 --> Hooks Class Initialized
INFO - 2016-11-17 22:26:38 --> Loader Class Initialized
DEBUG - 2016-11-17 22:26:38 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:38 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:38 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:38 --> URI Class Initialized
INFO - 2016-11-17 22:26:38 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:38 --> Router Class Initialized
INFO - 2016-11-17 22:26:38 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:39 --> Output Class Initialized
INFO - 2016-11-17 22:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:39 --> Security Class Initialized
INFO - 2016-11-17 22:26:39 --> Controller Class Initialized
INFO - 2016-11-17 22:26:39 --> Model Class Initialized
DEBUG - 2016-11-17 22:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:39 --> Input Class Initialized
INFO - 2016-11-17 22:26:39 --> Language Class Initialized
INFO - 2016-11-17 22:26:39 --> Loader Class Initialized
INFO - 2016-11-17 22:26:39 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:39 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:39 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:39 --> Controller Class Initialized
INFO - 2016-11-17 22:26:39 --> Model Class Initialized
INFO - 2016-11-17 22:26:39 --> Config Class Initialized
INFO - 2016-11-17 22:26:39 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:26:39 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:39 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:39 --> URI Class Initialized
INFO - 2016-11-17 22:26:39 --> Router Class Initialized
INFO - 2016-11-17 22:26:39 --> Output Class Initialized
INFO - 2016-11-17 22:26:39 --> Security Class Initialized
DEBUG - 2016-11-17 22:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:39 --> Input Class Initialized
INFO - 2016-11-17 22:26:39 --> Language Class Initialized
INFO - 2016-11-17 22:26:39 --> Loader Class Initialized
INFO - 2016-11-17 22:26:39 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:39 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:40 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:40 --> Controller Class Initialized
INFO - 2016-11-17 22:26:40 --> Model Class Initialized
INFO - 2016-11-17 22:26:40 --> Config Class Initialized
INFO - 2016-11-17 22:26:40 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:26:40 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:40 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:40 --> URI Class Initialized
INFO - 2016-11-17 22:26:40 --> Router Class Initialized
INFO - 2016-11-17 22:26:40 --> Output Class Initialized
INFO - 2016-11-17 22:26:40 --> Security Class Initialized
DEBUG - 2016-11-17 22:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:40 --> Input Class Initialized
INFO - 2016-11-17 22:26:40 --> Language Class Initialized
INFO - 2016-11-17 22:26:40 --> Loader Class Initialized
INFO - 2016-11-17 22:26:40 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:40 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:40 --> Config Class Initialized
INFO - 2016-11-17 22:26:40 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:40 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:26:40 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:40 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:40 --> Controller Class Initialized
INFO - 2016-11-17 22:26:40 --> URI Class Initialized
INFO - 2016-11-17 22:26:40 --> Model Class Initialized
INFO - 2016-11-17 22:26:40 --> Router Class Initialized
INFO - 2016-11-17 22:26:40 --> Output Class Initialized
INFO - 2016-11-17 22:26:40 --> Security Class Initialized
DEBUG - 2016-11-17 22:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:40 --> Input Class Initialized
INFO - 2016-11-17 22:26:40 --> Config Class Initialized
INFO - 2016-11-17 22:26:40 --> Language Class Initialized
INFO - 2016-11-17 22:26:40 --> Hooks Class Initialized
INFO - 2016-11-17 22:26:40 --> Loader Class Initialized
DEBUG - 2016-11-17 22:26:40 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:40 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:40 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:40 --> URI Class Initialized
INFO - 2016-11-17 22:26:40 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:40 --> Router Class Initialized
INFO - 2016-11-17 22:26:40 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:40 --> Output Class Initialized
INFO - 2016-11-17 22:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:40 --> Security Class Initialized
INFO - 2016-11-17 22:26:40 --> Controller Class Initialized
INFO - 2016-11-17 22:26:40 --> Model Class Initialized
INFO - 2016-11-17 22:26:40 --> Config Class Initialized
DEBUG - 2016-11-17 22:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:40 --> Input Class Initialized
INFO - 2016-11-17 22:26:40 --> Hooks Class Initialized
INFO - 2016-11-17 22:26:40 --> Language Class Initialized
DEBUG - 2016-11-17 22:26:40 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:40 --> Loader Class Initialized
INFO - 2016-11-17 22:26:40 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:40 --> URI Class Initialized
INFO - 2016-11-17 22:26:40 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:40 --> Router Class Initialized
INFO - 2016-11-17 22:26:40 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:40 --> Output Class Initialized
INFO - 2016-11-17 22:26:40 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:40 --> Security Class Initialized
INFO - 2016-11-17 22:26:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-17 22:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:40 --> Controller Class Initialized
INFO - 2016-11-17 22:26:40 --> Input Class Initialized
INFO - 2016-11-17 22:26:40 --> Model Class Initialized
INFO - 2016-11-17 22:26:40 --> Config Class Initialized
INFO - 2016-11-17 22:26:40 --> Hooks Class Initialized
INFO - 2016-11-17 22:26:40 --> Language Class Initialized
INFO - 2016-11-17 22:26:40 --> Loader Class Initialized
DEBUG - 2016-11-17 22:26:40 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:40 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:40 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:40 --> URI Class Initialized
INFO - 2016-11-17 22:26:40 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:40 --> Router Class Initialized
INFO - 2016-11-17 22:26:41 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:41 --> Output Class Initialized
INFO - 2016-11-17 22:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:41 --> Security Class Initialized
INFO - 2016-11-17 22:26:41 --> Controller Class Initialized
INFO - 2016-11-17 22:26:41 --> Model Class Initialized
INFO - 2016-11-17 22:26:41 --> Config Class Initialized
DEBUG - 2016-11-17 22:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:41 --> Hooks Class Initialized
INFO - 2016-11-17 22:26:41 --> Input Class Initialized
INFO - 2016-11-17 22:26:41 --> Language Class Initialized
DEBUG - 2016-11-17 22:26:41 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:41 --> Loader Class Initialized
INFO - 2016-11-17 22:26:41 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:41 --> URI Class Initialized
INFO - 2016-11-17 22:26:41 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:41 --> Router Class Initialized
INFO - 2016-11-17 22:26:41 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:41 --> Output Class Initialized
INFO - 2016-11-17 22:26:41 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:41 --> Security Class Initialized
INFO - 2016-11-17 22:26:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-17 22:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:41 --> Controller Class Initialized
INFO - 2016-11-17 22:26:41 --> Config Class Initialized
INFO - 2016-11-17 22:26:41 --> Model Class Initialized
INFO - 2016-11-17 22:26:41 --> Input Class Initialized
INFO - 2016-11-17 22:26:41 --> Hooks Class Initialized
INFO - 2016-11-17 22:26:41 --> Language Class Initialized
DEBUG - 2016-11-17 22:26:41 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:41 --> Loader Class Initialized
INFO - 2016-11-17 22:26:41 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:41 --> URI Class Initialized
INFO - 2016-11-17 22:26:41 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:41 --> Router Class Initialized
INFO - 2016-11-17 22:26:41 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:41 --> Output Class Initialized
INFO - 2016-11-17 22:26:41 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:41 --> Security Class Initialized
INFO - 2016-11-17 22:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:41 --> Config Class Initialized
INFO - 2016-11-17 22:26:41 --> Controller Class Initialized
DEBUG - 2016-11-17 22:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:41 --> Input Class Initialized
INFO - 2016-11-17 22:26:41 --> Hooks Class Initialized
INFO - 2016-11-17 22:26:41 --> Model Class Initialized
INFO - 2016-11-17 22:26:41 --> Language Class Initialized
DEBUG - 2016-11-17 22:26:41 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:41 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:41 --> Loader Class Initialized
INFO - 2016-11-17 22:26:41 --> URI Class Initialized
INFO - 2016-11-17 22:26:41 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:41 --> Router Class Initialized
INFO - 2016-11-17 22:26:41 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:41 --> Output Class Initialized
INFO - 2016-11-17 22:26:41 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:41 --> Security Class Initialized
INFO - 2016-11-17 22:26:41 --> Config Class Initialized
INFO - 2016-11-17 22:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:41 --> Controller Class Initialized
DEBUG - 2016-11-17 22:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:41 --> Hooks Class Initialized
INFO - 2016-11-17 22:26:41 --> Input Class Initialized
INFO - 2016-11-17 22:26:41 --> Model Class Initialized
DEBUG - 2016-11-17 22:26:41 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:41 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:41 --> Language Class Initialized
INFO - 2016-11-17 22:26:41 --> URI Class Initialized
INFO - 2016-11-17 22:26:41 --> Loader Class Initialized
INFO - 2016-11-17 22:26:41 --> Router Class Initialized
INFO - 2016-11-17 22:26:41 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:41 --> Output Class Initialized
INFO - 2016-11-17 22:26:41 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:41 --> Security Class Initialized
INFO - 2016-11-17 22:26:41 --> Database Driver Class Initialized
DEBUG - 2016-11-17 22:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:41 --> Config Class Initialized
INFO - 2016-11-17 22:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:41 --> Input Class Initialized
INFO - 2016-11-17 22:26:41 --> Hooks Class Initialized
INFO - 2016-11-17 22:26:41 --> Controller Class Initialized
INFO - 2016-11-17 22:26:41 --> Language Class Initialized
DEBUG - 2016-11-17 22:26:41 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:41 --> Model Class Initialized
INFO - 2016-11-17 22:26:41 --> Loader Class Initialized
INFO - 2016-11-17 22:26:41 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:41 --> URI Class Initialized
INFO - 2016-11-17 22:26:41 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:41 --> Router Class Initialized
INFO - 2016-11-17 22:26:41 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:41 --> Output Class Initialized
INFO - 2016-11-17 22:26:41 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:42 --> Security Class Initialized
INFO - 2016-11-17 22:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:42 --> Config Class Initialized
INFO - 2016-11-17 22:26:42 --> Controller Class Initialized
DEBUG - 2016-11-17 22:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:42 --> Hooks Class Initialized
INFO - 2016-11-17 22:26:42 --> Input Class Initialized
INFO - 2016-11-17 22:26:42 --> Model Class Initialized
DEBUG - 2016-11-17 22:26:42 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:42 --> Language Class Initialized
INFO - 2016-11-17 22:26:42 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:42 --> Loader Class Initialized
INFO - 2016-11-17 22:26:42 --> URI Class Initialized
INFO - 2016-11-17 22:26:42 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:42 --> Router Class Initialized
INFO - 2016-11-17 22:26:42 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:42 --> Output Class Initialized
INFO - 2016-11-17 22:26:42 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:42 --> Security Class Initialized
INFO - 2016-11-17 22:26:42 --> Config Class Initialized
INFO - 2016-11-17 22:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:42 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:42 --> Controller Class Initialized
INFO - 2016-11-17 22:26:42 --> Input Class Initialized
DEBUG - 2016-11-17 22:26:42 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:42 --> Model Class Initialized
INFO - 2016-11-17 22:26:42 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:42 --> Language Class Initialized
INFO - 2016-11-17 22:26:42 --> URI Class Initialized
INFO - 2016-11-17 22:26:42 --> Loader Class Initialized
INFO - 2016-11-17 22:26:42 --> Router Class Initialized
INFO - 2016-11-17 22:26:42 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:42 --> Output Class Initialized
INFO - 2016-11-17 22:26:42 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:42 --> Security Class Initialized
INFO - 2016-11-17 22:26:42 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:42 --> Config Class Initialized
DEBUG - 2016-11-17 22:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:42 --> Hooks Class Initialized
INFO - 2016-11-17 22:26:42 --> Input Class Initialized
INFO - 2016-11-17 22:26:42 --> Controller Class Initialized
DEBUG - 2016-11-17 22:26:42 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:42 --> Language Class Initialized
INFO - 2016-11-17 22:26:42 --> Model Class Initialized
INFO - 2016-11-17 22:26:42 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:42 --> Loader Class Initialized
INFO - 2016-11-17 22:26:42 --> URI Class Initialized
INFO - 2016-11-17 22:26:42 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:42 --> Router Class Initialized
INFO - 2016-11-17 22:26:42 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:42 --> Output Class Initialized
INFO - 2016-11-17 22:26:42 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:42 --> Security Class Initialized
INFO - 2016-11-17 22:26:42 --> Config Class Initialized
INFO - 2016-11-17 22:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:42 --> Hooks Class Initialized
INFO - 2016-11-17 22:26:42 --> Controller Class Initialized
DEBUG - 2016-11-17 22:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-17 22:26:42 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:26:42 --> Model Class Initialized
INFO - 2016-11-17 22:26:42 --> Input Class Initialized
INFO - 2016-11-17 22:26:42 --> Utf8 Class Initialized
INFO - 2016-11-17 22:26:42 --> Language Class Initialized
INFO - 2016-11-17 22:26:42 --> URI Class Initialized
INFO - 2016-11-17 22:26:42 --> Loader Class Initialized
INFO - 2016-11-17 22:26:42 --> Router Class Initialized
INFO - 2016-11-17 22:26:42 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:42 --> Output Class Initialized
INFO - 2016-11-17 22:26:42 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:42 --> Security Class Initialized
INFO - 2016-11-17 22:26:42 --> Database Driver Class Initialized
DEBUG - 2016-11-17 22:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:42 --> Input Class Initialized
INFO - 2016-11-17 22:26:42 --> Controller Class Initialized
INFO - 2016-11-17 22:26:42 --> Language Class Initialized
INFO - 2016-11-17 22:26:42 --> Model Class Initialized
INFO - 2016-11-17 22:26:42 --> Loader Class Initialized
INFO - 2016-11-17 22:26:42 --> Helper loaded: url_helper
INFO - 2016-11-17 22:26:42 --> Helper loaded: form_helper
INFO - 2016-11-17 22:26:42 --> Database Driver Class Initialized
INFO - 2016-11-17 22:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:26:42 --> Controller Class Initialized
INFO - 2016-11-17 22:26:42 --> Model Class Initialized
INFO - 2016-11-17 22:27:02 --> Config Class Initialized
INFO - 2016-11-17 22:27:02 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:27:02 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:27:02 --> Utf8 Class Initialized
INFO - 2016-11-17 22:27:02 --> URI Class Initialized
DEBUG - 2016-11-17 22:27:02 --> No URI present. Default controller set.
INFO - 2016-11-17 22:27:02 --> Router Class Initialized
INFO - 2016-11-17 22:27:02 --> Output Class Initialized
INFO - 2016-11-17 22:27:02 --> Security Class Initialized
DEBUG - 2016-11-17 22:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:27:02 --> Input Class Initialized
INFO - 2016-11-17 22:27:02 --> Language Class Initialized
INFO - 2016-11-17 22:27:02 --> Loader Class Initialized
INFO - 2016-11-17 22:27:02 --> Helper loaded: url_helper
INFO - 2016-11-17 22:27:02 --> Helper loaded: form_helper
INFO - 2016-11-17 22:27:02 --> Database Driver Class Initialized
INFO - 2016-11-17 22:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:27:02 --> Controller Class Initialized
INFO - 2016-11-17 22:27:02 --> Model Class Initialized
INFO - 2016-11-17 22:27:02 --> Model Class Initialized
INFO - 2016-11-17 22:27:02 --> Model Class Initialized
INFO - 2016-11-17 22:27:02 --> Model Class Initialized
INFO - 2016-11-17 22:27:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:27:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:27:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:27:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 22:27:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 22:27:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 22:27:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 22:27:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 22:27:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:27:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 22:27:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:27:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:27:02 --> Final output sent to browser
DEBUG - 2016-11-17 22:27:02 --> Total execution time: 0.6068
INFO - 2016-11-17 22:27:09 --> Config Class Initialized
INFO - 2016-11-17 22:27:09 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:27:09 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:27:09 --> Utf8 Class Initialized
INFO - 2016-11-17 22:27:09 --> URI Class Initialized
INFO - 2016-11-17 22:27:09 --> Router Class Initialized
INFO - 2016-11-17 22:27:09 --> Output Class Initialized
INFO - 2016-11-17 22:27:09 --> Security Class Initialized
DEBUG - 2016-11-17 22:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:27:09 --> Input Class Initialized
INFO - 2016-11-17 22:27:09 --> Language Class Initialized
INFO - 2016-11-17 22:27:09 --> Loader Class Initialized
INFO - 2016-11-17 22:27:09 --> Helper loaded: url_helper
INFO - 2016-11-17 22:27:09 --> Helper loaded: form_helper
INFO - 2016-11-17 22:27:09 --> Database Driver Class Initialized
INFO - 2016-11-17 22:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:27:09 --> Controller Class Initialized
INFO - 2016-11-17 22:27:09 --> Model Class Initialized
INFO - 2016-11-17 22:27:12 --> Config Class Initialized
INFO - 2016-11-17 22:27:12 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:27:12 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:27:12 --> Utf8 Class Initialized
INFO - 2016-11-17 22:27:12 --> URI Class Initialized
INFO - 2016-11-17 22:27:12 --> Router Class Initialized
INFO - 2016-11-17 22:27:12 --> Output Class Initialized
INFO - 2016-11-17 22:27:12 --> Security Class Initialized
DEBUG - 2016-11-17 22:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:27:12 --> Input Class Initialized
INFO - 2016-11-17 22:27:12 --> Language Class Initialized
INFO - 2016-11-17 22:27:12 --> Config Class Initialized
INFO - 2016-11-17 22:27:12 --> Hooks Class Initialized
INFO - 2016-11-17 22:27:12 --> Loader Class Initialized
INFO - 2016-11-17 22:27:12 --> Helper loaded: url_helper
DEBUG - 2016-11-17 22:27:12 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:27:12 --> Helper loaded: form_helper
INFO - 2016-11-17 22:27:12 --> Utf8 Class Initialized
INFO - 2016-11-17 22:27:12 --> URI Class Initialized
INFO - 2016-11-17 22:27:12 --> Database Driver Class Initialized
INFO - 2016-11-17 22:27:12 --> Router Class Initialized
INFO - 2016-11-17 22:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:27:12 --> Output Class Initialized
INFO - 2016-11-17 22:27:12 --> Controller Class Initialized
INFO - 2016-11-17 22:27:12 --> Model Class Initialized
INFO - 2016-11-17 22:27:12 --> Security Class Initialized
INFO - 2016-11-17 22:27:12 --> Config Class Initialized
INFO - 2016-11-17 22:27:12 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-17 22:27:13 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:27:13 --> Input Class Initialized
INFO - 2016-11-17 22:27:13 --> Utf8 Class Initialized
INFO - 2016-11-17 22:27:13 --> Language Class Initialized
INFO - 2016-11-17 22:27:13 --> URI Class Initialized
INFO - 2016-11-17 22:27:13 --> Loader Class Initialized
INFO - 2016-11-17 22:27:13 --> Router Class Initialized
INFO - 2016-11-17 22:27:13 --> Helper loaded: url_helper
INFO - 2016-11-17 22:27:13 --> Output Class Initialized
INFO - 2016-11-17 22:27:13 --> Config Class Initialized
INFO - 2016-11-17 22:27:13 --> Security Class Initialized
INFO - 2016-11-17 22:27:13 --> Hooks Class Initialized
INFO - 2016-11-17 22:27:13 --> Helper loaded: form_helper
DEBUG - 2016-11-17 22:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-17 22:27:13 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:27:13 --> Input Class Initialized
INFO - 2016-11-17 22:27:13 --> Database Driver Class Initialized
INFO - 2016-11-17 22:27:13 --> Utf8 Class Initialized
INFO - 2016-11-17 22:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:27:13 --> Language Class Initialized
INFO - 2016-11-17 22:27:13 --> URI Class Initialized
INFO - 2016-11-17 22:27:13 --> Controller Class Initialized
INFO - 2016-11-17 22:27:13 --> Loader Class Initialized
INFO - 2016-11-17 22:27:13 --> Model Class Initialized
INFO - 2016-11-17 22:27:13 --> Router Class Initialized
INFO - 2016-11-17 22:27:13 --> Helper loaded: url_helper
INFO - 2016-11-17 22:27:13 --> Output Class Initialized
INFO - 2016-11-17 22:27:13 --> Config Class Initialized
INFO - 2016-11-17 22:27:13 --> Hooks Class Initialized
INFO - 2016-11-17 22:27:13 --> Helper loaded: form_helper
INFO - 2016-11-17 22:27:13 --> Security Class Initialized
DEBUG - 2016-11-17 22:27:13 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:27:13 --> Database Driver Class Initialized
DEBUG - 2016-11-17 22:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:27:13 --> Utf8 Class Initialized
INFO - 2016-11-17 22:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:27:13 --> Input Class Initialized
INFO - 2016-11-17 22:27:13 --> Controller Class Initialized
INFO - 2016-11-17 22:27:13 --> URI Class Initialized
INFO - 2016-11-17 22:27:13 --> Language Class Initialized
INFO - 2016-11-17 22:27:13 --> Config Class Initialized
INFO - 2016-11-17 22:27:13 --> Model Class Initialized
INFO - 2016-11-17 22:27:13 --> Router Class Initialized
INFO - 2016-11-17 22:27:13 --> Hooks Class Initialized
INFO - 2016-11-17 22:27:13 --> Loader Class Initialized
INFO - 2016-11-17 22:27:13 --> Helper loaded: url_helper
DEBUG - 2016-11-17 22:27:13 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:27:13 --> Output Class Initialized
INFO - 2016-11-17 22:27:13 --> Utf8 Class Initialized
INFO - 2016-11-17 22:27:13 --> Helper loaded: form_helper
INFO - 2016-11-17 22:27:13 --> Security Class Initialized
INFO - 2016-11-17 22:27:13 --> URI Class Initialized
INFO - 2016-11-17 22:27:13 --> Database Driver Class Initialized
DEBUG - 2016-11-17 22:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:27:13 --> Router Class Initialized
INFO - 2016-11-17 22:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:27:13 --> Input Class Initialized
INFO - 2016-11-17 22:27:13 --> Controller Class Initialized
INFO - 2016-11-17 22:27:13 --> Output Class Initialized
INFO - 2016-11-17 22:27:13 --> Config Class Initialized
INFO - 2016-11-17 22:27:13 --> Language Class Initialized
INFO - 2016-11-17 22:27:13 --> Model Class Initialized
INFO - 2016-11-17 22:27:13 --> Security Class Initialized
INFO - 2016-11-17 22:27:13 --> Hooks Class Initialized
INFO - 2016-11-17 22:27:13 --> Loader Class Initialized
DEBUG - 2016-11-17 22:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-17 22:27:13 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:27:13 --> Helper loaded: url_helper
INFO - 2016-11-17 22:27:13 --> Input Class Initialized
INFO - 2016-11-17 22:27:13 --> Utf8 Class Initialized
INFO - 2016-11-17 22:27:13 --> Language Class Initialized
INFO - 2016-11-17 22:27:13 --> URI Class Initialized
INFO - 2016-11-17 22:27:13 --> Helper loaded: form_helper
INFO - 2016-11-17 22:27:13 --> Loader Class Initialized
INFO - 2016-11-17 22:27:13 --> Database Driver Class Initialized
INFO - 2016-11-17 22:27:13 --> Router Class Initialized
INFO - 2016-11-17 22:27:13 --> Helper loaded: url_helper
INFO - 2016-11-17 22:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:27:13 --> Output Class Initialized
INFO - 2016-11-17 22:27:13 --> Config Class Initialized
INFO - 2016-11-17 22:27:13 --> Helper loaded: form_helper
INFO - 2016-11-17 22:27:13 --> Controller Class Initialized
INFO - 2016-11-17 22:27:13 --> Hooks Class Initialized
INFO - 2016-11-17 22:27:13 --> Security Class Initialized
INFO - 2016-11-17 22:27:13 --> Database Driver Class Initialized
DEBUG - 2016-11-17 22:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-17 22:27:13 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:27:13 --> Model Class Initialized
INFO - 2016-11-17 22:27:13 --> Utf8 Class Initialized
INFO - 2016-11-17 22:27:13 --> Input Class Initialized
INFO - 2016-11-17 22:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:27:13 --> Language Class Initialized
INFO - 2016-11-17 22:27:13 --> URI Class Initialized
INFO - 2016-11-17 22:27:13 --> Controller Class Initialized
INFO - 2016-11-17 22:27:13 --> Model Class Initialized
INFO - 2016-11-17 22:27:13 --> Router Class Initialized
INFO - 2016-11-17 22:27:13 --> Loader Class Initialized
INFO - 2016-11-17 22:27:13 --> Helper loaded: url_helper
INFO - 2016-11-17 22:27:13 --> Output Class Initialized
INFO - 2016-11-17 22:27:13 --> Helper loaded: form_helper
INFO - 2016-11-17 22:27:13 --> Security Class Initialized
DEBUG - 2016-11-17 22:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:27:13 --> Database Driver Class Initialized
INFO - 2016-11-17 22:27:13 --> Input Class Initialized
INFO - 2016-11-17 22:27:13 --> Language Class Initialized
INFO - 2016-11-17 22:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:27:14 --> Loader Class Initialized
INFO - 2016-11-17 22:27:14 --> Controller Class Initialized
INFO - 2016-11-17 22:27:14 --> Model Class Initialized
INFO - 2016-11-17 22:27:14 --> Helper loaded: url_helper
INFO - 2016-11-17 22:27:14 --> Helper loaded: form_helper
INFO - 2016-11-17 22:27:14 --> Database Driver Class Initialized
INFO - 2016-11-17 22:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:27:14 --> Controller Class Initialized
INFO - 2016-11-17 22:27:14 --> Model Class Initialized
INFO - 2016-11-17 22:27:16 --> Config Class Initialized
INFO - 2016-11-17 22:27:16 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:27:16 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:27:16 --> Utf8 Class Initialized
INFO - 2016-11-17 22:27:16 --> URI Class Initialized
INFO - 2016-11-17 22:27:16 --> Router Class Initialized
INFO - 2016-11-17 22:27:16 --> Output Class Initialized
INFO - 2016-11-17 22:27:16 --> Security Class Initialized
DEBUG - 2016-11-17 22:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:27:16 --> Input Class Initialized
INFO - 2016-11-17 22:27:16 --> Language Class Initialized
INFO - 2016-11-17 22:27:16 --> Loader Class Initialized
INFO - 2016-11-17 22:27:16 --> Helper loaded: url_helper
INFO - 2016-11-17 22:27:16 --> Helper loaded: form_helper
INFO - 2016-11-17 22:27:16 --> Database Driver Class Initialized
INFO - 2016-11-17 22:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:27:16 --> Controller Class Initialized
INFO - 2016-11-17 22:27:16 --> Model Class Initialized
INFO - 2016-11-17 22:27:16 --> Config Class Initialized
INFO - 2016-11-17 22:27:16 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:27:16 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:27:16 --> Utf8 Class Initialized
INFO - 2016-11-17 22:27:16 --> URI Class Initialized
INFO - 2016-11-17 22:27:16 --> Router Class Initialized
INFO - 2016-11-17 22:27:16 --> Output Class Initialized
INFO - 2016-11-17 22:27:16 --> Security Class Initialized
DEBUG - 2016-11-17 22:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:27:16 --> Input Class Initialized
INFO - 2016-11-17 22:27:16 --> Language Class Initialized
INFO - 2016-11-17 22:27:16 --> Loader Class Initialized
INFO - 2016-11-17 22:27:16 --> Helper loaded: url_helper
INFO - 2016-11-17 22:27:16 --> Helper loaded: form_helper
INFO - 2016-11-17 22:27:16 --> Config Class Initialized
INFO - 2016-11-17 22:27:16 --> Database Driver Class Initialized
INFO - 2016-11-17 22:27:16 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:27:16 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:27:16 --> Utf8 Class Initialized
INFO - 2016-11-17 22:27:16 --> Controller Class Initialized
INFO - 2016-11-17 22:27:16 --> URI Class Initialized
INFO - 2016-11-17 22:27:16 --> Model Class Initialized
INFO - 2016-11-17 22:27:16 --> Router Class Initialized
INFO - 2016-11-17 22:27:16 --> Output Class Initialized
INFO - 2016-11-17 22:27:16 --> Security Class Initialized
DEBUG - 2016-11-17 22:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:27:16 --> Input Class Initialized
INFO - 2016-11-17 22:27:16 --> Language Class Initialized
INFO - 2016-11-17 22:27:16 --> Loader Class Initialized
INFO - 2016-11-17 22:27:16 --> Helper loaded: url_helper
INFO - 2016-11-17 22:27:16 --> Helper loaded: form_helper
INFO - 2016-11-17 22:27:16 --> Database Driver Class Initialized
INFO - 2016-11-17 22:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:27:16 --> Controller Class Initialized
INFO - 2016-11-17 22:27:16 --> Model Class Initialized
INFO - 2016-11-17 22:27:17 --> Config Class Initialized
INFO - 2016-11-17 22:27:17 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:27:17 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:27:17 --> Utf8 Class Initialized
INFO - 2016-11-17 22:27:17 --> URI Class Initialized
DEBUG - 2016-11-17 22:27:17 --> No URI present. Default controller set.
INFO - 2016-11-17 22:27:17 --> Router Class Initialized
INFO - 2016-11-17 22:27:17 --> Output Class Initialized
INFO - 2016-11-17 22:27:17 --> Security Class Initialized
DEBUG - 2016-11-17 22:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:27:17 --> Input Class Initialized
INFO - 2016-11-17 22:27:17 --> Language Class Initialized
INFO - 2016-11-17 22:27:17 --> Loader Class Initialized
INFO - 2016-11-17 22:27:17 --> Helper loaded: url_helper
INFO - 2016-11-17 22:27:17 --> Helper loaded: form_helper
INFO - 2016-11-17 22:27:18 --> Database Driver Class Initialized
INFO - 2016-11-17 22:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:27:18 --> Controller Class Initialized
INFO - 2016-11-17 22:27:18 --> Model Class Initialized
INFO - 2016-11-17 22:27:18 --> Model Class Initialized
INFO - 2016-11-17 22:27:18 --> Model Class Initialized
INFO - 2016-11-17 22:27:18 --> Model Class Initialized
INFO - 2016-11-17 22:27:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:27:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:27:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:27:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 22:27:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 22:27:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 22:27:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 22:27:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 22:27:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:27:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 22:27:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:27:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:27:18 --> Final output sent to browser
DEBUG - 2016-11-17 22:27:18 --> Total execution time: 0.6552
INFO - 2016-11-17 22:27:26 --> Config Class Initialized
INFO - 2016-11-17 22:27:26 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:27:26 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:27:27 --> Utf8 Class Initialized
INFO - 2016-11-17 22:27:27 --> URI Class Initialized
INFO - 2016-11-17 22:27:27 --> Router Class Initialized
INFO - 2016-11-17 22:27:27 --> Output Class Initialized
INFO - 2016-11-17 22:27:27 --> Security Class Initialized
DEBUG - 2016-11-17 22:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:27:27 --> Input Class Initialized
INFO - 2016-11-17 22:27:27 --> Language Class Initialized
INFO - 2016-11-17 22:27:27 --> Loader Class Initialized
INFO - 2016-11-17 22:27:27 --> Helper loaded: url_helper
INFO - 2016-11-17 22:27:27 --> Helper loaded: form_helper
INFO - 2016-11-17 22:27:27 --> Database Driver Class Initialized
INFO - 2016-11-17 22:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:27:27 --> Controller Class Initialized
INFO - 2016-11-17 22:27:27 --> Model Class Initialized
INFO - 2016-11-17 22:27:28 --> Config Class Initialized
INFO - 2016-11-17 22:27:28 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:27:28 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:27:28 --> Utf8 Class Initialized
INFO - 2016-11-17 22:27:28 --> URI Class Initialized
INFO - 2016-11-17 22:27:28 --> Router Class Initialized
INFO - 2016-11-17 22:27:28 --> Output Class Initialized
INFO - 2016-11-17 22:27:28 --> Security Class Initialized
DEBUG - 2016-11-17 22:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:27:28 --> Input Class Initialized
INFO - 2016-11-17 22:27:28 --> Config Class Initialized
INFO - 2016-11-17 22:27:28 --> Language Class Initialized
INFO - 2016-11-17 22:27:28 --> Hooks Class Initialized
INFO - 2016-11-17 22:27:28 --> Loader Class Initialized
DEBUG - 2016-11-17 22:27:28 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:27:28 --> Helper loaded: url_helper
INFO - 2016-11-17 22:27:28 --> Utf8 Class Initialized
INFO - 2016-11-17 22:27:28 --> Helper loaded: form_helper
INFO - 2016-11-17 22:27:28 --> URI Class Initialized
INFO - 2016-11-17 22:27:28 --> Router Class Initialized
INFO - 2016-11-17 22:27:29 --> Database Driver Class Initialized
INFO - 2016-11-17 22:27:29 --> Output Class Initialized
INFO - 2016-11-17 22:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:27:29 --> Config Class Initialized
INFO - 2016-11-17 22:27:29 --> Security Class Initialized
INFO - 2016-11-17 22:27:29 --> Hooks Class Initialized
INFO - 2016-11-17 22:27:29 --> Controller Class Initialized
INFO - 2016-11-17 22:27:29 --> Model Class Initialized
DEBUG - 2016-11-17 22:27:29 --> UTF-8 Support Enabled
DEBUG - 2016-11-17 22:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:27:29 --> Input Class Initialized
INFO - 2016-11-17 22:27:29 --> Utf8 Class Initialized
INFO - 2016-11-17 22:27:29 --> Language Class Initialized
INFO - 2016-11-17 22:27:29 --> URI Class Initialized
INFO - 2016-11-17 22:27:29 --> Loader Class Initialized
INFO - 2016-11-17 22:27:29 --> Router Class Initialized
INFO - 2016-11-17 22:27:29 --> Helper loaded: url_helper
INFO - 2016-11-17 22:27:29 --> Output Class Initialized
INFO - 2016-11-17 22:27:29 --> Config Class Initialized
INFO - 2016-11-17 22:27:29 --> Helper loaded: form_helper
INFO - 2016-11-17 22:27:29 --> Hooks Class Initialized
INFO - 2016-11-17 22:27:29 --> Security Class Initialized
INFO - 2016-11-17 22:27:29 --> Database Driver Class Initialized
DEBUG - 2016-11-17 22:27:29 --> UTF-8 Support Enabled
DEBUG - 2016-11-17 22:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:27:29 --> Utf8 Class Initialized
INFO - 2016-11-17 22:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:27:29 --> Input Class Initialized
INFO - 2016-11-17 22:27:29 --> URI Class Initialized
INFO - 2016-11-17 22:27:29 --> Controller Class Initialized
INFO - 2016-11-17 22:27:29 --> Language Class Initialized
INFO - 2016-11-17 22:27:29 --> Model Class Initialized
INFO - 2016-11-17 22:27:29 --> Router Class Initialized
INFO - 2016-11-17 22:27:29 --> Loader Class Initialized
INFO - 2016-11-17 22:27:29 --> Output Class Initialized
INFO - 2016-11-17 22:27:29 --> Config Class Initialized
INFO - 2016-11-17 22:27:29 --> Helper loaded: url_helper
INFO - 2016-11-17 22:27:29 --> Hooks Class Initialized
INFO - 2016-11-17 22:27:29 --> Security Class Initialized
INFO - 2016-11-17 22:27:29 --> Helper loaded: form_helper
DEBUG - 2016-11-17 22:27:29 --> UTF-8 Support Enabled
DEBUG - 2016-11-17 22:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:27:29 --> Utf8 Class Initialized
INFO - 2016-11-17 22:27:29 --> Database Driver Class Initialized
INFO - 2016-11-17 22:27:29 --> Input Class Initialized
INFO - 2016-11-17 22:27:29 --> URI Class Initialized
INFO - 2016-11-17 22:27:29 --> Language Class Initialized
INFO - 2016-11-17 22:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:27:29 --> Loader Class Initialized
INFO - 2016-11-17 22:27:29 --> Controller Class Initialized
INFO - 2016-11-17 22:27:29 --> Router Class Initialized
INFO - 2016-11-17 22:27:29 --> Model Class Initialized
INFO - 2016-11-17 22:27:29 --> Helper loaded: url_helper
INFO - 2016-11-17 22:27:29 --> Output Class Initialized
INFO - 2016-11-17 22:27:29 --> Security Class Initialized
INFO - 2016-11-17 22:27:29 --> Helper loaded: form_helper
DEBUG - 2016-11-17 22:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:27:29 --> Database Driver Class Initialized
INFO - 2016-11-17 22:27:29 --> Input Class Initialized
INFO - 2016-11-17 22:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:27:29 --> Language Class Initialized
INFO - 2016-11-17 22:27:29 --> Controller Class Initialized
INFO - 2016-11-17 22:27:29 --> Model Class Initialized
INFO - 2016-11-17 22:27:29 --> Loader Class Initialized
INFO - 2016-11-17 22:27:29 --> Helper loaded: url_helper
INFO - 2016-11-17 22:27:29 --> Helper loaded: form_helper
INFO - 2016-11-17 22:27:29 --> Database Driver Class Initialized
INFO - 2016-11-17 22:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:27:29 --> Controller Class Initialized
INFO - 2016-11-17 22:27:29 --> Model Class Initialized
INFO - 2016-11-17 22:27:52 --> Config Class Initialized
INFO - 2016-11-17 22:27:52 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:27:52 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:27:52 --> Utf8 Class Initialized
INFO - 2016-11-17 22:27:52 --> URI Class Initialized
DEBUG - 2016-11-17 22:27:52 --> No URI present. Default controller set.
INFO - 2016-11-17 22:27:52 --> Router Class Initialized
INFO - 2016-11-17 22:27:52 --> Output Class Initialized
INFO - 2016-11-17 22:27:52 --> Security Class Initialized
DEBUG - 2016-11-17 22:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:27:52 --> Input Class Initialized
INFO - 2016-11-17 22:27:52 --> Language Class Initialized
INFO - 2016-11-17 22:27:52 --> Loader Class Initialized
INFO - 2016-11-17 22:27:52 --> Helper loaded: url_helper
INFO - 2016-11-17 22:27:52 --> Helper loaded: form_helper
INFO - 2016-11-17 22:27:52 --> Database Driver Class Initialized
INFO - 2016-11-17 22:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:27:52 --> Controller Class Initialized
INFO - 2016-11-17 22:27:52 --> Model Class Initialized
INFO - 2016-11-17 22:27:52 --> Model Class Initialized
INFO - 2016-11-17 22:27:52 --> Model Class Initialized
INFO - 2016-11-17 22:27:52 --> Model Class Initialized
INFO - 2016-11-17 22:27:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:27:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:27:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:27:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 22:27:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 22:27:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 22:27:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 22:27:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 22:27:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:27:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 22:27:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:27:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:27:52 --> Final output sent to browser
DEBUG - 2016-11-17 22:27:53 --> Total execution time: 0.6305
INFO - 2016-11-17 22:27:58 --> Config Class Initialized
INFO - 2016-11-17 22:27:58 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:27:59 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:27:59 --> Utf8 Class Initialized
INFO - 2016-11-17 22:27:59 --> URI Class Initialized
INFO - 2016-11-17 22:27:59 --> Router Class Initialized
INFO - 2016-11-17 22:27:59 --> Output Class Initialized
INFO - 2016-11-17 22:27:59 --> Security Class Initialized
DEBUG - 2016-11-17 22:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:27:59 --> Input Class Initialized
INFO - 2016-11-17 22:27:59 --> Language Class Initialized
INFO - 2016-11-17 22:27:59 --> Loader Class Initialized
INFO - 2016-11-17 22:27:59 --> Helper loaded: url_helper
INFO - 2016-11-17 22:27:59 --> Helper loaded: form_helper
INFO - 2016-11-17 22:27:59 --> Database Driver Class Initialized
INFO - 2016-11-17 22:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:27:59 --> Controller Class Initialized
INFO - 2016-11-17 22:27:59 --> Model Class Initialized
INFO - 2016-11-17 22:27:59 --> Form Validation Class Initialized
INFO - 2016-11-17 22:27:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:27:59 --> Final output sent to browser
DEBUG - 2016-11-17 22:27:59 --> Total execution time: 0.3815
INFO - 2016-11-17 22:28:30 --> Config Class Initialized
INFO - 2016-11-17 22:28:30 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:28:30 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:28:30 --> Utf8 Class Initialized
INFO - 2016-11-17 22:28:30 --> URI Class Initialized
DEBUG - 2016-11-17 22:28:31 --> No URI present. Default controller set.
INFO - 2016-11-17 22:28:31 --> Router Class Initialized
INFO - 2016-11-17 22:28:31 --> Output Class Initialized
INFO - 2016-11-17 22:28:31 --> Security Class Initialized
DEBUG - 2016-11-17 22:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:28:31 --> Input Class Initialized
INFO - 2016-11-17 22:28:31 --> Language Class Initialized
INFO - 2016-11-17 22:28:31 --> Loader Class Initialized
INFO - 2016-11-17 22:28:31 --> Helper loaded: url_helper
INFO - 2016-11-17 22:28:31 --> Helper loaded: form_helper
INFO - 2016-11-17 22:28:31 --> Database Driver Class Initialized
INFO - 2016-11-17 22:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:28:31 --> Controller Class Initialized
INFO - 2016-11-17 22:28:31 --> Model Class Initialized
INFO - 2016-11-17 22:28:31 --> Model Class Initialized
INFO - 2016-11-17 22:28:31 --> Model Class Initialized
INFO - 2016-11-17 22:28:31 --> Model Class Initialized
INFO - 2016-11-17 22:28:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:28:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:28:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:28:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 22:28:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 22:28:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 22:28:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 22:28:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 22:28:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:28:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 22:28:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:28:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:28:31 --> Final output sent to browser
DEBUG - 2016-11-17 22:28:31 --> Total execution time: 0.5981
INFO - 2016-11-17 22:28:35 --> Config Class Initialized
INFO - 2016-11-17 22:28:35 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:28:35 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:28:35 --> Utf8 Class Initialized
INFO - 2016-11-17 22:28:35 --> URI Class Initialized
INFO - 2016-11-17 22:28:36 --> Router Class Initialized
INFO - 2016-11-17 22:28:36 --> Output Class Initialized
INFO - 2016-11-17 22:28:36 --> Security Class Initialized
DEBUG - 2016-11-17 22:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:28:36 --> Input Class Initialized
INFO - 2016-11-17 22:28:36 --> Language Class Initialized
INFO - 2016-11-17 22:28:36 --> Loader Class Initialized
INFO - 2016-11-17 22:28:36 --> Helper loaded: url_helper
INFO - 2016-11-17 22:28:36 --> Helper loaded: form_helper
INFO - 2016-11-17 22:28:36 --> Database Driver Class Initialized
INFO - 2016-11-17 22:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:28:36 --> Controller Class Initialized
INFO - 2016-11-17 22:28:36 --> Model Class Initialized
INFO - 2016-11-17 22:28:36 --> Form Validation Class Initialized
INFO - 2016-11-17 22:28:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:28:36 --> Final output sent to browser
DEBUG - 2016-11-17 22:28:36 --> Total execution time: 0.3341
INFO - 2016-11-17 22:28:38 --> Config Class Initialized
INFO - 2016-11-17 22:28:38 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:28:38 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:28:38 --> Utf8 Class Initialized
INFO - 2016-11-17 22:28:38 --> URI Class Initialized
INFO - 2016-11-17 22:28:38 --> Router Class Initialized
INFO - 2016-11-17 22:28:38 --> Output Class Initialized
INFO - 2016-11-17 22:28:38 --> Security Class Initialized
DEBUG - 2016-11-17 22:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:28:38 --> Input Class Initialized
INFO - 2016-11-17 22:28:38 --> Language Class Initialized
INFO - 2016-11-17 22:28:38 --> Loader Class Initialized
INFO - 2016-11-17 22:28:38 --> Helper loaded: url_helper
INFO - 2016-11-17 22:28:38 --> Helper loaded: form_helper
INFO - 2016-11-17 22:28:38 --> Database Driver Class Initialized
INFO - 2016-11-17 22:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:28:38 --> Controller Class Initialized
INFO - 2016-11-17 22:28:38 --> Model Class Initialized
INFO - 2016-11-17 22:28:38 --> Form Validation Class Initialized
INFO - 2016-11-17 22:28:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:28:38 --> Final output sent to browser
DEBUG - 2016-11-17 22:28:38 --> Total execution time: 0.4183
INFO - 2016-11-17 22:28:39 --> Config Class Initialized
INFO - 2016-11-17 22:28:39 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:28:39 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:28:39 --> Utf8 Class Initialized
INFO - 2016-11-17 22:28:39 --> URI Class Initialized
INFO - 2016-11-17 22:28:39 --> Router Class Initialized
INFO - 2016-11-17 22:28:39 --> Output Class Initialized
INFO - 2016-11-17 22:28:39 --> Security Class Initialized
DEBUG - 2016-11-17 22:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:28:39 --> Input Class Initialized
INFO - 2016-11-17 22:28:39 --> Language Class Initialized
INFO - 2016-11-17 22:28:39 --> Loader Class Initialized
INFO - 2016-11-17 22:28:39 --> Helper loaded: url_helper
INFO - 2016-11-17 22:28:39 --> Helper loaded: form_helper
INFO - 2016-11-17 22:28:39 --> Database Driver Class Initialized
INFO - 2016-11-17 22:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:28:39 --> Controller Class Initialized
INFO - 2016-11-17 22:28:39 --> Model Class Initialized
INFO - 2016-11-17 22:28:39 --> Form Validation Class Initialized
INFO - 2016-11-17 22:28:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:28:39 --> Final output sent to browser
DEBUG - 2016-11-17 22:28:39 --> Total execution time: 0.3911
INFO - 2016-11-17 22:28:56 --> Config Class Initialized
INFO - 2016-11-17 22:28:56 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:28:56 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:28:56 --> Utf8 Class Initialized
INFO - 2016-11-17 22:28:56 --> URI Class Initialized
DEBUG - 2016-11-17 22:28:56 --> No URI present. Default controller set.
INFO - 2016-11-17 22:28:56 --> Router Class Initialized
INFO - 2016-11-17 22:28:56 --> Output Class Initialized
INFO - 2016-11-17 22:28:56 --> Security Class Initialized
DEBUG - 2016-11-17 22:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:28:56 --> Input Class Initialized
INFO - 2016-11-17 22:28:56 --> Language Class Initialized
INFO - 2016-11-17 22:28:56 --> Loader Class Initialized
INFO - 2016-11-17 22:28:56 --> Helper loaded: url_helper
INFO - 2016-11-17 22:28:56 --> Helper loaded: form_helper
INFO - 2016-11-17 22:28:56 --> Database Driver Class Initialized
INFO - 2016-11-17 22:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:28:56 --> Controller Class Initialized
INFO - 2016-11-17 22:28:56 --> Model Class Initialized
INFO - 2016-11-17 22:28:56 --> Model Class Initialized
INFO - 2016-11-17 22:28:56 --> Model Class Initialized
INFO - 2016-11-17 22:28:56 --> Model Class Initialized
INFO - 2016-11-17 22:28:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:28:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:28:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:28:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 22:28:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 22:28:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 22:28:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 22:28:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 22:28:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:28:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 22:28:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:28:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:28:57 --> Final output sent to browser
DEBUG - 2016-11-17 22:28:57 --> Total execution time: 0.6799
INFO - 2016-11-17 22:29:02 --> Config Class Initialized
INFO - 2016-11-17 22:29:02 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:29:02 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:29:02 --> Utf8 Class Initialized
INFO - 2016-11-17 22:29:02 --> URI Class Initialized
INFO - 2016-11-17 22:29:02 --> Router Class Initialized
INFO - 2016-11-17 22:29:02 --> Output Class Initialized
INFO - 2016-11-17 22:29:02 --> Security Class Initialized
DEBUG - 2016-11-17 22:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:29:02 --> Input Class Initialized
INFO - 2016-11-17 22:29:02 --> Language Class Initialized
INFO - 2016-11-17 22:29:02 --> Loader Class Initialized
INFO - 2016-11-17 22:29:02 --> Helper loaded: url_helper
INFO - 2016-11-17 22:29:02 --> Helper loaded: form_helper
INFO - 2016-11-17 22:29:02 --> Database Driver Class Initialized
INFO - 2016-11-17 22:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:29:02 --> Controller Class Initialized
INFO - 2016-11-17 22:29:02 --> Model Class Initialized
INFO - 2016-11-17 22:29:02 --> Form Validation Class Initialized
INFO - 2016-11-17 22:29:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:29:02 --> Final output sent to browser
DEBUG - 2016-11-17 22:29:02 --> Total execution time: 0.3346
INFO - 2016-11-17 22:29:15 --> Config Class Initialized
INFO - 2016-11-17 22:29:15 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:29:15 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:29:15 --> Utf8 Class Initialized
INFO - 2016-11-17 22:29:15 --> URI Class Initialized
INFO - 2016-11-17 22:29:15 --> Router Class Initialized
INFO - 2016-11-17 22:29:15 --> Output Class Initialized
INFO - 2016-11-17 22:29:15 --> Security Class Initialized
DEBUG - 2016-11-17 22:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:29:15 --> Input Class Initialized
INFO - 2016-11-17 22:29:15 --> Language Class Initialized
INFO - 2016-11-17 22:29:15 --> Loader Class Initialized
INFO - 2016-11-17 22:29:15 --> Helper loaded: url_helper
INFO - 2016-11-17 22:29:15 --> Helper loaded: form_helper
INFO - 2016-11-17 22:29:15 --> Database Driver Class Initialized
INFO - 2016-11-17 22:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:29:15 --> Controller Class Initialized
INFO - 2016-11-17 22:29:15 --> Model Class Initialized
INFO - 2016-11-17 22:29:15 --> Form Validation Class Initialized
INFO - 2016-11-17 22:29:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:29:15 --> Final output sent to browser
DEBUG - 2016-11-17 22:29:15 --> Total execution time: 0.3797
INFO - 2016-11-17 22:29:22 --> Config Class Initialized
INFO - 2016-11-17 22:29:22 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:29:22 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:29:22 --> Utf8 Class Initialized
INFO - 2016-11-17 22:29:22 --> URI Class Initialized
INFO - 2016-11-17 22:29:22 --> Router Class Initialized
INFO - 2016-11-17 22:29:22 --> Output Class Initialized
INFO - 2016-11-17 22:29:22 --> Security Class Initialized
DEBUG - 2016-11-17 22:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:29:23 --> Input Class Initialized
INFO - 2016-11-17 22:29:23 --> Language Class Initialized
INFO - 2016-11-17 22:29:23 --> Loader Class Initialized
INFO - 2016-11-17 22:29:23 --> Helper loaded: url_helper
INFO - 2016-11-17 22:29:23 --> Helper loaded: form_helper
INFO - 2016-11-17 22:29:23 --> Database Driver Class Initialized
INFO - 2016-11-17 22:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:29:23 --> Controller Class Initialized
INFO - 2016-11-17 22:29:23 --> Model Class Initialized
INFO - 2016-11-17 22:29:23 --> Form Validation Class Initialized
INFO - 2016-11-17 22:29:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:29:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:29:23 --> Final output sent to browser
DEBUG - 2016-11-17 22:29:23 --> Total execution time: 0.5211
INFO - 2016-11-17 22:29:24 --> Config Class Initialized
INFO - 2016-11-17 22:29:24 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:29:24 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:29:24 --> Utf8 Class Initialized
INFO - 2016-11-17 22:29:24 --> URI Class Initialized
INFO - 2016-11-17 22:29:24 --> Router Class Initialized
INFO - 2016-11-17 22:29:24 --> Output Class Initialized
INFO - 2016-11-17 22:29:24 --> Security Class Initialized
DEBUG - 2016-11-17 22:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:29:24 --> Input Class Initialized
INFO - 2016-11-17 22:29:24 --> Language Class Initialized
INFO - 2016-11-17 22:29:24 --> Loader Class Initialized
INFO - 2016-11-17 22:29:24 --> Helper loaded: url_helper
INFO - 2016-11-17 22:29:24 --> Helper loaded: form_helper
INFO - 2016-11-17 22:29:24 --> Database Driver Class Initialized
INFO - 2016-11-17 22:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:29:24 --> Controller Class Initialized
INFO - 2016-11-17 22:29:24 --> Model Class Initialized
INFO - 2016-11-17 22:29:24 --> Form Validation Class Initialized
INFO - 2016-11-17 22:29:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:29:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:29:25 --> Final output sent to browser
DEBUG - 2016-11-17 22:29:25 --> Total execution time: 0.4744
INFO - 2016-11-17 22:29:29 --> Config Class Initialized
INFO - 2016-11-17 22:29:29 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:29:29 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:29:29 --> Utf8 Class Initialized
INFO - 2016-11-17 22:29:29 --> URI Class Initialized
DEBUG - 2016-11-17 22:29:29 --> No URI present. Default controller set.
INFO - 2016-11-17 22:29:29 --> Router Class Initialized
INFO - 2016-11-17 22:29:29 --> Output Class Initialized
INFO - 2016-11-17 22:29:29 --> Security Class Initialized
DEBUG - 2016-11-17 22:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:29:29 --> Input Class Initialized
INFO - 2016-11-17 22:29:29 --> Language Class Initialized
INFO - 2016-11-17 22:29:29 --> Loader Class Initialized
INFO - 2016-11-17 22:29:29 --> Helper loaded: url_helper
INFO - 2016-11-17 22:29:29 --> Helper loaded: form_helper
INFO - 2016-11-17 22:29:29 --> Database Driver Class Initialized
INFO - 2016-11-17 22:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:29:29 --> Controller Class Initialized
INFO - 2016-11-17 22:29:29 --> Model Class Initialized
INFO - 2016-11-17 22:29:29 --> Model Class Initialized
INFO - 2016-11-17 22:29:29 --> Model Class Initialized
INFO - 2016-11-17 22:29:29 --> Model Class Initialized
INFO - 2016-11-17 22:29:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:29:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:29:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:29:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 22:29:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 22:29:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 22:29:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 22:29:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 22:29:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:29:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 22:29:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:29:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:29:30 --> Final output sent to browser
DEBUG - 2016-11-17 22:29:30 --> Total execution time: 0.6241
INFO - 2016-11-17 22:29:57 --> Config Class Initialized
INFO - 2016-11-17 22:29:57 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:29:57 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:29:57 --> Utf8 Class Initialized
INFO - 2016-11-17 22:29:57 --> URI Class Initialized
INFO - 2016-11-17 22:29:57 --> Router Class Initialized
INFO - 2016-11-17 22:29:58 --> Output Class Initialized
INFO - 2016-11-17 22:29:58 --> Security Class Initialized
DEBUG - 2016-11-17 22:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:29:58 --> Input Class Initialized
INFO - 2016-11-17 22:29:58 --> Language Class Initialized
INFO - 2016-11-17 22:29:58 --> Loader Class Initialized
INFO - 2016-11-17 22:29:58 --> Helper loaded: url_helper
INFO - 2016-11-17 22:29:58 --> Helper loaded: form_helper
INFO - 2016-11-17 22:29:58 --> Database Driver Class Initialized
INFO - 2016-11-17 22:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:29:58 --> Controller Class Initialized
INFO - 2016-11-17 22:29:58 --> Model Class Initialized
INFO - 2016-11-17 22:29:58 --> Form Validation Class Initialized
INFO - 2016-11-17 22:29:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:29:58 --> Final output sent to browser
DEBUG - 2016-11-17 22:29:58 --> Total execution time: 0.3552
INFO - 2016-11-17 22:30:08 --> Config Class Initialized
INFO - 2016-11-17 22:30:08 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:30:08 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:30:08 --> Utf8 Class Initialized
INFO - 2016-11-17 22:30:08 --> URI Class Initialized
INFO - 2016-11-17 22:30:08 --> Router Class Initialized
INFO - 2016-11-17 22:30:08 --> Output Class Initialized
INFO - 2016-11-17 22:30:08 --> Security Class Initialized
DEBUG - 2016-11-17 22:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:30:08 --> Input Class Initialized
INFO - 2016-11-17 22:30:08 --> Language Class Initialized
INFO - 2016-11-17 22:30:08 --> Loader Class Initialized
INFO - 2016-11-17 22:30:08 --> Helper loaded: url_helper
INFO - 2016-11-17 22:30:08 --> Helper loaded: form_helper
INFO - 2016-11-17 22:30:08 --> Database Driver Class Initialized
INFO - 2016-11-17 22:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:30:08 --> Controller Class Initialized
INFO - 2016-11-17 22:30:08 --> Model Class Initialized
INFO - 2016-11-17 22:30:08 --> Form Validation Class Initialized
INFO - 2016-11-17 22:30:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:30:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:30:08 --> Final output sent to browser
DEBUG - 2016-11-17 22:30:08 --> Total execution time: 0.4918
INFO - 2016-11-17 22:30:10 --> Config Class Initialized
INFO - 2016-11-17 22:30:10 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:30:10 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:30:10 --> Utf8 Class Initialized
INFO - 2016-11-17 22:30:10 --> URI Class Initialized
INFO - 2016-11-17 22:30:10 --> Router Class Initialized
INFO - 2016-11-17 22:30:10 --> Output Class Initialized
INFO - 2016-11-17 22:30:10 --> Security Class Initialized
DEBUG - 2016-11-17 22:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:30:10 --> Input Class Initialized
INFO - 2016-11-17 22:30:10 --> Language Class Initialized
INFO - 2016-11-17 22:30:10 --> Loader Class Initialized
INFO - 2016-11-17 22:30:10 --> Helper loaded: url_helper
INFO - 2016-11-17 22:30:10 --> Helper loaded: form_helper
INFO - 2016-11-17 22:30:11 --> Database Driver Class Initialized
INFO - 2016-11-17 22:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:30:11 --> Controller Class Initialized
INFO - 2016-11-17 22:30:11 --> Model Class Initialized
INFO - 2016-11-17 22:30:11 --> Form Validation Class Initialized
INFO - 2016-11-17 22:30:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:30:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:30:11 --> Final output sent to browser
DEBUG - 2016-11-17 22:30:11 --> Total execution time: 0.4106
INFO - 2016-11-17 22:30:12 --> Config Class Initialized
INFO - 2016-11-17 22:30:12 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:30:12 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:30:12 --> Utf8 Class Initialized
INFO - 2016-11-17 22:30:12 --> URI Class Initialized
INFO - 2016-11-17 22:30:12 --> Router Class Initialized
INFO - 2016-11-17 22:30:12 --> Output Class Initialized
INFO - 2016-11-17 22:30:12 --> Security Class Initialized
DEBUG - 2016-11-17 22:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:30:12 --> Input Class Initialized
INFO - 2016-11-17 22:30:12 --> Language Class Initialized
INFO - 2016-11-17 22:30:12 --> Loader Class Initialized
INFO - 2016-11-17 22:30:12 --> Helper loaded: url_helper
INFO - 2016-11-17 22:30:12 --> Helper loaded: form_helper
INFO - 2016-11-17 22:30:12 --> Database Driver Class Initialized
INFO - 2016-11-17 22:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:30:12 --> Controller Class Initialized
INFO - 2016-11-17 22:30:12 --> Model Class Initialized
INFO - 2016-11-17 22:30:12 --> Form Validation Class Initialized
INFO - 2016-11-17 22:30:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:30:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:30:12 --> Final output sent to browser
DEBUG - 2016-11-17 22:30:12 --> Total execution time: 0.4951
INFO - 2016-11-17 22:30:13 --> Config Class Initialized
INFO - 2016-11-17 22:30:13 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:30:13 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:30:13 --> Utf8 Class Initialized
INFO - 2016-11-17 22:30:13 --> URI Class Initialized
INFO - 2016-11-17 22:30:13 --> Router Class Initialized
INFO - 2016-11-17 22:30:13 --> Output Class Initialized
INFO - 2016-11-17 22:30:13 --> Security Class Initialized
DEBUG - 2016-11-17 22:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:30:13 --> Input Class Initialized
INFO - 2016-11-17 22:30:13 --> Language Class Initialized
INFO - 2016-11-17 22:30:13 --> Loader Class Initialized
INFO - 2016-11-17 22:30:13 --> Helper loaded: url_helper
INFO - 2016-11-17 22:30:13 --> Helper loaded: form_helper
INFO - 2016-11-17 22:30:13 --> Database Driver Class Initialized
INFO - 2016-11-17 22:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:30:13 --> Controller Class Initialized
INFO - 2016-11-17 22:30:13 --> Model Class Initialized
INFO - 2016-11-17 22:30:13 --> Form Validation Class Initialized
INFO - 2016-11-17 22:30:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:30:13 --> Config Class Initialized
INFO - 2016-11-17 22:30:13 --> Hooks Class Initialized
INFO - 2016-11-17 22:30:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
DEBUG - 2016-11-17 22:30:13 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:30:13 --> Final output sent to browser
INFO - 2016-11-17 22:30:13 --> Utf8 Class Initialized
DEBUG - 2016-11-17 22:30:13 --> Total execution time: 0.4900
INFO - 2016-11-17 22:30:13 --> URI Class Initialized
INFO - 2016-11-17 22:30:13 --> Router Class Initialized
INFO - 2016-11-17 22:30:13 --> Output Class Initialized
INFO - 2016-11-17 22:30:13 --> Security Class Initialized
DEBUG - 2016-11-17 22:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:30:13 --> Input Class Initialized
INFO - 2016-11-17 22:30:13 --> Language Class Initialized
INFO - 2016-11-17 22:30:13 --> Loader Class Initialized
INFO - 2016-11-17 22:30:13 --> Helper loaded: url_helper
INFO - 2016-11-17 22:30:13 --> Helper loaded: form_helper
INFO - 2016-11-17 22:30:13 --> Config Class Initialized
INFO - 2016-11-17 22:30:13 --> Database Driver Class Initialized
INFO - 2016-11-17 22:30:13 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:30:13 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:30:14 --> Utf8 Class Initialized
INFO - 2016-11-17 22:30:14 --> Controller Class Initialized
INFO - 2016-11-17 22:30:14 --> URI Class Initialized
INFO - 2016-11-17 22:30:14 --> Model Class Initialized
INFO - 2016-11-17 22:30:14 --> Router Class Initialized
INFO - 2016-11-17 22:30:14 --> Form Validation Class Initialized
INFO - 2016-11-17 22:30:14 --> Output Class Initialized
INFO - 2016-11-17 22:30:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:30:14 --> Security Class Initialized
DEBUG - 2016-11-17 22:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:30:14 --> Input Class Initialized
INFO - 2016-11-17 22:30:14 --> Language Class Initialized
INFO - 2016-11-17 22:30:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:30:14 --> Loader Class Initialized
INFO - 2016-11-17 22:30:14 --> Final output sent to browser
INFO - 2016-11-17 22:30:14 --> Config Class Initialized
INFO - 2016-11-17 22:30:14 --> Helper loaded: url_helper
DEBUG - 2016-11-17 22:30:14 --> Total execution time: 0.5370
INFO - 2016-11-17 22:30:14 --> Hooks Class Initialized
INFO - 2016-11-17 22:30:14 --> Helper loaded: form_helper
DEBUG - 2016-11-17 22:30:14 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:30:14 --> Database Driver Class Initialized
INFO - 2016-11-17 22:30:14 --> Utf8 Class Initialized
INFO - 2016-11-17 22:30:14 --> URI Class Initialized
INFO - 2016-11-17 22:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:30:14 --> Controller Class Initialized
INFO - 2016-11-17 22:30:14 --> Router Class Initialized
INFO - 2016-11-17 22:30:14 --> Model Class Initialized
INFO - 2016-11-17 22:30:14 --> Output Class Initialized
INFO - 2016-11-17 22:30:14 --> Form Validation Class Initialized
INFO - 2016-11-17 22:30:14 --> Security Class Initialized
INFO - 2016-11-17 22:30:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:30:14 --> Config Class Initialized
DEBUG - 2016-11-17 22:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:30:14 --> Input Class Initialized
INFO - 2016-11-17 22:30:14 --> Hooks Class Initialized
INFO - 2016-11-17 22:30:14 --> Language Class Initialized
DEBUG - 2016-11-17 22:30:14 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:30:14 --> Loader Class Initialized
INFO - 2016-11-17 22:30:14 --> Utf8 Class Initialized
INFO - 2016-11-17 22:30:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:30:14 --> URI Class Initialized
INFO - 2016-11-17 22:30:14 --> Helper loaded: url_helper
INFO - 2016-11-17 22:30:14 --> Final output sent to browser
INFO - 2016-11-17 22:30:14 --> Helper loaded: form_helper
INFO - 2016-11-17 22:30:14 --> Router Class Initialized
DEBUG - 2016-11-17 22:30:14 --> Total execution time: 0.5644
INFO - 2016-11-17 22:30:14 --> Output Class Initialized
INFO - 2016-11-17 22:30:14 --> Database Driver Class Initialized
INFO - 2016-11-17 22:30:14 --> Security Class Initialized
INFO - 2016-11-17 22:30:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-17 22:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:30:14 --> Controller Class Initialized
INFO - 2016-11-17 22:30:14 --> Config Class Initialized
INFO - 2016-11-17 22:30:14 --> Input Class Initialized
INFO - 2016-11-17 22:30:14 --> Hooks Class Initialized
INFO - 2016-11-17 22:30:14 --> Model Class Initialized
INFO - 2016-11-17 22:30:14 --> Language Class Initialized
DEBUG - 2016-11-17 22:30:14 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:30:14 --> Form Validation Class Initialized
INFO - 2016-11-17 22:30:14 --> Loader Class Initialized
INFO - 2016-11-17 22:30:14 --> Utf8 Class Initialized
INFO - 2016-11-17 22:30:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:30:14 --> URI Class Initialized
INFO - 2016-11-17 22:30:14 --> Helper loaded: url_helper
INFO - 2016-11-17 22:30:14 --> Helper loaded: form_helper
INFO - 2016-11-17 22:30:14 --> Router Class Initialized
INFO - 2016-11-17 22:30:14 --> Output Class Initialized
INFO - 2016-11-17 22:30:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:30:14 --> Database Driver Class Initialized
INFO - 2016-11-17 22:30:14 --> Security Class Initialized
INFO - 2016-11-17 22:30:14 --> Final output sent to browser
INFO - 2016-11-17 22:30:14 --> Config Class Initialized
DEBUG - 2016-11-17 22:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-17 22:30:14 --> Total execution time: 0.5815
INFO - 2016-11-17 22:30:14 --> Input Class Initialized
INFO - 2016-11-17 22:30:14 --> Hooks Class Initialized
INFO - 2016-11-17 22:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:30:14 --> Language Class Initialized
DEBUG - 2016-11-17 22:30:14 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:30:14 --> Controller Class Initialized
INFO - 2016-11-17 22:30:14 --> Utf8 Class Initialized
INFO - 2016-11-17 22:30:14 --> Loader Class Initialized
INFO - 2016-11-17 22:30:14 --> Model Class Initialized
INFO - 2016-11-17 22:30:14 --> URI Class Initialized
INFO - 2016-11-17 22:30:14 --> Helper loaded: url_helper
INFO - 2016-11-17 22:30:14 --> Form Validation Class Initialized
INFO - 2016-11-17 22:30:14 --> Router Class Initialized
INFO - 2016-11-17 22:30:14 --> Helper loaded: form_helper
INFO - 2016-11-17 22:30:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:30:14 --> Output Class Initialized
INFO - 2016-11-17 22:30:15 --> Config Class Initialized
INFO - 2016-11-17 22:30:15 --> Database Driver Class Initialized
INFO - 2016-11-17 22:30:15 --> Security Class Initialized
INFO - 2016-11-17 22:30:15 --> Hooks Class Initialized
INFO - 2016-11-17 22:30:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
DEBUG - 2016-11-17 22:30:15 --> UTF-8 Support Enabled
DEBUG - 2016-11-17 22:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:30:15 --> Final output sent to browser
INFO - 2016-11-17 22:30:15 --> Utf8 Class Initialized
INFO - 2016-11-17 22:30:15 --> Input Class Initialized
DEBUG - 2016-11-17 22:30:15 --> Total execution time: 0.6354
INFO - 2016-11-17 22:30:15 --> URI Class Initialized
INFO - 2016-11-17 22:30:15 --> Language Class Initialized
INFO - 2016-11-17 22:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:30:15 --> Router Class Initialized
INFO - 2016-11-17 22:30:15 --> Controller Class Initialized
INFO - 2016-11-17 22:30:15 --> Loader Class Initialized
INFO - 2016-11-17 22:30:15 --> Output Class Initialized
INFO - 2016-11-17 22:30:15 --> Model Class Initialized
INFO - 2016-11-17 22:30:15 --> Helper loaded: url_helper
INFO - 2016-11-17 22:30:15 --> Security Class Initialized
INFO - 2016-11-17 22:30:15 --> Form Validation Class Initialized
INFO - 2016-11-17 22:30:15 --> Helper loaded: form_helper
DEBUG - 2016-11-17 22:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:30:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:30:15 --> Database Driver Class Initialized
INFO - 2016-11-17 22:30:15 --> Input Class Initialized
INFO - 2016-11-17 22:30:15 --> Language Class Initialized
INFO - 2016-11-17 22:30:15 --> Loader Class Initialized
INFO - 2016-11-17 22:30:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:30:15 --> Helper loaded: url_helper
INFO - 2016-11-17 22:30:15 --> Final output sent to browser
INFO - 2016-11-17 22:30:15 --> Helper loaded: form_helper
DEBUG - 2016-11-17 22:30:15 --> Total execution time: 0.6919
INFO - 2016-11-17 22:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:30:15 --> Database Driver Class Initialized
INFO - 2016-11-17 22:30:15 --> Controller Class Initialized
INFO - 2016-11-17 22:30:15 --> Model Class Initialized
INFO - 2016-11-17 22:30:15 --> Form Validation Class Initialized
INFO - 2016-11-17 22:30:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:30:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:30:15 --> Final output sent to browser
DEBUG - 2016-11-17 22:30:15 --> Total execution time: 0.7292
INFO - 2016-11-17 22:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:30:15 --> Controller Class Initialized
INFO - 2016-11-17 22:30:15 --> Model Class Initialized
INFO - 2016-11-17 22:30:15 --> Form Validation Class Initialized
INFO - 2016-11-17 22:30:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:30:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:30:15 --> Final output sent to browser
DEBUG - 2016-11-17 22:30:15 --> Total execution time: 0.7092
INFO - 2016-11-17 22:30:16 --> Config Class Initialized
INFO - 2016-11-17 22:30:16 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:30:16 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:30:16 --> Utf8 Class Initialized
INFO - 2016-11-17 22:30:16 --> URI Class Initialized
DEBUG - 2016-11-17 22:30:16 --> No URI present. Default controller set.
INFO - 2016-11-17 22:30:16 --> Router Class Initialized
INFO - 2016-11-17 22:30:16 --> Output Class Initialized
INFO - 2016-11-17 22:30:16 --> Security Class Initialized
DEBUG - 2016-11-17 22:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:30:16 --> Input Class Initialized
INFO - 2016-11-17 22:30:16 --> Language Class Initialized
INFO - 2016-11-17 22:30:16 --> Loader Class Initialized
INFO - 2016-11-17 22:30:16 --> Helper loaded: url_helper
INFO - 2016-11-17 22:30:16 --> Helper loaded: form_helper
INFO - 2016-11-17 22:30:16 --> Database Driver Class Initialized
INFO - 2016-11-17 22:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:30:16 --> Controller Class Initialized
INFO - 2016-11-17 22:30:16 --> Model Class Initialized
INFO - 2016-11-17 22:30:16 --> Model Class Initialized
INFO - 2016-11-17 22:30:16 --> Model Class Initialized
INFO - 2016-11-17 22:30:16 --> Model Class Initialized
INFO - 2016-11-17 22:30:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:30:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:30:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:30:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 22:30:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 22:30:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 22:30:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 22:30:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 22:30:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:30:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 22:30:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:30:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:30:17 --> Final output sent to browser
DEBUG - 2016-11-17 22:30:17 --> Total execution time: 0.6758
INFO - 2016-11-17 22:30:47 --> Config Class Initialized
INFO - 2016-11-17 22:30:47 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:30:47 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:30:47 --> Utf8 Class Initialized
INFO - 2016-11-17 22:30:47 --> URI Class Initialized
DEBUG - 2016-11-17 22:30:47 --> No URI present. Default controller set.
INFO - 2016-11-17 22:30:47 --> Router Class Initialized
INFO - 2016-11-17 22:30:47 --> Output Class Initialized
INFO - 2016-11-17 22:30:47 --> Security Class Initialized
DEBUG - 2016-11-17 22:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:30:47 --> Input Class Initialized
INFO - 2016-11-17 22:30:48 --> Language Class Initialized
INFO - 2016-11-17 22:30:48 --> Loader Class Initialized
INFO - 2016-11-17 22:30:48 --> Helper loaded: url_helper
INFO - 2016-11-17 22:30:48 --> Helper loaded: form_helper
INFO - 2016-11-17 22:30:48 --> Database Driver Class Initialized
INFO - 2016-11-17 22:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:30:48 --> Controller Class Initialized
INFO - 2016-11-17 22:30:48 --> Model Class Initialized
INFO - 2016-11-17 22:30:48 --> Model Class Initialized
INFO - 2016-11-17 22:30:48 --> Model Class Initialized
INFO - 2016-11-17 22:30:48 --> Model Class Initialized
INFO - 2016-11-17 22:30:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:30:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:30:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:30:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 22:30:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 22:30:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 22:30:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 22:30:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 22:30:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:30:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 22:30:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:30:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:30:48 --> Final output sent to browser
DEBUG - 2016-11-17 22:30:48 --> Total execution time: 0.6123
INFO - 2016-11-17 22:31:00 --> Config Class Initialized
INFO - 2016-11-17 22:31:00 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:31:00 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:00 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:00 --> URI Class Initialized
INFO - 2016-11-17 22:31:00 --> Router Class Initialized
INFO - 2016-11-17 22:31:00 --> Output Class Initialized
INFO - 2016-11-17 22:31:00 --> Security Class Initialized
DEBUG - 2016-11-17 22:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:00 --> Input Class Initialized
INFO - 2016-11-17 22:31:00 --> Language Class Initialized
INFO - 2016-11-17 22:31:00 --> Loader Class Initialized
INFO - 2016-11-17 22:31:00 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:00 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:00 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:00 --> Controller Class Initialized
INFO - 2016-11-17 22:31:00 --> Model Class Initialized
INFO - 2016-11-17 22:31:00 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:00 --> Final output sent to browser
DEBUG - 2016-11-17 22:31:00 --> Total execution time: 0.4669
INFO - 2016-11-17 22:31:01 --> Config Class Initialized
INFO - 2016-11-17 22:31:01 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:31:01 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:01 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:01 --> URI Class Initialized
INFO - 2016-11-17 22:31:01 --> Router Class Initialized
INFO - 2016-11-17 22:31:01 --> Output Class Initialized
INFO - 2016-11-17 22:31:01 --> Security Class Initialized
DEBUG - 2016-11-17 22:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:01 --> Input Class Initialized
INFO - 2016-11-17 22:31:01 --> Config Class Initialized
INFO - 2016-11-17 22:31:01 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:01 --> Language Class Initialized
DEBUG - 2016-11-17 22:31:01 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:01 --> Loader Class Initialized
INFO - 2016-11-17 22:31:01 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:01 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:01 --> URI Class Initialized
INFO - 2016-11-17 22:31:01 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:01 --> Router Class Initialized
INFO - 2016-11-17 22:31:01 --> Config Class Initialized
INFO - 2016-11-17 22:31:01 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:01 --> Output Class Initialized
INFO - 2016-11-17 22:31:01 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-17 22:31:02 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:02 --> Controller Class Initialized
INFO - 2016-11-17 22:31:02 --> Security Class Initialized
INFO - 2016-11-17 22:31:02 --> Utf8 Class Initialized
DEBUG - 2016-11-17 22:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:02 --> Model Class Initialized
INFO - 2016-11-17 22:31:02 --> Input Class Initialized
INFO - 2016-11-17 22:31:02 --> URI Class Initialized
INFO - 2016-11-17 22:31:02 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:02 --> Router Class Initialized
INFO - 2016-11-17 22:31:02 --> Language Class Initialized
INFO - 2016-11-17 22:31:02 --> Config Class Initialized
INFO - 2016-11-17 22:31:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:02 --> Output Class Initialized
INFO - 2016-11-17 22:31:02 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:02 --> Loader Class Initialized
INFO - 2016-11-17 22:31:02 --> Helper loaded: url_helper
DEBUG - 2016-11-17 22:31:02 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:02 --> Security Class Initialized
INFO - 2016-11-17 22:31:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:02 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:02 --> Utf8 Class Initialized
DEBUG - 2016-11-17 22:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:02 --> Final output sent to browser
INFO - 2016-11-17 22:31:02 --> URI Class Initialized
INFO - 2016-11-17 22:31:02 --> Input Class Initialized
INFO - 2016-11-17 22:31:02 --> Database Driver Class Initialized
DEBUG - 2016-11-17 22:31:02 --> Total execution time: 0.5775
INFO - 2016-11-17 22:31:02 --> Router Class Initialized
INFO - 2016-11-17 22:31:02 --> Language Class Initialized
INFO - 2016-11-17 22:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:02 --> Config Class Initialized
INFO - 2016-11-17 22:31:02 --> Output Class Initialized
INFO - 2016-11-17 22:31:02 --> Loader Class Initialized
INFO - 2016-11-17 22:31:02 --> Controller Class Initialized
INFO - 2016-11-17 22:31:02 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:02 --> Model Class Initialized
INFO - 2016-11-17 22:31:02 --> Security Class Initialized
DEBUG - 2016-11-17 22:31:02 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:02 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:02 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:02 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:02 --> Helper loaded: form_helper
DEBUG - 2016-11-17 22:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:02 --> URI Class Initialized
INFO - 2016-11-17 22:31:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:02 --> Input Class Initialized
INFO - 2016-11-17 22:31:02 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:02 --> Router Class Initialized
INFO - 2016-11-17 22:31:02 --> Language Class Initialized
INFO - 2016-11-17 22:31:02 --> Config Class Initialized
INFO - 2016-11-17 22:31:02 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:02 --> Loader Class Initialized
INFO - 2016-11-17 22:31:02 --> Output Class Initialized
DEBUG - 2016-11-17 22:31:02 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:02 --> Final output sent to browser
INFO - 2016-11-17 22:31:02 --> Utf8 Class Initialized
DEBUG - 2016-11-17 22:31:02 --> Total execution time: 0.6669
INFO - 2016-11-17 22:31:02 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:02 --> Security Class Initialized
INFO - 2016-11-17 22:31:02 --> URI Class Initialized
INFO - 2016-11-17 22:31:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-17 22:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:02 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:02 --> Controller Class Initialized
INFO - 2016-11-17 22:31:02 --> Router Class Initialized
INFO - 2016-11-17 22:31:02 --> Config Class Initialized
INFO - 2016-11-17 22:31:02 --> Input Class Initialized
INFO - 2016-11-17 22:31:02 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:02 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:02 --> Model Class Initialized
INFO - 2016-11-17 22:31:02 --> Output Class Initialized
INFO - 2016-11-17 22:31:02 --> Language Class Initialized
INFO - 2016-11-17 22:31:02 --> Form Validation Class Initialized
DEBUG - 2016-11-17 22:31:02 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:02 --> Security Class Initialized
INFO - 2016-11-17 22:31:02 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:02 --> Loader Class Initialized
INFO - 2016-11-17 22:31:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-17 22:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:02 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:02 --> URI Class Initialized
INFO - 2016-11-17 22:31:02 --> Input Class Initialized
INFO - 2016-11-17 22:31:02 --> Language Class Initialized
INFO - 2016-11-17 22:31:02 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:02 --> Config Class Initialized
INFO - 2016-11-17 22:31:02 --> Router Class Initialized
INFO - 2016-11-17 22:31:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:02 --> Loader Class Initialized
INFO - 2016-11-17 22:31:02 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:02 --> Output Class Initialized
INFO - 2016-11-17 22:31:02 --> Database Driver Class Initialized
DEBUG - 2016-11-17 22:31:02 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:02 --> Final output sent to browser
INFO - 2016-11-17 22:31:02 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:02 --> Security Class Initialized
INFO - 2016-11-17 22:31:02 --> Utf8 Class Initialized
DEBUG - 2016-11-17 22:31:02 --> Total execution time: 0.7713
INFO - 2016-11-17 22:31:02 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:02 --> URI Class Initialized
DEBUG - 2016-11-17 22:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:02 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:02 --> Input Class Initialized
INFO - 2016-11-17 22:31:02 --> Controller Class Initialized
INFO - 2016-11-17 22:31:02 --> Config Class Initialized
INFO - 2016-11-17 22:31:02 --> Router Class Initialized
INFO - 2016-11-17 22:31:02 --> Language Class Initialized
INFO - 2016-11-17 22:31:02 --> Model Class Initialized
INFO - 2016-11-17 22:31:02 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:02 --> Output Class Initialized
DEBUG - 2016-11-17 22:31:02 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:02 --> Loader Class Initialized
INFO - 2016-11-17 22:31:02 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:02 --> Security Class Initialized
INFO - 2016-11-17 22:31:02 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:02 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-17 22:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:02 --> URI Class Initialized
INFO - 2016-11-17 22:31:02 --> Input Class Initialized
INFO - 2016-11-17 22:31:02 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:02 --> Router Class Initialized
INFO - 2016-11-17 22:31:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:02 --> Language Class Initialized
INFO - 2016-11-17 22:31:02 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:03 --> Output Class Initialized
INFO - 2016-11-17 22:31:03 --> Final output sent to browser
INFO - 2016-11-17 22:31:03 --> Loader Class Initialized
DEBUG - 2016-11-17 22:31:03 --> Total execution time: 0.8855
INFO - 2016-11-17 22:31:03 --> Security Class Initialized
INFO - 2016-11-17 22:31:03 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:03 --> Config Class Initialized
INFO - 2016-11-17 22:31:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-17 22:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:03 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:03 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:03 --> Input Class Initialized
INFO - 2016-11-17 22:31:03 --> Controller Class Initialized
INFO - 2016-11-17 22:31:03 --> Language Class Initialized
INFO - 2016-11-17 22:31:03 --> Model Class Initialized
DEBUG - 2016-11-17 22:31:03 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:03 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:03 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:03 --> Loader Class Initialized
INFO - 2016-11-17 22:31:03 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:03 --> URI Class Initialized
INFO - 2016-11-17 22:31:03 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:03 --> Router Class Initialized
INFO - 2016-11-17 22:31:03 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:03 --> Output Class Initialized
INFO - 2016-11-17 22:31:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:03 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:03 --> Security Class Initialized
INFO - 2016-11-17 22:31:03 --> Final output sent to browser
DEBUG - 2016-11-17 22:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-17 22:31:03 --> Total execution time: 0.9978
INFO - 2016-11-17 22:31:03 --> Input Class Initialized
INFO - 2016-11-17 22:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:03 --> Config Class Initialized
INFO - 2016-11-17 22:31:03 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:03 --> Language Class Initialized
INFO - 2016-11-17 22:31:03 --> Controller Class Initialized
INFO - 2016-11-17 22:31:03 --> Model Class Initialized
DEBUG - 2016-11-17 22:31:03 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:03 --> Loader Class Initialized
INFO - 2016-11-17 22:31:03 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:03 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:03 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:03 --> URI Class Initialized
INFO - 2016-11-17 22:31:03 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:03 --> Router Class Initialized
INFO - 2016-11-17 22:31:03 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:03 --> Output Class Initialized
INFO - 2016-11-17 22:31:03 --> Final output sent to browser
INFO - 2016-11-17 22:31:03 --> Security Class Initialized
DEBUG - 2016-11-17 22:31:03 --> Total execution time: 1.0993
INFO - 2016-11-17 22:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:03 --> Config Class Initialized
DEBUG - 2016-11-17 22:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:03 --> Controller Class Initialized
INFO - 2016-11-17 22:31:03 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:03 --> Input Class Initialized
INFO - 2016-11-17 22:31:03 --> Model Class Initialized
INFO - 2016-11-17 22:31:03 --> Language Class Initialized
DEBUG - 2016-11-17 22:31:03 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:03 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:03 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:03 --> Loader Class Initialized
INFO - 2016-11-17 22:31:03 --> URI Class Initialized
INFO - 2016-11-17 22:31:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:03 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:03 --> Router Class Initialized
INFO - 2016-11-17 22:31:03 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:03 --> Output Class Initialized
INFO - 2016-11-17 22:31:03 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:03 --> Security Class Initialized
INFO - 2016-11-17 22:31:03 --> Final output sent to browser
DEBUG - 2016-11-17 22:31:03 --> Total execution time: 1.1813
DEBUG - 2016-11-17 22:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:03 --> Config Class Initialized
INFO - 2016-11-17 22:31:03 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:03 --> Controller Class Initialized
INFO - 2016-11-17 22:31:03 --> Input Class Initialized
DEBUG - 2016-11-17 22:31:03 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:03 --> Model Class Initialized
INFO - 2016-11-17 22:31:03 --> Language Class Initialized
INFO - 2016-11-17 22:31:03 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:03 --> URI Class Initialized
INFO - 2016-11-17 22:31:03 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:03 --> Loader Class Initialized
INFO - 2016-11-17 22:31:03 --> Router Class Initialized
INFO - 2016-11-17 22:31:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:03 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:03 --> Output Class Initialized
INFO - 2016-11-17 22:31:03 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:03 --> Security Class Initialized
INFO - 2016-11-17 22:31:03 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
DEBUG - 2016-11-17 22:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:04 --> Final output sent to browser
INFO - 2016-11-17 22:31:04 --> Input Class Initialized
DEBUG - 2016-11-17 22:31:04 --> Total execution time: 1.3072
INFO - 2016-11-17 22:31:04 --> Language Class Initialized
INFO - 2016-11-17 22:31:04 --> Config Class Initialized
INFO - 2016-11-17 22:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:04 --> Controller Class Initialized
INFO - 2016-11-17 22:31:04 --> Loader Class Initialized
INFO - 2016-11-17 22:31:04 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:04 --> Model Class Initialized
INFO - 2016-11-17 22:31:04 --> Helper loaded: url_helper
DEBUG - 2016-11-17 22:31:04 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:04 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:04 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:04 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:04 --> URI Class Initialized
INFO - 2016-11-17 22:31:04 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:04 --> Router Class Initialized
INFO - 2016-11-17 22:31:04 --> Output Class Initialized
INFO - 2016-11-17 22:31:04 --> Security Class Initialized
INFO - 2016-11-17 22:31:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
DEBUG - 2016-11-17 22:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:04 --> Final output sent to browser
INFO - 2016-11-17 22:31:04 --> Input Class Initialized
DEBUG - 2016-11-17 22:31:04 --> Total execution time: 1.4285
INFO - 2016-11-17 22:31:04 --> Language Class Initialized
INFO - 2016-11-17 22:31:04 --> Config Class Initialized
INFO - 2016-11-17 22:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:04 --> Loader Class Initialized
INFO - 2016-11-17 22:31:04 --> Controller Class Initialized
INFO - 2016-11-17 22:31:04 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:04 --> Model Class Initialized
DEBUG - 2016-11-17 22:31:04 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:04 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:04 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:04 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:04 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:04 --> URI Class Initialized
INFO - 2016-11-17 22:31:04 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:04 --> Router Class Initialized
INFO - 2016-11-17 22:31:04 --> Output Class Initialized
INFO - 2016-11-17 22:31:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:04 --> Security Class Initialized
INFO - 2016-11-17 22:31:04 --> Final output sent to browser
DEBUG - 2016-11-17 22:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-17 22:31:04 --> Total execution time: 1.4353
INFO - 2016-11-17 22:31:04 --> Input Class Initialized
INFO - 2016-11-17 22:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:04 --> Config Class Initialized
INFO - 2016-11-17 22:31:04 --> Language Class Initialized
INFO - 2016-11-17 22:31:04 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:04 --> Controller Class Initialized
INFO - 2016-11-17 22:31:04 --> Model Class Initialized
INFO - 2016-11-17 22:31:04 --> Loader Class Initialized
DEBUG - 2016-11-17 22:31:04 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:04 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:04 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:04 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:04 --> URI Class Initialized
INFO - 2016-11-17 22:31:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:04 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:04 --> Router Class Initialized
INFO - 2016-11-17 22:31:04 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:04 --> Output Class Initialized
INFO - 2016-11-17 22:31:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:04 --> Security Class Initialized
INFO - 2016-11-17 22:31:04 --> Final output sent to browser
DEBUG - 2016-11-17 22:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-17 22:31:04 --> Total execution time: 1.4404
INFO - 2016-11-17 22:31:04 --> Input Class Initialized
INFO - 2016-11-17 22:31:04 --> Config Class Initialized
INFO - 2016-11-17 22:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:04 --> Controller Class Initialized
INFO - 2016-11-17 22:31:04 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:04 --> Language Class Initialized
INFO - 2016-11-17 22:31:04 --> Model Class Initialized
DEBUG - 2016-11-17 22:31:04 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:04 --> Loader Class Initialized
INFO - 2016-11-17 22:31:04 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:04 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:04 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:04 --> URI Class Initialized
INFO - 2016-11-17 22:31:04 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:04 --> Router Class Initialized
INFO - 2016-11-17 22:31:04 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:04 --> Output Class Initialized
INFO - 2016-11-17 22:31:04 --> Security Class Initialized
INFO - 2016-11-17 22:31:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
DEBUG - 2016-11-17 22:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:05 --> Final output sent to browser
INFO - 2016-11-17 22:31:05 --> Input Class Initialized
DEBUG - 2016-11-17 22:31:05 --> Total execution time: 1.4883
INFO - 2016-11-17 22:31:05 --> Language Class Initialized
INFO - 2016-11-17 22:31:05 --> Config Class Initialized
INFO - 2016-11-17 22:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:05 --> Loader Class Initialized
INFO - 2016-11-17 22:31:05 --> Controller Class Initialized
INFO - 2016-11-17 22:31:05 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:05 --> Model Class Initialized
DEBUG - 2016-11-17 22:31:05 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:05 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:05 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:05 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:05 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:05 --> URI Class Initialized
INFO - 2016-11-17 22:31:05 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:05 --> Router Class Initialized
INFO - 2016-11-17 22:31:05 --> Output Class Initialized
INFO - 2016-11-17 22:31:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:05 --> Security Class Initialized
INFO - 2016-11-17 22:31:05 --> Final output sent to browser
DEBUG - 2016-11-17 22:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-17 22:31:05 --> Total execution time: 1.4960
INFO - 2016-11-17 22:31:05 --> Input Class Initialized
INFO - 2016-11-17 22:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:05 --> Config Class Initialized
INFO - 2016-11-17 22:31:05 --> Controller Class Initialized
INFO - 2016-11-17 22:31:05 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:05 --> Language Class Initialized
INFO - 2016-11-17 22:31:05 --> Model Class Initialized
DEBUG - 2016-11-17 22:31:05 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:05 --> Loader Class Initialized
INFO - 2016-11-17 22:31:05 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:05 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:05 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:05 --> URI Class Initialized
INFO - 2016-11-17 22:31:05 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:05 --> Router Class Initialized
INFO - 2016-11-17 22:31:05 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:05 --> Output Class Initialized
INFO - 2016-11-17 22:31:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:05 --> Security Class Initialized
INFO - 2016-11-17 22:31:05 --> Final output sent to browser
DEBUG - 2016-11-17 22:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-17 22:31:05 --> Total execution time: 1.4934
INFO - 2016-11-17 22:31:05 --> Input Class Initialized
INFO - 2016-11-17 22:31:05 --> Config Class Initialized
INFO - 2016-11-17 22:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:05 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:05 --> Controller Class Initialized
INFO - 2016-11-17 22:31:05 --> Language Class Initialized
INFO - 2016-11-17 22:31:05 --> Model Class Initialized
DEBUG - 2016-11-17 22:31:05 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:05 --> Loader Class Initialized
INFO - 2016-11-17 22:31:05 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:05 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:05 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:05 --> URI Class Initialized
INFO - 2016-11-17 22:31:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:05 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:05 --> Router Class Initialized
INFO - 2016-11-17 22:31:05 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:05 --> Output Class Initialized
INFO - 2016-11-17 22:31:05 --> Final output sent to browser
INFO - 2016-11-17 22:31:05 --> Security Class Initialized
DEBUG - 2016-11-17 22:31:05 --> Total execution time: 1.4862
INFO - 2016-11-17 22:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:05 --> Config Class Initialized
DEBUG - 2016-11-17 22:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:05 --> Input Class Initialized
INFO - 2016-11-17 22:31:05 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:05 --> Controller Class Initialized
INFO - 2016-11-17 22:31:05 --> Language Class Initialized
DEBUG - 2016-11-17 22:31:05 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:05 --> Model Class Initialized
INFO - 2016-11-17 22:31:05 --> Loader Class Initialized
INFO - 2016-11-17 22:31:05 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:05 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:06 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:06 --> URI Class Initialized
INFO - 2016-11-17 22:31:06 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:06 --> Router Class Initialized
INFO - 2016-11-17 22:31:06 --> Output Class Initialized
INFO - 2016-11-17 22:31:06 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:06 --> Security Class Initialized
INFO - 2016-11-17 22:31:06 --> Final output sent to browser
DEBUG - 2016-11-17 22:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-17 22:31:06 --> Total execution time: 1.5432
INFO - 2016-11-17 22:31:06 --> Input Class Initialized
INFO - 2016-11-17 22:31:06 --> Config Class Initialized
INFO - 2016-11-17 22:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:06 --> Language Class Initialized
INFO - 2016-11-17 22:31:06 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:06 --> Controller Class Initialized
DEBUG - 2016-11-17 22:31:06 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:06 --> Loader Class Initialized
INFO - 2016-11-17 22:31:06 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:06 --> Model Class Initialized
INFO - 2016-11-17 22:31:06 --> URI Class Initialized
INFO - 2016-11-17 22:31:06 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:06 --> Router Class Initialized
INFO - 2016-11-17 22:31:06 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:06 --> Output Class Initialized
INFO - 2016-11-17 22:31:06 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:06 --> Security Class Initialized
INFO - 2016-11-17 22:31:06 --> Database Driver Class Initialized
DEBUG - 2016-11-17 22:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:06 --> Input Class Initialized
INFO - 2016-11-17 22:31:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:06 --> Language Class Initialized
INFO - 2016-11-17 22:31:06 --> Final output sent to browser
INFO - 2016-11-17 22:31:06 --> Loader Class Initialized
DEBUG - 2016-11-17 22:31:06 --> Total execution time: 1.6441
INFO - 2016-11-17 22:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:06 --> Config Class Initialized
INFO - 2016-11-17 22:31:06 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:06 --> Controller Class Initialized
INFO - 2016-11-17 22:31:06 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:06 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:06 --> Model Class Initialized
DEBUG - 2016-11-17 22:31:06 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:06 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:06 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:06 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:06 --> URI Class Initialized
INFO - 2016-11-17 22:31:06 --> Router Class Initialized
INFO - 2016-11-17 22:31:06 --> Output Class Initialized
INFO - 2016-11-17 22:31:06 --> Security Class Initialized
DEBUG - 2016-11-17 22:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:06 --> Input Class Initialized
INFO - 2016-11-17 22:31:06 --> Language Class Initialized
INFO - 2016-11-17 22:31:06 --> Loader Class Initialized
INFO - 2016-11-17 22:31:06 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:06 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:06 --> Final output sent to browser
INFO - 2016-11-17 22:31:06 --> Database Driver Class Initialized
DEBUG - 2016-11-17 22:31:06 --> Total execution time: 1.7835
INFO - 2016-11-17 22:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:06 --> Config Class Initialized
INFO - 2016-11-17 22:31:06 --> Controller Class Initialized
INFO - 2016-11-17 22:31:06 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:06 --> Model Class Initialized
DEBUG - 2016-11-17 22:31:06 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:07 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:07 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:07 --> URI Class Initialized
DEBUG - 2016-11-17 22:31:07 --> No URI present. Default controller set.
INFO - 2016-11-17 22:31:07 --> Router Class Initialized
INFO - 2016-11-17 22:31:07 --> Output Class Initialized
INFO - 2016-11-17 22:31:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:07 --> Security Class Initialized
INFO - 2016-11-17 22:31:07 --> Final output sent to browser
DEBUG - 2016-11-17 22:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-17 22:31:07 --> Total execution time: 1.7803
INFO - 2016-11-17 22:31:07 --> Input Class Initialized
INFO - 2016-11-17 22:31:07 --> Config Class Initialized
INFO - 2016-11-17 22:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:07 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:07 --> Language Class Initialized
INFO - 2016-11-17 22:31:07 --> Controller Class Initialized
INFO - 2016-11-17 22:31:07 --> Model Class Initialized
DEBUG - 2016-11-17 22:31:07 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:07 --> Loader Class Initialized
INFO - 2016-11-17 22:31:07 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:07 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:07 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:07 --> URI Class Initialized
INFO - 2016-11-17 22:31:07 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:07 --> Router Class Initialized
INFO - 2016-11-17 22:31:07 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:07 --> Output Class Initialized
INFO - 2016-11-17 22:31:07 --> Final output sent to browser
INFO - 2016-11-17 22:31:07 --> Security Class Initialized
DEBUG - 2016-11-17 22:31:07 --> Total execution time: 1.8071
INFO - 2016-11-17 22:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:07 --> Config Class Initialized
DEBUG - 2016-11-17 22:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:07 --> Controller Class Initialized
INFO - 2016-11-17 22:31:07 --> Input Class Initialized
INFO - 2016-11-17 22:31:07 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:07 --> Model Class Initialized
DEBUG - 2016-11-17 22:31:07 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:07 --> Language Class Initialized
INFO - 2016-11-17 22:31:07 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:07 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:07 --> Loader Class Initialized
INFO - 2016-11-17 22:31:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:07 --> URI Class Initialized
INFO - 2016-11-17 22:31:07 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:07 --> Router Class Initialized
INFO - 2016-11-17 22:31:07 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:07 --> Output Class Initialized
INFO - 2016-11-17 22:31:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:07 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:07 --> Security Class Initialized
INFO - 2016-11-17 22:31:07 --> Final output sent to browser
DEBUG - 2016-11-17 22:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-17 22:31:07 --> Total execution time: 1.8276
INFO - 2016-11-17 22:31:07 --> Input Class Initialized
INFO - 2016-11-17 22:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:07 --> Language Class Initialized
INFO - 2016-11-17 22:31:07 --> Controller Class Initialized
INFO - 2016-11-17 22:31:07 --> Model Class Initialized
INFO - 2016-11-17 22:31:07 --> Loader Class Initialized
INFO - 2016-11-17 22:31:07 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:07 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:07 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:07 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:07 --> Final output sent to browser
DEBUG - 2016-11-17 22:31:07 --> Total execution time: 1.7887
INFO - 2016-11-17 22:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:07 --> Controller Class Initialized
INFO - 2016-11-17 22:31:08 --> Model Class Initialized
INFO - 2016-11-17 22:31:08 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:08 --> Final output sent to browser
DEBUG - 2016-11-17 22:31:08 --> Total execution time: 1.6795
INFO - 2016-11-17 22:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:08 --> Controller Class Initialized
INFO - 2016-11-17 22:31:08 --> Model Class Initialized
INFO - 2016-11-17 22:31:08 --> Model Class Initialized
INFO - 2016-11-17 22:31:08 --> Model Class Initialized
INFO - 2016-11-17 22:31:08 --> Model Class Initialized
INFO - 2016-11-17 22:31:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:31:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:31:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:31:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 22:31:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 22:31:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 22:31:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 22:31:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 22:31:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 22:31:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:31:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:31:08 --> Final output sent to browser
DEBUG - 2016-11-17 22:31:08 --> Total execution time: 1.6378
INFO - 2016-11-17 22:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:08 --> Controller Class Initialized
INFO - 2016-11-17 22:31:08 --> Model Class Initialized
INFO - 2016-11-17 22:31:08 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:08 --> Final output sent to browser
DEBUG - 2016-11-17 22:31:08 --> Total execution time: 1.6568
INFO - 2016-11-17 22:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:08 --> Controller Class Initialized
INFO - 2016-11-17 22:31:08 --> Model Class Initialized
INFO - 2016-11-17 22:31:08 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:09 --> Final output sent to browser
DEBUG - 2016-11-17 22:31:09 --> Total execution time: 1.5532
INFO - 2016-11-17 22:31:29 --> Config Class Initialized
INFO - 2016-11-17 22:31:29 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:31:29 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:29 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:29 --> URI Class Initialized
DEBUG - 2016-11-17 22:31:29 --> No URI present. Default controller set.
INFO - 2016-11-17 22:31:29 --> Router Class Initialized
INFO - 2016-11-17 22:31:29 --> Output Class Initialized
INFO - 2016-11-17 22:31:30 --> Security Class Initialized
DEBUG - 2016-11-17 22:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:30 --> Input Class Initialized
INFO - 2016-11-17 22:31:30 --> Language Class Initialized
INFO - 2016-11-17 22:31:30 --> Loader Class Initialized
INFO - 2016-11-17 22:31:30 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:30 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:30 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:30 --> Controller Class Initialized
INFO - 2016-11-17 22:31:30 --> Model Class Initialized
INFO - 2016-11-17 22:31:30 --> Model Class Initialized
INFO - 2016-11-17 22:31:30 --> Model Class Initialized
INFO - 2016-11-17 22:31:30 --> Model Class Initialized
INFO - 2016-11-17 22:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 22:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 22:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 22:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 22:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 22:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 22:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:31:30 --> Final output sent to browser
DEBUG - 2016-11-17 22:31:30 --> Total execution time: 0.6822
INFO - 2016-11-17 22:31:42 --> Config Class Initialized
INFO - 2016-11-17 22:31:42 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:31:42 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:42 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:42 --> URI Class Initialized
INFO - 2016-11-17 22:31:42 --> Router Class Initialized
INFO - 2016-11-17 22:31:42 --> Output Class Initialized
INFO - 2016-11-17 22:31:42 --> Security Class Initialized
DEBUG - 2016-11-17 22:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:42 --> Input Class Initialized
INFO - 2016-11-17 22:31:42 --> Config Class Initialized
INFO - 2016-11-17 22:31:42 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:42 --> Language Class Initialized
DEBUG - 2016-11-17 22:31:42 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:43 --> Loader Class Initialized
INFO - 2016-11-17 22:31:43 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:43 --> URI Class Initialized
INFO - 2016-11-17 22:31:43 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:43 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:43 --> Router Class Initialized
INFO - 2016-11-17 22:31:43 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:43 --> Config Class Initialized
INFO - 2016-11-17 22:31:43 --> Output Class Initialized
INFO - 2016-11-17 22:31:43 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:43 --> Security Class Initialized
INFO - 2016-11-17 22:31:43 --> Controller Class Initialized
DEBUG - 2016-11-17 22:31:43 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:43 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:43 --> Model Class Initialized
DEBUG - 2016-11-17 22:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:43 --> URI Class Initialized
INFO - 2016-11-17 22:31:43 --> Input Class Initialized
INFO - 2016-11-17 22:31:43 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:43 --> Router Class Initialized
INFO - 2016-11-17 22:31:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:43 --> Output Class Initialized
INFO - 2016-11-17 22:31:43 --> Language Class Initialized
INFO - 2016-11-17 22:31:43 --> Config Class Initialized
INFO - 2016-11-17 22:31:43 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:43 --> Security Class Initialized
INFO - 2016-11-17 22:31:43 --> Loader Class Initialized
DEBUG - 2016-11-17 22:31:43 --> UTF-8 Support Enabled
DEBUG - 2016-11-17 22:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:43 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:43 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:43 --> Input Class Initialized
INFO - 2016-11-17 22:31:43 --> Final output sent to browser
INFO - 2016-11-17 22:31:43 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:43 --> URI Class Initialized
DEBUG - 2016-11-17 22:31:43 --> Total execution time: 0.6307
INFO - 2016-11-17 22:31:43 --> Language Class Initialized
INFO - 2016-11-17 22:31:43 --> Config Class Initialized
INFO - 2016-11-17 22:31:43 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:43 --> Router Class Initialized
INFO - 2016-11-17 22:31:43 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:43 --> Loader Class Initialized
INFO - 2016-11-17 22:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:43 --> Output Class Initialized
DEBUG - 2016-11-17 22:31:43 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:43 --> Controller Class Initialized
INFO - 2016-11-17 22:31:43 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:43 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:43 --> Security Class Initialized
INFO - 2016-11-17 22:31:43 --> Config Class Initialized
INFO - 2016-11-17 22:31:43 --> Model Class Initialized
INFO - 2016-11-17 22:31:43 --> Helper loaded: form_helper
DEBUG - 2016-11-17 22:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:43 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:43 --> URI Class Initialized
INFO - 2016-11-17 22:31:43 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:43 --> Database Driver Class Initialized
DEBUG - 2016-11-17 22:31:43 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:43 --> Input Class Initialized
INFO - 2016-11-17 22:31:43 --> Router Class Initialized
INFO - 2016-11-17 22:31:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:43 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:43 --> Output Class Initialized
INFO - 2016-11-17 22:31:43 --> Language Class Initialized
INFO - 2016-11-17 22:31:43 --> URI Class Initialized
INFO - 2016-11-17 22:31:43 --> Security Class Initialized
INFO - 2016-11-17 22:31:43 --> Loader Class Initialized
INFO - 2016-11-17 22:31:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
DEBUG - 2016-11-17 22:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:43 --> Router Class Initialized
INFO - 2016-11-17 22:31:43 --> Config Class Initialized
INFO - 2016-11-17 22:31:43 --> Input Class Initialized
INFO - 2016-11-17 22:31:43 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:43 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:43 --> Output Class Initialized
INFO - 2016-11-17 22:31:43 --> Final output sent to browser
INFO - 2016-11-17 22:31:43 --> Helper loaded: form_helper
DEBUG - 2016-11-17 22:31:43 --> Total execution time: 0.7890
INFO - 2016-11-17 22:31:43 --> Language Class Initialized
DEBUG - 2016-11-17 22:31:43 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:43 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:43 --> Security Class Initialized
INFO - 2016-11-17 22:31:43 --> Loader Class Initialized
INFO - 2016-11-17 22:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:43 --> Utf8 Class Initialized
DEBUG - 2016-11-17 22:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:43 --> Controller Class Initialized
INFO - 2016-11-17 22:31:43 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:43 --> Input Class Initialized
INFO - 2016-11-17 22:31:43 --> URI Class Initialized
INFO - 2016-11-17 22:31:43 --> Model Class Initialized
INFO - 2016-11-17 22:31:43 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:43 --> Config Class Initialized
INFO - 2016-11-17 22:31:43 --> Router Class Initialized
INFO - 2016-11-17 22:31:43 --> Language Class Initialized
INFO - 2016-11-17 22:31:43 --> Hooks Class Initialized
INFO - 2016-11-17 22:31:43 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:43 --> Loader Class Initialized
INFO - 2016-11-17 22:31:43 --> Output Class Initialized
INFO - 2016-11-17 22:31:43 --> Database Driver Class Initialized
DEBUG - 2016-11-17 22:31:43 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:43 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:43 --> Security Class Initialized
INFO - 2016-11-17 22:31:43 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:43 --> URI Class Initialized
INFO - 2016-11-17 22:31:43 --> Helper loaded: form_helper
DEBUG - 2016-11-17 22:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:43 --> Router Class Initialized
INFO - 2016-11-17 22:31:43 --> Input Class Initialized
INFO - 2016-11-17 22:31:43 --> Final output sent to browser
INFO - 2016-11-17 22:31:43 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:43 --> Language Class Initialized
INFO - 2016-11-17 22:31:44 --> Output Class Initialized
DEBUG - 2016-11-17 22:31:44 --> Total execution time: 0.9213
INFO - 2016-11-17 22:31:44 --> Loader Class Initialized
INFO - 2016-11-17 22:31:44 --> Security Class Initialized
INFO - 2016-11-17 22:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:44 --> Controller Class Initialized
INFO - 2016-11-17 22:31:44 --> Helper loaded: url_helper
DEBUG - 2016-11-17 22:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:44 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:44 --> Model Class Initialized
INFO - 2016-11-17 22:31:44 --> Input Class Initialized
INFO - 2016-11-17 22:31:44 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:44 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:44 --> Language Class Initialized
INFO - 2016-11-17 22:31:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:44 --> Loader Class Initialized
INFO - 2016-11-17 22:31:44 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:44 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:44 --> Final output sent to browser
INFO - 2016-11-17 22:31:44 --> Database Driver Class Initialized
DEBUG - 2016-11-17 22:31:44 --> Total execution time: 1.0412
INFO - 2016-11-17 22:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:44 --> Controller Class Initialized
INFO - 2016-11-17 22:31:44 --> Model Class Initialized
INFO - 2016-11-17 22:31:44 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:44 --> Final output sent to browser
DEBUG - 2016-11-17 22:31:44 --> Total execution time: 1.1038
INFO - 2016-11-17 22:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:44 --> Controller Class Initialized
INFO - 2016-11-17 22:31:44 --> Model Class Initialized
INFO - 2016-11-17 22:31:44 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:44 --> Final output sent to browser
DEBUG - 2016-11-17 22:31:44 --> Total execution time: 1.1443
INFO - 2016-11-17 22:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:44 --> Controller Class Initialized
INFO - 2016-11-17 22:31:44 --> Model Class Initialized
INFO - 2016-11-17 22:31:44 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:44 --> Final output sent to browser
DEBUG - 2016-11-17 22:31:44 --> Total execution time: 1.1893
INFO - 2016-11-17 22:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:44 --> Controller Class Initialized
INFO - 2016-11-17 22:31:44 --> Model Class Initialized
INFO - 2016-11-17 22:31:44 --> Form Validation Class Initialized
INFO - 2016-11-17 22:31:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-17 22:31:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:45 --> Final output sent to browser
DEBUG - 2016-11-17 22:31:45 --> Total execution time: 1.2529
INFO - 2016-11-17 22:31:48 --> Config Class Initialized
INFO - 2016-11-17 22:31:48 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:31:48 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:31:48 --> Utf8 Class Initialized
INFO - 2016-11-17 22:31:48 --> URI Class Initialized
DEBUG - 2016-11-17 22:31:48 --> No URI present. Default controller set.
INFO - 2016-11-17 22:31:48 --> Router Class Initialized
INFO - 2016-11-17 22:31:48 --> Output Class Initialized
INFO - 2016-11-17 22:31:49 --> Security Class Initialized
DEBUG - 2016-11-17 22:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:31:49 --> Input Class Initialized
INFO - 2016-11-17 22:31:49 --> Language Class Initialized
INFO - 2016-11-17 22:31:49 --> Loader Class Initialized
INFO - 2016-11-17 22:31:49 --> Helper loaded: url_helper
INFO - 2016-11-17 22:31:49 --> Helper loaded: form_helper
INFO - 2016-11-17 22:31:49 --> Database Driver Class Initialized
INFO - 2016-11-17 22:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:31:49 --> Controller Class Initialized
INFO - 2016-11-17 22:31:49 --> Model Class Initialized
INFO - 2016-11-17 22:31:49 --> Model Class Initialized
INFO - 2016-11-17 22:31:49 --> Model Class Initialized
INFO - 2016-11-17 22:31:49 --> Model Class Initialized
INFO - 2016-11-17 22:31:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:31:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:31:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:31:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 22:31:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 22:31:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 22:31:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 22:31:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 22:31:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:31:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 22:31:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:31:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:31:49 --> Final output sent to browser
DEBUG - 2016-11-17 22:31:49 --> Total execution time: 0.6708
INFO - 2016-11-17 22:32:41 --> Config Class Initialized
INFO - 2016-11-17 22:32:41 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:32:41 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:32:41 --> Utf8 Class Initialized
INFO - 2016-11-17 22:32:41 --> URI Class Initialized
DEBUG - 2016-11-17 22:32:41 --> No URI present. Default controller set.
INFO - 2016-11-17 22:32:41 --> Router Class Initialized
INFO - 2016-11-17 22:32:41 --> Output Class Initialized
INFO - 2016-11-17 22:32:41 --> Security Class Initialized
DEBUG - 2016-11-17 22:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:32:41 --> Input Class Initialized
INFO - 2016-11-17 22:32:41 --> Language Class Initialized
INFO - 2016-11-17 22:32:41 --> Loader Class Initialized
INFO - 2016-11-17 22:32:41 --> Helper loaded: url_helper
INFO - 2016-11-17 22:32:41 --> Helper loaded: form_helper
INFO - 2016-11-17 22:32:41 --> Database Driver Class Initialized
INFO - 2016-11-17 22:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:32:41 --> Controller Class Initialized
INFO - 2016-11-17 22:32:41 --> Model Class Initialized
INFO - 2016-11-17 22:32:41 --> Model Class Initialized
INFO - 2016-11-17 22:32:41 --> Model Class Initialized
INFO - 2016-11-17 22:32:41 --> Model Class Initialized
INFO - 2016-11-17 22:32:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:32:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:32:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:32:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 22:32:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 22:32:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 22:32:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 22:32:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 22:32:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:32:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 22:32:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:32:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:32:41 --> Final output sent to browser
DEBUG - 2016-11-17 22:32:41 --> Total execution time: 0.6929
INFO - 2016-11-17 22:33:26 --> Config Class Initialized
INFO - 2016-11-17 22:33:26 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:33:26 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:33:26 --> Utf8 Class Initialized
INFO - 2016-11-17 22:33:26 --> URI Class Initialized
DEBUG - 2016-11-17 22:33:26 --> No URI present. Default controller set.
INFO - 2016-11-17 22:33:26 --> Router Class Initialized
INFO - 2016-11-17 22:33:26 --> Output Class Initialized
INFO - 2016-11-17 22:33:26 --> Security Class Initialized
DEBUG - 2016-11-17 22:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:33:26 --> Input Class Initialized
INFO - 2016-11-17 22:33:26 --> Language Class Initialized
INFO - 2016-11-17 22:33:26 --> Loader Class Initialized
INFO - 2016-11-17 22:33:26 --> Helper loaded: url_helper
INFO - 2016-11-17 22:33:26 --> Helper loaded: form_helper
INFO - 2016-11-17 22:33:26 --> Database Driver Class Initialized
INFO - 2016-11-17 22:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:33:26 --> Controller Class Initialized
INFO - 2016-11-17 22:33:26 --> Model Class Initialized
INFO - 2016-11-17 22:33:26 --> Model Class Initialized
INFO - 2016-11-17 22:33:26 --> Model Class Initialized
INFO - 2016-11-17 22:33:26 --> Model Class Initialized
INFO - 2016-11-17 22:33:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:33:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:33:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:33:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 22:33:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 22:33:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 22:33:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 22:33:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 22:33:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:33:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 22:33:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:33:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:33:27 --> Final output sent to browser
DEBUG - 2016-11-17 22:33:27 --> Total execution time: 0.6160
INFO - 2016-11-17 22:34:04 --> Config Class Initialized
INFO - 2016-11-17 22:34:04 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:34:04 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:34:04 --> Utf8 Class Initialized
INFO - 2016-11-17 22:34:04 --> URI Class Initialized
DEBUG - 2016-11-17 22:34:04 --> No URI present. Default controller set.
INFO - 2016-11-17 22:34:04 --> Router Class Initialized
INFO - 2016-11-17 22:34:04 --> Output Class Initialized
INFO - 2016-11-17 22:34:04 --> Security Class Initialized
DEBUG - 2016-11-17 22:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:34:04 --> Input Class Initialized
INFO - 2016-11-17 22:34:04 --> Language Class Initialized
INFO - 2016-11-17 22:34:05 --> Loader Class Initialized
INFO - 2016-11-17 22:34:05 --> Helper loaded: url_helper
INFO - 2016-11-17 22:34:05 --> Helper loaded: form_helper
INFO - 2016-11-17 22:34:05 --> Database Driver Class Initialized
INFO - 2016-11-17 22:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:34:05 --> Controller Class Initialized
INFO - 2016-11-17 22:34:05 --> Model Class Initialized
INFO - 2016-11-17 22:34:05 --> Model Class Initialized
INFO - 2016-11-17 22:34:05 --> Model Class Initialized
INFO - 2016-11-17 22:34:05 --> Model Class Initialized
INFO - 2016-11-17 22:34:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:34:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:34:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:34:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 22:34:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 22:34:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 22:34:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 22:34:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 22:34:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:34:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 22:34:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:34:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:34:05 --> Final output sent to browser
INFO - 2016-11-17 22:34:05 --> Config Class Initialized
INFO - 2016-11-17 22:34:05 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:34:05 --> Total execution time: 0.7515
DEBUG - 2016-11-17 22:34:05 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:34:05 --> Utf8 Class Initialized
INFO - 2016-11-17 22:34:05 --> URI Class Initialized
DEBUG - 2016-11-17 22:34:05 --> No URI present. Default controller set.
INFO - 2016-11-17 22:34:05 --> Router Class Initialized
INFO - 2016-11-17 22:34:05 --> Output Class Initialized
INFO - 2016-11-17 22:34:05 --> Security Class Initialized
DEBUG - 2016-11-17 22:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:34:05 --> Input Class Initialized
INFO - 2016-11-17 22:34:05 --> Language Class Initialized
INFO - 2016-11-17 22:34:05 --> Loader Class Initialized
INFO - 2016-11-17 22:34:05 --> Helper loaded: url_helper
INFO - 2016-11-17 22:34:05 --> Helper loaded: form_helper
INFO - 2016-11-17 22:34:05 --> Database Driver Class Initialized
INFO - 2016-11-17 22:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:34:05 --> Controller Class Initialized
INFO - 2016-11-17 22:34:05 --> Model Class Initialized
INFO - 2016-11-17 22:34:05 --> Model Class Initialized
INFO - 2016-11-17 22:34:05 --> Model Class Initialized
INFO - 2016-11-17 22:34:05 --> Model Class Initialized
INFO - 2016-11-17 22:34:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 22:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 22:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 22:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 22:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 22:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 22:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:34:06 --> Final output sent to browser
DEBUG - 2016-11-17 22:34:06 --> Total execution time: 0.6875
INFO - 2016-11-17 22:36:47 --> Config Class Initialized
INFO - 2016-11-17 22:36:47 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:36:47 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:36:47 --> Utf8 Class Initialized
INFO - 2016-11-17 22:36:47 --> URI Class Initialized
DEBUG - 2016-11-17 22:36:47 --> No URI present. Default controller set.
INFO - 2016-11-17 22:36:47 --> Router Class Initialized
INFO - 2016-11-17 22:36:47 --> Output Class Initialized
INFO - 2016-11-17 22:36:47 --> Security Class Initialized
DEBUG - 2016-11-17 22:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:36:47 --> Input Class Initialized
INFO - 2016-11-17 22:36:47 --> Language Class Initialized
INFO - 2016-11-17 22:36:47 --> Loader Class Initialized
INFO - 2016-11-17 22:36:47 --> Helper loaded: url_helper
INFO - 2016-11-17 22:36:47 --> Helper loaded: form_helper
INFO - 2016-11-17 22:36:47 --> Database Driver Class Initialized
INFO - 2016-11-17 22:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:36:47 --> Controller Class Initialized
INFO - 2016-11-17 22:36:47 --> Model Class Initialized
INFO - 2016-11-17 22:36:47 --> Model Class Initialized
INFO - 2016-11-17 22:36:47 --> Model Class Initialized
INFO - 2016-11-17 22:36:47 --> Model Class Initialized
INFO - 2016-11-17 22:36:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:36:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-17 22:36:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-17 22:36:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-17 22:36:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-17 22:36:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-17 22:36:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-17 22:36:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-17 22:36:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-17 22:36:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-17 22:36:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-17 22:36:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:36:48 --> Final output sent to browser
DEBUG - 2016-11-17 22:36:48 --> Total execution time: 0.6897
INFO - 2016-11-17 22:37:46 --> Config Class Initialized
INFO - 2016-11-17 22:37:46 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:37:46 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:37:46 --> Utf8 Class Initialized
INFO - 2016-11-17 22:37:46 --> URI Class Initialized
INFO - 2016-11-17 22:37:46 --> Router Class Initialized
INFO - 2016-11-17 22:37:47 --> Output Class Initialized
INFO - 2016-11-17 22:37:47 --> Security Class Initialized
DEBUG - 2016-11-17 22:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:37:47 --> Input Class Initialized
INFO - 2016-11-17 22:37:47 --> Language Class Initialized
INFO - 2016-11-17 22:37:47 --> Loader Class Initialized
INFO - 2016-11-17 22:37:47 --> Helper loaded: url_helper
INFO - 2016-11-17 22:37:47 --> Helper loaded: form_helper
INFO - 2016-11-17 22:37:47 --> Database Driver Class Initialized
INFO - 2016-11-17 22:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:37:47 --> Controller Class Initialized
INFO - 2016-11-17 22:37:47 --> Model Class Initialized
INFO - 2016-11-17 22:37:47 --> Model Class Initialized
INFO - 2016-11-17 22:37:47 --> Model Class Initialized
INFO - 2016-11-17 22:37:47 --> Model Class Initialized
DEBUG - 2016-11-17 22:37:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-17 22:37:47 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-17 22:37:47 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-17 22:37:47 --> Config Class Initialized
INFO - 2016-11-17 22:37:47 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:37:47 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:37:47 --> Utf8 Class Initialized
INFO - 2016-11-17 22:37:47 --> URI Class Initialized
DEBUG - 2016-11-17 22:37:47 --> No URI present. Default controller set.
INFO - 2016-11-17 22:37:47 --> Router Class Initialized
INFO - 2016-11-17 22:37:47 --> Output Class Initialized
INFO - 2016-11-17 22:37:47 --> Security Class Initialized
DEBUG - 2016-11-17 22:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:37:47 --> Input Class Initialized
INFO - 2016-11-17 22:37:47 --> Config Class Initialized
INFO - 2016-11-17 22:37:47 --> Language Class Initialized
INFO - 2016-11-17 22:37:47 --> Hooks Class Initialized
INFO - 2016-11-17 22:37:47 --> Loader Class Initialized
DEBUG - 2016-11-17 22:37:47 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:37:47 --> Helper loaded: url_helper
INFO - 2016-11-17 22:37:47 --> Utf8 Class Initialized
INFO - 2016-11-17 22:37:47 --> URI Class Initialized
INFO - 2016-11-17 22:37:47 --> Helper loaded: form_helper
INFO - 2016-11-17 22:37:47 --> Router Class Initialized
INFO - 2016-11-17 22:37:47 --> Database Driver Class Initialized
INFO - 2016-11-17 22:37:47 --> Output Class Initialized
INFO - 2016-11-17 22:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:37:47 --> Security Class Initialized
INFO - 2016-11-17 22:37:47 --> Controller Class Initialized
INFO - 2016-11-17 22:37:47 --> Model Class Initialized
INFO - 2016-11-17 22:37:47 --> Model Class Initialized
DEBUG - 2016-11-17 22:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:37:47 --> Input Class Initialized
INFO - 2016-11-17 22:37:47 --> Model Class Initialized
INFO - 2016-11-17 22:37:47 --> Language Class Initialized
INFO - 2016-11-17 22:37:47 --> Model Class Initialized
INFO - 2016-11-17 22:37:47 --> Loader Class Initialized
INFO - 2016-11-17 22:37:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:37:48 --> Helper loaded: url_helper
INFO - 2016-11-17 22:37:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-17 22:37:48 --> Helper loaded: form_helper
INFO - 2016-11-17 22:37:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:37:48 --> Database Driver Class Initialized
INFO - 2016-11-17 22:37:48 --> Final output sent to browser
DEBUG - 2016-11-17 22:37:48 --> Total execution time: 0.6856
INFO - 2016-11-17 22:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:37:48 --> Controller Class Initialized
INFO - 2016-11-17 22:37:48 --> Model Class Initialized
INFO - 2016-11-17 22:37:48 --> Model Class Initialized
INFO - 2016-11-17 22:37:48 --> Model Class Initialized
INFO - 2016-11-17 22:37:48 --> Model Class Initialized
DEBUG - 2016-11-17 22:37:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-17 22:37:48 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-17 22:37:48 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-17 22:37:48 --> Config Class Initialized
INFO - 2016-11-17 22:37:48 --> Hooks Class Initialized
DEBUG - 2016-11-17 22:37:48 --> UTF-8 Support Enabled
INFO - 2016-11-17 22:37:48 --> Utf8 Class Initialized
INFO - 2016-11-17 22:37:48 --> URI Class Initialized
DEBUG - 2016-11-17 22:37:48 --> No URI present. Default controller set.
INFO - 2016-11-17 22:37:48 --> Router Class Initialized
INFO - 2016-11-17 22:37:48 --> Output Class Initialized
INFO - 2016-11-17 22:37:48 --> Security Class Initialized
DEBUG - 2016-11-17 22:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-17 22:37:48 --> Input Class Initialized
INFO - 2016-11-17 22:37:48 --> Language Class Initialized
INFO - 2016-11-17 22:37:48 --> Loader Class Initialized
INFO - 2016-11-17 22:37:48 --> Helper loaded: url_helper
INFO - 2016-11-17 22:37:48 --> Helper loaded: form_helper
INFO - 2016-11-17 22:37:48 --> Database Driver Class Initialized
INFO - 2016-11-17 22:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-17 22:37:48 --> Controller Class Initialized
INFO - 2016-11-17 22:37:48 --> Model Class Initialized
INFO - 2016-11-17 22:37:48 --> Model Class Initialized
INFO - 2016-11-17 22:37:48 --> Model Class Initialized
INFO - 2016-11-17 22:37:48 --> Model Class Initialized
INFO - 2016-11-17 22:37:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-17 22:37:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-17 22:37:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-17 22:37:48 --> Final output sent to browser
DEBUG - 2016-11-17 22:37:48 --> Total execution time: 0.5139
