<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-30 09:54:12 --> Config Class Initialized
INFO - 2016-11-30 09:54:12 --> Hooks Class Initialized
DEBUG - 2016-11-30 09:54:12 --> UTF-8 Support Enabled
INFO - 2016-11-30 09:54:12 --> Utf8 Class Initialized
INFO - 2016-11-30 09:54:12 --> URI Class Initialized
DEBUG - 2016-11-30 09:54:12 --> No URI present. Default controller set.
INFO - 2016-11-30 09:54:12 --> Router Class Initialized
INFO - 2016-11-30 09:54:12 --> Output Class Initialized
INFO - 2016-11-30 09:54:12 --> Security Class Initialized
DEBUG - 2016-11-30 09:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 09:54:12 --> Input Class Initialized
INFO - 2016-11-30 09:54:12 --> Language Class Initialized
INFO - 2016-11-30 09:54:12 --> Loader Class Initialized
INFO - 2016-11-30 09:54:12 --> Helper loaded: url_helper
INFO - 2016-11-30 09:54:12 --> Helper loaded: form_helper
INFO - 2016-11-30 09:54:12 --> Database Driver Class Initialized
INFO - 2016-11-30 09:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 09:54:13 --> Controller Class Initialized
INFO - 2016-11-30 09:54:13 --> Model Class Initialized
INFO - 2016-11-30 09:54:13 --> Model Class Initialized
INFO - 2016-11-30 09:54:13 --> Model Class Initialized
INFO - 2016-11-30 09:54:13 --> Model Class Initialized
INFO - 2016-11-30 09:54:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 09:54:13 --> Pagination Class Initialized
INFO - 2016-11-30 09:54:13 --> Helper loaded: app_helper
INFO - 2016-11-30 09:54:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 09:54:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-30 09:54:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 09:54:13 --> Final output sent to browser
DEBUG - 2016-11-30 09:54:13 --> Total execution time: 1.0242
INFO - 2016-11-30 09:54:16 --> Config Class Initialized
INFO - 2016-11-30 09:54:16 --> Hooks Class Initialized
DEBUG - 2016-11-30 09:54:16 --> UTF-8 Support Enabled
INFO - 2016-11-30 09:54:16 --> Utf8 Class Initialized
INFO - 2016-11-30 09:54:16 --> URI Class Initialized
DEBUG - 2016-11-30 09:54:16 --> No URI present. Default controller set.
INFO - 2016-11-30 09:54:16 --> Router Class Initialized
INFO - 2016-11-30 09:54:16 --> Output Class Initialized
INFO - 2016-11-30 09:54:16 --> Security Class Initialized
DEBUG - 2016-11-30 09:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 09:54:16 --> Input Class Initialized
INFO - 2016-11-30 09:54:16 --> Language Class Initialized
INFO - 2016-11-30 09:54:16 --> Loader Class Initialized
INFO - 2016-11-30 09:54:16 --> Helper loaded: url_helper
INFO - 2016-11-30 09:54:16 --> Helper loaded: form_helper
INFO - 2016-11-30 09:54:16 --> Database Driver Class Initialized
INFO - 2016-11-30 09:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 09:54:16 --> Controller Class Initialized
INFO - 2016-11-30 09:54:16 --> Model Class Initialized
INFO - 2016-11-30 09:54:16 --> Model Class Initialized
INFO - 2016-11-30 09:54:16 --> Model Class Initialized
INFO - 2016-11-30 09:54:16 --> Model Class Initialized
INFO - 2016-11-30 09:54:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 09:54:16 --> Pagination Class Initialized
INFO - 2016-11-30 09:54:16 --> Helper loaded: app_helper
INFO - 2016-11-30 09:54:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 09:54:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-30 09:54:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 09:54:16 --> Final output sent to browser
DEBUG - 2016-11-30 09:54:16 --> Total execution time: 0.4405
INFO - 2016-11-30 09:54:40 --> Config Class Initialized
INFO - 2016-11-30 09:54:40 --> Hooks Class Initialized
DEBUG - 2016-11-30 09:54:40 --> UTF-8 Support Enabled
INFO - 2016-11-30 09:54:40 --> Utf8 Class Initialized
INFO - 2016-11-30 09:54:40 --> URI Class Initialized
INFO - 2016-11-30 09:54:40 --> Router Class Initialized
INFO - 2016-11-30 09:54:40 --> Output Class Initialized
INFO - 2016-11-30 09:54:40 --> Security Class Initialized
DEBUG - 2016-11-30 09:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 09:54:40 --> Input Class Initialized
INFO - 2016-11-30 09:54:40 --> Language Class Initialized
INFO - 2016-11-30 09:54:40 --> Loader Class Initialized
INFO - 2016-11-30 09:54:40 --> Helper loaded: url_helper
INFO - 2016-11-30 09:54:40 --> Helper loaded: form_helper
INFO - 2016-11-30 09:54:40 --> Database Driver Class Initialized
INFO - 2016-11-30 09:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 09:54:40 --> Controller Class Initialized
INFO - 2016-11-30 09:54:40 --> Model Class Initialized
INFO - 2016-11-30 09:54:40 --> Model Class Initialized
INFO - 2016-11-30 09:54:40 --> Model Class Initialized
INFO - 2016-11-30 09:54:40 --> Model Class Initialized
INFO - 2016-11-30 09:54:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 09:54:40 --> Pagination Class Initialized
INFO - 2016-11-30 09:54:40 --> Helper loaded: app_helper
DEBUG - 2016-11-30 09:54:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 09:54:40 --> Model Class Initialized
INFO - 2016-11-30 09:54:40 --> Final output sent to browser
DEBUG - 2016-11-30 09:54:40 --> Total execution time: 0.2724
INFO - 2016-11-30 09:54:40 --> Config Class Initialized
INFO - 2016-11-30 09:54:40 --> Hooks Class Initialized
DEBUG - 2016-11-30 09:54:40 --> UTF-8 Support Enabled
INFO - 2016-11-30 09:54:40 --> Utf8 Class Initialized
INFO - 2016-11-30 09:54:40 --> URI Class Initialized
DEBUG - 2016-11-30 09:54:40 --> No URI present. Default controller set.
INFO - 2016-11-30 09:54:40 --> Router Class Initialized
INFO - 2016-11-30 09:54:40 --> Output Class Initialized
INFO - 2016-11-30 09:54:40 --> Security Class Initialized
DEBUG - 2016-11-30 09:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 09:54:40 --> Input Class Initialized
INFO - 2016-11-30 09:54:40 --> Language Class Initialized
INFO - 2016-11-30 09:54:40 --> Loader Class Initialized
INFO - 2016-11-30 09:54:40 --> Helper loaded: url_helper
INFO - 2016-11-30 09:54:40 --> Helper loaded: form_helper
INFO - 2016-11-30 09:54:40 --> Database Driver Class Initialized
INFO - 2016-11-30 09:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 09:54:40 --> Controller Class Initialized
INFO - 2016-11-30 09:54:40 --> Model Class Initialized
INFO - 2016-11-30 09:54:40 --> Model Class Initialized
INFO - 2016-11-30 09:54:40 --> Model Class Initialized
INFO - 2016-11-30 09:54:40 --> Model Class Initialized
INFO - 2016-11-30 09:54:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 09:54:40 --> Pagination Class Initialized
INFO - 2016-11-30 09:54:40 --> Helper loaded: app_helper
INFO - 2016-11-30 09:54:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 09:54:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 09:54:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 09:54:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-30 09:54:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 09:54:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-30 09:54:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 09:54:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 09:54:40 --> Final output sent to browser
DEBUG - 2016-11-30 09:54:40 --> Total execution time: 0.5188
INFO - 2016-11-30 09:55:18 --> Config Class Initialized
INFO - 2016-11-30 09:55:18 --> Hooks Class Initialized
DEBUG - 2016-11-30 09:55:18 --> UTF-8 Support Enabled
INFO - 2016-11-30 09:55:18 --> Utf8 Class Initialized
INFO - 2016-11-30 09:55:18 --> URI Class Initialized
DEBUG - 2016-11-30 09:55:18 --> No URI present. Default controller set.
INFO - 2016-11-30 09:55:18 --> Router Class Initialized
INFO - 2016-11-30 09:55:18 --> Output Class Initialized
INFO - 2016-11-30 09:55:18 --> Security Class Initialized
DEBUG - 2016-11-30 09:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 09:55:18 --> Input Class Initialized
INFO - 2016-11-30 09:55:18 --> Language Class Initialized
INFO - 2016-11-30 09:55:18 --> Loader Class Initialized
INFO - 2016-11-30 09:55:19 --> Helper loaded: url_helper
INFO - 2016-11-30 09:55:19 --> Helper loaded: form_helper
INFO - 2016-11-30 09:55:19 --> Database Driver Class Initialized
INFO - 2016-11-30 09:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 09:55:19 --> Controller Class Initialized
INFO - 2016-11-30 09:55:19 --> Model Class Initialized
INFO - 2016-11-30 09:55:19 --> Model Class Initialized
INFO - 2016-11-30 09:55:19 --> Model Class Initialized
INFO - 2016-11-30 09:55:19 --> Model Class Initialized
INFO - 2016-11-30 09:55:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 09:55:19 --> Pagination Class Initialized
INFO - 2016-11-30 09:55:19 --> Helper loaded: app_helper
INFO - 2016-11-30 09:55:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 09:55:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 09:55:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 09:55:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-30 09:55:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 09:55:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-30 09:55:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 09:55:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 09:55:19 --> Final output sent to browser
DEBUG - 2016-11-30 09:55:19 --> Total execution time: 0.3644
INFO - 2016-11-30 09:55:24 --> Config Class Initialized
INFO - 2016-11-30 09:55:24 --> Hooks Class Initialized
DEBUG - 2016-11-30 09:55:24 --> UTF-8 Support Enabled
INFO - 2016-11-30 09:55:24 --> Utf8 Class Initialized
INFO - 2016-11-30 09:55:24 --> URI Class Initialized
INFO - 2016-11-30 09:55:24 --> Router Class Initialized
INFO - 2016-11-30 09:55:24 --> Output Class Initialized
INFO - 2016-11-30 09:55:24 --> Security Class Initialized
DEBUG - 2016-11-30 09:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 09:55:24 --> Input Class Initialized
INFO - 2016-11-30 09:55:24 --> Language Class Initialized
INFO - 2016-11-30 09:55:24 --> Loader Class Initialized
INFO - 2016-11-30 09:55:24 --> Helper loaded: url_helper
INFO - 2016-11-30 09:55:24 --> Helper loaded: form_helper
INFO - 2016-11-30 09:55:24 --> Database Driver Class Initialized
INFO - 2016-11-30 09:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 09:55:24 --> Controller Class Initialized
INFO - 2016-11-30 09:55:24 --> Model Class Initialized
INFO - 2016-11-30 09:55:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 09:55:24 --> Pagination Class Initialized
INFO - 2016-11-30 09:55:24 --> Helper loaded: app_helper
INFO - 2016-11-30 09:55:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 09:55:24 --> Final output sent to browser
DEBUG - 2016-11-30 09:55:24 --> Total execution time: 0.1929
INFO - 2016-11-30 09:55:26 --> Config Class Initialized
INFO - 2016-11-30 09:55:26 --> Hooks Class Initialized
DEBUG - 2016-11-30 09:55:26 --> UTF-8 Support Enabled
INFO - 2016-11-30 09:55:26 --> Utf8 Class Initialized
INFO - 2016-11-30 09:55:26 --> URI Class Initialized
INFO - 2016-11-30 09:55:26 --> Router Class Initialized
INFO - 2016-11-30 09:55:26 --> Output Class Initialized
INFO - 2016-11-30 09:55:26 --> Security Class Initialized
DEBUG - 2016-11-30 09:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 09:55:27 --> Input Class Initialized
INFO - 2016-11-30 09:55:27 --> Language Class Initialized
INFO - 2016-11-30 09:55:27 --> Loader Class Initialized
INFO - 2016-11-30 09:55:27 --> Helper loaded: url_helper
INFO - 2016-11-30 09:55:27 --> Helper loaded: form_helper
INFO - 2016-11-30 09:55:27 --> Database Driver Class Initialized
INFO - 2016-11-30 09:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 09:55:27 --> Controller Class Initialized
INFO - 2016-11-30 09:55:27 --> Model Class Initialized
INFO - 2016-11-30 09:55:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 09:55:27 --> Pagination Class Initialized
INFO - 2016-11-30 09:55:27 --> Helper loaded: app_helper
INFO - 2016-11-30 09:55:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 09:55:27 --> Final output sent to browser
DEBUG - 2016-11-30 09:55:27 --> Total execution time: 0.2425
INFO - 2016-11-30 09:55:28 --> Config Class Initialized
INFO - 2016-11-30 09:55:28 --> Hooks Class Initialized
DEBUG - 2016-11-30 09:55:28 --> UTF-8 Support Enabled
INFO - 2016-11-30 09:55:28 --> Utf8 Class Initialized
INFO - 2016-11-30 09:55:28 --> URI Class Initialized
DEBUG - 2016-11-30 09:55:28 --> No URI present. Default controller set.
INFO - 2016-11-30 09:55:28 --> Router Class Initialized
INFO - 2016-11-30 09:55:28 --> Output Class Initialized
INFO - 2016-11-30 09:55:28 --> Security Class Initialized
DEBUG - 2016-11-30 09:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 09:55:28 --> Input Class Initialized
INFO - 2016-11-30 09:55:28 --> Language Class Initialized
INFO - 2016-11-30 09:55:28 --> Loader Class Initialized
INFO - 2016-11-30 09:55:28 --> Helper loaded: url_helper
INFO - 2016-11-30 09:55:28 --> Helper loaded: form_helper
INFO - 2016-11-30 09:55:28 --> Database Driver Class Initialized
INFO - 2016-11-30 09:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 09:55:28 --> Controller Class Initialized
INFO - 2016-11-30 09:55:28 --> Model Class Initialized
INFO - 2016-11-30 09:55:28 --> Model Class Initialized
INFO - 2016-11-30 09:55:28 --> Model Class Initialized
INFO - 2016-11-30 09:55:28 --> Model Class Initialized
INFO - 2016-11-30 09:55:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 09:55:28 --> Pagination Class Initialized
INFO - 2016-11-30 09:55:28 --> Helper loaded: app_helper
INFO - 2016-11-30 09:55:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 09:55:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 09:55:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 09:55:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-30 09:55:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 09:55:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-30 09:55:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 09:55:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 09:55:28 --> Final output sent to browser
DEBUG - 2016-11-30 09:55:28 --> Total execution time: 0.4613
INFO - 2016-11-30 09:55:41 --> Config Class Initialized
INFO - 2016-11-30 09:55:41 --> Hooks Class Initialized
DEBUG - 2016-11-30 09:55:41 --> UTF-8 Support Enabled
INFO - 2016-11-30 09:55:41 --> Utf8 Class Initialized
INFO - 2016-11-30 09:55:41 --> URI Class Initialized
INFO - 2016-11-30 09:55:41 --> Router Class Initialized
INFO - 2016-11-30 09:55:42 --> Output Class Initialized
INFO - 2016-11-30 09:55:42 --> Security Class Initialized
DEBUG - 2016-11-30 09:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 09:55:42 --> Input Class Initialized
INFO - 2016-11-30 09:55:42 --> Language Class Initialized
INFO - 2016-11-30 09:55:42 --> Loader Class Initialized
INFO - 2016-11-30 09:55:42 --> Helper loaded: url_helper
INFO - 2016-11-30 09:55:42 --> Helper loaded: form_helper
INFO - 2016-11-30 09:55:42 --> Database Driver Class Initialized
INFO - 2016-11-30 09:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 09:55:42 --> Controller Class Initialized
INFO - 2016-11-30 09:55:42 --> Model Class Initialized
INFO - 2016-11-30 09:55:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 09:55:42 --> Pagination Class Initialized
INFO - 2016-11-30 09:55:42 --> Helper loaded: app_helper
INFO - 2016-11-30 09:55:42 --> Form Validation Class Initialized
INFO - 2016-11-30 09:55:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 09:55:42 --> Final output sent to browser
DEBUG - 2016-11-30 09:55:42 --> Total execution time: 0.3642
INFO - 2016-11-30 09:55:45 --> Config Class Initialized
INFO - 2016-11-30 09:55:45 --> Hooks Class Initialized
DEBUG - 2016-11-30 09:55:45 --> UTF-8 Support Enabled
INFO - 2016-11-30 09:55:45 --> Utf8 Class Initialized
INFO - 2016-11-30 09:55:45 --> URI Class Initialized
INFO - 2016-11-30 09:55:45 --> Router Class Initialized
INFO - 2016-11-30 09:55:45 --> Output Class Initialized
INFO - 2016-11-30 09:55:45 --> Security Class Initialized
DEBUG - 2016-11-30 09:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 09:55:45 --> Input Class Initialized
INFO - 2016-11-30 09:55:45 --> Language Class Initialized
INFO - 2016-11-30 09:55:45 --> Loader Class Initialized
INFO - 2016-11-30 09:55:45 --> Helper loaded: url_helper
INFO - 2016-11-30 09:55:45 --> Helper loaded: form_helper
INFO - 2016-11-30 09:55:45 --> Database Driver Class Initialized
INFO - 2016-11-30 09:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 09:55:45 --> Controller Class Initialized
INFO - 2016-11-30 09:55:45 --> Model Class Initialized
INFO - 2016-11-30 09:55:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 09:55:46 --> Pagination Class Initialized
INFO - 2016-11-30 09:55:46 --> Helper loaded: app_helper
INFO - 2016-11-30 09:55:46 --> Form Validation Class Initialized
INFO - 2016-11-30 09:55:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 09:55:46 --> Final output sent to browser
DEBUG - 2016-11-30 09:55:46 --> Total execution time: 0.2717
INFO - 2016-11-30 09:57:31 --> Config Class Initialized
INFO - 2016-11-30 09:57:31 --> Hooks Class Initialized
DEBUG - 2016-11-30 09:57:31 --> UTF-8 Support Enabled
INFO - 2016-11-30 09:57:31 --> Utf8 Class Initialized
INFO - 2016-11-30 09:57:32 --> URI Class Initialized
DEBUG - 2016-11-30 09:57:32 --> No URI present. Default controller set.
INFO - 2016-11-30 09:57:32 --> Router Class Initialized
INFO - 2016-11-30 09:57:32 --> Output Class Initialized
INFO - 2016-11-30 09:57:32 --> Security Class Initialized
DEBUG - 2016-11-30 09:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 09:57:32 --> Input Class Initialized
INFO - 2016-11-30 09:57:32 --> Language Class Initialized
INFO - 2016-11-30 09:57:32 --> Loader Class Initialized
INFO - 2016-11-30 09:57:32 --> Helper loaded: url_helper
INFO - 2016-11-30 09:57:32 --> Helper loaded: form_helper
INFO - 2016-11-30 09:57:32 --> Database Driver Class Initialized
INFO - 2016-11-30 09:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 09:57:32 --> Controller Class Initialized
INFO - 2016-11-30 09:57:32 --> Model Class Initialized
INFO - 2016-11-30 09:57:32 --> Model Class Initialized
INFO - 2016-11-30 09:57:32 --> Model Class Initialized
INFO - 2016-11-30 09:57:32 --> Model Class Initialized
INFO - 2016-11-30 09:57:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 09:57:32 --> Pagination Class Initialized
INFO - 2016-11-30 09:57:32 --> Helper loaded: app_helper
INFO - 2016-11-30 09:57:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 09:57:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 09:57:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 09:57:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-30 09:57:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 09:57:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-30 09:57:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 09:57:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 09:57:32 --> Final output sent to browser
DEBUG - 2016-11-30 09:57:32 --> Total execution time: 0.3664
INFO - 2016-11-30 09:59:06 --> Config Class Initialized
INFO - 2016-11-30 09:59:06 --> Hooks Class Initialized
DEBUG - 2016-11-30 09:59:06 --> UTF-8 Support Enabled
INFO - 2016-11-30 09:59:06 --> Utf8 Class Initialized
INFO - 2016-11-30 09:59:06 --> URI Class Initialized
INFO - 2016-11-30 09:59:06 --> Router Class Initialized
INFO - 2016-11-30 09:59:06 --> Output Class Initialized
INFO - 2016-11-30 09:59:06 --> Security Class Initialized
DEBUG - 2016-11-30 09:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 09:59:06 --> Input Class Initialized
INFO - 2016-11-30 09:59:06 --> Language Class Initialized
INFO - 2016-11-30 09:59:06 --> Loader Class Initialized
INFO - 2016-11-30 09:59:06 --> Helper loaded: url_helper
INFO - 2016-11-30 09:59:06 --> Helper loaded: form_helper
INFO - 2016-11-30 09:59:06 --> Database Driver Class Initialized
INFO - 2016-11-30 09:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 09:59:06 --> Controller Class Initialized
INFO - 2016-11-30 09:59:06 --> Model Class Initialized
INFO - 2016-11-30 09:59:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 09:59:06 --> Pagination Class Initialized
INFO - 2016-11-30 09:59:06 --> Helper loaded: app_helper
INFO - 2016-11-30 09:59:06 --> Form Validation Class Initialized
INFO - 2016-11-30 09:59:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 09:59:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 09:59:06 --> Final output sent to browser
DEBUG - 2016-11-30 09:59:06 --> Total execution time: 0.3297
INFO - 2016-11-30 10:00:57 --> Config Class Initialized
INFO - 2016-11-30 10:00:57 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:00:57 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:00:57 --> Utf8 Class Initialized
INFO - 2016-11-30 10:00:57 --> URI Class Initialized
INFO - 2016-11-30 10:00:57 --> Router Class Initialized
INFO - 2016-11-30 10:00:57 --> Output Class Initialized
INFO - 2016-11-30 10:00:57 --> Security Class Initialized
DEBUG - 2016-11-30 10:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:00:57 --> Input Class Initialized
INFO - 2016-11-30 10:00:57 --> Language Class Initialized
INFO - 2016-11-30 10:00:57 --> Loader Class Initialized
INFO - 2016-11-30 10:00:57 --> Helper loaded: url_helper
INFO - 2016-11-30 10:00:57 --> Helper loaded: form_helper
INFO - 2016-11-30 10:00:57 --> Database Driver Class Initialized
INFO - 2016-11-30 10:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:00:57 --> Controller Class Initialized
INFO - 2016-11-30 10:00:57 --> Model Class Initialized
INFO - 2016-11-30 10:00:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:00:57 --> Pagination Class Initialized
INFO - 2016-11-30 10:00:57 --> Helper loaded: app_helper
INFO - 2016-11-30 10:00:57 --> Form Validation Class Initialized
INFO - 2016-11-30 10:00:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 10:00:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:00:57 --> Final output sent to browser
DEBUG - 2016-11-30 10:00:57 --> Total execution time: 0.3422
INFO - 2016-11-30 10:00:59 --> Config Class Initialized
INFO - 2016-11-30 10:00:59 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:00:59 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:00:59 --> Utf8 Class Initialized
INFO - 2016-11-30 10:00:59 --> URI Class Initialized
INFO - 2016-11-30 10:00:59 --> Router Class Initialized
INFO - 2016-11-30 10:00:59 --> Output Class Initialized
INFO - 2016-11-30 10:00:59 --> Security Class Initialized
DEBUG - 2016-11-30 10:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:00:59 --> Input Class Initialized
INFO - 2016-11-30 10:00:59 --> Language Class Initialized
INFO - 2016-11-30 10:00:59 --> Loader Class Initialized
INFO - 2016-11-30 10:00:59 --> Helper loaded: url_helper
INFO - 2016-11-30 10:00:59 --> Helper loaded: form_helper
INFO - 2016-11-30 10:00:59 --> Database Driver Class Initialized
INFO - 2016-11-30 10:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:00:59 --> Controller Class Initialized
INFO - 2016-11-30 10:00:59 --> Model Class Initialized
INFO - 2016-11-30 10:00:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:00:59 --> Pagination Class Initialized
INFO - 2016-11-30 10:00:59 --> Helper loaded: app_helper
INFO - 2016-11-30 10:00:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:00:59 --> Final output sent to browser
DEBUG - 2016-11-30 10:00:59 --> Total execution time: 0.2573
INFO - 2016-11-30 10:01:03 --> Config Class Initialized
INFO - 2016-11-30 10:01:03 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:01:03 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:01:03 --> Utf8 Class Initialized
INFO - 2016-11-30 10:01:03 --> URI Class Initialized
INFO - 2016-11-30 10:01:03 --> Router Class Initialized
INFO - 2016-11-30 10:01:03 --> Output Class Initialized
INFO - 2016-11-30 10:01:03 --> Security Class Initialized
DEBUG - 2016-11-30 10:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:01:03 --> Input Class Initialized
INFO - 2016-11-30 10:01:03 --> Language Class Initialized
INFO - 2016-11-30 10:01:03 --> Loader Class Initialized
INFO - 2016-11-30 10:01:03 --> Helper loaded: url_helper
INFO - 2016-11-30 10:01:03 --> Helper loaded: form_helper
INFO - 2016-11-30 10:01:03 --> Database Driver Class Initialized
INFO - 2016-11-30 10:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:01:03 --> Controller Class Initialized
INFO - 2016-11-30 10:01:03 --> Model Class Initialized
INFO - 2016-11-30 10:01:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:01:03 --> Pagination Class Initialized
INFO - 2016-11-30 10:01:03 --> Helper loaded: app_helper
INFO - 2016-11-30 10:01:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:01:03 --> Final output sent to browser
DEBUG - 2016-11-30 10:01:03 --> Total execution time: 0.2177
INFO - 2016-11-30 10:01:06 --> Config Class Initialized
INFO - 2016-11-30 10:01:06 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:01:06 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:01:06 --> Utf8 Class Initialized
INFO - 2016-11-30 10:01:06 --> URI Class Initialized
INFO - 2016-11-30 10:01:06 --> Router Class Initialized
INFO - 2016-11-30 10:01:06 --> Output Class Initialized
INFO - 2016-11-30 10:01:06 --> Security Class Initialized
DEBUG - 2016-11-30 10:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:01:06 --> Input Class Initialized
INFO - 2016-11-30 10:01:06 --> Language Class Initialized
INFO - 2016-11-30 10:01:06 --> Loader Class Initialized
INFO - 2016-11-30 10:01:06 --> Helper loaded: url_helper
INFO - 2016-11-30 10:01:06 --> Helper loaded: form_helper
INFO - 2016-11-30 10:01:06 --> Database Driver Class Initialized
INFO - 2016-11-30 10:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:01:06 --> Controller Class Initialized
INFO - 2016-11-30 10:01:06 --> Model Class Initialized
INFO - 2016-11-30 10:01:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:01:06 --> Pagination Class Initialized
INFO - 2016-11-30 10:01:06 --> Helper loaded: app_helper
INFO - 2016-11-30 10:01:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:01:06 --> Final output sent to browser
DEBUG - 2016-11-30 10:01:06 --> Total execution time: 0.2240
INFO - 2016-11-30 10:01:08 --> Config Class Initialized
INFO - 2016-11-30 10:01:08 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:01:08 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:01:08 --> Utf8 Class Initialized
INFO - 2016-11-30 10:01:08 --> URI Class Initialized
INFO - 2016-11-30 10:01:08 --> Router Class Initialized
INFO - 2016-11-30 10:01:08 --> Output Class Initialized
INFO - 2016-11-30 10:01:08 --> Security Class Initialized
DEBUG - 2016-11-30 10:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:01:08 --> Input Class Initialized
INFO - 2016-11-30 10:01:08 --> Language Class Initialized
INFO - 2016-11-30 10:01:08 --> Loader Class Initialized
INFO - 2016-11-30 10:01:08 --> Helper loaded: url_helper
INFO - 2016-11-30 10:01:08 --> Helper loaded: form_helper
INFO - 2016-11-30 10:01:08 --> Database Driver Class Initialized
INFO - 2016-11-30 10:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:01:08 --> Controller Class Initialized
INFO - 2016-11-30 10:01:08 --> Model Class Initialized
INFO - 2016-11-30 10:01:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:01:08 --> Pagination Class Initialized
INFO - 2016-11-30 10:01:08 --> Helper loaded: app_helper
INFO - 2016-11-30 10:01:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:01:08 --> Final output sent to browser
DEBUG - 2016-11-30 10:01:08 --> Total execution time: 0.2119
INFO - 2016-11-30 10:01:23 --> Config Class Initialized
INFO - 2016-11-30 10:01:23 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:01:23 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:01:23 --> Utf8 Class Initialized
INFO - 2016-11-30 10:01:23 --> URI Class Initialized
INFO - 2016-11-30 10:01:23 --> Router Class Initialized
INFO - 2016-11-30 10:01:23 --> Output Class Initialized
INFO - 2016-11-30 10:01:23 --> Security Class Initialized
DEBUG - 2016-11-30 10:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:01:23 --> Input Class Initialized
INFO - 2016-11-30 10:01:23 --> Language Class Initialized
INFO - 2016-11-30 10:01:23 --> Loader Class Initialized
INFO - 2016-11-30 10:01:23 --> Helper loaded: url_helper
INFO - 2016-11-30 10:01:23 --> Helper loaded: form_helper
INFO - 2016-11-30 10:01:23 --> Database Driver Class Initialized
INFO - 2016-11-30 10:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:01:23 --> Controller Class Initialized
INFO - 2016-11-30 10:01:23 --> Model Class Initialized
INFO - 2016-11-30 10:01:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:01:23 --> Pagination Class Initialized
INFO - 2016-11-30 10:01:23 --> Helper loaded: app_helper
INFO - 2016-11-30 10:01:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:01:23 --> Final output sent to browser
DEBUG - 2016-11-30 10:01:23 --> Total execution time: 0.2255
INFO - 2016-11-30 10:01:26 --> Config Class Initialized
INFO - 2016-11-30 10:01:26 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:01:26 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:01:26 --> Utf8 Class Initialized
INFO - 2016-11-30 10:01:26 --> URI Class Initialized
INFO - 2016-11-30 10:01:26 --> Router Class Initialized
INFO - 2016-11-30 10:01:26 --> Output Class Initialized
INFO - 2016-11-30 10:01:26 --> Security Class Initialized
DEBUG - 2016-11-30 10:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:01:26 --> Input Class Initialized
INFO - 2016-11-30 10:01:26 --> Language Class Initialized
INFO - 2016-11-30 10:01:26 --> Loader Class Initialized
INFO - 2016-11-30 10:01:26 --> Helper loaded: url_helper
INFO - 2016-11-30 10:01:26 --> Helper loaded: form_helper
INFO - 2016-11-30 10:01:26 --> Database Driver Class Initialized
INFO - 2016-11-30 10:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:01:26 --> Controller Class Initialized
INFO - 2016-11-30 10:01:26 --> Model Class Initialized
INFO - 2016-11-30 10:01:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:01:26 --> Pagination Class Initialized
INFO - 2016-11-30 10:01:26 --> Helper loaded: app_helper
INFO - 2016-11-30 10:01:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:01:26 --> Final output sent to browser
DEBUG - 2016-11-30 10:01:26 --> Total execution time: 0.2200
INFO - 2016-11-30 10:04:21 --> Config Class Initialized
INFO - 2016-11-30 10:04:21 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:04:22 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:04:22 --> Utf8 Class Initialized
INFO - 2016-11-30 10:04:22 --> URI Class Initialized
INFO - 2016-11-30 10:04:22 --> Router Class Initialized
INFO - 2016-11-30 10:04:22 --> Output Class Initialized
INFO - 2016-11-30 10:04:22 --> Security Class Initialized
DEBUG - 2016-11-30 10:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:04:22 --> Input Class Initialized
INFO - 2016-11-30 10:04:22 --> Language Class Initialized
INFO - 2016-11-30 10:04:22 --> Loader Class Initialized
INFO - 2016-11-30 10:04:22 --> Helper loaded: url_helper
INFO - 2016-11-30 10:04:22 --> Helper loaded: form_helper
INFO - 2016-11-30 10:04:22 --> Database Driver Class Initialized
INFO - 2016-11-30 10:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:04:22 --> Controller Class Initialized
INFO - 2016-11-30 10:04:22 --> Model Class Initialized
INFO - 2016-11-30 10:04:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:04:22 --> Pagination Class Initialized
INFO - 2016-11-30 10:04:22 --> Helper loaded: app_helper
INFO - 2016-11-30 10:04:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:04:22 --> Final output sent to browser
DEBUG - 2016-11-30 10:04:22 --> Total execution time: 0.2799
INFO - 2016-11-30 10:04:23 --> Config Class Initialized
INFO - 2016-11-30 10:04:23 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:04:23 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:04:23 --> Utf8 Class Initialized
INFO - 2016-11-30 10:04:23 --> URI Class Initialized
INFO - 2016-11-30 10:04:23 --> Router Class Initialized
INFO - 2016-11-30 10:04:23 --> Output Class Initialized
INFO - 2016-11-30 10:04:23 --> Security Class Initialized
DEBUG - 2016-11-30 10:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:04:23 --> Input Class Initialized
INFO - 2016-11-30 10:04:23 --> Language Class Initialized
INFO - 2016-11-30 10:04:23 --> Loader Class Initialized
INFO - 2016-11-30 10:04:23 --> Helper loaded: url_helper
INFO - 2016-11-30 10:04:23 --> Helper loaded: form_helper
INFO - 2016-11-30 10:04:23 --> Database Driver Class Initialized
INFO - 2016-11-30 10:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:04:23 --> Controller Class Initialized
INFO - 2016-11-30 10:04:23 --> Model Class Initialized
INFO - 2016-11-30 10:04:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:04:23 --> Pagination Class Initialized
INFO - 2016-11-30 10:04:23 --> Helper loaded: app_helper
INFO - 2016-11-30 10:04:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:04:23 --> Final output sent to browser
DEBUG - 2016-11-30 10:04:23 --> Total execution time: 0.2983
INFO - 2016-11-30 10:11:47 --> Config Class Initialized
INFO - 2016-11-30 10:11:47 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:11:47 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:11:47 --> Utf8 Class Initialized
INFO - 2016-11-30 10:11:47 --> URI Class Initialized
INFO - 2016-11-30 10:11:47 --> Router Class Initialized
INFO - 2016-11-30 10:11:47 --> Output Class Initialized
INFO - 2016-11-30 10:11:47 --> Security Class Initialized
DEBUG - 2016-11-30 10:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:11:47 --> Input Class Initialized
INFO - 2016-11-30 10:11:47 --> Language Class Initialized
INFO - 2016-11-30 10:11:47 --> Loader Class Initialized
INFO - 2016-11-30 10:11:47 --> Helper loaded: url_helper
INFO - 2016-11-30 10:11:47 --> Helper loaded: form_helper
INFO - 2016-11-30 10:11:47 --> Database Driver Class Initialized
INFO - 2016-11-30 10:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:11:47 --> Controller Class Initialized
INFO - 2016-11-30 10:11:47 --> Model Class Initialized
INFO - 2016-11-30 10:11:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:11:47 --> Pagination Class Initialized
INFO - 2016-11-30 10:11:47 --> Helper loaded: app_helper
INFO - 2016-11-30 10:12:59 --> Config Class Initialized
INFO - 2016-11-30 10:12:59 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:12:59 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:12:59 --> Utf8 Class Initialized
INFO - 2016-11-30 10:12:59 --> URI Class Initialized
INFO - 2016-11-30 10:12:59 --> Router Class Initialized
INFO - 2016-11-30 10:12:59 --> Output Class Initialized
INFO - 2016-11-30 10:12:59 --> Security Class Initialized
DEBUG - 2016-11-30 10:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:12:59 --> Input Class Initialized
INFO - 2016-11-30 10:12:59 --> Language Class Initialized
INFO - 2016-11-30 10:12:59 --> Loader Class Initialized
INFO - 2016-11-30 10:12:59 --> Helper loaded: url_helper
INFO - 2016-11-30 10:12:59 --> Helper loaded: form_helper
INFO - 2016-11-30 10:12:59 --> Database Driver Class Initialized
INFO - 2016-11-30 10:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:12:59 --> Controller Class Initialized
INFO - 2016-11-30 10:12:59 --> Model Class Initialized
INFO - 2016-11-30 10:12:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:12:59 --> Pagination Class Initialized
INFO - 2016-11-30 10:12:59 --> Helper loaded: app_helper
INFO - 2016-11-30 10:13:06 --> Config Class Initialized
INFO - 2016-11-30 10:13:06 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:13:06 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:13:06 --> Utf8 Class Initialized
INFO - 2016-11-30 10:13:06 --> URI Class Initialized
INFO - 2016-11-30 10:13:06 --> Router Class Initialized
INFO - 2016-11-30 10:13:06 --> Output Class Initialized
INFO - 2016-11-30 10:13:06 --> Security Class Initialized
DEBUG - 2016-11-30 10:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:13:06 --> Input Class Initialized
INFO - 2016-11-30 10:13:06 --> Language Class Initialized
INFO - 2016-11-30 10:13:06 --> Loader Class Initialized
INFO - 2016-11-30 10:13:06 --> Helper loaded: url_helper
INFO - 2016-11-30 10:13:06 --> Helper loaded: form_helper
INFO - 2016-11-30 10:13:06 --> Database Driver Class Initialized
INFO - 2016-11-30 10:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:13:06 --> Controller Class Initialized
INFO - 2016-11-30 10:13:06 --> Model Class Initialized
INFO - 2016-11-30 10:13:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:13:06 --> Pagination Class Initialized
INFO - 2016-11-30 10:13:06 --> Helper loaded: app_helper
INFO - 2016-11-30 10:13:06 --> Form Validation Class Initialized
INFO - 2016-11-30 10:13:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 10:13:23 --> Config Class Initialized
INFO - 2016-11-30 10:13:23 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:13:23 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:13:23 --> Utf8 Class Initialized
INFO - 2016-11-30 10:13:23 --> URI Class Initialized
INFO - 2016-11-30 10:13:23 --> Router Class Initialized
INFO - 2016-11-30 10:13:23 --> Output Class Initialized
INFO - 2016-11-30 10:13:23 --> Security Class Initialized
DEBUG - 2016-11-30 10:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:13:23 --> Input Class Initialized
INFO - 2016-11-30 10:13:23 --> Language Class Initialized
INFO - 2016-11-30 10:13:23 --> Loader Class Initialized
INFO - 2016-11-30 10:13:23 --> Helper loaded: url_helper
INFO - 2016-11-30 10:13:23 --> Helper loaded: form_helper
INFO - 2016-11-30 10:13:23 --> Database Driver Class Initialized
INFO - 2016-11-30 10:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:13:24 --> Controller Class Initialized
INFO - 2016-11-30 10:13:24 --> Model Class Initialized
INFO - 2016-11-30 10:13:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:13:24 --> Pagination Class Initialized
INFO - 2016-11-30 10:13:24 --> Helper loaded: app_helper
INFO - 2016-11-30 10:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:13:24 --> Final output sent to browser
DEBUG - 2016-11-30 10:13:24 --> Total execution time: 0.2408
INFO - 2016-11-30 10:13:31 --> Config Class Initialized
INFO - 2016-11-30 10:13:31 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:13:31 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:13:31 --> Utf8 Class Initialized
INFO - 2016-11-30 10:13:31 --> URI Class Initialized
INFO - 2016-11-30 10:13:31 --> Router Class Initialized
INFO - 2016-11-30 10:13:31 --> Output Class Initialized
INFO - 2016-11-30 10:13:31 --> Security Class Initialized
DEBUG - 2016-11-30 10:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:13:31 --> Input Class Initialized
INFO - 2016-11-30 10:13:31 --> Language Class Initialized
INFO - 2016-11-30 10:13:31 --> Loader Class Initialized
INFO - 2016-11-30 10:13:31 --> Helper loaded: url_helper
INFO - 2016-11-30 10:13:31 --> Helper loaded: form_helper
INFO - 2016-11-30 10:13:31 --> Database Driver Class Initialized
INFO - 2016-11-30 10:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:13:31 --> Controller Class Initialized
INFO - 2016-11-30 10:13:31 --> Model Class Initialized
INFO - 2016-11-30 10:13:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:13:31 --> Pagination Class Initialized
INFO - 2016-11-30 10:13:31 --> Helper loaded: app_helper
INFO - 2016-11-30 10:13:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:13:31 --> Final output sent to browser
DEBUG - 2016-11-30 10:13:31 --> Total execution time: 0.2136
INFO - 2016-11-30 10:14:47 --> Config Class Initialized
INFO - 2016-11-30 10:14:47 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:14:47 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:14:47 --> Utf8 Class Initialized
INFO - 2016-11-30 10:14:47 --> URI Class Initialized
INFO - 2016-11-30 10:14:47 --> Router Class Initialized
INFO - 2016-11-30 10:14:47 --> Output Class Initialized
INFO - 2016-11-30 10:14:47 --> Security Class Initialized
DEBUG - 2016-11-30 10:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:14:47 --> Input Class Initialized
INFO - 2016-11-30 10:14:47 --> Language Class Initialized
INFO - 2016-11-30 10:14:47 --> Loader Class Initialized
INFO - 2016-11-30 10:14:47 --> Helper loaded: url_helper
INFO - 2016-11-30 10:14:47 --> Helper loaded: form_helper
INFO - 2016-11-30 10:14:47 --> Database Driver Class Initialized
INFO - 2016-11-30 10:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:14:47 --> Controller Class Initialized
INFO - 2016-11-30 10:14:47 --> Model Class Initialized
INFO - 2016-11-30 10:14:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:14:47 --> Pagination Class Initialized
INFO - 2016-11-30 10:14:47 --> Helper loaded: app_helper
INFO - 2016-11-30 10:14:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:14:47 --> Final output sent to browser
DEBUG - 2016-11-30 10:14:47 --> Total execution time: 0.2309
INFO - 2016-11-30 10:15:06 --> Config Class Initialized
INFO - 2016-11-30 10:15:06 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:15:06 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:15:06 --> Utf8 Class Initialized
INFO - 2016-11-30 10:15:06 --> URI Class Initialized
INFO - 2016-11-30 10:15:06 --> Router Class Initialized
INFO - 2016-11-30 10:15:06 --> Output Class Initialized
INFO - 2016-11-30 10:15:06 --> Security Class Initialized
DEBUG - 2016-11-30 10:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:15:06 --> Input Class Initialized
INFO - 2016-11-30 10:15:06 --> Language Class Initialized
INFO - 2016-11-30 10:15:06 --> Loader Class Initialized
INFO - 2016-11-30 10:15:06 --> Helper loaded: url_helper
INFO - 2016-11-30 10:15:06 --> Helper loaded: form_helper
INFO - 2016-11-30 10:15:06 --> Database Driver Class Initialized
INFO - 2016-11-30 10:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:15:06 --> Controller Class Initialized
INFO - 2016-11-30 10:15:06 --> Model Class Initialized
INFO - 2016-11-30 10:15:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:15:06 --> Pagination Class Initialized
INFO - 2016-11-30 10:15:06 --> Helper loaded: app_helper
INFO - 2016-11-30 10:15:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:15:06 --> Final output sent to browser
DEBUG - 2016-11-30 10:15:06 --> Total execution time: 0.2259
INFO - 2016-11-30 10:26:24 --> Config Class Initialized
INFO - 2016-11-30 10:26:24 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:26:24 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:26:24 --> Utf8 Class Initialized
INFO - 2016-11-30 10:26:24 --> URI Class Initialized
DEBUG - 2016-11-30 10:26:24 --> No URI present. Default controller set.
INFO - 2016-11-30 10:26:24 --> Router Class Initialized
INFO - 2016-11-30 10:26:24 --> Output Class Initialized
INFO - 2016-11-30 10:26:24 --> Security Class Initialized
DEBUG - 2016-11-30 10:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:26:24 --> Input Class Initialized
INFO - 2016-11-30 10:26:24 --> Language Class Initialized
INFO - 2016-11-30 10:26:24 --> Loader Class Initialized
INFO - 2016-11-30 10:26:24 --> Helper loaded: url_helper
INFO - 2016-11-30 10:26:24 --> Helper loaded: form_helper
INFO - 2016-11-30 10:26:24 --> Database Driver Class Initialized
INFO - 2016-11-30 10:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:26:24 --> Controller Class Initialized
INFO - 2016-11-30 10:26:24 --> Model Class Initialized
INFO - 2016-11-30 10:26:24 --> Model Class Initialized
INFO - 2016-11-30 10:26:24 --> Model Class Initialized
INFO - 2016-11-30 10:26:24 --> Model Class Initialized
INFO - 2016-11-30 10:26:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:26:24 --> Pagination Class Initialized
INFO - 2016-11-30 10:26:24 --> Helper loaded: app_helper
INFO - 2016-11-30 10:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 10:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 10:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 10:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-30 10:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-30 10:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 10:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 10:26:24 --> Final output sent to browser
DEBUG - 2016-11-30 10:26:25 --> Total execution time: 0.4195
INFO - 2016-11-30 10:26:32 --> Config Class Initialized
INFO - 2016-11-30 10:26:32 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:26:32 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:26:32 --> Utf8 Class Initialized
INFO - 2016-11-30 10:26:32 --> URI Class Initialized
INFO - 2016-11-30 10:26:32 --> Router Class Initialized
INFO - 2016-11-30 10:26:32 --> Output Class Initialized
INFO - 2016-11-30 10:26:32 --> Security Class Initialized
DEBUG - 2016-11-30 10:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:26:32 --> Input Class Initialized
INFO - 2016-11-30 10:26:32 --> Language Class Initialized
INFO - 2016-11-30 10:26:32 --> Loader Class Initialized
INFO - 2016-11-30 10:26:32 --> Helper loaded: url_helper
INFO - 2016-11-30 10:26:32 --> Helper loaded: form_helper
INFO - 2016-11-30 10:26:32 --> Database Driver Class Initialized
INFO - 2016-11-30 10:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:26:32 --> Controller Class Initialized
INFO - 2016-11-30 10:26:33 --> Model Class Initialized
INFO - 2016-11-30 10:26:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:26:33 --> Pagination Class Initialized
INFO - 2016-11-30 10:26:33 --> Helper loaded: app_helper
INFO - 2016-11-30 10:26:33 --> Form Validation Class Initialized
INFO - 2016-11-30 10:26:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 10:26:33 --> Final output sent to browser
DEBUG - 2016-11-30 10:26:33 --> Total execution time: 0.2354
INFO - 2016-11-30 10:26:37 --> Config Class Initialized
INFO - 2016-11-30 10:26:37 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:26:37 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:26:37 --> Utf8 Class Initialized
INFO - 2016-11-30 10:26:37 --> URI Class Initialized
INFO - 2016-11-30 10:26:37 --> Router Class Initialized
INFO - 2016-11-30 10:26:37 --> Output Class Initialized
INFO - 2016-11-30 10:26:37 --> Security Class Initialized
DEBUG - 2016-11-30 10:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:26:37 --> Input Class Initialized
INFO - 2016-11-30 10:26:37 --> Language Class Initialized
INFO - 2016-11-30 10:26:37 --> Loader Class Initialized
INFO - 2016-11-30 10:26:37 --> Helper loaded: url_helper
INFO - 2016-11-30 10:26:37 --> Helper loaded: form_helper
INFO - 2016-11-30 10:26:37 --> Database Driver Class Initialized
INFO - 2016-11-30 10:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:26:37 --> Controller Class Initialized
INFO - 2016-11-30 10:26:37 --> Model Class Initialized
INFO - 2016-11-30 10:26:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:26:37 --> Pagination Class Initialized
INFO - 2016-11-30 10:26:37 --> Helper loaded: app_helper
INFO - 2016-11-30 10:26:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:26:38 --> Final output sent to browser
DEBUG - 2016-11-30 10:26:38 --> Total execution time: 0.3043
INFO - 2016-11-30 10:26:41 --> Config Class Initialized
INFO - 2016-11-30 10:26:41 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:26:41 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:26:41 --> Utf8 Class Initialized
INFO - 2016-11-30 10:26:41 --> URI Class Initialized
DEBUG - 2016-11-30 10:26:41 --> No URI present. Default controller set.
INFO - 2016-11-30 10:26:41 --> Router Class Initialized
INFO - 2016-11-30 10:26:41 --> Output Class Initialized
INFO - 2016-11-30 10:26:41 --> Security Class Initialized
DEBUG - 2016-11-30 10:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:26:41 --> Input Class Initialized
INFO - 2016-11-30 10:26:41 --> Language Class Initialized
INFO - 2016-11-30 10:26:41 --> Loader Class Initialized
INFO - 2016-11-30 10:26:41 --> Helper loaded: url_helper
INFO - 2016-11-30 10:26:41 --> Helper loaded: form_helper
INFO - 2016-11-30 10:26:41 --> Database Driver Class Initialized
INFO - 2016-11-30 10:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:26:41 --> Controller Class Initialized
INFO - 2016-11-30 10:26:41 --> Model Class Initialized
INFO - 2016-11-30 10:26:41 --> Model Class Initialized
INFO - 2016-11-30 10:26:41 --> Model Class Initialized
INFO - 2016-11-30 10:26:41 --> Model Class Initialized
INFO - 2016-11-30 10:26:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:26:41 --> Pagination Class Initialized
INFO - 2016-11-30 10:26:41 --> Helper loaded: app_helper
INFO - 2016-11-30 10:26:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 10:26:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 10:26:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 10:26:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-30 10:26:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:26:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-30 10:26:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 10:26:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 10:26:41 --> Final output sent to browser
DEBUG - 2016-11-30 10:26:42 --> Total execution time: 0.7288
INFO - 2016-11-30 10:26:45 --> Config Class Initialized
INFO - 2016-11-30 10:26:45 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:26:45 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:26:45 --> Utf8 Class Initialized
INFO - 2016-11-30 10:26:45 --> URI Class Initialized
INFO - 2016-11-30 10:26:45 --> Router Class Initialized
INFO - 2016-11-30 10:26:45 --> Output Class Initialized
INFO - 2016-11-30 10:26:45 --> Security Class Initialized
DEBUG - 2016-11-30 10:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:26:45 --> Input Class Initialized
INFO - 2016-11-30 10:26:45 --> Language Class Initialized
INFO - 2016-11-30 10:26:45 --> Loader Class Initialized
INFO - 2016-11-30 10:26:45 --> Helper loaded: url_helper
INFO - 2016-11-30 10:26:45 --> Helper loaded: form_helper
INFO - 2016-11-30 10:26:45 --> Database Driver Class Initialized
INFO - 2016-11-30 10:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:26:45 --> Controller Class Initialized
INFO - 2016-11-30 10:26:45 --> Model Class Initialized
INFO - 2016-11-30 10:26:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:26:45 --> Pagination Class Initialized
INFO - 2016-11-30 10:26:45 --> Helper loaded: app_helper
INFO - 2016-11-30 10:26:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:26:45 --> Final output sent to browser
DEBUG - 2016-11-30 10:26:45 --> Total execution time: 0.2265
INFO - 2016-11-30 10:27:08 --> Config Class Initialized
INFO - 2016-11-30 10:27:08 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:27:08 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:27:08 --> Utf8 Class Initialized
INFO - 2016-11-30 10:27:08 --> URI Class Initialized
INFO - 2016-11-30 10:27:08 --> Router Class Initialized
INFO - 2016-11-30 10:27:08 --> Output Class Initialized
INFO - 2016-11-30 10:27:08 --> Security Class Initialized
DEBUG - 2016-11-30 10:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:27:08 --> Input Class Initialized
INFO - 2016-11-30 10:27:08 --> Language Class Initialized
INFO - 2016-11-30 10:27:08 --> Loader Class Initialized
INFO - 2016-11-30 10:27:08 --> Helper loaded: url_helper
INFO - 2016-11-30 10:27:08 --> Helper loaded: form_helper
INFO - 2016-11-30 10:27:08 --> Database Driver Class Initialized
INFO - 2016-11-30 10:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:27:08 --> Controller Class Initialized
INFO - 2016-11-30 10:27:08 --> Model Class Initialized
INFO - 2016-11-30 10:27:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:27:08 --> Pagination Class Initialized
INFO - 2016-11-30 10:27:08 --> Helper loaded: app_helper
INFO - 2016-11-30 10:27:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:27:08 --> Final output sent to browser
DEBUG - 2016-11-30 10:27:08 --> Total execution time: 0.2317
INFO - 2016-11-30 10:30:52 --> Config Class Initialized
INFO - 2016-11-30 10:30:52 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:30:52 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:30:52 --> Utf8 Class Initialized
INFO - 2016-11-30 10:30:52 --> URI Class Initialized
DEBUG - 2016-11-30 10:30:52 --> No URI present. Default controller set.
INFO - 2016-11-30 10:30:52 --> Router Class Initialized
INFO - 2016-11-30 10:30:52 --> Output Class Initialized
INFO - 2016-11-30 10:30:52 --> Security Class Initialized
DEBUG - 2016-11-30 10:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:30:52 --> Input Class Initialized
INFO - 2016-11-30 10:30:52 --> Language Class Initialized
INFO - 2016-11-30 10:30:52 --> Loader Class Initialized
INFO - 2016-11-30 10:30:52 --> Helper loaded: url_helper
INFO - 2016-11-30 10:30:52 --> Helper loaded: form_helper
INFO - 2016-11-30 10:30:52 --> Database Driver Class Initialized
INFO - 2016-11-30 10:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:30:52 --> Controller Class Initialized
INFO - 2016-11-30 10:30:52 --> Model Class Initialized
INFO - 2016-11-30 10:30:52 --> Model Class Initialized
INFO - 2016-11-30 10:30:52 --> Model Class Initialized
INFO - 2016-11-30 10:30:52 --> Model Class Initialized
INFO - 2016-11-30 10:30:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:30:52 --> Pagination Class Initialized
INFO - 2016-11-30 10:30:52 --> Helper loaded: app_helper
INFO - 2016-11-30 10:30:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 10:30:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 10:30:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 10:30:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-30 10:30:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:30:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-30 10:30:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 10:30:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 10:30:52 --> Final output sent to browser
DEBUG - 2016-11-30 10:30:52 --> Total execution time: 0.4341
INFO - 2016-11-30 10:31:04 --> Config Class Initialized
INFO - 2016-11-30 10:31:04 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:31:04 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:31:04 --> Utf8 Class Initialized
INFO - 2016-11-30 10:31:04 --> URI Class Initialized
INFO - 2016-11-30 10:31:04 --> Router Class Initialized
INFO - 2016-11-30 10:31:04 --> Output Class Initialized
INFO - 2016-11-30 10:31:04 --> Security Class Initialized
DEBUG - 2016-11-30 10:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:31:04 --> Input Class Initialized
INFO - 2016-11-30 10:31:04 --> Language Class Initialized
INFO - 2016-11-30 10:31:04 --> Loader Class Initialized
INFO - 2016-11-30 10:31:04 --> Helper loaded: url_helper
INFO - 2016-11-30 10:31:04 --> Helper loaded: form_helper
INFO - 2016-11-30 10:31:04 --> Database Driver Class Initialized
INFO - 2016-11-30 10:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:31:04 --> Controller Class Initialized
INFO - 2016-11-30 10:31:04 --> Model Class Initialized
INFO - 2016-11-30 10:31:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:31:04 --> Pagination Class Initialized
INFO - 2016-11-30 10:31:04 --> Helper loaded: app_helper
INFO - 2016-11-30 10:31:04 --> Form Validation Class Initialized
INFO - 2016-11-30 10:31:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 10:31:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:31:04 --> Final output sent to browser
DEBUG - 2016-11-30 10:31:04 --> Total execution time: 0.3500
INFO - 2016-11-30 10:31:08 --> Config Class Initialized
INFO - 2016-11-30 10:31:08 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:31:08 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:31:08 --> Utf8 Class Initialized
INFO - 2016-11-30 10:31:08 --> URI Class Initialized
DEBUG - 2016-11-30 10:31:09 --> No URI present. Default controller set.
INFO - 2016-11-30 10:31:09 --> Router Class Initialized
INFO - 2016-11-30 10:31:09 --> Output Class Initialized
INFO - 2016-11-30 10:31:09 --> Security Class Initialized
DEBUG - 2016-11-30 10:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:31:09 --> Input Class Initialized
INFO - 2016-11-30 10:31:09 --> Language Class Initialized
INFO - 2016-11-30 10:31:09 --> Loader Class Initialized
INFO - 2016-11-30 10:31:09 --> Helper loaded: url_helper
INFO - 2016-11-30 10:31:09 --> Helper loaded: form_helper
INFO - 2016-11-30 10:31:09 --> Database Driver Class Initialized
INFO - 2016-11-30 10:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:31:09 --> Controller Class Initialized
INFO - 2016-11-30 10:31:09 --> Model Class Initialized
INFO - 2016-11-30 10:31:09 --> Model Class Initialized
INFO - 2016-11-30 10:31:09 --> Model Class Initialized
INFO - 2016-11-30 10:31:09 --> Model Class Initialized
INFO - 2016-11-30 10:31:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:31:09 --> Pagination Class Initialized
INFO - 2016-11-30 10:31:09 --> Helper loaded: app_helper
INFO - 2016-11-30 10:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 10:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 10:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 10:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-30 10:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-30 10:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 10:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 10:31:09 --> Final output sent to browser
DEBUG - 2016-11-30 10:31:09 --> Total execution time: 0.6516
INFO - 2016-11-30 10:31:31 --> Config Class Initialized
INFO - 2016-11-30 10:31:31 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:31:31 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:31:31 --> Utf8 Class Initialized
INFO - 2016-11-30 10:31:31 --> URI Class Initialized
INFO - 2016-11-30 10:31:31 --> Router Class Initialized
INFO - 2016-11-30 10:31:31 --> Output Class Initialized
INFO - 2016-11-30 10:31:31 --> Security Class Initialized
DEBUG - 2016-11-30 10:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:31:31 --> Input Class Initialized
INFO - 2016-11-30 10:31:31 --> Language Class Initialized
INFO - 2016-11-30 10:31:31 --> Loader Class Initialized
INFO - 2016-11-30 10:31:31 --> Helper loaded: url_helper
INFO - 2016-11-30 10:31:31 --> Helper loaded: form_helper
INFO - 2016-11-30 10:31:31 --> Database Driver Class Initialized
INFO - 2016-11-30 10:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:31:31 --> Controller Class Initialized
INFO - 2016-11-30 10:31:31 --> Model Class Initialized
INFO - 2016-11-30 10:31:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:31:31 --> Pagination Class Initialized
INFO - 2016-11-30 10:31:31 --> Helper loaded: app_helper
INFO - 2016-11-30 10:31:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:31:31 --> Final output sent to browser
DEBUG - 2016-11-30 10:31:31 --> Total execution time: 0.4209
INFO - 2016-11-30 10:31:32 --> Config Class Initialized
INFO - 2016-11-30 10:31:32 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:31:32 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:31:32 --> Utf8 Class Initialized
INFO - 2016-11-30 10:31:32 --> URI Class Initialized
DEBUG - 2016-11-30 10:31:32 --> No URI present. Default controller set.
INFO - 2016-11-30 10:31:32 --> Router Class Initialized
INFO - 2016-11-30 10:31:32 --> Output Class Initialized
INFO - 2016-11-30 10:31:32 --> Security Class Initialized
DEBUG - 2016-11-30 10:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:31:32 --> Input Class Initialized
INFO - 2016-11-30 10:31:32 --> Language Class Initialized
INFO - 2016-11-30 10:31:32 --> Loader Class Initialized
INFO - 2016-11-30 10:31:32 --> Helper loaded: url_helper
INFO - 2016-11-30 10:31:32 --> Helper loaded: form_helper
INFO - 2016-11-30 10:31:32 --> Database Driver Class Initialized
INFO - 2016-11-30 10:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:31:32 --> Controller Class Initialized
INFO - 2016-11-30 10:31:32 --> Model Class Initialized
INFO - 2016-11-30 10:31:32 --> Model Class Initialized
INFO - 2016-11-30 10:31:32 --> Model Class Initialized
INFO - 2016-11-30 10:31:32 --> Model Class Initialized
INFO - 2016-11-30 10:31:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:31:32 --> Pagination Class Initialized
INFO - 2016-11-30 10:31:32 --> Helper loaded: app_helper
INFO - 2016-11-30 10:31:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 10:31:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 10:31:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 10:31:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-30 10:31:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:31:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-30 10:31:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 10:31:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 10:31:32 --> Final output sent to browser
DEBUG - 2016-11-30 10:31:32 --> Total execution time: 0.4113
INFO - 2016-11-30 10:31:45 --> Config Class Initialized
INFO - 2016-11-30 10:31:45 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:31:45 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:31:45 --> Utf8 Class Initialized
INFO - 2016-11-30 10:31:45 --> URI Class Initialized
INFO - 2016-11-30 10:31:45 --> Router Class Initialized
INFO - 2016-11-30 10:31:45 --> Output Class Initialized
INFO - 2016-11-30 10:31:45 --> Security Class Initialized
DEBUG - 2016-11-30 10:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:31:45 --> Input Class Initialized
INFO - 2016-11-30 10:31:45 --> Language Class Initialized
INFO - 2016-11-30 10:31:45 --> Loader Class Initialized
INFO - 2016-11-30 10:31:45 --> Helper loaded: url_helper
INFO - 2016-11-30 10:31:45 --> Helper loaded: form_helper
INFO - 2016-11-30 10:31:45 --> Database Driver Class Initialized
INFO - 2016-11-30 10:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:31:45 --> Controller Class Initialized
INFO - 2016-11-30 10:31:45 --> Model Class Initialized
INFO - 2016-11-30 10:31:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:31:45 --> Pagination Class Initialized
INFO - 2016-11-30 10:31:45 --> Helper loaded: app_helper
INFO - 2016-11-30 10:31:45 --> Form Validation Class Initialized
INFO - 2016-11-30 10:31:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 10:31:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:31:45 --> Final output sent to browser
DEBUG - 2016-11-30 10:31:45 --> Total execution time: 0.3579
INFO - 2016-11-30 10:34:12 --> Config Class Initialized
INFO - 2016-11-30 10:34:12 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:34:12 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:34:12 --> Utf8 Class Initialized
INFO - 2016-11-30 10:34:12 --> URI Class Initialized
INFO - 2016-11-30 10:34:12 --> Router Class Initialized
INFO - 2016-11-30 10:34:12 --> Output Class Initialized
INFO - 2016-11-30 10:34:12 --> Security Class Initialized
DEBUG - 2016-11-30 10:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:34:12 --> Input Class Initialized
INFO - 2016-11-30 10:34:12 --> Language Class Initialized
INFO - 2016-11-30 10:34:12 --> Loader Class Initialized
INFO - 2016-11-30 10:34:12 --> Helper loaded: url_helper
INFO - 2016-11-30 10:34:12 --> Helper loaded: form_helper
INFO - 2016-11-30 10:34:12 --> Database Driver Class Initialized
INFO - 2016-11-30 10:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:34:12 --> Controller Class Initialized
INFO - 2016-11-30 10:34:12 --> Model Class Initialized
INFO - 2016-11-30 10:34:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:34:12 --> Pagination Class Initialized
INFO - 2016-11-30 10:34:12 --> Helper loaded: app_helper
INFO - 2016-11-30 10:34:12 --> Form Validation Class Initialized
INFO - 2016-11-30 10:34:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 10:34:12 --> Final output sent to browser
DEBUG - 2016-11-30 10:34:12 --> Total execution time: 0.3169
INFO - 2016-11-30 10:34:19 --> Config Class Initialized
INFO - 2016-11-30 10:34:19 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:34:19 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:34:19 --> Utf8 Class Initialized
INFO - 2016-11-30 10:34:19 --> URI Class Initialized
DEBUG - 2016-11-30 10:34:19 --> No URI present. Default controller set.
INFO - 2016-11-30 10:34:19 --> Router Class Initialized
INFO - 2016-11-30 10:34:19 --> Output Class Initialized
INFO - 2016-11-30 10:34:19 --> Security Class Initialized
DEBUG - 2016-11-30 10:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:34:19 --> Input Class Initialized
INFO - 2016-11-30 10:34:19 --> Language Class Initialized
INFO - 2016-11-30 10:34:19 --> Loader Class Initialized
INFO - 2016-11-30 10:34:19 --> Helper loaded: url_helper
INFO - 2016-11-30 10:34:19 --> Helper loaded: form_helper
INFO - 2016-11-30 10:34:19 --> Database Driver Class Initialized
INFO - 2016-11-30 10:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:34:19 --> Controller Class Initialized
INFO - 2016-11-30 10:34:19 --> Model Class Initialized
INFO - 2016-11-30 10:34:19 --> Model Class Initialized
INFO - 2016-11-30 10:34:19 --> Model Class Initialized
INFO - 2016-11-30 10:34:19 --> Model Class Initialized
INFO - 2016-11-30 10:34:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:34:19 --> Pagination Class Initialized
INFO - 2016-11-30 10:34:19 --> Helper loaded: app_helper
INFO - 2016-11-30 10:34:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 10:34:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 10:34:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 10:34:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-30 10:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-30 10:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 10:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 10:34:20 --> Final output sent to browser
DEBUG - 2016-11-30 10:34:20 --> Total execution time: 0.4118
INFO - 2016-11-30 10:34:24 --> Config Class Initialized
INFO - 2016-11-30 10:34:24 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:34:24 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:34:24 --> Utf8 Class Initialized
INFO - 2016-11-30 10:34:24 --> URI Class Initialized
INFO - 2016-11-30 10:34:24 --> Router Class Initialized
INFO - 2016-11-30 10:34:24 --> Output Class Initialized
INFO - 2016-11-30 10:34:24 --> Security Class Initialized
DEBUG - 2016-11-30 10:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:34:24 --> Input Class Initialized
INFO - 2016-11-30 10:34:24 --> Language Class Initialized
INFO - 2016-11-30 10:34:24 --> Loader Class Initialized
INFO - 2016-11-30 10:34:24 --> Helper loaded: url_helper
INFO - 2016-11-30 10:34:24 --> Helper loaded: form_helper
INFO - 2016-11-30 10:34:24 --> Database Driver Class Initialized
INFO - 2016-11-30 10:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:34:24 --> Controller Class Initialized
INFO - 2016-11-30 10:34:24 --> Model Class Initialized
INFO - 2016-11-30 10:34:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:34:24 --> Pagination Class Initialized
INFO - 2016-11-30 10:34:24 --> Helper loaded: app_helper
INFO - 2016-11-30 10:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:34:24 --> Final output sent to browser
DEBUG - 2016-11-30 10:34:24 --> Total execution time: 0.3931
INFO - 2016-11-30 10:34:26 --> Config Class Initialized
INFO - 2016-11-30 10:34:26 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:34:26 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:34:26 --> Utf8 Class Initialized
INFO - 2016-11-30 10:34:26 --> URI Class Initialized
DEBUG - 2016-11-30 10:34:26 --> No URI present. Default controller set.
INFO - 2016-11-30 10:34:26 --> Router Class Initialized
INFO - 2016-11-30 10:34:26 --> Output Class Initialized
INFO - 2016-11-30 10:34:26 --> Security Class Initialized
DEBUG - 2016-11-30 10:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:34:26 --> Input Class Initialized
INFO - 2016-11-30 10:34:26 --> Language Class Initialized
INFO - 2016-11-30 10:34:26 --> Loader Class Initialized
INFO - 2016-11-30 10:34:26 --> Helper loaded: url_helper
INFO - 2016-11-30 10:34:26 --> Helper loaded: form_helper
INFO - 2016-11-30 10:34:26 --> Database Driver Class Initialized
INFO - 2016-11-30 10:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:34:26 --> Controller Class Initialized
INFO - 2016-11-30 10:34:26 --> Model Class Initialized
INFO - 2016-11-30 10:34:26 --> Model Class Initialized
INFO - 2016-11-30 10:34:26 --> Model Class Initialized
INFO - 2016-11-30 10:34:26 --> Model Class Initialized
INFO - 2016-11-30 10:34:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:34:26 --> Pagination Class Initialized
INFO - 2016-11-30 10:34:26 --> Helper loaded: app_helper
INFO - 2016-11-30 10:34:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 10:34:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 10:34:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 10:34:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-30 10:34:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:34:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-30 10:34:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 10:34:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 10:34:27 --> Final output sent to browser
DEBUG - 2016-11-30 10:34:27 --> Total execution time: 0.4681
INFO - 2016-11-30 10:34:37 --> Config Class Initialized
INFO - 2016-11-30 10:34:37 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:34:37 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:34:37 --> Utf8 Class Initialized
INFO - 2016-11-30 10:34:37 --> URI Class Initialized
INFO - 2016-11-30 10:34:37 --> Router Class Initialized
INFO - 2016-11-30 10:34:37 --> Output Class Initialized
INFO - 2016-11-30 10:34:37 --> Security Class Initialized
DEBUG - 2016-11-30 10:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:34:37 --> Input Class Initialized
INFO - 2016-11-30 10:34:37 --> Language Class Initialized
INFO - 2016-11-30 10:34:37 --> Loader Class Initialized
INFO - 2016-11-30 10:34:37 --> Helper loaded: url_helper
INFO - 2016-11-30 10:34:37 --> Helper loaded: form_helper
INFO - 2016-11-30 10:34:37 --> Database Driver Class Initialized
INFO - 2016-11-30 10:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:34:37 --> Controller Class Initialized
INFO - 2016-11-30 10:34:37 --> Model Class Initialized
INFO - 2016-11-30 10:34:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:34:37 --> Pagination Class Initialized
INFO - 2016-11-30 10:34:37 --> Helper loaded: app_helper
INFO - 2016-11-30 10:34:37 --> Form Validation Class Initialized
INFO - 2016-11-30 10:34:37 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-30 10:34:37 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\hrm\add_leave_record_sidebar.php 31
INFO - 2016-11-30 10:34:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:34:37 --> Final output sent to browser
DEBUG - 2016-11-30 10:34:38 --> Total execution time: 0.5279
INFO - 2016-11-30 10:37:06 --> Config Class Initialized
INFO - 2016-11-30 10:37:06 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:37:06 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:37:06 --> Utf8 Class Initialized
INFO - 2016-11-30 10:37:06 --> URI Class Initialized
DEBUG - 2016-11-30 10:37:06 --> No URI present. Default controller set.
INFO - 2016-11-30 10:37:06 --> Router Class Initialized
INFO - 2016-11-30 10:37:06 --> Output Class Initialized
INFO - 2016-11-30 10:37:06 --> Security Class Initialized
DEBUG - 2016-11-30 10:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:37:06 --> Input Class Initialized
INFO - 2016-11-30 10:37:06 --> Language Class Initialized
INFO - 2016-11-30 10:37:06 --> Loader Class Initialized
INFO - 2016-11-30 10:37:06 --> Helper loaded: url_helper
INFO - 2016-11-30 10:37:06 --> Helper loaded: form_helper
INFO - 2016-11-30 10:37:06 --> Database Driver Class Initialized
INFO - 2016-11-30 10:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:37:06 --> Controller Class Initialized
INFO - 2016-11-30 10:37:06 --> Model Class Initialized
INFO - 2016-11-30 10:37:06 --> Model Class Initialized
INFO - 2016-11-30 10:37:06 --> Model Class Initialized
INFO - 2016-11-30 10:37:06 --> Model Class Initialized
INFO - 2016-11-30 10:37:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:37:06 --> Pagination Class Initialized
INFO - 2016-11-30 10:37:06 --> Helper loaded: app_helper
INFO - 2016-11-30 10:37:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 10:37:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 10:37:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 10:37:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-30 10:37:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:37:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-30 10:37:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 10:37:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 10:37:06 --> Final output sent to browser
DEBUG - 2016-11-30 10:37:07 --> Total execution time: 0.4420
INFO - 2016-11-30 10:37:12 --> Config Class Initialized
INFO - 2016-11-30 10:37:12 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:37:12 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:37:12 --> Utf8 Class Initialized
INFO - 2016-11-30 10:37:12 --> URI Class Initialized
INFO - 2016-11-30 10:37:12 --> Router Class Initialized
INFO - 2016-11-30 10:37:12 --> Output Class Initialized
INFO - 2016-11-30 10:37:12 --> Security Class Initialized
DEBUG - 2016-11-30 10:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:37:12 --> Input Class Initialized
INFO - 2016-11-30 10:37:12 --> Language Class Initialized
INFO - 2016-11-30 10:37:12 --> Loader Class Initialized
INFO - 2016-11-30 10:37:12 --> Helper loaded: url_helper
INFO - 2016-11-30 10:37:12 --> Helper loaded: form_helper
INFO - 2016-11-30 10:37:12 --> Database Driver Class Initialized
INFO - 2016-11-30 10:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:37:12 --> Controller Class Initialized
INFO - 2016-11-30 10:37:12 --> Model Class Initialized
INFO - 2016-11-30 10:37:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:37:12 --> Pagination Class Initialized
INFO - 2016-11-30 10:37:12 --> Helper loaded: app_helper
INFO - 2016-11-30 10:37:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:37:12 --> Final output sent to browser
DEBUG - 2016-11-30 10:37:12 --> Total execution time: 0.3865
INFO - 2016-11-30 10:37:22 --> Config Class Initialized
INFO - 2016-11-30 10:37:22 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:37:22 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:37:22 --> Utf8 Class Initialized
INFO - 2016-11-30 10:37:22 --> URI Class Initialized
INFO - 2016-11-30 10:37:22 --> Router Class Initialized
INFO - 2016-11-30 10:37:22 --> Output Class Initialized
INFO - 2016-11-30 10:37:22 --> Security Class Initialized
DEBUG - 2016-11-30 10:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:37:22 --> Input Class Initialized
INFO - 2016-11-30 10:37:22 --> Language Class Initialized
INFO - 2016-11-30 10:37:22 --> Loader Class Initialized
INFO - 2016-11-30 10:37:22 --> Helper loaded: url_helper
INFO - 2016-11-30 10:37:22 --> Helper loaded: form_helper
INFO - 2016-11-30 10:37:22 --> Database Driver Class Initialized
INFO - 2016-11-30 10:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:37:22 --> Controller Class Initialized
INFO - 2016-11-30 10:37:22 --> Model Class Initialized
INFO - 2016-11-30 10:37:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:37:22 --> Pagination Class Initialized
INFO - 2016-11-30 10:37:22 --> Helper loaded: app_helper
INFO - 2016-11-30 10:37:22 --> Form Validation Class Initialized
INFO - 2016-11-30 10:37:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 10:37:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:37:22 --> Final output sent to browser
DEBUG - 2016-11-30 10:37:22 --> Total execution time: 0.3994
INFO - 2016-11-30 10:38:42 --> Config Class Initialized
INFO - 2016-11-30 10:38:42 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:38:42 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:38:42 --> Utf8 Class Initialized
INFO - 2016-11-30 10:38:42 --> URI Class Initialized
DEBUG - 2016-11-30 10:38:42 --> No URI present. Default controller set.
INFO - 2016-11-30 10:38:42 --> Router Class Initialized
INFO - 2016-11-30 10:38:42 --> Output Class Initialized
INFO - 2016-11-30 10:38:42 --> Security Class Initialized
DEBUG - 2016-11-30 10:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:38:42 --> Input Class Initialized
INFO - 2016-11-30 10:38:42 --> Language Class Initialized
INFO - 2016-11-30 10:38:42 --> Loader Class Initialized
INFO - 2016-11-30 10:38:42 --> Helper loaded: url_helper
INFO - 2016-11-30 10:38:42 --> Helper loaded: form_helper
INFO - 2016-11-30 10:38:42 --> Database Driver Class Initialized
INFO - 2016-11-30 10:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:38:42 --> Controller Class Initialized
INFO - 2016-11-30 10:38:42 --> Model Class Initialized
INFO - 2016-11-30 10:38:42 --> Model Class Initialized
INFO - 2016-11-30 10:38:42 --> Model Class Initialized
INFO - 2016-11-30 10:38:42 --> Model Class Initialized
INFO - 2016-11-30 10:38:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:38:42 --> Pagination Class Initialized
INFO - 2016-11-30 10:38:42 --> Helper loaded: app_helper
INFO - 2016-11-30 10:38:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 10:38:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 10:38:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 10:38:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-30 10:38:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:38:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-30 10:38:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 10:38:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 10:38:42 --> Final output sent to browser
DEBUG - 2016-11-30 10:38:43 --> Total execution time: 0.4448
INFO - 2016-11-30 10:38:51 --> Config Class Initialized
INFO - 2016-11-30 10:38:51 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:38:51 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:38:51 --> Utf8 Class Initialized
INFO - 2016-11-30 10:38:51 --> URI Class Initialized
INFO - 2016-11-30 10:38:51 --> Router Class Initialized
INFO - 2016-11-30 10:38:51 --> Output Class Initialized
INFO - 2016-11-30 10:38:51 --> Security Class Initialized
DEBUG - 2016-11-30 10:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:38:51 --> Input Class Initialized
INFO - 2016-11-30 10:38:51 --> Language Class Initialized
INFO - 2016-11-30 10:38:51 --> Loader Class Initialized
INFO - 2016-11-30 10:38:51 --> Helper loaded: url_helper
INFO - 2016-11-30 10:38:51 --> Helper loaded: form_helper
INFO - 2016-11-30 10:38:51 --> Database Driver Class Initialized
INFO - 2016-11-30 10:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:38:51 --> Controller Class Initialized
INFO - 2016-11-30 10:38:51 --> Model Class Initialized
INFO - 2016-11-30 10:38:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:38:51 --> Pagination Class Initialized
INFO - 2016-11-30 10:38:51 --> Helper loaded: app_helper
INFO - 2016-11-30 10:38:51 --> Form Validation Class Initialized
INFO - 2016-11-30 10:38:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 10:38:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:40:23 --> Config Class Initialized
INFO - 2016-11-30 10:40:23 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:40:23 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:40:23 --> Utf8 Class Initialized
INFO - 2016-11-30 10:40:23 --> URI Class Initialized
DEBUG - 2016-11-30 10:40:23 --> No URI present. Default controller set.
INFO - 2016-11-30 10:40:23 --> Router Class Initialized
INFO - 2016-11-30 10:40:23 --> Output Class Initialized
INFO - 2016-11-30 10:40:23 --> Security Class Initialized
DEBUG - 2016-11-30 10:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:40:23 --> Input Class Initialized
INFO - 2016-11-30 10:40:23 --> Language Class Initialized
INFO - 2016-11-30 10:40:23 --> Loader Class Initialized
INFO - 2016-11-30 10:40:23 --> Helper loaded: url_helper
INFO - 2016-11-30 10:40:23 --> Helper loaded: form_helper
INFO - 2016-11-30 10:40:23 --> Database Driver Class Initialized
INFO - 2016-11-30 10:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:40:23 --> Controller Class Initialized
INFO - 2016-11-30 10:40:23 --> Model Class Initialized
INFO - 2016-11-30 10:40:23 --> Model Class Initialized
INFO - 2016-11-30 10:40:23 --> Model Class Initialized
INFO - 2016-11-30 10:40:23 --> Model Class Initialized
INFO - 2016-11-30 10:40:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:40:23 --> Pagination Class Initialized
INFO - 2016-11-30 10:40:23 --> Helper loaded: app_helper
INFO - 2016-11-30 10:40:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 10:40:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 10:40:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 10:40:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-30 10:40:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:40:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-30 10:40:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 10:40:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 10:40:23 --> Final output sent to browser
DEBUG - 2016-11-30 10:40:23 --> Total execution time: 0.4937
INFO - 2016-11-30 10:40:36 --> Config Class Initialized
INFO - 2016-11-30 10:40:36 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:40:36 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:40:36 --> Utf8 Class Initialized
INFO - 2016-11-30 10:40:36 --> URI Class Initialized
INFO - 2016-11-30 10:40:36 --> Router Class Initialized
INFO - 2016-11-30 10:40:36 --> Output Class Initialized
INFO - 2016-11-30 10:40:36 --> Security Class Initialized
DEBUG - 2016-11-30 10:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:40:36 --> Input Class Initialized
INFO - 2016-11-30 10:40:36 --> Language Class Initialized
INFO - 2016-11-30 10:40:36 --> Loader Class Initialized
INFO - 2016-11-30 10:40:36 --> Helper loaded: url_helper
INFO - 2016-11-30 10:40:36 --> Helper loaded: form_helper
INFO - 2016-11-30 10:40:36 --> Database Driver Class Initialized
INFO - 2016-11-30 10:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:40:36 --> Controller Class Initialized
INFO - 2016-11-30 10:40:36 --> Model Class Initialized
INFO - 2016-11-30 10:40:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:40:36 --> Pagination Class Initialized
INFO - 2016-11-30 10:40:36 --> Helper loaded: app_helper
INFO - 2016-11-30 10:40:36 --> Form Validation Class Initialized
INFO - 2016-11-30 10:40:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 10:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:40:36 --> Final output sent to browser
DEBUG - 2016-11-30 10:40:36 --> Total execution time: 0.4296
INFO - 2016-11-30 10:41:00 --> Config Class Initialized
INFO - 2016-11-30 10:41:00 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:41:00 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:41:00 --> Utf8 Class Initialized
INFO - 2016-11-30 10:41:00 --> URI Class Initialized
DEBUG - 2016-11-30 10:41:00 --> No URI present. Default controller set.
INFO - 2016-11-30 10:41:00 --> Router Class Initialized
INFO - 2016-11-30 10:41:00 --> Output Class Initialized
INFO - 2016-11-30 10:41:00 --> Security Class Initialized
DEBUG - 2016-11-30 10:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:41:00 --> Input Class Initialized
INFO - 2016-11-30 10:41:00 --> Language Class Initialized
INFO - 2016-11-30 10:41:00 --> Loader Class Initialized
INFO - 2016-11-30 10:41:00 --> Helper loaded: url_helper
INFO - 2016-11-30 10:41:00 --> Helper loaded: form_helper
INFO - 2016-11-30 10:41:00 --> Database Driver Class Initialized
INFO - 2016-11-30 10:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:41:00 --> Controller Class Initialized
INFO - 2016-11-30 10:41:00 --> Model Class Initialized
INFO - 2016-11-30 10:41:00 --> Model Class Initialized
INFO - 2016-11-30 10:41:00 --> Model Class Initialized
INFO - 2016-11-30 10:41:00 --> Model Class Initialized
INFO - 2016-11-30 10:41:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:41:00 --> Pagination Class Initialized
INFO - 2016-11-30 10:41:00 --> Helper loaded: app_helper
INFO - 2016-11-30 10:41:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 10:41:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 10:41:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 10:41:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-30 10:41:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:41:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-30 10:41:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 10:41:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 10:41:00 --> Final output sent to browser
DEBUG - 2016-11-30 10:41:00 --> Total execution time: 0.4870
INFO - 2016-11-30 10:41:10 --> Config Class Initialized
INFO - 2016-11-30 10:41:10 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:41:10 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:41:10 --> Utf8 Class Initialized
INFO - 2016-11-30 10:41:10 --> URI Class Initialized
INFO - 2016-11-30 10:41:10 --> Router Class Initialized
INFO - 2016-11-30 10:41:10 --> Output Class Initialized
INFO - 2016-11-30 10:41:10 --> Security Class Initialized
DEBUG - 2016-11-30 10:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:41:10 --> Input Class Initialized
INFO - 2016-11-30 10:41:10 --> Language Class Initialized
INFO - 2016-11-30 10:41:10 --> Loader Class Initialized
INFO - 2016-11-30 10:41:10 --> Helper loaded: url_helper
INFO - 2016-11-30 10:41:10 --> Helper loaded: form_helper
INFO - 2016-11-30 10:41:10 --> Database Driver Class Initialized
INFO - 2016-11-30 10:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:41:10 --> Controller Class Initialized
INFO - 2016-11-30 10:41:10 --> Model Class Initialized
INFO - 2016-11-30 10:41:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:41:10 --> Pagination Class Initialized
INFO - 2016-11-30 10:41:10 --> Helper loaded: app_helper
INFO - 2016-11-30 10:41:10 --> Form Validation Class Initialized
INFO - 2016-11-30 10:41:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 10:41:21 --> Config Class Initialized
INFO - 2016-11-30 10:41:21 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:41:21 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:41:21 --> Utf8 Class Initialized
INFO - 2016-11-30 10:41:21 --> URI Class Initialized
INFO - 2016-11-30 10:41:21 --> Router Class Initialized
INFO - 2016-11-30 10:41:21 --> Output Class Initialized
INFO - 2016-11-30 10:41:21 --> Security Class Initialized
DEBUG - 2016-11-30 10:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:41:21 --> Input Class Initialized
INFO - 2016-11-30 10:41:21 --> Language Class Initialized
INFO - 2016-11-30 10:41:21 --> Loader Class Initialized
INFO - 2016-11-30 10:41:21 --> Helper loaded: url_helper
INFO - 2016-11-30 10:41:21 --> Helper loaded: form_helper
INFO - 2016-11-30 10:41:21 --> Database Driver Class Initialized
INFO - 2016-11-30 10:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:41:21 --> Controller Class Initialized
INFO - 2016-11-30 10:41:21 --> Model Class Initialized
INFO - 2016-11-30 10:41:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:41:21 --> Pagination Class Initialized
INFO - 2016-11-30 10:41:21 --> Helper loaded: app_helper
INFO - 2016-11-30 10:41:21 --> Form Validation Class Initialized
INFO - 2016-11-30 10:41:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 10:41:21 --> Final output sent to browser
DEBUG - 2016-11-30 10:41:21 --> Total execution time: 0.3122
INFO - 2016-11-30 10:41:30 --> Config Class Initialized
INFO - 2016-11-30 10:41:30 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:41:30 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:41:30 --> Utf8 Class Initialized
INFO - 2016-11-30 10:41:30 --> URI Class Initialized
INFO - 2016-11-30 10:41:30 --> Router Class Initialized
INFO - 2016-11-30 10:41:30 --> Output Class Initialized
INFO - 2016-11-30 10:41:30 --> Security Class Initialized
DEBUG - 2016-11-30 10:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:41:30 --> Input Class Initialized
INFO - 2016-11-30 10:41:30 --> Language Class Initialized
INFO - 2016-11-30 10:41:30 --> Loader Class Initialized
INFO - 2016-11-30 10:41:30 --> Helper loaded: url_helper
INFO - 2016-11-30 10:41:30 --> Helper loaded: form_helper
INFO - 2016-11-30 10:41:30 --> Database Driver Class Initialized
INFO - 2016-11-30 10:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:41:30 --> Controller Class Initialized
INFO - 2016-11-30 10:41:30 --> Model Class Initialized
INFO - 2016-11-30 10:41:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:41:30 --> Pagination Class Initialized
INFO - 2016-11-30 10:41:30 --> Helper loaded: app_helper
INFO - 2016-11-30 10:41:30 --> Form Validation Class Initialized
INFO - 2016-11-30 10:41:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 10:44:10 --> Config Class Initialized
INFO - 2016-11-30 10:44:10 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:44:10 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:44:10 --> Utf8 Class Initialized
INFO - 2016-11-30 10:44:10 --> URI Class Initialized
DEBUG - 2016-11-30 10:44:10 --> No URI present. Default controller set.
INFO - 2016-11-30 10:44:10 --> Router Class Initialized
INFO - 2016-11-30 10:44:10 --> Output Class Initialized
INFO - 2016-11-30 10:44:10 --> Security Class Initialized
DEBUG - 2016-11-30 10:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:44:10 --> Input Class Initialized
INFO - 2016-11-30 10:44:11 --> Language Class Initialized
INFO - 2016-11-30 10:44:11 --> Loader Class Initialized
INFO - 2016-11-30 10:44:11 --> Helper loaded: url_helper
INFO - 2016-11-30 10:44:11 --> Helper loaded: form_helper
INFO - 2016-11-30 10:44:11 --> Database Driver Class Initialized
INFO - 2016-11-30 10:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:44:11 --> Controller Class Initialized
INFO - 2016-11-30 10:44:11 --> Model Class Initialized
INFO - 2016-11-30 10:44:11 --> Model Class Initialized
INFO - 2016-11-30 10:44:11 --> Model Class Initialized
INFO - 2016-11-30 10:44:11 --> Model Class Initialized
INFO - 2016-11-30 10:44:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:44:11 --> Pagination Class Initialized
INFO - 2016-11-30 10:44:11 --> Helper loaded: app_helper
INFO - 2016-11-30 10:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 10:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 10:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 10:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-30 10:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-30 10:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 10:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 10:44:11 --> Final output sent to browser
DEBUG - 2016-11-30 10:44:11 --> Total execution time: 0.5625
INFO - 2016-11-30 10:44:24 --> Config Class Initialized
INFO - 2016-11-30 10:44:24 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:44:24 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:44:24 --> Utf8 Class Initialized
INFO - 2016-11-30 10:44:25 --> URI Class Initialized
INFO - 2016-11-30 10:44:25 --> Router Class Initialized
INFO - 2016-11-30 10:44:25 --> Output Class Initialized
INFO - 2016-11-30 10:44:25 --> Security Class Initialized
DEBUG - 2016-11-30 10:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:44:25 --> Input Class Initialized
INFO - 2016-11-30 10:44:25 --> Language Class Initialized
INFO - 2016-11-30 10:44:25 --> Loader Class Initialized
INFO - 2016-11-30 10:44:25 --> Helper loaded: url_helper
INFO - 2016-11-30 10:44:25 --> Helper loaded: form_helper
INFO - 2016-11-30 10:44:25 --> Database Driver Class Initialized
INFO - 2016-11-30 10:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:44:25 --> Controller Class Initialized
INFO - 2016-11-30 10:44:25 --> Model Class Initialized
INFO - 2016-11-30 10:44:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:44:25 --> Pagination Class Initialized
INFO - 2016-11-30 10:44:25 --> Helper loaded: app_helper
INFO - 2016-11-30 10:44:25 --> Form Validation Class Initialized
INFO - 2016-11-30 10:44:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 10:44:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:44:25 --> Final output sent to browser
DEBUG - 2016-11-30 10:44:25 --> Total execution time: 0.4366
INFO - 2016-11-30 10:44:41 --> Config Class Initialized
INFO - 2016-11-30 10:44:41 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:44:41 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:44:41 --> Utf8 Class Initialized
INFO - 2016-11-30 10:44:41 --> URI Class Initialized
INFO - 2016-11-30 10:44:41 --> Router Class Initialized
INFO - 2016-11-30 10:44:41 --> Output Class Initialized
INFO - 2016-11-30 10:44:41 --> Security Class Initialized
DEBUG - 2016-11-30 10:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:44:41 --> Input Class Initialized
INFO - 2016-11-30 10:44:41 --> Language Class Initialized
INFO - 2016-11-30 10:44:41 --> Loader Class Initialized
INFO - 2016-11-30 10:44:41 --> Helper loaded: url_helper
INFO - 2016-11-30 10:44:41 --> Helper loaded: form_helper
INFO - 2016-11-30 10:44:41 --> Database Driver Class Initialized
INFO - 2016-11-30 10:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:44:41 --> Controller Class Initialized
INFO - 2016-11-30 10:44:41 --> Model Class Initialized
INFO - 2016-11-30 10:44:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:44:41 --> Pagination Class Initialized
INFO - 2016-11-30 10:44:41 --> Helper loaded: app_helper
INFO - 2016-11-30 10:44:41 --> Form Validation Class Initialized
INFO - 2016-11-30 10:44:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 10:44:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:44:41 --> Final output sent to browser
DEBUG - 2016-11-30 10:44:41 --> Total execution time: 0.4002
INFO - 2016-11-30 10:44:51 --> Config Class Initialized
INFO - 2016-11-30 10:44:51 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:44:51 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:44:51 --> Utf8 Class Initialized
INFO - 2016-11-30 10:44:51 --> URI Class Initialized
INFO - 2016-11-30 10:44:51 --> Router Class Initialized
INFO - 2016-11-30 10:44:51 --> Output Class Initialized
INFO - 2016-11-30 10:44:51 --> Security Class Initialized
DEBUG - 2016-11-30 10:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:44:51 --> Input Class Initialized
INFO - 2016-11-30 10:44:51 --> Language Class Initialized
INFO - 2016-11-30 10:44:51 --> Loader Class Initialized
INFO - 2016-11-30 10:44:51 --> Helper loaded: url_helper
INFO - 2016-11-30 10:44:51 --> Helper loaded: form_helper
INFO - 2016-11-30 10:44:51 --> Database Driver Class Initialized
INFO - 2016-11-30 10:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:44:51 --> Controller Class Initialized
INFO - 2016-11-30 10:44:51 --> Model Class Initialized
INFO - 2016-11-30 10:44:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:44:51 --> Pagination Class Initialized
INFO - 2016-11-30 10:44:51 --> Helper loaded: app_helper
INFO - 2016-11-30 10:44:51 --> Form Validation Class Initialized
INFO - 2016-11-30 10:44:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 10:44:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:44:51 --> Final output sent to browser
DEBUG - 2016-11-30 10:44:51 --> Total execution time: 0.3875
INFO - 2016-11-30 10:44:54 --> Config Class Initialized
INFO - 2016-11-30 10:44:54 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:44:54 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:44:54 --> Utf8 Class Initialized
INFO - 2016-11-30 10:44:54 --> URI Class Initialized
DEBUG - 2016-11-30 10:44:54 --> No URI present. Default controller set.
INFO - 2016-11-30 10:44:55 --> Router Class Initialized
INFO - 2016-11-30 10:44:55 --> Output Class Initialized
INFO - 2016-11-30 10:44:55 --> Security Class Initialized
DEBUG - 2016-11-30 10:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:44:55 --> Input Class Initialized
INFO - 2016-11-30 10:44:55 --> Language Class Initialized
INFO - 2016-11-30 10:44:55 --> Loader Class Initialized
INFO - 2016-11-30 10:44:55 --> Helper loaded: url_helper
INFO - 2016-11-30 10:44:55 --> Helper loaded: form_helper
INFO - 2016-11-30 10:44:55 --> Database Driver Class Initialized
INFO - 2016-11-30 10:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:44:55 --> Controller Class Initialized
INFO - 2016-11-30 10:44:55 --> Model Class Initialized
INFO - 2016-11-30 10:44:55 --> Model Class Initialized
INFO - 2016-11-30 10:44:55 --> Model Class Initialized
INFO - 2016-11-30 10:44:55 --> Model Class Initialized
INFO - 2016-11-30 10:44:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:44:55 --> Pagination Class Initialized
INFO - 2016-11-30 10:44:55 --> Helper loaded: app_helper
INFO - 2016-11-30 10:44:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 10:44:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 10:44:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 10:44:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-30 10:44:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:44:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-30 10:44:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 10:44:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 10:44:55 --> Final output sent to browser
DEBUG - 2016-11-30 10:44:55 --> Total execution time: 0.6264
INFO - 2016-11-30 10:45:05 --> Config Class Initialized
INFO - 2016-11-30 10:45:05 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:45:05 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:45:05 --> Utf8 Class Initialized
INFO - 2016-11-30 10:45:05 --> URI Class Initialized
INFO - 2016-11-30 10:45:05 --> Router Class Initialized
INFO - 2016-11-30 10:45:05 --> Output Class Initialized
INFO - 2016-11-30 10:45:05 --> Security Class Initialized
DEBUG - 2016-11-30 10:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:45:06 --> Input Class Initialized
INFO - 2016-11-30 10:45:06 --> Language Class Initialized
INFO - 2016-11-30 10:45:06 --> Loader Class Initialized
INFO - 2016-11-30 10:45:06 --> Helper loaded: url_helper
INFO - 2016-11-30 10:45:06 --> Helper loaded: form_helper
INFO - 2016-11-30 10:45:06 --> Database Driver Class Initialized
INFO - 2016-11-30 10:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:45:06 --> Controller Class Initialized
INFO - 2016-11-30 10:45:06 --> Model Class Initialized
INFO - 2016-11-30 10:45:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:45:06 --> Pagination Class Initialized
INFO - 2016-11-30 10:45:06 --> Helper loaded: app_helper
INFO - 2016-11-30 10:45:06 --> Form Validation Class Initialized
INFO - 2016-11-30 10:45:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 10:45:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:45:06 --> Final output sent to browser
DEBUG - 2016-11-30 10:45:06 --> Total execution time: 0.3909
INFO - 2016-11-30 10:45:27 --> Config Class Initialized
INFO - 2016-11-30 10:45:27 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:45:27 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:45:27 --> Utf8 Class Initialized
INFO - 2016-11-30 10:45:27 --> URI Class Initialized
INFO - 2016-11-30 10:45:27 --> Router Class Initialized
INFO - 2016-11-30 10:45:27 --> Output Class Initialized
INFO - 2016-11-30 10:45:27 --> Security Class Initialized
DEBUG - 2016-11-30 10:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:45:27 --> Input Class Initialized
INFO - 2016-11-30 10:45:27 --> Language Class Initialized
INFO - 2016-11-30 10:45:27 --> Loader Class Initialized
INFO - 2016-11-30 10:45:27 --> Helper loaded: url_helper
INFO - 2016-11-30 10:45:27 --> Helper loaded: form_helper
INFO - 2016-11-30 10:45:27 --> Database Driver Class Initialized
INFO - 2016-11-30 10:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:45:27 --> Controller Class Initialized
INFO - 2016-11-30 10:45:27 --> Model Class Initialized
INFO - 2016-11-30 10:45:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:45:27 --> Pagination Class Initialized
INFO - 2016-11-30 10:45:27 --> Helper loaded: app_helper
INFO - 2016-11-30 10:45:27 --> Form Validation Class Initialized
INFO - 2016-11-30 10:45:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 10:45:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:45:28 --> Final output sent to browser
DEBUG - 2016-11-30 10:45:28 --> Total execution time: 0.3834
INFO - 2016-11-30 10:45:37 --> Config Class Initialized
INFO - 2016-11-30 10:45:37 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:45:37 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:45:37 --> Utf8 Class Initialized
INFO - 2016-11-30 10:45:37 --> URI Class Initialized
INFO - 2016-11-30 10:45:37 --> Router Class Initialized
INFO - 2016-11-30 10:45:37 --> Output Class Initialized
INFO - 2016-11-30 10:45:37 --> Security Class Initialized
DEBUG - 2016-11-30 10:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:45:37 --> Input Class Initialized
INFO - 2016-11-30 10:45:37 --> Language Class Initialized
INFO - 2016-11-30 10:45:37 --> Loader Class Initialized
INFO - 2016-11-30 10:45:37 --> Helper loaded: url_helper
INFO - 2016-11-30 10:45:37 --> Helper loaded: form_helper
INFO - 2016-11-30 10:45:37 --> Database Driver Class Initialized
INFO - 2016-11-30 10:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:45:37 --> Controller Class Initialized
INFO - 2016-11-30 10:45:37 --> Model Class Initialized
INFO - 2016-11-30 10:45:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:45:37 --> Pagination Class Initialized
INFO - 2016-11-30 10:45:37 --> Helper loaded: app_helper
INFO - 2016-11-30 10:45:37 --> Form Validation Class Initialized
INFO - 2016-11-30 10:45:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 10:45:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:45:37 --> Final output sent to browser
DEBUG - 2016-11-30 10:45:37 --> Total execution time: 0.3916
INFO - 2016-11-30 10:45:40 --> Config Class Initialized
INFO - 2016-11-30 10:45:40 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:45:40 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:45:40 --> Utf8 Class Initialized
INFO - 2016-11-30 10:45:40 --> URI Class Initialized
INFO - 2016-11-30 10:45:40 --> Router Class Initialized
INFO - 2016-11-30 10:45:40 --> Output Class Initialized
INFO - 2016-11-30 10:45:40 --> Security Class Initialized
DEBUG - 2016-11-30 10:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:45:40 --> Input Class Initialized
INFO - 2016-11-30 10:45:40 --> Language Class Initialized
INFO - 2016-11-30 10:45:40 --> Loader Class Initialized
INFO - 2016-11-30 10:45:40 --> Helper loaded: url_helper
INFO - 2016-11-30 10:45:40 --> Helper loaded: form_helper
INFO - 2016-11-30 10:45:40 --> Database Driver Class Initialized
INFO - 2016-11-30 10:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:45:40 --> Controller Class Initialized
INFO - 2016-11-30 10:45:40 --> Model Class Initialized
INFO - 2016-11-30 10:45:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:45:40 --> Pagination Class Initialized
INFO - 2016-11-30 10:45:40 --> Helper loaded: app_helper
INFO - 2016-11-30 10:45:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:45:40 --> Final output sent to browser
DEBUG - 2016-11-30 10:45:40 --> Total execution time: 0.2764
INFO - 2016-11-30 10:45:42 --> Config Class Initialized
INFO - 2016-11-30 10:45:42 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:45:42 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:45:42 --> Utf8 Class Initialized
INFO - 2016-11-30 10:45:42 --> URI Class Initialized
INFO - 2016-11-30 10:45:42 --> Router Class Initialized
INFO - 2016-11-30 10:45:42 --> Output Class Initialized
INFO - 2016-11-30 10:45:42 --> Security Class Initialized
DEBUG - 2016-11-30 10:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:45:42 --> Input Class Initialized
INFO - 2016-11-30 10:45:42 --> Language Class Initialized
INFO - 2016-11-30 10:45:42 --> Loader Class Initialized
INFO - 2016-11-30 10:45:42 --> Helper loaded: url_helper
INFO - 2016-11-30 10:45:42 --> Helper loaded: form_helper
INFO - 2016-11-30 10:45:42 --> Database Driver Class Initialized
INFO - 2016-11-30 10:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:45:42 --> Controller Class Initialized
INFO - 2016-11-30 10:45:42 --> Model Class Initialized
INFO - 2016-11-30 10:45:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:45:42 --> Pagination Class Initialized
INFO - 2016-11-30 10:45:42 --> Helper loaded: app_helper
INFO - 2016-11-30 10:45:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:45:42 --> Final output sent to browser
DEBUG - 2016-11-30 10:45:42 --> Total execution time: 0.2975
INFO - 2016-11-30 10:45:57 --> Config Class Initialized
INFO - 2016-11-30 10:45:57 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:45:57 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:45:57 --> Utf8 Class Initialized
INFO - 2016-11-30 10:45:57 --> URI Class Initialized
INFO - 2016-11-30 10:45:57 --> Router Class Initialized
INFO - 2016-11-30 10:45:57 --> Output Class Initialized
INFO - 2016-11-30 10:45:57 --> Security Class Initialized
DEBUG - 2016-11-30 10:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:45:57 --> Input Class Initialized
INFO - 2016-11-30 10:45:57 --> Language Class Initialized
INFO - 2016-11-30 10:45:57 --> Loader Class Initialized
INFO - 2016-11-30 10:45:57 --> Helper loaded: url_helper
INFO - 2016-11-30 10:45:57 --> Helper loaded: form_helper
INFO - 2016-11-30 10:45:57 --> Database Driver Class Initialized
INFO - 2016-11-30 10:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:45:57 --> Controller Class Initialized
INFO - 2016-11-30 10:45:57 --> Model Class Initialized
INFO - 2016-11-30 10:45:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:45:57 --> Pagination Class Initialized
INFO - 2016-11-30 10:45:57 --> Helper loaded: app_helper
INFO - 2016-11-30 10:45:57 --> Form Validation Class Initialized
INFO - 2016-11-30 10:45:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 10:45:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:45:58 --> Final output sent to browser
DEBUG - 2016-11-30 10:45:58 --> Total execution time: 0.4312
INFO - 2016-11-30 10:46:06 --> Config Class Initialized
INFO - 2016-11-30 10:46:06 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:46:06 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:46:06 --> Utf8 Class Initialized
INFO - 2016-11-30 10:46:06 --> URI Class Initialized
INFO - 2016-11-30 10:46:06 --> Router Class Initialized
INFO - 2016-11-30 10:46:06 --> Output Class Initialized
INFO - 2016-11-30 10:46:06 --> Security Class Initialized
DEBUG - 2016-11-30 10:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:46:06 --> Input Class Initialized
INFO - 2016-11-30 10:46:06 --> Language Class Initialized
INFO - 2016-11-30 10:46:06 --> Loader Class Initialized
INFO - 2016-11-30 10:46:06 --> Helper loaded: url_helper
INFO - 2016-11-30 10:46:06 --> Helper loaded: form_helper
INFO - 2016-11-30 10:46:06 --> Database Driver Class Initialized
INFO - 2016-11-30 10:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:46:06 --> Controller Class Initialized
INFO - 2016-11-30 10:46:06 --> Model Class Initialized
INFO - 2016-11-30 10:46:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:46:06 --> Pagination Class Initialized
INFO - 2016-11-30 10:46:06 --> Helper loaded: app_helper
INFO - 2016-11-30 10:46:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:46:06 --> Final output sent to browser
DEBUG - 2016-11-30 10:46:06 --> Total execution time: 0.2893
INFO - 2016-11-30 10:46:09 --> Config Class Initialized
INFO - 2016-11-30 10:46:09 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:46:09 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:46:09 --> Utf8 Class Initialized
INFO - 2016-11-30 10:46:09 --> URI Class Initialized
INFO - 2016-11-30 10:46:09 --> Router Class Initialized
INFO - 2016-11-30 10:46:09 --> Output Class Initialized
INFO - 2016-11-30 10:46:09 --> Security Class Initialized
DEBUG - 2016-11-30 10:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:46:09 --> Input Class Initialized
INFO - 2016-11-30 10:46:09 --> Language Class Initialized
INFO - 2016-11-30 10:46:09 --> Loader Class Initialized
INFO - 2016-11-30 10:46:09 --> Helper loaded: url_helper
INFO - 2016-11-30 10:46:09 --> Helper loaded: form_helper
INFO - 2016-11-30 10:46:09 --> Database Driver Class Initialized
INFO - 2016-11-30 10:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:46:09 --> Controller Class Initialized
INFO - 2016-11-30 10:46:09 --> Model Class Initialized
INFO - 2016-11-30 10:46:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:46:09 --> Pagination Class Initialized
INFO - 2016-11-30 10:46:09 --> Helper loaded: app_helper
INFO - 2016-11-30 10:46:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:46:09 --> Final output sent to browser
DEBUG - 2016-11-30 10:46:09 --> Total execution time: 0.2510
INFO - 2016-11-30 10:46:20 --> Config Class Initialized
INFO - 2016-11-30 10:46:20 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:46:20 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:46:20 --> Utf8 Class Initialized
INFO - 2016-11-30 10:46:20 --> URI Class Initialized
INFO - 2016-11-30 10:46:20 --> Router Class Initialized
INFO - 2016-11-30 10:46:20 --> Output Class Initialized
INFO - 2016-11-30 10:46:20 --> Security Class Initialized
DEBUG - 2016-11-30 10:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:46:20 --> Input Class Initialized
INFO - 2016-11-30 10:46:20 --> Language Class Initialized
INFO - 2016-11-30 10:46:20 --> Loader Class Initialized
INFO - 2016-11-30 10:46:20 --> Helper loaded: url_helper
INFO - 2016-11-30 10:46:20 --> Helper loaded: form_helper
INFO - 2016-11-30 10:46:20 --> Database Driver Class Initialized
INFO - 2016-11-30 10:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:46:20 --> Controller Class Initialized
INFO - 2016-11-30 10:46:20 --> Model Class Initialized
INFO - 2016-11-30 10:46:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:46:20 --> Pagination Class Initialized
INFO - 2016-11-30 10:46:20 --> Helper loaded: app_helper
INFO - 2016-11-30 10:46:20 --> Form Validation Class Initialized
INFO - 2016-11-30 10:46:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 10:46:20 --> Final output sent to browser
DEBUG - 2016-11-30 10:46:20 --> Total execution time: 0.2852
INFO - 2016-11-30 10:46:23 --> Config Class Initialized
INFO - 2016-11-30 10:46:23 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:46:23 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:46:23 --> Utf8 Class Initialized
INFO - 2016-11-30 10:46:23 --> URI Class Initialized
INFO - 2016-11-30 10:46:23 --> Router Class Initialized
INFO - 2016-11-30 10:46:23 --> Output Class Initialized
INFO - 2016-11-30 10:46:23 --> Security Class Initialized
DEBUG - 2016-11-30 10:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:46:23 --> Input Class Initialized
INFO - 2016-11-30 10:46:23 --> Language Class Initialized
INFO - 2016-11-30 10:46:23 --> Loader Class Initialized
INFO - 2016-11-30 10:46:23 --> Helper loaded: url_helper
INFO - 2016-11-30 10:46:23 --> Helper loaded: form_helper
INFO - 2016-11-30 10:46:23 --> Database Driver Class Initialized
INFO - 2016-11-30 10:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:46:23 --> Controller Class Initialized
INFO - 2016-11-30 10:46:23 --> Model Class Initialized
INFO - 2016-11-30 10:46:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:46:23 --> Pagination Class Initialized
INFO - 2016-11-30 10:46:23 --> Helper loaded: app_helper
INFO - 2016-11-30 10:46:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 10:46:23 --> Final output sent to browser
DEBUG - 2016-11-30 10:46:23 --> Total execution time: 0.2525
INFO - 2016-11-30 10:49:36 --> Config Class Initialized
INFO - 2016-11-30 10:49:36 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:49:36 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:49:36 --> Utf8 Class Initialized
INFO - 2016-11-30 10:49:36 --> URI Class Initialized
INFO - 2016-11-30 10:49:36 --> Router Class Initialized
INFO - 2016-11-30 10:49:36 --> Output Class Initialized
INFO - 2016-11-30 10:49:36 --> Security Class Initialized
DEBUG - 2016-11-30 10:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:49:36 --> Input Class Initialized
INFO - 2016-11-30 10:49:36 --> Language Class Initialized
INFO - 2016-11-30 10:49:36 --> Loader Class Initialized
INFO - 2016-11-30 10:49:36 --> Helper loaded: url_helper
INFO - 2016-11-30 10:49:36 --> Helper loaded: form_helper
INFO - 2016-11-30 10:49:36 --> Database Driver Class Initialized
INFO - 2016-11-30 10:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:49:36 --> Controller Class Initialized
INFO - 2016-11-30 10:49:36 --> Model Class Initialized
INFO - 2016-11-30 10:49:36 --> Model Class Initialized
INFO - 2016-11-30 10:49:36 --> Model Class Initialized
INFO - 2016-11-30 10:49:36 --> Model Class Initialized
INFO - 2016-11-30 10:49:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:49:36 --> Pagination Class Initialized
INFO - 2016-11-30 10:49:36 --> Helper loaded: app_helper
DEBUG - 2016-11-30 10:49:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-30 10:49:36 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-30 10:49:36 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-30 10:49:36 --> Config Class Initialized
INFO - 2016-11-30 10:49:36 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:49:36 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:49:36 --> Utf8 Class Initialized
INFO - 2016-11-30 10:49:36 --> URI Class Initialized
DEBUG - 2016-11-30 10:49:36 --> No URI present. Default controller set.
INFO - 2016-11-30 10:49:36 --> Router Class Initialized
INFO - 2016-11-30 10:49:36 --> Output Class Initialized
INFO - 2016-11-30 10:49:36 --> Security Class Initialized
DEBUG - 2016-11-30 10:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:49:36 --> Input Class Initialized
INFO - 2016-11-30 10:49:36 --> Language Class Initialized
INFO - 2016-11-30 10:49:36 --> Loader Class Initialized
INFO - 2016-11-30 10:49:36 --> Helper loaded: url_helper
INFO - 2016-11-30 10:49:36 --> Helper loaded: form_helper
INFO - 2016-11-30 10:49:36 --> Database Driver Class Initialized
INFO - 2016-11-30 10:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:49:36 --> Controller Class Initialized
INFO - 2016-11-30 10:49:36 --> Model Class Initialized
INFO - 2016-11-30 10:49:36 --> Model Class Initialized
INFO - 2016-11-30 10:49:36 --> Model Class Initialized
INFO - 2016-11-30 10:49:36 --> Model Class Initialized
INFO - 2016-11-30 10:49:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:49:36 --> Pagination Class Initialized
INFO - 2016-11-30 10:49:36 --> Helper loaded: app_helper
INFO - 2016-11-30 10:49:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 10:49:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-30 10:49:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 10:49:37 --> Final output sent to browser
DEBUG - 2016-11-30 10:49:37 --> Total execution time: 0.3388
INFO - 2016-11-30 10:49:47 --> Config Class Initialized
INFO - 2016-11-30 10:49:47 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:49:47 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:49:47 --> Utf8 Class Initialized
INFO - 2016-11-30 10:49:47 --> URI Class Initialized
INFO - 2016-11-30 10:49:47 --> Router Class Initialized
INFO - 2016-11-30 10:49:47 --> Output Class Initialized
INFO - 2016-11-30 10:49:47 --> Security Class Initialized
DEBUG - 2016-11-30 10:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:49:47 --> Input Class Initialized
INFO - 2016-11-30 10:49:47 --> Language Class Initialized
INFO - 2016-11-30 10:49:47 --> Loader Class Initialized
INFO - 2016-11-30 10:49:47 --> Helper loaded: url_helper
INFO - 2016-11-30 10:49:47 --> Helper loaded: form_helper
INFO - 2016-11-30 10:49:47 --> Database Driver Class Initialized
INFO - 2016-11-30 10:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:49:47 --> Controller Class Initialized
INFO - 2016-11-30 10:49:47 --> Model Class Initialized
INFO - 2016-11-30 10:49:47 --> Model Class Initialized
INFO - 2016-11-30 10:49:47 --> Model Class Initialized
INFO - 2016-11-30 10:49:47 --> Model Class Initialized
INFO - 2016-11-30 10:49:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:49:47 --> Pagination Class Initialized
INFO - 2016-11-30 10:49:47 --> Helper loaded: app_helper
DEBUG - 2016-11-30 10:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 10:49:47 --> Model Class Initialized
INFO - 2016-11-30 10:49:47 --> Final output sent to browser
DEBUG - 2016-11-30 10:49:47 --> Total execution time: 0.3110
INFO - 2016-11-30 10:49:47 --> Config Class Initialized
INFO - 2016-11-30 10:49:47 --> Hooks Class Initialized
DEBUG - 2016-11-30 10:49:47 --> UTF-8 Support Enabled
INFO - 2016-11-30 10:49:47 --> Utf8 Class Initialized
INFO - 2016-11-30 10:49:47 --> URI Class Initialized
DEBUG - 2016-11-30 10:49:47 --> No URI present. Default controller set.
INFO - 2016-11-30 10:49:47 --> Router Class Initialized
INFO - 2016-11-30 10:49:47 --> Output Class Initialized
INFO - 2016-11-30 10:49:47 --> Security Class Initialized
DEBUG - 2016-11-30 10:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 10:49:47 --> Input Class Initialized
INFO - 2016-11-30 10:49:47 --> Language Class Initialized
INFO - 2016-11-30 10:49:47 --> Loader Class Initialized
INFO - 2016-11-30 10:49:47 --> Helper loaded: url_helper
INFO - 2016-11-30 10:49:47 --> Helper loaded: form_helper
INFO - 2016-11-30 10:49:47 --> Database Driver Class Initialized
INFO - 2016-11-30 10:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 10:49:47 --> Controller Class Initialized
INFO - 2016-11-30 10:49:47 --> Model Class Initialized
INFO - 2016-11-30 10:49:47 --> Model Class Initialized
INFO - 2016-11-30 10:49:47 --> Model Class Initialized
INFO - 2016-11-30 10:49:47 --> Model Class Initialized
INFO - 2016-11-30 10:49:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 10:49:47 --> Pagination Class Initialized
INFO - 2016-11-30 10:49:47 --> Helper loaded: app_helper
INFO - 2016-11-30 10:49:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 10:49:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 10:49:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 10:49:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 10:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 10:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 10:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 10:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 10:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 10:49:48 --> Final output sent to browser
DEBUG - 2016-11-30 10:49:48 --> Total execution time: 0.4728
INFO - 2016-11-30 11:02:00 --> Config Class Initialized
INFO - 2016-11-30 11:02:00 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:02:00 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:02:00 --> Utf8 Class Initialized
INFO - 2016-11-30 11:02:00 --> URI Class Initialized
DEBUG - 2016-11-30 11:02:00 --> No URI present. Default controller set.
INFO - 2016-11-30 11:02:00 --> Router Class Initialized
INFO - 2016-11-30 11:02:00 --> Output Class Initialized
INFO - 2016-11-30 11:02:00 --> Security Class Initialized
DEBUG - 2016-11-30 11:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:02:00 --> Input Class Initialized
INFO - 2016-11-30 11:02:00 --> Language Class Initialized
INFO - 2016-11-30 11:02:00 --> Loader Class Initialized
INFO - 2016-11-30 11:02:00 --> Helper loaded: url_helper
INFO - 2016-11-30 11:02:00 --> Helper loaded: form_helper
INFO - 2016-11-30 11:02:00 --> Database Driver Class Initialized
INFO - 2016-11-30 11:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:02:00 --> Controller Class Initialized
INFO - 2016-11-30 11:02:00 --> Model Class Initialized
INFO - 2016-11-30 11:02:00 --> Model Class Initialized
INFO - 2016-11-30 11:02:00 --> Model Class Initialized
INFO - 2016-11-30 11:02:00 --> Model Class Initialized
INFO - 2016-11-30 11:02:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:02:00 --> Pagination Class Initialized
INFO - 2016-11-30 11:02:00 --> Helper loaded: app_helper
INFO - 2016-11-30 11:02:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:02:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:02:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:02:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 11:02:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 11:02:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 11:02:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 11:02:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:02:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:02:00 --> Final output sent to browser
DEBUG - 2016-11-30 11:02:00 --> Total execution time: 0.4917
INFO - 2016-11-30 11:02:15 --> Config Class Initialized
INFO - 2016-11-30 11:02:15 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:02:15 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:02:15 --> Utf8 Class Initialized
INFO - 2016-11-30 11:02:15 --> URI Class Initialized
DEBUG - 2016-11-30 11:02:15 --> No URI present. Default controller set.
INFO - 2016-11-30 11:02:15 --> Router Class Initialized
INFO - 2016-11-30 11:02:15 --> Output Class Initialized
INFO - 2016-11-30 11:02:15 --> Security Class Initialized
DEBUG - 2016-11-30 11:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:02:15 --> Input Class Initialized
INFO - 2016-11-30 11:02:15 --> Language Class Initialized
INFO - 2016-11-30 11:02:15 --> Loader Class Initialized
INFO - 2016-11-30 11:02:15 --> Helper loaded: url_helper
INFO - 2016-11-30 11:02:15 --> Helper loaded: form_helper
INFO - 2016-11-30 11:02:15 --> Database Driver Class Initialized
INFO - 2016-11-30 11:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:02:15 --> Controller Class Initialized
INFO - 2016-11-30 11:02:15 --> Model Class Initialized
INFO - 2016-11-30 11:02:15 --> Model Class Initialized
INFO - 2016-11-30 11:02:15 --> Model Class Initialized
INFO - 2016-11-30 11:02:15 --> Model Class Initialized
INFO - 2016-11-30 11:02:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:02:15 --> Pagination Class Initialized
INFO - 2016-11-30 11:02:15 --> Helper loaded: app_helper
INFO - 2016-11-30 11:02:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:02:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:02:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:02:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 11:02:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 11:02:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 11:02:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 11:02:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:02:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:02:15 --> Final output sent to browser
DEBUG - 2016-11-30 11:02:15 --> Total execution time: 0.4455
INFO - 2016-11-30 11:02:24 --> Config Class Initialized
INFO - 2016-11-30 11:02:24 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:02:24 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:02:24 --> Utf8 Class Initialized
INFO - 2016-11-30 11:02:24 --> URI Class Initialized
INFO - 2016-11-30 11:02:24 --> Router Class Initialized
INFO - 2016-11-30 11:02:24 --> Output Class Initialized
INFO - 2016-11-30 11:02:24 --> Security Class Initialized
DEBUG - 2016-11-30 11:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:02:24 --> Input Class Initialized
INFO - 2016-11-30 11:02:24 --> Language Class Initialized
INFO - 2016-11-30 11:02:24 --> Loader Class Initialized
INFO - 2016-11-30 11:02:24 --> Helper loaded: url_helper
INFO - 2016-11-30 11:02:24 --> Helper loaded: form_helper
INFO - 2016-11-30 11:02:24 --> Database Driver Class Initialized
INFO - 2016-11-30 11:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:02:24 --> Controller Class Initialized
INFO - 2016-11-30 11:02:24 --> Model Class Initialized
INFO - 2016-11-30 11:02:24 --> Form Validation Class Initialized
INFO - 2016-11-30 11:02:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:02:24 --> Pagination Class Initialized
INFO - 2016-11-30 11:02:24 --> Helper loaded: app_helper
INFO - 2016-11-30 11:02:25 --> Email Class Initialized
INFO - 2016-11-30 11:02:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 11:02:25 --> Final output sent to browser
DEBUG - 2016-11-30 11:02:25 --> Total execution time: 0.4294
INFO - 2016-11-30 11:14:29 --> Config Class Initialized
INFO - 2016-11-30 11:14:29 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:14:29 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:14:29 --> Utf8 Class Initialized
INFO - 2016-11-30 11:14:29 --> URI Class Initialized
DEBUG - 2016-11-30 11:14:29 --> No URI present. Default controller set.
INFO - 2016-11-30 11:14:29 --> Router Class Initialized
INFO - 2016-11-30 11:14:29 --> Output Class Initialized
INFO - 2016-11-30 11:14:29 --> Security Class Initialized
DEBUG - 2016-11-30 11:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:14:29 --> Input Class Initialized
INFO - 2016-11-30 11:14:29 --> Language Class Initialized
INFO - 2016-11-30 11:14:29 --> Loader Class Initialized
INFO - 2016-11-30 11:14:29 --> Helper loaded: url_helper
INFO - 2016-11-30 11:14:29 --> Helper loaded: form_helper
INFO - 2016-11-30 11:14:30 --> Database Driver Class Initialized
INFO - 2016-11-30 11:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:14:30 --> Controller Class Initialized
INFO - 2016-11-30 11:14:30 --> Model Class Initialized
INFO - 2016-11-30 11:14:30 --> Model Class Initialized
INFO - 2016-11-30 11:14:30 --> Model Class Initialized
INFO - 2016-11-30 11:14:30 --> Model Class Initialized
INFO - 2016-11-30 11:14:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:14:30 --> Pagination Class Initialized
INFO - 2016-11-30 11:14:30 --> Helper loaded: app_helper
INFO - 2016-11-30 11:14:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:14:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:14:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:14:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 11:14:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 11:14:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 11:14:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 11:14:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:14:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:14:30 --> Final output sent to browser
DEBUG - 2016-11-30 11:14:30 --> Total execution time: 0.4507
INFO - 2016-11-30 11:15:47 --> Config Class Initialized
INFO - 2016-11-30 11:15:47 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:15:47 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:15:47 --> Utf8 Class Initialized
INFO - 2016-11-30 11:15:48 --> URI Class Initialized
DEBUG - 2016-11-30 11:15:48 --> No URI present. Default controller set.
INFO - 2016-11-30 11:15:48 --> Router Class Initialized
INFO - 2016-11-30 11:15:48 --> Output Class Initialized
INFO - 2016-11-30 11:15:48 --> Security Class Initialized
DEBUG - 2016-11-30 11:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:15:48 --> Input Class Initialized
INFO - 2016-11-30 11:15:48 --> Language Class Initialized
INFO - 2016-11-30 11:15:48 --> Loader Class Initialized
INFO - 2016-11-30 11:15:48 --> Helper loaded: url_helper
INFO - 2016-11-30 11:15:48 --> Helper loaded: form_helper
INFO - 2016-11-30 11:15:48 --> Database Driver Class Initialized
INFO - 2016-11-30 11:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:15:48 --> Controller Class Initialized
INFO - 2016-11-30 11:15:48 --> Model Class Initialized
INFO - 2016-11-30 11:15:48 --> Model Class Initialized
INFO - 2016-11-30 11:15:48 --> Model Class Initialized
INFO - 2016-11-30 11:15:48 --> Model Class Initialized
INFO - 2016-11-30 11:15:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:15:48 --> Pagination Class Initialized
INFO - 2016-11-30 11:15:48 --> Helper loaded: app_helper
INFO - 2016-11-30 11:15:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:15:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:15:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:15:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 11:15:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 11:15:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 11:15:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 11:15:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:15:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:15:48 --> Final output sent to browser
DEBUG - 2016-11-30 11:15:48 --> Total execution time: 0.6682
INFO - 2016-11-30 11:16:12 --> Config Class Initialized
INFO - 2016-11-30 11:16:12 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:16:12 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:16:12 --> Utf8 Class Initialized
INFO - 2016-11-30 11:16:12 --> URI Class Initialized
INFO - 2016-11-30 11:16:12 --> Router Class Initialized
INFO - 2016-11-30 11:16:12 --> Output Class Initialized
INFO - 2016-11-30 11:16:12 --> Security Class Initialized
DEBUG - 2016-11-30 11:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:16:12 --> Input Class Initialized
INFO - 2016-11-30 11:16:12 --> Language Class Initialized
INFO - 2016-11-30 11:16:12 --> Loader Class Initialized
INFO - 2016-11-30 11:16:12 --> Helper loaded: url_helper
INFO - 2016-11-30 11:16:12 --> Helper loaded: form_helper
INFO - 2016-11-30 11:16:12 --> Database Driver Class Initialized
INFO - 2016-11-30 11:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:16:12 --> Controller Class Initialized
INFO - 2016-11-30 11:16:12 --> Model Class Initialized
INFO - 2016-11-30 11:16:12 --> Form Validation Class Initialized
INFO - 2016-11-30 11:16:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:16:12 --> Pagination Class Initialized
INFO - 2016-11-30 11:16:12 --> Helper loaded: app_helper
INFO - 2016-11-30 11:16:12 --> Email Class Initialized
INFO - 2016-11-30 11:16:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 11:16:12 --> Final output sent to browser
DEBUG - 2016-11-30 11:16:12 --> Total execution time: 0.3575
INFO - 2016-11-30 11:16:15 --> Config Class Initialized
INFO - 2016-11-30 11:16:15 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:16:15 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:16:15 --> Utf8 Class Initialized
INFO - 2016-11-30 11:16:15 --> URI Class Initialized
INFO - 2016-11-30 11:16:15 --> Router Class Initialized
INFO - 2016-11-30 11:16:15 --> Output Class Initialized
INFO - 2016-11-30 11:16:15 --> Security Class Initialized
DEBUG - 2016-11-30 11:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:16:15 --> Input Class Initialized
INFO - 2016-11-30 11:16:15 --> Language Class Initialized
INFO - 2016-11-30 11:16:15 --> Loader Class Initialized
INFO - 2016-11-30 11:16:15 --> Helper loaded: url_helper
INFO - 2016-11-30 11:16:15 --> Helper loaded: form_helper
INFO - 2016-11-30 11:16:15 --> Database Driver Class Initialized
INFO - 2016-11-30 11:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:16:15 --> Controller Class Initialized
INFO - 2016-11-30 11:16:15 --> Model Class Initialized
INFO - 2016-11-30 11:16:15 --> Form Validation Class Initialized
INFO - 2016-11-30 11:16:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:16:15 --> Pagination Class Initialized
INFO - 2016-11-30 11:16:15 --> Helper loaded: app_helper
INFO - 2016-11-30 11:16:15 --> Email Class Initialized
INFO - 2016-11-30 11:16:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 11:16:15 --> Final output sent to browser
DEBUG - 2016-11-30 11:16:15 --> Total execution time: 0.2990
INFO - 2016-11-30 11:16:18 --> Config Class Initialized
INFO - 2016-11-30 11:16:18 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:16:18 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:16:18 --> Utf8 Class Initialized
INFO - 2016-11-30 11:16:18 --> URI Class Initialized
DEBUG - 2016-11-30 11:16:18 --> No URI present. Default controller set.
INFO - 2016-11-30 11:16:18 --> Router Class Initialized
INFO - 2016-11-30 11:16:18 --> Output Class Initialized
INFO - 2016-11-30 11:16:18 --> Security Class Initialized
DEBUG - 2016-11-30 11:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:16:18 --> Input Class Initialized
INFO - 2016-11-30 11:16:18 --> Language Class Initialized
INFO - 2016-11-30 11:16:18 --> Loader Class Initialized
INFO - 2016-11-30 11:16:18 --> Helper loaded: url_helper
INFO - 2016-11-30 11:16:18 --> Helper loaded: form_helper
INFO - 2016-11-30 11:16:18 --> Database Driver Class Initialized
INFO - 2016-11-30 11:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:16:18 --> Controller Class Initialized
INFO - 2016-11-30 11:16:18 --> Model Class Initialized
INFO - 2016-11-30 11:16:18 --> Model Class Initialized
INFO - 2016-11-30 11:16:18 --> Model Class Initialized
INFO - 2016-11-30 11:16:18 --> Model Class Initialized
INFO - 2016-11-30 11:16:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:16:18 --> Pagination Class Initialized
INFO - 2016-11-30 11:16:18 --> Helper loaded: app_helper
INFO - 2016-11-30 11:16:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:16:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:16:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:16:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 11:16:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 11:16:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 11:16:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 11:16:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:16:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:16:18 --> Final output sent to browser
DEBUG - 2016-11-30 11:16:18 --> Total execution time: 0.6218
INFO - 2016-11-30 11:16:40 --> Config Class Initialized
INFO - 2016-11-30 11:16:40 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:16:40 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:16:40 --> Utf8 Class Initialized
INFO - 2016-11-30 11:16:40 --> URI Class Initialized
INFO - 2016-11-30 11:16:40 --> Router Class Initialized
INFO - 2016-11-30 11:16:40 --> Output Class Initialized
INFO - 2016-11-30 11:16:40 --> Security Class Initialized
DEBUG - 2016-11-30 11:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:16:40 --> Input Class Initialized
INFO - 2016-11-30 11:16:40 --> Language Class Initialized
INFO - 2016-11-30 11:16:40 --> Loader Class Initialized
INFO - 2016-11-30 11:16:41 --> Helper loaded: url_helper
INFO - 2016-11-30 11:16:41 --> Helper loaded: form_helper
INFO - 2016-11-30 11:16:41 --> Database Driver Class Initialized
INFO - 2016-11-30 11:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:16:41 --> Controller Class Initialized
INFO - 2016-11-30 11:16:41 --> Model Class Initialized
INFO - 2016-11-30 11:16:41 --> Model Class Initialized
INFO - 2016-11-30 11:16:41 --> Model Class Initialized
INFO - 2016-11-30 11:16:41 --> Model Class Initialized
INFO - 2016-11-30 11:16:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:16:41 --> Pagination Class Initialized
INFO - 2016-11-30 11:16:41 --> Helper loaded: app_helper
DEBUG - 2016-11-30 11:16:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-30 11:16:41 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-30 11:16:41 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-30 11:16:41 --> Config Class Initialized
INFO - 2016-11-30 11:16:41 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:16:41 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:16:41 --> Utf8 Class Initialized
INFO - 2016-11-30 11:16:41 --> URI Class Initialized
DEBUG - 2016-11-30 11:16:41 --> No URI present. Default controller set.
INFO - 2016-11-30 11:16:41 --> Router Class Initialized
INFO - 2016-11-30 11:16:41 --> Output Class Initialized
INFO - 2016-11-30 11:16:41 --> Security Class Initialized
DEBUG - 2016-11-30 11:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:16:41 --> Input Class Initialized
INFO - 2016-11-30 11:16:41 --> Language Class Initialized
INFO - 2016-11-30 11:16:41 --> Loader Class Initialized
INFO - 2016-11-30 11:16:41 --> Helper loaded: url_helper
INFO - 2016-11-30 11:16:41 --> Helper loaded: form_helper
INFO - 2016-11-30 11:16:41 --> Database Driver Class Initialized
INFO - 2016-11-30 11:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:16:41 --> Controller Class Initialized
INFO - 2016-11-30 11:16:41 --> Model Class Initialized
INFO - 2016-11-30 11:16:41 --> Model Class Initialized
INFO - 2016-11-30 11:16:41 --> Model Class Initialized
INFO - 2016-11-30 11:16:41 --> Model Class Initialized
INFO - 2016-11-30 11:16:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:16:41 --> Pagination Class Initialized
INFO - 2016-11-30 11:16:41 --> Helper loaded: app_helper
INFO - 2016-11-30 11:16:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:16:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-30 11:16:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:16:41 --> Final output sent to browser
DEBUG - 2016-11-30 11:16:41 --> Total execution time: 0.3543
INFO - 2016-11-30 11:16:49 --> Config Class Initialized
INFO - 2016-11-30 11:16:49 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:16:49 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:16:49 --> Utf8 Class Initialized
INFO - 2016-11-30 11:16:49 --> URI Class Initialized
INFO - 2016-11-30 11:16:49 --> Router Class Initialized
INFO - 2016-11-30 11:16:49 --> Output Class Initialized
INFO - 2016-11-30 11:16:49 --> Security Class Initialized
DEBUG - 2016-11-30 11:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:16:49 --> Input Class Initialized
INFO - 2016-11-30 11:16:49 --> Language Class Initialized
INFO - 2016-11-30 11:16:49 --> Loader Class Initialized
INFO - 2016-11-30 11:16:49 --> Helper loaded: url_helper
INFO - 2016-11-30 11:16:49 --> Helper loaded: form_helper
INFO - 2016-11-30 11:16:49 --> Database Driver Class Initialized
INFO - 2016-11-30 11:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:16:49 --> Controller Class Initialized
INFO - 2016-11-30 11:16:49 --> Model Class Initialized
INFO - 2016-11-30 11:16:49 --> Model Class Initialized
INFO - 2016-11-30 11:16:49 --> Model Class Initialized
INFO - 2016-11-30 11:16:49 --> Model Class Initialized
INFO - 2016-11-30 11:16:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:16:49 --> Pagination Class Initialized
INFO - 2016-11-30 11:16:49 --> Helper loaded: app_helper
DEBUG - 2016-11-30 11:16:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 11:16:49 --> Model Class Initialized
INFO - 2016-11-30 11:16:49 --> Final output sent to browser
DEBUG - 2016-11-30 11:16:49 --> Total execution time: 0.4383
INFO - 2016-11-30 11:16:49 --> Config Class Initialized
INFO - 2016-11-30 11:16:49 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:16:49 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:16:49 --> Utf8 Class Initialized
INFO - 2016-11-30 11:16:49 --> URI Class Initialized
DEBUG - 2016-11-30 11:16:49 --> No URI present. Default controller set.
INFO - 2016-11-30 11:16:49 --> Router Class Initialized
INFO - 2016-11-30 11:16:49 --> Output Class Initialized
INFO - 2016-11-30 11:16:49 --> Security Class Initialized
DEBUG - 2016-11-30 11:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:16:49 --> Input Class Initialized
INFO - 2016-11-30 11:16:49 --> Language Class Initialized
INFO - 2016-11-30 11:16:50 --> Loader Class Initialized
INFO - 2016-11-30 11:16:50 --> Helper loaded: url_helper
INFO - 2016-11-30 11:16:50 --> Helper loaded: form_helper
INFO - 2016-11-30 11:16:50 --> Database Driver Class Initialized
INFO - 2016-11-30 11:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:16:50 --> Controller Class Initialized
INFO - 2016-11-30 11:16:50 --> Model Class Initialized
INFO - 2016-11-30 11:16:50 --> Model Class Initialized
INFO - 2016-11-30 11:16:50 --> Model Class Initialized
INFO - 2016-11-30 11:16:50 --> Model Class Initialized
INFO - 2016-11-30 11:16:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:16:50 --> Pagination Class Initialized
INFO - 2016-11-30 11:16:50 --> Helper loaded: app_helper
INFO - 2016-11-30 11:16:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:16:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:16:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:16:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-30 11:16:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 11:16:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-30 11:16:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:16:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:16:50 --> Final output sent to browser
DEBUG - 2016-11-30 11:16:50 --> Total execution time: 0.4314
INFO - 2016-11-30 11:17:01 --> Config Class Initialized
INFO - 2016-11-30 11:17:01 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:17:01 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:17:01 --> Utf8 Class Initialized
INFO - 2016-11-30 11:17:01 --> URI Class Initialized
INFO - 2016-11-30 11:17:01 --> Router Class Initialized
INFO - 2016-11-30 11:17:01 --> Output Class Initialized
INFO - 2016-11-30 11:17:01 --> Security Class Initialized
DEBUG - 2016-11-30 11:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:17:01 --> Input Class Initialized
INFO - 2016-11-30 11:17:01 --> Language Class Initialized
INFO - 2016-11-30 11:17:01 --> Loader Class Initialized
INFO - 2016-11-30 11:17:01 --> Helper loaded: url_helper
INFO - 2016-11-30 11:17:01 --> Helper loaded: form_helper
INFO - 2016-11-30 11:17:01 --> Database Driver Class Initialized
INFO - 2016-11-30 11:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:17:01 --> Controller Class Initialized
INFO - 2016-11-30 11:17:01 --> Model Class Initialized
INFO - 2016-11-30 11:17:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:17:01 --> Pagination Class Initialized
INFO - 2016-11-30 11:17:01 --> Helper loaded: app_helper
INFO - 2016-11-30 11:17:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 11:17:01 --> Final output sent to browser
DEBUG - 2016-11-30 11:17:01 --> Total execution time: 0.3868
INFO - 2016-11-30 11:17:03 --> Config Class Initialized
INFO - 2016-11-30 11:17:03 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:17:03 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:17:03 --> Utf8 Class Initialized
INFO - 2016-11-30 11:17:03 --> URI Class Initialized
INFO - 2016-11-30 11:17:03 --> Router Class Initialized
INFO - 2016-11-30 11:17:03 --> Output Class Initialized
INFO - 2016-11-30 11:17:03 --> Security Class Initialized
DEBUG - 2016-11-30 11:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:17:03 --> Input Class Initialized
INFO - 2016-11-30 11:17:03 --> Language Class Initialized
INFO - 2016-11-30 11:17:03 --> Loader Class Initialized
INFO - 2016-11-30 11:17:03 --> Helper loaded: url_helper
INFO - 2016-11-30 11:17:03 --> Helper loaded: form_helper
INFO - 2016-11-30 11:17:03 --> Database Driver Class Initialized
INFO - 2016-11-30 11:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:17:03 --> Controller Class Initialized
INFO - 2016-11-30 11:17:03 --> Model Class Initialized
INFO - 2016-11-30 11:17:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:17:03 --> Pagination Class Initialized
INFO - 2016-11-30 11:17:03 --> Helper loaded: app_helper
INFO - 2016-11-30 11:17:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 11:17:03 --> Final output sent to browser
DEBUG - 2016-11-30 11:17:03 --> Total execution time: 0.3079
INFO - 2016-11-30 11:17:06 --> Config Class Initialized
INFO - 2016-11-30 11:17:06 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:17:06 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:17:06 --> Utf8 Class Initialized
INFO - 2016-11-30 11:17:06 --> URI Class Initialized
INFO - 2016-11-30 11:17:06 --> Router Class Initialized
INFO - 2016-11-30 11:17:06 --> Output Class Initialized
INFO - 2016-11-30 11:17:06 --> Security Class Initialized
DEBUG - 2016-11-30 11:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:17:06 --> Input Class Initialized
INFO - 2016-11-30 11:17:06 --> Language Class Initialized
INFO - 2016-11-30 11:17:06 --> Loader Class Initialized
INFO - 2016-11-30 11:17:06 --> Helper loaded: url_helper
INFO - 2016-11-30 11:17:06 --> Helper loaded: form_helper
INFO - 2016-11-30 11:17:06 --> Database Driver Class Initialized
INFO - 2016-11-30 11:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:17:06 --> Controller Class Initialized
INFO - 2016-11-30 11:17:06 --> Model Class Initialized
INFO - 2016-11-30 11:17:06 --> Model Class Initialized
INFO - 2016-11-30 11:17:06 --> Model Class Initialized
INFO - 2016-11-30 11:17:06 --> Model Class Initialized
INFO - 2016-11-30 11:17:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:17:06 --> Pagination Class Initialized
INFO - 2016-11-30 11:17:06 --> Helper loaded: app_helper
DEBUG - 2016-11-30 11:17:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-30 11:17:06 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-30 11:17:06 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-30 11:17:06 --> Config Class Initialized
INFO - 2016-11-30 11:17:06 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:17:06 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:17:06 --> Utf8 Class Initialized
INFO - 2016-11-30 11:17:06 --> URI Class Initialized
DEBUG - 2016-11-30 11:17:06 --> No URI present. Default controller set.
INFO - 2016-11-30 11:17:06 --> Router Class Initialized
INFO - 2016-11-30 11:17:06 --> Output Class Initialized
INFO - 2016-11-30 11:17:06 --> Security Class Initialized
DEBUG - 2016-11-30 11:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:17:06 --> Input Class Initialized
INFO - 2016-11-30 11:17:06 --> Language Class Initialized
INFO - 2016-11-30 11:17:06 --> Loader Class Initialized
INFO - 2016-11-30 11:17:06 --> Helper loaded: url_helper
INFO - 2016-11-30 11:17:06 --> Helper loaded: form_helper
INFO - 2016-11-30 11:17:06 --> Database Driver Class Initialized
INFO - 2016-11-30 11:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:17:07 --> Controller Class Initialized
INFO - 2016-11-30 11:17:07 --> Model Class Initialized
INFO - 2016-11-30 11:17:07 --> Model Class Initialized
INFO - 2016-11-30 11:17:07 --> Model Class Initialized
INFO - 2016-11-30 11:17:07 --> Model Class Initialized
INFO - 2016-11-30 11:17:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:17:07 --> Pagination Class Initialized
INFO - 2016-11-30 11:17:07 --> Helper loaded: app_helper
INFO - 2016-11-30 11:17:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:17:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-30 11:17:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:17:07 --> Final output sent to browser
DEBUG - 2016-11-30 11:17:07 --> Total execution time: 0.3485
INFO - 2016-11-30 11:17:20 --> Config Class Initialized
INFO - 2016-11-30 11:17:20 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:17:20 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:17:20 --> Utf8 Class Initialized
INFO - 2016-11-30 11:17:20 --> URI Class Initialized
INFO - 2016-11-30 11:17:20 --> Router Class Initialized
INFO - 2016-11-30 11:17:20 --> Output Class Initialized
INFO - 2016-11-30 11:17:20 --> Security Class Initialized
DEBUG - 2016-11-30 11:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:17:20 --> Input Class Initialized
INFO - 2016-11-30 11:17:20 --> Language Class Initialized
INFO - 2016-11-30 11:17:20 --> Loader Class Initialized
INFO - 2016-11-30 11:17:20 --> Helper loaded: url_helper
INFO - 2016-11-30 11:17:20 --> Helper loaded: form_helper
INFO - 2016-11-30 11:17:20 --> Database Driver Class Initialized
INFO - 2016-11-30 11:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:17:20 --> Controller Class Initialized
INFO - 2016-11-30 11:17:20 --> Model Class Initialized
INFO - 2016-11-30 11:17:20 --> Model Class Initialized
INFO - 2016-11-30 11:17:20 --> Model Class Initialized
INFO - 2016-11-30 11:17:20 --> Model Class Initialized
INFO - 2016-11-30 11:17:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:17:20 --> Pagination Class Initialized
INFO - 2016-11-30 11:17:20 --> Helper loaded: app_helper
DEBUG - 2016-11-30 11:17:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 11:17:20 --> Model Class Initialized
INFO - 2016-11-30 11:17:20 --> Final output sent to browser
DEBUG - 2016-11-30 11:17:20 --> Total execution time: 0.3381
INFO - 2016-11-30 11:17:20 --> Config Class Initialized
INFO - 2016-11-30 11:17:20 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:17:20 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:17:20 --> Utf8 Class Initialized
INFO - 2016-11-30 11:17:20 --> URI Class Initialized
DEBUG - 2016-11-30 11:17:20 --> No URI present. Default controller set.
INFO - 2016-11-30 11:17:20 --> Router Class Initialized
INFO - 2016-11-30 11:17:20 --> Output Class Initialized
INFO - 2016-11-30 11:17:20 --> Security Class Initialized
DEBUG - 2016-11-30 11:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:17:20 --> Input Class Initialized
INFO - 2016-11-30 11:17:20 --> Language Class Initialized
INFO - 2016-11-30 11:17:20 --> Loader Class Initialized
INFO - 2016-11-30 11:17:20 --> Helper loaded: url_helper
INFO - 2016-11-30 11:17:20 --> Helper loaded: form_helper
INFO - 2016-11-30 11:17:20 --> Database Driver Class Initialized
INFO - 2016-11-30 11:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:17:21 --> Controller Class Initialized
INFO - 2016-11-30 11:17:21 --> Model Class Initialized
INFO - 2016-11-30 11:17:21 --> Model Class Initialized
INFO - 2016-11-30 11:17:21 --> Model Class Initialized
INFO - 2016-11-30 11:17:21 --> Model Class Initialized
INFO - 2016-11-30 11:17:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:17:21 --> Pagination Class Initialized
INFO - 2016-11-30 11:17:21 --> Helper loaded: app_helper
INFO - 2016-11-30 11:17:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:17:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:17:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:17:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 11:17:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 11:17:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 11:17:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 11:17:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:17:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:17:21 --> Final output sent to browser
DEBUG - 2016-11-30 11:17:21 --> Total execution time: 0.6014
INFO - 2016-11-30 11:19:01 --> Config Class Initialized
INFO - 2016-11-30 11:19:01 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:19:01 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:19:01 --> Utf8 Class Initialized
INFO - 2016-11-30 11:19:01 --> URI Class Initialized
INFO - 2016-11-30 11:19:01 --> Router Class Initialized
INFO - 2016-11-30 11:19:01 --> Output Class Initialized
INFO - 2016-11-30 11:19:01 --> Security Class Initialized
DEBUG - 2016-11-30 11:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:19:01 --> Input Class Initialized
INFO - 2016-11-30 11:19:01 --> Language Class Initialized
INFO - 2016-11-30 11:19:01 --> Loader Class Initialized
INFO - 2016-11-30 11:19:01 --> Helper loaded: url_helper
INFO - 2016-11-30 11:19:01 --> Helper loaded: form_helper
INFO - 2016-11-30 11:19:01 --> Database Driver Class Initialized
INFO - 2016-11-30 11:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:19:02 --> Controller Class Initialized
INFO - 2016-11-30 11:19:02 --> Model Class Initialized
INFO - 2016-11-30 11:19:02 --> Form Validation Class Initialized
INFO - 2016-11-30 11:19:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:19:02 --> Pagination Class Initialized
INFO - 2016-11-30 11:19:02 --> Helper loaded: app_helper
INFO - 2016-11-30 11:19:02 --> Email Class Initialized
INFO - 2016-11-30 11:19:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 10:19:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 10:19:02 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 10:19:03 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-30 10:19:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
ERROR - 2016-11-30 10:19:04 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-30 10:19:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 10:19:05 --> Final output sent to browser
DEBUG - 2016-11-30 10:19:05 --> Total execution time: 3.2532
INFO - 2016-11-30 11:19:19 --> Config Class Initialized
INFO - 2016-11-30 11:19:19 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:19:19 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:19:19 --> Utf8 Class Initialized
INFO - 2016-11-30 11:19:19 --> URI Class Initialized
DEBUG - 2016-11-30 11:19:19 --> No URI present. Default controller set.
INFO - 2016-11-30 11:19:19 --> Router Class Initialized
INFO - 2016-11-30 11:19:19 --> Output Class Initialized
INFO - 2016-11-30 11:19:19 --> Security Class Initialized
DEBUG - 2016-11-30 11:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:19:19 --> Input Class Initialized
INFO - 2016-11-30 11:19:19 --> Language Class Initialized
INFO - 2016-11-30 11:19:19 --> Loader Class Initialized
INFO - 2016-11-30 11:19:19 --> Helper loaded: url_helper
INFO - 2016-11-30 11:19:19 --> Helper loaded: form_helper
INFO - 2016-11-30 11:19:19 --> Database Driver Class Initialized
INFO - 2016-11-30 11:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:19:19 --> Controller Class Initialized
INFO - 2016-11-30 11:19:19 --> Model Class Initialized
INFO - 2016-11-30 11:19:19 --> Model Class Initialized
INFO - 2016-11-30 11:19:19 --> Model Class Initialized
INFO - 2016-11-30 11:19:19 --> Model Class Initialized
INFO - 2016-11-30 11:19:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:19:19 --> Pagination Class Initialized
INFO - 2016-11-30 11:19:19 --> Helper loaded: app_helper
INFO - 2016-11-30 11:19:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:19:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:19:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:19:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 11:19:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 11:19:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 11:19:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 11:19:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:19:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:19:19 --> Final output sent to browser
DEBUG - 2016-11-30 11:19:19 --> Total execution time: 0.4736
INFO - 2016-11-30 11:20:59 --> Config Class Initialized
INFO - 2016-11-30 11:20:59 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:20:59 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:20:59 --> Utf8 Class Initialized
INFO - 2016-11-30 11:20:59 --> URI Class Initialized
INFO - 2016-11-30 11:20:59 --> Router Class Initialized
INFO - 2016-11-30 11:20:59 --> Output Class Initialized
INFO - 2016-11-30 11:20:59 --> Security Class Initialized
DEBUG - 2016-11-30 11:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:20:59 --> Input Class Initialized
INFO - 2016-11-30 11:20:59 --> Language Class Initialized
INFO - 2016-11-30 11:20:59 --> Loader Class Initialized
INFO - 2016-11-30 11:20:59 --> Helper loaded: url_helper
INFO - 2016-11-30 11:20:59 --> Helper loaded: form_helper
INFO - 2016-11-30 11:21:00 --> Database Driver Class Initialized
INFO - 2016-11-30 11:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:21:00 --> Controller Class Initialized
INFO - 2016-11-30 11:21:00 --> Model Class Initialized
INFO - 2016-11-30 11:21:00 --> Model Class Initialized
INFO - 2016-11-30 11:21:00 --> Model Class Initialized
INFO - 2016-11-30 11:21:00 --> Model Class Initialized
INFO - 2016-11-30 11:21:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:21:00 --> Pagination Class Initialized
INFO - 2016-11-30 11:21:00 --> Helper loaded: app_helper
DEBUG - 2016-11-30 11:21:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-30 11:21:00 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-30 11:21:00 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-30 11:21:00 --> Config Class Initialized
INFO - 2016-11-30 11:21:00 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:21:00 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:21:00 --> Utf8 Class Initialized
INFO - 2016-11-30 11:21:00 --> URI Class Initialized
DEBUG - 2016-11-30 11:21:00 --> No URI present. Default controller set.
INFO - 2016-11-30 11:21:00 --> Router Class Initialized
INFO - 2016-11-30 11:21:00 --> Output Class Initialized
INFO - 2016-11-30 11:21:00 --> Security Class Initialized
DEBUG - 2016-11-30 11:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:21:00 --> Input Class Initialized
INFO - 2016-11-30 11:21:00 --> Language Class Initialized
INFO - 2016-11-30 11:21:00 --> Loader Class Initialized
INFO - 2016-11-30 11:21:00 --> Helper loaded: url_helper
INFO - 2016-11-30 11:21:00 --> Helper loaded: form_helper
INFO - 2016-11-30 11:21:00 --> Database Driver Class Initialized
INFO - 2016-11-30 11:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:21:00 --> Controller Class Initialized
INFO - 2016-11-30 11:21:00 --> Model Class Initialized
INFO - 2016-11-30 11:21:00 --> Model Class Initialized
INFO - 2016-11-30 11:21:00 --> Model Class Initialized
INFO - 2016-11-30 11:21:00 --> Model Class Initialized
INFO - 2016-11-30 11:21:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:21:00 --> Pagination Class Initialized
INFO - 2016-11-30 11:21:00 --> Helper loaded: app_helper
INFO - 2016-11-30 11:21:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:21:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-30 11:21:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:21:01 --> Final output sent to browser
DEBUG - 2016-11-30 11:21:01 --> Total execution time: 0.7192
INFO - 2016-11-30 11:21:11 --> Config Class Initialized
INFO - 2016-11-30 11:21:11 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:21:11 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:21:11 --> Utf8 Class Initialized
INFO - 2016-11-30 11:21:11 --> URI Class Initialized
INFO - 2016-11-30 11:21:11 --> Router Class Initialized
INFO - 2016-11-30 11:21:11 --> Output Class Initialized
INFO - 2016-11-30 11:21:11 --> Security Class Initialized
DEBUG - 2016-11-30 11:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:21:11 --> Input Class Initialized
INFO - 2016-11-30 11:21:11 --> Language Class Initialized
INFO - 2016-11-30 11:21:11 --> Loader Class Initialized
INFO - 2016-11-30 11:21:11 --> Helper loaded: url_helper
INFO - 2016-11-30 11:21:11 --> Helper loaded: form_helper
INFO - 2016-11-30 11:21:11 --> Database Driver Class Initialized
INFO - 2016-11-30 11:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:21:11 --> Controller Class Initialized
INFO - 2016-11-30 11:21:11 --> Model Class Initialized
INFO - 2016-11-30 11:21:11 --> Model Class Initialized
INFO - 2016-11-30 11:21:11 --> Model Class Initialized
INFO - 2016-11-30 11:21:11 --> Model Class Initialized
INFO - 2016-11-30 11:21:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:21:11 --> Pagination Class Initialized
INFO - 2016-11-30 11:21:11 --> Helper loaded: app_helper
DEBUG - 2016-11-30 11:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 11:21:11 --> Model Class Initialized
INFO - 2016-11-30 11:21:11 --> Final output sent to browser
DEBUG - 2016-11-30 11:21:11 --> Total execution time: 0.3465
INFO - 2016-11-30 11:21:11 --> Config Class Initialized
INFO - 2016-11-30 11:21:11 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:21:11 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:21:11 --> Utf8 Class Initialized
INFO - 2016-11-30 11:21:11 --> URI Class Initialized
DEBUG - 2016-11-30 11:21:11 --> No URI present. Default controller set.
INFO - 2016-11-30 11:21:11 --> Router Class Initialized
INFO - 2016-11-30 11:21:11 --> Output Class Initialized
INFO - 2016-11-30 11:21:11 --> Security Class Initialized
DEBUG - 2016-11-30 11:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:21:11 --> Input Class Initialized
INFO - 2016-11-30 11:21:11 --> Language Class Initialized
INFO - 2016-11-30 11:21:11 --> Loader Class Initialized
INFO - 2016-11-30 11:21:11 --> Helper loaded: url_helper
INFO - 2016-11-30 11:21:11 --> Helper loaded: form_helper
INFO - 2016-11-30 11:21:11 --> Database Driver Class Initialized
INFO - 2016-11-30 11:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:21:11 --> Controller Class Initialized
INFO - 2016-11-30 11:21:11 --> Model Class Initialized
INFO - 2016-11-30 11:21:11 --> Model Class Initialized
INFO - 2016-11-30 11:21:11 --> Model Class Initialized
INFO - 2016-11-30 11:21:11 --> Model Class Initialized
INFO - 2016-11-30 11:21:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:21:11 --> Pagination Class Initialized
INFO - 2016-11-30 11:21:11 --> Helper loaded: app_helper
INFO - 2016-11-30 11:21:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:21:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:21:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:21:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-30 11:21:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 11:21:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-30 11:21:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:21:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:21:12 --> Final output sent to browser
DEBUG - 2016-11-30 11:21:12 --> Total execution time: 0.4411
INFO - 2016-11-30 11:21:21 --> Config Class Initialized
INFO - 2016-11-30 11:21:21 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:21:21 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:21:21 --> Utf8 Class Initialized
INFO - 2016-11-30 11:21:21 --> URI Class Initialized
DEBUG - 2016-11-30 11:21:21 --> No URI present. Default controller set.
INFO - 2016-11-30 11:21:21 --> Router Class Initialized
INFO - 2016-11-30 11:21:21 --> Output Class Initialized
INFO - 2016-11-30 11:21:21 --> Security Class Initialized
DEBUG - 2016-11-30 11:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:21:21 --> Input Class Initialized
INFO - 2016-11-30 11:21:21 --> Language Class Initialized
INFO - 2016-11-30 11:21:21 --> Loader Class Initialized
INFO - 2016-11-30 11:21:21 --> Helper loaded: url_helper
INFO - 2016-11-30 11:21:21 --> Helper loaded: form_helper
INFO - 2016-11-30 11:21:21 --> Database Driver Class Initialized
INFO - 2016-11-30 11:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:21:21 --> Controller Class Initialized
INFO - 2016-11-30 11:21:21 --> Model Class Initialized
INFO - 2016-11-30 11:21:21 --> Model Class Initialized
INFO - 2016-11-30 11:21:21 --> Model Class Initialized
INFO - 2016-11-30 11:21:21 --> Model Class Initialized
INFO - 2016-11-30 11:21:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:21:21 --> Pagination Class Initialized
INFO - 2016-11-30 11:21:21 --> Helper loaded: app_helper
INFO - 2016-11-30 11:21:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:21:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:21:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:21:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-30 11:21:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 11:21:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-30 11:21:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:21:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:21:21 --> Final output sent to browser
DEBUG - 2016-11-30 11:21:21 --> Total execution time: 0.5173
INFO - 2016-11-30 11:21:43 --> Config Class Initialized
INFO - 2016-11-30 11:21:43 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:21:43 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:21:43 --> Utf8 Class Initialized
INFO - 2016-11-30 11:21:43 --> URI Class Initialized
INFO - 2016-11-30 11:21:43 --> Router Class Initialized
INFO - 2016-11-30 11:21:43 --> Output Class Initialized
INFO - 2016-11-30 11:21:43 --> Security Class Initialized
DEBUG - 2016-11-30 11:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:21:43 --> Input Class Initialized
INFO - 2016-11-30 11:21:43 --> Language Class Initialized
INFO - 2016-11-30 11:21:43 --> Loader Class Initialized
INFO - 2016-11-30 11:21:43 --> Helper loaded: url_helper
INFO - 2016-11-30 11:21:43 --> Helper loaded: form_helper
INFO - 2016-11-30 11:21:43 --> Database Driver Class Initialized
INFO - 2016-11-30 11:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:21:43 --> Controller Class Initialized
INFO - 2016-11-30 11:21:43 --> Model Class Initialized
INFO - 2016-11-30 11:21:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:21:43 --> Pagination Class Initialized
INFO - 2016-11-30 11:21:43 --> Helper loaded: app_helper
INFO - 2016-11-30 11:21:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 11:21:43 --> Final output sent to browser
DEBUG - 2016-11-30 11:21:43 --> Total execution time: 0.3092
INFO - 2016-11-30 11:21:45 --> Config Class Initialized
INFO - 2016-11-30 11:21:45 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:21:45 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:21:45 --> Utf8 Class Initialized
INFO - 2016-11-30 11:21:45 --> URI Class Initialized
INFO - 2016-11-30 11:21:45 --> Router Class Initialized
INFO - 2016-11-30 11:21:45 --> Output Class Initialized
INFO - 2016-11-30 11:21:45 --> Security Class Initialized
DEBUG - 2016-11-30 11:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:21:45 --> Input Class Initialized
INFO - 2016-11-30 11:21:45 --> Language Class Initialized
INFO - 2016-11-30 11:21:45 --> Loader Class Initialized
INFO - 2016-11-30 11:21:46 --> Helper loaded: url_helper
INFO - 2016-11-30 11:21:46 --> Helper loaded: form_helper
INFO - 2016-11-30 11:21:46 --> Database Driver Class Initialized
INFO - 2016-11-30 11:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:21:46 --> Controller Class Initialized
INFO - 2016-11-30 11:21:46 --> Model Class Initialized
INFO - 2016-11-30 11:21:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:21:46 --> Pagination Class Initialized
INFO - 2016-11-30 11:21:46 --> Helper loaded: app_helper
INFO - 2016-11-30 11:21:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 11:21:46 --> Final output sent to browser
DEBUG - 2016-11-30 11:21:46 --> Total execution time: 0.2721
INFO - 2016-11-30 11:22:33 --> Config Class Initialized
INFO - 2016-11-30 11:22:33 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:22:33 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:22:33 --> Utf8 Class Initialized
INFO - 2016-11-30 11:22:33 --> URI Class Initialized
INFO - 2016-11-30 11:22:33 --> Router Class Initialized
INFO - 2016-11-30 11:22:33 --> Output Class Initialized
INFO - 2016-11-30 11:22:33 --> Security Class Initialized
DEBUG - 2016-11-30 11:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:22:33 --> Input Class Initialized
INFO - 2016-11-30 11:22:33 --> Language Class Initialized
INFO - 2016-11-30 11:22:33 --> Loader Class Initialized
INFO - 2016-11-30 11:22:33 --> Helper loaded: url_helper
INFO - 2016-11-30 11:22:33 --> Helper loaded: form_helper
INFO - 2016-11-30 11:22:33 --> Database Driver Class Initialized
INFO - 2016-11-30 11:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:22:33 --> Controller Class Initialized
INFO - 2016-11-30 11:22:33 --> Model Class Initialized
INFO - 2016-11-30 11:22:33 --> Model Class Initialized
INFO - 2016-11-30 11:22:33 --> Model Class Initialized
INFO - 2016-11-30 11:22:33 --> Model Class Initialized
INFO - 2016-11-30 11:22:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:22:33 --> Pagination Class Initialized
INFO - 2016-11-30 11:22:33 --> Helper loaded: app_helper
DEBUG - 2016-11-30 11:22:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-30 11:22:33 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-30 11:22:33 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-30 11:22:33 --> Config Class Initialized
INFO - 2016-11-30 11:22:33 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:22:33 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:22:33 --> Utf8 Class Initialized
INFO - 2016-11-30 11:22:33 --> URI Class Initialized
DEBUG - 2016-11-30 11:22:33 --> No URI present. Default controller set.
INFO - 2016-11-30 11:22:33 --> Router Class Initialized
INFO - 2016-11-30 11:22:33 --> Output Class Initialized
INFO - 2016-11-30 11:22:33 --> Security Class Initialized
DEBUG - 2016-11-30 11:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:22:33 --> Input Class Initialized
INFO - 2016-11-30 11:22:33 --> Language Class Initialized
INFO - 2016-11-30 11:22:33 --> Loader Class Initialized
INFO - 2016-11-30 11:22:33 --> Helper loaded: url_helper
INFO - 2016-11-30 11:22:33 --> Helper loaded: form_helper
INFO - 2016-11-30 11:22:33 --> Database Driver Class Initialized
INFO - 2016-11-30 11:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:22:33 --> Controller Class Initialized
INFO - 2016-11-30 11:22:33 --> Model Class Initialized
INFO - 2016-11-30 11:22:33 --> Model Class Initialized
INFO - 2016-11-30 11:22:33 --> Model Class Initialized
INFO - 2016-11-30 11:22:33 --> Model Class Initialized
INFO - 2016-11-30 11:22:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:22:33 --> Pagination Class Initialized
INFO - 2016-11-30 11:22:33 --> Helper loaded: app_helper
INFO - 2016-11-30 11:22:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:22:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-30 11:22:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:22:33 --> Final output sent to browser
DEBUG - 2016-11-30 11:22:33 --> Total execution time: 0.3694
INFO - 2016-11-30 11:22:43 --> Config Class Initialized
INFO - 2016-11-30 11:22:43 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:22:43 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:22:43 --> Utf8 Class Initialized
INFO - 2016-11-30 11:22:43 --> URI Class Initialized
INFO - 2016-11-30 11:22:43 --> Router Class Initialized
INFO - 2016-11-30 11:22:43 --> Output Class Initialized
INFO - 2016-11-30 11:22:43 --> Security Class Initialized
DEBUG - 2016-11-30 11:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:22:43 --> Input Class Initialized
INFO - 2016-11-30 11:22:43 --> Language Class Initialized
INFO - 2016-11-30 11:22:43 --> Loader Class Initialized
INFO - 2016-11-30 11:22:43 --> Helper loaded: url_helper
INFO - 2016-11-30 11:22:43 --> Helper loaded: form_helper
INFO - 2016-11-30 11:22:43 --> Database Driver Class Initialized
INFO - 2016-11-30 11:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:22:43 --> Controller Class Initialized
INFO - 2016-11-30 11:22:43 --> Model Class Initialized
INFO - 2016-11-30 11:22:43 --> Model Class Initialized
INFO - 2016-11-30 11:22:43 --> Model Class Initialized
INFO - 2016-11-30 11:22:43 --> Model Class Initialized
INFO - 2016-11-30 11:22:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:22:43 --> Pagination Class Initialized
INFO - 2016-11-30 11:22:43 --> Helper loaded: app_helper
DEBUG - 2016-11-30 11:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 11:22:43 --> Model Class Initialized
INFO - 2016-11-30 11:22:43 --> Final output sent to browser
DEBUG - 2016-11-30 11:22:43 --> Total execution time: 0.3356
INFO - 2016-11-30 11:22:43 --> Config Class Initialized
INFO - 2016-11-30 11:22:43 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:22:43 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:22:43 --> Utf8 Class Initialized
INFO - 2016-11-30 11:22:43 --> URI Class Initialized
DEBUG - 2016-11-30 11:22:43 --> No URI present. Default controller set.
INFO - 2016-11-30 11:22:44 --> Router Class Initialized
INFO - 2016-11-30 11:22:44 --> Output Class Initialized
INFO - 2016-11-30 11:22:44 --> Security Class Initialized
DEBUG - 2016-11-30 11:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:22:44 --> Input Class Initialized
INFO - 2016-11-30 11:22:44 --> Language Class Initialized
INFO - 2016-11-30 11:22:44 --> Loader Class Initialized
INFO - 2016-11-30 11:22:44 --> Helper loaded: url_helper
INFO - 2016-11-30 11:22:44 --> Helper loaded: form_helper
INFO - 2016-11-30 11:22:44 --> Database Driver Class Initialized
INFO - 2016-11-30 11:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:22:44 --> Controller Class Initialized
INFO - 2016-11-30 11:22:44 --> Model Class Initialized
INFO - 2016-11-30 11:22:44 --> Model Class Initialized
INFO - 2016-11-30 11:22:44 --> Model Class Initialized
INFO - 2016-11-30 11:22:44 --> Model Class Initialized
INFO - 2016-11-30 11:22:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:22:44 --> Pagination Class Initialized
INFO - 2016-11-30 11:22:44 --> Helper loaded: app_helper
INFO - 2016-11-30 11:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 11:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 11:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 11:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 11:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:22:44 --> Final output sent to browser
DEBUG - 2016-11-30 11:22:44 --> Total execution time: 0.5557
INFO - 2016-11-30 11:23:53 --> Config Class Initialized
INFO - 2016-11-30 11:23:53 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:23:53 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:23:53 --> Utf8 Class Initialized
INFO - 2016-11-30 11:23:53 --> URI Class Initialized
DEBUG - 2016-11-30 11:23:53 --> No URI present. Default controller set.
INFO - 2016-11-30 11:23:53 --> Router Class Initialized
INFO - 2016-11-30 11:23:53 --> Output Class Initialized
INFO - 2016-11-30 11:23:53 --> Security Class Initialized
DEBUG - 2016-11-30 11:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:23:53 --> Input Class Initialized
INFO - 2016-11-30 11:23:53 --> Language Class Initialized
INFO - 2016-11-30 11:23:53 --> Loader Class Initialized
INFO - 2016-11-30 11:23:53 --> Helper loaded: url_helper
INFO - 2016-11-30 11:23:53 --> Helper loaded: form_helper
INFO - 2016-11-30 11:23:53 --> Database Driver Class Initialized
INFO - 2016-11-30 11:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:23:53 --> Controller Class Initialized
INFO - 2016-11-30 11:23:53 --> Model Class Initialized
INFO - 2016-11-30 11:23:53 --> Model Class Initialized
INFO - 2016-11-30 11:23:53 --> Model Class Initialized
INFO - 2016-11-30 11:23:53 --> Model Class Initialized
INFO - 2016-11-30 11:23:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:23:53 --> Pagination Class Initialized
INFO - 2016-11-30 11:23:53 --> Helper loaded: app_helper
INFO - 2016-11-30 11:23:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:23:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:23:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:23:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 11:23:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 11:23:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 11:23:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 11:23:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:23:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:23:53 --> Final output sent to browser
DEBUG - 2016-11-30 11:23:53 --> Total execution time: 0.5069
INFO - 2016-11-30 11:24:03 --> Config Class Initialized
INFO - 2016-11-30 11:24:03 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:24:03 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:24:03 --> Utf8 Class Initialized
INFO - 2016-11-30 11:24:03 --> URI Class Initialized
INFO - 2016-11-30 11:24:03 --> Router Class Initialized
INFO - 2016-11-30 11:24:03 --> Output Class Initialized
INFO - 2016-11-30 11:24:03 --> Security Class Initialized
DEBUG - 2016-11-30 11:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:24:03 --> Input Class Initialized
INFO - 2016-11-30 11:24:03 --> Language Class Initialized
INFO - 2016-11-30 11:24:03 --> Loader Class Initialized
INFO - 2016-11-30 11:24:03 --> Helper loaded: url_helper
INFO - 2016-11-30 11:24:03 --> Helper loaded: form_helper
INFO - 2016-11-30 11:24:03 --> Database Driver Class Initialized
INFO - 2016-11-30 11:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:24:03 --> Controller Class Initialized
INFO - 2016-11-30 11:24:03 --> Model Class Initialized
INFO - 2016-11-30 11:24:03 --> Form Validation Class Initialized
INFO - 2016-11-30 11:24:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:24:03 --> Pagination Class Initialized
INFO - 2016-11-30 11:24:03 --> Helper loaded: app_helper
INFO - 2016-11-30 11:24:03 --> Email Class Initialized
INFO - 2016-11-30 11:24:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 11:24:03 --> Final output sent to browser
DEBUG - 2016-11-30 11:24:03 --> Total execution time: 0.4867
INFO - 2016-11-30 11:26:55 --> Config Class Initialized
INFO - 2016-11-30 11:26:56 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:26:56 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:26:56 --> Utf8 Class Initialized
INFO - 2016-11-30 11:26:56 --> URI Class Initialized
INFO - 2016-11-30 11:26:56 --> Router Class Initialized
INFO - 2016-11-30 11:26:56 --> Output Class Initialized
INFO - 2016-11-30 11:26:56 --> Security Class Initialized
DEBUG - 2016-11-30 11:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:26:56 --> Input Class Initialized
INFO - 2016-11-30 11:26:56 --> Language Class Initialized
INFO - 2016-11-30 11:26:56 --> Loader Class Initialized
INFO - 2016-11-30 11:26:56 --> Helper loaded: url_helper
INFO - 2016-11-30 11:26:56 --> Helper loaded: form_helper
INFO - 2016-11-30 11:26:56 --> Database Driver Class Initialized
INFO - 2016-11-30 11:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:26:56 --> Controller Class Initialized
INFO - 2016-11-30 11:26:56 --> Model Class Initialized
INFO - 2016-11-30 11:26:56 --> Model Class Initialized
INFO - 2016-11-30 11:26:56 --> Model Class Initialized
INFO - 2016-11-30 11:26:56 --> Model Class Initialized
INFO - 2016-11-30 11:26:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:26:56 --> Pagination Class Initialized
INFO - 2016-11-30 11:26:56 --> Helper loaded: app_helper
DEBUG - 2016-11-30 11:26:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-30 11:26:56 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-30 11:26:56 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-30 11:26:56 --> Config Class Initialized
INFO - 2016-11-30 11:26:56 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:26:56 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:26:56 --> Utf8 Class Initialized
INFO - 2016-11-30 11:26:56 --> URI Class Initialized
DEBUG - 2016-11-30 11:26:56 --> No URI present. Default controller set.
INFO - 2016-11-30 11:26:56 --> Router Class Initialized
INFO - 2016-11-30 11:26:56 --> Output Class Initialized
INFO - 2016-11-30 11:26:56 --> Security Class Initialized
DEBUG - 2016-11-30 11:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:26:56 --> Input Class Initialized
INFO - 2016-11-30 11:26:56 --> Language Class Initialized
INFO - 2016-11-30 11:26:56 --> Loader Class Initialized
INFO - 2016-11-30 11:26:56 --> Helper loaded: url_helper
INFO - 2016-11-30 11:26:56 --> Helper loaded: form_helper
INFO - 2016-11-30 11:26:56 --> Database Driver Class Initialized
INFO - 2016-11-30 11:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:26:56 --> Controller Class Initialized
INFO - 2016-11-30 11:26:56 --> Model Class Initialized
INFO - 2016-11-30 11:26:56 --> Model Class Initialized
INFO - 2016-11-30 11:26:56 --> Model Class Initialized
INFO - 2016-11-30 11:26:56 --> Model Class Initialized
INFO - 2016-11-30 11:26:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:26:56 --> Pagination Class Initialized
INFO - 2016-11-30 11:26:56 --> Helper loaded: app_helper
INFO - 2016-11-30 11:26:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:26:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-30 11:26:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:26:56 --> Final output sent to browser
DEBUG - 2016-11-30 11:26:56 --> Total execution time: 0.5600
INFO - 2016-11-30 11:27:27 --> Config Class Initialized
INFO - 2016-11-30 11:27:27 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:27:27 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:27:27 --> Utf8 Class Initialized
INFO - 2016-11-30 11:27:27 --> URI Class Initialized
DEBUG - 2016-11-30 11:27:27 --> No URI present. Default controller set.
INFO - 2016-11-30 11:27:27 --> Router Class Initialized
INFO - 2016-11-30 11:27:27 --> Output Class Initialized
INFO - 2016-11-30 11:27:27 --> Security Class Initialized
DEBUG - 2016-11-30 11:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:27:27 --> Input Class Initialized
INFO - 2016-11-30 11:27:27 --> Language Class Initialized
INFO - 2016-11-30 11:27:27 --> Loader Class Initialized
INFO - 2016-11-30 11:27:27 --> Helper loaded: url_helper
INFO - 2016-11-30 11:27:27 --> Helper loaded: form_helper
INFO - 2016-11-30 11:27:27 --> Database Driver Class Initialized
INFO - 2016-11-30 11:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:27:27 --> Controller Class Initialized
INFO - 2016-11-30 11:27:27 --> Model Class Initialized
INFO - 2016-11-30 11:27:27 --> Model Class Initialized
INFO - 2016-11-30 11:27:27 --> Model Class Initialized
INFO - 2016-11-30 11:27:28 --> Model Class Initialized
INFO - 2016-11-30 11:27:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:27:28 --> Pagination Class Initialized
INFO - 2016-11-30 11:27:28 --> Helper loaded: app_helper
INFO - 2016-11-30 11:27:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:27:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-30 11:27:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:27:28 --> Final output sent to browser
DEBUG - 2016-11-30 11:27:28 --> Total execution time: 0.3827
INFO - 2016-11-30 11:27:38 --> Config Class Initialized
INFO - 2016-11-30 11:27:38 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:27:38 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:27:38 --> Utf8 Class Initialized
INFO - 2016-11-30 11:27:38 --> URI Class Initialized
INFO - 2016-11-30 11:27:38 --> Router Class Initialized
INFO - 2016-11-30 11:27:38 --> Output Class Initialized
INFO - 2016-11-30 11:27:38 --> Security Class Initialized
DEBUG - 2016-11-30 11:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:27:38 --> Input Class Initialized
INFO - 2016-11-30 11:27:38 --> Language Class Initialized
INFO - 2016-11-30 11:27:38 --> Loader Class Initialized
INFO - 2016-11-30 11:27:38 --> Helper loaded: url_helper
INFO - 2016-11-30 11:27:38 --> Helper loaded: form_helper
INFO - 2016-11-30 11:27:38 --> Database Driver Class Initialized
INFO - 2016-11-30 11:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:27:38 --> Controller Class Initialized
INFO - 2016-11-30 11:27:38 --> Model Class Initialized
INFO - 2016-11-30 11:27:38 --> Model Class Initialized
INFO - 2016-11-30 11:27:38 --> Model Class Initialized
INFO - 2016-11-30 11:27:38 --> Model Class Initialized
INFO - 2016-11-30 11:27:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:27:38 --> Pagination Class Initialized
INFO - 2016-11-30 11:27:38 --> Helper loaded: app_helper
DEBUG - 2016-11-30 11:27:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 11:27:38 --> Model Class Initialized
INFO - 2016-11-30 11:27:38 --> Final output sent to browser
DEBUG - 2016-11-30 11:27:38 --> Total execution time: 0.3569
INFO - 2016-11-30 11:27:38 --> Config Class Initialized
INFO - 2016-11-30 11:27:38 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:27:38 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:27:39 --> Utf8 Class Initialized
INFO - 2016-11-30 11:27:39 --> URI Class Initialized
DEBUG - 2016-11-30 11:27:39 --> No URI present. Default controller set.
INFO - 2016-11-30 11:27:39 --> Router Class Initialized
INFO - 2016-11-30 11:27:39 --> Output Class Initialized
INFO - 2016-11-30 11:27:39 --> Security Class Initialized
DEBUG - 2016-11-30 11:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:27:39 --> Input Class Initialized
INFO - 2016-11-30 11:27:39 --> Language Class Initialized
INFO - 2016-11-30 11:27:39 --> Loader Class Initialized
INFO - 2016-11-30 11:27:39 --> Helper loaded: url_helper
INFO - 2016-11-30 11:27:39 --> Helper loaded: form_helper
INFO - 2016-11-30 11:27:39 --> Database Driver Class Initialized
INFO - 2016-11-30 11:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:27:39 --> Controller Class Initialized
INFO - 2016-11-30 11:27:39 --> Model Class Initialized
INFO - 2016-11-30 11:27:39 --> Model Class Initialized
INFO - 2016-11-30 11:27:39 --> Model Class Initialized
INFO - 2016-11-30 11:27:39 --> Model Class Initialized
INFO - 2016-11-30 11:27:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:27:39 --> Pagination Class Initialized
INFO - 2016-11-30 11:27:39 --> Helper loaded: app_helper
INFO - 2016-11-30 11:27:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:27:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:27:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:27:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-30 11:27:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 11:27:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-30 11:27:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:27:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:27:39 --> Final output sent to browser
DEBUG - 2016-11-30 11:27:39 --> Total execution time: 0.4619
INFO - 2016-11-30 11:27:42 --> Config Class Initialized
INFO - 2016-11-30 11:27:42 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:27:42 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:27:42 --> Utf8 Class Initialized
INFO - 2016-11-30 11:27:42 --> URI Class Initialized
INFO - 2016-11-30 11:27:42 --> Router Class Initialized
INFO - 2016-11-30 11:27:42 --> Output Class Initialized
INFO - 2016-11-30 11:27:42 --> Security Class Initialized
DEBUG - 2016-11-30 11:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:27:42 --> Input Class Initialized
INFO - 2016-11-30 11:27:42 --> Language Class Initialized
INFO - 2016-11-30 11:27:42 --> Loader Class Initialized
INFO - 2016-11-30 11:27:42 --> Helper loaded: url_helper
INFO - 2016-11-30 11:27:42 --> Helper loaded: form_helper
INFO - 2016-11-30 11:27:42 --> Database Driver Class Initialized
INFO - 2016-11-30 11:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:27:42 --> Controller Class Initialized
INFO - 2016-11-30 11:27:42 --> Model Class Initialized
INFO - 2016-11-30 11:27:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:27:42 --> Pagination Class Initialized
INFO - 2016-11-30 11:27:42 --> Helper loaded: app_helper
INFO - 2016-11-30 11:27:42 --> Form Validation Class Initialized
INFO - 2016-11-30 11:27:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 11:27:42 --> Final output sent to browser
DEBUG - 2016-11-30 11:27:42 --> Total execution time: 0.2926
INFO - 2016-11-30 11:27:46 --> Config Class Initialized
INFO - 2016-11-30 11:27:46 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:27:46 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:27:46 --> Utf8 Class Initialized
INFO - 2016-11-30 11:27:46 --> URI Class Initialized
INFO - 2016-11-30 11:27:46 --> Router Class Initialized
INFO - 2016-11-30 11:27:46 --> Output Class Initialized
INFO - 2016-11-30 11:27:46 --> Security Class Initialized
DEBUG - 2016-11-30 11:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:27:46 --> Input Class Initialized
INFO - 2016-11-30 11:27:46 --> Language Class Initialized
INFO - 2016-11-30 11:27:46 --> Loader Class Initialized
INFO - 2016-11-30 11:27:46 --> Helper loaded: url_helper
INFO - 2016-11-30 11:27:46 --> Helper loaded: form_helper
INFO - 2016-11-30 11:27:46 --> Database Driver Class Initialized
INFO - 2016-11-30 11:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:27:46 --> Controller Class Initialized
INFO - 2016-11-30 11:27:46 --> Model Class Initialized
INFO - 2016-11-30 11:27:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:27:46 --> Pagination Class Initialized
INFO - 2016-11-30 11:27:46 --> Helper loaded: app_helper
INFO - 2016-11-30 11:27:47 --> Form Validation Class Initialized
INFO - 2016-11-30 11:27:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 11:27:47 --> Final output sent to browser
DEBUG - 2016-11-30 11:27:47 --> Total execution time: 0.3915
INFO - 2016-11-30 11:31:43 --> Config Class Initialized
INFO - 2016-11-30 11:31:43 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:31:43 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:31:43 --> Utf8 Class Initialized
INFO - 2016-11-30 11:31:43 --> URI Class Initialized
DEBUG - 2016-11-30 11:31:43 --> No URI present. Default controller set.
INFO - 2016-11-30 11:31:43 --> Router Class Initialized
INFO - 2016-11-30 11:31:43 --> Output Class Initialized
INFO - 2016-11-30 11:31:43 --> Security Class Initialized
DEBUG - 2016-11-30 11:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:31:43 --> Input Class Initialized
INFO - 2016-11-30 11:31:43 --> Language Class Initialized
INFO - 2016-11-30 11:31:43 --> Loader Class Initialized
INFO - 2016-11-30 11:31:43 --> Helper loaded: url_helper
INFO - 2016-11-30 11:31:43 --> Helper loaded: form_helper
INFO - 2016-11-30 11:31:43 --> Database Driver Class Initialized
INFO - 2016-11-30 11:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:31:43 --> Controller Class Initialized
INFO - 2016-11-30 11:31:43 --> Model Class Initialized
INFO - 2016-11-30 11:31:43 --> Model Class Initialized
INFO - 2016-11-30 11:31:43 --> Model Class Initialized
INFO - 2016-11-30 11:31:43 --> Model Class Initialized
INFO - 2016-11-30 11:31:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:31:43 --> Pagination Class Initialized
INFO - 2016-11-30 11:31:43 --> Helper loaded: app_helper
INFO - 2016-11-30 11:31:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:31:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:31:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:31:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-30 11:31:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 11:31:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-30 11:31:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:31:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:31:43 --> Final output sent to browser
DEBUG - 2016-11-30 11:31:43 --> Total execution time: 0.4784
INFO - 2016-11-30 11:31:45 --> Config Class Initialized
INFO - 2016-11-30 11:31:45 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:31:45 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:31:45 --> Utf8 Class Initialized
INFO - 2016-11-30 11:31:45 --> URI Class Initialized
INFO - 2016-11-30 11:31:45 --> Router Class Initialized
INFO - 2016-11-30 11:31:45 --> Output Class Initialized
INFO - 2016-11-30 11:31:45 --> Security Class Initialized
DEBUG - 2016-11-30 11:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:31:45 --> Input Class Initialized
INFO - 2016-11-30 11:31:45 --> Language Class Initialized
INFO - 2016-11-30 11:31:45 --> Loader Class Initialized
INFO - 2016-11-30 11:31:45 --> Helper loaded: url_helper
INFO - 2016-11-30 11:31:45 --> Helper loaded: form_helper
INFO - 2016-11-30 11:31:45 --> Database Driver Class Initialized
INFO - 2016-11-30 11:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:31:45 --> Controller Class Initialized
INFO - 2016-11-30 11:31:45 --> Model Class Initialized
INFO - 2016-11-30 11:31:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:31:45 --> Pagination Class Initialized
INFO - 2016-11-30 11:31:45 --> Helper loaded: app_helper
INFO - 2016-11-30 11:31:45 --> Form Validation Class Initialized
INFO - 2016-11-30 11:31:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 11:31:45 --> Final output sent to browser
DEBUG - 2016-11-30 11:31:45 --> Total execution time: 0.3381
INFO - 2016-11-30 11:31:47 --> Config Class Initialized
INFO - 2016-11-30 11:31:47 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:31:47 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:31:47 --> Utf8 Class Initialized
INFO - 2016-11-30 11:31:47 --> URI Class Initialized
INFO - 2016-11-30 11:31:47 --> Router Class Initialized
INFO - 2016-11-30 11:31:47 --> Output Class Initialized
INFO - 2016-11-30 11:31:47 --> Security Class Initialized
DEBUG - 2016-11-30 11:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:31:47 --> Input Class Initialized
INFO - 2016-11-30 11:31:47 --> Language Class Initialized
INFO - 2016-11-30 11:31:47 --> Loader Class Initialized
INFO - 2016-11-30 11:31:47 --> Helper loaded: url_helper
INFO - 2016-11-30 11:31:47 --> Helper loaded: form_helper
INFO - 2016-11-30 11:31:47 --> Database Driver Class Initialized
INFO - 2016-11-30 11:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:31:47 --> Controller Class Initialized
INFO - 2016-11-30 11:31:47 --> Model Class Initialized
INFO - 2016-11-30 11:31:47 --> Model Class Initialized
INFO - 2016-11-30 11:31:47 --> Model Class Initialized
INFO - 2016-11-30 11:31:47 --> Model Class Initialized
INFO - 2016-11-30 11:31:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:31:47 --> Pagination Class Initialized
INFO - 2016-11-30 11:31:47 --> Helper loaded: app_helper
DEBUG - 2016-11-30 11:31:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-30 11:31:47 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-30 11:31:48 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-30 11:31:48 --> Config Class Initialized
INFO - 2016-11-30 11:31:48 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:31:48 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:31:48 --> Utf8 Class Initialized
INFO - 2016-11-30 11:31:48 --> URI Class Initialized
DEBUG - 2016-11-30 11:31:48 --> No URI present. Default controller set.
INFO - 2016-11-30 11:31:48 --> Router Class Initialized
INFO - 2016-11-30 11:31:48 --> Output Class Initialized
INFO - 2016-11-30 11:31:48 --> Security Class Initialized
DEBUG - 2016-11-30 11:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:31:48 --> Input Class Initialized
INFO - 2016-11-30 11:31:48 --> Language Class Initialized
INFO - 2016-11-30 11:31:48 --> Loader Class Initialized
INFO - 2016-11-30 11:31:48 --> Helper loaded: url_helper
INFO - 2016-11-30 11:31:48 --> Helper loaded: form_helper
INFO - 2016-11-30 11:31:48 --> Database Driver Class Initialized
INFO - 2016-11-30 11:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:31:48 --> Controller Class Initialized
INFO - 2016-11-30 11:31:48 --> Model Class Initialized
INFO - 2016-11-30 11:31:48 --> Model Class Initialized
INFO - 2016-11-30 11:31:48 --> Model Class Initialized
INFO - 2016-11-30 11:31:48 --> Model Class Initialized
INFO - 2016-11-30 11:31:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:31:48 --> Pagination Class Initialized
INFO - 2016-11-30 11:31:48 --> Helper loaded: app_helper
INFO - 2016-11-30 11:31:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:31:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-30 11:31:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:31:48 --> Final output sent to browser
DEBUG - 2016-11-30 11:31:48 --> Total execution time: 0.4086
INFO - 2016-11-30 11:31:57 --> Config Class Initialized
INFO - 2016-11-30 11:31:57 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:31:57 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:31:57 --> Utf8 Class Initialized
INFO - 2016-11-30 11:31:57 --> URI Class Initialized
INFO - 2016-11-30 11:31:57 --> Router Class Initialized
INFO - 2016-11-30 11:31:57 --> Output Class Initialized
INFO - 2016-11-30 11:31:57 --> Security Class Initialized
DEBUG - 2016-11-30 11:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:31:57 --> Input Class Initialized
INFO - 2016-11-30 11:31:57 --> Language Class Initialized
INFO - 2016-11-30 11:31:57 --> Loader Class Initialized
INFO - 2016-11-30 11:31:57 --> Helper loaded: url_helper
INFO - 2016-11-30 11:31:57 --> Helper loaded: form_helper
INFO - 2016-11-30 11:31:57 --> Database Driver Class Initialized
INFO - 2016-11-30 11:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:31:58 --> Controller Class Initialized
INFO - 2016-11-30 11:31:58 --> Model Class Initialized
INFO - 2016-11-30 11:31:58 --> Model Class Initialized
INFO - 2016-11-30 11:31:58 --> Model Class Initialized
INFO - 2016-11-30 11:31:58 --> Model Class Initialized
INFO - 2016-11-30 11:31:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:31:58 --> Pagination Class Initialized
INFO - 2016-11-30 11:31:58 --> Helper loaded: app_helper
DEBUG - 2016-11-30 11:31:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 11:31:58 --> Model Class Initialized
INFO - 2016-11-30 11:31:58 --> Final output sent to browser
DEBUG - 2016-11-30 11:31:58 --> Total execution time: 0.4347
INFO - 2016-11-30 11:31:58 --> Config Class Initialized
INFO - 2016-11-30 11:31:58 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:31:58 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:31:58 --> Utf8 Class Initialized
INFO - 2016-11-30 11:31:58 --> URI Class Initialized
DEBUG - 2016-11-30 11:31:58 --> No URI present. Default controller set.
INFO - 2016-11-30 11:31:58 --> Router Class Initialized
INFO - 2016-11-30 11:31:58 --> Output Class Initialized
INFO - 2016-11-30 11:31:58 --> Security Class Initialized
DEBUG - 2016-11-30 11:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:31:58 --> Input Class Initialized
INFO - 2016-11-30 11:31:58 --> Language Class Initialized
INFO - 2016-11-30 11:31:58 --> Loader Class Initialized
INFO - 2016-11-30 11:31:58 --> Helper loaded: url_helper
INFO - 2016-11-30 11:31:58 --> Helper loaded: form_helper
INFO - 2016-11-30 11:31:58 --> Database Driver Class Initialized
INFO - 2016-11-30 11:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:31:58 --> Controller Class Initialized
INFO - 2016-11-30 11:31:58 --> Model Class Initialized
INFO - 2016-11-30 11:31:58 --> Model Class Initialized
INFO - 2016-11-30 11:31:58 --> Model Class Initialized
INFO - 2016-11-30 11:31:58 --> Model Class Initialized
INFO - 2016-11-30 11:31:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:31:58 --> Pagination Class Initialized
INFO - 2016-11-30 11:31:59 --> Helper loaded: app_helper
INFO - 2016-11-30 11:31:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:31:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:31:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:31:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 11:31:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 11:31:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 11:31:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 11:31:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:31:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:31:59 --> Final output sent to browser
DEBUG - 2016-11-30 11:31:59 --> Total execution time: 1.0527
INFO - 2016-11-30 11:32:02 --> Config Class Initialized
INFO - 2016-11-30 11:32:02 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:32:02 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:32:02 --> Utf8 Class Initialized
INFO - 2016-11-30 11:32:02 --> URI Class Initialized
INFO - 2016-11-30 11:32:02 --> Router Class Initialized
INFO - 2016-11-30 11:32:02 --> Output Class Initialized
INFO - 2016-11-30 11:32:02 --> Security Class Initialized
DEBUG - 2016-11-30 11:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:32:02 --> Input Class Initialized
INFO - 2016-11-30 11:32:02 --> Language Class Initialized
INFO - 2016-11-30 11:32:02 --> Loader Class Initialized
INFO - 2016-11-30 11:32:03 --> Helper loaded: url_helper
INFO - 2016-11-30 11:32:03 --> Helper loaded: form_helper
INFO - 2016-11-30 11:32:03 --> Database Driver Class Initialized
INFO - 2016-11-30 11:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:32:03 --> Controller Class Initialized
INFO - 2016-11-30 11:32:03 --> Model Class Initialized
INFO - 2016-11-30 11:32:03 --> Form Validation Class Initialized
INFO - 2016-11-30 11:32:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:32:03 --> Pagination Class Initialized
INFO - 2016-11-30 11:32:03 --> Helper loaded: app_helper
INFO - 2016-11-30 11:32:03 --> Email Class Initialized
INFO - 2016-11-30 11:32:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 11:32:03 --> Final output sent to browser
DEBUG - 2016-11-30 11:32:03 --> Total execution time: 0.5948
INFO - 2016-11-30 11:32:05 --> Config Class Initialized
INFO - 2016-11-30 11:32:05 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:32:05 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:32:05 --> Utf8 Class Initialized
INFO - 2016-11-30 11:32:05 --> URI Class Initialized
DEBUG - 2016-11-30 11:32:05 --> No URI present. Default controller set.
INFO - 2016-11-30 11:32:05 --> Router Class Initialized
INFO - 2016-11-30 11:32:05 --> Output Class Initialized
INFO - 2016-11-30 11:32:05 --> Security Class Initialized
DEBUG - 2016-11-30 11:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:32:05 --> Input Class Initialized
INFO - 2016-11-30 11:32:05 --> Language Class Initialized
INFO - 2016-11-30 11:32:05 --> Loader Class Initialized
INFO - 2016-11-30 11:32:05 --> Helper loaded: url_helper
INFO - 2016-11-30 11:32:05 --> Helper loaded: form_helper
INFO - 2016-11-30 11:32:05 --> Database Driver Class Initialized
INFO - 2016-11-30 11:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:32:05 --> Controller Class Initialized
INFO - 2016-11-30 11:32:05 --> Model Class Initialized
INFO - 2016-11-30 11:32:05 --> Model Class Initialized
INFO - 2016-11-30 11:32:05 --> Model Class Initialized
INFO - 2016-11-30 11:32:05 --> Model Class Initialized
INFO - 2016-11-30 11:32:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:32:06 --> Pagination Class Initialized
INFO - 2016-11-30 11:32:06 --> Helper loaded: app_helper
INFO - 2016-11-30 11:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 11:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 11:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 11:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 11:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:32:06 --> Final output sent to browser
DEBUG - 2016-11-30 11:32:06 --> Total execution time: 0.5726
INFO - 2016-11-30 11:32:09 --> Config Class Initialized
INFO - 2016-11-30 11:32:09 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:32:10 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:32:10 --> Utf8 Class Initialized
INFO - 2016-11-30 11:32:10 --> URI Class Initialized
INFO - 2016-11-30 11:32:10 --> Router Class Initialized
INFO - 2016-11-30 11:32:10 --> Output Class Initialized
INFO - 2016-11-30 11:32:10 --> Security Class Initialized
DEBUG - 2016-11-30 11:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:32:10 --> Input Class Initialized
INFO - 2016-11-30 11:32:10 --> Language Class Initialized
INFO - 2016-11-30 11:32:10 --> Loader Class Initialized
INFO - 2016-11-30 11:32:10 --> Helper loaded: url_helper
INFO - 2016-11-30 11:32:10 --> Helper loaded: form_helper
INFO - 2016-11-30 11:32:10 --> Database Driver Class Initialized
INFO - 2016-11-30 11:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:32:10 --> Controller Class Initialized
INFO - 2016-11-30 11:32:10 --> Model Class Initialized
INFO - 2016-11-30 11:32:10 --> Form Validation Class Initialized
INFO - 2016-11-30 11:32:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:32:10 --> Pagination Class Initialized
INFO - 2016-11-30 11:32:10 --> Helper loaded: app_helper
INFO - 2016-11-30 11:32:10 --> Email Class Initialized
INFO - 2016-11-30 11:32:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 11:32:10 --> Final output sent to browser
DEBUG - 2016-11-30 11:32:10 --> Total execution time: 0.3158
INFO - 2016-11-30 11:33:20 --> Config Class Initialized
INFO - 2016-11-30 11:33:20 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:33:20 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:33:20 --> Utf8 Class Initialized
INFO - 2016-11-30 11:33:20 --> URI Class Initialized
DEBUG - 2016-11-30 11:33:20 --> No URI present. Default controller set.
INFO - 2016-11-30 11:33:20 --> Router Class Initialized
INFO - 2016-11-30 11:33:20 --> Output Class Initialized
INFO - 2016-11-30 11:33:20 --> Security Class Initialized
DEBUG - 2016-11-30 11:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:33:20 --> Input Class Initialized
INFO - 2016-11-30 11:33:20 --> Language Class Initialized
INFO - 2016-11-30 11:33:20 --> Loader Class Initialized
INFO - 2016-11-30 11:33:20 --> Helper loaded: url_helper
INFO - 2016-11-30 11:33:20 --> Helper loaded: form_helper
INFO - 2016-11-30 11:33:20 --> Database Driver Class Initialized
INFO - 2016-11-30 11:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:33:20 --> Controller Class Initialized
INFO - 2016-11-30 11:33:20 --> Model Class Initialized
INFO - 2016-11-30 11:33:20 --> Model Class Initialized
INFO - 2016-11-30 11:33:20 --> Model Class Initialized
INFO - 2016-11-30 11:33:20 --> Model Class Initialized
INFO - 2016-11-30 11:33:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:33:20 --> Pagination Class Initialized
INFO - 2016-11-30 11:33:20 --> Helper loaded: app_helper
INFO - 2016-11-30 11:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 11:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 11:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 11:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 11:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:33:20 --> Final output sent to browser
DEBUG - 2016-11-30 11:33:20 --> Total execution time: 0.4978
INFO - 2016-11-30 11:33:29 --> Config Class Initialized
INFO - 2016-11-30 11:33:29 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:33:29 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:33:29 --> Utf8 Class Initialized
INFO - 2016-11-30 11:33:29 --> URI Class Initialized
DEBUG - 2016-11-30 11:33:29 --> No URI present. Default controller set.
INFO - 2016-11-30 11:33:29 --> Router Class Initialized
INFO - 2016-11-30 11:33:29 --> Output Class Initialized
INFO - 2016-11-30 11:33:29 --> Security Class Initialized
DEBUG - 2016-11-30 11:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:33:29 --> Input Class Initialized
INFO - 2016-11-30 11:33:29 --> Language Class Initialized
INFO - 2016-11-30 11:33:29 --> Loader Class Initialized
INFO - 2016-11-30 11:33:29 --> Helper loaded: url_helper
INFO - 2016-11-30 11:33:29 --> Helper loaded: form_helper
INFO - 2016-11-30 11:33:29 --> Database Driver Class Initialized
INFO - 2016-11-30 11:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:33:29 --> Controller Class Initialized
INFO - 2016-11-30 11:33:29 --> Model Class Initialized
INFO - 2016-11-30 11:33:29 --> Model Class Initialized
INFO - 2016-11-30 11:33:29 --> Model Class Initialized
INFO - 2016-11-30 11:33:29 --> Model Class Initialized
INFO - 2016-11-30 11:33:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:33:29 --> Pagination Class Initialized
INFO - 2016-11-30 11:33:29 --> Helper loaded: app_helper
INFO - 2016-11-30 11:33:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:33:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:33:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:33:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 11:33:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 11:33:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 11:33:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 11:33:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:33:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:33:29 --> Final output sent to browser
DEBUG - 2016-11-30 11:33:29 --> Total execution time: 0.5036
INFO - 2016-11-30 11:33:42 --> Config Class Initialized
INFO - 2016-11-30 11:33:42 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:33:42 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:33:42 --> Utf8 Class Initialized
INFO - 2016-11-30 11:33:42 --> URI Class Initialized
INFO - 2016-11-30 11:33:42 --> Router Class Initialized
INFO - 2016-11-30 11:33:43 --> Output Class Initialized
INFO - 2016-11-30 11:33:43 --> Security Class Initialized
DEBUG - 2016-11-30 11:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:33:43 --> Input Class Initialized
INFO - 2016-11-30 11:33:43 --> Language Class Initialized
INFO - 2016-11-30 11:33:43 --> Loader Class Initialized
INFO - 2016-11-30 11:33:43 --> Helper loaded: url_helper
INFO - 2016-11-30 11:33:43 --> Helper loaded: form_helper
INFO - 2016-11-30 11:33:43 --> Database Driver Class Initialized
INFO - 2016-11-30 11:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:33:43 --> Controller Class Initialized
INFO - 2016-11-30 11:33:43 --> Model Class Initialized
INFO - 2016-11-30 11:33:43 --> Form Validation Class Initialized
INFO - 2016-11-30 11:33:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:33:43 --> Pagination Class Initialized
INFO - 2016-11-30 11:33:43 --> Helper loaded: app_helper
INFO - 2016-11-30 11:33:43 --> Email Class Initialized
INFO - 2016-11-30 11:33:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 11:33:43 --> Final output sent to browser
DEBUG - 2016-11-30 11:33:43 --> Total execution time: 0.3484
INFO - 2016-11-30 11:33:46 --> Config Class Initialized
INFO - 2016-11-30 11:33:46 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:33:46 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:33:46 --> Utf8 Class Initialized
INFO - 2016-11-30 11:33:46 --> URI Class Initialized
INFO - 2016-11-30 11:33:46 --> Router Class Initialized
INFO - 2016-11-30 11:33:46 --> Output Class Initialized
INFO - 2016-11-30 11:33:46 --> Security Class Initialized
DEBUG - 2016-11-30 11:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:33:46 --> Input Class Initialized
INFO - 2016-11-30 11:33:46 --> Language Class Initialized
INFO - 2016-11-30 11:33:46 --> Loader Class Initialized
INFO - 2016-11-30 11:33:46 --> Helper loaded: url_helper
INFO - 2016-11-30 11:33:46 --> Helper loaded: form_helper
INFO - 2016-11-30 11:33:46 --> Database Driver Class Initialized
INFO - 2016-11-30 11:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:33:46 --> Controller Class Initialized
INFO - 2016-11-30 11:33:46 --> Model Class Initialized
INFO - 2016-11-30 11:33:46 --> Form Validation Class Initialized
INFO - 2016-11-30 11:33:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:33:46 --> Pagination Class Initialized
INFO - 2016-11-30 11:33:46 --> Helper loaded: app_helper
INFO - 2016-11-30 11:33:46 --> Email Class Initialized
INFO - 2016-11-30 11:33:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 11:33:46 --> Final output sent to browser
DEBUG - 2016-11-30 11:33:46 --> Total execution time: 0.3156
INFO - 2016-11-30 11:33:46 --> Config Class Initialized
INFO - 2016-11-30 11:33:46 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:33:46 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:33:46 --> Utf8 Class Initialized
INFO - 2016-11-30 11:33:46 --> URI Class Initialized
INFO - 2016-11-30 11:33:46 --> Router Class Initialized
INFO - 2016-11-30 11:33:46 --> Output Class Initialized
INFO - 2016-11-30 11:33:47 --> Security Class Initialized
DEBUG - 2016-11-30 11:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:33:47 --> Input Class Initialized
INFO - 2016-11-30 11:33:47 --> Language Class Initialized
INFO - 2016-11-30 11:33:47 --> Loader Class Initialized
INFO - 2016-11-30 11:33:47 --> Helper loaded: url_helper
INFO - 2016-11-30 11:33:47 --> Helper loaded: form_helper
INFO - 2016-11-30 11:33:47 --> Database Driver Class Initialized
INFO - 2016-11-30 11:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:33:47 --> Controller Class Initialized
INFO - 2016-11-30 11:33:47 --> Model Class Initialized
INFO - 2016-11-30 11:33:47 --> Form Validation Class Initialized
INFO - 2016-11-30 11:33:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:33:47 --> Pagination Class Initialized
INFO - 2016-11-30 11:33:47 --> Helper loaded: app_helper
INFO - 2016-11-30 11:33:47 --> Email Class Initialized
INFO - 2016-11-30 11:33:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 11:33:47 --> Final output sent to browser
DEBUG - 2016-11-30 11:33:47 --> Total execution time: 0.3209
INFO - 2016-11-30 11:33:47 --> Config Class Initialized
INFO - 2016-11-30 11:33:47 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:33:47 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:33:47 --> Utf8 Class Initialized
INFO - 2016-11-30 11:33:47 --> URI Class Initialized
INFO - 2016-11-30 11:33:47 --> Router Class Initialized
INFO - 2016-11-30 11:33:47 --> Output Class Initialized
INFO - 2016-11-30 11:33:47 --> Security Class Initialized
DEBUG - 2016-11-30 11:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:33:47 --> Input Class Initialized
INFO - 2016-11-30 11:33:47 --> Language Class Initialized
INFO - 2016-11-30 11:33:47 --> Loader Class Initialized
INFO - 2016-11-30 11:33:47 --> Helper loaded: url_helper
INFO - 2016-11-30 11:33:47 --> Helper loaded: form_helper
INFO - 2016-11-30 11:33:47 --> Database Driver Class Initialized
INFO - 2016-11-30 11:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:33:47 --> Controller Class Initialized
INFO - 2016-11-30 11:33:47 --> Model Class Initialized
INFO - 2016-11-30 11:33:47 --> Form Validation Class Initialized
INFO - 2016-11-30 11:33:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:33:47 --> Pagination Class Initialized
INFO - 2016-11-30 11:33:47 --> Helper loaded: app_helper
INFO - 2016-11-30 11:33:47 --> Email Class Initialized
INFO - 2016-11-30 11:33:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 11:33:47 --> Config Class Initialized
INFO - 2016-11-30 11:33:47 --> Final output sent to browser
INFO - 2016-11-30 11:33:47 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:33:47 --> Total execution time: 0.3552
DEBUG - 2016-11-30 11:33:47 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:33:47 --> Utf8 Class Initialized
INFO - 2016-11-30 11:33:47 --> URI Class Initialized
INFO - 2016-11-30 11:33:47 --> Router Class Initialized
INFO - 2016-11-30 11:33:47 --> Output Class Initialized
INFO - 2016-11-30 11:33:47 --> Security Class Initialized
DEBUG - 2016-11-30 11:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:33:47 --> Input Class Initialized
INFO - 2016-11-30 11:33:47 --> Language Class Initialized
INFO - 2016-11-30 11:33:47 --> Loader Class Initialized
INFO - 2016-11-30 11:33:47 --> Helper loaded: url_helper
INFO - 2016-11-30 11:33:47 --> Helper loaded: form_helper
INFO - 2016-11-30 11:33:47 --> Database Driver Class Initialized
INFO - 2016-11-30 11:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:33:48 --> Controller Class Initialized
INFO - 2016-11-30 11:33:48 --> Model Class Initialized
INFO - 2016-11-30 11:33:48 --> Form Validation Class Initialized
INFO - 2016-11-30 11:33:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:33:48 --> Pagination Class Initialized
INFO - 2016-11-30 11:33:48 --> Helper loaded: app_helper
INFO - 2016-11-30 11:33:48 --> Email Class Initialized
INFO - 2016-11-30 11:33:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 11:33:48 --> Final output sent to browser
DEBUG - 2016-11-30 11:33:48 --> Total execution time: 0.3665
INFO - 2016-11-30 11:34:17 --> Config Class Initialized
INFO - 2016-11-30 11:34:17 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:34:17 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:34:17 --> Utf8 Class Initialized
INFO - 2016-11-30 11:34:17 --> URI Class Initialized
INFO - 2016-11-30 11:34:17 --> Router Class Initialized
INFO - 2016-11-30 11:34:17 --> Output Class Initialized
INFO - 2016-11-30 11:34:17 --> Security Class Initialized
DEBUG - 2016-11-30 11:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:34:17 --> Input Class Initialized
INFO - 2016-11-30 11:34:17 --> Language Class Initialized
INFO - 2016-11-30 11:34:17 --> Loader Class Initialized
INFO - 2016-11-30 11:34:17 --> Helper loaded: url_helper
INFO - 2016-11-30 11:34:17 --> Helper loaded: form_helper
INFO - 2016-11-30 11:34:17 --> Database Driver Class Initialized
INFO - 2016-11-30 11:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:34:17 --> Controller Class Initialized
INFO - 2016-11-30 11:34:17 --> Model Class Initialized
INFO - 2016-11-30 11:34:17 --> Form Validation Class Initialized
INFO - 2016-11-30 11:34:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:34:17 --> Pagination Class Initialized
INFO - 2016-11-30 11:34:17 --> Helper loaded: app_helper
INFO - 2016-11-30 11:34:17 --> Email Class Initialized
INFO - 2016-11-30 11:34:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 11:34:17 --> Final output sent to browser
DEBUG - 2016-11-30 11:34:17 --> Total execution time: 0.4527
INFO - 2016-11-30 11:34:17 --> Config Class Initialized
INFO - 2016-11-30 11:34:17 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:34:17 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:34:18 --> Utf8 Class Initialized
INFO - 2016-11-30 11:34:18 --> URI Class Initialized
INFO - 2016-11-30 11:34:18 --> Router Class Initialized
INFO - 2016-11-30 11:34:18 --> Output Class Initialized
INFO - 2016-11-30 11:34:18 --> Security Class Initialized
DEBUG - 2016-11-30 11:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:34:18 --> Input Class Initialized
INFO - 2016-11-30 11:34:18 --> Language Class Initialized
INFO - 2016-11-30 11:34:18 --> Loader Class Initialized
INFO - 2016-11-30 11:34:18 --> Helper loaded: url_helper
INFO - 2016-11-30 11:34:18 --> Helper loaded: form_helper
INFO - 2016-11-30 11:34:18 --> Database Driver Class Initialized
INFO - 2016-11-30 11:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:34:18 --> Controller Class Initialized
INFO - 2016-11-30 11:34:18 --> Config Class Initialized
INFO - 2016-11-30 11:34:18 --> Model Class Initialized
INFO - 2016-11-30 11:34:18 --> Hooks Class Initialized
INFO - 2016-11-30 11:34:18 --> Form Validation Class Initialized
DEBUG - 2016-11-30 11:34:18 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:34:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:34:18 --> Utf8 Class Initialized
INFO - 2016-11-30 11:34:18 --> Pagination Class Initialized
INFO - 2016-11-30 11:34:18 --> URI Class Initialized
INFO - 2016-11-30 11:34:18 --> Helper loaded: app_helper
INFO - 2016-11-30 11:34:18 --> Router Class Initialized
INFO - 2016-11-30 11:34:18 --> Email Class Initialized
INFO - 2016-11-30 11:34:18 --> Output Class Initialized
INFO - 2016-11-30 11:34:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 11:34:18 --> Security Class Initialized
INFO - 2016-11-30 11:34:18 --> Final output sent to browser
DEBUG - 2016-11-30 11:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-30 11:34:18 --> Total execution time: 0.5322
INFO - 2016-11-30 11:34:18 --> Input Class Initialized
INFO - 2016-11-30 11:34:18 --> Language Class Initialized
INFO - 2016-11-30 11:34:18 --> Loader Class Initialized
INFO - 2016-11-30 11:34:18 --> Helper loaded: url_helper
INFO - 2016-11-30 11:34:18 --> Helper loaded: form_helper
INFO - 2016-11-30 11:34:18 --> Database Driver Class Initialized
INFO - 2016-11-30 11:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:34:18 --> Controller Class Initialized
INFO - 2016-11-30 11:34:18 --> Model Class Initialized
INFO - 2016-11-30 11:34:18 --> Form Validation Class Initialized
INFO - 2016-11-30 11:34:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:34:18 --> Pagination Class Initialized
INFO - 2016-11-30 11:34:18 --> Helper loaded: app_helper
INFO - 2016-11-30 11:34:18 --> Email Class Initialized
INFO - 2016-11-30 11:34:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 11:34:18 --> Final output sent to browser
DEBUG - 2016-11-30 11:34:18 --> Total execution time: 0.4078
INFO - 2016-11-30 11:34:27 --> Config Class Initialized
INFO - 2016-11-30 11:34:27 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:34:27 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:34:27 --> Utf8 Class Initialized
INFO - 2016-11-30 11:34:27 --> URI Class Initialized
INFO - 2016-11-30 11:34:27 --> Router Class Initialized
INFO - 2016-11-30 11:34:27 --> Output Class Initialized
INFO - 2016-11-30 11:34:27 --> Security Class Initialized
DEBUG - 2016-11-30 11:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:34:27 --> Input Class Initialized
INFO - 2016-11-30 11:34:27 --> Language Class Initialized
INFO - 2016-11-30 11:34:27 --> Loader Class Initialized
INFO - 2016-11-30 11:34:27 --> Helper loaded: url_helper
INFO - 2016-11-30 11:34:27 --> Helper loaded: form_helper
INFO - 2016-11-30 11:34:27 --> Database Driver Class Initialized
INFO - 2016-11-30 11:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:34:28 --> Controller Class Initialized
INFO - 2016-11-30 11:34:28 --> Model Class Initialized
INFO - 2016-11-30 11:34:28 --> Form Validation Class Initialized
INFO - 2016-11-30 11:34:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:34:28 --> Pagination Class Initialized
INFO - 2016-11-30 11:34:28 --> Helper loaded: app_helper
INFO - 2016-11-30 11:34:28 --> Email Class Initialized
INFO - 2016-11-30 11:34:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 11:34:28 --> Final output sent to browser
DEBUG - 2016-11-30 11:34:28 --> Total execution time: 0.4759
INFO - 2016-11-30 11:35:10 --> Config Class Initialized
INFO - 2016-11-30 11:35:10 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:35:10 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:35:10 --> Utf8 Class Initialized
INFO - 2016-11-30 11:35:10 --> URI Class Initialized
INFO - 2016-11-30 11:35:10 --> Router Class Initialized
INFO - 2016-11-30 11:35:10 --> Output Class Initialized
INFO - 2016-11-30 11:35:10 --> Security Class Initialized
DEBUG - 2016-11-30 11:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:35:11 --> Input Class Initialized
INFO - 2016-11-30 11:35:11 --> Language Class Initialized
INFO - 2016-11-30 11:35:11 --> Loader Class Initialized
INFO - 2016-11-30 11:35:11 --> Helper loaded: url_helper
INFO - 2016-11-30 11:35:11 --> Helper loaded: form_helper
INFO - 2016-11-30 11:35:11 --> Database Driver Class Initialized
INFO - 2016-11-30 11:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:35:11 --> Controller Class Initialized
INFO - 2016-11-30 11:35:11 --> Model Class Initialized
INFO - 2016-11-30 11:35:11 --> Form Validation Class Initialized
INFO - 2016-11-30 11:35:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:35:11 --> Pagination Class Initialized
INFO - 2016-11-30 11:35:11 --> Helper loaded: app_helper
INFO - 2016-11-30 11:35:11 --> Email Class Initialized
INFO - 2016-11-30 11:35:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 11:35:11 --> Final output sent to browser
DEBUG - 2016-11-30 11:35:11 --> Total execution time: 0.3890
INFO - 2016-11-30 11:37:05 --> Config Class Initialized
INFO - 2016-11-30 11:37:05 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:37:05 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:37:05 --> Utf8 Class Initialized
INFO - 2016-11-30 11:37:05 --> URI Class Initialized
DEBUG - 2016-11-30 11:37:05 --> No URI present. Default controller set.
INFO - 2016-11-30 11:37:05 --> Router Class Initialized
INFO - 2016-11-30 11:37:05 --> Output Class Initialized
INFO - 2016-11-30 11:37:05 --> Security Class Initialized
DEBUG - 2016-11-30 11:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:37:05 --> Input Class Initialized
INFO - 2016-11-30 11:37:05 --> Language Class Initialized
INFO - 2016-11-30 11:37:05 --> Loader Class Initialized
INFO - 2016-11-30 11:37:05 --> Helper loaded: url_helper
INFO - 2016-11-30 11:37:05 --> Helper loaded: form_helper
INFO - 2016-11-30 11:37:05 --> Database Driver Class Initialized
INFO - 2016-11-30 11:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:37:05 --> Controller Class Initialized
INFO - 2016-11-30 11:37:05 --> Model Class Initialized
INFO - 2016-11-30 11:37:05 --> Model Class Initialized
INFO - 2016-11-30 11:37:05 --> Model Class Initialized
INFO - 2016-11-30 11:37:05 --> Model Class Initialized
INFO - 2016-11-30 11:37:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:37:05 --> Pagination Class Initialized
INFO - 2016-11-30 11:37:05 --> Helper loaded: app_helper
INFO - 2016-11-30 11:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:37:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:37:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 11:37:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 11:37:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 11:37:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 11:37:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:37:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:37:06 --> Final output sent to browser
DEBUG - 2016-11-30 11:37:06 --> Total execution time: 0.5395
INFO - 2016-11-30 11:42:51 --> Config Class Initialized
INFO - 2016-11-30 11:42:51 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:42:51 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:42:51 --> Utf8 Class Initialized
INFO - 2016-11-30 11:42:51 --> URI Class Initialized
DEBUG - 2016-11-30 11:42:51 --> No URI present. Default controller set.
INFO - 2016-11-30 11:42:51 --> Router Class Initialized
INFO - 2016-11-30 11:42:51 --> Output Class Initialized
INFO - 2016-11-30 11:42:51 --> Security Class Initialized
DEBUG - 2016-11-30 11:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:42:51 --> Input Class Initialized
INFO - 2016-11-30 11:42:51 --> Language Class Initialized
INFO - 2016-11-30 11:42:51 --> Loader Class Initialized
INFO - 2016-11-30 11:42:51 --> Helper loaded: url_helper
INFO - 2016-11-30 11:42:51 --> Helper loaded: form_helper
INFO - 2016-11-30 11:42:51 --> Database Driver Class Initialized
INFO - 2016-11-30 11:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:42:51 --> Controller Class Initialized
INFO - 2016-11-30 11:42:51 --> Model Class Initialized
INFO - 2016-11-30 11:42:51 --> Model Class Initialized
INFO - 2016-11-30 11:42:51 --> Model Class Initialized
INFO - 2016-11-30 11:42:51 --> Model Class Initialized
INFO - 2016-11-30 11:42:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:42:51 --> Pagination Class Initialized
INFO - 2016-11-30 11:42:51 --> Helper loaded: app_helper
INFO - 2016-11-30 11:42:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:42:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:42:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:42:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 11:42:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 11:42:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 11:42:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 11:42:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:42:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:42:51 --> Final output sent to browser
DEBUG - 2016-11-30 11:42:51 --> Total execution time: 0.5608
INFO - 2016-11-30 11:43:27 --> Config Class Initialized
INFO - 2016-11-30 11:43:27 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:43:27 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:43:27 --> Utf8 Class Initialized
INFO - 2016-11-30 11:43:27 --> URI Class Initialized
DEBUG - 2016-11-30 11:43:27 --> No URI present. Default controller set.
INFO - 2016-11-30 11:43:27 --> Router Class Initialized
INFO - 2016-11-30 11:43:27 --> Output Class Initialized
INFO - 2016-11-30 11:43:27 --> Security Class Initialized
DEBUG - 2016-11-30 11:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:43:27 --> Input Class Initialized
INFO - 2016-11-30 11:43:27 --> Language Class Initialized
INFO - 2016-11-30 11:43:27 --> Loader Class Initialized
INFO - 2016-11-30 11:43:27 --> Helper loaded: url_helper
INFO - 2016-11-30 11:43:27 --> Helper loaded: form_helper
INFO - 2016-11-30 11:43:27 --> Database Driver Class Initialized
INFO - 2016-11-30 11:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:43:27 --> Controller Class Initialized
INFO - 2016-11-30 11:43:27 --> Model Class Initialized
INFO - 2016-11-30 11:43:27 --> Model Class Initialized
INFO - 2016-11-30 11:43:27 --> Model Class Initialized
INFO - 2016-11-30 11:43:27 --> Model Class Initialized
INFO - 2016-11-30 11:43:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:43:27 --> Pagination Class Initialized
INFO - 2016-11-30 11:43:27 --> Helper loaded: app_helper
INFO - 2016-11-30 11:43:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:43:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:43:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:43:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 11:43:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 11:43:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 11:43:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 11:43:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:43:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:43:28 --> Final output sent to browser
DEBUG - 2016-11-30 11:43:28 --> Total execution time: 0.5643
INFO - 2016-11-30 11:43:53 --> Config Class Initialized
INFO - 2016-11-30 11:43:53 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:43:53 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:43:53 --> Utf8 Class Initialized
INFO - 2016-11-30 11:43:53 --> URI Class Initialized
DEBUG - 2016-11-30 11:43:53 --> No URI present. Default controller set.
INFO - 2016-11-30 11:43:53 --> Router Class Initialized
INFO - 2016-11-30 11:43:53 --> Output Class Initialized
INFO - 2016-11-30 11:43:53 --> Security Class Initialized
DEBUG - 2016-11-30 11:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:43:53 --> Input Class Initialized
INFO - 2016-11-30 11:43:53 --> Language Class Initialized
INFO - 2016-11-30 11:43:54 --> Loader Class Initialized
INFO - 2016-11-30 11:43:54 --> Helper loaded: url_helper
INFO - 2016-11-30 11:43:54 --> Helper loaded: form_helper
INFO - 2016-11-30 11:43:54 --> Database Driver Class Initialized
INFO - 2016-11-30 11:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:43:54 --> Controller Class Initialized
INFO - 2016-11-30 11:43:54 --> Model Class Initialized
INFO - 2016-11-30 11:43:54 --> Model Class Initialized
INFO - 2016-11-30 11:43:54 --> Model Class Initialized
INFO - 2016-11-30 11:43:54 --> Model Class Initialized
INFO - 2016-11-30 11:43:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:43:54 --> Pagination Class Initialized
INFO - 2016-11-30 11:43:54 --> Helper loaded: app_helper
INFO - 2016-11-30 11:43:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:43:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:43:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:43:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 11:43:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 11:43:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 11:43:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 11:43:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:43:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:43:54 --> Final output sent to browser
DEBUG - 2016-11-30 11:43:54 --> Total execution time: 0.5460
INFO - 2016-11-30 11:44:03 --> Config Class Initialized
INFO - 2016-11-30 11:44:03 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:44:03 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:44:03 --> Utf8 Class Initialized
INFO - 2016-11-30 11:44:03 --> URI Class Initialized
INFO - 2016-11-30 11:44:03 --> Router Class Initialized
INFO - 2016-11-30 11:44:03 --> Output Class Initialized
INFO - 2016-11-30 11:44:03 --> Security Class Initialized
DEBUG - 2016-11-30 11:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:44:03 --> Input Class Initialized
INFO - 2016-11-30 11:44:03 --> Language Class Initialized
INFO - 2016-11-30 11:44:03 --> Loader Class Initialized
INFO - 2016-11-30 11:44:04 --> Helper loaded: url_helper
INFO - 2016-11-30 11:44:04 --> Helper loaded: form_helper
INFO - 2016-11-30 11:44:04 --> Database Driver Class Initialized
INFO - 2016-11-30 11:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:44:04 --> Controller Class Initialized
INFO - 2016-11-30 11:44:04 --> Model Class Initialized
INFO - 2016-11-30 11:44:04 --> Form Validation Class Initialized
INFO - 2016-11-30 11:44:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:44:04 --> Pagination Class Initialized
INFO - 2016-11-30 11:44:04 --> Helper loaded: app_helper
INFO - 2016-11-30 11:44:04 --> Email Class Initialized
INFO - 2016-11-30 11:44:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 11:44:04 --> Final output sent to browser
DEBUG - 2016-11-30 11:44:04 --> Total execution time: 0.3603
INFO - 2016-11-30 11:44:17 --> Config Class Initialized
INFO - 2016-11-30 11:44:17 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:44:18 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:44:18 --> Utf8 Class Initialized
INFO - 2016-11-30 11:44:18 --> URI Class Initialized
INFO - 2016-11-30 11:44:18 --> Router Class Initialized
INFO - 2016-11-30 11:44:18 --> Output Class Initialized
INFO - 2016-11-30 11:44:18 --> Security Class Initialized
DEBUG - 2016-11-30 11:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:44:18 --> Input Class Initialized
INFO - 2016-11-30 11:44:18 --> Language Class Initialized
INFO - 2016-11-30 11:44:18 --> Loader Class Initialized
INFO - 2016-11-30 11:44:18 --> Helper loaded: url_helper
INFO - 2016-11-30 11:44:18 --> Helper loaded: form_helper
INFO - 2016-11-30 11:44:18 --> Database Driver Class Initialized
INFO - 2016-11-30 11:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:44:18 --> Controller Class Initialized
INFO - 2016-11-30 11:44:18 --> Model Class Initialized
INFO - 2016-11-30 11:44:18 --> Form Validation Class Initialized
INFO - 2016-11-30 11:44:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:44:18 --> Pagination Class Initialized
INFO - 2016-11-30 11:44:18 --> Helper loaded: app_helper
INFO - 2016-11-30 11:44:18 --> Email Class Initialized
INFO - 2016-11-30 11:44:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 11:44:18 --> Final output sent to browser
DEBUG - 2016-11-30 11:44:18 --> Total execution time: 0.4151
INFO - 2016-11-30 11:44:19 --> Config Class Initialized
INFO - 2016-11-30 11:44:19 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:44:19 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:44:19 --> Utf8 Class Initialized
INFO - 2016-11-30 11:44:19 --> URI Class Initialized
INFO - 2016-11-30 11:44:19 --> Router Class Initialized
INFO - 2016-11-30 11:44:19 --> Output Class Initialized
INFO - 2016-11-30 11:44:19 --> Security Class Initialized
DEBUG - 2016-11-30 11:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:44:19 --> Input Class Initialized
INFO - 2016-11-30 11:44:19 --> Language Class Initialized
INFO - 2016-11-30 11:44:19 --> Loader Class Initialized
INFO - 2016-11-30 11:44:19 --> Helper loaded: url_helper
INFO - 2016-11-30 11:44:19 --> Helper loaded: form_helper
INFO - 2016-11-30 11:44:19 --> Database Driver Class Initialized
INFO - 2016-11-30 11:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:44:19 --> Controller Class Initialized
INFO - 2016-11-30 11:44:19 --> Model Class Initialized
INFO - 2016-11-30 11:44:19 --> Form Validation Class Initialized
INFO - 2016-11-30 11:44:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:44:19 --> Pagination Class Initialized
INFO - 2016-11-30 11:44:19 --> Helper loaded: app_helper
INFO - 2016-11-30 11:44:19 --> Email Class Initialized
INFO - 2016-11-30 11:44:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 11:44:19 --> Final output sent to browser
DEBUG - 2016-11-30 11:44:19 --> Total execution time: 0.3346
INFO - 2016-11-30 11:44:22 --> Config Class Initialized
INFO - 2016-11-30 11:44:22 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:44:22 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:44:22 --> Utf8 Class Initialized
INFO - 2016-11-30 11:44:22 --> URI Class Initialized
INFO - 2016-11-30 11:44:22 --> Router Class Initialized
INFO - 2016-11-30 11:44:22 --> Output Class Initialized
INFO - 2016-11-30 11:44:22 --> Security Class Initialized
DEBUG - 2016-11-30 11:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:44:22 --> Input Class Initialized
INFO - 2016-11-30 11:44:22 --> Language Class Initialized
INFO - 2016-11-30 11:44:22 --> Loader Class Initialized
INFO - 2016-11-30 11:44:22 --> Helper loaded: url_helper
INFO - 2016-11-30 11:44:22 --> Helper loaded: form_helper
INFO - 2016-11-30 11:44:22 --> Database Driver Class Initialized
INFO - 2016-11-30 11:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:44:22 --> Controller Class Initialized
INFO - 2016-11-30 11:44:22 --> Model Class Initialized
INFO - 2016-11-30 11:44:22 --> Form Validation Class Initialized
INFO - 2016-11-30 11:44:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:44:22 --> Pagination Class Initialized
INFO - 2016-11-30 11:44:22 --> Helper loaded: app_helper
INFO - 2016-11-30 11:44:22 --> Email Class Initialized
INFO - 2016-11-30 11:44:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 10:44:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 10:44:22 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 10:44:23 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-30 10:44:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
ERROR - 2016-11-30 10:44:24 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-30 10:44:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 10:44:24 --> Final output sent to browser
DEBUG - 2016-11-30 10:44:24 --> Total execution time: 2.4678
INFO - 2016-11-30 11:44:31 --> Config Class Initialized
INFO - 2016-11-30 11:44:31 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:44:31 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:44:31 --> Utf8 Class Initialized
INFO - 2016-11-30 11:44:31 --> URI Class Initialized
DEBUG - 2016-11-30 11:44:31 --> No URI present. Default controller set.
INFO - 2016-11-30 11:44:31 --> Router Class Initialized
INFO - 2016-11-30 11:44:31 --> Output Class Initialized
INFO - 2016-11-30 11:44:31 --> Security Class Initialized
DEBUG - 2016-11-30 11:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:44:31 --> Input Class Initialized
INFO - 2016-11-30 11:44:31 --> Language Class Initialized
INFO - 2016-11-30 11:44:31 --> Loader Class Initialized
INFO - 2016-11-30 11:44:31 --> Helper loaded: url_helper
INFO - 2016-11-30 11:44:31 --> Helper loaded: form_helper
INFO - 2016-11-30 11:44:31 --> Database Driver Class Initialized
INFO - 2016-11-30 11:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:44:31 --> Controller Class Initialized
INFO - 2016-11-30 11:44:31 --> Model Class Initialized
INFO - 2016-11-30 11:44:31 --> Model Class Initialized
INFO - 2016-11-30 11:44:32 --> Model Class Initialized
INFO - 2016-11-30 11:44:32 --> Model Class Initialized
INFO - 2016-11-30 11:44:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:44:32 --> Pagination Class Initialized
INFO - 2016-11-30 11:44:32 --> Helper loaded: app_helper
INFO - 2016-11-30 11:44:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:44:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:44:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:44:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 11:44:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 11:44:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 11:44:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 11:44:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:44:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:44:32 --> Final output sent to browser
DEBUG - 2016-11-30 11:44:32 --> Total execution time: 0.5436
INFO - 2016-11-30 11:44:42 --> Config Class Initialized
INFO - 2016-11-30 11:44:42 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:44:42 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:44:42 --> Utf8 Class Initialized
INFO - 2016-11-30 11:44:42 --> URI Class Initialized
INFO - 2016-11-30 11:44:42 --> Router Class Initialized
INFO - 2016-11-30 11:44:42 --> Output Class Initialized
INFO - 2016-11-30 11:44:42 --> Security Class Initialized
DEBUG - 2016-11-30 11:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:44:43 --> Input Class Initialized
INFO - 2016-11-30 11:44:43 --> Language Class Initialized
INFO - 2016-11-30 11:44:43 --> Loader Class Initialized
INFO - 2016-11-30 11:44:43 --> Helper loaded: url_helper
INFO - 2016-11-30 11:44:43 --> Helper loaded: form_helper
INFO - 2016-11-30 11:44:43 --> Database Driver Class Initialized
INFO - 2016-11-30 11:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:44:43 --> Controller Class Initialized
INFO - 2016-11-30 11:44:43 --> Model Class Initialized
INFO - 2016-11-30 11:44:43 --> Model Class Initialized
INFO - 2016-11-30 11:44:43 --> Model Class Initialized
INFO - 2016-11-30 11:44:43 --> Model Class Initialized
INFO - 2016-11-30 11:44:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:44:43 --> Pagination Class Initialized
INFO - 2016-11-30 11:44:43 --> Helper loaded: app_helper
DEBUG - 2016-11-30 11:44:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-30 11:44:43 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-30 11:44:43 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-30 11:44:43 --> Config Class Initialized
INFO - 2016-11-30 11:44:43 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:44:43 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:44:43 --> Utf8 Class Initialized
INFO - 2016-11-30 11:44:43 --> URI Class Initialized
DEBUG - 2016-11-30 11:44:43 --> No URI present. Default controller set.
INFO - 2016-11-30 11:44:43 --> Router Class Initialized
INFO - 2016-11-30 11:44:43 --> Output Class Initialized
INFO - 2016-11-30 11:44:43 --> Security Class Initialized
DEBUG - 2016-11-30 11:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:44:43 --> Input Class Initialized
INFO - 2016-11-30 11:44:43 --> Language Class Initialized
INFO - 2016-11-30 11:44:43 --> Loader Class Initialized
INFO - 2016-11-30 11:44:43 --> Helper loaded: url_helper
INFO - 2016-11-30 11:44:43 --> Helper loaded: form_helper
INFO - 2016-11-30 11:44:43 --> Database Driver Class Initialized
INFO - 2016-11-30 11:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:44:43 --> Controller Class Initialized
INFO - 2016-11-30 11:44:43 --> Model Class Initialized
INFO - 2016-11-30 11:44:43 --> Model Class Initialized
INFO - 2016-11-30 11:44:43 --> Model Class Initialized
INFO - 2016-11-30 11:44:43 --> Model Class Initialized
INFO - 2016-11-30 11:44:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:44:43 --> Pagination Class Initialized
INFO - 2016-11-30 11:44:43 --> Helper loaded: app_helper
INFO - 2016-11-30 11:44:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:44:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-30 11:44:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:44:43 --> Final output sent to browser
DEBUG - 2016-11-30 11:44:43 --> Total execution time: 0.4116
INFO - 2016-11-30 11:44:58 --> Config Class Initialized
INFO - 2016-11-30 11:44:58 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:44:58 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:44:58 --> Utf8 Class Initialized
INFO - 2016-11-30 11:44:58 --> URI Class Initialized
INFO - 2016-11-30 11:44:59 --> Router Class Initialized
INFO - 2016-11-30 11:44:59 --> Output Class Initialized
INFO - 2016-11-30 11:44:59 --> Security Class Initialized
DEBUG - 2016-11-30 11:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:44:59 --> Input Class Initialized
INFO - 2016-11-30 11:44:59 --> Language Class Initialized
INFO - 2016-11-30 11:44:59 --> Loader Class Initialized
INFO - 2016-11-30 11:44:59 --> Helper loaded: url_helper
INFO - 2016-11-30 11:44:59 --> Helper loaded: form_helper
INFO - 2016-11-30 11:44:59 --> Database Driver Class Initialized
INFO - 2016-11-30 11:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:44:59 --> Controller Class Initialized
INFO - 2016-11-30 11:44:59 --> Model Class Initialized
INFO - 2016-11-30 11:44:59 --> Model Class Initialized
INFO - 2016-11-30 11:44:59 --> Model Class Initialized
INFO - 2016-11-30 11:44:59 --> Model Class Initialized
INFO - 2016-11-30 11:44:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:44:59 --> Pagination Class Initialized
INFO - 2016-11-30 11:44:59 --> Helper loaded: app_helper
DEBUG - 2016-11-30 11:44:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 11:44:59 --> Model Class Initialized
INFO - 2016-11-30 11:44:59 --> Final output sent to browser
DEBUG - 2016-11-30 11:44:59 --> Total execution time: 0.4040
INFO - 2016-11-30 11:44:59 --> Config Class Initialized
INFO - 2016-11-30 11:44:59 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:44:59 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:44:59 --> Utf8 Class Initialized
INFO - 2016-11-30 11:44:59 --> URI Class Initialized
DEBUG - 2016-11-30 11:44:59 --> No URI present. Default controller set.
INFO - 2016-11-30 11:44:59 --> Router Class Initialized
INFO - 2016-11-30 11:44:59 --> Output Class Initialized
INFO - 2016-11-30 11:44:59 --> Security Class Initialized
DEBUG - 2016-11-30 11:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:44:59 --> Input Class Initialized
INFO - 2016-11-30 11:44:59 --> Language Class Initialized
INFO - 2016-11-30 11:44:59 --> Loader Class Initialized
INFO - 2016-11-30 11:44:59 --> Helper loaded: url_helper
INFO - 2016-11-30 11:44:59 --> Helper loaded: form_helper
INFO - 2016-11-30 11:44:59 --> Database Driver Class Initialized
INFO - 2016-11-30 11:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:44:59 --> Controller Class Initialized
INFO - 2016-11-30 11:44:59 --> Model Class Initialized
INFO - 2016-11-30 11:44:59 --> Model Class Initialized
INFO - 2016-11-30 11:44:59 --> Model Class Initialized
INFO - 2016-11-30 11:44:59 --> Model Class Initialized
INFO - 2016-11-30 11:44:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:44:59 --> Pagination Class Initialized
INFO - 2016-11-30 11:44:59 --> Helper loaded: app_helper
INFO - 2016-11-30 11:45:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:45:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:45:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:45:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-30 11:45:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 11:45:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-30 11:45:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:45:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:45:00 --> Final output sent to browser
DEBUG - 2016-11-30 11:45:00 --> Total execution time: 0.7502
INFO - 2016-11-30 11:45:14 --> Config Class Initialized
INFO - 2016-11-30 11:45:14 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:45:14 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:45:14 --> Utf8 Class Initialized
INFO - 2016-11-30 11:45:14 --> URI Class Initialized
DEBUG - 2016-11-30 11:45:14 --> No URI present. Default controller set.
INFO - 2016-11-30 11:45:14 --> Router Class Initialized
INFO - 2016-11-30 11:45:14 --> Output Class Initialized
INFO - 2016-11-30 11:45:14 --> Security Class Initialized
DEBUG - 2016-11-30 11:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:45:14 --> Input Class Initialized
INFO - 2016-11-30 11:45:14 --> Language Class Initialized
INFO - 2016-11-30 11:45:14 --> Loader Class Initialized
INFO - 2016-11-30 11:45:14 --> Helper loaded: url_helper
INFO - 2016-11-30 11:45:14 --> Helper loaded: form_helper
INFO - 2016-11-30 11:45:14 --> Database Driver Class Initialized
INFO - 2016-11-30 11:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:45:14 --> Controller Class Initialized
INFO - 2016-11-30 11:45:14 --> Model Class Initialized
INFO - 2016-11-30 11:45:14 --> Model Class Initialized
INFO - 2016-11-30 11:45:14 --> Model Class Initialized
INFO - 2016-11-30 11:45:14 --> Model Class Initialized
INFO - 2016-11-30 11:45:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:45:14 --> Pagination Class Initialized
INFO - 2016-11-30 11:45:14 --> Helper loaded: app_helper
INFO - 2016-11-30 11:45:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:45:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:45:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:45:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-30 11:45:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 11:45:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-30 11:45:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:45:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:45:15 --> Final output sent to browser
DEBUG - 2016-11-30 11:45:15 --> Total execution time: 0.5417
INFO - 2016-11-30 11:45:20 --> Config Class Initialized
INFO - 2016-11-30 11:45:20 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:45:20 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:45:20 --> Utf8 Class Initialized
INFO - 2016-11-30 11:45:20 --> URI Class Initialized
INFO - 2016-11-30 11:45:20 --> Router Class Initialized
INFO - 2016-11-30 11:45:20 --> Output Class Initialized
INFO - 2016-11-30 11:45:20 --> Security Class Initialized
DEBUG - 2016-11-30 11:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:45:20 --> Input Class Initialized
INFO - 2016-11-30 11:45:20 --> Language Class Initialized
INFO - 2016-11-30 11:45:20 --> Loader Class Initialized
INFO - 2016-11-30 11:45:20 --> Helper loaded: url_helper
INFO - 2016-11-30 11:45:20 --> Helper loaded: form_helper
INFO - 2016-11-30 11:45:20 --> Database Driver Class Initialized
INFO - 2016-11-30 11:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:45:20 --> Controller Class Initialized
INFO - 2016-11-30 11:45:20 --> Model Class Initialized
INFO - 2016-11-30 11:45:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:45:20 --> Pagination Class Initialized
INFO - 2016-11-30 11:45:20 --> Helper loaded: app_helper
INFO - 2016-11-30 11:45:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 11:45:20 --> Final output sent to browser
DEBUG - 2016-11-30 11:45:20 --> Total execution time: 0.3414
INFO - 2016-11-30 11:45:23 --> Config Class Initialized
INFO - 2016-11-30 11:45:23 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:45:23 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:45:23 --> Utf8 Class Initialized
INFO - 2016-11-30 11:45:23 --> URI Class Initialized
INFO - 2016-11-30 11:45:23 --> Router Class Initialized
INFO - 2016-11-30 11:45:23 --> Output Class Initialized
INFO - 2016-11-30 11:45:23 --> Security Class Initialized
DEBUG - 2016-11-30 11:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:45:23 --> Input Class Initialized
INFO - 2016-11-30 11:45:23 --> Language Class Initialized
INFO - 2016-11-30 11:45:23 --> Loader Class Initialized
INFO - 2016-11-30 11:45:23 --> Helper loaded: url_helper
INFO - 2016-11-30 11:45:23 --> Helper loaded: form_helper
INFO - 2016-11-30 11:45:23 --> Database Driver Class Initialized
INFO - 2016-11-30 11:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:45:23 --> Controller Class Initialized
INFO - 2016-11-30 11:45:23 --> Model Class Initialized
INFO - 2016-11-30 11:45:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:45:23 --> Pagination Class Initialized
INFO - 2016-11-30 11:45:23 --> Helper loaded: app_helper
INFO - 2016-11-30 11:45:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-30 11:45:23 --> Final output sent to browser
DEBUG - 2016-11-30 11:45:23 --> Total execution time: 0.3201
INFO - 2016-11-30 11:45:33 --> Config Class Initialized
INFO - 2016-11-30 11:45:33 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:45:33 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:45:33 --> Utf8 Class Initialized
INFO - 2016-11-30 11:45:33 --> URI Class Initialized
INFO - 2016-11-30 11:45:33 --> Router Class Initialized
INFO - 2016-11-30 11:45:33 --> Output Class Initialized
INFO - 2016-11-30 11:45:33 --> Security Class Initialized
DEBUG - 2016-11-30 11:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:45:33 --> Input Class Initialized
INFO - 2016-11-30 11:45:33 --> Language Class Initialized
INFO - 2016-11-30 11:45:33 --> Loader Class Initialized
INFO - 2016-11-30 11:45:33 --> Helper loaded: url_helper
INFO - 2016-11-30 11:45:33 --> Helper loaded: form_helper
INFO - 2016-11-30 11:45:33 --> Database Driver Class Initialized
INFO - 2016-11-30 11:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:45:33 --> Controller Class Initialized
INFO - 2016-11-30 11:45:33 --> Model Class Initialized
INFO - 2016-11-30 11:45:33 --> Model Class Initialized
INFO - 2016-11-30 11:45:33 --> Model Class Initialized
INFO - 2016-11-30 11:45:33 --> Model Class Initialized
INFO - 2016-11-30 11:45:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:45:33 --> Pagination Class Initialized
INFO - 2016-11-30 11:45:33 --> Helper loaded: app_helper
DEBUG - 2016-11-30 11:45:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-30 11:45:33 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-30 11:45:33 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-30 11:45:33 --> Config Class Initialized
INFO - 2016-11-30 11:45:33 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:45:33 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:45:33 --> Utf8 Class Initialized
INFO - 2016-11-30 11:45:33 --> URI Class Initialized
DEBUG - 2016-11-30 11:45:33 --> No URI present. Default controller set.
INFO - 2016-11-30 11:45:33 --> Router Class Initialized
INFO - 2016-11-30 11:45:33 --> Output Class Initialized
INFO - 2016-11-30 11:45:33 --> Security Class Initialized
DEBUG - 2016-11-30 11:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:45:33 --> Input Class Initialized
INFO - 2016-11-30 11:45:33 --> Language Class Initialized
INFO - 2016-11-30 11:45:34 --> Loader Class Initialized
INFO - 2016-11-30 11:45:34 --> Helper loaded: url_helper
INFO - 2016-11-30 11:45:34 --> Helper loaded: form_helper
INFO - 2016-11-30 11:45:34 --> Database Driver Class Initialized
INFO - 2016-11-30 11:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:45:34 --> Controller Class Initialized
INFO - 2016-11-30 11:45:34 --> Model Class Initialized
INFO - 2016-11-30 11:45:34 --> Model Class Initialized
INFO - 2016-11-30 11:45:34 --> Model Class Initialized
INFO - 2016-11-30 11:45:34 --> Model Class Initialized
INFO - 2016-11-30 11:45:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:45:34 --> Pagination Class Initialized
INFO - 2016-11-30 11:45:34 --> Helper loaded: app_helper
INFO - 2016-11-30 11:45:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:45:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-30 11:45:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:45:34 --> Final output sent to browser
DEBUG - 2016-11-30 11:45:34 --> Total execution time: 0.4221
INFO - 2016-11-30 11:45:35 --> Config Class Initialized
INFO - 2016-11-30 11:45:35 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:45:35 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:45:35 --> Utf8 Class Initialized
INFO - 2016-11-30 11:45:36 --> URI Class Initialized
DEBUG - 2016-11-30 11:45:36 --> No URI present. Default controller set.
INFO - 2016-11-30 11:45:36 --> Router Class Initialized
INFO - 2016-11-30 11:45:36 --> Output Class Initialized
INFO - 2016-11-30 11:45:36 --> Security Class Initialized
DEBUG - 2016-11-30 11:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:45:36 --> Input Class Initialized
INFO - 2016-11-30 11:45:36 --> Language Class Initialized
INFO - 2016-11-30 11:45:36 --> Loader Class Initialized
INFO - 2016-11-30 11:45:36 --> Helper loaded: url_helper
INFO - 2016-11-30 11:45:36 --> Helper loaded: form_helper
INFO - 2016-11-30 11:45:36 --> Database Driver Class Initialized
INFO - 2016-11-30 11:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:45:36 --> Controller Class Initialized
INFO - 2016-11-30 11:45:36 --> Model Class Initialized
INFO - 2016-11-30 11:45:36 --> Model Class Initialized
INFO - 2016-11-30 11:45:36 --> Model Class Initialized
INFO - 2016-11-30 11:45:36 --> Model Class Initialized
INFO - 2016-11-30 11:45:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:45:36 --> Pagination Class Initialized
INFO - 2016-11-30 11:45:36 --> Helper loaded: app_helper
INFO - 2016-11-30 11:45:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:45:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-30 11:45:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:45:36 --> Final output sent to browser
DEBUG - 2016-11-30 11:45:36 --> Total execution time: 0.4931
INFO - 2016-11-30 11:45:58 --> Config Class Initialized
INFO - 2016-11-30 11:45:58 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:45:58 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:45:58 --> Utf8 Class Initialized
INFO - 2016-11-30 11:45:58 --> URI Class Initialized
DEBUG - 2016-11-30 11:45:58 --> No URI present. Default controller set.
INFO - 2016-11-30 11:45:58 --> Router Class Initialized
INFO - 2016-11-30 11:45:58 --> Output Class Initialized
INFO - 2016-11-30 11:45:58 --> Security Class Initialized
DEBUG - 2016-11-30 11:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:45:58 --> Input Class Initialized
INFO - 2016-11-30 11:45:58 --> Language Class Initialized
INFO - 2016-11-30 11:45:58 --> Loader Class Initialized
INFO - 2016-11-30 11:45:58 --> Helper loaded: url_helper
INFO - 2016-11-30 11:45:58 --> Helper loaded: form_helper
INFO - 2016-11-30 11:45:58 --> Database Driver Class Initialized
INFO - 2016-11-30 11:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:45:58 --> Controller Class Initialized
INFO - 2016-11-30 11:45:58 --> Model Class Initialized
INFO - 2016-11-30 11:45:58 --> Model Class Initialized
INFO - 2016-11-30 11:45:58 --> Model Class Initialized
INFO - 2016-11-30 11:45:58 --> Model Class Initialized
INFO - 2016-11-30 11:45:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:45:58 --> Pagination Class Initialized
INFO - 2016-11-30 11:45:58 --> Helper loaded: app_helper
INFO - 2016-11-30 11:45:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:45:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-30 11:45:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:45:59 --> Final output sent to browser
DEBUG - 2016-11-30 11:45:59 --> Total execution time: 0.4604
INFO - 2016-11-30 11:46:08 --> Config Class Initialized
INFO - 2016-11-30 11:46:08 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:46:08 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:46:08 --> Utf8 Class Initialized
INFO - 2016-11-30 11:46:08 --> URI Class Initialized
INFO - 2016-11-30 11:46:08 --> Router Class Initialized
INFO - 2016-11-30 11:46:08 --> Output Class Initialized
INFO - 2016-11-30 11:46:08 --> Security Class Initialized
DEBUG - 2016-11-30 11:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:46:08 --> Input Class Initialized
INFO - 2016-11-30 11:46:08 --> Language Class Initialized
INFO - 2016-11-30 11:46:08 --> Loader Class Initialized
INFO - 2016-11-30 11:46:08 --> Helper loaded: url_helper
INFO - 2016-11-30 11:46:08 --> Helper loaded: form_helper
INFO - 2016-11-30 11:46:08 --> Database Driver Class Initialized
INFO - 2016-11-30 11:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:46:08 --> Controller Class Initialized
INFO - 2016-11-30 11:46:08 --> Model Class Initialized
INFO - 2016-11-30 11:46:08 --> Model Class Initialized
INFO - 2016-11-30 11:46:08 --> Model Class Initialized
INFO - 2016-11-30 11:46:08 --> Model Class Initialized
INFO - 2016-11-30 11:46:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:46:08 --> Pagination Class Initialized
INFO - 2016-11-30 11:46:08 --> Helper loaded: app_helper
DEBUG - 2016-11-30 11:46:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 11:46:08 --> Model Class Initialized
INFO - 2016-11-30 11:46:08 --> Final output sent to browser
DEBUG - 2016-11-30 11:46:08 --> Total execution time: 0.3930
INFO - 2016-11-30 11:46:08 --> Config Class Initialized
INFO - 2016-11-30 11:46:08 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:46:08 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:46:08 --> Utf8 Class Initialized
INFO - 2016-11-30 11:46:08 --> URI Class Initialized
DEBUG - 2016-11-30 11:46:08 --> No URI present. Default controller set.
INFO - 2016-11-30 11:46:08 --> Router Class Initialized
INFO - 2016-11-30 11:46:08 --> Output Class Initialized
INFO - 2016-11-30 11:46:08 --> Security Class Initialized
DEBUG - 2016-11-30 11:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:46:08 --> Input Class Initialized
INFO - 2016-11-30 11:46:08 --> Language Class Initialized
INFO - 2016-11-30 11:46:08 --> Loader Class Initialized
INFO - 2016-11-30 11:46:08 --> Helper loaded: url_helper
INFO - 2016-11-30 11:46:08 --> Helper loaded: form_helper
INFO - 2016-11-30 11:46:09 --> Database Driver Class Initialized
INFO - 2016-11-30 11:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:46:09 --> Controller Class Initialized
INFO - 2016-11-30 11:46:09 --> Model Class Initialized
INFO - 2016-11-30 11:46:09 --> Model Class Initialized
INFO - 2016-11-30 11:46:09 --> Model Class Initialized
INFO - 2016-11-30 11:46:09 --> Model Class Initialized
INFO - 2016-11-30 11:46:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:46:09 --> Pagination Class Initialized
INFO - 2016-11-30 11:46:09 --> Helper loaded: app_helper
INFO - 2016-11-30 11:46:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:46:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:46:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:46:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 11:46:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 11:46:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 11:46:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 11:46:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:46:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:46:09 --> Final output sent to browser
DEBUG - 2016-11-30 11:46:09 --> Total execution time: 0.5262
INFO - 2016-11-30 11:46:39 --> Config Class Initialized
INFO - 2016-11-30 11:46:39 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:46:39 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:46:39 --> Utf8 Class Initialized
INFO - 2016-11-30 11:46:39 --> URI Class Initialized
INFO - 2016-11-30 11:46:39 --> Router Class Initialized
INFO - 2016-11-30 11:46:39 --> Output Class Initialized
INFO - 2016-11-30 11:46:39 --> Security Class Initialized
DEBUG - 2016-11-30 11:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:46:39 --> Input Class Initialized
INFO - 2016-11-30 11:46:39 --> Language Class Initialized
INFO - 2016-11-30 11:46:39 --> Loader Class Initialized
INFO - 2016-11-30 11:46:40 --> Helper loaded: url_helper
INFO - 2016-11-30 11:46:40 --> Helper loaded: form_helper
INFO - 2016-11-30 11:46:40 --> Database Driver Class Initialized
INFO - 2016-11-30 11:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:46:40 --> Controller Class Initialized
INFO - 2016-11-30 11:46:40 --> Model Class Initialized
INFO - 2016-11-30 11:46:40 --> Form Validation Class Initialized
INFO - 2016-11-30 11:46:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:46:40 --> Pagination Class Initialized
INFO - 2016-11-30 11:46:40 --> Helper loaded: app_helper
INFO - 2016-11-30 11:46:40 --> Email Class Initialized
INFO - 2016-11-30 11:46:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 11:46:40 --> Final output sent to browser
DEBUG - 2016-11-30 11:46:40 --> Total execution time: 0.4695
INFO - 2016-11-30 11:46:44 --> Config Class Initialized
INFO - 2016-11-30 11:46:44 --> Hooks Class Initialized
DEBUG - 2016-11-30 11:46:44 --> UTF-8 Support Enabled
INFO - 2016-11-30 11:46:44 --> Utf8 Class Initialized
INFO - 2016-11-30 11:46:45 --> URI Class Initialized
DEBUG - 2016-11-30 11:46:45 --> No URI present. Default controller set.
INFO - 2016-11-30 11:46:45 --> Router Class Initialized
INFO - 2016-11-30 11:46:45 --> Output Class Initialized
INFO - 2016-11-30 11:46:45 --> Security Class Initialized
DEBUG - 2016-11-30 11:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 11:46:45 --> Input Class Initialized
INFO - 2016-11-30 11:46:45 --> Language Class Initialized
INFO - 2016-11-30 11:46:45 --> Loader Class Initialized
INFO - 2016-11-30 11:46:45 --> Helper loaded: url_helper
INFO - 2016-11-30 11:46:45 --> Helper loaded: form_helper
INFO - 2016-11-30 11:46:45 --> Database Driver Class Initialized
INFO - 2016-11-30 11:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 11:46:45 --> Controller Class Initialized
INFO - 2016-11-30 11:46:45 --> Model Class Initialized
INFO - 2016-11-30 11:46:45 --> Model Class Initialized
INFO - 2016-11-30 11:46:45 --> Model Class Initialized
INFO - 2016-11-30 11:46:45 --> Model Class Initialized
INFO - 2016-11-30 11:46:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 11:46:45 --> Pagination Class Initialized
INFO - 2016-11-30 11:46:45 --> Helper loaded: app_helper
INFO - 2016-11-30 11:46:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 11:46:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 11:46:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 11:46:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 11:46:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 11:46:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 11:46:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 11:46:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 11:46:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 11:46:45 --> Final output sent to browser
DEBUG - 2016-11-30 11:46:45 --> Total execution time: 0.5481
INFO - 2016-11-30 12:18:30 --> Config Class Initialized
INFO - 2016-11-30 12:18:30 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:18:30 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:18:30 --> Utf8 Class Initialized
INFO - 2016-11-30 12:18:30 --> URI Class Initialized
DEBUG - 2016-11-30 12:18:30 --> No URI present. Default controller set.
INFO - 2016-11-30 12:18:30 --> Router Class Initialized
INFO - 2016-11-30 12:18:30 --> Output Class Initialized
INFO - 2016-11-30 12:18:30 --> Security Class Initialized
DEBUG - 2016-11-30 12:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:18:30 --> Input Class Initialized
INFO - 2016-11-30 12:18:30 --> Language Class Initialized
INFO - 2016-11-30 12:18:30 --> Loader Class Initialized
INFO - 2016-11-30 12:18:30 --> Helper loaded: url_helper
INFO - 2016-11-30 12:18:30 --> Helper loaded: form_helper
INFO - 2016-11-30 12:18:30 --> Database Driver Class Initialized
INFO - 2016-11-30 12:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:18:30 --> Controller Class Initialized
INFO - 2016-11-30 12:18:31 --> Model Class Initialized
INFO - 2016-11-30 12:18:31 --> Model Class Initialized
INFO - 2016-11-30 12:18:31 --> Model Class Initialized
INFO - 2016-11-30 12:18:31 --> Model Class Initialized
INFO - 2016-11-30 12:18:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:18:31 --> Pagination Class Initialized
INFO - 2016-11-30 12:18:31 --> Helper loaded: app_helper
INFO - 2016-11-30 12:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 12:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 12:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 12:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 12:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 12:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 12:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 12:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 12:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 12:18:31 --> Final output sent to browser
DEBUG - 2016-11-30 12:18:31 --> Total execution time: 0.5793
INFO - 2016-11-30 12:18:35 --> Config Class Initialized
INFO - 2016-11-30 12:18:35 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:18:35 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:18:35 --> Utf8 Class Initialized
INFO - 2016-11-30 12:18:35 --> URI Class Initialized
INFO - 2016-11-30 12:18:35 --> Router Class Initialized
INFO - 2016-11-30 12:18:35 --> Output Class Initialized
INFO - 2016-11-30 12:18:35 --> Security Class Initialized
DEBUG - 2016-11-30 12:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:18:35 --> Input Class Initialized
INFO - 2016-11-30 12:18:35 --> Language Class Initialized
INFO - 2016-11-30 12:18:35 --> Loader Class Initialized
INFO - 2016-11-30 12:18:35 --> Helper loaded: url_helper
INFO - 2016-11-30 12:18:35 --> Helper loaded: form_helper
INFO - 2016-11-30 12:18:35 --> Database Driver Class Initialized
INFO - 2016-11-30 12:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:18:35 --> Controller Class Initialized
INFO - 2016-11-30 12:18:35 --> Model Class Initialized
INFO - 2016-11-30 12:18:35 --> Form Validation Class Initialized
INFO - 2016-11-30 12:18:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:18:36 --> Pagination Class Initialized
INFO - 2016-11-30 12:18:36 --> Helper loaded: app_helper
INFO - 2016-11-30 12:18:36 --> Email Class Initialized
INFO - 2016-11-30 12:18:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:18:36 --> Final output sent to browser
DEBUG - 2016-11-30 12:18:36 --> Total execution time: 0.5771
INFO - 2016-11-30 12:18:47 --> Config Class Initialized
INFO - 2016-11-30 12:18:47 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:18:47 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:18:47 --> Utf8 Class Initialized
INFO - 2016-11-30 12:18:47 --> URI Class Initialized
INFO - 2016-11-30 12:18:47 --> Router Class Initialized
INFO - 2016-11-30 12:18:47 --> Output Class Initialized
INFO - 2016-11-30 12:18:47 --> Security Class Initialized
DEBUG - 2016-11-30 12:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:18:47 --> Input Class Initialized
INFO - 2016-11-30 12:18:47 --> Language Class Initialized
INFO - 2016-11-30 12:18:47 --> Loader Class Initialized
INFO - 2016-11-30 12:18:47 --> Helper loaded: url_helper
INFO - 2016-11-30 12:18:47 --> Helper loaded: form_helper
INFO - 2016-11-30 12:18:47 --> Database Driver Class Initialized
INFO - 2016-11-30 12:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:18:47 --> Controller Class Initialized
INFO - 2016-11-30 12:18:47 --> Model Class Initialized
INFO - 2016-11-30 12:18:47 --> Form Validation Class Initialized
INFO - 2016-11-30 12:18:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:18:47 --> Pagination Class Initialized
INFO - 2016-11-30 12:18:47 --> Helper loaded: app_helper
INFO - 2016-11-30 12:18:47 --> Email Class Initialized
INFO - 2016-11-30 12:18:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:18:47 --> Final output sent to browser
DEBUG - 2016-11-30 12:18:47 --> Total execution time: 0.3823
INFO - 2016-11-30 12:18:54 --> Config Class Initialized
INFO - 2016-11-30 12:18:54 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:18:54 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:18:54 --> Utf8 Class Initialized
INFO - 2016-11-30 12:18:54 --> URI Class Initialized
INFO - 2016-11-30 12:18:54 --> Router Class Initialized
INFO - 2016-11-30 12:18:54 --> Output Class Initialized
INFO - 2016-11-30 12:18:54 --> Security Class Initialized
DEBUG - 2016-11-30 12:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:18:54 --> Input Class Initialized
INFO - 2016-11-30 12:18:54 --> Language Class Initialized
INFO - 2016-11-30 12:18:54 --> Loader Class Initialized
INFO - 2016-11-30 12:18:54 --> Helper loaded: url_helper
INFO - 2016-11-30 12:18:54 --> Helper loaded: form_helper
INFO - 2016-11-30 12:18:54 --> Database Driver Class Initialized
INFO - 2016-11-30 12:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:18:54 --> Controller Class Initialized
INFO - 2016-11-30 12:18:54 --> Model Class Initialized
INFO - 2016-11-30 12:18:54 --> Form Validation Class Initialized
INFO - 2016-11-30 12:18:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:18:54 --> Pagination Class Initialized
INFO - 2016-11-30 12:18:54 --> Helper loaded: app_helper
INFO - 2016-11-30 12:18:54 --> Email Class Initialized
INFO - 2016-11-30 12:18:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 11:18:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 11:18:54 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 11:18:54 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-30 11:18:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-30 11:18:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 11:18:55 --> Final output sent to browser
DEBUG - 2016-11-30 11:18:55 --> Total execution time: 1.6589
INFO - 2016-11-30 12:19:18 --> Config Class Initialized
INFO - 2016-11-30 12:19:18 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:19:18 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:19:18 --> Utf8 Class Initialized
INFO - 2016-11-30 12:19:18 --> URI Class Initialized
DEBUG - 2016-11-30 12:19:18 --> No URI present. Default controller set.
INFO - 2016-11-30 12:19:18 --> Router Class Initialized
INFO - 2016-11-30 12:19:18 --> Output Class Initialized
INFO - 2016-11-30 12:19:18 --> Security Class Initialized
DEBUG - 2016-11-30 12:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:19:18 --> Input Class Initialized
INFO - 2016-11-30 12:19:18 --> Language Class Initialized
INFO - 2016-11-30 12:19:18 --> Loader Class Initialized
INFO - 2016-11-30 12:19:18 --> Helper loaded: url_helper
INFO - 2016-11-30 12:19:18 --> Helper loaded: form_helper
INFO - 2016-11-30 12:19:18 --> Database Driver Class Initialized
INFO - 2016-11-30 12:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:19:18 --> Controller Class Initialized
INFO - 2016-11-30 12:19:18 --> Model Class Initialized
INFO - 2016-11-30 12:19:18 --> Model Class Initialized
INFO - 2016-11-30 12:19:18 --> Model Class Initialized
INFO - 2016-11-30 12:19:18 --> Model Class Initialized
INFO - 2016-11-30 12:19:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:19:18 --> Pagination Class Initialized
INFO - 2016-11-30 12:19:18 --> Helper loaded: app_helper
INFO - 2016-11-30 12:19:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 12:19:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 12:19:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 12:19:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 12:19:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 12:19:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 12:19:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 12:19:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 12:19:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 12:19:18 --> Final output sent to browser
DEBUG - 2016-11-30 12:19:18 --> Total execution time: 0.5723
INFO - 2016-11-30 12:20:15 --> Config Class Initialized
INFO - 2016-11-30 12:20:15 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:20:15 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:20:15 --> Utf8 Class Initialized
INFO - 2016-11-30 12:20:15 --> URI Class Initialized
INFO - 2016-11-30 12:20:15 --> Router Class Initialized
INFO - 2016-11-30 12:20:15 --> Output Class Initialized
INFO - 2016-11-30 12:20:15 --> Security Class Initialized
DEBUG - 2016-11-30 12:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:20:15 --> Input Class Initialized
INFO - 2016-11-30 12:20:15 --> Language Class Initialized
INFO - 2016-11-30 12:20:16 --> Loader Class Initialized
INFO - 2016-11-30 12:20:16 --> Helper loaded: url_helper
INFO - 2016-11-30 12:20:16 --> Helper loaded: form_helper
INFO - 2016-11-30 12:20:16 --> Database Driver Class Initialized
INFO - 2016-11-30 12:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:20:16 --> Controller Class Initialized
INFO - 2016-11-30 12:20:16 --> Model Class Initialized
INFO - 2016-11-30 12:20:16 --> Form Validation Class Initialized
INFO - 2016-11-30 12:20:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:20:16 --> Pagination Class Initialized
INFO - 2016-11-30 12:20:16 --> Helper loaded: app_helper
INFO - 2016-11-30 12:20:16 --> Email Class Initialized
INFO - 2016-11-30 12:20:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:20:16 --> Final output sent to browser
DEBUG - 2016-11-30 12:20:16 --> Total execution time: 0.3678
INFO - 2016-11-30 12:20:21 --> Config Class Initialized
INFO - 2016-11-30 12:20:21 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:20:21 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:20:21 --> Utf8 Class Initialized
INFO - 2016-11-30 12:20:21 --> URI Class Initialized
INFO - 2016-11-30 12:20:21 --> Router Class Initialized
INFO - 2016-11-30 12:20:21 --> Output Class Initialized
INFO - 2016-11-30 12:20:21 --> Security Class Initialized
DEBUG - 2016-11-30 12:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:20:21 --> Input Class Initialized
INFO - 2016-11-30 12:20:21 --> Language Class Initialized
INFO - 2016-11-30 12:20:21 --> Loader Class Initialized
INFO - 2016-11-30 12:20:21 --> Helper loaded: url_helper
INFO - 2016-11-30 12:20:21 --> Helper loaded: form_helper
INFO - 2016-11-30 12:20:21 --> Database Driver Class Initialized
INFO - 2016-11-30 12:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:20:22 --> Controller Class Initialized
INFO - 2016-11-30 12:20:22 --> Model Class Initialized
INFO - 2016-11-30 12:20:22 --> Form Validation Class Initialized
INFO - 2016-11-30 12:20:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:20:22 --> Pagination Class Initialized
INFO - 2016-11-30 12:20:22 --> Helper loaded: app_helper
INFO - 2016-11-30 12:20:22 --> Email Class Initialized
INFO - 2016-11-30 12:20:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:20:22 --> Final output sent to browser
DEBUG - 2016-11-30 12:20:22 --> Total execution time: 0.3535
INFO - 2016-11-30 12:20:22 --> Config Class Initialized
INFO - 2016-11-30 12:20:22 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:20:22 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:20:22 --> Utf8 Class Initialized
INFO - 2016-11-30 12:20:22 --> URI Class Initialized
INFO - 2016-11-30 12:20:22 --> Router Class Initialized
INFO - 2016-11-30 12:20:22 --> Output Class Initialized
INFO - 2016-11-30 12:20:22 --> Security Class Initialized
DEBUG - 2016-11-30 12:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:20:22 --> Input Class Initialized
INFO - 2016-11-30 12:20:22 --> Language Class Initialized
INFO - 2016-11-30 12:20:22 --> Loader Class Initialized
INFO - 2016-11-30 12:20:22 --> Helper loaded: url_helper
INFO - 2016-11-30 12:20:22 --> Helper loaded: form_helper
INFO - 2016-11-30 12:20:22 --> Database Driver Class Initialized
INFO - 2016-11-30 12:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:20:22 --> Controller Class Initialized
INFO - 2016-11-30 12:20:22 --> Model Class Initialized
INFO - 2016-11-30 12:20:22 --> Form Validation Class Initialized
INFO - 2016-11-30 12:20:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:20:22 --> Pagination Class Initialized
INFO - 2016-11-30 12:20:22 --> Helper loaded: app_helper
INFO - 2016-11-30 12:20:22 --> Email Class Initialized
INFO - 2016-11-30 12:20:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:20:22 --> Final output sent to browser
DEBUG - 2016-11-30 12:20:22 --> Total execution time: 0.3612
INFO - 2016-11-30 12:20:22 --> Config Class Initialized
INFO - 2016-11-30 12:20:22 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:20:22 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:20:22 --> Utf8 Class Initialized
INFO - 2016-11-30 12:20:22 --> URI Class Initialized
INFO - 2016-11-30 12:20:23 --> Router Class Initialized
INFO - 2016-11-30 12:20:23 --> Output Class Initialized
INFO - 2016-11-30 12:20:23 --> Security Class Initialized
DEBUG - 2016-11-30 12:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:20:23 --> Input Class Initialized
INFO - 2016-11-30 12:20:23 --> Language Class Initialized
INFO - 2016-11-30 12:20:23 --> Loader Class Initialized
INFO - 2016-11-30 12:20:23 --> Helper loaded: url_helper
INFO - 2016-11-30 12:20:23 --> Helper loaded: form_helper
INFO - 2016-11-30 12:20:23 --> Database Driver Class Initialized
INFO - 2016-11-30 12:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:20:23 --> Config Class Initialized
INFO - 2016-11-30 12:20:23 --> Controller Class Initialized
INFO - 2016-11-30 12:20:23 --> Hooks Class Initialized
INFO - 2016-11-30 12:20:23 --> Model Class Initialized
DEBUG - 2016-11-30 12:20:23 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:20:23 --> Form Validation Class Initialized
INFO - 2016-11-30 12:20:23 --> Utf8 Class Initialized
INFO - 2016-11-30 12:20:23 --> URI Class Initialized
INFO - 2016-11-30 12:20:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:20:23 --> Router Class Initialized
INFO - 2016-11-30 12:20:23 --> Pagination Class Initialized
INFO - 2016-11-30 12:20:23 --> Helper loaded: app_helper
INFO - 2016-11-30 12:20:23 --> Output Class Initialized
INFO - 2016-11-30 12:20:23 --> Email Class Initialized
INFO - 2016-11-30 12:20:23 --> Security Class Initialized
INFO - 2016-11-30 12:20:23 --> Config Class Initialized
INFO - 2016-11-30 12:20:23 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-30 12:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:20:23 --> Hooks Class Initialized
INFO - 2016-11-30 12:20:23 --> Final output sent to browser
INFO - 2016-11-30 12:20:23 --> Input Class Initialized
DEBUG - 2016-11-30 12:20:23 --> Total execution time: 0.4517
DEBUG - 2016-11-30 12:20:23 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:20:23 --> Language Class Initialized
INFO - 2016-11-30 12:20:23 --> Utf8 Class Initialized
INFO - 2016-11-30 12:20:23 --> URI Class Initialized
INFO - 2016-11-30 12:20:23 --> Loader Class Initialized
INFO - 2016-11-30 12:20:23 --> Router Class Initialized
INFO - 2016-11-30 12:20:23 --> Helper loaded: url_helper
INFO - 2016-11-30 12:20:23 --> Output Class Initialized
INFO - 2016-11-30 12:20:23 --> Helper loaded: form_helper
INFO - 2016-11-30 12:20:23 --> Config Class Initialized
INFO - 2016-11-30 12:20:23 --> Security Class Initialized
INFO - 2016-11-30 12:20:23 --> Database Driver Class Initialized
INFO - 2016-11-30 12:20:23 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:20:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-30 12:20:23 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:20:23 --> Input Class Initialized
INFO - 2016-11-30 12:20:23 --> Utf8 Class Initialized
INFO - 2016-11-30 12:20:23 --> Controller Class Initialized
INFO - 2016-11-30 12:20:23 --> Language Class Initialized
INFO - 2016-11-30 12:20:23 --> URI Class Initialized
INFO - 2016-11-30 12:20:23 --> Model Class Initialized
INFO - 2016-11-30 12:20:23 --> Loader Class Initialized
INFO - 2016-11-30 12:20:23 --> Form Validation Class Initialized
INFO - 2016-11-30 12:20:23 --> Router Class Initialized
INFO - 2016-11-30 12:20:23 --> Helper loaded: url_helper
INFO - 2016-11-30 12:20:23 --> Output Class Initialized
INFO - 2016-11-30 12:20:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:20:23 --> Helper loaded: form_helper
INFO - 2016-11-30 12:20:23 --> Pagination Class Initialized
INFO - 2016-11-30 12:20:23 --> Config Class Initialized
INFO - 2016-11-30 12:20:23 --> Security Class Initialized
INFO - 2016-11-30 12:20:23 --> Helper loaded: app_helper
INFO - 2016-11-30 12:20:23 --> Database Driver Class Initialized
INFO - 2016-11-30 12:20:23 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:20:23 --> Email Class Initialized
INFO - 2016-11-30 12:20:23 --> Input Class Initialized
DEBUG - 2016-11-30 12:20:23 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:20:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:20:23 --> Language Class Initialized
INFO - 2016-11-30 12:20:23 --> Utf8 Class Initialized
INFO - 2016-11-30 12:20:23 --> URI Class Initialized
INFO - 2016-11-30 12:20:23 --> Final output sent to browser
INFO - 2016-11-30 12:20:23 --> Loader Class Initialized
INFO - 2016-11-30 12:20:23 --> Router Class Initialized
DEBUG - 2016-11-30 12:20:23 --> Total execution time: 0.6273
INFO - 2016-11-30 12:20:23 --> Helper loaded: url_helper
INFO - 2016-11-30 12:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:20:23 --> Output Class Initialized
INFO - 2016-11-30 12:20:23 --> Config Class Initialized
INFO - 2016-11-30 12:20:23 --> Helper loaded: form_helper
INFO - 2016-11-30 12:20:23 --> Controller Class Initialized
INFO - 2016-11-30 12:20:23 --> Hooks Class Initialized
INFO - 2016-11-30 12:20:23 --> Security Class Initialized
INFO - 2016-11-30 12:20:23 --> Database Driver Class Initialized
DEBUG - 2016-11-30 12:20:23 --> UTF-8 Support Enabled
DEBUG - 2016-11-30 12:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:20:23 --> Model Class Initialized
INFO - 2016-11-30 12:20:23 --> Utf8 Class Initialized
INFO - 2016-11-30 12:20:23 --> Input Class Initialized
INFO - 2016-11-30 12:20:23 --> Form Validation Class Initialized
INFO - 2016-11-30 12:20:23 --> URI Class Initialized
INFO - 2016-11-30 12:20:23 --> Language Class Initialized
INFO - 2016-11-30 12:20:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:20:23 --> Loader Class Initialized
INFO - 2016-11-30 12:20:23 --> Router Class Initialized
INFO - 2016-11-30 12:20:23 --> Pagination Class Initialized
INFO - 2016-11-30 12:20:23 --> Helper loaded: app_helper
INFO - 2016-11-30 12:20:23 --> Helper loaded: url_helper
INFO - 2016-11-30 12:20:24 --> Config Class Initialized
INFO - 2016-11-30 12:20:24 --> Output Class Initialized
INFO - 2016-11-30 12:20:24 --> Helper loaded: form_helper
INFO - 2016-11-30 12:20:24 --> Email Class Initialized
INFO - 2016-11-30 12:20:24 --> Hooks Class Initialized
INFO - 2016-11-30 12:20:24 --> Security Class Initialized
DEBUG - 2016-11-30 12:20:24 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:20:24 --> Database Driver Class Initialized
INFO - 2016-11-30 12:20:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-30 12:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:20:24 --> Utf8 Class Initialized
INFO - 2016-11-30 12:20:24 --> Final output sent to browser
INFO - 2016-11-30 12:20:24 --> Input Class Initialized
DEBUG - 2016-11-30 12:20:24 --> Total execution time: 0.7363
INFO - 2016-11-30 12:20:24 --> URI Class Initialized
INFO - 2016-11-30 12:20:24 --> Language Class Initialized
INFO - 2016-11-30 12:20:24 --> Router Class Initialized
INFO - 2016-11-30 12:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:20:24 --> Loader Class Initialized
INFO - 2016-11-30 12:20:24 --> Controller Class Initialized
INFO - 2016-11-30 12:20:24 --> Output Class Initialized
INFO - 2016-11-30 12:20:24 --> Helper loaded: url_helper
INFO - 2016-11-30 12:20:24 --> Model Class Initialized
INFO - 2016-11-30 12:20:24 --> Security Class Initialized
INFO - 2016-11-30 12:20:24 --> Helper loaded: form_helper
INFO - 2016-11-30 12:20:24 --> Form Validation Class Initialized
DEBUG - 2016-11-30 12:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:20:24 --> Database Driver Class Initialized
INFO - 2016-11-30 12:20:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:20:24 --> Input Class Initialized
INFO - 2016-11-30 12:20:24 --> Pagination Class Initialized
INFO - 2016-11-30 12:20:24 --> Language Class Initialized
INFO - 2016-11-30 12:20:24 --> Helper loaded: app_helper
INFO - 2016-11-30 12:20:24 --> Loader Class Initialized
INFO - 2016-11-30 12:20:24 --> Email Class Initialized
INFO - 2016-11-30 12:20:24 --> Helper loaded: url_helper
INFO - 2016-11-30 12:20:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:20:24 --> Helper loaded: form_helper
INFO - 2016-11-30 12:20:24 --> Final output sent to browser
INFO - 2016-11-30 12:20:24 --> Database Driver Class Initialized
DEBUG - 2016-11-30 12:20:24 --> Total execution time: 0.8503
INFO - 2016-11-30 12:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:20:24 --> Controller Class Initialized
INFO - 2016-11-30 12:20:24 --> Model Class Initialized
INFO - 2016-11-30 12:20:24 --> Form Validation Class Initialized
INFO - 2016-11-30 12:20:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:20:24 --> Pagination Class Initialized
INFO - 2016-11-30 12:20:24 --> Helper loaded: app_helper
INFO - 2016-11-30 12:20:24 --> Email Class Initialized
INFO - 2016-11-30 12:20:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:20:24 --> Final output sent to browser
DEBUG - 2016-11-30 12:20:24 --> Total execution time: 0.8598
INFO - 2016-11-30 12:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:20:24 --> Controller Class Initialized
INFO - 2016-11-30 12:20:24 --> Model Class Initialized
INFO - 2016-11-30 12:20:24 --> Form Validation Class Initialized
INFO - 2016-11-30 12:20:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:20:24 --> Pagination Class Initialized
INFO - 2016-11-30 12:20:24 --> Helper loaded: app_helper
INFO - 2016-11-30 12:20:24 --> Email Class Initialized
INFO - 2016-11-30 12:20:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:20:24 --> Final output sent to browser
DEBUG - 2016-11-30 12:20:24 --> Total execution time: 0.8491
INFO - 2016-11-30 12:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:20:24 --> Controller Class Initialized
INFO - 2016-11-30 12:20:24 --> Model Class Initialized
INFO - 2016-11-30 12:20:24 --> Form Validation Class Initialized
INFO - 2016-11-30 12:20:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:20:24 --> Pagination Class Initialized
INFO - 2016-11-30 12:20:24 --> Helper loaded: app_helper
INFO - 2016-11-30 12:20:24 --> Email Class Initialized
INFO - 2016-11-30 12:20:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:20:24 --> Final output sent to browser
DEBUG - 2016-11-30 12:20:24 --> Total execution time: 0.8654
INFO - 2016-11-30 12:20:26 --> Config Class Initialized
INFO - 2016-11-30 12:20:26 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:20:26 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:20:26 --> Utf8 Class Initialized
INFO - 2016-11-30 12:20:26 --> URI Class Initialized
INFO - 2016-11-30 12:20:26 --> Router Class Initialized
INFO - 2016-11-30 12:20:26 --> Output Class Initialized
INFO - 2016-11-30 12:20:26 --> Security Class Initialized
DEBUG - 2016-11-30 12:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:20:26 --> Input Class Initialized
INFO - 2016-11-30 12:20:26 --> Language Class Initialized
INFO - 2016-11-30 12:20:26 --> Loader Class Initialized
INFO - 2016-11-30 12:20:26 --> Helper loaded: url_helper
INFO - 2016-11-30 12:20:26 --> Helper loaded: form_helper
INFO - 2016-11-30 12:20:26 --> Database Driver Class Initialized
INFO - 2016-11-30 12:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:20:26 --> Controller Class Initialized
INFO - 2016-11-30 12:20:26 --> Model Class Initialized
INFO - 2016-11-30 12:20:26 --> Form Validation Class Initialized
INFO - 2016-11-30 12:20:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:20:26 --> Pagination Class Initialized
INFO - 2016-11-30 12:20:26 --> Helper loaded: app_helper
INFO - 2016-11-30 12:20:26 --> Email Class Initialized
INFO - 2016-11-30 12:20:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:20:26 --> Final output sent to browser
DEBUG - 2016-11-30 12:20:26 --> Total execution time: 0.4318
INFO - 2016-11-30 12:20:54 --> Config Class Initialized
INFO - 2016-11-30 12:20:54 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:20:54 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:20:54 --> Utf8 Class Initialized
INFO - 2016-11-30 12:20:54 --> URI Class Initialized
INFO - 2016-11-30 12:20:54 --> Router Class Initialized
INFO - 2016-11-30 12:20:54 --> Output Class Initialized
INFO - 2016-11-30 12:20:54 --> Security Class Initialized
DEBUG - 2016-11-30 12:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:20:54 --> Input Class Initialized
INFO - 2016-11-30 12:20:54 --> Language Class Initialized
INFO - 2016-11-30 12:20:54 --> Loader Class Initialized
INFO - 2016-11-30 12:20:54 --> Helper loaded: url_helper
INFO - 2016-11-30 12:20:54 --> Helper loaded: form_helper
INFO - 2016-11-30 12:20:54 --> Database Driver Class Initialized
INFO - 2016-11-30 12:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:20:54 --> Controller Class Initialized
INFO - 2016-11-30 12:20:54 --> Model Class Initialized
INFO - 2016-11-30 12:20:54 --> Form Validation Class Initialized
INFO - 2016-11-30 12:20:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:20:54 --> Pagination Class Initialized
INFO - 2016-11-30 12:20:54 --> Helper loaded: app_helper
INFO - 2016-11-30 12:20:54 --> Email Class Initialized
INFO - 2016-11-30 12:20:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:20:54 --> Final output sent to browser
DEBUG - 2016-11-30 12:20:54 --> Total execution time: 0.6251
INFO - 2016-11-30 12:21:42 --> Config Class Initialized
INFO - 2016-11-30 12:21:42 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:21:42 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:21:42 --> Utf8 Class Initialized
INFO - 2016-11-30 12:21:42 --> URI Class Initialized
INFO - 2016-11-30 12:21:42 --> Router Class Initialized
INFO - 2016-11-30 12:21:42 --> Output Class Initialized
INFO - 2016-11-30 12:21:42 --> Security Class Initialized
DEBUG - 2016-11-30 12:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:21:42 --> Input Class Initialized
INFO - 2016-11-30 12:21:42 --> Language Class Initialized
INFO - 2016-11-30 12:21:42 --> Loader Class Initialized
INFO - 2016-11-30 12:21:42 --> Helper loaded: url_helper
INFO - 2016-11-30 12:21:42 --> Helper loaded: form_helper
INFO - 2016-11-30 12:21:42 --> Database Driver Class Initialized
INFO - 2016-11-30 12:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:21:42 --> Controller Class Initialized
INFO - 2016-11-30 12:21:42 --> Model Class Initialized
INFO - 2016-11-30 12:21:42 --> Form Validation Class Initialized
INFO - 2016-11-30 12:21:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:21:42 --> Pagination Class Initialized
INFO - 2016-11-30 12:21:42 --> Helper loaded: app_helper
INFO - 2016-11-30 12:21:42 --> Email Class Initialized
INFO - 2016-11-30 12:21:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:21:43 --> Final output sent to browser
DEBUG - 2016-11-30 12:21:43 --> Total execution time: 0.5085
INFO - 2016-11-30 12:22:13 --> Config Class Initialized
INFO - 2016-11-30 12:22:13 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:22:13 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:22:13 --> Utf8 Class Initialized
INFO - 2016-11-30 12:22:13 --> URI Class Initialized
INFO - 2016-11-30 12:22:13 --> Router Class Initialized
INFO - 2016-11-30 12:22:13 --> Output Class Initialized
INFO - 2016-11-30 12:22:13 --> Security Class Initialized
DEBUG - 2016-11-30 12:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:22:13 --> Input Class Initialized
INFO - 2016-11-30 12:22:13 --> Language Class Initialized
INFO - 2016-11-30 12:22:13 --> Loader Class Initialized
INFO - 2016-11-30 12:22:13 --> Helper loaded: url_helper
INFO - 2016-11-30 12:22:13 --> Helper loaded: form_helper
INFO - 2016-11-30 12:22:13 --> Database Driver Class Initialized
INFO - 2016-11-30 12:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:22:13 --> Controller Class Initialized
INFO - 2016-11-30 12:22:13 --> Model Class Initialized
INFO - 2016-11-30 12:22:13 --> Form Validation Class Initialized
INFO - 2016-11-30 12:22:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:22:14 --> Pagination Class Initialized
INFO - 2016-11-30 12:22:14 --> Helper loaded: app_helper
INFO - 2016-11-30 12:22:14 --> Email Class Initialized
INFO - 2016-11-30 12:22:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:22:14 --> Final output sent to browser
DEBUG - 2016-11-30 12:22:14 --> Total execution time: 0.6176
INFO - 2016-11-30 12:23:01 --> Config Class Initialized
INFO - 2016-11-30 12:23:01 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:23:01 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:23:01 --> Utf8 Class Initialized
INFO - 2016-11-30 12:23:01 --> URI Class Initialized
INFO - 2016-11-30 12:23:01 --> Router Class Initialized
INFO - 2016-11-30 12:23:01 --> Output Class Initialized
INFO - 2016-11-30 12:23:01 --> Security Class Initialized
DEBUG - 2016-11-30 12:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:23:01 --> Input Class Initialized
INFO - 2016-11-30 12:23:01 --> Language Class Initialized
INFO - 2016-11-30 12:23:01 --> Loader Class Initialized
INFO - 2016-11-30 12:23:01 --> Helper loaded: url_helper
INFO - 2016-11-30 12:23:01 --> Helper loaded: form_helper
INFO - 2016-11-30 12:23:01 --> Database Driver Class Initialized
INFO - 2016-11-30 12:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:23:01 --> Controller Class Initialized
INFO - 2016-11-30 12:23:01 --> Model Class Initialized
INFO - 2016-11-30 12:23:01 --> Form Validation Class Initialized
INFO - 2016-11-30 12:23:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:23:01 --> Pagination Class Initialized
INFO - 2016-11-30 12:23:01 --> Helper loaded: app_helper
INFO - 2016-11-30 12:23:01 --> Email Class Initialized
INFO - 2016-11-30 12:23:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:23:01 --> Final output sent to browser
DEBUG - 2016-11-30 12:23:02 --> Total execution time: 0.3855
INFO - 2016-11-30 12:24:24 --> Config Class Initialized
INFO - 2016-11-30 12:24:24 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:24:24 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:24:24 --> Utf8 Class Initialized
INFO - 2016-11-30 12:24:24 --> URI Class Initialized
INFO - 2016-11-30 12:24:24 --> Router Class Initialized
INFO - 2016-11-30 12:24:24 --> Output Class Initialized
INFO - 2016-11-30 12:24:24 --> Security Class Initialized
DEBUG - 2016-11-30 12:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:24:24 --> Input Class Initialized
INFO - 2016-11-30 12:24:24 --> Language Class Initialized
INFO - 2016-11-30 12:24:24 --> Loader Class Initialized
INFO - 2016-11-30 12:24:24 --> Helper loaded: url_helper
INFO - 2016-11-30 12:24:24 --> Helper loaded: form_helper
INFO - 2016-11-30 12:24:24 --> Database Driver Class Initialized
INFO - 2016-11-30 12:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:24:24 --> Controller Class Initialized
INFO - 2016-11-30 12:24:24 --> Model Class Initialized
INFO - 2016-11-30 12:24:24 --> Form Validation Class Initialized
INFO - 2016-11-30 12:24:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:24:24 --> Pagination Class Initialized
INFO - 2016-11-30 12:24:24 --> Helper loaded: app_helper
INFO - 2016-11-30 12:24:24 --> Email Class Initialized
INFO - 2016-11-30 12:24:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:24:24 --> Final output sent to browser
DEBUG - 2016-11-30 12:24:24 --> Total execution time: 0.3935
INFO - 2016-11-30 12:24:27 --> Config Class Initialized
INFO - 2016-11-30 12:24:27 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:24:27 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:24:27 --> Utf8 Class Initialized
INFO - 2016-11-30 12:24:27 --> URI Class Initialized
DEBUG - 2016-11-30 12:24:27 --> No URI present. Default controller set.
INFO - 2016-11-30 12:24:27 --> Router Class Initialized
INFO - 2016-11-30 12:24:27 --> Output Class Initialized
INFO - 2016-11-30 12:24:27 --> Security Class Initialized
DEBUG - 2016-11-30 12:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:24:27 --> Input Class Initialized
INFO - 2016-11-30 12:24:27 --> Language Class Initialized
INFO - 2016-11-30 12:24:27 --> Loader Class Initialized
INFO - 2016-11-30 12:24:27 --> Helper loaded: url_helper
INFO - 2016-11-30 12:24:28 --> Helper loaded: form_helper
INFO - 2016-11-30 12:24:28 --> Database Driver Class Initialized
INFO - 2016-11-30 12:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:24:28 --> Controller Class Initialized
INFO - 2016-11-30 12:24:28 --> Model Class Initialized
INFO - 2016-11-30 12:24:28 --> Model Class Initialized
INFO - 2016-11-30 12:24:28 --> Model Class Initialized
INFO - 2016-11-30 12:24:28 --> Model Class Initialized
INFO - 2016-11-30 12:24:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:24:28 --> Pagination Class Initialized
INFO - 2016-11-30 12:24:28 --> Helper loaded: app_helper
INFO - 2016-11-30 12:24:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 12:24:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 12:24:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 12:24:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 12:24:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 12:24:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 12:24:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 12:24:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 12:24:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 12:24:28 --> Final output sent to browser
DEBUG - 2016-11-30 12:24:28 --> Total execution time: 0.6427
INFO - 2016-11-30 12:24:35 --> Config Class Initialized
INFO - 2016-11-30 12:24:35 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:24:35 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:24:35 --> Utf8 Class Initialized
INFO - 2016-11-30 12:24:35 --> URI Class Initialized
DEBUG - 2016-11-30 12:24:35 --> No URI present. Default controller set.
INFO - 2016-11-30 12:24:35 --> Router Class Initialized
INFO - 2016-11-30 12:24:35 --> Output Class Initialized
INFO - 2016-11-30 12:24:35 --> Security Class Initialized
DEBUG - 2016-11-30 12:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:24:35 --> Input Class Initialized
INFO - 2016-11-30 12:24:35 --> Language Class Initialized
INFO - 2016-11-30 12:24:35 --> Loader Class Initialized
INFO - 2016-11-30 12:24:35 --> Helper loaded: url_helper
INFO - 2016-11-30 12:24:35 --> Helper loaded: form_helper
INFO - 2016-11-30 12:24:35 --> Database Driver Class Initialized
INFO - 2016-11-30 12:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:24:35 --> Controller Class Initialized
INFO - 2016-11-30 12:24:35 --> Model Class Initialized
INFO - 2016-11-30 12:24:35 --> Model Class Initialized
INFO - 2016-11-30 12:24:35 --> Model Class Initialized
INFO - 2016-11-30 12:24:35 --> Model Class Initialized
INFO - 2016-11-30 12:24:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:24:35 --> Pagination Class Initialized
INFO - 2016-11-30 12:24:35 --> Helper loaded: app_helper
INFO - 2016-11-30 12:24:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 12:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 12:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 12:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 12:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 12:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 12:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 12:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 12:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 12:24:36 --> Final output sent to browser
DEBUG - 2016-11-30 12:24:36 --> Total execution time: 0.6337
INFO - 2016-11-30 12:24:48 --> Config Class Initialized
INFO - 2016-11-30 12:24:48 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:24:48 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:24:48 --> Utf8 Class Initialized
INFO - 2016-11-30 12:24:48 --> URI Class Initialized
INFO - 2016-11-30 12:24:48 --> Router Class Initialized
INFO - 2016-11-30 12:24:48 --> Output Class Initialized
INFO - 2016-11-30 12:24:48 --> Security Class Initialized
DEBUG - 2016-11-30 12:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:24:48 --> Input Class Initialized
INFO - 2016-11-30 12:24:48 --> Language Class Initialized
INFO - 2016-11-30 12:24:48 --> Loader Class Initialized
INFO - 2016-11-30 12:24:48 --> Helper loaded: url_helper
INFO - 2016-11-30 12:24:48 --> Helper loaded: form_helper
INFO - 2016-11-30 12:24:48 --> Database Driver Class Initialized
INFO - 2016-11-30 12:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:24:48 --> Controller Class Initialized
INFO - 2016-11-30 12:24:48 --> Model Class Initialized
INFO - 2016-11-30 12:24:48 --> Form Validation Class Initialized
INFO - 2016-11-30 12:24:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:24:48 --> Pagination Class Initialized
INFO - 2016-11-30 12:24:48 --> Helper loaded: app_helper
INFO - 2016-11-30 12:24:48 --> Email Class Initialized
INFO - 2016-11-30 12:24:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:24:48 --> Final output sent to browser
DEBUG - 2016-11-30 12:24:48 --> Total execution time: 0.6270
INFO - 2016-11-30 12:24:52 --> Config Class Initialized
INFO - 2016-11-30 12:24:52 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:24:52 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:24:52 --> Utf8 Class Initialized
INFO - 2016-11-30 12:24:52 --> URI Class Initialized
INFO - 2016-11-30 12:24:52 --> Router Class Initialized
INFO - 2016-11-30 12:24:52 --> Output Class Initialized
INFO - 2016-11-30 12:24:52 --> Security Class Initialized
DEBUG - 2016-11-30 12:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:24:52 --> Input Class Initialized
INFO - 2016-11-30 12:24:52 --> Language Class Initialized
INFO - 2016-11-30 12:24:52 --> Loader Class Initialized
INFO - 2016-11-30 12:24:52 --> Helper loaded: url_helper
INFO - 2016-11-30 12:24:52 --> Helper loaded: form_helper
INFO - 2016-11-30 12:24:52 --> Database Driver Class Initialized
INFO - 2016-11-30 12:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:24:52 --> Controller Class Initialized
INFO - 2016-11-30 12:24:52 --> Model Class Initialized
INFO - 2016-11-30 12:24:52 --> Form Validation Class Initialized
INFO - 2016-11-30 12:24:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:24:52 --> Pagination Class Initialized
INFO - 2016-11-30 12:24:52 --> Helper loaded: app_helper
INFO - 2016-11-30 12:24:52 --> Email Class Initialized
INFO - 2016-11-30 12:24:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:24:52 --> Final output sent to browser
DEBUG - 2016-11-30 12:24:52 --> Total execution time: 0.5734
INFO - 2016-11-30 12:25:02 --> Config Class Initialized
INFO - 2016-11-30 12:25:02 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:25:02 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:25:02 --> Utf8 Class Initialized
INFO - 2016-11-30 12:25:02 --> URI Class Initialized
INFO - 2016-11-30 12:25:02 --> Router Class Initialized
INFO - 2016-11-30 12:25:02 --> Output Class Initialized
INFO - 2016-11-30 12:25:02 --> Security Class Initialized
DEBUG - 2016-11-30 12:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:25:02 --> Input Class Initialized
INFO - 2016-11-30 12:25:02 --> Language Class Initialized
INFO - 2016-11-30 12:25:02 --> Loader Class Initialized
INFO - 2016-11-30 12:25:02 --> Helper loaded: url_helper
INFO - 2016-11-30 12:25:02 --> Helper loaded: form_helper
INFO - 2016-11-30 12:25:02 --> Database Driver Class Initialized
INFO - 2016-11-30 12:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:25:02 --> Controller Class Initialized
INFO - 2016-11-30 12:25:02 --> Model Class Initialized
INFO - 2016-11-30 12:25:02 --> Form Validation Class Initialized
INFO - 2016-11-30 12:25:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:25:02 --> Pagination Class Initialized
INFO - 2016-11-30 12:25:02 --> Helper loaded: app_helper
INFO - 2016-11-30 12:25:02 --> Email Class Initialized
INFO - 2016-11-30 12:25:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:25:02 --> Final output sent to browser
DEBUG - 2016-11-30 12:25:03 --> Total execution time: 0.3988
INFO - 2016-11-30 12:25:29 --> Config Class Initialized
INFO - 2016-11-30 12:25:29 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:25:29 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:25:29 --> Utf8 Class Initialized
INFO - 2016-11-30 12:25:29 --> URI Class Initialized
DEBUG - 2016-11-30 12:25:29 --> No URI present. Default controller set.
INFO - 2016-11-30 12:25:29 --> Router Class Initialized
INFO - 2016-11-30 12:25:29 --> Output Class Initialized
INFO - 2016-11-30 12:25:29 --> Security Class Initialized
DEBUG - 2016-11-30 12:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:25:29 --> Input Class Initialized
INFO - 2016-11-30 12:25:29 --> Language Class Initialized
INFO - 2016-11-30 12:25:29 --> Loader Class Initialized
INFO - 2016-11-30 12:25:29 --> Helper loaded: url_helper
INFO - 2016-11-30 12:25:29 --> Helper loaded: form_helper
INFO - 2016-11-30 12:25:29 --> Database Driver Class Initialized
INFO - 2016-11-30 12:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:25:29 --> Controller Class Initialized
INFO - 2016-11-30 12:25:30 --> Model Class Initialized
INFO - 2016-11-30 12:25:30 --> Model Class Initialized
INFO - 2016-11-30 12:25:30 --> Model Class Initialized
INFO - 2016-11-30 12:25:30 --> Model Class Initialized
INFO - 2016-11-30 12:25:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:25:30 --> Pagination Class Initialized
INFO - 2016-11-30 12:25:30 --> Helper loaded: app_helper
INFO - 2016-11-30 12:25:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 12:25:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 12:25:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 12:25:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 12:25:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 12:25:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 12:25:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 12:25:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 12:25:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 12:25:30 --> Final output sent to browser
DEBUG - 2016-11-30 12:25:30 --> Total execution time: 0.6768
INFO - 2016-11-30 12:25:34 --> Config Class Initialized
INFO - 2016-11-30 12:25:34 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:25:34 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:25:34 --> Utf8 Class Initialized
INFO - 2016-11-30 12:25:34 --> URI Class Initialized
INFO - 2016-11-30 12:25:34 --> Router Class Initialized
INFO - 2016-11-30 12:25:34 --> Output Class Initialized
INFO - 2016-11-30 12:25:34 --> Security Class Initialized
DEBUG - 2016-11-30 12:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:25:34 --> Input Class Initialized
INFO - 2016-11-30 12:25:34 --> Language Class Initialized
INFO - 2016-11-30 12:25:34 --> Loader Class Initialized
INFO - 2016-11-30 12:25:34 --> Helper loaded: url_helper
INFO - 2016-11-30 12:25:34 --> Helper loaded: form_helper
INFO - 2016-11-30 12:25:34 --> Database Driver Class Initialized
INFO - 2016-11-30 12:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:25:34 --> Controller Class Initialized
INFO - 2016-11-30 12:25:34 --> Model Class Initialized
INFO - 2016-11-30 12:25:34 --> Form Validation Class Initialized
INFO - 2016-11-30 12:25:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:25:34 --> Pagination Class Initialized
INFO - 2016-11-30 12:25:34 --> Helper loaded: app_helper
INFO - 2016-11-30 12:25:34 --> Email Class Initialized
INFO - 2016-11-30 12:25:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:25:34 --> Final output sent to browser
DEBUG - 2016-11-30 12:25:34 --> Total execution time: 0.4101
INFO - 2016-11-30 12:25:54 --> Config Class Initialized
INFO - 2016-11-30 12:25:54 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:25:54 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:25:54 --> Utf8 Class Initialized
INFO - 2016-11-30 12:25:54 --> URI Class Initialized
INFO - 2016-11-30 12:25:54 --> Router Class Initialized
INFO - 2016-11-30 12:25:54 --> Output Class Initialized
INFO - 2016-11-30 12:25:54 --> Security Class Initialized
DEBUG - 2016-11-30 12:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:25:54 --> Input Class Initialized
INFO - 2016-11-30 12:25:54 --> Language Class Initialized
INFO - 2016-11-30 12:25:54 --> Loader Class Initialized
INFO - 2016-11-30 12:25:54 --> Helper loaded: url_helper
INFO - 2016-11-30 12:25:54 --> Helper loaded: form_helper
INFO - 2016-11-30 12:25:54 --> Database Driver Class Initialized
INFO - 2016-11-30 12:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:25:54 --> Controller Class Initialized
INFO - 2016-11-30 12:25:54 --> Model Class Initialized
INFO - 2016-11-30 12:25:54 --> Form Validation Class Initialized
INFO - 2016-11-30 12:25:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:25:54 --> Pagination Class Initialized
INFO - 2016-11-30 12:25:54 --> Helper loaded: app_helper
INFO - 2016-11-30 12:25:54 --> Email Class Initialized
INFO - 2016-11-30 12:25:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:25:54 --> Final output sent to browser
DEBUG - 2016-11-30 12:25:54 --> Total execution time: 0.4141
INFO - 2016-11-30 12:25:59 --> Config Class Initialized
INFO - 2016-11-30 12:25:59 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:25:59 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:25:59 --> Utf8 Class Initialized
INFO - 2016-11-30 12:25:59 --> URI Class Initialized
INFO - 2016-11-30 12:26:00 --> Router Class Initialized
INFO - 2016-11-30 12:26:00 --> Output Class Initialized
INFO - 2016-11-30 12:26:00 --> Security Class Initialized
DEBUG - 2016-11-30 12:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:26:00 --> Input Class Initialized
INFO - 2016-11-30 12:26:00 --> Language Class Initialized
INFO - 2016-11-30 12:26:00 --> Loader Class Initialized
INFO - 2016-11-30 12:26:00 --> Helper loaded: url_helper
INFO - 2016-11-30 12:26:00 --> Helper loaded: form_helper
INFO - 2016-11-30 12:26:00 --> Database Driver Class Initialized
INFO - 2016-11-30 12:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:26:00 --> Controller Class Initialized
INFO - 2016-11-30 12:26:00 --> Model Class Initialized
INFO - 2016-11-30 12:26:00 --> Form Validation Class Initialized
INFO - 2016-11-30 12:26:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:26:00 --> Pagination Class Initialized
INFO - 2016-11-30 12:26:00 --> Helper loaded: app_helper
INFO - 2016-11-30 12:26:00 --> Email Class Initialized
INFO - 2016-11-30 12:26:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:26:00 --> Final output sent to browser
DEBUG - 2016-11-30 12:26:00 --> Total execution time: 0.4598
INFO - 2016-11-30 12:28:00 --> Config Class Initialized
INFO - 2016-11-30 12:28:01 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:28:01 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:28:01 --> Utf8 Class Initialized
INFO - 2016-11-30 12:28:01 --> URI Class Initialized
DEBUG - 2016-11-30 12:28:01 --> No URI present. Default controller set.
INFO - 2016-11-30 12:28:01 --> Router Class Initialized
INFO - 2016-11-30 12:28:01 --> Output Class Initialized
INFO - 2016-11-30 12:28:01 --> Security Class Initialized
DEBUG - 2016-11-30 12:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:28:01 --> Input Class Initialized
INFO - 2016-11-30 12:28:01 --> Language Class Initialized
INFO - 2016-11-30 12:28:01 --> Loader Class Initialized
INFO - 2016-11-30 12:28:01 --> Helper loaded: url_helper
INFO - 2016-11-30 12:28:01 --> Helper loaded: form_helper
INFO - 2016-11-30 12:28:01 --> Database Driver Class Initialized
INFO - 2016-11-30 12:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:28:01 --> Controller Class Initialized
INFO - 2016-11-30 12:28:01 --> Model Class Initialized
INFO - 2016-11-30 12:28:01 --> Model Class Initialized
INFO - 2016-11-30 12:28:01 --> Model Class Initialized
INFO - 2016-11-30 12:28:01 --> Model Class Initialized
INFO - 2016-11-30 12:28:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:28:01 --> Pagination Class Initialized
INFO - 2016-11-30 12:28:01 --> Helper loaded: app_helper
INFO - 2016-11-30 12:28:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 12:28:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 12:28:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 12:28:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 12:28:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 12:28:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 12:28:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 12:28:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 12:28:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 12:28:01 --> Final output sent to browser
DEBUG - 2016-11-30 12:28:01 --> Total execution time: 0.6287
INFO - 2016-11-30 12:28:13 --> Config Class Initialized
INFO - 2016-11-30 12:28:13 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:28:13 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:28:13 --> Utf8 Class Initialized
INFO - 2016-11-30 12:28:13 --> URI Class Initialized
INFO - 2016-11-30 12:28:13 --> Router Class Initialized
INFO - 2016-11-30 12:28:13 --> Output Class Initialized
INFO - 2016-11-30 12:28:13 --> Security Class Initialized
DEBUG - 2016-11-30 12:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:28:13 --> Input Class Initialized
INFO - 2016-11-30 12:28:13 --> Language Class Initialized
INFO - 2016-11-30 12:28:13 --> Loader Class Initialized
INFO - 2016-11-30 12:28:13 --> Helper loaded: url_helper
INFO - 2016-11-30 12:28:13 --> Helper loaded: form_helper
INFO - 2016-11-30 12:28:13 --> Database Driver Class Initialized
INFO - 2016-11-30 12:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:28:13 --> Controller Class Initialized
INFO - 2016-11-30 12:28:13 --> Model Class Initialized
INFO - 2016-11-30 12:28:13 --> Form Validation Class Initialized
INFO - 2016-11-30 12:28:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:28:13 --> Pagination Class Initialized
INFO - 2016-11-30 12:28:13 --> Helper loaded: app_helper
INFO - 2016-11-30 12:28:13 --> Email Class Initialized
INFO - 2016-11-30 12:28:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:28:13 --> Final output sent to browser
DEBUG - 2016-11-30 12:28:13 --> Total execution time: 0.4527
INFO - 2016-11-30 12:28:45 --> Config Class Initialized
INFO - 2016-11-30 12:28:45 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:28:45 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:28:46 --> Utf8 Class Initialized
INFO - 2016-11-30 12:28:46 --> URI Class Initialized
INFO - 2016-11-30 12:28:46 --> Router Class Initialized
INFO - 2016-11-30 12:28:46 --> Output Class Initialized
INFO - 2016-11-30 12:28:46 --> Security Class Initialized
DEBUG - 2016-11-30 12:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:28:46 --> Input Class Initialized
INFO - 2016-11-30 12:28:46 --> Language Class Initialized
INFO - 2016-11-30 12:28:46 --> Loader Class Initialized
INFO - 2016-11-30 12:28:46 --> Helper loaded: url_helper
INFO - 2016-11-30 12:28:46 --> Helper loaded: form_helper
INFO - 2016-11-30 12:28:46 --> Database Driver Class Initialized
INFO - 2016-11-30 12:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:28:46 --> Controller Class Initialized
INFO - 2016-11-30 12:28:46 --> Model Class Initialized
INFO - 2016-11-30 12:28:46 --> Form Validation Class Initialized
INFO - 2016-11-30 12:28:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:28:46 --> Pagination Class Initialized
INFO - 2016-11-30 12:28:46 --> Helper loaded: app_helper
INFO - 2016-11-30 12:28:46 --> Email Class Initialized
INFO - 2016-11-30 12:28:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:28:46 --> Final output sent to browser
DEBUG - 2016-11-30 12:28:46 --> Total execution time: 0.5876
INFO - 2016-11-30 12:29:33 --> Config Class Initialized
INFO - 2016-11-30 12:29:33 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:29:33 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:29:33 --> Utf8 Class Initialized
INFO - 2016-11-30 12:29:33 --> URI Class Initialized
INFO - 2016-11-30 12:29:33 --> Router Class Initialized
INFO - 2016-11-30 12:29:33 --> Output Class Initialized
INFO - 2016-11-30 12:29:33 --> Security Class Initialized
DEBUG - 2016-11-30 12:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:29:33 --> Input Class Initialized
INFO - 2016-11-30 12:29:33 --> Language Class Initialized
INFO - 2016-11-30 12:29:33 --> Loader Class Initialized
INFO - 2016-11-30 12:29:33 --> Helper loaded: url_helper
INFO - 2016-11-30 12:29:33 --> Helper loaded: form_helper
INFO - 2016-11-30 12:29:33 --> Database Driver Class Initialized
INFO - 2016-11-30 12:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:29:33 --> Controller Class Initialized
INFO - 2016-11-30 12:29:33 --> Model Class Initialized
INFO - 2016-11-30 12:29:33 --> Form Validation Class Initialized
INFO - 2016-11-30 12:29:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:29:33 --> Pagination Class Initialized
INFO - 2016-11-30 12:29:33 --> Helper loaded: app_helper
INFO - 2016-11-30 12:29:33 --> Email Class Initialized
INFO - 2016-11-30 12:29:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:29:33 --> Final output sent to browser
DEBUG - 2016-11-30 12:29:33 --> Total execution time: 0.3918
INFO - 2016-11-30 12:29:47 --> Config Class Initialized
INFO - 2016-11-30 12:29:47 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:29:47 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:29:47 --> Utf8 Class Initialized
INFO - 2016-11-30 12:29:47 --> URI Class Initialized
DEBUG - 2016-11-30 12:29:47 --> No URI present. Default controller set.
INFO - 2016-11-30 12:29:47 --> Router Class Initialized
INFO - 2016-11-30 12:29:47 --> Output Class Initialized
INFO - 2016-11-30 12:29:47 --> Security Class Initialized
DEBUG - 2016-11-30 12:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:29:47 --> Input Class Initialized
INFO - 2016-11-30 12:29:47 --> Language Class Initialized
INFO - 2016-11-30 12:29:47 --> Loader Class Initialized
INFO - 2016-11-30 12:29:47 --> Helper loaded: url_helper
INFO - 2016-11-30 12:29:47 --> Helper loaded: form_helper
INFO - 2016-11-30 12:29:47 --> Database Driver Class Initialized
INFO - 2016-11-30 12:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:29:47 --> Controller Class Initialized
INFO - 2016-11-30 12:29:47 --> Model Class Initialized
INFO - 2016-11-30 12:29:47 --> Model Class Initialized
INFO - 2016-11-30 12:29:47 --> Model Class Initialized
INFO - 2016-11-30 12:29:47 --> Model Class Initialized
INFO - 2016-11-30 12:29:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:29:47 --> Pagination Class Initialized
INFO - 2016-11-30 12:29:47 --> Helper loaded: app_helper
INFO - 2016-11-30 12:29:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 12:29:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 12:29:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 12:29:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 12:29:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 12:29:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 12:29:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 12:29:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 12:29:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 12:29:47 --> Final output sent to browser
DEBUG - 2016-11-30 12:29:47 --> Total execution time: 0.6379
INFO - 2016-11-30 12:29:56 --> Config Class Initialized
INFO - 2016-11-30 12:29:56 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:29:57 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:29:57 --> Utf8 Class Initialized
INFO - 2016-11-30 12:29:57 --> URI Class Initialized
INFO - 2016-11-30 12:29:57 --> Router Class Initialized
INFO - 2016-11-30 12:29:57 --> Output Class Initialized
INFO - 2016-11-30 12:29:57 --> Security Class Initialized
DEBUG - 2016-11-30 12:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:29:57 --> Input Class Initialized
INFO - 2016-11-30 12:29:57 --> Language Class Initialized
INFO - 2016-11-30 12:29:57 --> Loader Class Initialized
INFO - 2016-11-30 12:29:57 --> Helper loaded: url_helper
INFO - 2016-11-30 12:29:57 --> Helper loaded: form_helper
INFO - 2016-11-30 12:29:57 --> Database Driver Class Initialized
INFO - 2016-11-30 12:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:29:57 --> Controller Class Initialized
INFO - 2016-11-30 12:29:57 --> Model Class Initialized
INFO - 2016-11-30 12:29:57 --> Form Validation Class Initialized
INFO - 2016-11-30 12:29:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:29:57 --> Pagination Class Initialized
INFO - 2016-11-30 12:29:57 --> Helper loaded: app_helper
INFO - 2016-11-30 12:29:57 --> Email Class Initialized
INFO - 2016-11-30 12:29:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:29:57 --> Final output sent to browser
DEBUG - 2016-11-30 12:29:57 --> Total execution time: 0.4226
INFO - 2016-11-30 12:30:10 --> Config Class Initialized
INFO - 2016-11-30 12:30:10 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:30:10 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:30:10 --> Utf8 Class Initialized
INFO - 2016-11-30 12:30:10 --> URI Class Initialized
INFO - 2016-11-30 12:30:10 --> Router Class Initialized
INFO - 2016-11-30 12:30:10 --> Output Class Initialized
INFO - 2016-11-30 12:30:10 --> Security Class Initialized
DEBUG - 2016-11-30 12:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:30:10 --> Input Class Initialized
INFO - 2016-11-30 12:30:10 --> Language Class Initialized
INFO - 2016-11-30 12:30:10 --> Loader Class Initialized
INFO - 2016-11-30 12:30:10 --> Helper loaded: url_helper
INFO - 2016-11-30 12:30:10 --> Helper loaded: form_helper
INFO - 2016-11-30 12:30:10 --> Database Driver Class Initialized
INFO - 2016-11-30 12:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:30:10 --> Controller Class Initialized
INFO - 2016-11-30 12:30:10 --> Model Class Initialized
INFO - 2016-11-30 12:30:10 --> Form Validation Class Initialized
INFO - 2016-11-30 12:30:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:30:10 --> Pagination Class Initialized
INFO - 2016-11-30 12:30:10 --> Helper loaded: app_helper
INFO - 2016-11-30 12:30:10 --> Email Class Initialized
INFO - 2016-11-30 12:30:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:30:10 --> Final output sent to browser
DEBUG - 2016-11-30 12:30:10 --> Total execution time: 0.4043
INFO - 2016-11-30 12:30:21 --> Config Class Initialized
INFO - 2016-11-30 12:30:21 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:30:21 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:30:21 --> Utf8 Class Initialized
INFO - 2016-11-30 12:30:21 --> URI Class Initialized
DEBUG - 2016-11-30 12:30:21 --> No URI present. Default controller set.
INFO - 2016-11-30 12:30:21 --> Router Class Initialized
INFO - 2016-11-30 12:30:22 --> Output Class Initialized
INFO - 2016-11-30 12:30:22 --> Security Class Initialized
DEBUG - 2016-11-30 12:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:30:22 --> Input Class Initialized
INFO - 2016-11-30 12:30:22 --> Language Class Initialized
INFO - 2016-11-30 12:30:22 --> Loader Class Initialized
INFO - 2016-11-30 12:30:22 --> Helper loaded: url_helper
INFO - 2016-11-30 12:30:22 --> Helper loaded: form_helper
INFO - 2016-11-30 12:30:22 --> Database Driver Class Initialized
INFO - 2016-11-30 12:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:30:22 --> Controller Class Initialized
INFO - 2016-11-30 12:30:22 --> Model Class Initialized
INFO - 2016-11-30 12:30:22 --> Model Class Initialized
INFO - 2016-11-30 12:30:22 --> Model Class Initialized
INFO - 2016-11-30 12:30:22 --> Model Class Initialized
INFO - 2016-11-30 12:30:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:30:22 --> Pagination Class Initialized
INFO - 2016-11-30 12:30:22 --> Helper loaded: app_helper
INFO - 2016-11-30 12:30:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 12:30:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 12:30:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 12:30:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 12:30:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 12:30:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 12:30:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 12:30:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 12:30:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 12:30:22 --> Final output sent to browser
DEBUG - 2016-11-30 12:30:22 --> Total execution time: 0.6459
INFO - 2016-11-30 12:30:52 --> Config Class Initialized
INFO - 2016-11-30 12:30:52 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:30:52 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:30:52 --> Utf8 Class Initialized
INFO - 2016-11-30 12:30:52 --> URI Class Initialized
DEBUG - 2016-11-30 12:30:52 --> No URI present. Default controller set.
INFO - 2016-11-30 12:30:52 --> Router Class Initialized
INFO - 2016-11-30 12:30:52 --> Output Class Initialized
INFO - 2016-11-30 12:30:52 --> Security Class Initialized
DEBUG - 2016-11-30 12:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:30:52 --> Input Class Initialized
INFO - 2016-11-30 12:30:52 --> Language Class Initialized
INFO - 2016-11-30 12:30:52 --> Loader Class Initialized
INFO - 2016-11-30 12:30:52 --> Helper loaded: url_helper
INFO - 2016-11-30 12:30:52 --> Helper loaded: form_helper
INFO - 2016-11-30 12:30:53 --> Database Driver Class Initialized
INFO - 2016-11-30 12:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:30:53 --> Controller Class Initialized
INFO - 2016-11-30 12:30:53 --> Model Class Initialized
INFO - 2016-11-30 12:30:53 --> Model Class Initialized
INFO - 2016-11-30 12:30:53 --> Model Class Initialized
INFO - 2016-11-30 12:30:53 --> Model Class Initialized
INFO - 2016-11-30 12:30:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:30:53 --> Pagination Class Initialized
INFO - 2016-11-30 12:30:53 --> Helper loaded: app_helper
INFO - 2016-11-30 12:30:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 12:30:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 12:30:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 12:30:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 12:30:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 12:30:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 12:30:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 12:30:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 12:30:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 12:30:53 --> Final output sent to browser
DEBUG - 2016-11-30 12:30:53 --> Total execution time: 0.6076
INFO - 2016-11-30 12:31:13 --> Config Class Initialized
INFO - 2016-11-30 12:31:13 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:31:13 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:31:13 --> Utf8 Class Initialized
INFO - 2016-11-30 12:31:13 --> URI Class Initialized
DEBUG - 2016-11-30 12:31:13 --> No URI present. Default controller set.
INFO - 2016-11-30 12:31:13 --> Router Class Initialized
INFO - 2016-11-30 12:31:13 --> Output Class Initialized
INFO - 2016-11-30 12:31:13 --> Security Class Initialized
DEBUG - 2016-11-30 12:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:31:13 --> Input Class Initialized
INFO - 2016-11-30 12:31:13 --> Language Class Initialized
INFO - 2016-11-30 12:31:13 --> Loader Class Initialized
INFO - 2016-11-30 12:31:13 --> Helper loaded: url_helper
INFO - 2016-11-30 12:31:13 --> Helper loaded: form_helper
INFO - 2016-11-30 12:31:13 --> Database Driver Class Initialized
INFO - 2016-11-30 12:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:31:13 --> Controller Class Initialized
INFO - 2016-11-30 12:31:13 --> Model Class Initialized
INFO - 2016-11-30 12:31:13 --> Model Class Initialized
INFO - 2016-11-30 12:31:13 --> Model Class Initialized
INFO - 2016-11-30 12:31:13 --> Model Class Initialized
INFO - 2016-11-30 12:31:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:31:14 --> Pagination Class Initialized
INFO - 2016-11-30 12:31:14 --> Helper loaded: app_helper
INFO - 2016-11-30 12:31:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 12:31:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 12:31:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 12:31:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 12:31:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 12:31:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 12:31:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 12:31:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 12:31:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 12:31:14 --> Final output sent to browser
DEBUG - 2016-11-30 12:31:14 --> Total execution time: 0.6157
INFO - 2016-11-30 12:35:43 --> Config Class Initialized
INFO - 2016-11-30 12:35:43 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:35:43 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:35:43 --> Utf8 Class Initialized
INFO - 2016-11-30 12:35:43 --> URI Class Initialized
DEBUG - 2016-11-30 12:35:43 --> No URI present. Default controller set.
INFO - 2016-11-30 12:35:43 --> Router Class Initialized
INFO - 2016-11-30 12:35:43 --> Output Class Initialized
INFO - 2016-11-30 12:35:43 --> Security Class Initialized
DEBUG - 2016-11-30 12:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:35:43 --> Input Class Initialized
INFO - 2016-11-30 12:35:43 --> Language Class Initialized
INFO - 2016-11-30 12:35:43 --> Loader Class Initialized
INFO - 2016-11-30 12:35:43 --> Helper loaded: url_helper
INFO - 2016-11-30 12:35:43 --> Helper loaded: form_helper
INFO - 2016-11-30 12:35:43 --> Database Driver Class Initialized
INFO - 2016-11-30 12:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:35:43 --> Controller Class Initialized
INFO - 2016-11-30 12:35:43 --> Model Class Initialized
INFO - 2016-11-30 12:35:43 --> Model Class Initialized
INFO - 2016-11-30 12:35:43 --> Model Class Initialized
INFO - 2016-11-30 12:35:43 --> Model Class Initialized
INFO - 2016-11-30 12:35:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:35:43 --> Pagination Class Initialized
INFO - 2016-11-30 12:35:43 --> Helper loaded: app_helper
INFO - 2016-11-30 12:35:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 12:35:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 12:35:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 12:35:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 12:35:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 12:35:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 12:35:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 12:35:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 12:35:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 12:35:43 --> Final output sent to browser
DEBUG - 2016-11-30 12:35:43 --> Total execution time: 0.5793
INFO - 2016-11-30 12:37:17 --> Config Class Initialized
INFO - 2016-11-30 12:37:17 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:37:17 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:37:17 --> Utf8 Class Initialized
INFO - 2016-11-30 12:37:17 --> URI Class Initialized
DEBUG - 2016-11-30 12:37:17 --> No URI present. Default controller set.
INFO - 2016-11-30 12:37:17 --> Router Class Initialized
INFO - 2016-11-30 12:37:17 --> Output Class Initialized
INFO - 2016-11-30 12:37:17 --> Security Class Initialized
DEBUG - 2016-11-30 12:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:37:17 --> Input Class Initialized
INFO - 2016-11-30 12:37:17 --> Language Class Initialized
INFO - 2016-11-30 12:37:17 --> Loader Class Initialized
INFO - 2016-11-30 12:37:17 --> Helper loaded: url_helper
INFO - 2016-11-30 12:37:17 --> Helper loaded: form_helper
INFO - 2016-11-30 12:37:17 --> Database Driver Class Initialized
INFO - 2016-11-30 12:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:37:17 --> Controller Class Initialized
INFO - 2016-11-30 12:37:17 --> Model Class Initialized
INFO - 2016-11-30 12:37:17 --> Model Class Initialized
INFO - 2016-11-30 12:37:17 --> Model Class Initialized
INFO - 2016-11-30 12:37:17 --> Model Class Initialized
INFO - 2016-11-30 12:37:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:37:17 --> Pagination Class Initialized
INFO - 2016-11-30 12:37:17 --> Helper loaded: app_helper
INFO - 2016-11-30 12:37:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 12:37:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 12:37:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 12:37:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 12:37:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 12:37:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 12:37:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 12:37:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 12:37:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 12:37:17 --> Final output sent to browser
DEBUG - 2016-11-30 12:37:17 --> Total execution time: 0.6358
INFO - 2016-11-30 12:37:27 --> Config Class Initialized
INFO - 2016-11-30 12:37:27 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:37:27 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:37:27 --> Utf8 Class Initialized
INFO - 2016-11-30 12:37:27 --> URI Class Initialized
INFO - 2016-11-30 12:37:27 --> Router Class Initialized
INFO - 2016-11-30 12:37:27 --> Output Class Initialized
INFO - 2016-11-30 12:37:27 --> Security Class Initialized
DEBUG - 2016-11-30 12:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:37:27 --> Input Class Initialized
INFO - 2016-11-30 12:37:27 --> Language Class Initialized
INFO - 2016-11-30 12:37:27 --> Loader Class Initialized
INFO - 2016-11-30 12:37:27 --> Helper loaded: url_helper
INFO - 2016-11-30 12:37:27 --> Helper loaded: form_helper
INFO - 2016-11-30 12:37:27 --> Database Driver Class Initialized
INFO - 2016-11-30 12:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:37:27 --> Controller Class Initialized
INFO - 2016-11-30 12:37:27 --> Model Class Initialized
INFO - 2016-11-30 12:37:27 --> Form Validation Class Initialized
INFO - 2016-11-30 12:37:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:37:27 --> Pagination Class Initialized
INFO - 2016-11-30 12:37:27 --> Helper loaded: app_helper
INFO - 2016-11-30 12:37:27 --> Email Class Initialized
INFO - 2016-11-30 12:37:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:37:27 --> Final output sent to browser
DEBUG - 2016-11-30 12:37:27 --> Total execution time: 0.3955
INFO - 2016-11-30 12:57:02 --> Config Class Initialized
INFO - 2016-11-30 12:57:02 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:57:02 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:57:02 --> Utf8 Class Initialized
INFO - 2016-11-30 12:57:02 --> URI Class Initialized
DEBUG - 2016-11-30 12:57:02 --> No URI present. Default controller set.
INFO - 2016-11-30 12:57:03 --> Router Class Initialized
INFO - 2016-11-30 12:57:03 --> Output Class Initialized
INFO - 2016-11-30 12:57:03 --> Security Class Initialized
DEBUG - 2016-11-30 12:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:57:03 --> Input Class Initialized
INFO - 2016-11-30 12:57:03 --> Language Class Initialized
INFO - 2016-11-30 12:57:03 --> Loader Class Initialized
INFO - 2016-11-30 12:57:03 --> Helper loaded: url_helper
INFO - 2016-11-30 12:57:03 --> Helper loaded: form_helper
INFO - 2016-11-30 12:57:03 --> Database Driver Class Initialized
INFO - 2016-11-30 12:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:57:03 --> Controller Class Initialized
INFO - 2016-11-30 12:57:03 --> Model Class Initialized
INFO - 2016-11-30 12:57:03 --> Model Class Initialized
INFO - 2016-11-30 12:57:03 --> Model Class Initialized
INFO - 2016-11-30 12:57:03 --> Model Class Initialized
INFO - 2016-11-30 12:57:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:57:03 --> Pagination Class Initialized
INFO - 2016-11-30 12:57:03 --> Helper loaded: app_helper
INFO - 2016-11-30 12:57:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 12:57:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 12:57:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 12:57:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 12:57:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 12:57:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 12:57:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 12:57:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 12:57:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 12:57:04 --> Final output sent to browser
DEBUG - 2016-11-30 12:57:04 --> Total execution time: 1.6952
INFO - 2016-11-30 12:57:11 --> Config Class Initialized
INFO - 2016-11-30 12:57:11 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:57:11 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:57:11 --> Utf8 Class Initialized
INFO - 2016-11-30 12:57:11 --> URI Class Initialized
INFO - 2016-11-30 12:57:11 --> Router Class Initialized
INFO - 2016-11-30 12:57:11 --> Output Class Initialized
INFO - 2016-11-30 12:57:12 --> Security Class Initialized
DEBUG - 2016-11-30 12:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:57:12 --> Input Class Initialized
INFO - 2016-11-30 12:57:12 --> Language Class Initialized
INFO - 2016-11-30 12:57:12 --> Loader Class Initialized
INFO - 2016-11-30 12:57:12 --> Helper loaded: url_helper
INFO - 2016-11-30 12:57:12 --> Helper loaded: form_helper
INFO - 2016-11-30 12:57:12 --> Database Driver Class Initialized
INFO - 2016-11-30 12:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:57:12 --> Controller Class Initialized
INFO - 2016-11-30 12:57:12 --> Model Class Initialized
INFO - 2016-11-30 12:57:12 --> Model Class Initialized
INFO - 2016-11-30 12:57:12 --> Model Class Initialized
INFO - 2016-11-30 12:57:12 --> Model Class Initialized
INFO - 2016-11-30 12:57:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:57:12 --> Pagination Class Initialized
INFO - 2016-11-30 12:57:12 --> Helper loaded: app_helper
DEBUG - 2016-11-30 12:57:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-30 12:57:12 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-30 12:57:12 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-30 12:57:12 --> Config Class Initialized
INFO - 2016-11-30 12:57:12 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:57:12 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:57:12 --> Utf8 Class Initialized
INFO - 2016-11-30 12:57:12 --> URI Class Initialized
DEBUG - 2016-11-30 12:57:12 --> No URI present. Default controller set.
INFO - 2016-11-30 12:57:12 --> Router Class Initialized
INFO - 2016-11-30 12:57:12 --> Output Class Initialized
INFO - 2016-11-30 12:57:12 --> Security Class Initialized
DEBUG - 2016-11-30 12:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:57:12 --> Input Class Initialized
INFO - 2016-11-30 12:57:12 --> Language Class Initialized
INFO - 2016-11-30 12:57:12 --> Loader Class Initialized
INFO - 2016-11-30 12:57:12 --> Helper loaded: url_helper
INFO - 2016-11-30 12:57:12 --> Helper loaded: form_helper
INFO - 2016-11-30 12:57:12 --> Database Driver Class Initialized
INFO - 2016-11-30 12:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:57:12 --> Controller Class Initialized
INFO - 2016-11-30 12:57:12 --> Model Class Initialized
INFO - 2016-11-30 12:57:12 --> Model Class Initialized
INFO - 2016-11-30 12:57:12 --> Model Class Initialized
INFO - 2016-11-30 12:57:12 --> Model Class Initialized
INFO - 2016-11-30 12:57:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:57:12 --> Pagination Class Initialized
INFO - 2016-11-30 12:57:12 --> Helper loaded: app_helper
INFO - 2016-11-30 12:57:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 12:57:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-30 12:57:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 12:57:12 --> Final output sent to browser
DEBUG - 2016-11-30 12:57:12 --> Total execution time: 0.4804
INFO - 2016-11-30 12:57:28 --> Config Class Initialized
INFO - 2016-11-30 12:57:28 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:57:28 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:57:28 --> Utf8 Class Initialized
INFO - 2016-11-30 12:57:28 --> URI Class Initialized
INFO - 2016-11-30 12:57:28 --> Router Class Initialized
INFO - 2016-11-30 12:57:28 --> Output Class Initialized
INFO - 2016-11-30 12:57:28 --> Security Class Initialized
DEBUG - 2016-11-30 12:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:57:28 --> Input Class Initialized
INFO - 2016-11-30 12:57:28 --> Language Class Initialized
INFO - 2016-11-30 12:57:28 --> Loader Class Initialized
INFO - 2016-11-30 12:57:28 --> Helper loaded: url_helper
INFO - 2016-11-30 12:57:28 --> Helper loaded: form_helper
INFO - 2016-11-30 12:57:28 --> Database Driver Class Initialized
INFO - 2016-11-30 12:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:57:28 --> Controller Class Initialized
INFO - 2016-11-30 12:57:28 --> Model Class Initialized
INFO - 2016-11-30 12:57:28 --> Model Class Initialized
INFO - 2016-11-30 12:57:28 --> Model Class Initialized
INFO - 2016-11-30 12:57:28 --> Model Class Initialized
INFO - 2016-11-30 12:57:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:57:28 --> Pagination Class Initialized
INFO - 2016-11-30 12:57:28 --> Helper loaded: app_helper
DEBUG - 2016-11-30 12:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 12:57:28 --> Model Class Initialized
INFO - 2016-11-30 12:57:28 --> Final output sent to browser
DEBUG - 2016-11-30 12:57:28 --> Total execution time: 0.4935
INFO - 2016-11-30 12:57:28 --> Config Class Initialized
INFO - 2016-11-30 12:57:28 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:57:28 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:57:28 --> Utf8 Class Initialized
INFO - 2016-11-30 12:57:28 --> URI Class Initialized
DEBUG - 2016-11-30 12:57:28 --> No URI present. Default controller set.
INFO - 2016-11-30 12:57:28 --> Router Class Initialized
INFO - 2016-11-30 12:57:28 --> Output Class Initialized
INFO - 2016-11-30 12:57:28 --> Security Class Initialized
DEBUG - 2016-11-30 12:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:57:28 --> Input Class Initialized
INFO - 2016-11-30 12:57:28 --> Language Class Initialized
INFO - 2016-11-30 12:57:28 --> Loader Class Initialized
INFO - 2016-11-30 12:57:28 --> Helper loaded: url_helper
INFO - 2016-11-30 12:57:28 --> Helper loaded: form_helper
INFO - 2016-11-30 12:57:28 --> Database Driver Class Initialized
INFO - 2016-11-30 12:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:57:28 --> Controller Class Initialized
INFO - 2016-11-30 12:57:28 --> Model Class Initialized
INFO - 2016-11-30 12:57:28 --> Model Class Initialized
INFO - 2016-11-30 12:57:28 --> Model Class Initialized
INFO - 2016-11-30 12:57:28 --> Model Class Initialized
INFO - 2016-11-30 12:57:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:57:28 --> Pagination Class Initialized
INFO - 2016-11-30 12:57:28 --> Helper loaded: app_helper
INFO - 2016-11-30 12:57:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 12:57:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 12:57:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 12:57:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 12:57:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 12:57:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 12:57:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 12:57:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 12:57:29 --> Final output sent to browser
DEBUG - 2016-11-30 12:57:29 --> Total execution time: 0.5609
INFO - 2016-11-30 12:57:56 --> Config Class Initialized
INFO - 2016-11-30 12:57:56 --> Hooks Class Initialized
DEBUG - 2016-11-30 12:57:56 --> UTF-8 Support Enabled
INFO - 2016-11-30 12:57:56 --> Utf8 Class Initialized
INFO - 2016-11-30 12:57:56 --> URI Class Initialized
INFO - 2016-11-30 12:57:56 --> Router Class Initialized
INFO - 2016-11-30 12:57:56 --> Output Class Initialized
INFO - 2016-11-30 12:57:56 --> Security Class Initialized
DEBUG - 2016-11-30 12:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 12:57:56 --> Input Class Initialized
INFO - 2016-11-30 12:57:56 --> Language Class Initialized
INFO - 2016-11-30 12:57:56 --> Loader Class Initialized
INFO - 2016-11-30 12:57:56 --> Helper loaded: url_helper
INFO - 2016-11-30 12:57:56 --> Helper loaded: form_helper
INFO - 2016-11-30 12:57:56 --> Database Driver Class Initialized
INFO - 2016-11-30 12:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 12:57:57 --> Controller Class Initialized
INFO - 2016-11-30 12:57:57 --> Model Class Initialized
INFO - 2016-11-30 12:57:57 --> Form Validation Class Initialized
INFO - 2016-11-30 12:57:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 12:57:57 --> Pagination Class Initialized
INFO - 2016-11-30 12:57:57 --> Helper loaded: app_helper
INFO - 2016-11-30 12:57:57 --> Email Class Initialized
INFO - 2016-11-30 12:57:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 11:57:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 11:57:57 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 11:57:57 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-30 11:57:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-30 11:57:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 11:57:59 --> Final output sent to browser
DEBUG - 2016-11-30 11:57:59 --> Total execution time: 2.6597
INFO - 2016-11-30 13:06:44 --> Config Class Initialized
INFO - 2016-11-30 13:06:44 --> Hooks Class Initialized
DEBUG - 2016-11-30 13:06:44 --> UTF-8 Support Enabled
INFO - 2016-11-30 13:06:44 --> Utf8 Class Initialized
INFO - 2016-11-30 13:06:44 --> URI Class Initialized
INFO - 2016-11-30 13:06:44 --> Router Class Initialized
INFO - 2016-11-30 13:06:44 --> Output Class Initialized
INFO - 2016-11-30 13:06:44 --> Security Class Initialized
DEBUG - 2016-11-30 13:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 13:06:44 --> Input Class Initialized
INFO - 2016-11-30 13:06:44 --> Language Class Initialized
INFO - 2016-11-30 13:06:44 --> Loader Class Initialized
INFO - 2016-11-30 13:06:44 --> Helper loaded: url_helper
INFO - 2016-11-30 13:06:44 --> Helper loaded: form_helper
INFO - 2016-11-30 13:06:44 --> Database Driver Class Initialized
INFO - 2016-11-30 13:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 13:06:44 --> Controller Class Initialized
INFO - 2016-11-30 13:06:44 --> Model Class Initialized
INFO - 2016-11-30 13:06:44 --> Form Validation Class Initialized
INFO - 2016-11-30 13:06:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 13:06:45 --> Pagination Class Initialized
INFO - 2016-11-30 13:06:45 --> Helper loaded: app_helper
INFO - 2016-11-30 13:06:45 --> Email Class Initialized
INFO - 2016-11-30 13:06:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 13:06:45 --> Final output sent to browser
DEBUG - 2016-11-30 13:06:45 --> Total execution time: 0.4681
INFO - 2016-11-30 13:07:05 --> Config Class Initialized
INFO - 2016-11-30 13:07:05 --> Hooks Class Initialized
DEBUG - 2016-11-30 13:07:05 --> UTF-8 Support Enabled
INFO - 2016-11-30 13:07:05 --> Utf8 Class Initialized
INFO - 2016-11-30 13:07:05 --> URI Class Initialized
DEBUG - 2016-11-30 13:07:05 --> No URI present. Default controller set.
INFO - 2016-11-30 13:07:05 --> Router Class Initialized
INFO - 2016-11-30 13:07:05 --> Output Class Initialized
INFO - 2016-11-30 13:07:05 --> Security Class Initialized
DEBUG - 2016-11-30 13:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 13:07:05 --> Input Class Initialized
INFO - 2016-11-30 13:07:05 --> Language Class Initialized
INFO - 2016-11-30 13:07:05 --> Loader Class Initialized
INFO - 2016-11-30 13:07:05 --> Helper loaded: url_helper
INFO - 2016-11-30 13:07:05 --> Helper loaded: form_helper
INFO - 2016-11-30 13:07:05 --> Database Driver Class Initialized
INFO - 2016-11-30 13:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 13:07:05 --> Controller Class Initialized
INFO - 2016-11-30 13:07:05 --> Model Class Initialized
INFO - 2016-11-30 13:07:05 --> Model Class Initialized
INFO - 2016-11-30 13:07:05 --> Model Class Initialized
INFO - 2016-11-30 13:07:05 --> Model Class Initialized
INFO - 2016-11-30 13:07:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 13:07:05 --> Pagination Class Initialized
INFO - 2016-11-30 13:07:05 --> Helper loaded: app_helper
INFO - 2016-11-30 13:07:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 13:07:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 13:07:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 13:07:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 13:07:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 13:07:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 13:07:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 13:07:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 13:07:05 --> Final output sent to browser
DEBUG - 2016-11-30 13:07:05 --> Total execution time: 0.6078
INFO - 2016-11-30 13:08:18 --> Config Class Initialized
INFO - 2016-11-30 13:08:18 --> Hooks Class Initialized
DEBUG - 2016-11-30 13:08:18 --> UTF-8 Support Enabled
INFO - 2016-11-30 13:08:18 --> Utf8 Class Initialized
INFO - 2016-11-30 13:08:18 --> URI Class Initialized
DEBUG - 2016-11-30 13:08:18 --> No URI present. Default controller set.
INFO - 2016-11-30 13:08:18 --> Router Class Initialized
INFO - 2016-11-30 13:08:18 --> Output Class Initialized
INFO - 2016-11-30 13:08:18 --> Security Class Initialized
DEBUG - 2016-11-30 13:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 13:08:18 --> Input Class Initialized
INFO - 2016-11-30 13:08:18 --> Language Class Initialized
INFO - 2016-11-30 13:08:18 --> Loader Class Initialized
INFO - 2016-11-30 13:08:18 --> Helper loaded: url_helper
INFO - 2016-11-30 13:08:19 --> Helper loaded: form_helper
INFO - 2016-11-30 13:08:19 --> Database Driver Class Initialized
INFO - 2016-11-30 13:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 13:08:19 --> Controller Class Initialized
INFO - 2016-11-30 13:08:19 --> Model Class Initialized
INFO - 2016-11-30 13:08:19 --> Model Class Initialized
INFO - 2016-11-30 13:08:19 --> Model Class Initialized
INFO - 2016-11-30 13:08:19 --> Model Class Initialized
INFO - 2016-11-30 13:08:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 13:08:19 --> Pagination Class Initialized
INFO - 2016-11-30 13:08:19 --> Helper loaded: app_helper
INFO - 2016-11-30 13:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 13:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 13:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 13:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 13:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 13:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 13:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 13:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 13:08:19 --> Final output sent to browser
DEBUG - 2016-11-30 13:08:19 --> Total execution time: 0.6252
INFO - 2016-11-30 13:13:04 --> Config Class Initialized
INFO - 2016-11-30 13:13:04 --> Hooks Class Initialized
DEBUG - 2016-11-30 13:13:04 --> UTF-8 Support Enabled
INFO - 2016-11-30 13:13:04 --> Utf8 Class Initialized
INFO - 2016-11-30 13:13:04 --> URI Class Initialized
DEBUG - 2016-11-30 13:13:04 --> No URI present. Default controller set.
INFO - 2016-11-30 13:13:04 --> Router Class Initialized
INFO - 2016-11-30 13:13:04 --> Output Class Initialized
INFO - 2016-11-30 13:13:04 --> Security Class Initialized
DEBUG - 2016-11-30 13:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 13:13:04 --> Input Class Initialized
INFO - 2016-11-30 13:13:04 --> Language Class Initialized
INFO - 2016-11-30 13:13:04 --> Loader Class Initialized
INFO - 2016-11-30 13:13:04 --> Helper loaded: url_helper
INFO - 2016-11-30 13:13:04 --> Helper loaded: form_helper
INFO - 2016-11-30 13:13:04 --> Database Driver Class Initialized
INFO - 2016-11-30 13:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 13:13:05 --> Controller Class Initialized
INFO - 2016-11-30 13:13:05 --> Model Class Initialized
INFO - 2016-11-30 13:13:05 --> Model Class Initialized
INFO - 2016-11-30 13:13:05 --> Model Class Initialized
INFO - 2016-11-30 13:13:05 --> Model Class Initialized
INFO - 2016-11-30 13:13:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 13:13:05 --> Pagination Class Initialized
INFO - 2016-11-30 13:13:05 --> Helper loaded: app_helper
INFO - 2016-11-30 13:13:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 13:13:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 13:13:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 13:13:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 13:13:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 13:13:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 13:13:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 13:13:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 13:13:05 --> Final output sent to browser
DEBUG - 2016-11-30 13:13:05 --> Total execution time: 0.6775
INFO - 2016-11-30 13:13:28 --> Config Class Initialized
INFO - 2016-11-30 13:13:28 --> Hooks Class Initialized
DEBUG - 2016-11-30 13:13:28 --> UTF-8 Support Enabled
INFO - 2016-11-30 13:13:28 --> Utf8 Class Initialized
INFO - 2016-11-30 13:13:28 --> URI Class Initialized
INFO - 2016-11-30 13:13:28 --> Router Class Initialized
INFO - 2016-11-30 13:13:28 --> Output Class Initialized
INFO - 2016-11-30 13:13:28 --> Security Class Initialized
DEBUG - 2016-11-30 13:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 13:13:28 --> Input Class Initialized
INFO - 2016-11-30 13:13:28 --> Language Class Initialized
INFO - 2016-11-30 13:13:28 --> Loader Class Initialized
INFO - 2016-11-30 13:13:28 --> Helper loaded: url_helper
INFO - 2016-11-30 13:13:28 --> Helper loaded: form_helper
INFO - 2016-11-30 13:13:28 --> Database Driver Class Initialized
INFO - 2016-11-30 13:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 13:13:28 --> Controller Class Initialized
INFO - 2016-11-30 13:13:28 --> Model Class Initialized
INFO - 2016-11-30 13:13:28 --> Form Validation Class Initialized
INFO - 2016-11-30 13:13:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 13:13:28 --> Pagination Class Initialized
INFO - 2016-11-30 13:13:28 --> Helper loaded: app_helper
INFO - 2016-11-30 13:13:28 --> Email Class Initialized
INFO - 2016-11-30 13:13:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 13:13:28 --> Final output sent to browser
DEBUG - 2016-11-30 13:13:28 --> Total execution time: 0.4066
INFO - 2016-11-30 13:13:55 --> Config Class Initialized
INFO - 2016-11-30 13:13:55 --> Hooks Class Initialized
DEBUG - 2016-11-30 13:13:55 --> UTF-8 Support Enabled
INFO - 2016-11-30 13:13:55 --> Utf8 Class Initialized
INFO - 2016-11-30 13:13:55 --> URI Class Initialized
INFO - 2016-11-30 13:13:55 --> Router Class Initialized
INFO - 2016-11-30 13:13:55 --> Output Class Initialized
INFO - 2016-11-30 13:13:55 --> Security Class Initialized
DEBUG - 2016-11-30 13:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 13:13:55 --> Input Class Initialized
INFO - 2016-11-30 13:13:55 --> Language Class Initialized
INFO - 2016-11-30 13:13:55 --> Loader Class Initialized
INFO - 2016-11-30 13:13:55 --> Helper loaded: url_helper
INFO - 2016-11-30 13:13:55 --> Helper loaded: form_helper
INFO - 2016-11-30 13:13:56 --> Database Driver Class Initialized
INFO - 2016-11-30 13:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 13:13:56 --> Controller Class Initialized
INFO - 2016-11-30 13:13:56 --> Model Class Initialized
INFO - 2016-11-30 13:13:56 --> Form Validation Class Initialized
INFO - 2016-11-30 13:13:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 13:13:56 --> Pagination Class Initialized
INFO - 2016-11-30 13:13:56 --> Helper loaded: app_helper
INFO - 2016-11-30 13:13:56 --> Email Class Initialized
INFO - 2016-11-30 13:13:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 13:13:56 --> Final output sent to browser
DEBUG - 2016-11-30 13:13:56 --> Total execution time: 0.3864
INFO - 2016-11-30 13:14:07 --> Config Class Initialized
INFO - 2016-11-30 13:14:07 --> Hooks Class Initialized
DEBUG - 2016-11-30 13:14:07 --> UTF-8 Support Enabled
INFO - 2016-11-30 13:14:07 --> Utf8 Class Initialized
INFO - 2016-11-30 13:14:07 --> URI Class Initialized
DEBUG - 2016-11-30 13:14:07 --> No URI present. Default controller set.
INFO - 2016-11-30 13:14:07 --> Router Class Initialized
INFO - 2016-11-30 13:14:07 --> Output Class Initialized
INFO - 2016-11-30 13:14:07 --> Security Class Initialized
DEBUG - 2016-11-30 13:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 13:14:07 --> Input Class Initialized
INFO - 2016-11-30 13:14:07 --> Language Class Initialized
INFO - 2016-11-30 13:14:07 --> Loader Class Initialized
INFO - 2016-11-30 13:14:07 --> Helper loaded: url_helper
INFO - 2016-11-30 13:14:07 --> Helper loaded: form_helper
INFO - 2016-11-30 13:14:07 --> Database Driver Class Initialized
INFO - 2016-11-30 13:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 13:14:07 --> Controller Class Initialized
INFO - 2016-11-30 13:14:07 --> Model Class Initialized
INFO - 2016-11-30 13:14:07 --> Model Class Initialized
INFO - 2016-11-30 13:14:07 --> Model Class Initialized
INFO - 2016-11-30 13:14:07 --> Model Class Initialized
INFO - 2016-11-30 13:14:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 13:14:07 --> Pagination Class Initialized
INFO - 2016-11-30 13:14:07 --> Helper loaded: app_helper
INFO - 2016-11-30 13:14:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 13:14:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 13:14:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 13:14:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 13:14:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 13:14:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 13:14:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 13:14:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 13:14:07 --> Final output sent to browser
DEBUG - 2016-11-30 13:14:07 --> Total execution time: 0.6663
INFO - 2016-11-30 13:14:29 --> Config Class Initialized
INFO - 2016-11-30 13:14:29 --> Hooks Class Initialized
DEBUG - 2016-11-30 13:14:29 --> UTF-8 Support Enabled
INFO - 2016-11-30 13:14:29 --> Utf8 Class Initialized
INFO - 2016-11-30 13:14:29 --> URI Class Initialized
DEBUG - 2016-11-30 13:14:29 --> No URI present. Default controller set.
INFO - 2016-11-30 13:14:29 --> Router Class Initialized
INFO - 2016-11-30 13:14:29 --> Output Class Initialized
INFO - 2016-11-30 13:14:29 --> Security Class Initialized
DEBUG - 2016-11-30 13:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 13:14:29 --> Input Class Initialized
INFO - 2016-11-30 13:14:29 --> Language Class Initialized
INFO - 2016-11-30 13:14:29 --> Loader Class Initialized
INFO - 2016-11-30 13:14:29 --> Helper loaded: url_helper
INFO - 2016-11-30 13:14:29 --> Helper loaded: form_helper
INFO - 2016-11-30 13:14:29 --> Database Driver Class Initialized
INFO - 2016-11-30 13:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 13:14:29 --> Controller Class Initialized
INFO - 2016-11-30 13:14:29 --> Model Class Initialized
INFO - 2016-11-30 13:14:29 --> Model Class Initialized
INFO - 2016-11-30 13:14:29 --> Model Class Initialized
INFO - 2016-11-30 13:14:29 --> Model Class Initialized
INFO - 2016-11-30 13:14:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 13:14:29 --> Pagination Class Initialized
INFO - 2016-11-30 13:14:29 --> Helper loaded: app_helper
INFO - 2016-11-30 13:14:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 13:14:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 13:14:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 13:14:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 13:14:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 13:14:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 13:14:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 13:14:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 13:14:29 --> Final output sent to browser
DEBUG - 2016-11-30 13:14:29 --> Total execution time: 0.6298
INFO - 2016-11-30 13:21:06 --> Config Class Initialized
INFO - 2016-11-30 13:21:06 --> Hooks Class Initialized
DEBUG - 2016-11-30 13:21:06 --> UTF-8 Support Enabled
INFO - 2016-11-30 13:21:06 --> Utf8 Class Initialized
INFO - 2016-11-30 13:21:06 --> URI Class Initialized
DEBUG - 2016-11-30 13:21:06 --> No URI present. Default controller set.
INFO - 2016-11-30 13:21:06 --> Router Class Initialized
INFO - 2016-11-30 13:21:06 --> Output Class Initialized
INFO - 2016-11-30 13:21:06 --> Security Class Initialized
DEBUG - 2016-11-30 13:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 13:21:06 --> Input Class Initialized
INFO - 2016-11-30 13:21:06 --> Language Class Initialized
INFO - 2016-11-30 13:21:06 --> Loader Class Initialized
INFO - 2016-11-30 13:21:06 --> Helper loaded: url_helper
INFO - 2016-11-30 13:21:06 --> Helper loaded: form_helper
INFO - 2016-11-30 13:21:06 --> Database Driver Class Initialized
INFO - 2016-11-30 13:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 13:21:06 --> Controller Class Initialized
INFO - 2016-11-30 13:21:06 --> Model Class Initialized
INFO - 2016-11-30 13:21:06 --> Model Class Initialized
INFO - 2016-11-30 13:21:06 --> Model Class Initialized
INFO - 2016-11-30 13:21:06 --> Model Class Initialized
INFO - 2016-11-30 13:21:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 13:21:07 --> Pagination Class Initialized
INFO - 2016-11-30 13:21:07 --> Helper loaded: app_helper
INFO - 2016-11-30 13:21:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 13:21:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 13:21:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 13:21:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 13:21:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 13:21:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 13:21:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 13:21:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 13:21:07 --> Final output sent to browser
DEBUG - 2016-11-30 13:21:07 --> Total execution time: 0.7405
INFO - 2016-11-30 13:21:45 --> Config Class Initialized
INFO - 2016-11-30 13:21:45 --> Hooks Class Initialized
DEBUG - 2016-11-30 13:21:45 --> UTF-8 Support Enabled
INFO - 2016-11-30 13:21:45 --> Utf8 Class Initialized
INFO - 2016-11-30 13:21:45 --> URI Class Initialized
INFO - 2016-11-30 13:21:45 --> Router Class Initialized
INFO - 2016-11-30 13:21:45 --> Output Class Initialized
INFO - 2016-11-30 13:21:45 --> Security Class Initialized
DEBUG - 2016-11-30 13:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 13:21:45 --> Input Class Initialized
INFO - 2016-11-30 13:21:45 --> Language Class Initialized
INFO - 2016-11-30 13:21:45 --> Loader Class Initialized
INFO - 2016-11-30 13:21:45 --> Helper loaded: url_helper
INFO - 2016-11-30 13:21:45 --> Helper loaded: form_helper
INFO - 2016-11-30 13:21:45 --> Database Driver Class Initialized
INFO - 2016-11-30 13:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 13:21:45 --> Controller Class Initialized
INFO - 2016-11-30 13:21:45 --> Model Class Initialized
INFO - 2016-11-30 13:21:45 --> Model Class Initialized
INFO - 2016-11-30 13:21:45 --> Model Class Initialized
INFO - 2016-11-30 13:21:45 --> Model Class Initialized
INFO - 2016-11-30 13:21:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 13:21:45 --> Pagination Class Initialized
INFO - 2016-11-30 13:21:45 --> Helper loaded: app_helper
DEBUG - 2016-11-30 13:21:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-30 13:21:45 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-30 13:21:45 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-30 13:21:45 --> Config Class Initialized
INFO - 2016-11-30 13:21:45 --> Hooks Class Initialized
DEBUG - 2016-11-30 13:21:45 --> UTF-8 Support Enabled
INFO - 2016-11-30 13:21:45 --> Utf8 Class Initialized
INFO - 2016-11-30 13:21:45 --> URI Class Initialized
DEBUG - 2016-11-30 13:21:45 --> No URI present. Default controller set.
INFO - 2016-11-30 13:21:45 --> Router Class Initialized
INFO - 2016-11-30 13:21:45 --> Output Class Initialized
INFO - 2016-11-30 13:21:45 --> Security Class Initialized
DEBUG - 2016-11-30 13:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 13:21:45 --> Input Class Initialized
INFO - 2016-11-30 13:21:45 --> Language Class Initialized
INFO - 2016-11-30 13:21:45 --> Loader Class Initialized
INFO - 2016-11-30 13:21:45 --> Helper loaded: url_helper
INFO - 2016-11-30 13:21:45 --> Helper loaded: form_helper
INFO - 2016-11-30 13:21:45 --> Database Driver Class Initialized
INFO - 2016-11-30 13:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 13:21:45 --> Controller Class Initialized
INFO - 2016-11-30 13:21:45 --> Model Class Initialized
INFO - 2016-11-30 13:21:45 --> Model Class Initialized
INFO - 2016-11-30 13:21:45 --> Model Class Initialized
INFO - 2016-11-30 13:21:45 --> Model Class Initialized
INFO - 2016-11-30 13:21:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 13:21:45 --> Pagination Class Initialized
INFO - 2016-11-30 13:21:45 --> Helper loaded: app_helper
INFO - 2016-11-30 13:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 13:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-30 13:21:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 13:21:46 --> Final output sent to browser
DEBUG - 2016-11-30 13:21:46 --> Total execution time: 0.4982
INFO - 2016-11-30 13:21:55 --> Config Class Initialized
INFO - 2016-11-30 13:21:55 --> Hooks Class Initialized
DEBUG - 2016-11-30 13:21:55 --> UTF-8 Support Enabled
INFO - 2016-11-30 13:21:55 --> Utf8 Class Initialized
INFO - 2016-11-30 13:21:55 --> URI Class Initialized
INFO - 2016-11-30 13:21:55 --> Router Class Initialized
INFO - 2016-11-30 13:21:55 --> Output Class Initialized
INFO - 2016-11-30 13:21:55 --> Security Class Initialized
DEBUG - 2016-11-30 13:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 13:21:55 --> Input Class Initialized
INFO - 2016-11-30 13:21:55 --> Language Class Initialized
INFO - 2016-11-30 13:21:56 --> Loader Class Initialized
INFO - 2016-11-30 13:21:56 --> Helper loaded: url_helper
INFO - 2016-11-30 13:21:56 --> Helper loaded: form_helper
INFO - 2016-11-30 13:21:56 --> Database Driver Class Initialized
INFO - 2016-11-30 13:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 13:21:56 --> Controller Class Initialized
INFO - 2016-11-30 13:21:56 --> Model Class Initialized
INFO - 2016-11-30 13:21:56 --> Model Class Initialized
INFO - 2016-11-30 13:21:56 --> Model Class Initialized
INFO - 2016-11-30 13:21:56 --> Model Class Initialized
INFO - 2016-11-30 13:21:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 13:21:56 --> Pagination Class Initialized
INFO - 2016-11-30 13:21:56 --> Helper loaded: app_helper
DEBUG - 2016-11-30 13:21:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 13:21:56 --> Model Class Initialized
INFO - 2016-11-30 13:21:56 --> Final output sent to browser
DEBUG - 2016-11-30 13:21:56 --> Total execution time: 0.4517
INFO - 2016-11-30 13:21:56 --> Config Class Initialized
INFO - 2016-11-30 13:21:56 --> Hooks Class Initialized
DEBUG - 2016-11-30 13:21:56 --> UTF-8 Support Enabled
INFO - 2016-11-30 13:21:56 --> Utf8 Class Initialized
INFO - 2016-11-30 13:21:56 --> URI Class Initialized
DEBUG - 2016-11-30 13:21:56 --> No URI present. Default controller set.
INFO - 2016-11-30 13:21:56 --> Router Class Initialized
INFO - 2016-11-30 13:21:56 --> Output Class Initialized
INFO - 2016-11-30 13:21:56 --> Security Class Initialized
DEBUG - 2016-11-30 13:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 13:21:56 --> Input Class Initialized
INFO - 2016-11-30 13:21:56 --> Language Class Initialized
INFO - 2016-11-30 13:21:56 --> Loader Class Initialized
INFO - 2016-11-30 13:21:56 --> Helper loaded: url_helper
INFO - 2016-11-30 13:21:56 --> Helper loaded: form_helper
INFO - 2016-11-30 13:21:56 --> Database Driver Class Initialized
INFO - 2016-11-30 13:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 13:21:56 --> Controller Class Initialized
INFO - 2016-11-30 13:21:56 --> Model Class Initialized
INFO - 2016-11-30 13:21:56 --> Model Class Initialized
INFO - 2016-11-30 13:21:56 --> Model Class Initialized
INFO - 2016-11-30 13:21:56 --> Model Class Initialized
INFO - 2016-11-30 13:21:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 13:21:56 --> Pagination Class Initialized
INFO - 2016-11-30 13:21:56 --> Helper loaded: app_helper
INFO - 2016-11-30 13:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 13:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 13:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 13:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 13:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 13:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 13:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 13:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 13:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 13:21:56 --> Final output sent to browser
DEBUG - 2016-11-30 13:21:56 --> Total execution time: 0.6300
INFO - 2016-11-30 13:22:12 --> Config Class Initialized
INFO - 2016-11-30 13:22:12 --> Hooks Class Initialized
DEBUG - 2016-11-30 13:22:12 --> UTF-8 Support Enabled
INFO - 2016-11-30 13:22:12 --> Utf8 Class Initialized
INFO - 2016-11-30 13:22:12 --> URI Class Initialized
INFO - 2016-11-30 13:22:12 --> Router Class Initialized
INFO - 2016-11-30 13:22:12 --> Output Class Initialized
INFO - 2016-11-30 13:22:12 --> Security Class Initialized
DEBUG - 2016-11-30 13:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 13:22:12 --> Input Class Initialized
INFO - 2016-11-30 13:22:12 --> Language Class Initialized
INFO - 2016-11-30 13:22:13 --> Loader Class Initialized
INFO - 2016-11-30 13:22:13 --> Helper loaded: url_helper
INFO - 2016-11-30 13:22:13 --> Helper loaded: form_helper
INFO - 2016-11-30 13:22:13 --> Database Driver Class Initialized
INFO - 2016-11-30 13:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 13:22:13 --> Controller Class Initialized
INFO - 2016-11-30 13:22:13 --> Model Class Initialized
INFO - 2016-11-30 13:22:13 --> Form Validation Class Initialized
INFO - 2016-11-30 13:22:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 13:22:13 --> Pagination Class Initialized
INFO - 2016-11-30 13:22:13 --> Helper loaded: app_helper
INFO - 2016-11-30 13:22:13 --> Email Class Initialized
INFO - 2016-11-30 13:22:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 12:22:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 12:22:13 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 12:22:13 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-30 12:22:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-30 12:22:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 12:22:15 --> Final output sent to browser
DEBUG - 2016-11-30 12:22:15 --> Total execution time: 2.4607
INFO - 2016-11-30 13:24:29 --> Config Class Initialized
INFO - 2016-11-30 13:24:29 --> Hooks Class Initialized
DEBUG - 2016-11-30 13:24:29 --> UTF-8 Support Enabled
INFO - 2016-11-30 13:24:29 --> Utf8 Class Initialized
INFO - 2016-11-30 13:24:29 --> URI Class Initialized
INFO - 2016-11-30 13:24:29 --> Router Class Initialized
INFO - 2016-11-30 13:24:29 --> Output Class Initialized
INFO - 2016-11-30 13:24:29 --> Security Class Initialized
DEBUG - 2016-11-30 13:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 13:24:30 --> Input Class Initialized
INFO - 2016-11-30 13:24:30 --> Language Class Initialized
INFO - 2016-11-30 13:24:30 --> Loader Class Initialized
INFO - 2016-11-30 13:24:30 --> Helper loaded: url_helper
INFO - 2016-11-30 13:24:30 --> Helper loaded: form_helper
INFO - 2016-11-30 13:24:30 --> Database Driver Class Initialized
INFO - 2016-11-30 13:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 13:24:30 --> Controller Class Initialized
INFO - 2016-11-30 13:24:30 --> Model Class Initialized
INFO - 2016-11-30 13:24:30 --> Form Validation Class Initialized
INFO - 2016-11-30 13:24:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 13:24:30 --> Pagination Class Initialized
INFO - 2016-11-30 13:24:30 --> Helper loaded: app_helper
INFO - 2016-11-30 13:24:30 --> Email Class Initialized
INFO - 2016-11-30 13:24:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 13:24:30 --> Final output sent to browser
DEBUG - 2016-11-30 13:24:30 --> Total execution time: 0.7718
INFO - 2016-11-30 13:24:37 --> Config Class Initialized
INFO - 2016-11-30 13:24:37 --> Hooks Class Initialized
DEBUG - 2016-11-30 13:24:37 --> UTF-8 Support Enabled
INFO - 2016-11-30 13:24:37 --> Utf8 Class Initialized
INFO - 2016-11-30 13:24:37 --> URI Class Initialized
DEBUG - 2016-11-30 13:24:37 --> No URI present. Default controller set.
INFO - 2016-11-30 13:24:37 --> Router Class Initialized
INFO - 2016-11-30 13:24:37 --> Output Class Initialized
INFO - 2016-11-30 13:24:37 --> Security Class Initialized
DEBUG - 2016-11-30 13:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 13:24:37 --> Input Class Initialized
INFO - 2016-11-30 13:24:37 --> Language Class Initialized
INFO - 2016-11-30 13:24:37 --> Loader Class Initialized
INFO - 2016-11-30 13:24:37 --> Helper loaded: url_helper
INFO - 2016-11-30 13:24:37 --> Helper loaded: form_helper
INFO - 2016-11-30 13:24:37 --> Database Driver Class Initialized
INFO - 2016-11-30 13:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 13:24:37 --> Controller Class Initialized
INFO - 2016-11-30 13:24:37 --> Model Class Initialized
INFO - 2016-11-30 13:24:37 --> Model Class Initialized
INFO - 2016-11-30 13:24:37 --> Model Class Initialized
INFO - 2016-11-30 13:24:37 --> Model Class Initialized
INFO - 2016-11-30 13:24:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 13:24:38 --> Pagination Class Initialized
INFO - 2016-11-30 13:24:38 --> Helper loaded: app_helper
INFO - 2016-11-30 13:24:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 13:24:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 13:24:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 13:24:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 13:24:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 13:24:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 13:24:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 13:24:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 13:24:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 13:24:38 --> Final output sent to browser
DEBUG - 2016-11-30 13:24:38 --> Total execution time: 0.7086
INFO - 2016-11-30 13:24:48 --> Config Class Initialized
INFO - 2016-11-30 13:24:48 --> Hooks Class Initialized
DEBUG - 2016-11-30 13:24:48 --> UTF-8 Support Enabled
INFO - 2016-11-30 13:24:48 --> Utf8 Class Initialized
INFO - 2016-11-30 13:24:48 --> URI Class Initialized
INFO - 2016-11-30 13:24:48 --> Router Class Initialized
INFO - 2016-11-30 13:24:48 --> Output Class Initialized
INFO - 2016-11-30 13:24:48 --> Security Class Initialized
DEBUG - 2016-11-30 13:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 13:24:48 --> Input Class Initialized
INFO - 2016-11-30 13:24:48 --> Language Class Initialized
INFO - 2016-11-30 13:24:48 --> Loader Class Initialized
INFO - 2016-11-30 13:24:48 --> Helper loaded: url_helper
INFO - 2016-11-30 13:24:48 --> Helper loaded: form_helper
INFO - 2016-11-30 13:24:48 --> Database Driver Class Initialized
INFO - 2016-11-30 13:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 13:24:48 --> Controller Class Initialized
INFO - 2016-11-30 13:24:48 --> Model Class Initialized
INFO - 2016-11-30 13:24:48 --> Model Class Initialized
INFO - 2016-11-30 13:24:48 --> Model Class Initialized
INFO - 2016-11-30 13:24:48 --> Model Class Initialized
INFO - 2016-11-30 13:24:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 13:24:48 --> Pagination Class Initialized
INFO - 2016-11-30 13:24:48 --> Helper loaded: app_helper
DEBUG - 2016-11-30 13:24:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-30 13:24:48 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-30 13:24:48 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-30 13:24:48 --> Config Class Initialized
INFO - 2016-11-30 13:24:48 --> Hooks Class Initialized
DEBUG - 2016-11-30 13:24:48 --> UTF-8 Support Enabled
INFO - 2016-11-30 13:24:48 --> Utf8 Class Initialized
INFO - 2016-11-30 13:24:48 --> URI Class Initialized
DEBUG - 2016-11-30 13:24:48 --> No URI present. Default controller set.
INFO - 2016-11-30 13:24:48 --> Router Class Initialized
INFO - 2016-11-30 13:24:48 --> Output Class Initialized
INFO - 2016-11-30 13:24:48 --> Security Class Initialized
DEBUG - 2016-11-30 13:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 13:24:48 --> Input Class Initialized
INFO - 2016-11-30 13:24:48 --> Language Class Initialized
INFO - 2016-11-30 13:24:48 --> Loader Class Initialized
INFO - 2016-11-30 13:24:48 --> Helper loaded: url_helper
INFO - 2016-11-30 13:24:48 --> Helper loaded: form_helper
INFO - 2016-11-30 13:24:48 --> Database Driver Class Initialized
INFO - 2016-11-30 13:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 13:24:48 --> Controller Class Initialized
INFO - 2016-11-30 13:24:48 --> Model Class Initialized
INFO - 2016-11-30 13:24:48 --> Model Class Initialized
INFO - 2016-11-30 13:24:48 --> Model Class Initialized
INFO - 2016-11-30 13:24:48 --> Model Class Initialized
INFO - 2016-11-30 13:24:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 13:24:49 --> Pagination Class Initialized
INFO - 2016-11-30 13:24:49 --> Helper loaded: app_helper
INFO - 2016-11-30 13:24:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 13:24:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-30 13:24:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 13:24:49 --> Final output sent to browser
DEBUG - 2016-11-30 13:24:49 --> Total execution time: 0.5031
INFO - 2016-11-30 13:24:58 --> Config Class Initialized
INFO - 2016-11-30 13:24:58 --> Hooks Class Initialized
DEBUG - 2016-11-30 13:24:58 --> UTF-8 Support Enabled
INFO - 2016-11-30 13:24:58 --> Utf8 Class Initialized
INFO - 2016-11-30 13:24:58 --> URI Class Initialized
INFO - 2016-11-30 13:24:58 --> Router Class Initialized
INFO - 2016-11-30 13:24:58 --> Output Class Initialized
INFO - 2016-11-30 13:24:58 --> Security Class Initialized
DEBUG - 2016-11-30 13:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 13:24:58 --> Input Class Initialized
INFO - 2016-11-30 13:24:58 --> Language Class Initialized
INFO - 2016-11-30 13:24:58 --> Loader Class Initialized
INFO - 2016-11-30 13:24:58 --> Helper loaded: url_helper
INFO - 2016-11-30 13:24:58 --> Helper loaded: form_helper
INFO - 2016-11-30 13:24:58 --> Database Driver Class Initialized
INFO - 2016-11-30 13:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 13:24:58 --> Controller Class Initialized
INFO - 2016-11-30 13:24:58 --> Model Class Initialized
INFO - 2016-11-30 13:24:58 --> Model Class Initialized
INFO - 2016-11-30 13:24:58 --> Model Class Initialized
INFO - 2016-11-30 13:24:58 --> Model Class Initialized
INFO - 2016-11-30 13:24:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 13:24:58 --> Pagination Class Initialized
INFO - 2016-11-30 13:24:58 --> Helper loaded: app_helper
DEBUG - 2016-11-30 13:24:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 13:24:58 --> Model Class Initialized
INFO - 2016-11-30 13:24:58 --> Final output sent to browser
DEBUG - 2016-11-30 13:24:58 --> Total execution time: 0.4574
INFO - 2016-11-30 13:24:58 --> Config Class Initialized
INFO - 2016-11-30 13:24:58 --> Hooks Class Initialized
DEBUG - 2016-11-30 13:24:58 --> UTF-8 Support Enabled
INFO - 2016-11-30 13:24:58 --> Utf8 Class Initialized
INFO - 2016-11-30 13:24:58 --> URI Class Initialized
DEBUG - 2016-11-30 13:24:58 --> No URI present. Default controller set.
INFO - 2016-11-30 13:24:58 --> Router Class Initialized
INFO - 2016-11-30 13:24:58 --> Output Class Initialized
INFO - 2016-11-30 13:24:58 --> Security Class Initialized
DEBUG - 2016-11-30 13:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 13:24:58 --> Input Class Initialized
INFO - 2016-11-30 13:24:59 --> Language Class Initialized
INFO - 2016-11-30 13:24:59 --> Loader Class Initialized
INFO - 2016-11-30 13:24:59 --> Helper loaded: url_helper
INFO - 2016-11-30 13:24:59 --> Helper loaded: form_helper
INFO - 2016-11-30 13:24:59 --> Database Driver Class Initialized
INFO - 2016-11-30 13:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 13:24:59 --> Controller Class Initialized
INFO - 2016-11-30 13:24:59 --> Model Class Initialized
INFO - 2016-11-30 13:24:59 --> Model Class Initialized
INFO - 2016-11-30 13:24:59 --> Model Class Initialized
INFO - 2016-11-30 13:24:59 --> Model Class Initialized
INFO - 2016-11-30 13:24:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 13:24:59 --> Pagination Class Initialized
INFO - 2016-11-30 13:24:59 --> Helper loaded: app_helper
INFO - 2016-11-30 13:24:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 13:24:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 13:24:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 13:24:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 13:24:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 13:24:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 13:24:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 13:24:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 13:24:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 13:24:59 --> Final output sent to browser
DEBUG - 2016-11-30 13:24:59 --> Total execution time: 0.6256
INFO - 2016-11-30 13:25:25 --> Config Class Initialized
INFO - 2016-11-30 13:25:25 --> Hooks Class Initialized
DEBUG - 2016-11-30 13:25:25 --> UTF-8 Support Enabled
INFO - 2016-11-30 13:25:25 --> Utf8 Class Initialized
INFO - 2016-11-30 13:25:25 --> URI Class Initialized
DEBUG - 2016-11-30 13:25:25 --> No URI present. Default controller set.
INFO - 2016-11-30 13:25:25 --> Router Class Initialized
INFO - 2016-11-30 13:25:25 --> Output Class Initialized
INFO - 2016-11-30 13:25:25 --> Security Class Initialized
DEBUG - 2016-11-30 13:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 13:25:25 --> Input Class Initialized
INFO - 2016-11-30 13:25:25 --> Language Class Initialized
INFO - 2016-11-30 13:25:26 --> Loader Class Initialized
INFO - 2016-11-30 13:25:26 --> Helper loaded: url_helper
INFO - 2016-11-30 13:25:26 --> Helper loaded: form_helper
INFO - 2016-11-30 13:25:26 --> Database Driver Class Initialized
INFO - 2016-11-30 13:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 13:25:26 --> Controller Class Initialized
INFO - 2016-11-30 13:25:26 --> Model Class Initialized
INFO - 2016-11-30 13:25:26 --> Model Class Initialized
INFO - 2016-11-30 13:25:26 --> Model Class Initialized
INFO - 2016-11-30 13:25:26 --> Model Class Initialized
INFO - 2016-11-30 13:25:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 13:25:26 --> Pagination Class Initialized
INFO - 2016-11-30 13:25:26 --> Helper loaded: app_helper
INFO - 2016-11-30 13:25:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 13:25:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 13:25:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 13:25:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 13:25:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 13:25:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 13:25:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 13:25:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 13:25:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 13:25:26 --> Final output sent to browser
DEBUG - 2016-11-30 13:25:26 --> Total execution time: 0.6892
INFO - 2016-11-30 14:23:24 --> Config Class Initialized
INFO - 2016-11-30 14:23:24 --> Hooks Class Initialized
DEBUG - 2016-11-30 14:23:24 --> UTF-8 Support Enabled
INFO - 2016-11-30 14:23:25 --> Utf8 Class Initialized
INFO - 2016-11-30 14:23:25 --> URI Class Initialized
DEBUG - 2016-11-30 14:23:25 --> No URI present. Default controller set.
INFO - 2016-11-30 14:23:25 --> Router Class Initialized
INFO - 2016-11-30 14:23:25 --> Output Class Initialized
INFO - 2016-11-30 14:23:25 --> Security Class Initialized
DEBUG - 2016-11-30 14:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 14:23:25 --> Input Class Initialized
INFO - 2016-11-30 14:23:25 --> Language Class Initialized
INFO - 2016-11-30 14:23:25 --> Loader Class Initialized
INFO - 2016-11-30 14:23:25 --> Helper loaded: url_helper
INFO - 2016-11-30 14:23:25 --> Helper loaded: form_helper
INFO - 2016-11-30 14:23:25 --> Database Driver Class Initialized
INFO - 2016-11-30 14:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 14:23:26 --> Controller Class Initialized
INFO - 2016-11-30 14:23:26 --> Model Class Initialized
INFO - 2016-11-30 14:23:26 --> Model Class Initialized
INFO - 2016-11-30 14:23:26 --> Model Class Initialized
INFO - 2016-11-30 14:23:26 --> Model Class Initialized
INFO - 2016-11-30 14:23:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 14:23:26 --> Pagination Class Initialized
INFO - 2016-11-30 14:23:26 --> Helper loaded: app_helper
INFO - 2016-11-30 14:23:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 14:23:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 14:23:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 14:23:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 14:23:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 14:23:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 14:23:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 14:23:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 14:23:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 14:23:27 --> Final output sent to browser
DEBUG - 2016-11-30 14:23:27 --> Total execution time: 2.2947
INFO - 2016-11-30 14:25:07 --> Config Class Initialized
INFO - 2016-11-30 14:25:07 --> Hooks Class Initialized
DEBUG - 2016-11-30 14:25:07 --> UTF-8 Support Enabled
INFO - 2016-11-30 14:25:07 --> Utf8 Class Initialized
INFO - 2016-11-30 14:25:07 --> URI Class Initialized
DEBUG - 2016-11-30 14:25:07 --> No URI present. Default controller set.
INFO - 2016-11-30 14:25:07 --> Router Class Initialized
INFO - 2016-11-30 14:25:07 --> Output Class Initialized
INFO - 2016-11-30 14:25:07 --> Security Class Initialized
DEBUG - 2016-11-30 14:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 14:25:07 --> Input Class Initialized
INFO - 2016-11-30 14:25:07 --> Language Class Initialized
INFO - 2016-11-30 14:25:07 --> Loader Class Initialized
INFO - 2016-11-30 14:25:07 --> Helper loaded: url_helper
INFO - 2016-11-30 14:25:07 --> Helper loaded: form_helper
INFO - 2016-11-30 14:25:07 --> Database Driver Class Initialized
INFO - 2016-11-30 14:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 14:25:07 --> Controller Class Initialized
INFO - 2016-11-30 14:25:07 --> Model Class Initialized
INFO - 2016-11-30 14:25:07 --> Model Class Initialized
INFO - 2016-11-30 14:25:07 --> Model Class Initialized
INFO - 2016-11-30 14:25:07 --> Model Class Initialized
INFO - 2016-11-30 14:25:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 14:25:07 --> Pagination Class Initialized
INFO - 2016-11-30 14:25:07 --> Helper loaded: app_helper
INFO - 2016-11-30 14:25:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 14:25:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 14:25:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 14:25:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 14:25:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 14:25:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 14:25:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 14:25:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 14:25:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 14:25:07 --> Final output sent to browser
DEBUG - 2016-11-30 14:25:07 --> Total execution time: 0.6559
INFO - 2016-11-30 14:25:17 --> Config Class Initialized
INFO - 2016-11-30 14:25:17 --> Hooks Class Initialized
DEBUG - 2016-11-30 14:25:17 --> UTF-8 Support Enabled
INFO - 2016-11-30 14:25:17 --> Utf8 Class Initialized
INFO - 2016-11-30 14:25:17 --> URI Class Initialized
DEBUG - 2016-11-30 14:25:17 --> No URI present. Default controller set.
INFO - 2016-11-30 14:25:17 --> Router Class Initialized
INFO - 2016-11-30 14:25:17 --> Output Class Initialized
INFO - 2016-11-30 14:25:17 --> Security Class Initialized
DEBUG - 2016-11-30 14:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 14:25:17 --> Input Class Initialized
INFO - 2016-11-30 14:25:17 --> Language Class Initialized
INFO - 2016-11-30 14:25:17 --> Loader Class Initialized
INFO - 2016-11-30 14:25:17 --> Helper loaded: url_helper
INFO - 2016-11-30 14:25:17 --> Helper loaded: form_helper
INFO - 2016-11-30 14:25:17 --> Database Driver Class Initialized
INFO - 2016-11-30 14:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 14:25:17 --> Controller Class Initialized
INFO - 2016-11-30 14:25:17 --> Model Class Initialized
INFO - 2016-11-30 14:25:17 --> Model Class Initialized
INFO - 2016-11-30 14:25:17 --> Model Class Initialized
INFO - 2016-11-30 14:25:17 --> Model Class Initialized
INFO - 2016-11-30 14:25:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 14:25:17 --> Pagination Class Initialized
INFO - 2016-11-30 14:25:17 --> Helper loaded: app_helper
INFO - 2016-11-30 14:25:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 14:25:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 14:25:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 14:25:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 14:25:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 14:25:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 14:25:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 14:25:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 14:25:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 14:25:17 --> Final output sent to browser
DEBUG - 2016-11-30 14:25:17 --> Total execution time: 0.6810
INFO - 2016-11-30 14:25:28 --> Config Class Initialized
INFO - 2016-11-30 14:25:28 --> Hooks Class Initialized
DEBUG - 2016-11-30 14:25:28 --> UTF-8 Support Enabled
INFO - 2016-11-30 14:25:28 --> Utf8 Class Initialized
INFO - 2016-11-30 14:25:28 --> URI Class Initialized
DEBUG - 2016-11-30 14:25:28 --> No URI present. Default controller set.
INFO - 2016-11-30 14:25:28 --> Router Class Initialized
INFO - 2016-11-30 14:25:28 --> Output Class Initialized
INFO - 2016-11-30 14:25:28 --> Security Class Initialized
DEBUG - 2016-11-30 14:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 14:25:28 --> Input Class Initialized
INFO - 2016-11-30 14:25:28 --> Language Class Initialized
INFO - 2016-11-30 14:25:28 --> Loader Class Initialized
INFO - 2016-11-30 14:25:28 --> Helper loaded: url_helper
INFO - 2016-11-30 14:25:28 --> Helper loaded: form_helper
INFO - 2016-11-30 14:25:28 --> Database Driver Class Initialized
INFO - 2016-11-30 14:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 14:25:28 --> Controller Class Initialized
INFO - 2016-11-30 14:25:28 --> Model Class Initialized
INFO - 2016-11-30 14:25:28 --> Model Class Initialized
INFO - 2016-11-30 14:25:28 --> Model Class Initialized
INFO - 2016-11-30 14:25:28 --> Model Class Initialized
INFO - 2016-11-30 14:25:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 14:25:28 --> Pagination Class Initialized
INFO - 2016-11-30 14:25:28 --> Helper loaded: app_helper
INFO - 2016-11-30 14:25:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 14:25:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 14:25:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 14:25:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 14:25:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 14:25:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 14:25:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 14:25:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 14:25:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 14:25:28 --> Final output sent to browser
DEBUG - 2016-11-30 14:25:29 --> Total execution time: 0.6573
INFO - 2016-11-30 14:28:04 --> Config Class Initialized
INFO - 2016-11-30 14:28:04 --> Hooks Class Initialized
DEBUG - 2016-11-30 14:28:04 --> UTF-8 Support Enabled
INFO - 2016-11-30 14:28:04 --> Utf8 Class Initialized
INFO - 2016-11-30 14:28:04 --> URI Class Initialized
DEBUG - 2016-11-30 14:28:05 --> No URI present. Default controller set.
INFO - 2016-11-30 14:28:05 --> Router Class Initialized
INFO - 2016-11-30 14:28:05 --> Output Class Initialized
INFO - 2016-11-30 14:28:05 --> Security Class Initialized
DEBUG - 2016-11-30 14:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 14:28:05 --> Input Class Initialized
INFO - 2016-11-30 14:28:05 --> Language Class Initialized
INFO - 2016-11-30 14:28:05 --> Loader Class Initialized
INFO - 2016-11-30 14:28:05 --> Helper loaded: url_helper
INFO - 2016-11-30 14:28:05 --> Helper loaded: form_helper
INFO - 2016-11-30 14:28:05 --> Database Driver Class Initialized
INFO - 2016-11-30 14:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 14:28:05 --> Controller Class Initialized
INFO - 2016-11-30 14:28:05 --> Model Class Initialized
INFO - 2016-11-30 14:28:05 --> Model Class Initialized
INFO - 2016-11-30 14:28:05 --> Model Class Initialized
INFO - 2016-11-30 14:28:05 --> Model Class Initialized
INFO - 2016-11-30 14:28:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 14:28:05 --> Pagination Class Initialized
INFO - 2016-11-30 14:28:05 --> Helper loaded: app_helper
INFO - 2016-11-30 14:28:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 14:28:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 14:28:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 14:28:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 14:28:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 14:28:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 14:28:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 14:28:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 14:28:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 14:28:05 --> Final output sent to browser
DEBUG - 2016-11-30 14:28:05 --> Total execution time: 0.9354
INFO - 2016-11-30 14:48:52 --> Config Class Initialized
INFO - 2016-11-30 14:48:52 --> Hooks Class Initialized
DEBUG - 2016-11-30 14:48:52 --> UTF-8 Support Enabled
INFO - 2016-11-30 14:48:52 --> Utf8 Class Initialized
INFO - 2016-11-30 14:48:52 --> URI Class Initialized
DEBUG - 2016-11-30 14:48:52 --> No URI present. Default controller set.
INFO - 2016-11-30 14:48:52 --> Router Class Initialized
INFO - 2016-11-30 14:48:52 --> Output Class Initialized
INFO - 2016-11-30 14:48:52 --> Security Class Initialized
DEBUG - 2016-11-30 14:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 14:48:52 --> Input Class Initialized
INFO - 2016-11-30 14:48:52 --> Language Class Initialized
INFO - 2016-11-30 14:48:52 --> Loader Class Initialized
INFO - 2016-11-30 14:48:52 --> Helper loaded: url_helper
INFO - 2016-11-30 14:48:52 --> Helper loaded: form_helper
INFO - 2016-11-30 14:48:52 --> Database Driver Class Initialized
INFO - 2016-11-30 14:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 14:48:52 --> Controller Class Initialized
INFO - 2016-11-30 14:48:52 --> Model Class Initialized
INFO - 2016-11-30 14:48:52 --> Model Class Initialized
INFO - 2016-11-30 14:48:52 --> Model Class Initialized
INFO - 2016-11-30 14:48:52 --> Model Class Initialized
INFO - 2016-11-30 14:48:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 14:48:52 --> Pagination Class Initialized
INFO - 2016-11-30 14:48:52 --> Helper loaded: app_helper
INFO - 2016-11-30 14:48:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 14:48:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 14:48:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 14:48:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 14:48:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 14:48:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 14:48:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 14:48:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 14:48:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 14:48:52 --> Final output sent to browser
DEBUG - 2016-11-30 14:48:52 --> Total execution time: 0.8190
INFO - 2016-11-30 14:49:11 --> Config Class Initialized
INFO - 2016-11-30 14:49:11 --> Hooks Class Initialized
DEBUG - 2016-11-30 14:49:11 --> UTF-8 Support Enabled
INFO - 2016-11-30 14:49:11 --> Utf8 Class Initialized
INFO - 2016-11-30 14:49:11 --> URI Class Initialized
INFO - 2016-11-30 14:49:11 --> Router Class Initialized
INFO - 2016-11-30 14:49:11 --> Output Class Initialized
INFO - 2016-11-30 14:49:11 --> Security Class Initialized
DEBUG - 2016-11-30 14:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 14:49:11 --> Input Class Initialized
INFO - 2016-11-30 14:49:11 --> Language Class Initialized
INFO - 2016-11-30 14:49:11 --> Loader Class Initialized
INFO - 2016-11-30 14:49:11 --> Helper loaded: url_helper
INFO - 2016-11-30 14:49:11 --> Helper loaded: form_helper
INFO - 2016-11-30 14:49:11 --> Database Driver Class Initialized
INFO - 2016-11-30 14:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 14:49:11 --> Controller Class Initialized
INFO - 2016-11-30 14:49:11 --> Model Class Initialized
INFO - 2016-11-30 14:49:11 --> Form Validation Class Initialized
INFO - 2016-11-30 14:49:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 14:49:11 --> Pagination Class Initialized
INFO - 2016-11-30 14:49:12 --> Helper loaded: app_helper
INFO - 2016-11-30 14:49:12 --> Email Class Initialized
INFO - 2016-11-30 14:49:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 14:49:12 --> Final output sent to browser
DEBUG - 2016-11-30 14:49:12 --> Total execution time: 0.6086
INFO - 2016-11-30 14:49:18 --> Config Class Initialized
INFO - 2016-11-30 14:49:18 --> Hooks Class Initialized
DEBUG - 2016-11-30 14:49:18 --> UTF-8 Support Enabled
INFO - 2016-11-30 14:49:18 --> Utf8 Class Initialized
INFO - 2016-11-30 14:49:18 --> URI Class Initialized
INFO - 2016-11-30 14:49:18 --> Router Class Initialized
INFO - 2016-11-30 14:49:18 --> Output Class Initialized
INFO - 2016-11-30 14:49:18 --> Security Class Initialized
DEBUG - 2016-11-30 14:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 14:49:18 --> Input Class Initialized
INFO - 2016-11-30 14:49:18 --> Language Class Initialized
INFO - 2016-11-30 14:49:18 --> Loader Class Initialized
INFO - 2016-11-30 14:49:18 --> Helper loaded: url_helper
INFO - 2016-11-30 14:49:19 --> Helper loaded: form_helper
INFO - 2016-11-30 14:49:19 --> Database Driver Class Initialized
INFO - 2016-11-30 14:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 14:49:19 --> Controller Class Initialized
INFO - 2016-11-30 14:49:19 --> Model Class Initialized
INFO - 2016-11-30 14:49:19 --> Form Validation Class Initialized
INFO - 2016-11-30 14:49:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 14:49:19 --> Pagination Class Initialized
INFO - 2016-11-30 14:49:19 --> Helper loaded: app_helper
INFO - 2016-11-30 14:49:19 --> Email Class Initialized
INFO - 2016-11-30 14:49:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 14:49:19 --> Final output sent to browser
DEBUG - 2016-11-30 14:49:19 --> Total execution time: 0.4917
INFO - 2016-11-30 14:49:24 --> Config Class Initialized
INFO - 2016-11-30 14:49:24 --> Hooks Class Initialized
DEBUG - 2016-11-30 14:49:24 --> UTF-8 Support Enabled
INFO - 2016-11-30 14:49:24 --> Utf8 Class Initialized
INFO - 2016-11-30 14:49:24 --> URI Class Initialized
INFO - 2016-11-30 14:49:24 --> Router Class Initialized
INFO - 2016-11-30 14:49:24 --> Output Class Initialized
INFO - 2016-11-30 14:49:24 --> Security Class Initialized
DEBUG - 2016-11-30 14:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 14:49:25 --> Input Class Initialized
INFO - 2016-11-30 14:49:25 --> Language Class Initialized
INFO - 2016-11-30 14:49:25 --> Loader Class Initialized
INFO - 2016-11-30 14:49:25 --> Helper loaded: url_helper
INFO - 2016-11-30 14:49:25 --> Helper loaded: form_helper
INFO - 2016-11-30 14:49:25 --> Database Driver Class Initialized
INFO - 2016-11-30 14:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 14:49:25 --> Controller Class Initialized
INFO - 2016-11-30 14:49:25 --> Model Class Initialized
INFO - 2016-11-30 14:49:25 --> Form Validation Class Initialized
INFO - 2016-11-30 14:49:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 14:49:25 --> Pagination Class Initialized
INFO - 2016-11-30 14:49:25 --> Helper loaded: app_helper
INFO - 2016-11-30 14:49:25 --> Email Class Initialized
INFO - 2016-11-30 14:49:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 13:49:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 13:49:25 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 13:49:26 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-30 13:49:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-30 13:49:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 13:49:27 --> Final output sent to browser
DEBUG - 2016-11-30 13:49:27 --> Total execution time: 2.7184
INFO - 2016-11-30 14:51:23 --> Config Class Initialized
INFO - 2016-11-30 14:51:23 --> Hooks Class Initialized
DEBUG - 2016-11-30 14:51:23 --> UTF-8 Support Enabled
INFO - 2016-11-30 14:51:23 --> Utf8 Class Initialized
INFO - 2016-11-30 14:51:23 --> URI Class Initialized
DEBUG - 2016-11-30 14:51:23 --> No URI present. Default controller set.
INFO - 2016-11-30 14:51:23 --> Router Class Initialized
INFO - 2016-11-30 14:51:23 --> Output Class Initialized
INFO - 2016-11-30 14:51:23 --> Security Class Initialized
DEBUG - 2016-11-30 14:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 14:51:23 --> Input Class Initialized
INFO - 2016-11-30 14:51:23 --> Language Class Initialized
INFO - 2016-11-30 14:51:23 --> Loader Class Initialized
INFO - 2016-11-30 14:51:23 --> Helper loaded: url_helper
INFO - 2016-11-30 14:51:23 --> Helper loaded: form_helper
INFO - 2016-11-30 14:51:23 --> Database Driver Class Initialized
INFO - 2016-11-30 14:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 14:51:24 --> Controller Class Initialized
INFO - 2016-11-30 14:51:24 --> Model Class Initialized
INFO - 2016-11-30 14:51:24 --> Model Class Initialized
INFO - 2016-11-30 14:51:24 --> Model Class Initialized
INFO - 2016-11-30 14:51:24 --> Model Class Initialized
INFO - 2016-11-30 14:51:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 14:51:24 --> Pagination Class Initialized
INFO - 2016-11-30 14:51:24 --> Helper loaded: app_helper
INFO - 2016-11-30 14:51:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 14:51:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 14:51:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 14:51:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 14:51:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 14:51:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 14:51:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 14:51:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 14:51:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 14:51:24 --> Final output sent to browser
DEBUG - 2016-11-30 14:51:24 --> Total execution time: 0.7171
INFO - 2016-11-30 14:53:48 --> Config Class Initialized
INFO - 2016-11-30 14:53:48 --> Hooks Class Initialized
DEBUG - 2016-11-30 14:53:48 --> UTF-8 Support Enabled
INFO - 2016-11-30 14:53:48 --> Utf8 Class Initialized
INFO - 2016-11-30 14:53:48 --> URI Class Initialized
DEBUG - 2016-11-30 14:53:48 --> No URI present. Default controller set.
INFO - 2016-11-30 14:53:48 --> Router Class Initialized
INFO - 2016-11-30 14:53:48 --> Output Class Initialized
INFO - 2016-11-30 14:53:48 --> Security Class Initialized
DEBUG - 2016-11-30 14:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 14:53:48 --> Input Class Initialized
INFO - 2016-11-30 14:53:48 --> Language Class Initialized
INFO - 2016-11-30 14:53:48 --> Loader Class Initialized
INFO - 2016-11-30 14:53:48 --> Helper loaded: url_helper
INFO - 2016-11-30 14:53:48 --> Helper loaded: form_helper
INFO - 2016-11-30 14:53:48 --> Database Driver Class Initialized
INFO - 2016-11-30 14:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 14:53:48 --> Controller Class Initialized
INFO - 2016-11-30 14:53:48 --> Model Class Initialized
INFO - 2016-11-30 14:53:48 --> Model Class Initialized
INFO - 2016-11-30 14:53:48 --> Model Class Initialized
INFO - 2016-11-30 14:53:48 --> Model Class Initialized
INFO - 2016-11-30 14:53:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 14:53:48 --> Pagination Class Initialized
INFO - 2016-11-30 14:53:48 --> Helper loaded: app_helper
INFO - 2016-11-30 14:53:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 14:53:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 14:53:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 14:53:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 14:53:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 14:53:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 14:53:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 14:53:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 14:53:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 14:53:49 --> Final output sent to browser
DEBUG - 2016-11-30 14:53:49 --> Total execution time: 0.7153
INFO - 2016-11-30 15:03:29 --> Config Class Initialized
INFO - 2016-11-30 15:03:29 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:03:29 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:03:29 --> Utf8 Class Initialized
INFO - 2016-11-30 15:03:29 --> URI Class Initialized
DEBUG - 2016-11-30 15:03:29 --> No URI present. Default controller set.
INFO - 2016-11-30 15:03:29 --> Router Class Initialized
INFO - 2016-11-30 15:03:29 --> Output Class Initialized
INFO - 2016-11-30 15:03:29 --> Security Class Initialized
DEBUG - 2016-11-30 15:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:03:29 --> Input Class Initialized
INFO - 2016-11-30 15:03:29 --> Language Class Initialized
INFO - 2016-11-30 15:03:29 --> Loader Class Initialized
INFO - 2016-11-30 15:03:29 --> Helper loaded: url_helper
INFO - 2016-11-30 15:03:29 --> Helper loaded: form_helper
INFO - 2016-11-30 15:03:29 --> Database Driver Class Initialized
INFO - 2016-11-30 15:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:03:29 --> Controller Class Initialized
INFO - 2016-11-30 15:03:29 --> Model Class Initialized
INFO - 2016-11-30 15:03:29 --> Model Class Initialized
INFO - 2016-11-30 15:03:29 --> Model Class Initialized
INFO - 2016-11-30 15:03:29 --> Model Class Initialized
INFO - 2016-11-30 15:03:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:03:29 --> Pagination Class Initialized
INFO - 2016-11-30 15:03:29 --> Helper loaded: app_helper
INFO - 2016-11-30 15:03:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 15:03:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-30 15:03:29 --> Query error: Unknown column 'lt.name' in 'field list' - Invalid query: SELECT `ad`.*, `lt`.`name`
FROM `applicationData` `ad`
JOIN `leavetype` `lt` ON `lt`.`id` = `ad`.`idLeaveType`
WHERE `idEmployee` = '19'
AND `bDeleted` =0
 LIMIT 10
INFO - 2016-11-30 15:03:29 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-30 15:04:08 --> Config Class Initialized
INFO - 2016-11-30 15:04:08 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:04:08 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:04:08 --> Utf8 Class Initialized
INFO - 2016-11-30 15:04:08 --> URI Class Initialized
DEBUG - 2016-11-30 15:04:09 --> No URI present. Default controller set.
INFO - 2016-11-30 15:04:09 --> Router Class Initialized
INFO - 2016-11-30 15:04:09 --> Output Class Initialized
INFO - 2016-11-30 15:04:09 --> Security Class Initialized
DEBUG - 2016-11-30 15:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:04:09 --> Input Class Initialized
INFO - 2016-11-30 15:04:09 --> Language Class Initialized
INFO - 2016-11-30 15:04:09 --> Loader Class Initialized
INFO - 2016-11-30 15:04:09 --> Helper loaded: url_helper
INFO - 2016-11-30 15:04:09 --> Helper loaded: form_helper
INFO - 2016-11-30 15:04:09 --> Database Driver Class Initialized
INFO - 2016-11-30 15:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:04:09 --> Controller Class Initialized
INFO - 2016-11-30 15:04:09 --> Model Class Initialized
INFO - 2016-11-30 15:04:09 --> Model Class Initialized
INFO - 2016-11-30 15:04:09 --> Model Class Initialized
INFO - 2016-11-30 15:04:09 --> Model Class Initialized
INFO - 2016-11-30 15:04:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:04:09 --> Pagination Class Initialized
INFO - 2016-11-30 15:04:09 --> Helper loaded: app_helper
INFO - 2016-11-30 15:04:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 15:04:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-30 15:04:09 --> Query error: Column 'bDeleted' in where clause is ambiguous - Invalid query: SELECT `ad`.*, `lt`.`typeName`
FROM `applicationData` `ad`
JOIN `leavetype` `lt` ON `lt`.`id` = `ad`.`idLeaveType`
WHERE `idEmployee` = '19'
AND `bDeleted` =0
 LIMIT 10
INFO - 2016-11-30 15:04:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-30 15:04:37 --> Config Class Initialized
INFO - 2016-11-30 15:04:37 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:04:37 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:04:37 --> Utf8 Class Initialized
INFO - 2016-11-30 15:04:37 --> URI Class Initialized
DEBUG - 2016-11-30 15:04:37 --> No URI present. Default controller set.
INFO - 2016-11-30 15:04:37 --> Router Class Initialized
INFO - 2016-11-30 15:04:37 --> Output Class Initialized
INFO - 2016-11-30 15:04:37 --> Security Class Initialized
DEBUG - 2016-11-30 15:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:04:37 --> Input Class Initialized
INFO - 2016-11-30 15:04:37 --> Language Class Initialized
INFO - 2016-11-30 15:04:37 --> Loader Class Initialized
INFO - 2016-11-30 15:04:37 --> Helper loaded: url_helper
INFO - 2016-11-30 15:04:37 --> Helper loaded: form_helper
INFO - 2016-11-30 15:04:37 --> Database Driver Class Initialized
INFO - 2016-11-30 15:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:04:37 --> Controller Class Initialized
INFO - 2016-11-30 15:04:37 --> Model Class Initialized
INFO - 2016-11-30 15:04:37 --> Model Class Initialized
INFO - 2016-11-30 15:04:37 --> Model Class Initialized
INFO - 2016-11-30 15:04:37 --> Model Class Initialized
INFO - 2016-11-30 15:04:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:04:37 --> Pagination Class Initialized
INFO - 2016-11-30 15:04:37 --> Helper loaded: app_helper
INFO - 2016-11-30 15:04:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 15:04:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-30 15:04:38 --> Query error: Column 'bDeleted' in where clause is ambiguous - Invalid query: SELECT `ad`.*, `lt`.`typeName`
FROM `applicationData` `ad`
LEFT JOIN `leavetype` `lt` ON `lt`.`id` = `ad`.`idLeaveType`
WHERE `idEmployee` = '19'
AND `bDeleted` =0
 LIMIT 10
INFO - 2016-11-30 15:04:38 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-30 15:07:51 --> Config Class Initialized
INFO - 2016-11-30 15:07:51 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:07:51 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:07:51 --> Utf8 Class Initialized
INFO - 2016-11-30 15:07:51 --> URI Class Initialized
DEBUG - 2016-11-30 15:07:51 --> No URI present. Default controller set.
INFO - 2016-11-30 15:07:51 --> Router Class Initialized
INFO - 2016-11-30 15:07:51 --> Output Class Initialized
INFO - 2016-11-30 15:07:51 --> Security Class Initialized
DEBUG - 2016-11-30 15:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:07:51 --> Input Class Initialized
INFO - 2016-11-30 15:07:51 --> Language Class Initialized
INFO - 2016-11-30 15:07:51 --> Loader Class Initialized
INFO - 2016-11-30 15:07:51 --> Helper loaded: url_helper
INFO - 2016-11-30 15:07:51 --> Helper loaded: form_helper
INFO - 2016-11-30 15:07:51 --> Database Driver Class Initialized
INFO - 2016-11-30 15:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:07:51 --> Controller Class Initialized
INFO - 2016-11-30 15:07:51 --> Model Class Initialized
INFO - 2016-11-30 15:07:51 --> Model Class Initialized
INFO - 2016-11-30 15:07:51 --> Model Class Initialized
INFO - 2016-11-30 15:07:51 --> Model Class Initialized
INFO - 2016-11-30 15:07:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:07:51 --> Pagination Class Initialized
INFO - 2016-11-30 15:07:51 --> Helper loaded: app_helper
INFO - 2016-11-30 15:07:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 15:07:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-30 15:07:51 --> Query error: Column 'bDeleted' in where clause is ambiguous - Invalid query: SELECT `ad`.*, `lt`.`typeName`
FROM `applicationData` `ad`
LEFT JOIN `leavetype` `lt` ON `lt`.`id` = `ad`.`idLeaveType`
WHERE `idEmployee` = '19'
AND `bDeleted` =0
 LIMIT 10
INFO - 2016-11-30 15:07:51 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-30 15:08:32 --> Config Class Initialized
INFO - 2016-11-30 15:08:32 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:08:32 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:08:32 --> Utf8 Class Initialized
INFO - 2016-11-30 15:08:32 --> URI Class Initialized
DEBUG - 2016-11-30 15:08:32 --> No URI present. Default controller set.
INFO - 2016-11-30 15:08:32 --> Router Class Initialized
INFO - 2016-11-30 15:08:32 --> Output Class Initialized
INFO - 2016-11-30 15:08:32 --> Security Class Initialized
DEBUG - 2016-11-30 15:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:08:32 --> Input Class Initialized
INFO - 2016-11-30 15:08:32 --> Language Class Initialized
INFO - 2016-11-30 15:08:32 --> Loader Class Initialized
INFO - 2016-11-30 15:08:32 --> Helper loaded: url_helper
INFO - 2016-11-30 15:08:32 --> Helper loaded: form_helper
INFO - 2016-11-30 15:08:32 --> Database Driver Class Initialized
INFO - 2016-11-30 15:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:08:32 --> Controller Class Initialized
INFO - 2016-11-30 15:08:32 --> Model Class Initialized
INFO - 2016-11-30 15:08:32 --> Model Class Initialized
INFO - 2016-11-30 15:08:32 --> Model Class Initialized
INFO - 2016-11-30 15:08:32 --> Model Class Initialized
INFO - 2016-11-30 15:08:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:08:32 --> Pagination Class Initialized
INFO - 2016-11-30 15:08:32 --> Helper loaded: app_helper
INFO - 2016-11-30 15:08:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 15:08:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-30 15:08:32 --> Query error: Column 'bDeleted' in where clause is ambiguous - Invalid query: SELECT `ad`.*, `lt`.`typeName`
FROM `applicationData` `ad`
LEFT JOIN `leavetype` `lt` ON `lt`.`id` = `ad`.`idLeaveType`
WHERE `idEmployee` = '19'
AND `bDeleted` =0
 LIMIT 10
INFO - 2016-11-30 15:08:32 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-30 15:09:00 --> Config Class Initialized
INFO - 2016-11-30 15:09:00 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:09:00 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:09:00 --> Utf8 Class Initialized
INFO - 2016-11-30 15:09:00 --> URI Class Initialized
DEBUG - 2016-11-30 15:09:00 --> No URI present. Default controller set.
INFO - 2016-11-30 15:09:00 --> Router Class Initialized
INFO - 2016-11-30 15:09:00 --> Output Class Initialized
INFO - 2016-11-30 15:09:00 --> Security Class Initialized
DEBUG - 2016-11-30 15:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:09:00 --> Input Class Initialized
INFO - 2016-11-30 15:09:00 --> Language Class Initialized
INFO - 2016-11-30 15:09:01 --> Loader Class Initialized
INFO - 2016-11-30 15:09:01 --> Helper loaded: url_helper
INFO - 2016-11-30 15:09:01 --> Helper loaded: form_helper
INFO - 2016-11-30 15:09:01 --> Database Driver Class Initialized
INFO - 2016-11-30 15:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:09:01 --> Controller Class Initialized
INFO - 2016-11-30 15:09:01 --> Model Class Initialized
INFO - 2016-11-30 15:09:01 --> Model Class Initialized
INFO - 2016-11-30 15:09:01 --> Model Class Initialized
INFO - 2016-11-30 15:09:01 --> Model Class Initialized
INFO - 2016-11-30 15:09:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:09:01 --> Pagination Class Initialized
INFO - 2016-11-30 15:09:01 --> Helper loaded: app_helper
INFO - 2016-11-30 15:09:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 15:09:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 15:09:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 15:09:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 15:09:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 15:09:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 15:09:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 15:09:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 15:09:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 15:09:01 --> Final output sent to browser
DEBUG - 2016-11-30 15:09:01 --> Total execution time: 0.6737
INFO - 2016-11-30 15:09:34 --> Config Class Initialized
INFO - 2016-11-30 15:09:34 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:09:34 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:09:34 --> Utf8 Class Initialized
INFO - 2016-11-30 15:09:34 --> URI Class Initialized
DEBUG - 2016-11-30 15:09:34 --> No URI present. Default controller set.
INFO - 2016-11-30 15:09:34 --> Router Class Initialized
INFO - 2016-11-30 15:09:34 --> Output Class Initialized
INFO - 2016-11-30 15:09:34 --> Security Class Initialized
DEBUG - 2016-11-30 15:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:09:34 --> Input Class Initialized
INFO - 2016-11-30 15:09:34 --> Language Class Initialized
INFO - 2016-11-30 15:09:34 --> Loader Class Initialized
INFO - 2016-11-30 15:09:34 --> Helper loaded: url_helper
INFO - 2016-11-30 15:09:35 --> Helper loaded: form_helper
INFO - 2016-11-30 15:09:35 --> Database Driver Class Initialized
INFO - 2016-11-30 15:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:09:35 --> Controller Class Initialized
INFO - 2016-11-30 15:09:35 --> Model Class Initialized
INFO - 2016-11-30 15:09:35 --> Model Class Initialized
INFO - 2016-11-30 15:09:35 --> Model Class Initialized
INFO - 2016-11-30 15:09:35 --> Model Class Initialized
INFO - 2016-11-30 15:09:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:09:35 --> Pagination Class Initialized
INFO - 2016-11-30 15:09:35 --> Helper loaded: app_helper
INFO - 2016-11-30 15:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 15:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 15:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 15:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 15:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 15:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 15:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 15:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 15:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 15:09:35 --> Final output sent to browser
DEBUG - 2016-11-30 15:09:35 --> Total execution time: 0.7231
INFO - 2016-11-30 15:10:37 --> Config Class Initialized
INFO - 2016-11-30 15:10:37 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:10:37 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:10:37 --> Utf8 Class Initialized
INFO - 2016-11-30 15:10:37 --> URI Class Initialized
DEBUG - 2016-11-30 15:10:37 --> No URI present. Default controller set.
INFO - 2016-11-30 15:10:37 --> Router Class Initialized
INFO - 2016-11-30 15:10:37 --> Output Class Initialized
INFO - 2016-11-30 15:10:37 --> Security Class Initialized
DEBUG - 2016-11-30 15:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:10:37 --> Input Class Initialized
INFO - 2016-11-30 15:10:37 --> Language Class Initialized
INFO - 2016-11-30 15:10:37 --> Loader Class Initialized
INFO - 2016-11-30 15:10:37 --> Helper loaded: url_helper
INFO - 2016-11-30 15:10:37 --> Helper loaded: form_helper
INFO - 2016-11-30 15:10:37 --> Database Driver Class Initialized
INFO - 2016-11-30 15:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:10:37 --> Controller Class Initialized
INFO - 2016-11-30 15:10:37 --> Model Class Initialized
INFO - 2016-11-30 15:10:37 --> Model Class Initialized
INFO - 2016-11-30 15:10:37 --> Model Class Initialized
INFO - 2016-11-30 15:10:37 --> Model Class Initialized
INFO - 2016-11-30 15:10:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:10:37 --> Pagination Class Initialized
INFO - 2016-11-30 15:10:37 --> Helper loaded: app_helper
INFO - 2016-11-30 15:10:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 15:10:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 15:10:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 15:10:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 15:10:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 15:10:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 15:10:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 15:10:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 15:10:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 15:10:37 --> Final output sent to browser
DEBUG - 2016-11-30 15:10:37 --> Total execution time: 0.6989
INFO - 2016-11-30 15:10:58 --> Config Class Initialized
INFO - 2016-11-30 15:10:58 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:10:58 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:10:58 --> Utf8 Class Initialized
INFO - 2016-11-30 15:10:58 --> URI Class Initialized
DEBUG - 2016-11-30 15:10:58 --> No URI present. Default controller set.
INFO - 2016-11-30 15:10:58 --> Router Class Initialized
INFO - 2016-11-30 15:10:58 --> Output Class Initialized
INFO - 2016-11-30 15:10:58 --> Security Class Initialized
DEBUG - 2016-11-30 15:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:10:58 --> Input Class Initialized
INFO - 2016-11-30 15:10:58 --> Language Class Initialized
INFO - 2016-11-30 15:10:58 --> Loader Class Initialized
INFO - 2016-11-30 15:10:58 --> Helper loaded: url_helper
INFO - 2016-11-30 15:10:58 --> Helper loaded: form_helper
INFO - 2016-11-30 15:10:58 --> Database Driver Class Initialized
INFO - 2016-11-30 15:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:10:58 --> Controller Class Initialized
INFO - 2016-11-30 15:10:58 --> Model Class Initialized
INFO - 2016-11-30 15:10:58 --> Model Class Initialized
INFO - 2016-11-30 15:10:58 --> Model Class Initialized
INFO - 2016-11-30 15:10:58 --> Model Class Initialized
INFO - 2016-11-30 15:10:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:10:58 --> Pagination Class Initialized
INFO - 2016-11-30 15:10:58 --> Helper loaded: app_helper
INFO - 2016-11-30 15:10:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 15:10:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 15:10:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 15:10:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 15:10:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 15:10:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 15:10:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 15:10:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 15:10:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 15:10:58 --> Final output sent to browser
DEBUG - 2016-11-30 15:10:58 --> Total execution time: 0.7468
INFO - 2016-11-30 15:12:28 --> Config Class Initialized
INFO - 2016-11-30 15:12:28 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:12:28 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:12:28 --> Utf8 Class Initialized
INFO - 2016-11-30 15:12:28 --> URI Class Initialized
DEBUG - 2016-11-30 15:12:28 --> No URI present. Default controller set.
INFO - 2016-11-30 15:12:28 --> Router Class Initialized
INFO - 2016-11-30 15:12:29 --> Output Class Initialized
INFO - 2016-11-30 15:12:29 --> Security Class Initialized
DEBUG - 2016-11-30 15:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:12:29 --> Input Class Initialized
INFO - 2016-11-30 15:12:29 --> Language Class Initialized
INFO - 2016-11-30 15:12:29 --> Loader Class Initialized
INFO - 2016-11-30 15:12:29 --> Helper loaded: url_helper
INFO - 2016-11-30 15:12:29 --> Helper loaded: form_helper
INFO - 2016-11-30 15:12:29 --> Database Driver Class Initialized
INFO - 2016-11-30 15:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:12:29 --> Controller Class Initialized
INFO - 2016-11-30 15:12:29 --> Model Class Initialized
INFO - 2016-11-30 15:12:29 --> Model Class Initialized
INFO - 2016-11-30 15:12:29 --> Model Class Initialized
INFO - 2016-11-30 15:12:29 --> Model Class Initialized
INFO - 2016-11-30 15:12:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:12:29 --> Pagination Class Initialized
INFO - 2016-11-30 15:12:29 --> Helper loaded: app_helper
INFO - 2016-11-30 15:12:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 15:12:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 15:12:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 15:12:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 15:12:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 15:12:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 15:12:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 15:12:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 15:12:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 15:12:29 --> Final output sent to browser
DEBUG - 2016-11-30 15:12:29 --> Total execution time: 0.7566
INFO - 2016-11-30 15:13:06 --> Config Class Initialized
INFO - 2016-11-30 15:13:06 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:13:06 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:13:06 --> Utf8 Class Initialized
INFO - 2016-11-30 15:13:06 --> URI Class Initialized
DEBUG - 2016-11-30 15:13:06 --> No URI present. Default controller set.
INFO - 2016-11-30 15:13:06 --> Router Class Initialized
INFO - 2016-11-30 15:13:06 --> Output Class Initialized
INFO - 2016-11-30 15:13:06 --> Security Class Initialized
DEBUG - 2016-11-30 15:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:13:06 --> Input Class Initialized
INFO - 2016-11-30 15:13:06 --> Language Class Initialized
INFO - 2016-11-30 15:13:06 --> Loader Class Initialized
INFO - 2016-11-30 15:13:06 --> Helper loaded: url_helper
INFO - 2016-11-30 15:13:06 --> Helper loaded: form_helper
INFO - 2016-11-30 15:13:06 --> Database Driver Class Initialized
INFO - 2016-11-30 15:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:13:06 --> Controller Class Initialized
INFO - 2016-11-30 15:13:06 --> Model Class Initialized
INFO - 2016-11-30 15:13:06 --> Model Class Initialized
INFO - 2016-11-30 15:13:06 --> Model Class Initialized
INFO - 2016-11-30 15:13:06 --> Model Class Initialized
INFO - 2016-11-30 15:13:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:13:07 --> Pagination Class Initialized
INFO - 2016-11-30 15:13:07 --> Helper loaded: app_helper
INFO - 2016-11-30 15:13:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 15:13:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 15:13:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 15:13:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 15:13:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 15:13:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 15:13:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 15:13:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 15:13:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 15:13:07 --> Final output sent to browser
DEBUG - 2016-11-30 15:13:07 --> Total execution time: 0.7512
INFO - 2016-11-30 15:16:37 --> Config Class Initialized
INFO - 2016-11-30 15:16:37 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:16:37 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:16:37 --> Utf8 Class Initialized
INFO - 2016-11-30 15:16:37 --> URI Class Initialized
DEBUG - 2016-11-30 15:16:37 --> No URI present. Default controller set.
INFO - 2016-11-30 15:16:37 --> Router Class Initialized
INFO - 2016-11-30 15:16:37 --> Output Class Initialized
INFO - 2016-11-30 15:16:37 --> Security Class Initialized
DEBUG - 2016-11-30 15:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:16:37 --> Input Class Initialized
INFO - 2016-11-30 15:16:37 --> Language Class Initialized
INFO - 2016-11-30 15:16:37 --> Loader Class Initialized
INFO - 2016-11-30 15:16:37 --> Helper loaded: url_helper
INFO - 2016-11-30 15:16:37 --> Helper loaded: form_helper
INFO - 2016-11-30 15:16:37 --> Database Driver Class Initialized
INFO - 2016-11-30 15:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:16:37 --> Controller Class Initialized
INFO - 2016-11-30 15:16:37 --> Model Class Initialized
INFO - 2016-11-30 15:16:37 --> Model Class Initialized
INFO - 2016-11-30 15:16:37 --> Model Class Initialized
INFO - 2016-11-30 15:16:37 --> Model Class Initialized
INFO - 2016-11-30 15:16:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:16:37 --> Pagination Class Initialized
INFO - 2016-11-30 15:16:37 --> Helper loaded: app_helper
INFO - 2016-11-30 15:16:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 15:16:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 15:16:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 15:16:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 15:16:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 15:16:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 15:16:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 15:16:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 15:16:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 15:16:38 --> Final output sent to browser
DEBUG - 2016-11-30 15:16:38 --> Total execution time: 0.7434
INFO - 2016-11-30 15:26:05 --> Config Class Initialized
INFO - 2016-11-30 15:26:05 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:26:05 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:26:05 --> Utf8 Class Initialized
INFO - 2016-11-30 15:26:05 --> URI Class Initialized
DEBUG - 2016-11-30 15:26:05 --> No URI present. Default controller set.
INFO - 2016-11-30 15:26:05 --> Router Class Initialized
INFO - 2016-11-30 15:26:05 --> Output Class Initialized
INFO - 2016-11-30 15:26:05 --> Security Class Initialized
DEBUG - 2016-11-30 15:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:26:05 --> Input Class Initialized
INFO - 2016-11-30 15:26:05 --> Language Class Initialized
INFO - 2016-11-30 15:26:05 --> Loader Class Initialized
INFO - 2016-11-30 15:26:05 --> Helper loaded: url_helper
INFO - 2016-11-30 15:26:05 --> Helper loaded: form_helper
INFO - 2016-11-30 15:26:05 --> Database Driver Class Initialized
INFO - 2016-11-30 15:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:26:05 --> Controller Class Initialized
INFO - 2016-11-30 15:26:05 --> Model Class Initialized
INFO - 2016-11-30 15:26:05 --> Model Class Initialized
INFO - 2016-11-30 15:26:05 --> Model Class Initialized
INFO - 2016-11-30 15:26:05 --> Model Class Initialized
INFO - 2016-11-30 15:26:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:26:06 --> Pagination Class Initialized
INFO - 2016-11-30 15:26:06 --> Helper loaded: app_helper
INFO - 2016-11-30 15:26:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 15:26:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 15:26:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 15:26:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 15:26:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 15:26:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 15:26:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 15:26:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 15:26:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 15:26:06 --> Final output sent to browser
DEBUG - 2016-11-30 15:26:06 --> Total execution time: 0.8052
INFO - 2016-11-30 15:26:09 --> Config Class Initialized
INFO - 2016-11-30 15:26:09 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:26:09 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:26:09 --> Utf8 Class Initialized
INFO - 2016-11-30 15:26:09 --> URI Class Initialized
INFO - 2016-11-30 15:26:09 --> Router Class Initialized
INFO - 2016-11-30 15:26:09 --> Output Class Initialized
INFO - 2016-11-30 15:26:09 --> Security Class Initialized
DEBUG - 2016-11-30 15:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:26:09 --> Input Class Initialized
INFO - 2016-11-30 15:26:09 --> Language Class Initialized
INFO - 2016-11-30 15:26:09 --> Loader Class Initialized
INFO - 2016-11-30 15:26:09 --> Helper loaded: url_helper
INFO - 2016-11-30 15:26:09 --> Helper loaded: form_helper
INFO - 2016-11-30 15:26:10 --> Database Driver Class Initialized
INFO - 2016-11-30 15:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:26:10 --> Controller Class Initialized
INFO - 2016-11-30 15:26:10 --> Model Class Initialized
INFO - 2016-11-30 15:26:10 --> Model Class Initialized
INFO - 2016-11-30 15:26:10 --> Model Class Initialized
INFO - 2016-11-30 15:26:10 --> Model Class Initialized
INFO - 2016-11-30 15:26:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:26:10 --> Pagination Class Initialized
INFO - 2016-11-30 15:26:10 --> Helper loaded: app_helper
DEBUG - 2016-11-30 15:26:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-30 15:26:10 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-30 15:26:10 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-30 15:26:10 --> Config Class Initialized
INFO - 2016-11-30 15:26:10 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:26:10 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:26:10 --> Utf8 Class Initialized
INFO - 2016-11-30 15:26:10 --> URI Class Initialized
DEBUG - 2016-11-30 15:26:10 --> No URI present. Default controller set.
INFO - 2016-11-30 15:26:10 --> Router Class Initialized
INFO - 2016-11-30 15:26:10 --> Output Class Initialized
INFO - 2016-11-30 15:26:10 --> Security Class Initialized
DEBUG - 2016-11-30 15:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:26:10 --> Input Class Initialized
INFO - 2016-11-30 15:26:10 --> Language Class Initialized
INFO - 2016-11-30 15:26:10 --> Loader Class Initialized
INFO - 2016-11-30 15:26:10 --> Helper loaded: url_helper
INFO - 2016-11-30 15:26:10 --> Helper loaded: form_helper
INFO - 2016-11-30 15:26:10 --> Database Driver Class Initialized
INFO - 2016-11-30 15:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:26:10 --> Controller Class Initialized
INFO - 2016-11-30 15:26:10 --> Model Class Initialized
INFO - 2016-11-30 15:26:10 --> Model Class Initialized
INFO - 2016-11-30 15:26:10 --> Model Class Initialized
INFO - 2016-11-30 15:26:10 --> Model Class Initialized
INFO - 2016-11-30 15:26:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:26:10 --> Pagination Class Initialized
INFO - 2016-11-30 15:26:10 --> Helper loaded: app_helper
INFO - 2016-11-30 15:26:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 15:26:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-30 15:26:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 15:26:11 --> Final output sent to browser
DEBUG - 2016-11-30 15:26:11 --> Total execution time: 0.7652
INFO - 2016-11-30 15:26:36 --> Config Class Initialized
INFO - 2016-11-30 15:26:36 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:26:36 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:26:36 --> Utf8 Class Initialized
INFO - 2016-11-30 15:26:36 --> URI Class Initialized
INFO - 2016-11-30 15:26:36 --> Router Class Initialized
INFO - 2016-11-30 15:26:36 --> Output Class Initialized
INFO - 2016-11-30 15:26:36 --> Security Class Initialized
DEBUG - 2016-11-30 15:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:26:36 --> Input Class Initialized
INFO - 2016-11-30 15:26:36 --> Language Class Initialized
INFO - 2016-11-30 15:26:36 --> Loader Class Initialized
INFO - 2016-11-30 15:26:36 --> Helper loaded: url_helper
INFO - 2016-11-30 15:26:36 --> Helper loaded: form_helper
INFO - 2016-11-30 15:26:36 --> Database Driver Class Initialized
INFO - 2016-11-30 15:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:26:37 --> Controller Class Initialized
INFO - 2016-11-30 15:26:37 --> Model Class Initialized
INFO - 2016-11-30 15:26:37 --> Model Class Initialized
INFO - 2016-11-30 15:26:37 --> Model Class Initialized
INFO - 2016-11-30 15:26:37 --> Model Class Initialized
INFO - 2016-11-30 15:26:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:26:37 --> Pagination Class Initialized
INFO - 2016-11-30 15:26:37 --> Helper loaded: app_helper
DEBUG - 2016-11-30 15:26:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 15:26:37 --> Model Class Initialized
INFO - 2016-11-30 15:26:37 --> Final output sent to browser
DEBUG - 2016-11-30 15:26:37 --> Total execution time: 0.5120
INFO - 2016-11-30 15:26:37 --> Config Class Initialized
INFO - 2016-11-30 15:26:37 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:26:37 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:26:37 --> Utf8 Class Initialized
INFO - 2016-11-30 15:26:37 --> URI Class Initialized
DEBUG - 2016-11-30 15:26:37 --> No URI present. Default controller set.
INFO - 2016-11-30 15:26:37 --> Router Class Initialized
INFO - 2016-11-30 15:26:37 --> Output Class Initialized
INFO - 2016-11-30 15:26:37 --> Security Class Initialized
DEBUG - 2016-11-30 15:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:26:37 --> Input Class Initialized
INFO - 2016-11-30 15:26:37 --> Language Class Initialized
INFO - 2016-11-30 15:26:37 --> Loader Class Initialized
INFO - 2016-11-30 15:26:37 --> Helper loaded: url_helper
INFO - 2016-11-30 15:26:37 --> Helper loaded: form_helper
INFO - 2016-11-30 15:26:37 --> Database Driver Class Initialized
INFO - 2016-11-30 15:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:26:37 --> Controller Class Initialized
INFO - 2016-11-30 15:26:37 --> Model Class Initialized
INFO - 2016-11-30 15:26:37 --> Model Class Initialized
INFO - 2016-11-30 15:26:37 --> Model Class Initialized
INFO - 2016-11-30 15:26:37 --> Model Class Initialized
INFO - 2016-11-30 15:26:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:26:37 --> Pagination Class Initialized
INFO - 2016-11-30 15:26:37 --> Helper loaded: app_helper
INFO - 2016-11-30 15:26:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 15:26:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 15:26:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 15:26:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 15:26:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 15:26:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 15:26:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 15:26:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 15:26:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 15:26:38 --> Final output sent to browser
DEBUG - 2016-11-30 15:26:38 --> Total execution time: 0.7508
INFO - 2016-11-30 15:26:51 --> Config Class Initialized
INFO - 2016-11-30 15:26:51 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:26:52 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:26:52 --> Utf8 Class Initialized
INFO - 2016-11-30 15:26:52 --> URI Class Initialized
INFO - 2016-11-30 15:26:52 --> Router Class Initialized
INFO - 2016-11-30 15:26:52 --> Output Class Initialized
INFO - 2016-11-30 15:26:52 --> Security Class Initialized
DEBUG - 2016-11-30 15:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:26:52 --> Input Class Initialized
INFO - 2016-11-30 15:26:52 --> Language Class Initialized
INFO - 2016-11-30 15:26:52 --> Loader Class Initialized
INFO - 2016-11-30 15:26:52 --> Helper loaded: url_helper
INFO - 2016-11-30 15:26:52 --> Helper loaded: form_helper
INFO - 2016-11-30 15:26:52 --> Database Driver Class Initialized
INFO - 2016-11-30 15:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:26:52 --> Controller Class Initialized
INFO - 2016-11-30 15:26:52 --> Model Class Initialized
INFO - 2016-11-30 15:26:52 --> Form Validation Class Initialized
INFO - 2016-11-30 15:26:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:26:52 --> Pagination Class Initialized
INFO - 2016-11-30 15:26:52 --> Helper loaded: app_helper
INFO - 2016-11-30 15:26:52 --> Email Class Initialized
INFO - 2016-11-30 15:26:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 14:26:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 14:26:52 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 14:26:53 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-30 14:26:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-30 14:26:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 14:26:53 --> Final output sent to browser
DEBUG - 2016-11-30 14:26:53 --> Total execution time: 1.6875
INFO - 2016-11-30 15:29:04 --> Config Class Initialized
INFO - 2016-11-30 15:29:04 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:29:04 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:29:04 --> Utf8 Class Initialized
INFO - 2016-11-30 15:29:04 --> URI Class Initialized
INFO - 2016-11-30 15:29:04 --> Router Class Initialized
INFO - 2016-11-30 15:29:04 --> Output Class Initialized
INFO - 2016-11-30 15:29:04 --> Security Class Initialized
DEBUG - 2016-11-30 15:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:29:04 --> Input Class Initialized
INFO - 2016-11-30 15:29:04 --> Language Class Initialized
INFO - 2016-11-30 15:29:04 --> Loader Class Initialized
INFO - 2016-11-30 15:29:04 --> Helper loaded: url_helper
INFO - 2016-11-30 15:29:04 --> Helper loaded: form_helper
INFO - 2016-11-30 15:29:05 --> Database Driver Class Initialized
INFO - 2016-11-30 15:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:29:05 --> Controller Class Initialized
INFO - 2016-11-30 15:29:05 --> Model Class Initialized
INFO - 2016-11-30 15:29:05 --> Model Class Initialized
INFO - 2016-11-30 15:29:05 --> Model Class Initialized
INFO - 2016-11-30 15:29:05 --> Model Class Initialized
INFO - 2016-11-30 15:29:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:29:05 --> Pagination Class Initialized
INFO - 2016-11-30 15:29:05 --> Helper loaded: app_helper
DEBUG - 2016-11-30 15:29:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-30 15:29:05 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-30 15:29:05 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-30 15:29:05 --> Config Class Initialized
INFO - 2016-11-30 15:29:05 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:29:05 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:29:05 --> Utf8 Class Initialized
INFO - 2016-11-30 15:29:05 --> URI Class Initialized
DEBUG - 2016-11-30 15:29:05 --> No URI present. Default controller set.
INFO - 2016-11-30 15:29:05 --> Router Class Initialized
INFO - 2016-11-30 15:29:05 --> Output Class Initialized
INFO - 2016-11-30 15:29:05 --> Security Class Initialized
DEBUG - 2016-11-30 15:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:29:05 --> Input Class Initialized
INFO - 2016-11-30 15:29:05 --> Language Class Initialized
INFO - 2016-11-30 15:29:05 --> Loader Class Initialized
INFO - 2016-11-30 15:29:05 --> Helper loaded: url_helper
INFO - 2016-11-30 15:29:05 --> Helper loaded: form_helper
INFO - 2016-11-30 15:29:05 --> Database Driver Class Initialized
INFO - 2016-11-30 15:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:29:05 --> Controller Class Initialized
INFO - 2016-11-30 15:29:05 --> Model Class Initialized
INFO - 2016-11-30 15:29:05 --> Model Class Initialized
INFO - 2016-11-30 15:29:05 --> Model Class Initialized
INFO - 2016-11-30 15:29:05 --> Model Class Initialized
INFO - 2016-11-30 15:29:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:29:05 --> Pagination Class Initialized
INFO - 2016-11-30 15:29:05 --> Helper loaded: app_helper
INFO - 2016-11-30 15:29:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 15:29:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-30 15:29:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 15:29:06 --> Final output sent to browser
DEBUG - 2016-11-30 15:29:06 --> Total execution time: 0.7121
INFO - 2016-11-30 15:29:16 --> Config Class Initialized
INFO - 2016-11-30 15:29:16 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:29:16 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:29:16 --> Utf8 Class Initialized
INFO - 2016-11-30 15:29:16 --> URI Class Initialized
INFO - 2016-11-30 15:29:16 --> Router Class Initialized
INFO - 2016-11-30 15:29:16 --> Output Class Initialized
INFO - 2016-11-30 15:29:16 --> Security Class Initialized
DEBUG - 2016-11-30 15:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:29:16 --> Input Class Initialized
INFO - 2016-11-30 15:29:16 --> Language Class Initialized
INFO - 2016-11-30 15:29:16 --> Loader Class Initialized
INFO - 2016-11-30 15:29:16 --> Helper loaded: url_helper
INFO - 2016-11-30 15:29:16 --> Helper loaded: form_helper
INFO - 2016-11-30 15:29:16 --> Database Driver Class Initialized
INFO - 2016-11-30 15:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:29:16 --> Controller Class Initialized
INFO - 2016-11-30 15:29:16 --> Model Class Initialized
INFO - 2016-11-30 15:29:16 --> Model Class Initialized
INFO - 2016-11-30 15:29:17 --> Model Class Initialized
INFO - 2016-11-30 15:29:17 --> Model Class Initialized
INFO - 2016-11-30 15:29:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:29:17 --> Pagination Class Initialized
INFO - 2016-11-30 15:29:17 --> Helper loaded: app_helper
DEBUG - 2016-11-30 15:29:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 15:29:17 --> Model Class Initialized
INFO - 2016-11-30 15:29:17 --> Final output sent to browser
DEBUG - 2016-11-30 15:29:17 --> Total execution time: 0.5288
INFO - 2016-11-30 15:29:17 --> Config Class Initialized
INFO - 2016-11-30 15:29:17 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:29:17 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:29:17 --> Utf8 Class Initialized
INFO - 2016-11-30 15:29:17 --> URI Class Initialized
DEBUG - 2016-11-30 15:29:17 --> No URI present. Default controller set.
INFO - 2016-11-30 15:29:17 --> Router Class Initialized
INFO - 2016-11-30 15:29:17 --> Output Class Initialized
INFO - 2016-11-30 15:29:17 --> Security Class Initialized
DEBUG - 2016-11-30 15:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:29:17 --> Input Class Initialized
INFO - 2016-11-30 15:29:17 --> Language Class Initialized
INFO - 2016-11-30 15:29:17 --> Loader Class Initialized
INFO - 2016-11-30 15:29:17 --> Helper loaded: url_helper
INFO - 2016-11-30 15:29:17 --> Helper loaded: form_helper
INFO - 2016-11-30 15:29:17 --> Database Driver Class Initialized
INFO - 2016-11-30 15:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:29:17 --> Controller Class Initialized
INFO - 2016-11-30 15:29:17 --> Model Class Initialized
INFO - 2016-11-30 15:29:17 --> Model Class Initialized
INFO - 2016-11-30 15:29:17 --> Model Class Initialized
INFO - 2016-11-30 15:29:17 --> Model Class Initialized
INFO - 2016-11-30 15:29:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:29:17 --> Pagination Class Initialized
INFO - 2016-11-30 15:29:17 --> Helper loaded: app_helper
INFO - 2016-11-30 15:29:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 15:29:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 15:29:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 15:29:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 15:29:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 15:29:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 15:29:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 15:29:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 15:29:17 --> Final output sent to browser
DEBUG - 2016-11-30 15:29:17 --> Total execution time: 0.7180
INFO - 2016-11-30 15:29:29 --> Config Class Initialized
INFO - 2016-11-30 15:29:29 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:29:29 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:29:29 --> Utf8 Class Initialized
INFO - 2016-11-30 15:29:29 --> URI Class Initialized
INFO - 2016-11-30 15:29:29 --> Router Class Initialized
INFO - 2016-11-30 15:29:29 --> Output Class Initialized
INFO - 2016-11-30 15:29:29 --> Security Class Initialized
DEBUG - 2016-11-30 15:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:29:29 --> Input Class Initialized
INFO - 2016-11-30 15:29:29 --> Language Class Initialized
INFO - 2016-11-30 15:29:29 --> Loader Class Initialized
INFO - 2016-11-30 15:29:29 --> Helper loaded: url_helper
INFO - 2016-11-30 15:29:29 --> Helper loaded: form_helper
INFO - 2016-11-30 15:29:29 --> Database Driver Class Initialized
INFO - 2016-11-30 15:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:29:29 --> Controller Class Initialized
INFO - 2016-11-30 15:29:29 --> Model Class Initialized
INFO - 2016-11-30 15:29:29 --> Form Validation Class Initialized
INFO - 2016-11-30 15:29:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:29:29 --> Pagination Class Initialized
INFO - 2016-11-30 15:29:29 --> Helper loaded: app_helper
INFO - 2016-11-30 15:29:29 --> Email Class Initialized
INFO - 2016-11-30 15:29:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 14:29:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 14:29:30 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 14:29:30 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-30 14:29:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-30 14:29:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 14:29:30 --> Final output sent to browser
DEBUG - 2016-11-30 14:29:30 --> Total execution time: 1.3955
INFO - 2016-11-30 15:31:15 --> Config Class Initialized
INFO - 2016-11-30 15:31:15 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:31:15 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:31:15 --> Utf8 Class Initialized
INFO - 2016-11-30 15:31:15 --> URI Class Initialized
DEBUG - 2016-11-30 15:31:15 --> No URI present. Default controller set.
INFO - 2016-11-30 15:31:15 --> Router Class Initialized
INFO - 2016-11-30 15:31:15 --> Output Class Initialized
INFO - 2016-11-30 15:31:15 --> Security Class Initialized
DEBUG - 2016-11-30 15:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:31:15 --> Input Class Initialized
INFO - 2016-11-30 15:31:15 --> Language Class Initialized
INFO - 2016-11-30 15:31:15 --> Loader Class Initialized
INFO - 2016-11-30 15:31:15 --> Helper loaded: url_helper
INFO - 2016-11-30 15:31:15 --> Helper loaded: form_helper
INFO - 2016-11-30 15:31:15 --> Database Driver Class Initialized
INFO - 2016-11-30 15:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:31:15 --> Controller Class Initialized
INFO - 2016-11-30 15:31:15 --> Model Class Initialized
INFO - 2016-11-30 15:31:15 --> Model Class Initialized
INFO - 2016-11-30 15:31:15 --> Model Class Initialized
INFO - 2016-11-30 15:31:15 --> Model Class Initialized
INFO - 2016-11-30 15:31:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:31:15 --> Pagination Class Initialized
INFO - 2016-11-30 15:31:15 --> Helper loaded: app_helper
INFO - 2016-11-30 15:31:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 15:31:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 15:31:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 15:31:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 15:31:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 15:31:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 15:31:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 15:31:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 15:31:15 --> Final output sent to browser
DEBUG - 2016-11-30 15:31:15 --> Total execution time: 0.7757
INFO - 2016-11-30 15:31:23 --> Config Class Initialized
INFO - 2016-11-30 15:31:23 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:31:23 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:31:23 --> Utf8 Class Initialized
INFO - 2016-11-30 15:31:23 --> URI Class Initialized
INFO - 2016-11-30 15:31:23 --> Router Class Initialized
INFO - 2016-11-30 15:31:23 --> Output Class Initialized
INFO - 2016-11-30 15:31:23 --> Security Class Initialized
DEBUG - 2016-11-30 15:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:31:23 --> Input Class Initialized
INFO - 2016-11-30 15:31:23 --> Language Class Initialized
INFO - 2016-11-30 15:31:23 --> Loader Class Initialized
INFO - 2016-11-30 15:31:23 --> Helper loaded: url_helper
INFO - 2016-11-30 15:31:23 --> Helper loaded: form_helper
INFO - 2016-11-30 15:31:23 --> Database Driver Class Initialized
INFO - 2016-11-30 15:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:31:23 --> Controller Class Initialized
INFO - 2016-11-30 15:31:23 --> Model Class Initialized
INFO - 2016-11-30 15:31:23 --> Form Validation Class Initialized
INFO - 2016-11-30 15:31:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:31:23 --> Pagination Class Initialized
INFO - 2016-11-30 15:31:23 --> Helper loaded: app_helper
INFO - 2016-11-30 15:31:23 --> Email Class Initialized
INFO - 2016-11-30 15:31:23 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-30 14:31:24 --> Severity: Notice --> Undefined variable: hash C:\xampp\htdocs\LMS\app\views\email_template.php 49
INFO - 2016-11-30 14:31:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 14:31:24 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 14:31:24 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-30 14:31:24 --> Severity: Notice --> Undefined variable: hash C:\xampp\htdocs\LMS\app\views\email_template.php 49
INFO - 2016-11-30 14:31:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-30 14:31:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 14:31:24 --> Final output sent to browser
DEBUG - 2016-11-30 14:31:24 --> Total execution time: 1.4447
INFO - 2016-11-30 15:51:37 --> Config Class Initialized
INFO - 2016-11-30 15:51:37 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:51:37 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:51:37 --> Utf8 Class Initialized
INFO - 2016-11-30 15:51:37 --> URI Class Initialized
DEBUG - 2016-11-30 15:51:37 --> No URI present. Default controller set.
INFO - 2016-11-30 15:51:37 --> Router Class Initialized
INFO - 2016-11-30 15:51:37 --> Output Class Initialized
INFO - 2016-11-30 15:51:37 --> Security Class Initialized
DEBUG - 2016-11-30 15:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:51:37 --> Input Class Initialized
INFO - 2016-11-30 15:51:37 --> Language Class Initialized
INFO - 2016-11-30 15:51:37 --> Loader Class Initialized
INFO - 2016-11-30 15:51:37 --> Helper loaded: url_helper
INFO - 2016-11-30 15:51:37 --> Helper loaded: form_helper
INFO - 2016-11-30 15:51:37 --> Database Driver Class Initialized
INFO - 2016-11-30 15:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:51:37 --> Controller Class Initialized
INFO - 2016-11-30 15:51:37 --> Model Class Initialized
INFO - 2016-11-30 15:51:37 --> Model Class Initialized
INFO - 2016-11-30 15:51:37 --> Model Class Initialized
INFO - 2016-11-30 15:51:37 --> Model Class Initialized
INFO - 2016-11-30 15:51:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:51:37 --> Pagination Class Initialized
INFO - 2016-11-30 15:51:37 --> Helper loaded: app_helper
INFO - 2016-11-30 15:51:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 15:51:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 15:51:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 15:51:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 15:51:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 15:51:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 15:51:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 15:51:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 15:51:37 --> Final output sent to browser
DEBUG - 2016-11-30 15:51:38 --> Total execution time: 0.8694
INFO - 2016-11-30 15:52:43 --> Config Class Initialized
INFO - 2016-11-30 15:52:43 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:52:43 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:52:43 --> Utf8 Class Initialized
INFO - 2016-11-30 15:52:43 --> URI Class Initialized
DEBUG - 2016-11-30 15:52:44 --> No URI present. Default controller set.
INFO - 2016-11-30 15:52:44 --> Router Class Initialized
INFO - 2016-11-30 15:52:44 --> Output Class Initialized
INFO - 2016-11-30 15:52:44 --> Security Class Initialized
DEBUG - 2016-11-30 15:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:52:44 --> Input Class Initialized
INFO - 2016-11-30 15:52:44 --> Language Class Initialized
INFO - 2016-11-30 15:52:44 --> Loader Class Initialized
INFO - 2016-11-30 15:52:44 --> Helper loaded: url_helper
INFO - 2016-11-30 15:52:44 --> Helper loaded: form_helper
INFO - 2016-11-30 15:52:44 --> Database Driver Class Initialized
INFO - 2016-11-30 15:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:52:44 --> Controller Class Initialized
INFO - 2016-11-30 15:52:44 --> Model Class Initialized
INFO - 2016-11-30 15:52:44 --> Model Class Initialized
INFO - 2016-11-30 15:52:44 --> Model Class Initialized
INFO - 2016-11-30 15:52:44 --> Model Class Initialized
INFO - 2016-11-30 15:52:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:52:44 --> Pagination Class Initialized
INFO - 2016-11-30 15:52:44 --> Helper loaded: app_helper
INFO - 2016-11-30 15:52:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 15:52:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 15:52:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 15:52:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 15:52:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 15:52:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 15:52:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 15:52:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 15:52:44 --> Final output sent to browser
DEBUG - 2016-11-30 15:52:44 --> Total execution time: 0.8545
INFO - 2016-11-30 15:53:58 --> Config Class Initialized
INFO - 2016-11-30 15:53:58 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:53:58 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:53:58 --> Utf8 Class Initialized
INFO - 2016-11-30 15:53:58 --> URI Class Initialized
DEBUG - 2016-11-30 15:53:58 --> No URI present. Default controller set.
INFO - 2016-11-30 15:53:58 --> Router Class Initialized
INFO - 2016-11-30 15:53:58 --> Output Class Initialized
INFO - 2016-11-30 15:53:58 --> Security Class Initialized
DEBUG - 2016-11-30 15:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:53:58 --> Input Class Initialized
INFO - 2016-11-30 15:53:58 --> Language Class Initialized
INFO - 2016-11-30 15:53:58 --> Loader Class Initialized
INFO - 2016-11-30 15:53:58 --> Helper loaded: url_helper
INFO - 2016-11-30 15:53:58 --> Helper loaded: form_helper
INFO - 2016-11-30 15:53:58 --> Database Driver Class Initialized
INFO - 2016-11-30 15:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:53:58 --> Controller Class Initialized
INFO - 2016-11-30 15:53:58 --> Model Class Initialized
INFO - 2016-11-30 15:53:58 --> Model Class Initialized
INFO - 2016-11-30 15:53:58 --> Model Class Initialized
INFO - 2016-11-30 15:53:58 --> Model Class Initialized
INFO - 2016-11-30 15:53:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:53:58 --> Pagination Class Initialized
INFO - 2016-11-30 15:53:58 --> Helper loaded: app_helper
INFO - 2016-11-30 15:53:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 15:53:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 15:53:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 15:53:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 15:53:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 15:53:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 15:53:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 15:53:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 15:53:59 --> Final output sent to browser
DEBUG - 2016-11-30 15:53:59 --> Total execution time: 0.8760
INFO - 2016-11-30 15:54:04 --> Config Class Initialized
INFO - 2016-11-30 15:54:04 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:54:04 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:54:05 --> Utf8 Class Initialized
INFO - 2016-11-30 15:54:05 --> URI Class Initialized
INFO - 2016-11-30 15:54:05 --> Router Class Initialized
INFO - 2016-11-30 15:54:05 --> Output Class Initialized
INFO - 2016-11-30 15:54:05 --> Security Class Initialized
DEBUG - 2016-11-30 15:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:54:05 --> Input Class Initialized
INFO - 2016-11-30 15:54:05 --> Language Class Initialized
INFO - 2016-11-30 15:54:05 --> Loader Class Initialized
INFO - 2016-11-30 15:54:05 --> Helper loaded: url_helper
INFO - 2016-11-30 15:54:05 --> Helper loaded: form_helper
INFO - 2016-11-30 15:54:05 --> Database Driver Class Initialized
INFO - 2016-11-30 15:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:54:05 --> Controller Class Initialized
INFO - 2016-11-30 15:54:05 --> Model Class Initialized
INFO - 2016-11-30 15:54:05 --> Form Validation Class Initialized
INFO - 2016-11-30 15:54:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:54:05 --> Pagination Class Initialized
INFO - 2016-11-30 15:54:05 --> Helper loaded: app_helper
INFO - 2016-11-30 15:54:05 --> Email Class Initialized
INFO - 2016-11-30 15:54:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 15:54:05 --> Final output sent to browser
DEBUG - 2016-11-30 15:54:05 --> Total execution time: 0.4740
INFO - 2016-11-30 15:55:52 --> Config Class Initialized
INFO - 2016-11-30 15:55:52 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:55:52 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:55:52 --> Utf8 Class Initialized
INFO - 2016-11-30 15:55:52 --> URI Class Initialized
DEBUG - 2016-11-30 15:55:52 --> No URI present. Default controller set.
INFO - 2016-11-30 15:55:52 --> Router Class Initialized
INFO - 2016-11-30 15:55:52 --> Output Class Initialized
INFO - 2016-11-30 15:55:52 --> Security Class Initialized
DEBUG - 2016-11-30 15:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:55:52 --> Input Class Initialized
INFO - 2016-11-30 15:55:52 --> Language Class Initialized
INFO - 2016-11-30 15:55:52 --> Loader Class Initialized
INFO - 2016-11-30 15:55:52 --> Helper loaded: url_helper
INFO - 2016-11-30 15:55:52 --> Helper loaded: form_helper
INFO - 2016-11-30 15:55:52 --> Database Driver Class Initialized
INFO - 2016-11-30 15:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:55:52 --> Controller Class Initialized
INFO - 2016-11-30 15:55:52 --> Model Class Initialized
INFO - 2016-11-30 15:55:52 --> Model Class Initialized
INFO - 2016-11-30 15:55:52 --> Model Class Initialized
INFO - 2016-11-30 15:55:52 --> Model Class Initialized
INFO - 2016-11-30 15:55:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:55:52 --> Pagination Class Initialized
INFO - 2016-11-30 15:55:52 --> Helper loaded: app_helper
INFO - 2016-11-30 15:55:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 15:55:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 15:55:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 15:55:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 15:55:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 15:55:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 15:55:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 15:55:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 15:55:52 --> Final output sent to browser
DEBUG - 2016-11-30 15:55:52 --> Total execution time: 0.8153
INFO - 2016-11-30 15:56:03 --> Config Class Initialized
INFO - 2016-11-30 15:56:03 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:56:03 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:56:03 --> Utf8 Class Initialized
INFO - 2016-11-30 15:56:03 --> URI Class Initialized
INFO - 2016-11-30 15:56:03 --> Router Class Initialized
INFO - 2016-11-30 15:56:03 --> Output Class Initialized
INFO - 2016-11-30 15:56:03 --> Security Class Initialized
DEBUG - 2016-11-30 15:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:56:04 --> Input Class Initialized
INFO - 2016-11-30 15:56:04 --> Language Class Initialized
INFO - 2016-11-30 15:56:04 --> Loader Class Initialized
INFO - 2016-11-30 15:56:04 --> Helper loaded: url_helper
INFO - 2016-11-30 15:56:04 --> Helper loaded: form_helper
INFO - 2016-11-30 15:56:04 --> Database Driver Class Initialized
INFO - 2016-11-30 15:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:56:04 --> Controller Class Initialized
INFO - 2016-11-30 15:56:04 --> Model Class Initialized
INFO - 2016-11-30 15:56:04 --> Form Validation Class Initialized
INFO - 2016-11-30 15:56:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:56:04 --> Pagination Class Initialized
INFO - 2016-11-30 15:56:04 --> Helper loaded: app_helper
INFO - 2016-11-30 15:56:04 --> Email Class Initialized
INFO - 2016-11-30 15:56:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 15:56:04 --> Final output sent to browser
DEBUG - 2016-11-30 15:56:04 --> Total execution time: 0.5012
INFO - 2016-11-30 15:57:11 --> Config Class Initialized
INFO - 2016-11-30 15:57:11 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:57:11 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:57:11 --> Utf8 Class Initialized
INFO - 2016-11-30 15:57:11 --> URI Class Initialized
DEBUG - 2016-11-30 15:57:11 --> No URI present. Default controller set.
INFO - 2016-11-30 15:57:11 --> Router Class Initialized
INFO - 2016-11-30 15:57:11 --> Output Class Initialized
INFO - 2016-11-30 15:57:11 --> Security Class Initialized
DEBUG - 2016-11-30 15:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:57:11 --> Input Class Initialized
INFO - 2016-11-30 15:57:11 --> Language Class Initialized
INFO - 2016-11-30 15:57:11 --> Loader Class Initialized
INFO - 2016-11-30 15:57:11 --> Helper loaded: url_helper
INFO - 2016-11-30 15:57:11 --> Helper loaded: form_helper
INFO - 2016-11-30 15:57:11 --> Database Driver Class Initialized
INFO - 2016-11-30 15:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:57:11 --> Controller Class Initialized
INFO - 2016-11-30 15:57:11 --> Model Class Initialized
INFO - 2016-11-30 15:57:11 --> Model Class Initialized
INFO - 2016-11-30 15:57:11 --> Model Class Initialized
INFO - 2016-11-30 15:57:11 --> Model Class Initialized
INFO - 2016-11-30 15:57:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:57:11 --> Pagination Class Initialized
INFO - 2016-11-30 15:57:11 --> Helper loaded: app_helper
INFO - 2016-11-30 15:57:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 15:57:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 15:57:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 15:57:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 15:57:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 15:57:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 15:57:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 15:57:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 15:57:12 --> Final output sent to browser
DEBUG - 2016-11-30 15:57:12 --> Total execution time: 0.9560
INFO - 2016-11-30 15:57:29 --> Config Class Initialized
INFO - 2016-11-30 15:57:29 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:57:29 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:57:29 --> Utf8 Class Initialized
INFO - 2016-11-30 15:57:29 --> URI Class Initialized
INFO - 2016-11-30 15:57:29 --> Router Class Initialized
INFO - 2016-11-30 15:57:29 --> Output Class Initialized
INFO - 2016-11-30 15:57:29 --> Security Class Initialized
DEBUG - 2016-11-30 15:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:57:29 --> Input Class Initialized
INFO - 2016-11-30 15:57:29 --> Language Class Initialized
INFO - 2016-11-30 15:57:29 --> Loader Class Initialized
INFO - 2016-11-30 15:57:29 --> Helper loaded: url_helper
INFO - 2016-11-30 15:57:29 --> Helper loaded: form_helper
INFO - 2016-11-30 15:57:29 --> Database Driver Class Initialized
INFO - 2016-11-30 15:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:57:29 --> Controller Class Initialized
INFO - 2016-11-30 15:57:29 --> Model Class Initialized
INFO - 2016-11-30 15:57:29 --> Form Validation Class Initialized
INFO - 2016-11-30 15:57:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 15:57:29 --> Pagination Class Initialized
INFO - 2016-11-30 15:57:29 --> Helper loaded: app_helper
INFO - 2016-11-30 15:57:30 --> Email Class Initialized
INFO - 2016-11-30 15:57:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 15:57:30 --> Final output sent to browser
DEBUG - 2016-11-30 15:57:30 --> Total execution time: 0.5895
INFO - 2016-11-30 16:00:54 --> Config Class Initialized
INFO - 2016-11-30 16:00:55 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:00:55 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:00:55 --> Utf8 Class Initialized
INFO - 2016-11-30 16:00:55 --> URI Class Initialized
DEBUG - 2016-11-30 16:00:55 --> No URI present. Default controller set.
INFO - 2016-11-30 16:00:55 --> Router Class Initialized
INFO - 2016-11-30 16:00:55 --> Output Class Initialized
INFO - 2016-11-30 16:00:55 --> Security Class Initialized
DEBUG - 2016-11-30 16:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:00:55 --> Input Class Initialized
INFO - 2016-11-30 16:00:55 --> Language Class Initialized
INFO - 2016-11-30 16:00:55 --> Loader Class Initialized
INFO - 2016-11-30 16:00:55 --> Helper loaded: url_helper
INFO - 2016-11-30 16:00:55 --> Helper loaded: form_helper
INFO - 2016-11-30 16:00:55 --> Database Driver Class Initialized
INFO - 2016-11-30 16:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:00:55 --> Controller Class Initialized
INFO - 2016-11-30 16:00:55 --> Model Class Initialized
INFO - 2016-11-30 16:00:55 --> Model Class Initialized
INFO - 2016-11-30 16:00:55 --> Model Class Initialized
INFO - 2016-11-30 16:00:55 --> Model Class Initialized
INFO - 2016-11-30 16:00:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:00:55 --> Pagination Class Initialized
INFO - 2016-11-30 16:00:55 --> Helper loaded: app_helper
INFO - 2016-11-30 16:00:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:00:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:00:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:00:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:00:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:00:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:00:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:00:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:00:55 --> Final output sent to browser
DEBUG - 2016-11-30 16:00:55 --> Total execution time: 0.8189
INFO - 2016-11-30 16:03:09 --> Config Class Initialized
INFO - 2016-11-30 16:03:09 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:03:09 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:03:09 --> Utf8 Class Initialized
INFO - 2016-11-30 16:03:09 --> URI Class Initialized
DEBUG - 2016-11-30 16:03:09 --> No URI present. Default controller set.
INFO - 2016-11-30 16:03:09 --> Router Class Initialized
INFO - 2016-11-30 16:03:09 --> Output Class Initialized
INFO - 2016-11-30 16:03:09 --> Security Class Initialized
DEBUG - 2016-11-30 16:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:03:09 --> Input Class Initialized
INFO - 2016-11-30 16:03:09 --> Language Class Initialized
INFO - 2016-11-30 16:03:09 --> Loader Class Initialized
INFO - 2016-11-30 16:03:09 --> Helper loaded: url_helper
INFO - 2016-11-30 16:03:09 --> Helper loaded: form_helper
INFO - 2016-11-30 16:03:09 --> Database Driver Class Initialized
INFO - 2016-11-30 16:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:03:09 --> Controller Class Initialized
INFO - 2016-11-30 16:03:09 --> Model Class Initialized
INFO - 2016-11-30 16:03:09 --> Model Class Initialized
INFO - 2016-11-30 16:03:09 --> Model Class Initialized
INFO - 2016-11-30 16:03:09 --> Model Class Initialized
INFO - 2016-11-30 16:03:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:03:09 --> Pagination Class Initialized
INFO - 2016-11-30 16:03:09 --> Helper loaded: app_helper
INFO - 2016-11-30 16:03:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:03:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:03:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:03:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:03:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:03:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:03:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:03:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:03:10 --> Final output sent to browser
DEBUG - 2016-11-30 16:03:10 --> Total execution time: 0.9236
INFO - 2016-11-30 16:03:16 --> Config Class Initialized
INFO - 2016-11-30 16:03:16 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:03:16 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:03:16 --> Utf8 Class Initialized
INFO - 2016-11-30 16:03:16 --> URI Class Initialized
DEBUG - 2016-11-30 16:03:16 --> No URI present. Default controller set.
INFO - 2016-11-30 16:03:16 --> Router Class Initialized
INFO - 2016-11-30 16:03:16 --> Output Class Initialized
INFO - 2016-11-30 16:03:16 --> Security Class Initialized
DEBUG - 2016-11-30 16:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:03:16 --> Input Class Initialized
INFO - 2016-11-30 16:03:16 --> Language Class Initialized
INFO - 2016-11-30 16:03:16 --> Loader Class Initialized
INFO - 2016-11-30 16:03:16 --> Helper loaded: url_helper
INFO - 2016-11-30 16:03:16 --> Helper loaded: form_helper
INFO - 2016-11-30 16:03:16 --> Database Driver Class Initialized
INFO - 2016-11-30 16:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:03:17 --> Controller Class Initialized
INFO - 2016-11-30 16:03:17 --> Model Class Initialized
INFO - 2016-11-30 16:03:17 --> Model Class Initialized
INFO - 2016-11-30 16:03:17 --> Model Class Initialized
INFO - 2016-11-30 16:03:17 --> Model Class Initialized
INFO - 2016-11-30 16:03:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:03:17 --> Pagination Class Initialized
INFO - 2016-11-30 16:03:17 --> Helper loaded: app_helper
INFO - 2016-11-30 16:03:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:03:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:03:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:03:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:03:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:03:17 --> Config Class Initialized
INFO - 2016-11-30 16:03:17 --> Hooks Class Initialized
INFO - 2016-11-30 16:03:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:03:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
DEBUG - 2016-11-30 16:03:17 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:03:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:03:17 --> Utf8 Class Initialized
INFO - 2016-11-30 16:03:17 --> Final output sent to browser
INFO - 2016-11-30 16:03:17 --> URI Class Initialized
DEBUG - 2016-11-30 16:03:17 --> Total execution time: 0.9032
DEBUG - 2016-11-30 16:03:17 --> No URI present. Default controller set.
INFO - 2016-11-30 16:03:17 --> Router Class Initialized
INFO - 2016-11-30 16:03:17 --> Output Class Initialized
INFO - 2016-11-30 16:03:17 --> Security Class Initialized
DEBUG - 2016-11-30 16:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:03:17 --> Input Class Initialized
INFO - 2016-11-30 16:03:17 --> Language Class Initialized
INFO - 2016-11-30 16:03:17 --> Loader Class Initialized
INFO - 2016-11-30 16:03:17 --> Helper loaded: url_helper
INFO - 2016-11-30 16:03:17 --> Helper loaded: form_helper
INFO - 2016-11-30 16:03:17 --> Database Driver Class Initialized
INFO - 2016-11-30 16:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:03:17 --> Controller Class Initialized
INFO - 2016-11-30 16:03:17 --> Model Class Initialized
INFO - 2016-11-30 16:03:17 --> Model Class Initialized
INFO - 2016-11-30 16:03:17 --> Model Class Initialized
INFO - 2016-11-30 16:03:17 --> Model Class Initialized
INFO - 2016-11-30 16:03:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:03:17 --> Pagination Class Initialized
INFO - 2016-11-30 16:03:17 --> Helper loaded: app_helper
INFO - 2016-11-30 16:03:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:03:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:03:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:03:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:03:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:03:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:03:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:03:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:03:18 --> Final output sent to browser
DEBUG - 2016-11-30 16:03:18 --> Total execution time: 0.8415
INFO - 2016-11-30 16:03:45 --> Config Class Initialized
INFO - 2016-11-30 16:03:45 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:03:45 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:03:45 --> Utf8 Class Initialized
INFO - 2016-11-30 16:03:45 --> URI Class Initialized
INFO - 2016-11-30 16:03:45 --> Router Class Initialized
INFO - 2016-11-30 16:03:45 --> Output Class Initialized
INFO - 2016-11-30 16:03:45 --> Security Class Initialized
DEBUG - 2016-11-30 16:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:03:45 --> Input Class Initialized
INFO - 2016-11-30 16:03:45 --> Language Class Initialized
INFO - 2016-11-30 16:03:45 --> Loader Class Initialized
INFO - 2016-11-30 16:03:45 --> Helper loaded: url_helper
INFO - 2016-11-30 16:03:45 --> Helper loaded: form_helper
INFO - 2016-11-30 16:03:45 --> Database Driver Class Initialized
INFO - 2016-11-30 16:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:03:45 --> Controller Class Initialized
INFO - 2016-11-30 16:03:45 --> Model Class Initialized
INFO - 2016-11-30 16:03:45 --> Form Validation Class Initialized
INFO - 2016-11-30 16:03:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:03:45 --> Pagination Class Initialized
INFO - 2016-11-30 16:03:45 --> Helper loaded: app_helper
INFO - 2016-11-30 16:03:45 --> Email Class Initialized
INFO - 2016-11-30 16:03:45 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-30 15:03:45 --> Severity: Notice --> Undefined variable: hash C:\xampp\htdocs\LMS\app\views\email_template.php 49
INFO - 2016-11-30 15:03:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 15:03:45 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 15:03:46 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-30 15:03:46 --> Severity: Notice --> Undefined variable: hash C:\xampp\htdocs\LMS\app\views\email_template.php 49
INFO - 2016-11-30 15:03:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-30 15:03:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 15:03:46 --> Final output sent to browser
DEBUG - 2016-11-30 15:03:46 --> Total execution time: 1.5593
INFO - 2016-11-30 16:03:50 --> Config Class Initialized
INFO - 2016-11-30 16:03:50 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:03:50 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:03:50 --> Utf8 Class Initialized
INFO - 2016-11-30 16:03:50 --> URI Class Initialized
DEBUG - 2016-11-30 16:03:50 --> No URI present. Default controller set.
INFO - 2016-11-30 16:03:50 --> Router Class Initialized
INFO - 2016-11-30 16:03:50 --> Output Class Initialized
INFO - 2016-11-30 16:03:50 --> Security Class Initialized
DEBUG - 2016-11-30 16:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:03:50 --> Input Class Initialized
INFO - 2016-11-30 16:03:50 --> Language Class Initialized
INFO - 2016-11-30 16:03:50 --> Loader Class Initialized
INFO - 2016-11-30 16:03:50 --> Helper loaded: url_helper
INFO - 2016-11-30 16:03:50 --> Helper loaded: form_helper
INFO - 2016-11-30 16:03:50 --> Database Driver Class Initialized
INFO - 2016-11-30 16:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:03:50 --> Controller Class Initialized
INFO - 2016-11-30 16:03:50 --> Model Class Initialized
INFO - 2016-11-30 16:03:50 --> Model Class Initialized
INFO - 2016-11-30 16:03:50 --> Model Class Initialized
INFO - 2016-11-30 16:03:50 --> Model Class Initialized
INFO - 2016-11-30 16:03:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:03:50 --> Pagination Class Initialized
INFO - 2016-11-30 16:03:50 --> Helper loaded: app_helper
INFO - 2016-11-30 16:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:03:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:03:51 --> Final output sent to browser
DEBUG - 2016-11-30 16:03:51 --> Total execution time: 0.7920
INFO - 2016-11-30 16:08:22 --> Config Class Initialized
INFO - 2016-11-30 16:08:22 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:08:22 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:08:22 --> Utf8 Class Initialized
INFO - 2016-11-30 16:08:22 --> URI Class Initialized
INFO - 2016-11-30 16:08:22 --> Router Class Initialized
INFO - 2016-11-30 16:08:22 --> Output Class Initialized
INFO - 2016-11-30 16:08:22 --> Security Class Initialized
DEBUG - 2016-11-30 16:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:08:22 --> Input Class Initialized
INFO - 2016-11-30 16:08:22 --> Language Class Initialized
INFO - 2016-11-30 16:08:22 --> Loader Class Initialized
INFO - 2016-11-30 16:08:22 --> Helper loaded: url_helper
INFO - 2016-11-30 16:08:22 --> Helper loaded: form_helper
INFO - 2016-11-30 16:08:22 --> Database Driver Class Initialized
INFO - 2016-11-30 16:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:08:22 --> Controller Class Initialized
INFO - 2016-11-30 16:08:22 --> Model Class Initialized
INFO - 2016-11-30 16:08:22 --> Form Validation Class Initialized
INFO - 2016-11-30 16:08:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:08:22 --> Pagination Class Initialized
INFO - 2016-11-30 16:08:22 --> Helper loaded: app_helper
INFO - 2016-11-30 16:08:22 --> Email Class Initialized
INFO - 2016-11-30 16:08:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 16:08:22 --> Final output sent to browser
DEBUG - 2016-11-30 16:08:22 --> Total execution time: 0.6543
INFO - 2016-11-30 16:08:29 --> Config Class Initialized
INFO - 2016-11-30 16:08:29 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:08:29 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:08:29 --> Utf8 Class Initialized
INFO - 2016-11-30 16:08:29 --> URI Class Initialized
DEBUG - 2016-11-30 16:08:29 --> No URI present. Default controller set.
INFO - 2016-11-30 16:08:29 --> Router Class Initialized
INFO - 2016-11-30 16:08:29 --> Output Class Initialized
INFO - 2016-11-30 16:08:29 --> Security Class Initialized
DEBUG - 2016-11-30 16:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:08:29 --> Input Class Initialized
INFO - 2016-11-30 16:08:29 --> Language Class Initialized
INFO - 2016-11-30 16:08:29 --> Loader Class Initialized
INFO - 2016-11-30 16:08:29 --> Helper loaded: url_helper
INFO - 2016-11-30 16:08:29 --> Helper loaded: form_helper
INFO - 2016-11-30 16:08:29 --> Database Driver Class Initialized
INFO - 2016-11-30 16:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:08:29 --> Controller Class Initialized
INFO - 2016-11-30 16:08:29 --> Model Class Initialized
INFO - 2016-11-30 16:08:29 --> Model Class Initialized
INFO - 2016-11-30 16:08:29 --> Model Class Initialized
INFO - 2016-11-30 16:08:29 --> Model Class Initialized
INFO - 2016-11-30 16:08:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:08:29 --> Pagination Class Initialized
INFO - 2016-11-30 16:08:29 --> Helper loaded: app_helper
INFO - 2016-11-30 16:08:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:08:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:08:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:08:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:08:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:08:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:08:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:08:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:08:30 --> Final output sent to browser
DEBUG - 2016-11-30 16:08:30 --> Total execution time: 0.7882
INFO - 2016-11-30 16:11:46 --> Config Class Initialized
INFO - 2016-11-30 16:11:47 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:11:47 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:11:47 --> Utf8 Class Initialized
INFO - 2016-11-30 16:11:47 --> URI Class Initialized
INFO - 2016-11-30 16:11:47 --> Router Class Initialized
INFO - 2016-11-30 16:11:47 --> Output Class Initialized
INFO - 2016-11-30 16:11:47 --> Security Class Initialized
DEBUG - 2016-11-30 16:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:11:47 --> Input Class Initialized
INFO - 2016-11-30 16:11:47 --> Language Class Initialized
INFO - 2016-11-30 16:11:47 --> Loader Class Initialized
INFO - 2016-11-30 16:11:47 --> Helper loaded: url_helper
INFO - 2016-11-30 16:11:47 --> Helper loaded: form_helper
INFO - 2016-11-30 16:11:47 --> Database Driver Class Initialized
INFO - 2016-11-30 16:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:11:47 --> Controller Class Initialized
INFO - 2016-11-30 16:11:47 --> Model Class Initialized
INFO - 2016-11-30 16:11:47 --> Form Validation Class Initialized
INFO - 2016-11-30 16:11:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:11:47 --> Pagination Class Initialized
INFO - 2016-11-30 16:11:47 --> Helper loaded: app_helper
INFO - 2016-11-30 16:11:47 --> Email Class Initialized
INFO - 2016-11-30 16:11:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 16:11:47 --> Final output sent to browser
DEBUG - 2016-11-30 16:11:47 --> Total execution time: 0.6335
INFO - 2016-11-30 16:13:40 --> Config Class Initialized
INFO - 2016-11-30 16:13:40 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:13:40 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:13:40 --> Utf8 Class Initialized
INFO - 2016-11-30 16:13:40 --> URI Class Initialized
DEBUG - 2016-11-30 16:13:40 --> No URI present. Default controller set.
INFO - 2016-11-30 16:13:40 --> Router Class Initialized
INFO - 2016-11-30 16:13:40 --> Output Class Initialized
INFO - 2016-11-30 16:13:40 --> Security Class Initialized
DEBUG - 2016-11-30 16:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:13:40 --> Input Class Initialized
INFO - 2016-11-30 16:13:40 --> Language Class Initialized
INFO - 2016-11-30 16:13:40 --> Loader Class Initialized
INFO - 2016-11-30 16:13:40 --> Helper loaded: url_helper
INFO - 2016-11-30 16:13:40 --> Helper loaded: form_helper
INFO - 2016-11-30 16:13:40 --> Database Driver Class Initialized
INFO - 2016-11-30 16:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:13:40 --> Controller Class Initialized
INFO - 2016-11-30 16:13:41 --> Model Class Initialized
INFO - 2016-11-30 16:13:41 --> Model Class Initialized
INFO - 2016-11-30 16:13:41 --> Model Class Initialized
INFO - 2016-11-30 16:13:41 --> Model Class Initialized
INFO - 2016-11-30 16:13:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:13:41 --> Pagination Class Initialized
INFO - 2016-11-30 16:13:41 --> Helper loaded: app_helper
INFO - 2016-11-30 16:13:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:13:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:13:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:13:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:13:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:13:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:13:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:13:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:13:41 --> Final output sent to browser
DEBUG - 2016-11-30 16:13:41 --> Total execution time: 0.9464
INFO - 2016-11-30 16:13:53 --> Config Class Initialized
INFO - 2016-11-30 16:13:53 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:13:53 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:13:53 --> Utf8 Class Initialized
INFO - 2016-11-30 16:13:53 --> URI Class Initialized
DEBUG - 2016-11-30 16:13:53 --> No URI present. Default controller set.
INFO - 2016-11-30 16:13:53 --> Router Class Initialized
INFO - 2016-11-30 16:13:53 --> Output Class Initialized
INFO - 2016-11-30 16:13:53 --> Security Class Initialized
DEBUG - 2016-11-30 16:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:13:53 --> Input Class Initialized
INFO - 2016-11-30 16:13:53 --> Language Class Initialized
INFO - 2016-11-30 16:13:53 --> Loader Class Initialized
INFO - 2016-11-30 16:13:53 --> Helper loaded: url_helper
INFO - 2016-11-30 16:13:53 --> Helper loaded: form_helper
INFO - 2016-11-30 16:13:53 --> Database Driver Class Initialized
INFO - 2016-11-30 16:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:13:53 --> Controller Class Initialized
INFO - 2016-11-30 16:13:53 --> Model Class Initialized
INFO - 2016-11-30 16:13:53 --> Model Class Initialized
INFO - 2016-11-30 16:13:53 --> Model Class Initialized
INFO - 2016-11-30 16:13:53 --> Model Class Initialized
INFO - 2016-11-30 16:13:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:13:53 --> Pagination Class Initialized
INFO - 2016-11-30 16:13:53 --> Helper loaded: app_helper
INFO - 2016-11-30 16:13:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:13:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:13:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:13:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:13:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:13:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:13:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:13:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:13:54 --> Final output sent to browser
DEBUG - 2016-11-30 16:13:54 --> Total execution time: 0.7371
INFO - 2016-11-30 16:14:01 --> Config Class Initialized
INFO - 2016-11-30 16:14:01 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:14:01 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:14:01 --> Utf8 Class Initialized
INFO - 2016-11-30 16:14:01 --> URI Class Initialized
INFO - 2016-11-30 16:14:01 --> Router Class Initialized
INFO - 2016-11-30 16:14:01 --> Output Class Initialized
INFO - 2016-11-30 16:14:01 --> Security Class Initialized
DEBUG - 2016-11-30 16:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:14:01 --> Input Class Initialized
INFO - 2016-11-30 16:14:01 --> Language Class Initialized
INFO - 2016-11-30 16:14:01 --> Loader Class Initialized
INFO - 2016-11-30 16:14:01 --> Helper loaded: url_helper
INFO - 2016-11-30 16:14:02 --> Helper loaded: form_helper
INFO - 2016-11-30 16:14:02 --> Database Driver Class Initialized
INFO - 2016-11-30 16:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:14:02 --> Controller Class Initialized
INFO - 2016-11-30 16:14:02 --> Model Class Initialized
INFO - 2016-11-30 16:14:02 --> Form Validation Class Initialized
INFO - 2016-11-30 16:14:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:14:02 --> Pagination Class Initialized
INFO - 2016-11-30 16:14:02 --> Helper loaded: app_helper
INFO - 2016-11-30 16:14:02 --> Email Class Initialized
INFO - 2016-11-30 16:14:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 16:14:02 --> Final output sent to browser
DEBUG - 2016-11-30 16:14:02 --> Total execution time: 0.5063
INFO - 2016-11-30 16:14:14 --> Config Class Initialized
INFO - 2016-11-30 16:14:14 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:14:14 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:14:14 --> Utf8 Class Initialized
INFO - 2016-11-30 16:14:14 --> URI Class Initialized
INFO - 2016-11-30 16:14:14 --> Router Class Initialized
INFO - 2016-11-30 16:14:14 --> Output Class Initialized
INFO - 2016-11-30 16:14:14 --> Security Class Initialized
DEBUG - 2016-11-30 16:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:14:14 --> Input Class Initialized
INFO - 2016-11-30 16:14:14 --> Language Class Initialized
INFO - 2016-11-30 16:14:14 --> Loader Class Initialized
INFO - 2016-11-30 16:14:14 --> Helper loaded: url_helper
INFO - 2016-11-30 16:14:14 --> Helper loaded: form_helper
INFO - 2016-11-30 16:14:14 --> Database Driver Class Initialized
INFO - 2016-11-30 16:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:14:14 --> Controller Class Initialized
INFO - 2016-11-30 16:14:14 --> Model Class Initialized
INFO - 2016-11-30 16:14:14 --> Form Validation Class Initialized
INFO - 2016-11-30 16:14:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:14:14 --> Pagination Class Initialized
INFO - 2016-11-30 16:14:14 --> Helper loaded: app_helper
INFO - 2016-11-30 16:14:14 --> Email Class Initialized
INFO - 2016-11-30 16:14:14 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-30 15:14:14 --> Severity: Notice --> Undefined variable: hash C:\xampp\htdocs\LMS\app\views\email_template.php 49
INFO - 2016-11-30 15:14:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 15:14:14 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-30 15:14:16 --> Severity: Warning --> fsockopen(): unable to connect to localhost:465 (No connection could be made because the target machine actively refused it.
) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-11-30 15:14:16 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-30 15:14:16 --> Severity: Notice --> Undefined variable: hash C:\xampp\htdocs\LMS\app\views\email_template.php 49
INFO - 2016-11-30 15:14:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
ERROR - 2016-11-30 15:14:18 --> Severity: Warning --> fsockopen(): unable to connect to localhost:465 (No connection could be made because the target machine actively refused it.
) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-11-30 15:14:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 15:14:19 --> Final output sent to browser
DEBUG - 2016-11-30 15:14:19 --> Total execution time: 4.9703
INFO - 2016-11-30 16:17:41 --> Config Class Initialized
INFO - 2016-11-30 16:17:41 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:17:41 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:17:41 --> Utf8 Class Initialized
INFO - 2016-11-30 16:17:41 --> URI Class Initialized
DEBUG - 2016-11-30 16:17:41 --> No URI present. Default controller set.
INFO - 2016-11-30 16:17:41 --> Router Class Initialized
INFO - 2016-11-30 16:17:41 --> Output Class Initialized
INFO - 2016-11-30 16:17:41 --> Security Class Initialized
DEBUG - 2016-11-30 16:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:17:41 --> Input Class Initialized
INFO - 2016-11-30 16:17:41 --> Language Class Initialized
INFO - 2016-11-30 16:17:41 --> Loader Class Initialized
INFO - 2016-11-30 16:17:41 --> Helper loaded: url_helper
INFO - 2016-11-30 16:17:41 --> Helper loaded: form_helper
INFO - 2016-11-30 16:17:41 --> Database Driver Class Initialized
INFO - 2016-11-30 16:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:17:42 --> Controller Class Initialized
INFO - 2016-11-30 16:17:42 --> Model Class Initialized
INFO - 2016-11-30 16:17:42 --> Model Class Initialized
INFO - 2016-11-30 16:17:42 --> Model Class Initialized
INFO - 2016-11-30 16:17:42 --> Model Class Initialized
INFO - 2016-11-30 16:17:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:17:42 --> Pagination Class Initialized
INFO - 2016-11-30 16:17:42 --> Helper loaded: app_helper
INFO - 2016-11-30 16:17:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:17:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:17:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:17:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:17:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:17:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:17:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:17:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:17:42 --> Final output sent to browser
DEBUG - 2016-11-30 16:17:42 --> Total execution time: 1.0103
INFO - 2016-11-30 16:17:48 --> Config Class Initialized
INFO - 2016-11-30 16:17:48 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:17:48 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:17:48 --> Utf8 Class Initialized
INFO - 2016-11-30 16:17:48 --> URI Class Initialized
INFO - 2016-11-30 16:17:48 --> Router Class Initialized
INFO - 2016-11-30 16:17:48 --> Output Class Initialized
INFO - 2016-11-30 16:17:48 --> Security Class Initialized
DEBUG - 2016-11-30 16:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:17:48 --> Input Class Initialized
INFO - 2016-11-30 16:17:48 --> Language Class Initialized
INFO - 2016-11-30 16:17:48 --> Loader Class Initialized
INFO - 2016-11-30 16:17:48 --> Helper loaded: url_helper
INFO - 2016-11-30 16:17:48 --> Helper loaded: form_helper
INFO - 2016-11-30 16:17:48 --> Database Driver Class Initialized
INFO - 2016-11-30 16:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:17:48 --> Controller Class Initialized
INFO - 2016-11-30 16:17:48 --> Model Class Initialized
INFO - 2016-11-30 16:17:48 --> Form Validation Class Initialized
INFO - 2016-11-30 16:17:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:17:48 --> Pagination Class Initialized
INFO - 2016-11-30 16:17:48 --> Helper loaded: app_helper
INFO - 2016-11-30 16:17:48 --> Email Class Initialized
INFO - 2016-11-30 16:17:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 16:17:48 --> Final output sent to browser
DEBUG - 2016-11-30 16:17:48 --> Total execution time: 0.5174
INFO - 2016-11-30 16:18:00 --> Config Class Initialized
INFO - 2016-11-30 16:18:00 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:18:00 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:18:00 --> Utf8 Class Initialized
INFO - 2016-11-30 16:18:00 --> URI Class Initialized
INFO - 2016-11-30 16:18:00 --> Router Class Initialized
INFO - 2016-11-30 16:18:00 --> Output Class Initialized
INFO - 2016-11-30 16:18:00 --> Security Class Initialized
DEBUG - 2016-11-30 16:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:18:00 --> Input Class Initialized
INFO - 2016-11-30 16:18:00 --> Language Class Initialized
INFO - 2016-11-30 16:18:00 --> Loader Class Initialized
INFO - 2016-11-30 16:18:00 --> Helper loaded: url_helper
INFO - 2016-11-30 16:18:00 --> Helper loaded: form_helper
INFO - 2016-11-30 16:18:00 --> Database Driver Class Initialized
INFO - 2016-11-30 16:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:18:00 --> Controller Class Initialized
INFO - 2016-11-30 16:18:00 --> Model Class Initialized
INFO - 2016-11-30 16:18:00 --> Form Validation Class Initialized
INFO - 2016-11-30 16:18:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:18:00 --> Pagination Class Initialized
INFO - 2016-11-30 16:18:00 --> Helper loaded: app_helper
INFO - 2016-11-30 16:18:00 --> Email Class Initialized
INFO - 2016-11-30 16:18:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 16:18:00 --> Final output sent to browser
DEBUG - 2016-11-30 16:18:00 --> Total execution time: 0.5440
INFO - 2016-11-30 16:18:07 --> Config Class Initialized
INFO - 2016-11-30 16:18:07 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:18:07 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:18:07 --> Utf8 Class Initialized
INFO - 2016-11-30 16:18:07 --> URI Class Initialized
INFO - 2016-11-30 16:18:07 --> Router Class Initialized
INFO - 2016-11-30 16:18:07 --> Output Class Initialized
INFO - 2016-11-30 16:18:07 --> Security Class Initialized
DEBUG - 2016-11-30 16:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:18:07 --> Input Class Initialized
INFO - 2016-11-30 16:18:07 --> Language Class Initialized
INFO - 2016-11-30 16:18:07 --> Loader Class Initialized
INFO - 2016-11-30 16:18:07 --> Helper loaded: url_helper
INFO - 2016-11-30 16:18:07 --> Helper loaded: form_helper
INFO - 2016-11-30 16:18:07 --> Database Driver Class Initialized
INFO - 2016-11-30 16:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:18:07 --> Controller Class Initialized
INFO - 2016-11-30 16:18:07 --> Model Class Initialized
INFO - 2016-11-30 16:18:07 --> Form Validation Class Initialized
INFO - 2016-11-30 16:18:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:18:07 --> Pagination Class Initialized
INFO - 2016-11-30 16:18:07 --> Helper loaded: app_helper
INFO - 2016-11-30 16:18:07 --> Email Class Initialized
INFO - 2016-11-30 16:18:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 16:18:07 --> Final output sent to browser
DEBUG - 2016-11-30 16:18:07 --> Total execution time: 0.5422
INFO - 2016-11-30 16:18:18 --> Config Class Initialized
INFO - 2016-11-30 16:18:18 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:18:18 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:18:18 --> Utf8 Class Initialized
INFO - 2016-11-30 16:18:18 --> URI Class Initialized
INFO - 2016-11-30 16:18:18 --> Router Class Initialized
INFO - 2016-11-30 16:18:18 --> Output Class Initialized
INFO - 2016-11-30 16:18:18 --> Security Class Initialized
DEBUG - 2016-11-30 16:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:18:18 --> Input Class Initialized
INFO - 2016-11-30 16:18:18 --> Language Class Initialized
INFO - 2016-11-30 16:18:18 --> Loader Class Initialized
INFO - 2016-11-30 16:18:19 --> Helper loaded: url_helper
INFO - 2016-11-30 16:18:19 --> Helper loaded: form_helper
INFO - 2016-11-30 16:18:19 --> Database Driver Class Initialized
INFO - 2016-11-30 16:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:18:19 --> Controller Class Initialized
INFO - 2016-11-30 16:18:19 --> Model Class Initialized
INFO - 2016-11-30 16:18:19 --> Form Validation Class Initialized
INFO - 2016-11-30 16:18:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:18:19 --> Pagination Class Initialized
INFO - 2016-11-30 16:18:19 --> Helper loaded: app_helper
INFO - 2016-11-30 16:18:19 --> Email Class Initialized
INFO - 2016-11-30 16:18:19 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-30 15:18:19 --> Severity: Notice --> Undefined variable: hash C:\xampp\htdocs\LMS\app\views\email_template.php 49
INFO - 2016-11-30 15:18:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 15:18:19 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 15:18:20 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-30 15:18:20 --> Severity: Notice --> Undefined variable: hash C:\xampp\htdocs\LMS\app\views\email_template.php 49
INFO - 2016-11-30 15:18:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-30 15:18:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 15:18:20 --> Final output sent to browser
DEBUG - 2016-11-30 15:18:20 --> Total execution time: 2.1821
INFO - 2016-11-30 16:18:26 --> Config Class Initialized
INFO - 2016-11-30 16:18:26 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:18:26 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:18:26 --> Utf8 Class Initialized
INFO - 2016-11-30 16:18:26 --> URI Class Initialized
DEBUG - 2016-11-30 16:18:26 --> No URI present. Default controller set.
INFO - 2016-11-30 16:18:26 --> Router Class Initialized
INFO - 2016-11-30 16:18:26 --> Output Class Initialized
INFO - 2016-11-30 16:18:26 --> Security Class Initialized
DEBUG - 2016-11-30 16:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:18:26 --> Input Class Initialized
INFO - 2016-11-30 16:18:26 --> Language Class Initialized
INFO - 2016-11-30 16:18:26 --> Loader Class Initialized
INFO - 2016-11-30 16:18:26 --> Helper loaded: url_helper
INFO - 2016-11-30 16:18:26 --> Helper loaded: form_helper
INFO - 2016-11-30 16:18:26 --> Database Driver Class Initialized
INFO - 2016-11-30 16:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:18:26 --> Controller Class Initialized
INFO - 2016-11-30 16:18:26 --> Model Class Initialized
INFO - 2016-11-30 16:18:26 --> Model Class Initialized
INFO - 2016-11-30 16:18:27 --> Model Class Initialized
INFO - 2016-11-30 16:18:27 --> Model Class Initialized
INFO - 2016-11-30 16:18:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:18:27 --> Pagination Class Initialized
INFO - 2016-11-30 16:18:27 --> Helper loaded: app_helper
INFO - 2016-11-30 16:18:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:18:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:18:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:18:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:18:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:18:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:18:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:18:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:18:27 --> Final output sent to browser
DEBUG - 2016-11-30 16:18:27 --> Total execution time: 0.7519
INFO - 2016-11-30 16:18:31 --> Config Class Initialized
INFO - 2016-11-30 16:18:31 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:18:31 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:18:31 --> Utf8 Class Initialized
INFO - 2016-11-30 16:18:31 --> URI Class Initialized
DEBUG - 2016-11-30 16:18:31 --> No URI present. Default controller set.
INFO - 2016-11-30 16:18:31 --> Router Class Initialized
INFO - 2016-11-30 16:18:31 --> Output Class Initialized
INFO - 2016-11-30 16:18:31 --> Security Class Initialized
DEBUG - 2016-11-30 16:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:18:31 --> Input Class Initialized
INFO - 2016-11-30 16:18:31 --> Language Class Initialized
INFO - 2016-11-30 16:18:31 --> Loader Class Initialized
INFO - 2016-11-30 16:18:31 --> Helper loaded: url_helper
INFO - 2016-11-30 16:18:31 --> Helper loaded: form_helper
INFO - 2016-11-30 16:18:31 --> Database Driver Class Initialized
INFO - 2016-11-30 16:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:18:31 --> Controller Class Initialized
INFO - 2016-11-30 16:18:31 --> Model Class Initialized
INFO - 2016-11-30 16:18:31 --> Model Class Initialized
INFO - 2016-11-30 16:18:31 --> Model Class Initialized
INFO - 2016-11-30 16:18:31 --> Model Class Initialized
INFO - 2016-11-30 16:18:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:18:31 --> Pagination Class Initialized
INFO - 2016-11-30 16:18:31 --> Helper loaded: app_helper
INFO - 2016-11-30 16:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:18:31 --> Final output sent to browser
DEBUG - 2016-11-30 16:18:31 --> Total execution time: 0.7794
INFO - 2016-11-30 16:19:31 --> Config Class Initialized
INFO - 2016-11-30 16:19:31 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:19:32 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:19:32 --> Utf8 Class Initialized
INFO - 2016-11-30 16:19:32 --> URI Class Initialized
DEBUG - 2016-11-30 16:19:32 --> No URI present. Default controller set.
INFO - 2016-11-30 16:19:32 --> Router Class Initialized
INFO - 2016-11-30 16:19:32 --> Output Class Initialized
INFO - 2016-11-30 16:19:32 --> Security Class Initialized
DEBUG - 2016-11-30 16:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:19:32 --> Input Class Initialized
INFO - 2016-11-30 16:19:32 --> Language Class Initialized
INFO - 2016-11-30 16:19:32 --> Loader Class Initialized
INFO - 2016-11-30 16:19:32 --> Helper loaded: url_helper
INFO - 2016-11-30 16:19:32 --> Helper loaded: form_helper
INFO - 2016-11-30 16:19:32 --> Database Driver Class Initialized
INFO - 2016-11-30 16:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:19:32 --> Controller Class Initialized
INFO - 2016-11-30 16:19:32 --> Model Class Initialized
INFO - 2016-11-30 16:19:32 --> Model Class Initialized
INFO - 2016-11-30 16:19:32 --> Model Class Initialized
INFO - 2016-11-30 16:19:32 --> Model Class Initialized
INFO - 2016-11-30 16:19:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:19:32 --> Pagination Class Initialized
INFO - 2016-11-30 16:19:32 --> Helper loaded: app_helper
INFO - 2016-11-30 16:19:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:19:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:19:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:19:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:19:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:19:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:19:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:19:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:19:32 --> Final output sent to browser
DEBUG - 2016-11-30 16:19:32 --> Total execution time: 0.7500
INFO - 2016-11-30 16:19:57 --> Config Class Initialized
INFO - 2016-11-30 16:19:57 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:19:57 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:19:57 --> Utf8 Class Initialized
INFO - 2016-11-30 16:19:57 --> URI Class Initialized
DEBUG - 2016-11-30 16:19:57 --> No URI present. Default controller set.
INFO - 2016-11-30 16:19:57 --> Router Class Initialized
INFO - 2016-11-30 16:19:57 --> Output Class Initialized
INFO - 2016-11-30 16:19:57 --> Security Class Initialized
DEBUG - 2016-11-30 16:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:19:58 --> Input Class Initialized
INFO - 2016-11-30 16:19:58 --> Language Class Initialized
INFO - 2016-11-30 16:19:58 --> Loader Class Initialized
INFO - 2016-11-30 16:19:58 --> Helper loaded: url_helper
INFO - 2016-11-30 16:19:58 --> Helper loaded: form_helper
INFO - 2016-11-30 16:19:58 --> Database Driver Class Initialized
INFO - 2016-11-30 16:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:19:58 --> Controller Class Initialized
INFO - 2016-11-30 16:19:58 --> Model Class Initialized
INFO - 2016-11-30 16:19:58 --> Model Class Initialized
INFO - 2016-11-30 16:19:58 --> Model Class Initialized
INFO - 2016-11-30 16:19:58 --> Model Class Initialized
INFO - 2016-11-30 16:19:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:19:58 --> Pagination Class Initialized
INFO - 2016-11-30 16:19:58 --> Helper loaded: app_helper
INFO - 2016-11-30 16:19:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:19:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:19:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:19:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:19:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:19:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:19:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:19:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:19:58 --> Final output sent to browser
DEBUG - 2016-11-30 16:19:58 --> Total execution time: 0.8165
INFO - 2016-11-30 16:20:18 --> Config Class Initialized
INFO - 2016-11-30 16:20:18 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:20:18 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:20:18 --> Utf8 Class Initialized
INFO - 2016-11-30 16:20:18 --> URI Class Initialized
DEBUG - 2016-11-30 16:20:18 --> No URI present. Default controller set.
INFO - 2016-11-30 16:20:18 --> Router Class Initialized
INFO - 2016-11-30 16:20:18 --> Output Class Initialized
INFO - 2016-11-30 16:20:18 --> Security Class Initialized
DEBUG - 2016-11-30 16:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:20:18 --> Input Class Initialized
INFO - 2016-11-30 16:20:18 --> Language Class Initialized
INFO - 2016-11-30 16:20:18 --> Loader Class Initialized
INFO - 2016-11-30 16:20:18 --> Helper loaded: url_helper
INFO - 2016-11-30 16:20:18 --> Helper loaded: form_helper
INFO - 2016-11-30 16:20:18 --> Database Driver Class Initialized
INFO - 2016-11-30 16:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:20:19 --> Controller Class Initialized
INFO - 2016-11-30 16:20:19 --> Model Class Initialized
INFO - 2016-11-30 16:20:19 --> Model Class Initialized
INFO - 2016-11-30 16:20:19 --> Model Class Initialized
INFO - 2016-11-30 16:20:19 --> Model Class Initialized
INFO - 2016-11-30 16:20:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:20:19 --> Pagination Class Initialized
INFO - 2016-11-30 16:20:19 --> Helper loaded: app_helper
INFO - 2016-11-30 16:20:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:20:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:20:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:20:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:20:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:20:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:20:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:20:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:20:19 --> Final output sent to browser
DEBUG - 2016-11-30 16:20:19 --> Total execution time: 0.8105
INFO - 2016-11-30 16:20:43 --> Config Class Initialized
INFO - 2016-11-30 16:20:43 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:20:43 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:20:43 --> Utf8 Class Initialized
INFO - 2016-11-30 16:20:43 --> URI Class Initialized
DEBUG - 2016-11-30 16:20:43 --> No URI present. Default controller set.
INFO - 2016-11-30 16:20:43 --> Router Class Initialized
INFO - 2016-11-30 16:20:43 --> Output Class Initialized
INFO - 2016-11-30 16:20:43 --> Security Class Initialized
DEBUG - 2016-11-30 16:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:20:43 --> Input Class Initialized
INFO - 2016-11-30 16:20:43 --> Language Class Initialized
INFO - 2016-11-30 16:20:43 --> Loader Class Initialized
INFO - 2016-11-30 16:20:43 --> Helper loaded: url_helper
INFO - 2016-11-30 16:20:43 --> Helper loaded: form_helper
INFO - 2016-11-30 16:20:43 --> Database Driver Class Initialized
INFO - 2016-11-30 16:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:20:43 --> Controller Class Initialized
INFO - 2016-11-30 16:20:43 --> Model Class Initialized
INFO - 2016-11-30 16:20:43 --> Model Class Initialized
INFO - 2016-11-30 16:20:44 --> Model Class Initialized
INFO - 2016-11-30 16:20:44 --> Model Class Initialized
INFO - 2016-11-30 16:20:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:20:44 --> Pagination Class Initialized
INFO - 2016-11-30 16:20:44 --> Helper loaded: app_helper
INFO - 2016-11-30 16:20:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:20:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:20:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:20:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:20:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:20:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:20:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:20:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:20:44 --> Final output sent to browser
DEBUG - 2016-11-30 16:20:44 --> Total execution time: 0.7757
INFO - 2016-11-30 16:22:41 --> Config Class Initialized
INFO - 2016-11-30 16:22:42 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:22:42 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:22:42 --> Utf8 Class Initialized
INFO - 2016-11-30 16:22:42 --> URI Class Initialized
DEBUG - 2016-11-30 16:22:42 --> No URI present. Default controller set.
INFO - 2016-11-30 16:22:42 --> Router Class Initialized
INFO - 2016-11-30 16:22:42 --> Output Class Initialized
INFO - 2016-11-30 16:22:42 --> Security Class Initialized
DEBUG - 2016-11-30 16:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:22:42 --> Input Class Initialized
INFO - 2016-11-30 16:22:42 --> Language Class Initialized
INFO - 2016-11-30 16:22:42 --> Loader Class Initialized
INFO - 2016-11-30 16:22:42 --> Helper loaded: url_helper
INFO - 2016-11-30 16:22:42 --> Helper loaded: form_helper
INFO - 2016-11-30 16:22:42 --> Database Driver Class Initialized
INFO - 2016-11-30 16:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:22:42 --> Controller Class Initialized
INFO - 2016-11-30 16:22:42 --> Model Class Initialized
INFO - 2016-11-30 16:22:42 --> Model Class Initialized
INFO - 2016-11-30 16:22:42 --> Model Class Initialized
INFO - 2016-11-30 16:22:42 --> Model Class Initialized
INFO - 2016-11-30 16:22:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:22:42 --> Pagination Class Initialized
INFO - 2016-11-30 16:22:42 --> Helper loaded: app_helper
INFO - 2016-11-30 16:22:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:22:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:22:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:22:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:22:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:22:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:22:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:22:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:22:42 --> Final output sent to browser
DEBUG - 2016-11-30 16:22:42 --> Total execution time: 0.7761
INFO - 2016-11-30 16:22:51 --> Config Class Initialized
INFO - 2016-11-30 16:22:51 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:22:51 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:22:51 --> Utf8 Class Initialized
INFO - 2016-11-30 16:22:51 --> URI Class Initialized
INFO - 2016-11-30 16:22:51 --> Router Class Initialized
INFO - 2016-11-30 16:22:51 --> Output Class Initialized
INFO - 2016-11-30 16:22:51 --> Security Class Initialized
DEBUG - 2016-11-30 16:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:22:51 --> Input Class Initialized
INFO - 2016-11-30 16:22:51 --> Language Class Initialized
INFO - 2016-11-30 16:22:51 --> Loader Class Initialized
INFO - 2016-11-30 16:22:51 --> Helper loaded: url_helper
INFO - 2016-11-30 16:22:51 --> Helper loaded: form_helper
INFO - 2016-11-30 16:22:51 --> Database Driver Class Initialized
INFO - 2016-11-30 16:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:22:51 --> Controller Class Initialized
INFO - 2016-11-30 16:22:51 --> Model Class Initialized
INFO - 2016-11-30 16:22:51 --> Form Validation Class Initialized
INFO - 2016-11-30 16:22:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:22:51 --> Pagination Class Initialized
INFO - 2016-11-30 16:22:51 --> Helper loaded: app_helper
INFO - 2016-11-30 16:22:51 --> Email Class Initialized
INFO - 2016-11-30 16:22:51 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-30 15:22:51 --> Severity: Notice --> Undefined variable: hash C:\xampp\htdocs\LMS\app\views\email_template.php 49
INFO - 2016-11-30 15:22:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 15:22:51 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 15:22:53 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-30 15:22:53 --> Severity: Notice --> Undefined variable: hash C:\xampp\htdocs\LMS\app\views\email_template.php 49
INFO - 2016-11-30 15:22:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
ERROR - 2016-11-30 15:22:53 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 21
INFO - 2016-11-30 15:22:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 15:22:53 --> Final output sent to browser
DEBUG - 2016-11-30 15:22:53 --> Total execution time: 2.4710
INFO - 2016-11-30 16:25:19 --> Config Class Initialized
INFO - 2016-11-30 16:25:19 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:25:19 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:25:19 --> Utf8 Class Initialized
INFO - 2016-11-30 16:25:20 --> URI Class Initialized
DEBUG - 2016-11-30 16:25:20 --> No URI present. Default controller set.
INFO - 2016-11-30 16:25:20 --> Router Class Initialized
INFO - 2016-11-30 16:25:20 --> Output Class Initialized
INFO - 2016-11-30 16:25:20 --> Security Class Initialized
DEBUG - 2016-11-30 16:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:25:20 --> Input Class Initialized
INFO - 2016-11-30 16:25:20 --> Language Class Initialized
INFO - 2016-11-30 16:25:20 --> Loader Class Initialized
INFO - 2016-11-30 16:25:20 --> Helper loaded: url_helper
INFO - 2016-11-30 16:25:20 --> Helper loaded: form_helper
INFO - 2016-11-30 16:25:20 --> Database Driver Class Initialized
INFO - 2016-11-30 16:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:25:20 --> Controller Class Initialized
INFO - 2016-11-30 16:25:20 --> Model Class Initialized
INFO - 2016-11-30 16:25:20 --> Model Class Initialized
ERROR - 2016-11-30 16:25:20 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 21
INFO - 2016-11-30 16:26:08 --> Config Class Initialized
INFO - 2016-11-30 16:26:08 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:26:08 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:26:08 --> Utf8 Class Initialized
INFO - 2016-11-30 16:26:08 --> URI Class Initialized
DEBUG - 2016-11-30 16:26:08 --> No URI present. Default controller set.
INFO - 2016-11-30 16:26:08 --> Router Class Initialized
INFO - 2016-11-30 16:26:08 --> Output Class Initialized
INFO - 2016-11-30 16:26:08 --> Security Class Initialized
DEBUG - 2016-11-30 16:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:26:08 --> Input Class Initialized
INFO - 2016-11-30 16:26:08 --> Language Class Initialized
INFO - 2016-11-30 16:26:08 --> Loader Class Initialized
INFO - 2016-11-30 16:26:08 --> Helper loaded: url_helper
INFO - 2016-11-30 16:26:08 --> Helper loaded: form_helper
INFO - 2016-11-30 16:26:08 --> Database Driver Class Initialized
INFO - 2016-11-30 16:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:26:08 --> Controller Class Initialized
INFO - 2016-11-30 16:26:08 --> Model Class Initialized
INFO - 2016-11-30 16:26:08 --> Model Class Initialized
ERROR - 2016-11-30 16:26:08 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 21
INFO - 2016-11-30 16:28:13 --> Config Class Initialized
INFO - 2016-11-30 16:28:13 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:28:13 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:28:13 --> Utf8 Class Initialized
INFO - 2016-11-30 16:28:13 --> URI Class Initialized
DEBUG - 2016-11-30 16:28:13 --> No URI present. Default controller set.
INFO - 2016-11-30 16:28:13 --> Router Class Initialized
INFO - 2016-11-30 16:28:13 --> Output Class Initialized
INFO - 2016-11-30 16:28:13 --> Security Class Initialized
DEBUG - 2016-11-30 16:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:28:13 --> Input Class Initialized
INFO - 2016-11-30 16:28:13 --> Language Class Initialized
INFO - 2016-11-30 16:28:13 --> Loader Class Initialized
INFO - 2016-11-30 16:28:13 --> Helper loaded: url_helper
INFO - 2016-11-30 16:28:13 --> Helper loaded: form_helper
INFO - 2016-11-30 16:28:13 --> Database Driver Class Initialized
INFO - 2016-11-30 16:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:28:13 --> Controller Class Initialized
INFO - 2016-11-30 16:28:13 --> Model Class Initialized
INFO - 2016-11-30 16:28:13 --> Model Class Initialized
INFO - 2016-11-30 16:28:13 --> Model Class Initialized
INFO - 2016-11-30 16:28:13 --> Model Class Initialized
INFO - 2016-11-30 16:28:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:28:13 --> Pagination Class Initialized
INFO - 2016-11-30 16:28:13 --> Helper loaded: app_helper
INFO - 2016-11-30 16:28:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:28:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:28:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:28:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
ERROR - 2016-11-30 16:28:14 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 21
INFO - 2016-11-30 16:28:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:28:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:28:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:28:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:28:14 --> Final output sent to browser
DEBUG - 2016-11-30 16:28:14 --> Total execution time: 0.7702
INFO - 2016-11-30 16:28:57 --> Config Class Initialized
INFO - 2016-11-30 16:28:57 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:28:57 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:28:57 --> Utf8 Class Initialized
INFO - 2016-11-30 16:28:57 --> URI Class Initialized
DEBUG - 2016-11-30 16:28:57 --> No URI present. Default controller set.
INFO - 2016-11-30 16:28:57 --> Router Class Initialized
INFO - 2016-11-30 16:28:57 --> Output Class Initialized
INFO - 2016-11-30 16:28:57 --> Security Class Initialized
DEBUG - 2016-11-30 16:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:28:57 --> Input Class Initialized
INFO - 2016-11-30 16:28:57 --> Language Class Initialized
INFO - 2016-11-30 16:28:57 --> Loader Class Initialized
INFO - 2016-11-30 16:28:57 --> Helper loaded: url_helper
INFO - 2016-11-30 16:28:57 --> Helper loaded: form_helper
INFO - 2016-11-30 16:28:57 --> Database Driver Class Initialized
INFO - 2016-11-30 16:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:28:57 --> Controller Class Initialized
INFO - 2016-11-30 16:28:57 --> Model Class Initialized
INFO - 2016-11-30 16:28:57 --> Model Class Initialized
INFO - 2016-11-30 16:28:57 --> Model Class Initialized
INFO - 2016-11-30 16:28:57 --> Model Class Initialized
INFO - 2016-11-30 16:28:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:28:57 --> Pagination Class Initialized
INFO - 2016-11-30 16:28:57 --> Helper loaded: app_helper
INFO - 2016-11-30 16:28:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:28:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-30 16:28:57 --> Severity: Notice --> Undefined variable: idLeaveType C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 14
INFO - 2016-11-30 16:28:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:28:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:28:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:28:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:28:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:28:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:28:57 --> Final output sent to browser
DEBUG - 2016-11-30 16:28:57 --> Total execution time: 0.7517
INFO - 2016-11-30 16:29:17 --> Config Class Initialized
INFO - 2016-11-30 16:29:17 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:29:17 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:29:17 --> Utf8 Class Initialized
INFO - 2016-11-30 16:29:17 --> URI Class Initialized
DEBUG - 2016-11-30 16:29:17 --> No URI present. Default controller set.
INFO - 2016-11-30 16:29:17 --> Router Class Initialized
INFO - 2016-11-30 16:29:17 --> Output Class Initialized
INFO - 2016-11-30 16:29:17 --> Security Class Initialized
DEBUG - 2016-11-30 16:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:29:17 --> Input Class Initialized
INFO - 2016-11-30 16:29:17 --> Language Class Initialized
INFO - 2016-11-30 16:29:17 --> Loader Class Initialized
INFO - 2016-11-30 16:29:17 --> Helper loaded: url_helper
INFO - 2016-11-30 16:29:17 --> Helper loaded: form_helper
INFO - 2016-11-30 16:29:17 --> Database Driver Class Initialized
INFO - 2016-11-30 16:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:29:17 --> Controller Class Initialized
INFO - 2016-11-30 16:29:17 --> Model Class Initialized
INFO - 2016-11-30 16:29:17 --> Model Class Initialized
INFO - 2016-11-30 16:29:17 --> Model Class Initialized
INFO - 2016-11-30 16:29:17 --> Model Class Initialized
INFO - 2016-11-30 16:29:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:29:17 --> Pagination Class Initialized
INFO - 2016-11-30 16:29:17 --> Helper loaded: app_helper
INFO - 2016-11-30 16:29:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:29:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:29:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:29:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:29:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:29:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:29:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:29:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:29:17 --> Final output sent to browser
DEBUG - 2016-11-30 16:29:17 --> Total execution time: 0.7434
INFO - 2016-11-30 16:29:33 --> Config Class Initialized
INFO - 2016-11-30 16:29:33 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:29:33 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:29:33 --> Utf8 Class Initialized
INFO - 2016-11-30 16:29:33 --> URI Class Initialized
DEBUG - 2016-11-30 16:29:33 --> No URI present. Default controller set.
INFO - 2016-11-30 16:29:33 --> Router Class Initialized
INFO - 2016-11-30 16:29:33 --> Output Class Initialized
INFO - 2016-11-30 16:29:33 --> Security Class Initialized
DEBUG - 2016-11-30 16:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:29:33 --> Input Class Initialized
INFO - 2016-11-30 16:29:33 --> Language Class Initialized
INFO - 2016-11-30 16:29:33 --> Loader Class Initialized
INFO - 2016-11-30 16:29:33 --> Helper loaded: url_helper
INFO - 2016-11-30 16:29:33 --> Helper loaded: form_helper
INFO - 2016-11-30 16:29:33 --> Database Driver Class Initialized
INFO - 2016-11-30 16:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:29:33 --> Controller Class Initialized
INFO - 2016-11-30 16:29:33 --> Model Class Initialized
INFO - 2016-11-30 16:29:33 --> Model Class Initialized
INFO - 2016-11-30 16:29:33 --> Model Class Initialized
INFO - 2016-11-30 16:29:33 --> Model Class Initialized
INFO - 2016-11-30 16:29:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:29:33 --> Pagination Class Initialized
INFO - 2016-11-30 16:29:33 --> Helper loaded: app_helper
INFO - 2016-11-30 16:29:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:29:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:29:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:29:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:29:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:29:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:29:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:29:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:29:33 --> Final output sent to browser
DEBUG - 2016-11-30 16:29:33 --> Total execution time: 0.7446
INFO - 2016-11-30 16:29:40 --> Config Class Initialized
INFO - 2016-11-30 16:29:40 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:29:40 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:29:40 --> Utf8 Class Initialized
INFO - 2016-11-30 16:29:40 --> URI Class Initialized
INFO - 2016-11-30 16:29:40 --> Router Class Initialized
INFO - 2016-11-30 16:29:40 --> Output Class Initialized
INFO - 2016-11-30 16:29:40 --> Security Class Initialized
DEBUG - 2016-11-30 16:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:29:40 --> Input Class Initialized
INFO - 2016-11-30 16:29:40 --> Language Class Initialized
INFO - 2016-11-30 16:29:40 --> Loader Class Initialized
INFO - 2016-11-30 16:29:40 --> Helper loaded: url_helper
INFO - 2016-11-30 16:29:41 --> Helper loaded: form_helper
INFO - 2016-11-30 16:29:41 --> Database Driver Class Initialized
INFO - 2016-11-30 16:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:29:41 --> Controller Class Initialized
INFO - 2016-11-30 16:29:41 --> Model Class Initialized
INFO - 2016-11-30 16:29:41 --> Form Validation Class Initialized
INFO - 2016-11-30 16:29:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:29:41 --> Pagination Class Initialized
INFO - 2016-11-30 16:29:41 --> Helper loaded: app_helper
INFO - 2016-11-30 16:29:41 --> Email Class Initialized
INFO - 2016-11-30 16:29:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 16:29:41 --> Final output sent to browser
DEBUG - 2016-11-30 16:29:41 --> Total execution time: 0.5237
INFO - 2016-11-30 16:30:37 --> Config Class Initialized
INFO - 2016-11-30 16:30:37 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:30:37 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:30:37 --> Utf8 Class Initialized
INFO - 2016-11-30 16:30:37 --> URI Class Initialized
DEBUG - 2016-11-30 16:30:37 --> No URI present. Default controller set.
INFO - 2016-11-30 16:30:37 --> Router Class Initialized
INFO - 2016-11-30 16:30:37 --> Output Class Initialized
INFO - 2016-11-30 16:30:37 --> Security Class Initialized
DEBUG - 2016-11-30 16:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:30:37 --> Input Class Initialized
INFO - 2016-11-30 16:30:37 --> Language Class Initialized
INFO - 2016-11-30 16:30:37 --> Loader Class Initialized
INFO - 2016-11-30 16:30:37 --> Helper loaded: url_helper
INFO - 2016-11-30 16:30:37 --> Helper loaded: form_helper
INFO - 2016-11-30 16:30:37 --> Database Driver Class Initialized
INFO - 2016-11-30 16:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:30:37 --> Controller Class Initialized
INFO - 2016-11-30 16:30:37 --> Model Class Initialized
INFO - 2016-11-30 16:30:37 --> Model Class Initialized
INFO - 2016-11-30 16:30:37 --> Model Class Initialized
INFO - 2016-11-30 16:30:37 --> Model Class Initialized
INFO - 2016-11-30 16:30:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:30:37 --> Pagination Class Initialized
INFO - 2016-11-30 16:30:37 --> Helper loaded: app_helper
INFO - 2016-11-30 16:30:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:30:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:30:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:30:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:30:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:30:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:30:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:30:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:30:38 --> Final output sent to browser
DEBUG - 2016-11-30 16:30:38 --> Total execution time: 0.8061
INFO - 2016-11-30 16:32:08 --> Config Class Initialized
INFO - 2016-11-30 16:32:08 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:32:08 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:32:08 --> Utf8 Class Initialized
INFO - 2016-11-30 16:32:08 --> URI Class Initialized
DEBUG - 2016-11-30 16:32:08 --> No URI present. Default controller set.
INFO - 2016-11-30 16:32:08 --> Router Class Initialized
INFO - 2016-11-30 16:32:08 --> Output Class Initialized
INFO - 2016-11-30 16:32:08 --> Security Class Initialized
DEBUG - 2016-11-30 16:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:32:08 --> Input Class Initialized
INFO - 2016-11-30 16:32:08 --> Language Class Initialized
INFO - 2016-11-30 16:32:08 --> Loader Class Initialized
INFO - 2016-11-30 16:32:08 --> Helper loaded: url_helper
INFO - 2016-11-30 16:32:08 --> Helper loaded: form_helper
INFO - 2016-11-30 16:32:08 --> Database Driver Class Initialized
INFO - 2016-11-30 16:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:32:08 --> Controller Class Initialized
INFO - 2016-11-30 16:32:08 --> Model Class Initialized
INFO - 2016-11-30 16:32:08 --> Model Class Initialized
INFO - 2016-11-30 16:32:08 --> Model Class Initialized
INFO - 2016-11-30 16:32:09 --> Model Class Initialized
INFO - 2016-11-30 16:32:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:32:09 --> Pagination Class Initialized
INFO - 2016-11-30 16:32:09 --> Helper loaded: app_helper
INFO - 2016-11-30 16:32:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:32:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:32:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:32:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:32:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:32:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:32:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:32:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:32:09 --> Final output sent to browser
DEBUG - 2016-11-30 16:32:09 --> Total execution time: 0.9813
INFO - 2016-11-30 16:32:17 --> Config Class Initialized
INFO - 2016-11-30 16:32:17 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:32:17 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:32:17 --> Utf8 Class Initialized
INFO - 2016-11-30 16:32:17 --> URI Class Initialized
INFO - 2016-11-30 16:32:17 --> Router Class Initialized
INFO - 2016-11-30 16:32:17 --> Output Class Initialized
INFO - 2016-11-30 16:32:17 --> Security Class Initialized
DEBUG - 2016-11-30 16:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:32:18 --> Input Class Initialized
INFO - 2016-11-30 16:32:18 --> Language Class Initialized
INFO - 2016-11-30 16:32:18 --> Loader Class Initialized
INFO - 2016-11-30 16:32:18 --> Helper loaded: url_helper
INFO - 2016-11-30 16:32:18 --> Helper loaded: form_helper
INFO - 2016-11-30 16:32:18 --> Database Driver Class Initialized
INFO - 2016-11-30 16:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:32:18 --> Controller Class Initialized
INFO - 2016-11-30 16:32:18 --> Model Class Initialized
INFO - 2016-11-30 16:32:18 --> Form Validation Class Initialized
INFO - 2016-11-30 16:32:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:32:18 --> Pagination Class Initialized
INFO - 2016-11-30 16:32:18 --> Helper loaded: app_helper
INFO - 2016-11-30 16:32:18 --> Email Class Initialized
INFO - 2016-11-30 16:32:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 16:32:18 --> Final output sent to browser
DEBUG - 2016-11-30 16:32:18 --> Total execution time: 0.5478
INFO - 2016-11-30 16:33:55 --> Config Class Initialized
INFO - 2016-11-30 16:33:55 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:33:55 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:33:55 --> Utf8 Class Initialized
INFO - 2016-11-30 16:33:55 --> URI Class Initialized
DEBUG - 2016-11-30 16:33:55 --> No URI present. Default controller set.
INFO - 2016-11-30 16:33:55 --> Router Class Initialized
INFO - 2016-11-30 16:33:55 --> Output Class Initialized
INFO - 2016-11-30 16:33:55 --> Security Class Initialized
DEBUG - 2016-11-30 16:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:33:55 --> Input Class Initialized
INFO - 2016-11-30 16:33:55 --> Language Class Initialized
INFO - 2016-11-30 16:33:55 --> Loader Class Initialized
INFO - 2016-11-30 16:33:55 --> Helper loaded: url_helper
INFO - 2016-11-30 16:33:55 --> Helper loaded: form_helper
INFO - 2016-11-30 16:33:55 --> Database Driver Class Initialized
INFO - 2016-11-30 16:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:33:55 --> Controller Class Initialized
INFO - 2016-11-30 16:33:55 --> Model Class Initialized
INFO - 2016-11-30 16:33:55 --> Model Class Initialized
INFO - 2016-11-30 16:33:55 --> Model Class Initialized
INFO - 2016-11-30 16:33:55 --> Model Class Initialized
INFO - 2016-11-30 16:33:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:33:55 --> Pagination Class Initialized
INFO - 2016-11-30 16:33:55 --> Helper loaded: app_helper
INFO - 2016-11-30 16:33:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:33:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:33:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:33:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:33:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:33:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:33:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:33:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:33:56 --> Final output sent to browser
DEBUG - 2016-11-30 16:33:56 --> Total execution time: 0.8567
INFO - 2016-11-30 16:34:07 --> Config Class Initialized
INFO - 2016-11-30 16:34:07 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:34:07 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:34:07 --> Utf8 Class Initialized
INFO - 2016-11-30 16:34:07 --> URI Class Initialized
DEBUG - 2016-11-30 16:34:07 --> No URI present. Default controller set.
INFO - 2016-11-30 16:34:07 --> Router Class Initialized
INFO - 2016-11-30 16:34:07 --> Output Class Initialized
INFO - 2016-11-30 16:34:07 --> Security Class Initialized
DEBUG - 2016-11-30 16:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:34:07 --> Input Class Initialized
INFO - 2016-11-30 16:34:07 --> Language Class Initialized
INFO - 2016-11-30 16:34:07 --> Loader Class Initialized
INFO - 2016-11-30 16:34:07 --> Helper loaded: url_helper
INFO - 2016-11-30 16:34:08 --> Helper loaded: form_helper
INFO - 2016-11-30 16:34:08 --> Database Driver Class Initialized
INFO - 2016-11-30 16:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:34:08 --> Controller Class Initialized
INFO - 2016-11-30 16:34:08 --> Model Class Initialized
INFO - 2016-11-30 16:34:08 --> Model Class Initialized
INFO - 2016-11-30 16:34:08 --> Model Class Initialized
INFO - 2016-11-30 16:34:08 --> Model Class Initialized
INFO - 2016-11-30 16:34:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:34:08 --> Pagination Class Initialized
INFO - 2016-11-30 16:34:08 --> Helper loaded: app_helper
INFO - 2016-11-30 16:34:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:34:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:34:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:34:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:34:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:34:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:34:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:34:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:34:08 --> Final output sent to browser
DEBUG - 2016-11-30 16:34:08 --> Total execution time: 0.8470
INFO - 2016-11-30 16:34:11 --> Config Class Initialized
INFO - 2016-11-30 16:34:11 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:34:11 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:34:11 --> Utf8 Class Initialized
INFO - 2016-11-30 16:34:11 --> URI Class Initialized
DEBUG - 2016-11-30 16:34:11 --> No URI present. Default controller set.
INFO - 2016-11-30 16:34:11 --> Router Class Initialized
INFO - 2016-11-30 16:34:11 --> Output Class Initialized
INFO - 2016-11-30 16:34:11 --> Security Class Initialized
DEBUG - 2016-11-30 16:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:34:11 --> Input Class Initialized
INFO - 2016-11-30 16:34:11 --> Language Class Initialized
INFO - 2016-11-30 16:34:11 --> Loader Class Initialized
INFO - 2016-11-30 16:34:11 --> Helper loaded: url_helper
INFO - 2016-11-30 16:34:11 --> Helper loaded: form_helper
INFO - 2016-11-30 16:34:11 --> Database Driver Class Initialized
INFO - 2016-11-30 16:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:34:11 --> Controller Class Initialized
INFO - 2016-11-30 16:34:12 --> Model Class Initialized
INFO - 2016-11-30 16:34:12 --> Model Class Initialized
INFO - 2016-11-30 16:34:12 --> Model Class Initialized
INFO - 2016-11-30 16:34:12 --> Model Class Initialized
INFO - 2016-11-30 16:34:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:34:12 --> Pagination Class Initialized
INFO - 2016-11-30 16:34:12 --> Helper loaded: app_helper
INFO - 2016-11-30 16:34:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:34:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:34:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:34:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:34:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:34:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:34:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:34:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:34:12 --> Final output sent to browser
DEBUG - 2016-11-30 16:34:12 --> Total execution time: 0.7692
INFO - 2016-11-30 16:34:18 --> Config Class Initialized
INFO - 2016-11-30 16:34:18 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:34:18 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:34:18 --> Utf8 Class Initialized
INFO - 2016-11-30 16:34:18 --> URI Class Initialized
INFO - 2016-11-30 16:34:18 --> Router Class Initialized
INFO - 2016-11-30 16:34:18 --> Output Class Initialized
INFO - 2016-11-30 16:34:18 --> Security Class Initialized
DEBUG - 2016-11-30 16:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:34:18 --> Input Class Initialized
INFO - 2016-11-30 16:34:18 --> Language Class Initialized
INFO - 2016-11-30 16:34:18 --> Loader Class Initialized
INFO - 2016-11-30 16:34:18 --> Helper loaded: url_helper
INFO - 2016-11-30 16:34:18 --> Helper loaded: form_helper
INFO - 2016-11-30 16:34:18 --> Database Driver Class Initialized
INFO - 2016-11-30 16:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:34:18 --> Controller Class Initialized
INFO - 2016-11-30 16:34:18 --> Model Class Initialized
INFO - 2016-11-30 16:34:18 --> Form Validation Class Initialized
INFO - 2016-11-30 16:34:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:34:19 --> Pagination Class Initialized
INFO - 2016-11-30 16:34:19 --> Helper loaded: app_helper
INFO - 2016-11-30 16:34:19 --> Email Class Initialized
INFO - 2016-11-30 16:34:19 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-30 15:34:19 --> Severity: Notice --> Undefined variable: hash C:\xampp\htdocs\LMS\app\views\email_template.php 49
INFO - 2016-11-30 15:34:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 15:34:19 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 15:34:19 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-30 15:34:19 --> Severity: Notice --> Undefined variable: hash C:\xampp\htdocs\LMS\app\views\email_template.php 49
INFO - 2016-11-30 15:34:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-30 15:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 15:34:20 --> Final output sent to browser
DEBUG - 2016-11-30 15:34:20 --> Total execution time: 1.5336
INFO - 2016-11-30 16:35:25 --> Config Class Initialized
INFO - 2016-11-30 16:35:25 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:35:25 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:35:25 --> Utf8 Class Initialized
INFO - 2016-11-30 16:35:25 --> URI Class Initialized
DEBUG - 2016-11-30 16:35:25 --> No URI present. Default controller set.
INFO - 2016-11-30 16:35:25 --> Router Class Initialized
INFO - 2016-11-30 16:35:25 --> Output Class Initialized
INFO - 2016-11-30 16:35:25 --> Security Class Initialized
DEBUG - 2016-11-30 16:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:35:26 --> Input Class Initialized
INFO - 2016-11-30 16:35:26 --> Language Class Initialized
INFO - 2016-11-30 16:35:26 --> Loader Class Initialized
INFO - 2016-11-30 16:35:26 --> Helper loaded: url_helper
INFO - 2016-11-30 16:35:26 --> Helper loaded: form_helper
INFO - 2016-11-30 16:35:26 --> Database Driver Class Initialized
INFO - 2016-11-30 16:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:35:26 --> Controller Class Initialized
INFO - 2016-11-30 16:35:26 --> Model Class Initialized
INFO - 2016-11-30 16:35:26 --> Model Class Initialized
INFO - 2016-11-30 16:35:26 --> Model Class Initialized
INFO - 2016-11-30 16:35:26 --> Model Class Initialized
INFO - 2016-11-30 16:35:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:35:26 --> Pagination Class Initialized
INFO - 2016-11-30 16:35:26 --> Helper loaded: app_helper
INFO - 2016-11-30 16:35:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:35:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:35:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:35:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:35:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:35:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:35:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:35:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:35:26 --> Final output sent to browser
DEBUG - 2016-11-30 16:35:26 --> Total execution time: 0.8355
INFO - 2016-11-30 16:37:31 --> Config Class Initialized
INFO - 2016-11-30 16:37:31 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:37:31 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:37:31 --> Utf8 Class Initialized
INFO - 2016-11-30 16:37:31 --> URI Class Initialized
DEBUG - 2016-11-30 16:37:31 --> No URI present. Default controller set.
INFO - 2016-11-30 16:37:31 --> Router Class Initialized
INFO - 2016-11-30 16:37:31 --> Output Class Initialized
INFO - 2016-11-30 16:37:31 --> Security Class Initialized
DEBUG - 2016-11-30 16:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:37:31 --> Input Class Initialized
INFO - 2016-11-30 16:37:31 --> Language Class Initialized
INFO - 2016-11-30 16:37:31 --> Loader Class Initialized
INFO - 2016-11-30 16:37:31 --> Helper loaded: url_helper
INFO - 2016-11-30 16:37:31 --> Helper loaded: form_helper
INFO - 2016-11-30 16:37:31 --> Database Driver Class Initialized
INFO - 2016-11-30 16:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:37:31 --> Controller Class Initialized
INFO - 2016-11-30 16:37:31 --> Model Class Initialized
INFO - 2016-11-30 16:37:31 --> Model Class Initialized
INFO - 2016-11-30 16:37:31 --> Model Class Initialized
INFO - 2016-11-30 16:37:31 --> Model Class Initialized
INFO - 2016-11-30 16:37:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:37:31 --> Pagination Class Initialized
INFO - 2016-11-30 16:37:31 --> Helper loaded: app_helper
INFO - 2016-11-30 16:37:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:37:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:37:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:37:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:37:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:37:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:37:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:37:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:37:31 --> Final output sent to browser
DEBUG - 2016-11-30 16:37:31 --> Total execution time: 0.8334
INFO - 2016-11-30 16:38:37 --> Config Class Initialized
INFO - 2016-11-30 16:38:37 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:38:37 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:38:37 --> Utf8 Class Initialized
INFO - 2016-11-30 16:38:37 --> URI Class Initialized
INFO - 2016-11-30 16:38:37 --> Router Class Initialized
INFO - 2016-11-30 16:38:37 --> Output Class Initialized
INFO - 2016-11-30 16:38:37 --> Security Class Initialized
DEBUG - 2016-11-30 16:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:38:37 --> Input Class Initialized
INFO - 2016-11-30 16:38:37 --> Language Class Initialized
INFO - 2016-11-30 16:38:37 --> Loader Class Initialized
INFO - 2016-11-30 16:38:37 --> Helper loaded: url_helper
INFO - 2016-11-30 16:38:37 --> Helper loaded: form_helper
INFO - 2016-11-30 16:38:37 --> Database Driver Class Initialized
INFO - 2016-11-30 16:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:38:37 --> Controller Class Initialized
INFO - 2016-11-30 16:38:37 --> Model Class Initialized
INFO - 2016-11-30 16:38:37 --> Form Validation Class Initialized
INFO - 2016-11-30 16:38:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:38:37 --> Pagination Class Initialized
INFO - 2016-11-30 16:38:37 --> Helper loaded: app_helper
INFO - 2016-11-30 16:38:37 --> Email Class Initialized
INFO - 2016-11-30 16:38:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 16:38:37 --> Final output sent to browser
DEBUG - 2016-11-30 16:38:37 --> Total execution time: 0.5147
INFO - 2016-11-30 16:38:40 --> Config Class Initialized
INFO - 2016-11-30 16:38:40 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:38:40 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:38:40 --> Utf8 Class Initialized
INFO - 2016-11-30 16:38:40 --> URI Class Initialized
INFO - 2016-11-30 16:38:40 --> Router Class Initialized
INFO - 2016-11-30 16:38:40 --> Output Class Initialized
INFO - 2016-11-30 16:38:40 --> Security Class Initialized
DEBUG - 2016-11-30 16:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:38:41 --> Input Class Initialized
INFO - 2016-11-30 16:38:41 --> Language Class Initialized
INFO - 2016-11-30 16:38:41 --> Loader Class Initialized
INFO - 2016-11-30 16:38:41 --> Helper loaded: url_helper
INFO - 2016-11-30 16:38:41 --> Helper loaded: form_helper
INFO - 2016-11-30 16:38:41 --> Database Driver Class Initialized
INFO - 2016-11-30 16:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:38:41 --> Controller Class Initialized
INFO - 2016-11-30 16:38:41 --> Model Class Initialized
INFO - 2016-11-30 16:38:41 --> Model Class Initialized
INFO - 2016-11-30 16:38:41 --> Model Class Initialized
INFO - 2016-11-30 16:38:41 --> Model Class Initialized
INFO - 2016-11-30 16:38:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:38:41 --> Pagination Class Initialized
INFO - 2016-11-30 16:38:41 --> Helper loaded: app_helper
DEBUG - 2016-11-30 16:38:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-30 16:38:41 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-30 16:38:41 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-30 16:38:41 --> Config Class Initialized
INFO - 2016-11-30 16:38:41 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:38:41 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:38:41 --> Utf8 Class Initialized
INFO - 2016-11-30 16:38:41 --> URI Class Initialized
DEBUG - 2016-11-30 16:38:41 --> No URI present. Default controller set.
INFO - 2016-11-30 16:38:41 --> Router Class Initialized
INFO - 2016-11-30 16:38:41 --> Output Class Initialized
INFO - 2016-11-30 16:38:41 --> Security Class Initialized
DEBUG - 2016-11-30 16:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:38:41 --> Input Class Initialized
INFO - 2016-11-30 16:38:41 --> Language Class Initialized
INFO - 2016-11-30 16:38:41 --> Loader Class Initialized
INFO - 2016-11-30 16:38:41 --> Helper loaded: url_helper
INFO - 2016-11-30 16:38:41 --> Helper loaded: form_helper
INFO - 2016-11-30 16:38:41 --> Database Driver Class Initialized
INFO - 2016-11-30 16:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:38:41 --> Controller Class Initialized
INFO - 2016-11-30 16:38:41 --> Model Class Initialized
INFO - 2016-11-30 16:38:41 --> Model Class Initialized
INFO - 2016-11-30 16:38:41 --> Model Class Initialized
INFO - 2016-11-30 16:38:41 --> Model Class Initialized
INFO - 2016-11-30 16:38:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:38:42 --> Pagination Class Initialized
INFO - 2016-11-30 16:38:42 --> Helper loaded: app_helper
INFO - 2016-11-30 16:38:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:38:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-30 16:38:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:38:42 --> Final output sent to browser
DEBUG - 2016-11-30 16:38:42 --> Total execution time: 0.7708
INFO - 2016-11-30 16:38:54 --> Config Class Initialized
INFO - 2016-11-30 16:38:54 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:38:54 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:38:54 --> Utf8 Class Initialized
INFO - 2016-11-30 16:38:54 --> URI Class Initialized
INFO - 2016-11-30 16:38:54 --> Router Class Initialized
INFO - 2016-11-30 16:38:54 --> Output Class Initialized
INFO - 2016-11-30 16:38:54 --> Security Class Initialized
DEBUG - 2016-11-30 16:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:38:54 --> Input Class Initialized
INFO - 2016-11-30 16:38:54 --> Language Class Initialized
INFO - 2016-11-30 16:38:54 --> Loader Class Initialized
INFO - 2016-11-30 16:38:54 --> Helper loaded: url_helper
INFO - 2016-11-30 16:38:54 --> Helper loaded: form_helper
INFO - 2016-11-30 16:38:54 --> Database Driver Class Initialized
INFO - 2016-11-30 16:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:38:54 --> Controller Class Initialized
INFO - 2016-11-30 16:38:54 --> Model Class Initialized
INFO - 2016-11-30 16:38:54 --> Model Class Initialized
INFO - 2016-11-30 16:38:54 --> Model Class Initialized
INFO - 2016-11-30 16:38:54 --> Model Class Initialized
INFO - 2016-11-30 16:38:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:38:54 --> Pagination Class Initialized
INFO - 2016-11-30 16:38:54 --> Helper loaded: app_helper
DEBUG - 2016-11-30 16:38:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 16:38:54 --> Model Class Initialized
INFO - 2016-11-30 16:38:54 --> Final output sent to browser
DEBUG - 2016-11-30 16:38:54 --> Total execution time: 0.5671
INFO - 2016-11-30 16:38:55 --> Config Class Initialized
INFO - 2016-11-30 16:38:55 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:38:55 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:38:55 --> Utf8 Class Initialized
INFO - 2016-11-30 16:38:55 --> URI Class Initialized
DEBUG - 2016-11-30 16:38:55 --> No URI present. Default controller set.
INFO - 2016-11-30 16:38:55 --> Router Class Initialized
INFO - 2016-11-30 16:38:55 --> Output Class Initialized
INFO - 2016-11-30 16:38:55 --> Security Class Initialized
DEBUG - 2016-11-30 16:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:38:55 --> Input Class Initialized
INFO - 2016-11-30 16:38:55 --> Language Class Initialized
INFO - 2016-11-30 16:38:55 --> Loader Class Initialized
INFO - 2016-11-30 16:38:55 --> Helper loaded: url_helper
INFO - 2016-11-30 16:38:55 --> Helper loaded: form_helper
INFO - 2016-11-30 16:38:55 --> Database Driver Class Initialized
INFO - 2016-11-30 16:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:38:55 --> Controller Class Initialized
INFO - 2016-11-30 16:38:55 --> Model Class Initialized
INFO - 2016-11-30 16:38:55 --> Model Class Initialized
INFO - 2016-11-30 16:38:55 --> Model Class Initialized
INFO - 2016-11-30 16:38:55 --> Model Class Initialized
INFO - 2016-11-30 16:38:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:38:55 --> Pagination Class Initialized
INFO - 2016-11-30 16:38:55 --> Helper loaded: app_helper
INFO - 2016-11-30 16:38:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:38:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:38:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:38:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:38:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:38:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:38:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 16:38:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:38:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:38:55 --> Final output sent to browser
DEBUG - 2016-11-30 16:38:55 --> Total execution time: 0.7950
INFO - 2016-11-30 16:39:14 --> Config Class Initialized
INFO - 2016-11-30 16:39:14 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:39:14 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:39:14 --> Utf8 Class Initialized
INFO - 2016-11-30 16:39:14 --> URI Class Initialized
INFO - 2016-11-30 16:39:14 --> Router Class Initialized
INFO - 2016-11-30 16:39:14 --> Output Class Initialized
INFO - 2016-11-30 16:39:14 --> Security Class Initialized
DEBUG - 2016-11-30 16:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:39:14 --> Input Class Initialized
INFO - 2016-11-30 16:39:14 --> Language Class Initialized
INFO - 2016-11-30 16:39:14 --> Loader Class Initialized
INFO - 2016-11-30 16:39:14 --> Helper loaded: url_helper
INFO - 2016-11-30 16:39:15 --> Helper loaded: form_helper
INFO - 2016-11-30 16:39:15 --> Database Driver Class Initialized
INFO - 2016-11-30 16:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:39:15 --> Controller Class Initialized
INFO - 2016-11-30 16:39:15 --> Model Class Initialized
INFO - 2016-11-30 16:39:15 --> Form Validation Class Initialized
INFO - 2016-11-30 16:39:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:39:15 --> Pagination Class Initialized
INFO - 2016-11-30 16:39:15 --> Helper loaded: app_helper
INFO - 2016-11-30 16:39:15 --> Email Class Initialized
INFO - 2016-11-30 16:39:15 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-30 15:39:15 --> Severity: Notice --> Undefined variable: hash C:\xampp\htdocs\LMS\app\views\email_template.php 49
INFO - 2016-11-30 15:39:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 15:39:15 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 15:39:15 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-30 15:39:15 --> Severity: Notice --> Undefined variable: hash C:\xampp\htdocs\LMS\app\views\email_template.php 49
INFO - 2016-11-30 15:39:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-30 15:39:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 15:39:16 --> Final output sent to browser
DEBUG - 2016-11-30 15:39:16 --> Total execution time: 1.5827
INFO - 2016-11-30 16:40:29 --> Config Class Initialized
INFO - 2016-11-30 16:40:29 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:40:29 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:40:29 --> Utf8 Class Initialized
INFO - 2016-11-30 16:40:29 --> URI Class Initialized
DEBUG - 2016-11-30 16:40:29 --> No URI present. Default controller set.
INFO - 2016-11-30 16:40:29 --> Router Class Initialized
INFO - 2016-11-30 16:40:29 --> Output Class Initialized
INFO - 2016-11-30 16:40:29 --> Security Class Initialized
DEBUG - 2016-11-30 16:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:40:29 --> Input Class Initialized
INFO - 2016-11-30 16:40:29 --> Language Class Initialized
INFO - 2016-11-30 16:40:29 --> Loader Class Initialized
INFO - 2016-11-30 16:40:29 --> Helper loaded: url_helper
INFO - 2016-11-30 16:40:29 --> Helper loaded: form_helper
INFO - 2016-11-30 16:40:30 --> Database Driver Class Initialized
INFO - 2016-11-30 16:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:40:30 --> Controller Class Initialized
INFO - 2016-11-30 16:40:30 --> Model Class Initialized
INFO - 2016-11-30 16:40:30 --> Model Class Initialized
INFO - 2016-11-30 16:40:30 --> Model Class Initialized
INFO - 2016-11-30 16:40:30 --> Model Class Initialized
INFO - 2016-11-30 16:40:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:40:30 --> Pagination Class Initialized
INFO - 2016-11-30 16:40:30 --> Helper loaded: app_helper
INFO - 2016-11-30 16:40:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:40:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:40:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:40:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:40:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:40:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:40:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 16:40:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:40:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:40:30 --> Final output sent to browser
DEBUG - 2016-11-30 16:40:30 --> Total execution time: 0.8417
INFO - 2016-11-30 16:40:44 --> Config Class Initialized
INFO - 2016-11-30 16:40:44 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:40:44 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:40:44 --> Utf8 Class Initialized
INFO - 2016-11-30 16:40:44 --> URI Class Initialized
INFO - 2016-11-30 16:40:44 --> Router Class Initialized
INFO - 2016-11-30 16:40:44 --> Output Class Initialized
INFO - 2016-11-30 16:40:45 --> Security Class Initialized
DEBUG - 2016-11-30 16:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:40:45 --> Input Class Initialized
INFO - 2016-11-30 16:40:45 --> Language Class Initialized
INFO - 2016-11-30 16:40:45 --> Loader Class Initialized
INFO - 2016-11-30 16:40:45 --> Helper loaded: url_helper
INFO - 2016-11-30 16:40:45 --> Helper loaded: form_helper
INFO - 2016-11-30 16:40:45 --> Database Driver Class Initialized
INFO - 2016-11-30 16:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:40:45 --> Controller Class Initialized
INFO - 2016-11-30 16:40:45 --> Model Class Initialized
INFO - 2016-11-30 16:40:45 --> Form Validation Class Initialized
INFO - 2016-11-30 16:40:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:40:45 --> Pagination Class Initialized
INFO - 2016-11-30 16:40:45 --> Helper loaded: app_helper
INFO - 2016-11-30 16:40:45 --> Email Class Initialized
INFO - 2016-11-30 16:40:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 16:40:45 --> Final output sent to browser
DEBUG - 2016-11-30 16:40:45 --> Total execution time: 0.5323
INFO - 2016-11-30 16:40:49 --> Config Class Initialized
INFO - 2016-11-30 16:40:49 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:40:49 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:40:49 --> Utf8 Class Initialized
INFO - 2016-11-30 16:40:49 --> URI Class Initialized
INFO - 2016-11-30 16:40:49 --> Router Class Initialized
INFO - 2016-11-30 16:40:49 --> Output Class Initialized
INFO - 2016-11-30 16:40:49 --> Security Class Initialized
DEBUG - 2016-11-30 16:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:40:49 --> Input Class Initialized
INFO - 2016-11-30 16:40:49 --> Language Class Initialized
INFO - 2016-11-30 16:40:49 --> Loader Class Initialized
INFO - 2016-11-30 16:40:49 --> Helper loaded: url_helper
INFO - 2016-11-30 16:40:49 --> Helper loaded: form_helper
INFO - 2016-11-30 16:40:49 --> Database Driver Class Initialized
INFO - 2016-11-30 16:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:40:49 --> Controller Class Initialized
INFO - 2016-11-30 16:40:50 --> Model Class Initialized
INFO - 2016-11-30 16:40:50 --> Form Validation Class Initialized
INFO - 2016-11-30 16:40:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:40:50 --> Pagination Class Initialized
INFO - 2016-11-30 16:40:50 --> Helper loaded: app_helper
INFO - 2016-11-30 16:40:50 --> Email Class Initialized
INFO - 2016-11-30 16:40:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 16:40:50 --> Final output sent to browser
DEBUG - 2016-11-30 16:40:50 --> Total execution time: 0.5171
INFO - 2016-11-30 16:40:55 --> Config Class Initialized
INFO - 2016-11-30 16:40:55 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:40:55 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:40:55 --> Utf8 Class Initialized
INFO - 2016-11-30 16:40:55 --> URI Class Initialized
INFO - 2016-11-30 16:40:55 --> Router Class Initialized
INFO - 2016-11-30 16:40:55 --> Output Class Initialized
INFO - 2016-11-30 16:40:55 --> Security Class Initialized
DEBUG - 2016-11-30 16:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:40:55 --> Input Class Initialized
INFO - 2016-11-30 16:40:55 --> Language Class Initialized
INFO - 2016-11-30 16:40:55 --> Loader Class Initialized
INFO - 2016-11-30 16:40:55 --> Helper loaded: url_helper
INFO - 2016-11-30 16:40:55 --> Helper loaded: form_helper
INFO - 2016-11-30 16:40:55 --> Database Driver Class Initialized
INFO - 2016-11-30 16:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:40:55 --> Controller Class Initialized
INFO - 2016-11-30 16:40:55 --> Model Class Initialized
INFO - 2016-11-30 16:40:55 --> Form Validation Class Initialized
INFO - 2016-11-30 16:40:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:40:55 --> Pagination Class Initialized
INFO - 2016-11-30 16:40:55 --> Helper loaded: app_helper
INFO - 2016-11-30 16:40:55 --> Email Class Initialized
INFO - 2016-11-30 16:40:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 16:40:55 --> Final output sent to browser
DEBUG - 2016-11-30 16:40:55 --> Total execution time: 0.5362
INFO - 2016-11-30 16:41:03 --> Config Class Initialized
INFO - 2016-11-30 16:41:03 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:41:03 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:41:03 --> Utf8 Class Initialized
INFO - 2016-11-30 16:41:03 --> URI Class Initialized
INFO - 2016-11-30 16:41:03 --> Router Class Initialized
INFO - 2016-11-30 16:41:03 --> Output Class Initialized
INFO - 2016-11-30 16:41:03 --> Security Class Initialized
DEBUG - 2016-11-30 16:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:41:03 --> Input Class Initialized
INFO - 2016-11-30 16:41:03 --> Language Class Initialized
INFO - 2016-11-30 16:41:03 --> Loader Class Initialized
INFO - 2016-11-30 16:41:04 --> Helper loaded: url_helper
INFO - 2016-11-30 16:41:04 --> Helper loaded: form_helper
INFO - 2016-11-30 16:41:04 --> Database Driver Class Initialized
INFO - 2016-11-30 16:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:41:04 --> Controller Class Initialized
INFO - 2016-11-30 16:41:04 --> Model Class Initialized
INFO - 2016-11-30 16:41:04 --> Form Validation Class Initialized
INFO - 2016-11-30 16:41:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:41:04 --> Pagination Class Initialized
INFO - 2016-11-30 16:41:04 --> Helper loaded: app_helper
INFO - 2016-11-30 16:41:04 --> Email Class Initialized
INFO - 2016-11-30 16:41:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 16:41:04 --> Final output sent to browser
DEBUG - 2016-11-30 16:41:04 --> Total execution time: 0.5551
INFO - 2016-11-30 16:41:13 --> Config Class Initialized
INFO - 2016-11-30 16:41:13 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:41:13 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:41:14 --> Utf8 Class Initialized
INFO - 2016-11-30 16:41:14 --> URI Class Initialized
INFO - 2016-11-30 16:41:14 --> Router Class Initialized
INFO - 2016-11-30 16:41:14 --> Output Class Initialized
INFO - 2016-11-30 16:41:14 --> Security Class Initialized
DEBUG - 2016-11-30 16:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:41:14 --> Input Class Initialized
INFO - 2016-11-30 16:41:14 --> Language Class Initialized
INFO - 2016-11-30 16:41:14 --> Loader Class Initialized
INFO - 2016-11-30 16:41:14 --> Helper loaded: url_helper
INFO - 2016-11-30 16:41:14 --> Helper loaded: form_helper
INFO - 2016-11-30 16:41:14 --> Database Driver Class Initialized
INFO - 2016-11-30 16:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:41:14 --> Controller Class Initialized
INFO - 2016-11-30 16:41:14 --> Model Class Initialized
INFO - 2016-11-30 16:41:14 --> Form Validation Class Initialized
INFO - 2016-11-30 16:41:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:41:14 --> Pagination Class Initialized
INFO - 2016-11-30 16:41:14 --> Helper loaded: app_helper
INFO - 2016-11-30 16:41:14 --> Email Class Initialized
INFO - 2016-11-30 16:41:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 16:41:14 --> Final output sent to browser
DEBUG - 2016-11-30 16:41:14 --> Total execution time: 0.5327
INFO - 2016-11-30 16:41:20 --> Config Class Initialized
INFO - 2016-11-30 16:41:20 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:41:20 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:41:20 --> Utf8 Class Initialized
INFO - 2016-11-30 16:41:20 --> URI Class Initialized
INFO - 2016-11-30 16:41:20 --> Router Class Initialized
INFO - 2016-11-30 16:41:20 --> Output Class Initialized
INFO - 2016-11-30 16:41:20 --> Security Class Initialized
DEBUG - 2016-11-30 16:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:41:20 --> Input Class Initialized
INFO - 2016-11-30 16:41:20 --> Language Class Initialized
INFO - 2016-11-30 16:41:20 --> Loader Class Initialized
INFO - 2016-11-30 16:41:20 --> Helper loaded: url_helper
INFO - 2016-11-30 16:41:20 --> Helper loaded: form_helper
INFO - 2016-11-30 16:41:20 --> Database Driver Class Initialized
INFO - 2016-11-30 16:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:41:20 --> Controller Class Initialized
INFO - 2016-11-30 16:41:20 --> Model Class Initialized
INFO - 2016-11-30 16:41:20 --> Form Validation Class Initialized
INFO - 2016-11-30 16:41:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:41:20 --> Pagination Class Initialized
INFO - 2016-11-30 16:41:20 --> Helper loaded: app_helper
INFO - 2016-11-30 16:41:20 --> Email Class Initialized
INFO - 2016-11-30 16:41:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 16:41:20 --> Final output sent to browser
DEBUG - 2016-11-30 16:41:20 --> Total execution time: 0.5787
INFO - 2016-11-30 16:41:29 --> Config Class Initialized
INFO - 2016-11-30 16:41:29 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:41:29 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:41:29 --> Utf8 Class Initialized
INFO - 2016-11-30 16:41:29 --> URI Class Initialized
INFO - 2016-11-30 16:41:29 --> Router Class Initialized
INFO - 2016-11-30 16:41:29 --> Output Class Initialized
INFO - 2016-11-30 16:41:29 --> Security Class Initialized
DEBUG - 2016-11-30 16:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:41:29 --> Input Class Initialized
INFO - 2016-11-30 16:41:29 --> Language Class Initialized
INFO - 2016-11-30 16:41:29 --> Loader Class Initialized
INFO - 2016-11-30 16:41:29 --> Helper loaded: url_helper
INFO - 2016-11-30 16:41:29 --> Helper loaded: form_helper
INFO - 2016-11-30 16:41:29 --> Database Driver Class Initialized
INFO - 2016-11-30 16:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:41:29 --> Controller Class Initialized
INFO - 2016-11-30 16:41:29 --> Model Class Initialized
INFO - 2016-11-30 16:41:29 --> Form Validation Class Initialized
INFO - 2016-11-30 16:41:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:41:29 --> Pagination Class Initialized
INFO - 2016-11-30 16:41:29 --> Helper loaded: app_helper
INFO - 2016-11-30 16:41:30 --> Email Class Initialized
INFO - 2016-11-30 16:41:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 16:41:30 --> Final output sent to browser
DEBUG - 2016-11-30 16:41:30 --> Total execution time: 0.5309
INFO - 2016-11-30 16:41:33 --> Config Class Initialized
INFO - 2016-11-30 16:41:33 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:41:33 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:41:33 --> Utf8 Class Initialized
INFO - 2016-11-30 16:41:33 --> URI Class Initialized
INFO - 2016-11-30 16:41:33 --> Router Class Initialized
INFO - 2016-11-30 16:41:33 --> Output Class Initialized
INFO - 2016-11-30 16:41:33 --> Security Class Initialized
DEBUG - 2016-11-30 16:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:41:33 --> Input Class Initialized
INFO - 2016-11-30 16:41:33 --> Language Class Initialized
INFO - 2016-11-30 16:41:33 --> Loader Class Initialized
INFO - 2016-11-30 16:41:33 --> Helper loaded: url_helper
INFO - 2016-11-30 16:41:33 --> Helper loaded: form_helper
INFO - 2016-11-30 16:41:33 --> Database Driver Class Initialized
INFO - 2016-11-30 16:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:41:33 --> Controller Class Initialized
INFO - 2016-11-30 16:41:33 --> Model Class Initialized
INFO - 2016-11-30 16:41:34 --> Form Validation Class Initialized
INFO - 2016-11-30 16:41:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:41:34 --> Pagination Class Initialized
INFO - 2016-11-30 16:41:34 --> Helper loaded: app_helper
INFO - 2016-11-30 16:41:34 --> Email Class Initialized
INFO - 2016-11-30 16:41:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 16:41:34 --> Final output sent to browser
DEBUG - 2016-11-30 16:41:34 --> Total execution time: 0.5431
INFO - 2016-11-30 16:41:45 --> Config Class Initialized
INFO - 2016-11-30 16:41:45 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:41:45 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:41:45 --> Utf8 Class Initialized
INFO - 2016-11-30 16:41:45 --> URI Class Initialized
INFO - 2016-11-30 16:41:45 --> Router Class Initialized
INFO - 2016-11-30 16:41:45 --> Output Class Initialized
INFO - 2016-11-30 16:41:45 --> Security Class Initialized
DEBUG - 2016-11-30 16:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:41:45 --> Input Class Initialized
INFO - 2016-11-30 16:41:45 --> Language Class Initialized
INFO - 2016-11-30 16:41:45 --> Loader Class Initialized
INFO - 2016-11-30 16:41:45 --> Helper loaded: url_helper
INFO - 2016-11-30 16:41:45 --> Helper loaded: form_helper
INFO - 2016-11-30 16:41:45 --> Database Driver Class Initialized
INFO - 2016-11-30 16:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:41:45 --> Controller Class Initialized
INFO - 2016-11-30 16:41:45 --> Model Class Initialized
INFO - 2016-11-30 16:41:45 --> Form Validation Class Initialized
INFO - 2016-11-30 16:41:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:41:45 --> Pagination Class Initialized
INFO - 2016-11-30 16:41:45 --> Helper loaded: app_helper
INFO - 2016-11-30 16:41:45 --> Email Class Initialized
INFO - 2016-11-30 16:41:45 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-30 15:41:45 --> Severity: Notice --> Undefined variable: hash C:\xampp\htdocs\LMS\app\views\email_template.php 49
INFO - 2016-11-30 15:41:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 15:41:45 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 15:41:45 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-30 15:41:46 --> Severity: Notice --> Undefined variable: hash C:\xampp\htdocs\LMS\app\views\email_template.php 49
INFO - 2016-11-30 15:41:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-30 15:41:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 15:41:46 --> Final output sent to browser
DEBUG - 2016-11-30 15:41:46 --> Total execution time: 1.5165
INFO - 2016-11-30 16:42:01 --> Config Class Initialized
INFO - 2016-11-30 16:42:01 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:42:01 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:42:01 --> Utf8 Class Initialized
INFO - 2016-11-30 16:42:01 --> URI Class Initialized
DEBUG - 2016-11-30 16:42:01 --> No URI present. Default controller set.
INFO - 2016-11-30 16:42:01 --> Router Class Initialized
INFO - 2016-11-30 16:42:01 --> Output Class Initialized
INFO - 2016-11-30 16:42:01 --> Security Class Initialized
DEBUG - 2016-11-30 16:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:42:02 --> Input Class Initialized
INFO - 2016-11-30 16:42:02 --> Language Class Initialized
INFO - 2016-11-30 16:42:02 --> Loader Class Initialized
INFO - 2016-11-30 16:42:02 --> Helper loaded: url_helper
INFO - 2016-11-30 16:42:02 --> Helper loaded: form_helper
INFO - 2016-11-30 16:42:02 --> Database Driver Class Initialized
INFO - 2016-11-30 16:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:42:02 --> Controller Class Initialized
INFO - 2016-11-30 16:42:02 --> Model Class Initialized
INFO - 2016-11-30 16:42:02 --> Model Class Initialized
INFO - 2016-11-30 16:42:02 --> Model Class Initialized
INFO - 2016-11-30 16:42:02 --> Model Class Initialized
INFO - 2016-11-30 16:42:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:42:02 --> Pagination Class Initialized
INFO - 2016-11-30 16:42:02 --> Helper loaded: app_helper
INFO - 2016-11-30 16:42:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:42:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:42:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:42:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:42:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:42:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:42:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 16:42:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:42:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:42:02 --> Final output sent to browser
DEBUG - 2016-11-30 16:42:02 --> Total execution time: 0.8626
INFO - 2016-11-30 16:43:06 --> Config Class Initialized
INFO - 2016-11-30 16:43:06 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:43:06 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:43:06 --> Utf8 Class Initialized
INFO - 2016-11-30 16:43:06 --> URI Class Initialized
DEBUG - 2016-11-30 16:43:06 --> No URI present. Default controller set.
INFO - 2016-11-30 16:43:06 --> Router Class Initialized
INFO - 2016-11-30 16:43:06 --> Output Class Initialized
INFO - 2016-11-30 16:43:06 --> Security Class Initialized
DEBUG - 2016-11-30 16:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:43:07 --> Input Class Initialized
INFO - 2016-11-30 16:43:07 --> Language Class Initialized
INFO - 2016-11-30 16:43:07 --> Loader Class Initialized
INFO - 2016-11-30 16:43:07 --> Helper loaded: url_helper
INFO - 2016-11-30 16:43:07 --> Helper loaded: form_helper
INFO - 2016-11-30 16:43:07 --> Database Driver Class Initialized
INFO - 2016-11-30 16:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:43:07 --> Controller Class Initialized
INFO - 2016-11-30 16:43:07 --> Model Class Initialized
INFO - 2016-11-30 16:43:07 --> Model Class Initialized
INFO - 2016-11-30 16:43:07 --> Model Class Initialized
INFO - 2016-11-30 16:43:07 --> Model Class Initialized
INFO - 2016-11-30 16:43:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:43:07 --> Pagination Class Initialized
INFO - 2016-11-30 16:43:07 --> Helper loaded: app_helper
INFO - 2016-11-30 16:43:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:43:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:43:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:43:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:43:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:43:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:43:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 16:43:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:43:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:43:07 --> Final output sent to browser
DEBUG - 2016-11-30 16:43:07 --> Total execution time: 0.8128
INFO - 2016-11-30 16:43:22 --> Config Class Initialized
INFO - 2016-11-30 16:43:22 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:43:22 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:43:22 --> Utf8 Class Initialized
INFO - 2016-11-30 16:43:22 --> URI Class Initialized
INFO - 2016-11-30 16:43:22 --> Router Class Initialized
INFO - 2016-11-30 16:43:22 --> Output Class Initialized
INFO - 2016-11-30 16:43:22 --> Security Class Initialized
DEBUG - 2016-11-30 16:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:43:23 --> Input Class Initialized
INFO - 2016-11-30 16:43:23 --> Language Class Initialized
INFO - 2016-11-30 16:43:23 --> Loader Class Initialized
INFO - 2016-11-30 16:43:23 --> Helper loaded: url_helper
INFO - 2016-11-30 16:43:23 --> Helper loaded: form_helper
INFO - 2016-11-30 16:43:23 --> Database Driver Class Initialized
INFO - 2016-11-30 16:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:43:23 --> Controller Class Initialized
INFO - 2016-11-30 16:43:23 --> Model Class Initialized
INFO - 2016-11-30 16:43:23 --> Form Validation Class Initialized
INFO - 2016-11-30 16:43:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:43:23 --> Pagination Class Initialized
INFO - 2016-11-30 16:43:23 --> Helper loaded: app_helper
INFO - 2016-11-30 16:43:23 --> Email Class Initialized
INFO - 2016-11-30 16:43:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 15:43:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 15:43:23 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 15:43:23 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-30 15:43:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-30 15:43:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 15:43:24 --> Final output sent to browser
DEBUG - 2016-11-30 15:43:24 --> Total execution time: 1.4307
INFO - 2016-11-30 16:43:29 --> Config Class Initialized
INFO - 2016-11-30 16:43:30 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:43:30 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:43:30 --> Utf8 Class Initialized
INFO - 2016-11-30 16:43:30 --> URI Class Initialized
DEBUG - 2016-11-30 16:43:30 --> No URI present. Default controller set.
INFO - 2016-11-30 16:43:30 --> Router Class Initialized
INFO - 2016-11-30 16:43:30 --> Output Class Initialized
INFO - 2016-11-30 16:43:30 --> Security Class Initialized
DEBUG - 2016-11-30 16:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:43:30 --> Input Class Initialized
INFO - 2016-11-30 16:43:30 --> Language Class Initialized
INFO - 2016-11-30 16:43:30 --> Loader Class Initialized
INFO - 2016-11-30 16:43:30 --> Helper loaded: url_helper
INFO - 2016-11-30 16:43:30 --> Helper loaded: form_helper
INFO - 2016-11-30 16:43:30 --> Database Driver Class Initialized
INFO - 2016-11-30 16:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:43:30 --> Controller Class Initialized
INFO - 2016-11-30 16:43:30 --> Model Class Initialized
INFO - 2016-11-30 16:43:30 --> Model Class Initialized
INFO - 2016-11-30 16:43:30 --> Model Class Initialized
INFO - 2016-11-30 16:43:30 --> Model Class Initialized
INFO - 2016-11-30 16:43:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:43:30 --> Pagination Class Initialized
INFO - 2016-11-30 16:43:30 --> Helper loaded: app_helper
INFO - 2016-11-30 16:43:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:43:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:43:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:43:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:43:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:43:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:43:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 16:43:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:43:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:43:30 --> Final output sent to browser
DEBUG - 2016-11-30 16:43:30 --> Total execution time: 0.8553
INFO - 2016-11-30 16:46:33 --> Config Class Initialized
INFO - 2016-11-30 16:46:33 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:46:33 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:46:33 --> Utf8 Class Initialized
INFO - 2016-11-30 16:46:33 --> URI Class Initialized
DEBUG - 2016-11-30 16:46:33 --> No URI present. Default controller set.
INFO - 2016-11-30 16:46:33 --> Router Class Initialized
INFO - 2016-11-30 16:46:33 --> Output Class Initialized
INFO - 2016-11-30 16:46:33 --> Security Class Initialized
DEBUG - 2016-11-30 16:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:46:34 --> Input Class Initialized
INFO - 2016-11-30 16:46:34 --> Language Class Initialized
INFO - 2016-11-30 16:46:34 --> Loader Class Initialized
INFO - 2016-11-30 16:46:34 --> Helper loaded: url_helper
INFO - 2016-11-30 16:46:34 --> Helper loaded: form_helper
INFO - 2016-11-30 16:46:34 --> Database Driver Class Initialized
INFO - 2016-11-30 16:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:46:34 --> Controller Class Initialized
INFO - 2016-11-30 16:46:34 --> Model Class Initialized
INFO - 2016-11-30 16:46:34 --> Model Class Initialized
INFO - 2016-11-30 16:46:34 --> Model Class Initialized
INFO - 2016-11-30 16:46:34 --> Model Class Initialized
INFO - 2016-11-30 16:46:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:46:34 --> Pagination Class Initialized
INFO - 2016-11-30 16:46:34 --> Helper loaded: app_helper
INFO - 2016-11-30 16:46:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:46:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:46:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:46:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:46:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:46:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:46:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 16:46:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:46:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:46:34 --> Final output sent to browser
DEBUG - 2016-11-30 16:46:34 --> Total execution time: 1.0136
INFO - 2016-11-30 16:46:57 --> Config Class Initialized
INFO - 2016-11-30 16:46:57 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:46:57 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:46:57 --> Utf8 Class Initialized
INFO - 2016-11-30 16:46:57 --> URI Class Initialized
DEBUG - 2016-11-30 16:46:57 --> No URI present. Default controller set.
INFO - 2016-11-30 16:46:57 --> Router Class Initialized
INFO - 2016-11-30 16:46:57 --> Output Class Initialized
INFO - 2016-11-30 16:46:57 --> Security Class Initialized
DEBUG - 2016-11-30 16:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:46:57 --> Input Class Initialized
INFO - 2016-11-30 16:46:57 --> Language Class Initialized
INFO - 2016-11-30 16:46:57 --> Loader Class Initialized
INFO - 2016-11-30 16:46:57 --> Helper loaded: url_helper
INFO - 2016-11-30 16:46:57 --> Helper loaded: form_helper
INFO - 2016-11-30 16:46:57 --> Database Driver Class Initialized
INFO - 2016-11-30 16:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:46:57 --> Controller Class Initialized
INFO - 2016-11-30 16:46:57 --> Model Class Initialized
INFO - 2016-11-30 16:46:57 --> Model Class Initialized
INFO - 2016-11-30 16:46:57 --> Model Class Initialized
INFO - 2016-11-30 16:46:57 --> Model Class Initialized
INFO - 2016-11-30 16:46:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:46:57 --> Pagination Class Initialized
INFO - 2016-11-30 16:46:57 --> Helper loaded: app_helper
INFO - 2016-11-30 16:46:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:46:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:46:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:46:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:46:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:46:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:46:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 16:46:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:46:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:46:57 --> Final output sent to browser
DEBUG - 2016-11-30 16:46:57 --> Total execution time: 0.8861
INFO - 2016-11-30 16:47:14 --> Config Class Initialized
INFO - 2016-11-30 16:47:14 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:47:14 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:47:14 --> Utf8 Class Initialized
INFO - 2016-11-30 16:47:14 --> URI Class Initialized
INFO - 2016-11-30 16:47:14 --> Router Class Initialized
INFO - 2016-11-30 16:47:14 --> Output Class Initialized
INFO - 2016-11-30 16:47:14 --> Security Class Initialized
DEBUG - 2016-11-30 16:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:47:14 --> Input Class Initialized
INFO - 2016-11-30 16:47:14 --> Language Class Initialized
INFO - 2016-11-30 16:47:14 --> Loader Class Initialized
INFO - 2016-11-30 16:47:14 --> Helper loaded: url_helper
INFO - 2016-11-30 16:47:14 --> Helper loaded: form_helper
INFO - 2016-11-30 16:47:14 --> Database Driver Class Initialized
INFO - 2016-11-30 16:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:47:14 --> Controller Class Initialized
INFO - 2016-11-30 16:47:14 --> Model Class Initialized
INFO - 2016-11-30 16:47:14 --> Form Validation Class Initialized
INFO - 2016-11-30 16:47:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:47:14 --> Pagination Class Initialized
INFO - 2016-11-30 16:47:14 --> Helper loaded: app_helper
INFO - 2016-11-30 16:47:14 --> Email Class Initialized
INFO - 2016-11-30 16:47:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 15:47:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 15:47:14 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 15:47:15 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-30 15:47:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-30 15:47:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 15:47:15 --> Final output sent to browser
DEBUG - 2016-11-30 15:47:15 --> Total execution time: 1.4662
INFO - 2016-11-30 16:48:01 --> Config Class Initialized
INFO - 2016-11-30 16:48:02 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:48:02 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:48:02 --> Utf8 Class Initialized
INFO - 2016-11-30 16:48:02 --> URI Class Initialized
DEBUG - 2016-11-30 16:48:02 --> No URI present. Default controller set.
INFO - 2016-11-30 16:48:02 --> Router Class Initialized
INFO - 2016-11-30 16:48:02 --> Output Class Initialized
INFO - 2016-11-30 16:48:02 --> Security Class Initialized
DEBUG - 2016-11-30 16:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:48:02 --> Input Class Initialized
INFO - 2016-11-30 16:48:02 --> Language Class Initialized
INFO - 2016-11-30 16:48:02 --> Loader Class Initialized
INFO - 2016-11-30 16:48:02 --> Helper loaded: url_helper
INFO - 2016-11-30 16:48:02 --> Helper loaded: form_helper
INFO - 2016-11-30 16:48:02 --> Database Driver Class Initialized
INFO - 2016-11-30 16:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:48:02 --> Controller Class Initialized
INFO - 2016-11-30 16:48:02 --> Model Class Initialized
INFO - 2016-11-30 16:48:02 --> Model Class Initialized
INFO - 2016-11-30 16:48:02 --> Model Class Initialized
INFO - 2016-11-30 16:48:02 --> Model Class Initialized
INFO - 2016-11-30 16:48:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:48:02 --> Pagination Class Initialized
INFO - 2016-11-30 16:48:02 --> Helper loaded: app_helper
INFO - 2016-11-30 16:48:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:48:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:48:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:48:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:48:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:48:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:48:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 16:48:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:48:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:48:02 --> Final output sent to browser
DEBUG - 2016-11-30 16:48:02 --> Total execution time: 0.8736
INFO - 2016-11-30 16:51:41 --> Config Class Initialized
INFO - 2016-11-30 16:51:41 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:51:41 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:51:41 --> Utf8 Class Initialized
INFO - 2016-11-30 16:51:41 --> URI Class Initialized
DEBUG - 2016-11-30 16:51:42 --> No URI present. Default controller set.
INFO - 2016-11-30 16:51:42 --> Router Class Initialized
INFO - 2016-11-30 16:51:42 --> Output Class Initialized
INFO - 2016-11-30 16:51:42 --> Security Class Initialized
DEBUG - 2016-11-30 16:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:51:42 --> Input Class Initialized
INFO - 2016-11-30 16:51:42 --> Language Class Initialized
INFO - 2016-11-30 16:51:42 --> Loader Class Initialized
INFO - 2016-11-30 16:51:42 --> Helper loaded: url_helper
INFO - 2016-11-30 16:51:42 --> Helper loaded: form_helper
INFO - 2016-11-30 16:51:42 --> Database Driver Class Initialized
INFO - 2016-11-30 16:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:51:42 --> Controller Class Initialized
INFO - 2016-11-30 16:51:42 --> Model Class Initialized
INFO - 2016-11-30 16:51:42 --> Model Class Initialized
INFO - 2016-11-30 16:51:42 --> Model Class Initialized
INFO - 2016-11-30 16:51:42 --> Model Class Initialized
INFO - 2016-11-30 16:51:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:51:42 --> Pagination Class Initialized
INFO - 2016-11-30 16:51:42 --> Helper loaded: app_helper
INFO - 2016-11-30 16:51:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:51:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 16:51:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 16:51:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 16:51:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 16:51:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 16:51:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-30 16:51:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 16:51:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:51:42 --> Final output sent to browser
DEBUG - 2016-11-30 16:51:42 --> Total execution time: 0.8415
INFO - 2016-11-30 16:52:04 --> Config Class Initialized
INFO - 2016-11-30 16:52:04 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:52:04 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:52:04 --> Utf8 Class Initialized
INFO - 2016-11-30 16:52:04 --> URI Class Initialized
INFO - 2016-11-30 16:52:04 --> Router Class Initialized
INFO - 2016-11-30 16:52:04 --> Output Class Initialized
INFO - 2016-11-30 16:52:04 --> Security Class Initialized
DEBUG - 2016-11-30 16:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:52:04 --> Input Class Initialized
INFO - 2016-11-30 16:52:04 --> Language Class Initialized
INFO - 2016-11-30 16:52:04 --> Loader Class Initialized
INFO - 2016-11-30 16:52:04 --> Helper loaded: url_helper
INFO - 2016-11-30 16:52:04 --> Helper loaded: form_helper
INFO - 2016-11-30 16:52:05 --> Database Driver Class Initialized
INFO - 2016-11-30 16:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:52:05 --> Controller Class Initialized
INFO - 2016-11-30 16:52:05 --> Model Class Initialized
INFO - 2016-11-30 16:52:05 --> Model Class Initialized
INFO - 2016-11-30 16:52:05 --> Model Class Initialized
INFO - 2016-11-30 16:52:05 --> Model Class Initialized
INFO - 2016-11-30 16:52:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:52:05 --> Pagination Class Initialized
INFO - 2016-11-30 16:52:05 --> Helper loaded: app_helper
DEBUG - 2016-11-30 16:52:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-30 16:52:05 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-30 16:52:05 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-30 16:52:05 --> Config Class Initialized
INFO - 2016-11-30 16:52:05 --> Hooks Class Initialized
DEBUG - 2016-11-30 16:52:05 --> UTF-8 Support Enabled
INFO - 2016-11-30 16:52:05 --> Utf8 Class Initialized
INFO - 2016-11-30 16:52:05 --> URI Class Initialized
DEBUG - 2016-11-30 16:52:05 --> No URI present. Default controller set.
INFO - 2016-11-30 16:52:05 --> Router Class Initialized
INFO - 2016-11-30 16:52:05 --> Output Class Initialized
INFO - 2016-11-30 16:52:05 --> Security Class Initialized
DEBUG - 2016-11-30 16:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 16:52:05 --> Input Class Initialized
INFO - 2016-11-30 16:52:05 --> Language Class Initialized
INFO - 2016-11-30 16:52:05 --> Loader Class Initialized
INFO - 2016-11-30 16:52:05 --> Helper loaded: url_helper
INFO - 2016-11-30 16:52:05 --> Helper loaded: form_helper
INFO - 2016-11-30 16:52:05 --> Database Driver Class Initialized
INFO - 2016-11-30 16:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 16:52:05 --> Controller Class Initialized
INFO - 2016-11-30 16:52:05 --> Model Class Initialized
INFO - 2016-11-30 16:52:05 --> Model Class Initialized
INFO - 2016-11-30 16:52:05 --> Model Class Initialized
INFO - 2016-11-30 16:52:05 --> Model Class Initialized
INFO - 2016-11-30 16:52:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 16:52:05 --> Pagination Class Initialized
INFO - 2016-11-30 16:52:05 --> Helper loaded: app_helper
INFO - 2016-11-30 16:52:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 16:52:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-30 16:52:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 16:52:05 --> Final output sent to browser
DEBUG - 2016-11-30 16:52:06 --> Total execution time: 0.6656
INFO - 2016-11-30 18:07:39 --> Config Class Initialized
INFO - 2016-11-30 18:07:40 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:07:40 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:07:40 --> Utf8 Class Initialized
INFO - 2016-11-30 18:07:40 --> URI Class Initialized
DEBUG - 2016-11-30 18:07:40 --> No URI present. Default controller set.
INFO - 2016-11-30 18:07:40 --> Router Class Initialized
INFO - 2016-11-30 18:07:41 --> Output Class Initialized
INFO - 2016-11-30 18:07:41 --> Security Class Initialized
DEBUG - 2016-11-30 18:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:07:41 --> Input Class Initialized
INFO - 2016-11-30 18:07:41 --> Language Class Initialized
INFO - 2016-11-30 18:07:41 --> Loader Class Initialized
INFO - 2016-11-30 18:07:41 --> Helper loaded: url_helper
INFO - 2016-11-30 18:07:41 --> Helper loaded: form_helper
INFO - 2016-11-30 18:07:42 --> Database Driver Class Initialized
INFO - 2016-11-30 18:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:07:42 --> Controller Class Initialized
INFO - 2016-11-30 18:07:42 --> Model Class Initialized
INFO - 2016-11-30 18:07:42 --> Model Class Initialized
INFO - 2016-11-30 18:07:42 --> Model Class Initialized
INFO - 2016-11-30 18:07:42 --> Model Class Initialized
INFO - 2016-11-30 18:07:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:07:42 --> Pagination Class Initialized
INFO - 2016-11-30 18:07:42 --> Helper loaded: app_helper
INFO - 2016-11-30 18:07:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:07:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-30 18:07:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:07:42 --> Final output sent to browser
DEBUG - 2016-11-30 18:07:42 --> Total execution time: 2.8497
INFO - 2016-11-30 18:07:44 --> Config Class Initialized
INFO - 2016-11-30 18:07:44 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:07:44 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:07:44 --> Utf8 Class Initialized
INFO - 2016-11-30 18:07:44 --> URI Class Initialized
DEBUG - 2016-11-30 18:07:44 --> No URI present. Default controller set.
INFO - 2016-11-30 18:07:44 --> Router Class Initialized
INFO - 2016-11-30 18:07:45 --> Output Class Initialized
INFO - 2016-11-30 18:07:45 --> Security Class Initialized
DEBUG - 2016-11-30 18:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:07:45 --> Input Class Initialized
INFO - 2016-11-30 18:07:45 --> Language Class Initialized
INFO - 2016-11-30 18:07:45 --> Loader Class Initialized
INFO - 2016-11-30 18:07:45 --> Helper loaded: url_helper
INFO - 2016-11-30 18:07:45 --> Helper loaded: form_helper
INFO - 2016-11-30 18:07:45 --> Database Driver Class Initialized
INFO - 2016-11-30 18:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:07:45 --> Controller Class Initialized
INFO - 2016-11-30 18:07:45 --> Model Class Initialized
INFO - 2016-11-30 18:07:45 --> Model Class Initialized
INFO - 2016-11-30 18:07:45 --> Model Class Initialized
INFO - 2016-11-30 18:07:45 --> Model Class Initialized
INFO - 2016-11-30 18:07:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:07:45 --> Pagination Class Initialized
INFO - 2016-11-30 18:07:45 --> Helper loaded: app_helper
INFO - 2016-11-30 18:07:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:07:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-30 18:07:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:07:45 --> Final output sent to browser
DEBUG - 2016-11-30 18:07:45 --> Total execution time: 0.7832
INFO - 2016-11-30 18:08:13 --> Config Class Initialized
INFO - 2016-11-30 18:08:14 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:08:14 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:08:14 --> Utf8 Class Initialized
INFO - 2016-11-30 18:08:14 --> URI Class Initialized
INFO - 2016-11-30 18:08:14 --> Router Class Initialized
INFO - 2016-11-30 18:08:14 --> Output Class Initialized
INFO - 2016-11-30 18:08:14 --> Security Class Initialized
DEBUG - 2016-11-30 18:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:08:14 --> Input Class Initialized
INFO - 2016-11-30 18:08:14 --> Language Class Initialized
INFO - 2016-11-30 18:08:14 --> Loader Class Initialized
INFO - 2016-11-30 18:08:14 --> Helper loaded: url_helper
INFO - 2016-11-30 18:08:14 --> Helper loaded: form_helper
INFO - 2016-11-30 18:08:14 --> Database Driver Class Initialized
INFO - 2016-11-30 18:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:08:14 --> Controller Class Initialized
INFO - 2016-11-30 18:08:14 --> Model Class Initialized
INFO - 2016-11-30 18:08:14 --> Model Class Initialized
INFO - 2016-11-30 18:08:14 --> Model Class Initialized
INFO - 2016-11-30 18:08:14 --> Model Class Initialized
INFO - 2016-11-30 18:08:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:08:14 --> Pagination Class Initialized
INFO - 2016-11-30 18:08:14 --> Helper loaded: app_helper
DEBUG - 2016-11-30 18:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 18:08:14 --> Model Class Initialized
INFO - 2016-11-30 18:08:14 --> Final output sent to browser
DEBUG - 2016-11-30 18:08:14 --> Total execution time: 0.6058
INFO - 2016-11-30 18:08:14 --> Config Class Initialized
INFO - 2016-11-30 18:08:14 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:08:14 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:08:14 --> Utf8 Class Initialized
INFO - 2016-11-30 18:08:14 --> URI Class Initialized
DEBUG - 2016-11-30 18:08:14 --> No URI present. Default controller set.
INFO - 2016-11-30 18:08:14 --> Router Class Initialized
INFO - 2016-11-30 18:08:14 --> Output Class Initialized
INFO - 2016-11-30 18:08:14 --> Security Class Initialized
DEBUG - 2016-11-30 18:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:08:14 --> Input Class Initialized
INFO - 2016-11-30 18:08:14 --> Language Class Initialized
INFO - 2016-11-30 18:08:14 --> Loader Class Initialized
INFO - 2016-11-30 18:08:14 --> Helper loaded: url_helper
INFO - 2016-11-30 18:08:14 --> Helper loaded: form_helper
INFO - 2016-11-30 18:08:14 --> Database Driver Class Initialized
INFO - 2016-11-30 18:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:08:15 --> Controller Class Initialized
INFO - 2016-11-30 18:08:15 --> Model Class Initialized
INFO - 2016-11-30 18:08:15 --> Model Class Initialized
INFO - 2016-11-30 18:08:15 --> Model Class Initialized
INFO - 2016-11-30 18:08:15 --> Model Class Initialized
INFO - 2016-11-30 18:08:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:08:15 --> Pagination Class Initialized
INFO - 2016-11-30 18:08:15 --> Helper loaded: app_helper
INFO - 2016-11-30 18:08:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:08:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:08:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:08:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:08:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:08:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:08:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:08:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:08:15 --> Final output sent to browser
DEBUG - 2016-11-30 18:08:15 --> Total execution time: 1.1495
INFO - 2016-11-30 18:08:20 --> Config Class Initialized
INFO - 2016-11-30 18:08:20 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:08:20 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:08:20 --> Utf8 Class Initialized
INFO - 2016-11-30 18:08:20 --> URI Class Initialized
DEBUG - 2016-11-30 18:08:20 --> No URI present. Default controller set.
INFO - 2016-11-30 18:08:20 --> Router Class Initialized
INFO - 2016-11-30 18:08:20 --> Output Class Initialized
INFO - 2016-11-30 18:08:20 --> Security Class Initialized
DEBUG - 2016-11-30 18:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:08:20 --> Input Class Initialized
INFO - 2016-11-30 18:08:20 --> Language Class Initialized
INFO - 2016-11-30 18:08:20 --> Loader Class Initialized
INFO - 2016-11-30 18:08:20 --> Helper loaded: url_helper
INFO - 2016-11-30 18:08:20 --> Helper loaded: form_helper
INFO - 2016-11-30 18:08:20 --> Database Driver Class Initialized
INFO - 2016-11-30 18:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:08:20 --> Controller Class Initialized
INFO - 2016-11-30 18:08:20 --> Model Class Initialized
INFO - 2016-11-30 18:08:20 --> Model Class Initialized
INFO - 2016-11-30 18:08:20 --> Model Class Initialized
INFO - 2016-11-30 18:08:20 --> Model Class Initialized
INFO - 2016-11-30 18:08:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:08:20 --> Pagination Class Initialized
INFO - 2016-11-30 18:08:20 --> Helper loaded: app_helper
INFO - 2016-11-30 18:08:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:08:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:08:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:08:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:08:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:08:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:08:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:08:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:08:20 --> Final output sent to browser
DEBUG - 2016-11-30 18:08:21 --> Total execution time: 0.7303
INFO - 2016-11-30 18:08:35 --> Config Class Initialized
INFO - 2016-11-30 18:08:35 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:08:35 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:08:35 --> Utf8 Class Initialized
INFO - 2016-11-30 18:08:35 --> URI Class Initialized
INFO - 2016-11-30 18:08:35 --> Router Class Initialized
INFO - 2016-11-30 18:08:35 --> Output Class Initialized
INFO - 2016-11-30 18:08:35 --> Security Class Initialized
DEBUG - 2016-11-30 18:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:08:35 --> Input Class Initialized
INFO - 2016-11-30 18:08:35 --> Language Class Initialized
INFO - 2016-11-30 18:08:35 --> Loader Class Initialized
INFO - 2016-11-30 18:08:35 --> Helper loaded: url_helper
INFO - 2016-11-30 18:08:35 --> Helper loaded: form_helper
INFO - 2016-11-30 18:08:35 --> Database Driver Class Initialized
INFO - 2016-11-30 18:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:08:35 --> Controller Class Initialized
INFO - 2016-11-30 18:08:35 --> Model Class Initialized
INFO - 2016-11-30 18:08:35 --> Form Validation Class Initialized
INFO - 2016-11-30 18:08:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:08:35 --> Pagination Class Initialized
INFO - 2016-11-30 18:08:35 --> Helper loaded: app_helper
INFO - 2016-11-30 18:08:35 --> Email Class Initialized
INFO - 2016-11-30 18:08:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 18:08:35 --> Final output sent to browser
DEBUG - 2016-11-30 18:08:35 --> Total execution time: 0.6522
INFO - 2016-11-30 18:08:50 --> Config Class Initialized
INFO - 2016-11-30 18:08:50 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:08:50 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:08:50 --> Utf8 Class Initialized
INFO - 2016-11-30 18:08:50 --> URI Class Initialized
INFO - 2016-11-30 18:08:50 --> Router Class Initialized
INFO - 2016-11-30 18:08:50 --> Output Class Initialized
INFO - 2016-11-30 18:08:50 --> Security Class Initialized
DEBUG - 2016-11-30 18:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:08:50 --> Input Class Initialized
INFO - 2016-11-30 18:08:50 --> Language Class Initialized
INFO - 2016-11-30 18:08:50 --> Loader Class Initialized
INFO - 2016-11-30 18:08:50 --> Helper loaded: url_helper
INFO - 2016-11-30 18:08:50 --> Helper loaded: form_helper
INFO - 2016-11-30 18:08:50 --> Database Driver Class Initialized
INFO - 2016-11-30 18:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:08:50 --> Controller Class Initialized
INFO - 2016-11-30 18:08:50 --> Model Class Initialized
INFO - 2016-11-30 18:08:50 --> Form Validation Class Initialized
INFO - 2016-11-30 18:08:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:08:50 --> Pagination Class Initialized
INFO - 2016-11-30 18:08:50 --> Helper loaded: app_helper
INFO - 2016-11-30 18:08:50 --> Email Class Initialized
INFO - 2016-11-30 18:08:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 17:08:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 17:08:50 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 17:08:51 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-30 17:08:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-30 17:08:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 17:08:51 --> Final output sent to browser
DEBUG - 2016-11-30 17:08:51 --> Total execution time: 1.6864
INFO - 2016-11-30 18:10:31 --> Config Class Initialized
INFO - 2016-11-30 18:10:31 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:10:31 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:10:31 --> Utf8 Class Initialized
INFO - 2016-11-30 18:10:31 --> URI Class Initialized
DEBUG - 2016-11-30 18:10:31 --> No URI present. Default controller set.
INFO - 2016-11-30 18:10:31 --> Router Class Initialized
INFO - 2016-11-30 18:10:31 --> Output Class Initialized
INFO - 2016-11-30 18:10:31 --> Security Class Initialized
DEBUG - 2016-11-30 18:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:10:31 --> Input Class Initialized
INFO - 2016-11-30 18:10:31 --> Language Class Initialized
INFO - 2016-11-30 18:10:31 --> Loader Class Initialized
INFO - 2016-11-30 18:10:31 --> Helper loaded: url_helper
INFO - 2016-11-30 18:10:31 --> Helper loaded: form_helper
INFO - 2016-11-30 18:10:31 --> Database Driver Class Initialized
INFO - 2016-11-30 18:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:10:31 --> Controller Class Initialized
INFO - 2016-11-30 18:10:31 --> Model Class Initialized
INFO - 2016-11-30 18:10:31 --> Model Class Initialized
INFO - 2016-11-30 18:10:31 --> Model Class Initialized
INFO - 2016-11-30 18:10:32 --> Model Class Initialized
INFO - 2016-11-30 18:10:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:10:32 --> Pagination Class Initialized
INFO - 2016-11-30 18:10:32 --> Helper loaded: app_helper
INFO - 2016-11-30 18:10:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:10:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:10:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:10:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:10:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:10:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:10:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:10:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:10:32 --> Final output sent to browser
DEBUG - 2016-11-30 18:10:32 --> Total execution time: 0.7574
INFO - 2016-11-30 18:10:38 --> Config Class Initialized
INFO - 2016-11-30 18:10:38 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:10:38 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:10:38 --> Utf8 Class Initialized
INFO - 2016-11-30 18:10:38 --> URI Class Initialized
DEBUG - 2016-11-30 18:10:38 --> No URI present. Default controller set.
INFO - 2016-11-30 18:10:38 --> Router Class Initialized
INFO - 2016-11-30 18:10:38 --> Output Class Initialized
INFO - 2016-11-30 18:10:38 --> Security Class Initialized
DEBUG - 2016-11-30 18:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:10:38 --> Input Class Initialized
INFO - 2016-11-30 18:10:38 --> Language Class Initialized
INFO - 2016-11-30 18:10:38 --> Loader Class Initialized
INFO - 2016-11-30 18:10:38 --> Helper loaded: url_helper
INFO - 2016-11-30 18:10:38 --> Helper loaded: form_helper
INFO - 2016-11-30 18:10:38 --> Database Driver Class Initialized
INFO - 2016-11-30 18:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:10:38 --> Controller Class Initialized
INFO - 2016-11-30 18:10:38 --> Model Class Initialized
INFO - 2016-11-30 18:10:38 --> Model Class Initialized
INFO - 2016-11-30 18:10:38 --> Model Class Initialized
INFO - 2016-11-30 18:10:38 --> Model Class Initialized
INFO - 2016-11-30 18:10:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:10:38 --> Pagination Class Initialized
INFO - 2016-11-30 18:10:38 --> Helper loaded: app_helper
INFO - 2016-11-30 18:10:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:10:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:10:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:10:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:10:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:10:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:10:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:10:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:10:39 --> Final output sent to browser
DEBUG - 2016-11-30 18:10:39 --> Total execution time: 0.7523
INFO - 2016-11-30 18:12:31 --> Config Class Initialized
INFO - 2016-11-30 18:12:31 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:12:31 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:12:31 --> Utf8 Class Initialized
INFO - 2016-11-30 18:12:31 --> URI Class Initialized
DEBUG - 2016-11-30 18:12:31 --> No URI present. Default controller set.
INFO - 2016-11-30 18:12:32 --> Router Class Initialized
INFO - 2016-11-30 18:12:32 --> Output Class Initialized
INFO - 2016-11-30 18:12:32 --> Security Class Initialized
DEBUG - 2016-11-30 18:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:12:32 --> Input Class Initialized
INFO - 2016-11-30 18:12:32 --> Language Class Initialized
INFO - 2016-11-30 18:12:32 --> Loader Class Initialized
INFO - 2016-11-30 18:12:32 --> Helper loaded: url_helper
INFO - 2016-11-30 18:12:32 --> Helper loaded: form_helper
INFO - 2016-11-30 18:12:32 --> Database Driver Class Initialized
INFO - 2016-11-30 18:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:12:32 --> Controller Class Initialized
INFO - 2016-11-30 18:12:32 --> Model Class Initialized
INFO - 2016-11-30 18:12:32 --> Model Class Initialized
INFO - 2016-11-30 18:12:32 --> Model Class Initialized
INFO - 2016-11-30 18:12:32 --> Model Class Initialized
INFO - 2016-11-30 18:12:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:12:32 --> Pagination Class Initialized
INFO - 2016-11-30 18:12:32 --> Helper loaded: app_helper
INFO - 2016-11-30 18:12:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:12:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:12:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:12:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:12:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:12:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:12:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:12:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:12:32 --> Final output sent to browser
DEBUG - 2016-11-30 18:12:32 --> Total execution time: 0.9002
INFO - 2016-11-30 18:13:17 --> Config Class Initialized
INFO - 2016-11-30 18:13:18 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:13:18 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:13:18 --> Utf8 Class Initialized
INFO - 2016-11-30 18:13:18 --> URI Class Initialized
DEBUG - 2016-11-30 18:13:18 --> No URI present. Default controller set.
INFO - 2016-11-30 18:13:18 --> Router Class Initialized
INFO - 2016-11-30 18:13:18 --> Output Class Initialized
INFO - 2016-11-30 18:13:18 --> Security Class Initialized
DEBUG - 2016-11-30 18:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:13:18 --> Input Class Initialized
INFO - 2016-11-30 18:13:18 --> Language Class Initialized
INFO - 2016-11-30 18:13:18 --> Loader Class Initialized
INFO - 2016-11-30 18:13:18 --> Helper loaded: url_helper
INFO - 2016-11-30 18:13:18 --> Helper loaded: form_helper
INFO - 2016-11-30 18:13:18 --> Database Driver Class Initialized
INFO - 2016-11-30 18:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:13:18 --> Controller Class Initialized
INFO - 2016-11-30 18:13:18 --> Model Class Initialized
INFO - 2016-11-30 18:13:18 --> Model Class Initialized
INFO - 2016-11-30 18:13:18 --> Model Class Initialized
INFO - 2016-11-30 18:13:18 --> Model Class Initialized
INFO - 2016-11-30 18:13:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:13:18 --> Pagination Class Initialized
INFO - 2016-11-30 18:13:18 --> Helper loaded: app_helper
INFO - 2016-11-30 18:13:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:13:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:13:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:13:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:13:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:13:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:13:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:13:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:13:18 --> Final output sent to browser
DEBUG - 2016-11-30 18:13:18 --> Total execution time: 1.0145
INFO - 2016-11-30 18:13:33 --> Config Class Initialized
INFO - 2016-11-30 18:13:33 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:13:33 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:13:33 --> Utf8 Class Initialized
INFO - 2016-11-30 18:13:33 --> URI Class Initialized
INFO - 2016-11-30 18:13:33 --> Router Class Initialized
INFO - 2016-11-30 18:13:33 --> Output Class Initialized
INFO - 2016-11-30 18:13:33 --> Security Class Initialized
DEBUG - 2016-11-30 18:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:13:33 --> Input Class Initialized
INFO - 2016-11-30 18:13:33 --> Language Class Initialized
ERROR - 2016-11-30 18:13:33 --> Severity: Parsing Error --> syntax error, unexpected ':' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 175
INFO - 2016-11-30 18:13:55 --> Config Class Initialized
INFO - 2016-11-30 18:13:55 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:13:56 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:13:56 --> Utf8 Class Initialized
INFO - 2016-11-30 18:13:56 --> URI Class Initialized
INFO - 2016-11-30 18:13:56 --> Router Class Initialized
INFO - 2016-11-30 18:13:56 --> Output Class Initialized
INFO - 2016-11-30 18:13:56 --> Security Class Initialized
DEBUG - 2016-11-30 18:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:13:56 --> Input Class Initialized
INFO - 2016-11-30 18:13:56 --> Language Class Initialized
INFO - 2016-11-30 18:13:56 --> Loader Class Initialized
INFO - 2016-11-30 18:13:56 --> Helper loaded: url_helper
INFO - 2016-11-30 18:13:56 --> Helper loaded: form_helper
INFO - 2016-11-30 18:13:56 --> Database Driver Class Initialized
INFO - 2016-11-30 18:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:13:56 --> Controller Class Initialized
INFO - 2016-11-30 18:13:56 --> Model Class Initialized
INFO - 2016-11-30 18:13:56 --> Form Validation Class Initialized
INFO - 2016-11-30 18:13:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:13:56 --> Pagination Class Initialized
INFO - 2016-11-30 18:13:56 --> Helper loaded: app_helper
INFO - 2016-11-30 18:13:56 --> Email Class Initialized
INFO - 2016-11-30 18:13:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 18:14:06 --> Config Class Initialized
INFO - 2016-11-30 18:14:06 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:14:06 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:14:06 --> Utf8 Class Initialized
INFO - 2016-11-30 18:14:07 --> URI Class Initialized
DEBUG - 2016-11-30 18:14:07 --> No URI present. Default controller set.
INFO - 2016-11-30 18:14:07 --> Router Class Initialized
INFO - 2016-11-30 18:14:07 --> Output Class Initialized
INFO - 2016-11-30 18:14:07 --> Security Class Initialized
DEBUG - 2016-11-30 18:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:14:07 --> Input Class Initialized
INFO - 2016-11-30 18:14:07 --> Language Class Initialized
INFO - 2016-11-30 18:14:07 --> Loader Class Initialized
INFO - 2016-11-30 18:14:07 --> Helper loaded: url_helper
INFO - 2016-11-30 18:14:07 --> Helper loaded: form_helper
INFO - 2016-11-30 18:14:07 --> Database Driver Class Initialized
INFO - 2016-11-30 18:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:14:07 --> Controller Class Initialized
INFO - 2016-11-30 18:14:07 --> Model Class Initialized
INFO - 2016-11-30 18:14:07 --> Model Class Initialized
INFO - 2016-11-30 18:14:07 --> Model Class Initialized
INFO - 2016-11-30 18:14:07 --> Model Class Initialized
INFO - 2016-11-30 18:14:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:14:07 --> Pagination Class Initialized
INFO - 2016-11-30 18:14:07 --> Helper loaded: app_helper
INFO - 2016-11-30 18:14:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:14:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:14:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:14:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:14:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:14:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:14:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:14:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:14:07 --> Final output sent to browser
DEBUG - 2016-11-30 18:14:07 --> Total execution time: 0.7734
INFO - 2016-11-30 18:14:32 --> Config Class Initialized
INFO - 2016-11-30 18:14:32 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:14:32 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:14:32 --> Utf8 Class Initialized
INFO - 2016-11-30 18:14:32 --> URI Class Initialized
DEBUG - 2016-11-30 18:14:32 --> No URI present. Default controller set.
INFO - 2016-11-30 18:14:32 --> Router Class Initialized
INFO - 2016-11-30 18:14:32 --> Output Class Initialized
INFO - 2016-11-30 18:14:32 --> Security Class Initialized
DEBUG - 2016-11-30 18:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:14:33 --> Input Class Initialized
INFO - 2016-11-30 18:14:33 --> Language Class Initialized
INFO - 2016-11-30 18:14:33 --> Loader Class Initialized
INFO - 2016-11-30 18:14:33 --> Helper loaded: url_helper
INFO - 2016-11-30 18:14:33 --> Helper loaded: form_helper
INFO - 2016-11-30 18:14:33 --> Database Driver Class Initialized
INFO - 2016-11-30 18:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:14:33 --> Controller Class Initialized
INFO - 2016-11-30 18:14:33 --> Model Class Initialized
INFO - 2016-11-30 18:14:33 --> Model Class Initialized
INFO - 2016-11-30 18:14:33 --> Model Class Initialized
INFO - 2016-11-30 18:14:33 --> Model Class Initialized
INFO - 2016-11-30 18:14:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:14:33 --> Pagination Class Initialized
INFO - 2016-11-30 18:14:33 --> Helper loaded: app_helper
INFO - 2016-11-30 18:14:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:14:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:14:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:14:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:14:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:14:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:14:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:14:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:14:33 --> Final output sent to browser
DEBUG - 2016-11-30 18:14:33 --> Total execution time: 0.7753
INFO - 2016-11-30 18:14:46 --> Config Class Initialized
INFO - 2016-11-30 18:14:46 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:14:46 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:14:46 --> Utf8 Class Initialized
INFO - 2016-11-30 18:14:46 --> URI Class Initialized
INFO - 2016-11-30 18:14:46 --> Router Class Initialized
INFO - 2016-11-30 18:14:46 --> Output Class Initialized
INFO - 2016-11-30 18:14:46 --> Security Class Initialized
DEBUG - 2016-11-30 18:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:14:46 --> Input Class Initialized
INFO - 2016-11-30 18:14:46 --> Language Class Initialized
INFO - 2016-11-30 18:14:46 --> Loader Class Initialized
INFO - 2016-11-30 18:14:46 --> Helper loaded: url_helper
INFO - 2016-11-30 18:14:46 --> Helper loaded: form_helper
INFO - 2016-11-30 18:14:46 --> Database Driver Class Initialized
INFO - 2016-11-30 18:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:14:46 --> Controller Class Initialized
INFO - 2016-11-30 18:14:46 --> Model Class Initialized
INFO - 2016-11-30 18:14:46 --> Form Validation Class Initialized
INFO - 2016-11-30 18:14:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:14:46 --> Pagination Class Initialized
INFO - 2016-11-30 18:14:46 --> Helper loaded: app_helper
INFO - 2016-11-30 18:14:46 --> Email Class Initialized
INFO - 2016-11-30 18:14:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 18:16:16 --> Config Class Initialized
INFO - 2016-11-30 18:16:16 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:16:16 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:16:16 --> Utf8 Class Initialized
INFO - 2016-11-30 18:16:16 --> URI Class Initialized
DEBUG - 2016-11-30 18:16:16 --> No URI present. Default controller set.
INFO - 2016-11-30 18:16:16 --> Router Class Initialized
INFO - 2016-11-30 18:16:16 --> Output Class Initialized
INFO - 2016-11-30 18:16:16 --> Security Class Initialized
DEBUG - 2016-11-30 18:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:16:16 --> Input Class Initialized
INFO - 2016-11-30 18:16:16 --> Language Class Initialized
INFO - 2016-11-30 18:16:16 --> Loader Class Initialized
INFO - 2016-11-30 18:16:16 --> Helper loaded: url_helper
INFO - 2016-11-30 18:16:16 --> Helper loaded: form_helper
INFO - 2016-11-30 18:16:16 --> Database Driver Class Initialized
INFO - 2016-11-30 18:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:16:16 --> Controller Class Initialized
INFO - 2016-11-30 18:16:16 --> Model Class Initialized
INFO - 2016-11-30 18:16:16 --> Model Class Initialized
INFO - 2016-11-30 18:16:16 --> Model Class Initialized
INFO - 2016-11-30 18:16:16 --> Model Class Initialized
INFO - 2016-11-30 18:16:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:16:17 --> Pagination Class Initialized
INFO - 2016-11-30 18:16:17 --> Helper loaded: app_helper
INFO - 2016-11-30 18:16:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:16:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:16:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:16:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:16:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:16:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:16:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:16:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:16:17 --> Final output sent to browser
DEBUG - 2016-11-30 18:16:17 --> Total execution time: 1.0743
INFO - 2016-11-30 18:16:32 --> Config Class Initialized
INFO - 2016-11-30 18:16:32 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:16:32 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:16:32 --> Utf8 Class Initialized
INFO - 2016-11-30 18:16:32 --> URI Class Initialized
INFO - 2016-11-30 18:16:32 --> Router Class Initialized
INFO - 2016-11-30 18:16:32 --> Output Class Initialized
INFO - 2016-11-30 18:16:32 --> Security Class Initialized
DEBUG - 2016-11-30 18:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:16:32 --> Input Class Initialized
INFO - 2016-11-30 18:16:32 --> Language Class Initialized
ERROR - 2016-11-30 18:16:32 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 213
INFO - 2016-11-30 18:17:07 --> Config Class Initialized
INFO - 2016-11-30 18:17:07 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:17:07 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:17:07 --> Utf8 Class Initialized
INFO - 2016-11-30 18:17:07 --> URI Class Initialized
INFO - 2016-11-30 18:17:07 --> Router Class Initialized
INFO - 2016-11-30 18:17:07 --> Output Class Initialized
INFO - 2016-11-30 18:17:07 --> Security Class Initialized
DEBUG - 2016-11-30 18:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:17:07 --> Input Class Initialized
INFO - 2016-11-30 18:17:07 --> Language Class Initialized
INFO - 2016-11-30 18:17:07 --> Loader Class Initialized
INFO - 2016-11-30 18:17:07 --> Helper loaded: url_helper
INFO - 2016-11-30 18:17:07 --> Helper loaded: form_helper
INFO - 2016-11-30 18:17:07 --> Database Driver Class Initialized
INFO - 2016-11-30 18:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:17:07 --> Controller Class Initialized
INFO - 2016-11-30 18:17:07 --> Model Class Initialized
INFO - 2016-11-30 18:17:07 --> Form Validation Class Initialized
INFO - 2016-11-30 18:17:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:17:07 --> Pagination Class Initialized
INFO - 2016-11-30 18:17:07 --> Helper loaded: app_helper
INFO - 2016-11-30 18:17:07 --> Email Class Initialized
INFO - 2016-11-30 18:17:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 17:17:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 17:17:08 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 17:17:08 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-30 18:19:07 --> Config Class Initialized
INFO - 2016-11-30 18:19:08 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:19:08 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:19:08 --> Utf8 Class Initialized
INFO - 2016-11-30 18:19:08 --> URI Class Initialized
DEBUG - 2016-11-30 18:19:08 --> No URI present. Default controller set.
INFO - 2016-11-30 18:19:08 --> Router Class Initialized
INFO - 2016-11-30 18:19:08 --> Output Class Initialized
INFO - 2016-11-30 18:19:08 --> Security Class Initialized
DEBUG - 2016-11-30 18:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:19:08 --> Input Class Initialized
INFO - 2016-11-30 18:19:08 --> Language Class Initialized
INFO - 2016-11-30 18:19:08 --> Loader Class Initialized
INFO - 2016-11-30 18:19:08 --> Helper loaded: url_helper
INFO - 2016-11-30 18:19:08 --> Helper loaded: form_helper
INFO - 2016-11-30 18:19:08 --> Database Driver Class Initialized
INFO - 2016-11-30 18:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:19:08 --> Controller Class Initialized
INFO - 2016-11-30 18:19:08 --> Model Class Initialized
INFO - 2016-11-30 18:19:08 --> Model Class Initialized
INFO - 2016-11-30 18:19:08 --> Model Class Initialized
INFO - 2016-11-30 18:19:08 --> Model Class Initialized
INFO - 2016-11-30 18:19:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:19:08 --> Pagination Class Initialized
INFO - 2016-11-30 18:19:08 --> Helper loaded: app_helper
INFO - 2016-11-30 18:19:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:19:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:19:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:19:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:19:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:19:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:19:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:19:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:19:08 --> Final output sent to browser
DEBUG - 2016-11-30 18:19:08 --> Total execution time: 0.7510
INFO - 2016-11-30 18:19:19 --> Config Class Initialized
INFO - 2016-11-30 18:19:19 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:19:19 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:19:19 --> Utf8 Class Initialized
INFO - 2016-11-30 18:19:19 --> URI Class Initialized
INFO - 2016-11-30 18:19:19 --> Router Class Initialized
INFO - 2016-11-30 18:19:19 --> Output Class Initialized
INFO - 2016-11-30 18:19:19 --> Security Class Initialized
DEBUG - 2016-11-30 18:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:19:19 --> Input Class Initialized
INFO - 2016-11-30 18:19:19 --> Language Class Initialized
INFO - 2016-11-30 18:19:19 --> Loader Class Initialized
INFO - 2016-11-30 18:19:19 --> Helper loaded: url_helper
INFO - 2016-11-30 18:19:19 --> Helper loaded: form_helper
INFO - 2016-11-30 18:19:19 --> Database Driver Class Initialized
INFO - 2016-11-30 18:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:19:19 --> Controller Class Initialized
INFO - 2016-11-30 18:19:19 --> Model Class Initialized
INFO - 2016-11-30 18:19:19 --> Form Validation Class Initialized
INFO - 2016-11-30 18:19:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:19:19 --> Pagination Class Initialized
INFO - 2016-11-30 18:19:19 --> Helper loaded: app_helper
INFO - 2016-11-30 18:19:19 --> Email Class Initialized
INFO - 2016-11-30 18:19:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 17:19:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-30 18:20:48 --> Config Class Initialized
INFO - 2016-11-30 18:20:48 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:20:48 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:20:48 --> Utf8 Class Initialized
INFO - 2016-11-30 18:20:48 --> URI Class Initialized
DEBUG - 2016-11-30 18:20:48 --> No URI present. Default controller set.
INFO - 2016-11-30 18:20:48 --> Router Class Initialized
INFO - 2016-11-30 18:20:48 --> Output Class Initialized
INFO - 2016-11-30 18:20:48 --> Security Class Initialized
DEBUG - 2016-11-30 18:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:20:49 --> Input Class Initialized
INFO - 2016-11-30 18:20:49 --> Language Class Initialized
INFO - 2016-11-30 18:20:49 --> Loader Class Initialized
INFO - 2016-11-30 18:20:49 --> Helper loaded: url_helper
INFO - 2016-11-30 18:20:49 --> Helper loaded: form_helper
INFO - 2016-11-30 18:20:49 --> Database Driver Class Initialized
INFO - 2016-11-30 18:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:20:49 --> Controller Class Initialized
INFO - 2016-11-30 18:20:49 --> Model Class Initialized
INFO - 2016-11-30 18:20:49 --> Model Class Initialized
INFO - 2016-11-30 18:20:49 --> Model Class Initialized
INFO - 2016-11-30 18:20:49 --> Model Class Initialized
INFO - 2016-11-30 18:20:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:20:49 --> Pagination Class Initialized
INFO - 2016-11-30 18:20:49 --> Helper loaded: app_helper
INFO - 2016-11-30 18:20:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:20:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:20:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:20:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:20:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:20:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:20:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:20:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:20:49 --> Final output sent to browser
DEBUG - 2016-11-30 18:20:49 --> Total execution time: 0.8062
INFO - 2016-11-30 18:20:59 --> Config Class Initialized
INFO - 2016-11-30 18:20:59 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:20:59 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:21:00 --> Utf8 Class Initialized
INFO - 2016-11-30 18:21:00 --> URI Class Initialized
DEBUG - 2016-11-30 18:21:00 --> No URI present. Default controller set.
INFO - 2016-11-30 18:21:00 --> Router Class Initialized
INFO - 2016-11-30 18:21:00 --> Output Class Initialized
INFO - 2016-11-30 18:21:00 --> Security Class Initialized
DEBUG - 2016-11-30 18:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:21:00 --> Input Class Initialized
INFO - 2016-11-30 18:21:00 --> Language Class Initialized
INFO - 2016-11-30 18:21:00 --> Loader Class Initialized
INFO - 2016-11-30 18:21:00 --> Helper loaded: url_helper
INFO - 2016-11-30 18:21:00 --> Helper loaded: form_helper
INFO - 2016-11-30 18:21:00 --> Database Driver Class Initialized
INFO - 2016-11-30 18:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:21:00 --> Controller Class Initialized
INFO - 2016-11-30 18:21:00 --> Model Class Initialized
INFO - 2016-11-30 18:21:00 --> Model Class Initialized
INFO - 2016-11-30 18:21:00 --> Model Class Initialized
INFO - 2016-11-30 18:21:00 --> Model Class Initialized
INFO - 2016-11-30 18:21:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:21:00 --> Pagination Class Initialized
INFO - 2016-11-30 18:21:00 --> Helper loaded: app_helper
INFO - 2016-11-30 18:21:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:21:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:21:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:21:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:21:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:21:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:21:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:21:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:21:00 --> Final output sent to browser
DEBUG - 2016-11-30 18:21:00 --> Total execution time: 0.8283
INFO - 2016-11-30 18:21:10 --> Config Class Initialized
INFO - 2016-11-30 18:21:10 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:21:10 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:21:10 --> Utf8 Class Initialized
INFO - 2016-11-30 18:21:10 --> URI Class Initialized
INFO - 2016-11-30 18:21:10 --> Router Class Initialized
INFO - 2016-11-30 18:21:10 --> Output Class Initialized
INFO - 2016-11-30 18:21:10 --> Security Class Initialized
DEBUG - 2016-11-30 18:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:21:11 --> Input Class Initialized
INFO - 2016-11-30 18:21:11 --> Language Class Initialized
INFO - 2016-11-30 18:21:11 --> Loader Class Initialized
INFO - 2016-11-30 18:21:11 --> Helper loaded: url_helper
INFO - 2016-11-30 18:21:11 --> Helper loaded: form_helper
INFO - 2016-11-30 18:21:11 --> Database Driver Class Initialized
INFO - 2016-11-30 18:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:21:11 --> Controller Class Initialized
INFO - 2016-11-30 18:21:11 --> Model Class Initialized
INFO - 2016-11-30 18:21:11 --> Form Validation Class Initialized
INFO - 2016-11-30 18:21:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:21:11 --> Pagination Class Initialized
INFO - 2016-11-30 18:21:11 --> Helper loaded: app_helper
INFO - 2016-11-30 18:21:11 --> Email Class Initialized
INFO - 2016-11-30 18:21:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 17:21:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 17:21:11 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 18:21:55 --> Config Class Initialized
INFO - 2016-11-30 18:21:55 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:21:55 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:21:55 --> Utf8 Class Initialized
INFO - 2016-11-30 18:21:55 --> URI Class Initialized
DEBUG - 2016-11-30 18:21:55 --> No URI present. Default controller set.
INFO - 2016-11-30 18:21:55 --> Router Class Initialized
INFO - 2016-11-30 18:21:55 --> Output Class Initialized
INFO - 2016-11-30 18:21:55 --> Security Class Initialized
DEBUG - 2016-11-30 18:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:21:55 --> Input Class Initialized
INFO - 2016-11-30 18:21:55 --> Language Class Initialized
INFO - 2016-11-30 18:21:55 --> Loader Class Initialized
INFO - 2016-11-30 18:21:55 --> Helper loaded: url_helper
INFO - 2016-11-30 18:21:55 --> Helper loaded: form_helper
INFO - 2016-11-30 18:21:55 --> Database Driver Class Initialized
INFO - 2016-11-30 18:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:21:55 --> Controller Class Initialized
INFO - 2016-11-30 18:21:55 --> Model Class Initialized
INFO - 2016-11-30 18:21:55 --> Model Class Initialized
INFO - 2016-11-30 18:21:55 --> Model Class Initialized
INFO - 2016-11-30 18:21:55 --> Model Class Initialized
INFO - 2016-11-30 18:21:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:21:55 --> Pagination Class Initialized
INFO - 2016-11-30 18:21:55 --> Helper loaded: app_helper
INFO - 2016-11-30 18:21:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:21:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:21:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:21:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:21:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:21:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:21:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:21:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:21:55 --> Final output sent to browser
DEBUG - 2016-11-30 18:21:56 --> Total execution time: 0.8337
INFO - 2016-11-30 18:22:12 --> Config Class Initialized
INFO - 2016-11-30 18:22:12 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:22:13 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:22:13 --> Utf8 Class Initialized
INFO - 2016-11-30 18:22:13 --> URI Class Initialized
INFO - 2016-11-30 18:22:13 --> Router Class Initialized
INFO - 2016-11-30 18:22:13 --> Output Class Initialized
INFO - 2016-11-30 18:22:13 --> Security Class Initialized
DEBUG - 2016-11-30 18:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:22:13 --> Input Class Initialized
INFO - 2016-11-30 18:22:13 --> Language Class Initialized
INFO - 2016-11-30 18:22:13 --> Loader Class Initialized
INFO - 2016-11-30 18:22:13 --> Helper loaded: url_helper
INFO - 2016-11-30 18:22:13 --> Helper loaded: form_helper
INFO - 2016-11-30 18:22:13 --> Database Driver Class Initialized
INFO - 2016-11-30 18:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:22:13 --> Controller Class Initialized
INFO - 2016-11-30 18:22:13 --> Model Class Initialized
INFO - 2016-11-30 18:22:13 --> Form Validation Class Initialized
INFO - 2016-11-30 18:22:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:22:13 --> Pagination Class Initialized
INFO - 2016-11-30 18:22:13 --> Helper loaded: app_helper
INFO - 2016-11-30 18:22:13 --> Email Class Initialized
INFO - 2016-11-30 18:22:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 17:22:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 17:22:13 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 18:23:07 --> Config Class Initialized
INFO - 2016-11-30 18:23:07 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:23:07 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:23:07 --> Utf8 Class Initialized
INFO - 2016-11-30 18:23:08 --> URI Class Initialized
DEBUG - 2016-11-30 18:23:08 --> No URI present. Default controller set.
INFO - 2016-11-30 18:23:08 --> Router Class Initialized
INFO - 2016-11-30 18:23:08 --> Output Class Initialized
INFO - 2016-11-30 18:23:08 --> Security Class Initialized
DEBUG - 2016-11-30 18:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:23:08 --> Input Class Initialized
INFO - 2016-11-30 18:23:08 --> Language Class Initialized
INFO - 2016-11-30 18:23:08 --> Loader Class Initialized
INFO - 2016-11-30 18:23:08 --> Helper loaded: url_helper
INFO - 2016-11-30 18:23:08 --> Helper loaded: form_helper
INFO - 2016-11-30 18:23:08 --> Database Driver Class Initialized
INFO - 2016-11-30 18:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:23:08 --> Controller Class Initialized
INFO - 2016-11-30 18:23:08 --> Model Class Initialized
INFO - 2016-11-30 18:23:08 --> Model Class Initialized
INFO - 2016-11-30 18:23:08 --> Model Class Initialized
INFO - 2016-11-30 18:23:08 --> Model Class Initialized
INFO - 2016-11-30 18:23:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:23:08 --> Pagination Class Initialized
INFO - 2016-11-30 18:23:08 --> Helper loaded: app_helper
INFO - 2016-11-30 18:23:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:23:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:23:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:23:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:23:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:23:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:23:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:23:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:23:08 --> Final output sent to browser
DEBUG - 2016-11-30 18:23:08 --> Total execution time: 0.7942
INFO - 2016-11-30 18:23:25 --> Config Class Initialized
INFO - 2016-11-30 18:23:25 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:23:25 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:23:25 --> Utf8 Class Initialized
INFO - 2016-11-30 18:23:25 --> URI Class Initialized
INFO - 2016-11-30 18:23:25 --> Router Class Initialized
INFO - 2016-11-30 18:23:25 --> Output Class Initialized
INFO - 2016-11-30 18:23:25 --> Security Class Initialized
DEBUG - 2016-11-30 18:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:23:25 --> Input Class Initialized
INFO - 2016-11-30 18:23:25 --> Language Class Initialized
INFO - 2016-11-30 18:23:25 --> Loader Class Initialized
INFO - 2016-11-30 18:23:25 --> Helper loaded: url_helper
INFO - 2016-11-30 18:23:25 --> Helper loaded: form_helper
INFO - 2016-11-30 18:23:25 --> Database Driver Class Initialized
INFO - 2016-11-30 18:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:23:25 --> Controller Class Initialized
INFO - 2016-11-30 18:23:25 --> Model Class Initialized
INFO - 2016-11-30 18:23:25 --> Form Validation Class Initialized
INFO - 2016-11-30 18:23:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:23:25 --> Pagination Class Initialized
INFO - 2016-11-30 18:23:25 --> Helper loaded: app_helper
INFO - 2016-11-30 18:23:25 --> Email Class Initialized
INFO - 2016-11-30 18:23:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 17:23:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 17:23:26 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 18:25:58 --> Config Class Initialized
INFO - 2016-11-30 18:25:58 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:25:58 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:25:58 --> Utf8 Class Initialized
INFO - 2016-11-30 18:25:58 --> URI Class Initialized
DEBUG - 2016-11-30 18:25:58 --> No URI present. Default controller set.
INFO - 2016-11-30 18:25:58 --> Router Class Initialized
INFO - 2016-11-30 18:25:58 --> Output Class Initialized
INFO - 2016-11-30 18:25:58 --> Security Class Initialized
DEBUG - 2016-11-30 18:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:25:58 --> Input Class Initialized
INFO - 2016-11-30 18:25:58 --> Language Class Initialized
INFO - 2016-11-30 18:25:58 --> Loader Class Initialized
INFO - 2016-11-30 18:25:58 --> Helper loaded: url_helper
INFO - 2016-11-30 18:25:58 --> Helper loaded: form_helper
INFO - 2016-11-30 18:25:58 --> Database Driver Class Initialized
INFO - 2016-11-30 18:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:25:58 --> Controller Class Initialized
INFO - 2016-11-30 18:25:58 --> Model Class Initialized
INFO - 2016-11-30 18:25:58 --> Model Class Initialized
INFO - 2016-11-30 18:25:58 --> Model Class Initialized
INFO - 2016-11-30 18:25:58 --> Model Class Initialized
INFO - 2016-11-30 18:25:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:25:58 --> Pagination Class Initialized
INFO - 2016-11-30 18:25:58 --> Helper loaded: app_helper
INFO - 2016-11-30 18:25:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:25:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:25:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:25:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:25:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:25:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:25:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:25:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:25:59 --> Final output sent to browser
DEBUG - 2016-11-30 18:25:59 --> Total execution time: 0.7801
INFO - 2016-11-30 18:26:09 --> Config Class Initialized
INFO - 2016-11-30 18:26:09 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:26:09 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:26:09 --> Utf8 Class Initialized
INFO - 2016-11-30 18:26:09 --> URI Class Initialized
INFO - 2016-11-30 18:26:09 --> Router Class Initialized
INFO - 2016-11-30 18:26:09 --> Output Class Initialized
INFO - 2016-11-30 18:26:09 --> Security Class Initialized
DEBUG - 2016-11-30 18:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:26:09 --> Input Class Initialized
INFO - 2016-11-30 18:26:09 --> Language Class Initialized
INFO - 2016-11-30 18:26:09 --> Loader Class Initialized
INFO - 2016-11-30 18:26:09 --> Helper loaded: url_helper
INFO - 2016-11-30 18:26:09 --> Helper loaded: form_helper
INFO - 2016-11-30 18:26:10 --> Database Driver Class Initialized
INFO - 2016-11-30 18:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:26:10 --> Controller Class Initialized
INFO - 2016-11-30 18:26:10 --> Model Class Initialized
INFO - 2016-11-30 18:26:10 --> Form Validation Class Initialized
INFO - 2016-11-30 18:26:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:26:10 --> Pagination Class Initialized
INFO - 2016-11-30 18:26:10 --> Helper loaded: app_helper
INFO - 2016-11-30 18:26:10 --> Email Class Initialized
INFO - 2016-11-30 18:26:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 17:26:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 17:26:10 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 17:26:10 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-30 18:28:29 --> Config Class Initialized
INFO - 2016-11-30 18:28:29 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:28:29 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:28:29 --> Utf8 Class Initialized
INFO - 2016-11-30 18:28:29 --> URI Class Initialized
DEBUG - 2016-11-30 18:28:29 --> No URI present. Default controller set.
INFO - 2016-11-30 18:28:29 --> Router Class Initialized
INFO - 2016-11-30 18:28:29 --> Output Class Initialized
INFO - 2016-11-30 18:28:29 --> Security Class Initialized
DEBUG - 2016-11-30 18:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:28:29 --> Input Class Initialized
INFO - 2016-11-30 18:28:29 --> Language Class Initialized
INFO - 2016-11-30 18:28:29 --> Loader Class Initialized
INFO - 2016-11-30 18:28:29 --> Helper loaded: url_helper
INFO - 2016-11-30 18:28:29 --> Helper loaded: form_helper
INFO - 2016-11-30 18:28:29 --> Database Driver Class Initialized
INFO - 2016-11-30 18:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:28:30 --> Controller Class Initialized
INFO - 2016-11-30 18:28:30 --> Model Class Initialized
INFO - 2016-11-30 18:28:30 --> Model Class Initialized
INFO - 2016-11-30 18:28:30 --> Model Class Initialized
INFO - 2016-11-30 18:28:30 --> Model Class Initialized
INFO - 2016-11-30 18:28:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:28:30 --> Pagination Class Initialized
INFO - 2016-11-30 18:28:30 --> Helper loaded: app_helper
INFO - 2016-11-30 18:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:28:30 --> Final output sent to browser
DEBUG - 2016-11-30 18:28:30 --> Total execution time: 0.7673
INFO - 2016-11-30 18:28:39 --> Config Class Initialized
INFO - 2016-11-30 18:28:39 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:28:39 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:28:39 --> Utf8 Class Initialized
INFO - 2016-11-30 18:28:39 --> URI Class Initialized
INFO - 2016-11-30 18:28:39 --> Router Class Initialized
INFO - 2016-11-30 18:28:39 --> Output Class Initialized
INFO - 2016-11-30 18:28:39 --> Security Class Initialized
DEBUG - 2016-11-30 18:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:28:39 --> Input Class Initialized
INFO - 2016-11-30 18:28:39 --> Language Class Initialized
INFO - 2016-11-30 18:28:39 --> Loader Class Initialized
INFO - 2016-11-30 18:28:39 --> Helper loaded: url_helper
INFO - 2016-11-30 18:28:39 --> Helper loaded: form_helper
INFO - 2016-11-30 18:28:39 --> Database Driver Class Initialized
INFO - 2016-11-30 18:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:28:39 --> Controller Class Initialized
INFO - 2016-11-30 18:28:39 --> Model Class Initialized
INFO - 2016-11-30 18:28:39 --> Form Validation Class Initialized
INFO - 2016-11-30 18:28:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:28:39 --> Pagination Class Initialized
INFO - 2016-11-30 18:28:39 --> Helper loaded: app_helper
INFO - 2016-11-30 18:28:39 --> Email Class Initialized
INFO - 2016-11-30 18:28:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 18:28:39 --> Final output sent to browser
DEBUG - 2016-11-30 18:28:39 --> Total execution time: 0.6055
INFO - 2016-11-30 18:29:03 --> Config Class Initialized
INFO - 2016-11-30 18:29:03 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:29:03 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:29:03 --> Utf8 Class Initialized
INFO - 2016-11-30 18:29:03 --> URI Class Initialized
INFO - 2016-11-30 18:29:03 --> Router Class Initialized
INFO - 2016-11-30 18:29:03 --> Output Class Initialized
INFO - 2016-11-30 18:29:03 --> Security Class Initialized
DEBUG - 2016-11-30 18:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:29:03 --> Input Class Initialized
INFO - 2016-11-30 18:29:03 --> Language Class Initialized
INFO - 2016-11-30 18:29:03 --> Loader Class Initialized
INFO - 2016-11-30 18:29:03 --> Helper loaded: url_helper
INFO - 2016-11-30 18:29:03 --> Helper loaded: form_helper
INFO - 2016-11-30 18:29:03 --> Database Driver Class Initialized
INFO - 2016-11-30 18:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:29:03 --> Controller Class Initialized
INFO - 2016-11-30 18:29:03 --> Model Class Initialized
INFO - 2016-11-30 18:29:03 --> Form Validation Class Initialized
INFO - 2016-11-30 18:29:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:29:03 --> Pagination Class Initialized
INFO - 2016-11-30 18:29:04 --> Helper loaded: app_helper
INFO - 2016-11-30 18:29:04 --> Email Class Initialized
INFO - 2016-11-30 18:29:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 17:29:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 17:29:04 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-30 17:29:04 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 208
ERROR - 2016-11-30 17:29:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\sys\libraries\Email.php 452
INFO - 2016-11-30 17:29:04 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-30 18:29:26 --> Config Class Initialized
INFO - 2016-11-30 18:29:26 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:29:26 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:29:26 --> Utf8 Class Initialized
INFO - 2016-11-30 18:29:26 --> URI Class Initialized
DEBUG - 2016-11-30 18:29:26 --> No URI present. Default controller set.
INFO - 2016-11-30 18:29:26 --> Router Class Initialized
INFO - 2016-11-30 18:29:26 --> Output Class Initialized
INFO - 2016-11-30 18:29:26 --> Security Class Initialized
DEBUG - 2016-11-30 18:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:29:26 --> Input Class Initialized
INFO - 2016-11-30 18:29:26 --> Language Class Initialized
INFO - 2016-11-30 18:29:26 --> Loader Class Initialized
INFO - 2016-11-30 18:29:26 --> Helper loaded: url_helper
INFO - 2016-11-30 18:29:26 --> Helper loaded: form_helper
INFO - 2016-11-30 18:29:26 --> Database Driver Class Initialized
INFO - 2016-11-30 18:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:29:26 --> Controller Class Initialized
INFO - 2016-11-30 18:29:26 --> Model Class Initialized
INFO - 2016-11-30 18:29:26 --> Model Class Initialized
INFO - 2016-11-30 18:29:26 --> Model Class Initialized
INFO - 2016-11-30 18:29:26 --> Model Class Initialized
INFO - 2016-11-30 18:29:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:29:27 --> Pagination Class Initialized
INFO - 2016-11-30 18:29:27 --> Helper loaded: app_helper
INFO - 2016-11-30 18:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:29:27 --> Final output sent to browser
DEBUG - 2016-11-30 18:29:27 --> Total execution time: 0.7632
INFO - 2016-11-30 18:29:41 --> Config Class Initialized
INFO - 2016-11-30 18:29:41 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:29:41 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:29:41 --> Utf8 Class Initialized
INFO - 2016-11-30 18:29:41 --> URI Class Initialized
DEBUG - 2016-11-30 18:29:41 --> No URI present. Default controller set.
INFO - 2016-11-30 18:29:41 --> Router Class Initialized
INFO - 2016-11-30 18:29:41 --> Output Class Initialized
INFO - 2016-11-30 18:29:41 --> Security Class Initialized
DEBUG - 2016-11-30 18:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:29:41 --> Input Class Initialized
INFO - 2016-11-30 18:29:41 --> Language Class Initialized
INFO - 2016-11-30 18:29:41 --> Loader Class Initialized
INFO - 2016-11-30 18:29:41 --> Helper loaded: url_helper
INFO - 2016-11-30 18:29:41 --> Helper loaded: form_helper
INFO - 2016-11-30 18:29:41 --> Database Driver Class Initialized
INFO - 2016-11-30 18:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:29:41 --> Controller Class Initialized
INFO - 2016-11-30 18:29:41 --> Model Class Initialized
INFO - 2016-11-30 18:29:42 --> Model Class Initialized
INFO - 2016-11-30 18:29:42 --> Model Class Initialized
INFO - 2016-11-30 18:29:42 --> Model Class Initialized
INFO - 2016-11-30 18:29:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:29:42 --> Pagination Class Initialized
INFO - 2016-11-30 18:29:42 --> Helper loaded: app_helper
INFO - 2016-11-30 18:29:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:29:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:29:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:29:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:29:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:29:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:29:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:29:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:29:42 --> Final output sent to browser
DEBUG - 2016-11-30 18:29:42 --> Total execution time: 0.7841
INFO - 2016-11-30 18:29:55 --> Config Class Initialized
INFO - 2016-11-30 18:29:55 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:29:55 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:29:55 --> Utf8 Class Initialized
INFO - 2016-11-30 18:29:55 --> URI Class Initialized
INFO - 2016-11-30 18:29:55 --> Router Class Initialized
INFO - 2016-11-30 18:29:55 --> Output Class Initialized
INFO - 2016-11-30 18:29:55 --> Security Class Initialized
DEBUG - 2016-11-30 18:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:29:55 --> Input Class Initialized
INFO - 2016-11-30 18:29:55 --> Language Class Initialized
INFO - 2016-11-30 18:29:55 --> Loader Class Initialized
INFO - 2016-11-30 18:29:55 --> Helper loaded: url_helper
INFO - 2016-11-30 18:29:55 --> Helper loaded: form_helper
INFO - 2016-11-30 18:29:55 --> Database Driver Class Initialized
INFO - 2016-11-30 18:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:29:55 --> Controller Class Initialized
INFO - 2016-11-30 18:29:55 --> Model Class Initialized
INFO - 2016-11-30 18:29:55 --> Form Validation Class Initialized
INFO - 2016-11-30 18:29:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:29:55 --> Pagination Class Initialized
INFO - 2016-11-30 18:29:55 --> Helper loaded: app_helper
INFO - 2016-11-30 18:29:55 --> Email Class Initialized
INFO - 2016-11-30 18:29:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 17:29:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 17:29:56 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 17:29:56 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-30 18:37:56 --> Config Class Initialized
INFO - 2016-11-30 18:37:56 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:37:56 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:37:56 --> Utf8 Class Initialized
INFO - 2016-11-30 18:37:56 --> URI Class Initialized
DEBUG - 2016-11-30 18:37:56 --> No URI present. Default controller set.
INFO - 2016-11-30 18:37:56 --> Router Class Initialized
INFO - 2016-11-30 18:37:56 --> Output Class Initialized
INFO - 2016-11-30 18:37:56 --> Security Class Initialized
DEBUG - 2016-11-30 18:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:37:56 --> Input Class Initialized
INFO - 2016-11-30 18:37:56 --> Language Class Initialized
INFO - 2016-11-30 18:37:56 --> Loader Class Initialized
INFO - 2016-11-30 18:37:56 --> Helper loaded: url_helper
INFO - 2016-11-30 18:37:56 --> Helper loaded: form_helper
INFO - 2016-11-30 18:37:56 --> Database Driver Class Initialized
INFO - 2016-11-30 18:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:37:56 --> Controller Class Initialized
INFO - 2016-11-30 18:37:56 --> Model Class Initialized
INFO - 2016-11-30 18:37:56 --> Model Class Initialized
INFO - 2016-11-30 18:37:56 --> Model Class Initialized
INFO - 2016-11-30 18:37:56 --> Model Class Initialized
INFO - 2016-11-30 18:37:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:37:57 --> Pagination Class Initialized
INFO - 2016-11-30 18:37:57 --> Helper loaded: app_helper
INFO - 2016-11-30 18:37:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:37:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:37:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:37:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:37:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:37:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:37:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:37:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:37:57 --> Final output sent to browser
DEBUG - 2016-11-30 18:37:57 --> Total execution time: 1.0333
INFO - 2016-11-30 18:38:08 --> Config Class Initialized
INFO - 2016-11-30 18:38:08 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:38:08 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:38:08 --> Utf8 Class Initialized
INFO - 2016-11-30 18:38:08 --> URI Class Initialized
INFO - 2016-11-30 18:38:08 --> Router Class Initialized
INFO - 2016-11-30 18:38:08 --> Output Class Initialized
INFO - 2016-11-30 18:38:08 --> Security Class Initialized
DEBUG - 2016-11-30 18:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:38:08 --> Input Class Initialized
INFO - 2016-11-30 18:38:08 --> Language Class Initialized
INFO - 2016-11-30 18:38:08 --> Loader Class Initialized
INFO - 2016-11-30 18:38:08 --> Helper loaded: url_helper
INFO - 2016-11-30 18:38:08 --> Helper loaded: form_helper
INFO - 2016-11-30 18:38:08 --> Database Driver Class Initialized
INFO - 2016-11-30 18:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:38:08 --> Controller Class Initialized
INFO - 2016-11-30 18:38:08 --> Model Class Initialized
INFO - 2016-11-30 18:38:08 --> Form Validation Class Initialized
INFO - 2016-11-30 18:38:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:38:08 --> Pagination Class Initialized
INFO - 2016-11-30 18:38:08 --> Helper loaded: app_helper
INFO - 2016-11-30 18:38:08 --> Email Class Initialized
INFO - 2016-11-30 18:38:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 17:38:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 17:38:08 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 17:38:09 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-30 18:40:09 --> Config Class Initialized
INFO - 2016-11-30 18:40:09 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:40:09 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:40:09 --> Utf8 Class Initialized
INFO - 2016-11-30 18:40:09 --> URI Class Initialized
DEBUG - 2016-11-30 18:40:09 --> No URI present. Default controller set.
INFO - 2016-11-30 18:40:09 --> Router Class Initialized
INFO - 2016-11-30 18:40:09 --> Output Class Initialized
INFO - 2016-11-30 18:40:09 --> Security Class Initialized
DEBUG - 2016-11-30 18:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:40:09 --> Input Class Initialized
INFO - 2016-11-30 18:40:09 --> Language Class Initialized
INFO - 2016-11-30 18:40:09 --> Loader Class Initialized
INFO - 2016-11-30 18:40:09 --> Helper loaded: url_helper
INFO - 2016-11-30 18:40:09 --> Helper loaded: form_helper
INFO - 2016-11-30 18:40:09 --> Database Driver Class Initialized
INFO - 2016-11-30 18:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:40:09 --> Controller Class Initialized
INFO - 2016-11-30 18:40:09 --> Model Class Initialized
INFO - 2016-11-30 18:40:09 --> Model Class Initialized
INFO - 2016-11-30 18:40:10 --> Model Class Initialized
INFO - 2016-11-30 18:40:10 --> Model Class Initialized
INFO - 2016-11-30 18:40:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:40:10 --> Pagination Class Initialized
INFO - 2016-11-30 18:40:10 --> Helper loaded: app_helper
INFO - 2016-11-30 18:40:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:40:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:40:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:40:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:40:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:40:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:40:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:40:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:40:10 --> Final output sent to browser
DEBUG - 2016-11-30 18:40:10 --> Total execution time: 0.9339
INFO - 2016-11-30 18:40:24 --> Config Class Initialized
INFO - 2016-11-30 18:40:24 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:40:24 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:40:24 --> Utf8 Class Initialized
INFO - 2016-11-30 18:40:24 --> URI Class Initialized
INFO - 2016-11-30 18:40:24 --> Router Class Initialized
INFO - 2016-11-30 18:40:24 --> Output Class Initialized
INFO - 2016-11-30 18:40:24 --> Security Class Initialized
DEBUG - 2016-11-30 18:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:40:25 --> Input Class Initialized
INFO - 2016-11-30 18:40:25 --> Language Class Initialized
INFO - 2016-11-30 18:40:25 --> Loader Class Initialized
INFO - 2016-11-30 18:40:25 --> Helper loaded: url_helper
INFO - 2016-11-30 18:40:25 --> Helper loaded: form_helper
INFO - 2016-11-30 18:40:25 --> Database Driver Class Initialized
INFO - 2016-11-30 18:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:40:25 --> Controller Class Initialized
INFO - 2016-11-30 18:40:25 --> Model Class Initialized
INFO - 2016-11-30 18:40:25 --> Form Validation Class Initialized
INFO - 2016-11-30 18:40:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:40:25 --> Pagination Class Initialized
INFO - 2016-11-30 18:40:25 --> Helper loaded: app_helper
INFO - 2016-11-30 18:40:25 --> Email Class Initialized
INFO - 2016-11-30 18:40:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 17:40:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 17:40:25 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 17:40:25 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-30 18:42:06 --> Config Class Initialized
INFO - 2016-11-30 18:42:07 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:42:07 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:42:07 --> Utf8 Class Initialized
INFO - 2016-11-30 18:42:07 --> URI Class Initialized
DEBUG - 2016-11-30 18:42:07 --> No URI present. Default controller set.
INFO - 2016-11-30 18:42:07 --> Router Class Initialized
INFO - 2016-11-30 18:42:07 --> Output Class Initialized
INFO - 2016-11-30 18:42:07 --> Security Class Initialized
DEBUG - 2016-11-30 18:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:42:07 --> Input Class Initialized
INFO - 2016-11-30 18:42:07 --> Language Class Initialized
INFO - 2016-11-30 18:42:07 --> Loader Class Initialized
INFO - 2016-11-30 18:42:07 --> Helper loaded: url_helper
INFO - 2016-11-30 18:42:07 --> Helper loaded: form_helper
INFO - 2016-11-30 18:42:07 --> Database Driver Class Initialized
INFO - 2016-11-30 18:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:42:07 --> Controller Class Initialized
INFO - 2016-11-30 18:42:07 --> Model Class Initialized
INFO - 2016-11-30 18:42:07 --> Model Class Initialized
INFO - 2016-11-30 18:42:07 --> Model Class Initialized
INFO - 2016-11-30 18:42:07 --> Model Class Initialized
INFO - 2016-11-30 18:42:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:42:07 --> Pagination Class Initialized
INFO - 2016-11-30 18:42:07 --> Helper loaded: app_helper
INFO - 2016-11-30 18:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:42:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:42:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:42:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:42:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:42:08 --> Final output sent to browser
DEBUG - 2016-11-30 18:42:08 --> Total execution time: 1.1633
INFO - 2016-11-30 18:42:21 --> Config Class Initialized
INFO - 2016-11-30 18:42:21 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:42:21 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:42:21 --> Utf8 Class Initialized
INFO - 2016-11-30 18:42:21 --> URI Class Initialized
INFO - 2016-11-30 18:42:21 --> Router Class Initialized
INFO - 2016-11-30 18:42:21 --> Output Class Initialized
INFO - 2016-11-30 18:42:21 --> Security Class Initialized
DEBUG - 2016-11-30 18:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:42:21 --> Input Class Initialized
INFO - 2016-11-30 18:42:21 --> Language Class Initialized
INFO - 2016-11-30 18:42:21 --> Loader Class Initialized
INFO - 2016-11-30 18:42:21 --> Helper loaded: url_helper
INFO - 2016-11-30 18:42:21 --> Helper loaded: form_helper
INFO - 2016-11-30 18:42:21 --> Database Driver Class Initialized
INFO - 2016-11-30 18:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:42:21 --> Controller Class Initialized
INFO - 2016-11-30 18:42:21 --> Model Class Initialized
INFO - 2016-11-30 18:42:21 --> Form Validation Class Initialized
INFO - 2016-11-30 18:42:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:42:21 --> Pagination Class Initialized
INFO - 2016-11-30 18:42:21 --> Helper loaded: app_helper
INFO - 2016-11-30 18:42:21 --> Email Class Initialized
INFO - 2016-11-30 18:42:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 17:42:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 17:42:21 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 17:42:22 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-30 18:44:20 --> Config Class Initialized
INFO - 2016-11-30 18:44:20 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:44:20 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:44:20 --> Utf8 Class Initialized
INFO - 2016-11-30 18:44:20 --> URI Class Initialized
DEBUG - 2016-11-30 18:44:20 --> No URI present. Default controller set.
INFO - 2016-11-30 18:44:20 --> Router Class Initialized
INFO - 2016-11-30 18:44:20 --> Output Class Initialized
INFO - 2016-11-30 18:44:20 --> Security Class Initialized
DEBUG - 2016-11-30 18:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:44:20 --> Input Class Initialized
INFO - 2016-11-30 18:44:20 --> Language Class Initialized
INFO - 2016-11-30 18:44:20 --> Loader Class Initialized
INFO - 2016-11-30 18:44:20 --> Helper loaded: url_helper
INFO - 2016-11-30 18:44:20 --> Helper loaded: form_helper
INFO - 2016-11-30 18:44:20 --> Database Driver Class Initialized
INFO - 2016-11-30 18:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:44:20 --> Controller Class Initialized
INFO - 2016-11-30 18:44:20 --> Model Class Initialized
INFO - 2016-11-30 18:44:20 --> Model Class Initialized
INFO - 2016-11-30 18:44:20 --> Model Class Initialized
INFO - 2016-11-30 18:44:20 --> Model Class Initialized
INFO - 2016-11-30 18:44:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:44:20 --> Pagination Class Initialized
INFO - 2016-11-30 18:44:20 --> Helper loaded: app_helper
INFO - 2016-11-30 18:44:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:44:21 --> Final output sent to browser
DEBUG - 2016-11-30 18:44:21 --> Total execution time: 1.0708
INFO - 2016-11-30 18:44:30 --> Config Class Initialized
INFO - 2016-11-30 18:44:31 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:44:31 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:44:31 --> Utf8 Class Initialized
INFO - 2016-11-30 18:44:31 --> URI Class Initialized
INFO - 2016-11-30 18:44:31 --> Router Class Initialized
INFO - 2016-11-30 18:44:31 --> Output Class Initialized
INFO - 2016-11-30 18:44:31 --> Security Class Initialized
DEBUG - 2016-11-30 18:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:44:31 --> Input Class Initialized
INFO - 2016-11-30 18:44:31 --> Language Class Initialized
INFO - 2016-11-30 18:44:31 --> Loader Class Initialized
INFO - 2016-11-30 18:44:31 --> Helper loaded: url_helper
INFO - 2016-11-30 18:44:31 --> Helper loaded: form_helper
INFO - 2016-11-30 18:44:31 --> Database Driver Class Initialized
INFO - 2016-11-30 18:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:44:31 --> Controller Class Initialized
INFO - 2016-11-30 18:44:31 --> Model Class Initialized
INFO - 2016-11-30 18:44:31 --> Form Validation Class Initialized
INFO - 2016-11-30 18:44:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:44:31 --> Pagination Class Initialized
INFO - 2016-11-30 18:44:31 --> Helper loaded: app_helper
INFO - 2016-11-30 18:44:31 --> Email Class Initialized
INFO - 2016-11-30 18:44:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 17:44:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 17:44:31 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 17:44:31 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-30 18:44:41 --> Config Class Initialized
INFO - 2016-11-30 18:44:41 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:44:41 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:44:41 --> Utf8 Class Initialized
INFO - 2016-11-30 18:44:41 --> URI Class Initialized
DEBUG - 2016-11-30 18:44:41 --> No URI present. Default controller set.
INFO - 2016-11-30 18:44:41 --> Router Class Initialized
INFO - 2016-11-30 18:44:41 --> Output Class Initialized
INFO - 2016-11-30 18:44:41 --> Security Class Initialized
DEBUG - 2016-11-30 18:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:44:41 --> Input Class Initialized
INFO - 2016-11-30 18:44:41 --> Language Class Initialized
INFO - 2016-11-30 18:44:41 --> Loader Class Initialized
INFO - 2016-11-30 18:44:41 --> Helper loaded: url_helper
INFO - 2016-11-30 18:44:41 --> Helper loaded: form_helper
INFO - 2016-11-30 18:44:41 --> Database Driver Class Initialized
INFO - 2016-11-30 18:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:44:41 --> Controller Class Initialized
INFO - 2016-11-30 18:44:41 --> Model Class Initialized
INFO - 2016-11-30 18:44:41 --> Model Class Initialized
INFO - 2016-11-30 18:44:41 --> Model Class Initialized
INFO - 2016-11-30 18:44:41 --> Model Class Initialized
INFO - 2016-11-30 18:44:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:44:41 --> Pagination Class Initialized
INFO - 2016-11-30 18:44:41 --> Helper loaded: app_helper
INFO - 2016-11-30 18:44:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:44:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:44:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:44:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:44:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:44:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:44:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:44:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:44:42 --> Final output sent to browser
DEBUG - 2016-11-30 18:44:42 --> Total execution time: 0.8099
INFO - 2016-11-30 18:49:54 --> Config Class Initialized
INFO - 2016-11-30 18:49:54 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:49:54 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:49:54 --> Utf8 Class Initialized
INFO - 2016-11-30 18:49:54 --> URI Class Initialized
DEBUG - 2016-11-30 18:49:54 --> No URI present. Default controller set.
INFO - 2016-11-30 18:49:54 --> Router Class Initialized
INFO - 2016-11-30 18:49:54 --> Output Class Initialized
INFO - 2016-11-30 18:49:54 --> Security Class Initialized
DEBUG - 2016-11-30 18:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:49:54 --> Input Class Initialized
INFO - 2016-11-30 18:49:54 --> Language Class Initialized
INFO - 2016-11-30 18:49:54 --> Loader Class Initialized
INFO - 2016-11-30 18:49:54 --> Helper loaded: url_helper
INFO - 2016-11-30 18:49:54 --> Helper loaded: form_helper
INFO - 2016-11-30 18:49:54 --> Database Driver Class Initialized
INFO - 2016-11-30 18:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:49:54 --> Controller Class Initialized
INFO - 2016-11-30 18:49:54 --> Model Class Initialized
INFO - 2016-11-30 18:49:54 --> Model Class Initialized
INFO - 2016-11-30 18:49:54 --> Model Class Initialized
INFO - 2016-11-30 18:49:54 --> Model Class Initialized
INFO - 2016-11-30 18:49:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:49:55 --> Pagination Class Initialized
INFO - 2016-11-30 18:49:55 --> Helper loaded: app_helper
INFO - 2016-11-30 18:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:49:55 --> Final output sent to browser
DEBUG - 2016-11-30 18:49:55 --> Total execution time: 1.1050
INFO - 2016-11-30 18:50:10 --> Config Class Initialized
INFO - 2016-11-30 18:50:10 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:50:10 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:50:10 --> Utf8 Class Initialized
INFO - 2016-11-30 18:50:10 --> URI Class Initialized
INFO - 2016-11-30 18:50:10 --> Router Class Initialized
INFO - 2016-11-30 18:50:10 --> Output Class Initialized
INFO - 2016-11-30 18:50:10 --> Security Class Initialized
DEBUG - 2016-11-30 18:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:50:10 --> Input Class Initialized
INFO - 2016-11-30 18:50:10 --> Language Class Initialized
INFO - 2016-11-30 18:50:10 --> Loader Class Initialized
INFO - 2016-11-30 18:50:10 --> Helper loaded: url_helper
INFO - 2016-11-30 18:50:10 --> Helper loaded: form_helper
INFO - 2016-11-30 18:50:10 --> Database Driver Class Initialized
INFO - 2016-11-30 18:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:50:10 --> Controller Class Initialized
INFO - 2016-11-30 18:50:10 --> Model Class Initialized
INFO - 2016-11-30 18:50:10 --> Form Validation Class Initialized
INFO - 2016-11-30 18:50:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:50:10 --> Pagination Class Initialized
INFO - 2016-11-30 18:50:10 --> Helper loaded: app_helper
INFO - 2016-11-30 18:50:10 --> Email Class Initialized
INFO - 2016-11-30 18:50:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 17:50:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 17:50:11 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 17:50:11 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-30 18:50:37 --> Config Class Initialized
INFO - 2016-11-30 18:50:37 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:50:37 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:50:37 --> Utf8 Class Initialized
INFO - 2016-11-30 18:50:37 --> URI Class Initialized
INFO - 2016-11-30 18:50:37 --> Router Class Initialized
INFO - 2016-11-30 18:50:38 --> Output Class Initialized
INFO - 2016-11-30 18:50:38 --> Security Class Initialized
DEBUG - 2016-11-30 18:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:50:38 --> Input Class Initialized
INFO - 2016-11-30 18:50:38 --> Language Class Initialized
INFO - 2016-11-30 18:50:38 --> Loader Class Initialized
INFO - 2016-11-30 18:50:38 --> Helper loaded: url_helper
INFO - 2016-11-30 18:50:38 --> Helper loaded: form_helper
INFO - 2016-11-30 18:50:38 --> Database Driver Class Initialized
INFO - 2016-11-30 18:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:50:38 --> Controller Class Initialized
INFO - 2016-11-30 18:50:38 --> Model Class Initialized
INFO - 2016-11-30 18:50:38 --> Form Validation Class Initialized
INFO - 2016-11-30 18:50:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:50:38 --> Pagination Class Initialized
INFO - 2016-11-30 18:50:38 --> Helper loaded: app_helper
INFO - 2016-11-30 18:50:38 --> Email Class Initialized
INFO - 2016-11-30 18:50:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 17:50:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 17:50:38 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 17:50:38 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-30 18:51:02 --> Config Class Initialized
INFO - 2016-11-30 18:51:02 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:51:02 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:51:02 --> Utf8 Class Initialized
INFO - 2016-11-30 18:51:02 --> URI Class Initialized
INFO - 2016-11-30 18:51:02 --> Router Class Initialized
INFO - 2016-11-30 18:51:02 --> Output Class Initialized
INFO - 2016-11-30 18:51:02 --> Security Class Initialized
DEBUG - 2016-11-30 18:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:51:02 --> Input Class Initialized
INFO - 2016-11-30 18:51:02 --> Language Class Initialized
INFO - 2016-11-30 18:51:02 --> Loader Class Initialized
INFO - 2016-11-30 18:51:02 --> Helper loaded: url_helper
INFO - 2016-11-30 18:51:02 --> Helper loaded: form_helper
INFO - 2016-11-30 18:51:02 --> Database Driver Class Initialized
INFO - 2016-11-30 18:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:51:02 --> Controller Class Initialized
INFO - 2016-11-30 18:51:02 --> Model Class Initialized
INFO - 2016-11-30 18:51:02 --> Form Validation Class Initialized
INFO - 2016-11-30 18:51:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:51:02 --> Pagination Class Initialized
INFO - 2016-11-30 18:51:02 --> Helper loaded: app_helper
INFO - 2016-11-30 18:51:02 --> Email Class Initialized
INFO - 2016-11-30 18:51:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 17:51:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 17:51:03 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 17:51:03 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-30 18:51:52 --> Config Class Initialized
INFO - 2016-11-30 18:51:52 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:51:52 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:51:52 --> Utf8 Class Initialized
INFO - 2016-11-30 18:51:52 --> URI Class Initialized
INFO - 2016-11-30 18:51:52 --> Router Class Initialized
INFO - 2016-11-30 18:51:52 --> Output Class Initialized
INFO - 2016-11-30 18:51:52 --> Security Class Initialized
DEBUG - 2016-11-30 18:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:51:52 --> Input Class Initialized
INFO - 2016-11-30 18:51:52 --> Language Class Initialized
INFO - 2016-11-30 18:51:52 --> Loader Class Initialized
INFO - 2016-11-30 18:51:52 --> Helper loaded: url_helper
INFO - 2016-11-30 18:51:52 --> Helper loaded: form_helper
INFO - 2016-11-30 18:51:52 --> Database Driver Class Initialized
INFO - 2016-11-30 18:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:51:52 --> Controller Class Initialized
INFO - 2016-11-30 18:51:52 --> Model Class Initialized
INFO - 2016-11-30 18:51:52 --> Form Validation Class Initialized
INFO - 2016-11-30 18:51:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:51:52 --> Pagination Class Initialized
INFO - 2016-11-30 18:51:52 --> Helper loaded: app_helper
INFO - 2016-11-30 18:51:52 --> Email Class Initialized
INFO - 2016-11-30 18:51:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 17:51:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 17:51:52 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 17:51:52 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-30 17:51:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-30 17:51:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 17:51:53 --> Final output sent to browser
DEBUG - 2016-11-30 17:51:53 --> Total execution time: 1.3947
INFO - 2016-11-30 18:52:51 --> Config Class Initialized
INFO - 2016-11-30 18:52:52 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:52:52 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:52:52 --> Utf8 Class Initialized
INFO - 2016-11-30 18:52:52 --> URI Class Initialized
INFO - 2016-11-30 18:52:52 --> Router Class Initialized
INFO - 2016-11-30 18:52:52 --> Output Class Initialized
INFO - 2016-11-30 18:52:52 --> Security Class Initialized
DEBUG - 2016-11-30 18:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:52:52 --> Input Class Initialized
INFO - 2016-11-30 18:52:52 --> Language Class Initialized
INFO - 2016-11-30 18:52:52 --> Loader Class Initialized
INFO - 2016-11-30 18:52:52 --> Helper loaded: url_helper
INFO - 2016-11-30 18:52:52 --> Helper loaded: form_helper
INFO - 2016-11-30 18:52:52 --> Database Driver Class Initialized
INFO - 2016-11-30 18:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:52:52 --> Controller Class Initialized
INFO - 2016-11-30 18:52:52 --> Model Class Initialized
INFO - 2016-11-30 18:52:52 --> Form Validation Class Initialized
INFO - 2016-11-30 18:52:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:52:52 --> Pagination Class Initialized
INFO - 2016-11-30 18:52:52 --> Helper loaded: app_helper
INFO - 2016-11-30 18:52:52 --> Email Class Initialized
INFO - 2016-11-30 18:52:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 18:52:52 --> Final output sent to browser
DEBUG - 2016-11-30 18:52:52 --> Total execution time: 0.8654
INFO - 2016-11-30 18:53:08 --> Config Class Initialized
INFO - 2016-11-30 18:53:08 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:53:08 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:53:08 --> Utf8 Class Initialized
INFO - 2016-11-30 18:53:08 --> URI Class Initialized
INFO - 2016-11-30 18:53:08 --> Router Class Initialized
INFO - 2016-11-30 18:53:08 --> Output Class Initialized
INFO - 2016-11-30 18:53:08 --> Security Class Initialized
DEBUG - 2016-11-30 18:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:53:08 --> Input Class Initialized
INFO - 2016-11-30 18:53:08 --> Language Class Initialized
INFO - 2016-11-30 18:53:09 --> Loader Class Initialized
INFO - 2016-11-30 18:53:09 --> Helper loaded: url_helper
INFO - 2016-11-30 18:53:09 --> Helper loaded: form_helper
INFO - 2016-11-30 18:53:09 --> Database Driver Class Initialized
INFO - 2016-11-30 18:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:53:09 --> Controller Class Initialized
INFO - 2016-11-30 18:53:09 --> Model Class Initialized
INFO - 2016-11-30 18:53:09 --> Form Validation Class Initialized
INFO - 2016-11-30 18:53:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:53:09 --> Pagination Class Initialized
INFO - 2016-11-30 18:53:09 --> Helper loaded: app_helper
INFO - 2016-11-30 18:53:09 --> Email Class Initialized
INFO - 2016-11-30 18:53:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-30 17:53:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-30 17:53:09 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-30 17:53:09 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-30 17:53:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-30 17:53:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 17:53:10 --> Final output sent to browser
DEBUG - 2016-11-30 17:53:10 --> Total execution time: 1.3640
INFO - 2016-11-30 18:54:01 --> Config Class Initialized
INFO - 2016-11-30 18:54:02 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:54:02 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:54:02 --> Utf8 Class Initialized
INFO - 2016-11-30 18:54:02 --> URI Class Initialized
DEBUG - 2016-11-30 18:54:02 --> No URI present. Default controller set.
INFO - 2016-11-30 18:54:02 --> Router Class Initialized
INFO - 2016-11-30 18:54:02 --> Output Class Initialized
INFO - 2016-11-30 18:54:02 --> Security Class Initialized
DEBUG - 2016-11-30 18:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:54:02 --> Input Class Initialized
INFO - 2016-11-30 18:54:02 --> Language Class Initialized
INFO - 2016-11-30 18:54:02 --> Loader Class Initialized
INFO - 2016-11-30 18:54:02 --> Helper loaded: url_helper
INFO - 2016-11-30 18:54:02 --> Helper loaded: form_helper
INFO - 2016-11-30 18:54:02 --> Database Driver Class Initialized
INFO - 2016-11-30 18:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:54:02 --> Controller Class Initialized
INFO - 2016-11-30 18:54:02 --> Model Class Initialized
INFO - 2016-11-30 18:54:02 --> Model Class Initialized
INFO - 2016-11-30 18:54:02 --> Model Class Initialized
INFO - 2016-11-30 18:54:02 --> Model Class Initialized
INFO - 2016-11-30 18:54:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:54:02 --> Pagination Class Initialized
INFO - 2016-11-30 18:54:02 --> Helper loaded: app_helper
INFO - 2016-11-30 18:54:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:54:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:54:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:54:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:54:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:54:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:54:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:54:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:54:03 --> Final output sent to browser
DEBUG - 2016-11-30 18:54:03 --> Total execution time: 1.3311
INFO - 2016-11-30 18:55:42 --> Config Class Initialized
INFO - 2016-11-30 18:55:42 --> Hooks Class Initialized
DEBUG - 2016-11-30 18:55:42 --> UTF-8 Support Enabled
INFO - 2016-11-30 18:55:42 --> Utf8 Class Initialized
INFO - 2016-11-30 18:55:42 --> URI Class Initialized
DEBUG - 2016-11-30 18:55:42 --> No URI present. Default controller set.
INFO - 2016-11-30 18:55:42 --> Router Class Initialized
INFO - 2016-11-30 18:55:42 --> Output Class Initialized
INFO - 2016-11-30 18:55:42 --> Security Class Initialized
DEBUG - 2016-11-30 18:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 18:55:42 --> Input Class Initialized
INFO - 2016-11-30 18:55:42 --> Language Class Initialized
INFO - 2016-11-30 18:55:42 --> Loader Class Initialized
INFO - 2016-11-30 18:55:42 --> Helper loaded: url_helper
INFO - 2016-11-30 18:55:42 --> Helper loaded: form_helper
INFO - 2016-11-30 18:55:42 --> Database Driver Class Initialized
INFO - 2016-11-30 18:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 18:55:42 --> Controller Class Initialized
INFO - 2016-11-30 18:55:42 --> Model Class Initialized
INFO - 2016-11-30 18:55:42 --> Model Class Initialized
INFO - 2016-11-30 18:55:42 --> Model Class Initialized
INFO - 2016-11-30 18:55:42 --> Model Class Initialized
INFO - 2016-11-30 18:55:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-30 18:55:42 --> Pagination Class Initialized
INFO - 2016-11-30 18:55:42 --> Helper loaded: app_helper
INFO - 2016-11-30 18:55:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-30 18:55:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-30 18:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-30 18:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-30 18:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-30 18:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-30 18:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-30 18:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-30 18:55:43 --> Final output sent to browser
DEBUG - 2016-11-30 18:55:43 --> Total execution time: 1.1503
