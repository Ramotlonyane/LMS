<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-21 10:25:56 --> Config Class Initialized
INFO - 2016-11-21 10:25:56 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:25:56 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:25:56 --> Utf8 Class Initialized
INFO - 2016-11-21 10:25:56 --> URI Class Initialized
DEBUG - 2016-11-21 10:25:56 --> No URI present. Default controller set.
INFO - 2016-11-21 10:25:56 --> Router Class Initialized
INFO - 2016-11-21 10:25:56 --> Output Class Initialized
INFO - 2016-11-21 10:25:56 --> Security Class Initialized
DEBUG - 2016-11-21 10:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:25:56 --> Input Class Initialized
INFO - 2016-11-21 10:25:56 --> Language Class Initialized
INFO - 2016-11-21 10:25:57 --> Loader Class Initialized
INFO - 2016-11-21 10:25:57 --> Helper loaded: url_helper
INFO - 2016-11-21 10:25:57 --> Helper loaded: form_helper
INFO - 2016-11-21 10:25:57 --> Database Driver Class Initialized
INFO - 2016-11-21 10:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:25:57 --> Controller Class Initialized
INFO - 2016-11-21 10:25:57 --> Model Class Initialized
INFO - 2016-11-21 10:25:57 --> Model Class Initialized
INFO - 2016-11-21 10:25:57 --> Model Class Initialized
INFO - 2016-11-21 10:25:57 --> Model Class Initialized
INFO - 2016-11-21 10:25:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:25:57 --> Pagination Class Initialized
INFO - 2016-11-21 10:25:57 --> Helper loaded: app_helper
INFO - 2016-11-21 10:25:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:25:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-21 10:25:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:25:57 --> Final output sent to browser
DEBUG - 2016-11-21 10:25:57 --> Total execution time: 1.1548
INFO - 2016-11-21 10:26:11 --> Config Class Initialized
INFO - 2016-11-21 10:26:11 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:26:11 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:26:11 --> Utf8 Class Initialized
INFO - 2016-11-21 10:26:11 --> URI Class Initialized
INFO - 2016-11-21 10:26:11 --> Router Class Initialized
INFO - 2016-11-21 10:26:11 --> Output Class Initialized
INFO - 2016-11-21 10:26:11 --> Security Class Initialized
DEBUG - 2016-11-21 10:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:26:11 --> Input Class Initialized
INFO - 2016-11-21 10:26:11 --> Language Class Initialized
INFO - 2016-11-21 10:26:11 --> Loader Class Initialized
INFO - 2016-11-21 10:26:11 --> Helper loaded: url_helper
INFO - 2016-11-21 10:26:11 --> Helper loaded: form_helper
INFO - 2016-11-21 10:26:11 --> Database Driver Class Initialized
INFO - 2016-11-21 10:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:26:11 --> Controller Class Initialized
INFO - 2016-11-21 10:26:11 --> Model Class Initialized
INFO - 2016-11-21 10:26:11 --> Model Class Initialized
INFO - 2016-11-21 10:26:11 --> Model Class Initialized
INFO - 2016-11-21 10:26:11 --> Model Class Initialized
INFO - 2016-11-21 10:26:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:26:11 --> Pagination Class Initialized
INFO - 2016-11-21 10:26:11 --> Helper loaded: app_helper
DEBUG - 2016-11-21 10:26:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-21 10:26:11 --> Model Class Initialized
INFO - 2016-11-21 10:26:11 --> Final output sent to browser
DEBUG - 2016-11-21 10:26:11 --> Total execution time: 0.4337
INFO - 2016-11-21 10:26:11 --> Config Class Initialized
INFO - 2016-11-21 10:26:11 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:26:11 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:26:11 --> Utf8 Class Initialized
INFO - 2016-11-21 10:26:11 --> URI Class Initialized
DEBUG - 2016-11-21 10:26:11 --> No URI present. Default controller set.
INFO - 2016-11-21 10:26:11 --> Router Class Initialized
INFO - 2016-11-21 10:26:11 --> Output Class Initialized
INFO - 2016-11-21 10:26:11 --> Security Class Initialized
DEBUG - 2016-11-21 10:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:26:11 --> Input Class Initialized
INFO - 2016-11-21 10:26:11 --> Language Class Initialized
INFO - 2016-11-21 10:26:11 --> Loader Class Initialized
INFO - 2016-11-21 10:26:11 --> Helper loaded: url_helper
INFO - 2016-11-21 10:26:11 --> Helper loaded: form_helper
INFO - 2016-11-21 10:26:11 --> Database Driver Class Initialized
INFO - 2016-11-21 10:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:26:11 --> Controller Class Initialized
INFO - 2016-11-21 10:26:11 --> Model Class Initialized
INFO - 2016-11-21 10:26:11 --> Model Class Initialized
INFO - 2016-11-21 10:26:11 --> Model Class Initialized
INFO - 2016-11-21 10:26:11 --> Model Class Initialized
INFO - 2016-11-21 10:26:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:26:11 --> Pagination Class Initialized
INFO - 2016-11-21 10:26:11 --> Helper loaded: app_helper
INFO - 2016-11-21 10:26:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:26:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:26:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:26:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:26:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:26:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:26:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:26:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:26:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:26:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:26:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:26:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:26:12 --> Final output sent to browser
DEBUG - 2016-11-21 10:26:12 --> Total execution time: 0.8532
INFO - 2016-11-21 10:26:26 --> Config Class Initialized
INFO - 2016-11-21 10:26:26 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:26:26 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:26:26 --> Utf8 Class Initialized
INFO - 2016-11-21 10:26:26 --> URI Class Initialized
INFO - 2016-11-21 10:26:26 --> Router Class Initialized
INFO - 2016-11-21 10:26:26 --> Output Class Initialized
INFO - 2016-11-21 10:26:26 --> Security Class Initialized
DEBUG - 2016-11-21 10:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:26:26 --> Input Class Initialized
INFO - 2016-11-21 10:26:26 --> Language Class Initialized
INFO - 2016-11-21 10:26:26 --> Loader Class Initialized
INFO - 2016-11-21 10:26:26 --> Helper loaded: url_helper
INFO - 2016-11-21 10:26:26 --> Helper loaded: form_helper
INFO - 2016-11-21 10:26:26 --> Database Driver Class Initialized
INFO - 2016-11-21 10:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:26:26 --> Controller Class Initialized
INFO - 2016-11-21 10:26:26 --> Model Class Initialized
INFO - 2016-11-21 10:26:26 --> Model Class Initialized
INFO - 2016-11-21 10:26:26 --> Model Class Initialized
INFO - 2016-11-21 10:26:26 --> Model Class Initialized
INFO - 2016-11-21 10:26:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:26:26 --> Pagination Class Initialized
INFO - 2016-11-21 10:26:26 --> Helper loaded: app_helper
DEBUG - 2016-11-21 10:26:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-21 10:26:26 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 180
ERROR - 2016-11-21 10:26:26 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 180
INFO - 2016-11-21 10:26:26 --> Config Class Initialized
INFO - 2016-11-21 10:26:26 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:26:26 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:26:27 --> Utf8 Class Initialized
INFO - 2016-11-21 10:26:27 --> URI Class Initialized
DEBUG - 2016-11-21 10:26:27 --> No URI present. Default controller set.
INFO - 2016-11-21 10:26:27 --> Router Class Initialized
INFO - 2016-11-21 10:26:27 --> Output Class Initialized
INFO - 2016-11-21 10:26:27 --> Security Class Initialized
DEBUG - 2016-11-21 10:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:26:27 --> Input Class Initialized
INFO - 2016-11-21 10:26:27 --> Language Class Initialized
INFO - 2016-11-21 10:26:27 --> Loader Class Initialized
INFO - 2016-11-21 10:26:27 --> Helper loaded: url_helper
INFO - 2016-11-21 10:26:27 --> Helper loaded: form_helper
INFO - 2016-11-21 10:26:27 --> Database Driver Class Initialized
INFO - 2016-11-21 10:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:26:27 --> Controller Class Initialized
INFO - 2016-11-21 10:26:27 --> Model Class Initialized
INFO - 2016-11-21 10:26:27 --> Model Class Initialized
INFO - 2016-11-21 10:26:27 --> Model Class Initialized
INFO - 2016-11-21 10:26:27 --> Model Class Initialized
INFO - 2016-11-21 10:26:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:26:27 --> Pagination Class Initialized
INFO - 2016-11-21 10:26:27 --> Helper loaded: app_helper
INFO - 2016-11-21 10:26:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:26:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-21 10:26:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:26:27 --> Final output sent to browser
DEBUG - 2016-11-21 10:26:27 --> Total execution time: 0.2428
INFO - 2016-11-21 10:26:36 --> Config Class Initialized
INFO - 2016-11-21 10:26:36 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:26:36 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:26:36 --> Utf8 Class Initialized
INFO - 2016-11-21 10:26:36 --> URI Class Initialized
INFO - 2016-11-21 10:26:36 --> Router Class Initialized
INFO - 2016-11-21 10:26:36 --> Output Class Initialized
INFO - 2016-11-21 10:26:36 --> Security Class Initialized
DEBUG - 2016-11-21 10:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:26:36 --> Input Class Initialized
INFO - 2016-11-21 10:26:36 --> Language Class Initialized
INFO - 2016-11-21 10:26:36 --> Loader Class Initialized
INFO - 2016-11-21 10:26:36 --> Helper loaded: url_helper
INFO - 2016-11-21 10:26:36 --> Helper loaded: form_helper
INFO - 2016-11-21 10:26:36 --> Database Driver Class Initialized
INFO - 2016-11-21 10:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:26:36 --> Controller Class Initialized
INFO - 2016-11-21 10:26:36 --> Model Class Initialized
INFO - 2016-11-21 10:26:36 --> Model Class Initialized
INFO - 2016-11-21 10:26:36 --> Model Class Initialized
INFO - 2016-11-21 10:26:36 --> Model Class Initialized
INFO - 2016-11-21 10:26:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:26:36 --> Pagination Class Initialized
INFO - 2016-11-21 10:26:36 --> Helper loaded: app_helper
DEBUG - 2016-11-21 10:26:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-21 10:26:36 --> Model Class Initialized
INFO - 2016-11-21 10:26:36 --> Final output sent to browser
DEBUG - 2016-11-21 10:26:36 --> Total execution time: 0.2320
INFO - 2016-11-21 10:26:36 --> Config Class Initialized
INFO - 2016-11-21 10:26:36 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:26:36 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:26:36 --> Utf8 Class Initialized
INFO - 2016-11-21 10:26:36 --> URI Class Initialized
DEBUG - 2016-11-21 10:26:36 --> No URI present. Default controller set.
INFO - 2016-11-21 10:26:36 --> Router Class Initialized
INFO - 2016-11-21 10:26:36 --> Output Class Initialized
INFO - 2016-11-21 10:26:36 --> Security Class Initialized
DEBUG - 2016-11-21 10:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:26:36 --> Input Class Initialized
INFO - 2016-11-21 10:26:36 --> Language Class Initialized
INFO - 2016-11-21 10:26:36 --> Loader Class Initialized
INFO - 2016-11-21 10:26:36 --> Helper loaded: url_helper
INFO - 2016-11-21 10:26:36 --> Helper loaded: form_helper
INFO - 2016-11-21 10:26:36 --> Database Driver Class Initialized
INFO - 2016-11-21 10:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:26:36 --> Controller Class Initialized
INFO - 2016-11-21 10:26:36 --> Model Class Initialized
INFO - 2016-11-21 10:26:36 --> Model Class Initialized
INFO - 2016-11-21 10:26:36 --> Model Class Initialized
INFO - 2016-11-21 10:26:36 --> Model Class Initialized
INFO - 2016-11-21 10:26:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:26:37 --> Pagination Class Initialized
INFO - 2016-11-21 10:26:37 --> Helper loaded: app_helper
INFO - 2016-11-21 10:26:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:26:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:26:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:26:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:26:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:26:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:26:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:26:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:26:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:26:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:26:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:26:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:26:37 --> Final output sent to browser
DEBUG - 2016-11-21 10:26:37 --> Total execution time: 0.3438
INFO - 2016-11-21 10:32:13 --> Config Class Initialized
INFO - 2016-11-21 10:32:13 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:32:13 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:32:13 --> Utf8 Class Initialized
INFO - 2016-11-21 10:32:13 --> URI Class Initialized
DEBUG - 2016-11-21 10:32:13 --> No URI present. Default controller set.
INFO - 2016-11-21 10:32:13 --> Router Class Initialized
INFO - 2016-11-21 10:32:13 --> Output Class Initialized
INFO - 2016-11-21 10:32:13 --> Security Class Initialized
DEBUG - 2016-11-21 10:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:32:13 --> Input Class Initialized
INFO - 2016-11-21 10:32:13 --> Language Class Initialized
INFO - 2016-11-21 10:32:13 --> Loader Class Initialized
INFO - 2016-11-21 10:32:13 --> Helper loaded: url_helper
INFO - 2016-11-21 10:32:13 --> Helper loaded: form_helper
INFO - 2016-11-21 10:32:13 --> Database Driver Class Initialized
INFO - 2016-11-21 10:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:32:14 --> Controller Class Initialized
INFO - 2016-11-21 10:32:14 --> Model Class Initialized
INFO - 2016-11-21 10:32:14 --> Model Class Initialized
INFO - 2016-11-21 10:32:14 --> Model Class Initialized
INFO - 2016-11-21 10:32:14 --> Model Class Initialized
INFO - 2016-11-21 10:32:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:32:14 --> Pagination Class Initialized
INFO - 2016-11-21 10:32:14 --> Helper loaded: app_helper
INFO - 2016-11-21 10:32:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:32:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:32:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:32:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:32:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:32:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:32:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:32:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:32:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:32:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:32:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:32:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:32:14 --> Final output sent to browser
DEBUG - 2016-11-21 10:32:14 --> Total execution time: 0.5621
INFO - 2016-11-21 10:32:53 --> Config Class Initialized
INFO - 2016-11-21 10:32:53 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:32:54 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:32:54 --> Utf8 Class Initialized
INFO - 2016-11-21 10:32:54 --> URI Class Initialized
DEBUG - 2016-11-21 10:32:54 --> No URI present. Default controller set.
INFO - 2016-11-21 10:32:54 --> Router Class Initialized
INFO - 2016-11-21 10:32:54 --> Output Class Initialized
INFO - 2016-11-21 10:32:54 --> Security Class Initialized
DEBUG - 2016-11-21 10:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:32:54 --> Input Class Initialized
INFO - 2016-11-21 10:32:54 --> Language Class Initialized
INFO - 2016-11-21 10:32:54 --> Loader Class Initialized
INFO - 2016-11-21 10:32:54 --> Helper loaded: url_helper
INFO - 2016-11-21 10:32:54 --> Helper loaded: form_helper
INFO - 2016-11-21 10:32:54 --> Database Driver Class Initialized
INFO - 2016-11-21 10:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:32:54 --> Controller Class Initialized
INFO - 2016-11-21 10:32:54 --> Model Class Initialized
INFO - 2016-11-21 10:32:54 --> Model Class Initialized
INFO - 2016-11-21 10:32:54 --> Model Class Initialized
INFO - 2016-11-21 10:32:54 --> Model Class Initialized
INFO - 2016-11-21 10:32:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:32:54 --> Pagination Class Initialized
INFO - 2016-11-21 10:32:54 --> Helper loaded: app_helper
INFO - 2016-11-21 10:32:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:32:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:32:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:32:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:32:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:32:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:32:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:32:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:32:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:32:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:32:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:32:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:32:54 --> Final output sent to browser
DEBUG - 2016-11-21 10:32:54 --> Total execution time: 0.5201
INFO - 2016-11-21 10:34:23 --> Config Class Initialized
INFO - 2016-11-21 10:34:23 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:34:23 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:34:23 --> Utf8 Class Initialized
INFO - 2016-11-21 10:34:23 --> URI Class Initialized
DEBUG - 2016-11-21 10:34:23 --> No URI present. Default controller set.
INFO - 2016-11-21 10:34:23 --> Router Class Initialized
INFO - 2016-11-21 10:34:23 --> Output Class Initialized
INFO - 2016-11-21 10:34:23 --> Security Class Initialized
DEBUG - 2016-11-21 10:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:34:23 --> Input Class Initialized
INFO - 2016-11-21 10:34:23 --> Language Class Initialized
INFO - 2016-11-21 10:34:23 --> Loader Class Initialized
INFO - 2016-11-21 10:34:23 --> Helper loaded: url_helper
INFO - 2016-11-21 10:34:23 --> Helper loaded: form_helper
INFO - 2016-11-21 10:34:23 --> Database Driver Class Initialized
INFO - 2016-11-21 10:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:34:23 --> Controller Class Initialized
INFO - 2016-11-21 10:34:23 --> Model Class Initialized
INFO - 2016-11-21 10:34:23 --> Model Class Initialized
INFO - 2016-11-21 10:34:23 --> Model Class Initialized
INFO - 2016-11-21 10:34:23 --> Model Class Initialized
INFO - 2016-11-21 10:34:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:34:23 --> Pagination Class Initialized
INFO - 2016-11-21 10:34:23 --> Helper loaded: app_helper
INFO - 2016-11-21 10:34:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:34:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:34:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:34:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:34:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:34:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:34:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:34:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:34:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:34:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:34:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:34:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:34:23 --> Final output sent to browser
DEBUG - 2016-11-21 10:34:23 --> Total execution time: 0.5437
INFO - 2016-11-21 10:34:27 --> Config Class Initialized
INFO - 2016-11-21 10:34:27 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:34:27 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:34:27 --> Utf8 Class Initialized
INFO - 2016-11-21 10:34:27 --> URI Class Initialized
DEBUG - 2016-11-21 10:34:27 --> No URI present. Default controller set.
INFO - 2016-11-21 10:34:27 --> Router Class Initialized
INFO - 2016-11-21 10:34:27 --> Output Class Initialized
INFO - 2016-11-21 10:34:27 --> Security Class Initialized
DEBUG - 2016-11-21 10:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:34:27 --> Input Class Initialized
INFO - 2016-11-21 10:34:27 --> Language Class Initialized
INFO - 2016-11-21 10:34:27 --> Loader Class Initialized
INFO - 2016-11-21 10:34:27 --> Helper loaded: url_helper
INFO - 2016-11-21 10:34:27 --> Helper loaded: form_helper
INFO - 2016-11-21 10:34:27 --> Database Driver Class Initialized
INFO - 2016-11-21 10:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:34:27 --> Controller Class Initialized
INFO - 2016-11-21 10:34:27 --> Model Class Initialized
INFO - 2016-11-21 10:34:27 --> Model Class Initialized
INFO - 2016-11-21 10:34:28 --> Model Class Initialized
INFO - 2016-11-21 10:34:28 --> Model Class Initialized
INFO - 2016-11-21 10:34:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:34:28 --> Pagination Class Initialized
INFO - 2016-11-21 10:34:28 --> Helper loaded: app_helper
INFO - 2016-11-21 10:34:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:34:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:34:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:34:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:34:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:34:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:34:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:34:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:34:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:34:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:34:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:34:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:34:28 --> Final output sent to browser
DEBUG - 2016-11-21 10:34:28 --> Total execution time: 0.5281
INFO - 2016-11-21 10:39:12 --> Config Class Initialized
INFO - 2016-11-21 10:39:13 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:39:13 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:39:13 --> Utf8 Class Initialized
INFO - 2016-11-21 10:39:13 --> URI Class Initialized
DEBUG - 2016-11-21 10:39:13 --> No URI present. Default controller set.
INFO - 2016-11-21 10:39:13 --> Router Class Initialized
INFO - 2016-11-21 10:39:13 --> Output Class Initialized
INFO - 2016-11-21 10:39:13 --> Security Class Initialized
DEBUG - 2016-11-21 10:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:39:13 --> Input Class Initialized
INFO - 2016-11-21 10:39:13 --> Language Class Initialized
INFO - 2016-11-21 10:39:13 --> Loader Class Initialized
INFO - 2016-11-21 10:39:13 --> Helper loaded: url_helper
INFO - 2016-11-21 10:39:13 --> Helper loaded: form_helper
INFO - 2016-11-21 10:39:13 --> Database Driver Class Initialized
INFO - 2016-11-21 10:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:39:13 --> Controller Class Initialized
INFO - 2016-11-21 10:39:13 --> Model Class Initialized
INFO - 2016-11-21 10:39:13 --> Model Class Initialized
INFO - 2016-11-21 10:39:13 --> Model Class Initialized
INFO - 2016-11-21 10:39:13 --> Model Class Initialized
INFO - 2016-11-21 10:39:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:39:13 --> Pagination Class Initialized
INFO - 2016-11-21 10:39:13 --> Helper loaded: app_helper
INFO - 2016-11-21 10:39:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:39:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-21 10:39:13 --> Severity: Warning --> Attempt to assign property of non-object C:\xampp\htdocs\LMS\app\controllers\Auth.php 88
INFO - 2016-11-21 10:39:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:39:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:39:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:39:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:39:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:39:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:39:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:39:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:39:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:39:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:39:13 --> Final output sent to browser
DEBUG - 2016-11-21 10:39:13 --> Total execution time: 0.6119
INFO - 2016-11-21 10:40:14 --> Config Class Initialized
INFO - 2016-11-21 10:40:14 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:40:14 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:40:14 --> Utf8 Class Initialized
INFO - 2016-11-21 10:40:14 --> URI Class Initialized
DEBUG - 2016-11-21 10:40:14 --> No URI present. Default controller set.
INFO - 2016-11-21 10:40:14 --> Router Class Initialized
INFO - 2016-11-21 10:40:14 --> Output Class Initialized
INFO - 2016-11-21 10:40:14 --> Security Class Initialized
DEBUG - 2016-11-21 10:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:40:14 --> Input Class Initialized
INFO - 2016-11-21 10:40:14 --> Language Class Initialized
INFO - 2016-11-21 10:40:14 --> Loader Class Initialized
INFO - 2016-11-21 10:40:14 --> Helper loaded: url_helper
INFO - 2016-11-21 10:40:14 --> Helper loaded: form_helper
INFO - 2016-11-21 10:40:14 --> Database Driver Class Initialized
INFO - 2016-11-21 10:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:40:14 --> Controller Class Initialized
INFO - 2016-11-21 10:40:14 --> Model Class Initialized
INFO - 2016-11-21 10:40:14 --> Model Class Initialized
INFO - 2016-11-21 10:40:14 --> Model Class Initialized
INFO - 2016-11-21 10:40:14 --> Model Class Initialized
INFO - 2016-11-21 10:40:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:40:14 --> Pagination Class Initialized
INFO - 2016-11-21 10:40:14 --> Helper loaded: app_helper
INFO - 2016-11-21 10:40:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:40:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:40:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:40:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:40:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:40:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:40:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:40:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:40:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:40:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:40:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:40:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:40:15 --> Final output sent to browser
DEBUG - 2016-11-21 10:40:15 --> Total execution time: 0.6645
INFO - 2016-11-21 10:40:36 --> Config Class Initialized
INFO - 2016-11-21 10:40:36 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:40:36 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:40:36 --> Utf8 Class Initialized
INFO - 2016-11-21 10:40:36 --> URI Class Initialized
DEBUG - 2016-11-21 10:40:36 --> No URI present. Default controller set.
INFO - 2016-11-21 10:40:36 --> Router Class Initialized
INFO - 2016-11-21 10:40:36 --> Output Class Initialized
INFO - 2016-11-21 10:40:36 --> Security Class Initialized
DEBUG - 2016-11-21 10:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:40:36 --> Input Class Initialized
INFO - 2016-11-21 10:40:36 --> Language Class Initialized
INFO - 2016-11-21 10:40:36 --> Loader Class Initialized
INFO - 2016-11-21 10:40:36 --> Helper loaded: url_helper
INFO - 2016-11-21 10:40:36 --> Helper loaded: form_helper
INFO - 2016-11-21 10:40:36 --> Database Driver Class Initialized
INFO - 2016-11-21 10:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:40:36 --> Controller Class Initialized
INFO - 2016-11-21 10:40:36 --> Model Class Initialized
INFO - 2016-11-21 10:40:36 --> Model Class Initialized
INFO - 2016-11-21 10:40:36 --> Model Class Initialized
INFO - 2016-11-21 10:40:36 --> Model Class Initialized
INFO - 2016-11-21 10:40:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:40:36 --> Pagination Class Initialized
INFO - 2016-11-21 10:40:36 --> Helper loaded: app_helper
INFO - 2016-11-21 10:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:40:36 --> Final output sent to browser
DEBUG - 2016-11-21 10:40:36 --> Total execution time: 0.5844
INFO - 2016-11-21 10:41:36 --> Config Class Initialized
INFO - 2016-11-21 10:41:36 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:41:36 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:41:36 --> Utf8 Class Initialized
INFO - 2016-11-21 10:41:36 --> URI Class Initialized
DEBUG - 2016-11-21 10:41:36 --> No URI present. Default controller set.
INFO - 2016-11-21 10:41:36 --> Router Class Initialized
INFO - 2016-11-21 10:41:36 --> Output Class Initialized
INFO - 2016-11-21 10:41:36 --> Security Class Initialized
DEBUG - 2016-11-21 10:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:41:36 --> Input Class Initialized
INFO - 2016-11-21 10:41:36 --> Language Class Initialized
INFO - 2016-11-21 10:41:36 --> Loader Class Initialized
INFO - 2016-11-21 10:41:37 --> Helper loaded: url_helper
INFO - 2016-11-21 10:41:37 --> Helper loaded: form_helper
INFO - 2016-11-21 10:41:37 --> Database Driver Class Initialized
INFO - 2016-11-21 10:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:41:37 --> Controller Class Initialized
INFO - 2016-11-21 10:41:37 --> Model Class Initialized
INFO - 2016-11-21 10:41:37 --> Model Class Initialized
INFO - 2016-11-21 10:41:37 --> Model Class Initialized
INFO - 2016-11-21 10:41:37 --> Model Class Initialized
INFO - 2016-11-21 10:41:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:41:37 --> Pagination Class Initialized
INFO - 2016-11-21 10:41:37 --> Helper loaded: app_helper
INFO - 2016-11-21 10:41:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:41:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:41:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:41:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:41:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:41:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:41:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:41:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:41:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:41:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:41:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:41:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:41:37 --> Final output sent to browser
DEBUG - 2016-11-21 10:41:37 --> Total execution time: 0.5618
INFO - 2016-11-21 10:41:51 --> Config Class Initialized
INFO - 2016-11-21 10:41:51 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:41:51 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:41:51 --> Utf8 Class Initialized
INFO - 2016-11-21 10:41:51 --> URI Class Initialized
DEBUG - 2016-11-21 10:41:51 --> No URI present. Default controller set.
INFO - 2016-11-21 10:41:51 --> Router Class Initialized
INFO - 2016-11-21 10:41:51 --> Output Class Initialized
INFO - 2016-11-21 10:41:51 --> Security Class Initialized
DEBUG - 2016-11-21 10:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:41:51 --> Input Class Initialized
INFO - 2016-11-21 10:41:51 --> Language Class Initialized
INFO - 2016-11-21 10:41:51 --> Loader Class Initialized
INFO - 2016-11-21 10:41:51 --> Helper loaded: url_helper
INFO - 2016-11-21 10:41:51 --> Helper loaded: form_helper
INFO - 2016-11-21 10:41:51 --> Database Driver Class Initialized
INFO - 2016-11-21 10:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:41:51 --> Controller Class Initialized
INFO - 2016-11-21 10:41:51 --> Model Class Initialized
INFO - 2016-11-21 10:41:51 --> Model Class Initialized
INFO - 2016-11-21 10:41:51 --> Model Class Initialized
INFO - 2016-11-21 10:41:51 --> Model Class Initialized
INFO - 2016-11-21 10:41:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:41:51 --> Pagination Class Initialized
INFO - 2016-11-21 10:41:51 --> Helper loaded: app_helper
INFO - 2016-11-21 10:41:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:41:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:41:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:41:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:41:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:41:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:41:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:41:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:41:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:41:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:41:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:41:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:41:51 --> Final output sent to browser
DEBUG - 2016-11-21 10:41:51 --> Total execution time: 0.5435
INFO - 2016-11-21 10:42:23 --> Config Class Initialized
INFO - 2016-11-21 10:42:23 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:42:23 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:42:23 --> Utf8 Class Initialized
INFO - 2016-11-21 10:42:23 --> URI Class Initialized
DEBUG - 2016-11-21 10:42:23 --> No URI present. Default controller set.
INFO - 2016-11-21 10:42:23 --> Router Class Initialized
INFO - 2016-11-21 10:42:23 --> Output Class Initialized
INFO - 2016-11-21 10:42:23 --> Security Class Initialized
DEBUG - 2016-11-21 10:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:42:23 --> Input Class Initialized
INFO - 2016-11-21 10:42:23 --> Language Class Initialized
INFO - 2016-11-21 10:42:23 --> Loader Class Initialized
INFO - 2016-11-21 10:42:23 --> Helper loaded: url_helper
INFO - 2016-11-21 10:42:23 --> Helper loaded: form_helper
INFO - 2016-11-21 10:42:23 --> Database Driver Class Initialized
INFO - 2016-11-21 10:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:42:23 --> Controller Class Initialized
INFO - 2016-11-21 10:42:23 --> Model Class Initialized
INFO - 2016-11-21 10:42:23 --> Model Class Initialized
INFO - 2016-11-21 10:42:23 --> Model Class Initialized
INFO - 2016-11-21 10:42:23 --> Model Class Initialized
INFO - 2016-11-21 10:42:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:42:23 --> Pagination Class Initialized
INFO - 2016-11-21 10:42:23 --> Helper loaded: app_helper
INFO - 2016-11-21 10:42:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:42:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:42:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:42:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:42:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:42:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:42:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:42:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:42:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:42:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:42:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:42:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:42:23 --> Final output sent to browser
DEBUG - 2016-11-21 10:42:23 --> Total execution time: 0.5370
INFO - 2016-11-21 10:42:41 --> Config Class Initialized
INFO - 2016-11-21 10:42:41 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:42:41 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:42:41 --> Utf8 Class Initialized
INFO - 2016-11-21 10:42:41 --> URI Class Initialized
INFO - 2016-11-21 10:42:41 --> Router Class Initialized
INFO - 2016-11-21 10:42:41 --> Output Class Initialized
INFO - 2016-11-21 10:42:41 --> Security Class Initialized
DEBUG - 2016-11-21 10:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:42:41 --> Input Class Initialized
INFO - 2016-11-21 10:42:41 --> Language Class Initialized
INFO - 2016-11-21 10:42:41 --> Loader Class Initialized
INFO - 2016-11-21 10:42:41 --> Helper loaded: url_helper
INFO - 2016-11-21 10:42:41 --> Helper loaded: form_helper
INFO - 2016-11-21 10:42:41 --> Database Driver Class Initialized
INFO - 2016-11-21 10:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:42:41 --> Controller Class Initialized
INFO - 2016-11-21 10:42:41 --> Model Class Initialized
INFO - 2016-11-21 10:42:41 --> Form Validation Class Initialized
ERROR - 2016-11-21 10:42:41 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 10:42:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 10:42:41 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 10:42:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 10:42:41 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 10:42:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 10:42:41 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 10:42:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 10:42:41 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 10:42:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 10:42:41 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 10:42:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 10:42:41 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 10:42:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 10:42:41 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 10:42:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 10:42:41 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 10:42:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 10:42:41 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 10:42:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 10:42:41 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 10:42:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 10:42:41 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-11-21 10:42:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:42:41 --> Final output sent to browser
DEBUG - 2016-11-21 10:42:41 --> Total execution time: 0.8805
INFO - 2016-11-21 10:42:42 --> Config Class Initialized
INFO - 2016-11-21 10:42:42 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:42:42 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:42:42 --> Utf8 Class Initialized
INFO - 2016-11-21 10:42:42 --> URI Class Initialized
DEBUG - 2016-11-21 10:42:42 --> No URI present. Default controller set.
INFO - 2016-11-21 10:42:42 --> Router Class Initialized
INFO - 2016-11-21 10:42:42 --> Output Class Initialized
INFO - 2016-11-21 10:42:42 --> Security Class Initialized
DEBUG - 2016-11-21 10:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:42:42 --> Input Class Initialized
INFO - 2016-11-21 10:42:42 --> Language Class Initialized
INFO - 2016-11-21 10:42:42 --> Loader Class Initialized
INFO - 2016-11-21 10:42:42 --> Helper loaded: url_helper
INFO - 2016-11-21 10:42:42 --> Helper loaded: form_helper
INFO - 2016-11-21 10:42:42 --> Database Driver Class Initialized
INFO - 2016-11-21 10:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:42:42 --> Controller Class Initialized
INFO - 2016-11-21 10:42:42 --> Model Class Initialized
INFO - 2016-11-21 10:42:42 --> Model Class Initialized
INFO - 2016-11-21 10:42:42 --> Model Class Initialized
INFO - 2016-11-21 10:42:42 --> Model Class Initialized
INFO - 2016-11-21 10:42:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:42:42 --> Pagination Class Initialized
INFO - 2016-11-21 10:42:42 --> Helper loaded: app_helper
INFO - 2016-11-21 10:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:42:42 --> Final output sent to browser
DEBUG - 2016-11-21 10:42:42 --> Total execution time: 0.7549
INFO - 2016-11-21 10:42:58 --> Config Class Initialized
INFO - 2016-11-21 10:42:58 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:42:58 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:42:58 --> Utf8 Class Initialized
INFO - 2016-11-21 10:42:58 --> URI Class Initialized
DEBUG - 2016-11-21 10:42:58 --> No URI present. Default controller set.
INFO - 2016-11-21 10:42:58 --> Router Class Initialized
INFO - 2016-11-21 10:42:58 --> Output Class Initialized
INFO - 2016-11-21 10:42:58 --> Security Class Initialized
DEBUG - 2016-11-21 10:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:42:58 --> Input Class Initialized
INFO - 2016-11-21 10:42:58 --> Language Class Initialized
INFO - 2016-11-21 10:42:58 --> Loader Class Initialized
INFO - 2016-11-21 10:42:58 --> Helper loaded: url_helper
INFO - 2016-11-21 10:42:58 --> Helper loaded: form_helper
INFO - 2016-11-21 10:42:58 --> Database Driver Class Initialized
INFO - 2016-11-21 10:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:42:58 --> Controller Class Initialized
INFO - 2016-11-21 10:42:58 --> Model Class Initialized
INFO - 2016-11-21 10:42:58 --> Model Class Initialized
INFO - 2016-11-21 10:42:58 --> Model Class Initialized
INFO - 2016-11-21 10:42:58 --> Model Class Initialized
INFO - 2016-11-21 10:42:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:42:58 --> Pagination Class Initialized
INFO - 2016-11-21 10:42:58 --> Helper loaded: app_helper
INFO - 2016-11-21 10:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:42:58 --> Final output sent to browser
DEBUG - 2016-11-21 10:42:59 --> Total execution time: 0.6414
INFO - 2016-11-21 10:43:15 --> Config Class Initialized
INFO - 2016-11-21 10:43:15 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:43:15 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:43:15 --> Utf8 Class Initialized
INFO - 2016-11-21 10:43:15 --> URI Class Initialized
DEBUG - 2016-11-21 10:43:15 --> No URI present. Default controller set.
INFO - 2016-11-21 10:43:15 --> Router Class Initialized
INFO - 2016-11-21 10:43:15 --> Output Class Initialized
INFO - 2016-11-21 10:43:15 --> Security Class Initialized
DEBUG - 2016-11-21 10:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:43:15 --> Input Class Initialized
INFO - 2016-11-21 10:43:15 --> Language Class Initialized
INFO - 2016-11-21 10:43:15 --> Loader Class Initialized
INFO - 2016-11-21 10:43:15 --> Helper loaded: url_helper
INFO - 2016-11-21 10:43:15 --> Helper loaded: form_helper
INFO - 2016-11-21 10:43:15 --> Database Driver Class Initialized
INFO - 2016-11-21 10:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:43:15 --> Controller Class Initialized
INFO - 2016-11-21 10:43:15 --> Model Class Initialized
INFO - 2016-11-21 10:43:15 --> Model Class Initialized
INFO - 2016-11-21 10:43:15 --> Model Class Initialized
INFO - 2016-11-21 10:43:15 --> Model Class Initialized
INFO - 2016-11-21 10:43:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:43:15 --> Pagination Class Initialized
INFO - 2016-11-21 10:43:15 --> Helper loaded: app_helper
INFO - 2016-11-21 10:43:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:43:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:43:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:43:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:43:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:43:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:43:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:43:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:43:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:43:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:43:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:43:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:43:16 --> Final output sent to browser
DEBUG - 2016-11-21 10:43:16 --> Total execution time: 0.6444
INFO - 2016-11-21 10:43:37 --> Config Class Initialized
INFO - 2016-11-21 10:43:37 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:43:37 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:43:37 --> Utf8 Class Initialized
INFO - 2016-11-21 10:43:37 --> URI Class Initialized
DEBUG - 2016-11-21 10:43:37 --> No URI present. Default controller set.
INFO - 2016-11-21 10:43:37 --> Router Class Initialized
INFO - 2016-11-21 10:43:37 --> Output Class Initialized
INFO - 2016-11-21 10:43:37 --> Security Class Initialized
DEBUG - 2016-11-21 10:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:43:37 --> Input Class Initialized
INFO - 2016-11-21 10:43:37 --> Language Class Initialized
INFO - 2016-11-21 10:43:37 --> Loader Class Initialized
INFO - 2016-11-21 10:43:37 --> Helper loaded: url_helper
INFO - 2016-11-21 10:43:37 --> Helper loaded: form_helper
INFO - 2016-11-21 10:43:37 --> Database Driver Class Initialized
INFO - 2016-11-21 10:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:43:37 --> Controller Class Initialized
INFO - 2016-11-21 10:43:37 --> Model Class Initialized
INFO - 2016-11-21 10:43:37 --> Model Class Initialized
INFO - 2016-11-21 10:43:37 --> Model Class Initialized
INFO - 2016-11-21 10:43:37 --> Model Class Initialized
INFO - 2016-11-21 10:43:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:43:37 --> Pagination Class Initialized
INFO - 2016-11-21 10:43:37 --> Helper loaded: app_helper
INFO - 2016-11-21 10:43:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:43:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:43:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:43:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:43:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:43:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:43:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:43:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:43:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:43:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:43:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:43:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:43:38 --> Final output sent to browser
DEBUG - 2016-11-21 10:43:38 --> Total execution time: 0.5969
INFO - 2016-11-21 10:43:53 --> Config Class Initialized
INFO - 2016-11-21 10:43:53 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:43:53 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:43:53 --> Utf8 Class Initialized
INFO - 2016-11-21 10:43:53 --> URI Class Initialized
DEBUG - 2016-11-21 10:43:53 --> No URI present. Default controller set.
INFO - 2016-11-21 10:43:53 --> Router Class Initialized
INFO - 2016-11-21 10:43:53 --> Output Class Initialized
INFO - 2016-11-21 10:43:53 --> Security Class Initialized
DEBUG - 2016-11-21 10:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:43:53 --> Input Class Initialized
INFO - 2016-11-21 10:43:53 --> Language Class Initialized
INFO - 2016-11-21 10:43:53 --> Loader Class Initialized
INFO - 2016-11-21 10:43:53 --> Helper loaded: url_helper
INFO - 2016-11-21 10:43:53 --> Helper loaded: form_helper
INFO - 2016-11-21 10:43:53 --> Database Driver Class Initialized
INFO - 2016-11-21 10:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:43:53 --> Controller Class Initialized
INFO - 2016-11-21 10:43:53 --> Model Class Initialized
INFO - 2016-11-21 10:43:53 --> Model Class Initialized
INFO - 2016-11-21 10:43:53 --> Model Class Initialized
INFO - 2016-11-21 10:43:53 --> Model Class Initialized
INFO - 2016-11-21 10:43:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:43:53 --> Pagination Class Initialized
INFO - 2016-11-21 10:43:54 --> Helper loaded: app_helper
INFO - 2016-11-21 10:43:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:43:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:43:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:43:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:43:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:43:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:43:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:43:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:43:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:43:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:43:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:43:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:43:54 --> Final output sent to browser
DEBUG - 2016-11-21 10:43:54 --> Total execution time: 0.5893
INFO - 2016-11-21 10:44:06 --> Config Class Initialized
INFO - 2016-11-21 10:44:06 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:44:06 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:44:06 --> Utf8 Class Initialized
INFO - 2016-11-21 10:44:06 --> URI Class Initialized
INFO - 2016-11-21 10:44:06 --> Router Class Initialized
INFO - 2016-11-21 10:44:06 --> Output Class Initialized
INFO - 2016-11-21 10:44:06 --> Security Class Initialized
DEBUG - 2016-11-21 10:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:44:06 --> Input Class Initialized
INFO - 2016-11-21 10:44:06 --> Language Class Initialized
INFO - 2016-11-21 10:44:06 --> Loader Class Initialized
INFO - 2016-11-21 10:44:06 --> Helper loaded: url_helper
INFO - 2016-11-21 10:44:06 --> Helper loaded: form_helper
INFO - 2016-11-21 10:44:06 --> Database Driver Class Initialized
INFO - 2016-11-21 10:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:44:06 --> Controller Class Initialized
INFO - 2016-11-21 10:44:06 --> Model Class Initialized
INFO - 2016-11-21 10:44:06 --> Form Validation Class Initialized
INFO - 2016-11-21 10:44:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 10:44:07 --> Final output sent to browser
DEBUG - 2016-11-21 10:44:07 --> Total execution time: 0.4306
INFO - 2016-11-21 10:44:11 --> Config Class Initialized
INFO - 2016-11-21 10:44:11 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:44:11 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:44:11 --> Utf8 Class Initialized
INFO - 2016-11-21 10:44:11 --> URI Class Initialized
DEBUG - 2016-11-21 10:44:11 --> No URI present. Default controller set.
INFO - 2016-11-21 10:44:11 --> Router Class Initialized
INFO - 2016-11-21 10:44:11 --> Output Class Initialized
INFO - 2016-11-21 10:44:11 --> Security Class Initialized
DEBUG - 2016-11-21 10:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:44:11 --> Input Class Initialized
INFO - 2016-11-21 10:44:11 --> Language Class Initialized
INFO - 2016-11-21 10:44:11 --> Loader Class Initialized
INFO - 2016-11-21 10:44:12 --> Helper loaded: url_helper
INFO - 2016-11-21 10:44:12 --> Helper loaded: form_helper
INFO - 2016-11-21 10:44:12 --> Database Driver Class Initialized
INFO - 2016-11-21 10:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:44:12 --> Controller Class Initialized
INFO - 2016-11-21 10:44:12 --> Model Class Initialized
INFO - 2016-11-21 10:44:12 --> Model Class Initialized
INFO - 2016-11-21 10:44:12 --> Model Class Initialized
INFO - 2016-11-21 10:44:12 --> Model Class Initialized
INFO - 2016-11-21 10:44:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:44:12 --> Pagination Class Initialized
INFO - 2016-11-21 10:44:12 --> Helper loaded: app_helper
INFO - 2016-11-21 10:44:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:44:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:44:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:44:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:44:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:44:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:44:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:44:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:44:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:44:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:44:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:44:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:44:12 --> Final output sent to browser
DEBUG - 2016-11-21 10:44:12 --> Total execution time: 0.6272
INFO - 2016-11-21 10:44:24 --> Config Class Initialized
INFO - 2016-11-21 10:44:24 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:44:24 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:44:24 --> Utf8 Class Initialized
INFO - 2016-11-21 10:44:24 --> URI Class Initialized
DEBUG - 2016-11-21 10:44:24 --> No URI present. Default controller set.
INFO - 2016-11-21 10:44:24 --> Router Class Initialized
INFO - 2016-11-21 10:44:24 --> Output Class Initialized
INFO - 2016-11-21 10:44:24 --> Security Class Initialized
DEBUG - 2016-11-21 10:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:44:24 --> Input Class Initialized
INFO - 2016-11-21 10:44:24 --> Language Class Initialized
INFO - 2016-11-21 10:44:24 --> Loader Class Initialized
INFO - 2016-11-21 10:44:24 --> Helper loaded: url_helper
INFO - 2016-11-21 10:44:24 --> Helper loaded: form_helper
INFO - 2016-11-21 10:44:24 --> Database Driver Class Initialized
INFO - 2016-11-21 10:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:44:24 --> Controller Class Initialized
INFO - 2016-11-21 10:44:24 --> Model Class Initialized
INFO - 2016-11-21 10:44:24 --> Model Class Initialized
INFO - 2016-11-21 10:44:25 --> Model Class Initialized
INFO - 2016-11-21 10:44:25 --> Model Class Initialized
INFO - 2016-11-21 10:44:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:44:25 --> Pagination Class Initialized
INFO - 2016-11-21 10:44:25 --> Helper loaded: app_helper
INFO - 2016-11-21 10:44:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:44:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:44:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:44:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:44:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:44:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:44:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:44:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:44:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:44:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:44:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:44:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:44:25 --> Final output sent to browser
DEBUG - 2016-11-21 10:44:25 --> Total execution time: 0.7667
INFO - 2016-11-21 10:44:40 --> Config Class Initialized
INFO - 2016-11-21 10:44:40 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:44:40 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:44:40 --> Utf8 Class Initialized
INFO - 2016-11-21 10:44:40 --> URI Class Initialized
INFO - 2016-11-21 10:44:40 --> Router Class Initialized
INFO - 2016-11-21 10:44:40 --> Output Class Initialized
INFO - 2016-11-21 10:44:40 --> Security Class Initialized
DEBUG - 2016-11-21 10:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:44:40 --> Input Class Initialized
INFO - 2016-11-21 10:44:40 --> Language Class Initialized
INFO - 2016-11-21 10:44:40 --> Loader Class Initialized
INFO - 2016-11-21 10:44:40 --> Helper loaded: url_helper
INFO - 2016-11-21 10:44:40 --> Helper loaded: form_helper
INFO - 2016-11-21 10:44:40 --> Database Driver Class Initialized
INFO - 2016-11-21 10:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:44:40 --> Controller Class Initialized
INFO - 2016-11-21 10:44:40 --> Model Class Initialized
INFO - 2016-11-21 10:44:40 --> Form Validation Class Initialized
INFO - 2016-11-21 10:44:40 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 10:44:41 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 85
ERROR - 2016-11-21 10:44:41 --> Severity: Notice --> Undefined variable: userName C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 85
ERROR - 2016-11-21 10:44:41 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
ERROR - 2016-11-21 10:44:41 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 10:44:41 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 10:44:41 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 147
ERROR - 2016-11-21 10:44:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\LMS\sys\core\Exceptions.php:272) C:\xampp\htdocs\LMS\sys\core\Common.php 573
ERROR - 2016-11-21 10:44:41 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 147
INFO - 2016-11-21 10:45:02 --> Config Class Initialized
INFO - 2016-11-21 10:45:02 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:45:02 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:45:02 --> Utf8 Class Initialized
INFO - 2016-11-21 10:45:02 --> URI Class Initialized
DEBUG - 2016-11-21 10:45:02 --> No URI present. Default controller set.
INFO - 2016-11-21 10:45:02 --> Router Class Initialized
INFO - 2016-11-21 10:45:02 --> Output Class Initialized
INFO - 2016-11-21 10:45:02 --> Security Class Initialized
DEBUG - 2016-11-21 10:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:45:02 --> Input Class Initialized
INFO - 2016-11-21 10:45:02 --> Language Class Initialized
INFO - 2016-11-21 10:45:02 --> Loader Class Initialized
INFO - 2016-11-21 10:45:02 --> Helper loaded: url_helper
INFO - 2016-11-21 10:45:02 --> Helper loaded: form_helper
INFO - 2016-11-21 10:45:02 --> Database Driver Class Initialized
INFO - 2016-11-21 10:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:45:02 --> Controller Class Initialized
INFO - 2016-11-21 10:45:02 --> Model Class Initialized
INFO - 2016-11-21 10:45:02 --> Model Class Initialized
INFO - 2016-11-21 10:45:02 --> Model Class Initialized
INFO - 2016-11-21 10:45:02 --> Model Class Initialized
INFO - 2016-11-21 10:45:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:45:02 --> Pagination Class Initialized
INFO - 2016-11-21 10:45:02 --> Helper loaded: app_helper
INFO - 2016-11-21 10:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:45:02 --> Final output sent to browser
DEBUG - 2016-11-21 10:45:02 --> Total execution time: 0.6709
INFO - 2016-11-21 10:45:15 --> Config Class Initialized
INFO - 2016-11-21 10:45:15 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:45:15 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:45:15 --> Utf8 Class Initialized
INFO - 2016-11-21 10:45:15 --> URI Class Initialized
INFO - 2016-11-21 10:45:16 --> Router Class Initialized
INFO - 2016-11-21 10:45:16 --> Output Class Initialized
INFO - 2016-11-21 10:45:16 --> Security Class Initialized
DEBUG - 2016-11-21 10:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:45:16 --> Input Class Initialized
INFO - 2016-11-21 10:45:16 --> Language Class Initialized
INFO - 2016-11-21 10:45:16 --> Loader Class Initialized
INFO - 2016-11-21 10:45:16 --> Helper loaded: url_helper
INFO - 2016-11-21 10:45:16 --> Helper loaded: form_helper
INFO - 2016-11-21 10:45:16 --> Database Driver Class Initialized
INFO - 2016-11-21 10:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:45:16 --> Controller Class Initialized
INFO - 2016-11-21 10:45:16 --> Model Class Initialized
INFO - 2016-11-21 10:45:16 --> Form Validation Class Initialized
INFO - 2016-11-21 10:45:16 --> Final output sent to browser
DEBUG - 2016-11-21 10:45:16 --> Total execution time: 0.3628
INFO - 2016-11-21 10:45:27 --> Config Class Initialized
INFO - 2016-11-21 10:45:27 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:45:27 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:45:27 --> Utf8 Class Initialized
INFO - 2016-11-21 10:45:27 --> URI Class Initialized
DEBUG - 2016-11-21 10:45:27 --> No URI present. Default controller set.
INFO - 2016-11-21 10:45:27 --> Router Class Initialized
INFO - 2016-11-21 10:45:27 --> Output Class Initialized
INFO - 2016-11-21 10:45:27 --> Security Class Initialized
DEBUG - 2016-11-21 10:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:45:27 --> Input Class Initialized
INFO - 2016-11-21 10:45:27 --> Language Class Initialized
INFO - 2016-11-21 10:45:27 --> Loader Class Initialized
INFO - 2016-11-21 10:45:27 --> Helper loaded: url_helper
INFO - 2016-11-21 10:45:27 --> Helper loaded: form_helper
INFO - 2016-11-21 10:45:27 --> Database Driver Class Initialized
INFO - 2016-11-21 10:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:45:27 --> Controller Class Initialized
INFO - 2016-11-21 10:45:27 --> Model Class Initialized
INFO - 2016-11-21 10:45:27 --> Model Class Initialized
INFO - 2016-11-21 10:45:27 --> Model Class Initialized
INFO - 2016-11-21 10:45:27 --> Model Class Initialized
INFO - 2016-11-21 10:45:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:45:27 --> Pagination Class Initialized
INFO - 2016-11-21 10:45:27 --> Helper loaded: app_helper
INFO - 2016-11-21 10:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:45:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:45:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:45:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:45:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:45:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:45:28 --> Final output sent to browser
DEBUG - 2016-11-21 10:45:28 --> Total execution time: 0.6766
INFO - 2016-11-21 10:45:53 --> Config Class Initialized
INFO - 2016-11-21 10:45:53 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:45:53 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:45:53 --> Utf8 Class Initialized
INFO - 2016-11-21 10:45:53 --> URI Class Initialized
DEBUG - 2016-11-21 10:45:53 --> No URI present. Default controller set.
INFO - 2016-11-21 10:45:53 --> Router Class Initialized
INFO - 2016-11-21 10:45:53 --> Output Class Initialized
INFO - 2016-11-21 10:45:53 --> Security Class Initialized
DEBUG - 2016-11-21 10:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:45:53 --> Input Class Initialized
INFO - 2016-11-21 10:45:53 --> Language Class Initialized
INFO - 2016-11-21 10:45:53 --> Loader Class Initialized
INFO - 2016-11-21 10:45:53 --> Helper loaded: url_helper
INFO - 2016-11-21 10:45:53 --> Helper loaded: form_helper
INFO - 2016-11-21 10:45:54 --> Database Driver Class Initialized
INFO - 2016-11-21 10:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:45:54 --> Controller Class Initialized
INFO - 2016-11-21 10:45:54 --> Model Class Initialized
INFO - 2016-11-21 10:45:54 --> Model Class Initialized
INFO - 2016-11-21 10:45:54 --> Model Class Initialized
INFO - 2016-11-21 10:45:54 --> Model Class Initialized
INFO - 2016-11-21 10:45:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:45:54 --> Pagination Class Initialized
INFO - 2016-11-21 10:45:54 --> Helper loaded: app_helper
INFO - 2016-11-21 10:45:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:45:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:45:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:45:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:45:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:45:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:45:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:45:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:45:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:45:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:45:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:45:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:45:54 --> Final output sent to browser
DEBUG - 2016-11-21 10:45:54 --> Total execution time: 0.7235
INFO - 2016-11-21 10:46:22 --> Config Class Initialized
INFO - 2016-11-21 10:46:22 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:46:22 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:46:22 --> Utf8 Class Initialized
INFO - 2016-11-21 10:46:22 --> URI Class Initialized
DEBUG - 2016-11-21 10:46:22 --> No URI present. Default controller set.
INFO - 2016-11-21 10:46:22 --> Router Class Initialized
INFO - 2016-11-21 10:46:22 --> Output Class Initialized
INFO - 2016-11-21 10:46:22 --> Security Class Initialized
DEBUG - 2016-11-21 10:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:46:22 --> Input Class Initialized
INFO - 2016-11-21 10:46:22 --> Language Class Initialized
INFO - 2016-11-21 10:46:22 --> Loader Class Initialized
INFO - 2016-11-21 10:46:22 --> Helper loaded: url_helper
INFO - 2016-11-21 10:46:22 --> Helper loaded: form_helper
INFO - 2016-11-21 10:46:22 --> Database Driver Class Initialized
INFO - 2016-11-21 10:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:46:22 --> Controller Class Initialized
INFO - 2016-11-21 10:46:22 --> Model Class Initialized
INFO - 2016-11-21 10:46:22 --> Model Class Initialized
INFO - 2016-11-21 10:46:22 --> Model Class Initialized
INFO - 2016-11-21 10:46:22 --> Model Class Initialized
INFO - 2016-11-21 10:46:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:46:22 --> Pagination Class Initialized
INFO - 2016-11-21 10:46:22 --> Helper loaded: app_helper
INFO - 2016-11-21 10:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:46:22 --> Final output sent to browser
DEBUG - 2016-11-21 10:46:22 --> Total execution time: 0.6241
INFO - 2016-11-21 10:46:27 --> Config Class Initialized
INFO - 2016-11-21 10:46:27 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:46:27 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:46:27 --> Utf8 Class Initialized
INFO - 2016-11-21 10:46:27 --> URI Class Initialized
INFO - 2016-11-21 10:46:27 --> Router Class Initialized
INFO - 2016-11-21 10:46:27 --> Output Class Initialized
INFO - 2016-11-21 10:46:27 --> Security Class Initialized
DEBUG - 2016-11-21 10:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:46:27 --> Input Class Initialized
INFO - 2016-11-21 10:46:27 --> Language Class Initialized
INFO - 2016-11-21 10:46:27 --> Loader Class Initialized
INFO - 2016-11-21 10:46:27 --> Helper loaded: url_helper
INFO - 2016-11-21 10:46:27 --> Helper loaded: form_helper
INFO - 2016-11-21 10:46:27 --> Database Driver Class Initialized
INFO - 2016-11-21 10:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:46:27 --> Controller Class Initialized
INFO - 2016-11-21 10:46:27 --> Model Class Initialized
INFO - 2016-11-21 10:46:27 --> Model Class Initialized
INFO - 2016-11-21 10:46:27 --> Model Class Initialized
INFO - 2016-11-21 10:46:27 --> Model Class Initialized
INFO - 2016-11-21 10:46:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:46:27 --> Pagination Class Initialized
INFO - 2016-11-21 10:46:27 --> Helper loaded: app_helper
INFO - 2016-11-21 10:46:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:46:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:46:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:46:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:46:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:46:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:46:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:46:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:46:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:46:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:46:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:46:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:46:28 --> Final output sent to browser
DEBUG - 2016-11-21 10:46:28 --> Total execution time: 0.6080
INFO - 2016-11-21 10:47:08 --> Config Class Initialized
INFO - 2016-11-21 10:47:08 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:47:08 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:47:08 --> Utf8 Class Initialized
INFO - 2016-11-21 10:47:08 --> URI Class Initialized
DEBUG - 2016-11-21 10:47:08 --> No URI present. Default controller set.
INFO - 2016-11-21 10:47:08 --> Router Class Initialized
INFO - 2016-11-21 10:47:08 --> Output Class Initialized
INFO - 2016-11-21 10:47:08 --> Security Class Initialized
DEBUG - 2016-11-21 10:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:47:08 --> Input Class Initialized
INFO - 2016-11-21 10:47:08 --> Language Class Initialized
INFO - 2016-11-21 10:47:08 --> Loader Class Initialized
INFO - 2016-11-21 10:47:08 --> Helper loaded: url_helper
INFO - 2016-11-21 10:47:08 --> Helper loaded: form_helper
INFO - 2016-11-21 10:47:08 --> Database Driver Class Initialized
INFO - 2016-11-21 10:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:47:08 --> Controller Class Initialized
INFO - 2016-11-21 10:47:08 --> Model Class Initialized
INFO - 2016-11-21 10:47:09 --> Model Class Initialized
INFO - 2016-11-21 10:47:09 --> Model Class Initialized
INFO - 2016-11-21 10:47:09 --> Model Class Initialized
INFO - 2016-11-21 10:47:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:47:09 --> Pagination Class Initialized
INFO - 2016-11-21 10:47:09 --> Helper loaded: app_helper
INFO - 2016-11-21 10:47:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:47:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:47:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:47:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:47:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:47:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:47:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:47:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:47:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:47:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:47:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:47:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:47:09 --> Final output sent to browser
DEBUG - 2016-11-21 10:47:09 --> Total execution time: 0.6197
INFO - 2016-11-21 10:48:39 --> Config Class Initialized
INFO - 2016-11-21 10:48:39 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:48:39 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:48:39 --> Utf8 Class Initialized
INFO - 2016-11-21 10:48:39 --> URI Class Initialized
INFO - 2016-11-21 10:48:39 --> Router Class Initialized
INFO - 2016-11-21 10:48:39 --> Output Class Initialized
INFO - 2016-11-21 10:48:39 --> Security Class Initialized
DEBUG - 2016-11-21 10:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:48:39 --> Input Class Initialized
INFO - 2016-11-21 10:48:39 --> Language Class Initialized
INFO - 2016-11-21 10:48:39 --> Loader Class Initialized
INFO - 2016-11-21 10:48:39 --> Helper loaded: url_helper
INFO - 2016-11-21 10:48:39 --> Helper loaded: form_helper
INFO - 2016-11-21 10:48:39 --> Database Driver Class Initialized
INFO - 2016-11-21 10:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:48:39 --> Controller Class Initialized
INFO - 2016-11-21 10:48:39 --> Model Class Initialized
INFO - 2016-11-21 10:48:39 --> Form Validation Class Initialized
INFO - 2016-11-21 10:48:39 --> Final output sent to browser
DEBUG - 2016-11-21 10:48:39 --> Total execution time: 0.3653
INFO - 2016-11-21 10:49:53 --> Config Class Initialized
INFO - 2016-11-21 10:49:53 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:49:53 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:49:53 --> Utf8 Class Initialized
INFO - 2016-11-21 10:49:53 --> URI Class Initialized
DEBUG - 2016-11-21 10:49:54 --> No URI present. Default controller set.
INFO - 2016-11-21 10:49:54 --> Router Class Initialized
INFO - 2016-11-21 10:49:54 --> Output Class Initialized
INFO - 2016-11-21 10:49:54 --> Security Class Initialized
DEBUG - 2016-11-21 10:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:49:54 --> Input Class Initialized
INFO - 2016-11-21 10:49:54 --> Language Class Initialized
INFO - 2016-11-21 10:49:54 --> Loader Class Initialized
INFO - 2016-11-21 10:49:54 --> Helper loaded: url_helper
INFO - 2016-11-21 10:49:54 --> Helper loaded: form_helper
INFO - 2016-11-21 10:49:54 --> Database Driver Class Initialized
INFO - 2016-11-21 10:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:49:54 --> Controller Class Initialized
INFO - 2016-11-21 10:49:54 --> Model Class Initialized
INFO - 2016-11-21 10:49:54 --> Model Class Initialized
INFO - 2016-11-21 10:49:54 --> Model Class Initialized
INFO - 2016-11-21 10:49:54 --> Model Class Initialized
INFO - 2016-11-21 10:49:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:49:54 --> Pagination Class Initialized
INFO - 2016-11-21 10:49:54 --> Helper loaded: app_helper
INFO - 2016-11-21 10:49:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:49:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:49:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:49:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:49:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:49:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:49:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:49:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:49:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:49:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:49:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:49:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:49:54 --> Final output sent to browser
DEBUG - 2016-11-21 10:49:54 --> Total execution time: 0.6685
INFO - 2016-11-21 10:52:26 --> Config Class Initialized
INFO - 2016-11-21 10:52:26 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:52:26 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:52:26 --> Utf8 Class Initialized
INFO - 2016-11-21 10:52:26 --> URI Class Initialized
INFO - 2016-11-21 10:52:26 --> Router Class Initialized
INFO - 2016-11-21 10:52:26 --> Output Class Initialized
INFO - 2016-11-21 10:52:26 --> Security Class Initialized
DEBUG - 2016-11-21 10:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:52:26 --> Input Class Initialized
INFO - 2016-11-21 10:52:27 --> Language Class Initialized
INFO - 2016-11-21 10:52:27 --> Loader Class Initialized
INFO - 2016-11-21 10:52:27 --> Helper loaded: url_helper
INFO - 2016-11-21 10:52:27 --> Helper loaded: form_helper
INFO - 2016-11-21 10:52:27 --> Database Driver Class Initialized
INFO - 2016-11-21 10:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:52:27 --> Controller Class Initialized
INFO - 2016-11-21 10:52:27 --> Model Class Initialized
INFO - 2016-11-21 10:52:27 --> Form Validation Class Initialized
INFO - 2016-11-21 10:52:27 --> Final output sent to browser
DEBUG - 2016-11-21 10:52:27 --> Total execution time: 0.3665
INFO - 2016-11-21 10:52:30 --> Config Class Initialized
INFO - 2016-11-21 10:52:30 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:52:30 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:52:30 --> Utf8 Class Initialized
INFO - 2016-11-21 10:52:30 --> URI Class Initialized
DEBUG - 2016-11-21 10:52:30 --> No URI present. Default controller set.
INFO - 2016-11-21 10:52:30 --> Router Class Initialized
INFO - 2016-11-21 10:52:30 --> Output Class Initialized
INFO - 2016-11-21 10:52:30 --> Security Class Initialized
DEBUG - 2016-11-21 10:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:52:30 --> Input Class Initialized
INFO - 2016-11-21 10:52:30 --> Language Class Initialized
INFO - 2016-11-21 10:52:31 --> Loader Class Initialized
INFO - 2016-11-21 10:52:31 --> Helper loaded: url_helper
INFO - 2016-11-21 10:52:31 --> Helper loaded: form_helper
INFO - 2016-11-21 10:52:31 --> Database Driver Class Initialized
INFO - 2016-11-21 10:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:52:31 --> Controller Class Initialized
INFO - 2016-11-21 10:52:31 --> Model Class Initialized
INFO - 2016-11-21 10:52:31 --> Model Class Initialized
INFO - 2016-11-21 10:52:31 --> Model Class Initialized
INFO - 2016-11-21 10:52:31 --> Model Class Initialized
INFO - 2016-11-21 10:52:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:52:31 --> Pagination Class Initialized
INFO - 2016-11-21 10:52:31 --> Helper loaded: app_helper
INFO - 2016-11-21 10:52:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:52:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:52:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:52:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:52:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:52:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:52:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:52:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:52:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:52:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:52:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:52:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:52:31 --> Final output sent to browser
DEBUG - 2016-11-21 10:52:31 --> Total execution time: 0.6831
INFO - 2016-11-21 10:54:08 --> Config Class Initialized
INFO - 2016-11-21 10:54:08 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:54:08 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:54:08 --> Utf8 Class Initialized
INFO - 2016-11-21 10:54:08 --> URI Class Initialized
DEBUG - 2016-11-21 10:54:08 --> No URI present. Default controller set.
INFO - 2016-11-21 10:54:08 --> Router Class Initialized
INFO - 2016-11-21 10:54:08 --> Output Class Initialized
INFO - 2016-11-21 10:54:08 --> Security Class Initialized
DEBUG - 2016-11-21 10:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:54:08 --> Input Class Initialized
INFO - 2016-11-21 10:54:08 --> Language Class Initialized
INFO - 2016-11-21 10:54:08 --> Loader Class Initialized
INFO - 2016-11-21 10:54:08 --> Helper loaded: url_helper
INFO - 2016-11-21 10:54:08 --> Helper loaded: form_helper
INFO - 2016-11-21 10:54:08 --> Database Driver Class Initialized
INFO - 2016-11-21 10:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:54:08 --> Controller Class Initialized
INFO - 2016-11-21 10:54:08 --> Model Class Initialized
INFO - 2016-11-21 10:54:08 --> Model Class Initialized
INFO - 2016-11-21 10:54:08 --> Model Class Initialized
INFO - 2016-11-21 10:54:08 --> Model Class Initialized
INFO - 2016-11-21 10:54:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:54:08 --> Pagination Class Initialized
INFO - 2016-11-21 10:54:08 --> Helper loaded: app_helper
INFO - 2016-11-21 10:54:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:54:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:54:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:54:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:54:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:54:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:54:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:54:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:54:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:54:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:54:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:54:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:54:09 --> Final output sent to browser
DEBUG - 2016-11-21 10:54:09 --> Total execution time: 0.6593
INFO - 2016-11-21 10:59:39 --> Config Class Initialized
INFO - 2016-11-21 10:59:39 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:59:39 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:59:39 --> Utf8 Class Initialized
INFO - 2016-11-21 10:59:39 --> URI Class Initialized
DEBUG - 2016-11-21 10:59:39 --> No URI present. Default controller set.
INFO - 2016-11-21 10:59:39 --> Router Class Initialized
INFO - 2016-11-21 10:59:39 --> Output Class Initialized
INFO - 2016-11-21 10:59:39 --> Security Class Initialized
DEBUG - 2016-11-21 10:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:59:39 --> Input Class Initialized
INFO - 2016-11-21 10:59:39 --> Language Class Initialized
INFO - 2016-11-21 10:59:39 --> Loader Class Initialized
INFO - 2016-11-21 10:59:39 --> Helper loaded: url_helper
INFO - 2016-11-21 10:59:39 --> Helper loaded: form_helper
INFO - 2016-11-21 10:59:39 --> Database Driver Class Initialized
INFO - 2016-11-21 10:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:59:39 --> Controller Class Initialized
INFO - 2016-11-21 10:59:39 --> Model Class Initialized
INFO - 2016-11-21 10:59:39 --> Model Class Initialized
INFO - 2016-11-21 10:59:39 --> Model Class Initialized
INFO - 2016-11-21 10:59:39 --> Model Class Initialized
INFO - 2016-11-21 10:59:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 10:59:39 --> Pagination Class Initialized
INFO - 2016-11-21 10:59:39 --> Helper loaded: app_helper
INFO - 2016-11-21 10:59:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 10:59:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 10:59:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 10:59:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 10:59:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 10:59:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 10:59:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 10:59:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 10:59:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 10:59:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 10:59:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 10:59:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 10:59:39 --> Final output sent to browser
DEBUG - 2016-11-21 10:59:39 --> Total execution time: 0.6522
INFO - 2016-11-21 10:59:44 --> Config Class Initialized
INFO - 2016-11-21 10:59:44 --> Hooks Class Initialized
DEBUG - 2016-11-21 10:59:44 --> UTF-8 Support Enabled
INFO - 2016-11-21 10:59:44 --> Utf8 Class Initialized
INFO - 2016-11-21 10:59:44 --> URI Class Initialized
INFO - 2016-11-21 10:59:44 --> Router Class Initialized
INFO - 2016-11-21 10:59:44 --> Output Class Initialized
INFO - 2016-11-21 10:59:44 --> Security Class Initialized
DEBUG - 2016-11-21 10:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 10:59:44 --> Input Class Initialized
INFO - 2016-11-21 10:59:44 --> Language Class Initialized
INFO - 2016-11-21 10:59:44 --> Loader Class Initialized
INFO - 2016-11-21 10:59:44 --> Helper loaded: url_helper
INFO - 2016-11-21 10:59:44 --> Helper loaded: form_helper
INFO - 2016-11-21 10:59:45 --> Database Driver Class Initialized
INFO - 2016-11-21 10:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 10:59:45 --> Controller Class Initialized
INFO - 2016-11-21 10:59:45 --> Model Class Initialized
INFO - 2016-11-21 10:59:45 --> Form Validation Class Initialized
ERROR - 2016-11-21 10:59:45 --> Severity: Notice --> Undefined variable: subordinate C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 178
ERROR - 2016-11-21 10:59:45 --> Severity: Notice --> Undefined variable: sub_subordinate C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 178
ERROR - 2016-11-21 10:59:45 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 17
ERROR - 2016-11-21 10:59:45 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 17
INFO - 2016-11-21 11:01:19 --> Config Class Initialized
INFO - 2016-11-21 11:01:19 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:01:19 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:01:19 --> Utf8 Class Initialized
INFO - 2016-11-21 11:01:19 --> URI Class Initialized
DEBUG - 2016-11-21 11:01:19 --> No URI present. Default controller set.
INFO - 2016-11-21 11:01:19 --> Router Class Initialized
INFO - 2016-11-21 11:01:19 --> Output Class Initialized
INFO - 2016-11-21 11:01:19 --> Security Class Initialized
DEBUG - 2016-11-21 11:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:01:19 --> Input Class Initialized
INFO - 2016-11-21 11:01:19 --> Language Class Initialized
INFO - 2016-11-21 11:01:19 --> Loader Class Initialized
INFO - 2016-11-21 11:01:19 --> Helper loaded: url_helper
INFO - 2016-11-21 11:01:19 --> Helper loaded: form_helper
INFO - 2016-11-21 11:01:19 --> Database Driver Class Initialized
INFO - 2016-11-21 11:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:01:19 --> Controller Class Initialized
INFO - 2016-11-21 11:01:19 --> Model Class Initialized
INFO - 2016-11-21 11:01:19 --> Model Class Initialized
INFO - 2016-11-21 11:01:19 --> Model Class Initialized
INFO - 2016-11-21 11:01:19 --> Model Class Initialized
INFO - 2016-11-21 11:01:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:01:19 --> Pagination Class Initialized
INFO - 2016-11-21 11:01:19 --> Helper loaded: app_helper
INFO - 2016-11-21 11:01:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 11:01:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 11:01:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 11:01:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 11:01:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 11:01:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 11:01:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:01:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 11:01:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 11:01:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 11:01:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 11:01:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 11:01:19 --> Final output sent to browser
DEBUG - 2016-11-21 11:01:20 --> Total execution time: 0.7100
INFO - 2016-11-21 11:01:23 --> Config Class Initialized
INFO - 2016-11-21 11:01:23 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:01:23 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:01:24 --> Utf8 Class Initialized
INFO - 2016-11-21 11:01:24 --> URI Class Initialized
INFO - 2016-11-21 11:01:24 --> Router Class Initialized
INFO - 2016-11-21 11:01:24 --> Output Class Initialized
INFO - 2016-11-21 11:01:24 --> Security Class Initialized
DEBUG - 2016-11-21 11:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:01:24 --> Input Class Initialized
INFO - 2016-11-21 11:01:24 --> Language Class Initialized
INFO - 2016-11-21 11:01:24 --> Loader Class Initialized
INFO - 2016-11-21 11:01:24 --> Helper loaded: url_helper
INFO - 2016-11-21 11:01:24 --> Helper loaded: form_helper
INFO - 2016-11-21 11:01:24 --> Database Driver Class Initialized
INFO - 2016-11-21 11:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:01:24 --> Controller Class Initialized
INFO - 2016-11-21 11:01:24 --> Model Class Initialized
INFO - 2016-11-21 11:01:24 --> Form Validation Class Initialized
ERROR - 2016-11-21 11:01:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 183
ERROR - 2016-11-21 11:01:24 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 17
ERROR - 2016-11-21 11:01:24 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 17
INFO - 2016-11-21 11:01:48 --> Config Class Initialized
INFO - 2016-11-21 11:01:48 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:01:48 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:01:48 --> Utf8 Class Initialized
INFO - 2016-11-21 11:01:48 --> URI Class Initialized
DEBUG - 2016-11-21 11:01:48 --> No URI present. Default controller set.
INFO - 2016-11-21 11:01:48 --> Router Class Initialized
INFO - 2016-11-21 11:01:48 --> Output Class Initialized
INFO - 2016-11-21 11:01:48 --> Security Class Initialized
DEBUG - 2016-11-21 11:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:01:48 --> Input Class Initialized
INFO - 2016-11-21 11:01:48 --> Language Class Initialized
INFO - 2016-11-21 11:01:48 --> Loader Class Initialized
INFO - 2016-11-21 11:01:48 --> Helper loaded: url_helper
INFO - 2016-11-21 11:01:48 --> Helper loaded: form_helper
INFO - 2016-11-21 11:01:48 --> Database Driver Class Initialized
INFO - 2016-11-21 11:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:01:48 --> Controller Class Initialized
INFO - 2016-11-21 11:01:48 --> Model Class Initialized
INFO - 2016-11-21 11:01:48 --> Model Class Initialized
INFO - 2016-11-21 11:01:48 --> Model Class Initialized
INFO - 2016-11-21 11:01:48 --> Model Class Initialized
INFO - 2016-11-21 11:01:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:01:48 --> Pagination Class Initialized
INFO - 2016-11-21 11:01:48 --> Helper loaded: app_helper
INFO - 2016-11-21 11:01:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 11:01:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 11:01:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 11:01:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 11:01:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 11:01:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 11:01:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:01:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 11:01:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 11:01:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 11:01:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 11:01:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 11:01:48 --> Final output sent to browser
DEBUG - 2016-11-21 11:01:48 --> Total execution time: 0.6906
INFO - 2016-11-21 11:01:53 --> Config Class Initialized
INFO - 2016-11-21 11:01:53 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:01:53 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:01:53 --> Utf8 Class Initialized
INFO - 2016-11-21 11:01:53 --> URI Class Initialized
INFO - 2016-11-21 11:01:53 --> Router Class Initialized
INFO - 2016-11-21 11:01:53 --> Output Class Initialized
INFO - 2016-11-21 11:01:53 --> Security Class Initialized
DEBUG - 2016-11-21 11:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:01:53 --> Input Class Initialized
INFO - 2016-11-21 11:01:53 --> Language Class Initialized
INFO - 2016-11-21 11:01:53 --> Loader Class Initialized
INFO - 2016-11-21 11:01:53 --> Helper loaded: url_helper
INFO - 2016-11-21 11:01:53 --> Helper loaded: form_helper
INFO - 2016-11-21 11:01:53 --> Database Driver Class Initialized
INFO - 2016-11-21 11:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:01:53 --> Controller Class Initialized
INFO - 2016-11-21 11:01:53 --> Model Class Initialized
INFO - 2016-11-21 11:01:53 --> Form Validation Class Initialized
ERROR - 2016-11-21 11:01:53 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:01:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:01:53 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-11-21 11:01:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:01:53 --> Final output sent to browser
DEBUG - 2016-11-21 11:01:53 --> Total execution time: 0.4234
INFO - 2016-11-21 11:03:49 --> Config Class Initialized
INFO - 2016-11-21 11:03:49 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:03:49 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:03:49 --> Utf8 Class Initialized
INFO - 2016-11-21 11:03:49 --> URI Class Initialized
DEBUG - 2016-11-21 11:03:49 --> No URI present. Default controller set.
INFO - 2016-11-21 11:03:49 --> Router Class Initialized
INFO - 2016-11-21 11:03:49 --> Output Class Initialized
INFO - 2016-11-21 11:03:49 --> Security Class Initialized
DEBUG - 2016-11-21 11:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:03:49 --> Input Class Initialized
INFO - 2016-11-21 11:03:49 --> Language Class Initialized
INFO - 2016-11-21 11:03:49 --> Loader Class Initialized
INFO - 2016-11-21 11:03:50 --> Helper loaded: url_helper
INFO - 2016-11-21 11:03:50 --> Helper loaded: form_helper
INFO - 2016-11-21 11:03:50 --> Database Driver Class Initialized
INFO - 2016-11-21 11:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:03:50 --> Controller Class Initialized
INFO - 2016-11-21 11:03:50 --> Model Class Initialized
INFO - 2016-11-21 11:03:50 --> Model Class Initialized
INFO - 2016-11-21 11:03:50 --> Model Class Initialized
INFO - 2016-11-21 11:03:50 --> Model Class Initialized
INFO - 2016-11-21 11:03:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:03:50 --> Pagination Class Initialized
INFO - 2016-11-21 11:03:50 --> Helper loaded: app_helper
INFO - 2016-11-21 11:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 11:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 11:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 11:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 11:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 11:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 11:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 11:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 11:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 11:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 11:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 11:03:50 --> Final output sent to browser
DEBUG - 2016-11-21 11:03:50 --> Total execution time: 0.7001
INFO - 2016-11-21 11:04:33 --> Config Class Initialized
INFO - 2016-11-21 11:04:33 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:04:33 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:04:33 --> Utf8 Class Initialized
INFO - 2016-11-21 11:04:33 --> URI Class Initialized
DEBUG - 2016-11-21 11:04:33 --> No URI present. Default controller set.
INFO - 2016-11-21 11:04:33 --> Router Class Initialized
INFO - 2016-11-21 11:04:33 --> Output Class Initialized
INFO - 2016-11-21 11:04:33 --> Security Class Initialized
DEBUG - 2016-11-21 11:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:04:33 --> Input Class Initialized
INFO - 2016-11-21 11:04:33 --> Language Class Initialized
INFO - 2016-11-21 11:04:33 --> Loader Class Initialized
INFO - 2016-11-21 11:04:33 --> Helper loaded: url_helper
INFO - 2016-11-21 11:04:33 --> Helper loaded: form_helper
INFO - 2016-11-21 11:04:33 --> Database Driver Class Initialized
INFO - 2016-11-21 11:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:04:33 --> Controller Class Initialized
INFO - 2016-11-21 11:04:33 --> Model Class Initialized
INFO - 2016-11-21 11:04:33 --> Model Class Initialized
INFO - 2016-11-21 11:04:33 --> Model Class Initialized
INFO - 2016-11-21 11:04:33 --> Model Class Initialized
INFO - 2016-11-21 11:04:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:04:33 --> Pagination Class Initialized
INFO - 2016-11-21 11:04:33 --> Helper loaded: app_helper
INFO - 2016-11-21 11:04:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 11:04:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 11:04:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 11:04:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 11:04:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 11:04:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 11:04:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:04:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 11:04:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 11:04:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 11:04:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 11:04:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 11:04:33 --> Final output sent to browser
DEBUG - 2016-11-21 11:04:34 --> Total execution time: 0.6751
INFO - 2016-11-21 11:04:36 --> Config Class Initialized
INFO - 2016-11-21 11:04:37 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:04:37 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:04:37 --> Utf8 Class Initialized
INFO - 2016-11-21 11:04:37 --> URI Class Initialized
INFO - 2016-11-21 11:04:37 --> Router Class Initialized
INFO - 2016-11-21 11:04:37 --> Output Class Initialized
INFO - 2016-11-21 11:04:37 --> Security Class Initialized
DEBUG - 2016-11-21 11:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:04:37 --> Input Class Initialized
INFO - 2016-11-21 11:04:37 --> Language Class Initialized
INFO - 2016-11-21 11:04:37 --> Loader Class Initialized
INFO - 2016-11-21 11:04:37 --> Helper loaded: url_helper
INFO - 2016-11-21 11:04:37 --> Helper loaded: form_helper
INFO - 2016-11-21 11:04:37 --> Database Driver Class Initialized
INFO - 2016-11-21 11:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:04:37 --> Controller Class Initialized
INFO - 2016-11-21 11:04:37 --> Model Class Initialized
INFO - 2016-11-21 11:04:37 --> Form Validation Class Initialized
ERROR - 2016-11-21 11:04:37 --> Severity: Error --> Call to undefined function ajax_pagination() C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 180
INFO - 2016-11-21 11:05:18 --> Config Class Initialized
INFO - 2016-11-21 11:05:18 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:05:18 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:05:18 --> Utf8 Class Initialized
INFO - 2016-11-21 11:05:18 --> URI Class Initialized
DEBUG - 2016-11-21 11:05:18 --> No URI present. Default controller set.
INFO - 2016-11-21 11:05:18 --> Router Class Initialized
INFO - 2016-11-21 11:05:18 --> Output Class Initialized
INFO - 2016-11-21 11:05:18 --> Security Class Initialized
DEBUG - 2016-11-21 11:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:05:18 --> Input Class Initialized
INFO - 2016-11-21 11:05:19 --> Language Class Initialized
INFO - 2016-11-21 11:05:19 --> Loader Class Initialized
INFO - 2016-11-21 11:05:19 --> Helper loaded: url_helper
INFO - 2016-11-21 11:05:19 --> Helper loaded: form_helper
INFO - 2016-11-21 11:05:19 --> Database Driver Class Initialized
INFO - 2016-11-21 11:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:05:19 --> Controller Class Initialized
INFO - 2016-11-21 11:05:19 --> Model Class Initialized
INFO - 2016-11-21 11:05:19 --> Model Class Initialized
INFO - 2016-11-21 11:05:19 --> Model Class Initialized
INFO - 2016-11-21 11:05:19 --> Model Class Initialized
INFO - 2016-11-21 11:05:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:05:19 --> Pagination Class Initialized
INFO - 2016-11-21 11:05:19 --> Helper loaded: app_helper
INFO - 2016-11-21 11:05:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 11:05:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 11:05:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 11:05:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 11:05:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 11:05:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 11:05:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:05:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 11:05:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 11:05:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 11:05:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 11:05:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 11:05:19 --> Final output sent to browser
DEBUG - 2016-11-21 11:05:19 --> Total execution time: 0.8204
INFO - 2016-11-21 11:05:22 --> Config Class Initialized
INFO - 2016-11-21 11:05:22 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:05:22 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:05:22 --> Utf8 Class Initialized
INFO - 2016-11-21 11:05:22 --> URI Class Initialized
DEBUG - 2016-11-21 11:05:22 --> No URI present. Default controller set.
INFO - 2016-11-21 11:05:22 --> Router Class Initialized
INFO - 2016-11-21 11:05:22 --> Output Class Initialized
INFO - 2016-11-21 11:05:22 --> Security Class Initialized
DEBUG - 2016-11-21 11:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:05:22 --> Input Class Initialized
INFO - 2016-11-21 11:05:22 --> Language Class Initialized
INFO - 2016-11-21 11:05:22 --> Loader Class Initialized
INFO - 2016-11-21 11:05:22 --> Helper loaded: url_helper
INFO - 2016-11-21 11:05:22 --> Helper loaded: form_helper
INFO - 2016-11-21 11:05:22 --> Database Driver Class Initialized
INFO - 2016-11-21 11:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:05:22 --> Controller Class Initialized
INFO - 2016-11-21 11:05:22 --> Model Class Initialized
INFO - 2016-11-21 11:05:22 --> Model Class Initialized
INFO - 2016-11-21 11:05:22 --> Model Class Initialized
INFO - 2016-11-21 11:05:22 --> Model Class Initialized
INFO - 2016-11-21 11:05:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:05:22 --> Pagination Class Initialized
INFO - 2016-11-21 11:05:22 --> Helper loaded: app_helper
INFO - 2016-11-21 11:05:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 11:05:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 11:05:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 11:05:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 11:05:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 11:05:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 11:05:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:05:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 11:05:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 11:05:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 11:05:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 11:05:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 11:05:22 --> Final output sent to browser
DEBUG - 2016-11-21 11:05:22 --> Total execution time: 0.6790
INFO - 2016-11-21 11:05:26 --> Config Class Initialized
INFO - 2016-11-21 11:05:26 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:05:26 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:05:26 --> Utf8 Class Initialized
INFO - 2016-11-21 11:05:26 --> URI Class Initialized
INFO - 2016-11-21 11:05:26 --> Router Class Initialized
INFO - 2016-11-21 11:05:26 --> Output Class Initialized
INFO - 2016-11-21 11:05:26 --> Security Class Initialized
DEBUG - 2016-11-21 11:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:05:26 --> Input Class Initialized
INFO - 2016-11-21 11:05:26 --> Language Class Initialized
INFO - 2016-11-21 11:05:26 --> Loader Class Initialized
INFO - 2016-11-21 11:05:26 --> Helper loaded: url_helper
INFO - 2016-11-21 11:05:26 --> Helper loaded: form_helper
INFO - 2016-11-21 11:05:26 --> Database Driver Class Initialized
INFO - 2016-11-21 11:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:05:26 --> Controller Class Initialized
INFO - 2016-11-21 11:05:26 --> Model Class Initialized
INFO - 2016-11-21 11:05:26 --> Form Validation Class Initialized
ERROR - 2016-11-21 11:05:26 --> Severity: Error --> Call to undefined function ajax_pagination() C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 181
INFO - 2016-11-21 11:06:04 --> Config Class Initialized
INFO - 2016-11-21 11:06:04 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:06:04 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:06:04 --> Utf8 Class Initialized
INFO - 2016-11-21 11:06:04 --> URI Class Initialized
DEBUG - 2016-11-21 11:06:04 --> No URI present. Default controller set.
INFO - 2016-11-21 11:06:04 --> Router Class Initialized
INFO - 2016-11-21 11:06:04 --> Output Class Initialized
INFO - 2016-11-21 11:06:04 --> Security Class Initialized
DEBUG - 2016-11-21 11:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:06:04 --> Input Class Initialized
INFO - 2016-11-21 11:06:04 --> Language Class Initialized
INFO - 2016-11-21 11:06:04 --> Loader Class Initialized
INFO - 2016-11-21 11:06:04 --> Helper loaded: url_helper
INFO - 2016-11-21 11:06:04 --> Helper loaded: form_helper
INFO - 2016-11-21 11:06:04 --> Database Driver Class Initialized
INFO - 2016-11-21 11:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:06:04 --> Controller Class Initialized
INFO - 2016-11-21 11:06:04 --> Model Class Initialized
INFO - 2016-11-21 11:06:04 --> Model Class Initialized
INFO - 2016-11-21 11:06:04 --> Model Class Initialized
INFO - 2016-11-21 11:06:04 --> Model Class Initialized
INFO - 2016-11-21 11:06:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:06:04 --> Pagination Class Initialized
INFO - 2016-11-21 11:06:04 --> Helper loaded: app_helper
INFO - 2016-11-21 11:06:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 11:06:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 11:06:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 11:06:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 11:06:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 11:06:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 11:06:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:06:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 11:06:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 11:06:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 11:06:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 11:06:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 11:06:04 --> Final output sent to browser
DEBUG - 2016-11-21 11:06:05 --> Total execution time: 0.8358
INFO - 2016-11-21 11:06:08 --> Config Class Initialized
INFO - 2016-11-21 11:06:08 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:06:08 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:06:08 --> Utf8 Class Initialized
INFO - 2016-11-21 11:06:08 --> URI Class Initialized
INFO - 2016-11-21 11:06:08 --> Router Class Initialized
INFO - 2016-11-21 11:06:08 --> Output Class Initialized
INFO - 2016-11-21 11:06:08 --> Security Class Initialized
DEBUG - 2016-11-21 11:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:06:08 --> Input Class Initialized
INFO - 2016-11-21 11:06:08 --> Language Class Initialized
INFO - 2016-11-21 11:06:08 --> Loader Class Initialized
INFO - 2016-11-21 11:06:08 --> Helper loaded: url_helper
INFO - 2016-11-21 11:06:08 --> Helper loaded: form_helper
INFO - 2016-11-21 11:06:08 --> Database Driver Class Initialized
INFO - 2016-11-21 11:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:06:08 --> Controller Class Initialized
INFO - 2016-11-21 11:06:08 --> Model Class Initialized
INFO - 2016-11-21 11:06:08 --> Form Validation Class Initialized
INFO - 2016-11-21 11:06:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:06:08 --> Pagination Class Initialized
INFO - 2016-11-21 11:06:08 --> Helper loaded: app_helper
ERROR - 2016-11-21 11:06:08 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:06:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:06:08 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-11-21 11:06:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:06:08 --> Final output sent to browser
DEBUG - 2016-11-21 11:06:09 --> Total execution time: 0.4801
INFO - 2016-11-21 11:06:55 --> Config Class Initialized
INFO - 2016-11-21 11:06:55 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:06:55 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:06:55 --> Utf8 Class Initialized
INFO - 2016-11-21 11:06:55 --> URI Class Initialized
DEBUG - 2016-11-21 11:06:55 --> No URI present. Default controller set.
INFO - 2016-11-21 11:06:55 --> Router Class Initialized
INFO - 2016-11-21 11:06:55 --> Output Class Initialized
INFO - 2016-11-21 11:06:55 --> Security Class Initialized
DEBUG - 2016-11-21 11:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:06:55 --> Input Class Initialized
INFO - 2016-11-21 11:06:55 --> Language Class Initialized
INFO - 2016-11-21 11:06:55 --> Loader Class Initialized
INFO - 2016-11-21 11:06:55 --> Helper loaded: url_helper
INFO - 2016-11-21 11:06:55 --> Helper loaded: form_helper
INFO - 2016-11-21 11:06:55 --> Database Driver Class Initialized
INFO - 2016-11-21 11:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:06:55 --> Controller Class Initialized
INFO - 2016-11-21 11:06:55 --> Model Class Initialized
INFO - 2016-11-21 11:06:55 --> Model Class Initialized
INFO - 2016-11-21 11:06:55 --> Model Class Initialized
INFO - 2016-11-21 11:06:55 --> Model Class Initialized
INFO - 2016-11-21 11:06:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:06:55 --> Pagination Class Initialized
INFO - 2016-11-21 11:06:55 --> Helper loaded: app_helper
INFO - 2016-11-21 11:06:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 11:06:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 11:06:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 11:06:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 11:06:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 11:06:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 11:06:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:06:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 11:06:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 11:06:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 11:06:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 11:06:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 11:06:56 --> Final output sent to browser
DEBUG - 2016-11-21 11:06:56 --> Total execution time: 0.7005
INFO - 2016-11-21 11:07:00 --> Config Class Initialized
INFO - 2016-11-21 11:07:00 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:07:00 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:07:00 --> Utf8 Class Initialized
INFO - 2016-11-21 11:07:00 --> URI Class Initialized
INFO - 2016-11-21 11:07:00 --> Router Class Initialized
INFO - 2016-11-21 11:07:00 --> Output Class Initialized
INFO - 2016-11-21 11:07:00 --> Security Class Initialized
DEBUG - 2016-11-21 11:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:07:00 --> Input Class Initialized
INFO - 2016-11-21 11:07:00 --> Language Class Initialized
INFO - 2016-11-21 11:07:00 --> Loader Class Initialized
INFO - 2016-11-21 11:07:00 --> Helper loaded: url_helper
INFO - 2016-11-21 11:07:00 --> Helper loaded: form_helper
INFO - 2016-11-21 11:07:00 --> Database Driver Class Initialized
INFO - 2016-11-21 11:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:07:00 --> Controller Class Initialized
INFO - 2016-11-21 11:07:00 --> Model Class Initialized
INFO - 2016-11-21 11:07:00 --> Form Validation Class Initialized
INFO - 2016-11-21 11:07:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:07:00 --> Pagination Class Initialized
INFO - 2016-11-21 11:07:00 --> Helper loaded: app_helper
ERROR - 2016-11-21 11:07:00 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 11:07:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:07:00 --> Final output sent to browser
DEBUG - 2016-11-21 11:07:00 --> Total execution time: 0.4687
INFO - 2016-11-21 11:07:02 --> Config Class Initialized
INFO - 2016-11-21 11:07:02 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:07:02 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:07:02 --> Utf8 Class Initialized
INFO - 2016-11-21 11:07:02 --> URI Class Initialized
INFO - 2016-11-21 11:07:02 --> Router Class Initialized
INFO - 2016-11-21 11:07:02 --> Output Class Initialized
INFO - 2016-11-21 11:07:02 --> Security Class Initialized
DEBUG - 2016-11-21 11:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:07:02 --> Input Class Initialized
INFO - 2016-11-21 11:07:02 --> Language Class Initialized
INFO - 2016-11-21 11:07:02 --> Loader Class Initialized
INFO - 2016-11-21 11:07:02 --> Helper loaded: url_helper
INFO - 2016-11-21 11:07:02 --> Helper loaded: form_helper
INFO - 2016-11-21 11:07:02 --> Database Driver Class Initialized
INFO - 2016-11-21 11:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:07:02 --> Controller Class Initialized
INFO - 2016-11-21 11:07:02 --> Model Class Initialized
INFO - 2016-11-21 11:07:02 --> Form Validation Class Initialized
INFO - 2016-11-21 11:07:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:07:02 --> Pagination Class Initialized
INFO - 2016-11-21 11:07:02 --> Helper loaded: app_helper
ERROR - 2016-11-21 11:07:02 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:02 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:02 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:02 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:02 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:02 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:02 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:02 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:02 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 11:07:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:07:03 --> Final output sent to browser
DEBUG - 2016-11-21 11:07:03 --> Total execution time: 0.8351
INFO - 2016-11-21 11:07:04 --> Config Class Initialized
INFO - 2016-11-21 11:07:04 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:07:04 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:07:04 --> Utf8 Class Initialized
INFO - 2016-11-21 11:07:04 --> URI Class Initialized
INFO - 2016-11-21 11:07:05 --> Router Class Initialized
INFO - 2016-11-21 11:07:05 --> Output Class Initialized
INFO - 2016-11-21 11:07:05 --> Security Class Initialized
DEBUG - 2016-11-21 11:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:07:05 --> Input Class Initialized
INFO - 2016-11-21 11:07:05 --> Language Class Initialized
INFO - 2016-11-21 11:07:05 --> Loader Class Initialized
INFO - 2016-11-21 11:07:05 --> Helper loaded: url_helper
INFO - 2016-11-21 11:07:05 --> Helper loaded: form_helper
INFO - 2016-11-21 11:07:05 --> Database Driver Class Initialized
INFO - 2016-11-21 11:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:07:05 --> Controller Class Initialized
INFO - 2016-11-21 11:07:05 --> Model Class Initialized
INFO - 2016-11-21 11:07:05 --> Form Validation Class Initialized
INFO - 2016-11-21 11:07:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:07:05 --> Pagination Class Initialized
INFO - 2016-11-21 11:07:05 --> Helper loaded: app_helper
ERROR - 2016-11-21 11:07:05 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 11:07:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:07:05 --> Final output sent to browser
DEBUG - 2016-11-21 11:07:05 --> Total execution time: 0.5404
INFO - 2016-11-21 11:07:20 --> Config Class Initialized
INFO - 2016-11-21 11:07:20 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:07:20 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:07:20 --> Utf8 Class Initialized
INFO - 2016-11-21 11:07:20 --> URI Class Initialized
INFO - 2016-11-21 11:07:20 --> Router Class Initialized
INFO - 2016-11-21 11:07:20 --> Output Class Initialized
INFO - 2016-11-21 11:07:20 --> Security Class Initialized
DEBUG - 2016-11-21 11:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:07:20 --> Input Class Initialized
INFO - 2016-11-21 11:07:20 --> Language Class Initialized
INFO - 2016-11-21 11:07:20 --> Loader Class Initialized
INFO - 2016-11-21 11:07:20 --> Helper loaded: url_helper
INFO - 2016-11-21 11:07:20 --> Helper loaded: form_helper
INFO - 2016-11-21 11:07:20 --> Database Driver Class Initialized
INFO - 2016-11-21 11:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:07:20 --> Controller Class Initialized
INFO - 2016-11-21 11:07:20 --> Model Class Initialized
INFO - 2016-11-21 11:07:20 --> Form Validation Class Initialized
INFO - 2016-11-21 11:07:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:07:20 --> Pagination Class Initialized
INFO - 2016-11-21 11:07:20 --> Helper loaded: app_helper
ERROR - 2016-11-21 11:07:21 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:21 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:21 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:21 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:21 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:21 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:21 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:21 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:21 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:21 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:07:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 11:07:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:07:21 --> Final output sent to browser
DEBUG - 2016-11-21 11:07:21 --> Total execution time: 0.7696
INFO - 2016-11-21 11:07:47 --> Config Class Initialized
INFO - 2016-11-21 11:07:47 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:07:47 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:07:47 --> Utf8 Class Initialized
INFO - 2016-11-21 11:07:47 --> URI Class Initialized
DEBUG - 2016-11-21 11:07:47 --> No URI present. Default controller set.
INFO - 2016-11-21 11:07:47 --> Router Class Initialized
INFO - 2016-11-21 11:07:47 --> Output Class Initialized
INFO - 2016-11-21 11:07:47 --> Security Class Initialized
DEBUG - 2016-11-21 11:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:07:47 --> Input Class Initialized
INFO - 2016-11-21 11:07:47 --> Language Class Initialized
INFO - 2016-11-21 11:07:47 --> Loader Class Initialized
INFO - 2016-11-21 11:07:47 --> Helper loaded: url_helper
INFO - 2016-11-21 11:07:47 --> Helper loaded: form_helper
INFO - 2016-11-21 11:07:47 --> Database Driver Class Initialized
INFO - 2016-11-21 11:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:07:47 --> Controller Class Initialized
INFO - 2016-11-21 11:07:47 --> Model Class Initialized
INFO - 2016-11-21 11:07:47 --> Model Class Initialized
INFO - 2016-11-21 11:07:47 --> Model Class Initialized
INFO - 2016-11-21 11:07:47 --> Model Class Initialized
INFO - 2016-11-21 11:07:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:07:47 --> Pagination Class Initialized
INFO - 2016-11-21 11:07:47 --> Helper loaded: app_helper
INFO - 2016-11-21 11:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 11:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 11:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 11:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 11:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 11:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 11:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 11:07:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 11:07:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 11:07:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 11:07:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 11:07:48 --> Final output sent to browser
DEBUG - 2016-11-21 11:07:48 --> Total execution time: 0.7116
INFO - 2016-11-21 11:10:22 --> Config Class Initialized
INFO - 2016-11-21 11:10:22 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:10:22 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:10:22 --> Utf8 Class Initialized
INFO - 2016-11-21 11:10:22 --> URI Class Initialized
DEBUG - 2016-11-21 11:10:22 --> No URI present. Default controller set.
INFO - 2016-11-21 11:10:22 --> Router Class Initialized
INFO - 2016-11-21 11:10:22 --> Output Class Initialized
INFO - 2016-11-21 11:10:22 --> Security Class Initialized
DEBUG - 2016-11-21 11:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:10:22 --> Input Class Initialized
INFO - 2016-11-21 11:10:22 --> Language Class Initialized
INFO - 2016-11-21 11:10:22 --> Loader Class Initialized
INFO - 2016-11-21 11:10:22 --> Helper loaded: url_helper
INFO - 2016-11-21 11:10:22 --> Helper loaded: form_helper
INFO - 2016-11-21 11:10:22 --> Database Driver Class Initialized
INFO - 2016-11-21 11:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:10:22 --> Controller Class Initialized
INFO - 2016-11-21 11:10:22 --> Model Class Initialized
INFO - 2016-11-21 11:10:22 --> Model Class Initialized
INFO - 2016-11-21 11:10:22 --> Model Class Initialized
INFO - 2016-11-21 11:10:22 --> Model Class Initialized
INFO - 2016-11-21 11:10:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:10:22 --> Pagination Class Initialized
INFO - 2016-11-21 11:10:22 --> Helper loaded: app_helper
INFO - 2016-11-21 11:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 11:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 11:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 11:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 11:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 11:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 11:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 11:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 11:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 11:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 11:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 11:10:22 --> Final output sent to browser
DEBUG - 2016-11-21 11:10:22 --> Total execution time: 0.6738
INFO - 2016-11-21 11:10:26 --> Config Class Initialized
INFO - 2016-11-21 11:10:26 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:10:26 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:10:26 --> Utf8 Class Initialized
INFO - 2016-11-21 11:10:26 --> URI Class Initialized
INFO - 2016-11-21 11:10:26 --> Router Class Initialized
INFO - 2016-11-21 11:10:26 --> Output Class Initialized
INFO - 2016-11-21 11:10:26 --> Security Class Initialized
DEBUG - 2016-11-21 11:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:10:26 --> Input Class Initialized
INFO - 2016-11-21 11:10:26 --> Language Class Initialized
INFO - 2016-11-21 11:10:26 --> Loader Class Initialized
INFO - 2016-11-21 11:10:26 --> Helper loaded: url_helper
INFO - 2016-11-21 11:10:26 --> Helper loaded: form_helper
INFO - 2016-11-21 11:10:26 --> Database Driver Class Initialized
INFO - 2016-11-21 11:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:10:26 --> Controller Class Initialized
INFO - 2016-11-21 11:10:26 --> Model Class Initialized
INFO - 2016-11-21 11:10:26 --> Form Validation Class Initialized
INFO - 2016-11-21 11:10:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:10:26 --> Pagination Class Initialized
INFO - 2016-11-21 11:10:26 --> Helper loaded: app_helper
ERROR - 2016-11-21 11:10:26 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:10:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 11:10:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:10:26 --> Final output sent to browser
DEBUG - 2016-11-21 11:10:26 --> Total execution time: 0.4593
INFO - 2016-11-21 11:10:36 --> Config Class Initialized
INFO - 2016-11-21 11:10:36 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:10:36 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:10:36 --> Utf8 Class Initialized
INFO - 2016-11-21 11:10:36 --> URI Class Initialized
DEBUG - 2016-11-21 11:10:36 --> No URI present. Default controller set.
INFO - 2016-11-21 11:10:36 --> Router Class Initialized
INFO - 2016-11-21 11:10:36 --> Output Class Initialized
INFO - 2016-11-21 11:10:36 --> Security Class Initialized
DEBUG - 2016-11-21 11:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:10:36 --> Input Class Initialized
INFO - 2016-11-21 11:10:36 --> Language Class Initialized
INFO - 2016-11-21 11:10:36 --> Loader Class Initialized
INFO - 2016-11-21 11:10:36 --> Helper loaded: url_helper
INFO - 2016-11-21 11:10:36 --> Helper loaded: form_helper
INFO - 2016-11-21 11:10:36 --> Database Driver Class Initialized
INFO - 2016-11-21 11:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:10:36 --> Controller Class Initialized
INFO - 2016-11-21 11:10:36 --> Model Class Initialized
INFO - 2016-11-21 11:10:36 --> Model Class Initialized
INFO - 2016-11-21 11:10:36 --> Model Class Initialized
INFO - 2016-11-21 11:10:36 --> Model Class Initialized
INFO - 2016-11-21 11:10:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:10:36 --> Pagination Class Initialized
INFO - 2016-11-21 11:10:36 --> Helper loaded: app_helper
INFO - 2016-11-21 11:10:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 11:10:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 11:10:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 11:10:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 11:10:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 11:10:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 11:10:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:10:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 11:10:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 11:10:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 11:10:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 11:10:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 11:10:36 --> Final output sent to browser
DEBUG - 2016-11-21 11:10:36 --> Total execution time: 0.6820
INFO - 2016-11-21 11:11:34 --> Config Class Initialized
INFO - 2016-11-21 11:11:34 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:11:34 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:11:34 --> Utf8 Class Initialized
INFO - 2016-11-21 11:11:34 --> URI Class Initialized
DEBUG - 2016-11-21 11:11:34 --> No URI present. Default controller set.
INFO - 2016-11-21 11:11:34 --> Router Class Initialized
INFO - 2016-11-21 11:11:34 --> Output Class Initialized
INFO - 2016-11-21 11:11:34 --> Security Class Initialized
DEBUG - 2016-11-21 11:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:11:34 --> Input Class Initialized
INFO - 2016-11-21 11:11:34 --> Language Class Initialized
INFO - 2016-11-21 11:11:34 --> Loader Class Initialized
INFO - 2016-11-21 11:11:34 --> Helper loaded: url_helper
INFO - 2016-11-21 11:11:34 --> Helper loaded: form_helper
INFO - 2016-11-21 11:11:34 --> Database Driver Class Initialized
INFO - 2016-11-21 11:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:11:34 --> Controller Class Initialized
INFO - 2016-11-21 11:11:34 --> Model Class Initialized
INFO - 2016-11-21 11:11:34 --> Model Class Initialized
INFO - 2016-11-21 11:11:34 --> Model Class Initialized
INFO - 2016-11-21 11:11:34 --> Model Class Initialized
INFO - 2016-11-21 11:11:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:11:35 --> Pagination Class Initialized
INFO - 2016-11-21 11:11:35 --> Helper loaded: app_helper
INFO - 2016-11-21 11:11:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 11:11:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 11:11:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 11:11:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 11:11:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 11:11:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 11:11:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:11:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 11:11:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 11:11:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 11:11:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 11:11:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 11:11:35 --> Final output sent to browser
DEBUG - 2016-11-21 11:11:35 --> Total execution time: 0.6791
INFO - 2016-11-21 11:11:50 --> Config Class Initialized
INFO - 2016-11-21 11:11:50 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:11:50 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:11:50 --> Utf8 Class Initialized
INFO - 2016-11-21 11:11:50 --> URI Class Initialized
DEBUG - 2016-11-21 11:11:50 --> No URI present. Default controller set.
INFO - 2016-11-21 11:11:50 --> Router Class Initialized
INFO - 2016-11-21 11:11:50 --> Output Class Initialized
INFO - 2016-11-21 11:11:50 --> Security Class Initialized
DEBUG - 2016-11-21 11:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:11:50 --> Input Class Initialized
INFO - 2016-11-21 11:11:50 --> Language Class Initialized
INFO - 2016-11-21 11:11:50 --> Loader Class Initialized
INFO - 2016-11-21 11:11:50 --> Helper loaded: url_helper
INFO - 2016-11-21 11:11:50 --> Helper loaded: form_helper
INFO - 2016-11-21 11:11:50 --> Database Driver Class Initialized
INFO - 2016-11-21 11:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:11:50 --> Controller Class Initialized
INFO - 2016-11-21 11:11:50 --> Model Class Initialized
INFO - 2016-11-21 11:11:50 --> Model Class Initialized
INFO - 2016-11-21 11:11:50 --> Model Class Initialized
INFO - 2016-11-21 11:11:50 --> Model Class Initialized
INFO - 2016-11-21 11:11:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:11:50 --> Pagination Class Initialized
INFO - 2016-11-21 11:11:50 --> Helper loaded: app_helper
INFO - 2016-11-21 11:11:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 11:11:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 11:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 11:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 11:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 11:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 11:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 11:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 11:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 11:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 11:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 11:11:51 --> Final output sent to browser
DEBUG - 2016-11-21 11:11:51 --> Total execution time: 0.7220
INFO - 2016-11-21 11:11:54 --> Config Class Initialized
INFO - 2016-11-21 11:11:54 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:11:54 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:11:54 --> Utf8 Class Initialized
INFO - 2016-11-21 11:11:54 --> URI Class Initialized
INFO - 2016-11-21 11:11:54 --> Router Class Initialized
INFO - 2016-11-21 11:11:54 --> Output Class Initialized
INFO - 2016-11-21 11:11:54 --> Security Class Initialized
DEBUG - 2016-11-21 11:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:11:54 --> Input Class Initialized
INFO - 2016-11-21 11:11:54 --> Language Class Initialized
INFO - 2016-11-21 11:11:55 --> Loader Class Initialized
INFO - 2016-11-21 11:11:55 --> Helper loaded: url_helper
INFO - 2016-11-21 11:11:55 --> Helper loaded: form_helper
INFO - 2016-11-21 11:11:55 --> Database Driver Class Initialized
INFO - 2016-11-21 11:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:11:55 --> Controller Class Initialized
INFO - 2016-11-21 11:11:55 --> Model Class Initialized
INFO - 2016-11-21 11:11:55 --> Form Validation Class Initialized
INFO - 2016-11-21 11:11:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:11:55 --> Pagination Class Initialized
INFO - 2016-11-21 11:11:55 --> Helper loaded: app_helper
ERROR - 2016-11-21 11:11:55 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:11:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 11:11:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:11:55 --> Final output sent to browser
DEBUG - 2016-11-21 11:11:55 --> Total execution time: 0.4587
INFO - 2016-11-21 11:11:58 --> Config Class Initialized
INFO - 2016-11-21 11:11:59 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:11:59 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:11:59 --> Utf8 Class Initialized
INFO - 2016-11-21 11:11:59 --> URI Class Initialized
INFO - 2016-11-21 11:11:59 --> Router Class Initialized
INFO - 2016-11-21 11:11:59 --> Output Class Initialized
INFO - 2016-11-21 11:11:59 --> Security Class Initialized
DEBUG - 2016-11-21 11:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:11:59 --> Input Class Initialized
INFO - 2016-11-21 11:11:59 --> Language Class Initialized
INFO - 2016-11-21 11:11:59 --> Loader Class Initialized
INFO - 2016-11-21 11:11:59 --> Helper loaded: url_helper
INFO - 2016-11-21 11:11:59 --> Helper loaded: form_helper
INFO - 2016-11-21 11:11:59 --> Database Driver Class Initialized
INFO - 2016-11-21 11:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:11:59 --> Controller Class Initialized
INFO - 2016-11-21 11:11:59 --> Model Class Initialized
INFO - 2016-11-21 11:11:59 --> Form Validation Class Initialized
INFO - 2016-11-21 11:11:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:11:59 --> Pagination Class Initialized
INFO - 2016-11-21 11:11:59 --> Helper loaded: app_helper
ERROR - 2016-11-21 11:11:59 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:11:59 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:11:59 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:11:59 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:11:59 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:11:59 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:11:59 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:11:59 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:11:59 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:11:59 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 11:11:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:11:59 --> Final output sent to browser
DEBUG - 2016-11-21 11:11:59 --> Total execution time: 0.7718
INFO - 2016-11-21 11:12:02 --> Config Class Initialized
INFO - 2016-11-21 11:12:02 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:12:02 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:12:02 --> Utf8 Class Initialized
INFO - 2016-11-21 11:12:02 --> URI Class Initialized
INFO - 2016-11-21 11:12:02 --> Router Class Initialized
INFO - 2016-11-21 11:12:02 --> Output Class Initialized
INFO - 2016-11-21 11:12:02 --> Security Class Initialized
DEBUG - 2016-11-21 11:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:12:02 --> Input Class Initialized
INFO - 2016-11-21 11:12:02 --> Language Class Initialized
INFO - 2016-11-21 11:12:02 --> Loader Class Initialized
INFO - 2016-11-21 11:12:02 --> Helper loaded: url_helper
INFO - 2016-11-21 11:12:02 --> Helper loaded: form_helper
INFO - 2016-11-21 11:12:02 --> Database Driver Class Initialized
INFO - 2016-11-21 11:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:12:02 --> Controller Class Initialized
INFO - 2016-11-21 11:12:02 --> Model Class Initialized
INFO - 2016-11-21 11:12:02 --> Form Validation Class Initialized
INFO - 2016-11-21 11:12:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:12:03 --> Pagination Class Initialized
INFO - 2016-11-21 11:12:03 --> Helper loaded: app_helper
ERROR - 2016-11-21 11:12:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 11:12:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:12:03 --> Final output sent to browser
DEBUG - 2016-11-21 11:12:03 --> Total execution time: 0.7768
INFO - 2016-11-21 11:12:03 --> Config Class Initialized
INFO - 2016-11-21 11:12:03 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:12:03 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:12:03 --> Utf8 Class Initialized
INFO - 2016-11-21 11:12:03 --> URI Class Initialized
DEBUG - 2016-11-21 11:12:03 --> No URI present. Default controller set.
INFO - 2016-11-21 11:12:03 --> Router Class Initialized
INFO - 2016-11-21 11:12:03 --> Output Class Initialized
INFO - 2016-11-21 11:12:03 --> Security Class Initialized
DEBUG - 2016-11-21 11:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:12:03 --> Input Class Initialized
INFO - 2016-11-21 11:12:03 --> Language Class Initialized
INFO - 2016-11-21 11:12:03 --> Loader Class Initialized
INFO - 2016-11-21 11:12:04 --> Helper loaded: url_helper
INFO - 2016-11-21 11:12:04 --> Helper loaded: form_helper
INFO - 2016-11-21 11:12:04 --> Database Driver Class Initialized
INFO - 2016-11-21 11:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:12:04 --> Controller Class Initialized
INFO - 2016-11-21 11:12:04 --> Model Class Initialized
INFO - 2016-11-21 11:12:04 --> Model Class Initialized
INFO - 2016-11-21 11:12:04 --> Model Class Initialized
INFO - 2016-11-21 11:12:04 --> Model Class Initialized
INFO - 2016-11-21 11:12:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:12:04 --> Pagination Class Initialized
INFO - 2016-11-21 11:12:04 --> Helper loaded: app_helper
INFO - 2016-11-21 11:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 11:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 11:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 11:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 11:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 11:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 11:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 11:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 11:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 11:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 11:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 11:12:04 --> Final output sent to browser
DEBUG - 2016-11-21 11:12:04 --> Total execution time: 0.7106
INFO - 2016-11-21 11:12:07 --> Config Class Initialized
INFO - 2016-11-21 11:12:07 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:12:07 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:12:07 --> Utf8 Class Initialized
INFO - 2016-11-21 11:12:07 --> URI Class Initialized
INFO - 2016-11-21 11:12:07 --> Router Class Initialized
INFO - 2016-11-21 11:12:07 --> Output Class Initialized
INFO - 2016-11-21 11:12:07 --> Security Class Initialized
DEBUG - 2016-11-21 11:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:12:07 --> Input Class Initialized
INFO - 2016-11-21 11:12:07 --> Language Class Initialized
INFO - 2016-11-21 11:12:07 --> Loader Class Initialized
INFO - 2016-11-21 11:12:07 --> Helper loaded: url_helper
INFO - 2016-11-21 11:12:07 --> Helper loaded: form_helper
INFO - 2016-11-21 11:12:07 --> Database Driver Class Initialized
INFO - 2016-11-21 11:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:12:07 --> Controller Class Initialized
INFO - 2016-11-21 11:12:07 --> Model Class Initialized
INFO - 2016-11-21 11:12:07 --> Form Validation Class Initialized
INFO - 2016-11-21 11:12:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:12:07 --> Pagination Class Initialized
INFO - 2016-11-21 11:12:07 --> Helper loaded: app_helper
ERROR - 2016-11-21 11:12:07 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 11:12:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:12:07 --> Final output sent to browser
DEBUG - 2016-11-21 11:12:07 --> Total execution time: 0.4636
INFO - 2016-11-21 11:12:09 --> Config Class Initialized
INFO - 2016-11-21 11:12:09 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:12:09 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:12:09 --> Utf8 Class Initialized
INFO - 2016-11-21 11:12:09 --> URI Class Initialized
INFO - 2016-11-21 11:12:09 --> Router Class Initialized
INFO - 2016-11-21 11:12:09 --> Output Class Initialized
INFO - 2016-11-21 11:12:09 --> Security Class Initialized
DEBUG - 2016-11-21 11:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:12:09 --> Input Class Initialized
INFO - 2016-11-21 11:12:09 --> Language Class Initialized
INFO - 2016-11-21 11:12:09 --> Loader Class Initialized
INFO - 2016-11-21 11:12:09 --> Helper loaded: url_helper
INFO - 2016-11-21 11:12:09 --> Helper loaded: form_helper
INFO - 2016-11-21 11:12:09 --> Database Driver Class Initialized
INFO - 2016-11-21 11:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:12:09 --> Controller Class Initialized
INFO - 2016-11-21 11:12:10 --> Model Class Initialized
INFO - 2016-11-21 11:12:10 --> Form Validation Class Initialized
INFO - 2016-11-21 11:12:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:12:10 --> Pagination Class Initialized
INFO - 2016-11-21 11:12:10 --> Helper loaded: app_helper
ERROR - 2016-11-21 11:12:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 11:12:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:12:10 --> Final output sent to browser
DEBUG - 2016-11-21 11:12:10 --> Total execution time: 0.9143
INFO - 2016-11-21 11:12:16 --> Config Class Initialized
INFO - 2016-11-21 11:12:16 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:12:16 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:12:16 --> Utf8 Class Initialized
INFO - 2016-11-21 11:12:16 --> URI Class Initialized
DEBUG - 2016-11-21 11:12:16 --> No URI present. Default controller set.
INFO - 2016-11-21 11:12:16 --> Router Class Initialized
INFO - 2016-11-21 11:12:16 --> Output Class Initialized
INFO - 2016-11-21 11:12:16 --> Security Class Initialized
DEBUG - 2016-11-21 11:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:12:16 --> Input Class Initialized
INFO - 2016-11-21 11:12:16 --> Language Class Initialized
INFO - 2016-11-21 11:12:16 --> Loader Class Initialized
INFO - 2016-11-21 11:12:16 --> Helper loaded: url_helper
INFO - 2016-11-21 11:12:16 --> Helper loaded: form_helper
INFO - 2016-11-21 11:12:16 --> Database Driver Class Initialized
INFO - 2016-11-21 11:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:12:16 --> Controller Class Initialized
INFO - 2016-11-21 11:12:16 --> Model Class Initialized
INFO - 2016-11-21 11:12:16 --> Model Class Initialized
INFO - 2016-11-21 11:12:16 --> Model Class Initialized
INFO - 2016-11-21 11:12:16 --> Model Class Initialized
INFO - 2016-11-21 11:12:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:12:16 --> Pagination Class Initialized
INFO - 2016-11-21 11:12:16 --> Helper loaded: app_helper
INFO - 2016-11-21 11:12:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 11:12:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 11:12:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 11:12:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 11:12:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 11:12:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 11:12:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:12:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 11:12:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 11:12:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 11:12:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 11:12:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 11:12:17 --> Final output sent to browser
DEBUG - 2016-11-21 11:12:17 --> Total execution time: 0.7981
INFO - 2016-11-21 11:12:45 --> Config Class Initialized
INFO - 2016-11-21 11:12:45 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:12:45 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:12:45 --> Utf8 Class Initialized
INFO - 2016-11-21 11:12:45 --> URI Class Initialized
DEBUG - 2016-11-21 11:12:45 --> No URI present. Default controller set.
INFO - 2016-11-21 11:12:45 --> Router Class Initialized
INFO - 2016-11-21 11:12:45 --> Output Class Initialized
INFO - 2016-11-21 11:12:45 --> Security Class Initialized
DEBUG - 2016-11-21 11:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:12:45 --> Input Class Initialized
INFO - 2016-11-21 11:12:45 --> Language Class Initialized
INFO - 2016-11-21 11:12:45 --> Loader Class Initialized
INFO - 2016-11-21 11:12:45 --> Helper loaded: url_helper
INFO - 2016-11-21 11:12:45 --> Helper loaded: form_helper
INFO - 2016-11-21 11:12:45 --> Database Driver Class Initialized
INFO - 2016-11-21 11:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:12:45 --> Controller Class Initialized
INFO - 2016-11-21 11:12:45 --> Model Class Initialized
INFO - 2016-11-21 11:12:45 --> Model Class Initialized
INFO - 2016-11-21 11:12:45 --> Model Class Initialized
INFO - 2016-11-21 11:12:45 --> Model Class Initialized
INFO - 2016-11-21 11:12:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:12:45 --> Pagination Class Initialized
INFO - 2016-11-21 11:12:45 --> Helper loaded: app_helper
INFO - 2016-11-21 11:12:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 11:12:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 11:12:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 11:12:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 11:12:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 11:12:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 11:12:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:12:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 11:12:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 11:12:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 11:12:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 11:12:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 11:12:45 --> Final output sent to browser
DEBUG - 2016-11-21 11:12:45 --> Total execution time: 0.8201
INFO - 2016-11-21 11:12:49 --> Config Class Initialized
INFO - 2016-11-21 11:12:49 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:12:49 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:12:49 --> Utf8 Class Initialized
INFO - 2016-11-21 11:12:49 --> URI Class Initialized
INFO - 2016-11-21 11:12:49 --> Router Class Initialized
INFO - 2016-11-21 11:12:49 --> Output Class Initialized
INFO - 2016-11-21 11:12:49 --> Security Class Initialized
DEBUG - 2016-11-21 11:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:12:49 --> Input Class Initialized
INFO - 2016-11-21 11:12:49 --> Language Class Initialized
INFO - 2016-11-21 11:12:49 --> Loader Class Initialized
INFO - 2016-11-21 11:12:49 --> Helper loaded: url_helper
INFO - 2016-11-21 11:12:49 --> Helper loaded: form_helper
INFO - 2016-11-21 11:12:49 --> Database Driver Class Initialized
INFO - 2016-11-21 11:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:12:49 --> Controller Class Initialized
INFO - 2016-11-21 11:12:49 --> Model Class Initialized
INFO - 2016-11-21 11:12:49 --> Form Validation Class Initialized
INFO - 2016-11-21 11:12:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:12:49 --> Pagination Class Initialized
INFO - 2016-11-21 11:12:49 --> Helper loaded: app_helper
ERROR - 2016-11-21 11:12:49 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 11:12:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:12:49 --> Final output sent to browser
DEBUG - 2016-11-21 11:12:49 --> Total execution time: 0.4723
INFO - 2016-11-21 11:12:53 --> Config Class Initialized
INFO - 2016-11-21 11:12:53 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:12:53 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:12:53 --> Utf8 Class Initialized
INFO - 2016-11-21 11:12:53 --> URI Class Initialized
INFO - 2016-11-21 11:12:53 --> Router Class Initialized
INFO - 2016-11-21 11:12:53 --> Output Class Initialized
INFO - 2016-11-21 11:12:53 --> Security Class Initialized
DEBUG - 2016-11-21 11:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:12:53 --> Input Class Initialized
INFO - 2016-11-21 11:12:53 --> Language Class Initialized
INFO - 2016-11-21 11:12:53 --> Loader Class Initialized
INFO - 2016-11-21 11:12:53 --> Helper loaded: url_helper
INFO - 2016-11-21 11:12:53 --> Helper loaded: form_helper
INFO - 2016-11-21 11:12:54 --> Database Driver Class Initialized
INFO - 2016-11-21 11:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:12:54 --> Controller Class Initialized
INFO - 2016-11-21 11:12:54 --> Model Class Initialized
INFO - 2016-11-21 11:12:54 --> Form Validation Class Initialized
INFO - 2016-11-21 11:12:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:12:54 --> Pagination Class Initialized
INFO - 2016-11-21 11:12:54 --> Helper loaded: app_helper
ERROR - 2016-11-21 11:12:54 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 11:12:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:12:54 --> Final output sent to browser
DEBUG - 2016-11-21 11:12:54 --> Total execution time: 0.4756
INFO - 2016-11-21 11:12:59 --> Config Class Initialized
INFO - 2016-11-21 11:12:59 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:12:59 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:12:59 --> Utf8 Class Initialized
INFO - 2016-11-21 11:12:59 --> URI Class Initialized
INFO - 2016-11-21 11:12:59 --> Router Class Initialized
INFO - 2016-11-21 11:12:59 --> Output Class Initialized
INFO - 2016-11-21 11:12:59 --> Security Class Initialized
DEBUG - 2016-11-21 11:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:12:59 --> Input Class Initialized
INFO - 2016-11-21 11:12:59 --> Language Class Initialized
INFO - 2016-11-21 11:12:59 --> Loader Class Initialized
INFO - 2016-11-21 11:12:59 --> Helper loaded: url_helper
INFO - 2016-11-21 11:12:59 --> Helper loaded: form_helper
INFO - 2016-11-21 11:12:59 --> Database Driver Class Initialized
INFO - 2016-11-21 11:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:12:59 --> Controller Class Initialized
INFO - 2016-11-21 11:12:59 --> Model Class Initialized
INFO - 2016-11-21 11:12:59 --> Form Validation Class Initialized
INFO - 2016-11-21 11:12:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:12:59 --> Pagination Class Initialized
INFO - 2016-11-21 11:12:59 --> Helper loaded: app_helper
ERROR - 2016-11-21 11:12:59 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:59 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:59 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:59 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:59 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:59 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:59 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:59 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:59 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:59 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 11:12:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:12:59 --> Final output sent to browser
DEBUG - 2016-11-21 11:12:59 --> Total execution time: 0.8047
INFO - 2016-11-21 11:14:15 --> Config Class Initialized
INFO - 2016-11-21 11:14:15 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:14:15 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:14:15 --> Utf8 Class Initialized
INFO - 2016-11-21 11:14:15 --> URI Class Initialized
DEBUG - 2016-11-21 11:14:15 --> No URI present. Default controller set.
INFO - 2016-11-21 11:14:15 --> Router Class Initialized
INFO - 2016-11-21 11:14:15 --> Output Class Initialized
INFO - 2016-11-21 11:14:15 --> Security Class Initialized
DEBUG - 2016-11-21 11:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:14:15 --> Input Class Initialized
INFO - 2016-11-21 11:14:15 --> Language Class Initialized
INFO - 2016-11-21 11:14:15 --> Loader Class Initialized
INFO - 2016-11-21 11:14:15 --> Helper loaded: url_helper
INFO - 2016-11-21 11:14:15 --> Helper loaded: form_helper
INFO - 2016-11-21 11:14:15 --> Database Driver Class Initialized
INFO - 2016-11-21 11:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:14:15 --> Controller Class Initialized
INFO - 2016-11-21 11:14:15 --> Model Class Initialized
INFO - 2016-11-21 11:14:15 --> Model Class Initialized
INFO - 2016-11-21 11:14:15 --> Model Class Initialized
INFO - 2016-11-21 11:14:15 --> Model Class Initialized
INFO - 2016-11-21 11:14:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:14:15 --> Pagination Class Initialized
INFO - 2016-11-21 11:14:15 --> Helper loaded: app_helper
INFO - 2016-11-21 11:14:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 11:14:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 11:14:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 11:14:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 11:14:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 11:14:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 11:14:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:14:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 11:14:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 11:14:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 11:14:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 11:14:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 11:14:15 --> Final output sent to browser
DEBUG - 2016-11-21 11:14:15 --> Total execution time: 0.7850
INFO - 2016-11-21 11:14:18 --> Config Class Initialized
INFO - 2016-11-21 11:14:18 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:14:18 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:14:18 --> Utf8 Class Initialized
INFO - 2016-11-21 11:14:18 --> URI Class Initialized
INFO - 2016-11-21 11:14:18 --> Router Class Initialized
INFO - 2016-11-21 11:14:18 --> Output Class Initialized
INFO - 2016-11-21 11:14:18 --> Security Class Initialized
DEBUG - 2016-11-21 11:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:14:18 --> Input Class Initialized
INFO - 2016-11-21 11:14:18 --> Language Class Initialized
INFO - 2016-11-21 11:14:18 --> Loader Class Initialized
INFO - 2016-11-21 11:14:18 --> Helper loaded: url_helper
INFO - 2016-11-21 11:14:18 --> Helper loaded: form_helper
INFO - 2016-11-21 11:14:18 --> Database Driver Class Initialized
INFO - 2016-11-21 11:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:14:18 --> Controller Class Initialized
INFO - 2016-11-21 11:14:18 --> Model Class Initialized
INFO - 2016-11-21 11:14:18 --> Form Validation Class Initialized
INFO - 2016-11-21 11:14:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:14:18 --> Pagination Class Initialized
INFO - 2016-11-21 11:14:18 --> Helper loaded: app_helper
ERROR - 2016-11-21 11:14:18 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:14:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 11:14:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:14:18 --> Final output sent to browser
DEBUG - 2016-11-21 11:14:18 --> Total execution time: 0.4781
INFO - 2016-11-21 11:14:24 --> Config Class Initialized
INFO - 2016-11-21 11:14:24 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:14:24 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:14:24 --> Utf8 Class Initialized
INFO - 2016-11-21 11:14:24 --> URI Class Initialized
INFO - 2016-11-21 11:14:24 --> Router Class Initialized
INFO - 2016-11-21 11:14:24 --> Output Class Initialized
INFO - 2016-11-21 11:14:24 --> Security Class Initialized
DEBUG - 2016-11-21 11:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:14:24 --> Input Class Initialized
INFO - 2016-11-21 11:14:24 --> Language Class Initialized
INFO - 2016-11-21 11:14:24 --> Loader Class Initialized
INFO - 2016-11-21 11:14:24 --> Helper loaded: url_helper
INFO - 2016-11-21 11:14:24 --> Helper loaded: form_helper
INFO - 2016-11-21 11:14:24 --> Database Driver Class Initialized
INFO - 2016-11-21 11:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:14:24 --> Controller Class Initialized
INFO - 2016-11-21 11:14:24 --> Model Class Initialized
INFO - 2016-11-21 11:14:24 --> Form Validation Class Initialized
INFO - 2016-11-21 11:14:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:14:24 --> Pagination Class Initialized
INFO - 2016-11-21 11:14:24 --> Helper loaded: app_helper
ERROR - 2016-11-21 11:14:24 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:14:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:14:24 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:14:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:14:24 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:14:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:14:24 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:14:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:14:24 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:14:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:14:24 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:14:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:14:24 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:14:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:14:24 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:14:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:14:24 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:14:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:14:24 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:14:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 11:14:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:14:24 --> Final output sent to browser
DEBUG - 2016-11-21 11:14:24 --> Total execution time: 0.8198
INFO - 2016-11-21 11:14:52 --> Config Class Initialized
INFO - 2016-11-21 11:14:52 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:14:52 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:14:52 --> Utf8 Class Initialized
INFO - 2016-11-21 11:14:52 --> URI Class Initialized
DEBUG - 2016-11-21 11:14:52 --> No URI present. Default controller set.
INFO - 2016-11-21 11:14:52 --> Router Class Initialized
INFO - 2016-11-21 11:14:52 --> Output Class Initialized
INFO - 2016-11-21 11:14:52 --> Security Class Initialized
DEBUG - 2016-11-21 11:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:14:52 --> Input Class Initialized
INFO - 2016-11-21 11:14:52 --> Language Class Initialized
INFO - 2016-11-21 11:14:52 --> Loader Class Initialized
INFO - 2016-11-21 11:14:52 --> Helper loaded: url_helper
INFO - 2016-11-21 11:14:52 --> Helper loaded: form_helper
INFO - 2016-11-21 11:14:52 --> Database Driver Class Initialized
INFO - 2016-11-21 11:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:14:52 --> Controller Class Initialized
INFO - 2016-11-21 11:14:52 --> Model Class Initialized
INFO - 2016-11-21 11:14:52 --> Model Class Initialized
INFO - 2016-11-21 11:14:52 --> Model Class Initialized
INFO - 2016-11-21 11:14:52 --> Model Class Initialized
INFO - 2016-11-21 11:14:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:14:53 --> Pagination Class Initialized
INFO - 2016-11-21 11:14:53 --> Helper loaded: app_helper
INFO - 2016-11-21 11:14:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 11:14:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 11:14:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 11:14:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 11:14:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 11:14:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 11:14:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:14:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 11:14:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 11:14:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 11:14:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 11:14:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 11:14:53 --> Final output sent to browser
DEBUG - 2016-11-21 11:14:53 --> Total execution time: 0.7913
INFO - 2016-11-21 11:14:56 --> Config Class Initialized
INFO - 2016-11-21 11:14:56 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:14:56 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:14:56 --> Utf8 Class Initialized
INFO - 2016-11-21 11:14:56 --> URI Class Initialized
INFO - 2016-11-21 11:14:56 --> Router Class Initialized
INFO - 2016-11-21 11:14:56 --> Output Class Initialized
INFO - 2016-11-21 11:14:56 --> Security Class Initialized
DEBUG - 2016-11-21 11:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:14:56 --> Input Class Initialized
INFO - 2016-11-21 11:14:56 --> Language Class Initialized
INFO - 2016-11-21 11:14:56 --> Loader Class Initialized
INFO - 2016-11-21 11:14:56 --> Helper loaded: url_helper
INFO - 2016-11-21 11:14:56 --> Helper loaded: form_helper
INFO - 2016-11-21 11:14:56 --> Database Driver Class Initialized
INFO - 2016-11-21 11:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:14:56 --> Controller Class Initialized
INFO - 2016-11-21 11:14:56 --> Model Class Initialized
INFO - 2016-11-21 11:14:56 --> Form Validation Class Initialized
INFO - 2016-11-21 11:14:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:14:56 --> Pagination Class Initialized
INFO - 2016-11-21 11:14:56 --> Helper loaded: app_helper
ERROR - 2016-11-21 11:14:56 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:14:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 11:14:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:14:56 --> Final output sent to browser
DEBUG - 2016-11-21 11:14:56 --> Total execution time: 0.4985
INFO - 2016-11-21 11:15:00 --> Config Class Initialized
INFO - 2016-11-21 11:15:00 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:15:00 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:15:00 --> Utf8 Class Initialized
INFO - 2016-11-21 11:15:00 --> URI Class Initialized
INFO - 2016-11-21 11:15:00 --> Router Class Initialized
INFO - 2016-11-21 11:15:00 --> Output Class Initialized
INFO - 2016-11-21 11:15:00 --> Security Class Initialized
DEBUG - 2016-11-21 11:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:15:00 --> Input Class Initialized
INFO - 2016-11-21 11:15:00 --> Language Class Initialized
INFO - 2016-11-21 11:15:00 --> Loader Class Initialized
INFO - 2016-11-21 11:15:00 --> Helper loaded: url_helper
INFO - 2016-11-21 11:15:00 --> Helper loaded: form_helper
INFO - 2016-11-21 11:15:00 --> Database Driver Class Initialized
INFO - 2016-11-21 11:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:15:00 --> Controller Class Initialized
INFO - 2016-11-21 11:15:00 --> Model Class Initialized
INFO - 2016-11-21 11:15:00 --> Form Validation Class Initialized
INFO - 2016-11-21 11:15:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:15:00 --> Pagination Class Initialized
INFO - 2016-11-21 11:15:00 --> Helper loaded: app_helper
ERROR - 2016-11-21 11:15:00 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:15:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:15:00 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:15:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:15:00 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:15:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:15:00 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:15:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:15:00 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:15:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:15:00 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:15:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:15:00 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:15:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:15:00 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:15:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:15:00 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:15:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:15:00 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 11:15:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 11:15:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:15:00 --> Final output sent to browser
DEBUG - 2016-11-21 11:15:00 --> Total execution time: 0.8191
INFO - 2016-11-21 11:15:17 --> Config Class Initialized
INFO - 2016-11-21 11:15:17 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:15:17 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:15:17 --> Utf8 Class Initialized
INFO - 2016-11-21 11:15:17 --> URI Class Initialized
INFO - 2016-11-21 11:15:17 --> Router Class Initialized
INFO - 2016-11-21 11:15:17 --> Output Class Initialized
INFO - 2016-11-21 11:15:17 --> Security Class Initialized
DEBUG - 2016-11-21 11:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:15:17 --> Input Class Initialized
INFO - 2016-11-21 11:15:17 --> Language Class Initialized
INFO - 2016-11-21 11:15:17 --> Loader Class Initialized
INFO - 2016-11-21 11:15:17 --> Helper loaded: url_helper
INFO - 2016-11-21 11:15:17 --> Helper loaded: form_helper
INFO - 2016-11-21 11:15:17 --> Database Driver Class Initialized
INFO - 2016-11-21 11:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:15:17 --> Controller Class Initialized
INFO - 2016-11-21 11:15:17 --> Model Class Initialized
INFO - 2016-11-21 11:15:17 --> Model Class Initialized
INFO - 2016-11-21 11:15:17 --> Model Class Initialized
INFO - 2016-11-21 11:15:18 --> Model Class Initialized
INFO - 2016-11-21 11:15:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:15:18 --> Pagination Class Initialized
INFO - 2016-11-21 11:15:18 --> Helper loaded: app_helper
DEBUG - 2016-11-21 11:15:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-21 11:15:18 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 180
ERROR - 2016-11-21 11:15:18 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 180
INFO - 2016-11-21 11:15:18 --> Config Class Initialized
INFO - 2016-11-21 11:15:18 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:15:18 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:15:18 --> Utf8 Class Initialized
INFO - 2016-11-21 11:15:18 --> URI Class Initialized
DEBUG - 2016-11-21 11:15:18 --> No URI present. Default controller set.
INFO - 2016-11-21 11:15:18 --> Router Class Initialized
INFO - 2016-11-21 11:15:18 --> Output Class Initialized
INFO - 2016-11-21 11:15:18 --> Security Class Initialized
DEBUG - 2016-11-21 11:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:15:18 --> Input Class Initialized
INFO - 2016-11-21 11:15:18 --> Language Class Initialized
INFO - 2016-11-21 11:15:18 --> Loader Class Initialized
INFO - 2016-11-21 11:15:18 --> Helper loaded: url_helper
INFO - 2016-11-21 11:15:18 --> Helper loaded: form_helper
INFO - 2016-11-21 11:15:18 --> Database Driver Class Initialized
INFO - 2016-11-21 11:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:15:18 --> Controller Class Initialized
INFO - 2016-11-21 11:15:18 --> Model Class Initialized
INFO - 2016-11-21 11:15:18 --> Model Class Initialized
INFO - 2016-11-21 11:15:18 --> Model Class Initialized
INFO - 2016-11-21 11:15:18 --> Model Class Initialized
INFO - 2016-11-21 11:15:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:15:18 --> Pagination Class Initialized
INFO - 2016-11-21 11:15:18 --> Helper loaded: app_helper
INFO - 2016-11-21 11:15:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 11:15:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-21 11:15:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 11:15:18 --> Final output sent to browser
DEBUG - 2016-11-21 11:15:18 --> Total execution time: 0.5598
INFO - 2016-11-21 11:15:26 --> Config Class Initialized
INFO - 2016-11-21 11:15:26 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:15:26 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:15:26 --> Utf8 Class Initialized
INFO - 2016-11-21 11:15:27 --> URI Class Initialized
INFO - 2016-11-21 11:15:27 --> Router Class Initialized
INFO - 2016-11-21 11:15:27 --> Output Class Initialized
INFO - 2016-11-21 11:15:27 --> Security Class Initialized
DEBUG - 2016-11-21 11:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:15:27 --> Input Class Initialized
INFO - 2016-11-21 11:15:27 --> Language Class Initialized
INFO - 2016-11-21 11:15:27 --> Loader Class Initialized
INFO - 2016-11-21 11:15:27 --> Helper loaded: url_helper
INFO - 2016-11-21 11:15:27 --> Helper loaded: form_helper
INFO - 2016-11-21 11:15:27 --> Database Driver Class Initialized
INFO - 2016-11-21 11:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:15:27 --> Controller Class Initialized
INFO - 2016-11-21 11:15:27 --> Model Class Initialized
INFO - 2016-11-21 11:15:27 --> Model Class Initialized
INFO - 2016-11-21 11:15:27 --> Model Class Initialized
INFO - 2016-11-21 11:15:27 --> Model Class Initialized
INFO - 2016-11-21 11:15:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:15:27 --> Pagination Class Initialized
INFO - 2016-11-21 11:15:27 --> Helper loaded: app_helper
DEBUG - 2016-11-21 11:15:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-21 11:15:27 --> Model Class Initialized
INFO - 2016-11-21 11:15:27 --> Final output sent to browser
DEBUG - 2016-11-21 11:15:27 --> Total execution time: 0.5061
INFO - 2016-11-21 11:15:27 --> Config Class Initialized
INFO - 2016-11-21 11:15:27 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:15:27 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:15:27 --> Utf8 Class Initialized
INFO - 2016-11-21 11:15:27 --> URI Class Initialized
DEBUG - 2016-11-21 11:15:27 --> No URI present. Default controller set.
INFO - 2016-11-21 11:15:27 --> Router Class Initialized
INFO - 2016-11-21 11:15:27 --> Output Class Initialized
INFO - 2016-11-21 11:15:27 --> Security Class Initialized
DEBUG - 2016-11-21 11:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:15:27 --> Input Class Initialized
INFO - 2016-11-21 11:15:27 --> Language Class Initialized
INFO - 2016-11-21 11:15:27 --> Loader Class Initialized
INFO - 2016-11-21 11:15:27 --> Helper loaded: url_helper
INFO - 2016-11-21 11:15:27 --> Helper loaded: form_helper
INFO - 2016-11-21 11:15:27 --> Database Driver Class Initialized
INFO - 2016-11-21 11:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:15:27 --> Controller Class Initialized
INFO - 2016-11-21 11:15:27 --> Model Class Initialized
INFO - 2016-11-21 11:15:27 --> Model Class Initialized
INFO - 2016-11-21 11:15:27 --> Model Class Initialized
INFO - 2016-11-21 11:15:27 --> Model Class Initialized
INFO - 2016-11-21 11:15:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:15:27 --> Pagination Class Initialized
INFO - 2016-11-21 11:15:27 --> Helper loaded: app_helper
INFO - 2016-11-21 11:15:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 11:15:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 11:15:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 11:15:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 11:15:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 11:15:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 11:15:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:15:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 11:15:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 11:15:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 11:15:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 11:15:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 11:15:28 --> Final output sent to browser
DEBUG - 2016-11-21 11:15:28 --> Total execution time: 0.7590
INFO - 2016-11-21 11:16:54 --> Config Class Initialized
INFO - 2016-11-21 11:16:54 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:16:54 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:16:54 --> Utf8 Class Initialized
INFO - 2016-11-21 11:16:54 --> URI Class Initialized
DEBUG - 2016-11-21 11:16:54 --> No URI present. Default controller set.
INFO - 2016-11-21 11:16:54 --> Router Class Initialized
INFO - 2016-11-21 11:16:54 --> Output Class Initialized
INFO - 2016-11-21 11:16:54 --> Security Class Initialized
DEBUG - 2016-11-21 11:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:16:54 --> Input Class Initialized
INFO - 2016-11-21 11:16:54 --> Language Class Initialized
INFO - 2016-11-21 11:16:55 --> Loader Class Initialized
INFO - 2016-11-21 11:16:55 --> Helper loaded: url_helper
INFO - 2016-11-21 11:16:55 --> Helper loaded: form_helper
INFO - 2016-11-21 11:16:55 --> Database Driver Class Initialized
INFO - 2016-11-21 11:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:16:55 --> Controller Class Initialized
INFO - 2016-11-21 11:16:55 --> Model Class Initialized
INFO - 2016-11-21 11:16:55 --> Model Class Initialized
INFO - 2016-11-21 11:16:55 --> Model Class Initialized
INFO - 2016-11-21 11:16:55 --> Model Class Initialized
INFO - 2016-11-21 11:16:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:16:55 --> Pagination Class Initialized
INFO - 2016-11-21 11:16:55 --> Helper loaded: app_helper
INFO - 2016-11-21 11:16:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 11:16:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 11:16:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 11:16:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 11:16:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 11:16:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 11:16:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:16:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 11:16:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 11:16:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 11:16:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 11:16:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 11:16:55 --> Final output sent to browser
DEBUG - 2016-11-21 11:16:55 --> Total execution time: 0.8060
INFO - 2016-11-21 11:17:45 --> Config Class Initialized
INFO - 2016-11-21 11:17:45 --> Hooks Class Initialized
DEBUG - 2016-11-21 11:17:45 --> UTF-8 Support Enabled
INFO - 2016-11-21 11:17:45 --> Utf8 Class Initialized
INFO - 2016-11-21 11:17:45 --> URI Class Initialized
DEBUG - 2016-11-21 11:17:45 --> No URI present. Default controller set.
INFO - 2016-11-21 11:17:45 --> Router Class Initialized
INFO - 2016-11-21 11:17:45 --> Output Class Initialized
INFO - 2016-11-21 11:17:45 --> Security Class Initialized
DEBUG - 2016-11-21 11:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 11:17:45 --> Input Class Initialized
INFO - 2016-11-21 11:17:45 --> Language Class Initialized
INFO - 2016-11-21 11:17:45 --> Loader Class Initialized
INFO - 2016-11-21 11:17:45 --> Helper loaded: url_helper
INFO - 2016-11-21 11:17:45 --> Helper loaded: form_helper
INFO - 2016-11-21 11:17:45 --> Database Driver Class Initialized
INFO - 2016-11-21 11:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 11:17:45 --> Controller Class Initialized
INFO - 2016-11-21 11:17:45 --> Model Class Initialized
INFO - 2016-11-21 11:17:45 --> Model Class Initialized
INFO - 2016-11-21 11:17:45 --> Model Class Initialized
INFO - 2016-11-21 11:17:45 --> Model Class Initialized
INFO - 2016-11-21 11:17:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 11:17:45 --> Pagination Class Initialized
INFO - 2016-11-21 11:17:45 --> Helper loaded: app_helper
INFO - 2016-11-21 11:17:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 11:17:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 11:17:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 11:17:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 11:17:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 11:17:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 11:17:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 11:17:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 11:17:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 11:17:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 11:17:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 11:17:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 11:17:46 --> Final output sent to browser
DEBUG - 2016-11-21 11:17:46 --> Total execution time: 0.7960
INFO - 2016-11-21 15:19:21 --> Config Class Initialized
INFO - 2016-11-21 15:19:21 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:19:21 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:19:21 --> Utf8 Class Initialized
INFO - 2016-11-21 15:19:21 --> URI Class Initialized
DEBUG - 2016-11-21 15:19:21 --> No URI present. Default controller set.
INFO - 2016-11-21 15:19:21 --> Router Class Initialized
INFO - 2016-11-21 15:19:21 --> Output Class Initialized
INFO - 2016-11-21 15:19:21 --> Security Class Initialized
DEBUG - 2016-11-21 15:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:19:22 --> Input Class Initialized
INFO - 2016-11-21 15:19:22 --> Language Class Initialized
INFO - 2016-11-21 15:19:22 --> Loader Class Initialized
INFO - 2016-11-21 15:19:22 --> Helper loaded: url_helper
INFO - 2016-11-21 15:19:22 --> Helper loaded: form_helper
INFO - 2016-11-21 15:19:22 --> Database Driver Class Initialized
INFO - 2016-11-21 15:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:19:22 --> Controller Class Initialized
INFO - 2016-11-21 15:19:22 --> Model Class Initialized
INFO - 2016-11-21 15:19:22 --> Model Class Initialized
INFO - 2016-11-21 15:19:22 --> Model Class Initialized
INFO - 2016-11-21 15:19:22 --> Model Class Initialized
INFO - 2016-11-21 15:19:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:19:23 --> Pagination Class Initialized
INFO - 2016-11-21 15:19:23 --> Helper loaded: app_helper
INFO - 2016-11-21 15:19:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 15:19:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-21 15:19:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 15:19:23 --> Final output sent to browser
DEBUG - 2016-11-21 15:19:23 --> Total execution time: 2.0740
INFO - 2016-11-21 15:19:35 --> Config Class Initialized
INFO - 2016-11-21 15:19:35 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:19:35 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:19:35 --> Utf8 Class Initialized
INFO - 2016-11-21 15:19:35 --> URI Class Initialized
INFO - 2016-11-21 15:19:35 --> Router Class Initialized
INFO - 2016-11-21 15:19:35 --> Output Class Initialized
INFO - 2016-11-21 15:19:35 --> Security Class Initialized
DEBUG - 2016-11-21 15:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:19:35 --> Input Class Initialized
INFO - 2016-11-21 15:19:35 --> Language Class Initialized
INFO - 2016-11-21 15:19:35 --> Loader Class Initialized
INFO - 2016-11-21 15:19:35 --> Helper loaded: url_helper
INFO - 2016-11-21 15:19:35 --> Helper loaded: form_helper
INFO - 2016-11-21 15:19:35 --> Database Driver Class Initialized
INFO - 2016-11-21 15:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:19:35 --> Controller Class Initialized
INFO - 2016-11-21 15:19:35 --> Model Class Initialized
INFO - 2016-11-21 15:19:35 --> Model Class Initialized
INFO - 2016-11-21 15:19:35 --> Model Class Initialized
INFO - 2016-11-21 15:19:35 --> Model Class Initialized
INFO - 2016-11-21 15:19:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:19:35 --> Pagination Class Initialized
INFO - 2016-11-21 15:19:35 --> Helper loaded: app_helper
DEBUG - 2016-11-21 15:19:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-21 15:19:35 --> Model Class Initialized
INFO - 2016-11-21 15:19:35 --> Final output sent to browser
DEBUG - 2016-11-21 15:19:35 --> Total execution time: 0.4228
INFO - 2016-11-21 15:19:35 --> Config Class Initialized
INFO - 2016-11-21 15:19:35 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:19:35 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:19:35 --> Utf8 Class Initialized
INFO - 2016-11-21 15:19:35 --> URI Class Initialized
DEBUG - 2016-11-21 15:19:35 --> No URI present. Default controller set.
INFO - 2016-11-21 15:19:35 --> Router Class Initialized
INFO - 2016-11-21 15:19:35 --> Output Class Initialized
INFO - 2016-11-21 15:19:35 --> Security Class Initialized
DEBUG - 2016-11-21 15:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:19:36 --> Input Class Initialized
INFO - 2016-11-21 15:19:36 --> Language Class Initialized
INFO - 2016-11-21 15:19:36 --> Loader Class Initialized
INFO - 2016-11-21 15:19:36 --> Helper loaded: url_helper
INFO - 2016-11-21 15:19:36 --> Helper loaded: form_helper
INFO - 2016-11-21 15:19:36 --> Database Driver Class Initialized
INFO - 2016-11-21 15:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:19:36 --> Controller Class Initialized
INFO - 2016-11-21 15:19:36 --> Model Class Initialized
INFO - 2016-11-21 15:19:36 --> Model Class Initialized
INFO - 2016-11-21 15:19:36 --> Model Class Initialized
INFO - 2016-11-21 15:19:36 --> Model Class Initialized
INFO - 2016-11-21 15:19:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:19:36 --> Pagination Class Initialized
INFO - 2016-11-21 15:19:36 --> Helper loaded: app_helper
INFO - 2016-11-21 15:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 15:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 15:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 15:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 15:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 15:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 15:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 15:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 15:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 15:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 15:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 15:19:36 --> Final output sent to browser
DEBUG - 2016-11-21 15:19:36 --> Total execution time: 0.7308
INFO - 2016-11-21 15:19:41 --> Config Class Initialized
INFO - 2016-11-21 15:19:41 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:19:41 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:19:41 --> Utf8 Class Initialized
INFO - 2016-11-21 15:19:41 --> URI Class Initialized
INFO - 2016-11-21 15:19:41 --> Router Class Initialized
INFO - 2016-11-21 15:19:41 --> Output Class Initialized
INFO - 2016-11-21 15:19:41 --> Security Class Initialized
DEBUG - 2016-11-21 15:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:19:41 --> Input Class Initialized
INFO - 2016-11-21 15:19:41 --> Language Class Initialized
INFO - 2016-11-21 15:19:41 --> Loader Class Initialized
INFO - 2016-11-21 15:19:41 --> Helper loaded: url_helper
INFO - 2016-11-21 15:19:41 --> Helper loaded: form_helper
INFO - 2016-11-21 15:19:41 --> Database Driver Class Initialized
INFO - 2016-11-21 15:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:19:42 --> Controller Class Initialized
INFO - 2016-11-21 15:19:42 --> Model Class Initialized
INFO - 2016-11-21 15:19:42 --> Form Validation Class Initialized
INFO - 2016-11-21 15:19:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:19:42 --> Pagination Class Initialized
INFO - 2016-11-21 15:19:42 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:19:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:19:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:19:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:19:42 --> Final output sent to browser
DEBUG - 2016-11-21 15:19:42 --> Total execution time: 0.4470
INFO - 2016-11-21 15:19:46 --> Config Class Initialized
INFO - 2016-11-21 15:19:46 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:19:46 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:19:46 --> Utf8 Class Initialized
INFO - 2016-11-21 15:19:46 --> URI Class Initialized
INFO - 2016-11-21 15:19:46 --> Router Class Initialized
INFO - 2016-11-21 15:19:46 --> Output Class Initialized
INFO - 2016-11-21 15:19:46 --> Security Class Initialized
DEBUG - 2016-11-21 15:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:19:46 --> Input Class Initialized
INFO - 2016-11-21 15:19:46 --> Language Class Initialized
INFO - 2016-11-21 15:19:46 --> Loader Class Initialized
INFO - 2016-11-21 15:19:46 --> Helper loaded: url_helper
INFO - 2016-11-21 15:19:46 --> Helper loaded: form_helper
INFO - 2016-11-21 15:19:46 --> Database Driver Class Initialized
INFO - 2016-11-21 15:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:19:46 --> Controller Class Initialized
INFO - 2016-11-21 15:19:46 --> Model Class Initialized
INFO - 2016-11-21 15:19:46 --> Form Validation Class Initialized
INFO - 2016-11-21 15:19:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:19:46 --> Pagination Class Initialized
INFO - 2016-11-21 15:19:46 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:19:46 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:19:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:19:46 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:19:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:19:46 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:19:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:19:46 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:19:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:19:46 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:19:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:19:46 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:19:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:19:46 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:19:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:19:46 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:19:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:19:46 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:19:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:19:46 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:19:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:19:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:19:46 --> Final output sent to browser
DEBUG - 2016-11-21 15:19:46 --> Total execution time: 0.5559
INFO - 2016-11-21 15:19:48 --> Config Class Initialized
INFO - 2016-11-21 15:19:48 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:19:48 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:19:48 --> Utf8 Class Initialized
INFO - 2016-11-21 15:19:48 --> URI Class Initialized
INFO - 2016-11-21 15:19:48 --> Router Class Initialized
INFO - 2016-11-21 15:19:48 --> Output Class Initialized
INFO - 2016-11-21 15:19:48 --> Security Class Initialized
DEBUG - 2016-11-21 15:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:19:48 --> Input Class Initialized
INFO - 2016-11-21 15:19:48 --> Language Class Initialized
INFO - 2016-11-21 15:19:48 --> Loader Class Initialized
INFO - 2016-11-21 15:19:48 --> Helper loaded: url_helper
INFO - 2016-11-21 15:19:48 --> Helper loaded: form_helper
INFO - 2016-11-21 15:19:48 --> Database Driver Class Initialized
INFO - 2016-11-21 15:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:19:49 --> Controller Class Initialized
INFO - 2016-11-21 15:19:49 --> Model Class Initialized
INFO - 2016-11-21 15:19:49 --> Form Validation Class Initialized
INFO - 2016-11-21 15:19:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:19:49 --> Pagination Class Initialized
INFO - 2016-11-21 15:19:49 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:19:49 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:19:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:19:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:19:49 --> Final output sent to browser
DEBUG - 2016-11-21 15:19:49 --> Total execution time: 0.4128
INFO - 2016-11-21 15:19:55 --> Config Class Initialized
INFO - 2016-11-21 15:19:55 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:19:55 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:19:55 --> Utf8 Class Initialized
INFO - 2016-11-21 15:19:55 --> URI Class Initialized
DEBUG - 2016-11-21 15:19:55 --> No URI present. Default controller set.
INFO - 2016-11-21 15:19:55 --> Router Class Initialized
INFO - 2016-11-21 15:19:55 --> Output Class Initialized
INFO - 2016-11-21 15:19:55 --> Security Class Initialized
DEBUG - 2016-11-21 15:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:19:55 --> Input Class Initialized
INFO - 2016-11-21 15:19:55 --> Language Class Initialized
INFO - 2016-11-21 15:19:55 --> Loader Class Initialized
INFO - 2016-11-21 15:19:55 --> Helper loaded: url_helper
INFO - 2016-11-21 15:19:55 --> Helper loaded: form_helper
INFO - 2016-11-21 15:19:55 --> Database Driver Class Initialized
INFO - 2016-11-21 15:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:19:55 --> Controller Class Initialized
INFO - 2016-11-21 15:19:55 --> Model Class Initialized
INFO - 2016-11-21 15:19:55 --> Model Class Initialized
INFO - 2016-11-21 15:19:55 --> Model Class Initialized
INFO - 2016-11-21 15:19:55 --> Model Class Initialized
INFO - 2016-11-21 15:19:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:19:55 --> Pagination Class Initialized
INFO - 2016-11-21 15:19:55 --> Helper loaded: app_helper
INFO - 2016-11-21 15:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 15:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 15:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 15:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 15:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 15:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 15:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 15:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 15:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 15:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 15:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 15:19:56 --> Final output sent to browser
DEBUG - 2016-11-21 15:19:56 --> Total execution time: 0.6110
INFO - 2016-11-21 15:19:56 --> Config Class Initialized
INFO - 2016-11-21 15:19:56 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:19:56 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:19:56 --> Utf8 Class Initialized
INFO - 2016-11-21 15:19:56 --> URI Class Initialized
DEBUG - 2016-11-21 15:19:56 --> No URI present. Default controller set.
INFO - 2016-11-21 15:19:56 --> Router Class Initialized
INFO - 2016-11-21 15:19:56 --> Output Class Initialized
INFO - 2016-11-21 15:19:56 --> Security Class Initialized
DEBUG - 2016-11-21 15:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:19:56 --> Input Class Initialized
INFO - 2016-11-21 15:19:56 --> Language Class Initialized
INFO - 2016-11-21 15:19:56 --> Loader Class Initialized
INFO - 2016-11-21 15:19:56 --> Helper loaded: url_helper
INFO - 2016-11-21 15:19:56 --> Helper loaded: form_helper
INFO - 2016-11-21 15:19:56 --> Database Driver Class Initialized
INFO - 2016-11-21 15:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:19:56 --> Controller Class Initialized
INFO - 2016-11-21 15:19:56 --> Model Class Initialized
INFO - 2016-11-21 15:19:56 --> Model Class Initialized
INFO - 2016-11-21 15:19:56 --> Model Class Initialized
INFO - 2016-11-21 15:19:56 --> Model Class Initialized
INFO - 2016-11-21 15:19:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:19:56 --> Pagination Class Initialized
INFO - 2016-11-21 15:19:56 --> Helper loaded: app_helper
INFO - 2016-11-21 15:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 15:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 15:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 15:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 15:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 15:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 15:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 15:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 15:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 15:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 15:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 15:19:56 --> Final output sent to browser
DEBUG - 2016-11-21 15:19:56 --> Total execution time: 0.5649
INFO - 2016-11-21 15:20:05 --> Config Class Initialized
INFO - 2016-11-21 15:20:05 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:20:05 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:20:05 --> Utf8 Class Initialized
INFO - 2016-11-21 15:20:05 --> URI Class Initialized
INFO - 2016-11-21 15:20:05 --> Router Class Initialized
INFO - 2016-11-21 15:20:05 --> Output Class Initialized
INFO - 2016-11-21 15:20:05 --> Security Class Initialized
DEBUG - 2016-11-21 15:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:20:05 --> Input Class Initialized
INFO - 2016-11-21 15:20:05 --> Language Class Initialized
INFO - 2016-11-21 15:20:05 --> Loader Class Initialized
INFO - 2016-11-21 15:20:05 --> Helper loaded: url_helper
INFO - 2016-11-21 15:20:05 --> Helper loaded: form_helper
INFO - 2016-11-21 15:20:05 --> Database Driver Class Initialized
INFO - 2016-11-21 15:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:20:05 --> Controller Class Initialized
INFO - 2016-11-21 15:20:05 --> Model Class Initialized
INFO - 2016-11-21 15:20:05 --> Form Validation Class Initialized
INFO - 2016-11-21 15:20:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:20:05 --> Pagination Class Initialized
INFO - 2016-11-21 15:20:05 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:20:05 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:20:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:20:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:20:05 --> Final output sent to browser
DEBUG - 2016-11-21 15:20:05 --> Total execution time: 0.4572
INFO - 2016-11-21 15:20:45 --> Config Class Initialized
INFO - 2016-11-21 15:20:45 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:20:45 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:20:45 --> Utf8 Class Initialized
INFO - 2016-11-21 15:20:45 --> URI Class Initialized
INFO - 2016-11-21 15:20:45 --> Router Class Initialized
INFO - 2016-11-21 15:20:45 --> Output Class Initialized
INFO - 2016-11-21 15:20:45 --> Security Class Initialized
DEBUG - 2016-11-21 15:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:20:45 --> Input Class Initialized
INFO - 2016-11-21 15:20:45 --> Language Class Initialized
INFO - 2016-11-21 15:20:45 --> Loader Class Initialized
INFO - 2016-11-21 15:20:45 --> Helper loaded: url_helper
INFO - 2016-11-21 15:20:45 --> Helper loaded: form_helper
INFO - 2016-11-21 15:20:45 --> Database Driver Class Initialized
INFO - 2016-11-21 15:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:20:45 --> Controller Class Initialized
INFO - 2016-11-21 15:20:45 --> Model Class Initialized
INFO - 2016-11-21 15:20:45 --> Form Validation Class Initialized
INFO - 2016-11-21 15:20:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:20:45 --> Pagination Class Initialized
INFO - 2016-11-21 15:20:45 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:20:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:20:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:20:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:20:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:20:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:20:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:20:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:20:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:20:46 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:20:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:20:46 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:20:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:20:46 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:20:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:20:46 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:20:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:20:46 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:20:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:20:46 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:20:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:20:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:20:46 --> Final output sent to browser
DEBUG - 2016-11-21 15:20:46 --> Total execution time: 1.1484
INFO - 2016-11-21 15:20:52 --> Config Class Initialized
INFO - 2016-11-21 15:20:52 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:20:52 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:20:52 --> Utf8 Class Initialized
INFO - 2016-11-21 15:20:52 --> URI Class Initialized
DEBUG - 2016-11-21 15:20:52 --> No URI present. Default controller set.
INFO - 2016-11-21 15:20:52 --> Router Class Initialized
INFO - 2016-11-21 15:20:52 --> Output Class Initialized
INFO - 2016-11-21 15:20:52 --> Security Class Initialized
DEBUG - 2016-11-21 15:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:20:52 --> Input Class Initialized
INFO - 2016-11-21 15:20:52 --> Language Class Initialized
INFO - 2016-11-21 15:20:52 --> Loader Class Initialized
INFO - 2016-11-21 15:20:52 --> Helper loaded: url_helper
INFO - 2016-11-21 15:20:52 --> Helper loaded: form_helper
INFO - 2016-11-21 15:20:52 --> Database Driver Class Initialized
INFO - 2016-11-21 15:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:20:52 --> Controller Class Initialized
INFO - 2016-11-21 15:20:52 --> Model Class Initialized
INFO - 2016-11-21 15:20:53 --> Model Class Initialized
INFO - 2016-11-21 15:20:53 --> Model Class Initialized
INFO - 2016-11-21 15:20:53 --> Model Class Initialized
INFO - 2016-11-21 15:20:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:20:53 --> Pagination Class Initialized
INFO - 2016-11-21 15:20:53 --> Helper loaded: app_helper
INFO - 2016-11-21 15:20:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 15:20:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 15:20:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 15:20:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 15:20:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 15:20:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 15:20:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:20:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 15:20:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 15:20:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 15:20:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 15:20:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 15:20:53 --> Final output sent to browser
DEBUG - 2016-11-21 15:20:53 --> Total execution time: 0.5545
INFO - 2016-11-21 15:21:02 --> Config Class Initialized
INFO - 2016-11-21 15:21:02 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:21:02 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:21:02 --> Utf8 Class Initialized
INFO - 2016-11-21 15:21:02 --> URI Class Initialized
INFO - 2016-11-21 15:21:02 --> Router Class Initialized
INFO - 2016-11-21 15:21:02 --> Output Class Initialized
INFO - 2016-11-21 15:21:02 --> Security Class Initialized
DEBUG - 2016-11-21 15:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:21:02 --> Input Class Initialized
INFO - 2016-11-21 15:21:02 --> Language Class Initialized
INFO - 2016-11-21 15:21:02 --> Loader Class Initialized
INFO - 2016-11-21 15:21:02 --> Helper loaded: url_helper
INFO - 2016-11-21 15:21:02 --> Config Class Initialized
INFO - 2016-11-21 15:21:02 --> Helper loaded: form_helper
INFO - 2016-11-21 15:21:02 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:21:02 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:21:02 --> Database Driver Class Initialized
INFO - 2016-11-21 15:21:02 --> Utf8 Class Initialized
INFO - 2016-11-21 15:21:02 --> URI Class Initialized
INFO - 2016-11-21 15:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:21:02 --> Router Class Initialized
INFO - 2016-11-21 15:21:02 --> Controller Class Initialized
INFO - 2016-11-21 15:21:02 --> Model Class Initialized
INFO - 2016-11-21 15:21:02 --> Output Class Initialized
INFO - 2016-11-21 15:21:02 --> Form Validation Class Initialized
INFO - 2016-11-21 15:21:02 --> Security Class Initialized
INFO - 2016-11-21 15:21:02 --> Config Class Initialized
INFO - 2016-11-21 15:21:02 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2016-11-21 15:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:21:02 --> Pagination Class Initialized
INFO - 2016-11-21 15:21:02 --> Hooks Class Initialized
INFO - 2016-11-21 15:21:02 --> Input Class Initialized
DEBUG - 2016-11-21 15:21:02 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:21:02 --> Helper loaded: app_helper
INFO - 2016-11-21 15:21:02 --> Language Class Initialized
INFO - 2016-11-21 15:21:02 --> Utf8 Class Initialized
ERROR - 2016-11-21 15:21:02 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:21:02 --> URI Class Initialized
INFO - 2016-11-21 15:21:02 --> Loader Class Initialized
ERROR - 2016-11-21 15:21:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:21:02 --> Router Class Initialized
INFO - 2016-11-21 15:21:02 --> Helper loaded: url_helper
INFO - 2016-11-21 15:21:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:21:02 --> Output Class Initialized
INFO - 2016-11-21 15:21:02 --> Helper loaded: form_helper
INFO - 2016-11-21 15:21:02 --> Final output sent to browser
DEBUG - 2016-11-21 15:21:02 --> Total execution time: 0.4462
INFO - 2016-11-21 15:21:02 --> Security Class Initialized
INFO - 2016-11-21 15:21:02 --> Database Driver Class Initialized
DEBUG - 2016-11-21 15:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:21:02 --> Input Class Initialized
INFO - 2016-11-21 15:21:02 --> Controller Class Initialized
INFO - 2016-11-21 15:21:02 --> Language Class Initialized
INFO - 2016-11-21 15:21:02 --> Model Class Initialized
INFO - 2016-11-21 15:21:02 --> Loader Class Initialized
INFO - 2016-11-21 15:21:02 --> Form Validation Class Initialized
INFO - 2016-11-21 15:21:02 --> Helper loaded: url_helper
INFO - 2016-11-21 15:21:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:21:02 --> Helper loaded: form_helper
INFO - 2016-11-21 15:21:02 --> Pagination Class Initialized
INFO - 2016-11-21 15:21:02 --> Helper loaded: app_helper
INFO - 2016-11-21 15:21:02 --> Database Driver Class Initialized
ERROR - 2016-11-21 15:21:02 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:21:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:21:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:21:02 --> Final output sent to browser
DEBUG - 2016-11-21 15:21:02 --> Total execution time: 0.5201
INFO - 2016-11-21 15:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:21:02 --> Controller Class Initialized
INFO - 2016-11-21 15:21:02 --> Model Class Initialized
INFO - 2016-11-21 15:21:02 --> Form Validation Class Initialized
INFO - 2016-11-21 15:21:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:21:02 --> Pagination Class Initialized
INFO - 2016-11-21 15:21:02 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:21:02 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:21:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:21:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:21:03 --> Final output sent to browser
DEBUG - 2016-11-21 15:21:03 --> Total execution time: 0.5367
INFO - 2016-11-21 15:21:42 --> Config Class Initialized
INFO - 2016-11-21 15:21:42 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:21:42 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:21:42 --> Utf8 Class Initialized
INFO - 2016-11-21 15:21:42 --> URI Class Initialized
INFO - 2016-11-21 15:21:42 --> Router Class Initialized
INFO - 2016-11-21 15:21:42 --> Output Class Initialized
INFO - 2016-11-21 15:21:42 --> Security Class Initialized
DEBUG - 2016-11-21 15:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:21:42 --> Input Class Initialized
INFO - 2016-11-21 15:21:42 --> Language Class Initialized
INFO - 2016-11-21 15:21:42 --> Loader Class Initialized
INFO - 2016-11-21 15:21:42 --> Helper loaded: url_helper
INFO - 2016-11-21 15:21:42 --> Helper loaded: form_helper
INFO - 2016-11-21 15:21:42 --> Database Driver Class Initialized
INFO - 2016-11-21 15:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:21:42 --> Controller Class Initialized
INFO - 2016-11-21 15:21:42 --> Model Class Initialized
INFO - 2016-11-21 15:21:42 --> Form Validation Class Initialized
INFO - 2016-11-21 15:21:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:21:42 --> Pagination Class Initialized
INFO - 2016-11-21 15:21:42 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:21:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:21:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:21:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:21:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:21:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:21:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:21:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:21:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:21:43 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:21:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:21:43 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:21:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:21:43 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:21:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:21:43 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:21:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:21:43 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:21:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:21:43 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:21:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:21:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:21:43 --> Final output sent to browser
DEBUG - 2016-11-21 15:21:43 --> Total execution time: 0.6594
INFO - 2016-11-21 15:22:35 --> Config Class Initialized
INFO - 2016-11-21 15:22:35 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:22:35 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:22:35 --> Utf8 Class Initialized
INFO - 2016-11-21 15:22:35 --> URI Class Initialized
INFO - 2016-11-21 15:22:35 --> Router Class Initialized
INFO - 2016-11-21 15:22:35 --> Output Class Initialized
INFO - 2016-11-21 15:22:35 --> Security Class Initialized
DEBUG - 2016-11-21 15:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:22:35 --> Input Class Initialized
INFO - 2016-11-21 15:22:35 --> Language Class Initialized
INFO - 2016-11-21 15:22:35 --> Loader Class Initialized
INFO - 2016-11-21 15:22:35 --> Helper loaded: url_helper
INFO - 2016-11-21 15:22:35 --> Helper loaded: form_helper
INFO - 2016-11-21 15:22:35 --> Database Driver Class Initialized
INFO - 2016-11-21 15:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:22:35 --> Controller Class Initialized
INFO - 2016-11-21 15:22:35 --> Model Class Initialized
INFO - 2016-11-21 15:22:35 --> Form Validation Class Initialized
INFO - 2016-11-21 15:22:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 15:22:35 --> Final output sent to browser
DEBUG - 2016-11-21 15:22:35 --> Total execution time: 0.4324
INFO - 2016-11-21 15:22:42 --> Config Class Initialized
INFO - 2016-11-21 15:22:42 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:22:42 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:22:42 --> Utf8 Class Initialized
INFO - 2016-11-21 15:22:42 --> URI Class Initialized
INFO - 2016-11-21 15:22:42 --> Router Class Initialized
INFO - 2016-11-21 15:22:42 --> Output Class Initialized
INFO - 2016-11-21 15:22:42 --> Security Class Initialized
DEBUG - 2016-11-21 15:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:22:42 --> Input Class Initialized
INFO - 2016-11-21 15:22:42 --> Language Class Initialized
INFO - 2016-11-21 15:22:42 --> Loader Class Initialized
INFO - 2016-11-21 15:22:42 --> Helper loaded: url_helper
INFO - 2016-11-21 15:22:42 --> Helper loaded: form_helper
INFO - 2016-11-21 15:22:42 --> Database Driver Class Initialized
INFO - 2016-11-21 15:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:22:42 --> Controller Class Initialized
INFO - 2016-11-21 15:22:42 --> Model Class Initialized
INFO - 2016-11-21 15:22:42 --> Form Validation Class Initialized
INFO - 2016-11-21 15:22:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:22:42 --> Pagination Class Initialized
INFO - 2016-11-21 15:22:42 --> Helper loaded: app_helper
INFO - 2016-11-21 15:22:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 15:22:42 --> Final output sent to browser
DEBUG - 2016-11-21 15:22:42 --> Total execution time: 0.3905
INFO - 2016-11-21 15:22:53 --> Config Class Initialized
INFO - 2016-11-21 15:22:53 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:22:53 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:22:53 --> Utf8 Class Initialized
INFO - 2016-11-21 15:22:53 --> URI Class Initialized
DEBUG - 2016-11-21 15:22:53 --> No URI present. Default controller set.
INFO - 2016-11-21 15:22:53 --> Router Class Initialized
INFO - 2016-11-21 15:22:53 --> Output Class Initialized
INFO - 2016-11-21 15:22:53 --> Security Class Initialized
DEBUG - 2016-11-21 15:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:22:53 --> Input Class Initialized
INFO - 2016-11-21 15:22:53 --> Language Class Initialized
INFO - 2016-11-21 15:22:53 --> Loader Class Initialized
INFO - 2016-11-21 15:22:53 --> Helper loaded: url_helper
INFO - 2016-11-21 15:22:53 --> Helper loaded: form_helper
INFO - 2016-11-21 15:22:53 --> Database Driver Class Initialized
INFO - 2016-11-21 15:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:22:54 --> Controller Class Initialized
INFO - 2016-11-21 15:22:54 --> Model Class Initialized
INFO - 2016-11-21 15:22:54 --> Model Class Initialized
INFO - 2016-11-21 15:22:54 --> Model Class Initialized
INFO - 2016-11-21 15:22:54 --> Model Class Initialized
INFO - 2016-11-21 15:22:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:22:54 --> Pagination Class Initialized
INFO - 2016-11-21 15:22:54 --> Helper loaded: app_helper
INFO - 2016-11-21 15:22:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 15:22:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 15:22:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 15:22:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 15:22:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 15:22:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 15:22:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:22:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 15:22:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 15:22:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 15:22:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 15:22:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 15:22:54 --> Final output sent to browser
DEBUG - 2016-11-21 15:22:54 --> Total execution time: 0.5962
INFO - 2016-11-21 15:23:00 --> Config Class Initialized
INFO - 2016-11-21 15:23:00 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:23:00 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:23:00 --> Utf8 Class Initialized
INFO - 2016-11-21 15:23:00 --> URI Class Initialized
INFO - 2016-11-21 15:23:00 --> Router Class Initialized
INFO - 2016-11-21 15:23:00 --> Output Class Initialized
INFO - 2016-11-21 15:23:00 --> Security Class Initialized
DEBUG - 2016-11-21 15:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:23:00 --> Input Class Initialized
INFO - 2016-11-21 15:23:00 --> Language Class Initialized
INFO - 2016-11-21 15:23:00 --> Loader Class Initialized
INFO - 2016-11-21 15:23:00 --> Helper loaded: url_helper
INFO - 2016-11-21 15:23:00 --> Helper loaded: form_helper
INFO - 2016-11-21 15:23:00 --> Database Driver Class Initialized
INFO - 2016-11-21 15:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:23:00 --> Controller Class Initialized
INFO - 2016-11-21 15:23:00 --> Model Class Initialized
INFO - 2016-11-21 15:23:01 --> Form Validation Class Initialized
INFO - 2016-11-21 15:23:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:23:01 --> Pagination Class Initialized
INFO - 2016-11-21 15:23:01 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:23:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:23:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:23:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:23:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:23:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:23:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:23:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:23:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:23:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:23:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:23:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:23:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:23:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:23:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:23:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:23:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:23:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:23:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:23:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:23:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:23:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:23:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:23:01 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-11-21 15:23:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:23:02 --> Final output sent to browser
DEBUG - 2016-11-21 15:23:02 --> Total execution time: 1.2809
INFO - 2016-11-21 15:23:02 --> Config Class Initialized
INFO - 2016-11-21 15:23:02 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:23:02 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:23:02 --> Utf8 Class Initialized
INFO - 2016-11-21 15:23:02 --> URI Class Initialized
DEBUG - 2016-11-21 15:23:02 --> No URI present. Default controller set.
INFO - 2016-11-21 15:23:02 --> Router Class Initialized
INFO - 2016-11-21 15:23:02 --> Output Class Initialized
INFO - 2016-11-21 15:23:02 --> Security Class Initialized
DEBUG - 2016-11-21 15:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:23:02 --> Input Class Initialized
INFO - 2016-11-21 15:23:02 --> Language Class Initialized
INFO - 2016-11-21 15:23:02 --> Loader Class Initialized
INFO - 2016-11-21 15:23:02 --> Helper loaded: url_helper
INFO - 2016-11-21 15:23:02 --> Helper loaded: form_helper
INFO - 2016-11-21 15:23:02 --> Database Driver Class Initialized
INFO - 2016-11-21 15:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:23:02 --> Controller Class Initialized
INFO - 2016-11-21 15:23:02 --> Model Class Initialized
INFO - 2016-11-21 15:23:02 --> Model Class Initialized
INFO - 2016-11-21 15:23:02 --> Model Class Initialized
INFO - 2016-11-21 15:23:02 --> Model Class Initialized
INFO - 2016-11-21 15:23:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:23:02 --> Pagination Class Initialized
INFO - 2016-11-21 15:23:02 --> Helper loaded: app_helper
INFO - 2016-11-21 15:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 15:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 15:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 15:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 15:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 15:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 15:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 15:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 15:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 15:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 15:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 15:23:02 --> Final output sent to browser
DEBUG - 2016-11-21 15:23:02 --> Total execution time: 0.5902
INFO - 2016-11-21 15:23:15 --> Config Class Initialized
INFO - 2016-11-21 15:23:15 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:23:15 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:23:15 --> Utf8 Class Initialized
INFO - 2016-11-21 15:23:15 --> URI Class Initialized
DEBUG - 2016-11-21 15:23:15 --> No URI present. Default controller set.
INFO - 2016-11-21 15:23:15 --> Router Class Initialized
INFO - 2016-11-21 15:23:16 --> Output Class Initialized
INFO - 2016-11-21 15:23:16 --> Security Class Initialized
DEBUG - 2016-11-21 15:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:23:16 --> Input Class Initialized
INFO - 2016-11-21 15:23:16 --> Language Class Initialized
INFO - 2016-11-21 15:23:16 --> Loader Class Initialized
INFO - 2016-11-21 15:23:16 --> Helper loaded: url_helper
INFO - 2016-11-21 15:23:16 --> Helper loaded: form_helper
INFO - 2016-11-21 15:23:16 --> Database Driver Class Initialized
INFO - 2016-11-21 15:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:23:16 --> Controller Class Initialized
INFO - 2016-11-21 15:23:16 --> Model Class Initialized
INFO - 2016-11-21 15:23:16 --> Model Class Initialized
INFO - 2016-11-21 15:23:17 --> Model Class Initialized
INFO - 2016-11-21 15:23:17 --> Model Class Initialized
INFO - 2016-11-21 15:23:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:23:17 --> Pagination Class Initialized
INFO - 2016-11-21 15:23:17 --> Helper loaded: app_helper
INFO - 2016-11-21 15:23:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 15:23:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 15:23:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 15:23:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 15:23:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 15:23:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 15:23:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:23:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 15:23:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 15:23:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 15:23:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 15:23:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 15:23:17 --> Final output sent to browser
DEBUG - 2016-11-21 15:23:17 --> Total execution time: 2.0205
INFO - 2016-11-21 15:28:00 --> Config Class Initialized
INFO - 2016-11-21 15:28:00 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:28:00 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:28:00 --> Utf8 Class Initialized
INFO - 2016-11-21 15:28:00 --> URI Class Initialized
INFO - 2016-11-21 15:28:00 --> Router Class Initialized
INFO - 2016-11-21 15:28:00 --> Output Class Initialized
INFO - 2016-11-21 15:28:00 --> Security Class Initialized
DEBUG - 2016-11-21 15:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:28:00 --> Input Class Initialized
INFO - 2016-11-21 15:28:00 --> Language Class Initialized
INFO - 2016-11-21 15:28:00 --> Loader Class Initialized
INFO - 2016-11-21 15:28:00 --> Helper loaded: url_helper
INFO - 2016-11-21 15:28:00 --> Helper loaded: form_helper
INFO - 2016-11-21 15:28:00 --> Database Driver Class Initialized
INFO - 2016-11-21 15:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:28:00 --> Controller Class Initialized
INFO - 2016-11-21 15:28:00 --> Model Class Initialized
INFO - 2016-11-21 15:28:00 --> Form Validation Class Initialized
INFO - 2016-11-21 15:28:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:28:00 --> Pagination Class Initialized
INFO - 2016-11-21 15:28:00 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:28:00 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:28:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:28:00 --> Final output sent to browser
DEBUG - 2016-11-21 15:28:00 --> Total execution time: 0.4400
INFO - 2016-11-21 15:28:38 --> Config Class Initialized
INFO - 2016-11-21 15:28:38 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:28:38 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:28:38 --> Utf8 Class Initialized
INFO - 2016-11-21 15:28:38 --> URI Class Initialized
DEBUG - 2016-11-21 15:28:38 --> No URI present. Default controller set.
INFO - 2016-11-21 15:28:38 --> Router Class Initialized
INFO - 2016-11-21 15:28:38 --> Output Class Initialized
INFO - 2016-11-21 15:28:38 --> Security Class Initialized
DEBUG - 2016-11-21 15:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:28:38 --> Input Class Initialized
INFO - 2016-11-21 15:28:38 --> Language Class Initialized
INFO - 2016-11-21 15:28:38 --> Loader Class Initialized
INFO - 2016-11-21 15:28:38 --> Helper loaded: url_helper
INFO - 2016-11-21 15:28:38 --> Helper loaded: form_helper
INFO - 2016-11-21 15:28:38 --> Database Driver Class Initialized
INFO - 2016-11-21 15:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:28:38 --> Controller Class Initialized
INFO - 2016-11-21 15:28:38 --> Model Class Initialized
INFO - 2016-11-21 15:28:38 --> Model Class Initialized
INFO - 2016-11-21 15:28:38 --> Model Class Initialized
INFO - 2016-11-21 15:28:38 --> Model Class Initialized
INFO - 2016-11-21 15:28:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:28:38 --> Pagination Class Initialized
INFO - 2016-11-21 15:28:38 --> Helper loaded: app_helper
INFO - 2016-11-21 15:28:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 15:28:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 15:28:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 15:28:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 15:28:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 15:28:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 15:28:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:28:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 15:28:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 15:28:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 15:28:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 15:28:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 15:28:39 --> Final output sent to browser
DEBUG - 2016-11-21 15:28:39 --> Total execution time: 0.5850
INFO - 2016-11-21 15:30:34 --> Config Class Initialized
INFO - 2016-11-21 15:30:34 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:30:34 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:30:34 --> Utf8 Class Initialized
INFO - 2016-11-21 15:30:34 --> URI Class Initialized
INFO - 2016-11-21 15:30:34 --> Router Class Initialized
INFO - 2016-11-21 15:30:34 --> Output Class Initialized
INFO - 2016-11-21 15:30:34 --> Security Class Initialized
DEBUG - 2016-11-21 15:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:30:34 --> Input Class Initialized
INFO - 2016-11-21 15:30:34 --> Language Class Initialized
INFO - 2016-11-21 15:30:34 --> Loader Class Initialized
INFO - 2016-11-21 15:30:34 --> Helper loaded: url_helper
INFO - 2016-11-21 15:30:34 --> Helper loaded: form_helper
INFO - 2016-11-21 15:30:34 --> Database Driver Class Initialized
INFO - 2016-11-21 15:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:30:34 --> Controller Class Initialized
INFO - 2016-11-21 15:30:34 --> Model Class Initialized
INFO - 2016-11-21 15:30:34 --> Form Validation Class Initialized
INFO - 2016-11-21 15:30:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:30:34 --> Pagination Class Initialized
INFO - 2016-11-21 15:30:34 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:30:34 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:30:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:30:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:30:34 --> Final output sent to browser
DEBUG - 2016-11-21 15:30:34 --> Total execution time: 0.5217
INFO - 2016-11-21 15:39:49 --> Config Class Initialized
INFO - 2016-11-21 15:39:49 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:39:49 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:39:49 --> Utf8 Class Initialized
INFO - 2016-11-21 15:39:49 --> URI Class Initialized
DEBUG - 2016-11-21 15:39:49 --> No URI present. Default controller set.
INFO - 2016-11-21 15:39:49 --> Router Class Initialized
INFO - 2016-11-21 15:39:49 --> Output Class Initialized
INFO - 2016-11-21 15:39:49 --> Security Class Initialized
DEBUG - 2016-11-21 15:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:39:49 --> Input Class Initialized
INFO - 2016-11-21 15:39:49 --> Language Class Initialized
INFO - 2016-11-21 15:39:49 --> Loader Class Initialized
INFO - 2016-11-21 15:39:49 --> Helper loaded: url_helper
INFO - 2016-11-21 15:39:49 --> Helper loaded: form_helper
INFO - 2016-11-21 15:39:49 --> Database Driver Class Initialized
INFO - 2016-11-21 15:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:39:49 --> Controller Class Initialized
INFO - 2016-11-21 15:39:49 --> Model Class Initialized
INFO - 2016-11-21 15:39:49 --> Model Class Initialized
INFO - 2016-11-21 15:39:49 --> Model Class Initialized
INFO - 2016-11-21 15:39:49 --> Model Class Initialized
INFO - 2016-11-21 15:39:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:39:49 --> Pagination Class Initialized
INFO - 2016-11-21 15:39:49 --> Helper loaded: app_helper
INFO - 2016-11-21 15:39:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 15:39:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 15:39:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 15:39:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 15:39:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 15:39:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 15:39:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:39:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 15:39:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 15:39:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 15:39:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 15:39:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 15:39:49 --> Final output sent to browser
DEBUG - 2016-11-21 15:39:49 --> Total execution time: 0.6423
INFO - 2016-11-21 15:42:08 --> Config Class Initialized
INFO - 2016-11-21 15:42:08 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:42:08 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:42:08 --> Utf8 Class Initialized
INFO - 2016-11-21 15:42:08 --> URI Class Initialized
DEBUG - 2016-11-21 15:42:08 --> No URI present. Default controller set.
INFO - 2016-11-21 15:42:08 --> Router Class Initialized
INFO - 2016-11-21 15:42:08 --> Output Class Initialized
INFO - 2016-11-21 15:42:08 --> Security Class Initialized
DEBUG - 2016-11-21 15:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:42:08 --> Input Class Initialized
INFO - 2016-11-21 15:42:08 --> Language Class Initialized
INFO - 2016-11-21 15:42:08 --> Loader Class Initialized
INFO - 2016-11-21 15:42:08 --> Helper loaded: url_helper
INFO - 2016-11-21 15:42:08 --> Helper loaded: form_helper
INFO - 2016-11-21 15:42:09 --> Database Driver Class Initialized
INFO - 2016-11-21 15:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:42:09 --> Controller Class Initialized
INFO - 2016-11-21 15:42:09 --> Model Class Initialized
INFO - 2016-11-21 15:42:09 --> Model Class Initialized
INFO - 2016-11-21 15:42:09 --> Model Class Initialized
INFO - 2016-11-21 15:42:09 --> Model Class Initialized
INFO - 2016-11-21 15:42:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:42:09 --> Pagination Class Initialized
INFO - 2016-11-21 15:42:09 --> Helper loaded: app_helper
INFO - 2016-11-21 15:42:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 15:42:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 15:42:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 15:42:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 15:42:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 15:42:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 15:42:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:42:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 15:42:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 15:42:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 15:42:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 15:42:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 15:42:09 --> Final output sent to browser
DEBUG - 2016-11-21 15:42:09 --> Total execution time: 0.5726
INFO - 2016-11-21 15:42:15 --> Config Class Initialized
INFO - 2016-11-21 15:42:15 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:42:15 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:42:15 --> Utf8 Class Initialized
INFO - 2016-11-21 15:42:15 --> URI Class Initialized
INFO - 2016-11-21 15:42:15 --> Router Class Initialized
INFO - 2016-11-21 15:42:15 --> Output Class Initialized
INFO - 2016-11-21 15:42:15 --> Security Class Initialized
DEBUG - 2016-11-21 15:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:42:15 --> Input Class Initialized
INFO - 2016-11-21 15:42:15 --> Language Class Initialized
INFO - 2016-11-21 15:42:15 --> Loader Class Initialized
INFO - 2016-11-21 15:42:15 --> Helper loaded: url_helper
INFO - 2016-11-21 15:42:15 --> Helper loaded: form_helper
INFO - 2016-11-21 15:42:15 --> Database Driver Class Initialized
INFO - 2016-11-21 15:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:42:15 --> Controller Class Initialized
INFO - 2016-11-21 15:42:15 --> Model Class Initialized
INFO - 2016-11-21 15:42:15 --> Form Validation Class Initialized
INFO - 2016-11-21 15:42:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:42:15 --> Pagination Class Initialized
INFO - 2016-11-21 15:42:15 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:42:15 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:42:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:42:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:42:16 --> Final output sent to browser
DEBUG - 2016-11-21 15:42:16 --> Total execution time: 0.4867
INFO - 2016-11-21 15:42:30 --> Config Class Initialized
INFO - 2016-11-21 15:42:30 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:42:30 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:42:30 --> Utf8 Class Initialized
INFO - 2016-11-21 15:42:30 --> URI Class Initialized
DEBUG - 2016-11-21 15:42:30 --> No URI present. Default controller set.
INFO - 2016-11-21 15:42:30 --> Router Class Initialized
INFO - 2016-11-21 15:42:30 --> Output Class Initialized
INFO - 2016-11-21 15:42:31 --> Security Class Initialized
DEBUG - 2016-11-21 15:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:42:31 --> Input Class Initialized
INFO - 2016-11-21 15:42:31 --> Language Class Initialized
INFO - 2016-11-21 15:42:31 --> Loader Class Initialized
INFO - 2016-11-21 15:42:31 --> Helper loaded: url_helper
INFO - 2016-11-21 15:42:31 --> Helper loaded: form_helper
INFO - 2016-11-21 15:42:31 --> Database Driver Class Initialized
INFO - 2016-11-21 15:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:42:31 --> Controller Class Initialized
INFO - 2016-11-21 15:42:31 --> Model Class Initialized
INFO - 2016-11-21 15:42:31 --> Model Class Initialized
INFO - 2016-11-21 15:42:31 --> Model Class Initialized
INFO - 2016-11-21 15:42:31 --> Model Class Initialized
INFO - 2016-11-21 15:42:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:42:31 --> Pagination Class Initialized
INFO - 2016-11-21 15:42:31 --> Helper loaded: app_helper
INFO - 2016-11-21 15:42:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 15:42:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 15:42:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 15:42:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 15:42:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 15:42:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 15:42:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:42:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 15:42:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 15:42:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 15:42:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 15:42:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 15:42:31 --> Final output sent to browser
DEBUG - 2016-11-21 15:42:31 --> Total execution time: 0.6900
INFO - 2016-11-21 15:42:37 --> Config Class Initialized
INFO - 2016-11-21 15:42:37 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:42:37 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:42:37 --> Utf8 Class Initialized
INFO - 2016-11-21 15:42:37 --> URI Class Initialized
DEBUG - 2016-11-21 15:42:37 --> No URI present. Default controller set.
INFO - 2016-11-21 15:42:37 --> Router Class Initialized
INFO - 2016-11-21 15:42:37 --> Output Class Initialized
INFO - 2016-11-21 15:42:37 --> Security Class Initialized
DEBUG - 2016-11-21 15:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:42:37 --> Input Class Initialized
INFO - 2016-11-21 15:42:37 --> Language Class Initialized
INFO - 2016-11-21 15:42:37 --> Loader Class Initialized
INFO - 2016-11-21 15:42:37 --> Helper loaded: url_helper
INFO - 2016-11-21 15:42:38 --> Helper loaded: form_helper
INFO - 2016-11-21 15:42:38 --> Database Driver Class Initialized
INFO - 2016-11-21 15:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:42:38 --> Controller Class Initialized
INFO - 2016-11-21 15:42:38 --> Model Class Initialized
INFO - 2016-11-21 15:42:38 --> Model Class Initialized
INFO - 2016-11-21 15:42:38 --> Model Class Initialized
INFO - 2016-11-21 15:42:38 --> Model Class Initialized
INFO - 2016-11-21 15:42:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:42:38 --> Pagination Class Initialized
INFO - 2016-11-21 15:42:38 --> Helper loaded: app_helper
INFO - 2016-11-21 15:42:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 15:42:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 15:42:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 15:42:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 15:42:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 15:42:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 15:42:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:42:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 15:42:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 15:42:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 15:42:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 15:42:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 15:42:38 --> Final output sent to browser
DEBUG - 2016-11-21 15:42:38 --> Total execution time: 0.5992
INFO - 2016-11-21 15:42:45 --> Config Class Initialized
INFO - 2016-11-21 15:42:45 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:42:45 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:42:45 --> Utf8 Class Initialized
INFO - 2016-11-21 15:42:45 --> URI Class Initialized
INFO - 2016-11-21 15:42:45 --> Router Class Initialized
INFO - 2016-11-21 15:42:45 --> Output Class Initialized
INFO - 2016-11-21 15:42:45 --> Security Class Initialized
DEBUG - 2016-11-21 15:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:42:45 --> Input Class Initialized
INFO - 2016-11-21 15:42:45 --> Language Class Initialized
INFO - 2016-11-21 15:42:45 --> Loader Class Initialized
INFO - 2016-11-21 15:42:45 --> Helper loaded: url_helper
INFO - 2016-11-21 15:42:45 --> Helper loaded: form_helper
INFO - 2016-11-21 15:42:45 --> Database Driver Class Initialized
INFO - 2016-11-21 15:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:42:45 --> Controller Class Initialized
INFO - 2016-11-21 15:42:45 --> Model Class Initialized
INFO - 2016-11-21 15:42:45 --> Form Validation Class Initialized
INFO - 2016-11-21 15:42:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:42:45 --> Pagination Class Initialized
INFO - 2016-11-21 15:42:45 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:42:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:42:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:42:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:42:45 --> Final output sent to browser
DEBUG - 2016-11-21 15:42:45 --> Total execution time: 0.3521
INFO - 2016-11-21 15:44:04 --> Config Class Initialized
INFO - 2016-11-21 15:44:04 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:44:04 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:44:04 --> Utf8 Class Initialized
INFO - 2016-11-21 15:44:04 --> URI Class Initialized
INFO - 2016-11-21 15:44:04 --> Router Class Initialized
INFO - 2016-11-21 15:44:04 --> Output Class Initialized
INFO - 2016-11-21 15:44:04 --> Security Class Initialized
DEBUG - 2016-11-21 15:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:44:04 --> Input Class Initialized
INFO - 2016-11-21 15:44:04 --> Language Class Initialized
INFO - 2016-11-21 15:44:04 --> Loader Class Initialized
INFO - 2016-11-21 15:44:04 --> Helper loaded: url_helper
INFO - 2016-11-21 15:44:04 --> Helper loaded: form_helper
INFO - 2016-11-21 15:44:04 --> Database Driver Class Initialized
INFO - 2016-11-21 15:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:44:04 --> Controller Class Initialized
INFO - 2016-11-21 15:44:04 --> Model Class Initialized
INFO - 2016-11-21 15:44:04 --> Form Validation Class Initialized
INFO - 2016-11-21 15:44:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:44:04 --> Pagination Class Initialized
INFO - 2016-11-21 15:44:04 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:44:04 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:44:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:44:04 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:44:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:44:04 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:44:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:44:04 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:44:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:44:04 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:44:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:44:04 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:44:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:44:04 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:44:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:44:04 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:44:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:44:04 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:44:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:44:04 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:44:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:44:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:44:04 --> Final output sent to browser
DEBUG - 2016-11-21 15:44:04 --> Total execution time: 0.6543
INFO - 2016-11-21 15:44:24 --> Config Class Initialized
INFO - 2016-11-21 15:44:24 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:44:24 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:44:24 --> Utf8 Class Initialized
INFO - 2016-11-21 15:44:24 --> URI Class Initialized
INFO - 2016-11-21 15:44:24 --> Router Class Initialized
INFO - 2016-11-21 15:44:24 --> Output Class Initialized
INFO - 2016-11-21 15:44:24 --> Security Class Initialized
DEBUG - 2016-11-21 15:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:44:24 --> Input Class Initialized
INFO - 2016-11-21 15:44:24 --> Language Class Initialized
INFO - 2016-11-21 15:44:24 --> Loader Class Initialized
INFO - 2016-11-21 15:44:24 --> Helper loaded: url_helper
INFO - 2016-11-21 15:44:24 --> Helper loaded: form_helper
INFO - 2016-11-21 15:44:24 --> Database Driver Class Initialized
INFO - 2016-11-21 15:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:44:24 --> Controller Class Initialized
INFO - 2016-11-21 15:44:24 --> Model Class Initialized
INFO - 2016-11-21 15:44:24 --> Form Validation Class Initialized
INFO - 2016-11-21 15:44:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:44:24 --> Pagination Class Initialized
INFO - 2016-11-21 15:44:24 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:44:24 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:44:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:44:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:44:24 --> Final output sent to browser
DEBUG - 2016-11-21 15:44:24 --> Total execution time: 0.6166
INFO - 2016-11-21 15:45:04 --> Config Class Initialized
INFO - 2016-11-21 15:45:04 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:45:04 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:45:04 --> Utf8 Class Initialized
INFO - 2016-11-21 15:45:04 --> URI Class Initialized
DEBUG - 2016-11-21 15:45:04 --> No URI present. Default controller set.
INFO - 2016-11-21 15:45:04 --> Router Class Initialized
INFO - 2016-11-21 15:45:04 --> Output Class Initialized
INFO - 2016-11-21 15:45:04 --> Security Class Initialized
DEBUG - 2016-11-21 15:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:45:04 --> Input Class Initialized
INFO - 2016-11-21 15:45:04 --> Language Class Initialized
INFO - 2016-11-21 15:45:04 --> Loader Class Initialized
INFO - 2016-11-21 15:45:04 --> Helper loaded: url_helper
INFO - 2016-11-21 15:45:04 --> Helper loaded: form_helper
INFO - 2016-11-21 15:45:04 --> Database Driver Class Initialized
INFO - 2016-11-21 15:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:45:04 --> Controller Class Initialized
INFO - 2016-11-21 15:45:04 --> Model Class Initialized
INFO - 2016-11-21 15:45:04 --> Model Class Initialized
INFO - 2016-11-21 15:45:04 --> Model Class Initialized
INFO - 2016-11-21 15:45:04 --> Model Class Initialized
INFO - 2016-11-21 15:45:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:45:04 --> Pagination Class Initialized
INFO - 2016-11-21 15:45:04 --> Helper loaded: app_helper
INFO - 2016-11-21 15:45:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 15:45:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 15:45:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 15:45:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 15:45:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 15:45:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 15:45:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:45:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 15:45:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 15:45:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 15:45:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 15:45:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 15:45:04 --> Final output sent to browser
DEBUG - 2016-11-21 15:45:04 --> Total execution time: 0.5559
INFO - 2016-11-21 15:45:12 --> Config Class Initialized
INFO - 2016-11-21 15:45:12 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:45:12 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:45:12 --> Utf8 Class Initialized
INFO - 2016-11-21 15:45:12 --> URI Class Initialized
INFO - 2016-11-21 15:45:12 --> Router Class Initialized
INFO - 2016-11-21 15:45:12 --> Output Class Initialized
INFO - 2016-11-21 15:45:12 --> Security Class Initialized
DEBUG - 2016-11-21 15:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:45:12 --> Input Class Initialized
INFO - 2016-11-21 15:45:12 --> Language Class Initialized
INFO - 2016-11-21 15:45:12 --> Loader Class Initialized
INFO - 2016-11-21 15:45:12 --> Helper loaded: url_helper
INFO - 2016-11-21 15:45:12 --> Helper loaded: form_helper
INFO - 2016-11-21 15:45:12 --> Database Driver Class Initialized
INFO - 2016-11-21 15:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:45:12 --> Controller Class Initialized
INFO - 2016-11-21 15:45:12 --> Model Class Initialized
INFO - 2016-11-21 15:45:12 --> Form Validation Class Initialized
INFO - 2016-11-21 15:45:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:45:12 --> Pagination Class Initialized
INFO - 2016-11-21 15:45:12 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:45:12 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:45:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:45:12 --> Final output sent to browser
DEBUG - 2016-11-21 15:45:12 --> Total execution time: 0.5638
INFO - 2016-11-21 15:47:49 --> Config Class Initialized
INFO - 2016-11-21 15:47:49 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:47:49 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:47:49 --> Utf8 Class Initialized
INFO - 2016-11-21 15:47:49 --> URI Class Initialized
DEBUG - 2016-11-21 15:47:49 --> No URI present. Default controller set.
INFO - 2016-11-21 15:47:49 --> Router Class Initialized
INFO - 2016-11-21 15:47:49 --> Output Class Initialized
INFO - 2016-11-21 15:47:49 --> Security Class Initialized
DEBUG - 2016-11-21 15:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:47:49 --> Input Class Initialized
INFO - 2016-11-21 15:47:49 --> Language Class Initialized
INFO - 2016-11-21 15:47:49 --> Loader Class Initialized
INFO - 2016-11-21 15:47:49 --> Helper loaded: url_helper
INFO - 2016-11-21 15:47:49 --> Helper loaded: form_helper
INFO - 2016-11-21 15:47:49 --> Database Driver Class Initialized
INFO - 2016-11-21 15:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:47:49 --> Controller Class Initialized
INFO - 2016-11-21 15:47:49 --> Model Class Initialized
INFO - 2016-11-21 15:47:49 --> Model Class Initialized
INFO - 2016-11-21 15:47:49 --> Model Class Initialized
INFO - 2016-11-21 15:47:49 --> Model Class Initialized
INFO - 2016-11-21 15:47:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:47:49 --> Pagination Class Initialized
INFO - 2016-11-21 15:47:49 --> Helper loaded: app_helper
INFO - 2016-11-21 15:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 15:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 15:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 15:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 15:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 15:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 15:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 15:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 15:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 15:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 15:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 15:47:49 --> Final output sent to browser
DEBUG - 2016-11-21 15:47:49 --> Total execution time: 0.6272
INFO - 2016-11-21 15:47:55 --> Config Class Initialized
INFO - 2016-11-21 15:47:55 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:47:55 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:47:55 --> Utf8 Class Initialized
INFO - 2016-11-21 15:47:55 --> URI Class Initialized
INFO - 2016-11-21 15:47:55 --> Router Class Initialized
INFO - 2016-11-21 15:47:55 --> Output Class Initialized
INFO - 2016-11-21 15:47:55 --> Security Class Initialized
DEBUG - 2016-11-21 15:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:47:55 --> Input Class Initialized
INFO - 2016-11-21 15:47:55 --> Language Class Initialized
INFO - 2016-11-21 15:47:55 --> Loader Class Initialized
INFO - 2016-11-21 15:47:55 --> Helper loaded: url_helper
INFO - 2016-11-21 15:47:55 --> Helper loaded: form_helper
INFO - 2016-11-21 15:47:55 --> Database Driver Class Initialized
INFO - 2016-11-21 15:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:47:55 --> Controller Class Initialized
INFO - 2016-11-21 15:47:55 --> Model Class Initialized
INFO - 2016-11-21 15:47:55 --> Form Validation Class Initialized
INFO - 2016-11-21 15:47:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:47:55 --> Pagination Class Initialized
INFO - 2016-11-21 15:47:55 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:47:55 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:47:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:47:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:47:56 --> Final output sent to browser
DEBUG - 2016-11-21 15:47:56 --> Total execution time: 0.5647
INFO - 2016-11-21 15:50:23 --> Config Class Initialized
INFO - 2016-11-21 15:50:23 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:50:23 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:50:23 --> Utf8 Class Initialized
INFO - 2016-11-21 15:50:23 --> URI Class Initialized
DEBUG - 2016-11-21 15:50:23 --> No URI present. Default controller set.
INFO - 2016-11-21 15:50:23 --> Router Class Initialized
INFO - 2016-11-21 15:50:23 --> Output Class Initialized
INFO - 2016-11-21 15:50:23 --> Security Class Initialized
DEBUG - 2016-11-21 15:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:50:23 --> Input Class Initialized
INFO - 2016-11-21 15:50:23 --> Language Class Initialized
INFO - 2016-11-21 15:50:23 --> Loader Class Initialized
INFO - 2016-11-21 15:50:23 --> Helper loaded: url_helper
INFO - 2016-11-21 15:50:23 --> Helper loaded: form_helper
INFO - 2016-11-21 15:50:23 --> Database Driver Class Initialized
INFO - 2016-11-21 15:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:50:23 --> Controller Class Initialized
INFO - 2016-11-21 15:50:23 --> Model Class Initialized
INFO - 2016-11-21 15:50:23 --> Model Class Initialized
INFO - 2016-11-21 15:50:23 --> Model Class Initialized
INFO - 2016-11-21 15:50:23 --> Model Class Initialized
INFO - 2016-11-21 15:50:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:50:23 --> Pagination Class Initialized
INFO - 2016-11-21 15:50:23 --> Helper loaded: app_helper
INFO - 2016-11-21 15:50:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 15:50:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 15:50:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 15:50:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 15:50:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 15:50:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 15:50:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:50:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 15:50:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 15:50:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 15:50:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 15:50:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 15:50:24 --> Final output sent to browser
DEBUG - 2016-11-21 15:50:24 --> Total execution time: 0.6118
INFO - 2016-11-21 15:50:33 --> Config Class Initialized
INFO - 2016-11-21 15:50:33 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:50:33 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:50:33 --> Utf8 Class Initialized
INFO - 2016-11-21 15:50:33 --> URI Class Initialized
INFO - 2016-11-21 15:50:33 --> Router Class Initialized
INFO - 2016-11-21 15:50:33 --> Output Class Initialized
INFO - 2016-11-21 15:50:33 --> Security Class Initialized
DEBUG - 2016-11-21 15:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:50:33 --> Input Class Initialized
INFO - 2016-11-21 15:50:33 --> Language Class Initialized
INFO - 2016-11-21 15:50:33 --> Loader Class Initialized
INFO - 2016-11-21 15:50:33 --> Helper loaded: url_helper
INFO - 2016-11-21 15:50:33 --> Helper loaded: form_helper
INFO - 2016-11-21 15:50:34 --> Database Driver Class Initialized
INFO - 2016-11-21 15:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:50:34 --> Controller Class Initialized
INFO - 2016-11-21 15:50:34 --> Model Class Initialized
INFO - 2016-11-21 15:50:34 --> Form Validation Class Initialized
INFO - 2016-11-21 15:50:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:50:34 --> Pagination Class Initialized
INFO - 2016-11-21 15:50:34 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:50:34 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:50:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:50:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:50:34 --> Final output sent to browser
DEBUG - 2016-11-21 15:50:34 --> Total execution time: 0.3608
INFO - 2016-11-21 15:50:38 --> Config Class Initialized
INFO - 2016-11-21 15:50:38 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:50:38 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:50:38 --> Utf8 Class Initialized
INFO - 2016-11-21 15:50:38 --> URI Class Initialized
INFO - 2016-11-21 15:50:38 --> Router Class Initialized
INFO - 2016-11-21 15:50:38 --> Output Class Initialized
INFO - 2016-11-21 15:50:38 --> Security Class Initialized
DEBUG - 2016-11-21 15:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:50:38 --> Input Class Initialized
INFO - 2016-11-21 15:50:38 --> Language Class Initialized
INFO - 2016-11-21 15:50:38 --> Loader Class Initialized
INFO - 2016-11-21 15:50:38 --> Helper loaded: url_helper
INFO - 2016-11-21 15:50:38 --> Helper loaded: form_helper
INFO - 2016-11-21 15:50:38 --> Database Driver Class Initialized
INFO - 2016-11-21 15:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:50:38 --> Controller Class Initialized
INFO - 2016-11-21 15:50:38 --> Model Class Initialized
INFO - 2016-11-21 15:50:38 --> Form Validation Class Initialized
INFO - 2016-11-21 15:50:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:50:38 --> Pagination Class Initialized
INFO - 2016-11-21 15:50:38 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:50:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:50:38 --> Config Class Initialized
ERROR - 2016-11-21 15:50:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:50:38 --> Hooks Class Initialized
ERROR - 2016-11-21 15:50:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
DEBUG - 2016-11-21 15:50:38 --> UTF-8 Support Enabled
ERROR - 2016-11-21 15:50:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:50:38 --> Utf8 Class Initialized
ERROR - 2016-11-21 15:50:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:50:38 --> URI Class Initialized
ERROR - 2016-11-21 15:50:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:50:38 --> Router Class Initialized
ERROR - 2016-11-21 15:50:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:50:38 --> Output Class Initialized
ERROR - 2016-11-21 15:50:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:50:38 --> Security Class Initialized
ERROR - 2016-11-21 15:50:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
DEBUG - 2016-11-21 15:50:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-11-21 15:50:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:50:38 --> Input Class Initialized
INFO - 2016-11-21 15:50:38 --> Language Class Initialized
ERROR - 2016-11-21 15:50:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:50:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:50:39 --> Loader Class Initialized
ERROR - 2016-11-21 15:50:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:50:39 --> Helper loaded: url_helper
ERROR - 2016-11-21 15:50:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:50:39 --> Helper loaded: form_helper
ERROR - 2016-11-21 15:50:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:50:39 --> Database Driver Class Initialized
ERROR - 2016-11-21 15:50:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:50:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:50:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:50:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:50:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:50:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:50:39 --> Final output sent to browser
DEBUG - 2016-11-21 15:50:39 --> Total execution time: 0.9743
INFO - 2016-11-21 15:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:50:39 --> Controller Class Initialized
INFO - 2016-11-21 15:50:39 --> Model Class Initialized
INFO - 2016-11-21 15:50:39 --> Form Validation Class Initialized
INFO - 2016-11-21 15:50:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:50:39 --> Pagination Class Initialized
INFO - 2016-11-21 15:50:39 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:50:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:50:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:50:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:50:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:50:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:50:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:50:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:50:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:50:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:50:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:50:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:50:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:50:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:50:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:50:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:50:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:50:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:50:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:50:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:50:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:50:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:50:39 --> Final output sent to browser
DEBUG - 2016-11-21 15:50:39 --> Total execution time: 1.1608
INFO - 2016-11-21 15:52:24 --> Config Class Initialized
INFO - 2016-11-21 15:52:24 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:52:24 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:52:24 --> Utf8 Class Initialized
INFO - 2016-11-21 15:52:24 --> URI Class Initialized
DEBUG - 2016-11-21 15:52:24 --> No URI present. Default controller set.
INFO - 2016-11-21 15:52:24 --> Router Class Initialized
INFO - 2016-11-21 15:52:24 --> Output Class Initialized
INFO - 2016-11-21 15:52:24 --> Security Class Initialized
DEBUG - 2016-11-21 15:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:52:25 --> Input Class Initialized
INFO - 2016-11-21 15:52:25 --> Language Class Initialized
INFO - 2016-11-21 15:52:25 --> Loader Class Initialized
INFO - 2016-11-21 15:52:25 --> Helper loaded: url_helper
INFO - 2016-11-21 15:52:25 --> Helper loaded: form_helper
INFO - 2016-11-21 15:52:25 --> Database Driver Class Initialized
INFO - 2016-11-21 15:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:52:25 --> Controller Class Initialized
INFO - 2016-11-21 15:52:25 --> Model Class Initialized
INFO - 2016-11-21 15:52:25 --> Model Class Initialized
INFO - 2016-11-21 15:52:25 --> Model Class Initialized
INFO - 2016-11-21 15:52:25 --> Model Class Initialized
INFO - 2016-11-21 15:52:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:52:25 --> Pagination Class Initialized
INFO - 2016-11-21 15:52:25 --> Helper loaded: app_helper
INFO - 2016-11-21 15:52:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 15:52:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 15:52:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 15:52:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 15:52:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 15:52:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 15:52:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:52:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 15:52:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 15:52:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 15:52:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 15:52:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 15:52:25 --> Final output sent to browser
DEBUG - 2016-11-21 15:52:25 --> Total execution time: 0.6192
INFO - 2016-11-21 15:54:44 --> Config Class Initialized
INFO - 2016-11-21 15:54:44 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:54:44 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:54:44 --> Utf8 Class Initialized
INFO - 2016-11-21 15:54:44 --> URI Class Initialized
INFO - 2016-11-21 15:54:44 --> Router Class Initialized
INFO - 2016-11-21 15:54:44 --> Output Class Initialized
INFO - 2016-11-21 15:54:44 --> Security Class Initialized
DEBUG - 2016-11-21 15:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:54:44 --> Input Class Initialized
INFO - 2016-11-21 15:54:45 --> Language Class Initialized
INFO - 2016-11-21 15:54:45 --> Loader Class Initialized
INFO - 2016-11-21 15:54:45 --> Helper loaded: url_helper
INFO - 2016-11-21 15:54:45 --> Helper loaded: form_helper
INFO - 2016-11-21 15:54:45 --> Database Driver Class Initialized
INFO - 2016-11-21 15:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:54:45 --> Controller Class Initialized
INFO - 2016-11-21 15:54:45 --> Model Class Initialized
INFO - 2016-11-21 15:54:45 --> Form Validation Class Initialized
INFO - 2016-11-21 15:54:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:54:45 --> Pagination Class Initialized
INFO - 2016-11-21 15:54:45 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:54:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:54:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:54:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:54:45 --> Final output sent to browser
DEBUG - 2016-11-21 15:54:45 --> Total execution time: 0.5171
INFO - 2016-11-21 15:54:56 --> Config Class Initialized
INFO - 2016-11-21 15:54:56 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:54:56 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:54:56 --> Utf8 Class Initialized
INFO - 2016-11-21 15:54:56 --> URI Class Initialized
INFO - 2016-11-21 15:54:56 --> Router Class Initialized
INFO - 2016-11-21 15:54:56 --> Output Class Initialized
INFO - 2016-11-21 15:54:56 --> Security Class Initialized
DEBUG - 2016-11-21 15:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:54:57 --> Input Class Initialized
INFO - 2016-11-21 15:54:57 --> Language Class Initialized
INFO - 2016-11-21 15:54:57 --> Loader Class Initialized
INFO - 2016-11-21 15:54:57 --> Helper loaded: url_helper
INFO - 2016-11-21 15:54:57 --> Helper loaded: form_helper
INFO - 2016-11-21 15:54:57 --> Database Driver Class Initialized
INFO - 2016-11-21 15:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:54:57 --> Controller Class Initialized
INFO - 2016-11-21 15:54:57 --> Model Class Initialized
INFO - 2016-11-21 15:54:57 --> Form Validation Class Initialized
INFO - 2016-11-21 15:54:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:54:57 --> Pagination Class Initialized
INFO - 2016-11-21 15:54:57 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:54:57 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:54:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:54:57 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:54:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:54:57 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:54:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:54:57 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:54:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:54:57 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:54:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:54:57 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:54:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:54:57 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:54:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:54:57 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:54:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:54:57 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:54:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:54:58 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:54:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:54:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:54:58 --> Final output sent to browser
DEBUG - 2016-11-21 15:54:58 --> Total execution time: 1.2265
INFO - 2016-11-21 15:55:17 --> Config Class Initialized
INFO - 2016-11-21 15:55:17 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:55:17 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:55:17 --> Utf8 Class Initialized
INFO - 2016-11-21 15:55:17 --> URI Class Initialized
INFO - 2016-11-21 15:55:17 --> Router Class Initialized
INFO - 2016-11-21 15:55:17 --> Output Class Initialized
INFO - 2016-11-21 15:55:17 --> Security Class Initialized
DEBUG - 2016-11-21 15:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:55:18 --> Input Class Initialized
INFO - 2016-11-21 15:55:18 --> Language Class Initialized
INFO - 2016-11-21 15:55:18 --> Loader Class Initialized
INFO - 2016-11-21 15:55:18 --> Helper loaded: url_helper
INFO - 2016-11-21 15:55:18 --> Helper loaded: form_helper
INFO - 2016-11-21 15:55:18 --> Database Driver Class Initialized
INFO - 2016-11-21 15:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:55:18 --> Controller Class Initialized
INFO - 2016-11-21 15:55:18 --> Model Class Initialized
INFO - 2016-11-21 15:55:18 --> Form Validation Class Initialized
INFO - 2016-11-21 15:55:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:55:18 --> Pagination Class Initialized
INFO - 2016-11-21 15:55:18 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:55:18 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:55:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:55:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:55:18 --> Final output sent to browser
DEBUG - 2016-11-21 15:55:18 --> Total execution time: 0.5935
INFO - 2016-11-21 15:55:28 --> Config Class Initialized
INFO - 2016-11-21 15:55:28 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:55:28 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:55:28 --> Utf8 Class Initialized
INFO - 2016-11-21 15:55:28 --> URI Class Initialized
INFO - 2016-11-21 15:55:28 --> Router Class Initialized
INFO - 2016-11-21 15:55:28 --> Output Class Initialized
INFO - 2016-11-21 15:55:28 --> Security Class Initialized
DEBUG - 2016-11-21 15:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:55:28 --> Input Class Initialized
INFO - 2016-11-21 15:55:28 --> Language Class Initialized
INFO - 2016-11-21 15:55:28 --> Loader Class Initialized
INFO - 2016-11-21 15:55:28 --> Helper loaded: url_helper
INFO - 2016-11-21 15:55:28 --> Helper loaded: form_helper
INFO - 2016-11-21 15:55:28 --> Database Driver Class Initialized
INFO - 2016-11-21 15:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:55:28 --> Controller Class Initialized
INFO - 2016-11-21 15:55:28 --> Model Class Initialized
INFO - 2016-11-21 15:55:28 --> Form Validation Class Initialized
INFO - 2016-11-21 15:55:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:55:28 --> Pagination Class Initialized
INFO - 2016-11-21 15:55:28 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:55:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:55:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:55:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:55:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:55:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:55:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:55:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:55:29 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:55:29 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:55:29 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:55:29 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:55:29 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:55:29 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:55:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:55:29 --> Final output sent to browser
DEBUG - 2016-11-21 15:55:29 --> Total execution time: 1.0032
INFO - 2016-11-21 15:56:27 --> Config Class Initialized
INFO - 2016-11-21 15:56:27 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:56:27 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:56:27 --> Utf8 Class Initialized
INFO - 2016-11-21 15:56:27 --> URI Class Initialized
DEBUG - 2016-11-21 15:56:27 --> No URI present. Default controller set.
INFO - 2016-11-21 15:56:27 --> Router Class Initialized
INFO - 2016-11-21 15:56:27 --> Output Class Initialized
INFO - 2016-11-21 15:56:27 --> Security Class Initialized
DEBUG - 2016-11-21 15:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:56:27 --> Input Class Initialized
INFO - 2016-11-21 15:56:27 --> Language Class Initialized
INFO - 2016-11-21 15:56:27 --> Loader Class Initialized
INFO - 2016-11-21 15:56:27 --> Helper loaded: url_helper
INFO - 2016-11-21 15:56:27 --> Helper loaded: form_helper
INFO - 2016-11-21 15:56:27 --> Database Driver Class Initialized
INFO - 2016-11-21 15:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:56:28 --> Controller Class Initialized
INFO - 2016-11-21 15:56:28 --> Model Class Initialized
INFO - 2016-11-21 15:56:28 --> Model Class Initialized
INFO - 2016-11-21 15:56:28 --> Model Class Initialized
INFO - 2016-11-21 15:56:28 --> Model Class Initialized
INFO - 2016-11-21 15:56:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:56:28 --> Pagination Class Initialized
INFO - 2016-11-21 15:56:28 --> Helper loaded: app_helper
INFO - 2016-11-21 15:56:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 15:56:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 15:56:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 15:56:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 15:56:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 15:56:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 15:56:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:56:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 15:56:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 15:56:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 15:56:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 15:56:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 15:56:28 --> Final output sent to browser
DEBUG - 2016-11-21 15:56:28 --> Total execution time: 0.6206
INFO - 2016-11-21 15:56:33 --> Config Class Initialized
INFO - 2016-11-21 15:56:33 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:56:33 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:56:33 --> Utf8 Class Initialized
INFO - 2016-11-21 15:56:33 --> URI Class Initialized
INFO - 2016-11-21 15:56:33 --> Router Class Initialized
INFO - 2016-11-21 15:56:33 --> Output Class Initialized
INFO - 2016-11-21 15:56:33 --> Security Class Initialized
DEBUG - 2016-11-21 15:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:56:33 --> Input Class Initialized
INFO - 2016-11-21 15:56:33 --> Language Class Initialized
INFO - 2016-11-21 15:56:33 --> Loader Class Initialized
INFO - 2016-11-21 15:56:33 --> Helper loaded: url_helper
INFO - 2016-11-21 15:56:33 --> Helper loaded: form_helper
INFO - 2016-11-21 15:56:33 --> Database Driver Class Initialized
INFO - 2016-11-21 15:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:56:33 --> Controller Class Initialized
INFO - 2016-11-21 15:56:33 --> Model Class Initialized
INFO - 2016-11-21 15:56:33 --> Form Validation Class Initialized
INFO - 2016-11-21 15:56:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:56:33 --> Pagination Class Initialized
INFO - 2016-11-21 15:56:33 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:56:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:56:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:56:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:56:33 --> Final output sent to browser
DEBUG - 2016-11-21 15:56:33 --> Total execution time: 0.5522
INFO - 2016-11-21 15:56:35 --> Config Class Initialized
INFO - 2016-11-21 15:56:35 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:56:35 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:56:36 --> Utf8 Class Initialized
INFO - 2016-11-21 15:56:36 --> URI Class Initialized
INFO - 2016-11-21 15:56:36 --> Router Class Initialized
INFO - 2016-11-21 15:56:36 --> Output Class Initialized
INFO - 2016-11-21 15:56:36 --> Security Class Initialized
DEBUG - 2016-11-21 15:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:56:36 --> Input Class Initialized
INFO - 2016-11-21 15:56:36 --> Language Class Initialized
INFO - 2016-11-21 15:56:36 --> Loader Class Initialized
INFO - 2016-11-21 15:56:36 --> Helper loaded: url_helper
INFO - 2016-11-21 15:56:36 --> Helper loaded: form_helper
INFO - 2016-11-21 15:56:36 --> Database Driver Class Initialized
INFO - 2016-11-21 15:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:56:36 --> Controller Class Initialized
INFO - 2016-11-21 15:56:36 --> Model Class Initialized
INFO - 2016-11-21 15:56:36 --> Form Validation Class Initialized
INFO - 2016-11-21 15:56:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:56:36 --> Pagination Class Initialized
INFO - 2016-11-21 15:56:36 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:56:36 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:56:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:56:36 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:56:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:56:36 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:56:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:56:36 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:56:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:56:36 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:56:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:56:36 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:56:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:56:36 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:56:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:56:37 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:56:37 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:56:37 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:56:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:56:37 --> Final output sent to browser
DEBUG - 2016-11-21 15:56:37 --> Total execution time: 1.1949
INFO - 2016-11-21 15:56:51 --> Config Class Initialized
INFO - 2016-11-21 15:56:51 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:56:51 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:56:51 --> Utf8 Class Initialized
INFO - 2016-11-21 15:56:51 --> URI Class Initialized
INFO - 2016-11-21 15:56:51 --> Router Class Initialized
INFO - 2016-11-21 15:56:51 --> Output Class Initialized
INFO - 2016-11-21 15:56:51 --> Security Class Initialized
DEBUG - 2016-11-21 15:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:56:51 --> Input Class Initialized
INFO - 2016-11-21 15:56:51 --> Language Class Initialized
INFO - 2016-11-21 15:56:51 --> Loader Class Initialized
INFO - 2016-11-21 15:56:51 --> Helper loaded: url_helper
INFO - 2016-11-21 15:56:51 --> Helper loaded: form_helper
INFO - 2016-11-21 15:56:51 --> Database Driver Class Initialized
INFO - 2016-11-21 15:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:56:52 --> Controller Class Initialized
INFO - 2016-11-21 15:56:52 --> Model Class Initialized
INFO - 2016-11-21 15:56:52 --> Form Validation Class Initialized
INFO - 2016-11-21 15:56:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:56:52 --> Pagination Class Initialized
INFO - 2016-11-21 15:56:52 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:56:52 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:56:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:56:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:56:52 --> Final output sent to browser
DEBUG - 2016-11-21 15:56:52 --> Total execution time: 0.5290
INFO - 2016-11-21 15:57:20 --> Config Class Initialized
INFO - 2016-11-21 15:57:20 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:57:20 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:57:20 --> Utf8 Class Initialized
INFO - 2016-11-21 15:57:20 --> URI Class Initialized
INFO - 2016-11-21 15:57:20 --> Router Class Initialized
INFO - 2016-11-21 15:57:20 --> Output Class Initialized
INFO - 2016-11-21 15:57:20 --> Security Class Initialized
DEBUG - 2016-11-21 15:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:57:20 --> Input Class Initialized
INFO - 2016-11-21 15:57:20 --> Language Class Initialized
INFO - 2016-11-21 15:57:20 --> Loader Class Initialized
INFO - 2016-11-21 15:57:20 --> Helper loaded: url_helper
INFO - 2016-11-21 15:57:20 --> Helper loaded: form_helper
INFO - 2016-11-21 15:57:20 --> Database Driver Class Initialized
INFO - 2016-11-21 15:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:57:20 --> Controller Class Initialized
INFO - 2016-11-21 15:57:20 --> Model Class Initialized
INFO - 2016-11-21 15:57:20 --> Form Validation Class Initialized
INFO - 2016-11-21 15:57:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:57:20 --> Pagination Class Initialized
INFO - 2016-11-21 15:57:20 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:57:20 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:57:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:57:20 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:57:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:57:20 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:57:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:57:20 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:57:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:57:20 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:57:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:57:20 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:57:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:57:20 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:57:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:57:20 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:57:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:57:21 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:57:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:57:21 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:57:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:57:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:57:21 --> Final output sent to browser
DEBUG - 2016-11-21 15:57:21 --> Total execution time: 0.9795
INFO - 2016-11-21 15:57:27 --> Config Class Initialized
INFO - 2016-11-21 15:57:27 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:57:27 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:57:27 --> Utf8 Class Initialized
INFO - 2016-11-21 15:57:27 --> URI Class Initialized
INFO - 2016-11-21 15:57:27 --> Router Class Initialized
INFO - 2016-11-21 15:57:27 --> Output Class Initialized
INFO - 2016-11-21 15:57:28 --> Security Class Initialized
DEBUG - 2016-11-21 15:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:57:28 --> Input Class Initialized
INFO - 2016-11-21 15:57:28 --> Language Class Initialized
INFO - 2016-11-21 15:57:28 --> Loader Class Initialized
INFO - 2016-11-21 15:57:28 --> Helper loaded: url_helper
INFO - 2016-11-21 15:57:28 --> Helper loaded: form_helper
INFO - 2016-11-21 15:57:28 --> Database Driver Class Initialized
INFO - 2016-11-21 15:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:57:28 --> Controller Class Initialized
INFO - 2016-11-21 15:57:28 --> Model Class Initialized
INFO - 2016-11-21 15:57:28 --> Form Validation Class Initialized
INFO - 2016-11-21 15:57:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:57:28 --> Pagination Class Initialized
INFO - 2016-11-21 15:57:28 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:57:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:57:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:57:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:57:28 --> Final output sent to browser
DEBUG - 2016-11-21 15:57:28 --> Total execution time: 0.7789
INFO - 2016-11-21 15:57:54 --> Config Class Initialized
INFO - 2016-11-21 15:57:54 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:57:54 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:57:54 --> Utf8 Class Initialized
INFO - 2016-11-21 15:57:54 --> URI Class Initialized
DEBUG - 2016-11-21 15:57:54 --> No URI present. Default controller set.
INFO - 2016-11-21 15:57:54 --> Router Class Initialized
INFO - 2016-11-21 15:57:54 --> Output Class Initialized
INFO - 2016-11-21 15:57:54 --> Security Class Initialized
DEBUG - 2016-11-21 15:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:57:54 --> Input Class Initialized
INFO - 2016-11-21 15:57:54 --> Language Class Initialized
INFO - 2016-11-21 15:57:54 --> Loader Class Initialized
INFO - 2016-11-21 15:57:54 --> Helper loaded: url_helper
INFO - 2016-11-21 15:57:54 --> Helper loaded: form_helper
INFO - 2016-11-21 15:57:54 --> Database Driver Class Initialized
INFO - 2016-11-21 15:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:57:54 --> Controller Class Initialized
INFO - 2016-11-21 15:57:54 --> Model Class Initialized
INFO - 2016-11-21 15:57:54 --> Model Class Initialized
INFO - 2016-11-21 15:57:54 --> Model Class Initialized
INFO - 2016-11-21 15:57:54 --> Model Class Initialized
INFO - 2016-11-21 15:57:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:57:54 --> Pagination Class Initialized
INFO - 2016-11-21 15:57:54 --> Helper loaded: app_helper
INFO - 2016-11-21 15:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 15:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 15:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 15:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 15:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 15:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 15:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 15:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 15:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 15:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 15:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 15:57:54 --> Final output sent to browser
DEBUG - 2016-11-21 15:57:54 --> Total execution time: 0.6659
INFO - 2016-11-21 15:58:03 --> Config Class Initialized
INFO - 2016-11-21 15:58:03 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:58:03 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:58:03 --> Utf8 Class Initialized
INFO - 2016-11-21 15:58:03 --> URI Class Initialized
INFO - 2016-11-21 15:58:03 --> Router Class Initialized
INFO - 2016-11-21 15:58:03 --> Output Class Initialized
INFO - 2016-11-21 15:58:03 --> Security Class Initialized
DEBUG - 2016-11-21 15:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:58:03 --> Input Class Initialized
INFO - 2016-11-21 15:58:03 --> Language Class Initialized
INFO - 2016-11-21 15:58:03 --> Loader Class Initialized
INFO - 2016-11-21 15:58:03 --> Helper loaded: url_helper
INFO - 2016-11-21 15:58:03 --> Helper loaded: form_helper
INFO - 2016-11-21 15:58:04 --> Database Driver Class Initialized
INFO - 2016-11-21 15:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:58:04 --> Controller Class Initialized
INFO - 2016-11-21 15:58:04 --> Model Class Initialized
INFO - 2016-11-21 15:58:04 --> Form Validation Class Initialized
INFO - 2016-11-21 15:58:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:58:04 --> Pagination Class Initialized
INFO - 2016-11-21 15:58:04 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:58:04 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:58:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:58:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:58:04 --> Final output sent to browser
DEBUG - 2016-11-21 15:58:04 --> Total execution time: 0.4347
INFO - 2016-11-21 15:58:08 --> Config Class Initialized
INFO - 2016-11-21 15:58:08 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:58:08 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:58:08 --> Utf8 Class Initialized
INFO - 2016-11-21 15:58:08 --> URI Class Initialized
INFO - 2016-11-21 15:58:08 --> Router Class Initialized
INFO - 2016-11-21 15:58:08 --> Output Class Initialized
INFO - 2016-11-21 15:58:08 --> Security Class Initialized
DEBUG - 2016-11-21 15:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:58:08 --> Input Class Initialized
INFO - 2016-11-21 15:58:08 --> Language Class Initialized
INFO - 2016-11-21 15:58:08 --> Loader Class Initialized
INFO - 2016-11-21 15:58:08 --> Helper loaded: url_helper
INFO - 2016-11-21 15:58:08 --> Helper loaded: form_helper
INFO - 2016-11-21 15:58:08 --> Database Driver Class Initialized
INFO - 2016-11-21 15:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:58:08 --> Controller Class Initialized
INFO - 2016-11-21 15:58:08 --> Model Class Initialized
INFO - 2016-11-21 15:58:08 --> Form Validation Class Initialized
INFO - 2016-11-21 15:58:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:58:08 --> Pagination Class Initialized
INFO - 2016-11-21 15:58:08 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:58:08 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:58:08 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:58:08 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:58:09 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:58:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:58:09 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:58:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:58:09 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:58:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:58:09 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:58:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:58:09 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:58:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:58:09 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:58:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:58:09 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:58:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:58:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:58:09 --> Final output sent to browser
DEBUG - 2016-11-21 15:58:09 --> Total execution time: 0.6963
INFO - 2016-11-21 15:58:56 --> Config Class Initialized
INFO - 2016-11-21 15:58:56 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:58:56 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:58:56 --> Utf8 Class Initialized
INFO - 2016-11-21 15:58:56 --> URI Class Initialized
INFO - 2016-11-21 15:58:56 --> Router Class Initialized
INFO - 2016-11-21 15:58:56 --> Output Class Initialized
INFO - 2016-11-21 15:58:56 --> Security Class Initialized
DEBUG - 2016-11-21 15:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:58:56 --> Input Class Initialized
INFO - 2016-11-21 15:58:56 --> Language Class Initialized
INFO - 2016-11-21 15:58:56 --> Loader Class Initialized
INFO - 2016-11-21 15:58:56 --> Helper loaded: url_helper
INFO - 2016-11-21 15:58:56 --> Helper loaded: form_helper
INFO - 2016-11-21 15:58:56 --> Database Driver Class Initialized
INFO - 2016-11-21 15:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:58:56 --> Controller Class Initialized
INFO - 2016-11-21 15:58:56 --> Model Class Initialized
INFO - 2016-11-21 15:58:56 --> Form Validation Class Initialized
INFO - 2016-11-21 15:58:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:58:56 --> Pagination Class Initialized
INFO - 2016-11-21 15:58:56 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:58:56 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:58:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:58:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:58:56 --> Final output sent to browser
DEBUG - 2016-11-21 15:58:56 --> Total execution time: 0.5067
INFO - 2016-11-21 15:59:37 --> Config Class Initialized
INFO - 2016-11-21 15:59:37 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:59:37 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:59:37 --> Utf8 Class Initialized
INFO - 2016-11-21 15:59:37 --> URI Class Initialized
DEBUG - 2016-11-21 15:59:37 --> No URI present. Default controller set.
INFO - 2016-11-21 15:59:37 --> Router Class Initialized
INFO - 2016-11-21 15:59:37 --> Output Class Initialized
INFO - 2016-11-21 15:59:37 --> Security Class Initialized
DEBUG - 2016-11-21 15:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:59:37 --> Input Class Initialized
INFO - 2016-11-21 15:59:37 --> Language Class Initialized
INFO - 2016-11-21 15:59:37 --> Loader Class Initialized
INFO - 2016-11-21 15:59:37 --> Helper loaded: url_helper
INFO - 2016-11-21 15:59:37 --> Helper loaded: form_helper
INFO - 2016-11-21 15:59:37 --> Database Driver Class Initialized
INFO - 2016-11-21 15:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:59:37 --> Controller Class Initialized
INFO - 2016-11-21 15:59:37 --> Model Class Initialized
INFO - 2016-11-21 15:59:37 --> Model Class Initialized
INFO - 2016-11-21 15:59:37 --> Model Class Initialized
INFO - 2016-11-21 15:59:37 --> Model Class Initialized
INFO - 2016-11-21 15:59:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:59:37 --> Pagination Class Initialized
INFO - 2016-11-21 15:59:37 --> Helper loaded: app_helper
INFO - 2016-11-21 15:59:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 15:59:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 15:59:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 15:59:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 15:59:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 15:59:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 15:59:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:59:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 15:59:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 15:59:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 15:59:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 15:59:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 15:59:37 --> Final output sent to browser
DEBUG - 2016-11-21 15:59:38 --> Total execution time: 0.6570
INFO - 2016-11-21 15:59:41 --> Config Class Initialized
INFO - 2016-11-21 15:59:41 --> Hooks Class Initialized
DEBUG - 2016-11-21 15:59:41 --> UTF-8 Support Enabled
INFO - 2016-11-21 15:59:41 --> Utf8 Class Initialized
INFO - 2016-11-21 15:59:41 --> URI Class Initialized
INFO - 2016-11-21 15:59:41 --> Router Class Initialized
INFO - 2016-11-21 15:59:41 --> Output Class Initialized
INFO - 2016-11-21 15:59:41 --> Security Class Initialized
DEBUG - 2016-11-21 15:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 15:59:41 --> Input Class Initialized
INFO - 2016-11-21 15:59:41 --> Language Class Initialized
INFO - 2016-11-21 15:59:41 --> Loader Class Initialized
INFO - 2016-11-21 15:59:41 --> Helper loaded: url_helper
INFO - 2016-11-21 15:59:41 --> Helper loaded: form_helper
INFO - 2016-11-21 15:59:41 --> Database Driver Class Initialized
INFO - 2016-11-21 15:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 15:59:41 --> Controller Class Initialized
INFO - 2016-11-21 15:59:41 --> Model Class Initialized
INFO - 2016-11-21 15:59:41 --> Form Validation Class Initialized
INFO - 2016-11-21 15:59:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 15:59:41 --> Pagination Class Initialized
INFO - 2016-11-21 15:59:41 --> Helper loaded: app_helper
ERROR - 2016-11-21 15:59:41 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 15:59:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 15:59:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 15:59:42 --> Final output sent to browser
DEBUG - 2016-11-21 15:59:42 --> Total execution time: 0.4398
INFO - 2016-11-21 16:00:00 --> Config Class Initialized
INFO - 2016-11-21 16:00:01 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:00:01 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:00:01 --> Utf8 Class Initialized
INFO - 2016-11-21 16:00:01 --> URI Class Initialized
INFO - 2016-11-21 16:00:01 --> Router Class Initialized
INFO - 2016-11-21 16:00:01 --> Output Class Initialized
INFO - 2016-11-21 16:00:01 --> Security Class Initialized
DEBUG - 2016-11-21 16:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:00:01 --> Input Class Initialized
INFO - 2016-11-21 16:00:01 --> Language Class Initialized
INFO - 2016-11-21 16:00:01 --> Loader Class Initialized
INFO - 2016-11-21 16:00:01 --> Helper loaded: url_helper
INFO - 2016-11-21 16:00:01 --> Helper loaded: form_helper
INFO - 2016-11-21 16:00:01 --> Database Driver Class Initialized
INFO - 2016-11-21 16:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:00:01 --> Controller Class Initialized
INFO - 2016-11-21 16:00:01 --> Model Class Initialized
INFO - 2016-11-21 16:00:01 --> Form Validation Class Initialized
INFO - 2016-11-21 16:00:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:00:01 --> Pagination Class Initialized
INFO - 2016-11-21 16:00:01 --> Helper loaded: app_helper
ERROR - 2016-11-21 16:00:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 16:00:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 16:00:01 --> Final output sent to browser
DEBUG - 2016-11-21 16:00:01 --> Total execution time: 0.7988
INFO - 2016-11-21 16:00:06 --> Config Class Initialized
INFO - 2016-11-21 16:00:06 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:00:06 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:00:06 --> Utf8 Class Initialized
INFO - 2016-11-21 16:00:06 --> URI Class Initialized
DEBUG - 2016-11-21 16:00:06 --> No URI present. Default controller set.
INFO - 2016-11-21 16:00:06 --> Router Class Initialized
INFO - 2016-11-21 16:00:06 --> Output Class Initialized
INFO - 2016-11-21 16:00:06 --> Security Class Initialized
DEBUG - 2016-11-21 16:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:00:06 --> Input Class Initialized
INFO - 2016-11-21 16:00:06 --> Language Class Initialized
INFO - 2016-11-21 16:00:06 --> Loader Class Initialized
INFO - 2016-11-21 16:00:07 --> Helper loaded: url_helper
INFO - 2016-11-21 16:00:07 --> Helper loaded: form_helper
INFO - 2016-11-21 16:00:07 --> Database Driver Class Initialized
INFO - 2016-11-21 16:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:00:07 --> Controller Class Initialized
INFO - 2016-11-21 16:00:07 --> Model Class Initialized
INFO - 2016-11-21 16:00:07 --> Model Class Initialized
INFO - 2016-11-21 16:00:07 --> Model Class Initialized
INFO - 2016-11-21 16:00:07 --> Model Class Initialized
INFO - 2016-11-21 16:00:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:00:07 --> Pagination Class Initialized
INFO - 2016-11-21 16:00:07 --> Helper loaded: app_helper
INFO - 2016-11-21 16:00:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 16:00:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 16:00:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 16:00:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 16:00:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:00:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 16:00:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 16:00:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 16:00:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 16:00:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 16:00:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 16:00:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 16:00:07 --> Final output sent to browser
DEBUG - 2016-11-21 16:00:07 --> Total execution time: 0.6648
INFO - 2016-11-21 16:00:10 --> Config Class Initialized
INFO - 2016-11-21 16:00:10 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:00:10 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:00:10 --> Utf8 Class Initialized
INFO - 2016-11-21 16:00:10 --> URI Class Initialized
INFO - 2016-11-21 16:00:10 --> Router Class Initialized
INFO - 2016-11-21 16:00:10 --> Output Class Initialized
INFO - 2016-11-21 16:00:10 --> Security Class Initialized
DEBUG - 2016-11-21 16:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:00:10 --> Input Class Initialized
INFO - 2016-11-21 16:00:10 --> Language Class Initialized
INFO - 2016-11-21 16:00:10 --> Loader Class Initialized
INFO - 2016-11-21 16:00:10 --> Helper loaded: url_helper
INFO - 2016-11-21 16:00:10 --> Helper loaded: form_helper
INFO - 2016-11-21 16:00:10 --> Database Driver Class Initialized
INFO - 2016-11-21 16:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:00:10 --> Controller Class Initialized
INFO - 2016-11-21 16:00:10 --> Model Class Initialized
INFO - 2016-11-21 16:00:10 --> Form Validation Class Initialized
INFO - 2016-11-21 16:00:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:00:10 --> Pagination Class Initialized
INFO - 2016-11-21 16:00:10 --> Helper loaded: app_helper
ERROR - 2016-11-21 16:00:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 16:00:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 16:00:10 --> Final output sent to browser
DEBUG - 2016-11-21 16:00:10 --> Total execution time: 0.4837
INFO - 2016-11-21 16:00:12 --> Config Class Initialized
INFO - 2016-11-21 16:00:12 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:00:12 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:00:12 --> Utf8 Class Initialized
INFO - 2016-11-21 16:00:12 --> URI Class Initialized
INFO - 2016-11-21 16:00:12 --> Router Class Initialized
INFO - 2016-11-21 16:00:12 --> Output Class Initialized
INFO - 2016-11-21 16:00:12 --> Security Class Initialized
DEBUG - 2016-11-21 16:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:00:12 --> Input Class Initialized
INFO - 2016-11-21 16:00:13 --> Language Class Initialized
INFO - 2016-11-21 16:00:13 --> Loader Class Initialized
INFO - 2016-11-21 16:00:13 --> Helper loaded: url_helper
INFO - 2016-11-21 16:00:13 --> Helper loaded: form_helper
INFO - 2016-11-21 16:00:13 --> Database Driver Class Initialized
INFO - 2016-11-21 16:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:00:13 --> Controller Class Initialized
INFO - 2016-11-21 16:00:13 --> Model Class Initialized
INFO - 2016-11-21 16:00:13 --> Form Validation Class Initialized
INFO - 2016-11-21 16:00:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:00:13 --> Pagination Class Initialized
INFO - 2016-11-21 16:00:13 --> Helper loaded: app_helper
ERROR - 2016-11-21 16:00:13 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:13 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:13 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:13 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:13 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:13 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:13 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:13 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:13 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:13 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:00:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 16:00:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 16:00:13 --> Final output sent to browser
DEBUG - 2016-11-21 16:00:13 --> Total execution time: 0.8043
INFO - 2016-11-21 16:02:15 --> Config Class Initialized
INFO - 2016-11-21 16:02:15 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:02:15 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:02:15 --> Utf8 Class Initialized
INFO - 2016-11-21 16:02:15 --> URI Class Initialized
DEBUG - 2016-11-21 16:02:15 --> No URI present. Default controller set.
INFO - 2016-11-21 16:02:15 --> Router Class Initialized
INFO - 2016-11-21 16:02:15 --> Output Class Initialized
INFO - 2016-11-21 16:02:15 --> Security Class Initialized
DEBUG - 2016-11-21 16:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:02:15 --> Input Class Initialized
INFO - 2016-11-21 16:02:15 --> Language Class Initialized
INFO - 2016-11-21 16:02:15 --> Loader Class Initialized
INFO - 2016-11-21 16:02:15 --> Helper loaded: url_helper
INFO - 2016-11-21 16:02:15 --> Helper loaded: form_helper
INFO - 2016-11-21 16:02:15 --> Database Driver Class Initialized
INFO - 2016-11-21 16:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:02:15 --> Controller Class Initialized
INFO - 2016-11-21 16:02:15 --> Model Class Initialized
INFO - 2016-11-21 16:02:15 --> Model Class Initialized
INFO - 2016-11-21 16:02:16 --> Model Class Initialized
INFO - 2016-11-21 16:02:16 --> Model Class Initialized
INFO - 2016-11-21 16:02:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:02:16 --> Pagination Class Initialized
INFO - 2016-11-21 16:02:16 --> Helper loaded: app_helper
INFO - 2016-11-21 16:02:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 16:02:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 16:02:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 16:02:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 16:02:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:02:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 16:02:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 16:02:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 16:02:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 16:02:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 16:02:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 16:02:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 16:02:16 --> Final output sent to browser
DEBUG - 2016-11-21 16:02:16 --> Total execution time: 0.6257
INFO - 2016-11-21 16:02:36 --> Config Class Initialized
INFO - 2016-11-21 16:02:36 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:02:36 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:02:36 --> Utf8 Class Initialized
INFO - 2016-11-21 16:02:36 --> URI Class Initialized
INFO - 2016-11-21 16:02:36 --> Router Class Initialized
INFO - 2016-11-21 16:02:36 --> Output Class Initialized
INFO - 2016-11-21 16:02:36 --> Security Class Initialized
DEBUG - 2016-11-21 16:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:02:36 --> Input Class Initialized
INFO - 2016-11-21 16:02:36 --> Language Class Initialized
INFO - 2016-11-21 16:02:36 --> Loader Class Initialized
INFO - 2016-11-21 16:02:36 --> Helper loaded: url_helper
INFO - 2016-11-21 16:02:36 --> Helper loaded: form_helper
INFO - 2016-11-21 16:02:36 --> Database Driver Class Initialized
INFO - 2016-11-21 16:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:02:36 --> Controller Class Initialized
INFO - 2016-11-21 16:02:36 --> Model Class Initialized
INFO - 2016-11-21 16:02:36 --> Form Validation Class Initialized
INFO - 2016-11-21 16:02:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:02:36 --> Pagination Class Initialized
INFO - 2016-11-21 16:02:36 --> Helper loaded: app_helper
ERROR - 2016-11-21 16:02:36 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:02:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 16:02:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 16:02:36 --> Final output sent to browser
DEBUG - 2016-11-21 16:02:36 --> Total execution time: 0.4979
INFO - 2016-11-21 16:02:39 --> Config Class Initialized
INFO - 2016-11-21 16:02:39 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:02:39 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:02:39 --> Utf8 Class Initialized
INFO - 2016-11-21 16:02:39 --> URI Class Initialized
INFO - 2016-11-21 16:02:39 --> Router Class Initialized
INFO - 2016-11-21 16:02:39 --> Output Class Initialized
INFO - 2016-11-21 16:02:39 --> Security Class Initialized
DEBUG - 2016-11-21 16:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:02:39 --> Input Class Initialized
INFO - 2016-11-21 16:02:39 --> Language Class Initialized
INFO - 2016-11-21 16:02:39 --> Loader Class Initialized
INFO - 2016-11-21 16:02:39 --> Helper loaded: url_helper
INFO - 2016-11-21 16:02:39 --> Helper loaded: form_helper
INFO - 2016-11-21 16:02:39 --> Database Driver Class Initialized
INFO - 2016-11-21 16:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:02:39 --> Controller Class Initialized
INFO - 2016-11-21 16:02:39 --> Model Class Initialized
INFO - 2016-11-21 16:02:39 --> Form Validation Class Initialized
INFO - 2016-11-21 16:02:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:02:39 --> Pagination Class Initialized
INFO - 2016-11-21 16:02:39 --> Helper loaded: app_helper
ERROR - 2016-11-21 16:02:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:02:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:02:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:02:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:02:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:02:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:02:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:02:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:02:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:02:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:02:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:02:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:02:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:02:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:02:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:02:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:02:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:02:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:02:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:02:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 16:02:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 16:02:39 --> Final output sent to browser
DEBUG - 2016-11-21 16:02:39 --> Total execution time: 0.7101
INFO - 2016-11-21 16:03:56 --> Config Class Initialized
INFO - 2016-11-21 16:03:56 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:03:56 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:03:56 --> Utf8 Class Initialized
INFO - 2016-11-21 16:03:56 --> URI Class Initialized
DEBUG - 2016-11-21 16:03:56 --> No URI present. Default controller set.
INFO - 2016-11-21 16:03:56 --> Router Class Initialized
INFO - 2016-11-21 16:03:56 --> Output Class Initialized
INFO - 2016-11-21 16:03:56 --> Security Class Initialized
DEBUG - 2016-11-21 16:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:03:56 --> Input Class Initialized
INFO - 2016-11-21 16:03:56 --> Language Class Initialized
INFO - 2016-11-21 16:03:56 --> Loader Class Initialized
INFO - 2016-11-21 16:03:56 --> Helper loaded: url_helper
INFO - 2016-11-21 16:03:56 --> Helper loaded: form_helper
INFO - 2016-11-21 16:03:56 --> Database Driver Class Initialized
INFO - 2016-11-21 16:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:03:56 --> Controller Class Initialized
INFO - 2016-11-21 16:03:56 --> Model Class Initialized
INFO - 2016-11-21 16:03:56 --> Model Class Initialized
INFO - 2016-11-21 16:03:56 --> Model Class Initialized
INFO - 2016-11-21 16:03:56 --> Model Class Initialized
INFO - 2016-11-21 16:03:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:03:57 --> Pagination Class Initialized
INFO - 2016-11-21 16:03:57 --> Helper loaded: app_helper
INFO - 2016-11-21 16:03:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 16:03:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 16:03:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 16:03:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 16:03:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:03:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 16:03:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 16:03:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 16:03:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 16:03:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 16:03:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 16:03:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 16:03:57 --> Final output sent to browser
DEBUG - 2016-11-21 16:03:57 --> Total execution time: 0.6335
INFO - 2016-11-21 16:04:03 --> Config Class Initialized
INFO - 2016-11-21 16:04:03 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:04:03 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:04:03 --> Utf8 Class Initialized
INFO - 2016-11-21 16:04:03 --> URI Class Initialized
INFO - 2016-11-21 16:04:03 --> Router Class Initialized
INFO - 2016-11-21 16:04:03 --> Output Class Initialized
INFO - 2016-11-21 16:04:03 --> Security Class Initialized
DEBUG - 2016-11-21 16:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:04:03 --> Input Class Initialized
INFO - 2016-11-21 16:04:03 --> Language Class Initialized
INFO - 2016-11-21 16:04:03 --> Loader Class Initialized
INFO - 2016-11-21 16:04:03 --> Helper loaded: url_helper
INFO - 2016-11-21 16:04:03 --> Helper loaded: form_helper
INFO - 2016-11-21 16:04:03 --> Database Driver Class Initialized
INFO - 2016-11-21 16:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:04:03 --> Controller Class Initialized
INFO - 2016-11-21 16:04:03 --> Model Class Initialized
INFO - 2016-11-21 16:04:03 --> Form Validation Class Initialized
INFO - 2016-11-21 16:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:04:03 --> Pagination Class Initialized
INFO - 2016-11-21 16:04:03 --> Helper loaded: app_helper
ERROR - 2016-11-21 16:04:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:04:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 16:04:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 16:04:03 --> Final output sent to browser
DEBUG - 2016-11-21 16:04:03 --> Total execution time: 0.4320
INFO - 2016-11-21 16:04:06 --> Config Class Initialized
INFO - 2016-11-21 16:04:06 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:04:06 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:04:06 --> Utf8 Class Initialized
INFO - 2016-11-21 16:04:06 --> URI Class Initialized
INFO - 2016-11-21 16:04:06 --> Router Class Initialized
INFO - 2016-11-21 16:04:06 --> Output Class Initialized
INFO - 2016-11-21 16:04:06 --> Security Class Initialized
DEBUG - 2016-11-21 16:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:04:06 --> Input Class Initialized
INFO - 2016-11-21 16:04:06 --> Language Class Initialized
INFO - 2016-11-21 16:04:06 --> Loader Class Initialized
INFO - 2016-11-21 16:04:06 --> Helper loaded: url_helper
INFO - 2016-11-21 16:04:06 --> Helper loaded: form_helper
INFO - 2016-11-21 16:04:06 --> Database Driver Class Initialized
INFO - 2016-11-21 16:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:04:06 --> Controller Class Initialized
INFO - 2016-11-21 16:04:06 --> Model Class Initialized
INFO - 2016-11-21 16:04:06 --> Form Validation Class Initialized
INFO - 2016-11-21 16:04:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:04:06 --> Pagination Class Initialized
INFO - 2016-11-21 16:04:06 --> Helper loaded: app_helper
ERROR - 2016-11-21 16:04:06 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:04:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 16:04:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 16:04:06 --> Final output sent to browser
DEBUG - 2016-11-21 16:04:06 --> Total execution time: 0.4599
INFO - 2016-11-21 16:07:15 --> Config Class Initialized
INFO - 2016-11-21 16:07:15 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:07:15 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:07:15 --> Utf8 Class Initialized
INFO - 2016-11-21 16:07:15 --> URI Class Initialized
INFO - 2016-11-21 16:07:15 --> Router Class Initialized
INFO - 2016-11-21 16:07:15 --> Output Class Initialized
INFO - 2016-11-21 16:07:15 --> Security Class Initialized
DEBUG - 2016-11-21 16:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:07:15 --> Input Class Initialized
INFO - 2016-11-21 16:07:15 --> Language Class Initialized
INFO - 2016-11-21 16:07:15 --> Loader Class Initialized
INFO - 2016-11-21 16:07:15 --> Helper loaded: url_helper
INFO - 2016-11-21 16:07:15 --> Helper loaded: form_helper
INFO - 2016-11-21 16:07:15 --> Database Driver Class Initialized
INFO - 2016-11-21 16:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:07:15 --> Controller Class Initialized
INFO - 2016-11-21 16:07:15 --> Model Class Initialized
INFO - 2016-11-21 16:07:15 --> Form Validation Class Initialized
INFO - 2016-11-21 16:07:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:07:15 --> Pagination Class Initialized
INFO - 2016-11-21 16:07:15 --> Helper loaded: app_helper
ERROR - 2016-11-21 16:07:15 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 16:07:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 16:07:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 16:07:15 --> Final output sent to browser
DEBUG - 2016-11-21 16:07:15 --> Total execution time: 0.6238
INFO - 2016-11-21 16:07:25 --> Config Class Initialized
INFO - 2016-11-21 16:07:25 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:07:25 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:07:25 --> Utf8 Class Initialized
INFO - 2016-11-21 16:07:25 --> URI Class Initialized
DEBUG - 2016-11-21 16:07:25 --> No URI present. Default controller set.
INFO - 2016-11-21 16:07:25 --> Router Class Initialized
INFO - 2016-11-21 16:07:25 --> Output Class Initialized
INFO - 2016-11-21 16:07:25 --> Security Class Initialized
DEBUG - 2016-11-21 16:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:07:25 --> Input Class Initialized
INFO - 2016-11-21 16:07:25 --> Language Class Initialized
INFO - 2016-11-21 16:07:25 --> Loader Class Initialized
INFO - 2016-11-21 16:07:25 --> Helper loaded: url_helper
INFO - 2016-11-21 16:07:25 --> Helper loaded: form_helper
INFO - 2016-11-21 16:07:25 --> Database Driver Class Initialized
INFO - 2016-11-21 16:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:07:25 --> Controller Class Initialized
INFO - 2016-11-21 16:07:25 --> Model Class Initialized
INFO - 2016-11-21 16:07:25 --> Model Class Initialized
INFO - 2016-11-21 16:07:25 --> Model Class Initialized
INFO - 2016-11-21 16:07:25 --> Model Class Initialized
INFO - 2016-11-21 16:07:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:07:25 --> Pagination Class Initialized
INFO - 2016-11-21 16:07:25 --> Helper loaded: app_helper
INFO - 2016-11-21 16:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 16:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 16:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 16:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 16:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 16:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 16:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 16:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 16:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 16:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 16:07:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 16:07:26 --> Final output sent to browser
DEBUG - 2016-11-21 16:07:26 --> Total execution time: 0.6537
INFO - 2016-11-21 16:09:01 --> Config Class Initialized
INFO - 2016-11-21 16:09:01 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:09:01 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:09:01 --> Utf8 Class Initialized
INFO - 2016-11-21 16:09:01 --> URI Class Initialized
DEBUG - 2016-11-21 16:09:01 --> No URI present. Default controller set.
INFO - 2016-11-21 16:09:01 --> Router Class Initialized
INFO - 2016-11-21 16:09:01 --> Output Class Initialized
INFO - 2016-11-21 16:09:01 --> Security Class Initialized
DEBUG - 2016-11-21 16:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:09:01 --> Input Class Initialized
INFO - 2016-11-21 16:09:01 --> Language Class Initialized
INFO - 2016-11-21 16:09:01 --> Loader Class Initialized
INFO - 2016-11-21 16:09:01 --> Helper loaded: url_helper
INFO - 2016-11-21 16:09:01 --> Helper loaded: form_helper
INFO - 2016-11-21 16:09:01 --> Database Driver Class Initialized
INFO - 2016-11-21 16:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:09:01 --> Controller Class Initialized
INFO - 2016-11-21 16:09:01 --> Model Class Initialized
INFO - 2016-11-21 16:09:01 --> Model Class Initialized
INFO - 2016-11-21 16:09:01 --> Model Class Initialized
INFO - 2016-11-21 16:09:01 --> Model Class Initialized
INFO - 2016-11-21 16:09:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:09:01 --> Pagination Class Initialized
INFO - 2016-11-21 16:09:01 --> Helper loaded: app_helper
INFO - 2016-11-21 16:09:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 16:09:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 16:09:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 16:09:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 16:09:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:09:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 16:09:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 16:09:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 16:09:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 16:09:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 16:09:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 16:09:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 16:09:02 --> Final output sent to browser
DEBUG - 2016-11-21 16:09:02 --> Total execution time: 0.6513
INFO - 2016-11-21 16:09:09 --> Config Class Initialized
INFO - 2016-11-21 16:09:09 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:09:09 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:09:09 --> Utf8 Class Initialized
INFO - 2016-11-21 16:09:09 --> URI Class Initialized
DEBUG - 2016-11-21 16:09:09 --> No URI present. Default controller set.
INFO - 2016-11-21 16:09:09 --> Router Class Initialized
INFO - 2016-11-21 16:09:09 --> Output Class Initialized
INFO - 2016-11-21 16:09:09 --> Security Class Initialized
DEBUG - 2016-11-21 16:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:09:09 --> Input Class Initialized
INFO - 2016-11-21 16:09:09 --> Language Class Initialized
INFO - 2016-11-21 16:09:09 --> Loader Class Initialized
INFO - 2016-11-21 16:09:09 --> Helper loaded: url_helper
INFO - 2016-11-21 16:09:09 --> Helper loaded: form_helper
INFO - 2016-11-21 16:09:09 --> Database Driver Class Initialized
INFO - 2016-11-21 16:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:09:09 --> Controller Class Initialized
INFO - 2016-11-21 16:09:09 --> Model Class Initialized
INFO - 2016-11-21 16:09:09 --> Model Class Initialized
INFO - 2016-11-21 16:09:09 --> Model Class Initialized
INFO - 2016-11-21 16:09:09 --> Model Class Initialized
INFO - 2016-11-21 16:09:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:09:09 --> Pagination Class Initialized
INFO - 2016-11-21 16:09:09 --> Helper loaded: app_helper
INFO - 2016-11-21 16:09:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 16:09:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 16:09:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 16:09:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 16:09:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:09:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 16:09:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 16:09:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 16:09:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 16:09:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 16:09:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 16:09:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 16:09:09 --> Final output sent to browser
DEBUG - 2016-11-21 16:09:09 --> Total execution time: 0.6700
INFO - 2016-11-21 16:09:24 --> Config Class Initialized
INFO - 2016-11-21 16:09:24 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:09:24 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:09:24 --> Utf8 Class Initialized
INFO - 2016-11-21 16:09:24 --> URI Class Initialized
INFO - 2016-11-21 16:09:24 --> Router Class Initialized
INFO - 2016-11-21 16:09:24 --> Output Class Initialized
INFO - 2016-11-21 16:09:24 --> Security Class Initialized
DEBUG - 2016-11-21 16:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:09:24 --> Input Class Initialized
INFO - 2016-11-21 16:09:24 --> Language Class Initialized
INFO - 2016-11-21 16:09:24 --> Loader Class Initialized
INFO - 2016-11-21 16:09:24 --> Helper loaded: url_helper
INFO - 2016-11-21 16:09:24 --> Helper loaded: form_helper
INFO - 2016-11-21 16:09:24 --> Database Driver Class Initialized
INFO - 2016-11-21 16:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:09:24 --> Controller Class Initialized
INFO - 2016-11-21 16:09:24 --> Model Class Initialized
INFO - 2016-11-21 16:09:24 --> Form Validation Class Initialized
INFO - 2016-11-21 16:09:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:09:24 --> Pagination Class Initialized
INFO - 2016-11-21 16:09:24 --> Helper loaded: app_helper
INFO - 2016-11-21 16:09:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 16:09:24 --> Final output sent to browser
DEBUG - 2016-11-21 16:09:25 --> Total execution time: 0.5682
INFO - 2016-11-21 16:23:50 --> Config Class Initialized
INFO - 2016-11-21 16:23:50 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:23:50 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:23:50 --> Utf8 Class Initialized
INFO - 2016-11-21 16:23:50 --> URI Class Initialized
DEBUG - 2016-11-21 16:23:50 --> No URI present. Default controller set.
INFO - 2016-11-21 16:23:50 --> Router Class Initialized
INFO - 2016-11-21 16:23:50 --> Output Class Initialized
INFO - 2016-11-21 16:23:50 --> Security Class Initialized
DEBUG - 2016-11-21 16:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:23:50 --> Input Class Initialized
INFO - 2016-11-21 16:23:50 --> Language Class Initialized
INFO - 2016-11-21 16:23:50 --> Loader Class Initialized
INFO - 2016-11-21 16:23:50 --> Helper loaded: url_helper
INFO - 2016-11-21 16:23:50 --> Helper loaded: form_helper
INFO - 2016-11-21 16:23:50 --> Database Driver Class Initialized
INFO - 2016-11-21 16:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:23:50 --> Controller Class Initialized
INFO - 2016-11-21 16:23:50 --> Model Class Initialized
INFO - 2016-11-21 16:23:50 --> Model Class Initialized
INFO - 2016-11-21 16:23:50 --> Model Class Initialized
INFO - 2016-11-21 16:23:50 --> Model Class Initialized
INFO - 2016-11-21 16:23:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:23:50 --> Pagination Class Initialized
INFO - 2016-11-21 16:23:50 --> Helper loaded: app_helper
INFO - 2016-11-21 16:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 16:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 16:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 16:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 16:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 16:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 16:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 16:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 16:23:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 16:23:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 16:23:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 16:23:51 --> Final output sent to browser
DEBUG - 2016-11-21 16:23:51 --> Total execution time: 0.7320
INFO - 2016-11-21 16:42:08 --> Config Class Initialized
INFO - 2016-11-21 16:42:08 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:42:08 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:42:08 --> Utf8 Class Initialized
INFO - 2016-11-21 16:42:08 --> URI Class Initialized
DEBUG - 2016-11-21 16:42:08 --> No URI present. Default controller set.
INFO - 2016-11-21 16:42:08 --> Router Class Initialized
INFO - 2016-11-21 16:42:08 --> Output Class Initialized
INFO - 2016-11-21 16:42:08 --> Security Class Initialized
DEBUG - 2016-11-21 16:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:42:08 --> Input Class Initialized
INFO - 2016-11-21 16:42:08 --> Language Class Initialized
INFO - 2016-11-21 16:42:08 --> Loader Class Initialized
INFO - 2016-11-21 16:42:08 --> Helper loaded: url_helper
INFO - 2016-11-21 16:42:08 --> Helper loaded: form_helper
INFO - 2016-11-21 16:42:08 --> Database Driver Class Initialized
INFO - 2016-11-21 16:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:42:08 --> Controller Class Initialized
INFO - 2016-11-21 16:42:08 --> Model Class Initialized
INFO - 2016-11-21 16:42:08 --> Model Class Initialized
INFO - 2016-11-21 16:42:09 --> Model Class Initialized
INFO - 2016-11-21 16:42:09 --> Model Class Initialized
INFO - 2016-11-21 16:42:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:42:09 --> Pagination Class Initialized
INFO - 2016-11-21 16:42:09 --> Helper loaded: app_helper
INFO - 2016-11-21 16:42:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 16:42:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 16:42:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 16:42:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 16:42:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:42:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 16:42:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 16:42:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 16:42:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 16:42:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 16:42:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 16:42:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 16:42:09 --> Final output sent to browser
DEBUG - 2016-11-21 16:42:09 --> Total execution time: 0.6796
INFO - 2016-11-21 16:42:40 --> Config Class Initialized
INFO - 2016-11-21 16:42:40 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:42:40 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:42:40 --> Utf8 Class Initialized
INFO - 2016-11-21 16:42:40 --> URI Class Initialized
INFO - 2016-11-21 16:42:40 --> Router Class Initialized
INFO - 2016-11-21 16:42:40 --> Output Class Initialized
INFO - 2016-11-21 16:42:40 --> Security Class Initialized
DEBUG - 2016-11-21 16:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:42:40 --> Input Class Initialized
INFO - 2016-11-21 16:42:40 --> Language Class Initialized
INFO - 2016-11-21 16:42:40 --> Loader Class Initialized
INFO - 2016-11-21 16:42:40 --> Helper loaded: url_helper
INFO - 2016-11-21 16:42:40 --> Helper loaded: form_helper
INFO - 2016-11-21 16:42:40 --> Database Driver Class Initialized
INFO - 2016-11-21 16:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:42:40 --> Controller Class Initialized
INFO - 2016-11-21 16:42:40 --> Model Class Initialized
INFO - 2016-11-21 16:42:40 --> Form Validation Class Initialized
INFO - 2016-11-21 16:42:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:42:40 --> Pagination Class Initialized
INFO - 2016-11-21 16:42:40 --> Helper loaded: app_helper
INFO - 2016-11-21 16:42:40 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 16:42:40 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
ERROR - 2016-11-21 16:42:40 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 16:42:40 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:42:41 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
ERROR - 2016-11-21 16:42:41 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:42:45 --> Config Class Initialized
INFO - 2016-11-21 16:42:45 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:42:45 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:42:45 --> Utf8 Class Initialized
INFO - 2016-11-21 16:42:45 --> URI Class Initialized
INFO - 2016-11-21 16:42:45 --> Router Class Initialized
INFO - 2016-11-21 16:42:45 --> Output Class Initialized
INFO - 2016-11-21 16:42:45 --> Security Class Initialized
DEBUG - 2016-11-21 16:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:42:45 --> Input Class Initialized
INFO - 2016-11-21 16:42:45 --> Language Class Initialized
INFO - 2016-11-21 16:42:45 --> Loader Class Initialized
INFO - 2016-11-21 16:42:45 --> Helper loaded: url_helper
INFO - 2016-11-21 16:42:45 --> Helper loaded: form_helper
INFO - 2016-11-21 16:42:45 --> Database Driver Class Initialized
INFO - 2016-11-21 16:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:42:46 --> Controller Class Initialized
INFO - 2016-11-21 16:42:46 --> Model Class Initialized
INFO - 2016-11-21 16:42:46 --> Form Validation Class Initialized
INFO - 2016-11-21 16:42:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:42:46 --> Pagination Class Initialized
INFO - 2016-11-21 16:42:46 --> Helper loaded: app_helper
INFO - 2016-11-21 16:42:46 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 16:42:46 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
ERROR - 2016-11-21 16:42:46 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
INFO - 2016-11-21 16:42:46 --> Config Class Initialized
DEBUG - 2016-11-21 16:42:46 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-21 16:42:46 --> Hooks Class Initialized
ERROR - 2016-11-21 16:42:46 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
DEBUG - 2016-11-21 16:42:46 --> UTF-8 Support Enabled
ERROR - 2016-11-21 16:42:46 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:42:46 --> Utf8 Class Initialized
INFO - 2016-11-21 16:42:46 --> URI Class Initialized
INFO - 2016-11-21 16:42:46 --> Router Class Initialized
INFO - 2016-11-21 16:42:46 --> Output Class Initialized
INFO - 2016-11-21 16:42:46 --> Security Class Initialized
DEBUG - 2016-11-21 16:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:42:46 --> Config Class Initialized
INFO - 2016-11-21 16:42:46 --> Input Class Initialized
INFO - 2016-11-21 16:42:46 --> Hooks Class Initialized
INFO - 2016-11-21 16:42:46 --> Language Class Initialized
DEBUG - 2016-11-21 16:42:46 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:42:46 --> Loader Class Initialized
INFO - 2016-11-21 16:42:46 --> Utf8 Class Initialized
INFO - 2016-11-21 16:42:46 --> URI Class Initialized
INFO - 2016-11-21 16:42:46 --> Helper loaded: url_helper
INFO - 2016-11-21 16:42:46 --> Router Class Initialized
INFO - 2016-11-21 16:42:46 --> Helper loaded: form_helper
INFO - 2016-11-21 16:42:46 --> Output Class Initialized
INFO - 2016-11-21 16:42:46 --> Config Class Initialized
INFO - 2016-11-21 16:42:46 --> Database Driver Class Initialized
INFO - 2016-11-21 16:42:46 --> Hooks Class Initialized
INFO - 2016-11-21 16:42:46 --> Security Class Initialized
INFO - 2016-11-21 16:42:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-21 16:42:46 --> UTF-8 Support Enabled
DEBUG - 2016-11-21 16:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:42:46 --> Controller Class Initialized
INFO - 2016-11-21 16:42:46 --> Utf8 Class Initialized
INFO - 2016-11-21 16:42:46 --> Input Class Initialized
INFO - 2016-11-21 16:42:46 --> Model Class Initialized
INFO - 2016-11-21 16:42:46 --> URI Class Initialized
INFO - 2016-11-21 16:42:46 --> Language Class Initialized
INFO - 2016-11-21 16:42:46 --> Form Validation Class Initialized
INFO - 2016-11-21 16:42:46 --> Router Class Initialized
INFO - 2016-11-21 16:42:46 --> Loader Class Initialized
INFO - 2016-11-21 16:42:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:42:46 --> Output Class Initialized
INFO - 2016-11-21 16:42:46 --> Helper loaded: url_helper
INFO - 2016-11-21 16:42:46 --> Pagination Class Initialized
INFO - 2016-11-21 16:42:46 --> Security Class Initialized
INFO - 2016-11-21 16:42:46 --> Helper loaded: app_helper
INFO - 2016-11-21 16:42:46 --> Helper loaded: form_helper
DEBUG - 2016-11-21 16:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:42:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 16:42:46 --> Database Driver Class Initialized
INFO - 2016-11-21 16:42:46 --> Input Class Initialized
INFO - 2016-11-21 16:42:46 --> Language Class Initialized
INFO - 2016-11-21 16:42:46 --> Loader Class Initialized
INFO - 2016-11-21 16:42:46 --> Helper loaded: url_helper
INFO - 2016-11-21 16:42:46 --> Helper loaded: form_helper
INFO - 2016-11-21 16:42:46 --> Database Driver Class Initialized
ERROR - 2016-11-21 16:42:46 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
ERROR - 2016-11-21 16:42:46 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 16:42:46 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:42:46 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
ERROR - 2016-11-21 16:42:47 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:42:47 --> Controller Class Initialized
INFO - 2016-11-21 16:42:47 --> Model Class Initialized
INFO - 2016-11-21 16:42:47 --> Form Validation Class Initialized
INFO - 2016-11-21 16:42:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:42:47 --> Pagination Class Initialized
INFO - 2016-11-21 16:42:47 --> Helper loaded: app_helper
INFO - 2016-11-21 16:42:47 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 16:42:47 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
ERROR - 2016-11-21 16:42:47 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 16:42:47 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:42:47 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
ERROR - 2016-11-21 16:42:47 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:42:47 --> Controller Class Initialized
INFO - 2016-11-21 16:42:47 --> Model Class Initialized
INFO - 2016-11-21 16:42:47 --> Form Validation Class Initialized
INFO - 2016-11-21 16:42:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:42:47 --> Pagination Class Initialized
INFO - 2016-11-21 16:42:47 --> Helper loaded: app_helper
INFO - 2016-11-21 16:42:47 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 16:42:47 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
ERROR - 2016-11-21 16:42:47 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 16:42:47 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:42:47 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
ERROR - 2016-11-21 16:42:47 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:42:50 --> Config Class Initialized
INFO - 2016-11-21 16:42:50 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:42:50 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:42:50 --> Utf8 Class Initialized
INFO - 2016-11-21 16:42:50 --> URI Class Initialized
DEBUG - 2016-11-21 16:42:50 --> No URI present. Default controller set.
INFO - 2016-11-21 16:42:50 --> Router Class Initialized
INFO - 2016-11-21 16:42:50 --> Output Class Initialized
INFO - 2016-11-21 16:42:50 --> Security Class Initialized
DEBUG - 2016-11-21 16:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:42:50 --> Input Class Initialized
INFO - 2016-11-21 16:42:50 --> Language Class Initialized
INFO - 2016-11-21 16:42:50 --> Loader Class Initialized
INFO - 2016-11-21 16:42:50 --> Helper loaded: url_helper
INFO - 2016-11-21 16:42:50 --> Helper loaded: form_helper
INFO - 2016-11-21 16:42:50 --> Database Driver Class Initialized
INFO - 2016-11-21 16:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:42:50 --> Controller Class Initialized
INFO - 2016-11-21 16:42:50 --> Model Class Initialized
INFO - 2016-11-21 16:42:50 --> Model Class Initialized
INFO - 2016-11-21 16:42:50 --> Model Class Initialized
INFO - 2016-11-21 16:42:50 --> Model Class Initialized
INFO - 2016-11-21 16:42:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:42:50 --> Pagination Class Initialized
INFO - 2016-11-21 16:42:51 --> Helper loaded: app_helper
INFO - 2016-11-21 16:42:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 16:42:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 16:42:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 16:42:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 16:42:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:42:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 16:42:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 16:42:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 16:42:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 16:42:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 16:42:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 16:42:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 16:42:51 --> Final output sent to browser
DEBUG - 2016-11-21 16:42:51 --> Total execution time: 0.6850
INFO - 2016-11-21 16:42:54 --> Config Class Initialized
INFO - 2016-11-21 16:42:54 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:42:54 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:42:54 --> Utf8 Class Initialized
INFO - 2016-11-21 16:42:54 --> URI Class Initialized
INFO - 2016-11-21 16:42:54 --> Router Class Initialized
INFO - 2016-11-21 16:42:54 --> Output Class Initialized
INFO - 2016-11-21 16:42:54 --> Security Class Initialized
DEBUG - 2016-11-21 16:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:42:54 --> Input Class Initialized
INFO - 2016-11-21 16:42:54 --> Language Class Initialized
INFO - 2016-11-21 16:42:54 --> Loader Class Initialized
INFO - 2016-11-21 16:42:54 --> Helper loaded: url_helper
INFO - 2016-11-21 16:42:54 --> Helper loaded: form_helper
INFO - 2016-11-21 16:42:54 --> Database Driver Class Initialized
INFO - 2016-11-21 16:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:42:54 --> Controller Class Initialized
INFO - 2016-11-21 16:42:54 --> Model Class Initialized
INFO - 2016-11-21 16:42:54 --> Form Validation Class Initialized
INFO - 2016-11-21 16:42:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:42:54 --> Pagination Class Initialized
INFO - 2016-11-21 16:42:54 --> Helper loaded: app_helper
INFO - 2016-11-21 16:42:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 16:42:54 --> Final output sent to browser
DEBUG - 2016-11-21 16:42:54 --> Total execution time: 0.3855
INFO - 2016-11-21 16:43:30 --> Config Class Initialized
INFO - 2016-11-21 16:43:30 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:43:30 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:43:30 --> Utf8 Class Initialized
INFO - 2016-11-21 16:43:30 --> URI Class Initialized
INFO - 2016-11-21 16:43:30 --> Router Class Initialized
INFO - 2016-11-21 16:43:30 --> Output Class Initialized
INFO - 2016-11-21 16:43:30 --> Security Class Initialized
DEBUG - 2016-11-21 16:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:43:30 --> Input Class Initialized
INFO - 2016-11-21 16:43:30 --> Language Class Initialized
INFO - 2016-11-21 16:43:30 --> Loader Class Initialized
INFO - 2016-11-21 16:43:30 --> Helper loaded: url_helper
INFO - 2016-11-21 16:43:30 --> Helper loaded: form_helper
INFO - 2016-11-21 16:43:30 --> Database Driver Class Initialized
INFO - 2016-11-21 16:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:43:30 --> Controller Class Initialized
INFO - 2016-11-21 16:43:30 --> Model Class Initialized
INFO - 2016-11-21 16:43:30 --> Form Validation Class Initialized
INFO - 2016-11-21 16:43:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:43:30 --> Pagination Class Initialized
INFO - 2016-11-21 16:43:30 --> Helper loaded: app_helper
INFO - 2016-11-21 16:43:30 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 16:43:30 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:43:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:43:30 --> Final output sent to browser
DEBUG - 2016-11-21 16:43:30 --> Total execution time: 0.6147
INFO - 2016-11-21 16:43:39 --> Config Class Initialized
INFO - 2016-11-21 16:43:39 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:43:39 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:43:39 --> Utf8 Class Initialized
INFO - 2016-11-21 16:43:39 --> URI Class Initialized
DEBUG - 2016-11-21 16:43:39 --> No URI present. Default controller set.
INFO - 2016-11-21 16:43:39 --> Router Class Initialized
INFO - 2016-11-21 16:43:39 --> Output Class Initialized
INFO - 2016-11-21 16:43:39 --> Security Class Initialized
DEBUG - 2016-11-21 16:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:43:39 --> Input Class Initialized
INFO - 2016-11-21 16:43:39 --> Language Class Initialized
INFO - 2016-11-21 16:43:39 --> Loader Class Initialized
INFO - 2016-11-21 16:43:39 --> Helper loaded: url_helper
INFO - 2016-11-21 16:43:39 --> Helper loaded: form_helper
INFO - 2016-11-21 16:43:39 --> Database Driver Class Initialized
INFO - 2016-11-21 16:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:43:39 --> Controller Class Initialized
INFO - 2016-11-21 16:43:39 --> Model Class Initialized
INFO - 2016-11-21 16:43:39 --> Model Class Initialized
INFO - 2016-11-21 16:43:39 --> Model Class Initialized
INFO - 2016-11-21 16:43:39 --> Model Class Initialized
INFO - 2016-11-21 16:43:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:43:39 --> Pagination Class Initialized
INFO - 2016-11-21 16:43:39 --> Helper loaded: app_helper
INFO - 2016-11-21 16:43:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 16:43:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 16:43:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 16:43:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 16:43:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:43:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 16:43:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 16:43:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 16:43:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 16:43:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 16:43:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 16:43:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 16:43:40 --> Final output sent to browser
DEBUG - 2016-11-21 16:43:40 --> Total execution time: 0.6891
INFO - 2016-11-21 16:44:06 --> Config Class Initialized
INFO - 2016-11-21 16:44:06 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:44:06 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:44:06 --> Utf8 Class Initialized
INFO - 2016-11-21 16:44:06 --> URI Class Initialized
INFO - 2016-11-21 16:44:06 --> Router Class Initialized
INFO - 2016-11-21 16:44:06 --> Output Class Initialized
INFO - 2016-11-21 16:44:06 --> Security Class Initialized
DEBUG - 2016-11-21 16:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:44:06 --> Input Class Initialized
INFO - 2016-11-21 16:44:06 --> Language Class Initialized
INFO - 2016-11-21 16:44:06 --> Loader Class Initialized
INFO - 2016-11-21 16:44:06 --> Helper loaded: url_helper
INFO - 2016-11-21 16:44:06 --> Helper loaded: form_helper
INFO - 2016-11-21 16:44:06 --> Database Driver Class Initialized
INFO - 2016-11-21 16:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:44:06 --> Controller Class Initialized
INFO - 2016-11-21 16:44:06 --> Model Class Initialized
INFO - 2016-11-21 16:44:06 --> Form Validation Class Initialized
INFO - 2016-11-21 16:44:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:44:06 --> Pagination Class Initialized
INFO - 2016-11-21 16:44:06 --> Helper loaded: app_helper
INFO - 2016-11-21 16:44:06 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 16:44:06 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
ERROR - 2016-11-21 16:44:06 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 16:44:06 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:44:06 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
ERROR - 2016-11-21 16:44:06 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:44:09 --> Config Class Initialized
INFO - 2016-11-21 16:44:09 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:44:09 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:44:09 --> Utf8 Class Initialized
INFO - 2016-11-21 16:44:09 --> URI Class Initialized
INFO - 2016-11-21 16:44:09 --> Router Class Initialized
INFO - 2016-11-21 16:44:09 --> Output Class Initialized
INFO - 2016-11-21 16:44:09 --> Security Class Initialized
DEBUG - 2016-11-21 16:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:44:09 --> Input Class Initialized
INFO - 2016-11-21 16:44:09 --> Language Class Initialized
INFO - 2016-11-21 16:44:09 --> Config Class Initialized
INFO - 2016-11-21 16:44:09 --> Loader Class Initialized
INFO - 2016-11-21 16:44:09 --> Hooks Class Initialized
INFO - 2016-11-21 16:44:09 --> Helper loaded: url_helper
DEBUG - 2016-11-21 16:44:09 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:44:09 --> Helper loaded: form_helper
INFO - 2016-11-21 16:44:09 --> Utf8 Class Initialized
INFO - 2016-11-21 16:44:09 --> URI Class Initialized
INFO - 2016-11-21 16:44:09 --> Database Driver Class Initialized
INFO - 2016-11-21 16:44:09 --> Router Class Initialized
INFO - 2016-11-21 16:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:44:09 --> Output Class Initialized
INFO - 2016-11-21 16:44:09 --> Controller Class Initialized
INFO - 2016-11-21 16:44:09 --> Model Class Initialized
INFO - 2016-11-21 16:44:09 --> Security Class Initialized
INFO - 2016-11-21 16:44:09 --> Form Validation Class Initialized
DEBUG - 2016-11-21 16:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:44:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:44:09 --> Input Class Initialized
INFO - 2016-11-21 16:44:09 --> Pagination Class Initialized
INFO - 2016-11-21 16:44:09 --> Language Class Initialized
INFO - 2016-11-21 16:44:09 --> Helper loaded: app_helper
INFO - 2016-11-21 16:44:09 --> Loader Class Initialized
INFO - 2016-11-21 16:44:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 16:44:09 --> Helper loaded: url_helper
INFO - 2016-11-21 16:44:09 --> Helper loaded: form_helper
INFO - 2016-11-21 16:44:09 --> Database Driver Class Initialized
ERROR - 2016-11-21 16:44:09 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
ERROR - 2016-11-21 16:44:09 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 16:44:09 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:44:09 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
ERROR - 2016-11-21 16:44:09 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:44:09 --> Controller Class Initialized
INFO - 2016-11-21 16:44:09 --> Model Class Initialized
INFO - 2016-11-21 16:44:09 --> Form Validation Class Initialized
INFO - 2016-11-21 16:44:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:44:09 --> Pagination Class Initialized
INFO - 2016-11-21 16:44:10 --> Helper loaded: app_helper
INFO - 2016-11-21 16:44:10 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 16:44:10 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
ERROR - 2016-11-21 16:44:10 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 16:44:10 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:44:10 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
ERROR - 2016-11-21 16:44:10 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:45:03 --> Config Class Initialized
INFO - 2016-11-21 16:45:03 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:45:03 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:45:03 --> Utf8 Class Initialized
INFO - 2016-11-21 16:45:03 --> URI Class Initialized
DEBUG - 2016-11-21 16:45:03 --> No URI present. Default controller set.
INFO - 2016-11-21 16:45:03 --> Router Class Initialized
INFO - 2016-11-21 16:45:04 --> Output Class Initialized
INFO - 2016-11-21 16:45:04 --> Security Class Initialized
DEBUG - 2016-11-21 16:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:45:04 --> Input Class Initialized
INFO - 2016-11-21 16:45:04 --> Language Class Initialized
INFO - 2016-11-21 16:45:04 --> Loader Class Initialized
INFO - 2016-11-21 16:45:04 --> Helper loaded: url_helper
INFO - 2016-11-21 16:45:04 --> Helper loaded: form_helper
INFO - 2016-11-21 16:45:04 --> Database Driver Class Initialized
INFO - 2016-11-21 16:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:45:04 --> Controller Class Initialized
INFO - 2016-11-21 16:45:04 --> Model Class Initialized
INFO - 2016-11-21 16:45:04 --> Model Class Initialized
INFO - 2016-11-21 16:45:04 --> Model Class Initialized
INFO - 2016-11-21 16:45:04 --> Model Class Initialized
INFO - 2016-11-21 16:45:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:45:04 --> Pagination Class Initialized
INFO - 2016-11-21 16:45:04 --> Helper loaded: app_helper
INFO - 2016-11-21 16:45:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 16:45:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 16:45:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 16:45:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 16:45:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:45:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 16:45:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 16:45:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 16:45:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 16:45:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 16:45:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 16:45:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 16:45:04 --> Final output sent to browser
DEBUG - 2016-11-21 16:45:04 --> Total execution time: 0.6652
INFO - 2016-11-21 16:45:21 --> Config Class Initialized
INFO - 2016-11-21 16:45:21 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:45:21 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:45:21 --> Utf8 Class Initialized
INFO - 2016-11-21 16:45:21 --> URI Class Initialized
INFO - 2016-11-21 16:45:21 --> Router Class Initialized
INFO - 2016-11-21 16:45:21 --> Output Class Initialized
INFO - 2016-11-21 16:45:21 --> Security Class Initialized
DEBUG - 2016-11-21 16:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:45:21 --> Input Class Initialized
INFO - 2016-11-21 16:45:21 --> Language Class Initialized
INFO - 2016-11-21 16:45:21 --> Loader Class Initialized
INFO - 2016-11-21 16:45:21 --> Helper loaded: url_helper
INFO - 2016-11-21 16:45:22 --> Helper loaded: form_helper
INFO - 2016-11-21 16:45:22 --> Database Driver Class Initialized
INFO - 2016-11-21 16:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:45:22 --> Controller Class Initialized
INFO - 2016-11-21 16:45:22 --> Model Class Initialized
INFO - 2016-11-21 16:45:22 --> Form Validation Class Initialized
INFO - 2016-11-21 16:45:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:45:22 --> Pagination Class Initialized
INFO - 2016-11-21 16:45:22 --> Helper loaded: app_helper
INFO - 2016-11-21 16:45:22 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 16:45:22 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:45:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
ERROR - 2016-11-21 16:45:22 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
ERROR - 2016-11-21 16:45:22 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 16:45:22 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:45:22 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
ERROR - 2016-11-21 16:45:22 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:45:23 --> Config Class Initialized
INFO - 2016-11-21 16:45:23 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:45:23 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:45:24 --> Utf8 Class Initialized
INFO - 2016-11-21 16:45:24 --> URI Class Initialized
INFO - 2016-11-21 16:45:24 --> Router Class Initialized
INFO - 2016-11-21 16:45:24 --> Output Class Initialized
INFO - 2016-11-21 16:45:24 --> Security Class Initialized
DEBUG - 2016-11-21 16:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:45:24 --> Input Class Initialized
INFO - 2016-11-21 16:45:24 --> Config Class Initialized
INFO - 2016-11-21 16:45:24 --> Language Class Initialized
INFO - 2016-11-21 16:45:24 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:45:24 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:45:24 --> Loader Class Initialized
INFO - 2016-11-21 16:45:24 --> Utf8 Class Initialized
INFO - 2016-11-21 16:45:24 --> Helper loaded: url_helper
INFO - 2016-11-21 16:45:24 --> URI Class Initialized
INFO - 2016-11-21 16:45:24 --> Helper loaded: form_helper
INFO - 2016-11-21 16:45:24 --> Router Class Initialized
INFO - 2016-11-21 16:45:24 --> Config Class Initialized
INFO - 2016-11-21 16:45:24 --> Database Driver Class Initialized
INFO - 2016-11-21 16:45:24 --> Output Class Initialized
INFO - 2016-11-21 16:45:24 --> Hooks Class Initialized
INFO - 2016-11-21 16:45:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-21 16:45:24 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:45:24 --> Security Class Initialized
INFO - 2016-11-21 16:45:24 --> Controller Class Initialized
INFO - 2016-11-21 16:45:24 --> Utf8 Class Initialized
DEBUG - 2016-11-21 16:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:45:24 --> Model Class Initialized
INFO - 2016-11-21 16:45:24 --> URI Class Initialized
INFO - 2016-11-21 16:45:24 --> Input Class Initialized
INFO - 2016-11-21 16:45:24 --> Form Validation Class Initialized
INFO - 2016-11-21 16:45:24 --> Config Class Initialized
INFO - 2016-11-21 16:45:24 --> Language Class Initialized
INFO - 2016-11-21 16:45:24 --> Router Class Initialized
INFO - 2016-11-21 16:45:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:45:24 --> Hooks Class Initialized
INFO - 2016-11-21 16:45:24 --> Output Class Initialized
INFO - 2016-11-21 16:45:24 --> Loader Class Initialized
INFO - 2016-11-21 16:45:24 --> Pagination Class Initialized
DEBUG - 2016-11-21 16:45:24 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:45:24 --> Helper loaded: url_helper
INFO - 2016-11-21 16:45:24 --> Utf8 Class Initialized
INFO - 2016-11-21 16:45:24 --> Security Class Initialized
INFO - 2016-11-21 16:45:24 --> Helper loaded: app_helper
INFO - 2016-11-21 16:45:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-21 16:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:45:24 --> Helper loaded: form_helper
INFO - 2016-11-21 16:45:24 --> URI Class Initialized
INFO - 2016-11-21 16:45:24 --> Input Class Initialized
INFO - 2016-11-21 16:45:24 --> Config Class Initialized
INFO - 2016-11-21 16:45:24 --> Database Driver Class Initialized
INFO - 2016-11-21 16:45:24 --> Router Class Initialized
INFO - 2016-11-21 16:45:24 --> Language Class Initialized
INFO - 2016-11-21 16:45:24 --> Hooks Class Initialized
INFO - 2016-11-21 16:45:24 --> Output Class Initialized
INFO - 2016-11-21 16:45:24 --> Loader Class Initialized
DEBUG - 2016-11-21 16:45:24 --> UTF-8 Support Enabled
ERROR - 2016-11-21 16:45:24 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:45:24 --> Security Class Initialized
INFO - 2016-11-21 16:45:24 --> Utf8 Class Initialized
INFO - 2016-11-21 16:45:24 --> Helper loaded: url_helper
INFO - 2016-11-21 16:45:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:45:24 --> Config Class Initialized
INFO - 2016-11-21 16:45:24 --> URI Class Initialized
DEBUG - 2016-11-21 16:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:45:24 --> Helper loaded: form_helper
INFO - 2016-11-21 16:45:24 --> Hooks Class Initialized
INFO - 2016-11-21 16:45:24 --> Input Class Initialized
INFO - 2016-11-21 16:45:24 --> Router Class Initialized
ERROR - 2016-11-21 16:45:24 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
INFO - 2016-11-21 16:45:24 --> Database Driver Class Initialized
INFO - 2016-11-21 16:45:24 --> Language Class Initialized
DEBUG - 2016-11-21 16:45:24 --> UTF-8 Support Enabled
ERROR - 2016-11-21 16:45:24 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
INFO - 2016-11-21 16:45:24 --> Output Class Initialized
INFO - 2016-11-21 16:45:24 --> Utf8 Class Initialized
INFO - 2016-11-21 16:45:24 --> Loader Class Initialized
INFO - 2016-11-21 16:45:24 --> Security Class Initialized
INFO - 2016-11-21 16:45:24 --> URI Class Initialized
DEBUG - 2016-11-21 16:45:24 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-21 16:45:24 --> Helper loaded: url_helper
ERROR - 2016-11-21 16:45:24 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
DEBUG - 2016-11-21 16:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:45:24 --> Router Class Initialized
ERROR - 2016-11-21 16:45:24 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:45:24 --> Helper loaded: form_helper
INFO - 2016-11-21 16:45:24 --> Input Class Initialized
INFO - 2016-11-21 16:45:24 --> Output Class Initialized
INFO - 2016-11-21 16:45:24 --> Config Class Initialized
INFO - 2016-11-21 16:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:45:24 --> Database Driver Class Initialized
INFO - 2016-11-21 16:45:24 --> Hooks Class Initialized
INFO - 2016-11-21 16:45:24 --> Controller Class Initialized
INFO - 2016-11-21 16:45:24 --> Language Class Initialized
INFO - 2016-11-21 16:45:24 --> Security Class Initialized
INFO - 2016-11-21 16:45:24 --> Model Class Initialized
DEBUG - 2016-11-21 16:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-21 16:45:24 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:45:24 --> Loader Class Initialized
INFO - 2016-11-21 16:45:24 --> Form Validation Class Initialized
INFO - 2016-11-21 16:45:24 --> Utf8 Class Initialized
INFO - 2016-11-21 16:45:25 --> Input Class Initialized
INFO - 2016-11-21 16:45:25 --> Helper loaded: url_helper
INFO - 2016-11-21 16:45:25 --> URI Class Initialized
INFO - 2016-11-21 16:45:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:45:25 --> Language Class Initialized
INFO - 2016-11-21 16:45:25 --> Pagination Class Initialized
INFO - 2016-11-21 16:45:25 --> Helper loaded: form_helper
INFO - 2016-11-21 16:45:25 --> Router Class Initialized
INFO - 2016-11-21 16:45:25 --> Helper loaded: app_helper
INFO - 2016-11-21 16:45:25 --> Database Driver Class Initialized
INFO - 2016-11-21 16:45:25 --> Loader Class Initialized
INFO - 2016-11-21 16:45:25 --> Output Class Initialized
INFO - 2016-11-21 16:45:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 16:45:25 --> Helper loaded: url_helper
INFO - 2016-11-21 16:45:25 --> Security Class Initialized
INFO - 2016-11-21 16:45:25 --> Helper loaded: form_helper
DEBUG - 2016-11-21 16:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:45:25 --> Database Driver Class Initialized
INFO - 2016-11-21 16:45:25 --> Input Class Initialized
ERROR - 2016-11-21 16:45:25 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:45:25 --> Language Class Initialized
INFO - 2016-11-21 16:45:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:45:25 --> Loader Class Initialized
ERROR - 2016-11-21 16:45:25 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
INFO - 2016-11-21 16:45:25 --> Helper loaded: url_helper
ERROR - 2016-11-21 16:45:25 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
INFO - 2016-11-21 16:45:25 --> Helper loaded: form_helper
DEBUG - 2016-11-21 16:45:25 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-21 16:45:25 --> Database Driver Class Initialized
ERROR - 2016-11-21 16:45:25 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
ERROR - 2016-11-21 16:45:25 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:45:25 --> Config Class Initialized
INFO - 2016-11-21 16:45:25 --> Controller Class Initialized
INFO - 2016-11-21 16:45:25 --> Hooks Class Initialized
INFO - 2016-11-21 16:45:25 --> Model Class Initialized
DEBUG - 2016-11-21 16:45:25 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:45:25 --> Utf8 Class Initialized
INFO - 2016-11-21 16:45:25 --> Form Validation Class Initialized
INFO - 2016-11-21 16:45:25 --> URI Class Initialized
INFO - 2016-11-21 16:45:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:45:25 --> Router Class Initialized
INFO - 2016-11-21 16:45:25 --> Pagination Class Initialized
INFO - 2016-11-21 16:45:25 --> Helper loaded: app_helper
INFO - 2016-11-21 16:45:25 --> Output Class Initialized
INFO - 2016-11-21 16:45:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 16:45:25 --> Security Class Initialized
DEBUG - 2016-11-21 16:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:45:25 --> Input Class Initialized
INFO - 2016-11-21 16:45:25 --> Language Class Initialized
INFO - 2016-11-21 16:45:25 --> Loader Class Initialized
INFO - 2016-11-21 16:45:25 --> Helper loaded: url_helper
ERROR - 2016-11-21 16:45:25 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:45:25 --> Helper loaded: form_helper
INFO - 2016-11-21 16:45:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:45:25 --> Database Driver Class Initialized
ERROR - 2016-11-21 16:45:25 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
ERROR - 2016-11-21 16:45:25 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 16:45:25 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:45:25 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
ERROR - 2016-11-21 16:45:25 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:45:25 --> Config Class Initialized
INFO - 2016-11-21 16:45:25 --> Controller Class Initialized
INFO - 2016-11-21 16:45:25 --> Hooks Class Initialized
INFO - 2016-11-21 16:45:25 --> Model Class Initialized
DEBUG - 2016-11-21 16:45:25 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:45:25 --> Form Validation Class Initialized
INFO - 2016-11-21 16:45:25 --> Utf8 Class Initialized
INFO - 2016-11-21 16:45:25 --> URI Class Initialized
INFO - 2016-11-21 16:45:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:45:25 --> Router Class Initialized
INFO - 2016-11-21 16:45:25 --> Pagination Class Initialized
INFO - 2016-11-21 16:45:26 --> Helper loaded: app_helper
INFO - 2016-11-21 16:45:26 --> Output Class Initialized
INFO - 2016-11-21 16:45:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 16:45:26 --> Security Class Initialized
DEBUG - 2016-11-21 16:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:45:26 --> Input Class Initialized
INFO - 2016-11-21 16:45:26 --> Language Class Initialized
INFO - 2016-11-21 16:45:26 --> Loader Class Initialized
ERROR - 2016-11-21 16:45:26 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:45:26 --> Helper loaded: url_helper
INFO - 2016-11-21 16:45:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:45:26 --> Helper loaded: form_helper
ERROR - 2016-11-21 16:45:26 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
INFO - 2016-11-21 16:45:26 --> Database Driver Class Initialized
ERROR - 2016-11-21 16:45:26 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 16:45:26 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:45:26 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
ERROR - 2016-11-21 16:45:26 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:45:26 --> Config Class Initialized
INFO - 2016-11-21 16:45:26 --> Controller Class Initialized
INFO - 2016-11-21 16:45:26 --> Hooks Class Initialized
INFO - 2016-11-21 16:45:26 --> Model Class Initialized
DEBUG - 2016-11-21 16:45:26 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:45:26 --> Form Validation Class Initialized
INFO - 2016-11-21 16:45:26 --> Utf8 Class Initialized
INFO - 2016-11-21 16:45:26 --> URI Class Initialized
INFO - 2016-11-21 16:45:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:45:26 --> Router Class Initialized
INFO - 2016-11-21 16:45:26 --> Pagination Class Initialized
INFO - 2016-11-21 16:45:26 --> Helper loaded: app_helper
INFO - 2016-11-21 16:45:26 --> Output Class Initialized
INFO - 2016-11-21 16:45:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 16:45:26 --> Security Class Initialized
DEBUG - 2016-11-21 16:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:45:26 --> Input Class Initialized
INFO - 2016-11-21 16:45:26 --> Language Class Initialized
INFO - 2016-11-21 16:45:26 --> Loader Class Initialized
INFO - 2016-11-21 16:45:26 --> Helper loaded: url_helper
INFO - 2016-11-21 16:45:26 --> Helper loaded: form_helper
ERROR - 2016-11-21 16:45:26 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:45:26 --> Database Driver Class Initialized
INFO - 2016-11-21 16:45:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
ERROR - 2016-11-21 16:45:26 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
ERROR - 2016-11-21 16:45:26 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 16:45:26 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:45:26 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
ERROR - 2016-11-21 16:45:26 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:45:26 --> Config Class Initialized
INFO - 2016-11-21 16:45:26 --> Controller Class Initialized
INFO - 2016-11-21 16:45:26 --> Hooks Class Initialized
INFO - 2016-11-21 16:45:26 --> Model Class Initialized
DEBUG - 2016-11-21 16:45:26 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:45:26 --> Form Validation Class Initialized
INFO - 2016-11-21 16:45:26 --> Utf8 Class Initialized
INFO - 2016-11-21 16:45:26 --> URI Class Initialized
INFO - 2016-11-21 16:45:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:45:26 --> Router Class Initialized
INFO - 2016-11-21 16:45:26 --> Pagination Class Initialized
INFO - 2016-11-21 16:45:26 --> Helper loaded: app_helper
INFO - 2016-11-21 16:45:26 --> Output Class Initialized
INFO - 2016-11-21 16:45:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 16:45:26 --> Security Class Initialized
DEBUG - 2016-11-21 16:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:45:27 --> Input Class Initialized
INFO - 2016-11-21 16:45:27 --> Language Class Initialized
INFO - 2016-11-21 16:45:27 --> Loader Class Initialized
ERROR - 2016-11-21 16:45:27 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:45:27 --> Helper loaded: url_helper
INFO - 2016-11-21 16:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:45:27 --> Helper loaded: form_helper
ERROR - 2016-11-21 16:45:27 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
INFO - 2016-11-21 16:45:27 --> Database Driver Class Initialized
ERROR - 2016-11-21 16:45:27 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 16:45:27 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:45:27 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
ERROR - 2016-11-21 16:45:27 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:45:27 --> Config Class Initialized
INFO - 2016-11-21 16:45:27 --> Controller Class Initialized
INFO - 2016-11-21 16:45:27 --> Hooks Class Initialized
INFO - 2016-11-21 16:45:27 --> Model Class Initialized
DEBUG - 2016-11-21 16:45:27 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:45:27 --> Form Validation Class Initialized
INFO - 2016-11-21 16:45:27 --> Utf8 Class Initialized
INFO - 2016-11-21 16:45:27 --> URI Class Initialized
INFO - 2016-11-21 16:45:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:45:27 --> Router Class Initialized
INFO - 2016-11-21 16:45:27 --> Pagination Class Initialized
INFO - 2016-11-21 16:45:27 --> Helper loaded: app_helper
INFO - 2016-11-21 16:45:27 --> Output Class Initialized
INFO - 2016-11-21 16:45:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 16:45:27 --> Security Class Initialized
DEBUG - 2016-11-21 16:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:45:27 --> Input Class Initialized
INFO - 2016-11-21 16:45:27 --> Language Class Initialized
INFO - 2016-11-21 16:45:27 --> Loader Class Initialized
ERROR - 2016-11-21 16:45:27 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:45:27 --> Helper loaded: url_helper
INFO - 2016-11-21 16:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:45:27 --> Helper loaded: form_helper
ERROR - 2016-11-21 16:45:27 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
INFO - 2016-11-21 16:45:27 --> Database Driver Class Initialized
ERROR - 2016-11-21 16:45:27 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 16:45:27 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:45:27 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
ERROR - 2016-11-21 16:45:27 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:45:27 --> Config Class Initialized
INFO - 2016-11-21 16:45:27 --> Controller Class Initialized
INFO - 2016-11-21 16:45:27 --> Hooks Class Initialized
INFO - 2016-11-21 16:45:27 --> Model Class Initialized
DEBUG - 2016-11-21 16:45:27 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:45:27 --> Form Validation Class Initialized
INFO - 2016-11-21 16:45:27 --> Utf8 Class Initialized
INFO - 2016-11-21 16:45:27 --> URI Class Initialized
INFO - 2016-11-21 16:45:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:45:27 --> Router Class Initialized
INFO - 2016-11-21 16:45:27 --> Pagination Class Initialized
INFO - 2016-11-21 16:45:27 --> Helper loaded: app_helper
INFO - 2016-11-21 16:45:27 --> Output Class Initialized
INFO - 2016-11-21 16:45:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 16:45:27 --> Security Class Initialized
DEBUG - 2016-11-21 16:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:45:27 --> Input Class Initialized
INFO - 2016-11-21 16:45:27 --> Language Class Initialized
INFO - 2016-11-21 16:45:27 --> Loader Class Initialized
ERROR - 2016-11-21 16:45:28 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:45:28 --> Helper loaded: url_helper
INFO - 2016-11-21 16:45:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:45:28 --> Helper loaded: form_helper
ERROR - 2016-11-21 16:45:28 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
INFO - 2016-11-21 16:45:28 --> Database Driver Class Initialized
ERROR - 2016-11-21 16:45:28 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 16:45:28 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:45:28 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
ERROR - 2016-11-21 16:45:28 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:45:28 --> Config Class Initialized
INFO - 2016-11-21 16:45:28 --> Controller Class Initialized
INFO - 2016-11-21 16:45:28 --> Hooks Class Initialized
INFO - 2016-11-21 16:45:28 --> Model Class Initialized
DEBUG - 2016-11-21 16:45:28 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:45:28 --> Form Validation Class Initialized
INFO - 2016-11-21 16:45:28 --> Utf8 Class Initialized
INFO - 2016-11-21 16:45:28 --> URI Class Initialized
INFO - 2016-11-21 16:45:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:45:28 --> Router Class Initialized
INFO - 2016-11-21 16:45:28 --> Pagination Class Initialized
INFO - 2016-11-21 16:45:28 --> Helper loaded: app_helper
INFO - 2016-11-21 16:45:28 --> Output Class Initialized
INFO - 2016-11-21 16:45:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 16:45:28 --> Security Class Initialized
DEBUG - 2016-11-21 16:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:45:28 --> Input Class Initialized
INFO - 2016-11-21 16:45:28 --> Language Class Initialized
INFO - 2016-11-21 16:45:28 --> Loader Class Initialized
ERROR - 2016-11-21 16:45:28 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:45:28 --> Helper loaded: url_helper
INFO - 2016-11-21 16:45:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:45:28 --> Helper loaded: form_helper
ERROR - 2016-11-21 16:45:28 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
INFO - 2016-11-21 16:45:28 --> Database Driver Class Initialized
ERROR - 2016-11-21 16:45:28 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 16:45:28 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:45:28 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
ERROR - 2016-11-21 16:45:28 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:45:28 --> Config Class Initialized
INFO - 2016-11-21 16:45:28 --> Controller Class Initialized
INFO - 2016-11-21 16:45:28 --> Hooks Class Initialized
INFO - 2016-11-21 16:45:28 --> Model Class Initialized
DEBUG - 2016-11-21 16:45:28 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:45:28 --> Form Validation Class Initialized
INFO - 2016-11-21 16:45:28 --> Utf8 Class Initialized
INFO - 2016-11-21 16:45:28 --> URI Class Initialized
INFO - 2016-11-21 16:45:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:45:28 --> Router Class Initialized
INFO - 2016-11-21 16:45:28 --> Pagination Class Initialized
INFO - 2016-11-21 16:45:28 --> Helper loaded: app_helper
INFO - 2016-11-21 16:45:28 --> Output Class Initialized
INFO - 2016-11-21 16:45:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 16:45:28 --> Security Class Initialized
DEBUG - 2016-11-21 16:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:45:28 --> Input Class Initialized
INFO - 2016-11-21 16:45:28 --> Language Class Initialized
INFO - 2016-11-21 16:45:28 --> Loader Class Initialized
ERROR - 2016-11-21 16:45:28 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:45:28 --> Helper loaded: url_helper
INFO - 2016-11-21 16:45:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:45:28 --> Helper loaded: form_helper
ERROR - 2016-11-21 16:45:28 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
INFO - 2016-11-21 16:45:28 --> Database Driver Class Initialized
ERROR - 2016-11-21 16:45:29 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 16:45:29 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:45:29 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
ERROR - 2016-11-21 16:45:29 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:45:29 --> Controller Class Initialized
INFO - 2016-11-21 16:45:29 --> Config Class Initialized
INFO - 2016-11-21 16:45:29 --> Hooks Class Initialized
INFO - 2016-11-21 16:45:29 --> Model Class Initialized
DEBUG - 2016-11-21 16:45:29 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:45:29 --> Form Validation Class Initialized
INFO - 2016-11-21 16:45:29 --> Utf8 Class Initialized
INFO - 2016-11-21 16:45:29 --> URI Class Initialized
INFO - 2016-11-21 16:45:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:45:29 --> Router Class Initialized
INFO - 2016-11-21 16:45:29 --> Pagination Class Initialized
INFO - 2016-11-21 16:45:29 --> Helper loaded: app_helper
INFO - 2016-11-21 16:45:29 --> Output Class Initialized
INFO - 2016-11-21 16:45:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 16:45:29 --> Security Class Initialized
DEBUG - 2016-11-21 16:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:45:29 --> Input Class Initialized
INFO - 2016-11-21 16:45:29 --> Language Class Initialized
INFO - 2016-11-21 16:45:29 --> Loader Class Initialized
ERROR - 2016-11-21 16:45:29 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:45:29 --> Helper loaded: url_helper
INFO - 2016-11-21 16:45:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:45:29 --> Helper loaded: form_helper
ERROR - 2016-11-21 16:45:29 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
INFO - 2016-11-21 16:45:29 --> Database Driver Class Initialized
ERROR - 2016-11-21 16:45:29 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 16:45:29 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:45:29 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
ERROR - 2016-11-21 16:45:29 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:45:29 --> Config Class Initialized
INFO - 2016-11-21 16:45:29 --> Controller Class Initialized
INFO - 2016-11-21 16:45:29 --> Hooks Class Initialized
INFO - 2016-11-21 16:45:29 --> Model Class Initialized
DEBUG - 2016-11-21 16:45:29 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:45:29 --> Form Validation Class Initialized
INFO - 2016-11-21 16:45:29 --> Utf8 Class Initialized
INFO - 2016-11-21 16:45:29 --> URI Class Initialized
INFO - 2016-11-21 16:45:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:45:29 --> Router Class Initialized
INFO - 2016-11-21 16:45:29 --> Pagination Class Initialized
INFO - 2016-11-21 16:45:29 --> Helper loaded: app_helper
INFO - 2016-11-21 16:45:29 --> Output Class Initialized
INFO - 2016-11-21 16:45:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 16:45:29 --> Security Class Initialized
DEBUG - 2016-11-21 16:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:45:29 --> Input Class Initialized
INFO - 2016-11-21 16:45:29 --> Language Class Initialized
INFO - 2016-11-21 16:45:29 --> Loader Class Initialized
ERROR - 2016-11-21 16:45:29 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:45:29 --> Helper loaded: url_helper
INFO - 2016-11-21 16:45:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:45:29 --> Helper loaded: form_helper
ERROR - 2016-11-21 16:45:29 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
INFO - 2016-11-21 16:45:29 --> Database Driver Class Initialized
ERROR - 2016-11-21 16:45:29 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 16:45:29 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:45:29 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
ERROR - 2016-11-21 16:45:30 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:45:30 --> Config Class Initialized
INFO - 2016-11-21 16:45:30 --> Controller Class Initialized
INFO - 2016-11-21 16:45:30 --> Hooks Class Initialized
INFO - 2016-11-21 16:45:30 --> Model Class Initialized
DEBUG - 2016-11-21 16:45:30 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:45:30 --> Form Validation Class Initialized
INFO - 2016-11-21 16:45:30 --> Utf8 Class Initialized
INFO - 2016-11-21 16:45:30 --> URI Class Initialized
INFO - 2016-11-21 16:45:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:45:30 --> Router Class Initialized
INFO - 2016-11-21 16:45:30 --> Pagination Class Initialized
INFO - 2016-11-21 16:45:30 --> Helper loaded: app_helper
INFO - 2016-11-21 16:45:30 --> Output Class Initialized
INFO - 2016-11-21 16:45:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 16:45:30 --> Security Class Initialized
DEBUG - 2016-11-21 16:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:45:30 --> Input Class Initialized
INFO - 2016-11-21 16:45:30 --> Language Class Initialized
INFO - 2016-11-21 16:45:30 --> Loader Class Initialized
ERROR - 2016-11-21 16:45:30 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:45:30 --> Helper loaded: url_helper
INFO - 2016-11-21 16:45:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:45:30 --> Helper loaded: form_helper
ERROR - 2016-11-21 16:45:30 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
INFO - 2016-11-21 16:45:30 --> Database Driver Class Initialized
ERROR - 2016-11-21 16:45:30 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 16:45:30 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:45:30 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
ERROR - 2016-11-21 16:45:30 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:45:30 --> Controller Class Initialized
INFO - 2016-11-21 16:45:30 --> Model Class Initialized
INFO - 2016-11-21 16:45:30 --> Form Validation Class Initialized
INFO - 2016-11-21 16:45:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:45:30 --> Pagination Class Initialized
INFO - 2016-11-21 16:45:30 --> Helper loaded: app_helper
INFO - 2016-11-21 16:45:30 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 16:45:30 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:45:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
ERROR - 2016-11-21 16:45:30 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
ERROR - 2016-11-21 16:45:30 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 16:45:30 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:45:30 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
ERROR - 2016-11-21 16:45:30 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:45:30 --> Controller Class Initialized
INFO - 2016-11-21 16:45:30 --> Model Class Initialized
INFO - 2016-11-21 16:45:30 --> Form Validation Class Initialized
INFO - 2016-11-21 16:45:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:45:30 --> Pagination Class Initialized
INFO - 2016-11-21 16:45:30 --> Helper loaded: app_helper
INFO - 2016-11-21 16:45:31 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 16:45:31 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:45:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
ERROR - 2016-11-21 16:45:31 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
ERROR - 2016-11-21 16:45:31 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 16:45:31 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:45:31 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
ERROR - 2016-11-21 16:45:31 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:45:31 --> Controller Class Initialized
INFO - 2016-11-21 16:45:31 --> Model Class Initialized
INFO - 2016-11-21 16:45:31 --> Form Validation Class Initialized
INFO - 2016-11-21 16:45:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:45:31 --> Pagination Class Initialized
INFO - 2016-11-21 16:45:31 --> Helper loaded: app_helper
INFO - 2016-11-21 16:45:31 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 16:45:31 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:45:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
ERROR - 2016-11-21 16:45:31 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
ERROR - 2016-11-21 16:45:31 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 16:45:31 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:45:31 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
ERROR - 2016-11-21 16:45:31 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:45:31 --> Controller Class Initialized
INFO - 2016-11-21 16:45:31 --> Model Class Initialized
INFO - 2016-11-21 16:45:31 --> Form Validation Class Initialized
INFO - 2016-11-21 16:45:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:45:31 --> Pagination Class Initialized
INFO - 2016-11-21 16:45:31 --> Helper loaded: app_helper
INFO - 2016-11-21 16:45:31 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 16:45:32 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:45:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
ERROR - 2016-11-21 16:45:32 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
ERROR - 2016-11-21 16:45:32 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 16:45:32 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:45:32 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
ERROR - 2016-11-21 16:45:32 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:45:32 --> Controller Class Initialized
INFO - 2016-11-21 16:45:32 --> Model Class Initialized
INFO - 2016-11-21 16:45:32 --> Form Validation Class Initialized
INFO - 2016-11-21 16:45:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:45:32 --> Pagination Class Initialized
INFO - 2016-11-21 16:45:32 --> Helper loaded: app_helper
INFO - 2016-11-21 16:45:32 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 16:45:32 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:45:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
ERROR - 2016-11-21 16:45:32 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
ERROR - 2016-11-21 16:45:32 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 16:45:32 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:45:32 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
ERROR - 2016-11-21 16:45:32 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 154
INFO - 2016-11-21 16:46:40 --> Config Class Initialized
INFO - 2016-11-21 16:46:40 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:46:40 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:46:40 --> Utf8 Class Initialized
INFO - 2016-11-21 16:46:40 --> URI Class Initialized
DEBUG - 2016-11-21 16:46:40 --> No URI present. Default controller set.
INFO - 2016-11-21 16:46:40 --> Router Class Initialized
INFO - 2016-11-21 16:46:40 --> Output Class Initialized
INFO - 2016-11-21 16:46:40 --> Security Class Initialized
DEBUG - 2016-11-21 16:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:46:40 --> Input Class Initialized
INFO - 2016-11-21 16:46:40 --> Language Class Initialized
INFO - 2016-11-21 16:46:40 --> Loader Class Initialized
INFO - 2016-11-21 16:46:40 --> Helper loaded: url_helper
INFO - 2016-11-21 16:46:40 --> Helper loaded: form_helper
INFO - 2016-11-21 16:46:40 --> Database Driver Class Initialized
INFO - 2016-11-21 16:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:46:40 --> Controller Class Initialized
INFO - 2016-11-21 16:46:40 --> Model Class Initialized
INFO - 2016-11-21 16:46:41 --> Model Class Initialized
INFO - 2016-11-21 16:46:41 --> Model Class Initialized
INFO - 2016-11-21 16:46:41 --> Model Class Initialized
INFO - 2016-11-21 16:46:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:46:41 --> Pagination Class Initialized
INFO - 2016-11-21 16:46:41 --> Helper loaded: app_helper
INFO - 2016-11-21 16:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 16:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 16:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 16:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 16:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 16:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 16:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 16:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 16:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 16:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 16:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 16:46:41 --> Final output sent to browser
DEBUG - 2016-11-21 16:46:41 --> Total execution time: 0.7533
INFO - 2016-11-21 16:47:53 --> Config Class Initialized
INFO - 2016-11-21 16:47:53 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:47:53 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:47:53 --> Utf8 Class Initialized
INFO - 2016-11-21 16:47:53 --> URI Class Initialized
DEBUG - 2016-11-21 16:47:53 --> No URI present. Default controller set.
INFO - 2016-11-21 16:47:53 --> Router Class Initialized
INFO - 2016-11-21 16:47:53 --> Output Class Initialized
INFO - 2016-11-21 16:47:53 --> Security Class Initialized
DEBUG - 2016-11-21 16:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:47:53 --> Input Class Initialized
INFO - 2016-11-21 16:47:54 --> Language Class Initialized
INFO - 2016-11-21 16:47:54 --> Loader Class Initialized
INFO - 2016-11-21 16:47:54 --> Helper loaded: url_helper
INFO - 2016-11-21 16:47:54 --> Helper loaded: form_helper
INFO - 2016-11-21 16:47:54 --> Database Driver Class Initialized
INFO - 2016-11-21 16:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:47:54 --> Controller Class Initialized
INFO - 2016-11-21 16:47:54 --> Model Class Initialized
INFO - 2016-11-21 16:47:54 --> Model Class Initialized
INFO - 2016-11-21 16:47:54 --> Model Class Initialized
INFO - 2016-11-21 16:47:54 --> Model Class Initialized
INFO - 2016-11-21 16:47:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:47:54 --> Pagination Class Initialized
INFO - 2016-11-21 16:47:54 --> Helper loaded: app_helper
INFO - 2016-11-21 16:47:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 16:47:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 16:47:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 16:47:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 16:47:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:47:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 16:47:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 16:47:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 16:47:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 16:47:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 16:47:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 16:47:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 16:47:54 --> Final output sent to browser
DEBUG - 2016-11-21 16:47:54 --> Total execution time: 0.7241
INFO - 2016-11-21 16:48:06 --> Config Class Initialized
INFO - 2016-11-21 16:48:06 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:48:06 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:48:06 --> Utf8 Class Initialized
INFO - 2016-11-21 16:48:07 --> URI Class Initialized
INFO - 2016-11-21 16:48:07 --> Router Class Initialized
INFO - 2016-11-21 16:48:07 --> Output Class Initialized
INFO - 2016-11-21 16:48:07 --> Security Class Initialized
DEBUG - 2016-11-21 16:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:48:07 --> Input Class Initialized
INFO - 2016-11-21 16:48:07 --> Language Class Initialized
INFO - 2016-11-21 16:48:07 --> Loader Class Initialized
INFO - 2016-11-21 16:48:07 --> Helper loaded: url_helper
INFO - 2016-11-21 16:48:07 --> Helper loaded: form_helper
INFO - 2016-11-21 16:48:07 --> Database Driver Class Initialized
INFO - 2016-11-21 16:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:48:07 --> Controller Class Initialized
INFO - 2016-11-21 16:48:07 --> Model Class Initialized
INFO - 2016-11-21 16:48:07 --> Form Validation Class Initialized
INFO - 2016-11-21 16:48:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:48:07 --> Pagination Class Initialized
INFO - 2016-11-21 16:48:07 --> Helper loaded: app_helper
INFO - 2016-11-21 16:48:07 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 16:48:07 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:48:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
ERROR - 2016-11-21 16:48:07 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 9
ERROR - 2016-11-21 16:48:07 --> Severity: Notice --> Undefined property: CI_Config::$settings C:\xampp\htdocs\LMS\app\config\email.php 10
DEBUG - 2016-11-21 16:48:07 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:48:07 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 155
ERROR - 2016-11-21 16:48:07 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 155
INFO - 2016-11-21 16:49:39 --> Config Class Initialized
INFO - 2016-11-21 16:49:39 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:49:39 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:49:39 --> Utf8 Class Initialized
INFO - 2016-11-21 16:49:39 --> URI Class Initialized
DEBUG - 2016-11-21 16:49:39 --> No URI present. Default controller set.
INFO - 2016-11-21 16:49:39 --> Router Class Initialized
INFO - 2016-11-21 16:49:39 --> Output Class Initialized
INFO - 2016-11-21 16:49:39 --> Security Class Initialized
DEBUG - 2016-11-21 16:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:49:39 --> Input Class Initialized
INFO - 2016-11-21 16:49:39 --> Language Class Initialized
INFO - 2016-11-21 16:49:39 --> Loader Class Initialized
INFO - 2016-11-21 16:49:39 --> Helper loaded: url_helper
INFO - 2016-11-21 16:49:39 --> Helper loaded: form_helper
INFO - 2016-11-21 16:49:39 --> Database Driver Class Initialized
INFO - 2016-11-21 16:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:49:39 --> Controller Class Initialized
INFO - 2016-11-21 16:49:39 --> Model Class Initialized
INFO - 2016-11-21 16:49:39 --> Model Class Initialized
INFO - 2016-11-21 16:49:39 --> Model Class Initialized
INFO - 2016-11-21 16:49:39 --> Model Class Initialized
INFO - 2016-11-21 16:49:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:49:39 --> Pagination Class Initialized
INFO - 2016-11-21 16:49:39 --> Helper loaded: app_helper
INFO - 2016-11-21 16:49:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 16:49:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 16:49:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 16:49:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 16:49:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:49:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 16:49:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 16:49:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 16:49:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 16:49:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 16:49:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 16:49:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 16:49:40 --> Final output sent to browser
DEBUG - 2016-11-21 16:49:40 --> Total execution time: 0.6903
INFO - 2016-11-21 16:49:56 --> Config Class Initialized
INFO - 2016-11-21 16:49:56 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:49:56 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:49:56 --> Utf8 Class Initialized
INFO - 2016-11-21 16:49:56 --> URI Class Initialized
INFO - 2016-11-21 16:49:56 --> Router Class Initialized
INFO - 2016-11-21 16:49:56 --> Output Class Initialized
INFO - 2016-11-21 16:49:56 --> Security Class Initialized
DEBUG - 2016-11-21 16:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:49:56 --> Input Class Initialized
INFO - 2016-11-21 16:49:56 --> Language Class Initialized
INFO - 2016-11-21 16:49:56 --> Loader Class Initialized
INFO - 2016-11-21 16:49:56 --> Helper loaded: url_helper
INFO - 2016-11-21 16:49:56 --> Helper loaded: form_helper
INFO - 2016-11-21 16:49:56 --> Database Driver Class Initialized
INFO - 2016-11-21 16:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:49:56 --> Controller Class Initialized
INFO - 2016-11-21 16:49:56 --> Model Class Initialized
INFO - 2016-11-21 16:49:56 --> Form Validation Class Initialized
INFO - 2016-11-21 16:49:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:49:56 --> Pagination Class Initialized
INFO - 2016-11-21 16:49:56 --> Helper loaded: app_helper
INFO - 2016-11-21 16:49:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 16:49:56 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:49:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
DEBUG - 2016-11-21 16:49:56 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:49:56 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 155
ERROR - 2016-11-21 16:49:56 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 155
INFO - 2016-11-21 16:54:39 --> Config Class Initialized
INFO - 2016-11-21 16:54:39 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:54:39 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:54:39 --> Utf8 Class Initialized
INFO - 2016-11-21 16:54:39 --> URI Class Initialized
INFO - 2016-11-21 16:54:39 --> Router Class Initialized
INFO - 2016-11-21 16:54:39 --> Output Class Initialized
INFO - 2016-11-21 16:54:39 --> Security Class Initialized
DEBUG - 2016-11-21 16:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:54:39 --> Input Class Initialized
INFO - 2016-11-21 16:54:39 --> Language Class Initialized
INFO - 2016-11-21 16:54:39 --> Loader Class Initialized
INFO - 2016-11-21 16:54:39 --> Helper loaded: url_helper
INFO - 2016-11-21 16:54:39 --> Helper loaded: form_helper
INFO - 2016-11-21 16:54:39 --> Database Driver Class Initialized
INFO - 2016-11-21 16:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:54:39 --> Controller Class Initialized
INFO - 2016-11-21 16:54:39 --> Model Class Initialized
INFO - 2016-11-21 16:54:39 --> Form Validation Class Initialized
INFO - 2016-11-21 16:54:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:54:39 --> Pagination Class Initialized
INFO - 2016-11-21 16:54:39 --> Helper loaded: app_helper
INFO - 2016-11-21 16:54:39 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 16:54:40 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:54:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
DEBUG - 2016-11-21 16:54:40 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:54:40 --> Severity: Notice --> Undefined property: Leave_application_c::$email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 155
ERROR - 2016-11-21 16:54:40 --> Severity: Error --> Call to a member function from() on null C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 155
INFO - 2016-11-21 16:55:45 --> Config Class Initialized
INFO - 2016-11-21 16:55:45 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:55:45 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:55:45 --> Utf8 Class Initialized
INFO - 2016-11-21 16:55:45 --> URI Class Initialized
DEBUG - 2016-11-21 16:55:45 --> No URI present. Default controller set.
INFO - 2016-11-21 16:55:45 --> Router Class Initialized
INFO - 2016-11-21 16:55:45 --> Output Class Initialized
INFO - 2016-11-21 16:55:45 --> Security Class Initialized
DEBUG - 2016-11-21 16:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:55:45 --> Input Class Initialized
INFO - 2016-11-21 16:55:45 --> Language Class Initialized
INFO - 2016-11-21 16:55:45 --> Loader Class Initialized
INFO - 2016-11-21 16:55:45 --> Helper loaded: url_helper
INFO - 2016-11-21 16:55:45 --> Helper loaded: form_helper
INFO - 2016-11-21 16:55:45 --> Database Driver Class Initialized
INFO - 2016-11-21 16:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:55:46 --> Controller Class Initialized
INFO - 2016-11-21 16:55:46 --> Model Class Initialized
INFO - 2016-11-21 16:55:46 --> Model Class Initialized
INFO - 2016-11-21 16:55:46 --> Model Class Initialized
INFO - 2016-11-21 16:55:46 --> Model Class Initialized
INFO - 2016-11-21 16:55:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:55:46 --> Pagination Class Initialized
INFO - 2016-11-21 16:55:46 --> Helper loaded: app_helper
INFO - 2016-11-21 16:55:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 16:55:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 16:55:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 16:55:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 16:55:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:55:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 16:55:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 16:55:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 16:55:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 16:55:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 16:55:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 16:55:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 16:55:46 --> Final output sent to browser
DEBUG - 2016-11-21 16:55:46 --> Total execution time: 0.7542
INFO - 2016-11-21 16:56:34 --> Config Class Initialized
INFO - 2016-11-21 16:56:35 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:56:35 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:56:35 --> Utf8 Class Initialized
INFO - 2016-11-21 16:56:35 --> URI Class Initialized
INFO - 2016-11-21 16:56:35 --> Router Class Initialized
INFO - 2016-11-21 16:56:35 --> Output Class Initialized
INFO - 2016-11-21 16:56:35 --> Security Class Initialized
DEBUG - 2016-11-21 16:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:56:35 --> Input Class Initialized
INFO - 2016-11-21 16:56:35 --> Language Class Initialized
INFO - 2016-11-21 16:56:35 --> Loader Class Initialized
INFO - 2016-11-21 16:56:35 --> Helper loaded: url_helper
INFO - 2016-11-21 16:56:35 --> Helper loaded: form_helper
INFO - 2016-11-21 16:56:35 --> Database Driver Class Initialized
INFO - 2016-11-21 16:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:56:35 --> Controller Class Initialized
INFO - 2016-11-21 16:56:35 --> Model Class Initialized
INFO - 2016-11-21 16:56:35 --> Form Validation Class Initialized
INFO - 2016-11-21 16:56:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:56:35 --> Pagination Class Initialized
INFO - 2016-11-21 16:56:35 --> Helper loaded: app_helper
INFO - 2016-11-21 16:56:35 --> Email Class Initialized
INFO - 2016-11-21 16:56:35 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 16:56:35 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:56:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
DEBUG - 2016-11-21 16:56:35 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:56:35 --> Severity: Notice --> Undefined variable: leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 163
ERROR - 2016-11-21 16:56:35 --> Severity: Notice --> Undefined variable: application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 164
ERROR - 2016-11-21 16:56:35 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 165
ERROR - 2016-11-21 16:56:35 --> Severity: Notice --> Undefined variable: userName C:\xampp\htdocs\LMS\app\views\email_template.php 11
INFO - 2016-11-21 16:56:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-21 16:56:36 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-21 16:56:37 --> Final output sent to browser
DEBUG - 2016-11-21 16:56:37 --> Total execution time: 2.3504
INFO - 2016-11-21 16:57:38 --> Config Class Initialized
INFO - 2016-11-21 16:57:38 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:57:38 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:57:38 --> Utf8 Class Initialized
INFO - 2016-11-21 16:57:38 --> URI Class Initialized
INFO - 2016-11-21 16:57:38 --> Router Class Initialized
INFO - 2016-11-21 16:57:38 --> Output Class Initialized
INFO - 2016-11-21 16:57:38 --> Security Class Initialized
DEBUG - 2016-11-21 16:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:57:38 --> Input Class Initialized
INFO - 2016-11-21 16:57:38 --> Language Class Initialized
INFO - 2016-11-21 16:57:38 --> Loader Class Initialized
INFO - 2016-11-21 16:57:38 --> Helper loaded: url_helper
INFO - 2016-11-21 16:57:38 --> Helper loaded: form_helper
INFO - 2016-11-21 16:57:38 --> Database Driver Class Initialized
INFO - 2016-11-21 16:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:57:38 --> Controller Class Initialized
INFO - 2016-11-21 16:57:38 --> Model Class Initialized
INFO - 2016-11-21 16:57:38 --> Form Validation Class Initialized
INFO - 2016-11-21 16:57:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:57:38 --> Pagination Class Initialized
INFO - 2016-11-21 16:57:38 --> Helper loaded: app_helper
INFO - 2016-11-21 16:57:38 --> Email Class Initialized
INFO - 2016-11-21 16:57:38 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 16:57:38 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:57:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:57:45 --> Config Class Initialized
INFO - 2016-11-21 16:57:45 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:57:45 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:57:45 --> Utf8 Class Initialized
INFO - 2016-11-21 16:57:45 --> URI Class Initialized
DEBUG - 2016-11-21 16:57:46 --> No URI present. Default controller set.
INFO - 2016-11-21 16:57:46 --> Router Class Initialized
INFO - 2016-11-21 16:57:46 --> Output Class Initialized
INFO - 2016-11-21 16:57:46 --> Security Class Initialized
DEBUG - 2016-11-21 16:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:57:46 --> Input Class Initialized
INFO - 2016-11-21 16:57:46 --> Language Class Initialized
INFO - 2016-11-21 16:57:46 --> Loader Class Initialized
INFO - 2016-11-21 16:57:46 --> Helper loaded: url_helper
INFO - 2016-11-21 16:57:46 --> Helper loaded: form_helper
INFO - 2016-11-21 16:57:46 --> Database Driver Class Initialized
INFO - 2016-11-21 16:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:57:46 --> Controller Class Initialized
INFO - 2016-11-21 16:57:46 --> Model Class Initialized
INFO - 2016-11-21 16:57:46 --> Model Class Initialized
INFO - 2016-11-21 16:57:46 --> Model Class Initialized
INFO - 2016-11-21 16:57:46 --> Model Class Initialized
INFO - 2016-11-21 16:57:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:57:46 --> Pagination Class Initialized
INFO - 2016-11-21 16:57:46 --> Helper loaded: app_helper
INFO - 2016-11-21 16:57:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 16:57:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 16:57:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 16:57:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 16:57:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:57:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 16:57:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 16:57:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 16:57:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 16:57:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 16:57:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 16:57:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 16:57:46 --> Final output sent to browser
DEBUG - 2016-11-21 16:57:46 --> Total execution time: 0.6991
INFO - 2016-11-21 16:58:11 --> Config Class Initialized
INFO - 2016-11-21 16:58:11 --> Hooks Class Initialized
DEBUG - 2016-11-21 16:58:11 --> UTF-8 Support Enabled
INFO - 2016-11-21 16:58:11 --> Utf8 Class Initialized
INFO - 2016-11-21 16:58:11 --> URI Class Initialized
INFO - 2016-11-21 16:58:11 --> Router Class Initialized
INFO - 2016-11-21 16:58:11 --> Output Class Initialized
INFO - 2016-11-21 16:58:11 --> Security Class Initialized
DEBUG - 2016-11-21 16:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 16:58:11 --> Input Class Initialized
INFO - 2016-11-21 16:58:11 --> Language Class Initialized
INFO - 2016-11-21 16:58:11 --> Loader Class Initialized
INFO - 2016-11-21 16:58:11 --> Helper loaded: url_helper
INFO - 2016-11-21 16:58:11 --> Helper loaded: form_helper
INFO - 2016-11-21 16:58:11 --> Database Driver Class Initialized
INFO - 2016-11-21 16:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 16:58:11 --> Controller Class Initialized
INFO - 2016-11-21 16:58:11 --> Model Class Initialized
INFO - 2016-11-21 16:58:11 --> Form Validation Class Initialized
INFO - 2016-11-21 16:58:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 16:58:11 --> Pagination Class Initialized
INFO - 2016-11-21 16:58:11 --> Helper loaded: app_helper
INFO - 2016-11-21 16:58:11 --> Email Class Initialized
INFO - 2016-11-21 16:58:11 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 16:58:11 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:58:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 17:01:04 --> Config Class Initialized
INFO - 2016-11-21 17:01:04 --> Hooks Class Initialized
DEBUG - 2016-11-21 17:01:04 --> UTF-8 Support Enabled
INFO - 2016-11-21 17:01:04 --> Utf8 Class Initialized
INFO - 2016-11-21 17:01:04 --> URI Class Initialized
DEBUG - 2016-11-21 17:01:04 --> No URI present. Default controller set.
INFO - 2016-11-21 17:01:04 --> Router Class Initialized
INFO - 2016-11-21 17:01:04 --> Output Class Initialized
INFO - 2016-11-21 17:01:04 --> Security Class Initialized
DEBUG - 2016-11-21 17:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 17:01:04 --> Input Class Initialized
INFO - 2016-11-21 17:01:04 --> Language Class Initialized
INFO - 2016-11-21 17:01:04 --> Loader Class Initialized
INFO - 2016-11-21 17:01:04 --> Helper loaded: url_helper
INFO - 2016-11-21 17:01:04 --> Helper loaded: form_helper
INFO - 2016-11-21 17:01:04 --> Database Driver Class Initialized
INFO - 2016-11-21 17:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 17:01:04 --> Controller Class Initialized
INFO - 2016-11-21 17:01:04 --> Model Class Initialized
INFO - 2016-11-21 17:01:04 --> Model Class Initialized
INFO - 2016-11-21 17:01:04 --> Model Class Initialized
INFO - 2016-11-21 17:01:04 --> Model Class Initialized
INFO - 2016-11-21 17:01:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 17:01:04 --> Pagination Class Initialized
INFO - 2016-11-21 17:01:04 --> Helper loaded: app_helper
INFO - 2016-11-21 17:01:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 17:01:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 17:01:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 17:01:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 17:01:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 17:01:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 17:01:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 17:01:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 17:01:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 17:01:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 17:01:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 17:01:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 17:01:05 --> Final output sent to browser
DEBUG - 2016-11-21 17:01:05 --> Total execution time: 1.0268
INFO - 2016-11-21 17:06:23 --> Config Class Initialized
INFO - 2016-11-21 17:06:23 --> Hooks Class Initialized
DEBUG - 2016-11-21 17:06:23 --> UTF-8 Support Enabled
INFO - 2016-11-21 17:06:23 --> Utf8 Class Initialized
INFO - 2016-11-21 17:06:23 --> URI Class Initialized
DEBUG - 2016-11-21 17:06:23 --> No URI present. Default controller set.
INFO - 2016-11-21 17:06:23 --> Router Class Initialized
INFO - 2016-11-21 17:06:23 --> Output Class Initialized
INFO - 2016-11-21 17:06:23 --> Security Class Initialized
DEBUG - 2016-11-21 17:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 17:06:23 --> Input Class Initialized
INFO - 2016-11-21 17:06:23 --> Language Class Initialized
INFO - 2016-11-21 17:06:23 --> Loader Class Initialized
INFO - 2016-11-21 17:06:23 --> Helper loaded: url_helper
INFO - 2016-11-21 17:06:23 --> Helper loaded: form_helper
INFO - 2016-11-21 17:06:23 --> Database Driver Class Initialized
INFO - 2016-11-21 17:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 17:06:23 --> Controller Class Initialized
INFO - 2016-11-21 17:06:23 --> Model Class Initialized
INFO - 2016-11-21 17:06:23 --> Model Class Initialized
INFO - 2016-11-21 17:06:23 --> Model Class Initialized
INFO - 2016-11-21 17:06:24 --> Model Class Initialized
INFO - 2016-11-21 17:06:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 17:06:24 --> Pagination Class Initialized
INFO - 2016-11-21 17:06:24 --> Helper loaded: app_helper
INFO - 2016-11-21 17:06:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 17:06:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 17:06:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 17:06:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 17:06:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 17:06:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 17:06:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 17:06:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 17:06:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 17:06:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 17:06:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 17:06:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 17:06:24 --> Final output sent to browser
DEBUG - 2016-11-21 17:06:24 --> Total execution time: 0.7410
INFO - 2016-11-21 17:06:42 --> Config Class Initialized
INFO - 2016-11-21 17:06:42 --> Hooks Class Initialized
DEBUG - 2016-11-21 17:06:42 --> UTF-8 Support Enabled
INFO - 2016-11-21 17:06:43 --> Utf8 Class Initialized
INFO - 2016-11-21 17:06:43 --> URI Class Initialized
INFO - 2016-11-21 17:06:43 --> Router Class Initialized
INFO - 2016-11-21 17:06:43 --> Output Class Initialized
INFO - 2016-11-21 17:06:43 --> Security Class Initialized
DEBUG - 2016-11-21 17:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 17:06:43 --> Input Class Initialized
INFO - 2016-11-21 17:06:43 --> Language Class Initialized
INFO - 2016-11-21 17:06:43 --> Loader Class Initialized
INFO - 2016-11-21 17:06:43 --> Helper loaded: url_helper
INFO - 2016-11-21 17:06:43 --> Helper loaded: form_helper
INFO - 2016-11-21 17:06:43 --> Database Driver Class Initialized
INFO - 2016-11-21 17:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 17:06:43 --> Controller Class Initialized
INFO - 2016-11-21 17:06:43 --> Model Class Initialized
INFO - 2016-11-21 17:06:43 --> Form Validation Class Initialized
INFO - 2016-11-21 17:06:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 17:06:43 --> Pagination Class Initialized
INFO - 2016-11-21 17:06:43 --> Helper loaded: app_helper
INFO - 2016-11-21 17:06:43 --> Email Class Initialized
INFO - 2016-11-21 17:06:43 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 17:06:43 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 17:06:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
DEBUG - 2016-11-21 17:06:43 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 17:06:43 --> Severity: Notice --> Undefined variable: leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 162
ERROR - 2016-11-21 17:06:43 --> Severity: Notice --> Undefined variable: application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 163
ERROR - 2016-11-21 17:06:43 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 164
INFO - 2016-11-21 17:06:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-21 17:06:44 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-21 17:06:44 --> Final output sent to browser
DEBUG - 2016-11-21 17:06:44 --> Total execution time: 1.5350
INFO - 2016-11-21 17:10:54 --> Config Class Initialized
INFO - 2016-11-21 17:10:54 --> Hooks Class Initialized
DEBUG - 2016-11-21 17:10:54 --> UTF-8 Support Enabled
INFO - 2016-11-21 17:10:54 --> Utf8 Class Initialized
INFO - 2016-11-21 17:10:54 --> URI Class Initialized
DEBUG - 2016-11-21 17:10:54 --> No URI present. Default controller set.
INFO - 2016-11-21 17:10:54 --> Router Class Initialized
INFO - 2016-11-21 17:10:54 --> Output Class Initialized
INFO - 2016-11-21 17:10:54 --> Security Class Initialized
DEBUG - 2016-11-21 17:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 17:10:54 --> Input Class Initialized
INFO - 2016-11-21 17:10:54 --> Language Class Initialized
INFO - 2016-11-21 17:10:54 --> Loader Class Initialized
INFO - 2016-11-21 17:10:54 --> Helper loaded: url_helper
INFO - 2016-11-21 17:10:54 --> Helper loaded: form_helper
INFO - 2016-11-21 17:10:54 --> Database Driver Class Initialized
INFO - 2016-11-21 17:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 17:10:54 --> Controller Class Initialized
INFO - 2016-11-21 17:10:54 --> Model Class Initialized
INFO - 2016-11-21 17:10:54 --> Model Class Initialized
INFO - 2016-11-21 17:10:54 --> Model Class Initialized
INFO - 2016-11-21 17:10:54 --> Model Class Initialized
INFO - 2016-11-21 17:10:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 17:10:54 --> Pagination Class Initialized
INFO - 2016-11-21 17:10:54 --> Helper loaded: app_helper
INFO - 2016-11-21 17:10:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 17:10:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 17:10:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 17:10:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 17:10:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 17:10:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 17:10:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 17:10:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 17:10:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 17:10:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 17:10:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 17:10:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 17:10:55 --> Final output sent to browser
DEBUG - 2016-11-21 17:10:55 --> Total execution time: 0.7323
INFO - 2016-11-21 17:11:21 --> Config Class Initialized
INFO - 2016-11-21 17:11:21 --> Hooks Class Initialized
DEBUG - 2016-11-21 17:11:21 --> UTF-8 Support Enabled
INFO - 2016-11-21 17:11:21 --> Utf8 Class Initialized
INFO - 2016-11-21 17:11:21 --> URI Class Initialized
INFO - 2016-11-21 17:11:21 --> Router Class Initialized
INFO - 2016-11-21 17:11:21 --> Output Class Initialized
INFO - 2016-11-21 17:11:21 --> Security Class Initialized
DEBUG - 2016-11-21 17:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 17:11:21 --> Input Class Initialized
INFO - 2016-11-21 17:11:22 --> Language Class Initialized
INFO - 2016-11-21 17:11:22 --> Loader Class Initialized
INFO - 2016-11-21 17:11:22 --> Helper loaded: url_helper
INFO - 2016-11-21 17:11:22 --> Helper loaded: form_helper
INFO - 2016-11-21 17:11:22 --> Database Driver Class Initialized
INFO - 2016-11-21 17:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 17:11:22 --> Controller Class Initialized
INFO - 2016-11-21 17:11:22 --> Model Class Initialized
INFO - 2016-11-21 17:11:22 --> Form Validation Class Initialized
INFO - 2016-11-21 17:11:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 17:11:22 --> Pagination Class Initialized
INFO - 2016-11-21 17:11:22 --> Helper loaded: app_helper
ERROR - 2016-11-21 17:11:22 --> Severity: Notice --> Undefined property: CI_Loader::$email C:\xampp\htdocs\LMS\app\config\email.php 19
ERROR - 2016-11-21 17:11:22 --> Severity: Error --> Call to a member function initialize() on null C:\xampp\htdocs\LMS\app\config\email.php 19
INFO - 2016-11-21 17:12:06 --> Config Class Initialized
INFO - 2016-11-21 17:12:06 --> Hooks Class Initialized
DEBUG - 2016-11-21 17:12:06 --> UTF-8 Support Enabled
INFO - 2016-11-21 17:12:06 --> Utf8 Class Initialized
INFO - 2016-11-21 17:12:06 --> URI Class Initialized
DEBUG - 2016-11-21 17:12:06 --> No URI present. Default controller set.
INFO - 2016-11-21 17:12:06 --> Router Class Initialized
INFO - 2016-11-21 17:12:06 --> Output Class Initialized
INFO - 2016-11-21 17:12:06 --> Security Class Initialized
DEBUG - 2016-11-21 17:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 17:12:06 --> Input Class Initialized
INFO - 2016-11-21 17:12:06 --> Language Class Initialized
INFO - 2016-11-21 17:12:06 --> Loader Class Initialized
INFO - 2016-11-21 17:12:06 --> Helper loaded: url_helper
INFO - 2016-11-21 17:12:06 --> Helper loaded: form_helper
INFO - 2016-11-21 17:12:06 --> Database Driver Class Initialized
INFO - 2016-11-21 17:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 17:12:06 --> Controller Class Initialized
INFO - 2016-11-21 17:12:06 --> Model Class Initialized
INFO - 2016-11-21 17:12:06 --> Model Class Initialized
INFO - 2016-11-21 17:12:06 --> Model Class Initialized
INFO - 2016-11-21 17:12:06 --> Model Class Initialized
INFO - 2016-11-21 17:12:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 17:12:06 --> Pagination Class Initialized
INFO - 2016-11-21 17:12:06 --> Helper loaded: app_helper
INFO - 2016-11-21 17:12:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 17:12:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 17:12:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 17:12:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 17:12:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 17:12:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 17:12:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 17:12:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 17:12:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 17:12:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 17:12:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 17:12:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 17:12:07 --> Final output sent to browser
DEBUG - 2016-11-21 17:12:07 --> Total execution time: 0.7055
INFO - 2016-11-21 17:12:49 --> Config Class Initialized
INFO - 2016-11-21 17:12:49 --> Hooks Class Initialized
DEBUG - 2016-11-21 17:12:49 --> UTF-8 Support Enabled
INFO - 2016-11-21 17:12:49 --> Utf8 Class Initialized
INFO - 2016-11-21 17:12:49 --> URI Class Initialized
INFO - 2016-11-21 17:12:49 --> Router Class Initialized
INFO - 2016-11-21 17:12:49 --> Output Class Initialized
INFO - 2016-11-21 17:12:49 --> Security Class Initialized
DEBUG - 2016-11-21 17:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 17:12:49 --> Input Class Initialized
INFO - 2016-11-21 17:12:49 --> Language Class Initialized
INFO - 2016-11-21 17:12:49 --> Loader Class Initialized
INFO - 2016-11-21 17:12:49 --> Helper loaded: url_helper
INFO - 2016-11-21 17:12:50 --> Helper loaded: form_helper
INFO - 2016-11-21 17:12:50 --> Database Driver Class Initialized
INFO - 2016-11-21 17:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 17:12:50 --> Controller Class Initialized
INFO - 2016-11-21 17:12:50 --> Model Class Initialized
INFO - 2016-11-21 17:12:50 --> Form Validation Class Initialized
INFO - 2016-11-21 17:12:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 17:12:50 --> Pagination Class Initialized
INFO - 2016-11-21 17:12:50 --> Helper loaded: app_helper
INFO - 2016-11-21 17:12:50 --> Email Class Initialized
INFO - 2016-11-21 17:12:50 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 17:12:50 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 17:12:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
DEBUG - 2016-11-21 17:12:50 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 17:12:50 --> Severity: Notice --> Undefined variable: leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 162
ERROR - 2016-11-21 17:12:50 --> Severity: Notice --> Undefined variable: application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 163
ERROR - 2016-11-21 17:12:50 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 164
INFO - 2016-11-21 17:12:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-21 17:12:51 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-21 17:12:51 --> Final output sent to browser
DEBUG - 2016-11-21 17:12:51 --> Total execution time: 1.7021
INFO - 2016-11-21 17:13:16 --> Config Class Initialized
INFO - 2016-11-21 17:13:16 --> Hooks Class Initialized
DEBUG - 2016-11-21 17:13:16 --> UTF-8 Support Enabled
INFO - 2016-11-21 17:13:16 --> Utf8 Class Initialized
INFO - 2016-11-21 17:13:16 --> URI Class Initialized
DEBUG - 2016-11-21 17:13:16 --> No URI present. Default controller set.
INFO - 2016-11-21 17:13:16 --> Router Class Initialized
INFO - 2016-11-21 17:13:16 --> Output Class Initialized
INFO - 2016-11-21 17:13:16 --> Security Class Initialized
DEBUG - 2016-11-21 17:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 17:13:16 --> Input Class Initialized
INFO - 2016-11-21 17:13:16 --> Language Class Initialized
INFO - 2016-11-21 17:13:16 --> Loader Class Initialized
INFO - 2016-11-21 17:13:16 --> Helper loaded: url_helper
INFO - 2016-11-21 17:13:16 --> Helper loaded: form_helper
INFO - 2016-11-21 17:13:16 --> Database Driver Class Initialized
INFO - 2016-11-21 17:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 17:13:16 --> Controller Class Initialized
INFO - 2016-11-21 17:13:16 --> Model Class Initialized
INFO - 2016-11-21 17:13:16 --> Model Class Initialized
INFO - 2016-11-21 17:13:16 --> Model Class Initialized
INFO - 2016-11-21 17:13:16 --> Model Class Initialized
INFO - 2016-11-21 17:13:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 17:13:16 --> Pagination Class Initialized
INFO - 2016-11-21 17:13:16 --> Helper loaded: app_helper
INFO - 2016-11-21 17:13:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 17:13:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 17:13:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 17:13:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 17:13:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 17:13:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 17:13:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 17:13:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 17:13:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 17:13:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 17:13:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 17:13:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 17:13:16 --> Final output sent to browser
DEBUG - 2016-11-21 17:13:16 --> Total execution time: 0.7221
INFO - 2016-11-21 17:13:33 --> Config Class Initialized
INFO - 2016-11-21 17:13:33 --> Hooks Class Initialized
DEBUG - 2016-11-21 17:13:34 --> UTF-8 Support Enabled
INFO - 2016-11-21 17:13:34 --> Utf8 Class Initialized
INFO - 2016-11-21 17:13:34 --> URI Class Initialized
INFO - 2016-11-21 17:13:34 --> Router Class Initialized
INFO - 2016-11-21 17:13:34 --> Output Class Initialized
INFO - 2016-11-21 17:13:34 --> Security Class Initialized
DEBUG - 2016-11-21 17:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 17:13:34 --> Input Class Initialized
INFO - 2016-11-21 17:13:34 --> Language Class Initialized
INFO - 2016-11-21 17:13:34 --> Loader Class Initialized
INFO - 2016-11-21 17:13:34 --> Helper loaded: url_helper
INFO - 2016-11-21 17:13:34 --> Helper loaded: form_helper
INFO - 2016-11-21 17:13:34 --> Database Driver Class Initialized
INFO - 2016-11-21 17:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 17:13:34 --> Controller Class Initialized
INFO - 2016-11-21 17:13:34 --> Model Class Initialized
INFO - 2016-11-21 17:13:34 --> Form Validation Class Initialized
INFO - 2016-11-21 17:13:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 17:13:34 --> Pagination Class Initialized
INFO - 2016-11-21 17:13:34 --> Helper loaded: app_helper
INFO - 2016-11-21 17:13:34 --> Email Class Initialized
INFO - 2016-11-21 17:13:34 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 17:13:34 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 17:13:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
DEBUG - 2016-11-21 17:13:34 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 17:13:34 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 155
ERROR - 2016-11-21 17:13:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\sys\libraries\Email.php 452
ERROR - 2016-11-21 17:13:34 --> Severity: Notice --> Undefined variable: leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 163
ERROR - 2016-11-21 17:13:34 --> Severity: Notice --> Undefined variable: application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 164
ERROR - 2016-11-21 17:13:34 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 165
INFO - 2016-11-21 17:13:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-21 17:13:35 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-21 17:13:35 --> Final output sent to browser
DEBUG - 2016-11-21 17:13:35 --> Total execution time: 1.6601
INFO - 2016-11-21 17:14:42 --> Config Class Initialized
INFO - 2016-11-21 17:14:42 --> Hooks Class Initialized
DEBUG - 2016-11-21 17:14:42 --> UTF-8 Support Enabled
INFO - 2016-11-21 17:14:42 --> Utf8 Class Initialized
INFO - 2016-11-21 17:14:42 --> URI Class Initialized
DEBUG - 2016-11-21 17:14:42 --> No URI present. Default controller set.
INFO - 2016-11-21 17:14:42 --> Router Class Initialized
INFO - 2016-11-21 17:14:42 --> Output Class Initialized
INFO - 2016-11-21 17:14:42 --> Security Class Initialized
DEBUG - 2016-11-21 17:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 17:14:42 --> Input Class Initialized
INFO - 2016-11-21 17:14:42 --> Language Class Initialized
INFO - 2016-11-21 17:14:42 --> Loader Class Initialized
INFO - 2016-11-21 17:14:42 --> Helper loaded: url_helper
INFO - 2016-11-21 17:14:42 --> Helper loaded: form_helper
INFO - 2016-11-21 17:14:42 --> Database Driver Class Initialized
INFO - 2016-11-21 17:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 17:14:42 --> Controller Class Initialized
INFO - 2016-11-21 17:14:42 --> Model Class Initialized
INFO - 2016-11-21 17:14:42 --> Model Class Initialized
INFO - 2016-11-21 17:14:42 --> Model Class Initialized
INFO - 2016-11-21 17:14:42 --> Model Class Initialized
INFO - 2016-11-21 17:14:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 17:14:42 --> Pagination Class Initialized
INFO - 2016-11-21 17:14:42 --> Helper loaded: app_helper
INFO - 2016-11-21 17:14:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 17:14:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 17:14:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 17:14:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 17:14:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 17:14:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 17:14:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 17:14:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 17:14:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 17:14:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 17:14:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 17:14:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 17:14:43 --> Final output sent to browser
DEBUG - 2016-11-21 17:14:43 --> Total execution time: 0.8331
INFO - 2016-11-21 17:44:25 --> Config Class Initialized
INFO - 2016-11-21 17:44:25 --> Hooks Class Initialized
DEBUG - 2016-11-21 17:44:25 --> UTF-8 Support Enabled
INFO - 2016-11-21 17:44:25 --> Utf8 Class Initialized
INFO - 2016-11-21 17:44:25 --> URI Class Initialized
DEBUG - 2016-11-21 17:44:25 --> No URI present. Default controller set.
INFO - 2016-11-21 17:44:25 --> Router Class Initialized
INFO - 2016-11-21 17:44:25 --> Output Class Initialized
INFO - 2016-11-21 17:44:25 --> Security Class Initialized
DEBUG - 2016-11-21 17:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 17:44:25 --> Input Class Initialized
INFO - 2016-11-21 17:44:25 --> Language Class Initialized
INFO - 2016-11-21 17:44:25 --> Loader Class Initialized
INFO - 2016-11-21 17:44:25 --> Helper loaded: url_helper
INFO - 2016-11-21 17:44:25 --> Helper loaded: form_helper
INFO - 2016-11-21 17:44:25 --> Database Driver Class Initialized
INFO - 2016-11-21 17:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 17:44:25 --> Controller Class Initialized
INFO - 2016-11-21 17:44:25 --> Model Class Initialized
INFO - 2016-11-21 17:44:25 --> Model Class Initialized
INFO - 2016-11-21 17:44:25 --> Model Class Initialized
INFO - 2016-11-21 17:44:25 --> Model Class Initialized
INFO - 2016-11-21 17:44:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 17:44:25 --> Pagination Class Initialized
INFO - 2016-11-21 17:44:25 --> Helper loaded: app_helper
INFO - 2016-11-21 17:44:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 17:44:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 17:44:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 17:44:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 17:44:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 17:44:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 17:44:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 17:44:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 17:44:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 17:44:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 17:44:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 17:44:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 17:44:26 --> Final output sent to browser
DEBUG - 2016-11-21 17:44:26 --> Total execution time: 0.7396
INFO - 2016-11-21 17:44:44 --> Config Class Initialized
INFO - 2016-11-21 17:44:44 --> Hooks Class Initialized
DEBUG - 2016-11-21 17:44:44 --> UTF-8 Support Enabled
INFO - 2016-11-21 17:44:44 --> Utf8 Class Initialized
INFO - 2016-11-21 17:44:44 --> URI Class Initialized
INFO - 2016-11-21 17:44:44 --> Router Class Initialized
INFO - 2016-11-21 17:44:44 --> Output Class Initialized
INFO - 2016-11-21 17:44:44 --> Security Class Initialized
DEBUG - 2016-11-21 17:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 17:44:44 --> Input Class Initialized
INFO - 2016-11-21 17:44:44 --> Language Class Initialized
INFO - 2016-11-21 17:44:44 --> Loader Class Initialized
INFO - 2016-11-21 17:44:44 --> Helper loaded: url_helper
INFO - 2016-11-21 17:44:44 --> Helper loaded: form_helper
INFO - 2016-11-21 17:44:44 --> Database Driver Class Initialized
INFO - 2016-11-21 17:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 17:44:44 --> Controller Class Initialized
INFO - 2016-11-21 17:44:44 --> Model Class Initialized
INFO - 2016-11-21 17:44:44 --> Form Validation Class Initialized
INFO - 2016-11-21 17:44:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 17:44:44 --> Pagination Class Initialized
INFO - 2016-11-21 17:44:44 --> Helper loaded: app_helper
INFO - 2016-11-21 17:44:45 --> Email Class Initialized
INFO - 2016-11-21 17:44:45 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 16:44:45 --> Severity: Notice --> Undefined variable: leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 160
ERROR - 2016-11-21 16:44:45 --> Severity: Notice --> Undefined variable: application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 161
ERROR - 2016-11-21 16:44:45 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 162
INFO - 2016-11-21 16:44:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 16:44:45 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 16:44:45 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 169
ERROR - 2016-11-21 16:44:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\sys\libraries\Email.php 452
INFO - 2016-11-21 16:44:45 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 16:44:46 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:44:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:44:46 --> Final output sent to browser
DEBUG - 2016-11-21 16:44:46 --> Total execution time: 1.7113
INFO - 2016-11-21 17:45:47 --> Config Class Initialized
INFO - 2016-11-21 17:45:47 --> Hooks Class Initialized
DEBUG - 2016-11-21 17:45:47 --> UTF-8 Support Enabled
INFO - 2016-11-21 17:45:47 --> Utf8 Class Initialized
INFO - 2016-11-21 17:45:47 --> URI Class Initialized
DEBUG - 2016-11-21 17:45:47 --> No URI present. Default controller set.
INFO - 2016-11-21 17:45:47 --> Router Class Initialized
INFO - 2016-11-21 17:45:47 --> Output Class Initialized
INFO - 2016-11-21 17:45:47 --> Security Class Initialized
DEBUG - 2016-11-21 17:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 17:45:47 --> Input Class Initialized
INFO - 2016-11-21 17:45:47 --> Language Class Initialized
INFO - 2016-11-21 17:45:47 --> Loader Class Initialized
INFO - 2016-11-21 17:45:47 --> Helper loaded: url_helper
INFO - 2016-11-21 17:45:47 --> Helper loaded: form_helper
INFO - 2016-11-21 17:45:47 --> Database Driver Class Initialized
INFO - 2016-11-21 17:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 17:45:47 --> Controller Class Initialized
INFO - 2016-11-21 17:45:47 --> Model Class Initialized
INFO - 2016-11-21 17:45:47 --> Model Class Initialized
INFO - 2016-11-21 17:45:47 --> Model Class Initialized
INFO - 2016-11-21 17:45:47 --> Model Class Initialized
INFO - 2016-11-21 17:45:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 17:45:47 --> Pagination Class Initialized
INFO - 2016-11-21 17:45:47 --> Helper loaded: app_helper
INFO - 2016-11-21 17:45:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 17:45:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 17:45:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 17:45:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 17:45:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 17:45:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 17:45:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 17:45:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 17:45:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 17:45:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 17:45:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 17:45:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 17:45:48 --> Final output sent to browser
DEBUG - 2016-11-21 17:45:48 --> Total execution time: 0.7041
INFO - 2016-11-21 17:46:03 --> Config Class Initialized
INFO - 2016-11-21 17:46:03 --> Hooks Class Initialized
DEBUG - 2016-11-21 17:46:03 --> UTF-8 Support Enabled
INFO - 2016-11-21 17:46:03 --> Utf8 Class Initialized
INFO - 2016-11-21 17:46:03 --> URI Class Initialized
INFO - 2016-11-21 17:46:03 --> Router Class Initialized
INFO - 2016-11-21 17:46:03 --> Output Class Initialized
INFO - 2016-11-21 17:46:03 --> Security Class Initialized
DEBUG - 2016-11-21 17:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 17:46:03 --> Input Class Initialized
INFO - 2016-11-21 17:46:03 --> Language Class Initialized
INFO - 2016-11-21 17:46:03 --> Loader Class Initialized
INFO - 2016-11-21 17:46:03 --> Helper loaded: url_helper
INFO - 2016-11-21 17:46:03 --> Helper loaded: form_helper
INFO - 2016-11-21 17:46:03 --> Database Driver Class Initialized
INFO - 2016-11-21 17:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 17:46:04 --> Controller Class Initialized
INFO - 2016-11-21 17:46:04 --> Model Class Initialized
INFO - 2016-11-21 17:46:04 --> Form Validation Class Initialized
INFO - 2016-11-21 17:46:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 17:46:04 --> Pagination Class Initialized
INFO - 2016-11-21 17:46:04 --> Helper loaded: app_helper
INFO - 2016-11-21 17:46:04 --> Email Class Initialized
INFO - 2016-11-21 17:46:04 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 16:46:04 --> Severity: Notice --> Undefined variable: leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 160
ERROR - 2016-11-21 16:46:04 --> Severity: Notice --> Undefined variable: application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 161
ERROR - 2016-11-21 16:46:04 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 162
INFO - 2016-11-21 16:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-21 16:46:04 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 16:46:05 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:46:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:46:05 --> Final output sent to browser
DEBUG - 2016-11-21 16:46:05 --> Total execution time: 1.8229
INFO - 2016-11-21 17:47:30 --> Config Class Initialized
INFO - 2016-11-21 17:47:30 --> Hooks Class Initialized
DEBUG - 2016-11-21 17:47:30 --> UTF-8 Support Enabled
INFO - 2016-11-21 17:47:30 --> Utf8 Class Initialized
INFO - 2016-11-21 17:47:30 --> URI Class Initialized
DEBUG - 2016-11-21 17:47:30 --> No URI present. Default controller set.
INFO - 2016-11-21 17:47:30 --> Router Class Initialized
INFO - 2016-11-21 17:47:30 --> Output Class Initialized
INFO - 2016-11-21 17:47:30 --> Security Class Initialized
DEBUG - 2016-11-21 17:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 17:47:30 --> Input Class Initialized
INFO - 2016-11-21 17:47:30 --> Language Class Initialized
INFO - 2016-11-21 17:47:30 --> Loader Class Initialized
INFO - 2016-11-21 17:47:30 --> Helper loaded: url_helper
INFO - 2016-11-21 17:47:30 --> Helper loaded: form_helper
INFO - 2016-11-21 17:47:30 --> Database Driver Class Initialized
INFO - 2016-11-21 17:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 17:47:30 --> Controller Class Initialized
INFO - 2016-11-21 17:47:30 --> Model Class Initialized
INFO - 2016-11-21 17:47:30 --> Model Class Initialized
INFO - 2016-11-21 17:47:30 --> Model Class Initialized
INFO - 2016-11-21 17:47:30 --> Model Class Initialized
INFO - 2016-11-21 17:47:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 17:47:30 --> Pagination Class Initialized
INFO - 2016-11-21 17:47:30 --> Helper loaded: app_helper
INFO - 2016-11-21 17:47:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 17:47:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 17:47:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 17:47:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 17:47:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 17:47:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 17:47:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 17:47:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 17:47:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 17:47:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 17:47:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 17:47:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 17:47:31 --> Final output sent to browser
DEBUG - 2016-11-21 17:47:31 --> Total execution time: 0.8109
INFO - 2016-11-21 17:50:28 --> Config Class Initialized
INFO - 2016-11-21 17:50:28 --> Hooks Class Initialized
DEBUG - 2016-11-21 17:50:28 --> UTF-8 Support Enabled
INFO - 2016-11-21 17:50:28 --> Utf8 Class Initialized
INFO - 2016-11-21 17:50:28 --> URI Class Initialized
DEBUG - 2016-11-21 17:50:28 --> No URI present. Default controller set.
INFO - 2016-11-21 17:50:28 --> Router Class Initialized
INFO - 2016-11-21 17:50:28 --> Output Class Initialized
INFO - 2016-11-21 17:50:28 --> Security Class Initialized
DEBUG - 2016-11-21 17:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 17:50:28 --> Input Class Initialized
INFO - 2016-11-21 17:50:28 --> Language Class Initialized
INFO - 2016-11-21 17:50:28 --> Loader Class Initialized
INFO - 2016-11-21 17:50:28 --> Helper loaded: url_helper
INFO - 2016-11-21 17:50:29 --> Helper loaded: form_helper
INFO - 2016-11-21 17:50:29 --> Database Driver Class Initialized
INFO - 2016-11-21 17:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 17:50:29 --> Controller Class Initialized
INFO - 2016-11-21 17:50:29 --> Model Class Initialized
INFO - 2016-11-21 17:50:29 --> Model Class Initialized
INFO - 2016-11-21 17:50:29 --> Model Class Initialized
INFO - 2016-11-21 17:50:29 --> Model Class Initialized
INFO - 2016-11-21 17:50:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 17:50:29 --> Pagination Class Initialized
INFO - 2016-11-21 17:50:29 --> Helper loaded: app_helper
INFO - 2016-11-21 17:50:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 17:50:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 17:50:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 17:50:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 17:50:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 17:50:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 17:50:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 17:50:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 17:50:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 17:50:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 17:50:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 17:50:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 17:50:29 --> Final output sent to browser
DEBUG - 2016-11-21 17:50:29 --> Total execution time: 0.7280
INFO - 2016-11-21 17:50:44 --> Config Class Initialized
INFO - 2016-11-21 17:50:44 --> Hooks Class Initialized
DEBUG - 2016-11-21 17:50:44 --> UTF-8 Support Enabled
INFO - 2016-11-21 17:50:44 --> Utf8 Class Initialized
INFO - 2016-11-21 17:50:44 --> URI Class Initialized
INFO - 2016-11-21 17:50:44 --> Router Class Initialized
INFO - 2016-11-21 17:50:44 --> Output Class Initialized
INFO - 2016-11-21 17:50:44 --> Security Class Initialized
DEBUG - 2016-11-21 17:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 17:50:44 --> Input Class Initialized
INFO - 2016-11-21 17:50:44 --> Language Class Initialized
INFO - 2016-11-21 17:50:44 --> Loader Class Initialized
INFO - 2016-11-21 17:50:44 --> Helper loaded: url_helper
INFO - 2016-11-21 17:50:44 --> Helper loaded: form_helper
INFO - 2016-11-21 17:50:44 --> Database Driver Class Initialized
INFO - 2016-11-21 17:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 17:50:44 --> Controller Class Initialized
INFO - 2016-11-21 17:50:44 --> Model Class Initialized
INFO - 2016-11-21 17:50:44 --> Form Validation Class Initialized
INFO - 2016-11-21 17:50:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 17:50:44 --> Pagination Class Initialized
INFO - 2016-11-21 17:50:44 --> Helper loaded: app_helper
INFO - 2016-11-21 17:50:44 --> Email Class Initialized
INFO - 2016-11-21 17:50:44 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 16:50:44 --> Severity: Notice --> Undefined variable: leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 160
ERROR - 2016-11-21 16:50:44 --> Severity: Notice --> Undefined variable: application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 161
ERROR - 2016-11-21 16:50:44 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 162
INFO - 2016-11-21 16:50:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-21 16:50:45 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 16:50:45 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 16:50:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 16:50:45 --> Final output sent to browser
DEBUG - 2016-11-21 16:50:45 --> Total execution time: 1.5234
INFO - 2016-11-21 17:59:36 --> Config Class Initialized
INFO - 2016-11-21 17:59:36 --> Hooks Class Initialized
DEBUG - 2016-11-21 17:59:36 --> UTF-8 Support Enabled
INFO - 2016-11-21 17:59:36 --> Utf8 Class Initialized
INFO - 2016-11-21 17:59:36 --> URI Class Initialized
DEBUG - 2016-11-21 17:59:36 --> No URI present. Default controller set.
INFO - 2016-11-21 17:59:36 --> Router Class Initialized
INFO - 2016-11-21 17:59:36 --> Output Class Initialized
INFO - 2016-11-21 17:59:36 --> Security Class Initialized
DEBUG - 2016-11-21 17:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 17:59:36 --> Input Class Initialized
INFO - 2016-11-21 17:59:36 --> Language Class Initialized
INFO - 2016-11-21 17:59:36 --> Loader Class Initialized
INFO - 2016-11-21 17:59:36 --> Helper loaded: url_helper
INFO - 2016-11-21 17:59:36 --> Helper loaded: form_helper
INFO - 2016-11-21 17:59:36 --> Database Driver Class Initialized
INFO - 2016-11-21 17:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 17:59:36 --> Controller Class Initialized
INFO - 2016-11-21 17:59:36 --> Model Class Initialized
INFO - 2016-11-21 17:59:36 --> Model Class Initialized
INFO - 2016-11-21 17:59:36 --> Model Class Initialized
INFO - 2016-11-21 17:59:36 --> Model Class Initialized
INFO - 2016-11-21 17:59:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 17:59:36 --> Pagination Class Initialized
INFO - 2016-11-21 17:59:36 --> Helper loaded: app_helper
INFO - 2016-11-21 17:59:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 17:59:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 17:59:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 17:59:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 17:59:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 17:59:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 17:59:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 17:59:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 17:59:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 17:59:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 17:59:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 17:59:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 17:59:36 --> Final output sent to browser
DEBUG - 2016-11-21 17:59:36 --> Total execution time: 0.8081
INFO - 2016-11-21 17:59:42 --> Config Class Initialized
INFO - 2016-11-21 17:59:42 --> Hooks Class Initialized
DEBUG - 2016-11-21 17:59:42 --> UTF-8 Support Enabled
INFO - 2016-11-21 17:59:42 --> Utf8 Class Initialized
INFO - 2016-11-21 17:59:42 --> URI Class Initialized
INFO - 2016-11-21 17:59:42 --> Router Class Initialized
INFO - 2016-11-21 17:59:42 --> Output Class Initialized
INFO - 2016-11-21 17:59:42 --> Security Class Initialized
DEBUG - 2016-11-21 17:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 17:59:42 --> Input Class Initialized
INFO - 2016-11-21 17:59:42 --> Language Class Initialized
INFO - 2016-11-21 17:59:42 --> Loader Class Initialized
INFO - 2016-11-21 17:59:42 --> Helper loaded: url_helper
INFO - 2016-11-21 17:59:42 --> Helper loaded: form_helper
INFO - 2016-11-21 17:59:42 --> Database Driver Class Initialized
INFO - 2016-11-21 17:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 17:59:42 --> Controller Class Initialized
INFO - 2016-11-21 17:59:42 --> Model Class Initialized
INFO - 2016-11-21 17:59:42 --> Form Validation Class Initialized
INFO - 2016-11-21 17:59:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 17:59:42 --> Pagination Class Initialized
INFO - 2016-11-21 17:59:42 --> Helper loaded: app_helper
INFO - 2016-11-21 17:59:42 --> Email Class Initialized
ERROR - 2016-11-21 17:59:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 17:59:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 17:59:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 17:59:43 --> Final output sent to browser
DEBUG - 2016-11-21 17:59:43 --> Total execution time: 0.8490
INFO - 2016-11-21 17:59:48 --> Config Class Initialized
INFO - 2016-11-21 17:59:48 --> Hooks Class Initialized
DEBUG - 2016-11-21 17:59:48 --> UTF-8 Support Enabled
INFO - 2016-11-21 17:59:48 --> Utf8 Class Initialized
INFO - 2016-11-21 17:59:48 --> URI Class Initialized
INFO - 2016-11-21 17:59:48 --> Router Class Initialized
INFO - 2016-11-21 17:59:48 --> Output Class Initialized
INFO - 2016-11-21 17:59:48 --> Security Class Initialized
DEBUG - 2016-11-21 17:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 17:59:48 --> Input Class Initialized
INFO - 2016-11-21 17:59:48 --> Language Class Initialized
INFO - 2016-11-21 17:59:48 --> Loader Class Initialized
INFO - 2016-11-21 17:59:48 --> Helper loaded: url_helper
INFO - 2016-11-21 17:59:48 --> Helper loaded: form_helper
INFO - 2016-11-21 17:59:48 --> Database Driver Class Initialized
INFO - 2016-11-21 17:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 17:59:48 --> Controller Class Initialized
INFO - 2016-11-21 17:59:49 --> Model Class Initialized
INFO - 2016-11-21 17:59:49 --> Form Validation Class Initialized
INFO - 2016-11-21 17:59:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 17:59:49 --> Pagination Class Initialized
INFO - 2016-11-21 17:59:49 --> Helper loaded: app_helper
INFO - 2016-11-21 17:59:49 --> Email Class Initialized
ERROR - 2016-11-21 17:59:49 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 17:59:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 17:59:49 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 17:59:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 17:59:49 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 17:59:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 17:59:49 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 17:59:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 17:59:49 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 17:59:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 17:59:49 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 17:59:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 17:59:49 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 17:59:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 17:59:49 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 17:59:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 17:59:49 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 17:59:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 17:59:49 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 17:59:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 17:59:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 17:59:49 --> Final output sent to browser
DEBUG - 2016-11-21 17:59:49 --> Total execution time: 1.2700
INFO - 2016-11-21 18:00:05 --> Config Class Initialized
INFO - 2016-11-21 18:00:05 --> Hooks Class Initialized
DEBUG - 2016-11-21 18:00:05 --> UTF-8 Support Enabled
INFO - 2016-11-21 18:00:05 --> Utf8 Class Initialized
INFO - 2016-11-21 18:00:05 --> URI Class Initialized
INFO - 2016-11-21 18:00:05 --> Router Class Initialized
INFO - 2016-11-21 18:00:05 --> Output Class Initialized
INFO - 2016-11-21 18:00:05 --> Security Class Initialized
DEBUG - 2016-11-21 18:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 18:00:05 --> Input Class Initialized
INFO - 2016-11-21 18:00:05 --> Language Class Initialized
INFO - 2016-11-21 18:00:05 --> Loader Class Initialized
INFO - 2016-11-21 18:00:05 --> Helper loaded: url_helper
INFO - 2016-11-21 18:00:05 --> Helper loaded: form_helper
INFO - 2016-11-21 18:00:06 --> Database Driver Class Initialized
INFO - 2016-11-21 18:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 18:00:06 --> Controller Class Initialized
INFO - 2016-11-21 18:00:06 --> Model Class Initialized
INFO - 2016-11-21 18:00:06 --> Form Validation Class Initialized
INFO - 2016-11-21 18:00:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 18:00:06 --> Pagination Class Initialized
INFO - 2016-11-21 18:00:06 --> Helper loaded: app_helper
INFO - 2016-11-21 18:00:06 --> Email Class Initialized
INFO - 2016-11-21 18:00:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 18:00:06 --> Final output sent to browser
DEBUG - 2016-11-21 18:00:06 --> Total execution time: 0.5860
INFO - 2016-11-21 18:02:05 --> Config Class Initialized
INFO - 2016-11-21 18:02:05 --> Hooks Class Initialized
DEBUG - 2016-11-21 18:02:05 --> UTF-8 Support Enabled
INFO - 2016-11-21 18:02:05 --> Utf8 Class Initialized
INFO - 2016-11-21 18:02:05 --> URI Class Initialized
DEBUG - 2016-11-21 18:02:05 --> No URI present. Default controller set.
INFO - 2016-11-21 18:02:05 --> Router Class Initialized
INFO - 2016-11-21 18:02:05 --> Output Class Initialized
INFO - 2016-11-21 18:02:05 --> Security Class Initialized
DEBUG - 2016-11-21 18:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 18:02:05 --> Input Class Initialized
INFO - 2016-11-21 18:02:05 --> Language Class Initialized
INFO - 2016-11-21 18:02:05 --> Loader Class Initialized
INFO - 2016-11-21 18:02:05 --> Helper loaded: url_helper
INFO - 2016-11-21 18:02:05 --> Helper loaded: form_helper
INFO - 2016-11-21 18:02:05 --> Database Driver Class Initialized
INFO - 2016-11-21 18:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 18:02:05 --> Controller Class Initialized
INFO - 2016-11-21 18:02:05 --> Model Class Initialized
INFO - 2016-11-21 18:02:05 --> Model Class Initialized
INFO - 2016-11-21 18:02:06 --> Model Class Initialized
INFO - 2016-11-21 18:02:06 --> Model Class Initialized
INFO - 2016-11-21 18:02:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 18:02:06 --> Pagination Class Initialized
INFO - 2016-11-21 18:02:06 --> Helper loaded: app_helper
INFO - 2016-11-21 18:02:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 18:02:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 18:02:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 18:02:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 18:02:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 18:02:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 18:02:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 18:02:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 18:02:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 18:02:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 18:02:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 18:02:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 18:02:06 --> Final output sent to browser
DEBUG - 2016-11-21 18:02:06 --> Total execution time: 0.7216
INFO - 2016-11-21 18:02:24 --> Config Class Initialized
INFO - 2016-11-21 18:02:24 --> Hooks Class Initialized
DEBUG - 2016-11-21 18:02:24 --> UTF-8 Support Enabled
INFO - 2016-11-21 18:02:24 --> Utf8 Class Initialized
INFO - 2016-11-21 18:02:24 --> URI Class Initialized
INFO - 2016-11-21 18:02:24 --> Router Class Initialized
INFO - 2016-11-21 18:02:24 --> Output Class Initialized
INFO - 2016-11-21 18:02:24 --> Security Class Initialized
DEBUG - 2016-11-21 18:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 18:02:24 --> Input Class Initialized
INFO - 2016-11-21 18:02:24 --> Language Class Initialized
INFO - 2016-11-21 18:02:24 --> Loader Class Initialized
INFO - 2016-11-21 18:02:24 --> Helper loaded: url_helper
INFO - 2016-11-21 18:02:24 --> Helper loaded: form_helper
INFO - 2016-11-21 18:02:24 --> Database Driver Class Initialized
INFO - 2016-11-21 18:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 18:02:24 --> Controller Class Initialized
INFO - 2016-11-21 18:02:24 --> Model Class Initialized
INFO - 2016-11-21 18:02:24 --> Form Validation Class Initialized
INFO - 2016-11-21 18:02:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 18:02:24 --> Pagination Class Initialized
INFO - 2016-11-21 18:02:24 --> Helper loaded: app_helper
INFO - 2016-11-21 18:02:24 --> Email Class Initialized
INFO - 2016-11-21 18:02:24 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 17:02:24 --> Severity: Notice --> Undefined variable: leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 160
ERROR - 2016-11-21 17:02:24 --> Severity: Notice --> Undefined variable: application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 161
ERROR - 2016-11-21 17:02:24 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 162
INFO - 2016-11-21 17:02:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-21 17:02:29 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 17:02:30 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 17:02:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 17:02:30 --> Final output sent to browser
DEBUG - 2016-11-21 17:02:30 --> Total execution time: 6.4389
INFO - 2016-11-21 18:03:36 --> Config Class Initialized
INFO - 2016-11-21 18:03:36 --> Hooks Class Initialized
DEBUG - 2016-11-21 18:03:36 --> UTF-8 Support Enabled
INFO - 2016-11-21 18:03:36 --> Utf8 Class Initialized
INFO - 2016-11-21 18:03:36 --> URI Class Initialized
DEBUG - 2016-11-21 18:03:36 --> No URI present. Default controller set.
INFO - 2016-11-21 18:03:36 --> Router Class Initialized
INFO - 2016-11-21 18:03:36 --> Output Class Initialized
INFO - 2016-11-21 18:03:36 --> Security Class Initialized
DEBUG - 2016-11-21 18:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 18:03:36 --> Input Class Initialized
INFO - 2016-11-21 18:03:36 --> Language Class Initialized
INFO - 2016-11-21 18:03:36 --> Loader Class Initialized
INFO - 2016-11-21 18:03:36 --> Helper loaded: url_helper
INFO - 2016-11-21 18:03:36 --> Helper loaded: form_helper
INFO - 2016-11-21 18:03:36 --> Database Driver Class Initialized
INFO - 2016-11-21 18:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 18:03:36 --> Controller Class Initialized
INFO - 2016-11-21 18:03:36 --> Model Class Initialized
INFO - 2016-11-21 18:03:36 --> Model Class Initialized
INFO - 2016-11-21 18:03:36 --> Model Class Initialized
INFO - 2016-11-21 18:03:36 --> Model Class Initialized
INFO - 2016-11-21 18:03:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 18:03:36 --> Pagination Class Initialized
INFO - 2016-11-21 18:03:36 --> Helper loaded: app_helper
INFO - 2016-11-21 18:03:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 18:03:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 18:03:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 18:03:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 18:03:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 18:03:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 18:03:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 18:03:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 18:03:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 18:03:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 18:03:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 18:03:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 18:03:36 --> Final output sent to browser
DEBUG - 2016-11-21 18:03:36 --> Total execution time: 0.7484
INFO - 2016-11-21 18:03:53 --> Config Class Initialized
INFO - 2016-11-21 18:03:53 --> Hooks Class Initialized
DEBUG - 2016-11-21 18:03:53 --> UTF-8 Support Enabled
INFO - 2016-11-21 18:03:53 --> Utf8 Class Initialized
INFO - 2016-11-21 18:03:53 --> URI Class Initialized
INFO - 2016-11-21 18:03:53 --> Router Class Initialized
INFO - 2016-11-21 18:03:53 --> Output Class Initialized
INFO - 2016-11-21 18:03:53 --> Security Class Initialized
DEBUG - 2016-11-21 18:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 18:03:53 --> Input Class Initialized
INFO - 2016-11-21 18:03:53 --> Language Class Initialized
INFO - 2016-11-21 18:03:53 --> Loader Class Initialized
INFO - 2016-11-21 18:03:53 --> Helper loaded: url_helper
INFO - 2016-11-21 18:03:53 --> Helper loaded: form_helper
INFO - 2016-11-21 18:03:53 --> Database Driver Class Initialized
INFO - 2016-11-21 18:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 18:03:53 --> Controller Class Initialized
INFO - 2016-11-21 18:03:53 --> Model Class Initialized
INFO - 2016-11-21 18:03:53 --> Form Validation Class Initialized
INFO - 2016-11-21 18:03:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 18:03:53 --> Pagination Class Initialized
INFO - 2016-11-21 18:03:53 --> Helper loaded: app_helper
INFO - 2016-11-21 18:03:53 --> Email Class Initialized
INFO - 2016-11-21 18:03:53 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 17:03:53 --> Severity: Notice --> Undefined variable: leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 160
ERROR - 2016-11-21 17:03:53 --> Severity: Notice --> Undefined variable: application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 161
ERROR - 2016-11-21 17:03:53 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 162
INFO - 2016-11-21 17:03:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-11-21 17:03:54 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 17:03:54 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 17:03:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 17:03:54 --> Final output sent to browser
DEBUG - 2016-11-21 17:03:55 --> Total execution time: 1.7530
INFO - 2016-11-21 18:06:43 --> Config Class Initialized
INFO - 2016-11-21 18:06:43 --> Hooks Class Initialized
DEBUG - 2016-11-21 18:06:43 --> UTF-8 Support Enabled
INFO - 2016-11-21 18:06:43 --> Utf8 Class Initialized
INFO - 2016-11-21 18:06:43 --> URI Class Initialized
INFO - 2016-11-21 18:06:43 --> Router Class Initialized
INFO - 2016-11-21 18:06:43 --> Output Class Initialized
INFO - 2016-11-21 18:06:43 --> Security Class Initialized
DEBUG - 2016-11-21 18:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 18:06:43 --> Input Class Initialized
INFO - 2016-11-21 18:06:43 --> Language Class Initialized
INFO - 2016-11-21 18:06:43 --> Loader Class Initialized
INFO - 2016-11-21 18:06:43 --> Helper loaded: url_helper
INFO - 2016-11-21 18:06:43 --> Helper loaded: form_helper
INFO - 2016-11-21 18:06:43 --> Database Driver Class Initialized
INFO - 2016-11-21 18:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 18:06:43 --> Controller Class Initialized
INFO - 2016-11-21 18:06:43 --> Model Class Initialized
INFO - 2016-11-21 18:06:43 --> Form Validation Class Initialized
INFO - 2016-11-21 18:06:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 18:06:43 --> Pagination Class Initialized
INFO - 2016-11-21 18:06:43 --> Helper loaded: app_helper
INFO - 2016-11-21 18:06:43 --> Email Class Initialized
INFO - 2016-11-21 18:06:43 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 17:06:43 --> Severity: Notice --> Undefined variable: leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 160
ERROR - 2016-11-21 17:06:44 --> Severity: Notice --> Undefined variable: application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 161
ERROR - 2016-11-21 17:06:44 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 162
INFO - 2016-11-21 17:06:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 17:06:44 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 17:06:44 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 169
ERROR - 2016-11-21 17:06:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\sys\libraries\Email.php 452
INFO - 2016-11-21 17:06:44 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 17:06:45 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 17:06:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 17:06:45 --> Final output sent to browser
DEBUG - 2016-11-21 17:06:45 --> Total execution time: 1.9992
INFO - 2016-11-21 18:07:02 --> Config Class Initialized
INFO - 2016-11-21 18:07:02 --> Hooks Class Initialized
DEBUG - 2016-11-21 18:07:02 --> UTF-8 Support Enabled
INFO - 2016-11-21 18:07:02 --> Utf8 Class Initialized
INFO - 2016-11-21 18:07:02 --> URI Class Initialized
DEBUG - 2016-11-21 18:07:02 --> No URI present. Default controller set.
INFO - 2016-11-21 18:07:02 --> Router Class Initialized
INFO - 2016-11-21 18:07:02 --> Output Class Initialized
INFO - 2016-11-21 18:07:03 --> Security Class Initialized
DEBUG - 2016-11-21 18:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 18:07:03 --> Input Class Initialized
INFO - 2016-11-21 18:07:03 --> Language Class Initialized
INFO - 2016-11-21 18:07:03 --> Loader Class Initialized
INFO - 2016-11-21 18:07:03 --> Helper loaded: url_helper
INFO - 2016-11-21 18:07:03 --> Helper loaded: form_helper
INFO - 2016-11-21 18:07:03 --> Database Driver Class Initialized
INFO - 2016-11-21 18:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 18:07:03 --> Controller Class Initialized
INFO - 2016-11-21 18:07:03 --> Model Class Initialized
INFO - 2016-11-21 18:07:03 --> Model Class Initialized
INFO - 2016-11-21 18:07:03 --> Model Class Initialized
INFO - 2016-11-21 18:07:03 --> Model Class Initialized
INFO - 2016-11-21 18:07:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 18:07:03 --> Pagination Class Initialized
INFO - 2016-11-21 18:07:03 --> Helper loaded: app_helper
INFO - 2016-11-21 18:07:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 18:07:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 18:07:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 18:07:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 18:07:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 18:07:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 18:07:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 18:07:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 18:07:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 18:07:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 18:07:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 18:07:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 18:07:03 --> Final output sent to browser
DEBUG - 2016-11-21 18:07:03 --> Total execution time: 0.7617
INFO - 2016-11-21 18:07:19 --> Config Class Initialized
INFO - 2016-11-21 18:07:19 --> Hooks Class Initialized
DEBUG - 2016-11-21 18:07:19 --> UTF-8 Support Enabled
INFO - 2016-11-21 18:07:19 --> Utf8 Class Initialized
INFO - 2016-11-21 18:07:19 --> URI Class Initialized
INFO - 2016-11-21 18:07:19 --> Router Class Initialized
INFO - 2016-11-21 18:07:19 --> Output Class Initialized
INFO - 2016-11-21 18:07:19 --> Security Class Initialized
DEBUG - 2016-11-21 18:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 18:07:19 --> Input Class Initialized
INFO - 2016-11-21 18:07:19 --> Language Class Initialized
INFO - 2016-11-21 18:07:19 --> Loader Class Initialized
INFO - 2016-11-21 18:07:19 --> Helper loaded: url_helper
INFO - 2016-11-21 18:07:19 --> Helper loaded: form_helper
INFO - 2016-11-21 18:07:19 --> Database Driver Class Initialized
INFO - 2016-11-21 18:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 18:07:19 --> Controller Class Initialized
INFO - 2016-11-21 18:07:19 --> Model Class Initialized
INFO - 2016-11-21 18:07:19 --> Form Validation Class Initialized
INFO - 2016-11-21 18:07:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 18:07:19 --> Pagination Class Initialized
INFO - 2016-11-21 18:07:19 --> Helper loaded: app_helper
INFO - 2016-11-21 18:07:19 --> Email Class Initialized
INFO - 2016-11-21 18:07:19 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 17:07:20 --> Severity: Notice --> Undefined variable: leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 160
ERROR - 2016-11-21 17:07:20 --> Severity: Notice --> Undefined variable: application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 161
ERROR - 2016-11-21 17:07:20 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 162
INFO - 2016-11-21 17:07:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 17:07:20 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 17:07:20 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 169
ERROR - 2016-11-21 17:07:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\sys\libraries\Email.php 452
INFO - 2016-11-21 17:07:20 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 17:07:21 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 17:07:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 17:07:21 --> Final output sent to browser
DEBUG - 2016-11-21 17:07:21 --> Total execution time: 2.1739
INFO - 2016-11-21 18:09:30 --> Config Class Initialized
INFO - 2016-11-21 18:09:30 --> Hooks Class Initialized
DEBUG - 2016-11-21 18:09:30 --> UTF-8 Support Enabled
INFO - 2016-11-21 18:09:30 --> Utf8 Class Initialized
INFO - 2016-11-21 18:09:30 --> URI Class Initialized
DEBUG - 2016-11-21 18:09:30 --> No URI present. Default controller set.
INFO - 2016-11-21 18:09:30 --> Router Class Initialized
INFO - 2016-11-21 18:09:30 --> Output Class Initialized
INFO - 2016-11-21 18:09:30 --> Security Class Initialized
DEBUG - 2016-11-21 18:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 18:09:30 --> Input Class Initialized
INFO - 2016-11-21 18:09:30 --> Language Class Initialized
INFO - 2016-11-21 18:09:30 --> Loader Class Initialized
INFO - 2016-11-21 18:09:30 --> Helper loaded: url_helper
INFO - 2016-11-21 18:09:30 --> Helper loaded: form_helper
INFO - 2016-11-21 18:09:30 --> Database Driver Class Initialized
INFO - 2016-11-21 18:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 18:09:30 --> Controller Class Initialized
INFO - 2016-11-21 18:09:30 --> Model Class Initialized
INFO - 2016-11-21 18:09:30 --> Model Class Initialized
INFO - 2016-11-21 18:09:30 --> Model Class Initialized
INFO - 2016-11-21 18:09:30 --> Model Class Initialized
INFO - 2016-11-21 18:09:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 18:09:31 --> Pagination Class Initialized
INFO - 2016-11-21 18:09:31 --> Helper loaded: app_helper
INFO - 2016-11-21 18:09:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 18:09:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 18:09:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 18:09:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 18:09:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 18:09:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 18:09:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 18:09:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 18:09:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 18:09:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 18:09:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 18:09:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 18:09:31 --> Final output sent to browser
DEBUG - 2016-11-21 18:09:31 --> Total execution time: 0.8058
INFO - 2016-11-21 18:09:46 --> Config Class Initialized
INFO - 2016-11-21 18:09:46 --> Hooks Class Initialized
DEBUG - 2016-11-21 18:09:46 --> UTF-8 Support Enabled
INFO - 2016-11-21 18:09:46 --> Utf8 Class Initialized
INFO - 2016-11-21 18:09:46 --> URI Class Initialized
INFO - 2016-11-21 18:09:46 --> Router Class Initialized
INFO - 2016-11-21 18:09:46 --> Output Class Initialized
INFO - 2016-11-21 18:09:46 --> Security Class Initialized
DEBUG - 2016-11-21 18:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 18:09:46 --> Input Class Initialized
INFO - 2016-11-21 18:09:46 --> Language Class Initialized
INFO - 2016-11-21 18:09:46 --> Loader Class Initialized
INFO - 2016-11-21 18:09:46 --> Helper loaded: url_helper
INFO - 2016-11-21 18:09:46 --> Helper loaded: form_helper
INFO - 2016-11-21 18:09:46 --> Database Driver Class Initialized
INFO - 2016-11-21 18:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 18:09:46 --> Controller Class Initialized
INFO - 2016-11-21 18:09:46 --> Model Class Initialized
INFO - 2016-11-21 18:09:46 --> Form Validation Class Initialized
INFO - 2016-11-21 18:09:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 18:09:46 --> Pagination Class Initialized
INFO - 2016-11-21 18:09:46 --> Helper loaded: app_helper
INFO - 2016-11-21 18:09:46 --> Email Class Initialized
INFO - 2016-11-21 18:09:46 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 17:09:47 --> Severity: Notice --> Undefined variable: leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 160
ERROR - 2016-11-21 17:09:47 --> Severity: Notice --> Undefined variable: application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 161
ERROR - 2016-11-21 17:09:47 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 162
INFO - 2016-11-21 17:09:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 17:09:47 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 17:09:47 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 169
ERROR - 2016-11-21 17:09:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\sys\libraries\Email.php 452
INFO - 2016-11-21 17:09:47 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 17:09:48 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 17:09:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 17:09:48 --> Final output sent to browser
DEBUG - 2016-11-21 17:09:48 --> Total execution time: 1.6438
INFO - 2016-11-21 18:09:59 --> Config Class Initialized
INFO - 2016-11-21 18:09:59 --> Hooks Class Initialized
DEBUG - 2016-11-21 18:09:59 --> UTF-8 Support Enabled
INFO - 2016-11-21 18:09:59 --> Utf8 Class Initialized
INFO - 2016-11-21 18:09:59 --> URI Class Initialized
INFO - 2016-11-21 18:09:59 --> Router Class Initialized
INFO - 2016-11-21 18:09:59 --> Output Class Initialized
INFO - 2016-11-21 18:09:59 --> Security Class Initialized
DEBUG - 2016-11-21 18:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 18:09:59 --> Input Class Initialized
INFO - 2016-11-21 18:09:59 --> Language Class Initialized
INFO - 2016-11-21 18:09:59 --> Loader Class Initialized
INFO - 2016-11-21 18:09:59 --> Helper loaded: url_helper
INFO - 2016-11-21 18:09:59 --> Helper loaded: form_helper
INFO - 2016-11-21 18:09:59 --> Database Driver Class Initialized
INFO - 2016-11-21 18:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 18:09:59 --> Controller Class Initialized
INFO - 2016-11-21 18:09:59 --> Model Class Initialized
INFO - 2016-11-21 18:09:59 --> Form Validation Class Initialized
INFO - 2016-11-21 18:09:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 18:09:59 --> Pagination Class Initialized
INFO - 2016-11-21 18:09:59 --> Helper loaded: app_helper
INFO - 2016-11-21 18:09:59 --> Email Class Initialized
INFO - 2016-11-21 18:09:59 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 17:10:00 --> Severity: Notice --> Undefined variable: leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 160
ERROR - 2016-11-21 17:10:00 --> Severity: Notice --> Undefined variable: application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 161
ERROR - 2016-11-21 17:10:00 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 162
INFO - 2016-11-21 17:10:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 17:10:00 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 17:10:00 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 169
ERROR - 2016-11-21 17:10:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\sys\libraries\Email.php 452
INFO - 2016-11-21 17:10:00 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 17:10:01 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 17:10:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 17:10:01 --> Final output sent to browser
DEBUG - 2016-11-21 17:10:01 --> Total execution time: 1.8656
INFO - 2016-11-21 18:10:40 --> Config Class Initialized
INFO - 2016-11-21 18:10:40 --> Hooks Class Initialized
DEBUG - 2016-11-21 18:10:40 --> UTF-8 Support Enabled
INFO - 2016-11-21 18:10:40 --> Utf8 Class Initialized
INFO - 2016-11-21 18:10:40 --> URI Class Initialized
INFO - 2016-11-21 18:10:40 --> Router Class Initialized
INFO - 2016-11-21 18:10:40 --> Output Class Initialized
INFO - 2016-11-21 18:10:40 --> Security Class Initialized
DEBUG - 2016-11-21 18:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 18:10:40 --> Input Class Initialized
INFO - 2016-11-21 18:10:40 --> Language Class Initialized
INFO - 2016-11-21 18:10:41 --> Loader Class Initialized
INFO - 2016-11-21 18:10:41 --> Helper loaded: url_helper
INFO - 2016-11-21 18:10:41 --> Helper loaded: form_helper
INFO - 2016-11-21 18:10:41 --> Database Driver Class Initialized
INFO - 2016-11-21 18:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 18:10:41 --> Controller Class Initialized
INFO - 2016-11-21 18:10:41 --> Model Class Initialized
INFO - 2016-11-21 18:10:41 --> Form Validation Class Initialized
INFO - 2016-11-21 18:10:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 18:10:41 --> Pagination Class Initialized
INFO - 2016-11-21 18:10:41 --> Helper loaded: app_helper
INFO - 2016-11-21 18:10:41 --> Email Class Initialized
INFO - 2016-11-21 18:10:41 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 17:10:41 --> Severity: Notice --> Undefined variable: leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 160
ERROR - 2016-11-21 17:10:41 --> Severity: Notice --> Undefined variable: application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 161
ERROR - 2016-11-21 17:10:41 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 162
INFO - 2016-11-21 17:10:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 17:10:41 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 17:10:41 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 170
ERROR - 2016-11-21 17:10:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\sys\libraries\Email.php 452
INFO - 2016-11-21 17:10:41 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 17:10:41 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 17:10:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 17:10:41 --> Final output sent to browser
DEBUG - 2016-11-21 17:10:41 --> Total execution time: 1.2058
INFO - 2016-11-21 18:11:10 --> Config Class Initialized
INFO - 2016-11-21 18:11:10 --> Hooks Class Initialized
DEBUG - 2016-11-21 18:11:10 --> UTF-8 Support Enabled
INFO - 2016-11-21 18:11:10 --> Utf8 Class Initialized
INFO - 2016-11-21 18:11:10 --> URI Class Initialized
DEBUG - 2016-11-21 18:11:10 --> No URI present. Default controller set.
INFO - 2016-11-21 18:11:10 --> Router Class Initialized
INFO - 2016-11-21 18:11:10 --> Output Class Initialized
INFO - 2016-11-21 18:11:10 --> Security Class Initialized
DEBUG - 2016-11-21 18:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 18:11:10 --> Input Class Initialized
INFO - 2016-11-21 18:11:10 --> Language Class Initialized
INFO - 2016-11-21 18:11:10 --> Loader Class Initialized
INFO - 2016-11-21 18:11:10 --> Helper loaded: url_helper
INFO - 2016-11-21 18:11:10 --> Helper loaded: form_helper
INFO - 2016-11-21 18:11:10 --> Database Driver Class Initialized
INFO - 2016-11-21 18:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 18:11:11 --> Controller Class Initialized
INFO - 2016-11-21 18:11:11 --> Model Class Initialized
INFO - 2016-11-21 18:11:11 --> Model Class Initialized
INFO - 2016-11-21 18:11:11 --> Model Class Initialized
INFO - 2016-11-21 18:11:11 --> Model Class Initialized
INFO - 2016-11-21 18:11:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 18:11:11 --> Pagination Class Initialized
INFO - 2016-11-21 18:11:11 --> Helper loaded: app_helper
INFO - 2016-11-21 18:11:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 18:11:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 18:11:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 18:11:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 18:11:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 18:11:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 18:11:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 18:11:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 18:11:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 18:11:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 18:11:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 18:11:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 18:11:11 --> Final output sent to browser
DEBUG - 2016-11-21 18:11:11 --> Total execution time: 0.9595
INFO - 2016-11-21 18:11:23 --> Config Class Initialized
INFO - 2016-11-21 18:11:23 --> Hooks Class Initialized
DEBUG - 2016-11-21 18:11:23 --> UTF-8 Support Enabled
INFO - 2016-11-21 18:11:23 --> Utf8 Class Initialized
INFO - 2016-11-21 18:11:23 --> URI Class Initialized
INFO - 2016-11-21 18:11:23 --> Router Class Initialized
INFO - 2016-11-21 18:11:23 --> Output Class Initialized
INFO - 2016-11-21 18:11:23 --> Security Class Initialized
DEBUG - 2016-11-21 18:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 18:11:23 --> Input Class Initialized
INFO - 2016-11-21 18:11:23 --> Language Class Initialized
INFO - 2016-11-21 18:11:23 --> Loader Class Initialized
INFO - 2016-11-21 18:11:23 --> Helper loaded: url_helper
INFO - 2016-11-21 18:11:23 --> Helper loaded: form_helper
INFO - 2016-11-21 18:11:23 --> Database Driver Class Initialized
INFO - 2016-11-21 18:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 18:11:23 --> Controller Class Initialized
INFO - 2016-11-21 18:11:23 --> Model Class Initialized
INFO - 2016-11-21 18:11:23 --> Form Validation Class Initialized
INFO - 2016-11-21 18:11:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 18:11:23 --> Pagination Class Initialized
INFO - 2016-11-21 18:11:23 --> Helper loaded: app_helper
INFO - 2016-11-21 18:11:23 --> Email Class Initialized
INFO - 2016-11-21 18:11:23 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 17:11:23 --> Severity: Notice --> Undefined variable: leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 160
ERROR - 2016-11-21 17:11:24 --> Severity: Notice --> Undefined variable: application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 161
ERROR - 2016-11-21 17:11:24 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 162
INFO - 2016-11-21 17:11:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 17:11:24 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 17:11:24 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 169
ERROR - 2016-11-21 17:11:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\sys\libraries\Email.php 452
INFO - 2016-11-21 17:11:24 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 17:11:25 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 17:11:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 17:11:25 --> Final output sent to browser
DEBUG - 2016-11-21 17:11:25 --> Total execution time: 1.8123
INFO - 2016-11-21 18:50:08 --> Config Class Initialized
INFO - 2016-11-21 18:50:08 --> Hooks Class Initialized
DEBUG - 2016-11-21 18:50:08 --> UTF-8 Support Enabled
INFO - 2016-11-21 18:50:08 --> Utf8 Class Initialized
INFO - 2016-11-21 18:50:08 --> URI Class Initialized
INFO - 2016-11-21 18:50:08 --> Router Class Initialized
INFO - 2016-11-21 18:50:08 --> Output Class Initialized
INFO - 2016-11-21 18:50:08 --> Security Class Initialized
DEBUG - 2016-11-21 18:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 18:50:08 --> Input Class Initialized
INFO - 2016-11-21 18:50:08 --> Language Class Initialized
INFO - 2016-11-21 18:50:08 --> Loader Class Initialized
INFO - 2016-11-21 18:50:08 --> Helper loaded: url_helper
INFO - 2016-11-21 18:50:08 --> Helper loaded: form_helper
INFO - 2016-11-21 18:50:08 --> Database Driver Class Initialized
INFO - 2016-11-21 18:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 18:50:08 --> Controller Class Initialized
INFO - 2016-11-21 18:50:08 --> Model Class Initialized
INFO - 2016-11-21 18:50:08 --> Form Validation Class Initialized
INFO - 2016-11-21 18:50:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 18:50:08 --> Pagination Class Initialized
INFO - 2016-11-21 18:50:08 --> Helper loaded: app_helper
INFO - 2016-11-21 18:50:08 --> Email Class Initialized
INFO - 2016-11-21 18:50:08 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 17:50:08 --> Severity: Notice --> Undefined variable: leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 160
ERROR - 2016-11-21 17:50:09 --> Severity: Notice --> Undefined variable: application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 161
ERROR - 2016-11-21 17:50:09 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 162
INFO - 2016-11-21 17:50:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 17:50:09 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 17:50:09 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 169
ERROR - 2016-11-21 17:50:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\sys\libraries\Email.php 452
INFO - 2016-11-21 17:50:10 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 17:50:12 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 17:50:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 17:50:12 --> Final output sent to browser
DEBUG - 2016-11-21 17:50:12 --> Total execution time: 3.9372
INFO - 2016-11-21 18:52:05 --> Config Class Initialized
INFO - 2016-11-21 18:52:05 --> Hooks Class Initialized
DEBUG - 2016-11-21 18:52:05 --> UTF-8 Support Enabled
INFO - 2016-11-21 18:52:05 --> Utf8 Class Initialized
INFO - 2016-11-21 18:52:05 --> URI Class Initialized
INFO - 2016-11-21 18:52:05 --> Router Class Initialized
INFO - 2016-11-21 18:52:05 --> Output Class Initialized
INFO - 2016-11-21 18:52:05 --> Security Class Initialized
DEBUG - 2016-11-21 18:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 18:52:05 --> Input Class Initialized
INFO - 2016-11-21 18:52:05 --> Language Class Initialized
INFO - 2016-11-21 18:52:05 --> Loader Class Initialized
INFO - 2016-11-21 18:52:05 --> Helper loaded: url_helper
INFO - 2016-11-21 18:52:05 --> Helper loaded: form_helper
INFO - 2016-11-21 18:52:05 --> Database Driver Class Initialized
INFO - 2016-11-21 18:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 18:52:06 --> Controller Class Initialized
INFO - 2016-11-21 18:52:06 --> Model Class Initialized
INFO - 2016-11-21 18:52:06 --> Form Validation Class Initialized
INFO - 2016-11-21 18:52:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 18:52:06 --> Pagination Class Initialized
INFO - 2016-11-21 18:52:06 --> Helper loaded: app_helper
INFO - 2016-11-21 18:52:06 --> Email Class Initialized
INFO - 2016-11-21 18:52:06 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 17:52:06 --> Severity: Notice --> Undefined variable: leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 160
ERROR - 2016-11-21 17:52:06 --> Severity: Notice --> Undefined variable: application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 161
ERROR - 2016-11-21 17:52:06 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 162
INFO - 2016-11-21 17:52:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 17:52:06 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 17:52:06 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 169
ERROR - 2016-11-21 17:52:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\sys\libraries\Email.php 452
INFO - 2016-11-21 17:52:06 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 17:52:07 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 17:52:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 17:52:07 --> Final output sent to browser
DEBUG - 2016-11-21 17:52:07 --> Total execution time: 1.9833
INFO - 2016-11-21 18:56:52 --> Config Class Initialized
INFO - 2016-11-21 18:56:52 --> Hooks Class Initialized
DEBUG - 2016-11-21 18:56:52 --> UTF-8 Support Enabled
INFO - 2016-11-21 18:56:52 --> Utf8 Class Initialized
INFO - 2016-11-21 18:56:52 --> URI Class Initialized
INFO - 2016-11-21 18:56:52 --> Router Class Initialized
INFO - 2016-11-21 18:56:52 --> Output Class Initialized
INFO - 2016-11-21 18:56:52 --> Security Class Initialized
DEBUG - 2016-11-21 18:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 18:56:52 --> Input Class Initialized
INFO - 2016-11-21 18:56:52 --> Language Class Initialized
INFO - 2016-11-21 18:56:52 --> Loader Class Initialized
INFO - 2016-11-21 18:56:52 --> Helper loaded: url_helper
INFO - 2016-11-21 18:56:52 --> Helper loaded: form_helper
INFO - 2016-11-21 18:56:52 --> Database Driver Class Initialized
INFO - 2016-11-21 18:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 18:56:52 --> Controller Class Initialized
INFO - 2016-11-21 18:56:52 --> Model Class Initialized
INFO - 2016-11-21 18:56:52 --> Form Validation Class Initialized
INFO - 2016-11-21 18:56:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 18:56:53 --> Pagination Class Initialized
INFO - 2016-11-21 18:56:53 --> Helper loaded: app_helper
INFO - 2016-11-21 18:56:53 --> Email Class Initialized
INFO - 2016-11-21 18:56:53 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 17:56:53 --> Severity: Notice --> Undefined variable: leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 160
ERROR - 2016-11-21 17:56:53 --> Severity: Notice --> Undefined variable: application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 161
ERROR - 2016-11-21 17:56:53 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 162
INFO - 2016-11-21 17:56:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 17:56:53 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 17:56:53 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 169
ERROR - 2016-11-21 17:56:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\sys\libraries\Email.php 452
INFO - 2016-11-21 17:56:53 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 17:56:54 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 17:56:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 17:56:54 --> Final output sent to browser
DEBUG - 2016-11-21 17:56:54 --> Total execution time: 1.8376
INFO - 2016-11-21 18:57:12 --> Config Class Initialized
INFO - 2016-11-21 18:57:12 --> Hooks Class Initialized
DEBUG - 2016-11-21 18:57:12 --> UTF-8 Support Enabled
INFO - 2016-11-21 18:57:12 --> Utf8 Class Initialized
INFO - 2016-11-21 18:57:12 --> URI Class Initialized
INFO - 2016-11-21 18:57:12 --> Router Class Initialized
INFO - 2016-11-21 18:57:12 --> Output Class Initialized
INFO - 2016-11-21 18:57:12 --> Security Class Initialized
DEBUG - 2016-11-21 18:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 18:57:12 --> Input Class Initialized
INFO - 2016-11-21 18:57:12 --> Language Class Initialized
INFO - 2016-11-21 18:57:12 --> Loader Class Initialized
INFO - 2016-11-21 18:57:12 --> Helper loaded: url_helper
INFO - 2016-11-21 18:57:12 --> Helper loaded: form_helper
INFO - 2016-11-21 18:57:13 --> Database Driver Class Initialized
INFO - 2016-11-21 18:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 18:57:13 --> Controller Class Initialized
INFO - 2016-11-21 18:57:13 --> Model Class Initialized
INFO - 2016-11-21 18:57:13 --> Form Validation Class Initialized
INFO - 2016-11-21 18:57:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 18:57:13 --> Pagination Class Initialized
INFO - 2016-11-21 18:57:13 --> Helper loaded: app_helper
INFO - 2016-11-21 18:57:13 --> Email Class Initialized
INFO - 2016-11-21 18:57:13 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 17:57:13 --> Severity: Notice --> Undefined variable: leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 160
ERROR - 2016-11-21 17:57:13 --> Severity: Notice --> Undefined variable: application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 161
ERROR - 2016-11-21 17:57:13 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 162
INFO - 2016-11-21 17:57:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 17:57:13 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 17:57:13 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 169
ERROR - 2016-11-21 17:57:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\sys\libraries\Email.php 452
INFO - 2016-11-21 17:57:13 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 17:57:14 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 17:57:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 17:57:14 --> Final output sent to browser
DEBUG - 2016-11-21 17:57:14 --> Total execution time: 1.9439
INFO - 2016-11-21 19:00:37 --> Config Class Initialized
INFO - 2016-11-21 19:00:37 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:00:37 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:00:37 --> Utf8 Class Initialized
INFO - 2016-11-21 19:00:37 --> URI Class Initialized
DEBUG - 2016-11-21 19:00:37 --> No URI present. Default controller set.
INFO - 2016-11-21 19:00:37 --> Router Class Initialized
INFO - 2016-11-21 19:00:37 --> Output Class Initialized
INFO - 2016-11-21 19:00:37 --> Security Class Initialized
DEBUG - 2016-11-21 19:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:00:37 --> Input Class Initialized
INFO - 2016-11-21 19:00:37 --> Language Class Initialized
INFO - 2016-11-21 19:00:37 --> Loader Class Initialized
INFO - 2016-11-21 19:00:37 --> Helper loaded: url_helper
INFO - 2016-11-21 19:00:37 --> Helper loaded: form_helper
INFO - 2016-11-21 19:00:37 --> Database Driver Class Initialized
INFO - 2016-11-21 19:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:00:37 --> Controller Class Initialized
INFO - 2016-11-21 19:00:38 --> Model Class Initialized
INFO - 2016-11-21 19:00:38 --> Model Class Initialized
INFO - 2016-11-21 19:00:38 --> Model Class Initialized
INFO - 2016-11-21 19:00:38 --> Model Class Initialized
INFO - 2016-11-21 19:00:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:00:38 --> Pagination Class Initialized
INFO - 2016-11-21 19:00:38 --> Helper loaded: app_helper
INFO - 2016-11-21 19:00:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 19:00:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 19:00:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 19:00:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 19:00:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:00:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 19:00:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 19:00:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 19:00:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 19:00:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 19:00:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 19:00:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 19:00:38 --> Final output sent to browser
DEBUG - 2016-11-21 19:00:38 --> Total execution time: 0.9829
INFO - 2016-11-21 19:00:51 --> Config Class Initialized
INFO - 2016-11-21 19:00:51 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:00:51 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:00:51 --> Utf8 Class Initialized
INFO - 2016-11-21 19:00:51 --> URI Class Initialized
INFO - 2016-11-21 19:00:51 --> Router Class Initialized
INFO - 2016-11-21 19:00:51 --> Output Class Initialized
INFO - 2016-11-21 19:00:51 --> Security Class Initialized
DEBUG - 2016-11-21 19:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:00:51 --> Input Class Initialized
INFO - 2016-11-21 19:00:51 --> Language Class Initialized
INFO - 2016-11-21 19:00:51 --> Loader Class Initialized
INFO - 2016-11-21 19:00:51 --> Helper loaded: url_helper
INFO - 2016-11-21 19:00:51 --> Helper loaded: form_helper
INFO - 2016-11-21 19:00:51 --> Database Driver Class Initialized
INFO - 2016-11-21 19:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:00:51 --> Controller Class Initialized
INFO - 2016-11-21 19:00:51 --> Model Class Initialized
INFO - 2016-11-21 19:00:51 --> Form Validation Class Initialized
INFO - 2016-11-21 19:00:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:00:51 --> Pagination Class Initialized
INFO - 2016-11-21 19:00:51 --> Helper loaded: app_helper
INFO - 2016-11-21 19:00:51 --> Email Class Initialized
INFO - 2016-11-21 19:00:51 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 18:00:51 --> Severity: Notice --> Undefined variable: leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 160
ERROR - 2016-11-21 18:00:51 --> Severity: Notice --> Undefined variable: application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 161
ERROR - 2016-11-21 18:00:51 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 162
INFO - 2016-11-21 18:00:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 18:00:51 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 18:00:51 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 169
ERROR - 2016-11-21 18:00:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\sys\libraries\Email.php 452
INFO - 2016-11-21 18:00:51 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 18:00:52 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 18:00:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 18:00:52 --> Final output sent to browser
DEBUG - 2016-11-21 18:00:52 --> Total execution time: 1.6950
INFO - 2016-11-21 19:03:49 --> Config Class Initialized
INFO - 2016-11-21 19:03:49 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:03:49 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:03:49 --> Utf8 Class Initialized
INFO - 2016-11-21 19:03:49 --> URI Class Initialized
DEBUG - 2016-11-21 19:03:49 --> No URI present. Default controller set.
INFO - 2016-11-21 19:03:49 --> Router Class Initialized
INFO - 2016-11-21 19:03:49 --> Output Class Initialized
INFO - 2016-11-21 19:03:49 --> Security Class Initialized
DEBUG - 2016-11-21 19:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:03:49 --> Input Class Initialized
INFO - 2016-11-21 19:03:49 --> Language Class Initialized
INFO - 2016-11-21 19:03:49 --> Loader Class Initialized
INFO - 2016-11-21 19:03:49 --> Helper loaded: url_helper
INFO - 2016-11-21 19:03:50 --> Helper loaded: form_helper
INFO - 2016-11-21 19:03:50 --> Database Driver Class Initialized
INFO - 2016-11-21 19:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:03:50 --> Controller Class Initialized
INFO - 2016-11-21 19:03:50 --> Model Class Initialized
INFO - 2016-11-21 19:03:50 --> Model Class Initialized
INFO - 2016-11-21 19:03:50 --> Model Class Initialized
INFO - 2016-11-21 19:03:50 --> Model Class Initialized
INFO - 2016-11-21 19:03:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:03:50 --> Pagination Class Initialized
INFO - 2016-11-21 19:03:50 --> Helper loaded: app_helper
INFO - 2016-11-21 19:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 19:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 19:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 19:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 19:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 19:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 19:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 19:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 19:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 19:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 19:03:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 19:03:50 --> Final output sent to browser
DEBUG - 2016-11-21 19:03:50 --> Total execution time: 0.8531
INFO - 2016-11-21 19:03:55 --> Config Class Initialized
INFO - 2016-11-21 19:03:55 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:03:55 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:03:55 --> Utf8 Class Initialized
INFO - 2016-11-21 19:03:55 --> URI Class Initialized
INFO - 2016-11-21 19:03:55 --> Router Class Initialized
INFO - 2016-11-21 19:03:55 --> Output Class Initialized
INFO - 2016-11-21 19:03:55 --> Security Class Initialized
DEBUG - 2016-11-21 19:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:03:55 --> Input Class Initialized
INFO - 2016-11-21 19:03:55 --> Language Class Initialized
INFO - 2016-11-21 19:03:55 --> Loader Class Initialized
INFO - 2016-11-21 19:03:55 --> Helper loaded: url_helper
INFO - 2016-11-21 19:03:55 --> Helper loaded: form_helper
INFO - 2016-11-21 19:03:55 --> Database Driver Class Initialized
INFO - 2016-11-21 19:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:03:55 --> Controller Class Initialized
INFO - 2016-11-21 19:03:55 --> Model Class Initialized
INFO - 2016-11-21 19:03:55 --> Form Validation Class Initialized
INFO - 2016-11-21 19:03:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:03:55 --> Pagination Class Initialized
INFO - 2016-11-21 19:03:56 --> Helper loaded: app_helper
INFO - 2016-11-21 19:03:56 --> Email Class Initialized
ERROR - 2016-11-21 19:03:56 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:03:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-21 19:03:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 19:03:56 --> Final output sent to browser
DEBUG - 2016-11-21 19:03:56 --> Total execution time: 0.5691
INFO - 2016-11-21 19:04:08 --> Config Class Initialized
INFO - 2016-11-21 19:04:09 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:04:09 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:04:09 --> Utf8 Class Initialized
INFO - 2016-11-21 19:04:09 --> URI Class Initialized
INFO - 2016-11-21 19:04:09 --> Router Class Initialized
INFO - 2016-11-21 19:04:09 --> Output Class Initialized
INFO - 2016-11-21 19:04:09 --> Security Class Initialized
DEBUG - 2016-11-21 19:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:04:09 --> Input Class Initialized
INFO - 2016-11-21 19:04:09 --> Language Class Initialized
INFO - 2016-11-21 19:04:09 --> Loader Class Initialized
INFO - 2016-11-21 19:04:09 --> Helper loaded: url_helper
INFO - 2016-11-21 19:04:09 --> Helper loaded: form_helper
INFO - 2016-11-21 19:04:09 --> Database Driver Class Initialized
INFO - 2016-11-21 19:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:04:09 --> Controller Class Initialized
INFO - 2016-11-21 19:04:09 --> Model Class Initialized
INFO - 2016-11-21 19:04:09 --> Form Validation Class Initialized
INFO - 2016-11-21 19:04:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:04:09 --> Pagination Class Initialized
INFO - 2016-11-21 19:04:09 --> Helper loaded: app_helper
INFO - 2016-11-21 19:04:09 --> Email Class Initialized
INFO - 2016-11-21 19:04:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 19:04:09 --> Final output sent to browser
DEBUG - 2016-11-21 19:04:09 --> Total execution time: 0.4661
INFO - 2016-11-21 19:06:08 --> Config Class Initialized
INFO - 2016-11-21 19:06:08 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:06:08 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:06:08 --> Utf8 Class Initialized
INFO - 2016-11-21 19:06:08 --> URI Class Initialized
DEBUG - 2016-11-21 19:06:08 --> No URI present. Default controller set.
INFO - 2016-11-21 19:06:08 --> Router Class Initialized
INFO - 2016-11-21 19:06:08 --> Output Class Initialized
INFO - 2016-11-21 19:06:08 --> Security Class Initialized
DEBUG - 2016-11-21 19:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:06:08 --> Input Class Initialized
INFO - 2016-11-21 19:06:09 --> Language Class Initialized
INFO - 2016-11-21 19:06:09 --> Loader Class Initialized
INFO - 2016-11-21 19:06:09 --> Helper loaded: url_helper
INFO - 2016-11-21 19:06:09 --> Helper loaded: form_helper
INFO - 2016-11-21 19:06:09 --> Database Driver Class Initialized
INFO - 2016-11-21 19:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:06:09 --> Controller Class Initialized
INFO - 2016-11-21 19:06:09 --> Model Class Initialized
INFO - 2016-11-21 19:06:09 --> Model Class Initialized
INFO - 2016-11-21 19:06:09 --> Model Class Initialized
INFO - 2016-11-21 19:06:09 --> Model Class Initialized
INFO - 2016-11-21 19:06:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:06:09 --> Pagination Class Initialized
INFO - 2016-11-21 19:06:09 --> Helper loaded: app_helper
INFO - 2016-11-21 19:06:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 19:06:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 19:06:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 19:06:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 19:06:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:06:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 19:06:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 19:06:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 19:06:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 19:06:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 19:06:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 19:06:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 19:06:09 --> Final output sent to browser
DEBUG - 2016-11-21 19:06:09 --> Total execution time: 0.9026
INFO - 2016-11-21 19:22:45 --> Config Class Initialized
INFO - 2016-11-21 19:22:45 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:22:46 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:22:46 --> Utf8 Class Initialized
INFO - 2016-11-21 19:22:46 --> URI Class Initialized
DEBUG - 2016-11-21 19:22:46 --> No URI present. Default controller set.
INFO - 2016-11-21 19:22:46 --> Router Class Initialized
INFO - 2016-11-21 19:22:46 --> Output Class Initialized
INFO - 2016-11-21 19:22:46 --> Security Class Initialized
DEBUG - 2016-11-21 19:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:22:46 --> Input Class Initialized
INFO - 2016-11-21 19:22:46 --> Language Class Initialized
INFO - 2016-11-21 19:22:46 --> Loader Class Initialized
INFO - 2016-11-21 19:22:46 --> Helper loaded: url_helper
INFO - 2016-11-21 19:22:46 --> Helper loaded: form_helper
INFO - 2016-11-21 19:22:46 --> Database Driver Class Initialized
INFO - 2016-11-21 19:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:22:46 --> Controller Class Initialized
INFO - 2016-11-21 19:22:46 --> Model Class Initialized
INFO - 2016-11-21 19:22:46 --> Model Class Initialized
INFO - 2016-11-21 19:22:46 --> Model Class Initialized
INFO - 2016-11-21 19:22:46 --> Model Class Initialized
INFO - 2016-11-21 19:22:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:22:46 --> Pagination Class Initialized
INFO - 2016-11-21 19:22:46 --> Helper loaded: app_helper
INFO - 2016-11-21 19:22:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 19:22:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 19:22:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 19:22:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 19:22:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:22:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 19:22:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 19:22:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 19:22:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 19:22:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 19:22:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 19:22:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 19:22:46 --> Final output sent to browser
DEBUG - 2016-11-21 19:22:46 --> Total execution time: 0.9561
INFO - 2016-11-21 19:23:05 --> Config Class Initialized
INFO - 2016-11-21 19:23:05 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:23:05 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:23:05 --> Utf8 Class Initialized
INFO - 2016-11-21 19:23:05 --> URI Class Initialized
INFO - 2016-11-21 19:23:05 --> Router Class Initialized
INFO - 2016-11-21 19:23:05 --> Output Class Initialized
INFO - 2016-11-21 19:23:05 --> Security Class Initialized
DEBUG - 2016-11-21 19:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:23:05 --> Input Class Initialized
INFO - 2016-11-21 19:23:05 --> Language Class Initialized
INFO - 2016-11-21 19:23:05 --> Loader Class Initialized
INFO - 2016-11-21 19:23:05 --> Helper loaded: url_helper
INFO - 2016-11-21 19:23:05 --> Helper loaded: form_helper
INFO - 2016-11-21 19:23:05 --> Database Driver Class Initialized
INFO - 2016-11-21 19:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:23:05 --> Controller Class Initialized
INFO - 2016-11-21 19:23:05 --> Model Class Initialized
INFO - 2016-11-21 19:23:05 --> Form Validation Class Initialized
INFO - 2016-11-21 19:23:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:23:05 --> Pagination Class Initialized
INFO - 2016-11-21 19:23:05 --> Helper loaded: app_helper
INFO - 2016-11-21 19:23:05 --> Email Class Initialized
INFO - 2016-11-21 19:23:05 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 18:23:05 --> Severity: Notice --> Undefined variable: leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 160
ERROR - 2016-11-21 18:23:06 --> Severity: Notice --> Undefined variable: application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 161
ERROR - 2016-11-21 18:23:06 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 162
ERROR - 2016-11-21 18:23:06 --> Severity: Notice --> Undefined variable: hi C:\xampp\htdocs\LMS\app\views\email_template.php 23
ERROR - 2016-11-21 18:23:06 --> Severity: Notice --> Undefined variable: userName C:\xampp\htdocs\LMS\app\views\email_template.php 23
ERROR - 2016-11-21 18:23:06 --> Severity: Notice --> Undefined variable: msg1 C:\xampp\htdocs\LMS\app\views\email_template.php 24
INFO - 2016-11-21 18:23:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 18:23:06 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 18:23:06 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 169
ERROR - 2016-11-21 18:23:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\sys\libraries\Email.php 452
INFO - 2016-11-21 18:23:06 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 18:23:07 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 18:23:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 18:23:07 --> Final output sent to browser
DEBUG - 2016-11-21 18:23:07 --> Total execution time: 1.9089
INFO - 2016-11-21 19:24:12 --> Config Class Initialized
INFO - 2016-11-21 19:24:12 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:24:12 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:24:12 --> Utf8 Class Initialized
INFO - 2016-11-21 19:24:12 --> URI Class Initialized
DEBUG - 2016-11-21 19:24:12 --> No URI present. Default controller set.
INFO - 2016-11-21 19:24:12 --> Router Class Initialized
INFO - 2016-11-21 19:24:12 --> Output Class Initialized
INFO - 2016-11-21 19:24:12 --> Security Class Initialized
DEBUG - 2016-11-21 19:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:24:12 --> Input Class Initialized
INFO - 2016-11-21 19:24:12 --> Language Class Initialized
INFO - 2016-11-21 19:24:12 --> Loader Class Initialized
INFO - 2016-11-21 19:24:12 --> Helper loaded: url_helper
INFO - 2016-11-21 19:24:12 --> Helper loaded: form_helper
INFO - 2016-11-21 19:24:12 --> Database Driver Class Initialized
INFO - 2016-11-21 19:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:24:12 --> Controller Class Initialized
INFO - 2016-11-21 19:24:12 --> Model Class Initialized
INFO - 2016-11-21 19:24:12 --> Model Class Initialized
INFO - 2016-11-21 19:24:12 --> Model Class Initialized
INFO - 2016-11-21 19:24:12 --> Model Class Initialized
INFO - 2016-11-21 19:24:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:24:12 --> Pagination Class Initialized
INFO - 2016-11-21 19:24:12 --> Helper loaded: app_helper
INFO - 2016-11-21 19:24:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 19:24:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 19:24:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 19:24:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 19:24:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:24:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 19:24:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 19:24:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 19:24:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 19:24:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 19:24:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 19:24:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 19:24:13 --> Final output sent to browser
DEBUG - 2016-11-21 19:24:13 --> Total execution time: 0.9412
INFO - 2016-11-21 19:24:51 --> Config Class Initialized
INFO - 2016-11-21 19:24:51 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:24:51 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:24:51 --> Utf8 Class Initialized
INFO - 2016-11-21 19:24:51 --> URI Class Initialized
INFO - 2016-11-21 19:24:51 --> Router Class Initialized
INFO - 2016-11-21 19:24:51 --> Output Class Initialized
INFO - 2016-11-21 19:24:51 --> Security Class Initialized
DEBUG - 2016-11-21 19:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:24:51 --> Input Class Initialized
INFO - 2016-11-21 19:24:52 --> Language Class Initialized
INFO - 2016-11-21 19:24:52 --> Loader Class Initialized
INFO - 2016-11-21 19:24:52 --> Helper loaded: url_helper
INFO - 2016-11-21 19:24:52 --> Helper loaded: form_helper
INFO - 2016-11-21 19:24:52 --> Database Driver Class Initialized
INFO - 2016-11-21 19:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:24:52 --> Controller Class Initialized
INFO - 2016-11-21 19:24:52 --> Model Class Initialized
INFO - 2016-11-21 19:24:52 --> Form Validation Class Initialized
INFO - 2016-11-21 19:24:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:24:52 --> Pagination Class Initialized
INFO - 2016-11-21 19:24:52 --> Helper loaded: app_helper
INFO - 2016-11-21 19:24:52 --> Email Class Initialized
INFO - 2016-11-21 19:24:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 19:24:52 --> Final output sent to browser
DEBUG - 2016-11-21 19:24:52 --> Total execution time: 0.5553
INFO - 2016-11-21 19:35:35 --> Config Class Initialized
INFO - 2016-11-21 19:35:35 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:35:35 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:35:35 --> Utf8 Class Initialized
INFO - 2016-11-21 19:35:35 --> URI Class Initialized
DEBUG - 2016-11-21 19:35:35 --> No URI present. Default controller set.
INFO - 2016-11-21 19:35:35 --> Router Class Initialized
INFO - 2016-11-21 19:35:35 --> Output Class Initialized
INFO - 2016-11-21 19:35:35 --> Security Class Initialized
DEBUG - 2016-11-21 19:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:35:36 --> Input Class Initialized
INFO - 2016-11-21 19:35:36 --> Language Class Initialized
INFO - 2016-11-21 19:35:36 --> Loader Class Initialized
INFO - 2016-11-21 19:35:36 --> Helper loaded: url_helper
INFO - 2016-11-21 19:35:36 --> Helper loaded: form_helper
INFO - 2016-11-21 19:35:36 --> Database Driver Class Initialized
INFO - 2016-11-21 19:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:35:36 --> Controller Class Initialized
INFO - 2016-11-21 19:35:36 --> Model Class Initialized
INFO - 2016-11-21 19:35:36 --> Model Class Initialized
INFO - 2016-11-21 19:35:36 --> Model Class Initialized
INFO - 2016-11-21 19:35:36 --> Model Class Initialized
INFO - 2016-11-21 19:35:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:35:36 --> Pagination Class Initialized
INFO - 2016-11-21 19:35:36 --> Helper loaded: app_helper
INFO - 2016-11-21 19:35:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 19:35:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 19:35:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 19:35:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 19:35:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:35:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 19:35:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 19:35:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 19:35:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 19:35:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 19:35:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 19:35:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 19:35:36 --> Final output sent to browser
DEBUG - 2016-11-21 19:35:36 --> Total execution time: 0.9808
INFO - 2016-11-21 19:35:54 --> Config Class Initialized
INFO - 2016-11-21 19:35:54 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:35:54 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:35:54 --> Utf8 Class Initialized
INFO - 2016-11-21 19:35:54 --> URI Class Initialized
INFO - 2016-11-21 19:35:54 --> Router Class Initialized
INFO - 2016-11-21 19:35:54 --> Output Class Initialized
INFO - 2016-11-21 19:35:54 --> Security Class Initialized
DEBUG - 2016-11-21 19:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:35:54 --> Input Class Initialized
INFO - 2016-11-21 19:35:54 --> Language Class Initialized
INFO - 2016-11-21 19:35:54 --> Loader Class Initialized
INFO - 2016-11-21 19:35:54 --> Helper loaded: url_helper
INFO - 2016-11-21 19:35:54 --> Helper loaded: form_helper
INFO - 2016-11-21 19:35:54 --> Database Driver Class Initialized
INFO - 2016-11-21 19:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:35:54 --> Controller Class Initialized
INFO - 2016-11-21 19:35:54 --> Model Class Initialized
INFO - 2016-11-21 19:35:55 --> Form Validation Class Initialized
INFO - 2016-11-21 19:35:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:35:55 --> Pagination Class Initialized
INFO - 2016-11-21 19:35:55 --> Helper loaded: app_helper
INFO - 2016-11-21 19:35:55 --> Email Class Initialized
ERROR - 2016-11-21 19:35:55 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:35:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:35:55 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:35:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:35:55 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:35:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:35:55 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:35:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:35:55 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:35:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:35:55 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:35:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:35:55 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:35:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:35:55 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:35:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:35:55 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:35:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:35:55 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:35:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:35:55 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:35:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:35:55 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-11-21 19:35:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 19:35:55 --> Final output sent to browser
DEBUG - 2016-11-21 19:35:55 --> Total execution time: 1.1269
INFO - 2016-11-21 19:35:55 --> Config Class Initialized
INFO - 2016-11-21 19:35:55 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:35:55 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:35:55 --> Utf8 Class Initialized
INFO - 2016-11-21 19:35:55 --> URI Class Initialized
DEBUG - 2016-11-21 19:35:55 --> No URI present. Default controller set.
INFO - 2016-11-21 19:35:55 --> Router Class Initialized
INFO - 2016-11-21 19:35:55 --> Output Class Initialized
INFO - 2016-11-21 19:35:55 --> Security Class Initialized
DEBUG - 2016-11-21 19:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:35:56 --> Input Class Initialized
INFO - 2016-11-21 19:35:56 --> Language Class Initialized
INFO - 2016-11-21 19:35:56 --> Loader Class Initialized
INFO - 2016-11-21 19:35:56 --> Helper loaded: url_helper
INFO - 2016-11-21 19:35:56 --> Helper loaded: form_helper
INFO - 2016-11-21 19:35:56 --> Database Driver Class Initialized
INFO - 2016-11-21 19:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:35:56 --> Controller Class Initialized
INFO - 2016-11-21 19:35:56 --> Model Class Initialized
INFO - 2016-11-21 19:35:56 --> Model Class Initialized
INFO - 2016-11-21 19:35:56 --> Model Class Initialized
INFO - 2016-11-21 19:35:56 --> Model Class Initialized
INFO - 2016-11-21 19:35:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:35:56 --> Pagination Class Initialized
INFO - 2016-11-21 19:35:56 --> Helper loaded: app_helper
INFO - 2016-11-21 19:35:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 19:35:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 19:35:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 19:35:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 19:35:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:35:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 19:35:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 19:35:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 19:35:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 19:35:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 19:35:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 19:35:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 19:35:56 --> Final output sent to browser
DEBUG - 2016-11-21 19:35:56 --> Total execution time: 0.8187
INFO - 2016-11-21 19:40:35 --> Config Class Initialized
INFO - 2016-11-21 19:40:36 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:40:36 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:40:36 --> Utf8 Class Initialized
INFO - 2016-11-21 19:40:36 --> URI Class Initialized
DEBUG - 2016-11-21 19:40:36 --> No URI present. Default controller set.
INFO - 2016-11-21 19:40:36 --> Router Class Initialized
INFO - 2016-11-21 19:40:36 --> Output Class Initialized
INFO - 2016-11-21 19:40:36 --> Security Class Initialized
DEBUG - 2016-11-21 19:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:40:36 --> Input Class Initialized
INFO - 2016-11-21 19:40:36 --> Language Class Initialized
INFO - 2016-11-21 19:40:36 --> Loader Class Initialized
INFO - 2016-11-21 19:40:36 --> Helper loaded: url_helper
INFO - 2016-11-21 19:40:36 --> Helper loaded: form_helper
INFO - 2016-11-21 19:40:36 --> Database Driver Class Initialized
INFO - 2016-11-21 19:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:40:36 --> Controller Class Initialized
INFO - 2016-11-21 19:40:36 --> Model Class Initialized
INFO - 2016-11-21 19:40:36 --> Model Class Initialized
INFO - 2016-11-21 19:40:36 --> Model Class Initialized
INFO - 2016-11-21 19:40:36 --> Model Class Initialized
INFO - 2016-11-21 19:40:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:40:36 --> Pagination Class Initialized
INFO - 2016-11-21 19:40:36 --> Helper loaded: app_helper
INFO - 2016-11-21 19:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 19:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 19:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 19:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 19:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 19:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 19:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 19:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 19:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 19:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 19:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 19:40:36 --> Final output sent to browser
DEBUG - 2016-11-21 19:40:36 --> Total execution time: 0.8909
INFO - 2016-11-21 19:41:15 --> Config Class Initialized
INFO - 2016-11-21 19:41:15 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:41:15 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:41:15 --> Utf8 Class Initialized
INFO - 2016-11-21 19:41:15 --> URI Class Initialized
DEBUG - 2016-11-21 19:41:15 --> No URI present. Default controller set.
INFO - 2016-11-21 19:41:15 --> Router Class Initialized
INFO - 2016-11-21 19:41:15 --> Output Class Initialized
INFO - 2016-11-21 19:41:15 --> Security Class Initialized
DEBUG - 2016-11-21 19:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:41:15 --> Input Class Initialized
INFO - 2016-11-21 19:41:15 --> Language Class Initialized
INFO - 2016-11-21 19:41:15 --> Loader Class Initialized
INFO - 2016-11-21 19:41:15 --> Helper loaded: url_helper
INFO - 2016-11-21 19:41:15 --> Helper loaded: form_helper
INFO - 2016-11-21 19:41:15 --> Database Driver Class Initialized
INFO - 2016-11-21 19:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:41:15 --> Controller Class Initialized
INFO - 2016-11-21 19:41:15 --> Model Class Initialized
INFO - 2016-11-21 19:41:15 --> Model Class Initialized
INFO - 2016-11-21 19:41:15 --> Model Class Initialized
INFO - 2016-11-21 19:41:15 --> Model Class Initialized
INFO - 2016-11-21 19:41:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:41:15 --> Pagination Class Initialized
INFO - 2016-11-21 19:41:15 --> Helper loaded: app_helper
INFO - 2016-11-21 19:41:38 --> Config Class Initialized
INFO - 2016-11-21 19:41:38 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:41:38 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:41:38 --> Utf8 Class Initialized
INFO - 2016-11-21 19:41:38 --> URI Class Initialized
DEBUG - 2016-11-21 19:41:38 --> No URI present. Default controller set.
INFO - 2016-11-21 19:41:38 --> Router Class Initialized
INFO - 2016-11-21 19:41:38 --> Output Class Initialized
INFO - 2016-11-21 19:41:38 --> Security Class Initialized
DEBUG - 2016-11-21 19:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:41:38 --> Input Class Initialized
INFO - 2016-11-21 19:41:38 --> Language Class Initialized
INFO - 2016-11-21 19:41:38 --> Loader Class Initialized
INFO - 2016-11-21 19:41:38 --> Helper loaded: url_helper
INFO - 2016-11-21 19:41:38 --> Helper loaded: form_helper
INFO - 2016-11-21 19:41:38 --> Database Driver Class Initialized
INFO - 2016-11-21 19:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:41:38 --> Controller Class Initialized
INFO - 2016-11-21 19:41:38 --> Model Class Initialized
INFO - 2016-11-21 19:41:39 --> Model Class Initialized
INFO - 2016-11-21 19:41:39 --> Model Class Initialized
INFO - 2016-11-21 19:41:39 --> Model Class Initialized
INFO - 2016-11-21 19:41:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:41:39 --> Pagination Class Initialized
INFO - 2016-11-21 19:41:39 --> Helper loaded: app_helper
INFO - 2016-11-21 19:41:51 --> Config Class Initialized
INFO - 2016-11-21 19:41:51 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:41:51 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:41:51 --> Utf8 Class Initialized
INFO - 2016-11-21 19:41:51 --> URI Class Initialized
DEBUG - 2016-11-21 19:41:51 --> No URI present. Default controller set.
INFO - 2016-11-21 19:41:51 --> Router Class Initialized
INFO - 2016-11-21 19:41:51 --> Output Class Initialized
INFO - 2016-11-21 19:41:51 --> Security Class Initialized
DEBUG - 2016-11-21 19:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:41:51 --> Input Class Initialized
INFO - 2016-11-21 19:41:51 --> Language Class Initialized
INFO - 2016-11-21 19:41:51 --> Loader Class Initialized
INFO - 2016-11-21 19:41:51 --> Helper loaded: url_helper
INFO - 2016-11-21 19:41:51 --> Helper loaded: form_helper
INFO - 2016-11-21 19:41:51 --> Database Driver Class Initialized
INFO - 2016-11-21 19:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:41:51 --> Controller Class Initialized
INFO - 2016-11-21 19:41:51 --> Model Class Initialized
INFO - 2016-11-21 19:41:51 --> Model Class Initialized
INFO - 2016-11-21 19:41:52 --> Model Class Initialized
INFO - 2016-11-21 19:41:52 --> Model Class Initialized
INFO - 2016-11-21 19:41:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:41:52 --> Pagination Class Initialized
INFO - 2016-11-21 19:41:52 --> Helper loaded: app_helper
INFO - 2016-11-21 19:41:54 --> Config Class Initialized
INFO - 2016-11-21 19:41:54 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:41:54 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:41:54 --> Utf8 Class Initialized
INFO - 2016-11-21 19:41:54 --> URI Class Initialized
DEBUG - 2016-11-21 19:41:54 --> No URI present. Default controller set.
INFO - 2016-11-21 19:41:54 --> Router Class Initialized
INFO - 2016-11-21 19:41:54 --> Output Class Initialized
INFO - 2016-11-21 19:41:54 --> Security Class Initialized
DEBUG - 2016-11-21 19:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:41:54 --> Input Class Initialized
INFO - 2016-11-21 19:41:54 --> Language Class Initialized
INFO - 2016-11-21 19:41:54 --> Loader Class Initialized
INFO - 2016-11-21 19:41:54 --> Helper loaded: url_helper
INFO - 2016-11-21 19:41:54 --> Helper loaded: form_helper
INFO - 2016-11-21 19:41:54 --> Database Driver Class Initialized
INFO - 2016-11-21 19:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:41:54 --> Controller Class Initialized
INFO - 2016-11-21 19:41:54 --> Model Class Initialized
INFO - 2016-11-21 19:41:54 --> Model Class Initialized
INFO - 2016-11-21 19:41:54 --> Model Class Initialized
INFO - 2016-11-21 19:41:54 --> Model Class Initialized
INFO - 2016-11-21 19:41:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:41:54 --> Pagination Class Initialized
INFO - 2016-11-21 19:41:54 --> Helper loaded: app_helper
INFO - 2016-11-21 19:42:30 --> Config Class Initialized
INFO - 2016-11-21 19:42:31 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:42:31 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:42:31 --> Utf8 Class Initialized
INFO - 2016-11-21 19:42:31 --> URI Class Initialized
DEBUG - 2016-11-21 19:42:31 --> No URI present. Default controller set.
INFO - 2016-11-21 19:42:31 --> Router Class Initialized
INFO - 2016-11-21 19:42:31 --> Output Class Initialized
INFO - 2016-11-21 19:42:31 --> Security Class Initialized
DEBUG - 2016-11-21 19:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:42:31 --> Input Class Initialized
INFO - 2016-11-21 19:42:31 --> Language Class Initialized
INFO - 2016-11-21 19:42:31 --> Loader Class Initialized
INFO - 2016-11-21 19:42:31 --> Helper loaded: url_helper
INFO - 2016-11-21 19:42:31 --> Helper loaded: form_helper
INFO - 2016-11-21 19:42:31 --> Database Driver Class Initialized
INFO - 2016-11-21 19:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:42:31 --> Controller Class Initialized
INFO - 2016-11-21 19:42:31 --> Model Class Initialized
INFO - 2016-11-21 19:42:31 --> Model Class Initialized
INFO - 2016-11-21 19:42:31 --> Model Class Initialized
INFO - 2016-11-21 19:42:31 --> Model Class Initialized
INFO - 2016-11-21 19:42:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:42:31 --> Pagination Class Initialized
INFO - 2016-11-21 19:42:31 --> Helper loaded: app_helper
INFO - 2016-11-21 19:42:41 --> Config Class Initialized
INFO - 2016-11-21 19:42:41 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:42:41 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:42:41 --> Utf8 Class Initialized
INFO - 2016-11-21 19:42:41 --> URI Class Initialized
DEBUG - 2016-11-21 19:42:41 --> No URI present. Default controller set.
INFO - 2016-11-21 19:42:41 --> Router Class Initialized
INFO - 2016-11-21 19:42:41 --> Output Class Initialized
INFO - 2016-11-21 19:42:41 --> Security Class Initialized
DEBUG - 2016-11-21 19:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:42:41 --> Input Class Initialized
INFO - 2016-11-21 19:42:41 --> Language Class Initialized
INFO - 2016-11-21 19:42:41 --> Loader Class Initialized
INFO - 2016-11-21 19:42:41 --> Helper loaded: url_helper
INFO - 2016-11-21 19:42:41 --> Helper loaded: form_helper
INFO - 2016-11-21 19:42:42 --> Database Driver Class Initialized
INFO - 2016-11-21 19:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:42:42 --> Controller Class Initialized
INFO - 2016-11-21 19:42:42 --> Model Class Initialized
INFO - 2016-11-21 19:42:42 --> Model Class Initialized
INFO - 2016-11-21 19:42:42 --> Model Class Initialized
INFO - 2016-11-21 19:42:42 --> Model Class Initialized
INFO - 2016-11-21 19:42:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:42:42 --> Pagination Class Initialized
INFO - 2016-11-21 19:42:42 --> Helper loaded: app_helper
INFO - 2016-11-21 19:44:34 --> Config Class Initialized
INFO - 2016-11-21 19:44:34 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:44:34 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:44:34 --> Utf8 Class Initialized
INFO - 2016-11-21 19:44:34 --> URI Class Initialized
DEBUG - 2016-11-21 19:44:34 --> No URI present. Default controller set.
INFO - 2016-11-21 19:44:34 --> Router Class Initialized
INFO - 2016-11-21 19:44:34 --> Output Class Initialized
INFO - 2016-11-21 19:44:34 --> Security Class Initialized
DEBUG - 2016-11-21 19:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:44:34 --> Input Class Initialized
INFO - 2016-11-21 19:44:34 --> Language Class Initialized
INFO - 2016-11-21 19:44:34 --> Loader Class Initialized
INFO - 2016-11-21 19:44:34 --> Helper loaded: url_helper
INFO - 2016-11-21 19:44:34 --> Helper loaded: form_helper
INFO - 2016-11-21 19:44:34 --> Database Driver Class Initialized
INFO - 2016-11-21 19:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:44:34 --> Controller Class Initialized
INFO - 2016-11-21 19:44:35 --> Model Class Initialized
INFO - 2016-11-21 19:44:35 --> Model Class Initialized
INFO - 2016-11-21 19:44:35 --> Model Class Initialized
INFO - 2016-11-21 19:44:35 --> Model Class Initialized
INFO - 2016-11-21 19:44:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:44:35 --> Pagination Class Initialized
INFO - 2016-11-21 19:44:35 --> Helper loaded: app_helper
INFO - 2016-11-21 19:44:46 --> Config Class Initialized
INFO - 2016-11-21 19:44:46 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:44:46 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:44:46 --> Utf8 Class Initialized
INFO - 2016-11-21 19:44:46 --> URI Class Initialized
DEBUG - 2016-11-21 19:44:47 --> No URI present. Default controller set.
INFO - 2016-11-21 19:44:47 --> Router Class Initialized
INFO - 2016-11-21 19:44:47 --> Output Class Initialized
INFO - 2016-11-21 19:44:47 --> Security Class Initialized
DEBUG - 2016-11-21 19:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:44:47 --> Input Class Initialized
INFO - 2016-11-21 19:44:47 --> Language Class Initialized
INFO - 2016-11-21 19:44:47 --> Loader Class Initialized
INFO - 2016-11-21 19:44:47 --> Helper loaded: url_helper
INFO - 2016-11-21 19:44:47 --> Helper loaded: form_helper
INFO - 2016-11-21 19:44:47 --> Database Driver Class Initialized
INFO - 2016-11-21 19:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:44:47 --> Controller Class Initialized
INFO - 2016-11-21 19:44:47 --> Model Class Initialized
INFO - 2016-11-21 19:44:47 --> Model Class Initialized
INFO - 2016-11-21 19:44:47 --> Model Class Initialized
INFO - 2016-11-21 19:44:47 --> Model Class Initialized
INFO - 2016-11-21 19:44:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:44:47 --> Pagination Class Initialized
INFO - 2016-11-21 19:44:47 --> Helper loaded: app_helper
INFO - 2016-11-21 19:45:56 --> Config Class Initialized
INFO - 2016-11-21 19:45:56 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:45:56 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:45:56 --> Utf8 Class Initialized
INFO - 2016-11-21 19:45:56 --> URI Class Initialized
DEBUG - 2016-11-21 19:45:56 --> No URI present. Default controller set.
INFO - 2016-11-21 19:45:56 --> Router Class Initialized
INFO - 2016-11-21 19:45:56 --> Output Class Initialized
INFO - 2016-11-21 19:45:56 --> Security Class Initialized
DEBUG - 2016-11-21 19:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:45:57 --> Input Class Initialized
INFO - 2016-11-21 19:45:57 --> Language Class Initialized
INFO - 2016-11-21 19:45:57 --> Loader Class Initialized
INFO - 2016-11-21 19:45:57 --> Helper loaded: url_helper
INFO - 2016-11-21 19:45:57 --> Helper loaded: form_helper
INFO - 2016-11-21 19:45:57 --> Database Driver Class Initialized
INFO - 2016-11-21 19:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:45:57 --> Controller Class Initialized
INFO - 2016-11-21 19:45:57 --> Model Class Initialized
INFO - 2016-11-21 19:45:57 --> Model Class Initialized
INFO - 2016-11-21 19:45:57 --> Model Class Initialized
INFO - 2016-11-21 19:45:57 --> Model Class Initialized
INFO - 2016-11-21 19:45:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:45:57 --> Pagination Class Initialized
INFO - 2016-11-21 19:45:57 --> Helper loaded: app_helper
INFO - 2016-11-21 19:46:08 --> Config Class Initialized
INFO - 2016-11-21 19:46:08 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:46:08 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:46:08 --> Utf8 Class Initialized
INFO - 2016-11-21 19:46:08 --> URI Class Initialized
DEBUG - 2016-11-21 19:46:08 --> No URI present. Default controller set.
INFO - 2016-11-21 19:46:08 --> Router Class Initialized
INFO - 2016-11-21 19:46:08 --> Output Class Initialized
INFO - 2016-11-21 19:46:08 --> Security Class Initialized
DEBUG - 2016-11-21 19:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:46:08 --> Input Class Initialized
INFO - 2016-11-21 19:46:08 --> Language Class Initialized
INFO - 2016-11-21 19:46:08 --> Loader Class Initialized
INFO - 2016-11-21 19:46:08 --> Helper loaded: url_helper
INFO - 2016-11-21 19:46:08 --> Helper loaded: form_helper
INFO - 2016-11-21 19:46:08 --> Database Driver Class Initialized
INFO - 2016-11-21 19:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:46:08 --> Controller Class Initialized
INFO - 2016-11-21 19:46:08 --> Model Class Initialized
INFO - 2016-11-21 19:46:08 --> Model Class Initialized
INFO - 2016-11-21 19:46:08 --> Model Class Initialized
INFO - 2016-11-21 19:46:08 --> Model Class Initialized
INFO - 2016-11-21 19:46:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:46:08 --> Pagination Class Initialized
INFO - 2016-11-21 19:46:08 --> Helper loaded: app_helper
INFO - 2016-11-21 19:46:18 --> Config Class Initialized
INFO - 2016-11-21 19:46:18 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:46:18 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:46:18 --> Utf8 Class Initialized
INFO - 2016-11-21 19:46:18 --> URI Class Initialized
DEBUG - 2016-11-21 19:46:18 --> No URI present. Default controller set.
INFO - 2016-11-21 19:46:18 --> Router Class Initialized
INFO - 2016-11-21 19:46:18 --> Output Class Initialized
INFO - 2016-11-21 19:46:18 --> Security Class Initialized
DEBUG - 2016-11-21 19:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:46:18 --> Input Class Initialized
INFO - 2016-11-21 19:46:18 --> Language Class Initialized
INFO - 2016-11-21 19:46:18 --> Loader Class Initialized
INFO - 2016-11-21 19:46:18 --> Helper loaded: url_helper
INFO - 2016-11-21 19:46:18 --> Helper loaded: form_helper
INFO - 2016-11-21 19:46:18 --> Database Driver Class Initialized
INFO - 2016-11-21 19:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:46:18 --> Controller Class Initialized
INFO - 2016-11-21 19:46:18 --> Model Class Initialized
INFO - 2016-11-21 19:46:18 --> Model Class Initialized
INFO - 2016-11-21 19:46:18 --> Model Class Initialized
INFO - 2016-11-21 19:46:18 --> Model Class Initialized
INFO - 2016-11-21 19:46:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:46:18 --> Pagination Class Initialized
INFO - 2016-11-21 19:46:18 --> Helper loaded: app_helper
INFO - 2016-11-21 19:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 19:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 19:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 19:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 19:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 19:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 19:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 19:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 19:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 19:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 19:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 19:46:19 --> Final output sent to browser
DEBUG - 2016-11-21 19:46:19 --> Total execution time: 0.9588
INFO - 2016-11-21 19:46:21 --> Config Class Initialized
INFO - 2016-11-21 19:46:21 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:46:21 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:46:21 --> Utf8 Class Initialized
INFO - 2016-11-21 19:46:21 --> URI Class Initialized
INFO - 2016-11-21 19:46:21 --> Router Class Initialized
INFO - 2016-11-21 19:46:21 --> Output Class Initialized
INFO - 2016-11-21 19:46:21 --> Security Class Initialized
DEBUG - 2016-11-21 19:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:46:21 --> Input Class Initialized
INFO - 2016-11-21 19:46:21 --> Language Class Initialized
INFO - 2016-11-21 19:46:21 --> Loader Class Initialized
INFO - 2016-11-21 19:46:21 --> Helper loaded: url_helper
INFO - 2016-11-21 19:46:21 --> Helper loaded: form_helper
INFO - 2016-11-21 19:46:21 --> Database Driver Class Initialized
INFO - 2016-11-21 19:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:46:21 --> Controller Class Initialized
INFO - 2016-11-21 19:46:21 --> Model Class Initialized
INFO - 2016-11-21 19:46:21 --> Model Class Initialized
INFO - 2016-11-21 19:46:21 --> Model Class Initialized
INFO - 2016-11-21 19:46:21 --> Model Class Initialized
INFO - 2016-11-21 19:46:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:46:21 --> Pagination Class Initialized
INFO - 2016-11-21 19:46:21 --> Helper loaded: app_helper
DEBUG - 2016-11-21 19:46:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-21 19:46:21 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 168
ERROR - 2016-11-21 19:46:21 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 168
INFO - 2016-11-21 19:46:21 --> Config Class Initialized
INFO - 2016-11-21 19:46:21 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:46:21 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:46:21 --> Utf8 Class Initialized
INFO - 2016-11-21 19:46:21 --> URI Class Initialized
DEBUG - 2016-11-21 19:46:21 --> No URI present. Default controller set.
INFO - 2016-11-21 19:46:21 --> Router Class Initialized
INFO - 2016-11-21 19:46:21 --> Output Class Initialized
INFO - 2016-11-21 19:46:21 --> Security Class Initialized
DEBUG - 2016-11-21 19:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:46:21 --> Input Class Initialized
INFO - 2016-11-21 19:46:21 --> Language Class Initialized
INFO - 2016-11-21 19:46:22 --> Loader Class Initialized
INFO - 2016-11-21 19:46:22 --> Helper loaded: url_helper
INFO - 2016-11-21 19:46:22 --> Helper loaded: form_helper
INFO - 2016-11-21 19:46:22 --> Database Driver Class Initialized
INFO - 2016-11-21 19:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:46:22 --> Controller Class Initialized
INFO - 2016-11-21 19:46:22 --> Model Class Initialized
INFO - 2016-11-21 19:46:22 --> Model Class Initialized
INFO - 2016-11-21 19:46:22 --> Model Class Initialized
INFO - 2016-11-21 19:46:22 --> Model Class Initialized
INFO - 2016-11-21 19:46:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:46:22 --> Pagination Class Initialized
INFO - 2016-11-21 19:46:22 --> Helper loaded: app_helper
INFO - 2016-11-21 19:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 19:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-21 19:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 19:46:22 --> Final output sent to browser
DEBUG - 2016-11-21 19:46:22 --> Total execution time: 0.7166
INFO - 2016-11-21 19:46:34 --> Config Class Initialized
INFO - 2016-11-21 19:46:34 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:46:34 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:46:34 --> Utf8 Class Initialized
INFO - 2016-11-21 19:46:34 --> URI Class Initialized
INFO - 2016-11-21 19:46:34 --> Router Class Initialized
INFO - 2016-11-21 19:46:34 --> Output Class Initialized
INFO - 2016-11-21 19:46:34 --> Security Class Initialized
DEBUG - 2016-11-21 19:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:46:34 --> Input Class Initialized
INFO - 2016-11-21 19:46:34 --> Language Class Initialized
INFO - 2016-11-21 19:46:34 --> Loader Class Initialized
INFO - 2016-11-21 19:46:34 --> Helper loaded: url_helper
INFO - 2016-11-21 19:46:34 --> Helper loaded: form_helper
INFO - 2016-11-21 19:46:34 --> Database Driver Class Initialized
INFO - 2016-11-21 19:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:46:34 --> Controller Class Initialized
INFO - 2016-11-21 19:46:34 --> Model Class Initialized
INFO - 2016-11-21 19:46:34 --> Model Class Initialized
INFO - 2016-11-21 19:46:34 --> Model Class Initialized
INFO - 2016-11-21 19:46:34 --> Model Class Initialized
INFO - 2016-11-21 19:46:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:46:34 --> Pagination Class Initialized
INFO - 2016-11-21 19:46:34 --> Helper loaded: app_helper
DEBUG - 2016-11-21 19:46:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-21 19:46:34 --> Model Class Initialized
ERROR - 2016-11-21 19:46:34 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\LMS\app\controllers\Auth.php 156
ERROR - 2016-11-21 19:46:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\controllers\Auth.php 156
INFO - 2016-11-21 19:46:34 --> Final output sent to browser
DEBUG - 2016-11-21 19:46:34 --> Total execution time: 0.6671
INFO - 2016-11-21 19:47:54 --> Config Class Initialized
INFO - 2016-11-21 19:47:54 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:47:54 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:47:54 --> Utf8 Class Initialized
INFO - 2016-11-21 19:47:54 --> URI Class Initialized
DEBUG - 2016-11-21 19:47:54 --> No URI present. Default controller set.
INFO - 2016-11-21 19:47:54 --> Router Class Initialized
INFO - 2016-11-21 19:47:54 --> Output Class Initialized
INFO - 2016-11-21 19:47:54 --> Security Class Initialized
DEBUG - 2016-11-21 19:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:47:54 --> Input Class Initialized
INFO - 2016-11-21 19:47:54 --> Language Class Initialized
INFO - 2016-11-21 19:47:54 --> Loader Class Initialized
INFO - 2016-11-21 19:47:54 --> Helper loaded: url_helper
INFO - 2016-11-21 19:47:54 --> Helper loaded: form_helper
INFO - 2016-11-21 19:47:54 --> Database Driver Class Initialized
INFO - 2016-11-21 19:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:47:54 --> Controller Class Initialized
INFO - 2016-11-21 19:47:54 --> Model Class Initialized
INFO - 2016-11-21 19:47:54 --> Model Class Initialized
INFO - 2016-11-21 19:47:54 --> Model Class Initialized
INFO - 2016-11-21 19:47:54 --> Model Class Initialized
INFO - 2016-11-21 19:47:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:47:54 --> Pagination Class Initialized
INFO - 2016-11-21 19:47:54 --> Helper loaded: app_helper
INFO - 2016-11-21 19:47:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 19:47:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 19:47:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 19:47:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 19:47:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:47:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 19:47:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 19:47:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 19:47:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 19:47:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 19:47:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 19:47:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 19:47:55 --> Final output sent to browser
DEBUG - 2016-11-21 19:47:55 --> Total execution time: 0.9298
INFO - 2016-11-21 19:48:06 --> Config Class Initialized
INFO - 2016-11-21 19:48:06 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:48:06 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:48:06 --> Utf8 Class Initialized
INFO - 2016-11-21 19:48:06 --> URI Class Initialized
DEBUG - 2016-11-21 19:48:06 --> No URI present. Default controller set.
INFO - 2016-11-21 19:48:06 --> Router Class Initialized
INFO - 2016-11-21 19:48:06 --> Output Class Initialized
INFO - 2016-11-21 19:48:06 --> Security Class Initialized
DEBUG - 2016-11-21 19:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:48:07 --> Input Class Initialized
INFO - 2016-11-21 19:48:07 --> Language Class Initialized
INFO - 2016-11-21 19:48:07 --> Loader Class Initialized
INFO - 2016-11-21 19:48:07 --> Helper loaded: url_helper
INFO - 2016-11-21 19:48:07 --> Helper loaded: form_helper
INFO - 2016-11-21 19:48:07 --> Database Driver Class Initialized
INFO - 2016-11-21 19:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:48:07 --> Controller Class Initialized
INFO - 2016-11-21 19:48:07 --> Model Class Initialized
INFO - 2016-11-21 19:48:07 --> Model Class Initialized
INFO - 2016-11-21 19:48:07 --> Model Class Initialized
INFO - 2016-11-21 19:48:07 --> Model Class Initialized
INFO - 2016-11-21 19:48:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:48:07 --> Pagination Class Initialized
INFO - 2016-11-21 19:48:07 --> Helper loaded: app_helper
INFO - 2016-11-21 19:48:09 --> Config Class Initialized
INFO - 2016-11-21 19:48:09 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:48:09 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:48:09 --> Utf8 Class Initialized
INFO - 2016-11-21 19:48:09 --> URI Class Initialized
DEBUG - 2016-11-21 19:48:09 --> No URI present. Default controller set.
INFO - 2016-11-21 19:48:09 --> Router Class Initialized
INFO - 2016-11-21 19:48:09 --> Output Class Initialized
INFO - 2016-11-21 19:48:09 --> Security Class Initialized
DEBUG - 2016-11-21 19:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:48:09 --> Input Class Initialized
INFO - 2016-11-21 19:48:09 --> Language Class Initialized
INFO - 2016-11-21 19:48:09 --> Loader Class Initialized
INFO - 2016-11-21 19:48:09 --> Helper loaded: url_helper
INFO - 2016-11-21 19:48:09 --> Helper loaded: form_helper
INFO - 2016-11-21 19:48:09 --> Database Driver Class Initialized
INFO - 2016-11-21 19:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:48:09 --> Controller Class Initialized
INFO - 2016-11-21 19:48:09 --> Model Class Initialized
INFO - 2016-11-21 19:48:09 --> Model Class Initialized
INFO - 2016-11-21 19:48:09 --> Model Class Initialized
INFO - 2016-11-21 19:48:09 --> Model Class Initialized
INFO - 2016-11-21 19:48:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:48:09 --> Pagination Class Initialized
INFO - 2016-11-21 19:48:09 --> Helper loaded: app_helper
INFO - 2016-11-21 19:48:17 --> Config Class Initialized
INFO - 2016-11-21 19:48:17 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:48:17 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:48:17 --> Utf8 Class Initialized
INFO - 2016-11-21 19:48:17 --> URI Class Initialized
DEBUG - 2016-11-21 19:48:17 --> No URI present. Default controller set.
INFO - 2016-11-21 19:48:17 --> Router Class Initialized
INFO - 2016-11-21 19:48:17 --> Output Class Initialized
INFO - 2016-11-21 19:48:17 --> Security Class Initialized
DEBUG - 2016-11-21 19:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:48:17 --> Input Class Initialized
INFO - 2016-11-21 19:48:17 --> Language Class Initialized
INFO - 2016-11-21 19:48:17 --> Loader Class Initialized
INFO - 2016-11-21 19:48:17 --> Helper loaded: url_helper
INFO - 2016-11-21 19:48:17 --> Helper loaded: form_helper
INFO - 2016-11-21 19:48:17 --> Database Driver Class Initialized
INFO - 2016-11-21 19:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:48:18 --> Controller Class Initialized
INFO - 2016-11-21 19:48:18 --> Model Class Initialized
INFO - 2016-11-21 19:48:18 --> Model Class Initialized
INFO - 2016-11-21 19:48:18 --> Model Class Initialized
INFO - 2016-11-21 19:48:18 --> Model Class Initialized
INFO - 2016-11-21 19:48:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:48:18 --> Pagination Class Initialized
INFO - 2016-11-21 19:48:18 --> Helper loaded: app_helper
INFO - 2016-11-21 19:48:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 19:48:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 19:48:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 19:48:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 19:48:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:48:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 19:48:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 19:48:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 19:48:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 19:48:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 19:48:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 19:48:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 19:48:18 --> Final output sent to browser
DEBUG - 2016-11-21 19:48:18 --> Total execution time: 0.9271
INFO - 2016-11-21 19:48:20 --> Config Class Initialized
INFO - 2016-11-21 19:48:20 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:48:20 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:48:20 --> Utf8 Class Initialized
INFO - 2016-11-21 19:48:20 --> URI Class Initialized
INFO - 2016-11-21 19:48:20 --> Router Class Initialized
INFO - 2016-11-21 19:48:20 --> Output Class Initialized
INFO - 2016-11-21 19:48:20 --> Security Class Initialized
DEBUG - 2016-11-21 19:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:48:20 --> Input Class Initialized
INFO - 2016-11-21 19:48:20 --> Language Class Initialized
INFO - 2016-11-21 19:48:20 --> Loader Class Initialized
INFO - 2016-11-21 19:48:20 --> Helper loaded: url_helper
INFO - 2016-11-21 19:48:20 --> Helper loaded: form_helper
INFO - 2016-11-21 19:48:20 --> Database Driver Class Initialized
INFO - 2016-11-21 19:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:48:20 --> Controller Class Initialized
INFO - 2016-11-21 19:48:20 --> Model Class Initialized
INFO - 2016-11-21 19:48:20 --> Model Class Initialized
INFO - 2016-11-21 19:48:20 --> Model Class Initialized
INFO - 2016-11-21 19:48:20 --> Model Class Initialized
INFO - 2016-11-21 19:48:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:48:21 --> Pagination Class Initialized
INFO - 2016-11-21 19:48:21 --> Helper loaded: app_helper
DEBUG - 2016-11-21 19:48:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-21 19:48:21 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 168
ERROR - 2016-11-21 19:48:21 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 168
INFO - 2016-11-21 19:48:21 --> Config Class Initialized
INFO - 2016-11-21 19:48:21 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:48:21 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:48:21 --> Utf8 Class Initialized
INFO - 2016-11-21 19:48:21 --> URI Class Initialized
DEBUG - 2016-11-21 19:48:21 --> No URI present. Default controller set.
INFO - 2016-11-21 19:48:21 --> Router Class Initialized
INFO - 2016-11-21 19:48:21 --> Output Class Initialized
INFO - 2016-11-21 19:48:21 --> Security Class Initialized
DEBUG - 2016-11-21 19:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:48:21 --> Input Class Initialized
INFO - 2016-11-21 19:48:21 --> Language Class Initialized
INFO - 2016-11-21 19:48:21 --> Loader Class Initialized
INFO - 2016-11-21 19:48:21 --> Helper loaded: url_helper
INFO - 2016-11-21 19:48:21 --> Helper loaded: form_helper
INFO - 2016-11-21 19:48:21 --> Database Driver Class Initialized
INFO - 2016-11-21 19:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:48:21 --> Controller Class Initialized
INFO - 2016-11-21 19:48:21 --> Model Class Initialized
INFO - 2016-11-21 19:48:21 --> Model Class Initialized
INFO - 2016-11-21 19:48:21 --> Model Class Initialized
INFO - 2016-11-21 19:48:21 --> Model Class Initialized
INFO - 2016-11-21 19:48:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:48:21 --> Pagination Class Initialized
INFO - 2016-11-21 19:48:21 --> Helper loaded: app_helper
INFO - 2016-11-21 19:48:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 19:48:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-21 19:48:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 19:48:21 --> Final output sent to browser
DEBUG - 2016-11-21 19:48:21 --> Total execution time: 0.6218
INFO - 2016-11-21 19:48:23 --> Config Class Initialized
INFO - 2016-11-21 19:48:23 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:48:23 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:48:23 --> Utf8 Class Initialized
INFO - 2016-11-21 19:48:23 --> URI Class Initialized
DEBUG - 2016-11-21 19:48:23 --> No URI present. Default controller set.
INFO - 2016-11-21 19:48:23 --> Router Class Initialized
INFO - 2016-11-21 19:48:23 --> Output Class Initialized
INFO - 2016-11-21 19:48:23 --> Security Class Initialized
DEBUG - 2016-11-21 19:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:48:23 --> Input Class Initialized
INFO - 2016-11-21 19:48:23 --> Language Class Initialized
INFO - 2016-11-21 19:48:23 --> Loader Class Initialized
INFO - 2016-11-21 19:48:23 --> Helper loaded: url_helper
INFO - 2016-11-21 19:48:23 --> Helper loaded: form_helper
INFO - 2016-11-21 19:48:23 --> Database Driver Class Initialized
INFO - 2016-11-21 19:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:48:23 --> Controller Class Initialized
INFO - 2016-11-21 19:48:24 --> Model Class Initialized
INFO - 2016-11-21 19:48:24 --> Model Class Initialized
INFO - 2016-11-21 19:48:24 --> Model Class Initialized
INFO - 2016-11-21 19:48:24 --> Model Class Initialized
INFO - 2016-11-21 19:48:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:48:24 --> Pagination Class Initialized
INFO - 2016-11-21 19:48:24 --> Helper loaded: app_helper
INFO - 2016-11-21 19:48:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 19:48:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-21 19:48:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 19:48:24 --> Final output sent to browser
DEBUG - 2016-11-21 19:48:24 --> Total execution time: 0.7579
INFO - 2016-11-21 19:48:36 --> Config Class Initialized
INFO - 2016-11-21 19:48:36 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:48:36 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:48:36 --> Utf8 Class Initialized
INFO - 2016-11-21 19:48:36 --> URI Class Initialized
INFO - 2016-11-21 19:48:36 --> Router Class Initialized
INFO - 2016-11-21 19:48:36 --> Output Class Initialized
INFO - 2016-11-21 19:48:36 --> Security Class Initialized
DEBUG - 2016-11-21 19:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:48:36 --> Input Class Initialized
INFO - 2016-11-21 19:48:36 --> Language Class Initialized
INFO - 2016-11-21 19:48:36 --> Loader Class Initialized
INFO - 2016-11-21 19:48:36 --> Helper loaded: url_helper
INFO - 2016-11-21 19:48:36 --> Helper loaded: form_helper
INFO - 2016-11-21 19:48:36 --> Database Driver Class Initialized
INFO - 2016-11-21 19:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:48:36 --> Controller Class Initialized
INFO - 2016-11-21 19:48:36 --> Model Class Initialized
INFO - 2016-11-21 19:48:36 --> Model Class Initialized
INFO - 2016-11-21 19:48:36 --> Model Class Initialized
INFO - 2016-11-21 19:48:36 --> Model Class Initialized
INFO - 2016-11-21 19:48:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:48:36 --> Pagination Class Initialized
INFO - 2016-11-21 19:48:36 --> Helper loaded: app_helper
DEBUG - 2016-11-21 19:48:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-21 19:48:36 --> Model Class Initialized
ERROR - 2016-11-21 19:48:36 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\LMS\app\controllers\Auth.php 156
ERROR - 2016-11-21 19:48:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\controllers\Auth.php 156
INFO - 2016-11-21 19:48:36 --> Final output sent to browser
DEBUG - 2016-11-21 19:48:36 --> Total execution time: 0.7114
INFO - 2016-11-21 19:50:59 --> Config Class Initialized
INFO - 2016-11-21 19:50:59 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:50:59 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:50:59 --> Utf8 Class Initialized
INFO - 2016-11-21 19:50:59 --> URI Class Initialized
DEBUG - 2016-11-21 19:50:59 --> No URI present. Default controller set.
INFO - 2016-11-21 19:50:59 --> Router Class Initialized
INFO - 2016-11-21 19:50:59 --> Output Class Initialized
INFO - 2016-11-21 19:50:59 --> Security Class Initialized
DEBUG - 2016-11-21 19:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:50:59 --> Input Class Initialized
INFO - 2016-11-21 19:51:00 --> Language Class Initialized
INFO - 2016-11-21 19:51:00 --> Loader Class Initialized
INFO - 2016-11-21 19:51:00 --> Helper loaded: url_helper
INFO - 2016-11-21 19:51:00 --> Helper loaded: form_helper
INFO - 2016-11-21 19:51:00 --> Database Driver Class Initialized
INFO - 2016-11-21 19:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:51:00 --> Controller Class Initialized
INFO - 2016-11-21 19:51:00 --> Model Class Initialized
INFO - 2016-11-21 19:51:00 --> Model Class Initialized
INFO - 2016-11-21 19:51:00 --> Model Class Initialized
INFO - 2016-11-21 19:51:00 --> Model Class Initialized
INFO - 2016-11-21 19:51:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:51:00 --> Pagination Class Initialized
INFO - 2016-11-21 19:51:00 --> Helper loaded: app_helper
INFO - 2016-11-21 19:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 19:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 19:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 19:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 19:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 19:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 19:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 19:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 19:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 19:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 19:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 19:51:00 --> Final output sent to browser
DEBUG - 2016-11-21 19:51:00 --> Total execution time: 0.9854
INFO - 2016-11-21 19:51:09 --> Config Class Initialized
INFO - 2016-11-21 19:51:09 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:51:09 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:51:09 --> Utf8 Class Initialized
INFO - 2016-11-21 19:51:09 --> URI Class Initialized
INFO - 2016-11-21 19:51:10 --> Router Class Initialized
INFO - 2016-11-21 19:51:10 --> Output Class Initialized
INFO - 2016-11-21 19:51:10 --> Security Class Initialized
DEBUG - 2016-11-21 19:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:51:10 --> Input Class Initialized
INFO - 2016-11-21 19:51:10 --> Language Class Initialized
INFO - 2016-11-21 19:51:10 --> Loader Class Initialized
INFO - 2016-11-21 19:51:10 --> Helper loaded: url_helper
INFO - 2016-11-21 19:51:10 --> Helper loaded: form_helper
INFO - 2016-11-21 19:51:10 --> Database Driver Class Initialized
INFO - 2016-11-21 19:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:51:10 --> Controller Class Initialized
INFO - 2016-11-21 19:51:10 --> Model Class Initialized
INFO - 2016-11-21 19:51:10 --> Model Class Initialized
INFO - 2016-11-21 19:51:10 --> Model Class Initialized
INFO - 2016-11-21 19:51:10 --> Model Class Initialized
INFO - 2016-11-21 19:51:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:51:10 --> Pagination Class Initialized
INFO - 2016-11-21 19:51:10 --> Helper loaded: app_helper
DEBUG - 2016-11-21 19:51:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-21 19:51:10 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 167
ERROR - 2016-11-21 19:51:10 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 167
INFO - 2016-11-21 19:51:10 --> Config Class Initialized
INFO - 2016-11-21 19:51:10 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:51:10 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:51:10 --> Utf8 Class Initialized
INFO - 2016-11-21 19:51:10 --> URI Class Initialized
DEBUG - 2016-11-21 19:51:10 --> No URI present. Default controller set.
INFO - 2016-11-21 19:51:10 --> Router Class Initialized
INFO - 2016-11-21 19:51:10 --> Output Class Initialized
INFO - 2016-11-21 19:51:10 --> Security Class Initialized
DEBUG - 2016-11-21 19:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:51:10 --> Input Class Initialized
INFO - 2016-11-21 19:51:10 --> Language Class Initialized
INFO - 2016-11-21 19:51:10 --> Loader Class Initialized
INFO - 2016-11-21 19:51:10 --> Helper loaded: url_helper
INFO - 2016-11-21 19:51:10 --> Helper loaded: form_helper
INFO - 2016-11-21 19:51:10 --> Database Driver Class Initialized
INFO - 2016-11-21 19:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:51:11 --> Controller Class Initialized
INFO - 2016-11-21 19:51:11 --> Model Class Initialized
INFO - 2016-11-21 19:51:11 --> Model Class Initialized
INFO - 2016-11-21 19:51:11 --> Model Class Initialized
INFO - 2016-11-21 19:51:11 --> Model Class Initialized
INFO - 2016-11-21 19:51:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:51:11 --> Pagination Class Initialized
INFO - 2016-11-21 19:51:11 --> Helper loaded: app_helper
INFO - 2016-11-21 19:51:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 19:51:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-21 19:51:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 19:51:11 --> Final output sent to browser
DEBUG - 2016-11-21 19:51:11 --> Total execution time: 0.7080
INFO - 2016-11-21 19:51:19 --> Config Class Initialized
INFO - 2016-11-21 19:51:19 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:51:19 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:51:19 --> Utf8 Class Initialized
INFO - 2016-11-21 19:51:19 --> URI Class Initialized
INFO - 2016-11-21 19:51:19 --> Router Class Initialized
INFO - 2016-11-21 19:51:19 --> Output Class Initialized
INFO - 2016-11-21 19:51:19 --> Security Class Initialized
DEBUG - 2016-11-21 19:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:51:19 --> Input Class Initialized
INFO - 2016-11-21 19:51:19 --> Language Class Initialized
INFO - 2016-11-21 19:51:19 --> Loader Class Initialized
INFO - 2016-11-21 19:51:19 --> Helper loaded: url_helper
INFO - 2016-11-21 19:51:19 --> Helper loaded: form_helper
INFO - 2016-11-21 19:51:19 --> Database Driver Class Initialized
INFO - 2016-11-21 19:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:51:19 --> Controller Class Initialized
INFO - 2016-11-21 19:51:19 --> Model Class Initialized
INFO - 2016-11-21 19:51:19 --> Model Class Initialized
INFO - 2016-11-21 19:51:19 --> Model Class Initialized
INFO - 2016-11-21 19:51:19 --> Model Class Initialized
INFO - 2016-11-21 19:51:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:51:19 --> Pagination Class Initialized
INFO - 2016-11-21 19:51:19 --> Helper loaded: app_helper
DEBUG - 2016-11-21 19:51:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-21 19:51:19 --> Model Class Initialized
INFO - 2016-11-21 19:51:19 --> Final output sent to browser
DEBUG - 2016-11-21 19:51:19 --> Total execution time: 0.5401
INFO - 2016-11-21 19:51:19 --> Config Class Initialized
INFO - 2016-11-21 19:51:19 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:51:19 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:51:19 --> Utf8 Class Initialized
INFO - 2016-11-21 19:51:19 --> URI Class Initialized
DEBUG - 2016-11-21 19:51:20 --> No URI present. Default controller set.
INFO - 2016-11-21 19:51:20 --> Router Class Initialized
INFO - 2016-11-21 19:51:20 --> Output Class Initialized
INFO - 2016-11-21 19:51:20 --> Security Class Initialized
DEBUG - 2016-11-21 19:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:51:20 --> Input Class Initialized
INFO - 2016-11-21 19:51:20 --> Language Class Initialized
INFO - 2016-11-21 19:51:20 --> Loader Class Initialized
INFO - 2016-11-21 19:51:20 --> Helper loaded: url_helper
INFO - 2016-11-21 19:51:20 --> Helper loaded: form_helper
INFO - 2016-11-21 19:51:20 --> Database Driver Class Initialized
INFO - 2016-11-21 19:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:51:20 --> Controller Class Initialized
INFO - 2016-11-21 19:51:20 --> Model Class Initialized
INFO - 2016-11-21 19:51:20 --> Model Class Initialized
INFO - 2016-11-21 19:51:20 --> Model Class Initialized
INFO - 2016-11-21 19:51:20 --> Model Class Initialized
INFO - 2016-11-21 19:51:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:51:20 --> Pagination Class Initialized
INFO - 2016-11-21 19:51:20 --> Helper loaded: app_helper
INFO - 2016-11-21 19:51:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 19:51:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 19:51:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 19:51:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 19:51:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:51:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 19:51:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 19:51:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 19:51:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 19:51:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 19:51:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 19:51:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 19:51:20 --> Final output sent to browser
DEBUG - 2016-11-21 19:51:20 --> Total execution time: 0.8413
INFO - 2016-11-21 19:51:41 --> Config Class Initialized
INFO - 2016-11-21 19:51:41 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:51:41 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:51:41 --> Utf8 Class Initialized
INFO - 2016-11-21 19:51:41 --> URI Class Initialized
DEBUG - 2016-11-21 19:51:41 --> No URI present. Default controller set.
INFO - 2016-11-21 19:51:41 --> Router Class Initialized
INFO - 2016-11-21 19:51:41 --> Output Class Initialized
INFO - 2016-11-21 19:51:41 --> Security Class Initialized
DEBUG - 2016-11-21 19:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:51:41 --> Input Class Initialized
INFO - 2016-11-21 19:51:41 --> Language Class Initialized
INFO - 2016-11-21 19:51:42 --> Loader Class Initialized
INFO - 2016-11-21 19:51:42 --> Helper loaded: url_helper
INFO - 2016-11-21 19:51:42 --> Helper loaded: form_helper
INFO - 2016-11-21 19:51:42 --> Database Driver Class Initialized
INFO - 2016-11-21 19:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:51:42 --> Controller Class Initialized
INFO - 2016-11-21 19:51:42 --> Model Class Initialized
INFO - 2016-11-21 19:51:42 --> Model Class Initialized
INFO - 2016-11-21 19:51:42 --> Model Class Initialized
INFO - 2016-11-21 19:51:42 --> Model Class Initialized
INFO - 2016-11-21 19:51:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:51:42 --> Pagination Class Initialized
INFO - 2016-11-21 19:51:42 --> Helper loaded: app_helper
INFO - 2016-11-21 19:52:20 --> Config Class Initialized
INFO - 2016-11-21 19:52:20 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:52:20 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:52:20 --> Utf8 Class Initialized
INFO - 2016-11-21 19:52:20 --> URI Class Initialized
DEBUG - 2016-11-21 19:52:20 --> No URI present. Default controller set.
INFO - 2016-11-21 19:52:20 --> Router Class Initialized
INFO - 2016-11-21 19:52:21 --> Output Class Initialized
INFO - 2016-11-21 19:52:21 --> Security Class Initialized
DEBUG - 2016-11-21 19:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:52:21 --> Input Class Initialized
INFO - 2016-11-21 19:52:21 --> Language Class Initialized
INFO - 2016-11-21 19:52:21 --> Loader Class Initialized
INFO - 2016-11-21 19:52:21 --> Helper loaded: url_helper
INFO - 2016-11-21 19:52:21 --> Helper loaded: form_helper
INFO - 2016-11-21 19:52:21 --> Database Driver Class Initialized
INFO - 2016-11-21 19:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:52:21 --> Controller Class Initialized
INFO - 2016-11-21 19:52:21 --> Model Class Initialized
INFO - 2016-11-21 19:52:21 --> Model Class Initialized
INFO - 2016-11-21 19:52:21 --> Model Class Initialized
INFO - 2016-11-21 19:52:21 --> Model Class Initialized
INFO - 2016-11-21 19:52:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:52:21 --> Pagination Class Initialized
INFO - 2016-11-21 19:52:21 --> Helper loaded: app_helper
INFO - 2016-11-21 19:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 19:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 19:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 19:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 19:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 19:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 19:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 19:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 19:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 19:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 19:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 19:52:21 --> Final output sent to browser
DEBUG - 2016-11-21 19:52:21 --> Total execution time: 0.9545
INFO - 2016-11-21 19:53:03 --> Config Class Initialized
INFO - 2016-11-21 19:53:03 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:53:03 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:53:03 --> Utf8 Class Initialized
INFO - 2016-11-21 19:53:03 --> URI Class Initialized
DEBUG - 2016-11-21 19:53:03 --> No URI present. Default controller set.
INFO - 2016-11-21 19:53:03 --> Router Class Initialized
INFO - 2016-11-21 19:53:03 --> Output Class Initialized
INFO - 2016-11-21 19:53:03 --> Security Class Initialized
DEBUG - 2016-11-21 19:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:53:03 --> Input Class Initialized
INFO - 2016-11-21 19:53:03 --> Language Class Initialized
INFO - 2016-11-21 19:53:03 --> Loader Class Initialized
INFO - 2016-11-21 19:53:03 --> Helper loaded: url_helper
INFO - 2016-11-21 19:53:03 --> Helper loaded: form_helper
INFO - 2016-11-21 19:53:03 --> Database Driver Class Initialized
INFO - 2016-11-21 19:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:53:03 --> Controller Class Initialized
INFO - 2016-11-21 19:53:03 --> Model Class Initialized
INFO - 2016-11-21 19:53:03 --> Model Class Initialized
INFO - 2016-11-21 19:53:03 --> Model Class Initialized
INFO - 2016-11-21 19:53:03 --> Model Class Initialized
INFO - 2016-11-21 19:53:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:53:03 --> Pagination Class Initialized
INFO - 2016-11-21 19:53:03 --> Helper loaded: app_helper
INFO - 2016-11-21 19:54:03 --> Config Class Initialized
INFO - 2016-11-21 19:54:03 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:54:03 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:54:03 --> Utf8 Class Initialized
INFO - 2016-11-21 19:54:03 --> URI Class Initialized
DEBUG - 2016-11-21 19:54:03 --> No URI present. Default controller set.
INFO - 2016-11-21 19:54:03 --> Router Class Initialized
INFO - 2016-11-21 19:54:03 --> Output Class Initialized
INFO - 2016-11-21 19:54:03 --> Security Class Initialized
DEBUG - 2016-11-21 19:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:54:03 --> Input Class Initialized
INFO - 2016-11-21 19:54:03 --> Language Class Initialized
INFO - 2016-11-21 19:54:03 --> Loader Class Initialized
INFO - 2016-11-21 19:54:03 --> Helper loaded: url_helper
INFO - 2016-11-21 19:54:03 --> Helper loaded: form_helper
INFO - 2016-11-21 19:54:03 --> Database Driver Class Initialized
INFO - 2016-11-21 19:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:54:03 --> Controller Class Initialized
INFO - 2016-11-21 19:54:03 --> Model Class Initialized
INFO - 2016-11-21 19:54:03 --> Model Class Initialized
INFO - 2016-11-21 19:54:03 --> Model Class Initialized
INFO - 2016-11-21 19:54:03 --> Model Class Initialized
INFO - 2016-11-21 19:54:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:54:03 --> Pagination Class Initialized
INFO - 2016-11-21 19:54:03 --> Helper loaded: app_helper
INFO - 2016-11-21 19:54:13 --> Config Class Initialized
INFO - 2016-11-21 19:54:13 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:54:13 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:54:13 --> Utf8 Class Initialized
INFO - 2016-11-21 19:54:13 --> URI Class Initialized
DEBUG - 2016-11-21 19:54:13 --> No URI present. Default controller set.
INFO - 2016-11-21 19:54:13 --> Router Class Initialized
INFO - 2016-11-21 19:54:13 --> Output Class Initialized
INFO - 2016-11-21 19:54:13 --> Security Class Initialized
DEBUG - 2016-11-21 19:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:54:13 --> Input Class Initialized
INFO - 2016-11-21 19:54:13 --> Language Class Initialized
INFO - 2016-11-21 19:54:13 --> Loader Class Initialized
INFO - 2016-11-21 19:54:13 --> Helper loaded: url_helper
INFO - 2016-11-21 19:54:13 --> Helper loaded: form_helper
INFO - 2016-11-21 19:54:13 --> Database Driver Class Initialized
INFO - 2016-11-21 19:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:54:13 --> Controller Class Initialized
INFO - 2016-11-21 19:54:13 --> Model Class Initialized
INFO - 2016-11-21 19:54:13 --> Model Class Initialized
INFO - 2016-11-21 19:54:13 --> Model Class Initialized
INFO - 2016-11-21 19:54:13 --> Model Class Initialized
INFO - 2016-11-21 19:54:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:54:13 --> Pagination Class Initialized
INFO - 2016-11-21 19:54:13 --> Helper loaded: app_helper
INFO - 2016-11-21 19:56:24 --> Config Class Initialized
INFO - 2016-11-21 19:56:24 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:56:24 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:56:24 --> Utf8 Class Initialized
INFO - 2016-11-21 19:56:24 --> URI Class Initialized
DEBUG - 2016-11-21 19:56:24 --> No URI present. Default controller set.
INFO - 2016-11-21 19:56:24 --> Router Class Initialized
INFO - 2016-11-21 19:56:24 --> Output Class Initialized
INFO - 2016-11-21 19:56:24 --> Security Class Initialized
DEBUG - 2016-11-21 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:56:24 --> Input Class Initialized
INFO - 2016-11-21 19:56:24 --> Language Class Initialized
INFO - 2016-11-21 19:56:24 --> Loader Class Initialized
INFO - 2016-11-21 19:56:24 --> Helper loaded: url_helper
INFO - 2016-11-21 19:56:24 --> Helper loaded: form_helper
INFO - 2016-11-21 19:56:24 --> Database Driver Class Initialized
INFO - 2016-11-21 19:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:56:24 --> Controller Class Initialized
INFO - 2016-11-21 19:56:24 --> Model Class Initialized
INFO - 2016-11-21 19:56:24 --> Model Class Initialized
INFO - 2016-11-21 19:56:24 --> Model Class Initialized
INFO - 2016-11-21 19:56:24 --> Model Class Initialized
INFO - 2016-11-21 19:56:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:56:24 --> Pagination Class Initialized
INFO - 2016-11-21 19:56:24 --> Helper loaded: app_helper
INFO - 2016-11-21 19:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 19:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 19:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 19:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 19:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 19:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 19:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 19:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 19:56:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 19:56:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 19:56:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 19:56:25 --> Final output sent to browser
DEBUG - 2016-11-21 19:56:25 --> Total execution time: 0.9149
INFO - 2016-11-21 19:56:36 --> Config Class Initialized
INFO - 2016-11-21 19:56:36 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:56:36 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:56:36 --> Utf8 Class Initialized
INFO - 2016-11-21 19:56:36 --> URI Class Initialized
INFO - 2016-11-21 19:56:37 --> Router Class Initialized
INFO - 2016-11-21 19:56:37 --> Output Class Initialized
INFO - 2016-11-21 19:56:37 --> Security Class Initialized
DEBUG - 2016-11-21 19:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:56:37 --> Input Class Initialized
INFO - 2016-11-21 19:56:37 --> Language Class Initialized
INFO - 2016-11-21 19:56:37 --> Loader Class Initialized
INFO - 2016-11-21 19:56:37 --> Helper loaded: url_helper
INFO - 2016-11-21 19:56:37 --> Helper loaded: form_helper
INFO - 2016-11-21 19:56:37 --> Database Driver Class Initialized
INFO - 2016-11-21 19:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:56:37 --> Controller Class Initialized
INFO - 2016-11-21 19:56:37 --> Model Class Initialized
INFO - 2016-11-21 19:56:37 --> Form Validation Class Initialized
INFO - 2016-11-21 19:56:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:56:37 --> Pagination Class Initialized
INFO - 2016-11-21 19:56:37 --> Helper loaded: app_helper
INFO - 2016-11-21 19:56:37 --> Email Class Initialized
ERROR - 2016-11-21 19:56:37 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:56:37 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:56:37 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-21 19:56:37 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-11-21 19:56:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 19:56:37 --> Final output sent to browser
DEBUG - 2016-11-21 19:56:37 --> Total execution time: 0.8901
INFO - 2016-11-21 19:56:37 --> Config Class Initialized
INFO - 2016-11-21 19:56:37 --> Hooks Class Initialized
DEBUG - 2016-11-21 19:56:37 --> UTF-8 Support Enabled
INFO - 2016-11-21 19:56:37 --> Utf8 Class Initialized
INFO - 2016-11-21 19:56:37 --> URI Class Initialized
DEBUG - 2016-11-21 19:56:37 --> No URI present. Default controller set.
INFO - 2016-11-21 19:56:37 --> Router Class Initialized
INFO - 2016-11-21 19:56:38 --> Output Class Initialized
INFO - 2016-11-21 19:56:38 --> Security Class Initialized
DEBUG - 2016-11-21 19:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 19:56:38 --> Input Class Initialized
INFO - 2016-11-21 19:56:38 --> Language Class Initialized
INFO - 2016-11-21 19:56:38 --> Loader Class Initialized
INFO - 2016-11-21 19:56:38 --> Helper loaded: url_helper
INFO - 2016-11-21 19:56:38 --> Helper loaded: form_helper
INFO - 2016-11-21 19:56:38 --> Database Driver Class Initialized
INFO - 2016-11-21 19:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 19:56:38 --> Controller Class Initialized
INFO - 2016-11-21 19:56:38 --> Model Class Initialized
INFO - 2016-11-21 19:56:38 --> Model Class Initialized
INFO - 2016-11-21 19:56:38 --> Model Class Initialized
INFO - 2016-11-21 19:56:38 --> Model Class Initialized
INFO - 2016-11-21 19:56:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 19:56:38 --> Pagination Class Initialized
INFO - 2016-11-21 19:56:38 --> Helper loaded: app_helper
INFO - 2016-11-21 19:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 19:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 19:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 19:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 19:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 19:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 19:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 19:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 19:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 19:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 19:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 19:56:38 --> Final output sent to browser
DEBUG - 2016-11-21 19:56:38 --> Total execution time: 0.8777
INFO - 2016-11-21 20:06:15 --> Config Class Initialized
INFO - 2016-11-21 20:06:15 --> Hooks Class Initialized
DEBUG - 2016-11-21 20:06:15 --> UTF-8 Support Enabled
INFO - 2016-11-21 20:06:15 --> Utf8 Class Initialized
INFO - 2016-11-21 20:06:15 --> URI Class Initialized
INFO - 2016-11-21 20:06:15 --> Router Class Initialized
INFO - 2016-11-21 20:06:15 --> Output Class Initialized
INFO - 2016-11-21 20:06:15 --> Security Class Initialized
DEBUG - 2016-11-21 20:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 20:06:15 --> Input Class Initialized
INFO - 2016-11-21 20:06:15 --> Language Class Initialized
ERROR - 2016-11-21 20:06:16 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 180
INFO - 2016-11-21 20:06:37 --> Config Class Initialized
INFO - 2016-11-21 20:06:37 --> Hooks Class Initialized
DEBUG - 2016-11-21 20:06:37 --> UTF-8 Support Enabled
INFO - 2016-11-21 20:06:37 --> Utf8 Class Initialized
INFO - 2016-11-21 20:06:37 --> URI Class Initialized
DEBUG - 2016-11-21 20:06:37 --> No URI present. Default controller set.
INFO - 2016-11-21 20:06:37 --> Router Class Initialized
INFO - 2016-11-21 20:06:37 --> Output Class Initialized
INFO - 2016-11-21 20:06:37 --> Security Class Initialized
DEBUG - 2016-11-21 20:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 20:06:37 --> Input Class Initialized
INFO - 2016-11-21 20:06:37 --> Language Class Initialized
INFO - 2016-11-21 20:06:37 --> Loader Class Initialized
INFO - 2016-11-21 20:06:37 --> Helper loaded: url_helper
INFO - 2016-11-21 20:06:37 --> Helper loaded: form_helper
INFO - 2016-11-21 20:06:37 --> Database Driver Class Initialized
INFO - 2016-11-21 20:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 20:06:37 --> Controller Class Initialized
INFO - 2016-11-21 20:06:37 --> Model Class Initialized
INFO - 2016-11-21 20:06:38 --> Model Class Initialized
INFO - 2016-11-21 20:06:38 --> Model Class Initialized
INFO - 2016-11-21 20:06:38 --> Model Class Initialized
INFO - 2016-11-21 20:06:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 20:06:38 --> Pagination Class Initialized
INFO - 2016-11-21 20:06:38 --> Helper loaded: app_helper
INFO - 2016-11-21 20:06:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 20:06:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 20:06:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 20:06:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 20:06:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 20:06:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 20:06:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 20:06:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 20:06:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 20:06:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 20:06:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 20:06:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 20:06:38 --> Final output sent to browser
DEBUG - 2016-11-21 20:06:38 --> Total execution time: 0.9598
INFO - 2016-11-21 20:06:56 --> Config Class Initialized
INFO - 2016-11-21 20:06:56 --> Hooks Class Initialized
DEBUG - 2016-11-21 20:06:56 --> UTF-8 Support Enabled
INFO - 2016-11-21 20:06:56 --> Utf8 Class Initialized
INFO - 2016-11-21 20:06:56 --> URI Class Initialized
INFO - 2016-11-21 20:06:56 --> Router Class Initialized
INFO - 2016-11-21 20:06:56 --> Output Class Initialized
INFO - 2016-11-21 20:06:56 --> Security Class Initialized
DEBUG - 2016-11-21 20:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 20:06:56 --> Input Class Initialized
INFO - 2016-11-21 20:06:56 --> Language Class Initialized
ERROR - 2016-11-21 20:06:56 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 180
INFO - 2016-11-21 20:09:57 --> Config Class Initialized
INFO - 2016-11-21 20:09:57 --> Hooks Class Initialized
DEBUG - 2016-11-21 20:09:57 --> UTF-8 Support Enabled
INFO - 2016-11-21 20:09:57 --> Utf8 Class Initialized
INFO - 2016-11-21 20:09:57 --> URI Class Initialized
DEBUG - 2016-11-21 20:09:57 --> No URI present. Default controller set.
INFO - 2016-11-21 20:09:57 --> Router Class Initialized
INFO - 2016-11-21 20:09:57 --> Output Class Initialized
INFO - 2016-11-21 20:09:57 --> Security Class Initialized
DEBUG - 2016-11-21 20:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 20:09:57 --> Input Class Initialized
INFO - 2016-11-21 20:09:57 --> Language Class Initialized
INFO - 2016-11-21 20:09:57 --> Loader Class Initialized
INFO - 2016-11-21 20:09:57 --> Helper loaded: url_helper
INFO - 2016-11-21 20:09:57 --> Helper loaded: form_helper
INFO - 2016-11-21 20:09:57 --> Database Driver Class Initialized
INFO - 2016-11-21 20:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 20:09:57 --> Controller Class Initialized
INFO - 2016-11-21 20:09:57 --> Model Class Initialized
INFO - 2016-11-21 20:09:58 --> Model Class Initialized
INFO - 2016-11-21 20:09:58 --> Model Class Initialized
INFO - 2016-11-21 20:09:58 --> Model Class Initialized
INFO - 2016-11-21 20:09:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 20:09:58 --> Pagination Class Initialized
INFO - 2016-11-21 20:09:58 --> Helper loaded: app_helper
INFO - 2016-11-21 20:09:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 20:09:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 20:09:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 20:09:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 20:09:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 20:09:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 20:09:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 20:09:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 20:09:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 20:09:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 20:09:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 20:09:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 20:09:58 --> Final output sent to browser
DEBUG - 2016-11-21 20:09:58 --> Total execution time: 0.9920
INFO - 2016-11-21 20:10:16 --> Config Class Initialized
INFO - 2016-11-21 20:10:16 --> Hooks Class Initialized
DEBUG - 2016-11-21 20:10:16 --> UTF-8 Support Enabled
INFO - 2016-11-21 20:10:16 --> Utf8 Class Initialized
INFO - 2016-11-21 20:10:16 --> URI Class Initialized
INFO - 2016-11-21 20:10:16 --> Router Class Initialized
INFO - 2016-11-21 20:10:16 --> Output Class Initialized
INFO - 2016-11-21 20:10:16 --> Security Class Initialized
DEBUG - 2016-11-21 20:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 20:10:16 --> Input Class Initialized
INFO - 2016-11-21 20:10:16 --> Language Class Initialized
ERROR - 2016-11-21 20:10:16 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 180
INFO - 2016-11-21 20:10:23 --> Config Class Initialized
INFO - 2016-11-21 20:10:23 --> Hooks Class Initialized
DEBUG - 2016-11-21 20:10:23 --> UTF-8 Support Enabled
INFO - 2016-11-21 20:10:23 --> Utf8 Class Initialized
INFO - 2016-11-21 20:10:23 --> URI Class Initialized
INFO - 2016-11-21 20:10:24 --> Router Class Initialized
INFO - 2016-11-21 20:10:24 --> Output Class Initialized
INFO - 2016-11-21 20:10:24 --> Security Class Initialized
DEBUG - 2016-11-21 20:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 20:10:24 --> Input Class Initialized
INFO - 2016-11-21 20:10:24 --> Language Class Initialized
ERROR - 2016-11-21 20:10:24 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 180
INFO - 2016-11-21 20:12:10 --> Config Class Initialized
INFO - 2016-11-21 20:12:10 --> Hooks Class Initialized
DEBUG - 2016-11-21 20:12:10 --> UTF-8 Support Enabled
INFO - 2016-11-21 20:12:10 --> Utf8 Class Initialized
INFO - 2016-11-21 20:12:10 --> URI Class Initialized
INFO - 2016-11-21 20:12:10 --> Router Class Initialized
INFO - 2016-11-21 20:12:10 --> Output Class Initialized
INFO - 2016-11-21 20:12:11 --> Security Class Initialized
DEBUG - 2016-11-21 20:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 20:12:11 --> Input Class Initialized
INFO - 2016-11-21 20:12:11 --> Language Class Initialized
ERROR - 2016-11-21 20:12:11 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 180
INFO - 2016-11-21 20:13:05 --> Config Class Initialized
INFO - 2016-11-21 20:13:05 --> Hooks Class Initialized
DEBUG - 2016-11-21 20:13:05 --> UTF-8 Support Enabled
INFO - 2016-11-21 20:13:05 --> Utf8 Class Initialized
INFO - 2016-11-21 20:13:05 --> URI Class Initialized
INFO - 2016-11-21 20:13:05 --> Router Class Initialized
INFO - 2016-11-21 20:13:05 --> Output Class Initialized
INFO - 2016-11-21 20:13:05 --> Security Class Initialized
DEBUG - 2016-11-21 20:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 20:13:05 --> Input Class Initialized
INFO - 2016-11-21 20:13:05 --> Language Class Initialized
INFO - 2016-11-21 20:13:05 --> Loader Class Initialized
INFO - 2016-11-21 20:13:05 --> Helper loaded: url_helper
INFO - 2016-11-21 20:13:05 --> Helper loaded: form_helper
INFO - 2016-11-21 20:13:05 --> Database Driver Class Initialized
INFO - 2016-11-21 20:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 20:13:05 --> Controller Class Initialized
INFO - 2016-11-21 20:13:05 --> Model Class Initialized
INFO - 2016-11-21 20:13:05 --> Form Validation Class Initialized
INFO - 2016-11-21 20:13:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 20:13:05 --> Pagination Class Initialized
INFO - 2016-11-21 20:13:05 --> Helper loaded: app_helper
INFO - 2016-11-21 20:13:05 --> Email Class Initialized
INFO - 2016-11-21 20:13:05 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 20:13:05 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 20:13:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 20:13:05 --> Final output sent to browser
DEBUG - 2016-11-21 20:13:05 --> Total execution time: 0.7475
INFO - 2016-11-21 20:13:47 --> Config Class Initialized
INFO - 2016-11-21 20:13:47 --> Hooks Class Initialized
DEBUG - 2016-11-21 20:13:47 --> UTF-8 Support Enabled
INFO - 2016-11-21 20:13:47 --> Utf8 Class Initialized
INFO - 2016-11-21 20:13:47 --> URI Class Initialized
INFO - 2016-11-21 20:13:47 --> Router Class Initialized
INFO - 2016-11-21 20:13:47 --> Output Class Initialized
INFO - 2016-11-21 20:13:47 --> Security Class Initialized
DEBUG - 2016-11-21 20:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 20:13:47 --> Input Class Initialized
INFO - 2016-11-21 20:13:47 --> Language Class Initialized
INFO - 2016-11-21 20:13:47 --> Loader Class Initialized
INFO - 2016-11-21 20:13:47 --> Helper loaded: url_helper
INFO - 2016-11-21 20:13:47 --> Helper loaded: form_helper
INFO - 2016-11-21 20:13:47 --> Database Driver Class Initialized
INFO - 2016-11-21 20:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 20:13:47 --> Controller Class Initialized
INFO - 2016-11-21 20:13:47 --> Model Class Initialized
INFO - 2016-11-21 20:13:47 --> Form Validation Class Initialized
INFO - 2016-11-21 20:13:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 20:13:47 --> Pagination Class Initialized
INFO - 2016-11-21 20:13:47 --> Helper loaded: app_helper
INFO - 2016-11-21 20:13:47 --> Email Class Initialized
INFO - 2016-11-21 20:13:47 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 20:13:48 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 20:13:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 20:13:48 --> Final output sent to browser
DEBUG - 2016-11-21 20:13:48 --> Total execution time: 0.8085
INFO - 2016-11-21 20:14:53 --> Config Class Initialized
INFO - 2016-11-21 20:14:53 --> Hooks Class Initialized
DEBUG - 2016-11-21 20:14:53 --> UTF-8 Support Enabled
INFO - 2016-11-21 20:14:53 --> Utf8 Class Initialized
INFO - 2016-11-21 20:14:53 --> URI Class Initialized
INFO - 2016-11-21 20:14:53 --> Router Class Initialized
INFO - 2016-11-21 20:14:53 --> Output Class Initialized
INFO - 2016-11-21 20:14:53 --> Security Class Initialized
DEBUG - 2016-11-21 20:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 20:14:53 --> Input Class Initialized
INFO - 2016-11-21 20:14:53 --> Language Class Initialized
INFO - 2016-11-21 20:14:53 --> Loader Class Initialized
INFO - 2016-11-21 20:14:53 --> Helper loaded: url_helper
INFO - 2016-11-21 20:14:53 --> Helper loaded: form_helper
INFO - 2016-11-21 20:14:53 --> Database Driver Class Initialized
INFO - 2016-11-21 20:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 20:14:53 --> Controller Class Initialized
INFO - 2016-11-21 20:14:53 --> Model Class Initialized
INFO - 2016-11-21 20:14:53 --> Form Validation Class Initialized
INFO - 2016-11-21 20:14:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 20:14:53 --> Pagination Class Initialized
INFO - 2016-11-21 20:14:53 --> Helper loaded: app_helper
INFO - 2016-11-21 20:14:53 --> Email Class Initialized
INFO - 2016-11-21 20:14:53 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 19:14:54 --> Severity: Notice --> Undefined variable: leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 170
ERROR - 2016-11-21 19:14:54 --> Severity: Notice --> Undefined variable: application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 171
ERROR - 2016-11-21 19:14:54 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 172
ERROR - 2016-11-21 19:14:54 --> Severity: Notice --> Undefined variable: hi C:\xampp\htdocs\LMS\app\views\email_template.php 23
ERROR - 2016-11-21 19:14:54 --> Severity: Notice --> Undefined variable: userName C:\xampp\htdocs\LMS\app\views\email_template.php 23
ERROR - 2016-11-21 19:14:54 --> Severity: Notice --> Undefined variable: msg1 C:\xampp\htdocs\LMS\app\views\email_template.php 24
INFO - 2016-11-21 19:14:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 19:14:54 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 19:14:54 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 179
ERROR - 2016-11-21 19:14:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\sys\libraries\Email.php 452
ERROR - 2016-11-21 19:15:03 --> Severity: Warning --> fsockopen(): SSL: Handshake timed out C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-21 19:15:03 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-21 19:15:03 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.critsend.com:465 (Unknown error) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-11-21 19:15:03 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 19:15:03 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 19:15:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:15:04 --> Final output sent to browser
DEBUG - 2016-11-21 19:15:04 --> Total execution time: 10.6375
INFO - 2016-11-21 20:16:28 --> Config Class Initialized
INFO - 2016-11-21 20:16:28 --> Hooks Class Initialized
DEBUG - 2016-11-21 20:16:28 --> UTF-8 Support Enabled
INFO - 2016-11-21 20:16:28 --> Utf8 Class Initialized
INFO - 2016-11-21 20:16:28 --> URI Class Initialized
INFO - 2016-11-21 20:16:28 --> Router Class Initialized
INFO - 2016-11-21 20:16:28 --> Output Class Initialized
INFO - 2016-11-21 20:16:28 --> Security Class Initialized
DEBUG - 2016-11-21 20:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 20:16:28 --> Input Class Initialized
INFO - 2016-11-21 20:16:28 --> Language Class Initialized
INFO - 2016-11-21 20:16:28 --> Loader Class Initialized
INFO - 2016-11-21 20:16:28 --> Helper loaded: url_helper
INFO - 2016-11-21 20:16:28 --> Helper loaded: form_helper
INFO - 2016-11-21 20:16:28 --> Database Driver Class Initialized
INFO - 2016-11-21 20:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 20:16:28 --> Controller Class Initialized
INFO - 2016-11-21 20:16:28 --> Model Class Initialized
INFO - 2016-11-21 20:16:28 --> Form Validation Class Initialized
INFO - 2016-11-21 20:16:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 20:16:28 --> Pagination Class Initialized
INFO - 2016-11-21 20:16:28 --> Helper loaded: app_helper
INFO - 2016-11-21 20:16:28 --> Email Class Initialized
INFO - 2016-11-21 20:16:28 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 19:16:29 --> Severity: Notice --> Undefined variable: application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 170
ERROR - 2016-11-21 19:16:29 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 171
ERROR - 2016-11-21 19:16:29 --> Severity: Notice --> Undefined variable: hi C:\xampp\htdocs\LMS\app\views\email_template.php 23
ERROR - 2016-11-21 19:16:29 --> Severity: Notice --> Undefined variable: userName C:\xampp\htdocs\LMS\app\views\email_template.php 23
ERROR - 2016-11-21 19:16:29 --> Severity: Notice --> Undefined variable: msg1 C:\xampp\htdocs\LMS\app\views\email_template.php 24
INFO - 2016-11-21 19:16:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 19:16:29 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 19:16:29 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 178
ERROR - 2016-11-21 19:16:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\sys\libraries\Email.php 452
INFO - 2016-11-21 19:16:29 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 19:16:30 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 19:16:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:16:30 --> Final output sent to browser
DEBUG - 2016-11-21 19:16:30 --> Total execution time: 2.1544
INFO - 2016-11-21 20:20:51 --> Config Class Initialized
INFO - 2016-11-21 20:20:51 --> Hooks Class Initialized
DEBUG - 2016-11-21 20:20:51 --> UTF-8 Support Enabled
INFO - 2016-11-21 20:20:51 --> Utf8 Class Initialized
INFO - 2016-11-21 20:20:51 --> URI Class Initialized
INFO - 2016-11-21 20:20:51 --> Router Class Initialized
INFO - 2016-11-21 20:20:51 --> Output Class Initialized
INFO - 2016-11-21 20:20:51 --> Security Class Initialized
DEBUG - 2016-11-21 20:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 20:20:51 --> Input Class Initialized
INFO - 2016-11-21 20:20:51 --> Language Class Initialized
INFO - 2016-11-21 20:20:51 --> Loader Class Initialized
INFO - 2016-11-21 20:20:51 --> Helper loaded: url_helper
INFO - 2016-11-21 20:20:51 --> Helper loaded: form_helper
INFO - 2016-11-21 20:20:51 --> Database Driver Class Initialized
INFO - 2016-11-21 20:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 20:20:51 --> Controller Class Initialized
INFO - 2016-11-21 20:20:51 --> Model Class Initialized
INFO - 2016-11-21 20:20:51 --> Form Validation Class Initialized
INFO - 2016-11-21 20:20:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 20:20:51 --> Pagination Class Initialized
INFO - 2016-11-21 20:20:51 --> Helper loaded: app_helper
INFO - 2016-11-21 20:20:51 --> Email Class Initialized
INFO - 2016-11-21 20:20:51 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 19:20:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 167
ERROR - 2016-11-21 19:20:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 168
ERROR - 2016-11-21 19:20:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 169
ERROR - 2016-11-21 19:20:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 170
ERROR - 2016-11-21 19:20:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 171
ERROR - 2016-11-21 19:20:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 172
ERROR - 2016-11-21 19:20:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 173
ERROR - 2016-11-21 19:20:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 176
ERROR - 2016-11-21 19:20:52 --> Severity: Notice --> Undefined variable: hi C:\xampp\htdocs\LMS\app\views\email_template.php 23
ERROR - 2016-11-21 19:20:52 --> Severity: Notice --> Undefined variable: userName C:\xampp\htdocs\LMS\app\views\email_template.php 23
ERROR - 2016-11-21 19:20:52 --> Severity: Notice --> Undefined variable: msg1 C:\xampp\htdocs\LMS\app\views\email_template.php 24
INFO - 2016-11-21 19:20:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 19:20:52 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 19:20:52 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 179
ERROR - 2016-11-21 19:20:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\sys\libraries\Email.php 452
INFO - 2016-11-21 19:20:59 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 19:21:00 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 19:21:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:21:00 --> Final output sent to browser
DEBUG - 2016-11-21 19:21:00 --> Total execution time: 9.4084
INFO - 2016-11-21 20:21:53 --> Config Class Initialized
INFO - 2016-11-21 20:21:53 --> Hooks Class Initialized
DEBUG - 2016-11-21 20:21:53 --> UTF-8 Support Enabled
INFO - 2016-11-21 20:21:53 --> Utf8 Class Initialized
INFO - 2016-11-21 20:21:53 --> URI Class Initialized
INFO - 2016-11-21 20:21:53 --> Router Class Initialized
INFO - 2016-11-21 20:21:53 --> Output Class Initialized
INFO - 2016-11-21 20:21:54 --> Security Class Initialized
DEBUG - 2016-11-21 20:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 20:21:54 --> Input Class Initialized
INFO - 2016-11-21 20:21:54 --> Language Class Initialized
INFO - 2016-11-21 20:21:54 --> Loader Class Initialized
INFO - 2016-11-21 20:21:54 --> Helper loaded: url_helper
INFO - 2016-11-21 20:21:54 --> Helper loaded: form_helper
INFO - 2016-11-21 20:21:54 --> Database Driver Class Initialized
INFO - 2016-11-21 20:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 20:21:54 --> Controller Class Initialized
INFO - 2016-11-21 20:21:54 --> Model Class Initialized
INFO - 2016-11-21 20:21:54 --> Form Validation Class Initialized
INFO - 2016-11-21 20:21:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 20:21:54 --> Pagination Class Initialized
INFO - 2016-11-21 20:21:54 --> Helper loaded: app_helper
INFO - 2016-11-21 20:21:54 --> Email Class Initialized
INFO - 2016-11-21 20:21:54 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 19:21:54 --> Severity: Warning --> extract() expects parameter 1 to be array, null given C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 165
ERROR - 2016-11-21 19:21:54 --> Severity: Notice --> Undefined index: $startDate C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 167
ERROR - 2016-11-21 19:21:54 --> Severity: Notice --> Undefined index: $endDate C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 168
ERROR - 2016-11-21 19:21:54 --> Severity: Notice --> Undefined index: $numberOfDays C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 169
ERROR - 2016-11-21 19:21:54 --> Severity: Notice --> Undefined index: $leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 170
ERROR - 2016-11-21 19:21:54 --> Severity: Notice --> Undefined index: $application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 171
ERROR - 2016-11-21 19:21:54 --> Severity: Notice --> Undefined index: $userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 172
ERROR - 2016-11-21 19:21:54 --> Severity: Notice --> Undefined index: $leavePurpose C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 173
ERROR - 2016-11-21 19:21:54 --> Severity: Notice --> Undefined variable: hi C:\xampp\htdocs\LMS\app\views\email_template.php 23
ERROR - 2016-11-21 19:21:54 --> Severity: Notice --> Undefined variable: userName C:\xampp\htdocs\LMS\app\views\email_template.php 23
ERROR - 2016-11-21 19:21:54 --> Severity: Notice --> Undefined variable: msg1 C:\xampp\htdocs\LMS\app\views\email_template.php 24
INFO - 2016-11-21 19:21:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 19:21:54 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 19:21:54 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 179
ERROR - 2016-11-21 19:21:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\sys\libraries\Email.php 452
INFO - 2016-11-21 19:21:55 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 19:21:56 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 19:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:21:56 --> Final output sent to browser
DEBUG - 2016-11-21 19:21:56 --> Total execution time: 2.7333
INFO - 2016-11-21 20:22:32 --> Config Class Initialized
INFO - 2016-11-21 20:22:32 --> Hooks Class Initialized
DEBUG - 2016-11-21 20:22:32 --> UTF-8 Support Enabled
INFO - 2016-11-21 20:22:32 --> Utf8 Class Initialized
INFO - 2016-11-21 20:22:32 --> URI Class Initialized
INFO - 2016-11-21 20:22:32 --> Router Class Initialized
INFO - 2016-11-21 20:22:32 --> Output Class Initialized
INFO - 2016-11-21 20:22:32 --> Security Class Initialized
DEBUG - 2016-11-21 20:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 20:22:32 --> Input Class Initialized
INFO - 2016-11-21 20:22:32 --> Language Class Initialized
INFO - 2016-11-21 20:22:32 --> Loader Class Initialized
INFO - 2016-11-21 20:22:32 --> Helper loaded: url_helper
INFO - 2016-11-21 20:22:32 --> Helper loaded: form_helper
INFO - 2016-11-21 20:22:32 --> Database Driver Class Initialized
INFO - 2016-11-21 20:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 20:22:32 --> Controller Class Initialized
INFO - 2016-11-21 20:22:32 --> Model Class Initialized
INFO - 2016-11-21 20:22:32 --> Form Validation Class Initialized
INFO - 2016-11-21 20:22:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 20:22:32 --> Pagination Class Initialized
INFO - 2016-11-21 20:22:32 --> Helper loaded: app_helper
INFO - 2016-11-21 20:22:32 --> Email Class Initialized
INFO - 2016-11-21 20:22:32 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 19:22:33 --> Severity: Notice --> Undefined index: $startDate C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 166
ERROR - 2016-11-21 19:22:33 --> Severity: Notice --> Undefined index: $endDate C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 167
ERROR - 2016-11-21 19:22:33 --> Severity: Notice --> Undefined index: $numberOfDays C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 168
ERROR - 2016-11-21 19:22:33 --> Severity: Notice --> Undefined index: $leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 169
ERROR - 2016-11-21 19:22:33 --> Severity: Notice --> Undefined index: $application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 170
ERROR - 2016-11-21 19:22:33 --> Severity: Notice --> Undefined index: $userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 171
ERROR - 2016-11-21 19:22:33 --> Severity: Notice --> Undefined index: $leavePurpose C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 172
ERROR - 2016-11-21 19:22:33 --> Severity: Notice --> Undefined variable: hi C:\xampp\htdocs\LMS\app\views\email_template.php 23
ERROR - 2016-11-21 19:22:33 --> Severity: Notice --> Undefined variable: userName C:\xampp\htdocs\LMS\app\views\email_template.php 23
ERROR - 2016-11-21 19:22:33 --> Severity: Notice --> Undefined variable: msg1 C:\xampp\htdocs\LMS\app\views\email_template.php 24
INFO - 2016-11-21 19:22:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 19:22:33 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 19:22:33 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 178
ERROR - 2016-11-21 19:22:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\sys\libraries\Email.php 452
INFO - 2016-11-21 19:22:34 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 19:22:34 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 19:22:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:22:34 --> Final output sent to browser
DEBUG - 2016-11-21 19:22:34 --> Total execution time: 2.3503
INFO - 2016-11-21 20:23:00 --> Config Class Initialized
INFO - 2016-11-21 20:23:00 --> Hooks Class Initialized
DEBUG - 2016-11-21 20:23:00 --> UTF-8 Support Enabled
INFO - 2016-11-21 20:23:00 --> Utf8 Class Initialized
INFO - 2016-11-21 20:23:00 --> URI Class Initialized
INFO - 2016-11-21 20:23:00 --> Router Class Initialized
INFO - 2016-11-21 20:23:00 --> Output Class Initialized
INFO - 2016-11-21 20:23:00 --> Security Class Initialized
DEBUG - 2016-11-21 20:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 20:23:00 --> Input Class Initialized
INFO - 2016-11-21 20:23:00 --> Language Class Initialized
INFO - 2016-11-21 20:23:00 --> Loader Class Initialized
INFO - 2016-11-21 20:23:00 --> Helper loaded: url_helper
INFO - 2016-11-21 20:23:00 --> Helper loaded: form_helper
INFO - 2016-11-21 20:23:00 --> Database Driver Class Initialized
INFO - 2016-11-21 20:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 20:23:00 --> Controller Class Initialized
INFO - 2016-11-21 20:23:01 --> Model Class Initialized
INFO - 2016-11-21 20:23:01 --> Form Validation Class Initialized
INFO - 2016-11-21 20:23:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 20:23:01 --> Pagination Class Initialized
INFO - 2016-11-21 20:23:01 --> Helper loaded: app_helper
INFO - 2016-11-21 20:23:01 --> Email Class Initialized
INFO - 2016-11-21 20:23:01 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 19:23:01 --> Severity: Notice --> Undefined index: $startDate C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 167
ERROR - 2016-11-21 19:23:01 --> Severity: Notice --> Undefined index: $endDate C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 168
ERROR - 2016-11-21 19:23:01 --> Severity: Notice --> Undefined index: $numberOfDays C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 169
ERROR - 2016-11-21 19:23:01 --> Severity: Notice --> Undefined index: $leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 170
ERROR - 2016-11-21 19:23:01 --> Severity: Notice --> Undefined index: $application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 171
ERROR - 2016-11-21 19:23:01 --> Severity: Notice --> Undefined index: $userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 172
ERROR - 2016-11-21 19:23:01 --> Severity: Notice --> Undefined index: $leavePurpose C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 173
ERROR - 2016-11-21 19:23:01 --> Severity: Notice --> Undefined variable: hi C:\xampp\htdocs\LMS\app\views\email_template.php 23
ERROR - 2016-11-21 19:23:01 --> Severity: Notice --> Undefined variable: userName C:\xampp\htdocs\LMS\app\views\email_template.php 23
ERROR - 2016-11-21 19:23:01 --> Severity: Notice --> Undefined variable: msg1 C:\xampp\htdocs\LMS\app\views\email_template.php 24
INFO - 2016-11-21 19:23:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 19:23:01 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 19:23:01 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 179
ERROR - 2016-11-21 19:23:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\sys\libraries\Email.php 452
INFO - 2016-11-21 19:23:03 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 19:23:03 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 19:23:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:23:03 --> Final output sent to browser
DEBUG - 2016-11-21 19:23:03 --> Total execution time: 3.4236
INFO - 2016-11-21 20:23:40 --> Config Class Initialized
INFO - 2016-11-21 20:23:40 --> Hooks Class Initialized
DEBUG - 2016-11-21 20:23:40 --> UTF-8 Support Enabled
INFO - 2016-11-21 20:23:40 --> Utf8 Class Initialized
INFO - 2016-11-21 20:23:40 --> URI Class Initialized
INFO - 2016-11-21 20:23:40 --> Router Class Initialized
INFO - 2016-11-21 20:23:40 --> Output Class Initialized
INFO - 2016-11-21 20:23:41 --> Security Class Initialized
DEBUG - 2016-11-21 20:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 20:23:41 --> Input Class Initialized
INFO - 2016-11-21 20:23:41 --> Language Class Initialized
INFO - 2016-11-21 20:23:41 --> Loader Class Initialized
INFO - 2016-11-21 20:23:41 --> Helper loaded: url_helper
INFO - 2016-11-21 20:23:41 --> Helper loaded: form_helper
INFO - 2016-11-21 20:23:41 --> Database Driver Class Initialized
INFO - 2016-11-21 20:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 20:23:41 --> Controller Class Initialized
INFO - 2016-11-21 20:23:41 --> Model Class Initialized
INFO - 2016-11-21 20:23:41 --> Form Validation Class Initialized
INFO - 2016-11-21 20:23:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 20:23:41 --> Pagination Class Initialized
INFO - 2016-11-21 20:23:41 --> Helper loaded: app_helper
INFO - 2016-11-21 20:23:41 --> Email Class Initialized
INFO - 2016-11-21 20:23:41 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 19:23:41 --> Severity: Notice --> Undefined index: leaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 170
ERROR - 2016-11-21 19:23:41 --> Severity: Notice --> Undefined index: application_date C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 171
ERROR - 2016-11-21 19:23:41 --> Severity: Notice --> Undefined index: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 172
ERROR - 2016-11-21 19:23:41 --> Severity: Notice --> Undefined variable: hi C:\xampp\htdocs\LMS\app\views\email_template.php 23
ERROR - 2016-11-21 19:23:41 --> Severity: Notice --> Undefined variable: userName C:\xampp\htdocs\LMS\app\views\email_template.php 23
ERROR - 2016-11-21 19:23:41 --> Severity: Notice --> Undefined variable: msg1 C:\xampp\htdocs\LMS\app\views\email_template.php 24
INFO - 2016-11-21 19:23:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 19:23:41 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 19:23:41 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 179
ERROR - 2016-11-21 19:23:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\sys\libraries\Email.php 452
ERROR - 2016-11-21 19:23:48 --> Severity: Warning --> fsockopen(): SSL: Handshake timed out C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-21 19:23:48 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-21 19:23:48 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.critsend.com:465 (Unknown error) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-11-21 19:23:48 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 19:23:48 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 19:23:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:23:48 --> Final output sent to browser
DEBUG - 2016-11-21 19:23:48 --> Total execution time: 7.8125
INFO - 2016-11-21 20:25:32 --> Config Class Initialized
INFO - 2016-11-21 20:25:32 --> Hooks Class Initialized
DEBUG - 2016-11-21 20:25:32 --> UTF-8 Support Enabled
INFO - 2016-11-21 20:25:32 --> Utf8 Class Initialized
INFO - 2016-11-21 20:25:32 --> URI Class Initialized
INFO - 2016-11-21 20:25:32 --> Router Class Initialized
INFO - 2016-11-21 20:25:32 --> Output Class Initialized
INFO - 2016-11-21 20:25:32 --> Security Class Initialized
DEBUG - 2016-11-21 20:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 20:25:32 --> Input Class Initialized
INFO - 2016-11-21 20:25:32 --> Language Class Initialized
INFO - 2016-11-21 20:25:32 --> Loader Class Initialized
INFO - 2016-11-21 20:25:33 --> Helper loaded: url_helper
INFO - 2016-11-21 20:25:33 --> Helper loaded: form_helper
INFO - 2016-11-21 20:25:33 --> Database Driver Class Initialized
INFO - 2016-11-21 20:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 20:25:33 --> Controller Class Initialized
INFO - 2016-11-21 20:25:33 --> Model Class Initialized
INFO - 2016-11-21 20:25:33 --> Form Validation Class Initialized
INFO - 2016-11-21 20:25:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 20:25:33 --> Pagination Class Initialized
INFO - 2016-11-21 20:25:33 --> Helper loaded: app_helper
INFO - 2016-11-21 20:25:33 --> Email Class Initialized
INFO - 2016-11-21 20:25:33 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 19:25:33 --> Severity: Notice --> Undefined variable: hi C:\xampp\htdocs\LMS\app\views\email_template.php 23
ERROR - 2016-11-21 19:25:33 --> Severity: Notice --> Undefined variable: userName C:\xampp\htdocs\LMS\app\views\email_template.php 23
ERROR - 2016-11-21 19:25:33 --> Severity: Notice --> Undefined variable: msg1 C:\xampp\htdocs\LMS\app\views\email_template.php 24
INFO - 2016-11-21 19:25:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 19:25:33 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-21 19:25:33 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 179
ERROR - 2016-11-21 19:25:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\sys\libraries\Email.php 452
INFO - 2016-11-21 19:25:33 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 19:25:34 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 19:25:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:25:34 --> Final output sent to browser
DEBUG - 2016-11-21 19:25:34 --> Total execution time: 1.8570
INFO - 2016-11-21 20:26:34 --> Config Class Initialized
INFO - 2016-11-21 20:26:34 --> Hooks Class Initialized
DEBUG - 2016-11-21 20:26:34 --> UTF-8 Support Enabled
INFO - 2016-11-21 20:26:34 --> Utf8 Class Initialized
INFO - 2016-11-21 20:26:34 --> URI Class Initialized
INFO - 2016-11-21 20:26:34 --> Router Class Initialized
INFO - 2016-11-21 20:26:34 --> Output Class Initialized
INFO - 2016-11-21 20:26:34 --> Security Class Initialized
DEBUG - 2016-11-21 20:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 20:26:34 --> Input Class Initialized
INFO - 2016-11-21 20:26:34 --> Language Class Initialized
INFO - 2016-11-21 20:26:34 --> Loader Class Initialized
INFO - 2016-11-21 20:26:34 --> Helper loaded: url_helper
INFO - 2016-11-21 20:26:34 --> Helper loaded: form_helper
INFO - 2016-11-21 20:26:34 --> Database Driver Class Initialized
INFO - 2016-11-21 20:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 20:26:34 --> Controller Class Initialized
INFO - 2016-11-21 20:26:34 --> Model Class Initialized
INFO - 2016-11-21 20:26:34 --> Form Validation Class Initialized
INFO - 2016-11-21 20:26:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 20:26:34 --> Pagination Class Initialized
INFO - 2016-11-21 20:26:34 --> Helper loaded: app_helper
INFO - 2016-11-21 20:26:34 --> Email Class Initialized
INFO - 2016-11-21 20:26:34 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 19:26:35 --> Severity: Notice --> Undefined variable: hi C:\xampp\htdocs\LMS\app\views\email_template.php 23
ERROR - 2016-11-21 19:26:35 --> Severity: Notice --> Undefined variable: userName C:\xampp\htdocs\LMS\app\views\email_template.php 23
ERROR - 2016-11-21 19:26:35 --> Severity: Notice --> Undefined variable: msg1 C:\xampp\htdocs\LMS\app\views\email_template.php 24
INFO - 2016-11-21 19:26:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 19:26:35 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-21 19:26:37 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 19:26:41 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 19:26:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:26:41 --> Final output sent to browser
DEBUG - 2016-11-21 19:26:41 --> Total execution time: 7.3723
INFO - 2016-11-21 20:29:28 --> Config Class Initialized
INFO - 2016-11-21 20:29:28 --> Hooks Class Initialized
DEBUG - 2016-11-21 20:29:28 --> UTF-8 Support Enabled
INFO - 2016-11-21 20:29:29 --> Utf8 Class Initialized
INFO - 2016-11-21 20:29:29 --> URI Class Initialized
INFO - 2016-11-21 20:29:29 --> Router Class Initialized
INFO - 2016-11-21 20:29:29 --> Output Class Initialized
INFO - 2016-11-21 20:29:29 --> Security Class Initialized
DEBUG - 2016-11-21 20:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 20:29:29 --> Input Class Initialized
INFO - 2016-11-21 20:29:29 --> Language Class Initialized
INFO - 2016-11-21 20:29:29 --> Loader Class Initialized
INFO - 2016-11-21 20:29:29 --> Helper loaded: url_helper
INFO - 2016-11-21 20:29:29 --> Helper loaded: form_helper
INFO - 2016-11-21 20:29:29 --> Database Driver Class Initialized
INFO - 2016-11-21 20:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 20:29:29 --> Controller Class Initialized
INFO - 2016-11-21 20:29:29 --> Model Class Initialized
INFO - 2016-11-21 20:29:29 --> Form Validation Class Initialized
INFO - 2016-11-21 20:29:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 20:29:29 --> Pagination Class Initialized
INFO - 2016-11-21 20:29:29 --> Helper loaded: app_helper
INFO - 2016-11-21 20:29:29 --> Email Class Initialized
INFO - 2016-11-21 20:29:29 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 19:29:29 --> Severity: Notice --> Undefined variable: hi C:\xampp\htdocs\LMS\app\views\email_template.php 23
ERROR - 2016-11-21 19:29:29 --> Severity: Notice --> Undefined variable: userName C:\xampp\htdocs\LMS\app\views\email_template.php 23
ERROR - 2016-11-21 19:29:29 --> Severity: Notice --> Undefined variable: msg1 C:\xampp\htdocs\LMS\app\views\email_template.php 24
INFO - 2016-11-21 19:29:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 19:29:29 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-21 19:29:33 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 19:29:38 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 19:29:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:29:38 --> Final output sent to browser
DEBUG - 2016-11-21 19:29:38 --> Total execution time: 9.5286
INFO - 2016-11-21 20:34:20 --> Config Class Initialized
INFO - 2016-11-21 20:34:20 --> Hooks Class Initialized
DEBUG - 2016-11-21 20:34:20 --> UTF-8 Support Enabled
INFO - 2016-11-21 20:34:20 --> Utf8 Class Initialized
INFO - 2016-11-21 20:34:20 --> URI Class Initialized
DEBUG - 2016-11-21 20:34:20 --> No URI present. Default controller set.
INFO - 2016-11-21 20:34:20 --> Router Class Initialized
INFO - 2016-11-21 20:34:20 --> Output Class Initialized
INFO - 2016-11-21 20:34:20 --> Security Class Initialized
DEBUG - 2016-11-21 20:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 20:34:20 --> Input Class Initialized
INFO - 2016-11-21 20:34:20 --> Language Class Initialized
INFO - 2016-11-21 20:34:20 --> Loader Class Initialized
INFO - 2016-11-21 20:34:20 --> Helper loaded: url_helper
INFO - 2016-11-21 20:34:20 --> Helper loaded: form_helper
INFO - 2016-11-21 20:34:21 --> Database Driver Class Initialized
INFO - 2016-11-21 20:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 20:34:21 --> Controller Class Initialized
INFO - 2016-11-21 20:34:21 --> Model Class Initialized
INFO - 2016-11-21 20:34:21 --> Model Class Initialized
INFO - 2016-11-21 20:34:21 --> Model Class Initialized
INFO - 2016-11-21 20:34:21 --> Model Class Initialized
INFO - 2016-11-21 20:34:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 20:34:21 --> Pagination Class Initialized
INFO - 2016-11-21 20:34:21 --> Helper loaded: app_helper
INFO - 2016-11-21 20:34:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 20:34:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 20:34:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 20:34:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 20:34:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 20:34:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 20:34:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 20:34:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 20:34:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 20:34:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 20:34:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 20:34:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 20:34:21 --> Final output sent to browser
DEBUG - 2016-11-21 20:34:21 --> Total execution time: 1.3372
INFO - 2016-11-21 20:34:50 --> Config Class Initialized
INFO - 2016-11-21 20:34:50 --> Hooks Class Initialized
DEBUG - 2016-11-21 20:34:50 --> UTF-8 Support Enabled
INFO - 2016-11-21 20:34:50 --> Utf8 Class Initialized
INFO - 2016-11-21 20:34:50 --> URI Class Initialized
INFO - 2016-11-21 20:34:50 --> Router Class Initialized
INFO - 2016-11-21 20:34:50 --> Output Class Initialized
INFO - 2016-11-21 20:34:50 --> Security Class Initialized
DEBUG - 2016-11-21 20:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 20:34:51 --> Input Class Initialized
INFO - 2016-11-21 20:34:51 --> Language Class Initialized
INFO - 2016-11-21 20:34:51 --> Loader Class Initialized
INFO - 2016-11-21 20:34:51 --> Helper loaded: url_helper
INFO - 2016-11-21 20:34:51 --> Helper loaded: form_helper
INFO - 2016-11-21 20:34:51 --> Database Driver Class Initialized
INFO - 2016-11-21 20:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 20:34:51 --> Controller Class Initialized
INFO - 2016-11-21 20:34:51 --> Model Class Initialized
INFO - 2016-11-21 20:34:51 --> Form Validation Class Initialized
INFO - 2016-11-21 20:34:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 20:34:51 --> Pagination Class Initialized
INFO - 2016-11-21 20:34:51 --> Helper loaded: app_helper
INFO - 2016-11-21 20:34:51 --> Email Class Initialized
INFO - 2016-11-21 20:34:51 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 19:34:51 --> Severity: Notice --> Undefined variable: hi C:\xampp\htdocs\LMS\app\views\email_template.php 23
ERROR - 2016-11-21 19:34:51 --> Severity: Notice --> Undefined variable: msg1 C:\xampp\htdocs\LMS\app\views\email_template.php 24
INFO - 2016-11-21 19:34:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 19:34:51 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-21 19:34:52 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 19:34:54 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 19:34:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 19:34:54 --> Final output sent to browser
DEBUG - 2016-11-21 19:34:54 --> Total execution time: 3.4207
INFO - 2016-11-21 20:43:40 --> Config Class Initialized
INFO - 2016-11-21 20:43:40 --> Hooks Class Initialized
DEBUG - 2016-11-21 20:43:40 --> UTF-8 Support Enabled
INFO - 2016-11-21 20:43:40 --> Utf8 Class Initialized
INFO - 2016-11-21 20:43:40 --> URI Class Initialized
INFO - 2016-11-21 20:43:40 --> Router Class Initialized
INFO - 2016-11-21 20:43:40 --> Output Class Initialized
INFO - 2016-11-21 20:43:41 --> Security Class Initialized
DEBUG - 2016-11-21 20:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 20:43:41 --> Input Class Initialized
INFO - 2016-11-21 20:43:41 --> Language Class Initialized
INFO - 2016-11-21 20:43:41 --> Loader Class Initialized
INFO - 2016-11-21 20:43:41 --> Helper loaded: url_helper
INFO - 2016-11-21 20:43:41 --> Helper loaded: form_helper
INFO - 2016-11-21 20:43:41 --> Database Driver Class Initialized
INFO - 2016-11-21 20:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 20:43:41 --> Controller Class Initialized
INFO - 2016-11-21 20:43:41 --> Model Class Initialized
INFO - 2016-11-21 20:43:41 --> Form Validation Class Initialized
INFO - 2016-11-21 20:43:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 20:43:41 --> Pagination Class Initialized
INFO - 2016-11-21 20:43:41 --> Helper loaded: app_helper
INFO - 2016-11-21 20:43:41 --> Email Class Initialized
INFO - 2016-11-21 20:43:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 20:43:41 --> Final output sent to browser
DEBUG - 2016-11-21 20:43:41 --> Total execution time: 0.6416
INFO - 2016-11-21 20:43:58 --> Config Class Initialized
INFO - 2016-11-21 20:43:58 --> Hooks Class Initialized
DEBUG - 2016-11-21 20:43:58 --> UTF-8 Support Enabled
INFO - 2016-11-21 20:43:58 --> Utf8 Class Initialized
INFO - 2016-11-21 20:43:58 --> URI Class Initialized
DEBUG - 2016-11-21 20:43:58 --> No URI present. Default controller set.
INFO - 2016-11-21 20:43:58 --> Router Class Initialized
INFO - 2016-11-21 20:43:58 --> Output Class Initialized
INFO - 2016-11-21 20:43:58 --> Security Class Initialized
DEBUG - 2016-11-21 20:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 20:43:58 --> Input Class Initialized
INFO - 2016-11-21 20:43:58 --> Language Class Initialized
INFO - 2016-11-21 20:43:58 --> Loader Class Initialized
INFO - 2016-11-21 20:43:58 --> Helper loaded: url_helper
INFO - 2016-11-21 20:43:58 --> Helper loaded: form_helper
INFO - 2016-11-21 20:43:58 --> Database Driver Class Initialized
INFO - 2016-11-21 20:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 20:43:59 --> Controller Class Initialized
INFO - 2016-11-21 20:43:59 --> Model Class Initialized
INFO - 2016-11-21 20:43:59 --> Model Class Initialized
INFO - 2016-11-21 20:43:59 --> Model Class Initialized
INFO - 2016-11-21 20:43:59 --> Model Class Initialized
INFO - 2016-11-21 20:43:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 20:43:59 --> Pagination Class Initialized
INFO - 2016-11-21 20:43:59 --> Helper loaded: app_helper
INFO - 2016-11-21 20:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 20:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 20:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 20:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 20:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 20:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 20:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 20:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 20:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 20:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 20:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 20:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 20:43:59 --> Final output sent to browser
DEBUG - 2016-11-21 20:43:59 --> Total execution time: 1.0465
INFO - 2016-11-21 21:10:09 --> Config Class Initialized
INFO - 2016-11-21 21:10:09 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:10:09 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:10:09 --> Utf8 Class Initialized
INFO - 2016-11-21 21:10:09 --> URI Class Initialized
INFO - 2016-11-21 21:10:09 --> Router Class Initialized
INFO - 2016-11-21 21:10:09 --> Output Class Initialized
INFO - 2016-11-21 21:10:09 --> Security Class Initialized
DEBUG - 2016-11-21 21:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:10:09 --> Input Class Initialized
INFO - 2016-11-21 21:10:09 --> Language Class Initialized
ERROR - 2016-11-21 21:10:09 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 170
INFO - 2016-11-21 21:10:43 --> Config Class Initialized
INFO - 2016-11-21 21:10:43 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:10:43 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:10:43 --> Utf8 Class Initialized
INFO - 2016-11-21 21:10:43 --> URI Class Initialized
INFO - 2016-11-21 21:10:43 --> Router Class Initialized
INFO - 2016-11-21 21:10:43 --> Output Class Initialized
INFO - 2016-11-21 21:10:44 --> Security Class Initialized
DEBUG - 2016-11-21 21:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:10:44 --> Input Class Initialized
INFO - 2016-11-21 21:10:44 --> Language Class Initialized
INFO - 2016-11-21 21:10:44 --> Loader Class Initialized
INFO - 2016-11-21 21:10:44 --> Helper loaded: url_helper
INFO - 2016-11-21 21:10:44 --> Helper loaded: form_helper
INFO - 2016-11-21 21:10:44 --> Database Driver Class Initialized
INFO - 2016-11-21 21:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:10:44 --> Controller Class Initialized
INFO - 2016-11-21 21:10:44 --> Model Class Initialized
INFO - 2016-11-21 21:10:44 --> Form Validation Class Initialized
INFO - 2016-11-21 21:10:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:10:44 --> Pagination Class Initialized
INFO - 2016-11-21 21:10:44 --> Helper loaded: app_helper
INFO - 2016-11-21 21:10:44 --> Email Class Initialized
INFO - 2016-11-21 21:10:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 21:14:04 --> Config Class Initialized
INFO - 2016-11-21 21:14:04 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:14:04 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:14:04 --> Utf8 Class Initialized
INFO - 2016-11-21 21:14:04 --> URI Class Initialized
INFO - 2016-11-21 21:14:04 --> Router Class Initialized
INFO - 2016-11-21 21:14:04 --> Output Class Initialized
INFO - 2016-11-21 21:14:04 --> Security Class Initialized
DEBUG - 2016-11-21 21:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:14:04 --> Input Class Initialized
INFO - 2016-11-21 21:14:04 --> Language Class Initialized
INFO - 2016-11-21 21:14:04 --> Loader Class Initialized
INFO - 2016-11-21 21:14:04 --> Helper loaded: url_helper
INFO - 2016-11-21 21:14:04 --> Helper loaded: form_helper
INFO - 2016-11-21 21:14:04 --> Database Driver Class Initialized
INFO - 2016-11-21 21:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:14:04 --> Controller Class Initialized
INFO - 2016-11-21 21:14:04 --> Model Class Initialized
INFO - 2016-11-21 21:14:04 --> Form Validation Class Initialized
INFO - 2016-11-21 21:14:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:14:04 --> Pagination Class Initialized
INFO - 2016-11-21 21:14:04 --> Helper loaded: app_helper
INFO - 2016-11-21 21:14:04 --> Email Class Initialized
INFO - 2016-11-21 21:14:04 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 20:14:04 --> Severity: Notice --> Undefined index: typeName C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 177
INFO - 2016-11-21 20:14:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 20:14:04 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-21 20:14:06 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 20:14:06 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 20:14:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 20:14:06 --> Final output sent to browser
DEBUG - 2016-11-21 20:14:06 --> Total execution time: 2.7804
INFO - 2016-11-21 21:14:50 --> Config Class Initialized
INFO - 2016-11-21 21:14:50 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:14:50 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:14:50 --> Utf8 Class Initialized
INFO - 2016-11-21 21:14:50 --> URI Class Initialized
INFO - 2016-11-21 21:14:50 --> Router Class Initialized
INFO - 2016-11-21 21:14:50 --> Output Class Initialized
INFO - 2016-11-21 21:14:50 --> Security Class Initialized
DEBUG - 2016-11-21 21:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:14:50 --> Input Class Initialized
INFO - 2016-11-21 21:14:50 --> Language Class Initialized
INFO - 2016-11-21 21:14:50 --> Loader Class Initialized
INFO - 2016-11-21 21:14:50 --> Helper loaded: url_helper
INFO - 2016-11-21 21:14:50 --> Helper loaded: form_helper
INFO - 2016-11-21 21:14:50 --> Database Driver Class Initialized
INFO - 2016-11-21 21:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:14:50 --> Controller Class Initialized
INFO - 2016-11-21 21:14:50 --> Model Class Initialized
INFO - 2016-11-21 21:14:50 --> Form Validation Class Initialized
INFO - 2016-11-21 21:14:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:14:51 --> Pagination Class Initialized
INFO - 2016-11-21 21:14:51 --> Helper loaded: app_helper
INFO - 2016-11-21 21:14:51 --> Email Class Initialized
INFO - 2016-11-21 21:14:51 --> Final output sent to browser
DEBUG - 2016-11-21 21:14:51 --> Total execution time: 0.6879
INFO - 2016-11-21 21:15:14 --> Config Class Initialized
INFO - 2016-11-21 21:15:14 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:15:14 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:15:14 --> Utf8 Class Initialized
INFO - 2016-11-21 21:15:14 --> URI Class Initialized
INFO - 2016-11-21 21:15:14 --> Router Class Initialized
INFO - 2016-11-21 21:15:14 --> Output Class Initialized
INFO - 2016-11-21 21:15:14 --> Security Class Initialized
DEBUG - 2016-11-21 21:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:15:14 --> Input Class Initialized
INFO - 2016-11-21 21:15:14 --> Language Class Initialized
INFO - 2016-11-21 21:15:14 --> Loader Class Initialized
INFO - 2016-11-21 21:15:14 --> Helper loaded: url_helper
INFO - 2016-11-21 21:15:14 --> Helper loaded: form_helper
INFO - 2016-11-21 21:15:14 --> Database Driver Class Initialized
INFO - 2016-11-21 21:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:15:14 --> Controller Class Initialized
INFO - 2016-11-21 21:15:14 --> Model Class Initialized
INFO - 2016-11-21 21:15:14 --> Form Validation Class Initialized
INFO - 2016-11-21 21:15:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:15:14 --> Pagination Class Initialized
INFO - 2016-11-21 21:15:14 --> Helper loaded: app_helper
INFO - 2016-11-21 21:15:15 --> Email Class Initialized
INFO - 2016-11-21 21:15:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 20:15:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-21 20:15:15 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-21 20:15:15 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-21 20:15:16 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-21 20:15:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 20:15:17 --> Final output sent to browser
DEBUG - 2016-11-21 20:15:17 --> Total execution time: 2.6347
INFO - 2016-11-21 21:20:00 --> Config Class Initialized
INFO - 2016-11-21 21:20:00 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:20:00 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:20:00 --> Utf8 Class Initialized
INFO - 2016-11-21 21:20:00 --> URI Class Initialized
INFO - 2016-11-21 21:20:00 --> Router Class Initialized
INFO - 2016-11-21 21:20:00 --> Output Class Initialized
INFO - 2016-11-21 21:20:00 --> Security Class Initialized
DEBUG - 2016-11-21 21:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:20:00 --> Input Class Initialized
INFO - 2016-11-21 21:20:00 --> Language Class Initialized
INFO - 2016-11-21 21:20:00 --> Loader Class Initialized
INFO - 2016-11-21 21:20:00 --> Helper loaded: url_helper
INFO - 2016-11-21 21:20:00 --> Helper loaded: form_helper
INFO - 2016-11-21 21:20:00 --> Database Driver Class Initialized
INFO - 2016-11-21 21:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:20:00 --> Controller Class Initialized
INFO - 2016-11-21 21:20:00 --> Model Class Initialized
INFO - 2016-11-21 21:20:00 --> Form Validation Class Initialized
INFO - 2016-11-21 21:20:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:20:00 --> Pagination Class Initialized
INFO - 2016-11-21 21:20:00 --> Helper loaded: app_helper
INFO - 2016-11-21 21:20:00 --> Email Class Initialized
INFO - 2016-11-21 21:20:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 21:20:30 --> Config Class Initialized
INFO - 2016-11-21 21:20:30 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:20:30 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:20:30 --> Utf8 Class Initialized
INFO - 2016-11-21 21:20:30 --> URI Class Initialized
INFO - 2016-11-21 21:20:30 --> Router Class Initialized
INFO - 2016-11-21 21:20:30 --> Output Class Initialized
INFO - 2016-11-21 21:20:30 --> Security Class Initialized
DEBUG - 2016-11-21 21:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:20:30 --> Input Class Initialized
INFO - 2016-11-21 21:20:30 --> Language Class Initialized
INFO - 2016-11-21 21:20:30 --> Loader Class Initialized
INFO - 2016-11-21 21:20:30 --> Helper loaded: url_helper
INFO - 2016-11-21 21:20:30 --> Helper loaded: form_helper
INFO - 2016-11-21 21:20:30 --> Database Driver Class Initialized
INFO - 2016-11-21 21:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:20:30 --> Controller Class Initialized
INFO - 2016-11-21 21:20:30 --> Model Class Initialized
INFO - 2016-11-21 21:20:30 --> Form Validation Class Initialized
INFO - 2016-11-21 21:20:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:20:30 --> Pagination Class Initialized
INFO - 2016-11-21 21:20:30 --> Helper loaded: app_helper
INFO - 2016-11-21 21:20:30 --> Email Class Initialized
INFO - 2016-11-21 21:20:31 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 20:20:31 --> Severity: Notice --> Undefined index: typeName C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 171
INFO - 2016-11-21 21:22:42 --> Config Class Initialized
INFO - 2016-11-21 21:22:42 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:22:42 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:22:42 --> Utf8 Class Initialized
INFO - 2016-11-21 21:22:42 --> URI Class Initialized
INFO - 2016-11-21 21:22:42 --> Router Class Initialized
INFO - 2016-11-21 21:22:42 --> Output Class Initialized
INFO - 2016-11-21 21:22:42 --> Security Class Initialized
DEBUG - 2016-11-21 21:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:22:42 --> Input Class Initialized
INFO - 2016-11-21 21:22:42 --> Language Class Initialized
INFO - 2016-11-21 21:22:42 --> Loader Class Initialized
INFO - 2016-11-21 21:22:42 --> Helper loaded: url_helper
INFO - 2016-11-21 21:22:42 --> Helper loaded: form_helper
INFO - 2016-11-21 21:22:42 --> Database Driver Class Initialized
INFO - 2016-11-21 21:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:22:42 --> Controller Class Initialized
INFO - 2016-11-21 21:22:42 --> Model Class Initialized
INFO - 2016-11-21 21:22:42 --> Form Validation Class Initialized
INFO - 2016-11-21 21:22:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:22:42 --> Pagination Class Initialized
INFO - 2016-11-21 21:22:42 --> Helper loaded: app_helper
INFO - 2016-11-21 21:22:42 --> Email Class Initialized
INFO - 2016-11-21 21:22:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 21:24:05 --> Config Class Initialized
INFO - 2016-11-21 21:24:05 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:24:05 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:24:05 --> Utf8 Class Initialized
INFO - 2016-11-21 21:24:05 --> URI Class Initialized
INFO - 2016-11-21 21:24:05 --> Router Class Initialized
INFO - 2016-11-21 21:24:05 --> Output Class Initialized
INFO - 2016-11-21 21:24:05 --> Security Class Initialized
DEBUG - 2016-11-21 21:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:24:05 --> Input Class Initialized
INFO - 2016-11-21 21:24:05 --> Language Class Initialized
INFO - 2016-11-21 21:24:05 --> Loader Class Initialized
INFO - 2016-11-21 21:24:05 --> Helper loaded: url_helper
INFO - 2016-11-21 21:24:05 --> Helper loaded: form_helper
INFO - 2016-11-21 21:24:05 --> Database Driver Class Initialized
INFO - 2016-11-21 21:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:24:06 --> Controller Class Initialized
INFO - 2016-11-21 21:24:06 --> Model Class Initialized
INFO - 2016-11-21 21:24:06 --> Form Validation Class Initialized
INFO - 2016-11-21 21:24:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:24:06 --> Pagination Class Initialized
INFO - 2016-11-21 21:24:06 --> Helper loaded: app_helper
INFO - 2016-11-21 21:24:06 --> Email Class Initialized
INFO - 2016-11-21 21:24:06 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-21 20:24:06 --> Severity: Notice --> Undefined index: typeName C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 171
INFO - 2016-11-21 21:24:28 --> Config Class Initialized
INFO - 2016-11-21 21:24:28 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:24:28 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:24:28 --> Utf8 Class Initialized
INFO - 2016-11-21 21:24:28 --> URI Class Initialized
INFO - 2016-11-21 21:24:28 --> Router Class Initialized
INFO - 2016-11-21 21:24:28 --> Output Class Initialized
INFO - 2016-11-21 21:24:28 --> Security Class Initialized
DEBUG - 2016-11-21 21:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:24:29 --> Input Class Initialized
INFO - 2016-11-21 21:24:29 --> Language Class Initialized
INFO - 2016-11-21 21:24:29 --> Loader Class Initialized
INFO - 2016-11-21 21:24:29 --> Helper loaded: url_helper
INFO - 2016-11-21 21:24:29 --> Helper loaded: form_helper
INFO - 2016-11-21 21:24:29 --> Database Driver Class Initialized
INFO - 2016-11-21 21:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:24:29 --> Controller Class Initialized
INFO - 2016-11-21 21:24:29 --> Model Class Initialized
INFO - 2016-11-21 21:24:29 --> Form Validation Class Initialized
INFO - 2016-11-21 21:24:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:24:29 --> Pagination Class Initialized
INFO - 2016-11-21 21:24:29 --> Helper loaded: app_helper
INFO - 2016-11-21 21:24:29 --> Email Class Initialized
INFO - 2016-11-21 21:24:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 21:25:22 --> Config Class Initialized
INFO - 2016-11-21 21:25:22 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:25:22 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:25:22 --> Utf8 Class Initialized
INFO - 2016-11-21 21:25:22 --> URI Class Initialized
INFO - 2016-11-21 21:25:22 --> Router Class Initialized
INFO - 2016-11-21 21:25:22 --> Output Class Initialized
INFO - 2016-11-21 21:25:22 --> Security Class Initialized
DEBUG - 2016-11-21 21:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:25:23 --> Input Class Initialized
INFO - 2016-11-21 21:25:23 --> Language Class Initialized
INFO - 2016-11-21 21:25:23 --> Loader Class Initialized
INFO - 2016-11-21 21:25:23 --> Helper loaded: url_helper
INFO - 2016-11-21 21:25:23 --> Helper loaded: form_helper
INFO - 2016-11-21 21:25:23 --> Database Driver Class Initialized
INFO - 2016-11-21 21:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:25:23 --> Controller Class Initialized
INFO - 2016-11-21 21:25:23 --> Model Class Initialized
INFO - 2016-11-21 21:25:23 --> Form Validation Class Initialized
INFO - 2016-11-21 21:25:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:25:23 --> Pagination Class Initialized
INFO - 2016-11-21 21:25:23 --> Helper loaded: app_helper
INFO - 2016-11-21 21:25:23 --> Email Class Initialized
INFO - 2016-11-21 21:25:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 21:25:51 --> Config Class Initialized
INFO - 2016-11-21 21:25:51 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:25:52 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:25:52 --> Utf8 Class Initialized
INFO - 2016-11-21 21:25:52 --> URI Class Initialized
INFO - 2016-11-21 21:25:52 --> Router Class Initialized
INFO - 2016-11-21 21:25:52 --> Output Class Initialized
INFO - 2016-11-21 21:25:52 --> Security Class Initialized
DEBUG - 2016-11-21 21:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:25:52 --> Input Class Initialized
INFO - 2016-11-21 21:25:52 --> Language Class Initialized
INFO - 2016-11-21 21:25:52 --> Loader Class Initialized
INFO - 2016-11-21 21:25:52 --> Helper loaded: url_helper
INFO - 2016-11-21 21:25:52 --> Helper loaded: form_helper
INFO - 2016-11-21 21:25:52 --> Database Driver Class Initialized
INFO - 2016-11-21 21:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:25:52 --> Controller Class Initialized
INFO - 2016-11-21 21:25:52 --> Model Class Initialized
INFO - 2016-11-21 21:25:52 --> Form Validation Class Initialized
INFO - 2016-11-21 21:25:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:25:52 --> Pagination Class Initialized
INFO - 2016-11-21 21:25:52 --> Helper loaded: app_helper
INFO - 2016-11-21 21:25:52 --> Email Class Initialized
INFO - 2016-11-21 21:25:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 21:26:00 --> Config Class Initialized
INFO - 2016-11-21 21:26:00 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:26:00 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:26:00 --> Utf8 Class Initialized
INFO - 2016-11-21 21:26:00 --> URI Class Initialized
DEBUG - 2016-11-21 21:26:00 --> No URI present. Default controller set.
INFO - 2016-11-21 21:26:00 --> Router Class Initialized
INFO - 2016-11-21 21:26:00 --> Output Class Initialized
INFO - 2016-11-21 21:26:00 --> Security Class Initialized
DEBUG - 2016-11-21 21:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:26:00 --> Input Class Initialized
INFO - 2016-11-21 21:26:00 --> Language Class Initialized
INFO - 2016-11-21 21:26:00 --> Loader Class Initialized
INFO - 2016-11-21 21:26:00 --> Helper loaded: url_helper
INFO - 2016-11-21 21:26:00 --> Helper loaded: form_helper
INFO - 2016-11-21 21:26:00 --> Database Driver Class Initialized
INFO - 2016-11-21 21:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:26:00 --> Controller Class Initialized
INFO - 2016-11-21 21:26:00 --> Model Class Initialized
INFO - 2016-11-21 21:26:00 --> Model Class Initialized
INFO - 2016-11-21 21:26:00 --> Model Class Initialized
INFO - 2016-11-21 21:26:00 --> Model Class Initialized
INFO - 2016-11-21 21:26:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:26:00 --> Pagination Class Initialized
INFO - 2016-11-21 21:26:00 --> Helper loaded: app_helper
INFO - 2016-11-21 21:26:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 21:26:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 21:26:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 21:26:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 21:26:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 21:26:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 21:26:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 21:26:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 21:26:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 21:26:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 21:26:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 21:26:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 21:26:01 --> Final output sent to browser
DEBUG - 2016-11-21 21:26:01 --> Total execution time: 1.1285
INFO - 2016-11-21 21:26:26 --> Config Class Initialized
INFO - 2016-11-21 21:26:26 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:26:26 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:26:26 --> Utf8 Class Initialized
INFO - 2016-11-21 21:26:26 --> URI Class Initialized
INFO - 2016-11-21 21:26:26 --> Router Class Initialized
INFO - 2016-11-21 21:26:26 --> Output Class Initialized
INFO - 2016-11-21 21:26:26 --> Security Class Initialized
DEBUG - 2016-11-21 21:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:26:26 --> Input Class Initialized
INFO - 2016-11-21 21:26:26 --> Language Class Initialized
INFO - 2016-11-21 21:26:27 --> Loader Class Initialized
INFO - 2016-11-21 21:26:27 --> Helper loaded: url_helper
INFO - 2016-11-21 21:26:27 --> Helper loaded: form_helper
INFO - 2016-11-21 21:26:27 --> Database Driver Class Initialized
INFO - 2016-11-21 21:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:26:27 --> Controller Class Initialized
INFO - 2016-11-21 21:26:27 --> Model Class Initialized
INFO - 2016-11-21 21:26:27 --> Form Validation Class Initialized
INFO - 2016-11-21 21:26:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:26:27 --> Pagination Class Initialized
INFO - 2016-11-21 21:26:27 --> Helper loaded: app_helper
INFO - 2016-11-21 21:26:27 --> Email Class Initialized
INFO - 2016-11-21 21:26:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 21:29:22 --> Config Class Initialized
INFO - 2016-11-21 21:29:22 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:29:22 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:29:22 --> Utf8 Class Initialized
INFO - 2016-11-21 21:29:22 --> URI Class Initialized
INFO - 2016-11-21 21:29:22 --> Router Class Initialized
INFO - 2016-11-21 21:29:22 --> Output Class Initialized
INFO - 2016-11-21 21:29:22 --> Security Class Initialized
DEBUG - 2016-11-21 21:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:29:23 --> Input Class Initialized
INFO - 2016-11-21 21:29:23 --> Language Class Initialized
INFO - 2016-11-21 21:29:23 --> Loader Class Initialized
INFO - 2016-11-21 21:29:23 --> Helper loaded: url_helper
INFO - 2016-11-21 21:29:23 --> Helper loaded: form_helper
INFO - 2016-11-21 21:29:23 --> Database Driver Class Initialized
INFO - 2016-11-21 21:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:29:23 --> Controller Class Initialized
INFO - 2016-11-21 21:29:23 --> Model Class Initialized
INFO - 2016-11-21 21:29:23 --> Form Validation Class Initialized
INFO - 2016-11-21 21:29:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:29:23 --> Pagination Class Initialized
INFO - 2016-11-21 21:29:23 --> Helper loaded: app_helper
INFO - 2016-11-21 21:29:23 --> Email Class Initialized
INFO - 2016-11-21 21:29:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 21:30:05 --> Config Class Initialized
INFO - 2016-11-21 21:30:05 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:30:05 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:30:06 --> Utf8 Class Initialized
INFO - 2016-11-21 21:30:06 --> URI Class Initialized
INFO - 2016-11-21 21:30:06 --> Router Class Initialized
INFO - 2016-11-21 21:30:06 --> Output Class Initialized
INFO - 2016-11-21 21:30:06 --> Security Class Initialized
DEBUG - 2016-11-21 21:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:30:06 --> Input Class Initialized
INFO - 2016-11-21 21:30:06 --> Language Class Initialized
INFO - 2016-11-21 21:30:06 --> Loader Class Initialized
INFO - 2016-11-21 21:30:06 --> Helper loaded: url_helper
INFO - 2016-11-21 21:30:06 --> Helper loaded: form_helper
INFO - 2016-11-21 21:30:06 --> Database Driver Class Initialized
INFO - 2016-11-21 21:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:30:06 --> Controller Class Initialized
INFO - 2016-11-21 21:30:06 --> Model Class Initialized
INFO - 2016-11-21 21:30:06 --> Form Validation Class Initialized
INFO - 2016-11-21 21:30:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:30:06 --> Pagination Class Initialized
INFO - 2016-11-21 21:30:06 --> Helper loaded: app_helper
INFO - 2016-11-21 21:30:06 --> Email Class Initialized
INFO - 2016-11-21 21:30:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 21:32:04 --> Config Class Initialized
INFO - 2016-11-21 21:32:04 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:32:04 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:32:04 --> Utf8 Class Initialized
INFO - 2016-11-21 21:32:04 --> URI Class Initialized
DEBUG - 2016-11-21 21:32:04 --> No URI present. Default controller set.
INFO - 2016-11-21 21:32:04 --> Router Class Initialized
INFO - 2016-11-21 21:32:04 --> Output Class Initialized
INFO - 2016-11-21 21:32:04 --> Security Class Initialized
DEBUG - 2016-11-21 21:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:32:04 --> Input Class Initialized
INFO - 2016-11-21 21:32:04 --> Language Class Initialized
INFO - 2016-11-21 21:32:04 --> Loader Class Initialized
INFO - 2016-11-21 21:32:04 --> Helper loaded: url_helper
INFO - 2016-11-21 21:32:04 --> Helper loaded: form_helper
INFO - 2016-11-21 21:32:04 --> Database Driver Class Initialized
INFO - 2016-11-21 21:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:32:04 --> Controller Class Initialized
INFO - 2016-11-21 21:32:04 --> Model Class Initialized
INFO - 2016-11-21 21:32:04 --> Model Class Initialized
INFO - 2016-11-21 21:32:04 --> Model Class Initialized
INFO - 2016-11-21 21:32:04 --> Model Class Initialized
INFO - 2016-11-21 21:32:05 --> Config Class Initialized
INFO - 2016-11-21 21:32:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:32:05 --> Hooks Class Initialized
INFO - 2016-11-21 21:32:05 --> Pagination Class Initialized
DEBUG - 2016-11-21 21:32:05 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:32:05 --> Helper loaded: app_helper
INFO - 2016-11-21 21:32:05 --> Utf8 Class Initialized
INFO - 2016-11-21 21:32:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 21:32:05 --> URI Class Initialized
INFO - 2016-11-21 21:32:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
DEBUG - 2016-11-21 21:32:05 --> No URI present. Default controller set.
INFO - 2016-11-21 21:32:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 21:32:05 --> Router Class Initialized
INFO - 2016-11-21 21:32:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 21:32:05 --> Output Class Initialized
INFO - 2016-11-21 21:32:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 21:32:05 --> Security Class Initialized
INFO - 2016-11-21 21:32:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
DEBUG - 2016-11-21 21:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:32:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 21:32:05 --> Input Class Initialized
INFO - 2016-11-21 21:32:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 21:32:05 --> Language Class Initialized
INFO - 2016-11-21 21:32:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 21:32:05 --> Loader Class Initialized
INFO - 2016-11-21 21:32:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 21:32:05 --> Helper loaded: url_helper
INFO - 2016-11-21 21:32:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 21:32:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 21:32:05 --> Helper loaded: form_helper
INFO - 2016-11-21 21:32:05 --> Final output sent to browser
INFO - 2016-11-21 21:32:05 --> Database Driver Class Initialized
DEBUG - 2016-11-21 21:32:05 --> Total execution time: 1.3862
INFO - 2016-11-21 21:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:32:05 --> Controller Class Initialized
INFO - 2016-11-21 21:32:05 --> Model Class Initialized
INFO - 2016-11-21 21:32:05 --> Model Class Initialized
INFO - 2016-11-21 21:32:05 --> Model Class Initialized
INFO - 2016-11-21 21:32:05 --> Model Class Initialized
INFO - 2016-11-21 21:32:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:32:05 --> Pagination Class Initialized
INFO - 2016-11-21 21:32:05 --> Helper loaded: app_helper
INFO - 2016-11-21 21:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 21:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 21:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 21:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 21:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 21:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 21:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 21:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 21:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 21:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 21:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 21:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 21:32:06 --> Final output sent to browser
DEBUG - 2016-11-21 21:32:06 --> Total execution time: 1.3981
INFO - 2016-11-21 21:32:37 --> Config Class Initialized
INFO - 2016-11-21 21:32:37 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:32:37 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:32:37 --> Utf8 Class Initialized
INFO - 2016-11-21 21:32:37 --> URI Class Initialized
INFO - 2016-11-21 21:32:37 --> Router Class Initialized
INFO - 2016-11-21 21:32:37 --> Output Class Initialized
INFO - 2016-11-21 21:32:37 --> Security Class Initialized
DEBUG - 2016-11-21 21:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:32:37 --> Input Class Initialized
INFO - 2016-11-21 21:32:37 --> Language Class Initialized
INFO - 2016-11-21 21:32:37 --> Loader Class Initialized
INFO - 2016-11-21 21:32:37 --> Helper loaded: url_helper
INFO - 2016-11-21 21:32:37 --> Helper loaded: form_helper
INFO - 2016-11-21 21:32:37 --> Database Driver Class Initialized
INFO - 2016-11-21 21:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:32:38 --> Controller Class Initialized
INFO - 2016-11-21 21:32:38 --> Model Class Initialized
INFO - 2016-11-21 21:32:38 --> Form Validation Class Initialized
INFO - 2016-11-21 21:32:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:32:38 --> Pagination Class Initialized
INFO - 2016-11-21 21:32:38 --> Helper loaded: app_helper
INFO - 2016-11-21 21:32:38 --> Email Class Initialized
INFO - 2016-11-21 21:32:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 21:32:38 --> Final output sent to browser
DEBUG - 2016-11-21 21:32:38 --> Total execution time: 0.6441
INFO - 2016-11-21 21:32:56 --> Config Class Initialized
INFO - 2016-11-21 21:32:56 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:32:56 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:32:56 --> Utf8 Class Initialized
INFO - 2016-11-21 21:32:56 --> URI Class Initialized
INFO - 2016-11-21 21:32:56 --> Router Class Initialized
INFO - 2016-11-21 21:32:56 --> Output Class Initialized
INFO - 2016-11-21 21:32:56 --> Security Class Initialized
DEBUG - 2016-11-21 21:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:32:56 --> Input Class Initialized
INFO - 2016-11-21 21:32:56 --> Language Class Initialized
INFO - 2016-11-21 21:32:56 --> Loader Class Initialized
INFO - 2016-11-21 21:32:56 --> Helper loaded: url_helper
INFO - 2016-11-21 21:32:56 --> Helper loaded: form_helper
INFO - 2016-11-21 21:32:56 --> Database Driver Class Initialized
INFO - 2016-11-21 21:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:32:56 --> Controller Class Initialized
INFO - 2016-11-21 21:32:56 --> Model Class Initialized
INFO - 2016-11-21 21:32:56 --> Form Validation Class Initialized
INFO - 2016-11-21 21:32:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:32:56 --> Pagination Class Initialized
INFO - 2016-11-21 21:32:56 --> Helper loaded: app_helper
INFO - 2016-11-21 21:32:56 --> Email Class Initialized
INFO - 2016-11-21 21:32:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 21:40:04 --> Config Class Initialized
INFO - 2016-11-21 21:40:04 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:40:04 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:40:04 --> Utf8 Class Initialized
INFO - 2016-11-21 21:40:04 --> URI Class Initialized
INFO - 2016-11-21 21:40:04 --> Router Class Initialized
INFO - 2016-11-21 21:40:04 --> Output Class Initialized
INFO - 2016-11-21 21:40:04 --> Security Class Initialized
DEBUG - 2016-11-21 21:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:40:04 --> Input Class Initialized
INFO - 2016-11-21 21:40:04 --> Language Class Initialized
INFO - 2016-11-21 21:40:04 --> Loader Class Initialized
INFO - 2016-11-21 21:40:04 --> Helper loaded: url_helper
INFO - 2016-11-21 21:40:04 --> Helper loaded: form_helper
INFO - 2016-11-21 21:40:04 --> Database Driver Class Initialized
INFO - 2016-11-21 21:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:40:04 --> Controller Class Initialized
INFO - 2016-11-21 21:40:04 --> Model Class Initialized
INFO - 2016-11-21 21:40:04 --> Form Validation Class Initialized
INFO - 2016-11-21 21:40:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:40:05 --> Pagination Class Initialized
INFO - 2016-11-21 21:40:05 --> Helper loaded: app_helper
INFO - 2016-11-21 21:40:05 --> Email Class Initialized
INFO - 2016-11-21 21:40:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 21:41:08 --> Config Class Initialized
INFO - 2016-11-21 21:41:08 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:41:08 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:41:08 --> Utf8 Class Initialized
INFO - 2016-11-21 21:41:08 --> URI Class Initialized
INFO - 2016-11-21 21:41:08 --> Router Class Initialized
INFO - 2016-11-21 21:41:08 --> Output Class Initialized
INFO - 2016-11-21 21:41:08 --> Security Class Initialized
DEBUG - 2016-11-21 21:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:41:08 --> Input Class Initialized
INFO - 2016-11-21 21:41:08 --> Language Class Initialized
INFO - 2016-11-21 21:41:08 --> Loader Class Initialized
INFO - 2016-11-21 21:41:08 --> Helper loaded: url_helper
INFO - 2016-11-21 21:41:08 --> Helper loaded: form_helper
INFO - 2016-11-21 21:41:08 --> Database Driver Class Initialized
INFO - 2016-11-21 21:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:41:08 --> Controller Class Initialized
INFO - 2016-11-21 21:41:08 --> Model Class Initialized
INFO - 2016-11-21 21:41:08 --> Form Validation Class Initialized
INFO - 2016-11-21 21:41:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:41:08 --> Pagination Class Initialized
INFO - 2016-11-21 21:41:08 --> Helper loaded: app_helper
INFO - 2016-11-21 21:41:09 --> Email Class Initialized
INFO - 2016-11-21 21:41:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 21:43:47 --> Config Class Initialized
INFO - 2016-11-21 21:43:47 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:43:47 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:43:47 --> Utf8 Class Initialized
INFO - 2016-11-21 21:43:47 --> URI Class Initialized
INFO - 2016-11-21 21:43:47 --> Router Class Initialized
INFO - 2016-11-21 21:43:47 --> Output Class Initialized
INFO - 2016-11-21 21:43:47 --> Security Class Initialized
DEBUG - 2016-11-21 21:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:43:47 --> Input Class Initialized
INFO - 2016-11-21 21:43:47 --> Language Class Initialized
INFO - 2016-11-21 21:43:47 --> Loader Class Initialized
INFO - 2016-11-21 21:43:47 --> Helper loaded: url_helper
INFO - 2016-11-21 21:43:47 --> Helper loaded: form_helper
INFO - 2016-11-21 21:43:47 --> Database Driver Class Initialized
INFO - 2016-11-21 21:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:43:47 --> Controller Class Initialized
INFO - 2016-11-21 21:43:47 --> Model Class Initialized
INFO - 2016-11-21 21:43:47 --> Form Validation Class Initialized
INFO - 2016-11-21 21:43:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:43:47 --> Pagination Class Initialized
INFO - 2016-11-21 21:43:47 --> Helper loaded: app_helper
INFO - 2016-11-21 21:43:47 --> Email Class Initialized
INFO - 2016-11-21 21:43:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 21:44:20 --> Config Class Initialized
INFO - 2016-11-21 21:44:20 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:44:20 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:44:20 --> Utf8 Class Initialized
INFO - 2016-11-21 21:44:20 --> URI Class Initialized
INFO - 2016-11-21 21:44:20 --> Router Class Initialized
INFO - 2016-11-21 21:44:20 --> Output Class Initialized
INFO - 2016-11-21 21:44:20 --> Security Class Initialized
DEBUG - 2016-11-21 21:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:44:20 --> Input Class Initialized
INFO - 2016-11-21 21:44:20 --> Language Class Initialized
INFO - 2016-11-21 21:44:20 --> Loader Class Initialized
INFO - 2016-11-21 21:44:20 --> Helper loaded: url_helper
INFO - 2016-11-21 21:44:20 --> Helper loaded: form_helper
INFO - 2016-11-21 21:44:20 --> Database Driver Class Initialized
INFO - 2016-11-21 21:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:44:20 --> Controller Class Initialized
INFO - 2016-11-21 21:44:20 --> Model Class Initialized
INFO - 2016-11-21 21:44:20 --> Form Validation Class Initialized
INFO - 2016-11-21 21:44:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:44:20 --> Pagination Class Initialized
INFO - 2016-11-21 21:44:20 --> Helper loaded: app_helper
INFO - 2016-11-21 21:44:20 --> Email Class Initialized
INFO - 2016-11-21 21:44:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 21:46:00 --> Config Class Initialized
INFO - 2016-11-21 21:46:00 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:46:00 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:46:00 --> Utf8 Class Initialized
INFO - 2016-11-21 21:46:00 --> URI Class Initialized
INFO - 2016-11-21 21:46:00 --> Router Class Initialized
INFO - 2016-11-21 21:46:00 --> Output Class Initialized
INFO - 2016-11-21 21:46:00 --> Security Class Initialized
DEBUG - 2016-11-21 21:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:46:00 --> Input Class Initialized
INFO - 2016-11-21 21:46:00 --> Language Class Initialized
INFO - 2016-11-21 21:46:00 --> Loader Class Initialized
INFO - 2016-11-21 21:46:00 --> Helper loaded: url_helper
INFO - 2016-11-21 21:46:00 --> Helper loaded: form_helper
INFO - 2016-11-21 21:46:00 --> Database Driver Class Initialized
INFO - 2016-11-21 21:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:46:00 --> Controller Class Initialized
INFO - 2016-11-21 21:46:00 --> Model Class Initialized
INFO - 2016-11-21 21:46:00 --> Form Validation Class Initialized
INFO - 2016-11-21 21:46:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:46:00 --> Pagination Class Initialized
INFO - 2016-11-21 21:46:00 --> Helper loaded: app_helper
INFO - 2016-11-21 21:46:01 --> Email Class Initialized
INFO - 2016-11-21 21:46:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-21 21:47:23 --> Config Class Initialized
INFO - 2016-11-21 21:47:23 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:47:23 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:47:23 --> Utf8 Class Initialized
INFO - 2016-11-21 21:47:23 --> URI Class Initialized
DEBUG - 2016-11-21 21:47:23 --> No URI present. Default controller set.
INFO - 2016-11-21 21:47:23 --> Router Class Initialized
INFO - 2016-11-21 21:47:23 --> Output Class Initialized
INFO - 2016-11-21 21:47:23 --> Security Class Initialized
DEBUG - 2016-11-21 21:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:47:23 --> Input Class Initialized
INFO - 2016-11-21 21:47:23 --> Language Class Initialized
INFO - 2016-11-21 21:47:23 --> Loader Class Initialized
INFO - 2016-11-21 21:47:23 --> Helper loaded: url_helper
INFO - 2016-11-21 21:47:23 --> Helper loaded: form_helper
INFO - 2016-11-21 21:47:23 --> Database Driver Class Initialized
INFO - 2016-11-21 21:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:47:24 --> Controller Class Initialized
INFO - 2016-11-21 21:47:24 --> Model Class Initialized
INFO - 2016-11-21 21:47:24 --> Model Class Initialized
INFO - 2016-11-21 21:47:24 --> Model Class Initialized
INFO - 2016-11-21 21:47:24 --> Model Class Initialized
INFO - 2016-11-21 21:47:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:47:24 --> Pagination Class Initialized
INFO - 2016-11-21 21:47:24 --> Helper loaded: app_helper
INFO - 2016-11-21 21:47:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 21:47:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-21 21:47:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-21 21:47:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-21 21:47:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-21 21:47:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-21 21:47:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-21 21:47:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-21 21:47:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-21 21:47:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-21 21:47:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-21 21:47:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 21:47:24 --> Final output sent to browser
DEBUG - 2016-11-21 21:47:24 --> Total execution time: 0.9964
INFO - 2016-11-21 21:47:30 --> Config Class Initialized
INFO - 2016-11-21 21:47:30 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:47:31 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:47:31 --> Utf8 Class Initialized
INFO - 2016-11-21 21:47:31 --> URI Class Initialized
INFO - 2016-11-21 21:47:31 --> Router Class Initialized
INFO - 2016-11-21 21:47:31 --> Output Class Initialized
INFO - 2016-11-21 21:47:31 --> Security Class Initialized
DEBUG - 2016-11-21 21:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:47:31 --> Input Class Initialized
INFO - 2016-11-21 21:47:31 --> Language Class Initialized
INFO - 2016-11-21 21:47:31 --> Loader Class Initialized
INFO - 2016-11-21 21:47:31 --> Helper loaded: url_helper
INFO - 2016-11-21 21:47:31 --> Helper loaded: form_helper
INFO - 2016-11-21 21:47:31 --> Database Driver Class Initialized
INFO - 2016-11-21 21:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:47:31 --> Controller Class Initialized
INFO - 2016-11-21 21:47:31 --> Model Class Initialized
INFO - 2016-11-21 21:47:31 --> Model Class Initialized
INFO - 2016-11-21 21:47:31 --> Model Class Initialized
INFO - 2016-11-21 21:47:31 --> Model Class Initialized
INFO - 2016-11-21 21:47:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:47:31 --> Pagination Class Initialized
INFO - 2016-11-21 21:47:31 --> Helper loaded: app_helper
DEBUG - 2016-11-21 21:47:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-21 21:47:31 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-21 21:47:31 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-21 21:47:31 --> Config Class Initialized
INFO - 2016-11-21 21:47:31 --> Hooks Class Initialized
DEBUG - 2016-11-21 21:47:31 --> UTF-8 Support Enabled
INFO - 2016-11-21 21:47:31 --> Utf8 Class Initialized
INFO - 2016-11-21 21:47:31 --> URI Class Initialized
DEBUG - 2016-11-21 21:47:31 --> No URI present. Default controller set.
INFO - 2016-11-21 21:47:31 --> Router Class Initialized
INFO - 2016-11-21 21:47:31 --> Output Class Initialized
INFO - 2016-11-21 21:47:31 --> Security Class Initialized
DEBUG - 2016-11-21 21:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-21 21:47:32 --> Input Class Initialized
INFO - 2016-11-21 21:47:32 --> Language Class Initialized
INFO - 2016-11-21 21:47:32 --> Loader Class Initialized
INFO - 2016-11-21 21:47:32 --> Helper loaded: url_helper
INFO - 2016-11-21 21:47:32 --> Helper loaded: form_helper
INFO - 2016-11-21 21:47:32 --> Database Driver Class Initialized
INFO - 2016-11-21 21:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-21 21:47:32 --> Controller Class Initialized
INFO - 2016-11-21 21:47:32 --> Model Class Initialized
INFO - 2016-11-21 21:47:32 --> Model Class Initialized
INFO - 2016-11-21 21:47:32 --> Model Class Initialized
INFO - 2016-11-21 21:47:32 --> Model Class Initialized
INFO - 2016-11-21 21:47:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-21 21:47:32 --> Pagination Class Initialized
INFO - 2016-11-21 21:47:32 --> Helper loaded: app_helper
INFO - 2016-11-21 21:47:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-21 21:47:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-21 21:47:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-21 21:47:32 --> Final output sent to browser
DEBUG - 2016-11-21 21:47:32 --> Total execution time: 0.7833
