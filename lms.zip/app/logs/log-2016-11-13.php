<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-13 00:03:31 --> Config Class Initialized
INFO - 2016-11-13 00:03:31 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:03:31 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:03:31 --> Utf8 Class Initialized
INFO - 2016-11-13 00:03:32 --> URI Class Initialized
DEBUG - 2016-11-13 00:03:32 --> No URI present. Default controller set.
INFO - 2016-11-13 00:03:32 --> Router Class Initialized
INFO - 2016-11-13 00:03:32 --> Output Class Initialized
INFO - 2016-11-13 00:03:32 --> Security Class Initialized
DEBUG - 2016-11-13 00:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:03:32 --> Input Class Initialized
INFO - 2016-11-13 00:03:32 --> Language Class Initialized
INFO - 2016-11-13 00:03:32 --> Loader Class Initialized
INFO - 2016-11-13 00:03:33 --> Helper loaded: url_helper
INFO - 2016-11-13 00:03:33 --> Helper loaded: form_helper
INFO - 2016-11-13 00:03:33 --> Database Driver Class Initialized
INFO - 2016-11-13 00:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:03:34 --> Controller Class Initialized
INFO - 2016-11-13 00:03:34 --> Model Class Initialized
INFO - 2016-11-13 00:03:34 --> Model Class Initialized
INFO - 2016-11-13 00:03:34 --> Model Class Initialized
INFO - 2016-11-13 00:03:34 --> Model Class Initialized
INFO - 2016-11-13 00:03:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:03:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:03:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:03:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:03:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:03:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:03:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:03:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:03:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:03:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:03:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:03:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:03:35 --> Final output sent to browser
DEBUG - 2016-11-13 00:03:35 --> Total execution time: 4.9075
INFO - 2016-11-13 00:09:25 --> Config Class Initialized
INFO - 2016-11-13 00:09:25 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:09:25 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:09:25 --> Utf8 Class Initialized
INFO - 2016-11-13 00:09:25 --> URI Class Initialized
DEBUG - 2016-11-13 00:09:25 --> No URI present. Default controller set.
INFO - 2016-11-13 00:09:25 --> Router Class Initialized
INFO - 2016-11-13 00:09:25 --> Output Class Initialized
INFO - 2016-11-13 00:09:25 --> Security Class Initialized
DEBUG - 2016-11-13 00:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:09:25 --> Input Class Initialized
INFO - 2016-11-13 00:09:25 --> Language Class Initialized
INFO - 2016-11-13 00:09:25 --> Loader Class Initialized
INFO - 2016-11-13 00:09:25 --> Helper loaded: url_helper
INFO - 2016-11-13 00:09:25 --> Helper loaded: form_helper
INFO - 2016-11-13 00:09:25 --> Database Driver Class Initialized
INFO - 2016-11-13 00:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:09:25 --> Controller Class Initialized
INFO - 2016-11-13 00:09:25 --> Model Class Initialized
INFO - 2016-11-13 00:09:26 --> Model Class Initialized
INFO - 2016-11-13 00:09:26 --> Model Class Initialized
INFO - 2016-11-13 00:09:26 --> Model Class Initialized
INFO - 2016-11-13 00:09:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:09:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:09:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:09:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:09:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:09:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:09:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:09:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:09:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:09:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:09:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:09:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:09:26 --> Final output sent to browser
DEBUG - 2016-11-13 00:09:26 --> Total execution time: 0.3829
INFO - 2016-11-13 00:12:44 --> Config Class Initialized
INFO - 2016-11-13 00:12:44 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:12:44 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:12:44 --> Utf8 Class Initialized
INFO - 2016-11-13 00:12:44 --> URI Class Initialized
DEBUG - 2016-11-13 00:12:44 --> No URI present. Default controller set.
INFO - 2016-11-13 00:12:44 --> Router Class Initialized
INFO - 2016-11-13 00:12:44 --> Output Class Initialized
INFO - 2016-11-13 00:12:44 --> Security Class Initialized
DEBUG - 2016-11-13 00:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:12:44 --> Input Class Initialized
INFO - 2016-11-13 00:12:44 --> Language Class Initialized
INFO - 2016-11-13 00:12:44 --> Loader Class Initialized
INFO - 2016-11-13 00:12:44 --> Helper loaded: url_helper
INFO - 2016-11-13 00:12:44 --> Helper loaded: form_helper
INFO - 2016-11-13 00:12:44 --> Database Driver Class Initialized
INFO - 2016-11-13 00:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:12:44 --> Controller Class Initialized
INFO - 2016-11-13 00:12:44 --> Model Class Initialized
INFO - 2016-11-13 00:12:44 --> Model Class Initialized
INFO - 2016-11-13 00:12:45 --> Model Class Initialized
INFO - 2016-11-13 00:12:45 --> Model Class Initialized
INFO - 2016-11-13 00:12:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:12:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:12:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:12:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:12:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:12:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:12:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:12:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:12:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:12:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:12:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:12:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:12:45 --> Final output sent to browser
DEBUG - 2016-11-13 00:12:45 --> Total execution time: 0.3294
INFO - 2016-11-13 00:18:21 --> Config Class Initialized
INFO - 2016-11-13 00:18:21 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:18:21 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:18:21 --> Utf8 Class Initialized
INFO - 2016-11-13 00:18:21 --> URI Class Initialized
DEBUG - 2016-11-13 00:18:21 --> No URI present. Default controller set.
INFO - 2016-11-13 00:18:21 --> Router Class Initialized
INFO - 2016-11-13 00:18:21 --> Output Class Initialized
INFO - 2016-11-13 00:18:21 --> Security Class Initialized
DEBUG - 2016-11-13 00:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:18:21 --> Input Class Initialized
INFO - 2016-11-13 00:18:21 --> Language Class Initialized
INFO - 2016-11-13 00:18:21 --> Loader Class Initialized
INFO - 2016-11-13 00:18:21 --> Helper loaded: url_helper
INFO - 2016-11-13 00:18:21 --> Helper loaded: form_helper
INFO - 2016-11-13 00:18:21 --> Database Driver Class Initialized
INFO - 2016-11-13 00:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:18:21 --> Controller Class Initialized
INFO - 2016-11-13 00:18:21 --> Model Class Initialized
INFO - 2016-11-13 00:18:21 --> Model Class Initialized
ERROR - 2016-11-13 00:18:21 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 60
INFO - 2016-11-13 00:18:43 --> Config Class Initialized
INFO - 2016-11-13 00:18:43 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:18:43 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:18:43 --> Utf8 Class Initialized
INFO - 2016-11-13 00:18:43 --> URI Class Initialized
DEBUG - 2016-11-13 00:18:43 --> No URI present. Default controller set.
INFO - 2016-11-13 00:18:43 --> Router Class Initialized
INFO - 2016-11-13 00:18:43 --> Output Class Initialized
INFO - 2016-11-13 00:18:43 --> Security Class Initialized
DEBUG - 2016-11-13 00:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:18:43 --> Input Class Initialized
INFO - 2016-11-13 00:18:43 --> Language Class Initialized
INFO - 2016-11-13 00:18:43 --> Loader Class Initialized
INFO - 2016-11-13 00:18:43 --> Helper loaded: url_helper
INFO - 2016-11-13 00:18:43 --> Helper loaded: form_helper
INFO - 2016-11-13 00:18:43 --> Database Driver Class Initialized
INFO - 2016-11-13 00:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:18:43 --> Controller Class Initialized
INFO - 2016-11-13 00:18:43 --> Model Class Initialized
INFO - 2016-11-13 00:18:43 --> Model Class Initialized
INFO - 2016-11-13 00:18:43 --> Model Class Initialized
INFO - 2016-11-13 00:18:43 --> Model Class Initialized
INFO - 2016-11-13 00:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:18:43 --> Final output sent to browser
DEBUG - 2016-11-13 00:18:43 --> Total execution time: 0.3330
INFO - 2016-11-13 00:22:26 --> Config Class Initialized
INFO - 2016-11-13 00:22:26 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:22:26 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:22:26 --> Utf8 Class Initialized
INFO - 2016-11-13 00:22:26 --> URI Class Initialized
DEBUG - 2016-11-13 00:22:26 --> No URI present. Default controller set.
INFO - 2016-11-13 00:22:26 --> Router Class Initialized
INFO - 2016-11-13 00:22:26 --> Output Class Initialized
INFO - 2016-11-13 00:22:26 --> Security Class Initialized
DEBUG - 2016-11-13 00:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:22:26 --> Input Class Initialized
INFO - 2016-11-13 00:22:26 --> Language Class Initialized
INFO - 2016-11-13 00:22:26 --> Loader Class Initialized
INFO - 2016-11-13 00:22:26 --> Helper loaded: url_helper
INFO - 2016-11-13 00:22:26 --> Helper loaded: form_helper
INFO - 2016-11-13 00:22:26 --> Database Driver Class Initialized
INFO - 2016-11-13 00:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:22:26 --> Controller Class Initialized
INFO - 2016-11-13 00:22:26 --> Model Class Initialized
INFO - 2016-11-13 00:22:26 --> Model Class Initialized
INFO - 2016-11-13 00:22:26 --> Model Class Initialized
INFO - 2016-11-13 00:22:26 --> Model Class Initialized
INFO - 2016-11-13 00:22:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:22:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:22:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:22:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:22:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:22:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:22:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:22:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:22:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:22:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:22:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:22:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:22:26 --> Final output sent to browser
DEBUG - 2016-11-13 00:22:26 --> Total execution time: 0.3612
INFO - 2016-11-13 00:23:13 --> Config Class Initialized
INFO - 2016-11-13 00:23:13 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:23:13 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:23:13 --> Utf8 Class Initialized
INFO - 2016-11-13 00:23:13 --> URI Class Initialized
DEBUG - 2016-11-13 00:23:13 --> No URI present. Default controller set.
INFO - 2016-11-13 00:23:13 --> Router Class Initialized
INFO - 2016-11-13 00:23:13 --> Output Class Initialized
INFO - 2016-11-13 00:23:13 --> Security Class Initialized
DEBUG - 2016-11-13 00:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:23:13 --> Input Class Initialized
INFO - 2016-11-13 00:23:13 --> Language Class Initialized
INFO - 2016-11-13 00:23:13 --> Loader Class Initialized
INFO - 2016-11-13 00:23:13 --> Helper loaded: url_helper
INFO - 2016-11-13 00:23:13 --> Helper loaded: form_helper
INFO - 2016-11-13 00:23:13 --> Database Driver Class Initialized
INFO - 2016-11-13 00:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:23:13 --> Controller Class Initialized
INFO - 2016-11-13 00:23:13 --> Model Class Initialized
INFO - 2016-11-13 00:23:13 --> Model Class Initialized
INFO - 2016-11-13 00:23:13 --> Model Class Initialized
INFO - 2016-11-13 00:23:13 --> Model Class Initialized
INFO - 2016-11-13 00:23:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:23:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:23:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:23:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:23:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:23:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:23:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:23:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:23:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:23:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:23:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:23:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:23:14 --> Final output sent to browser
DEBUG - 2016-11-13 00:23:14 --> Total execution time: 0.3508
INFO - 2016-11-13 00:23:18 --> Config Class Initialized
INFO - 2016-11-13 00:23:18 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:23:18 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:23:18 --> Utf8 Class Initialized
INFO - 2016-11-13 00:23:18 --> URI Class Initialized
INFO - 2016-11-13 00:23:18 --> Router Class Initialized
INFO - 2016-11-13 00:23:18 --> Output Class Initialized
INFO - 2016-11-13 00:23:18 --> Security Class Initialized
DEBUG - 2016-11-13 00:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:23:18 --> Input Class Initialized
INFO - 2016-11-13 00:23:18 --> Language Class Initialized
INFO - 2016-11-13 00:23:18 --> Loader Class Initialized
INFO - 2016-11-13 00:23:18 --> Helper loaded: url_helper
INFO - 2016-11-13 00:23:18 --> Helper loaded: form_helper
INFO - 2016-11-13 00:23:18 --> Database Driver Class Initialized
INFO - 2016-11-13 00:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:23:18 --> Controller Class Initialized
INFO - 2016-11-13 00:23:18 --> Model Class Initialized
INFO - 2016-11-13 00:23:18 --> Final output sent to browser
DEBUG - 2016-11-13 00:23:18 --> Total execution time: 0.1852
INFO - 2016-11-13 00:26:39 --> Config Class Initialized
INFO - 2016-11-13 00:26:39 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:26:39 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:26:39 --> Utf8 Class Initialized
INFO - 2016-11-13 00:26:39 --> URI Class Initialized
DEBUG - 2016-11-13 00:26:39 --> No URI present. Default controller set.
INFO - 2016-11-13 00:26:39 --> Router Class Initialized
INFO - 2016-11-13 00:26:39 --> Output Class Initialized
INFO - 2016-11-13 00:26:39 --> Security Class Initialized
DEBUG - 2016-11-13 00:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:26:39 --> Input Class Initialized
INFO - 2016-11-13 00:26:39 --> Language Class Initialized
INFO - 2016-11-13 00:26:39 --> Loader Class Initialized
INFO - 2016-11-13 00:26:39 --> Helper loaded: url_helper
INFO - 2016-11-13 00:26:39 --> Helper loaded: form_helper
INFO - 2016-11-13 00:26:39 --> Database Driver Class Initialized
INFO - 2016-11-13 00:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:26:39 --> Controller Class Initialized
INFO - 2016-11-13 00:26:39 --> Model Class Initialized
INFO - 2016-11-13 00:26:39 --> Model Class Initialized
INFO - 2016-11-13 00:26:39 --> Model Class Initialized
INFO - 2016-11-13 00:26:39 --> Model Class Initialized
INFO - 2016-11-13 00:26:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:26:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:26:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:26:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:26:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:26:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:26:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:26:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:26:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:26:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:26:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:26:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:26:39 --> Final output sent to browser
DEBUG - 2016-11-13 00:26:39 --> Total execution time: 0.3652
INFO - 2016-11-13 00:34:57 --> Config Class Initialized
INFO - 2016-11-13 00:34:57 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:34:57 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:34:57 --> Utf8 Class Initialized
INFO - 2016-11-13 00:34:57 --> URI Class Initialized
DEBUG - 2016-11-13 00:34:57 --> No URI present. Default controller set.
INFO - 2016-11-13 00:34:57 --> Router Class Initialized
INFO - 2016-11-13 00:34:57 --> Output Class Initialized
INFO - 2016-11-13 00:34:57 --> Security Class Initialized
DEBUG - 2016-11-13 00:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:34:57 --> Input Class Initialized
INFO - 2016-11-13 00:34:57 --> Language Class Initialized
INFO - 2016-11-13 00:34:57 --> Loader Class Initialized
INFO - 2016-11-13 00:34:57 --> Helper loaded: url_helper
INFO - 2016-11-13 00:34:57 --> Helper loaded: form_helper
INFO - 2016-11-13 00:34:57 --> Database Driver Class Initialized
INFO - 2016-11-13 00:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:34:57 --> Controller Class Initialized
INFO - 2016-11-13 00:34:57 --> Model Class Initialized
INFO - 2016-11-13 00:34:57 --> Model Class Initialized
INFO - 2016-11-13 00:34:57 --> Model Class Initialized
INFO - 2016-11-13 00:34:57 --> Model Class Initialized
INFO - 2016-11-13 00:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:34:57 --> Final output sent to browser
DEBUG - 2016-11-13 00:34:57 --> Total execution time: 0.2851
INFO - 2016-11-13 00:37:27 --> Config Class Initialized
INFO - 2016-11-13 00:37:27 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:37:27 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:37:27 --> Utf8 Class Initialized
INFO - 2016-11-13 00:37:27 --> URI Class Initialized
DEBUG - 2016-11-13 00:37:27 --> No URI present. Default controller set.
INFO - 2016-11-13 00:37:27 --> Router Class Initialized
INFO - 2016-11-13 00:37:27 --> Output Class Initialized
INFO - 2016-11-13 00:37:27 --> Security Class Initialized
DEBUG - 2016-11-13 00:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:37:27 --> Input Class Initialized
INFO - 2016-11-13 00:37:27 --> Language Class Initialized
INFO - 2016-11-13 00:37:27 --> Loader Class Initialized
INFO - 2016-11-13 00:37:27 --> Helper loaded: url_helper
INFO - 2016-11-13 00:37:27 --> Helper loaded: form_helper
INFO - 2016-11-13 00:37:27 --> Database Driver Class Initialized
INFO - 2016-11-13 00:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:37:27 --> Controller Class Initialized
INFO - 2016-11-13 00:37:27 --> Model Class Initialized
INFO - 2016-11-13 00:37:27 --> Model Class Initialized
INFO - 2016-11-13 00:37:27 --> Model Class Initialized
INFO - 2016-11-13 00:37:27 --> Model Class Initialized
INFO - 2016-11-13 00:37:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:37:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:37:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:37:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:37:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:37:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:37:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:37:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:37:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:37:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:37:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:37:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:37:27 --> Final output sent to browser
DEBUG - 2016-11-13 00:37:27 --> Total execution time: 0.3164
INFO - 2016-11-13 00:37:59 --> Config Class Initialized
INFO - 2016-11-13 00:37:59 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:37:59 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:37:59 --> Utf8 Class Initialized
INFO - 2016-11-13 00:37:59 --> URI Class Initialized
DEBUG - 2016-11-13 00:37:59 --> No URI present. Default controller set.
INFO - 2016-11-13 00:37:59 --> Router Class Initialized
INFO - 2016-11-13 00:37:59 --> Output Class Initialized
INFO - 2016-11-13 00:37:59 --> Security Class Initialized
DEBUG - 2016-11-13 00:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:37:59 --> Input Class Initialized
INFO - 2016-11-13 00:37:59 --> Language Class Initialized
INFO - 2016-11-13 00:37:59 --> Loader Class Initialized
INFO - 2016-11-13 00:37:59 --> Helper loaded: url_helper
INFO - 2016-11-13 00:37:59 --> Helper loaded: form_helper
INFO - 2016-11-13 00:37:59 --> Database Driver Class Initialized
INFO - 2016-11-13 00:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:38:00 --> Controller Class Initialized
INFO - 2016-11-13 00:38:00 --> Model Class Initialized
INFO - 2016-11-13 00:38:00 --> Model Class Initialized
INFO - 2016-11-13 00:38:00 --> Model Class Initialized
INFO - 2016-11-13 00:38:00 --> Model Class Initialized
INFO - 2016-11-13 00:38:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:38:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:38:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:38:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:38:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:38:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:38:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:38:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:38:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:38:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:38:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:38:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:38:00 --> Final output sent to browser
DEBUG - 2016-11-13 00:38:00 --> Total execution time: 0.3195
INFO - 2016-11-13 00:40:42 --> Config Class Initialized
INFO - 2016-11-13 00:40:42 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:40:42 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:40:42 --> Utf8 Class Initialized
INFO - 2016-11-13 00:40:42 --> URI Class Initialized
DEBUG - 2016-11-13 00:40:42 --> No URI present. Default controller set.
INFO - 2016-11-13 00:40:42 --> Router Class Initialized
INFO - 2016-11-13 00:40:42 --> Output Class Initialized
INFO - 2016-11-13 00:40:42 --> Security Class Initialized
DEBUG - 2016-11-13 00:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:40:42 --> Input Class Initialized
INFO - 2016-11-13 00:40:42 --> Language Class Initialized
INFO - 2016-11-13 00:40:42 --> Loader Class Initialized
INFO - 2016-11-13 00:40:42 --> Helper loaded: url_helper
INFO - 2016-11-13 00:40:42 --> Helper loaded: form_helper
INFO - 2016-11-13 00:40:42 --> Database Driver Class Initialized
INFO - 2016-11-13 00:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:40:42 --> Controller Class Initialized
INFO - 2016-11-13 00:40:42 --> Model Class Initialized
INFO - 2016-11-13 00:40:42 --> Model Class Initialized
INFO - 2016-11-13 00:40:42 --> Model Class Initialized
INFO - 2016-11-13 00:40:42 --> Model Class Initialized
INFO - 2016-11-13 00:40:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:40:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:40:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:40:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:40:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:40:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:40:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:40:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:40:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:40:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:40:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:40:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:40:42 --> Final output sent to browser
DEBUG - 2016-11-13 00:40:42 --> Total execution time: 0.2949
INFO - 2016-11-13 00:40:48 --> Config Class Initialized
INFO - 2016-11-13 00:40:48 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:40:48 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:40:48 --> Utf8 Class Initialized
INFO - 2016-11-13 00:40:48 --> URI Class Initialized
INFO - 2016-11-13 00:40:48 --> Router Class Initialized
INFO - 2016-11-13 00:40:48 --> Output Class Initialized
INFO - 2016-11-13 00:40:48 --> Security Class Initialized
DEBUG - 2016-11-13 00:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:40:48 --> Input Class Initialized
INFO - 2016-11-13 00:40:48 --> Language Class Initialized
INFO - 2016-11-13 00:40:48 --> Loader Class Initialized
INFO - 2016-11-13 00:40:48 --> Helper loaded: url_helper
INFO - 2016-11-13 00:40:48 --> Helper loaded: form_helper
INFO - 2016-11-13 00:40:48 --> Database Driver Class Initialized
INFO - 2016-11-13 00:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:40:48 --> Controller Class Initialized
INFO - 2016-11-13 00:40:48 --> Model Class Initialized
INFO - 2016-11-13 00:40:48 --> Final output sent to browser
DEBUG - 2016-11-13 00:40:48 --> Total execution time: 0.1587
INFO - 2016-11-13 00:41:08 --> Config Class Initialized
INFO - 2016-11-13 00:41:08 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:41:08 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:41:08 --> Utf8 Class Initialized
INFO - 2016-11-13 00:41:08 --> URI Class Initialized
DEBUG - 2016-11-13 00:41:08 --> No URI present. Default controller set.
INFO - 2016-11-13 00:41:08 --> Router Class Initialized
INFO - 2016-11-13 00:41:08 --> Output Class Initialized
INFO - 2016-11-13 00:41:08 --> Security Class Initialized
DEBUG - 2016-11-13 00:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:41:08 --> Input Class Initialized
INFO - 2016-11-13 00:41:08 --> Language Class Initialized
INFO - 2016-11-13 00:41:08 --> Loader Class Initialized
INFO - 2016-11-13 00:41:08 --> Helper loaded: url_helper
INFO - 2016-11-13 00:41:08 --> Helper loaded: form_helper
INFO - 2016-11-13 00:41:08 --> Database Driver Class Initialized
INFO - 2016-11-13 00:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:41:08 --> Controller Class Initialized
INFO - 2016-11-13 00:41:08 --> Model Class Initialized
INFO - 2016-11-13 00:41:08 --> Model Class Initialized
INFO - 2016-11-13 00:41:08 --> Model Class Initialized
INFO - 2016-11-13 00:41:08 --> Model Class Initialized
INFO - 2016-11-13 00:41:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:41:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:41:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:41:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:41:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:41:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:41:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:41:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:41:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:41:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:41:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:41:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:41:08 --> Final output sent to browser
DEBUG - 2016-11-13 00:41:08 --> Total execution time: 0.2988
INFO - 2016-11-13 00:41:12 --> Config Class Initialized
INFO - 2016-11-13 00:41:12 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:41:12 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:41:12 --> Utf8 Class Initialized
INFO - 2016-11-13 00:41:12 --> URI Class Initialized
INFO - 2016-11-13 00:41:12 --> Router Class Initialized
INFO - 2016-11-13 00:41:12 --> Output Class Initialized
INFO - 2016-11-13 00:41:12 --> Security Class Initialized
DEBUG - 2016-11-13 00:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:41:12 --> Input Class Initialized
INFO - 2016-11-13 00:41:12 --> Language Class Initialized
INFO - 2016-11-13 00:41:12 --> Loader Class Initialized
INFO - 2016-11-13 00:41:12 --> Helper loaded: url_helper
INFO - 2016-11-13 00:41:12 --> Helper loaded: form_helper
INFO - 2016-11-13 00:41:12 --> Database Driver Class Initialized
INFO - 2016-11-13 00:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:41:12 --> Controller Class Initialized
INFO - 2016-11-13 00:41:12 --> Model Class Initialized
INFO - 2016-11-13 00:41:12 --> Final output sent to browser
DEBUG - 2016-11-13 00:41:12 --> Total execution time: 0.1548
INFO - 2016-11-13 00:42:02 --> Config Class Initialized
INFO - 2016-11-13 00:42:02 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:42:02 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:42:02 --> Utf8 Class Initialized
INFO - 2016-11-13 00:42:02 --> URI Class Initialized
DEBUG - 2016-11-13 00:42:02 --> No URI present. Default controller set.
INFO - 2016-11-13 00:42:02 --> Router Class Initialized
INFO - 2016-11-13 00:42:02 --> Output Class Initialized
INFO - 2016-11-13 00:42:02 --> Security Class Initialized
DEBUG - 2016-11-13 00:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:42:02 --> Input Class Initialized
INFO - 2016-11-13 00:42:02 --> Language Class Initialized
INFO - 2016-11-13 00:42:02 --> Loader Class Initialized
INFO - 2016-11-13 00:42:02 --> Helper loaded: url_helper
INFO - 2016-11-13 00:42:02 --> Helper loaded: form_helper
INFO - 2016-11-13 00:42:02 --> Database Driver Class Initialized
INFO - 2016-11-13 00:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:42:02 --> Controller Class Initialized
INFO - 2016-11-13 00:42:02 --> Model Class Initialized
INFO - 2016-11-13 00:42:02 --> Model Class Initialized
INFO - 2016-11-13 00:42:02 --> Model Class Initialized
INFO - 2016-11-13 00:42:02 --> Model Class Initialized
INFO - 2016-11-13 00:42:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:42:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:42:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:42:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:42:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:42:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:42:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:42:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:42:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:42:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:42:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:42:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:42:02 --> Final output sent to browser
DEBUG - 2016-11-13 00:42:02 --> Total execution time: 0.3329
INFO - 2016-11-13 00:42:13 --> Config Class Initialized
INFO - 2016-11-13 00:42:13 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:42:13 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:42:13 --> Utf8 Class Initialized
INFO - 2016-11-13 00:42:13 --> URI Class Initialized
DEBUG - 2016-11-13 00:42:13 --> No URI present. Default controller set.
INFO - 2016-11-13 00:42:13 --> Router Class Initialized
INFO - 2016-11-13 00:42:13 --> Output Class Initialized
INFO - 2016-11-13 00:42:13 --> Security Class Initialized
DEBUG - 2016-11-13 00:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:42:13 --> Input Class Initialized
INFO - 2016-11-13 00:42:13 --> Language Class Initialized
INFO - 2016-11-13 00:42:13 --> Loader Class Initialized
INFO - 2016-11-13 00:42:13 --> Helper loaded: url_helper
INFO - 2016-11-13 00:42:13 --> Helper loaded: form_helper
INFO - 2016-11-13 00:42:13 --> Database Driver Class Initialized
INFO - 2016-11-13 00:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:42:13 --> Controller Class Initialized
INFO - 2016-11-13 00:42:13 --> Model Class Initialized
INFO - 2016-11-13 00:42:13 --> Model Class Initialized
INFO - 2016-11-13 00:42:13 --> Model Class Initialized
INFO - 2016-11-13 00:42:14 --> Model Class Initialized
INFO - 2016-11-13 00:42:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:42:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:42:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:42:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:42:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:42:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:42:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:42:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:42:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:42:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:42:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:42:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:42:14 --> Final output sent to browser
DEBUG - 2016-11-13 00:42:14 --> Total execution time: 0.3298
INFO - 2016-11-13 00:42:32 --> Config Class Initialized
INFO - 2016-11-13 00:42:32 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:42:32 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:42:32 --> Utf8 Class Initialized
INFO - 2016-11-13 00:42:32 --> URI Class Initialized
DEBUG - 2016-11-13 00:42:32 --> No URI present. Default controller set.
INFO - 2016-11-13 00:42:32 --> Router Class Initialized
INFO - 2016-11-13 00:42:32 --> Output Class Initialized
INFO - 2016-11-13 00:42:32 --> Security Class Initialized
DEBUG - 2016-11-13 00:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:42:32 --> Input Class Initialized
INFO - 2016-11-13 00:42:32 --> Language Class Initialized
INFO - 2016-11-13 00:42:32 --> Loader Class Initialized
INFO - 2016-11-13 00:42:32 --> Helper loaded: url_helper
INFO - 2016-11-13 00:42:32 --> Helper loaded: form_helper
INFO - 2016-11-13 00:42:32 --> Database Driver Class Initialized
INFO - 2016-11-13 00:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:42:32 --> Controller Class Initialized
INFO - 2016-11-13 00:42:32 --> Model Class Initialized
INFO - 2016-11-13 00:42:32 --> Model Class Initialized
INFO - 2016-11-13 00:42:32 --> Model Class Initialized
INFO - 2016-11-13 00:42:32 --> Model Class Initialized
INFO - 2016-11-13 00:42:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:42:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:42:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:42:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:42:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:42:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:42:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:42:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:42:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:42:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:42:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:42:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:42:32 --> Final output sent to browser
DEBUG - 2016-11-13 00:42:32 --> Total execution time: 0.3096
INFO - 2016-11-13 00:42:38 --> Config Class Initialized
INFO - 2016-11-13 00:42:38 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:42:38 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:42:38 --> Utf8 Class Initialized
INFO - 2016-11-13 00:42:38 --> URI Class Initialized
INFO - 2016-11-13 00:42:38 --> Router Class Initialized
INFO - 2016-11-13 00:42:38 --> Output Class Initialized
INFO - 2016-11-13 00:42:38 --> Security Class Initialized
DEBUG - 2016-11-13 00:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:42:38 --> Input Class Initialized
INFO - 2016-11-13 00:42:38 --> Language Class Initialized
INFO - 2016-11-13 00:42:38 --> Loader Class Initialized
INFO - 2016-11-13 00:42:38 --> Helper loaded: url_helper
INFO - 2016-11-13 00:42:38 --> Helper loaded: form_helper
INFO - 2016-11-13 00:42:38 --> Database Driver Class Initialized
INFO - 2016-11-13 00:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:42:38 --> Controller Class Initialized
INFO - 2016-11-13 00:42:38 --> Model Class Initialized
INFO - 2016-11-13 00:42:38 --> Final output sent to browser
DEBUG - 2016-11-13 00:42:38 --> Total execution time: 0.1670
INFO - 2016-11-13 00:42:59 --> Config Class Initialized
INFO - 2016-11-13 00:42:59 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:42:59 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:42:59 --> Utf8 Class Initialized
INFO - 2016-11-13 00:42:59 --> URI Class Initialized
DEBUG - 2016-11-13 00:42:59 --> No URI present. Default controller set.
INFO - 2016-11-13 00:42:59 --> Router Class Initialized
INFO - 2016-11-13 00:42:59 --> Output Class Initialized
INFO - 2016-11-13 00:42:59 --> Security Class Initialized
DEBUG - 2016-11-13 00:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:42:59 --> Input Class Initialized
INFO - 2016-11-13 00:42:59 --> Language Class Initialized
INFO - 2016-11-13 00:42:59 --> Loader Class Initialized
INFO - 2016-11-13 00:42:59 --> Helper loaded: url_helper
INFO - 2016-11-13 00:42:59 --> Helper loaded: form_helper
INFO - 2016-11-13 00:42:59 --> Database Driver Class Initialized
INFO - 2016-11-13 00:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:42:59 --> Controller Class Initialized
INFO - 2016-11-13 00:42:59 --> Model Class Initialized
INFO - 2016-11-13 00:42:59 --> Model Class Initialized
INFO - 2016-11-13 00:42:59 --> Model Class Initialized
INFO - 2016-11-13 00:42:59 --> Model Class Initialized
INFO - 2016-11-13 00:42:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:42:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:43:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:43:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:43:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:43:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:43:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:43:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:43:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:43:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:43:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:43:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:43:00 --> Final output sent to browser
DEBUG - 2016-11-13 00:43:00 --> Total execution time: 0.3040
INFO - 2016-11-13 00:48:39 --> Config Class Initialized
INFO - 2016-11-13 00:48:39 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:48:39 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:48:39 --> Utf8 Class Initialized
INFO - 2016-11-13 00:48:39 --> URI Class Initialized
DEBUG - 2016-11-13 00:48:39 --> No URI present. Default controller set.
INFO - 2016-11-13 00:48:39 --> Router Class Initialized
INFO - 2016-11-13 00:48:39 --> Output Class Initialized
INFO - 2016-11-13 00:48:39 --> Security Class Initialized
DEBUG - 2016-11-13 00:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:48:39 --> Input Class Initialized
INFO - 2016-11-13 00:48:39 --> Language Class Initialized
INFO - 2016-11-13 00:48:39 --> Loader Class Initialized
INFO - 2016-11-13 00:48:39 --> Helper loaded: url_helper
INFO - 2016-11-13 00:48:39 --> Helper loaded: form_helper
INFO - 2016-11-13 00:48:39 --> Database Driver Class Initialized
INFO - 2016-11-13 00:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:48:39 --> Controller Class Initialized
INFO - 2016-11-13 00:48:39 --> Model Class Initialized
INFO - 2016-11-13 00:48:39 --> Model Class Initialized
INFO - 2016-11-13 00:48:39 --> Model Class Initialized
INFO - 2016-11-13 00:48:39 --> Model Class Initialized
INFO - 2016-11-13 00:48:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:48:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:48:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:48:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:48:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:48:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:48:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:48:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:48:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:48:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:48:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:48:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:48:39 --> Final output sent to browser
DEBUG - 2016-11-13 00:48:39 --> Total execution time: 0.3290
INFO - 2016-11-13 00:48:45 --> Config Class Initialized
INFO - 2016-11-13 00:48:45 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:48:45 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:48:45 --> Utf8 Class Initialized
INFO - 2016-11-13 00:48:45 --> URI Class Initialized
INFO - 2016-11-13 00:48:45 --> Router Class Initialized
INFO - 2016-11-13 00:48:45 --> Output Class Initialized
INFO - 2016-11-13 00:48:45 --> Security Class Initialized
DEBUG - 2016-11-13 00:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:48:45 --> Input Class Initialized
INFO - 2016-11-13 00:48:45 --> Language Class Initialized
INFO - 2016-11-13 00:48:45 --> Loader Class Initialized
INFO - 2016-11-13 00:48:45 --> Helper loaded: url_helper
INFO - 2016-11-13 00:48:45 --> Helper loaded: form_helper
INFO - 2016-11-13 00:48:45 --> Database Driver Class Initialized
INFO - 2016-11-13 00:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:48:45 --> Controller Class Initialized
INFO - 2016-11-13 00:48:45 --> Model Class Initialized
INFO - 2016-11-13 00:48:54 --> Config Class Initialized
INFO - 2016-11-13 00:48:54 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:48:54 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:48:54 --> Utf8 Class Initialized
INFO - 2016-11-13 00:48:54 --> URI Class Initialized
DEBUG - 2016-11-13 00:48:54 --> No URI present. Default controller set.
INFO - 2016-11-13 00:48:54 --> Router Class Initialized
INFO - 2016-11-13 00:48:54 --> Output Class Initialized
INFO - 2016-11-13 00:48:54 --> Security Class Initialized
DEBUG - 2016-11-13 00:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:48:54 --> Input Class Initialized
INFO - 2016-11-13 00:48:54 --> Language Class Initialized
INFO - 2016-11-13 00:48:54 --> Loader Class Initialized
INFO - 2016-11-13 00:48:54 --> Helper loaded: url_helper
INFO - 2016-11-13 00:48:54 --> Helper loaded: form_helper
INFO - 2016-11-13 00:48:54 --> Database Driver Class Initialized
INFO - 2016-11-13 00:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:48:55 --> Controller Class Initialized
INFO - 2016-11-13 00:48:55 --> Model Class Initialized
INFO - 2016-11-13 00:48:55 --> Model Class Initialized
INFO - 2016-11-13 00:48:55 --> Model Class Initialized
INFO - 2016-11-13 00:48:55 --> Model Class Initialized
INFO - 2016-11-13 00:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:48:55 --> Final output sent to browser
DEBUG - 2016-11-13 00:48:55 --> Total execution time: 0.3454
INFO - 2016-11-13 00:49:28 --> Config Class Initialized
INFO - 2016-11-13 00:49:28 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:49:28 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:49:28 --> Utf8 Class Initialized
INFO - 2016-11-13 00:49:28 --> URI Class Initialized
INFO - 2016-11-13 00:49:28 --> Router Class Initialized
INFO - 2016-11-13 00:49:28 --> Output Class Initialized
INFO - 2016-11-13 00:49:28 --> Security Class Initialized
DEBUG - 2016-11-13 00:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:49:28 --> Input Class Initialized
INFO - 2016-11-13 00:49:28 --> Language Class Initialized
INFO - 2016-11-13 00:49:28 --> Loader Class Initialized
INFO - 2016-11-13 00:49:28 --> Helper loaded: url_helper
INFO - 2016-11-13 00:49:28 --> Helper loaded: form_helper
INFO - 2016-11-13 00:49:28 --> Database Driver Class Initialized
INFO - 2016-11-13 00:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:49:28 --> Controller Class Initialized
INFO - 2016-11-13 00:49:28 --> Model Class Initialized
INFO - 2016-11-13 00:49:28 --> Final output sent to browser
DEBUG - 2016-11-13 00:49:28 --> Total execution time: 0.1760
INFO - 2016-11-13 00:51:17 --> Config Class Initialized
INFO - 2016-11-13 00:51:17 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:51:17 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:51:17 --> Utf8 Class Initialized
INFO - 2016-11-13 00:51:17 --> URI Class Initialized
DEBUG - 2016-11-13 00:51:17 --> No URI present. Default controller set.
INFO - 2016-11-13 00:51:17 --> Router Class Initialized
INFO - 2016-11-13 00:51:17 --> Output Class Initialized
INFO - 2016-11-13 00:51:17 --> Security Class Initialized
DEBUG - 2016-11-13 00:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:51:18 --> Input Class Initialized
INFO - 2016-11-13 00:51:18 --> Language Class Initialized
INFO - 2016-11-13 00:51:18 --> Loader Class Initialized
INFO - 2016-11-13 00:51:18 --> Helper loaded: url_helper
INFO - 2016-11-13 00:51:18 --> Helper loaded: form_helper
INFO - 2016-11-13 00:51:18 --> Database Driver Class Initialized
INFO - 2016-11-13 00:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:51:18 --> Controller Class Initialized
INFO - 2016-11-13 00:51:18 --> Model Class Initialized
INFO - 2016-11-13 00:51:18 --> Model Class Initialized
INFO - 2016-11-13 00:51:18 --> Model Class Initialized
INFO - 2016-11-13 00:51:18 --> Model Class Initialized
INFO - 2016-11-13 00:51:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:51:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:51:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:51:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:51:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:51:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:51:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:51:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:51:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:51:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:51:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:51:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:51:18 --> Final output sent to browser
DEBUG - 2016-11-13 00:51:18 --> Total execution time: 0.3183
INFO - 2016-11-13 00:51:24 --> Config Class Initialized
INFO - 2016-11-13 00:51:24 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:51:24 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:51:24 --> Utf8 Class Initialized
INFO - 2016-11-13 00:51:24 --> URI Class Initialized
INFO - 2016-11-13 00:51:24 --> Router Class Initialized
INFO - 2016-11-13 00:51:24 --> Output Class Initialized
INFO - 2016-11-13 00:51:24 --> Security Class Initialized
DEBUG - 2016-11-13 00:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:51:24 --> Input Class Initialized
INFO - 2016-11-13 00:51:24 --> Language Class Initialized
INFO - 2016-11-13 00:51:24 --> Loader Class Initialized
INFO - 2016-11-13 00:51:24 --> Helper loaded: url_helper
INFO - 2016-11-13 00:51:24 --> Helper loaded: form_helper
INFO - 2016-11-13 00:51:24 --> Database Driver Class Initialized
INFO - 2016-11-13 00:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:51:24 --> Controller Class Initialized
INFO - 2016-11-13 00:51:24 --> Model Class Initialized
INFO - 2016-11-13 00:51:24 --> Final output sent to browser
DEBUG - 2016-11-13 00:51:24 --> Total execution time: 0.1980
INFO - 2016-11-13 00:51:29 --> Config Class Initialized
INFO - 2016-11-13 00:51:29 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:51:29 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:51:29 --> Utf8 Class Initialized
INFO - 2016-11-13 00:51:29 --> URI Class Initialized
DEBUG - 2016-11-13 00:51:29 --> No URI present. Default controller set.
INFO - 2016-11-13 00:51:29 --> Router Class Initialized
INFO - 2016-11-13 00:51:29 --> Output Class Initialized
INFO - 2016-11-13 00:51:29 --> Security Class Initialized
DEBUG - 2016-11-13 00:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:51:30 --> Input Class Initialized
INFO - 2016-11-13 00:51:30 --> Language Class Initialized
INFO - 2016-11-13 00:51:30 --> Loader Class Initialized
INFO - 2016-11-13 00:51:30 --> Helper loaded: url_helper
INFO - 2016-11-13 00:51:30 --> Helper loaded: form_helper
INFO - 2016-11-13 00:51:30 --> Database Driver Class Initialized
INFO - 2016-11-13 00:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:51:30 --> Controller Class Initialized
INFO - 2016-11-13 00:51:30 --> Model Class Initialized
INFO - 2016-11-13 00:51:30 --> Model Class Initialized
INFO - 2016-11-13 00:51:30 --> Model Class Initialized
INFO - 2016-11-13 00:51:30 --> Model Class Initialized
INFO - 2016-11-13 00:51:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:51:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:51:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:51:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:51:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:51:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:51:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:51:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:51:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:51:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:51:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:51:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:51:30 --> Final output sent to browser
DEBUG - 2016-11-13 00:51:30 --> Total execution time: 0.3659
INFO - 2016-11-13 00:52:23 --> Config Class Initialized
INFO - 2016-11-13 00:52:23 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:52:23 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:52:23 --> Utf8 Class Initialized
INFO - 2016-11-13 00:52:23 --> URI Class Initialized
DEBUG - 2016-11-13 00:52:23 --> No URI present. Default controller set.
INFO - 2016-11-13 00:52:23 --> Router Class Initialized
INFO - 2016-11-13 00:52:23 --> Output Class Initialized
INFO - 2016-11-13 00:52:23 --> Security Class Initialized
DEBUG - 2016-11-13 00:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:52:23 --> Input Class Initialized
INFO - 2016-11-13 00:52:23 --> Language Class Initialized
INFO - 2016-11-13 00:52:23 --> Loader Class Initialized
INFO - 2016-11-13 00:52:23 --> Helper loaded: url_helper
INFO - 2016-11-13 00:52:23 --> Helper loaded: form_helper
INFO - 2016-11-13 00:52:23 --> Database Driver Class Initialized
INFO - 2016-11-13 00:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:52:23 --> Controller Class Initialized
INFO - 2016-11-13 00:52:23 --> Model Class Initialized
INFO - 2016-11-13 00:52:23 --> Model Class Initialized
INFO - 2016-11-13 00:52:23 --> Model Class Initialized
INFO - 2016-11-13 00:52:23 --> Model Class Initialized
INFO - 2016-11-13 00:52:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:52:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:52:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:52:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:52:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:52:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:52:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:52:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:52:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:52:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:52:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:52:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:52:24 --> Final output sent to browser
DEBUG - 2016-11-13 00:52:24 --> Total execution time: 0.3351
INFO - 2016-11-13 00:52:29 --> Config Class Initialized
INFO - 2016-11-13 00:52:29 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:52:29 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:52:29 --> Utf8 Class Initialized
INFO - 2016-11-13 00:52:29 --> URI Class Initialized
INFO - 2016-11-13 00:52:29 --> Router Class Initialized
INFO - 2016-11-13 00:52:29 --> Output Class Initialized
INFO - 2016-11-13 00:52:29 --> Security Class Initialized
DEBUG - 2016-11-13 00:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:52:29 --> Input Class Initialized
INFO - 2016-11-13 00:52:29 --> Language Class Initialized
INFO - 2016-11-13 00:52:29 --> Loader Class Initialized
INFO - 2016-11-13 00:52:29 --> Helper loaded: url_helper
INFO - 2016-11-13 00:52:29 --> Helper loaded: form_helper
INFO - 2016-11-13 00:52:29 --> Database Driver Class Initialized
INFO - 2016-11-13 00:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:52:29 --> Controller Class Initialized
INFO - 2016-11-13 00:52:29 --> Model Class Initialized
INFO - 2016-11-13 00:52:29 --> Final output sent to browser
DEBUG - 2016-11-13 00:52:29 --> Total execution time: 0.1707
INFO - 2016-11-13 00:52:42 --> Config Class Initialized
INFO - 2016-11-13 00:52:42 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:52:42 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:52:42 --> Utf8 Class Initialized
INFO - 2016-11-13 00:52:42 --> URI Class Initialized
DEBUG - 2016-11-13 00:52:42 --> No URI present. Default controller set.
INFO - 2016-11-13 00:52:42 --> Router Class Initialized
INFO - 2016-11-13 00:52:42 --> Output Class Initialized
INFO - 2016-11-13 00:52:42 --> Security Class Initialized
DEBUG - 2016-11-13 00:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:52:42 --> Input Class Initialized
INFO - 2016-11-13 00:52:42 --> Language Class Initialized
INFO - 2016-11-13 00:52:42 --> Loader Class Initialized
INFO - 2016-11-13 00:52:42 --> Helper loaded: url_helper
INFO - 2016-11-13 00:52:42 --> Helper loaded: form_helper
INFO - 2016-11-13 00:52:42 --> Database Driver Class Initialized
INFO - 2016-11-13 00:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:52:42 --> Controller Class Initialized
INFO - 2016-11-13 00:52:42 --> Model Class Initialized
INFO - 2016-11-13 00:52:42 --> Model Class Initialized
INFO - 2016-11-13 00:52:42 --> Model Class Initialized
INFO - 2016-11-13 00:52:42 --> Model Class Initialized
INFO - 2016-11-13 00:52:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:52:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:52:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:52:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:52:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:52:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:52:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:52:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:52:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:52:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:52:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:52:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:52:42 --> Final output sent to browser
DEBUG - 2016-11-13 00:52:42 --> Total execution time: 0.3472
INFO - 2016-11-13 00:52:48 --> Config Class Initialized
INFO - 2016-11-13 00:52:48 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:52:48 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:52:48 --> Utf8 Class Initialized
INFO - 2016-11-13 00:52:48 --> URI Class Initialized
INFO - 2016-11-13 00:52:48 --> Router Class Initialized
INFO - 2016-11-13 00:52:48 --> Output Class Initialized
INFO - 2016-11-13 00:52:48 --> Security Class Initialized
DEBUG - 2016-11-13 00:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:52:48 --> Input Class Initialized
INFO - 2016-11-13 00:52:48 --> Language Class Initialized
INFO - 2016-11-13 00:52:48 --> Loader Class Initialized
INFO - 2016-11-13 00:52:48 --> Helper loaded: url_helper
INFO - 2016-11-13 00:52:48 --> Helper loaded: form_helper
INFO - 2016-11-13 00:52:48 --> Database Driver Class Initialized
INFO - 2016-11-13 00:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:52:48 --> Controller Class Initialized
INFO - 2016-11-13 00:52:48 --> Model Class Initialized
INFO - 2016-11-13 00:52:48 --> Final output sent to browser
DEBUG - 2016-11-13 00:52:48 --> Total execution time: 0.1742
INFO - 2016-11-13 00:54:43 --> Config Class Initialized
INFO - 2016-11-13 00:54:43 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:54:43 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:54:43 --> Utf8 Class Initialized
INFO - 2016-11-13 00:54:43 --> URI Class Initialized
DEBUG - 2016-11-13 00:54:43 --> No URI present. Default controller set.
INFO - 2016-11-13 00:54:43 --> Router Class Initialized
INFO - 2016-11-13 00:54:43 --> Output Class Initialized
INFO - 2016-11-13 00:54:43 --> Security Class Initialized
DEBUG - 2016-11-13 00:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:54:43 --> Input Class Initialized
INFO - 2016-11-13 00:54:43 --> Language Class Initialized
INFO - 2016-11-13 00:54:43 --> Loader Class Initialized
INFO - 2016-11-13 00:54:43 --> Helper loaded: url_helper
INFO - 2016-11-13 00:54:43 --> Helper loaded: form_helper
INFO - 2016-11-13 00:54:43 --> Database Driver Class Initialized
INFO - 2016-11-13 00:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:54:43 --> Controller Class Initialized
INFO - 2016-11-13 00:54:43 --> Model Class Initialized
INFO - 2016-11-13 00:54:43 --> Model Class Initialized
INFO - 2016-11-13 00:54:43 --> Model Class Initialized
INFO - 2016-11-13 00:54:43 --> Model Class Initialized
INFO - 2016-11-13 00:54:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:54:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:54:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:54:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:54:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:54:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:54:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:54:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:54:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:54:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:54:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:54:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:54:43 --> Final output sent to browser
DEBUG - 2016-11-13 00:54:43 --> Total execution time: 0.3575
INFO - 2016-11-13 00:55:33 --> Config Class Initialized
INFO - 2016-11-13 00:55:33 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:55:33 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:55:33 --> Utf8 Class Initialized
INFO - 2016-11-13 00:55:33 --> URI Class Initialized
DEBUG - 2016-11-13 00:55:33 --> No URI present. Default controller set.
INFO - 2016-11-13 00:55:33 --> Router Class Initialized
INFO - 2016-11-13 00:55:33 --> Output Class Initialized
INFO - 2016-11-13 00:55:33 --> Security Class Initialized
DEBUG - 2016-11-13 00:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:55:33 --> Input Class Initialized
INFO - 2016-11-13 00:55:33 --> Language Class Initialized
INFO - 2016-11-13 00:55:33 --> Loader Class Initialized
INFO - 2016-11-13 00:55:33 --> Helper loaded: url_helper
INFO - 2016-11-13 00:55:33 --> Helper loaded: form_helper
INFO - 2016-11-13 00:55:33 --> Database Driver Class Initialized
INFO - 2016-11-13 00:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:55:33 --> Controller Class Initialized
INFO - 2016-11-13 00:55:33 --> Model Class Initialized
INFO - 2016-11-13 00:55:33 --> Model Class Initialized
INFO - 2016-11-13 00:55:33 --> Model Class Initialized
INFO - 2016-11-13 00:55:33 --> Model Class Initialized
INFO - 2016-11-13 00:55:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:55:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:55:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:55:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:55:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:55:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:55:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:55:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:55:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:55:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:55:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:55:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:55:33 --> Final output sent to browser
DEBUG - 2016-11-13 00:55:33 --> Total execution time: 0.3446
INFO - 2016-11-13 00:55:36 --> Config Class Initialized
INFO - 2016-11-13 00:55:36 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:55:36 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:55:36 --> Utf8 Class Initialized
INFO - 2016-11-13 00:55:36 --> URI Class Initialized
INFO - 2016-11-13 00:55:36 --> Router Class Initialized
INFO - 2016-11-13 00:55:36 --> Output Class Initialized
INFO - 2016-11-13 00:55:36 --> Security Class Initialized
DEBUG - 2016-11-13 00:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:55:36 --> Input Class Initialized
INFO - 2016-11-13 00:55:36 --> Language Class Initialized
INFO - 2016-11-13 00:55:36 --> Loader Class Initialized
INFO - 2016-11-13 00:55:36 --> Helper loaded: url_helper
INFO - 2016-11-13 00:55:36 --> Helper loaded: form_helper
INFO - 2016-11-13 00:55:36 --> Database Driver Class Initialized
INFO - 2016-11-13 00:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:55:36 --> Controller Class Initialized
INFO - 2016-11-13 00:55:36 --> Model Class Initialized
INFO - 2016-11-13 00:55:36 --> Final output sent to browser
DEBUG - 2016-11-13 00:55:36 --> Total execution time: 0.1787
INFO - 2016-11-13 00:55:42 --> Config Class Initialized
INFO - 2016-11-13 00:55:42 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:55:42 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:55:43 --> Utf8 Class Initialized
INFO - 2016-11-13 00:55:43 --> URI Class Initialized
DEBUG - 2016-11-13 00:55:43 --> No URI present. Default controller set.
INFO - 2016-11-13 00:55:43 --> Router Class Initialized
INFO - 2016-11-13 00:55:43 --> Output Class Initialized
INFO - 2016-11-13 00:55:43 --> Security Class Initialized
DEBUG - 2016-11-13 00:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:55:43 --> Input Class Initialized
INFO - 2016-11-13 00:55:43 --> Language Class Initialized
INFO - 2016-11-13 00:55:43 --> Loader Class Initialized
INFO - 2016-11-13 00:55:43 --> Helper loaded: url_helper
INFO - 2016-11-13 00:55:43 --> Helper loaded: form_helper
INFO - 2016-11-13 00:55:43 --> Database Driver Class Initialized
INFO - 2016-11-13 00:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:55:43 --> Controller Class Initialized
INFO - 2016-11-13 00:55:43 --> Model Class Initialized
INFO - 2016-11-13 00:55:43 --> Model Class Initialized
INFO - 2016-11-13 00:55:43 --> Model Class Initialized
INFO - 2016-11-13 00:55:43 --> Model Class Initialized
INFO - 2016-11-13 00:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:55:43 --> Final output sent to browser
DEBUG - 2016-11-13 00:55:43 --> Total execution time: 0.3714
INFO - 2016-11-13 00:56:20 --> Config Class Initialized
INFO - 2016-11-13 00:56:20 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:56:20 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:56:20 --> Utf8 Class Initialized
INFO - 2016-11-13 00:56:20 --> URI Class Initialized
INFO - 2016-11-13 00:56:20 --> Router Class Initialized
INFO - 2016-11-13 00:56:20 --> Output Class Initialized
INFO - 2016-11-13 00:56:20 --> Security Class Initialized
DEBUG - 2016-11-13 00:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:56:20 --> Input Class Initialized
INFO - 2016-11-13 00:56:20 --> Language Class Initialized
INFO - 2016-11-13 00:56:20 --> Loader Class Initialized
INFO - 2016-11-13 00:56:20 --> Helper loaded: url_helper
INFO - 2016-11-13 00:56:20 --> Helper loaded: form_helper
INFO - 2016-11-13 00:56:20 --> Database Driver Class Initialized
INFO - 2016-11-13 00:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:56:20 --> Controller Class Initialized
INFO - 2016-11-13 00:56:20 --> Model Class Initialized
INFO - 2016-11-13 00:56:20 --> Final output sent to browser
DEBUG - 2016-11-13 00:56:20 --> Total execution time: 0.1794
INFO - 2016-11-13 00:56:24 --> Config Class Initialized
INFO - 2016-11-13 00:56:24 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:56:24 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:56:24 --> Utf8 Class Initialized
INFO - 2016-11-13 00:56:24 --> URI Class Initialized
DEBUG - 2016-11-13 00:56:24 --> No URI present. Default controller set.
INFO - 2016-11-13 00:56:24 --> Router Class Initialized
INFO - 2016-11-13 00:56:24 --> Output Class Initialized
INFO - 2016-11-13 00:56:24 --> Security Class Initialized
DEBUG - 2016-11-13 00:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:56:24 --> Input Class Initialized
INFO - 2016-11-13 00:56:24 --> Language Class Initialized
INFO - 2016-11-13 00:56:24 --> Loader Class Initialized
INFO - 2016-11-13 00:56:24 --> Helper loaded: url_helper
INFO - 2016-11-13 00:56:24 --> Helper loaded: form_helper
INFO - 2016-11-13 00:56:24 --> Database Driver Class Initialized
INFO - 2016-11-13 00:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:56:24 --> Controller Class Initialized
INFO - 2016-11-13 00:56:24 --> Model Class Initialized
INFO - 2016-11-13 00:56:24 --> Model Class Initialized
INFO - 2016-11-13 00:56:24 --> Model Class Initialized
INFO - 2016-11-13 00:56:24 --> Model Class Initialized
INFO - 2016-11-13 00:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:56:24 --> Final output sent to browser
DEBUG - 2016-11-13 00:56:24 --> Total execution time: 0.3857
INFO - 2016-11-13 00:56:33 --> Config Class Initialized
INFO - 2016-11-13 00:56:33 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:56:33 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:56:33 --> Utf8 Class Initialized
INFO - 2016-11-13 00:56:33 --> URI Class Initialized
INFO - 2016-11-13 00:56:33 --> Router Class Initialized
INFO - 2016-11-13 00:56:33 --> Output Class Initialized
INFO - 2016-11-13 00:56:33 --> Security Class Initialized
DEBUG - 2016-11-13 00:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:56:33 --> Input Class Initialized
INFO - 2016-11-13 00:56:33 --> Language Class Initialized
INFO - 2016-11-13 00:56:33 --> Loader Class Initialized
INFO - 2016-11-13 00:56:33 --> Helper loaded: url_helper
INFO - 2016-11-13 00:56:33 --> Helper loaded: form_helper
INFO - 2016-11-13 00:56:33 --> Database Driver Class Initialized
INFO - 2016-11-13 00:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:56:33 --> Controller Class Initialized
INFO - 2016-11-13 00:56:33 --> Model Class Initialized
INFO - 2016-11-13 00:56:33 --> Final output sent to browser
DEBUG - 2016-11-13 00:56:33 --> Total execution time: 0.1917
INFO - 2016-11-13 00:56:34 --> Config Class Initialized
INFO - 2016-11-13 00:56:34 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:56:34 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:56:35 --> Utf8 Class Initialized
INFO - 2016-11-13 00:56:35 --> URI Class Initialized
DEBUG - 2016-11-13 00:56:35 --> No URI present. Default controller set.
INFO - 2016-11-13 00:56:35 --> Router Class Initialized
INFO - 2016-11-13 00:56:35 --> Output Class Initialized
INFO - 2016-11-13 00:56:35 --> Security Class Initialized
DEBUG - 2016-11-13 00:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:56:35 --> Input Class Initialized
INFO - 2016-11-13 00:56:35 --> Language Class Initialized
INFO - 2016-11-13 00:56:35 --> Loader Class Initialized
INFO - 2016-11-13 00:56:35 --> Helper loaded: url_helper
INFO - 2016-11-13 00:56:35 --> Helper loaded: form_helper
INFO - 2016-11-13 00:56:35 --> Database Driver Class Initialized
INFO - 2016-11-13 00:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:56:35 --> Controller Class Initialized
INFO - 2016-11-13 00:56:35 --> Model Class Initialized
INFO - 2016-11-13 00:56:35 --> Model Class Initialized
INFO - 2016-11-13 00:56:35 --> Model Class Initialized
INFO - 2016-11-13 00:56:35 --> Model Class Initialized
INFO - 2016-11-13 00:56:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:56:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:56:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:56:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:56:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:56:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:56:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:56:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:56:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:56:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:56:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:56:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:56:35 --> Final output sent to browser
DEBUG - 2016-11-13 00:56:35 --> Total execution time: 0.3916
INFO - 2016-11-13 00:56:42 --> Config Class Initialized
INFO - 2016-11-13 00:56:42 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:56:42 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:56:42 --> Utf8 Class Initialized
INFO - 2016-11-13 00:56:42 --> URI Class Initialized
INFO - 2016-11-13 00:56:42 --> Router Class Initialized
INFO - 2016-11-13 00:56:42 --> Output Class Initialized
INFO - 2016-11-13 00:56:42 --> Security Class Initialized
DEBUG - 2016-11-13 00:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:56:42 --> Input Class Initialized
INFO - 2016-11-13 00:56:42 --> Language Class Initialized
INFO - 2016-11-13 00:56:42 --> Loader Class Initialized
INFO - 2016-11-13 00:56:42 --> Helper loaded: url_helper
INFO - 2016-11-13 00:56:42 --> Helper loaded: form_helper
INFO - 2016-11-13 00:56:42 --> Database Driver Class Initialized
INFO - 2016-11-13 00:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:56:42 --> Controller Class Initialized
INFO - 2016-11-13 00:56:42 --> Model Class Initialized
INFO - 2016-11-13 00:56:42 --> Final output sent to browser
DEBUG - 2016-11-13 00:56:42 --> Total execution time: 0.1779
INFO - 2016-11-13 00:56:49 --> Config Class Initialized
INFO - 2016-11-13 00:56:49 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:56:49 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:56:49 --> Utf8 Class Initialized
INFO - 2016-11-13 00:56:49 --> URI Class Initialized
DEBUG - 2016-11-13 00:56:49 --> No URI present. Default controller set.
INFO - 2016-11-13 00:56:49 --> Router Class Initialized
INFO - 2016-11-13 00:56:49 --> Output Class Initialized
INFO - 2016-11-13 00:56:49 --> Security Class Initialized
DEBUG - 2016-11-13 00:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:56:49 --> Input Class Initialized
INFO - 2016-11-13 00:56:49 --> Language Class Initialized
INFO - 2016-11-13 00:56:49 --> Loader Class Initialized
INFO - 2016-11-13 00:56:49 --> Helper loaded: url_helper
INFO - 2016-11-13 00:56:49 --> Helper loaded: form_helper
INFO - 2016-11-13 00:56:49 --> Database Driver Class Initialized
INFO - 2016-11-13 00:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:56:49 --> Controller Class Initialized
INFO - 2016-11-13 00:56:49 --> Model Class Initialized
INFO - 2016-11-13 00:56:49 --> Model Class Initialized
INFO - 2016-11-13 00:56:49 --> Model Class Initialized
INFO - 2016-11-13 00:56:49 --> Model Class Initialized
INFO - 2016-11-13 00:56:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:56:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:56:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:56:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:56:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:56:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:56:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:56:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:56:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:56:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:56:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:56:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:56:49 --> Final output sent to browser
DEBUG - 2016-11-13 00:56:49 --> Total execution time: 0.3750
INFO - 2016-11-13 00:59:31 --> Config Class Initialized
INFO - 2016-11-13 00:59:31 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:59:31 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:59:31 --> Utf8 Class Initialized
INFO - 2016-11-13 00:59:31 --> URI Class Initialized
DEBUG - 2016-11-13 00:59:31 --> No URI present. Default controller set.
INFO - 2016-11-13 00:59:31 --> Router Class Initialized
INFO - 2016-11-13 00:59:31 --> Output Class Initialized
INFO - 2016-11-13 00:59:31 --> Security Class Initialized
DEBUG - 2016-11-13 00:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:59:31 --> Input Class Initialized
INFO - 2016-11-13 00:59:31 --> Language Class Initialized
INFO - 2016-11-13 00:59:31 --> Loader Class Initialized
INFO - 2016-11-13 00:59:31 --> Helper loaded: url_helper
INFO - 2016-11-13 00:59:31 --> Helper loaded: form_helper
INFO - 2016-11-13 00:59:31 --> Database Driver Class Initialized
INFO - 2016-11-13 00:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:59:31 --> Controller Class Initialized
INFO - 2016-11-13 00:59:31 --> Model Class Initialized
INFO - 2016-11-13 00:59:31 --> Model Class Initialized
INFO - 2016-11-13 00:59:31 --> Model Class Initialized
INFO - 2016-11-13 00:59:31 --> Model Class Initialized
INFO - 2016-11-13 00:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 00:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 00:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 00:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 00:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 00:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 00:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 00:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 00:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 00:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 00:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 00:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 00:59:31 --> Final output sent to browser
DEBUG - 2016-11-13 00:59:31 --> Total execution time: 0.3682
INFO - 2016-11-13 00:59:36 --> Config Class Initialized
INFO - 2016-11-13 00:59:36 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:59:36 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:59:36 --> Utf8 Class Initialized
INFO - 2016-11-13 00:59:36 --> URI Class Initialized
INFO - 2016-11-13 00:59:36 --> Router Class Initialized
INFO - 2016-11-13 00:59:36 --> Output Class Initialized
INFO - 2016-11-13 00:59:36 --> Security Class Initialized
DEBUG - 2016-11-13 00:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:59:36 --> Input Class Initialized
INFO - 2016-11-13 00:59:36 --> Language Class Initialized
INFO - 2016-11-13 00:59:36 --> Loader Class Initialized
INFO - 2016-11-13 00:59:36 --> Helper loaded: url_helper
INFO - 2016-11-13 00:59:36 --> Helper loaded: form_helper
INFO - 2016-11-13 00:59:36 --> Database Driver Class Initialized
INFO - 2016-11-13 00:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:59:36 --> Controller Class Initialized
INFO - 2016-11-13 00:59:36 --> Model Class Initialized
INFO - 2016-11-13 00:59:37 --> Form Validation Class Initialized
INFO - 2016-11-13 00:59:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 00:59:37 --> Final output sent to browser
DEBUG - 2016-11-13 00:59:37 --> Total execution time: 0.4166
INFO - 2016-11-13 00:59:51 --> Config Class Initialized
INFO - 2016-11-13 00:59:51 --> Config Class Initialized
INFO - 2016-11-13 00:59:51 --> Hooks Class Initialized
INFO - 2016-11-13 00:59:51 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:59:51 --> UTF-8 Support Enabled
DEBUG - 2016-11-13 00:59:51 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:59:51 --> Utf8 Class Initialized
INFO - 2016-11-13 00:59:51 --> Utf8 Class Initialized
INFO - 2016-11-13 00:59:51 --> URI Class Initialized
INFO - 2016-11-13 00:59:51 --> URI Class Initialized
INFO - 2016-11-13 00:59:51 --> Router Class Initialized
INFO - 2016-11-13 00:59:51 --> Router Class Initialized
INFO - 2016-11-13 00:59:51 --> Output Class Initialized
INFO - 2016-11-13 00:59:51 --> Output Class Initialized
INFO - 2016-11-13 00:59:51 --> Security Class Initialized
INFO - 2016-11-13 00:59:51 --> Security Class Initialized
DEBUG - 2016-11-13 00:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-13 00:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:59:51 --> Input Class Initialized
INFO - 2016-11-13 00:59:51 --> Input Class Initialized
INFO - 2016-11-13 00:59:51 --> Language Class Initialized
INFO - 2016-11-13 00:59:51 --> Language Class Initialized
INFO - 2016-11-13 00:59:51 --> Loader Class Initialized
INFO - 2016-11-13 00:59:51 --> Helper loaded: url_helper
INFO - 2016-11-13 00:59:51 --> Helper loaded: form_helper
INFO - 2016-11-13 00:59:51 --> Database Driver Class Initialized
INFO - 2016-11-13 00:59:51 --> Loader Class Initialized
INFO - 2016-11-13 00:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:59:51 --> Controller Class Initialized
INFO - 2016-11-13 00:59:51 --> Helper loaded: url_helper
INFO - 2016-11-13 00:59:51 --> Model Class Initialized
INFO - 2016-11-13 00:59:51 --> Helper loaded: form_helper
INFO - 2016-11-13 00:59:51 --> Form Validation Class Initialized
INFO - 2016-11-13 00:59:51 --> Database Driver Class Initialized
INFO - 2016-11-13 00:59:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 00:59:51 --> Final output sent to browser
DEBUG - 2016-11-13 00:59:51 --> Total execution time: 0.2968
INFO - 2016-11-13 00:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:59:51 --> Controller Class Initialized
INFO - 2016-11-13 00:59:51 --> Model Class Initialized
INFO - 2016-11-13 00:59:51 --> Form Validation Class Initialized
INFO - 2016-11-13 00:59:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 00:59:51 --> Final output sent to browser
DEBUG - 2016-11-13 00:59:51 --> Total execution time: 0.3450
INFO - 2016-11-13 00:59:55 --> Config Class Initialized
INFO - 2016-11-13 00:59:55 --> Config Class Initialized
INFO - 2016-11-13 00:59:55 --> Hooks Class Initialized
INFO - 2016-11-13 00:59:55 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:59:55 --> UTF-8 Support Enabled
DEBUG - 2016-11-13 00:59:55 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:59:55 --> Utf8 Class Initialized
INFO - 2016-11-13 00:59:55 --> Utf8 Class Initialized
INFO - 2016-11-13 00:59:55 --> URI Class Initialized
INFO - 2016-11-13 00:59:55 --> URI Class Initialized
INFO - 2016-11-13 00:59:55 --> Router Class Initialized
INFO - 2016-11-13 00:59:55 --> Router Class Initialized
INFO - 2016-11-13 00:59:55 --> Output Class Initialized
INFO - 2016-11-13 00:59:55 --> Output Class Initialized
INFO - 2016-11-13 00:59:55 --> Security Class Initialized
INFO - 2016-11-13 00:59:55 --> Security Class Initialized
DEBUG - 2016-11-13 00:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-13 00:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:59:55 --> Input Class Initialized
INFO - 2016-11-13 00:59:55 --> Input Class Initialized
INFO - 2016-11-13 00:59:55 --> Language Class Initialized
INFO - 2016-11-13 00:59:55 --> Language Class Initialized
INFO - 2016-11-13 00:59:55 --> Loader Class Initialized
INFO - 2016-11-13 00:59:55 --> Loader Class Initialized
INFO - 2016-11-13 00:59:55 --> Helper loaded: url_helper
INFO - 2016-11-13 00:59:55 --> Helper loaded: url_helper
INFO - 2016-11-13 00:59:55 --> Helper loaded: form_helper
INFO - 2016-11-13 00:59:55 --> Helper loaded: form_helper
INFO - 2016-11-13 00:59:55 --> Database Driver Class Initialized
INFO - 2016-11-13 00:59:55 --> Database Driver Class Initialized
INFO - 2016-11-13 00:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:59:55 --> Controller Class Initialized
INFO - 2016-11-13 00:59:55 --> Model Class Initialized
INFO - 2016-11-13 00:59:55 --> Form Validation Class Initialized
INFO - 2016-11-13 00:59:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 00:59:55 --> Final output sent to browser
DEBUG - 2016-11-13 00:59:55 --> Total execution time: 0.3521
INFO - 2016-11-13 00:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:59:55 --> Controller Class Initialized
INFO - 2016-11-13 00:59:55 --> Model Class Initialized
INFO - 2016-11-13 00:59:55 --> Form Validation Class Initialized
INFO - 2016-11-13 00:59:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 00:59:55 --> Final output sent to browser
DEBUG - 2016-11-13 00:59:55 --> Total execution time: 0.4050
INFO - 2016-11-13 01:03:42 --> Config Class Initialized
INFO - 2016-11-13 01:03:42 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:03:42 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:03:42 --> Utf8 Class Initialized
INFO - 2016-11-13 01:03:42 --> URI Class Initialized
INFO - 2016-11-13 01:03:42 --> Router Class Initialized
INFO - 2016-11-13 01:03:42 --> Output Class Initialized
INFO - 2016-11-13 01:03:42 --> Security Class Initialized
DEBUG - 2016-11-13 01:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:03:42 --> Input Class Initialized
INFO - 2016-11-13 01:03:42 --> Language Class Initialized
INFO - 2016-11-13 01:03:42 --> Loader Class Initialized
INFO - 2016-11-13 01:03:42 --> Helper loaded: url_helper
INFO - 2016-11-13 01:03:42 --> Helper loaded: form_helper
INFO - 2016-11-13 01:03:42 --> Database Driver Class Initialized
INFO - 2016-11-13 01:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:03:42 --> Controller Class Initialized
INFO - 2016-11-13 01:03:42 --> Model Class Initialized
INFO - 2016-11-13 01:03:42 --> Form Validation Class Initialized
INFO - 2016-11-13 01:03:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 01:03:42 --> Final output sent to browser
DEBUG - 2016-11-13 01:03:42 --> Total execution time: 0.2523
INFO - 2016-11-13 01:03:49 --> Config Class Initialized
INFO - 2016-11-13 01:03:49 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:03:49 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:03:49 --> Utf8 Class Initialized
INFO - 2016-11-13 01:03:49 --> URI Class Initialized
DEBUG - 2016-11-13 01:03:49 --> No URI present. Default controller set.
INFO - 2016-11-13 01:03:49 --> Router Class Initialized
INFO - 2016-11-13 01:03:49 --> Output Class Initialized
INFO - 2016-11-13 01:03:49 --> Security Class Initialized
DEBUG - 2016-11-13 01:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:03:49 --> Input Class Initialized
INFO - 2016-11-13 01:03:49 --> Language Class Initialized
INFO - 2016-11-13 01:03:49 --> Loader Class Initialized
INFO - 2016-11-13 01:03:49 --> Helper loaded: url_helper
INFO - 2016-11-13 01:03:49 --> Helper loaded: form_helper
INFO - 2016-11-13 01:03:49 --> Database Driver Class Initialized
INFO - 2016-11-13 01:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:03:49 --> Controller Class Initialized
INFO - 2016-11-13 01:03:49 --> Model Class Initialized
INFO - 2016-11-13 01:03:49 --> Model Class Initialized
INFO - 2016-11-13 01:03:49 --> Model Class Initialized
INFO - 2016-11-13 01:03:49 --> Model Class Initialized
INFO - 2016-11-13 01:03:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:03:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:03:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:03:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:03:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:03:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:03:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:03:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:03:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:03:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:03:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:03:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:03:49 --> Final output sent to browser
DEBUG - 2016-11-13 01:03:49 --> Total execution time: 0.3841
INFO - 2016-11-13 01:04:37 --> Config Class Initialized
INFO - 2016-11-13 01:04:37 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:04:37 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:04:37 --> Utf8 Class Initialized
INFO - 2016-11-13 01:04:37 --> URI Class Initialized
DEBUG - 2016-11-13 01:04:37 --> No URI present. Default controller set.
INFO - 2016-11-13 01:04:37 --> Router Class Initialized
INFO - 2016-11-13 01:04:37 --> Output Class Initialized
INFO - 2016-11-13 01:04:37 --> Security Class Initialized
DEBUG - 2016-11-13 01:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:04:37 --> Input Class Initialized
INFO - 2016-11-13 01:04:37 --> Language Class Initialized
INFO - 2016-11-13 01:04:37 --> Loader Class Initialized
INFO - 2016-11-13 01:04:37 --> Helper loaded: url_helper
INFO - 2016-11-13 01:04:37 --> Helper loaded: form_helper
INFO - 2016-11-13 01:04:37 --> Database Driver Class Initialized
INFO - 2016-11-13 01:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:04:37 --> Controller Class Initialized
INFO - 2016-11-13 01:04:37 --> Model Class Initialized
INFO - 2016-11-13 01:04:37 --> Model Class Initialized
INFO - 2016-11-13 01:04:37 --> Model Class Initialized
INFO - 2016-11-13 01:04:37 --> Model Class Initialized
INFO - 2016-11-13 01:04:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:04:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:04:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:04:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:04:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:04:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:04:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:04:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:04:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:04:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:04:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:04:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:04:37 --> Final output sent to browser
DEBUG - 2016-11-13 01:04:37 --> Total execution time: 0.3547
INFO - 2016-11-13 01:04:48 --> Config Class Initialized
INFO - 2016-11-13 01:04:48 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:04:48 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:04:48 --> Utf8 Class Initialized
INFO - 2016-11-13 01:04:48 --> URI Class Initialized
INFO - 2016-11-13 01:04:48 --> Router Class Initialized
INFO - 2016-11-13 01:04:48 --> Output Class Initialized
INFO - 2016-11-13 01:04:48 --> Security Class Initialized
DEBUG - 2016-11-13 01:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:04:48 --> Input Class Initialized
INFO - 2016-11-13 01:04:48 --> Language Class Initialized
INFO - 2016-11-13 01:04:48 --> Loader Class Initialized
INFO - 2016-11-13 01:04:48 --> Helper loaded: url_helper
INFO - 2016-11-13 01:04:48 --> Helper loaded: form_helper
INFO - 2016-11-13 01:04:48 --> Database Driver Class Initialized
INFO - 2016-11-13 01:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:04:48 --> Controller Class Initialized
INFO - 2016-11-13 01:04:48 --> Model Class Initialized
INFO - 2016-11-13 01:04:48 --> Form Validation Class Initialized
INFO - 2016-11-13 01:04:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 01:04:48 --> Final output sent to browser
DEBUG - 2016-11-13 01:04:48 --> Total execution time: 0.1930
INFO - 2016-11-13 01:04:50 --> Config Class Initialized
INFO - 2016-11-13 01:04:50 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:04:50 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:04:50 --> Utf8 Class Initialized
INFO - 2016-11-13 01:04:50 --> URI Class Initialized
INFO - 2016-11-13 01:04:50 --> Router Class Initialized
INFO - 2016-11-13 01:04:50 --> Output Class Initialized
INFO - 2016-11-13 01:04:50 --> Security Class Initialized
DEBUG - 2016-11-13 01:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:04:50 --> Input Class Initialized
INFO - 2016-11-13 01:04:50 --> Language Class Initialized
INFO - 2016-11-13 01:04:50 --> Loader Class Initialized
INFO - 2016-11-13 01:04:50 --> Helper loaded: url_helper
INFO - 2016-11-13 01:04:50 --> Helper loaded: form_helper
INFO - 2016-11-13 01:04:50 --> Database Driver Class Initialized
INFO - 2016-11-13 01:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:04:50 --> Controller Class Initialized
INFO - 2016-11-13 01:04:50 --> Model Class Initialized
INFO - 2016-11-13 01:04:50 --> Form Validation Class Initialized
INFO - 2016-11-13 01:04:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 01:04:50 --> Final output sent to browser
DEBUG - 2016-11-13 01:04:50 --> Total execution time: 0.2801
INFO - 2016-11-13 01:04:55 --> Config Class Initialized
INFO - 2016-11-13 01:04:55 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:04:55 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:04:55 --> Utf8 Class Initialized
INFO - 2016-11-13 01:04:55 --> URI Class Initialized
DEBUG - 2016-11-13 01:04:55 --> No URI present. Default controller set.
INFO - 2016-11-13 01:04:55 --> Router Class Initialized
INFO - 2016-11-13 01:04:55 --> Output Class Initialized
INFO - 2016-11-13 01:04:55 --> Security Class Initialized
DEBUG - 2016-11-13 01:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:04:55 --> Input Class Initialized
INFO - 2016-11-13 01:04:55 --> Language Class Initialized
INFO - 2016-11-13 01:04:55 --> Loader Class Initialized
INFO - 2016-11-13 01:04:55 --> Helper loaded: url_helper
INFO - 2016-11-13 01:04:55 --> Helper loaded: form_helper
INFO - 2016-11-13 01:04:55 --> Database Driver Class Initialized
INFO - 2016-11-13 01:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:04:55 --> Controller Class Initialized
INFO - 2016-11-13 01:04:55 --> Model Class Initialized
INFO - 2016-11-13 01:04:55 --> Model Class Initialized
INFO - 2016-11-13 01:04:55 --> Model Class Initialized
INFO - 2016-11-13 01:04:55 --> Model Class Initialized
INFO - 2016-11-13 01:04:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:04:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:04:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:04:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:04:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:04:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:04:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:04:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:04:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:04:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:04:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:04:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:04:55 --> Final output sent to browser
DEBUG - 2016-11-13 01:04:55 --> Total execution time: 0.3995
INFO - 2016-11-13 01:04:58 --> Config Class Initialized
INFO - 2016-11-13 01:04:58 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:04:58 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:04:58 --> Utf8 Class Initialized
INFO - 2016-11-13 01:04:58 --> URI Class Initialized
INFO - 2016-11-13 01:04:58 --> Router Class Initialized
INFO - 2016-11-13 01:04:58 --> Output Class Initialized
INFO - 2016-11-13 01:04:58 --> Security Class Initialized
DEBUG - 2016-11-13 01:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:04:58 --> Input Class Initialized
INFO - 2016-11-13 01:04:58 --> Language Class Initialized
INFO - 2016-11-13 01:04:58 --> Loader Class Initialized
INFO - 2016-11-13 01:04:58 --> Helper loaded: url_helper
INFO - 2016-11-13 01:04:58 --> Helper loaded: form_helper
INFO - 2016-11-13 01:04:58 --> Database Driver Class Initialized
INFO - 2016-11-13 01:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:04:58 --> Controller Class Initialized
INFO - 2016-11-13 01:04:58 --> Model Class Initialized
INFO - 2016-11-13 01:04:58 --> Form Validation Class Initialized
INFO - 2016-11-13 01:04:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 01:04:58 --> Final output sent to browser
DEBUG - 2016-11-13 01:04:58 --> Total execution time: 0.2070
INFO - 2016-11-13 01:05:09 --> Config Class Initialized
INFO - 2016-11-13 01:05:09 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:05:09 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:05:09 --> Utf8 Class Initialized
INFO - 2016-11-13 01:05:09 --> URI Class Initialized
INFO - 2016-11-13 01:05:09 --> Router Class Initialized
INFO - 2016-11-13 01:05:09 --> Output Class Initialized
INFO - 2016-11-13 01:05:09 --> Security Class Initialized
DEBUG - 2016-11-13 01:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:05:09 --> Input Class Initialized
INFO - 2016-11-13 01:05:09 --> Language Class Initialized
INFO - 2016-11-13 01:05:09 --> Loader Class Initialized
INFO - 2016-11-13 01:05:09 --> Helper loaded: url_helper
INFO - 2016-11-13 01:05:09 --> Helper loaded: form_helper
INFO - 2016-11-13 01:05:09 --> Database Driver Class Initialized
INFO - 2016-11-13 01:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:05:09 --> Controller Class Initialized
INFO - 2016-11-13 01:05:09 --> Model Class Initialized
INFO - 2016-11-13 01:05:09 --> Form Validation Class Initialized
INFO - 2016-11-13 01:05:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 01:05:09 --> Final output sent to browser
DEBUG - 2016-11-13 01:05:09 --> Total execution time: 0.1956
INFO - 2016-11-13 01:05:34 --> Config Class Initialized
INFO - 2016-11-13 01:05:34 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:05:34 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:05:34 --> Utf8 Class Initialized
INFO - 2016-11-13 01:05:34 --> URI Class Initialized
INFO - 2016-11-13 01:05:35 --> Router Class Initialized
INFO - 2016-11-13 01:05:35 --> Output Class Initialized
INFO - 2016-11-13 01:05:35 --> Security Class Initialized
DEBUG - 2016-11-13 01:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:05:35 --> Input Class Initialized
INFO - 2016-11-13 01:05:35 --> Language Class Initialized
INFO - 2016-11-13 01:05:35 --> Loader Class Initialized
INFO - 2016-11-13 01:05:35 --> Helper loaded: url_helper
INFO - 2016-11-13 01:05:35 --> Helper loaded: form_helper
INFO - 2016-11-13 01:05:35 --> Database Driver Class Initialized
INFO - 2016-11-13 01:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:05:35 --> Controller Class Initialized
INFO - 2016-11-13 01:05:35 --> Model Class Initialized
INFO - 2016-11-13 01:05:35 --> Form Validation Class Initialized
INFO - 2016-11-13 01:05:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 01:05:35 --> Final output sent to browser
DEBUG - 2016-11-13 01:05:35 --> Total execution time: 0.2390
INFO - 2016-11-13 01:05:41 --> Config Class Initialized
INFO - 2016-11-13 01:05:41 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:05:41 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:05:41 --> Utf8 Class Initialized
INFO - 2016-11-13 01:05:41 --> URI Class Initialized
DEBUG - 2016-11-13 01:05:41 --> No URI present. Default controller set.
INFO - 2016-11-13 01:05:41 --> Router Class Initialized
INFO - 2016-11-13 01:05:41 --> Output Class Initialized
INFO - 2016-11-13 01:05:41 --> Security Class Initialized
DEBUG - 2016-11-13 01:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:05:41 --> Input Class Initialized
INFO - 2016-11-13 01:05:41 --> Language Class Initialized
INFO - 2016-11-13 01:05:41 --> Loader Class Initialized
INFO - 2016-11-13 01:05:41 --> Helper loaded: url_helper
INFO - 2016-11-13 01:05:41 --> Helper loaded: form_helper
INFO - 2016-11-13 01:05:41 --> Database Driver Class Initialized
INFO - 2016-11-13 01:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:05:41 --> Controller Class Initialized
INFO - 2016-11-13 01:05:41 --> Model Class Initialized
INFO - 2016-11-13 01:05:41 --> Model Class Initialized
INFO - 2016-11-13 01:05:41 --> Model Class Initialized
INFO - 2016-11-13 01:05:41 --> Model Class Initialized
INFO - 2016-11-13 01:05:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:05:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:05:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:05:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:05:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:05:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:05:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:05:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:05:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:05:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:05:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:05:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:05:41 --> Final output sent to browser
DEBUG - 2016-11-13 01:05:41 --> Total execution time: 0.3748
INFO - 2016-11-13 01:06:12 --> Config Class Initialized
INFO - 2016-11-13 01:06:12 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:06:12 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:06:12 --> Utf8 Class Initialized
INFO - 2016-11-13 01:06:12 --> URI Class Initialized
DEBUG - 2016-11-13 01:06:12 --> No URI present. Default controller set.
INFO - 2016-11-13 01:06:12 --> Router Class Initialized
INFO - 2016-11-13 01:06:12 --> Output Class Initialized
INFO - 2016-11-13 01:06:12 --> Security Class Initialized
DEBUG - 2016-11-13 01:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:06:13 --> Input Class Initialized
INFO - 2016-11-13 01:06:13 --> Language Class Initialized
INFO - 2016-11-13 01:06:13 --> Loader Class Initialized
INFO - 2016-11-13 01:06:13 --> Helper loaded: url_helper
INFO - 2016-11-13 01:06:13 --> Helper loaded: form_helper
INFO - 2016-11-13 01:06:13 --> Database Driver Class Initialized
INFO - 2016-11-13 01:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:06:13 --> Controller Class Initialized
INFO - 2016-11-13 01:06:13 --> Model Class Initialized
INFO - 2016-11-13 01:06:13 --> Model Class Initialized
INFO - 2016-11-13 01:06:13 --> Model Class Initialized
INFO - 2016-11-13 01:06:13 --> Model Class Initialized
INFO - 2016-11-13 01:06:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:06:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:06:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:06:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:06:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:06:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:06:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:06:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:06:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:06:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:06:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:06:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:06:13 --> Final output sent to browser
DEBUG - 2016-11-13 01:06:13 --> Total execution time: 0.3781
INFO - 2016-11-13 01:06:17 --> Config Class Initialized
INFO - 2016-11-13 01:06:17 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:06:17 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:06:17 --> Utf8 Class Initialized
INFO - 2016-11-13 01:06:17 --> URI Class Initialized
INFO - 2016-11-13 01:06:17 --> Router Class Initialized
INFO - 2016-11-13 01:06:17 --> Output Class Initialized
INFO - 2016-11-13 01:06:17 --> Security Class Initialized
DEBUG - 2016-11-13 01:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:06:17 --> Input Class Initialized
INFO - 2016-11-13 01:06:17 --> Language Class Initialized
INFO - 2016-11-13 01:06:17 --> Loader Class Initialized
INFO - 2016-11-13 01:06:17 --> Helper loaded: url_helper
INFO - 2016-11-13 01:06:17 --> Helper loaded: form_helper
INFO - 2016-11-13 01:06:17 --> Database Driver Class Initialized
INFO - 2016-11-13 01:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:06:17 --> Controller Class Initialized
INFO - 2016-11-13 01:06:17 --> Model Class Initialized
INFO - 2016-11-13 01:06:17 --> Form Validation Class Initialized
INFO - 2016-11-13 01:06:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 01:06:17 --> Final output sent to browser
DEBUG - 2016-11-13 01:06:17 --> Total execution time: 0.1966
INFO - 2016-11-13 01:06:24 --> Config Class Initialized
INFO - 2016-11-13 01:06:24 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:06:24 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:06:24 --> Utf8 Class Initialized
INFO - 2016-11-13 01:06:24 --> URI Class Initialized
INFO - 2016-11-13 01:06:24 --> Router Class Initialized
INFO - 2016-11-13 01:06:24 --> Output Class Initialized
INFO - 2016-11-13 01:06:24 --> Security Class Initialized
DEBUG - 2016-11-13 01:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:06:24 --> Input Class Initialized
INFO - 2016-11-13 01:06:24 --> Language Class Initialized
INFO - 2016-11-13 01:06:24 --> Loader Class Initialized
INFO - 2016-11-13 01:06:24 --> Helper loaded: url_helper
INFO - 2016-11-13 01:06:24 --> Helper loaded: form_helper
INFO - 2016-11-13 01:06:24 --> Database Driver Class Initialized
INFO - 2016-11-13 01:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:06:24 --> Controller Class Initialized
INFO - 2016-11-13 01:06:24 --> Model Class Initialized
INFO - 2016-11-13 01:06:24 --> Form Validation Class Initialized
INFO - 2016-11-13 01:06:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 01:06:24 --> Final output sent to browser
DEBUG - 2016-11-13 01:06:24 --> Total execution time: 0.2125
INFO - 2016-11-13 01:07:39 --> Config Class Initialized
INFO - 2016-11-13 01:07:39 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:07:39 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:07:39 --> Utf8 Class Initialized
INFO - 2016-11-13 01:07:39 --> URI Class Initialized
DEBUG - 2016-11-13 01:07:39 --> No URI present. Default controller set.
INFO - 2016-11-13 01:07:39 --> Router Class Initialized
INFO - 2016-11-13 01:07:39 --> Output Class Initialized
INFO - 2016-11-13 01:07:39 --> Security Class Initialized
DEBUG - 2016-11-13 01:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:07:39 --> Input Class Initialized
INFO - 2016-11-13 01:07:39 --> Language Class Initialized
INFO - 2016-11-13 01:07:39 --> Loader Class Initialized
INFO - 2016-11-13 01:07:39 --> Helper loaded: url_helper
INFO - 2016-11-13 01:07:39 --> Helper loaded: form_helper
INFO - 2016-11-13 01:07:39 --> Database Driver Class Initialized
INFO - 2016-11-13 01:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:07:39 --> Controller Class Initialized
INFO - 2016-11-13 01:07:39 --> Model Class Initialized
INFO - 2016-11-13 01:07:39 --> Model Class Initialized
INFO - 2016-11-13 01:07:39 --> Model Class Initialized
INFO - 2016-11-13 01:07:39 --> Model Class Initialized
INFO - 2016-11-13 01:07:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:07:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:07:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:07:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:07:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:07:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:07:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:07:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:07:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:07:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:07:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:07:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:07:39 --> Final output sent to browser
DEBUG - 2016-11-13 01:07:39 --> Total execution time: 0.3752
INFO - 2016-11-13 01:07:44 --> Config Class Initialized
INFO - 2016-11-13 01:07:44 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:07:44 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:07:44 --> Utf8 Class Initialized
INFO - 2016-11-13 01:07:44 --> URI Class Initialized
INFO - 2016-11-13 01:07:44 --> Router Class Initialized
INFO - 2016-11-13 01:07:44 --> Output Class Initialized
INFO - 2016-11-13 01:07:44 --> Security Class Initialized
DEBUG - 2016-11-13 01:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:07:44 --> Input Class Initialized
INFO - 2016-11-13 01:07:44 --> Language Class Initialized
INFO - 2016-11-13 01:07:44 --> Loader Class Initialized
INFO - 2016-11-13 01:07:44 --> Helper loaded: url_helper
INFO - 2016-11-13 01:07:44 --> Helper loaded: form_helper
INFO - 2016-11-13 01:07:44 --> Database Driver Class Initialized
INFO - 2016-11-13 01:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:07:44 --> Controller Class Initialized
INFO - 2016-11-13 01:07:44 --> Model Class Initialized
INFO - 2016-11-13 01:07:44 --> Form Validation Class Initialized
INFO - 2016-11-13 01:07:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 01:07:44 --> Final output sent to browser
DEBUG - 2016-11-13 01:07:44 --> Total execution time: 0.2123
INFO - 2016-11-13 01:09:12 --> Config Class Initialized
INFO - 2016-11-13 01:09:12 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:09:12 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:09:12 --> Utf8 Class Initialized
INFO - 2016-11-13 01:09:12 --> URI Class Initialized
DEBUG - 2016-11-13 01:09:12 --> No URI present. Default controller set.
INFO - 2016-11-13 01:09:12 --> Router Class Initialized
INFO - 2016-11-13 01:09:12 --> Output Class Initialized
INFO - 2016-11-13 01:09:12 --> Security Class Initialized
DEBUG - 2016-11-13 01:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:09:12 --> Input Class Initialized
INFO - 2016-11-13 01:09:12 --> Language Class Initialized
INFO - 2016-11-13 01:09:12 --> Loader Class Initialized
INFO - 2016-11-13 01:09:12 --> Helper loaded: url_helper
INFO - 2016-11-13 01:09:12 --> Helper loaded: form_helper
INFO - 2016-11-13 01:09:12 --> Database Driver Class Initialized
INFO - 2016-11-13 01:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:09:12 --> Controller Class Initialized
INFO - 2016-11-13 01:09:12 --> Model Class Initialized
INFO - 2016-11-13 01:09:13 --> Model Class Initialized
INFO - 2016-11-13 01:09:13 --> Model Class Initialized
INFO - 2016-11-13 01:09:13 --> Model Class Initialized
INFO - 2016-11-13 01:09:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:09:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:09:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:09:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:09:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:09:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:09:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:09:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:09:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:09:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:09:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:09:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:09:13 --> Final output sent to browser
DEBUG - 2016-11-13 01:09:13 --> Total execution time: 0.3919
INFO - 2016-11-13 01:09:18 --> Config Class Initialized
INFO - 2016-11-13 01:09:18 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:09:18 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:09:18 --> Utf8 Class Initialized
INFO - 2016-11-13 01:09:18 --> URI Class Initialized
INFO - 2016-11-13 01:09:18 --> Router Class Initialized
INFO - 2016-11-13 01:09:18 --> Output Class Initialized
INFO - 2016-11-13 01:09:18 --> Security Class Initialized
DEBUG - 2016-11-13 01:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:09:18 --> Input Class Initialized
INFO - 2016-11-13 01:09:18 --> Language Class Initialized
INFO - 2016-11-13 01:09:18 --> Loader Class Initialized
INFO - 2016-11-13 01:09:18 --> Helper loaded: url_helper
INFO - 2016-11-13 01:09:18 --> Helper loaded: form_helper
INFO - 2016-11-13 01:09:18 --> Database Driver Class Initialized
INFO - 2016-11-13 01:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:09:18 --> Controller Class Initialized
INFO - 2016-11-13 01:09:18 --> Model Class Initialized
INFO - 2016-11-13 01:09:18 --> Form Validation Class Initialized
INFO - 2016-11-13 01:09:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 01:09:18 --> Final output sent to browser
DEBUG - 2016-11-13 01:09:18 --> Total execution time: 0.2114
INFO - 2016-11-13 01:09:25 --> Config Class Initialized
INFO - 2016-11-13 01:09:25 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:09:25 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:09:25 --> Utf8 Class Initialized
INFO - 2016-11-13 01:09:25 --> URI Class Initialized
DEBUG - 2016-11-13 01:09:25 --> No URI present. Default controller set.
INFO - 2016-11-13 01:09:25 --> Router Class Initialized
INFO - 2016-11-13 01:09:25 --> Output Class Initialized
INFO - 2016-11-13 01:09:25 --> Security Class Initialized
DEBUG - 2016-11-13 01:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:09:25 --> Input Class Initialized
INFO - 2016-11-13 01:09:25 --> Language Class Initialized
INFO - 2016-11-13 01:09:25 --> Loader Class Initialized
INFO - 2016-11-13 01:09:25 --> Helper loaded: url_helper
INFO - 2016-11-13 01:09:25 --> Helper loaded: form_helper
INFO - 2016-11-13 01:09:25 --> Database Driver Class Initialized
INFO - 2016-11-13 01:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:09:25 --> Controller Class Initialized
INFO - 2016-11-13 01:09:25 --> Model Class Initialized
INFO - 2016-11-13 01:09:25 --> Model Class Initialized
INFO - 2016-11-13 01:09:25 --> Model Class Initialized
INFO - 2016-11-13 01:09:25 --> Model Class Initialized
INFO - 2016-11-13 01:09:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:09:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:09:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:09:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:09:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:09:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:09:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:09:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:09:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:09:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:09:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:09:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:09:25 --> Final output sent to browser
DEBUG - 2016-11-13 01:09:25 --> Total execution time: 0.3822
INFO - 2016-11-13 01:10:15 --> Config Class Initialized
INFO - 2016-11-13 01:10:15 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:10:15 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:10:15 --> Utf8 Class Initialized
INFO - 2016-11-13 01:10:15 --> URI Class Initialized
DEBUG - 2016-11-13 01:10:15 --> No URI present. Default controller set.
INFO - 2016-11-13 01:10:15 --> Router Class Initialized
INFO - 2016-11-13 01:10:15 --> Output Class Initialized
INFO - 2016-11-13 01:10:15 --> Security Class Initialized
DEBUG - 2016-11-13 01:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:10:15 --> Input Class Initialized
INFO - 2016-11-13 01:10:15 --> Language Class Initialized
INFO - 2016-11-13 01:10:15 --> Loader Class Initialized
INFO - 2016-11-13 01:10:15 --> Helper loaded: url_helper
INFO - 2016-11-13 01:10:15 --> Helper loaded: form_helper
INFO - 2016-11-13 01:10:15 --> Database Driver Class Initialized
INFO - 2016-11-13 01:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:10:15 --> Controller Class Initialized
INFO - 2016-11-13 01:10:15 --> Model Class Initialized
INFO - 2016-11-13 01:10:15 --> Model Class Initialized
INFO - 2016-11-13 01:10:15 --> Model Class Initialized
INFO - 2016-11-13 01:10:15 --> Model Class Initialized
INFO - 2016-11-13 01:10:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:10:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:10:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:10:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:10:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:10:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:10:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:10:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:10:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:10:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:10:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:10:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:10:15 --> Final output sent to browser
DEBUG - 2016-11-13 01:10:15 --> Total execution time: 0.4075
INFO - 2016-11-13 01:10:19 --> Config Class Initialized
INFO - 2016-11-13 01:10:19 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:10:19 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:10:19 --> Utf8 Class Initialized
INFO - 2016-11-13 01:10:19 --> URI Class Initialized
INFO - 2016-11-13 01:10:19 --> Router Class Initialized
INFO - 2016-11-13 01:10:19 --> Output Class Initialized
INFO - 2016-11-13 01:10:20 --> Security Class Initialized
DEBUG - 2016-11-13 01:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:10:20 --> Input Class Initialized
INFO - 2016-11-13 01:10:20 --> Language Class Initialized
INFO - 2016-11-13 01:10:20 --> Loader Class Initialized
INFO - 2016-11-13 01:10:20 --> Helper loaded: url_helper
INFO - 2016-11-13 01:10:20 --> Helper loaded: form_helper
INFO - 2016-11-13 01:10:20 --> Database Driver Class Initialized
INFO - 2016-11-13 01:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:10:20 --> Controller Class Initialized
INFO - 2016-11-13 01:10:20 --> Model Class Initialized
INFO - 2016-11-13 01:10:20 --> Form Validation Class Initialized
INFO - 2016-11-13 01:10:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 01:10:20 --> Final output sent to browser
DEBUG - 2016-11-13 01:10:20 --> Total execution time: 0.2132
INFO - 2016-11-13 01:10:22 --> Config Class Initialized
INFO - 2016-11-13 01:10:22 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:10:22 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:10:22 --> Utf8 Class Initialized
INFO - 2016-11-13 01:10:22 --> URI Class Initialized
DEBUG - 2016-11-13 01:10:22 --> No URI present. Default controller set.
INFO - 2016-11-13 01:10:22 --> Router Class Initialized
INFO - 2016-11-13 01:10:22 --> Output Class Initialized
INFO - 2016-11-13 01:10:22 --> Security Class Initialized
DEBUG - 2016-11-13 01:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:10:22 --> Input Class Initialized
INFO - 2016-11-13 01:10:22 --> Language Class Initialized
INFO - 2016-11-13 01:10:22 --> Loader Class Initialized
INFO - 2016-11-13 01:10:22 --> Helper loaded: url_helper
INFO - 2016-11-13 01:10:22 --> Helper loaded: form_helper
INFO - 2016-11-13 01:10:22 --> Database Driver Class Initialized
INFO - 2016-11-13 01:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:10:22 --> Controller Class Initialized
INFO - 2016-11-13 01:10:22 --> Model Class Initialized
INFO - 2016-11-13 01:10:22 --> Model Class Initialized
INFO - 2016-11-13 01:10:22 --> Model Class Initialized
INFO - 2016-11-13 01:10:22 --> Model Class Initialized
INFO - 2016-11-13 01:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:10:22 --> Final output sent to browser
DEBUG - 2016-11-13 01:10:22 --> Total execution time: 0.4106
INFO - 2016-11-13 01:10:27 --> Config Class Initialized
INFO - 2016-11-13 01:10:27 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:10:27 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:10:27 --> Utf8 Class Initialized
INFO - 2016-11-13 01:10:27 --> URI Class Initialized
INFO - 2016-11-13 01:10:27 --> Router Class Initialized
INFO - 2016-11-13 01:10:27 --> Output Class Initialized
INFO - 2016-11-13 01:10:27 --> Security Class Initialized
DEBUG - 2016-11-13 01:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:10:27 --> Input Class Initialized
INFO - 2016-11-13 01:10:27 --> Language Class Initialized
INFO - 2016-11-13 01:10:27 --> Loader Class Initialized
INFO - 2016-11-13 01:10:27 --> Helper loaded: url_helper
INFO - 2016-11-13 01:10:27 --> Helper loaded: form_helper
INFO - 2016-11-13 01:10:27 --> Database Driver Class Initialized
INFO - 2016-11-13 01:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:10:27 --> Controller Class Initialized
INFO - 2016-11-13 01:10:27 --> Model Class Initialized
INFO - 2016-11-13 01:10:27 --> Form Validation Class Initialized
INFO - 2016-11-13 01:10:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 01:12:02 --> Config Class Initialized
INFO - 2016-11-13 01:12:02 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:12:02 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:12:02 --> Utf8 Class Initialized
INFO - 2016-11-13 01:12:02 --> URI Class Initialized
DEBUG - 2016-11-13 01:12:02 --> No URI present. Default controller set.
INFO - 2016-11-13 01:12:02 --> Router Class Initialized
INFO - 2016-11-13 01:12:02 --> Output Class Initialized
INFO - 2016-11-13 01:12:02 --> Security Class Initialized
DEBUG - 2016-11-13 01:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:12:02 --> Input Class Initialized
INFO - 2016-11-13 01:12:02 --> Language Class Initialized
INFO - 2016-11-13 01:12:02 --> Loader Class Initialized
INFO - 2016-11-13 01:12:02 --> Helper loaded: url_helper
INFO - 2016-11-13 01:12:02 --> Helper loaded: form_helper
INFO - 2016-11-13 01:12:02 --> Database Driver Class Initialized
INFO - 2016-11-13 01:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:12:02 --> Controller Class Initialized
INFO - 2016-11-13 01:12:02 --> Model Class Initialized
INFO - 2016-11-13 01:12:02 --> Model Class Initialized
INFO - 2016-11-13 01:12:02 --> Model Class Initialized
INFO - 2016-11-13 01:12:02 --> Model Class Initialized
INFO - 2016-11-13 01:12:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:12:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:12:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:12:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:12:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:12:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:12:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:12:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:12:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:12:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:12:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:12:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:12:03 --> Final output sent to browser
DEBUG - 2016-11-13 01:12:03 --> Total execution time: 0.3922
INFO - 2016-11-13 01:12:08 --> Config Class Initialized
INFO - 2016-11-13 01:12:08 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:12:08 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:12:08 --> Utf8 Class Initialized
INFO - 2016-11-13 01:12:08 --> URI Class Initialized
INFO - 2016-11-13 01:12:08 --> Router Class Initialized
INFO - 2016-11-13 01:12:08 --> Output Class Initialized
INFO - 2016-11-13 01:12:08 --> Security Class Initialized
DEBUG - 2016-11-13 01:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:12:08 --> Input Class Initialized
INFO - 2016-11-13 01:12:08 --> Language Class Initialized
INFO - 2016-11-13 01:12:08 --> Loader Class Initialized
INFO - 2016-11-13 01:12:08 --> Helper loaded: url_helper
INFO - 2016-11-13 01:12:08 --> Helper loaded: form_helper
INFO - 2016-11-13 01:12:08 --> Database Driver Class Initialized
INFO - 2016-11-13 01:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:12:08 --> Controller Class Initialized
INFO - 2016-11-13 01:12:08 --> Model Class Initialized
INFO - 2016-11-13 01:12:08 --> Form Validation Class Initialized
INFO - 2016-11-13 01:12:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 01:14:21 --> Config Class Initialized
INFO - 2016-11-13 01:14:21 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:14:21 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:14:21 --> Utf8 Class Initialized
INFO - 2016-11-13 01:14:21 --> URI Class Initialized
DEBUG - 2016-11-13 01:14:21 --> No URI present. Default controller set.
INFO - 2016-11-13 01:14:21 --> Router Class Initialized
INFO - 2016-11-13 01:14:21 --> Output Class Initialized
INFO - 2016-11-13 01:14:21 --> Security Class Initialized
DEBUG - 2016-11-13 01:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:14:21 --> Input Class Initialized
INFO - 2016-11-13 01:14:21 --> Language Class Initialized
INFO - 2016-11-13 01:14:21 --> Loader Class Initialized
INFO - 2016-11-13 01:14:21 --> Helper loaded: url_helper
INFO - 2016-11-13 01:14:21 --> Helper loaded: form_helper
INFO - 2016-11-13 01:14:21 --> Database Driver Class Initialized
INFO - 2016-11-13 01:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:14:21 --> Controller Class Initialized
INFO - 2016-11-13 01:14:21 --> Model Class Initialized
INFO - 2016-11-13 01:14:21 --> Model Class Initialized
INFO - 2016-11-13 01:14:21 --> Model Class Initialized
INFO - 2016-11-13 01:14:21 --> Model Class Initialized
INFO - 2016-11-13 01:14:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:14:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:14:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:14:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:14:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:14:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:14:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:14:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:14:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:14:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:14:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:14:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:14:21 --> Final output sent to browser
DEBUG - 2016-11-13 01:14:21 --> Total execution time: 0.4287
INFO - 2016-11-13 01:14:25 --> Config Class Initialized
INFO - 2016-11-13 01:14:25 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:14:25 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:14:25 --> Utf8 Class Initialized
INFO - 2016-11-13 01:14:25 --> URI Class Initialized
INFO - 2016-11-13 01:14:25 --> Router Class Initialized
INFO - 2016-11-13 01:14:25 --> Output Class Initialized
INFO - 2016-11-13 01:14:25 --> Security Class Initialized
DEBUG - 2016-11-13 01:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:14:25 --> Input Class Initialized
INFO - 2016-11-13 01:14:25 --> Language Class Initialized
INFO - 2016-11-13 01:14:25 --> Loader Class Initialized
INFO - 2016-11-13 01:14:25 --> Helper loaded: url_helper
INFO - 2016-11-13 01:14:25 --> Helper loaded: form_helper
INFO - 2016-11-13 01:14:25 --> Database Driver Class Initialized
INFO - 2016-11-13 01:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:14:25 --> Controller Class Initialized
INFO - 2016-11-13 01:14:25 --> Model Class Initialized
INFO - 2016-11-13 01:14:25 --> Form Validation Class Initialized
DEBUG - 2016-11-13 01:14:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-11-13 01:14:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 01:14:25 --> Final output sent to browser
DEBUG - 2016-11-13 01:14:25 --> Total execution time: 0.2281
INFO - 2016-11-13 01:14:30 --> Config Class Initialized
INFO - 2016-11-13 01:14:30 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:14:30 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:14:30 --> Utf8 Class Initialized
INFO - 2016-11-13 01:14:30 --> URI Class Initialized
DEBUG - 2016-11-13 01:14:30 --> No URI present. Default controller set.
INFO - 2016-11-13 01:14:30 --> Router Class Initialized
INFO - 2016-11-13 01:14:30 --> Output Class Initialized
INFO - 2016-11-13 01:14:30 --> Security Class Initialized
DEBUG - 2016-11-13 01:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:14:30 --> Input Class Initialized
INFO - 2016-11-13 01:14:30 --> Language Class Initialized
INFO - 2016-11-13 01:14:30 --> Loader Class Initialized
INFO - 2016-11-13 01:14:30 --> Helper loaded: url_helper
INFO - 2016-11-13 01:14:30 --> Helper loaded: form_helper
INFO - 2016-11-13 01:14:30 --> Database Driver Class Initialized
INFO - 2016-11-13 01:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:14:30 --> Controller Class Initialized
INFO - 2016-11-13 01:14:30 --> Model Class Initialized
INFO - 2016-11-13 01:14:30 --> Model Class Initialized
INFO - 2016-11-13 01:14:30 --> Model Class Initialized
INFO - 2016-11-13 01:14:30 --> Model Class Initialized
INFO - 2016-11-13 01:14:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:14:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:14:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:14:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:14:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:14:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:14:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:14:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:14:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:14:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:14:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:14:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:14:30 --> Final output sent to browser
DEBUG - 2016-11-13 01:14:30 --> Total execution time: 0.4018
INFO - 2016-11-13 01:19:26 --> Config Class Initialized
INFO - 2016-11-13 01:19:26 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:19:26 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:19:26 --> Utf8 Class Initialized
INFO - 2016-11-13 01:19:26 --> URI Class Initialized
INFO - 2016-11-13 01:19:26 --> Router Class Initialized
INFO - 2016-11-13 01:19:26 --> Output Class Initialized
INFO - 2016-11-13 01:19:26 --> Security Class Initialized
DEBUG - 2016-11-13 01:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:19:26 --> Input Class Initialized
INFO - 2016-11-13 01:19:26 --> Language Class Initialized
ERROR - 2016-11-13 01:19:26 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 134
INFO - 2016-11-13 01:19:30 --> Config Class Initialized
INFO - 2016-11-13 01:19:30 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:19:30 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:19:30 --> Utf8 Class Initialized
INFO - 2016-11-13 01:19:30 --> URI Class Initialized
DEBUG - 2016-11-13 01:19:30 --> No URI present. Default controller set.
INFO - 2016-11-13 01:19:30 --> Router Class Initialized
INFO - 2016-11-13 01:19:30 --> Output Class Initialized
INFO - 2016-11-13 01:19:30 --> Security Class Initialized
DEBUG - 2016-11-13 01:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:19:30 --> Input Class Initialized
INFO - 2016-11-13 01:19:30 --> Language Class Initialized
INFO - 2016-11-13 01:19:30 --> Loader Class Initialized
INFO - 2016-11-13 01:19:30 --> Helper loaded: url_helper
INFO - 2016-11-13 01:19:30 --> Helper loaded: form_helper
INFO - 2016-11-13 01:19:30 --> Database Driver Class Initialized
INFO - 2016-11-13 01:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:19:30 --> Controller Class Initialized
INFO - 2016-11-13 01:19:30 --> Model Class Initialized
INFO - 2016-11-13 01:19:30 --> Model Class Initialized
INFO - 2016-11-13 01:19:30 --> Model Class Initialized
INFO - 2016-11-13 01:19:30 --> Model Class Initialized
INFO - 2016-11-13 01:19:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:19:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:19:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:19:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:19:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:19:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:19:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:19:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:19:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:19:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:19:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:19:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:19:30 --> Final output sent to browser
DEBUG - 2016-11-13 01:19:30 --> Total execution time: 0.3898
INFO - 2016-11-13 01:26:09 --> Config Class Initialized
INFO - 2016-11-13 01:26:09 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:26:09 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:26:09 --> Utf8 Class Initialized
INFO - 2016-11-13 01:26:09 --> URI Class Initialized
DEBUG - 2016-11-13 01:26:09 --> No URI present. Default controller set.
INFO - 2016-11-13 01:26:09 --> Router Class Initialized
INFO - 2016-11-13 01:26:09 --> Output Class Initialized
INFO - 2016-11-13 01:26:09 --> Security Class Initialized
DEBUG - 2016-11-13 01:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:26:09 --> Input Class Initialized
INFO - 2016-11-13 01:26:09 --> Language Class Initialized
INFO - 2016-11-13 01:26:09 --> Loader Class Initialized
INFO - 2016-11-13 01:26:09 --> Helper loaded: url_helper
INFO - 2016-11-13 01:26:09 --> Helper loaded: form_helper
INFO - 2016-11-13 01:26:09 --> Database Driver Class Initialized
INFO - 2016-11-13 01:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:26:09 --> Controller Class Initialized
INFO - 2016-11-13 01:26:09 --> Model Class Initialized
INFO - 2016-11-13 01:26:09 --> Model Class Initialized
INFO - 2016-11-13 01:26:09 --> Model Class Initialized
INFO - 2016-11-13 01:26:10 --> Model Class Initialized
INFO - 2016-11-13 01:26:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:26:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:26:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:26:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:26:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:26:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:26:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:26:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:26:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:26:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:26:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:26:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:26:10 --> Final output sent to browser
DEBUG - 2016-11-13 01:26:10 --> Total execution time: 0.4695
INFO - 2016-11-13 01:26:13 --> Config Class Initialized
INFO - 2016-11-13 01:26:13 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:26:13 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:26:13 --> Utf8 Class Initialized
INFO - 2016-11-13 01:26:13 --> URI Class Initialized
INFO - 2016-11-13 01:26:13 --> Router Class Initialized
INFO - 2016-11-13 01:26:13 --> Output Class Initialized
INFO - 2016-11-13 01:26:13 --> Security Class Initialized
DEBUG - 2016-11-13 01:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:26:13 --> Input Class Initialized
INFO - 2016-11-13 01:26:13 --> Language Class Initialized
INFO - 2016-11-13 01:26:13 --> Loader Class Initialized
INFO - 2016-11-13 01:26:13 --> Helper loaded: url_helper
INFO - 2016-11-13 01:26:13 --> Helper loaded: form_helper
INFO - 2016-11-13 01:26:13 --> Database Driver Class Initialized
INFO - 2016-11-13 01:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:26:13 --> Controller Class Initialized
INFO - 2016-11-13 01:26:13 --> Model Class Initialized
INFO - 2016-11-13 01:26:13 --> Form Validation Class Initialized
INFO - 2016-11-13 01:26:13 --> Final output sent to browser
DEBUG - 2016-11-13 01:26:13 --> Total execution time: 0.2150
INFO - 2016-11-13 01:26:15 --> Config Class Initialized
INFO - 2016-11-13 01:26:15 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:26:15 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:26:15 --> Utf8 Class Initialized
INFO - 2016-11-13 01:26:15 --> URI Class Initialized
DEBUG - 2016-11-13 01:26:15 --> No URI present. Default controller set.
INFO - 2016-11-13 01:26:15 --> Router Class Initialized
INFO - 2016-11-13 01:26:15 --> Output Class Initialized
INFO - 2016-11-13 01:26:15 --> Security Class Initialized
DEBUG - 2016-11-13 01:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:26:15 --> Input Class Initialized
INFO - 2016-11-13 01:26:15 --> Language Class Initialized
INFO - 2016-11-13 01:26:15 --> Loader Class Initialized
INFO - 2016-11-13 01:26:16 --> Helper loaded: url_helper
INFO - 2016-11-13 01:26:16 --> Helper loaded: form_helper
INFO - 2016-11-13 01:26:16 --> Database Driver Class Initialized
INFO - 2016-11-13 01:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:26:16 --> Controller Class Initialized
INFO - 2016-11-13 01:26:16 --> Model Class Initialized
INFO - 2016-11-13 01:26:16 --> Model Class Initialized
INFO - 2016-11-13 01:26:16 --> Model Class Initialized
INFO - 2016-11-13 01:26:16 --> Model Class Initialized
INFO - 2016-11-13 01:26:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:26:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:26:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:26:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:26:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:26:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:26:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:26:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:26:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:26:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:26:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:26:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:26:16 --> Final output sent to browser
DEBUG - 2016-11-13 01:26:16 --> Total execution time: 0.4309
INFO - 2016-11-13 01:26:20 --> Config Class Initialized
INFO - 2016-11-13 01:26:20 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:26:20 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:26:20 --> Utf8 Class Initialized
INFO - 2016-11-13 01:26:20 --> URI Class Initialized
INFO - 2016-11-13 01:26:20 --> Router Class Initialized
INFO - 2016-11-13 01:26:20 --> Output Class Initialized
INFO - 2016-11-13 01:26:20 --> Security Class Initialized
DEBUG - 2016-11-13 01:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:26:20 --> Input Class Initialized
INFO - 2016-11-13 01:26:20 --> Language Class Initialized
INFO - 2016-11-13 01:26:20 --> Loader Class Initialized
INFO - 2016-11-13 01:26:20 --> Helper loaded: url_helper
INFO - 2016-11-13 01:26:20 --> Helper loaded: form_helper
INFO - 2016-11-13 01:26:21 --> Database Driver Class Initialized
INFO - 2016-11-13 01:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:26:21 --> Controller Class Initialized
INFO - 2016-11-13 01:26:21 --> Model Class Initialized
INFO - 2016-11-13 01:26:21 --> Form Validation Class Initialized
INFO - 2016-11-13 01:26:21 --> Final output sent to browser
DEBUG - 2016-11-13 01:26:21 --> Total execution time: 0.2186
INFO - 2016-11-13 01:26:24 --> Config Class Initialized
INFO - 2016-11-13 01:26:24 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:26:24 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:26:24 --> Utf8 Class Initialized
INFO - 2016-11-13 01:26:24 --> URI Class Initialized
DEBUG - 2016-11-13 01:26:24 --> No URI present. Default controller set.
INFO - 2016-11-13 01:26:24 --> Router Class Initialized
INFO - 2016-11-13 01:26:24 --> Output Class Initialized
INFO - 2016-11-13 01:26:24 --> Security Class Initialized
DEBUG - 2016-11-13 01:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:26:24 --> Input Class Initialized
INFO - 2016-11-13 01:26:24 --> Language Class Initialized
INFO - 2016-11-13 01:26:24 --> Loader Class Initialized
INFO - 2016-11-13 01:26:24 --> Helper loaded: url_helper
INFO - 2016-11-13 01:26:24 --> Helper loaded: form_helper
INFO - 2016-11-13 01:26:24 --> Database Driver Class Initialized
INFO - 2016-11-13 01:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:26:24 --> Controller Class Initialized
INFO - 2016-11-13 01:26:24 --> Model Class Initialized
INFO - 2016-11-13 01:26:24 --> Model Class Initialized
INFO - 2016-11-13 01:26:24 --> Model Class Initialized
INFO - 2016-11-13 01:26:24 --> Model Class Initialized
INFO - 2016-11-13 01:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:26:24 --> Final output sent to browser
DEBUG - 2016-11-13 01:26:24 --> Total execution time: 0.4265
INFO - 2016-11-13 01:26:35 --> Config Class Initialized
INFO - 2016-11-13 01:26:35 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:26:35 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:26:35 --> Utf8 Class Initialized
INFO - 2016-11-13 01:26:35 --> URI Class Initialized
DEBUG - 2016-11-13 01:26:35 --> No URI present. Default controller set.
INFO - 2016-11-13 01:26:35 --> Router Class Initialized
INFO - 2016-11-13 01:26:35 --> Output Class Initialized
INFO - 2016-11-13 01:26:35 --> Security Class Initialized
DEBUG - 2016-11-13 01:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:26:35 --> Input Class Initialized
INFO - 2016-11-13 01:26:35 --> Language Class Initialized
INFO - 2016-11-13 01:26:35 --> Loader Class Initialized
INFO - 2016-11-13 01:26:35 --> Helper loaded: url_helper
INFO - 2016-11-13 01:26:35 --> Helper loaded: form_helper
INFO - 2016-11-13 01:26:35 --> Database Driver Class Initialized
INFO - 2016-11-13 01:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:26:35 --> Controller Class Initialized
INFO - 2016-11-13 01:26:35 --> Model Class Initialized
INFO - 2016-11-13 01:26:35 --> Model Class Initialized
INFO - 2016-11-13 01:26:35 --> Model Class Initialized
INFO - 2016-11-13 01:26:35 --> Model Class Initialized
INFO - 2016-11-13 01:26:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:26:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:26:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:26:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:26:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:26:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:26:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:26:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:26:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:26:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:26:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:26:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:26:35 --> Final output sent to browser
DEBUG - 2016-11-13 01:26:35 --> Total execution time: 0.4461
INFO - 2016-11-13 01:26:40 --> Config Class Initialized
INFO - 2016-11-13 01:26:40 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:26:40 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:26:40 --> Utf8 Class Initialized
INFO - 2016-11-13 01:26:40 --> URI Class Initialized
INFO - 2016-11-13 01:26:40 --> Router Class Initialized
INFO - 2016-11-13 01:26:40 --> Output Class Initialized
INFO - 2016-11-13 01:26:40 --> Security Class Initialized
DEBUG - 2016-11-13 01:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:26:40 --> Input Class Initialized
INFO - 2016-11-13 01:26:40 --> Language Class Initialized
INFO - 2016-11-13 01:26:40 --> Loader Class Initialized
INFO - 2016-11-13 01:26:40 --> Helper loaded: url_helper
INFO - 2016-11-13 01:26:40 --> Helper loaded: form_helper
INFO - 2016-11-13 01:26:40 --> Database Driver Class Initialized
INFO - 2016-11-13 01:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:26:41 --> Controller Class Initialized
INFO - 2016-11-13 01:26:41 --> Model Class Initialized
INFO - 2016-11-13 01:26:41 --> Form Validation Class Initialized
INFO - 2016-11-13 01:27:32 --> Config Class Initialized
INFO - 2016-11-13 01:27:32 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:27:32 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:27:32 --> Utf8 Class Initialized
INFO - 2016-11-13 01:27:32 --> URI Class Initialized
DEBUG - 2016-11-13 01:27:32 --> No URI present. Default controller set.
INFO - 2016-11-13 01:27:32 --> Router Class Initialized
INFO - 2016-11-13 01:27:32 --> Output Class Initialized
INFO - 2016-11-13 01:27:32 --> Security Class Initialized
DEBUG - 2016-11-13 01:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:27:32 --> Input Class Initialized
INFO - 2016-11-13 01:27:32 --> Language Class Initialized
INFO - 2016-11-13 01:27:32 --> Loader Class Initialized
INFO - 2016-11-13 01:27:32 --> Helper loaded: url_helper
INFO - 2016-11-13 01:27:32 --> Helper loaded: form_helper
INFO - 2016-11-13 01:27:32 --> Database Driver Class Initialized
INFO - 2016-11-13 01:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:27:32 --> Controller Class Initialized
INFO - 2016-11-13 01:27:32 --> Model Class Initialized
INFO - 2016-11-13 01:27:32 --> Model Class Initialized
INFO - 2016-11-13 01:27:32 --> Model Class Initialized
INFO - 2016-11-13 01:27:32 --> Model Class Initialized
INFO - 2016-11-13 01:27:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:27:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:27:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:27:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:27:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:27:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:27:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:27:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:27:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:27:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:27:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:27:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:27:32 --> Final output sent to browser
DEBUG - 2016-11-13 01:27:32 --> Total execution time: 0.4424
INFO - 2016-11-13 01:31:42 --> Config Class Initialized
INFO - 2016-11-13 01:31:42 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:31:42 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:31:42 --> Utf8 Class Initialized
INFO - 2016-11-13 01:31:42 --> URI Class Initialized
DEBUG - 2016-11-13 01:31:42 --> No URI present. Default controller set.
INFO - 2016-11-13 01:31:42 --> Router Class Initialized
INFO - 2016-11-13 01:31:42 --> Output Class Initialized
INFO - 2016-11-13 01:31:42 --> Security Class Initialized
DEBUG - 2016-11-13 01:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:31:42 --> Input Class Initialized
INFO - 2016-11-13 01:31:42 --> Language Class Initialized
INFO - 2016-11-13 01:31:42 --> Loader Class Initialized
INFO - 2016-11-13 01:31:42 --> Helper loaded: url_helper
INFO - 2016-11-13 01:31:42 --> Helper loaded: form_helper
INFO - 2016-11-13 01:31:42 --> Database Driver Class Initialized
INFO - 2016-11-13 01:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:31:42 --> Controller Class Initialized
INFO - 2016-11-13 01:31:42 --> Model Class Initialized
INFO - 2016-11-13 01:31:42 --> Model Class Initialized
INFO - 2016-11-13 01:31:42 --> Model Class Initialized
INFO - 2016-11-13 01:31:42 --> Model Class Initialized
INFO - 2016-11-13 01:31:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:31:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:31:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:31:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:31:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:31:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:31:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:31:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:31:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:31:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:31:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:31:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:31:42 --> Final output sent to browser
DEBUG - 2016-11-13 01:31:42 --> Total execution time: 0.3924
INFO - 2016-11-13 01:32:00 --> Config Class Initialized
INFO - 2016-11-13 01:32:00 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:32:00 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:32:00 --> Utf8 Class Initialized
INFO - 2016-11-13 01:32:00 --> URI Class Initialized
INFO - 2016-11-13 01:32:00 --> Router Class Initialized
INFO - 2016-11-13 01:32:00 --> Output Class Initialized
INFO - 2016-11-13 01:32:00 --> Security Class Initialized
DEBUG - 2016-11-13 01:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:32:00 --> Input Class Initialized
INFO - 2016-11-13 01:32:00 --> Language Class Initialized
INFO - 2016-11-13 01:32:00 --> Loader Class Initialized
INFO - 2016-11-13 01:32:00 --> Helper loaded: url_helper
INFO - 2016-11-13 01:32:00 --> Helper loaded: form_helper
INFO - 2016-11-13 01:32:00 --> Database Driver Class Initialized
INFO - 2016-11-13 01:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:32:00 --> Controller Class Initialized
INFO - 2016-11-13 01:32:00 --> Model Class Initialized
INFO - 2016-11-13 01:32:00 --> Form Validation Class Initialized
ERROR - 2016-11-13 01:32:00 --> Severity: Notice --> Undefined variable: idrecord C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 60
ERROR - 2016-11-13 01:32:00 --> Severity: Notice --> Undefined variable: leavename C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 61
ERROR - 2016-11-13 01:32:00 --> Severity: Notice --> Undefined variable: numberOfLeaves C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 62
ERROR - 2016-11-13 01:32:00 --> Severity: Notice --> Undefined variable: description C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 63
ERROR - 2016-11-13 01:32:00 --> Query error: Unknown column 'typeName' in 'field list' - Invalid query: UPDATE `applicationData` SET `typeName` = NULL, `numberOfLeaves` = NULL, `description` = NULL
WHERE `id` IS NULL
INFO - 2016-11-13 01:32:00 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 01:32:06 --> Config Class Initialized
INFO - 2016-11-13 01:32:06 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:32:06 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:32:06 --> Utf8 Class Initialized
INFO - 2016-11-13 01:32:06 --> URI Class Initialized
DEBUG - 2016-11-13 01:32:06 --> No URI present. Default controller set.
INFO - 2016-11-13 01:32:06 --> Router Class Initialized
INFO - 2016-11-13 01:32:06 --> Output Class Initialized
INFO - 2016-11-13 01:32:06 --> Security Class Initialized
DEBUG - 2016-11-13 01:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:32:06 --> Input Class Initialized
INFO - 2016-11-13 01:32:06 --> Language Class Initialized
INFO - 2016-11-13 01:32:06 --> Loader Class Initialized
INFO - 2016-11-13 01:32:06 --> Helper loaded: url_helper
INFO - 2016-11-13 01:32:06 --> Helper loaded: form_helper
INFO - 2016-11-13 01:32:06 --> Database Driver Class Initialized
INFO - 2016-11-13 01:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:32:06 --> Controller Class Initialized
INFO - 2016-11-13 01:32:06 --> Model Class Initialized
INFO - 2016-11-13 01:32:06 --> Model Class Initialized
INFO - 2016-11-13 01:32:06 --> Model Class Initialized
INFO - 2016-11-13 01:32:06 --> Model Class Initialized
INFO - 2016-11-13 01:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:32:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:32:06 --> Final output sent to browser
DEBUG - 2016-11-13 01:32:06 --> Total execution time: 0.4333
INFO - 2016-11-13 01:32:12 --> Config Class Initialized
INFO - 2016-11-13 01:32:12 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:32:12 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:32:12 --> Utf8 Class Initialized
INFO - 2016-11-13 01:32:12 --> URI Class Initialized
INFO - 2016-11-13 01:32:12 --> Router Class Initialized
INFO - 2016-11-13 01:32:12 --> Output Class Initialized
INFO - 2016-11-13 01:32:12 --> Security Class Initialized
DEBUG - 2016-11-13 01:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:32:12 --> Input Class Initialized
INFO - 2016-11-13 01:32:12 --> Language Class Initialized
INFO - 2016-11-13 01:32:12 --> Loader Class Initialized
INFO - 2016-11-13 01:32:12 --> Helper loaded: url_helper
INFO - 2016-11-13 01:32:12 --> Helper loaded: form_helper
INFO - 2016-11-13 01:32:12 --> Database Driver Class Initialized
INFO - 2016-11-13 01:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:32:12 --> Controller Class Initialized
INFO - 2016-11-13 01:32:12 --> Model Class Initialized
INFO - 2016-11-13 01:32:12 --> Form Validation Class Initialized
INFO - 2016-11-13 01:32:12 --> Final output sent to browser
DEBUG - 2016-11-13 01:32:12 --> Total execution time: 0.2345
INFO - 2016-11-13 01:32:20 --> Config Class Initialized
INFO - 2016-11-13 01:32:20 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:32:20 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:32:20 --> Utf8 Class Initialized
INFO - 2016-11-13 01:32:20 --> URI Class Initialized
DEBUG - 2016-11-13 01:32:20 --> No URI present. Default controller set.
INFO - 2016-11-13 01:32:20 --> Router Class Initialized
INFO - 2016-11-13 01:32:20 --> Output Class Initialized
INFO - 2016-11-13 01:32:20 --> Security Class Initialized
DEBUG - 2016-11-13 01:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:32:20 --> Input Class Initialized
INFO - 2016-11-13 01:32:20 --> Language Class Initialized
INFO - 2016-11-13 01:32:20 --> Loader Class Initialized
INFO - 2016-11-13 01:32:20 --> Helper loaded: url_helper
INFO - 2016-11-13 01:32:20 --> Helper loaded: form_helper
INFO - 2016-11-13 01:32:20 --> Database Driver Class Initialized
INFO - 2016-11-13 01:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:32:20 --> Controller Class Initialized
INFO - 2016-11-13 01:32:20 --> Model Class Initialized
INFO - 2016-11-13 01:32:20 --> Model Class Initialized
INFO - 2016-11-13 01:32:20 --> Model Class Initialized
INFO - 2016-11-13 01:32:20 --> Model Class Initialized
INFO - 2016-11-13 01:32:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:32:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:32:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:32:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:32:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:32:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:32:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:32:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:32:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:32:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:32:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:32:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:32:21 --> Final output sent to browser
DEBUG - 2016-11-13 01:32:21 --> Total execution time: 0.4517
INFO - 2016-11-13 01:32:27 --> Config Class Initialized
INFO - 2016-11-13 01:32:27 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:32:27 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:32:27 --> Utf8 Class Initialized
INFO - 2016-11-13 01:32:27 --> URI Class Initialized
INFO - 2016-11-13 01:32:27 --> Router Class Initialized
INFO - 2016-11-13 01:32:27 --> Output Class Initialized
INFO - 2016-11-13 01:32:27 --> Security Class Initialized
DEBUG - 2016-11-13 01:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:32:27 --> Input Class Initialized
INFO - 2016-11-13 01:32:27 --> Language Class Initialized
INFO - 2016-11-13 01:32:27 --> Loader Class Initialized
INFO - 2016-11-13 01:32:27 --> Helper loaded: url_helper
INFO - 2016-11-13 01:32:27 --> Helper loaded: form_helper
INFO - 2016-11-13 01:32:27 --> Database Driver Class Initialized
INFO - 2016-11-13 01:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:32:27 --> Controller Class Initialized
INFO - 2016-11-13 01:32:27 --> Model Class Initialized
INFO - 2016-11-13 01:32:27 --> Form Validation Class Initialized
ERROR - 2016-11-13 01:32:27 --> Severity: Notice --> Undefined variable: idrecord C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 60
ERROR - 2016-11-13 01:32:27 --> Severity: Notice --> Undefined variable: leavename C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 61
ERROR - 2016-11-13 01:32:27 --> Severity: Notice --> Undefined variable: numberOfLeaves C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 62
ERROR - 2016-11-13 01:32:27 --> Severity: Notice --> Undefined variable: description C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 63
ERROR - 2016-11-13 01:32:27 --> Query error: Unknown column 'typeName' in 'field list' - Invalid query: UPDATE `applicationData` SET `typeName` = NULL, `numberOfLeaves` = NULL, `description` = NULL
WHERE `id` IS NULL
INFO - 2016-11-13 01:32:27 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 01:34:16 --> Config Class Initialized
INFO - 2016-11-13 01:34:16 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:34:16 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:34:16 --> Utf8 Class Initialized
INFO - 2016-11-13 01:34:16 --> URI Class Initialized
DEBUG - 2016-11-13 01:34:16 --> No URI present. Default controller set.
INFO - 2016-11-13 01:34:16 --> Router Class Initialized
INFO - 2016-11-13 01:34:16 --> Output Class Initialized
INFO - 2016-11-13 01:34:16 --> Security Class Initialized
DEBUG - 2016-11-13 01:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:34:16 --> Input Class Initialized
INFO - 2016-11-13 01:34:16 --> Language Class Initialized
INFO - 2016-11-13 01:34:16 --> Loader Class Initialized
INFO - 2016-11-13 01:34:16 --> Helper loaded: url_helper
INFO - 2016-11-13 01:34:16 --> Helper loaded: form_helper
INFO - 2016-11-13 01:34:16 --> Database Driver Class Initialized
INFO - 2016-11-13 01:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:34:16 --> Controller Class Initialized
INFO - 2016-11-13 01:34:16 --> Model Class Initialized
INFO - 2016-11-13 01:34:16 --> Model Class Initialized
INFO - 2016-11-13 01:34:16 --> Model Class Initialized
INFO - 2016-11-13 01:34:16 --> Model Class Initialized
INFO - 2016-11-13 01:34:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:34:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:34:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:34:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:34:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:34:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:34:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:34:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:34:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:34:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:34:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:34:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:34:16 --> Final output sent to browser
DEBUG - 2016-11-13 01:34:16 --> Total execution time: 0.4139
INFO - 2016-11-13 01:34:24 --> Config Class Initialized
INFO - 2016-11-13 01:34:24 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:34:24 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:34:24 --> Utf8 Class Initialized
INFO - 2016-11-13 01:34:24 --> URI Class Initialized
INFO - 2016-11-13 01:34:24 --> Router Class Initialized
INFO - 2016-11-13 01:34:24 --> Output Class Initialized
INFO - 2016-11-13 01:34:24 --> Security Class Initialized
DEBUG - 2016-11-13 01:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:34:24 --> Input Class Initialized
INFO - 2016-11-13 01:34:24 --> Language Class Initialized
INFO - 2016-11-13 01:34:24 --> Loader Class Initialized
INFO - 2016-11-13 01:34:24 --> Helper loaded: url_helper
INFO - 2016-11-13 01:34:24 --> Helper loaded: form_helper
INFO - 2016-11-13 01:34:24 --> Database Driver Class Initialized
INFO - 2016-11-13 01:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:34:24 --> Controller Class Initialized
INFO - 2016-11-13 01:34:24 --> Model Class Initialized
INFO - 2016-11-13 01:34:24 --> Form Validation Class Initialized
ERROR - 2016-11-13 01:34:24 --> Severity: Notice --> Undefined variable: idrecord C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 60
ERROR - 2016-11-13 01:34:24 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 62
ERROR - 2016-11-13 01:34:24 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 28
ERROR - 2016-11-13 01:34:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 28
INFO - 2016-11-13 01:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:34:24 --> Final output sent to browser
DEBUG - 2016-11-13 01:34:24 --> Total execution time: 0.3514
INFO - 2016-11-13 01:34:54 --> Config Class Initialized
INFO - 2016-11-13 01:34:54 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:34:54 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:34:54 --> Utf8 Class Initialized
INFO - 2016-11-13 01:34:54 --> URI Class Initialized
DEBUG - 2016-11-13 01:34:54 --> No URI present. Default controller set.
INFO - 2016-11-13 01:34:54 --> Router Class Initialized
INFO - 2016-11-13 01:34:54 --> Output Class Initialized
INFO - 2016-11-13 01:34:54 --> Security Class Initialized
DEBUG - 2016-11-13 01:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:34:54 --> Input Class Initialized
INFO - 2016-11-13 01:34:54 --> Language Class Initialized
INFO - 2016-11-13 01:34:54 --> Loader Class Initialized
INFO - 2016-11-13 01:34:54 --> Helper loaded: url_helper
INFO - 2016-11-13 01:34:54 --> Helper loaded: form_helper
INFO - 2016-11-13 01:34:54 --> Database Driver Class Initialized
INFO - 2016-11-13 01:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:34:54 --> Controller Class Initialized
INFO - 2016-11-13 01:34:54 --> Model Class Initialized
INFO - 2016-11-13 01:34:54 --> Model Class Initialized
INFO - 2016-11-13 01:34:54 --> Model Class Initialized
INFO - 2016-11-13 01:34:54 --> Model Class Initialized
INFO - 2016-11-13 01:34:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:34:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:34:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:34:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:34:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:34:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:34:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:34:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:34:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:34:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:34:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:34:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:34:54 --> Final output sent to browser
DEBUG - 2016-11-13 01:34:54 --> Total execution time: 0.4423
INFO - 2016-11-13 01:35:01 --> Config Class Initialized
INFO - 2016-11-13 01:35:01 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:35:01 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:35:01 --> Utf8 Class Initialized
INFO - 2016-11-13 01:35:01 --> URI Class Initialized
INFO - 2016-11-13 01:35:01 --> Router Class Initialized
INFO - 2016-11-13 01:35:01 --> Output Class Initialized
INFO - 2016-11-13 01:35:01 --> Security Class Initialized
DEBUG - 2016-11-13 01:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:35:01 --> Input Class Initialized
INFO - 2016-11-13 01:35:01 --> Language Class Initialized
INFO - 2016-11-13 01:35:01 --> Loader Class Initialized
INFO - 2016-11-13 01:35:01 --> Helper loaded: url_helper
INFO - 2016-11-13 01:35:01 --> Helper loaded: form_helper
INFO - 2016-11-13 01:35:01 --> Database Driver Class Initialized
INFO - 2016-11-13 01:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:35:01 --> Controller Class Initialized
INFO - 2016-11-13 01:35:01 --> Model Class Initialized
INFO - 2016-11-13 01:35:01 --> Form Validation Class Initialized
ERROR - 2016-11-13 01:35:01 --> Severity: Warning --> extract() expects parameter 1 to be array, null given C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 59
ERROR - 2016-11-13 01:35:01 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\LMS\sys\database\DB_query_builder.php 669
ERROR - 2016-11-13 01:35:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 62
ERROR - 2016-11-13 01:35:01 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `applicationData` SET `idLeaveStatus` = NULL
WHERE `id` = `Array`
INFO - 2016-11-13 01:35:01 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 01:35:06 --> Config Class Initialized
INFO - 2016-11-13 01:35:06 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:35:06 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:35:06 --> Utf8 Class Initialized
INFO - 2016-11-13 01:35:06 --> URI Class Initialized
DEBUG - 2016-11-13 01:35:06 --> No URI present. Default controller set.
INFO - 2016-11-13 01:35:06 --> Router Class Initialized
INFO - 2016-11-13 01:35:06 --> Output Class Initialized
INFO - 2016-11-13 01:35:06 --> Security Class Initialized
DEBUG - 2016-11-13 01:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:35:06 --> Input Class Initialized
INFO - 2016-11-13 01:35:06 --> Language Class Initialized
INFO - 2016-11-13 01:35:06 --> Loader Class Initialized
INFO - 2016-11-13 01:35:06 --> Helper loaded: url_helper
INFO - 2016-11-13 01:35:06 --> Helper loaded: form_helper
INFO - 2016-11-13 01:35:06 --> Database Driver Class Initialized
INFO - 2016-11-13 01:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:35:06 --> Controller Class Initialized
INFO - 2016-11-13 01:35:06 --> Model Class Initialized
INFO - 2016-11-13 01:35:06 --> Model Class Initialized
INFO - 2016-11-13 01:35:06 --> Model Class Initialized
INFO - 2016-11-13 01:35:06 --> Model Class Initialized
INFO - 2016-11-13 01:35:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:35:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:35:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:35:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:35:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:35:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:35:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:35:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:35:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:35:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:35:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:35:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:35:06 --> Final output sent to browser
DEBUG - 2016-11-13 01:35:06 --> Total execution time: 0.4458
INFO - 2016-11-13 01:37:28 --> Config Class Initialized
INFO - 2016-11-13 01:37:28 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:37:28 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:37:28 --> Utf8 Class Initialized
INFO - 2016-11-13 01:37:28 --> URI Class Initialized
DEBUG - 2016-11-13 01:37:28 --> No URI present. Default controller set.
INFO - 2016-11-13 01:37:28 --> Router Class Initialized
INFO - 2016-11-13 01:37:28 --> Output Class Initialized
INFO - 2016-11-13 01:37:28 --> Security Class Initialized
DEBUG - 2016-11-13 01:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:37:28 --> Input Class Initialized
INFO - 2016-11-13 01:37:28 --> Language Class Initialized
INFO - 2016-11-13 01:37:28 --> Loader Class Initialized
INFO - 2016-11-13 01:37:28 --> Helper loaded: url_helper
INFO - 2016-11-13 01:37:28 --> Helper loaded: form_helper
INFO - 2016-11-13 01:37:28 --> Database Driver Class Initialized
INFO - 2016-11-13 01:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:37:28 --> Controller Class Initialized
INFO - 2016-11-13 01:37:28 --> Model Class Initialized
INFO - 2016-11-13 01:37:28 --> Model Class Initialized
INFO - 2016-11-13 01:37:28 --> Model Class Initialized
INFO - 2016-11-13 01:37:28 --> Model Class Initialized
INFO - 2016-11-13 01:37:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:37:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:37:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:37:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:37:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:37:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:37:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:37:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:37:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:37:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:37:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:37:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:37:28 --> Final output sent to browser
DEBUG - 2016-11-13 01:37:28 --> Total execution time: 0.4014
INFO - 2016-11-13 01:37:33 --> Config Class Initialized
INFO - 2016-11-13 01:37:33 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:37:33 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:37:33 --> Utf8 Class Initialized
INFO - 2016-11-13 01:37:33 --> URI Class Initialized
INFO - 2016-11-13 01:37:33 --> Router Class Initialized
INFO - 2016-11-13 01:37:33 --> Output Class Initialized
INFO - 2016-11-13 01:37:33 --> Security Class Initialized
DEBUG - 2016-11-13 01:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:37:33 --> Input Class Initialized
INFO - 2016-11-13 01:37:33 --> Language Class Initialized
INFO - 2016-11-13 01:37:33 --> Loader Class Initialized
INFO - 2016-11-13 01:37:33 --> Helper loaded: url_helper
INFO - 2016-11-13 01:37:33 --> Helper loaded: form_helper
INFO - 2016-11-13 01:37:33 --> Database Driver Class Initialized
INFO - 2016-11-13 01:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:37:33 --> Controller Class Initialized
INFO - 2016-11-13 01:37:33 --> Model Class Initialized
INFO - 2016-11-13 01:37:33 --> Form Validation Class Initialized
ERROR - 2016-11-13 01:37:33 --> Severity: Notice --> Undefined variable: idrecord C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 60
ERROR - 2016-11-13 01:37:33 --> Severity: Notice --> Undefined variable: idstatus C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 62
ERROR - 2016-11-13 01:37:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 28
ERROR - 2016-11-13 01:37:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 28
INFO - 2016-11-13 01:37:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:37:33 --> Final output sent to browser
DEBUG - 2016-11-13 01:37:33 --> Total execution time: 0.2839
INFO - 2016-11-13 01:39:55 --> Config Class Initialized
INFO - 2016-11-13 01:39:55 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:39:55 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:39:55 --> Utf8 Class Initialized
INFO - 2016-11-13 01:39:55 --> URI Class Initialized
DEBUG - 2016-11-13 01:39:55 --> No URI present. Default controller set.
INFO - 2016-11-13 01:39:55 --> Router Class Initialized
INFO - 2016-11-13 01:39:55 --> Output Class Initialized
INFO - 2016-11-13 01:39:55 --> Security Class Initialized
DEBUG - 2016-11-13 01:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:39:55 --> Input Class Initialized
INFO - 2016-11-13 01:39:55 --> Language Class Initialized
INFO - 2016-11-13 01:39:55 --> Loader Class Initialized
INFO - 2016-11-13 01:39:55 --> Helper loaded: url_helper
INFO - 2016-11-13 01:39:55 --> Helper loaded: form_helper
INFO - 2016-11-13 01:39:55 --> Database Driver Class Initialized
INFO - 2016-11-13 01:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:39:55 --> Controller Class Initialized
INFO - 2016-11-13 01:39:55 --> Model Class Initialized
INFO - 2016-11-13 01:39:55 --> Model Class Initialized
INFO - 2016-11-13 01:39:55 --> Model Class Initialized
INFO - 2016-11-13 01:39:55 --> Model Class Initialized
INFO - 2016-11-13 01:39:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:39:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:39:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:39:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:39:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:39:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:39:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:39:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:39:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:39:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:39:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:39:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:39:55 --> Final output sent to browser
DEBUG - 2016-11-13 01:39:55 --> Total execution time: 0.5337
INFO - 2016-11-13 01:40:00 --> Config Class Initialized
INFO - 2016-11-13 01:40:00 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:40:00 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:40:00 --> Utf8 Class Initialized
INFO - 2016-11-13 01:40:00 --> URI Class Initialized
INFO - 2016-11-13 01:40:00 --> Router Class Initialized
INFO - 2016-11-13 01:40:00 --> Output Class Initialized
INFO - 2016-11-13 01:40:00 --> Security Class Initialized
DEBUG - 2016-11-13 01:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:40:00 --> Input Class Initialized
INFO - 2016-11-13 01:40:00 --> Language Class Initialized
INFO - 2016-11-13 01:40:00 --> Loader Class Initialized
INFO - 2016-11-13 01:40:00 --> Helper loaded: url_helper
INFO - 2016-11-13 01:40:00 --> Helper loaded: form_helper
INFO - 2016-11-13 01:40:00 --> Database Driver Class Initialized
INFO - 2016-11-13 01:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:40:00 --> Controller Class Initialized
INFO - 2016-11-13 01:40:00 --> Model Class Initialized
INFO - 2016-11-13 01:40:01 --> Form Validation Class Initialized
ERROR - 2016-11-13 01:40:01 --> Severity: Notice --> Undefined index: idrecord C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 60
ERROR - 2016-11-13 01:40:01 --> Severity: Notice --> Undefined index: $idstatus C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 61
ERROR - 2016-11-13 01:40:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 28
ERROR - 2016-11-13 01:40:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 28
INFO - 2016-11-13 01:40:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:40:01 --> Final output sent to browser
DEBUG - 2016-11-13 01:40:01 --> Total execution time: 0.2948
INFO - 2016-11-13 01:40:45 --> Config Class Initialized
INFO - 2016-11-13 01:40:45 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:40:45 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:40:45 --> Utf8 Class Initialized
INFO - 2016-11-13 01:40:45 --> URI Class Initialized
DEBUG - 2016-11-13 01:40:45 --> No URI present. Default controller set.
INFO - 2016-11-13 01:40:45 --> Router Class Initialized
INFO - 2016-11-13 01:40:45 --> Output Class Initialized
INFO - 2016-11-13 01:40:45 --> Security Class Initialized
DEBUG - 2016-11-13 01:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:40:45 --> Input Class Initialized
INFO - 2016-11-13 01:40:45 --> Language Class Initialized
INFO - 2016-11-13 01:40:45 --> Loader Class Initialized
INFO - 2016-11-13 01:40:45 --> Helper loaded: url_helper
INFO - 2016-11-13 01:40:45 --> Helper loaded: form_helper
INFO - 2016-11-13 01:40:45 --> Database Driver Class Initialized
INFO - 2016-11-13 01:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:40:45 --> Controller Class Initialized
INFO - 2016-11-13 01:40:45 --> Model Class Initialized
INFO - 2016-11-13 01:40:46 --> Model Class Initialized
INFO - 2016-11-13 01:40:46 --> Model Class Initialized
INFO - 2016-11-13 01:40:46 --> Model Class Initialized
INFO - 2016-11-13 01:40:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:40:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:40:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:40:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:40:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:40:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:40:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:40:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:40:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:40:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:40:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:40:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:40:46 --> Final output sent to browser
DEBUG - 2016-11-13 01:40:46 --> Total execution time: 0.4636
INFO - 2016-11-13 01:42:27 --> Config Class Initialized
INFO - 2016-11-13 01:42:27 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:42:27 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:42:27 --> Utf8 Class Initialized
INFO - 2016-11-13 01:42:27 --> URI Class Initialized
DEBUG - 2016-11-13 01:42:27 --> No URI present. Default controller set.
INFO - 2016-11-13 01:42:27 --> Router Class Initialized
INFO - 2016-11-13 01:42:27 --> Output Class Initialized
INFO - 2016-11-13 01:42:27 --> Security Class Initialized
DEBUG - 2016-11-13 01:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:42:27 --> Input Class Initialized
INFO - 2016-11-13 01:42:27 --> Language Class Initialized
INFO - 2016-11-13 01:42:27 --> Loader Class Initialized
INFO - 2016-11-13 01:42:27 --> Helper loaded: url_helper
INFO - 2016-11-13 01:42:27 --> Helper loaded: form_helper
INFO - 2016-11-13 01:42:27 --> Database Driver Class Initialized
INFO - 2016-11-13 01:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:42:27 --> Controller Class Initialized
INFO - 2016-11-13 01:42:27 --> Model Class Initialized
INFO - 2016-11-13 01:42:27 --> Model Class Initialized
INFO - 2016-11-13 01:42:27 --> Model Class Initialized
INFO - 2016-11-13 01:42:27 --> Model Class Initialized
INFO - 2016-11-13 01:42:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:42:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:42:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:42:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:42:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:42:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:42:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:42:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:42:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:42:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:42:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:42:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:42:27 --> Final output sent to browser
DEBUG - 2016-11-13 01:42:27 --> Total execution time: 0.4167
INFO - 2016-11-13 01:42:34 --> Config Class Initialized
INFO - 2016-11-13 01:42:34 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:42:34 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:42:34 --> Utf8 Class Initialized
INFO - 2016-11-13 01:42:34 --> URI Class Initialized
INFO - 2016-11-13 01:42:34 --> Router Class Initialized
INFO - 2016-11-13 01:42:34 --> Output Class Initialized
INFO - 2016-11-13 01:42:34 --> Security Class Initialized
DEBUG - 2016-11-13 01:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:42:34 --> Input Class Initialized
INFO - 2016-11-13 01:42:34 --> Language Class Initialized
INFO - 2016-11-13 01:42:34 --> Loader Class Initialized
INFO - 2016-11-13 01:42:34 --> Helper loaded: url_helper
INFO - 2016-11-13 01:42:34 --> Helper loaded: form_helper
INFO - 2016-11-13 01:42:34 --> Database Driver Class Initialized
INFO - 2016-11-13 01:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:42:34 --> Controller Class Initialized
INFO - 2016-11-13 01:42:34 --> Model Class Initialized
INFO - 2016-11-13 01:42:34 --> Form Validation Class Initialized
ERROR - 2016-11-13 01:42:34 --> Severity: Notice --> Undefined variable: idrecord C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 60
ERROR - 2016-11-13 01:42:34 --> Severity: Notice --> Undefined variable: idstatus C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 62
ERROR - 2016-11-13 01:42:34 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 28
ERROR - 2016-11-13 01:42:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 28
INFO - 2016-11-13 01:42:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:42:34 --> Final output sent to browser
DEBUG - 2016-11-13 01:42:34 --> Total execution time: 0.2925
INFO - 2016-11-13 01:45:39 --> Config Class Initialized
INFO - 2016-11-13 01:45:39 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:45:39 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:45:39 --> Utf8 Class Initialized
INFO - 2016-11-13 01:45:39 --> URI Class Initialized
DEBUG - 2016-11-13 01:45:39 --> No URI present. Default controller set.
INFO - 2016-11-13 01:45:39 --> Router Class Initialized
INFO - 2016-11-13 01:45:39 --> Output Class Initialized
INFO - 2016-11-13 01:45:39 --> Security Class Initialized
DEBUG - 2016-11-13 01:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:45:39 --> Input Class Initialized
INFO - 2016-11-13 01:45:39 --> Language Class Initialized
INFO - 2016-11-13 01:45:39 --> Loader Class Initialized
INFO - 2016-11-13 01:45:39 --> Helper loaded: url_helper
INFO - 2016-11-13 01:45:39 --> Helper loaded: form_helper
INFO - 2016-11-13 01:45:39 --> Database Driver Class Initialized
INFO - 2016-11-13 01:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:45:39 --> Controller Class Initialized
INFO - 2016-11-13 01:45:39 --> Model Class Initialized
INFO - 2016-11-13 01:45:39 --> Model Class Initialized
INFO - 2016-11-13 01:45:39 --> Model Class Initialized
INFO - 2016-11-13 01:45:39 --> Model Class Initialized
INFO - 2016-11-13 01:45:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:45:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:45:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:45:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:45:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:45:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:45:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:45:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:45:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:45:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:45:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:45:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:45:39 --> Final output sent to browser
DEBUG - 2016-11-13 01:45:39 --> Total execution time: 0.4160
INFO - 2016-11-13 01:45:45 --> Config Class Initialized
INFO - 2016-11-13 01:45:45 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:45:45 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:45:45 --> Utf8 Class Initialized
INFO - 2016-11-13 01:45:45 --> URI Class Initialized
INFO - 2016-11-13 01:45:45 --> Router Class Initialized
INFO - 2016-11-13 01:45:45 --> Output Class Initialized
INFO - 2016-11-13 01:45:45 --> Security Class Initialized
DEBUG - 2016-11-13 01:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:45:45 --> Input Class Initialized
INFO - 2016-11-13 01:45:45 --> Language Class Initialized
INFO - 2016-11-13 01:45:45 --> Loader Class Initialized
INFO - 2016-11-13 01:45:45 --> Helper loaded: url_helper
INFO - 2016-11-13 01:45:45 --> Helper loaded: form_helper
INFO - 2016-11-13 01:45:45 --> Database Driver Class Initialized
INFO - 2016-11-13 01:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:45:45 --> Controller Class Initialized
INFO - 2016-11-13 01:45:45 --> Model Class Initialized
INFO - 2016-11-13 01:45:45 --> Form Validation Class Initialized
ERROR - 2016-11-13 01:45:45 --> Severity: Warning --> extract() expects parameter 1 to be array, string given C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 59
ERROR - 2016-11-13 01:45:45 --> Severity: Notice --> Undefined variable: idrecord C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 60
ERROR - 2016-11-13 01:45:45 --> Severity: Notice --> Undefined variable: idstatus C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 62
ERROR - 2016-11-13 01:45:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 28
ERROR - 2016-11-13 01:45:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 28
INFO - 2016-11-13 01:45:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:45:45 --> Final output sent to browser
DEBUG - 2016-11-13 01:45:45 --> Total execution time: 0.3025
INFO - 2016-11-13 01:46:21 --> Config Class Initialized
INFO - 2016-11-13 01:46:21 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:46:21 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:46:21 --> Utf8 Class Initialized
INFO - 2016-11-13 01:46:21 --> URI Class Initialized
DEBUG - 2016-11-13 01:46:21 --> No URI present. Default controller set.
INFO - 2016-11-13 01:46:21 --> Router Class Initialized
INFO - 2016-11-13 01:46:21 --> Output Class Initialized
INFO - 2016-11-13 01:46:21 --> Security Class Initialized
DEBUG - 2016-11-13 01:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:46:21 --> Input Class Initialized
INFO - 2016-11-13 01:46:21 --> Language Class Initialized
INFO - 2016-11-13 01:46:21 --> Loader Class Initialized
INFO - 2016-11-13 01:46:21 --> Helper loaded: url_helper
INFO - 2016-11-13 01:46:21 --> Helper loaded: form_helper
INFO - 2016-11-13 01:46:21 --> Database Driver Class Initialized
INFO - 2016-11-13 01:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:46:22 --> Controller Class Initialized
INFO - 2016-11-13 01:46:22 --> Model Class Initialized
INFO - 2016-11-13 01:46:22 --> Model Class Initialized
INFO - 2016-11-13 01:46:22 --> Model Class Initialized
INFO - 2016-11-13 01:46:22 --> Model Class Initialized
INFO - 2016-11-13 01:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:46:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:46:22 --> Final output sent to browser
DEBUG - 2016-11-13 01:46:22 --> Total execution time: 0.4274
INFO - 2016-11-13 01:46:27 --> Config Class Initialized
INFO - 2016-11-13 01:46:27 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:46:27 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:46:27 --> Utf8 Class Initialized
INFO - 2016-11-13 01:46:27 --> URI Class Initialized
INFO - 2016-11-13 01:46:27 --> Router Class Initialized
INFO - 2016-11-13 01:46:27 --> Output Class Initialized
INFO - 2016-11-13 01:46:27 --> Security Class Initialized
DEBUG - 2016-11-13 01:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:46:27 --> Input Class Initialized
INFO - 2016-11-13 01:46:27 --> Language Class Initialized
INFO - 2016-11-13 01:46:27 --> Loader Class Initialized
INFO - 2016-11-13 01:46:27 --> Helper loaded: url_helper
INFO - 2016-11-13 01:46:27 --> Helper loaded: form_helper
INFO - 2016-11-13 01:46:27 --> Database Driver Class Initialized
INFO - 2016-11-13 01:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:46:27 --> Controller Class Initialized
INFO - 2016-11-13 01:46:27 --> Model Class Initialized
INFO - 2016-11-13 01:46:27 --> Form Validation Class Initialized
ERROR - 2016-11-13 01:46:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 28
ERROR - 2016-11-13 01:46:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 28
INFO - 2016-11-13 01:46:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:46:28 --> Final output sent to browser
DEBUG - 2016-11-13 01:46:28 --> Total execution time: 0.4738
INFO - 2016-11-13 01:46:31 --> Config Class Initialized
INFO - 2016-11-13 01:46:31 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:46:31 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:46:31 --> Utf8 Class Initialized
INFO - 2016-11-13 01:46:31 --> URI Class Initialized
DEBUG - 2016-11-13 01:46:31 --> No URI present. Default controller set.
INFO - 2016-11-13 01:46:31 --> Router Class Initialized
INFO - 2016-11-13 01:46:31 --> Output Class Initialized
INFO - 2016-11-13 01:46:31 --> Security Class Initialized
DEBUG - 2016-11-13 01:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:46:31 --> Input Class Initialized
INFO - 2016-11-13 01:46:31 --> Language Class Initialized
INFO - 2016-11-13 01:46:31 --> Loader Class Initialized
INFO - 2016-11-13 01:46:31 --> Helper loaded: url_helper
INFO - 2016-11-13 01:46:31 --> Helper loaded: form_helper
INFO - 2016-11-13 01:46:31 --> Database Driver Class Initialized
INFO - 2016-11-13 01:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:46:31 --> Controller Class Initialized
INFO - 2016-11-13 01:46:31 --> Model Class Initialized
INFO - 2016-11-13 01:46:31 --> Model Class Initialized
INFO - 2016-11-13 01:46:31 --> Model Class Initialized
INFO - 2016-11-13 01:46:31 --> Model Class Initialized
INFO - 2016-11-13 01:46:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:46:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:46:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:46:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:46:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:46:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:46:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:46:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:46:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:46:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:46:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:46:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:46:31 --> Final output sent to browser
DEBUG - 2016-11-13 01:46:31 --> Total execution time: 0.4780
INFO - 2016-11-13 01:46:54 --> Config Class Initialized
INFO - 2016-11-13 01:46:54 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:46:54 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:46:54 --> Utf8 Class Initialized
INFO - 2016-11-13 01:46:54 --> URI Class Initialized
INFO - 2016-11-13 01:46:54 --> Router Class Initialized
INFO - 2016-11-13 01:46:54 --> Output Class Initialized
INFO - 2016-11-13 01:46:54 --> Security Class Initialized
DEBUG - 2016-11-13 01:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:46:54 --> Input Class Initialized
INFO - 2016-11-13 01:46:55 --> Language Class Initialized
INFO - 2016-11-13 01:46:55 --> Loader Class Initialized
INFO - 2016-11-13 01:46:55 --> Helper loaded: url_helper
INFO - 2016-11-13 01:46:55 --> Helper loaded: form_helper
INFO - 2016-11-13 01:46:55 --> Database Driver Class Initialized
INFO - 2016-11-13 01:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:46:55 --> Controller Class Initialized
INFO - 2016-11-13 01:46:55 --> Model Class Initialized
INFO - 2016-11-13 01:46:55 --> Form Validation Class Initialized
ERROR - 2016-11-13 01:46:55 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 28
ERROR - 2016-11-13 01:46:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 28
INFO - 2016-11-13 01:46:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:46:55 --> Final output sent to browser
DEBUG - 2016-11-13 01:46:55 --> Total execution time: 0.4292
INFO - 2016-11-13 01:50:56 --> Config Class Initialized
INFO - 2016-11-13 01:50:56 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:50:56 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:50:56 --> Utf8 Class Initialized
INFO - 2016-11-13 01:50:56 --> URI Class Initialized
DEBUG - 2016-11-13 01:50:56 --> No URI present. Default controller set.
INFO - 2016-11-13 01:50:56 --> Router Class Initialized
INFO - 2016-11-13 01:50:56 --> Output Class Initialized
INFO - 2016-11-13 01:50:56 --> Security Class Initialized
DEBUG - 2016-11-13 01:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:50:56 --> Input Class Initialized
INFO - 2016-11-13 01:50:56 --> Language Class Initialized
INFO - 2016-11-13 01:50:56 --> Loader Class Initialized
INFO - 2016-11-13 01:50:56 --> Helper loaded: url_helper
INFO - 2016-11-13 01:50:56 --> Helper loaded: form_helper
INFO - 2016-11-13 01:50:56 --> Database Driver Class Initialized
INFO - 2016-11-13 01:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:50:56 --> Controller Class Initialized
INFO - 2016-11-13 01:50:56 --> Model Class Initialized
INFO - 2016-11-13 01:50:56 --> Model Class Initialized
INFO - 2016-11-13 01:50:56 --> Model Class Initialized
INFO - 2016-11-13 01:50:56 --> Model Class Initialized
INFO - 2016-11-13 01:50:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:50:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:50:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:50:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:50:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:50:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:50:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:50:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:50:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:50:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:50:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:50:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:50:56 --> Final output sent to browser
DEBUG - 2016-11-13 01:50:56 --> Total execution time: 0.4629
INFO - 2016-11-13 01:51:07 --> Config Class Initialized
INFO - 2016-11-13 01:51:08 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:51:08 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:51:08 --> Utf8 Class Initialized
INFO - 2016-11-13 01:51:08 --> URI Class Initialized
INFO - 2016-11-13 01:51:08 --> Router Class Initialized
INFO - 2016-11-13 01:51:08 --> Output Class Initialized
INFO - 2016-11-13 01:51:08 --> Security Class Initialized
DEBUG - 2016-11-13 01:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:51:08 --> Input Class Initialized
INFO - 2016-11-13 01:51:08 --> Language Class Initialized
INFO - 2016-11-13 01:51:08 --> Loader Class Initialized
INFO - 2016-11-13 01:51:08 --> Helper loaded: url_helper
INFO - 2016-11-13 01:51:08 --> Helper loaded: form_helper
INFO - 2016-11-13 01:51:08 --> Database Driver Class Initialized
INFO - 2016-11-13 01:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:51:08 --> Controller Class Initialized
INFO - 2016-11-13 01:51:08 --> Model Class Initialized
INFO - 2016-11-13 01:51:08 --> Form Validation Class Initialized
ERROR - 2016-11-13 01:51:08 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-13 01:51:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-13 01:51:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:51:08 --> Final output sent to browser
DEBUG - 2016-11-13 01:51:08 --> Total execution time: 0.4156
INFO - 2016-11-13 01:51:43 --> Config Class Initialized
INFO - 2016-11-13 01:51:43 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:51:43 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:51:43 --> Utf8 Class Initialized
INFO - 2016-11-13 01:51:43 --> URI Class Initialized
DEBUG - 2016-11-13 01:51:43 --> No URI present. Default controller set.
INFO - 2016-11-13 01:51:43 --> Router Class Initialized
INFO - 2016-11-13 01:51:43 --> Output Class Initialized
INFO - 2016-11-13 01:51:43 --> Security Class Initialized
DEBUG - 2016-11-13 01:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:51:43 --> Input Class Initialized
INFO - 2016-11-13 01:51:43 --> Language Class Initialized
INFO - 2016-11-13 01:51:43 --> Loader Class Initialized
INFO - 2016-11-13 01:51:43 --> Helper loaded: url_helper
INFO - 2016-11-13 01:51:43 --> Helper loaded: form_helper
INFO - 2016-11-13 01:51:43 --> Database Driver Class Initialized
INFO - 2016-11-13 01:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:51:44 --> Controller Class Initialized
INFO - 2016-11-13 01:51:44 --> Model Class Initialized
INFO - 2016-11-13 01:51:44 --> Model Class Initialized
INFO - 2016-11-13 01:51:44 --> Model Class Initialized
INFO - 2016-11-13 01:51:44 --> Model Class Initialized
INFO - 2016-11-13 01:51:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:51:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:51:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:51:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:51:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:51:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:51:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:51:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:51:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:51:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:51:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:51:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:51:44 --> Final output sent to browser
DEBUG - 2016-11-13 01:51:44 --> Total execution time: 0.4495
INFO - 2016-11-13 01:51:56 --> Config Class Initialized
INFO - 2016-11-13 01:51:56 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:51:56 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:51:56 --> Utf8 Class Initialized
INFO - 2016-11-13 01:51:56 --> URI Class Initialized
INFO - 2016-11-13 01:51:56 --> Router Class Initialized
INFO - 2016-11-13 01:51:56 --> Output Class Initialized
INFO - 2016-11-13 01:51:56 --> Security Class Initialized
DEBUG - 2016-11-13 01:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:51:56 --> Input Class Initialized
INFO - 2016-11-13 01:51:56 --> Language Class Initialized
INFO - 2016-11-13 01:51:56 --> Loader Class Initialized
INFO - 2016-11-13 01:51:56 --> Helper loaded: url_helper
INFO - 2016-11-13 01:51:56 --> Helper loaded: form_helper
INFO - 2016-11-13 01:51:56 --> Database Driver Class Initialized
INFO - 2016-11-13 01:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:51:56 --> Controller Class Initialized
INFO - 2016-11-13 01:51:56 --> Model Class Initialized
INFO - 2016-11-13 01:51:56 --> Form Validation Class Initialized
ERROR - 2016-11-13 01:51:56 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-13 01:51:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-13 01:51:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:51:57 --> Final output sent to browser
DEBUG - 2016-11-13 01:51:57 --> Total execution time: 0.3858
INFO - 2016-11-13 01:54:46 --> Config Class Initialized
INFO - 2016-11-13 01:54:46 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:54:46 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:54:46 --> Utf8 Class Initialized
INFO - 2016-11-13 01:54:46 --> URI Class Initialized
DEBUG - 2016-11-13 01:54:46 --> No URI present. Default controller set.
INFO - 2016-11-13 01:54:46 --> Router Class Initialized
INFO - 2016-11-13 01:54:46 --> Output Class Initialized
INFO - 2016-11-13 01:54:46 --> Security Class Initialized
DEBUG - 2016-11-13 01:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:54:46 --> Input Class Initialized
INFO - 2016-11-13 01:54:46 --> Language Class Initialized
INFO - 2016-11-13 01:54:46 --> Loader Class Initialized
INFO - 2016-11-13 01:54:46 --> Helper loaded: url_helper
INFO - 2016-11-13 01:54:46 --> Helper loaded: form_helper
INFO - 2016-11-13 01:54:46 --> Database Driver Class Initialized
INFO - 2016-11-13 01:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:54:46 --> Controller Class Initialized
INFO - 2016-11-13 01:54:46 --> Model Class Initialized
INFO - 2016-11-13 01:54:46 --> Model Class Initialized
INFO - 2016-11-13 01:54:46 --> Model Class Initialized
INFO - 2016-11-13 01:54:46 --> Model Class Initialized
INFO - 2016-11-13 01:54:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:54:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:54:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:54:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:54:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:54:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:54:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:54:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:54:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:54:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:54:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:54:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:54:46 --> Final output sent to browser
DEBUG - 2016-11-13 01:54:46 --> Total execution time: 0.4527
INFO - 2016-11-13 01:54:56 --> Config Class Initialized
INFO - 2016-11-13 01:54:56 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:54:56 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:54:56 --> Utf8 Class Initialized
INFO - 2016-11-13 01:54:56 --> URI Class Initialized
INFO - 2016-11-13 01:54:56 --> Router Class Initialized
INFO - 2016-11-13 01:54:56 --> Output Class Initialized
INFO - 2016-11-13 01:54:56 --> Security Class Initialized
DEBUG - 2016-11-13 01:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:54:56 --> Input Class Initialized
INFO - 2016-11-13 01:54:56 --> Language Class Initialized
INFO - 2016-11-13 01:54:56 --> Loader Class Initialized
INFO - 2016-11-13 01:54:56 --> Helper loaded: url_helper
INFO - 2016-11-13 01:54:56 --> Helper loaded: form_helper
INFO - 2016-11-13 01:54:56 --> Database Driver Class Initialized
INFO - 2016-11-13 01:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:54:56 --> Controller Class Initialized
INFO - 2016-11-13 01:54:56 --> Model Class Initialized
INFO - 2016-11-13 01:54:56 --> Form Validation Class Initialized
ERROR - 2016-11-13 01:54:56 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-13 01:54:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-13 01:54:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:54:56 --> Final output sent to browser
DEBUG - 2016-11-13 01:54:56 --> Total execution time: 0.3660
INFO - 2016-11-13 01:55:48 --> Config Class Initialized
INFO - 2016-11-13 01:55:48 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:55:48 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:55:48 --> Utf8 Class Initialized
INFO - 2016-11-13 01:55:48 --> URI Class Initialized
DEBUG - 2016-11-13 01:55:48 --> No URI present. Default controller set.
INFO - 2016-11-13 01:55:48 --> Router Class Initialized
INFO - 2016-11-13 01:55:48 --> Output Class Initialized
INFO - 2016-11-13 01:55:48 --> Security Class Initialized
DEBUG - 2016-11-13 01:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:55:48 --> Input Class Initialized
INFO - 2016-11-13 01:55:48 --> Language Class Initialized
INFO - 2016-11-13 01:55:48 --> Loader Class Initialized
INFO - 2016-11-13 01:55:48 --> Helper loaded: url_helper
INFO - 2016-11-13 01:55:48 --> Helper loaded: form_helper
INFO - 2016-11-13 01:55:48 --> Database Driver Class Initialized
INFO - 2016-11-13 01:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:55:48 --> Controller Class Initialized
INFO - 2016-11-13 01:55:48 --> Model Class Initialized
INFO - 2016-11-13 01:55:48 --> Model Class Initialized
INFO - 2016-11-13 01:55:48 --> Model Class Initialized
INFO - 2016-11-13 01:55:48 --> Model Class Initialized
INFO - 2016-11-13 01:55:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:55:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:55:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:55:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:55:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:55:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:55:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:55:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:55:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:55:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:55:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:55:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:55:48 --> Final output sent to browser
DEBUG - 2016-11-13 01:55:48 --> Total execution time: 0.4537
INFO - 2016-11-13 01:55:54 --> Config Class Initialized
INFO - 2016-11-13 01:55:54 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:55:54 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:55:54 --> Utf8 Class Initialized
INFO - 2016-11-13 01:55:54 --> URI Class Initialized
INFO - 2016-11-13 01:55:54 --> Router Class Initialized
INFO - 2016-11-13 01:55:54 --> Output Class Initialized
INFO - 2016-11-13 01:55:54 --> Security Class Initialized
DEBUG - 2016-11-13 01:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:55:54 --> Input Class Initialized
INFO - 2016-11-13 01:55:54 --> Language Class Initialized
INFO - 2016-11-13 01:55:54 --> Loader Class Initialized
INFO - 2016-11-13 01:55:54 --> Helper loaded: url_helper
INFO - 2016-11-13 01:55:55 --> Helper loaded: form_helper
INFO - 2016-11-13 01:55:55 --> Database Driver Class Initialized
INFO - 2016-11-13 01:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:55:55 --> Controller Class Initialized
INFO - 2016-11-13 01:55:55 --> Model Class Initialized
INFO - 2016-11-13 01:55:55 --> Form Validation Class Initialized
ERROR - 2016-11-13 01:55:55 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-13 01:55:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-13 01:55:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:55:55 --> Final output sent to browser
DEBUG - 2016-11-13 01:55:55 --> Total execution time: 0.3965
INFO - 2016-11-13 01:56:06 --> Config Class Initialized
INFO - 2016-11-13 01:56:06 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:56:06 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:56:06 --> Utf8 Class Initialized
INFO - 2016-11-13 01:56:06 --> URI Class Initialized
INFO - 2016-11-13 01:56:06 --> Router Class Initialized
INFO - 2016-11-13 01:56:06 --> Output Class Initialized
INFO - 2016-11-13 01:56:06 --> Security Class Initialized
DEBUG - 2016-11-13 01:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:56:06 --> Input Class Initialized
INFO - 2016-11-13 01:56:06 --> Language Class Initialized
INFO - 2016-11-13 01:56:06 --> Loader Class Initialized
INFO - 2016-11-13 01:56:06 --> Helper loaded: url_helper
INFO - 2016-11-13 01:56:06 --> Helper loaded: form_helper
INFO - 2016-11-13 01:56:06 --> Database Driver Class Initialized
INFO - 2016-11-13 01:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:56:06 --> Controller Class Initialized
INFO - 2016-11-13 01:56:06 --> Model Class Initialized
INFO - 2016-11-13 01:56:06 --> Model Class Initialized
INFO - 2016-11-13 01:56:06 --> Model Class Initialized
INFO - 2016-11-13 01:56:06 --> Model Class Initialized
DEBUG - 2016-11-13 01:56:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-13 01:56:06 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-13 01:56:06 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-13 01:56:06 --> Config Class Initialized
INFO - 2016-11-13 01:56:06 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:56:06 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:56:06 --> Utf8 Class Initialized
INFO - 2016-11-13 01:56:06 --> URI Class Initialized
DEBUG - 2016-11-13 01:56:06 --> No URI present. Default controller set.
INFO - 2016-11-13 01:56:06 --> Router Class Initialized
INFO - 2016-11-13 01:56:06 --> Output Class Initialized
INFO - 2016-11-13 01:56:06 --> Security Class Initialized
DEBUG - 2016-11-13 01:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:56:06 --> Input Class Initialized
INFO - 2016-11-13 01:56:06 --> Language Class Initialized
INFO - 2016-11-13 01:56:06 --> Loader Class Initialized
INFO - 2016-11-13 01:56:06 --> Helper loaded: url_helper
INFO - 2016-11-13 01:56:06 --> Helper loaded: form_helper
INFO - 2016-11-13 01:56:06 --> Database Driver Class Initialized
INFO - 2016-11-13 01:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:56:06 --> Controller Class Initialized
INFO - 2016-11-13 01:56:06 --> Model Class Initialized
INFO - 2016-11-13 01:56:06 --> Model Class Initialized
INFO - 2016-11-13 01:56:06 --> Model Class Initialized
INFO - 2016-11-13 01:56:06 --> Model Class Initialized
INFO - 2016-11-13 01:56:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:56:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-13 01:56:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:56:07 --> Final output sent to browser
DEBUG - 2016-11-13 01:56:07 --> Total execution time: 0.3837
INFO - 2016-11-13 01:56:17 --> Config Class Initialized
INFO - 2016-11-13 01:56:17 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:56:17 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:56:17 --> Utf8 Class Initialized
INFO - 2016-11-13 01:56:17 --> URI Class Initialized
DEBUG - 2016-11-13 01:56:17 --> No URI present. Default controller set.
INFO - 2016-11-13 01:56:17 --> Router Class Initialized
INFO - 2016-11-13 01:56:17 --> Output Class Initialized
INFO - 2016-11-13 01:56:17 --> Security Class Initialized
DEBUG - 2016-11-13 01:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:56:18 --> Input Class Initialized
INFO - 2016-11-13 01:56:18 --> Language Class Initialized
INFO - 2016-11-13 01:56:18 --> Loader Class Initialized
INFO - 2016-11-13 01:56:18 --> Helper loaded: url_helper
INFO - 2016-11-13 01:56:18 --> Helper loaded: form_helper
INFO - 2016-11-13 01:56:18 --> Database Driver Class Initialized
INFO - 2016-11-13 01:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:56:18 --> Controller Class Initialized
INFO - 2016-11-13 01:56:18 --> Model Class Initialized
INFO - 2016-11-13 01:56:18 --> Model Class Initialized
INFO - 2016-11-13 01:56:18 --> Model Class Initialized
INFO - 2016-11-13 01:56:18 --> Model Class Initialized
INFO - 2016-11-13 01:56:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:56:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-13 01:56:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:56:18 --> Final output sent to browser
DEBUG - 2016-11-13 01:56:18 --> Total execution time: 0.3630
INFO - 2016-11-13 01:56:23 --> Config Class Initialized
INFO - 2016-11-13 01:56:23 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:56:23 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:56:23 --> Utf8 Class Initialized
INFO - 2016-11-13 01:56:23 --> URI Class Initialized
INFO - 2016-11-13 01:56:23 --> Router Class Initialized
INFO - 2016-11-13 01:56:23 --> Output Class Initialized
INFO - 2016-11-13 01:56:24 --> Security Class Initialized
DEBUG - 2016-11-13 01:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:56:24 --> Input Class Initialized
INFO - 2016-11-13 01:56:24 --> Language Class Initialized
INFO - 2016-11-13 01:56:24 --> Loader Class Initialized
INFO - 2016-11-13 01:56:24 --> Helper loaded: url_helper
INFO - 2016-11-13 01:56:24 --> Helper loaded: form_helper
INFO - 2016-11-13 01:56:24 --> Database Driver Class Initialized
INFO - 2016-11-13 01:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:56:24 --> Controller Class Initialized
INFO - 2016-11-13 01:56:24 --> Model Class Initialized
INFO - 2016-11-13 01:56:24 --> Model Class Initialized
INFO - 2016-11-13 01:56:24 --> Model Class Initialized
INFO - 2016-11-13 01:56:24 --> Model Class Initialized
DEBUG - 2016-11-13 01:56:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-13 01:56:24 --> Model Class Initialized
INFO - 2016-11-13 01:56:24 --> Final output sent to browser
DEBUG - 2016-11-13 01:56:24 --> Total execution time: 0.3127
INFO - 2016-11-13 01:56:24 --> Config Class Initialized
INFO - 2016-11-13 01:56:24 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:56:24 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:56:24 --> Utf8 Class Initialized
INFO - 2016-11-13 01:56:24 --> URI Class Initialized
DEBUG - 2016-11-13 01:56:24 --> No URI present. Default controller set.
INFO - 2016-11-13 01:56:24 --> Router Class Initialized
INFO - 2016-11-13 01:56:24 --> Output Class Initialized
INFO - 2016-11-13 01:56:24 --> Security Class Initialized
DEBUG - 2016-11-13 01:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:56:24 --> Input Class Initialized
INFO - 2016-11-13 01:56:24 --> Language Class Initialized
INFO - 2016-11-13 01:56:24 --> Loader Class Initialized
INFO - 2016-11-13 01:56:24 --> Helper loaded: url_helper
INFO - 2016-11-13 01:56:24 --> Helper loaded: form_helper
INFO - 2016-11-13 01:56:24 --> Database Driver Class Initialized
INFO - 2016-11-13 01:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:56:24 --> Controller Class Initialized
INFO - 2016-11-13 01:56:24 --> Model Class Initialized
INFO - 2016-11-13 01:56:24 --> Model Class Initialized
INFO - 2016-11-13 01:56:24 --> Model Class Initialized
INFO - 2016-11-13 01:56:24 --> Model Class Initialized
INFO - 2016-11-13 01:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 01:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 01:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 01:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 01:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 01:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 01:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 01:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 01:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 01:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 01:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 01:56:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 01:56:24 --> Final output sent to browser
DEBUG - 2016-11-13 01:56:24 --> Total execution time: 0.4434
INFO - 2016-11-13 01:57:34 --> Config Class Initialized
INFO - 2016-11-13 01:57:34 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:57:34 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:57:34 --> Utf8 Class Initialized
INFO - 2016-11-13 01:57:34 --> URI Class Initialized
INFO - 2016-11-13 01:57:34 --> Router Class Initialized
INFO - 2016-11-13 01:57:34 --> Output Class Initialized
INFO - 2016-11-13 01:57:34 --> Security Class Initialized
DEBUG - 2016-11-13 01:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:57:34 --> Input Class Initialized
INFO - 2016-11-13 01:57:34 --> Language Class Initialized
INFO - 2016-11-13 01:57:35 --> Loader Class Initialized
INFO - 2016-11-13 01:57:35 --> Helper loaded: url_helper
INFO - 2016-11-13 01:57:35 --> Helper loaded: form_helper
INFO - 2016-11-13 01:57:35 --> Database Driver Class Initialized
INFO - 2016-11-13 01:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:57:35 --> Controller Class Initialized
INFO - 2016-11-13 01:57:35 --> Model Class Initialized
INFO - 2016-11-13 01:57:35 --> Form Validation Class Initialized
INFO - 2016-11-13 01:57:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 01:57:35 --> Final output sent to browser
DEBUG - 2016-11-13 01:57:35 --> Total execution time: 0.2993
INFO - 2016-11-13 01:57:45 --> Config Class Initialized
INFO - 2016-11-13 01:57:45 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:57:45 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:57:45 --> Utf8 Class Initialized
INFO - 2016-11-13 01:57:45 --> URI Class Initialized
INFO - 2016-11-13 01:57:45 --> Router Class Initialized
INFO - 2016-11-13 01:57:45 --> Output Class Initialized
INFO - 2016-11-13 01:57:45 --> Security Class Initialized
DEBUG - 2016-11-13 01:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:57:45 --> Input Class Initialized
INFO - 2016-11-13 01:57:45 --> Language Class Initialized
INFO - 2016-11-13 01:57:45 --> Loader Class Initialized
INFO - 2016-11-13 01:57:45 --> Helper loaded: url_helper
INFO - 2016-11-13 01:57:45 --> Helper loaded: form_helper
INFO - 2016-11-13 01:57:45 --> Database Driver Class Initialized
INFO - 2016-11-13 01:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:57:45 --> Controller Class Initialized
INFO - 2016-11-13 01:57:45 --> Model Class Initialized
INFO - 2016-11-13 01:57:45 --> Form Validation Class Initialized
INFO - 2016-11-13 01:57:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 01:57:45 --> Final output sent to browser
DEBUG - 2016-11-13 01:57:45 --> Total execution time: 0.2613
INFO - 2016-11-13 01:57:49 --> Config Class Initialized
INFO - 2016-11-13 01:57:49 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:57:49 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:57:49 --> Utf8 Class Initialized
INFO - 2016-11-13 01:57:50 --> URI Class Initialized
INFO - 2016-11-13 01:57:50 --> Router Class Initialized
INFO - 2016-11-13 01:57:50 --> Output Class Initialized
INFO - 2016-11-13 01:57:50 --> Security Class Initialized
DEBUG - 2016-11-13 01:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:57:50 --> Input Class Initialized
INFO - 2016-11-13 01:57:50 --> Language Class Initialized
INFO - 2016-11-13 01:57:50 --> Loader Class Initialized
INFO - 2016-11-13 01:57:50 --> Helper loaded: url_helper
INFO - 2016-11-13 01:57:50 --> Helper loaded: form_helper
INFO - 2016-11-13 01:57:50 --> Database Driver Class Initialized
INFO - 2016-11-13 01:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:57:50 --> Controller Class Initialized
INFO - 2016-11-13 01:57:50 --> Model Class Initialized
INFO - 2016-11-13 01:57:50 --> Form Validation Class Initialized
INFO - 2016-11-13 01:57:50 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 01:57:50 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 01:57:50 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '4', '3', '2016-11-13 01:57:50', '1', '')
INFO - 2016-11-13 01:57:50 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 01:58:00 --> Config Class Initialized
INFO - 2016-11-13 01:58:00 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:58:00 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:58:00 --> Utf8 Class Initialized
INFO - 2016-11-13 01:58:00 --> URI Class Initialized
INFO - 2016-11-13 01:58:00 --> Router Class Initialized
INFO - 2016-11-13 01:58:00 --> Output Class Initialized
INFO - 2016-11-13 01:58:00 --> Security Class Initialized
DEBUG - 2016-11-13 01:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:58:00 --> Input Class Initialized
INFO - 2016-11-13 01:58:00 --> Language Class Initialized
INFO - 2016-11-13 01:58:00 --> Loader Class Initialized
INFO - 2016-11-13 01:58:00 --> Helper loaded: url_helper
INFO - 2016-11-13 01:58:00 --> Helper loaded: form_helper
INFO - 2016-11-13 01:58:00 --> Database Driver Class Initialized
INFO - 2016-11-13 01:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:58:00 --> Controller Class Initialized
INFO - 2016-11-13 01:58:00 --> Model Class Initialized
INFO - 2016-11-13 01:58:00 --> Form Validation Class Initialized
INFO - 2016-11-13 01:58:00 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 01:58:00 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 01:58:00 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '6', '3', '2016-11-13 01:58:00', '1', '')
INFO - 2016-11-13 01:58:00 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 01:58:00 --> Config Class Initialized
INFO - 2016-11-13 01:58:00 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:58:00 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:58:00 --> Utf8 Class Initialized
INFO - 2016-11-13 01:58:00 --> URI Class Initialized
INFO - 2016-11-13 01:58:00 --> Router Class Initialized
INFO - 2016-11-13 01:58:00 --> Output Class Initialized
INFO - 2016-11-13 01:58:01 --> Security Class Initialized
DEBUG - 2016-11-13 01:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:58:01 --> Input Class Initialized
INFO - 2016-11-13 01:58:01 --> Language Class Initialized
INFO - 2016-11-13 01:58:01 --> Loader Class Initialized
INFO - 2016-11-13 01:58:01 --> Helper loaded: url_helper
INFO - 2016-11-13 01:58:01 --> Helper loaded: form_helper
INFO - 2016-11-13 01:58:01 --> Config Class Initialized
INFO - 2016-11-13 01:58:01 --> Database Driver Class Initialized
INFO - 2016-11-13 01:58:01 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:58:01 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:58:01 --> Utf8 Class Initialized
INFO - 2016-11-13 01:58:01 --> Controller Class Initialized
INFO - 2016-11-13 01:58:01 --> URI Class Initialized
INFO - 2016-11-13 01:58:01 --> Model Class Initialized
INFO - 2016-11-13 01:58:01 --> Router Class Initialized
INFO - 2016-11-13 01:58:01 --> Form Validation Class Initialized
INFO - 2016-11-13 01:58:01 --> Output Class Initialized
INFO - 2016-11-13 01:58:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 01:58:01 --> Security Class Initialized
ERROR - 2016-11-13 01:58:01 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
DEBUG - 2016-11-13 01:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:58:01 --> Input Class Initialized
INFO - 2016-11-13 01:58:01 --> Language Class Initialized
INFO - 2016-11-13 01:58:01 --> Loader Class Initialized
INFO - 2016-11-13 01:58:01 --> Helper loaded: url_helper
INFO - 2016-11-13 01:58:01 --> Helper loaded: form_helper
INFO - 2016-11-13 01:58:01 --> Database Driver Class Initialized
ERROR - 2016-11-13 01:58:01 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '6', '3', '2016-11-13 01:58:01', '1', '')
INFO - 2016-11-13 01:58:01 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 01:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:58:01 --> Controller Class Initialized
INFO - 2016-11-13 01:58:01 --> Model Class Initialized
INFO - 2016-11-13 01:58:01 --> Form Validation Class Initialized
INFO - 2016-11-13 01:58:01 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 01:58:01 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 01:58:01 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '6', '3', '2016-11-13 01:58:01', '1', '')
INFO - 2016-11-13 01:58:01 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 01:58:01 --> Config Class Initialized
INFO - 2016-11-13 01:58:01 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:58:01 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:58:01 --> Utf8 Class Initialized
INFO - 2016-11-13 01:58:01 --> URI Class Initialized
INFO - 2016-11-13 01:58:01 --> Router Class Initialized
INFO - 2016-11-13 01:58:01 --> Output Class Initialized
INFO - 2016-11-13 01:58:01 --> Security Class Initialized
DEBUG - 2016-11-13 01:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:58:01 --> Input Class Initialized
INFO - 2016-11-13 01:58:01 --> Language Class Initialized
INFO - 2016-11-13 01:58:01 --> Loader Class Initialized
INFO - 2016-11-13 01:58:01 --> Helper loaded: url_helper
INFO - 2016-11-13 01:58:01 --> Helper loaded: form_helper
INFO - 2016-11-13 01:58:01 --> Database Driver Class Initialized
INFO - 2016-11-13 01:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:58:01 --> Controller Class Initialized
INFO - 2016-11-13 01:58:01 --> Model Class Initialized
INFO - 2016-11-13 01:58:01 --> Form Validation Class Initialized
INFO - 2016-11-13 01:58:01 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 01:58:01 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 01:58:02 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '6', '3', '2016-11-13 01:58:01', '1', '')
INFO - 2016-11-13 01:58:02 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 01:58:02 --> Config Class Initialized
INFO - 2016-11-13 01:58:02 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:58:02 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:58:02 --> Utf8 Class Initialized
INFO - 2016-11-13 01:58:02 --> URI Class Initialized
INFO - 2016-11-13 01:58:02 --> Router Class Initialized
INFO - 2016-11-13 01:58:02 --> Output Class Initialized
INFO - 2016-11-13 01:58:02 --> Security Class Initialized
DEBUG - 2016-11-13 01:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:58:02 --> Input Class Initialized
INFO - 2016-11-13 01:58:02 --> Language Class Initialized
INFO - 2016-11-13 01:58:02 --> Loader Class Initialized
INFO - 2016-11-13 01:58:02 --> Helper loaded: url_helper
INFO - 2016-11-13 01:58:02 --> Helper loaded: form_helper
INFO - 2016-11-13 01:58:02 --> Database Driver Class Initialized
INFO - 2016-11-13 01:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:58:02 --> Config Class Initialized
INFO - 2016-11-13 01:58:02 --> Controller Class Initialized
INFO - 2016-11-13 01:58:02 --> Hooks Class Initialized
INFO - 2016-11-13 01:58:02 --> Model Class Initialized
DEBUG - 2016-11-13 01:58:02 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:58:02 --> Form Validation Class Initialized
INFO - 2016-11-13 01:58:02 --> Utf8 Class Initialized
INFO - 2016-11-13 01:58:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 01:58:02 --> URI Class Initialized
ERROR - 2016-11-13 01:58:02 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 01:58:02 --> Router Class Initialized
INFO - 2016-11-13 01:58:02 --> Output Class Initialized
INFO - 2016-11-13 01:58:03 --> Security Class Initialized
ERROR - 2016-11-13 01:58:03 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '6', '3', '2016-11-13 01:58:02', '1', '')
DEBUG - 2016-11-13 01:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:58:03 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 01:58:03 --> Config Class Initialized
INFO - 2016-11-13 01:58:03 --> Input Class Initialized
INFO - 2016-11-13 01:58:03 --> Hooks Class Initialized
INFO - 2016-11-13 01:58:03 --> Language Class Initialized
DEBUG - 2016-11-13 01:58:03 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:58:03 --> Loader Class Initialized
INFO - 2016-11-13 01:58:03 --> Utf8 Class Initialized
INFO - 2016-11-13 01:58:03 --> URI Class Initialized
INFO - 2016-11-13 01:58:03 --> Helper loaded: url_helper
INFO - 2016-11-13 01:58:03 --> Router Class Initialized
INFO - 2016-11-13 01:58:03 --> Helper loaded: form_helper
INFO - 2016-11-13 01:58:03 --> Output Class Initialized
INFO - 2016-11-13 01:58:03 --> Database Driver Class Initialized
INFO - 2016-11-13 01:58:03 --> Security Class Initialized
INFO - 2016-11-13 01:58:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-13 01:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:58:03 --> Controller Class Initialized
INFO - 2016-11-13 01:58:03 --> Input Class Initialized
INFO - 2016-11-13 01:58:03 --> Model Class Initialized
INFO - 2016-11-13 01:58:03 --> Language Class Initialized
INFO - 2016-11-13 01:58:03 --> Form Validation Class Initialized
INFO - 2016-11-13 01:58:03 --> Loader Class Initialized
INFO - 2016-11-13 01:58:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 01:58:03 --> Helper loaded: url_helper
ERROR - 2016-11-13 01:58:03 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 01:58:03 --> Helper loaded: form_helper
INFO - 2016-11-13 01:58:03 --> Database Driver Class Initialized
ERROR - 2016-11-13 01:58:03 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '6', '3', '2016-11-13 01:58:03', '1', '')
INFO - 2016-11-13 01:58:03 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 01:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:58:03 --> Controller Class Initialized
INFO - 2016-11-13 01:58:03 --> Model Class Initialized
INFO - 2016-11-13 01:58:03 --> Form Validation Class Initialized
INFO - 2016-11-13 01:58:03 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 01:58:03 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 01:58:03 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '6', '3', '2016-11-13 01:58:03', '1', '')
INFO - 2016-11-13 01:58:03 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 01:58:28 --> Config Class Initialized
INFO - 2016-11-13 01:58:28 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:58:28 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:58:28 --> Utf8 Class Initialized
INFO - 2016-11-13 01:58:28 --> URI Class Initialized
INFO - 2016-11-13 01:58:28 --> Router Class Initialized
INFO - 2016-11-13 01:58:28 --> Output Class Initialized
INFO - 2016-11-13 01:58:28 --> Security Class Initialized
DEBUG - 2016-11-13 01:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:58:28 --> Input Class Initialized
INFO - 2016-11-13 01:58:28 --> Language Class Initialized
INFO - 2016-11-13 01:58:28 --> Loader Class Initialized
INFO - 2016-11-13 01:58:28 --> Helper loaded: url_helper
INFO - 2016-11-13 01:58:28 --> Helper loaded: form_helper
INFO - 2016-11-13 01:58:28 --> Database Driver Class Initialized
INFO - 2016-11-13 01:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:58:28 --> Controller Class Initialized
INFO - 2016-11-13 01:58:28 --> Model Class Initialized
INFO - 2016-11-13 01:58:28 --> Form Validation Class Initialized
INFO - 2016-11-13 01:58:28 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 01:58:28 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 01:58:28 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '6', '3', '2016-11-13 01:58:28', '1', '')
INFO - 2016-11-13 01:58:28 --> Config Class Initialized
INFO - 2016-11-13 01:58:28 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 01:58:28 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:58:28 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:58:28 --> Utf8 Class Initialized
INFO - 2016-11-13 01:58:28 --> URI Class Initialized
INFO - 2016-11-13 01:58:28 --> Router Class Initialized
INFO - 2016-11-13 01:58:28 --> Output Class Initialized
INFO - 2016-11-13 01:58:28 --> Security Class Initialized
DEBUG - 2016-11-13 01:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:58:28 --> Input Class Initialized
INFO - 2016-11-13 01:58:28 --> Config Class Initialized
INFO - 2016-11-13 01:58:28 --> Language Class Initialized
INFO - 2016-11-13 01:58:28 --> Hooks Class Initialized
INFO - 2016-11-13 01:58:28 --> Loader Class Initialized
DEBUG - 2016-11-13 01:58:28 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:58:28 --> Utf8 Class Initialized
INFO - 2016-11-13 01:58:28 --> Helper loaded: url_helper
INFO - 2016-11-13 01:58:28 --> URI Class Initialized
INFO - 2016-11-13 01:58:28 --> Helper loaded: form_helper
INFO - 2016-11-13 01:58:28 --> Router Class Initialized
INFO - 2016-11-13 01:58:28 --> Database Driver Class Initialized
INFO - 2016-11-13 01:58:28 --> Output Class Initialized
INFO - 2016-11-13 01:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:58:28 --> Security Class Initialized
INFO - 2016-11-13 01:58:28 --> Controller Class Initialized
INFO - 2016-11-13 01:58:28 --> Model Class Initialized
DEBUG - 2016-11-13 01:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:58:28 --> Form Validation Class Initialized
INFO - 2016-11-13 01:58:28 --> Input Class Initialized
INFO - 2016-11-13 01:58:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 01:58:28 --> Language Class Initialized
ERROR - 2016-11-13 01:58:28 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 01:58:28 --> Loader Class Initialized
INFO - 2016-11-13 01:58:28 --> Helper loaded: url_helper
INFO - 2016-11-13 01:58:28 --> Helper loaded: form_helper
INFO - 2016-11-13 01:58:28 --> Database Driver Class Initialized
ERROR - 2016-11-13 01:58:28 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '6', '3', '2016-11-13 01:58:28', '1', '')
INFO - 2016-11-13 01:58:28 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 01:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:58:28 --> Controller Class Initialized
INFO - 2016-11-13 01:58:28 --> Model Class Initialized
INFO - 2016-11-13 01:58:29 --> Form Validation Class Initialized
INFO - 2016-11-13 01:58:29 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 01:58:29 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 01:58:29 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '6', '3', '2016-11-13 01:58:29', '1', '')
INFO - 2016-11-13 01:58:29 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 01:59:11 --> Config Class Initialized
INFO - 2016-11-13 01:59:11 --> Hooks Class Initialized
DEBUG - 2016-11-13 01:59:11 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:59:11 --> Utf8 Class Initialized
INFO - 2016-11-13 01:59:11 --> URI Class Initialized
INFO - 2016-11-13 01:59:11 --> Router Class Initialized
INFO - 2016-11-13 01:59:11 --> Output Class Initialized
INFO - 2016-11-13 01:59:12 --> Security Class Initialized
DEBUG - 2016-11-13 01:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:59:12 --> Input Class Initialized
INFO - 2016-11-13 01:59:12 --> Language Class Initialized
INFO - 2016-11-13 01:59:12 --> Config Class Initialized
INFO - 2016-11-13 01:59:12 --> Loader Class Initialized
INFO - 2016-11-13 01:59:12 --> Hooks Class Initialized
INFO - 2016-11-13 01:59:12 --> Helper loaded: url_helper
DEBUG - 2016-11-13 01:59:12 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:59:12 --> Helper loaded: form_helper
INFO - 2016-11-13 01:59:12 --> Utf8 Class Initialized
INFO - 2016-11-13 01:59:12 --> URI Class Initialized
INFO - 2016-11-13 01:59:12 --> Database Driver Class Initialized
INFO - 2016-11-13 01:59:12 --> Router Class Initialized
INFO - 2016-11-13 01:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:59:12 --> Output Class Initialized
INFO - 2016-11-13 01:59:12 --> Controller Class Initialized
INFO - 2016-11-13 01:59:12 --> Model Class Initialized
INFO - 2016-11-13 01:59:12 --> Security Class Initialized
INFO - 2016-11-13 01:59:12 --> Form Validation Class Initialized
DEBUG - 2016-11-13 01:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:59:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 01:59:12 --> Config Class Initialized
INFO - 2016-11-13 01:59:12 --> Input Class Initialized
INFO - 2016-11-13 01:59:12 --> Hooks Class Initialized
INFO - 2016-11-13 01:59:12 --> Language Class Initialized
ERROR - 2016-11-13 01:59:12 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
DEBUG - 2016-11-13 01:59:12 --> UTF-8 Support Enabled
INFO - 2016-11-13 01:59:12 --> Loader Class Initialized
INFO - 2016-11-13 01:59:12 --> Utf8 Class Initialized
INFO - 2016-11-13 01:59:12 --> URI Class Initialized
INFO - 2016-11-13 01:59:12 --> Helper loaded: url_helper
INFO - 2016-11-13 01:59:12 --> Router Class Initialized
INFO - 2016-11-13 01:59:12 --> Helper loaded: form_helper
INFO - 2016-11-13 01:59:12 --> Output Class Initialized
INFO - 2016-11-13 01:59:12 --> Config Class Initialized
ERROR - 2016-11-13 01:59:12 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '6', '3', '2016-11-13 01:59:12', '1', '')
INFO - 2016-11-13 01:59:12 --> Database Driver Class Initialized
INFO - 2016-11-13 01:59:12 --> Security Class Initialized
INFO - 2016-11-13 01:59:12 --> Hooks Class Initialized
INFO - 2016-11-13 01:59:12 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-11-13 01:59:12 --> UTF-8 Support Enabled
DEBUG - 2016-11-13 01:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:59:12 --> Input Class Initialized
INFO - 2016-11-13 01:59:12 --> Utf8 Class Initialized
INFO - 2016-11-13 01:59:12 --> Controller Class Initialized
INFO - 2016-11-13 01:59:12 --> Language Class Initialized
INFO - 2016-11-13 01:59:12 --> URI Class Initialized
INFO - 2016-11-13 01:59:12 --> Model Class Initialized
INFO - 2016-11-13 01:59:12 --> Loader Class Initialized
INFO - 2016-11-13 01:59:12 --> Router Class Initialized
INFO - 2016-11-13 01:59:12 --> Form Validation Class Initialized
INFO - 2016-11-13 01:59:12 --> Helper loaded: url_helper
INFO - 2016-11-13 01:59:12 --> Output Class Initialized
INFO - 2016-11-13 01:59:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 01:59:12 --> Helper loaded: form_helper
INFO - 2016-11-13 01:59:12 --> Security Class Initialized
ERROR - 2016-11-13 01:59:12 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 01:59:12 --> Database Driver Class Initialized
DEBUG - 2016-11-13 01:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 01:59:12 --> Input Class Initialized
INFO - 2016-11-13 01:59:12 --> Language Class Initialized
ERROR - 2016-11-13 01:59:12 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '6', '3', '2016-11-13 01:59:12', '1', '')
INFO - 2016-11-13 01:59:12 --> Loader Class Initialized
INFO - 2016-11-13 01:59:12 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 01:59:12 --> Helper loaded: url_helper
INFO - 2016-11-13 01:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:59:12 --> Helper loaded: form_helper
INFO - 2016-11-13 01:59:12 --> Controller Class Initialized
INFO - 2016-11-13 01:59:12 --> Model Class Initialized
INFO - 2016-11-13 01:59:12 --> Database Driver Class Initialized
INFO - 2016-11-13 01:59:12 --> Form Validation Class Initialized
INFO - 2016-11-13 01:59:12 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 01:59:12 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 01:59:12 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '6', '3', '2016-11-13 01:59:12', '1', '')
INFO - 2016-11-13 01:59:12 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 01:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 01:59:12 --> Controller Class Initialized
INFO - 2016-11-13 01:59:12 --> Model Class Initialized
INFO - 2016-11-13 01:59:12 --> Form Validation Class Initialized
INFO - 2016-11-13 01:59:12 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 01:59:12 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 01:59:12 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '6', '3', '2016-11-13 01:59:12', '1', '')
INFO - 2016-11-13 01:59:12 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:00:13 --> Config Class Initialized
INFO - 2016-11-13 02:00:13 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:00:13 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:00:13 --> Utf8 Class Initialized
INFO - 2016-11-13 02:00:13 --> URI Class Initialized
INFO - 2016-11-13 02:00:13 --> Router Class Initialized
INFO - 2016-11-13 02:00:13 --> Output Class Initialized
INFO - 2016-11-13 02:00:14 --> Security Class Initialized
DEBUG - 2016-11-13 02:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:00:14 --> Input Class Initialized
INFO - 2016-11-13 02:00:14 --> Language Class Initialized
INFO - 2016-11-13 02:00:14 --> Loader Class Initialized
INFO - 2016-11-13 02:00:14 --> Helper loaded: url_helper
INFO - 2016-11-13 02:00:14 --> Helper loaded: form_helper
INFO - 2016-11-13 02:00:14 --> Database Driver Class Initialized
INFO - 2016-11-13 02:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:00:14 --> Controller Class Initialized
INFO - 2016-11-13 02:00:14 --> Model Class Initialized
INFO - 2016-11-13 02:00:14 --> Form Validation Class Initialized
INFO - 2016-11-13 02:00:14 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:00:14 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:00:14 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '3', '3', '2016-11-13 02:00:14', '1', '')
INFO - 2016-11-13 02:00:14 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:00:14 --> Config Class Initialized
INFO - 2016-11-13 02:00:14 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:00:14 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:00:14 --> Utf8 Class Initialized
INFO - 2016-11-13 02:00:14 --> URI Class Initialized
INFO - 2016-11-13 02:00:14 --> Router Class Initialized
INFO - 2016-11-13 02:00:14 --> Output Class Initialized
INFO - 2016-11-13 02:00:14 --> Security Class Initialized
DEBUG - 2016-11-13 02:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:00:14 --> Input Class Initialized
INFO - 2016-11-13 02:00:14 --> Language Class Initialized
INFO - 2016-11-13 02:00:14 --> Loader Class Initialized
INFO - 2016-11-13 02:00:14 --> Helper loaded: url_helper
INFO - 2016-11-13 02:00:14 --> Config Class Initialized
INFO - 2016-11-13 02:00:14 --> Helper loaded: form_helper
INFO - 2016-11-13 02:00:14 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:00:14 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:00:14 --> Database Driver Class Initialized
INFO - 2016-11-13 02:00:14 --> Utf8 Class Initialized
INFO - 2016-11-13 02:00:14 --> URI Class Initialized
INFO - 2016-11-13 02:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:00:14 --> Router Class Initialized
INFO - 2016-11-13 02:00:14 --> Controller Class Initialized
INFO - 2016-11-13 02:00:14 --> Model Class Initialized
INFO - 2016-11-13 02:00:14 --> Output Class Initialized
INFO - 2016-11-13 02:00:14 --> Form Validation Class Initialized
INFO - 2016-11-13 02:00:14 --> Security Class Initialized
INFO - 2016-11-13 02:00:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-13 02:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-11-13 02:00:14 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:00:14 --> Input Class Initialized
INFO - 2016-11-13 02:00:14 --> Config Class Initialized
INFO - 2016-11-13 02:00:14 --> Language Class Initialized
INFO - 2016-11-13 02:00:14 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:00:14 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:00:14 --> Loader Class Initialized
INFO - 2016-11-13 02:00:14 --> Utf8 Class Initialized
INFO - 2016-11-13 02:00:14 --> Helper loaded: url_helper
INFO - 2016-11-13 02:00:14 --> URI Class Initialized
INFO - 2016-11-13 02:00:14 --> Helper loaded: form_helper
ERROR - 2016-11-13 02:00:14 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '3', '3', '2016-11-13 02:00:14', '1', '')
INFO - 2016-11-13 02:00:14 --> Router Class Initialized
INFO - 2016-11-13 02:00:14 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:00:14 --> Database Driver Class Initialized
INFO - 2016-11-13 02:00:14 --> Output Class Initialized
INFO - 2016-11-13 02:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:00:14 --> Security Class Initialized
INFO - 2016-11-13 02:00:14 --> Controller Class Initialized
INFO - 2016-11-13 02:00:14 --> Config Class Initialized
INFO - 2016-11-13 02:00:15 --> Model Class Initialized
DEBUG - 2016-11-13 02:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:00:15 --> Hooks Class Initialized
INFO - 2016-11-13 02:00:15 --> Input Class Initialized
INFO - 2016-11-13 02:00:15 --> Form Validation Class Initialized
DEBUG - 2016-11-13 02:00:15 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:00:15 --> Language Class Initialized
INFO - 2016-11-13 02:00:15 --> Utf8 Class Initialized
INFO - 2016-11-13 02:00:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:00:15 --> Loader Class Initialized
INFO - 2016-11-13 02:00:15 --> URI Class Initialized
ERROR - 2016-11-13 02:00:15 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:00:15 --> Router Class Initialized
INFO - 2016-11-13 02:00:15 --> Helper loaded: url_helper
INFO - 2016-11-13 02:00:15 --> Helper loaded: form_helper
INFO - 2016-11-13 02:00:15 --> Output Class Initialized
INFO - 2016-11-13 02:00:15 --> Database Driver Class Initialized
ERROR - 2016-11-13 02:00:15 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '3', '3', '2016-11-13 02:00:15', '1', '')
INFO - 2016-11-13 02:00:15 --> Security Class Initialized
INFO - 2016-11-13 02:00:15 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-11-13 02:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:00:15 --> Config Class Initialized
INFO - 2016-11-13 02:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:00:15 --> Hooks Class Initialized
INFO - 2016-11-13 02:00:15 --> Input Class Initialized
INFO - 2016-11-13 02:00:15 --> Controller Class Initialized
DEBUG - 2016-11-13 02:00:15 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:00:15 --> Language Class Initialized
INFO - 2016-11-13 02:00:15 --> Model Class Initialized
INFO - 2016-11-13 02:00:15 --> Utf8 Class Initialized
INFO - 2016-11-13 02:00:15 --> Loader Class Initialized
INFO - 2016-11-13 02:00:15 --> Form Validation Class Initialized
INFO - 2016-11-13 02:00:15 --> URI Class Initialized
INFO - 2016-11-13 02:00:15 --> Helper loaded: url_helper
INFO - 2016-11-13 02:00:15 --> Router Class Initialized
INFO - 2016-11-13 02:00:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:00:15 --> Helper loaded: form_helper
ERROR - 2016-11-13 02:00:15 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:00:15 --> Output Class Initialized
INFO - 2016-11-13 02:00:15 --> Database Driver Class Initialized
INFO - 2016-11-13 02:00:15 --> Security Class Initialized
DEBUG - 2016-11-13 02:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:00:15 --> Config Class Initialized
INFO - 2016-11-13 02:00:15 --> Input Class Initialized
INFO - 2016-11-13 02:00:15 --> Hooks Class Initialized
ERROR - 2016-11-13 02:00:15 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '3', '3', '2016-11-13 02:00:15', '1', '')
INFO - 2016-11-13 02:00:15 --> Language Class Initialized
DEBUG - 2016-11-13 02:00:15 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:00:15 --> Loader Class Initialized
INFO - 2016-11-13 02:00:15 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:00:15 --> Utf8 Class Initialized
INFO - 2016-11-13 02:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:00:15 --> URI Class Initialized
INFO - 2016-11-13 02:00:15 --> Helper loaded: url_helper
INFO - 2016-11-13 02:00:15 --> Controller Class Initialized
INFO - 2016-11-13 02:00:15 --> Router Class Initialized
INFO - 2016-11-13 02:00:15 --> Helper loaded: form_helper
INFO - 2016-11-13 02:00:15 --> Model Class Initialized
INFO - 2016-11-13 02:00:15 --> Output Class Initialized
INFO - 2016-11-13 02:00:15 --> Form Validation Class Initialized
INFO - 2016-11-13 02:00:15 --> Database Driver Class Initialized
INFO - 2016-11-13 02:00:15 --> Security Class Initialized
INFO - 2016-11-13 02:00:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:00:15 --> Config Class Initialized
DEBUG - 2016-11-13 02:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:00:15 --> Hooks Class Initialized
ERROR - 2016-11-13 02:00:15 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:00:15 --> Input Class Initialized
DEBUG - 2016-11-13 02:00:15 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:00:15 --> Language Class Initialized
INFO - 2016-11-13 02:00:15 --> Utf8 Class Initialized
INFO - 2016-11-13 02:00:15 --> URI Class Initialized
INFO - 2016-11-13 02:00:15 --> Loader Class Initialized
ERROR - 2016-11-13 02:00:15 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '3', '3', '2016-11-13 02:00:15', '1', '')
INFO - 2016-11-13 02:00:15 --> Router Class Initialized
INFO - 2016-11-13 02:00:15 --> Helper loaded: url_helper
INFO - 2016-11-13 02:00:15 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:00:15 --> Output Class Initialized
INFO - 2016-11-13 02:00:15 --> Helper loaded: form_helper
INFO - 2016-11-13 02:00:15 --> Security Class Initialized
INFO - 2016-11-13 02:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:00:15 --> Database Driver Class Initialized
INFO - 2016-11-13 02:00:15 --> Controller Class Initialized
INFO - 2016-11-13 02:00:15 --> Config Class Initialized
DEBUG - 2016-11-13 02:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:00:15 --> Input Class Initialized
INFO - 2016-11-13 02:00:15 --> Hooks Class Initialized
INFO - 2016-11-13 02:00:15 --> Model Class Initialized
INFO - 2016-11-13 02:00:15 --> Language Class Initialized
DEBUG - 2016-11-13 02:00:15 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:00:15 --> Form Validation Class Initialized
INFO - 2016-11-13 02:00:15 --> Loader Class Initialized
INFO - 2016-11-13 02:00:15 --> Utf8 Class Initialized
INFO - 2016-11-13 02:00:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:00:15 --> URI Class Initialized
INFO - 2016-11-13 02:00:15 --> Helper loaded: url_helper
ERROR - 2016-11-13 02:00:15 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:00:15 --> Router Class Initialized
INFO - 2016-11-13 02:00:15 --> Helper loaded: form_helper
INFO - 2016-11-13 02:00:15 --> Output Class Initialized
INFO - 2016-11-13 02:00:15 --> Database Driver Class Initialized
ERROR - 2016-11-13 02:00:15 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '3', '3', '2016-11-13 02:00:15', '1', '')
INFO - 2016-11-13 02:00:15 --> Security Class Initialized
INFO - 2016-11-13 02:00:15 --> Config Class Initialized
DEBUG - 2016-11-13 02:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:00:15 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:00:15 --> Hooks Class Initialized
INFO - 2016-11-13 02:00:15 --> Input Class Initialized
INFO - 2016-11-13 02:00:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-13 02:00:15 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:00:15 --> Language Class Initialized
INFO - 2016-11-13 02:00:15 --> Utf8 Class Initialized
INFO - 2016-11-13 02:00:15 --> Controller Class Initialized
INFO - 2016-11-13 02:00:15 --> Model Class Initialized
INFO - 2016-11-13 02:00:15 --> URI Class Initialized
INFO - 2016-11-13 02:00:15 --> Loader Class Initialized
INFO - 2016-11-13 02:00:15 --> Form Validation Class Initialized
INFO - 2016-11-13 02:00:15 --> Router Class Initialized
INFO - 2016-11-13 02:00:15 --> Helper loaded: url_helper
INFO - 2016-11-13 02:00:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:00:15 --> Output Class Initialized
INFO - 2016-11-13 02:00:15 --> Helper loaded: form_helper
INFO - 2016-11-13 02:00:15 --> Security Class Initialized
ERROR - 2016-11-13 02:00:15 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:00:15 --> Database Driver Class Initialized
DEBUG - 2016-11-13 02:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:00:16 --> Config Class Initialized
INFO - 2016-11-13 02:00:16 --> Input Class Initialized
INFO - 2016-11-13 02:00:16 --> Hooks Class Initialized
INFO - 2016-11-13 02:00:16 --> Language Class Initialized
ERROR - 2016-11-13 02:00:16 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '3', '3', '2016-11-13 02:00:15', '1', '')
DEBUG - 2016-11-13 02:00:16 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:00:16 --> Loader Class Initialized
INFO - 2016-11-13 02:00:16 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:00:16 --> Utf8 Class Initialized
INFO - 2016-11-13 02:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:00:16 --> Helper loaded: url_helper
INFO - 2016-11-13 02:00:16 --> URI Class Initialized
INFO - 2016-11-13 02:00:16 --> Controller Class Initialized
INFO - 2016-11-13 02:00:16 --> Model Class Initialized
INFO - 2016-11-13 02:00:16 --> Router Class Initialized
INFO - 2016-11-13 02:00:16 --> Helper loaded: form_helper
INFO - 2016-11-13 02:00:16 --> Form Validation Class Initialized
INFO - 2016-11-13 02:00:16 --> Output Class Initialized
INFO - 2016-11-13 02:00:16 --> Database Driver Class Initialized
INFO - 2016-11-13 02:00:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:00:16 --> Config Class Initialized
INFO - 2016-11-13 02:00:16 --> Security Class Initialized
ERROR - 2016-11-13 02:00:16 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:00:16 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-13 02:00:16 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:00:16 --> Input Class Initialized
INFO - 2016-11-13 02:00:16 --> Utf8 Class Initialized
INFO - 2016-11-13 02:00:16 --> Language Class Initialized
ERROR - 2016-11-13 02:00:16 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '3', '3', '2016-11-13 02:00:16', '1', '')
INFO - 2016-11-13 02:00:16 --> URI Class Initialized
INFO - 2016-11-13 02:00:16 --> Loader Class Initialized
INFO - 2016-11-13 02:00:16 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:00:16 --> Router Class Initialized
INFO - 2016-11-13 02:00:16 --> Helper loaded: url_helper
INFO - 2016-11-13 02:00:16 --> Output Class Initialized
INFO - 2016-11-13 02:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:00:16 --> Controller Class Initialized
INFO - 2016-11-13 02:00:16 --> Helper loaded: form_helper
INFO - 2016-11-13 02:00:16 --> Security Class Initialized
INFO - 2016-11-13 02:00:16 --> Model Class Initialized
INFO - 2016-11-13 02:00:16 --> Database Driver Class Initialized
INFO - 2016-11-13 02:00:16 --> Config Class Initialized
INFO - 2016-11-13 02:00:16 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:00:16 --> Form Validation Class Initialized
INFO - 2016-11-13 02:00:16 --> Input Class Initialized
DEBUG - 2016-11-13 02:00:16 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:00:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:00:16 --> Language Class Initialized
INFO - 2016-11-13 02:00:16 --> Utf8 Class Initialized
INFO - 2016-11-13 02:00:16 --> URI Class Initialized
ERROR - 2016-11-13 02:00:16 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:00:16 --> Loader Class Initialized
INFO - 2016-11-13 02:00:16 --> Router Class Initialized
INFO - 2016-11-13 02:00:16 --> Helper loaded: url_helper
INFO - 2016-11-13 02:00:16 --> Output Class Initialized
INFO - 2016-11-13 02:00:16 --> Helper loaded: form_helper
INFO - 2016-11-13 02:00:16 --> Security Class Initialized
ERROR - 2016-11-13 02:00:16 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '3', '3', '2016-11-13 02:00:16', '1', '')
INFO - 2016-11-13 02:00:16 --> Database Driver Class Initialized
INFO - 2016-11-13 02:00:16 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:00:16 --> Config Class Initialized
DEBUG - 2016-11-13 02:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:00:16 --> Input Class Initialized
INFO - 2016-11-13 02:00:16 --> Hooks Class Initialized
INFO - 2016-11-13 02:00:16 --> Controller Class Initialized
INFO - 2016-11-13 02:00:16 --> Language Class Initialized
DEBUG - 2016-11-13 02:00:16 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:00:16 --> Utf8 Class Initialized
INFO - 2016-11-13 02:00:16 --> Model Class Initialized
INFO - 2016-11-13 02:00:16 --> Loader Class Initialized
INFO - 2016-11-13 02:00:16 --> Form Validation Class Initialized
INFO - 2016-11-13 02:00:16 --> URI Class Initialized
INFO - 2016-11-13 02:00:16 --> Helper loaded: url_helper
INFO - 2016-11-13 02:00:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:00:16 --> Router Class Initialized
INFO - 2016-11-13 02:00:16 --> Helper loaded: form_helper
ERROR - 2016-11-13 02:00:16 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:00:16 --> Output Class Initialized
INFO - 2016-11-13 02:00:16 --> Database Driver Class Initialized
INFO - 2016-11-13 02:00:16 --> Security Class Initialized
INFO - 2016-11-13 02:00:16 --> Config Class Initialized
INFO - 2016-11-13 02:00:16 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-13 02:00:16 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:00:16 --> Input Class Initialized
ERROR - 2016-11-13 02:00:16 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '3', '3', '2016-11-13 02:00:16', '1', '')
INFO - 2016-11-13 02:00:16 --> Utf8 Class Initialized
INFO - 2016-11-13 02:00:16 --> Language Class Initialized
INFO - 2016-11-13 02:00:16 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:00:16 --> URI Class Initialized
INFO - 2016-11-13 02:00:16 --> Loader Class Initialized
INFO - 2016-11-13 02:00:16 --> Router Class Initialized
INFO - 2016-11-13 02:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:00:16 --> Helper loaded: url_helper
INFO - 2016-11-13 02:00:16 --> Controller Class Initialized
INFO - 2016-11-13 02:00:16 --> Output Class Initialized
INFO - 2016-11-13 02:00:16 --> Model Class Initialized
INFO - 2016-11-13 02:00:16 --> Helper loaded: form_helper
INFO - 2016-11-13 02:00:16 --> Security Class Initialized
INFO - 2016-11-13 02:00:16 --> Config Class Initialized
INFO - 2016-11-13 02:00:16 --> Database Driver Class Initialized
INFO - 2016-11-13 02:00:16 --> Form Validation Class Initialized
DEBUG - 2016-11-13 02:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:00:16 --> Hooks Class Initialized
INFO - 2016-11-13 02:00:16 --> Input Class Initialized
INFO - 2016-11-13 02:00:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-13 02:00:16 --> UTF-8 Support Enabled
ERROR - 2016-11-13 02:00:16 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:00:16 --> Language Class Initialized
INFO - 2016-11-13 02:00:16 --> Utf8 Class Initialized
INFO - 2016-11-13 02:00:16 --> URI Class Initialized
INFO - 2016-11-13 02:00:16 --> Loader Class Initialized
INFO - 2016-11-13 02:00:16 --> Router Class Initialized
ERROR - 2016-11-13 02:00:16 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '3', '3', '2016-11-13 02:00:16', '1', '')
INFO - 2016-11-13 02:00:16 --> Helper loaded: url_helper
INFO - 2016-11-13 02:00:16 --> Output Class Initialized
INFO - 2016-11-13 02:00:16 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:00:16 --> Helper loaded: form_helper
INFO - 2016-11-13 02:00:16 --> Security Class Initialized
INFO - 2016-11-13 02:00:17 --> Database Driver Class Initialized
INFO - 2016-11-13 02:00:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-13 02:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:00:17 --> Controller Class Initialized
INFO - 2016-11-13 02:00:17 --> Input Class Initialized
INFO - 2016-11-13 02:00:17 --> Model Class Initialized
INFO - 2016-11-13 02:00:17 --> Language Class Initialized
INFO - 2016-11-13 02:00:17 --> Form Validation Class Initialized
INFO - 2016-11-13 02:00:17 --> Loader Class Initialized
INFO - 2016-11-13 02:00:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:00:17 --> Helper loaded: url_helper
ERROR - 2016-11-13 02:00:17 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:00:17 --> Helper loaded: form_helper
INFO - 2016-11-13 02:00:17 --> Database Driver Class Initialized
ERROR - 2016-11-13 02:00:17 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '3', '3', '2016-11-13 02:00:17', '1', '')
INFO - 2016-11-13 02:00:17 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:00:17 --> Controller Class Initialized
INFO - 2016-11-13 02:00:17 --> Model Class Initialized
INFO - 2016-11-13 02:00:17 --> Form Validation Class Initialized
INFO - 2016-11-13 02:00:17 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:00:17 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:00:17 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '3', '3', '2016-11-13 02:00:17', '1', '')
INFO - 2016-11-13 02:00:17 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:00:17 --> Controller Class Initialized
INFO - 2016-11-13 02:00:17 --> Model Class Initialized
INFO - 2016-11-13 02:00:17 --> Form Validation Class Initialized
INFO - 2016-11-13 02:00:17 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:00:17 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:00:17 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '3', '3', '2016-11-13 02:00:17', '1', '')
INFO - 2016-11-13 02:00:17 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:00:17 --> Controller Class Initialized
INFO - 2016-11-13 02:00:17 --> Model Class Initialized
INFO - 2016-11-13 02:00:17 --> Form Validation Class Initialized
INFO - 2016-11-13 02:00:17 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:00:17 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:00:17 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '3', '3', '2016-11-13 02:00:17', '1', '')
INFO - 2016-11-13 02:00:17 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:00:17 --> Controller Class Initialized
INFO - 2016-11-13 02:00:17 --> Model Class Initialized
INFO - 2016-11-13 02:00:17 --> Form Validation Class Initialized
INFO - 2016-11-13 02:00:17 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:00:17 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:00:17 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '3', '3', '2016-11-13 02:00:17', '1', '')
INFO - 2016-11-13 02:00:17 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:00:18 --> Config Class Initialized
INFO - 2016-11-13 02:00:18 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:00:18 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:00:18 --> Utf8 Class Initialized
INFO - 2016-11-13 02:00:18 --> URI Class Initialized
INFO - 2016-11-13 02:00:18 --> Router Class Initialized
INFO - 2016-11-13 02:00:18 --> Output Class Initialized
INFO - 2016-11-13 02:00:18 --> Security Class Initialized
DEBUG - 2016-11-13 02:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:00:18 --> Input Class Initialized
INFO - 2016-11-13 02:00:18 --> Language Class Initialized
INFO - 2016-11-13 02:00:18 --> Loader Class Initialized
INFO - 2016-11-13 02:00:18 --> Helper loaded: url_helper
INFO - 2016-11-13 02:00:18 --> Config Class Initialized
INFO - 2016-11-13 02:00:18 --> Helper loaded: form_helper
INFO - 2016-11-13 02:00:18 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:00:18 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:00:18 --> Database Driver Class Initialized
INFO - 2016-11-13 02:00:18 --> Utf8 Class Initialized
INFO - 2016-11-13 02:00:18 --> URI Class Initialized
INFO - 2016-11-13 02:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:00:18 --> Router Class Initialized
INFO - 2016-11-13 02:00:18 --> Controller Class Initialized
INFO - 2016-11-13 02:00:18 --> Model Class Initialized
INFO - 2016-11-13 02:00:18 --> Output Class Initialized
INFO - 2016-11-13 02:00:18 --> Form Validation Class Initialized
INFO - 2016-11-13 02:00:18 --> Security Class Initialized
INFO - 2016-11-13 02:00:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:00:18 --> Config Class Initialized
DEBUG - 2016-11-13 02:00:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-11-13 02:00:18 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:00:18 --> Input Class Initialized
INFO - 2016-11-13 02:00:18 --> Hooks Class Initialized
INFO - 2016-11-13 02:00:19 --> Language Class Initialized
DEBUG - 2016-11-13 02:00:19 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:00:19 --> Loader Class Initialized
INFO - 2016-11-13 02:00:19 --> Utf8 Class Initialized
INFO - 2016-11-13 02:00:19 --> URI Class Initialized
INFO - 2016-11-13 02:00:19 --> Helper loaded: url_helper
ERROR - 2016-11-13 02:00:19 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '3', '3', '2016-11-13 02:00:18', '1', 'bvcbvcb')
INFO - 2016-11-13 02:00:19 --> Router Class Initialized
INFO - 2016-11-13 02:00:19 --> Helper loaded: form_helper
INFO - 2016-11-13 02:00:19 --> Output Class Initialized
INFO - 2016-11-13 02:00:19 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:00:19 --> Database Driver Class Initialized
INFO - 2016-11-13 02:00:19 --> Security Class Initialized
INFO - 2016-11-13 02:00:19 --> Config Class Initialized
INFO - 2016-11-13 02:00:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-13 02:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:00:19 --> Hooks Class Initialized
INFO - 2016-11-13 02:00:19 --> Controller Class Initialized
INFO - 2016-11-13 02:00:19 --> Input Class Initialized
DEBUG - 2016-11-13 02:00:19 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:00:19 --> Model Class Initialized
INFO - 2016-11-13 02:00:19 --> Language Class Initialized
INFO - 2016-11-13 02:00:19 --> Utf8 Class Initialized
INFO - 2016-11-13 02:00:19 --> Form Validation Class Initialized
INFO - 2016-11-13 02:00:19 --> Loader Class Initialized
INFO - 2016-11-13 02:00:19 --> URI Class Initialized
INFO - 2016-11-13 02:00:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:00:19 --> Helper loaded: url_helper
INFO - 2016-11-13 02:00:19 --> Router Class Initialized
ERROR - 2016-11-13 02:00:19 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:00:19 --> Helper loaded: form_helper
INFO - 2016-11-13 02:00:19 --> Output Class Initialized
INFO - 2016-11-13 02:00:19 --> Security Class Initialized
INFO - 2016-11-13 02:00:19 --> Config Class Initialized
INFO - 2016-11-13 02:00:19 --> Database Driver Class Initialized
ERROR - 2016-11-13 02:00:19 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '3', '3', '2016-11-13 02:00:19', '1', 'bvcbvcb')
DEBUG - 2016-11-13 02:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:00:19 --> Hooks Class Initialized
INFO - 2016-11-13 02:00:19 --> Input Class Initialized
INFO - 2016-11-13 02:00:19 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-11-13 02:00:19 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:00:19 --> Utf8 Class Initialized
INFO - 2016-11-13 02:00:19 --> Language Class Initialized
INFO - 2016-11-13 02:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:00:19 --> URI Class Initialized
INFO - 2016-11-13 02:00:19 --> Loader Class Initialized
INFO - 2016-11-13 02:00:19 --> Controller Class Initialized
INFO - 2016-11-13 02:00:19 --> Model Class Initialized
INFO - 2016-11-13 02:00:19 --> Router Class Initialized
INFO - 2016-11-13 02:00:19 --> Helper loaded: url_helper
INFO - 2016-11-13 02:00:19 --> Form Validation Class Initialized
INFO - 2016-11-13 02:00:19 --> Output Class Initialized
INFO - 2016-11-13 02:00:19 --> Helper loaded: form_helper
INFO - 2016-11-13 02:00:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:00:19 --> Database Driver Class Initialized
INFO - 2016-11-13 02:00:19 --> Security Class Initialized
ERROR - 2016-11-13 02:00:19 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
DEBUG - 2016-11-13 02:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:00:19 --> Input Class Initialized
INFO - 2016-11-13 02:00:19 --> Language Class Initialized
INFO - 2016-11-13 02:00:19 --> Loader Class Initialized
ERROR - 2016-11-13 02:00:19 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '3', '3', '2016-11-13 02:00:19', '1', 'bvcbvcb')
INFO - 2016-11-13 02:00:19 --> Helper loaded: url_helper
INFO - 2016-11-13 02:00:19 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:00:19 --> Helper loaded: form_helper
INFO - 2016-11-13 02:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:00:19 --> Database Driver Class Initialized
INFO - 2016-11-13 02:00:19 --> Controller Class Initialized
INFO - 2016-11-13 02:00:19 --> Model Class Initialized
INFO - 2016-11-13 02:00:19 --> Form Validation Class Initialized
INFO - 2016-11-13 02:00:19 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:00:19 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:00:19 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '3', '3', '2016-11-13 02:00:19', '1', 'bvcbvcb')
INFO - 2016-11-13 02:00:19 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:00:19 --> Controller Class Initialized
INFO - 2016-11-13 02:00:19 --> Model Class Initialized
INFO - 2016-11-13 02:00:19 --> Form Validation Class Initialized
INFO - 2016-11-13 02:00:19 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:00:19 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:00:19 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-06', '2016-11-08', '3', '3', '2016-11-13 02:00:19', '1', 'bvcbvcb')
INFO - 2016-11-13 02:00:19 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:01:27 --> Config Class Initialized
INFO - 2016-11-13 02:01:27 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:01:27 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:01:27 --> Utf8 Class Initialized
INFO - 2016-11-13 02:01:27 --> URI Class Initialized
DEBUG - 2016-11-13 02:01:27 --> No URI present. Default controller set.
INFO - 2016-11-13 02:01:28 --> Router Class Initialized
INFO - 2016-11-13 02:01:28 --> Output Class Initialized
INFO - 2016-11-13 02:01:28 --> Security Class Initialized
DEBUG - 2016-11-13 02:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:01:28 --> Input Class Initialized
INFO - 2016-11-13 02:01:28 --> Language Class Initialized
INFO - 2016-11-13 02:01:28 --> Loader Class Initialized
INFO - 2016-11-13 02:01:28 --> Helper loaded: url_helper
INFO - 2016-11-13 02:01:28 --> Helper loaded: form_helper
INFO - 2016-11-13 02:01:28 --> Database Driver Class Initialized
INFO - 2016-11-13 02:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:01:28 --> Controller Class Initialized
INFO - 2016-11-13 02:01:28 --> Model Class Initialized
INFO - 2016-11-13 02:01:28 --> Model Class Initialized
INFO - 2016-11-13 02:01:28 --> Model Class Initialized
INFO - 2016-11-13 02:01:28 --> Model Class Initialized
INFO - 2016-11-13 02:01:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:01:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:01:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:01:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:01:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:01:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:01:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:01:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:01:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:01:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:01:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:01:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:01:28 --> Final output sent to browser
DEBUG - 2016-11-13 02:01:28 --> Total execution time: 0.5175
INFO - 2016-11-13 02:01:32 --> Config Class Initialized
INFO - 2016-11-13 02:01:32 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:01:32 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:01:32 --> Utf8 Class Initialized
INFO - 2016-11-13 02:01:32 --> URI Class Initialized
INFO - 2016-11-13 02:01:32 --> Router Class Initialized
INFO - 2016-11-13 02:01:32 --> Output Class Initialized
INFO - 2016-11-13 02:01:32 --> Security Class Initialized
DEBUG - 2016-11-13 02:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:01:32 --> Input Class Initialized
INFO - 2016-11-13 02:01:32 --> Language Class Initialized
INFO - 2016-11-13 02:01:32 --> Loader Class Initialized
INFO - 2016-11-13 02:01:32 --> Helper loaded: url_helper
INFO - 2016-11-13 02:01:32 --> Helper loaded: form_helper
INFO - 2016-11-13 02:01:32 --> Database Driver Class Initialized
INFO - 2016-11-13 02:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:01:32 --> Controller Class Initialized
INFO - 2016-11-13 02:01:32 --> Model Class Initialized
INFO - 2016-11-13 02:01:32 --> Form Validation Class Initialized
INFO - 2016-11-13 02:01:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:01:32 --> Final output sent to browser
DEBUG - 2016-11-13 02:01:32 --> Total execution time: 0.2745
INFO - 2016-11-13 02:01:36 --> Config Class Initialized
INFO - 2016-11-13 02:01:36 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:01:36 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:01:36 --> Utf8 Class Initialized
INFO - 2016-11-13 02:01:36 --> URI Class Initialized
INFO - 2016-11-13 02:01:36 --> Router Class Initialized
INFO - 2016-11-13 02:01:36 --> Output Class Initialized
INFO - 2016-11-13 02:01:36 --> Security Class Initialized
DEBUG - 2016-11-13 02:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:01:36 --> Input Class Initialized
INFO - 2016-11-13 02:01:36 --> Language Class Initialized
INFO - 2016-11-13 02:01:36 --> Loader Class Initialized
INFO - 2016-11-13 02:01:36 --> Helper loaded: url_helper
INFO - 2016-11-13 02:01:36 --> Helper loaded: form_helper
INFO - 2016-11-13 02:01:36 --> Database Driver Class Initialized
INFO - 2016-11-13 02:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:01:36 --> Controller Class Initialized
INFO - 2016-11-13 02:01:36 --> Model Class Initialized
INFO - 2016-11-13 02:01:36 --> Form Validation Class Initialized
INFO - 2016-11-13 02:01:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:01:36 --> Final output sent to browser
DEBUG - 2016-11-13 02:01:36 --> Total execution time: 0.3184
INFO - 2016-11-13 02:01:54 --> Config Class Initialized
INFO - 2016-11-13 02:01:54 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:01:54 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:01:54 --> Utf8 Class Initialized
INFO - 2016-11-13 02:01:54 --> URI Class Initialized
INFO - 2016-11-13 02:01:54 --> Router Class Initialized
INFO - 2016-11-13 02:01:54 --> Output Class Initialized
INFO - 2016-11-13 02:01:54 --> Security Class Initialized
DEBUG - 2016-11-13 02:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:01:54 --> Input Class Initialized
INFO - 2016-11-13 02:01:54 --> Language Class Initialized
INFO - 2016-11-13 02:01:54 --> Loader Class Initialized
INFO - 2016-11-13 02:01:54 --> Helper loaded: url_helper
INFO - 2016-11-13 02:01:54 --> Helper loaded: form_helper
INFO - 2016-11-13 02:01:54 --> Database Driver Class Initialized
INFO - 2016-11-13 02:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:01:54 --> Controller Class Initialized
INFO - 2016-11-13 02:01:54 --> Model Class Initialized
INFO - 2016-11-13 02:01:54 --> Form Validation Class Initialized
INFO - 2016-11-13 02:01:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:01:54 --> Final output sent to browser
DEBUG - 2016-11-13 02:01:54 --> Total execution time: 0.2716
INFO - 2016-11-13 02:02:00 --> Config Class Initialized
INFO - 2016-11-13 02:02:00 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:02:00 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:02:00 --> Utf8 Class Initialized
INFO - 2016-11-13 02:02:00 --> URI Class Initialized
INFO - 2016-11-13 02:02:00 --> Router Class Initialized
INFO - 2016-11-13 02:02:00 --> Output Class Initialized
INFO - 2016-11-13 02:02:00 --> Security Class Initialized
DEBUG - 2016-11-13 02:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:02:01 --> Input Class Initialized
INFO - 2016-11-13 02:02:01 --> Language Class Initialized
INFO - 2016-11-13 02:02:01 --> Config Class Initialized
INFO - 2016-11-13 02:02:01 --> Loader Class Initialized
INFO - 2016-11-13 02:02:01 --> Hooks Class Initialized
INFO - 2016-11-13 02:02:01 --> Helper loaded: url_helper
DEBUG - 2016-11-13 02:02:01 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:02:01 --> Helper loaded: form_helper
INFO - 2016-11-13 02:02:01 --> Utf8 Class Initialized
INFO - 2016-11-13 02:02:01 --> URI Class Initialized
INFO - 2016-11-13 02:02:01 --> Database Driver Class Initialized
INFO - 2016-11-13 02:02:01 --> Router Class Initialized
INFO - 2016-11-13 02:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:02:01 --> Output Class Initialized
INFO - 2016-11-13 02:02:01 --> Controller Class Initialized
INFO - 2016-11-13 02:02:01 --> Model Class Initialized
INFO - 2016-11-13 02:02:01 --> Security Class Initialized
INFO - 2016-11-13 02:02:01 --> Form Validation Class Initialized
DEBUG - 2016-11-13 02:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:02:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:02:01 --> Input Class Initialized
INFO - 2016-11-13 02:02:01 --> Final output sent to browser
INFO - 2016-11-13 02:02:01 --> Language Class Initialized
DEBUG - 2016-11-13 02:02:01 --> Total execution time: 0.3651
INFO - 2016-11-13 02:02:01 --> Loader Class Initialized
INFO - 2016-11-13 02:02:01 --> Helper loaded: url_helper
INFO - 2016-11-13 02:02:01 --> Helper loaded: form_helper
INFO - 2016-11-13 02:02:01 --> Database Driver Class Initialized
INFO - 2016-11-13 02:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:02:01 --> Config Class Initialized
INFO - 2016-11-13 02:02:01 --> Controller Class Initialized
INFO - 2016-11-13 02:02:01 --> Hooks Class Initialized
INFO - 2016-11-13 02:02:01 --> Model Class Initialized
DEBUG - 2016-11-13 02:02:01 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:02:01 --> Form Validation Class Initialized
INFO - 2016-11-13 02:02:01 --> Utf8 Class Initialized
INFO - 2016-11-13 02:02:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:02:01 --> URI Class Initialized
INFO - 2016-11-13 02:02:01 --> Final output sent to browser
INFO - 2016-11-13 02:02:01 --> Router Class Initialized
DEBUG - 2016-11-13 02:02:01 --> Total execution time: 0.4133
INFO - 2016-11-13 02:02:01 --> Output Class Initialized
INFO - 2016-11-13 02:02:01 --> Security Class Initialized
DEBUG - 2016-11-13 02:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:02:01 --> Config Class Initialized
INFO - 2016-11-13 02:02:01 --> Input Class Initialized
INFO - 2016-11-13 02:02:01 --> Hooks Class Initialized
INFO - 2016-11-13 02:02:01 --> Language Class Initialized
DEBUG - 2016-11-13 02:02:01 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:02:01 --> Loader Class Initialized
INFO - 2016-11-13 02:02:01 --> Utf8 Class Initialized
INFO - 2016-11-13 02:02:01 --> URI Class Initialized
INFO - 2016-11-13 02:02:01 --> Helper loaded: url_helper
INFO - 2016-11-13 02:02:01 --> Router Class Initialized
INFO - 2016-11-13 02:02:01 --> Helper loaded: form_helper
INFO - 2016-11-13 02:02:01 --> Output Class Initialized
INFO - 2016-11-13 02:02:01 --> Config Class Initialized
INFO - 2016-11-13 02:02:01 --> Database Driver Class Initialized
INFO - 2016-11-13 02:02:01 --> Security Class Initialized
INFO - 2016-11-13 02:02:01 --> Hooks Class Initialized
INFO - 2016-11-13 02:02:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-13 02:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-13 02:02:01 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:02:01 --> Controller Class Initialized
INFO - 2016-11-13 02:02:01 --> Input Class Initialized
INFO - 2016-11-13 02:02:01 --> Utf8 Class Initialized
INFO - 2016-11-13 02:02:01 --> Model Class Initialized
INFO - 2016-11-13 02:02:01 --> Language Class Initialized
INFO - 2016-11-13 02:02:01 --> URI Class Initialized
INFO - 2016-11-13 02:02:01 --> Form Validation Class Initialized
INFO - 2016-11-13 02:02:01 --> Loader Class Initialized
INFO - 2016-11-13 02:02:01 --> Router Class Initialized
INFO - 2016-11-13 02:02:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:02:01 --> Output Class Initialized
INFO - 2016-11-13 02:02:01 --> Helper loaded: url_helper
INFO - 2016-11-13 02:02:01 --> Final output sent to browser
INFO - 2016-11-13 02:02:01 --> Config Class Initialized
INFO - 2016-11-13 02:02:01 --> Helper loaded: form_helper
INFO - 2016-11-13 02:02:01 --> Security Class Initialized
INFO - 2016-11-13 02:02:01 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:02:01 --> Total execution time: 0.4489
DEBUG - 2016-11-13 02:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:02:01 --> Database Driver Class Initialized
DEBUG - 2016-11-13 02:02:01 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:02:01 --> Input Class Initialized
INFO - 2016-11-13 02:02:01 --> Utf8 Class Initialized
INFO - 2016-11-13 02:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:02:01 --> Language Class Initialized
INFO - 2016-11-13 02:02:01 --> URI Class Initialized
INFO - 2016-11-13 02:02:01 --> Controller Class Initialized
INFO - 2016-11-13 02:02:01 --> Loader Class Initialized
INFO - 2016-11-13 02:02:01 --> Model Class Initialized
INFO - 2016-11-13 02:02:01 --> Router Class Initialized
INFO - 2016-11-13 02:02:01 --> Helper loaded: url_helper
INFO - 2016-11-13 02:02:01 --> Output Class Initialized
INFO - 2016-11-13 02:02:01 --> Form Validation Class Initialized
INFO - 2016-11-13 02:02:01 --> Helper loaded: form_helper
INFO - 2016-11-13 02:02:01 --> Security Class Initialized
INFO - 2016-11-13 02:02:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:02:02 --> Config Class Initialized
INFO - 2016-11-13 02:02:02 --> Database Driver Class Initialized
INFO - 2016-11-13 02:02:02 --> Final output sent to browser
DEBUG - 2016-11-13 02:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:02:02 --> Hooks Class Initialized
INFO - 2016-11-13 02:02:02 --> Input Class Initialized
DEBUG - 2016-11-13 02:02:02 --> Total execution time: 0.4734
DEBUG - 2016-11-13 02:02:02 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:02:02 --> Language Class Initialized
INFO - 2016-11-13 02:02:02 --> Utf8 Class Initialized
INFO - 2016-11-13 02:02:02 --> Controller Class Initialized
INFO - 2016-11-13 02:02:02 --> URI Class Initialized
INFO - 2016-11-13 02:02:02 --> Loader Class Initialized
INFO - 2016-11-13 02:02:02 --> Model Class Initialized
INFO - 2016-11-13 02:02:02 --> Helper loaded: url_helper
INFO - 2016-11-13 02:02:02 --> Router Class Initialized
INFO - 2016-11-13 02:02:02 --> Form Validation Class Initialized
INFO - 2016-11-13 02:02:02 --> Helper loaded: form_helper
INFO - 2016-11-13 02:02:02 --> Output Class Initialized
INFO - 2016-11-13 02:02:02 --> Config Class Initialized
INFO - 2016-11-13 02:02:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:02:02 --> Database Driver Class Initialized
INFO - 2016-11-13 02:02:02 --> Hooks Class Initialized
INFO - 2016-11-13 02:02:02 --> Security Class Initialized
INFO - 2016-11-13 02:02:02 --> Final output sent to browser
DEBUG - 2016-11-13 02:02:02 --> UTF-8 Support Enabled
DEBUG - 2016-11-13 02:02:02 --> Total execution time: 0.5068
DEBUG - 2016-11-13 02:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:02:02 --> Utf8 Class Initialized
INFO - 2016-11-13 02:02:02 --> Input Class Initialized
INFO - 2016-11-13 02:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:02:02 --> Language Class Initialized
INFO - 2016-11-13 02:02:02 --> URI Class Initialized
INFO - 2016-11-13 02:02:02 --> Controller Class Initialized
INFO - 2016-11-13 02:02:02 --> Model Class Initialized
INFO - 2016-11-13 02:02:02 --> Router Class Initialized
INFO - 2016-11-13 02:02:02 --> Loader Class Initialized
INFO - 2016-11-13 02:02:02 --> Form Validation Class Initialized
INFO - 2016-11-13 02:02:02 --> Helper loaded: url_helper
INFO - 2016-11-13 02:02:02 --> Output Class Initialized
INFO - 2016-11-13 02:02:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:02:02 --> Helper loaded: form_helper
INFO - 2016-11-13 02:02:02 --> Security Class Initialized
INFO - 2016-11-13 02:02:02 --> Final output sent to browser
DEBUG - 2016-11-13 02:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:02:02 --> Database Driver Class Initialized
DEBUG - 2016-11-13 02:02:02 --> Total execution time: 0.5113
INFO - 2016-11-13 02:02:02 --> Input Class Initialized
INFO - 2016-11-13 02:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:02:02 --> Language Class Initialized
INFO - 2016-11-13 02:02:02 --> Controller Class Initialized
INFO - 2016-11-13 02:02:02 --> Model Class Initialized
INFO - 2016-11-13 02:02:02 --> Loader Class Initialized
INFO - 2016-11-13 02:02:02 --> Form Validation Class Initialized
INFO - 2016-11-13 02:02:02 --> Helper loaded: url_helper
INFO - 2016-11-13 02:02:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:02:02 --> Helper loaded: form_helper
INFO - 2016-11-13 02:02:02 --> Final output sent to browser
INFO - 2016-11-13 02:02:02 --> Database Driver Class Initialized
DEBUG - 2016-11-13 02:02:02 --> Total execution time: 0.4792
INFO - 2016-11-13 02:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:02:02 --> Controller Class Initialized
INFO - 2016-11-13 02:02:02 --> Model Class Initialized
INFO - 2016-11-13 02:02:02 --> Form Validation Class Initialized
INFO - 2016-11-13 02:02:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:02:02 --> Final output sent to browser
DEBUG - 2016-11-13 02:02:02 --> Total execution time: 0.4401
INFO - 2016-11-13 02:02:17 --> Config Class Initialized
INFO - 2016-11-13 02:02:17 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:02:17 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:02:17 --> Utf8 Class Initialized
INFO - 2016-11-13 02:02:17 --> URI Class Initialized
INFO - 2016-11-13 02:02:17 --> Router Class Initialized
INFO - 2016-11-13 02:02:17 --> Output Class Initialized
INFO - 2016-11-13 02:02:17 --> Security Class Initialized
DEBUG - 2016-11-13 02:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:02:17 --> Input Class Initialized
INFO - 2016-11-13 02:02:17 --> Language Class Initialized
INFO - 2016-11-13 02:02:17 --> Loader Class Initialized
INFO - 2016-11-13 02:02:17 --> Helper loaded: url_helper
INFO - 2016-11-13 02:02:17 --> Helper loaded: form_helper
INFO - 2016-11-13 02:02:17 --> Database Driver Class Initialized
INFO - 2016-11-13 02:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:02:17 --> Controller Class Initialized
INFO - 2016-11-13 02:02:17 --> Model Class Initialized
INFO - 2016-11-13 02:02:17 --> Form Validation Class Initialized
INFO - 2016-11-13 02:02:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:02:17 --> Final output sent to browser
DEBUG - 2016-11-13 02:02:17 --> Total execution time: 0.3121
INFO - 2016-11-13 02:02:23 --> Config Class Initialized
INFO - 2016-11-13 02:02:23 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:02:23 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:02:23 --> Utf8 Class Initialized
INFO - 2016-11-13 02:02:23 --> URI Class Initialized
DEBUG - 2016-11-13 02:02:23 --> No URI present. Default controller set.
INFO - 2016-11-13 02:02:23 --> Router Class Initialized
INFO - 2016-11-13 02:02:23 --> Output Class Initialized
INFO - 2016-11-13 02:02:23 --> Security Class Initialized
DEBUG - 2016-11-13 02:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:02:23 --> Input Class Initialized
INFO - 2016-11-13 02:02:23 --> Language Class Initialized
INFO - 2016-11-13 02:02:23 --> Loader Class Initialized
INFO - 2016-11-13 02:02:23 --> Helper loaded: url_helper
INFO - 2016-11-13 02:02:23 --> Helper loaded: form_helper
INFO - 2016-11-13 02:02:23 --> Database Driver Class Initialized
INFO - 2016-11-13 02:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:02:23 --> Controller Class Initialized
INFO - 2016-11-13 02:02:23 --> Model Class Initialized
INFO - 2016-11-13 02:02:23 --> Model Class Initialized
INFO - 2016-11-13 02:02:23 --> Model Class Initialized
INFO - 2016-11-13 02:02:23 --> Model Class Initialized
INFO - 2016-11-13 02:02:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:02:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:02:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:02:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:02:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:02:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:02:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:02:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:02:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:02:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:02:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:02:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:02:24 --> Final output sent to browser
DEBUG - 2016-11-13 02:02:24 --> Total execution time: 0.5282
INFO - 2016-11-13 02:02:28 --> Config Class Initialized
INFO - 2016-11-13 02:02:28 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:02:28 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:02:28 --> Utf8 Class Initialized
INFO - 2016-11-13 02:02:28 --> URI Class Initialized
INFO - 2016-11-13 02:02:28 --> Router Class Initialized
INFO - 2016-11-13 02:02:28 --> Output Class Initialized
INFO - 2016-11-13 02:02:28 --> Security Class Initialized
DEBUG - 2016-11-13 02:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:02:28 --> Input Class Initialized
INFO - 2016-11-13 02:02:28 --> Language Class Initialized
INFO - 2016-11-13 02:02:28 --> Loader Class Initialized
INFO - 2016-11-13 02:02:28 --> Helper loaded: url_helper
INFO - 2016-11-13 02:02:28 --> Helper loaded: form_helper
INFO - 2016-11-13 02:02:29 --> Database Driver Class Initialized
INFO - 2016-11-13 02:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:02:29 --> Controller Class Initialized
INFO - 2016-11-13 02:02:29 --> Model Class Initialized
INFO - 2016-11-13 02:02:29 --> Form Validation Class Initialized
INFO - 2016-11-13 02:02:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:02:29 --> Final output sent to browser
DEBUG - 2016-11-13 02:02:29 --> Total execution time: 0.2685
INFO - 2016-11-13 02:02:33 --> Config Class Initialized
INFO - 2016-11-13 02:02:33 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:02:33 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:02:33 --> Utf8 Class Initialized
INFO - 2016-11-13 02:02:33 --> URI Class Initialized
INFO - 2016-11-13 02:02:33 --> Router Class Initialized
INFO - 2016-11-13 02:02:33 --> Output Class Initialized
INFO - 2016-11-13 02:02:33 --> Security Class Initialized
DEBUG - 2016-11-13 02:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:02:33 --> Input Class Initialized
INFO - 2016-11-13 02:02:33 --> Language Class Initialized
INFO - 2016-11-13 02:02:33 --> Loader Class Initialized
INFO - 2016-11-13 02:02:33 --> Helper loaded: url_helper
INFO - 2016-11-13 02:02:33 --> Helper loaded: form_helper
INFO - 2016-11-13 02:02:33 --> Database Driver Class Initialized
INFO - 2016-11-13 02:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:02:33 --> Controller Class Initialized
INFO - 2016-11-13 02:02:33 --> Model Class Initialized
INFO - 2016-11-13 02:02:33 --> Form Validation Class Initialized
INFO - 2016-11-13 02:02:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:02:33 --> Final output sent to browser
DEBUG - 2016-11-13 02:02:33 --> Total execution time: 0.3915
INFO - 2016-11-13 02:02:40 --> Config Class Initialized
INFO - 2016-11-13 02:02:40 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:02:40 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:02:40 --> Utf8 Class Initialized
INFO - 2016-11-13 02:02:40 --> URI Class Initialized
INFO - 2016-11-13 02:02:40 --> Router Class Initialized
INFO - 2016-11-13 02:02:40 --> Output Class Initialized
INFO - 2016-11-13 02:02:40 --> Security Class Initialized
DEBUG - 2016-11-13 02:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:02:40 --> Input Class Initialized
INFO - 2016-11-13 02:02:40 --> Language Class Initialized
INFO - 2016-11-13 02:02:40 --> Loader Class Initialized
INFO - 2016-11-13 02:02:40 --> Helper loaded: url_helper
INFO - 2016-11-13 02:02:40 --> Helper loaded: form_helper
INFO - 2016-11-13 02:02:40 --> Database Driver Class Initialized
INFO - 2016-11-13 02:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:02:40 --> Controller Class Initialized
INFO - 2016-11-13 02:02:40 --> Model Class Initialized
INFO - 2016-11-13 02:02:40 --> Form Validation Class Initialized
INFO - 2016-11-13 02:02:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:02:40 --> Final output sent to browser
DEBUG - 2016-11-13 02:02:40 --> Total execution time: 0.4401
INFO - 2016-11-13 02:02:58 --> Config Class Initialized
INFO - 2016-11-13 02:02:58 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:02:58 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:02:58 --> Utf8 Class Initialized
INFO - 2016-11-13 02:02:58 --> URI Class Initialized
DEBUG - 2016-11-13 02:02:58 --> No URI present. Default controller set.
INFO - 2016-11-13 02:02:58 --> Router Class Initialized
INFO - 2016-11-13 02:02:58 --> Output Class Initialized
INFO - 2016-11-13 02:02:58 --> Security Class Initialized
DEBUG - 2016-11-13 02:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:02:58 --> Input Class Initialized
INFO - 2016-11-13 02:02:58 --> Language Class Initialized
INFO - 2016-11-13 02:02:58 --> Loader Class Initialized
INFO - 2016-11-13 02:02:58 --> Helper loaded: url_helper
INFO - 2016-11-13 02:02:58 --> Helper loaded: form_helper
INFO - 2016-11-13 02:02:58 --> Database Driver Class Initialized
INFO - 2016-11-13 02:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:02:58 --> Controller Class Initialized
INFO - 2016-11-13 02:02:58 --> Model Class Initialized
INFO - 2016-11-13 02:02:58 --> Model Class Initialized
INFO - 2016-11-13 02:02:58 --> Model Class Initialized
INFO - 2016-11-13 02:02:58 --> Model Class Initialized
INFO - 2016-11-13 02:02:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:02:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:02:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:02:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:02:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:02:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:02:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:02:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:02:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:02:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:02:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:02:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:02:58 --> Final output sent to browser
DEBUG - 2016-11-13 02:02:58 --> Total execution time: 0.5435
INFO - 2016-11-13 02:03:06 --> Config Class Initialized
INFO - 2016-11-13 02:03:06 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:03:06 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:03:06 --> Utf8 Class Initialized
INFO - 2016-11-13 02:03:06 --> URI Class Initialized
INFO - 2016-11-13 02:03:06 --> Router Class Initialized
INFO - 2016-11-13 02:03:06 --> Output Class Initialized
INFO - 2016-11-13 02:03:06 --> Security Class Initialized
DEBUG - 2016-11-13 02:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:03:06 --> Input Class Initialized
INFO - 2016-11-13 02:03:06 --> Language Class Initialized
INFO - 2016-11-13 02:03:06 --> Loader Class Initialized
INFO - 2016-11-13 02:03:06 --> Helper loaded: url_helper
INFO - 2016-11-13 02:03:06 --> Helper loaded: form_helper
INFO - 2016-11-13 02:03:06 --> Database Driver Class Initialized
INFO - 2016-11-13 02:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:03:06 --> Controller Class Initialized
INFO - 2016-11-13 02:03:06 --> Model Class Initialized
INFO - 2016-11-13 02:03:06 --> Form Validation Class Initialized
INFO - 2016-11-13 02:03:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:03:06 --> Final output sent to browser
DEBUG - 2016-11-13 02:03:06 --> Total execution time: 0.2904
INFO - 2016-11-13 02:03:08 --> Config Class Initialized
INFO - 2016-11-13 02:03:08 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:03:08 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:03:08 --> Utf8 Class Initialized
INFO - 2016-11-13 02:03:08 --> URI Class Initialized
INFO - 2016-11-13 02:03:08 --> Router Class Initialized
INFO - 2016-11-13 02:03:08 --> Output Class Initialized
INFO - 2016-11-13 02:03:08 --> Security Class Initialized
DEBUG - 2016-11-13 02:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:03:08 --> Input Class Initialized
INFO - 2016-11-13 02:03:08 --> Language Class Initialized
INFO - 2016-11-13 02:03:08 --> Loader Class Initialized
INFO - 2016-11-13 02:03:08 --> Helper loaded: url_helper
INFO - 2016-11-13 02:03:08 --> Helper loaded: form_helper
INFO - 2016-11-13 02:03:08 --> Database Driver Class Initialized
INFO - 2016-11-13 02:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:03:08 --> Controller Class Initialized
INFO - 2016-11-13 02:03:08 --> Model Class Initialized
INFO - 2016-11-13 02:03:08 --> Form Validation Class Initialized
INFO - 2016-11-13 02:03:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:03:08 --> Final output sent to browser
DEBUG - 2016-11-13 02:03:08 --> Total execution time: 0.3524
INFO - 2016-11-13 02:03:09 --> Config Class Initialized
INFO - 2016-11-13 02:03:09 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:03:09 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:03:09 --> Utf8 Class Initialized
INFO - 2016-11-13 02:03:09 --> URI Class Initialized
INFO - 2016-11-13 02:03:09 --> Router Class Initialized
INFO - 2016-11-13 02:03:09 --> Output Class Initialized
INFO - 2016-11-13 02:03:09 --> Security Class Initialized
DEBUG - 2016-11-13 02:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:03:09 --> Input Class Initialized
INFO - 2016-11-13 02:03:09 --> Language Class Initialized
INFO - 2016-11-13 02:03:09 --> Loader Class Initialized
INFO - 2016-11-13 02:03:09 --> Helper loaded: url_helper
INFO - 2016-11-13 02:03:09 --> Helper loaded: form_helper
INFO - 2016-11-13 02:03:09 --> Database Driver Class Initialized
INFO - 2016-11-13 02:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:03:09 --> Controller Class Initialized
INFO - 2016-11-13 02:03:09 --> Model Class Initialized
INFO - 2016-11-13 02:03:09 --> Form Validation Class Initialized
INFO - 2016-11-13 02:03:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:03:09 --> Final output sent to browser
DEBUG - 2016-11-13 02:03:09 --> Total execution time: 0.2738
INFO - 2016-11-13 02:03:12 --> Config Class Initialized
INFO - 2016-11-13 02:03:12 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:03:12 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:03:12 --> Utf8 Class Initialized
INFO - 2016-11-13 02:03:12 --> URI Class Initialized
INFO - 2016-11-13 02:03:12 --> Router Class Initialized
INFO - 2016-11-13 02:03:12 --> Output Class Initialized
INFO - 2016-11-13 02:03:12 --> Security Class Initialized
DEBUG - 2016-11-13 02:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:03:12 --> Input Class Initialized
INFO - 2016-11-13 02:03:12 --> Language Class Initialized
INFO - 2016-11-13 02:03:12 --> Loader Class Initialized
INFO - 2016-11-13 02:03:12 --> Helper loaded: url_helper
INFO - 2016-11-13 02:03:12 --> Helper loaded: form_helper
INFO - 2016-11-13 02:03:12 --> Database Driver Class Initialized
INFO - 2016-11-13 02:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:03:13 --> Controller Class Initialized
INFO - 2016-11-13 02:03:13 --> Model Class Initialized
INFO - 2016-11-13 02:03:13 --> Form Validation Class Initialized
INFO - 2016-11-13 02:03:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:03:13 --> Final output sent to browser
DEBUG - 2016-11-13 02:03:13 --> Total execution time: 0.3022
INFO - 2016-11-13 02:04:25 --> Config Class Initialized
INFO - 2016-11-13 02:04:25 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:04:25 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:04:25 --> Utf8 Class Initialized
INFO - 2016-11-13 02:04:25 --> URI Class Initialized
INFO - 2016-11-13 02:04:25 --> Router Class Initialized
INFO - 2016-11-13 02:04:25 --> Output Class Initialized
INFO - 2016-11-13 02:04:25 --> Security Class Initialized
DEBUG - 2016-11-13 02:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:04:25 --> Input Class Initialized
INFO - 2016-11-13 02:04:25 --> Language Class Initialized
INFO - 2016-11-13 02:04:25 --> Loader Class Initialized
INFO - 2016-11-13 02:04:25 --> Helper loaded: url_helper
INFO - 2016-11-13 02:04:25 --> Helper loaded: form_helper
INFO - 2016-11-13 02:04:25 --> Database Driver Class Initialized
INFO - 2016-11-13 02:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:04:25 --> Controller Class Initialized
INFO - 2016-11-13 02:04:25 --> Model Class Initialized
INFO - 2016-11-13 02:04:25 --> Form Validation Class Initialized
INFO - 2016-11-13 02:04:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:04:25 --> Final output sent to browser
DEBUG - 2016-11-13 02:04:25 --> Total execution time: 0.2784
INFO - 2016-11-13 02:04:26 --> Config Class Initialized
INFO - 2016-11-13 02:04:26 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:04:26 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:04:26 --> Utf8 Class Initialized
INFO - 2016-11-13 02:04:26 --> URI Class Initialized
DEBUG - 2016-11-13 02:04:26 --> No URI present. Default controller set.
INFO - 2016-11-13 02:04:26 --> Router Class Initialized
INFO - 2016-11-13 02:04:26 --> Output Class Initialized
INFO - 2016-11-13 02:04:26 --> Security Class Initialized
DEBUG - 2016-11-13 02:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:04:26 --> Input Class Initialized
INFO - 2016-11-13 02:04:27 --> Language Class Initialized
INFO - 2016-11-13 02:04:27 --> Loader Class Initialized
INFO - 2016-11-13 02:04:27 --> Helper loaded: url_helper
INFO - 2016-11-13 02:04:27 --> Helper loaded: form_helper
INFO - 2016-11-13 02:04:27 --> Database Driver Class Initialized
INFO - 2016-11-13 02:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:04:27 --> Controller Class Initialized
INFO - 2016-11-13 02:04:27 --> Model Class Initialized
INFO - 2016-11-13 02:04:27 --> Model Class Initialized
INFO - 2016-11-13 02:04:27 --> Model Class Initialized
INFO - 2016-11-13 02:04:27 --> Model Class Initialized
INFO - 2016-11-13 02:04:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:04:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:04:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:04:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:04:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:04:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:04:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:04:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:04:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:04:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:04:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:04:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:04:27 --> Final output sent to browser
DEBUG - 2016-11-13 02:04:27 --> Total execution time: 0.6280
INFO - 2016-11-13 02:04:30 --> Config Class Initialized
INFO - 2016-11-13 02:04:30 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:04:30 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:04:30 --> Utf8 Class Initialized
INFO - 2016-11-13 02:04:30 --> URI Class Initialized
INFO - 2016-11-13 02:04:30 --> Router Class Initialized
INFO - 2016-11-13 02:04:30 --> Output Class Initialized
INFO - 2016-11-13 02:04:30 --> Security Class Initialized
DEBUG - 2016-11-13 02:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:04:30 --> Input Class Initialized
INFO - 2016-11-13 02:04:30 --> Language Class Initialized
INFO - 2016-11-13 02:04:30 --> Loader Class Initialized
INFO - 2016-11-13 02:04:30 --> Helper loaded: url_helper
INFO - 2016-11-13 02:04:30 --> Helper loaded: form_helper
INFO - 2016-11-13 02:04:30 --> Database Driver Class Initialized
INFO - 2016-11-13 02:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:04:30 --> Controller Class Initialized
INFO - 2016-11-13 02:04:30 --> Model Class Initialized
INFO - 2016-11-13 02:04:30 --> Form Validation Class Initialized
INFO - 2016-11-13 02:04:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:04:30 --> Final output sent to browser
DEBUG - 2016-11-13 02:04:30 --> Total execution time: 0.2823
INFO - 2016-11-13 02:07:45 --> Config Class Initialized
INFO - 2016-11-13 02:07:45 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:07:45 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:07:45 --> Utf8 Class Initialized
INFO - 2016-11-13 02:07:45 --> URI Class Initialized
DEBUG - 2016-11-13 02:07:45 --> No URI present. Default controller set.
INFO - 2016-11-13 02:07:45 --> Router Class Initialized
INFO - 2016-11-13 02:07:45 --> Output Class Initialized
INFO - 2016-11-13 02:07:45 --> Security Class Initialized
DEBUG - 2016-11-13 02:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:07:45 --> Input Class Initialized
INFO - 2016-11-13 02:07:45 --> Language Class Initialized
INFO - 2016-11-13 02:07:45 --> Loader Class Initialized
INFO - 2016-11-13 02:07:45 --> Helper loaded: url_helper
INFO - 2016-11-13 02:07:45 --> Helper loaded: form_helper
INFO - 2016-11-13 02:07:45 --> Database Driver Class Initialized
INFO - 2016-11-13 02:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:07:45 --> Controller Class Initialized
INFO - 2016-11-13 02:07:45 --> Model Class Initialized
INFO - 2016-11-13 02:07:45 --> Model Class Initialized
INFO - 2016-11-13 02:07:45 --> Model Class Initialized
INFO - 2016-11-13 02:07:45 --> Model Class Initialized
INFO - 2016-11-13 02:07:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:07:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:07:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:07:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:07:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:07:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:07:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:07:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:07:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:07:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:07:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:07:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:07:45 --> Final output sent to browser
DEBUG - 2016-11-13 02:07:45 --> Total execution time: 0.5178
INFO - 2016-11-13 02:07:48 --> Config Class Initialized
INFO - 2016-11-13 02:07:48 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:07:48 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:07:48 --> Utf8 Class Initialized
INFO - 2016-11-13 02:07:48 --> URI Class Initialized
INFO - 2016-11-13 02:07:48 --> Router Class Initialized
INFO - 2016-11-13 02:07:48 --> Output Class Initialized
INFO - 2016-11-13 02:07:48 --> Security Class Initialized
DEBUG - 2016-11-13 02:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:07:48 --> Input Class Initialized
INFO - 2016-11-13 02:07:49 --> Language Class Initialized
INFO - 2016-11-13 02:07:49 --> Loader Class Initialized
INFO - 2016-11-13 02:07:49 --> Helper loaded: url_helper
INFO - 2016-11-13 02:07:49 --> Helper loaded: form_helper
INFO - 2016-11-13 02:07:49 --> Database Driver Class Initialized
INFO - 2016-11-13 02:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:07:49 --> Controller Class Initialized
INFO - 2016-11-13 02:07:49 --> Model Class Initialized
INFO - 2016-11-13 02:07:49 --> Form Validation Class Initialized
INFO - 2016-11-13 02:07:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:07:49 --> Final output sent to browser
DEBUG - 2016-11-13 02:07:49 --> Total execution time: 0.2766
INFO - 2016-11-13 02:07:52 --> Config Class Initialized
INFO - 2016-11-13 02:07:52 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:07:52 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:07:52 --> Utf8 Class Initialized
INFO - 2016-11-13 02:07:53 --> URI Class Initialized
INFO - 2016-11-13 02:07:53 --> Router Class Initialized
INFO - 2016-11-13 02:07:53 --> Output Class Initialized
INFO - 2016-11-13 02:07:53 --> Security Class Initialized
DEBUG - 2016-11-13 02:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:07:53 --> Input Class Initialized
INFO - 2016-11-13 02:07:53 --> Language Class Initialized
INFO - 2016-11-13 02:07:53 --> Loader Class Initialized
INFO - 2016-11-13 02:07:53 --> Helper loaded: url_helper
INFO - 2016-11-13 02:07:53 --> Helper loaded: form_helper
INFO - 2016-11-13 02:07:53 --> Database Driver Class Initialized
INFO - 2016-11-13 02:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:07:53 --> Controller Class Initialized
INFO - 2016-11-13 02:07:53 --> Model Class Initialized
INFO - 2016-11-13 02:07:53 --> Form Validation Class Initialized
INFO - 2016-11-13 02:07:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:07:53 --> Final output sent to browser
DEBUG - 2016-11-13 02:07:53 --> Total execution time: 0.2895
INFO - 2016-11-13 02:09:37 --> Config Class Initialized
INFO - 2016-11-13 02:09:37 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:09:37 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:09:37 --> Utf8 Class Initialized
INFO - 2016-11-13 02:09:37 --> URI Class Initialized
DEBUG - 2016-11-13 02:09:37 --> No URI present. Default controller set.
INFO - 2016-11-13 02:09:37 --> Router Class Initialized
INFO - 2016-11-13 02:09:37 --> Output Class Initialized
INFO - 2016-11-13 02:09:37 --> Security Class Initialized
DEBUG - 2016-11-13 02:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:09:37 --> Input Class Initialized
INFO - 2016-11-13 02:09:37 --> Language Class Initialized
INFO - 2016-11-13 02:09:37 --> Loader Class Initialized
INFO - 2016-11-13 02:09:37 --> Helper loaded: url_helper
INFO - 2016-11-13 02:09:37 --> Helper loaded: form_helper
INFO - 2016-11-13 02:09:38 --> Database Driver Class Initialized
INFO - 2016-11-13 02:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:09:38 --> Controller Class Initialized
INFO - 2016-11-13 02:09:38 --> Model Class Initialized
INFO - 2016-11-13 02:09:38 --> Model Class Initialized
INFO - 2016-11-13 02:09:38 --> Model Class Initialized
INFO - 2016-11-13 02:09:38 --> Model Class Initialized
INFO - 2016-11-13 02:09:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:09:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:09:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:09:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:09:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:09:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:09:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:09:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:09:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:09:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:09:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:09:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:09:38 --> Final output sent to browser
DEBUG - 2016-11-13 02:09:38 --> Total execution time: 0.5418
INFO - 2016-11-13 02:10:04 --> Config Class Initialized
INFO - 2016-11-13 02:10:04 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:10:04 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:10:04 --> Utf8 Class Initialized
INFO - 2016-11-13 02:10:04 --> URI Class Initialized
DEBUG - 2016-11-13 02:10:04 --> No URI present. Default controller set.
INFO - 2016-11-13 02:10:04 --> Router Class Initialized
INFO - 2016-11-13 02:10:04 --> Output Class Initialized
INFO - 2016-11-13 02:10:04 --> Security Class Initialized
DEBUG - 2016-11-13 02:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:10:04 --> Input Class Initialized
INFO - 2016-11-13 02:10:04 --> Language Class Initialized
INFO - 2016-11-13 02:10:04 --> Loader Class Initialized
INFO - 2016-11-13 02:10:04 --> Helper loaded: url_helper
INFO - 2016-11-13 02:10:04 --> Helper loaded: form_helper
INFO - 2016-11-13 02:10:04 --> Database Driver Class Initialized
INFO - 2016-11-13 02:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:10:04 --> Controller Class Initialized
INFO - 2016-11-13 02:10:04 --> Model Class Initialized
INFO - 2016-11-13 02:10:04 --> Model Class Initialized
INFO - 2016-11-13 02:10:04 --> Model Class Initialized
INFO - 2016-11-13 02:10:04 --> Model Class Initialized
INFO - 2016-11-13 02:10:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:10:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:10:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:10:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:10:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:10:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:10:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:10:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:10:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:10:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:10:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:10:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:10:04 --> Final output sent to browser
DEBUG - 2016-11-13 02:10:04 --> Total execution time: 0.5539
INFO - 2016-11-13 02:10:07 --> Config Class Initialized
INFO - 2016-11-13 02:10:07 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:10:07 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:10:07 --> Utf8 Class Initialized
INFO - 2016-11-13 02:10:07 --> URI Class Initialized
INFO - 2016-11-13 02:10:07 --> Router Class Initialized
INFO - 2016-11-13 02:10:07 --> Output Class Initialized
INFO - 2016-11-13 02:10:07 --> Security Class Initialized
DEBUG - 2016-11-13 02:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:10:07 --> Input Class Initialized
INFO - 2016-11-13 02:10:07 --> Language Class Initialized
INFO - 2016-11-13 02:10:07 --> Loader Class Initialized
INFO - 2016-11-13 02:10:07 --> Helper loaded: url_helper
INFO - 2016-11-13 02:10:07 --> Helper loaded: form_helper
INFO - 2016-11-13 02:10:07 --> Database Driver Class Initialized
INFO - 2016-11-13 02:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:10:07 --> Controller Class Initialized
INFO - 2016-11-13 02:10:07 --> Model Class Initialized
INFO - 2016-11-13 02:10:07 --> Form Validation Class Initialized
INFO - 2016-11-13 02:10:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:10:07 --> Final output sent to browser
DEBUG - 2016-11-13 02:10:07 --> Total execution time: 0.2820
INFO - 2016-11-13 02:10:17 --> Config Class Initialized
INFO - 2016-11-13 02:10:17 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:10:17 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:10:17 --> Utf8 Class Initialized
INFO - 2016-11-13 02:10:17 --> URI Class Initialized
INFO - 2016-11-13 02:10:17 --> Router Class Initialized
INFO - 2016-11-13 02:10:17 --> Output Class Initialized
INFO - 2016-11-13 02:10:17 --> Security Class Initialized
DEBUG - 2016-11-13 02:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:10:18 --> Input Class Initialized
INFO - 2016-11-13 02:10:18 --> Language Class Initialized
INFO - 2016-11-13 02:10:18 --> Loader Class Initialized
INFO - 2016-11-13 02:10:18 --> Helper loaded: url_helper
INFO - 2016-11-13 02:10:18 --> Helper loaded: form_helper
INFO - 2016-11-13 02:10:18 --> Database Driver Class Initialized
INFO - 2016-11-13 02:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:10:18 --> Controller Class Initialized
INFO - 2016-11-13 02:10:18 --> Model Class Initialized
INFO - 2016-11-13 02:10:18 --> Form Validation Class Initialized
INFO - 2016-11-13 02:10:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:10:18 --> Final output sent to browser
DEBUG - 2016-11-13 02:10:18 --> Total execution time: 0.2857
INFO - 2016-11-13 02:10:26 --> Config Class Initialized
INFO - 2016-11-13 02:10:26 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:10:26 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:10:26 --> Utf8 Class Initialized
INFO - 2016-11-13 02:10:26 --> URI Class Initialized
INFO - 2016-11-13 02:10:26 --> Router Class Initialized
INFO - 2016-11-13 02:10:26 --> Output Class Initialized
INFO - 2016-11-13 02:10:26 --> Security Class Initialized
DEBUG - 2016-11-13 02:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:10:26 --> Input Class Initialized
INFO - 2016-11-13 02:10:26 --> Language Class Initialized
INFO - 2016-11-13 02:10:26 --> Loader Class Initialized
INFO - 2016-11-13 02:10:26 --> Helper loaded: url_helper
INFO - 2016-11-13 02:10:26 --> Helper loaded: form_helper
INFO - 2016-11-13 02:10:26 --> Database Driver Class Initialized
INFO - 2016-11-13 02:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:10:26 --> Controller Class Initialized
INFO - 2016-11-13 02:10:26 --> Model Class Initialized
INFO - 2016-11-13 02:10:26 --> Form Validation Class Initialized
INFO - 2016-11-13 02:10:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:10:26 --> Final output sent to browser
DEBUG - 2016-11-13 02:10:27 --> Total execution time: 0.3348
INFO - 2016-11-13 02:10:29 --> Config Class Initialized
INFO - 2016-11-13 02:10:29 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:10:29 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:10:29 --> Utf8 Class Initialized
INFO - 2016-11-13 02:10:29 --> URI Class Initialized
INFO - 2016-11-13 02:10:29 --> Router Class Initialized
INFO - 2016-11-13 02:10:29 --> Output Class Initialized
INFO - 2016-11-13 02:10:29 --> Security Class Initialized
DEBUG - 2016-11-13 02:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:10:29 --> Input Class Initialized
INFO - 2016-11-13 02:10:29 --> Language Class Initialized
INFO - 2016-11-13 02:10:29 --> Loader Class Initialized
INFO - 2016-11-13 02:10:30 --> Helper loaded: url_helper
INFO - 2016-11-13 02:10:30 --> Helper loaded: form_helper
INFO - 2016-11-13 02:10:30 --> Database Driver Class Initialized
INFO - 2016-11-13 02:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:10:30 --> Controller Class Initialized
INFO - 2016-11-13 02:10:30 --> Model Class Initialized
INFO - 2016-11-13 02:10:30 --> Model Class Initialized
INFO - 2016-11-13 02:10:30 --> Model Class Initialized
INFO - 2016-11-13 02:10:30 --> Model Class Initialized
DEBUG - 2016-11-13 02:10:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-13 02:10:30 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-13 02:10:30 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-13 02:10:30 --> Config Class Initialized
INFO - 2016-11-13 02:10:30 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:10:30 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:10:30 --> Utf8 Class Initialized
INFO - 2016-11-13 02:10:30 --> URI Class Initialized
DEBUG - 2016-11-13 02:10:30 --> No URI present. Default controller set.
INFO - 2016-11-13 02:10:30 --> Router Class Initialized
INFO - 2016-11-13 02:10:30 --> Output Class Initialized
INFO - 2016-11-13 02:10:30 --> Security Class Initialized
DEBUG - 2016-11-13 02:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:10:30 --> Input Class Initialized
INFO - 2016-11-13 02:10:30 --> Language Class Initialized
INFO - 2016-11-13 02:10:30 --> Loader Class Initialized
INFO - 2016-11-13 02:10:30 --> Helper loaded: url_helper
INFO - 2016-11-13 02:10:30 --> Helper loaded: form_helper
INFO - 2016-11-13 02:10:30 --> Database Driver Class Initialized
INFO - 2016-11-13 02:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:10:30 --> Controller Class Initialized
INFO - 2016-11-13 02:10:30 --> Model Class Initialized
INFO - 2016-11-13 02:10:30 --> Model Class Initialized
INFO - 2016-11-13 02:10:30 --> Model Class Initialized
INFO - 2016-11-13 02:10:30 --> Model Class Initialized
INFO - 2016-11-13 02:10:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:10:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-13 02:10:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:10:30 --> Final output sent to browser
DEBUG - 2016-11-13 02:10:30 --> Total execution time: 0.3795
INFO - 2016-11-13 02:10:39 --> Config Class Initialized
INFO - 2016-11-13 02:10:39 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:10:39 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:10:39 --> Utf8 Class Initialized
INFO - 2016-11-13 02:10:39 --> URI Class Initialized
INFO - 2016-11-13 02:10:39 --> Router Class Initialized
INFO - 2016-11-13 02:10:39 --> Output Class Initialized
INFO - 2016-11-13 02:10:39 --> Security Class Initialized
DEBUG - 2016-11-13 02:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:10:39 --> Input Class Initialized
INFO - 2016-11-13 02:10:39 --> Language Class Initialized
INFO - 2016-11-13 02:10:39 --> Loader Class Initialized
INFO - 2016-11-13 02:10:39 --> Helper loaded: url_helper
INFO - 2016-11-13 02:10:39 --> Helper loaded: form_helper
INFO - 2016-11-13 02:10:39 --> Database Driver Class Initialized
INFO - 2016-11-13 02:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:10:39 --> Controller Class Initialized
INFO - 2016-11-13 02:10:39 --> Model Class Initialized
INFO - 2016-11-13 02:10:39 --> Model Class Initialized
INFO - 2016-11-13 02:10:39 --> Model Class Initialized
INFO - 2016-11-13 02:10:39 --> Model Class Initialized
DEBUG - 2016-11-13 02:10:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-13 02:10:39 --> Model Class Initialized
INFO - 2016-11-13 02:10:39 --> Final output sent to browser
DEBUG - 2016-11-13 02:10:39 --> Total execution time: 0.3379
INFO - 2016-11-13 02:10:47 --> Config Class Initialized
INFO - 2016-11-13 02:10:47 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:10:47 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:10:47 --> Utf8 Class Initialized
INFO - 2016-11-13 02:10:47 --> URI Class Initialized
INFO - 2016-11-13 02:10:47 --> Router Class Initialized
INFO - 2016-11-13 02:10:47 --> Output Class Initialized
INFO - 2016-11-13 02:10:47 --> Security Class Initialized
DEBUG - 2016-11-13 02:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:10:47 --> Input Class Initialized
INFO - 2016-11-13 02:10:47 --> Language Class Initialized
INFO - 2016-11-13 02:10:47 --> Loader Class Initialized
INFO - 2016-11-13 02:10:47 --> Helper loaded: url_helper
INFO - 2016-11-13 02:10:47 --> Helper loaded: form_helper
INFO - 2016-11-13 02:10:47 --> Database Driver Class Initialized
INFO - 2016-11-13 02:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:10:48 --> Controller Class Initialized
INFO - 2016-11-13 02:10:48 --> Model Class Initialized
INFO - 2016-11-13 02:10:48 --> Model Class Initialized
INFO - 2016-11-13 02:10:48 --> Model Class Initialized
INFO - 2016-11-13 02:10:48 --> Model Class Initialized
DEBUG - 2016-11-13 02:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-13 02:10:48 --> Model Class Initialized
INFO - 2016-11-13 02:10:48 --> Final output sent to browser
DEBUG - 2016-11-13 02:10:48 --> Total execution time: 0.3625
INFO - 2016-11-13 02:10:48 --> Config Class Initialized
INFO - 2016-11-13 02:10:48 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:10:48 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:10:48 --> Utf8 Class Initialized
INFO - 2016-11-13 02:10:48 --> URI Class Initialized
DEBUG - 2016-11-13 02:10:48 --> No URI present. Default controller set.
INFO - 2016-11-13 02:10:48 --> Router Class Initialized
INFO - 2016-11-13 02:10:48 --> Output Class Initialized
INFO - 2016-11-13 02:10:48 --> Security Class Initialized
DEBUG - 2016-11-13 02:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:10:48 --> Input Class Initialized
INFO - 2016-11-13 02:10:48 --> Language Class Initialized
INFO - 2016-11-13 02:10:48 --> Loader Class Initialized
INFO - 2016-11-13 02:10:48 --> Helper loaded: url_helper
INFO - 2016-11-13 02:10:48 --> Helper loaded: form_helper
INFO - 2016-11-13 02:10:48 --> Database Driver Class Initialized
INFO - 2016-11-13 02:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:10:48 --> Controller Class Initialized
INFO - 2016-11-13 02:10:48 --> Model Class Initialized
INFO - 2016-11-13 02:10:48 --> Model Class Initialized
INFO - 2016-11-13 02:10:48 --> Model Class Initialized
INFO - 2016-11-13 02:10:48 --> Model Class Initialized
INFO - 2016-11-13 02:10:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:10:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:10:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:10:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-13 02:10:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-13 02:10:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-13 02:10:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-13 02:10:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-13 02:10:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-13 02:10:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:10:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:10:48 --> Final output sent to browser
DEBUG - 2016-11-13 02:10:48 --> Total execution time: 0.5109
INFO - 2016-11-13 02:10:57 --> Config Class Initialized
INFO - 2016-11-13 02:10:57 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:10:57 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:10:57 --> Utf8 Class Initialized
INFO - 2016-11-13 02:10:57 --> URI Class Initialized
INFO - 2016-11-13 02:10:57 --> Router Class Initialized
INFO - 2016-11-13 02:10:57 --> Output Class Initialized
INFO - 2016-11-13 02:10:57 --> Security Class Initialized
DEBUG - 2016-11-13 02:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:10:57 --> Input Class Initialized
INFO - 2016-11-13 02:10:58 --> Language Class Initialized
INFO - 2016-11-13 02:10:58 --> Loader Class Initialized
INFO - 2016-11-13 02:10:58 --> Helper loaded: url_helper
INFO - 2016-11-13 02:10:58 --> Helper loaded: form_helper
INFO - 2016-11-13 02:10:58 --> Database Driver Class Initialized
INFO - 2016-11-13 02:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:10:58 --> Controller Class Initialized
INFO - 2016-11-13 02:10:58 --> Model Class Initialized
INFO - 2016-11-13 02:10:58 --> Form Validation Class Initialized
INFO - 2016-11-13 02:10:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:10:58 --> Final output sent to browser
DEBUG - 2016-11-13 02:10:58 --> Total execution time: 0.3469
INFO - 2016-11-13 02:13:36 --> Config Class Initialized
INFO - 2016-11-13 02:13:36 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:13:36 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:13:36 --> Utf8 Class Initialized
INFO - 2016-11-13 02:13:36 --> URI Class Initialized
INFO - 2016-11-13 02:13:36 --> Router Class Initialized
INFO - 2016-11-13 02:13:36 --> Output Class Initialized
INFO - 2016-11-13 02:13:36 --> Security Class Initialized
DEBUG - 2016-11-13 02:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:13:36 --> Input Class Initialized
INFO - 2016-11-13 02:13:36 --> Language Class Initialized
INFO - 2016-11-13 02:13:36 --> Loader Class Initialized
INFO - 2016-11-13 02:13:36 --> Helper loaded: url_helper
INFO - 2016-11-13 02:13:36 --> Helper loaded: form_helper
INFO - 2016-11-13 02:13:36 --> Database Driver Class Initialized
INFO - 2016-11-13 02:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:13:36 --> Controller Class Initialized
INFO - 2016-11-13 02:13:36 --> Model Class Initialized
INFO - 2016-11-13 02:13:36 --> Model Class Initialized
INFO - 2016-11-13 02:13:36 --> Model Class Initialized
INFO - 2016-11-13 02:13:36 --> Model Class Initialized
DEBUG - 2016-11-13 02:13:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-13 02:13:36 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-13 02:13:36 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-13 02:13:36 --> Config Class Initialized
INFO - 2016-11-13 02:13:36 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:13:37 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:13:37 --> Utf8 Class Initialized
INFO - 2016-11-13 02:13:37 --> URI Class Initialized
DEBUG - 2016-11-13 02:13:37 --> No URI present. Default controller set.
INFO - 2016-11-13 02:13:37 --> Router Class Initialized
INFO - 2016-11-13 02:13:37 --> Output Class Initialized
INFO - 2016-11-13 02:13:37 --> Security Class Initialized
DEBUG - 2016-11-13 02:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:13:37 --> Input Class Initialized
INFO - 2016-11-13 02:13:37 --> Language Class Initialized
INFO - 2016-11-13 02:13:37 --> Loader Class Initialized
INFO - 2016-11-13 02:13:37 --> Helper loaded: url_helper
INFO - 2016-11-13 02:13:37 --> Helper loaded: form_helper
INFO - 2016-11-13 02:13:37 --> Database Driver Class Initialized
INFO - 2016-11-13 02:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:13:37 --> Controller Class Initialized
INFO - 2016-11-13 02:13:37 --> Model Class Initialized
INFO - 2016-11-13 02:13:37 --> Model Class Initialized
INFO - 2016-11-13 02:13:37 --> Model Class Initialized
INFO - 2016-11-13 02:13:37 --> Model Class Initialized
INFO - 2016-11-13 02:13:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:13:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-13 02:13:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:13:37 --> Final output sent to browser
DEBUG - 2016-11-13 02:13:37 --> Total execution time: 0.3847
INFO - 2016-11-13 02:13:44 --> Config Class Initialized
INFO - 2016-11-13 02:13:44 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:13:44 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:13:44 --> Utf8 Class Initialized
INFO - 2016-11-13 02:13:44 --> URI Class Initialized
INFO - 2016-11-13 02:13:44 --> Router Class Initialized
INFO - 2016-11-13 02:13:44 --> Output Class Initialized
INFO - 2016-11-13 02:13:44 --> Security Class Initialized
DEBUG - 2016-11-13 02:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:13:44 --> Input Class Initialized
INFO - 2016-11-13 02:13:44 --> Language Class Initialized
INFO - 2016-11-13 02:13:44 --> Loader Class Initialized
INFO - 2016-11-13 02:13:44 --> Helper loaded: url_helper
INFO - 2016-11-13 02:13:44 --> Helper loaded: form_helper
INFO - 2016-11-13 02:13:44 --> Database Driver Class Initialized
INFO - 2016-11-13 02:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:13:44 --> Controller Class Initialized
INFO - 2016-11-13 02:13:44 --> Model Class Initialized
INFO - 2016-11-13 02:13:44 --> Model Class Initialized
INFO - 2016-11-13 02:13:44 --> Model Class Initialized
INFO - 2016-11-13 02:13:44 --> Model Class Initialized
DEBUG - 2016-11-13 02:13:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-13 02:13:44 --> Model Class Initialized
INFO - 2016-11-13 02:13:44 --> Final output sent to browser
DEBUG - 2016-11-13 02:13:44 --> Total execution time: 0.3541
INFO - 2016-11-13 02:13:44 --> Config Class Initialized
INFO - 2016-11-13 02:13:44 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:13:44 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:13:44 --> Utf8 Class Initialized
INFO - 2016-11-13 02:13:45 --> URI Class Initialized
DEBUG - 2016-11-13 02:13:45 --> No URI present. Default controller set.
INFO - 2016-11-13 02:13:45 --> Router Class Initialized
INFO - 2016-11-13 02:13:45 --> Output Class Initialized
INFO - 2016-11-13 02:13:45 --> Security Class Initialized
DEBUG - 2016-11-13 02:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:13:45 --> Input Class Initialized
INFO - 2016-11-13 02:13:45 --> Language Class Initialized
INFO - 2016-11-13 02:13:45 --> Loader Class Initialized
INFO - 2016-11-13 02:13:45 --> Helper loaded: url_helper
INFO - 2016-11-13 02:13:45 --> Helper loaded: form_helper
INFO - 2016-11-13 02:13:45 --> Database Driver Class Initialized
INFO - 2016-11-13 02:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:13:45 --> Controller Class Initialized
INFO - 2016-11-13 02:13:45 --> Model Class Initialized
INFO - 2016-11-13 02:13:45 --> Model Class Initialized
INFO - 2016-11-13 02:13:45 --> Model Class Initialized
INFO - 2016-11-13 02:13:45 --> Model Class Initialized
INFO - 2016-11-13 02:13:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:13:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:13:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:13:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:13:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:13:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:13:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:13:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:13:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:13:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:13:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:13:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:13:45 --> Final output sent to browser
DEBUG - 2016-11-13 02:13:45 --> Total execution time: 0.5381
INFO - 2016-11-13 02:13:50 --> Config Class Initialized
INFO - 2016-11-13 02:13:50 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:13:50 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:13:50 --> Utf8 Class Initialized
INFO - 2016-11-13 02:13:50 --> URI Class Initialized
INFO - 2016-11-13 02:13:50 --> Router Class Initialized
INFO - 2016-11-13 02:13:50 --> Output Class Initialized
INFO - 2016-11-13 02:13:50 --> Security Class Initialized
DEBUG - 2016-11-13 02:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:13:50 --> Input Class Initialized
INFO - 2016-11-13 02:13:50 --> Language Class Initialized
INFO - 2016-11-13 02:13:50 --> Loader Class Initialized
INFO - 2016-11-13 02:13:50 --> Helper loaded: url_helper
INFO - 2016-11-13 02:13:50 --> Helper loaded: form_helper
INFO - 2016-11-13 02:13:50 --> Database Driver Class Initialized
INFO - 2016-11-13 02:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:13:50 --> Controller Class Initialized
INFO - 2016-11-13 02:13:50 --> Model Class Initialized
INFO - 2016-11-13 02:13:50 --> Form Validation Class Initialized
INFO - 2016-11-13 02:13:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:13:50 --> Final output sent to browser
DEBUG - 2016-11-13 02:13:50 --> Total execution time: 0.2858
INFO - 2016-11-13 02:14:00 --> Config Class Initialized
INFO - 2016-11-13 02:14:00 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:14:00 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:14:00 --> Utf8 Class Initialized
INFO - 2016-11-13 02:14:00 --> URI Class Initialized
INFO - 2016-11-13 02:14:00 --> Router Class Initialized
INFO - 2016-11-13 02:14:00 --> Output Class Initialized
INFO - 2016-11-13 02:14:00 --> Security Class Initialized
DEBUG - 2016-11-13 02:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:14:00 --> Input Class Initialized
INFO - 2016-11-13 02:14:00 --> Language Class Initialized
INFO - 2016-11-13 02:14:00 --> Loader Class Initialized
INFO - 2016-11-13 02:14:00 --> Helper loaded: url_helper
INFO - 2016-11-13 02:14:00 --> Helper loaded: form_helper
INFO - 2016-11-13 02:14:00 --> Database Driver Class Initialized
INFO - 2016-11-13 02:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:14:00 --> Controller Class Initialized
INFO - 2016-11-13 02:14:00 --> Model Class Initialized
INFO - 2016-11-13 02:14:00 --> Form Validation Class Initialized
INFO - 2016-11-13 02:14:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:14:00 --> Final output sent to browser
DEBUG - 2016-11-13 02:14:00 --> Total execution time: 0.2891
INFO - 2016-11-13 02:14:36 --> Config Class Initialized
INFO - 2016-11-13 02:14:36 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:14:36 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:14:36 --> Utf8 Class Initialized
INFO - 2016-11-13 02:14:36 --> URI Class Initialized
DEBUG - 2016-11-13 02:14:36 --> No URI present. Default controller set.
INFO - 2016-11-13 02:14:36 --> Router Class Initialized
INFO - 2016-11-13 02:14:36 --> Output Class Initialized
INFO - 2016-11-13 02:14:36 --> Security Class Initialized
DEBUG - 2016-11-13 02:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:14:36 --> Input Class Initialized
INFO - 2016-11-13 02:14:36 --> Language Class Initialized
INFO - 2016-11-13 02:14:36 --> Loader Class Initialized
INFO - 2016-11-13 02:14:36 --> Helper loaded: url_helper
INFO - 2016-11-13 02:14:36 --> Helper loaded: form_helper
INFO - 2016-11-13 02:14:36 --> Database Driver Class Initialized
INFO - 2016-11-13 02:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:14:36 --> Controller Class Initialized
INFO - 2016-11-13 02:14:36 --> Model Class Initialized
INFO - 2016-11-13 02:14:36 --> Model Class Initialized
INFO - 2016-11-13 02:14:36 --> Model Class Initialized
INFO - 2016-11-13 02:14:36 --> Model Class Initialized
INFO - 2016-11-13 02:14:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:14:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:14:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:14:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:14:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:14:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:14:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:14:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:14:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:14:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:14:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:14:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:14:37 --> Final output sent to browser
DEBUG - 2016-11-13 02:14:37 --> Total execution time: 0.5309
INFO - 2016-11-13 02:14:41 --> Config Class Initialized
INFO - 2016-11-13 02:14:41 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:14:41 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:14:41 --> Utf8 Class Initialized
INFO - 2016-11-13 02:14:41 --> URI Class Initialized
INFO - 2016-11-13 02:14:41 --> Router Class Initialized
INFO - 2016-11-13 02:14:41 --> Output Class Initialized
INFO - 2016-11-13 02:14:41 --> Security Class Initialized
DEBUG - 2016-11-13 02:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:14:41 --> Input Class Initialized
INFO - 2016-11-13 02:14:41 --> Language Class Initialized
INFO - 2016-11-13 02:14:41 --> Loader Class Initialized
INFO - 2016-11-13 02:14:41 --> Helper loaded: url_helper
INFO - 2016-11-13 02:14:41 --> Helper loaded: form_helper
INFO - 2016-11-13 02:14:41 --> Database Driver Class Initialized
INFO - 2016-11-13 02:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:14:41 --> Controller Class Initialized
INFO - 2016-11-13 02:14:41 --> Model Class Initialized
INFO - 2016-11-13 02:14:41 --> Form Validation Class Initialized
INFO - 2016-11-13 02:14:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:14:41 --> Final output sent to browser
DEBUG - 2016-11-13 02:14:41 --> Total execution time: 0.2874
INFO - 2016-11-13 02:14:58 --> Config Class Initialized
INFO - 2016-11-13 02:14:58 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:14:58 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:14:58 --> Utf8 Class Initialized
INFO - 2016-11-13 02:14:58 --> URI Class Initialized
DEBUG - 2016-11-13 02:14:58 --> No URI present. Default controller set.
INFO - 2016-11-13 02:14:58 --> Router Class Initialized
INFO - 2016-11-13 02:14:58 --> Output Class Initialized
INFO - 2016-11-13 02:14:58 --> Security Class Initialized
DEBUG - 2016-11-13 02:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:14:58 --> Input Class Initialized
INFO - 2016-11-13 02:14:58 --> Language Class Initialized
INFO - 2016-11-13 02:14:58 --> Loader Class Initialized
INFO - 2016-11-13 02:14:58 --> Helper loaded: url_helper
INFO - 2016-11-13 02:14:58 --> Helper loaded: form_helper
INFO - 2016-11-13 02:14:58 --> Database Driver Class Initialized
INFO - 2016-11-13 02:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:14:58 --> Controller Class Initialized
INFO - 2016-11-13 02:14:58 --> Model Class Initialized
INFO - 2016-11-13 02:14:58 --> Model Class Initialized
INFO - 2016-11-13 02:14:58 --> Model Class Initialized
INFO - 2016-11-13 02:14:58 --> Model Class Initialized
INFO - 2016-11-13 02:14:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:14:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:14:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:14:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:14:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:14:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:14:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:14:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:14:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:14:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:14:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:14:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:14:58 --> Final output sent to browser
DEBUG - 2016-11-13 02:14:58 --> Total execution time: 0.5930
INFO - 2016-11-13 02:15:01 --> Config Class Initialized
INFO - 2016-11-13 02:15:01 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:15:01 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:15:01 --> Utf8 Class Initialized
INFO - 2016-11-13 02:15:01 --> URI Class Initialized
INFO - 2016-11-13 02:15:01 --> Router Class Initialized
INFO - 2016-11-13 02:15:01 --> Output Class Initialized
INFO - 2016-11-13 02:15:01 --> Security Class Initialized
DEBUG - 2016-11-13 02:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:15:01 --> Input Class Initialized
INFO - 2016-11-13 02:15:01 --> Language Class Initialized
INFO - 2016-11-13 02:15:01 --> Loader Class Initialized
INFO - 2016-11-13 02:15:01 --> Helper loaded: url_helper
INFO - 2016-11-13 02:15:01 --> Helper loaded: form_helper
INFO - 2016-11-13 02:15:01 --> Database Driver Class Initialized
INFO - 2016-11-13 02:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:15:01 --> Controller Class Initialized
INFO - 2016-11-13 02:15:01 --> Model Class Initialized
INFO - 2016-11-13 02:15:01 --> Form Validation Class Initialized
INFO - 2016-11-13 02:15:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:15:01 --> Final output sent to browser
DEBUG - 2016-11-13 02:15:01 --> Total execution time: 0.2915
INFO - 2016-11-13 02:15:21 --> Config Class Initialized
INFO - 2016-11-13 02:15:21 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:15:21 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:15:21 --> Utf8 Class Initialized
INFO - 2016-11-13 02:15:21 --> URI Class Initialized
INFO - 2016-11-13 02:15:21 --> Router Class Initialized
INFO - 2016-11-13 02:15:21 --> Output Class Initialized
INFO - 2016-11-13 02:15:21 --> Security Class Initialized
DEBUG - 2016-11-13 02:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:15:21 --> Input Class Initialized
INFO - 2016-11-13 02:15:21 --> Language Class Initialized
INFO - 2016-11-13 02:15:21 --> Loader Class Initialized
INFO - 2016-11-13 02:15:21 --> Helper loaded: url_helper
INFO - 2016-11-13 02:15:21 --> Helper loaded: form_helper
INFO - 2016-11-13 02:15:21 --> Database Driver Class Initialized
INFO - 2016-11-13 02:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:15:21 --> Controller Class Initialized
INFO - 2016-11-13 02:15:21 --> Model Class Initialized
INFO - 2016-11-13 02:15:21 --> Form Validation Class Initialized
INFO - 2016-11-13 02:15:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:15:21 --> Final output sent to browser
DEBUG - 2016-11-13 02:15:21 --> Total execution time: 0.3081
INFO - 2016-11-13 02:15:31 --> Config Class Initialized
INFO - 2016-11-13 02:15:31 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:15:31 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:15:31 --> Utf8 Class Initialized
INFO - 2016-11-13 02:15:31 --> URI Class Initialized
INFO - 2016-11-13 02:15:31 --> Router Class Initialized
INFO - 2016-11-13 02:15:31 --> Output Class Initialized
INFO - 2016-11-13 02:15:31 --> Security Class Initialized
DEBUG - 2016-11-13 02:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:15:31 --> Input Class Initialized
INFO - 2016-11-13 02:15:31 --> Language Class Initialized
INFO - 2016-11-13 02:15:31 --> Loader Class Initialized
INFO - 2016-11-13 02:15:31 --> Helper loaded: url_helper
INFO - 2016-11-13 02:15:31 --> Helper loaded: form_helper
INFO - 2016-11-13 02:15:31 --> Database Driver Class Initialized
INFO - 2016-11-13 02:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:15:31 --> Controller Class Initialized
INFO - 2016-11-13 02:15:31 --> Model Class Initialized
INFO - 2016-11-13 02:15:31 --> Form Validation Class Initialized
INFO - 2016-11-13 02:15:31 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:15:31 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:15:31 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-05', '2016-11-16', '2', '3', '2016-11-13 02:15:31', '1', '')
INFO - 2016-11-13 02:15:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:15:33 --> Config Class Initialized
INFO - 2016-11-13 02:15:33 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:15:33 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:15:33 --> Utf8 Class Initialized
INFO - 2016-11-13 02:15:33 --> URI Class Initialized
INFO - 2016-11-13 02:15:33 --> Router Class Initialized
INFO - 2016-11-13 02:15:33 --> Output Class Initialized
INFO - 2016-11-13 02:15:33 --> Security Class Initialized
DEBUG - 2016-11-13 02:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:15:33 --> Input Class Initialized
INFO - 2016-11-13 02:15:33 --> Language Class Initialized
INFO - 2016-11-13 02:15:33 --> Loader Class Initialized
INFO - 2016-11-13 02:15:34 --> Helper loaded: url_helper
INFO - 2016-11-13 02:15:34 --> Helper loaded: form_helper
INFO - 2016-11-13 02:15:34 --> Database Driver Class Initialized
INFO - 2016-11-13 02:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:15:34 --> Controller Class Initialized
INFO - 2016-11-13 02:15:34 --> Model Class Initialized
INFO - 2016-11-13 02:15:34 --> Form Validation Class Initialized
INFO - 2016-11-13 02:15:34 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:15:34 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:15:34 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-05', '2016-11-16', '2', '3', '2016-11-13 02:15:34', '1', '')
INFO - 2016-11-13 02:15:34 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:15:42 --> Config Class Initialized
INFO - 2016-11-13 02:15:42 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:15:42 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:15:42 --> Utf8 Class Initialized
INFO - 2016-11-13 02:15:42 --> URI Class Initialized
INFO - 2016-11-13 02:15:42 --> Router Class Initialized
INFO - 2016-11-13 02:15:42 --> Output Class Initialized
INFO - 2016-11-13 02:15:42 --> Security Class Initialized
DEBUG - 2016-11-13 02:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:15:42 --> Input Class Initialized
INFO - 2016-11-13 02:15:42 --> Language Class Initialized
INFO - 2016-11-13 02:15:42 --> Loader Class Initialized
INFO - 2016-11-13 02:15:42 --> Helper loaded: url_helper
INFO - 2016-11-13 02:15:42 --> Helper loaded: form_helper
INFO - 2016-11-13 02:15:42 --> Database Driver Class Initialized
INFO - 2016-11-13 02:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:15:42 --> Controller Class Initialized
INFO - 2016-11-13 02:15:42 --> Model Class Initialized
INFO - 2016-11-13 02:15:42 --> Form Validation Class Initialized
INFO - 2016-11-13 02:15:42 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:15:42 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:15:43 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-05', '2016-11-17', '2', '3', '2016-11-13 02:15:42', '1', '')
INFO - 2016-11-13 02:15:43 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:15:43 --> Config Class Initialized
INFO - 2016-11-13 02:15:43 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:15:43 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:15:44 --> Utf8 Class Initialized
INFO - 2016-11-13 02:15:44 --> URI Class Initialized
INFO - 2016-11-13 02:15:44 --> Router Class Initialized
INFO - 2016-11-13 02:15:44 --> Output Class Initialized
INFO - 2016-11-13 02:15:44 --> Security Class Initialized
DEBUG - 2016-11-13 02:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:15:44 --> Input Class Initialized
INFO - 2016-11-13 02:15:44 --> Language Class Initialized
INFO - 2016-11-13 02:15:44 --> Loader Class Initialized
INFO - 2016-11-13 02:15:44 --> Helper loaded: url_helper
INFO - 2016-11-13 02:15:44 --> Helper loaded: form_helper
INFO - 2016-11-13 02:15:44 --> Database Driver Class Initialized
INFO - 2016-11-13 02:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:15:44 --> Controller Class Initialized
INFO - 2016-11-13 02:15:44 --> Model Class Initialized
INFO - 2016-11-13 02:15:44 --> Form Validation Class Initialized
INFO - 2016-11-13 02:15:44 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:15:44 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:15:44 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-05', '2016-11-17', '2', '3', '2016-11-13 02:15:44', '1', '')
INFO - 2016-11-13 02:15:44 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:04 --> Config Class Initialized
INFO - 2016-11-13 02:16:04 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:16:04 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:04 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:04 --> URI Class Initialized
INFO - 2016-11-13 02:16:04 --> Router Class Initialized
INFO - 2016-11-13 02:16:04 --> Output Class Initialized
INFO - 2016-11-13 02:16:04 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:04 --> Input Class Initialized
INFO - 2016-11-13 02:16:04 --> Language Class Initialized
INFO - 2016-11-13 02:16:04 --> Config Class Initialized
INFO - 2016-11-13 02:16:04 --> Loader Class Initialized
INFO - 2016-11-13 02:16:04 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:04 --> Helper loaded: url_helper
DEBUG - 2016-11-13 02:16:04 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:04 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:04 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:04 --> URI Class Initialized
INFO - 2016-11-13 02:16:04 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:04 --> Router Class Initialized
INFO - 2016-11-13 02:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:04 --> Output Class Initialized
INFO - 2016-11-13 02:16:04 --> Controller Class Initialized
INFO - 2016-11-13 02:16:04 --> Model Class Initialized
INFO - 2016-11-13 02:16:04 --> Security Class Initialized
INFO - 2016-11-13 02:16:04 --> Form Validation Class Initialized
DEBUG - 2016-11-13 02:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:04 --> Input Class Initialized
INFO - 2016-11-13 02:16:04 --> Language Class Initialized
ERROR - 2016-11-13 02:16:04 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:04 --> Loader Class Initialized
INFO - 2016-11-13 02:16:04 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:04 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:04 --> Database Driver Class Initialized
ERROR - 2016-11-13 02:16:04 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:04', '1', '')
INFO - 2016-11-13 02:16:04 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:04 --> Controller Class Initialized
INFO - 2016-11-13 02:16:04 --> Model Class Initialized
INFO - 2016-11-13 02:16:04 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:04 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:16:04 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:16:04 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:04', '1', '')
INFO - 2016-11-13 02:16:04 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:04 --> Config Class Initialized
INFO - 2016-11-13 02:16:04 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:16:04 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:04 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:05 --> URI Class Initialized
INFO - 2016-11-13 02:16:05 --> Router Class Initialized
INFO - 2016-11-13 02:16:05 --> Output Class Initialized
INFO - 2016-11-13 02:16:05 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:05 --> Input Class Initialized
INFO - 2016-11-13 02:16:05 --> Language Class Initialized
INFO - 2016-11-13 02:16:05 --> Loader Class Initialized
INFO - 2016-11-13 02:16:05 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:05 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:05 --> Config Class Initialized
INFO - 2016-11-13 02:16:05 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:05 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:16:05 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:05 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:05 --> Controller Class Initialized
INFO - 2016-11-13 02:16:05 --> URI Class Initialized
INFO - 2016-11-13 02:16:05 --> Model Class Initialized
INFO - 2016-11-13 02:16:05 --> Router Class Initialized
INFO - 2016-11-13 02:16:05 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:05 --> Output Class Initialized
INFO - 2016-11-13 02:16:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:05 --> Security Class Initialized
INFO - 2016-11-13 02:16:05 --> Config Class Initialized
ERROR - 2016-11-13 02:16:05 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
DEBUG - 2016-11-13 02:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:05 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:05 --> Input Class Initialized
DEBUG - 2016-11-13 02:16:05 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:05 --> Language Class Initialized
INFO - 2016-11-13 02:16:05 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:05 --> URI Class Initialized
INFO - 2016-11-13 02:16:05 --> Loader Class Initialized
ERROR - 2016-11-13 02:16:05 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:05', '1', '')
INFO - 2016-11-13 02:16:05 --> Router Class Initialized
INFO - 2016-11-13 02:16:05 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:05 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:05 --> Output Class Initialized
INFO - 2016-11-13 02:16:05 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:05 --> Security Class Initialized
INFO - 2016-11-13 02:16:05 --> Config Class Initialized
INFO - 2016-11-13 02:16:05 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:05 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-13 02:16:05 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:05 --> Input Class Initialized
INFO - 2016-11-13 02:16:05 --> Controller Class Initialized
INFO - 2016-11-13 02:16:05 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:05 --> Language Class Initialized
INFO - 2016-11-13 02:16:05 --> Model Class Initialized
INFO - 2016-11-13 02:16:05 --> URI Class Initialized
INFO - 2016-11-13 02:16:05 --> Loader Class Initialized
INFO - 2016-11-13 02:16:05 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:05 --> Router Class Initialized
INFO - 2016-11-13 02:16:05 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:05 --> Output Class Initialized
INFO - 2016-11-13 02:16:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:05 --> Config Class Initialized
INFO - 2016-11-13 02:16:05 --> Helper loaded: form_helper
ERROR - 2016-11-13 02:16:05 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:05 --> Security Class Initialized
INFO - 2016-11-13 02:16:05 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:05 --> Database Driver Class Initialized
DEBUG - 2016-11-13 02:16:05 --> UTF-8 Support Enabled
DEBUG - 2016-11-13 02:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:05 --> Input Class Initialized
INFO - 2016-11-13 02:16:05 --> Utf8 Class Initialized
ERROR - 2016-11-13 02:16:05 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:05', '1', '')
INFO - 2016-11-13 02:16:05 --> URI Class Initialized
INFO - 2016-11-13 02:16:05 --> Language Class Initialized
INFO - 2016-11-13 02:16:05 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:05 --> Router Class Initialized
INFO - 2016-11-13 02:16:05 --> Loader Class Initialized
INFO - 2016-11-13 02:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:05 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:05 --> Output Class Initialized
INFO - 2016-11-13 02:16:05 --> Controller Class Initialized
INFO - 2016-11-13 02:16:05 --> Config Class Initialized
INFO - 2016-11-13 02:16:05 --> Security Class Initialized
INFO - 2016-11-13 02:16:05 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:05 --> Model Class Initialized
INFO - 2016-11-13 02:16:05 --> Helper loaded: form_helper
DEBUG - 2016-11-13 02:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-13 02:16:05 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:05 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:05 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:05 --> Input Class Initialized
INFO - 2016-11-13 02:16:05 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:05 --> Language Class Initialized
INFO - 2016-11-13 02:16:05 --> URI Class Initialized
INFO - 2016-11-13 02:16:05 --> Loader Class Initialized
ERROR - 2016-11-13 02:16:05 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:05 --> Router Class Initialized
INFO - 2016-11-13 02:16:05 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:05 --> Config Class Initialized
INFO - 2016-11-13 02:16:05 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:05 --> Output Class Initialized
ERROR - 2016-11-13 02:16:06 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:05', '1', '')
INFO - 2016-11-13 02:16:06 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:06 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:06 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:06 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:06 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:06 --> Utf8 Class Initialized
DEBUG - 2016-11-13 02:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:06 --> URI Class Initialized
INFO - 2016-11-13 02:16:06 --> Input Class Initialized
INFO - 2016-11-13 02:16:06 --> Controller Class Initialized
INFO - 2016-11-13 02:16:06 --> Router Class Initialized
INFO - 2016-11-13 02:16:06 --> Language Class Initialized
INFO - 2016-11-13 02:16:06 --> Model Class Initialized
INFO - 2016-11-13 02:16:06 --> Output Class Initialized
INFO - 2016-11-13 02:16:06 --> Loader Class Initialized
INFO - 2016-11-13 02:16:06 --> Config Class Initialized
INFO - 2016-11-13 02:16:06 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:06 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:06 --> Security Class Initialized
INFO - 2016-11-13 02:16:06 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-13 02:16:06 --> UTF-8 Support Enabled
DEBUG - 2016-11-13 02:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:06 --> Helper loaded: form_helper
ERROR - 2016-11-13 02:16:06 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:06 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:06 --> Input Class Initialized
INFO - 2016-11-13 02:16:06 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:06 --> URI Class Initialized
INFO - 2016-11-13 02:16:06 --> Language Class Initialized
INFO - 2016-11-13 02:16:06 --> Router Class Initialized
ERROR - 2016-11-13 02:16:06 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:06', '1', '')
INFO - 2016-11-13 02:16:06 --> Loader Class Initialized
INFO - 2016-11-13 02:16:06 --> Config Class Initialized
INFO - 2016-11-13 02:16:06 --> Output Class Initialized
INFO - 2016-11-13 02:16:06 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:06 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:06 --> Helper loaded: url_helper
DEBUG - 2016-11-13 02:16:06 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:06 --> Security Class Initialized
INFO - 2016-11-13 02:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:06 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:06 --> Utf8 Class Initialized
DEBUG - 2016-11-13 02:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:06 --> Controller Class Initialized
INFO - 2016-11-13 02:16:06 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:06 --> Input Class Initialized
INFO - 2016-11-13 02:16:06 --> URI Class Initialized
INFO - 2016-11-13 02:16:06 --> Model Class Initialized
INFO - 2016-11-13 02:16:06 --> Language Class Initialized
INFO - 2016-11-13 02:16:06 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:06 --> Router Class Initialized
INFO - 2016-11-13 02:16:06 --> Config Class Initialized
INFO - 2016-11-13 02:16:06 --> Loader Class Initialized
INFO - 2016-11-13 02:16:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:06 --> Output Class Initialized
INFO - 2016-11-13 02:16:06 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:06 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:06 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:06 --> UTF-8 Support Enabled
ERROR - 2016-11-13 02:16:06 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:06 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:06 --> Utf8 Class Initialized
DEBUG - 2016-11-13 02:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:06 --> URI Class Initialized
INFO - 2016-11-13 02:16:06 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:06 --> Input Class Initialized
ERROR - 2016-11-13 02:16:06 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:06', '1', '')
INFO - 2016-11-13 02:16:06 --> Language Class Initialized
INFO - 2016-11-13 02:16:06 --> Router Class Initialized
INFO - 2016-11-13 02:16:06 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:06 --> Output Class Initialized
INFO - 2016-11-13 02:16:06 --> Loader Class Initialized
INFO - 2016-11-13 02:16:06 --> Config Class Initialized
INFO - 2016-11-13 02:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:06 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:06 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:06 --> Controller Class Initialized
INFO - 2016-11-13 02:16:06 --> Security Class Initialized
INFO - 2016-11-13 02:16:06 --> Model Class Initialized
INFO - 2016-11-13 02:16:06 --> Helper loaded: form_helper
DEBUG - 2016-11-13 02:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-13 02:16:06 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:06 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:06 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:06 --> Input Class Initialized
INFO - 2016-11-13 02:16:06 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:06 --> URI Class Initialized
INFO - 2016-11-13 02:16:06 --> Language Class Initialized
INFO - 2016-11-13 02:16:06 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:16:06 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:06 --> Loader Class Initialized
INFO - 2016-11-13 02:16:06 --> Router Class Initialized
INFO - 2016-11-13 02:16:06 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:06 --> Output Class Initialized
ERROR - 2016-11-13 02:16:06 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:06', '1', '')
INFO - 2016-11-13 02:16:06 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:06 --> Security Class Initialized
INFO - 2016-11-13 02:16:06 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:06 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-11-13 02:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:06 --> Config Class Initialized
INFO - 2016-11-13 02:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:06 --> Input Class Initialized
INFO - 2016-11-13 02:16:06 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:06 --> Controller Class Initialized
INFO - 2016-11-13 02:16:06 --> Language Class Initialized
INFO - 2016-11-13 02:16:06 --> Model Class Initialized
DEBUG - 2016-11-13 02:16:06 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:06 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:06 --> Loader Class Initialized
INFO - 2016-11-13 02:16:06 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:06 --> URI Class Initialized
INFO - 2016-11-13 02:16:06 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:06 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:06 --> Router Class Initialized
ERROR - 2016-11-13 02:16:06 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:06 --> Output Class Initialized
INFO - 2016-11-13 02:16:06 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:06 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:07 --> Input Class Initialized
ERROR - 2016-11-13 02:16:07 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:06', '1', '')
INFO - 2016-11-13 02:16:07 --> Language Class Initialized
INFO - 2016-11-13 02:16:07 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:07 --> Loader Class Initialized
INFO - 2016-11-13 02:16:07 --> Config Class Initialized
INFO - 2016-11-13 02:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:07 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:07 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:07 --> Controller Class Initialized
INFO - 2016-11-13 02:16:07 --> Model Class Initialized
INFO - 2016-11-13 02:16:07 --> Helper loaded: form_helper
DEBUG - 2016-11-13 02:16:07 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:07 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:07 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:07 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:07 --> URI Class Initialized
INFO - 2016-11-13 02:16:07 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:16:07 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:07 --> Router Class Initialized
INFO - 2016-11-13 02:16:07 --> Output Class Initialized
INFO - 2016-11-13 02:16:07 --> Security Class Initialized
ERROR - 2016-11-13 02:16:07 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:07', '1', '')
DEBUG - 2016-11-13 02:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:07 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:07 --> Input Class Initialized
INFO - 2016-11-13 02:16:07 --> Language Class Initialized
INFO - 2016-11-13 02:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:07 --> Config Class Initialized
INFO - 2016-11-13 02:16:07 --> Loader Class Initialized
INFO - 2016-11-13 02:16:07 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:07 --> Controller Class Initialized
INFO - 2016-11-13 02:16:07 --> Model Class Initialized
INFO - 2016-11-13 02:16:07 --> Helper loaded: url_helper
DEBUG - 2016-11-13 02:16:07 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:07 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:07 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:07 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:07 --> URI Class Initialized
INFO - 2016-11-13 02:16:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:07 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:07 --> Router Class Initialized
ERROR - 2016-11-13 02:16:07 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:07 --> Output Class Initialized
INFO - 2016-11-13 02:16:07 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:07 --> Input Class Initialized
INFO - 2016-11-13 02:16:07 --> Language Class Initialized
ERROR - 2016-11-13 02:16:07 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:07', '1', '')
INFO - 2016-11-13 02:16:07 --> Loader Class Initialized
INFO - 2016-11-13 02:16:07 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:07 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:07 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:07 --> Config Class Initialized
INFO - 2016-11-13 02:16:07 --> Controller Class Initialized
INFO - 2016-11-13 02:16:07 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:07 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:07 --> Model Class Initialized
DEBUG - 2016-11-13 02:16:07 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:07 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:07 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:07 --> URI Class Initialized
ERROR - 2016-11-13 02:16:07 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:07 --> Router Class Initialized
INFO - 2016-11-13 02:16:07 --> Output Class Initialized
INFO - 2016-11-13 02:16:07 --> Security Class Initialized
ERROR - 2016-11-13 02:16:07 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:07', '1', '')
DEBUG - 2016-11-13 02:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:07 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:07 --> Input Class Initialized
INFO - 2016-11-13 02:16:07 --> Language Class Initialized
INFO - 2016-11-13 02:16:07 --> Config Class Initialized
INFO - 2016-11-13 02:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:07 --> Loader Class Initialized
INFO - 2016-11-13 02:16:07 --> Controller Class Initialized
INFO - 2016-11-13 02:16:07 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:07 --> Model Class Initialized
DEBUG - 2016-11-13 02:16:07 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:07 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:07 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:07 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:07 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:07 --> URI Class Initialized
INFO - 2016-11-13 02:16:07 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:07 --> Router Class Initialized
ERROR - 2016-11-13 02:16:07 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:07 --> Output Class Initialized
INFO - 2016-11-13 02:16:08 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-11-13 02:16:08 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:07', '1', '')
INFO - 2016-11-13 02:16:08 --> Input Class Initialized
INFO - 2016-11-13 02:16:08 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:08 --> Language Class Initialized
INFO - 2016-11-13 02:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:08 --> Config Class Initialized
INFO - 2016-11-13 02:16:08 --> Loader Class Initialized
INFO - 2016-11-13 02:16:08 --> Controller Class Initialized
INFO - 2016-11-13 02:16:08 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:08 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:08 --> Model Class Initialized
DEBUG - 2016-11-13 02:16:08 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:08 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:08 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:08 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:08 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:08 --> URI Class Initialized
ERROR - 2016-11-13 02:16:08 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:08 --> Router Class Initialized
INFO - 2016-11-13 02:16:08 --> Output Class Initialized
INFO - 2016-11-13 02:16:08 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-11-13 02:16:08 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:08', '1', '')
INFO - 2016-11-13 02:16:08 --> Input Class Initialized
INFO - 2016-11-13 02:16:08 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:08 --> Language Class Initialized
INFO - 2016-11-13 02:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:08 --> Config Class Initialized
INFO - 2016-11-13 02:16:08 --> Loader Class Initialized
INFO - 2016-11-13 02:16:08 --> Controller Class Initialized
INFO - 2016-11-13 02:16:08 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:08 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:08 --> Model Class Initialized
DEBUG - 2016-11-13 02:16:08 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:08 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:08 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:08 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:08 --> URI Class Initialized
INFO - 2016-11-13 02:16:08 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:08 --> Router Class Initialized
ERROR - 2016-11-13 02:16:08 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:08 --> Output Class Initialized
INFO - 2016-11-13 02:16:08 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-11-13 02:16:08 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:08', '1', '')
INFO - 2016-11-13 02:16:08 --> Input Class Initialized
INFO - 2016-11-13 02:16:08 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:08 --> Language Class Initialized
INFO - 2016-11-13 02:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:08 --> Config Class Initialized
INFO - 2016-11-13 02:16:08 --> Loader Class Initialized
INFO - 2016-11-13 02:16:08 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:08 --> Controller Class Initialized
INFO - 2016-11-13 02:16:08 --> Model Class Initialized
DEBUG - 2016-11-13 02:16:08 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:08 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:08 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:08 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:08 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:08 --> URI Class Initialized
INFO - 2016-11-13 02:16:08 --> Database Driver Class Initialized
ERROR - 2016-11-13 02:16:08 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:08 --> Router Class Initialized
INFO - 2016-11-13 02:16:08 --> Output Class Initialized
INFO - 2016-11-13 02:16:08 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:08 --> Input Class Initialized
ERROR - 2016-11-13 02:16:08 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:08', '1', '')
INFO - 2016-11-13 02:16:08 --> Language Class Initialized
INFO - 2016-11-13 02:16:08 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:08 --> Loader Class Initialized
INFO - 2016-11-13 02:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:08 --> Config Class Initialized
INFO - 2016-11-13 02:16:08 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:08 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:08 --> Controller Class Initialized
INFO - 2016-11-13 02:16:08 --> Model Class Initialized
DEBUG - 2016-11-13 02:16:08 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:08 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:08 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:08 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:08 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:08 --> URI Class Initialized
INFO - 2016-11-13 02:16:08 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:16:08 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:08 --> Router Class Initialized
INFO - 2016-11-13 02:16:08 --> Output Class Initialized
INFO - 2016-11-13 02:16:08 --> Security Class Initialized
ERROR - 2016-11-13 02:16:08 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:08', '1', '')
DEBUG - 2016-11-13 02:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:09 --> Input Class Initialized
INFO - 2016-11-13 02:16:09 --> Language Class Initialized
INFO - 2016-11-13 02:16:09 --> Config Class Initialized
INFO - 2016-11-13 02:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:09 --> Loader Class Initialized
INFO - 2016-11-13 02:16:09 --> Controller Class Initialized
INFO - 2016-11-13 02:16:09 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:09 --> Model Class Initialized
DEBUG - 2016-11-13 02:16:09 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:09 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:09 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:09 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:09 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:09 --> URI Class Initialized
INFO - 2016-11-13 02:16:09 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:09 --> Router Class Initialized
ERROR - 2016-11-13 02:16:09 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:09 --> Output Class Initialized
INFO - 2016-11-13 02:16:09 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:09 --> Input Class Initialized
ERROR - 2016-11-13 02:16:09 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:09', '1', '')
INFO - 2016-11-13 02:16:09 --> Language Class Initialized
INFO - 2016-11-13 02:16:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:09 --> Loader Class Initialized
INFO - 2016-11-13 02:16:09 --> Config Class Initialized
INFO - 2016-11-13 02:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:09 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:09 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:09 --> Controller Class Initialized
INFO - 2016-11-13 02:16:09 --> Model Class Initialized
DEBUG - 2016-11-13 02:16:09 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:09 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:09 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:09 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:09 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:09 --> URI Class Initialized
ERROR - 2016-11-13 02:16:09 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:09 --> Router Class Initialized
INFO - 2016-11-13 02:16:09 --> Output Class Initialized
INFO - 2016-11-13 02:16:09 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:09 --> Input Class Initialized
ERROR - 2016-11-13 02:16:09 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:09', '1', '')
INFO - 2016-11-13 02:16:09 --> Language Class Initialized
INFO - 2016-11-13 02:16:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:09 --> Loader Class Initialized
INFO - 2016-11-13 02:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:09 --> Config Class Initialized
INFO - 2016-11-13 02:16:09 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:09 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:09 --> Controller Class Initialized
INFO - 2016-11-13 02:16:09 --> Model Class Initialized
DEBUG - 2016-11-13 02:16:09 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:09 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:09 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:09 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:09 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:09 --> URI Class Initialized
INFO - 2016-11-13 02:16:09 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:16:09 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:09 --> Router Class Initialized
INFO - 2016-11-13 02:16:09 --> Output Class Initialized
INFO - 2016-11-13 02:16:09 --> Security Class Initialized
ERROR - 2016-11-13 02:16:09 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:09', '1', '')
DEBUG - 2016-11-13 02:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:09 --> Input Class Initialized
INFO - 2016-11-13 02:16:09 --> Language Class Initialized
INFO - 2016-11-13 02:16:09 --> Config Class Initialized
INFO - 2016-11-13 02:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:09 --> Loader Class Initialized
INFO - 2016-11-13 02:16:09 --> Controller Class Initialized
INFO - 2016-11-13 02:16:09 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:09 --> Model Class Initialized
DEBUG - 2016-11-13 02:16:09 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:09 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:09 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:09 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:09 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:09 --> URI Class Initialized
INFO - 2016-11-13 02:16:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:09 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:09 --> Router Class Initialized
ERROR - 2016-11-13 02:16:09 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:09 --> Output Class Initialized
INFO - 2016-11-13 02:16:09 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-11-13 02:16:09 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:09', '1', '')
INFO - 2016-11-13 02:16:09 --> Input Class Initialized
INFO - 2016-11-13 02:16:10 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:10 --> Language Class Initialized
INFO - 2016-11-13 02:16:10 --> Config Class Initialized
INFO - 2016-11-13 02:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:10 --> Loader Class Initialized
INFO - 2016-11-13 02:16:10 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:10 --> Controller Class Initialized
INFO - 2016-11-13 02:16:10 --> Model Class Initialized
DEBUG - 2016-11-13 02:16:10 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:10 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:10 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:10 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:10 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:10 --> URI Class Initialized
INFO - 2016-11-13 02:16:10 --> Database Driver Class Initialized
ERROR - 2016-11-13 02:16:10 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:10 --> Router Class Initialized
INFO - 2016-11-13 02:16:10 --> Output Class Initialized
INFO - 2016-11-13 02:16:10 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:10 --> Input Class Initialized
INFO - 2016-11-13 02:16:10 --> Language Class Initialized
INFO - 2016-11-13 02:16:10 --> Loader Class Initialized
INFO - 2016-11-13 02:16:10 --> Helper loaded: url_helper
ERROR - 2016-11-13 02:16:10 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:10', '1', '')
INFO - 2016-11-13 02:16:10 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:10 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:10 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:10 --> Config Class Initialized
INFO - 2016-11-13 02:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:10 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:10 --> Controller Class Initialized
INFO - 2016-11-13 02:16:10 --> Model Class Initialized
DEBUG - 2016-11-13 02:16:10 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:10 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:10 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:10 --> URI Class Initialized
ERROR - 2016-11-13 02:16:10 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:10 --> Router Class Initialized
INFO - 2016-11-13 02:16:10 --> Output Class Initialized
INFO - 2016-11-13 02:16:10 --> Security Class Initialized
ERROR - 2016-11-13 02:16:10 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:10', '1', '')
DEBUG - 2016-11-13 02:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:10 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:10 --> Input Class Initialized
INFO - 2016-11-13 02:16:10 --> Language Class Initialized
INFO - 2016-11-13 02:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:10 --> Config Class Initialized
INFO - 2016-11-13 02:16:10 --> Loader Class Initialized
INFO - 2016-11-13 02:16:10 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:10 --> Controller Class Initialized
INFO - 2016-11-13 02:16:10 --> Model Class Initialized
DEBUG - 2016-11-13 02:16:10 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:10 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:10 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:10 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:10 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:10 --> URI Class Initialized
INFO - 2016-11-13 02:16:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:10 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:10 --> Router Class Initialized
ERROR - 2016-11-13 02:16:10 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:10 --> Output Class Initialized
INFO - 2016-11-13 02:16:10 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:10 --> Input Class Initialized
ERROR - 2016-11-13 02:16:10 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:10', '1', '')
INFO - 2016-11-13 02:16:10 --> Language Class Initialized
INFO - 2016-11-13 02:16:10 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:10 --> Loader Class Initialized
INFO - 2016-11-13 02:16:10 --> Config Class Initialized
INFO - 2016-11-13 02:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:10 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:10 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:10 --> Controller Class Initialized
INFO - 2016-11-13 02:16:10 --> Model Class Initialized
DEBUG - 2016-11-13 02:16:10 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:10 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:10 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:10 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:10 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:10 --> URI Class Initialized
INFO - 2016-11-13 02:16:10 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:16:10 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:10 --> Router Class Initialized
INFO - 2016-11-13 02:16:10 --> Output Class Initialized
INFO - 2016-11-13 02:16:11 --> Security Class Initialized
ERROR - 2016-11-13 02:16:11 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:10', '1', '')
DEBUG - 2016-11-13 02:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:11 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:11 --> Input Class Initialized
INFO - 2016-11-13 02:16:11 --> Language Class Initialized
INFO - 2016-11-13 02:16:11 --> Config Class Initialized
INFO - 2016-11-13 02:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:11 --> Controller Class Initialized
INFO - 2016-11-13 02:16:11 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:11 --> Loader Class Initialized
INFO - 2016-11-13 02:16:11 --> Model Class Initialized
DEBUG - 2016-11-13 02:16:11 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:11 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:11 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:11 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:11 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:11 --> URI Class Initialized
INFO - 2016-11-13 02:16:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:11 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:11 --> Router Class Initialized
ERROR - 2016-11-13 02:16:11 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:11 --> Output Class Initialized
INFO - 2016-11-13 02:16:11 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:11 --> Input Class Initialized
ERROR - 2016-11-13 02:16:11 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:11', '1', '')
INFO - 2016-11-13 02:16:11 --> Language Class Initialized
INFO - 2016-11-13 02:16:11 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:11 --> Loader Class Initialized
INFO - 2016-11-13 02:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:11 --> Config Class Initialized
INFO - 2016-11-13 02:16:11 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:11 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:11 --> Controller Class Initialized
DEBUG - 2016-11-13 02:16:11 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:11 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:11 --> Model Class Initialized
INFO - 2016-11-13 02:16:11 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:11 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:11 --> URI Class Initialized
INFO - 2016-11-13 02:16:11 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:11 --> Router Class Initialized
ERROR - 2016-11-13 02:16:11 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:11 --> Output Class Initialized
INFO - 2016-11-13 02:16:11 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-11-13 02:16:11 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:11', '1', '')
INFO - 2016-11-13 02:16:11 --> Input Class Initialized
INFO - 2016-11-13 02:16:11 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:11 --> Language Class Initialized
INFO - 2016-11-13 02:16:11 --> Config Class Initialized
INFO - 2016-11-13 02:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:11 --> Loader Class Initialized
INFO - 2016-11-13 02:16:11 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:11 --> Controller Class Initialized
INFO - 2016-11-13 02:16:11 --> Model Class Initialized
INFO - 2016-11-13 02:16:11 --> Helper loaded: url_helper
DEBUG - 2016-11-13 02:16:11 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:11 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:11 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:11 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:11 --> URI Class Initialized
INFO - 2016-11-13 02:16:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:11 --> Database Driver Class Initialized
ERROR - 2016-11-13 02:16:11 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:11 --> Router Class Initialized
INFO - 2016-11-13 02:16:11 --> Output Class Initialized
INFO - 2016-11-13 02:16:11 --> Security Class Initialized
ERROR - 2016-11-13 02:16:11 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:11', '1', '')
DEBUG - 2016-11-13 02:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:11 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:11 --> Input Class Initialized
INFO - 2016-11-13 02:16:11 --> Language Class Initialized
INFO - 2016-11-13 02:16:11 --> Config Class Initialized
INFO - 2016-11-13 02:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:11 --> Loader Class Initialized
INFO - 2016-11-13 02:16:11 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:11 --> Controller Class Initialized
INFO - 2016-11-13 02:16:11 --> Model Class Initialized
DEBUG - 2016-11-13 02:16:11 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:11 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:11 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:11 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:11 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:11 --> URI Class Initialized
INFO - 2016-11-13 02:16:11 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:11 --> Router Class Initialized
ERROR - 2016-11-13 02:16:11 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:11 --> Output Class Initialized
INFO - 2016-11-13 02:16:11 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-11-13 02:16:12 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:11', '1', '')
INFO - 2016-11-13 02:16:12 --> Input Class Initialized
INFO - 2016-11-13 02:16:12 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:12 --> Language Class Initialized
INFO - 2016-11-13 02:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:12 --> Loader Class Initialized
INFO - 2016-11-13 02:16:12 --> Config Class Initialized
INFO - 2016-11-13 02:16:12 --> Controller Class Initialized
INFO - 2016-11-13 02:16:12 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:12 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:12 --> Model Class Initialized
DEBUG - 2016-11-13 02:16:12 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:12 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:12 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:12 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:12 --> URI Class Initialized
INFO - 2016-11-13 02:16:12 --> Database Driver Class Initialized
ERROR - 2016-11-13 02:16:12 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:12 --> Router Class Initialized
INFO - 2016-11-13 02:16:12 --> Output Class Initialized
INFO - 2016-11-13 02:16:12 --> Security Class Initialized
ERROR - 2016-11-13 02:16:12 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:12', '1', '')
DEBUG - 2016-11-13 02:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:12 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:12 --> Input Class Initialized
INFO - 2016-11-13 02:16:12 --> Language Class Initialized
INFO - 2016-11-13 02:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:12 --> Loader Class Initialized
INFO - 2016-11-13 02:16:12 --> Controller Class Initialized
INFO - 2016-11-13 02:16:12 --> Model Class Initialized
INFO - 2016-11-13 02:16:12 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:12 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:12 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:12 --> Database Driver Class Initialized
ERROR - 2016-11-13 02:16:12 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:16:12 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:12', '1', '')
INFO - 2016-11-13 02:16:12 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:12 --> Controller Class Initialized
INFO - 2016-11-13 02:16:12 --> Model Class Initialized
INFO - 2016-11-13 02:16:12 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:12 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:16:12 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:16:12 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:12', '1', '')
INFO - 2016-11-13 02:16:12 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:12 --> Controller Class Initialized
INFO - 2016-11-13 02:16:12 --> Model Class Initialized
INFO - 2016-11-13 02:16:12 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:12 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:16:12 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:16:12 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:12', '1', '')
INFO - 2016-11-13 02:16:12 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:12 --> Controller Class Initialized
INFO - 2016-11-13 02:16:12 --> Model Class Initialized
INFO - 2016-11-13 02:16:12 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:12 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:16:12 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:16:13 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:12', '1', '')
INFO - 2016-11-13 02:16:13 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:13 --> Controller Class Initialized
INFO - 2016-11-13 02:16:13 --> Model Class Initialized
INFO - 2016-11-13 02:16:13 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:13 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:16:13 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:16:13 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-17', '2', '3', '2016-11-13 02:16:13', '1', '')
INFO - 2016-11-13 02:16:13 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:18 --> Config Class Initialized
INFO - 2016-11-13 02:16:18 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:16:18 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:18 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:18 --> URI Class Initialized
INFO - 2016-11-13 02:16:18 --> Router Class Initialized
INFO - 2016-11-13 02:16:18 --> Output Class Initialized
INFO - 2016-11-13 02:16:18 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:18 --> Input Class Initialized
INFO - 2016-11-13 02:16:18 --> Language Class Initialized
INFO - 2016-11-13 02:16:18 --> Loader Class Initialized
INFO - 2016-11-13 02:16:18 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:18 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:18 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:18 --> Controller Class Initialized
INFO - 2016-11-13 02:16:18 --> Model Class Initialized
INFO - 2016-11-13 02:16:18 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:18 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:16:18 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:16:18 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-24', '2', '3', '2016-11-13 02:16:18', '1', '')
INFO - 2016-11-13 02:16:18 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:18 --> Config Class Initialized
INFO - 2016-11-13 02:16:18 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:16:18 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:18 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:18 --> URI Class Initialized
INFO - 2016-11-13 02:16:19 --> Router Class Initialized
INFO - 2016-11-13 02:16:19 --> Output Class Initialized
INFO - 2016-11-13 02:16:19 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:19 --> Input Class Initialized
INFO - 2016-11-13 02:16:19 --> Language Class Initialized
INFO - 2016-11-13 02:16:19 --> Loader Class Initialized
INFO - 2016-11-13 02:16:19 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:19 --> Config Class Initialized
INFO - 2016-11-13 02:16:19 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:19 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:16:19 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:19 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:19 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:19 --> URI Class Initialized
INFO - 2016-11-13 02:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:19 --> Router Class Initialized
INFO - 2016-11-13 02:16:19 --> Controller Class Initialized
INFO - 2016-11-13 02:16:19 --> Model Class Initialized
INFO - 2016-11-13 02:16:19 --> Output Class Initialized
INFO - 2016-11-13 02:16:19 --> Config Class Initialized
INFO - 2016-11-13 02:16:19 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:19 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:19 --> Security Class Initialized
INFO - 2016-11-13 02:16:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-13 02:16:19 --> UTF-8 Support Enabled
DEBUG - 2016-11-13 02:16:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-11-13 02:16:19 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:19 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:19 --> Input Class Initialized
INFO - 2016-11-13 02:16:19 --> Language Class Initialized
INFO - 2016-11-13 02:16:19 --> URI Class Initialized
INFO - 2016-11-13 02:16:19 --> Loader Class Initialized
INFO - 2016-11-13 02:16:19 --> Router Class Initialized
INFO - 2016-11-13 02:16:19 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:19 --> Output Class Initialized
INFO - 2016-11-13 02:16:19 --> Config Class Initialized
INFO - 2016-11-13 02:16:19 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:19 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:19 --> Security Class Initialized
ERROR - 2016-11-13 02:16:19 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-24', '2', '3', '2016-11-13 02:16:19', '1', '')
DEBUG - 2016-11-13 02:16:19 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:19 --> Database Driver Class Initialized
DEBUG - 2016-11-13 02:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:19 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:19 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:19 --> Input Class Initialized
INFO - 2016-11-13 02:16:19 --> URI Class Initialized
INFO - 2016-11-13 02:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:19 --> Language Class Initialized
INFO - 2016-11-13 02:16:19 --> Controller Class Initialized
INFO - 2016-11-13 02:16:19 --> Router Class Initialized
INFO - 2016-11-13 02:16:19 --> Loader Class Initialized
INFO - 2016-11-13 02:16:19 --> Model Class Initialized
INFO - 2016-11-13 02:16:19 --> Output Class Initialized
INFO - 2016-11-13 02:16:19 --> Config Class Initialized
INFO - 2016-11-13 02:16:19 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:19 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:19 --> Security Class Initialized
INFO - 2016-11-13 02:16:19 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:19 --> Helper loaded: form_helper
DEBUG - 2016-11-13 02:16:19 --> UTF-8 Support Enabled
DEBUG - 2016-11-13 02:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:19 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:19 --> Input Class Initialized
ERROR - 2016-11-13 02:16:19 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:19 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:19 --> Language Class Initialized
INFO - 2016-11-13 02:16:19 --> URI Class Initialized
INFO - 2016-11-13 02:16:19 --> Loader Class Initialized
ERROR - 2016-11-13 02:16:19 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-24', '2', '3', '2016-11-13 02:16:19', '1', '')
INFO - 2016-11-13 02:16:19 --> Router Class Initialized
INFO - 2016-11-13 02:16:19 --> Config Class Initialized
INFO - 2016-11-13 02:16:19 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:19 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:19 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:19 --> Output Class Initialized
INFO - 2016-11-13 02:16:19 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:19 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:19 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:19 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:19 --> Controller Class Initialized
INFO - 2016-11-13 02:16:19 --> Database Driver Class Initialized
DEBUG - 2016-11-13 02:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:19 --> Model Class Initialized
INFO - 2016-11-13 02:16:19 --> URI Class Initialized
INFO - 2016-11-13 02:16:19 --> Input Class Initialized
INFO - 2016-11-13 02:16:19 --> Language Class Initialized
INFO - 2016-11-13 02:16:19 --> Router Class Initialized
INFO - 2016-11-13 02:16:19 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:19 --> Loader Class Initialized
INFO - 2016-11-13 02:16:19 --> Output Class Initialized
INFO - 2016-11-13 02:16:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:19 --> Config Class Initialized
INFO - 2016-11-13 02:16:19 --> Helper loaded: url_helper
ERROR - 2016-11-13 02:16:19 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:19 --> Security Class Initialized
INFO - 2016-11-13 02:16:19 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:20 --> Helper loaded: form_helper
DEBUG - 2016-11-13 02:16:20 --> UTF-8 Support Enabled
DEBUG - 2016-11-13 02:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:20 --> Input Class Initialized
INFO - 2016-11-13 02:16:20 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:20 --> Utf8 Class Initialized
ERROR - 2016-11-13 02:16:20 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-24', '2', '3', '2016-11-13 02:16:19', '1', '')
INFO - 2016-11-13 02:16:20 --> Language Class Initialized
INFO - 2016-11-13 02:16:20 --> URI Class Initialized
INFO - 2016-11-13 02:16:20 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:20 --> Loader Class Initialized
INFO - 2016-11-13 02:16:20 --> Router Class Initialized
INFO - 2016-11-13 02:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:20 --> Config Class Initialized
INFO - 2016-11-13 02:16:20 --> Output Class Initialized
INFO - 2016-11-13 02:16:20 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:20 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:20 --> Controller Class Initialized
INFO - 2016-11-13 02:16:20 --> Model Class Initialized
INFO - 2016-11-13 02:16:20 --> Security Class Initialized
INFO - 2016-11-13 02:16:20 --> Helper loaded: form_helper
DEBUG - 2016-11-13 02:16:20 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:20 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:20 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:20 --> Database Driver Class Initialized
DEBUG - 2016-11-13 02:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:20 --> Input Class Initialized
INFO - 2016-11-13 02:16:20 --> URI Class Initialized
INFO - 2016-11-13 02:16:20 --> Language Class Initialized
ERROR - 2016-11-13 02:16:20 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:20 --> Router Class Initialized
INFO - 2016-11-13 02:16:20 --> Loader Class Initialized
INFO - 2016-11-13 02:16:20 --> Config Class Initialized
INFO - 2016-11-13 02:16:20 --> Output Class Initialized
INFO - 2016-11-13 02:16:20 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:20 --> Helper loaded: url_helper
ERROR - 2016-11-13 02:16:20 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-24', '2', '3', '2016-11-13 02:16:20', '1', '')
DEBUG - 2016-11-13 02:16:20 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:20 --> Security Class Initialized
INFO - 2016-11-13 02:16:20 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:20 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:20 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-11-13 02:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:20 --> URI Class Initialized
INFO - 2016-11-13 02:16:20 --> Input Class Initialized
INFO - 2016-11-13 02:16:20 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:20 --> Router Class Initialized
INFO - 2016-11-13 02:16:20 --> Language Class Initialized
INFO - 2016-11-13 02:16:20 --> Controller Class Initialized
INFO - 2016-11-13 02:16:20 --> Model Class Initialized
INFO - 2016-11-13 02:16:20 --> Config Class Initialized
INFO - 2016-11-13 02:16:20 --> Output Class Initialized
INFO - 2016-11-13 02:16:20 --> Loader Class Initialized
INFO - 2016-11-13 02:16:20 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:20 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:20 --> Security Class Initialized
INFO - 2016-11-13 02:16:20 --> Helper loaded: url_helper
DEBUG - 2016-11-13 02:16:20 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-13 02:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:20 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:20 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:20 --> Input Class Initialized
ERROR - 2016-11-13 02:16:20 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:20 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:20 --> URI Class Initialized
INFO - 2016-11-13 02:16:20 --> Language Class Initialized
INFO - 2016-11-13 02:16:20 --> Router Class Initialized
INFO - 2016-11-13 02:16:20 --> Loader Class Initialized
ERROR - 2016-11-13 02:16:20 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-24', '2', '3', '2016-11-13 02:16:20', '1', '')
INFO - 2016-11-13 02:16:20 --> Output Class Initialized
INFO - 2016-11-13 02:16:20 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:20 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:20 --> Security Class Initialized
INFO - 2016-11-13 02:16:20 --> Config Class Initialized
INFO - 2016-11-13 02:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:20 --> Helper loaded: form_helper
DEBUG - 2016-11-13 02:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:20 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:20 --> Controller Class Initialized
INFO - 2016-11-13 02:16:20 --> Input Class Initialized
INFO - 2016-11-13 02:16:20 --> Database Driver Class Initialized
DEBUG - 2016-11-13 02:16:20 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:20 --> Model Class Initialized
INFO - 2016-11-13 02:16:20 --> Language Class Initialized
INFO - 2016-11-13 02:16:20 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:20 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:20 --> Loader Class Initialized
INFO - 2016-11-13 02:16:20 --> URI Class Initialized
INFO - 2016-11-13 02:16:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:20 --> Router Class Initialized
INFO - 2016-11-13 02:16:20 --> Helper loaded: url_helper
ERROR - 2016-11-13 02:16:20 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:20 --> Output Class Initialized
INFO - 2016-11-13 02:16:20 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:20 --> Security Class Initialized
INFO - 2016-11-13 02:16:20 --> Database Driver Class Initialized
DEBUG - 2016-11-13 02:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:20 --> Input Class Initialized
ERROR - 2016-11-13 02:16:20 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-24', '2', '3', '2016-11-13 02:16:20', '1', '')
INFO - 2016-11-13 02:16:20 --> Language Class Initialized
INFO - 2016-11-13 02:16:20 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:20 --> Loader Class Initialized
INFO - 2016-11-13 02:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:20 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:20 --> Controller Class Initialized
INFO - 2016-11-13 02:16:21 --> Model Class Initialized
INFO - 2016-11-13 02:16:21 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:21 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:21 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:21 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:16:21 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:16:21 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-24', '2', '3', '2016-11-13 02:16:21', '1', '')
INFO - 2016-11-13 02:16:21 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:21 --> Controller Class Initialized
INFO - 2016-11-13 02:16:21 --> Model Class Initialized
INFO - 2016-11-13 02:16:21 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:21 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:16:21 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:16:21 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-24', '2', '3', '2016-11-13 02:16:21', '1', '')
INFO - 2016-11-13 02:16:21 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:21 --> Controller Class Initialized
INFO - 2016-11-13 02:16:21 --> Model Class Initialized
INFO - 2016-11-13 02:16:21 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:21 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:16:21 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:16:21 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-24', '2', '3', '2016-11-13 02:16:21', '1', '')
INFO - 2016-11-13 02:16:21 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:21 --> Controller Class Initialized
INFO - 2016-11-13 02:16:21 --> Model Class Initialized
INFO - 2016-11-13 02:16:21 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:21 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:16:21 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:16:21 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-24', '2', '3', '2016-11-13 02:16:21', '1', '')
INFO - 2016-11-13 02:16:21 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:21 --> Controller Class Initialized
INFO - 2016-11-13 02:16:21 --> Model Class Initialized
INFO - 2016-11-13 02:16:21 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:21 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:16:21 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:16:21 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-24', '2', '3', '2016-11-13 02:16:21', '1', '')
INFO - 2016-11-13 02:16:21 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:22 --> Config Class Initialized
INFO - 2016-11-13 02:16:22 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:16:22 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:22 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:22 --> URI Class Initialized
INFO - 2016-11-13 02:16:22 --> Router Class Initialized
INFO - 2016-11-13 02:16:22 --> Output Class Initialized
INFO - 2016-11-13 02:16:22 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:22 --> Config Class Initialized
INFO - 2016-11-13 02:16:22 --> Input Class Initialized
INFO - 2016-11-13 02:16:23 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:23 --> Language Class Initialized
DEBUG - 2016-11-13 02:16:23 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:23 --> Loader Class Initialized
INFO - 2016-11-13 02:16:23 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:23 --> URI Class Initialized
INFO - 2016-11-13 02:16:23 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:23 --> Router Class Initialized
INFO - 2016-11-13 02:16:23 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:23 --> Output Class Initialized
INFO - 2016-11-13 02:16:23 --> Config Class Initialized
INFO - 2016-11-13 02:16:23 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:23 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:23 --> Security Class Initialized
INFO - 2016-11-13 02:16:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-13 02:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-13 02:16:23 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:23 --> Controller Class Initialized
INFO - 2016-11-13 02:16:23 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:23 --> Input Class Initialized
INFO - 2016-11-13 02:16:23 --> Model Class Initialized
INFO - 2016-11-13 02:16:23 --> URI Class Initialized
INFO - 2016-11-13 02:16:23 --> Language Class Initialized
INFO - 2016-11-13 02:16:23 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:23 --> Loader Class Initialized
INFO - 2016-11-13 02:16:23 --> Router Class Initialized
INFO - 2016-11-13 02:16:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:23 --> Output Class Initialized
INFO - 2016-11-13 02:16:23 --> Config Class Initialized
INFO - 2016-11-13 02:16:23 --> Helper loaded: url_helper
ERROR - 2016-11-13 02:16:23 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:23 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:23 --> Security Class Initialized
INFO - 2016-11-13 02:16:23 --> Helper loaded: form_helper
DEBUG - 2016-11-13 02:16:23 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:23 --> Database Driver Class Initialized
DEBUG - 2016-11-13 02:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:23 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:23 --> Input Class Initialized
INFO - 2016-11-13 02:16:23 --> URI Class Initialized
ERROR - 2016-11-13 02:16:23 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-24', '4', '3', '2016-11-13 02:16:23', '1', '')
INFO - 2016-11-13 02:16:23 --> Language Class Initialized
INFO - 2016-11-13 02:16:23 --> Router Class Initialized
INFO - 2016-11-13 02:16:23 --> Config Class Initialized
INFO - 2016-11-13 02:16:23 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:23 --> Loader Class Initialized
INFO - 2016-11-13 02:16:23 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:23 --> Output Class Initialized
INFO - 2016-11-13 02:16:23 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-13 02:16:23 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:23 --> Controller Class Initialized
INFO - 2016-11-13 02:16:23 --> Security Class Initialized
INFO - 2016-11-13 02:16:23 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:23 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:23 --> Model Class Initialized
DEBUG - 2016-11-13 02:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:23 --> URI Class Initialized
INFO - 2016-11-13 02:16:23 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:23 --> Input Class Initialized
INFO - 2016-11-13 02:16:23 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:23 --> Router Class Initialized
INFO - 2016-11-13 02:16:23 --> Language Class Initialized
INFO - 2016-11-13 02:16:23 --> Config Class Initialized
INFO - 2016-11-13 02:16:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:23 --> Output Class Initialized
INFO - 2016-11-13 02:16:23 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:23 --> Loader Class Initialized
ERROR - 2016-11-13 02:16:23 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:23 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:23 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:23 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:23 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:23 --> Helper loaded: form_helper
DEBUG - 2016-11-13 02:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:23 --> URI Class Initialized
INFO - 2016-11-13 02:16:23 --> Input Class Initialized
ERROR - 2016-11-13 02:16:23 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-24', '4', '3', '2016-11-13 02:16:23', '1', '')
INFO - 2016-11-13 02:16:23 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:23 --> Router Class Initialized
INFO - 2016-11-13 02:16:23 --> Language Class Initialized
INFO - 2016-11-13 02:16:23 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:23 --> Output Class Initialized
INFO - 2016-11-13 02:16:23 --> Loader Class Initialized
INFO - 2016-11-13 02:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:23 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:23 --> Security Class Initialized
INFO - 2016-11-13 02:16:23 --> Controller Class Initialized
DEBUG - 2016-11-13 02:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:23 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:23 --> Model Class Initialized
INFO - 2016-11-13 02:16:23 --> Input Class Initialized
INFO - 2016-11-13 02:16:23 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:23 --> Language Class Initialized
INFO - 2016-11-13 02:16:23 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:23 --> Loader Class Initialized
ERROR - 2016-11-13 02:16:23 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:23 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:23 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:23 --> Database Driver Class Initialized
ERROR - 2016-11-13 02:16:24 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-24', '4', '3', '2016-11-13 02:16:23', '1', '')
INFO - 2016-11-13 02:16:24 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:24 --> Controller Class Initialized
INFO - 2016-11-13 02:16:24 --> Model Class Initialized
INFO - 2016-11-13 02:16:24 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:24 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:16:24 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:16:24 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-24', '4', '3', '2016-11-13 02:16:24', '1', '')
INFO - 2016-11-13 02:16:24 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:24 --> Controller Class Initialized
INFO - 2016-11-13 02:16:24 --> Model Class Initialized
INFO - 2016-11-13 02:16:24 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:24 --> Config Class Initialized
INFO - 2016-11-13 02:16:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:24 --> Hooks Class Initialized
ERROR - 2016-11-13 02:16:24 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
DEBUG - 2016-11-13 02:16:24 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:24 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:24 --> URI Class Initialized
INFO - 2016-11-13 02:16:24 --> Router Class Initialized
ERROR - 2016-11-13 02:16:24 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-24', '4', '3', '2016-11-13 02:16:24', '1', '')
INFO - 2016-11-13 02:16:24 --> Output Class Initialized
INFO - 2016-11-13 02:16:24 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:24 --> Security Class Initialized
INFO - 2016-11-13 02:16:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-13 02:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:24 --> Controller Class Initialized
INFO - 2016-11-13 02:16:24 --> Input Class Initialized
INFO - 2016-11-13 02:16:24 --> Model Class Initialized
INFO - 2016-11-13 02:16:24 --> Language Class Initialized
INFO - 2016-11-13 02:16:24 --> Config Class Initialized
INFO - 2016-11-13 02:16:24 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:24 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:24 --> Loader Class Initialized
DEBUG - 2016-11-13 02:16:24 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:24 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:24 --> Utf8 Class Initialized
ERROR - 2016-11-13 02:16:24 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:24 --> URI Class Initialized
INFO - 2016-11-13 02:16:24 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:24 --> Router Class Initialized
ERROR - 2016-11-13 02:16:24 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-24', '4', '3', '2016-11-13 02:16:24', '1', '')
INFO - 2016-11-13 02:16:24 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:24 --> Output Class Initialized
INFO - 2016-11-13 02:16:24 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:24 --> Security Class Initialized
INFO - 2016-11-13 02:16:24 --> Config Class Initialized
INFO - 2016-11-13 02:16:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-13 02:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:24 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:24 --> Controller Class Initialized
INFO - 2016-11-13 02:16:24 --> Input Class Initialized
DEBUG - 2016-11-13 02:16:24 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:24 --> Model Class Initialized
INFO - 2016-11-13 02:16:24 --> Language Class Initialized
INFO - 2016-11-13 02:16:24 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:24 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:24 --> Loader Class Initialized
INFO - 2016-11-13 02:16:24 --> URI Class Initialized
INFO - 2016-11-13 02:16:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:24 --> Router Class Initialized
INFO - 2016-11-13 02:16:24 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:24 --> Config Class Initialized
ERROR - 2016-11-13 02:16:24 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:24 --> Hooks Class Initialized
INFO - 2016-11-13 02:16:24 --> Output Class Initialized
INFO - 2016-11-13 02:16:24 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:24 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:24 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:24 --> Database Driver Class Initialized
DEBUG - 2016-11-13 02:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:24 --> Utf8 Class Initialized
ERROR - 2016-11-13 02:16:24 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-24', '4', '3', '2016-11-13 02:16:24', '1', '')
INFO - 2016-11-13 02:16:24 --> Input Class Initialized
INFO - 2016-11-13 02:16:24 --> URI Class Initialized
INFO - 2016-11-13 02:16:24 --> Language Class Initialized
INFO - 2016-11-13 02:16:24 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:25 --> Router Class Initialized
INFO - 2016-11-13 02:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:25 --> Loader Class Initialized
INFO - 2016-11-13 02:16:25 --> Output Class Initialized
INFO - 2016-11-13 02:16:25 --> Controller Class Initialized
INFO - 2016-11-13 02:16:25 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:25 --> Model Class Initialized
INFO - 2016-11-13 02:16:25 --> Security Class Initialized
INFO - 2016-11-13 02:16:25 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:25 --> Form Validation Class Initialized
DEBUG - 2016-11-13 02:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:25 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:25 --> Input Class Initialized
INFO - 2016-11-13 02:16:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:25 --> Language Class Initialized
ERROR - 2016-11-13 02:16:25 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:16:25 --> Loader Class Initialized
INFO - 2016-11-13 02:16:25 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:25 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:25 --> Database Driver Class Initialized
ERROR - 2016-11-13 02:16:25 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-24', '4', '3', '2016-11-13 02:16:25', '1', '')
INFO - 2016-11-13 02:16:25 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:25 --> Controller Class Initialized
INFO - 2016-11-13 02:16:25 --> Model Class Initialized
INFO - 2016-11-13 02:16:25 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:25 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:16:25 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:16:25 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-24', '4', '3', '2016-11-13 02:16:25', '1', '')
INFO - 2016-11-13 02:16:25 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:25 --> Controller Class Initialized
INFO - 2016-11-13 02:16:25 --> Model Class Initialized
INFO - 2016-11-13 02:16:25 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:25 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:16:25 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:16:25 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-24', '4', '3', '2016-11-13 02:16:25', '1', '')
INFO - 2016-11-13 02:16:25 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:16:36 --> Config Class Initialized
INFO - 2016-11-13 02:16:36 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:16:36 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:36 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:36 --> URI Class Initialized
INFO - 2016-11-13 02:16:36 --> Router Class Initialized
INFO - 2016-11-13 02:16:36 --> Output Class Initialized
INFO - 2016-11-13 02:16:36 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:36 --> Input Class Initialized
INFO - 2016-11-13 02:16:36 --> Language Class Initialized
INFO - 2016-11-13 02:16:36 --> Loader Class Initialized
INFO - 2016-11-13 02:16:36 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:36 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:36 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:36 --> Controller Class Initialized
INFO - 2016-11-13 02:16:36 --> Model Class Initialized
INFO - 2016-11-13 02:16:36 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:36 --> Final output sent to browser
DEBUG - 2016-11-13 02:16:36 --> Total execution time: 0.3741
INFO - 2016-11-13 02:16:50 --> Config Class Initialized
INFO - 2016-11-13 02:16:50 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:16:50 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:50 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:50 --> URI Class Initialized
INFO - 2016-11-13 02:16:50 --> Router Class Initialized
INFO - 2016-11-13 02:16:50 --> Output Class Initialized
INFO - 2016-11-13 02:16:50 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:50 --> Input Class Initialized
INFO - 2016-11-13 02:16:50 --> Language Class Initialized
INFO - 2016-11-13 02:16:50 --> Loader Class Initialized
INFO - 2016-11-13 02:16:50 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:50 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:50 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:51 --> Controller Class Initialized
INFO - 2016-11-13 02:16:51 --> Model Class Initialized
INFO - 2016-11-13 02:16:51 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:51 --> Final output sent to browser
DEBUG - 2016-11-13 02:16:51 --> Total execution time: 0.3746
INFO - 2016-11-13 02:16:58 --> Config Class Initialized
INFO - 2016-11-13 02:16:59 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:16:59 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:16:59 --> Utf8 Class Initialized
INFO - 2016-11-13 02:16:59 --> URI Class Initialized
INFO - 2016-11-13 02:16:59 --> Router Class Initialized
INFO - 2016-11-13 02:16:59 --> Output Class Initialized
INFO - 2016-11-13 02:16:59 --> Security Class Initialized
DEBUG - 2016-11-13 02:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:16:59 --> Input Class Initialized
INFO - 2016-11-13 02:16:59 --> Language Class Initialized
INFO - 2016-11-13 02:16:59 --> Loader Class Initialized
INFO - 2016-11-13 02:16:59 --> Helper loaded: url_helper
INFO - 2016-11-13 02:16:59 --> Helper loaded: form_helper
INFO - 2016-11-13 02:16:59 --> Database Driver Class Initialized
INFO - 2016-11-13 02:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:16:59 --> Controller Class Initialized
INFO - 2016-11-13 02:16:59 --> Model Class Initialized
INFO - 2016-11-13 02:16:59 --> Form Validation Class Initialized
INFO - 2016-11-13 02:16:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:16:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:16:59 --> Final output sent to browser
DEBUG - 2016-11-13 02:16:59 --> Total execution time: 0.5161
INFO - 2016-11-13 02:17:28 --> Config Class Initialized
INFO - 2016-11-13 02:17:28 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:17:28 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:17:28 --> Utf8 Class Initialized
INFO - 2016-11-13 02:17:28 --> URI Class Initialized
DEBUG - 2016-11-13 02:17:28 --> No URI present. Default controller set.
INFO - 2016-11-13 02:17:28 --> Router Class Initialized
INFO - 2016-11-13 02:17:28 --> Output Class Initialized
INFO - 2016-11-13 02:17:28 --> Security Class Initialized
DEBUG - 2016-11-13 02:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:17:28 --> Input Class Initialized
INFO - 2016-11-13 02:17:28 --> Language Class Initialized
INFO - 2016-11-13 02:17:28 --> Loader Class Initialized
INFO - 2016-11-13 02:17:28 --> Helper loaded: url_helper
INFO - 2016-11-13 02:17:28 --> Helper loaded: form_helper
INFO - 2016-11-13 02:17:28 --> Database Driver Class Initialized
INFO - 2016-11-13 02:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:17:28 --> Controller Class Initialized
INFO - 2016-11-13 02:17:28 --> Model Class Initialized
INFO - 2016-11-13 02:17:28 --> Model Class Initialized
INFO - 2016-11-13 02:17:28 --> Model Class Initialized
INFO - 2016-11-13 02:17:28 --> Model Class Initialized
INFO - 2016-11-13 02:17:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:17:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:17:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:17:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:17:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:17:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:17:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:17:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:17:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:17:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:17:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:17:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:17:29 --> Final output sent to browser
DEBUG - 2016-11-13 02:17:29 --> Total execution time: 0.6233
INFO - 2016-11-13 02:18:04 --> Config Class Initialized
INFO - 2016-11-13 02:18:04 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:18:04 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:18:04 --> Utf8 Class Initialized
INFO - 2016-11-13 02:18:04 --> URI Class Initialized
INFO - 2016-11-13 02:18:04 --> Router Class Initialized
INFO - 2016-11-13 02:18:04 --> Output Class Initialized
INFO - 2016-11-13 02:18:04 --> Security Class Initialized
DEBUG - 2016-11-13 02:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:18:04 --> Input Class Initialized
INFO - 2016-11-13 02:18:04 --> Language Class Initialized
INFO - 2016-11-13 02:18:04 --> Loader Class Initialized
INFO - 2016-11-13 02:18:04 --> Helper loaded: url_helper
INFO - 2016-11-13 02:18:04 --> Helper loaded: form_helper
INFO - 2016-11-13 02:18:04 --> Database Driver Class Initialized
INFO - 2016-11-13 02:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:18:04 --> Controller Class Initialized
INFO - 2016-11-13 02:18:05 --> Model Class Initialized
INFO - 2016-11-13 02:18:05 --> Form Validation Class Initialized
INFO - 2016-11-13 02:18:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:18:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:18:05 --> Final output sent to browser
DEBUG - 2016-11-13 02:18:05 --> Total execution time: 0.4557
INFO - 2016-11-13 02:18:55 --> Config Class Initialized
INFO - 2016-11-13 02:18:55 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:18:55 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:18:55 --> Utf8 Class Initialized
INFO - 2016-11-13 02:18:55 --> URI Class Initialized
DEBUG - 2016-11-13 02:18:55 --> No URI present. Default controller set.
INFO - 2016-11-13 02:18:55 --> Router Class Initialized
INFO - 2016-11-13 02:18:55 --> Output Class Initialized
INFO - 2016-11-13 02:18:55 --> Security Class Initialized
DEBUG - 2016-11-13 02:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:18:55 --> Input Class Initialized
INFO - 2016-11-13 02:18:55 --> Language Class Initialized
INFO - 2016-11-13 02:18:55 --> Loader Class Initialized
INFO - 2016-11-13 02:18:55 --> Helper loaded: url_helper
INFO - 2016-11-13 02:18:55 --> Helper loaded: form_helper
INFO - 2016-11-13 02:18:55 --> Database Driver Class Initialized
INFO - 2016-11-13 02:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:18:55 --> Controller Class Initialized
INFO - 2016-11-13 02:18:55 --> Model Class Initialized
INFO - 2016-11-13 02:18:55 --> Model Class Initialized
INFO - 2016-11-13 02:18:55 --> Model Class Initialized
INFO - 2016-11-13 02:18:55 --> Model Class Initialized
INFO - 2016-11-13 02:18:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:18:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:18:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:18:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:18:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:18:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:18:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:18:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:18:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:18:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:18:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:18:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:18:56 --> Final output sent to browser
DEBUG - 2016-11-13 02:18:56 --> Total execution time: 0.6269
INFO - 2016-11-13 02:21:27 --> Config Class Initialized
INFO - 2016-11-13 02:21:27 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:21:27 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:21:27 --> Utf8 Class Initialized
INFO - 2016-11-13 02:21:27 --> URI Class Initialized
DEBUG - 2016-11-13 02:21:27 --> No URI present. Default controller set.
INFO - 2016-11-13 02:21:27 --> Router Class Initialized
INFO - 2016-11-13 02:21:27 --> Output Class Initialized
INFO - 2016-11-13 02:21:27 --> Security Class Initialized
DEBUG - 2016-11-13 02:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:21:27 --> Input Class Initialized
INFO - 2016-11-13 02:21:27 --> Language Class Initialized
INFO - 2016-11-13 02:21:27 --> Loader Class Initialized
INFO - 2016-11-13 02:21:27 --> Helper loaded: url_helper
INFO - 2016-11-13 02:21:27 --> Helper loaded: form_helper
INFO - 2016-11-13 02:21:27 --> Database Driver Class Initialized
INFO - 2016-11-13 02:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:21:27 --> Controller Class Initialized
INFO - 2016-11-13 02:21:27 --> Model Class Initialized
INFO - 2016-11-13 02:21:27 --> Model Class Initialized
INFO - 2016-11-13 02:21:27 --> Model Class Initialized
INFO - 2016-11-13 02:21:27 --> Model Class Initialized
INFO - 2016-11-13 02:21:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:21:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:21:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:21:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:21:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:21:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:21:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:21:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:21:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:21:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:21:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:21:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:21:27 --> Final output sent to browser
DEBUG - 2016-11-13 02:21:27 --> Total execution time: 0.6296
INFO - 2016-11-13 02:21:58 --> Config Class Initialized
INFO - 2016-11-13 02:21:58 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:21:58 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:21:58 --> Utf8 Class Initialized
INFO - 2016-11-13 02:21:58 --> URI Class Initialized
INFO - 2016-11-13 02:21:58 --> Router Class Initialized
INFO - 2016-11-13 02:21:58 --> Output Class Initialized
INFO - 2016-11-13 02:21:59 --> Security Class Initialized
DEBUG - 2016-11-13 02:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:21:59 --> Input Class Initialized
INFO - 2016-11-13 02:21:59 --> Language Class Initialized
INFO - 2016-11-13 02:21:59 --> Loader Class Initialized
INFO - 2016-11-13 02:21:59 --> Helper loaded: url_helper
INFO - 2016-11-13 02:21:59 --> Helper loaded: form_helper
INFO - 2016-11-13 02:21:59 --> Database Driver Class Initialized
INFO - 2016-11-13 02:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:21:59 --> Controller Class Initialized
INFO - 2016-11-13 02:21:59 --> Model Class Initialized
INFO - 2016-11-13 02:21:59 --> Model Class Initialized
INFO - 2016-11-13 02:21:59 --> Model Class Initialized
INFO - 2016-11-13 02:21:59 --> Model Class Initialized
DEBUG - 2016-11-13 02:21:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-13 02:21:59 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-13 02:21:59 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-13 02:21:59 --> Config Class Initialized
INFO - 2016-11-13 02:21:59 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:21:59 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:21:59 --> Utf8 Class Initialized
INFO - 2016-11-13 02:21:59 --> URI Class Initialized
DEBUG - 2016-11-13 02:21:59 --> No URI present. Default controller set.
INFO - 2016-11-13 02:21:59 --> Router Class Initialized
INFO - 2016-11-13 02:21:59 --> Output Class Initialized
INFO - 2016-11-13 02:21:59 --> Security Class Initialized
DEBUG - 2016-11-13 02:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:21:59 --> Input Class Initialized
INFO - 2016-11-13 02:21:59 --> Language Class Initialized
INFO - 2016-11-13 02:21:59 --> Loader Class Initialized
INFO - 2016-11-13 02:21:59 --> Helper loaded: url_helper
INFO - 2016-11-13 02:21:59 --> Helper loaded: form_helper
INFO - 2016-11-13 02:21:59 --> Database Driver Class Initialized
INFO - 2016-11-13 02:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:21:59 --> Controller Class Initialized
INFO - 2016-11-13 02:21:59 --> Model Class Initialized
INFO - 2016-11-13 02:21:59 --> Model Class Initialized
INFO - 2016-11-13 02:21:59 --> Model Class Initialized
INFO - 2016-11-13 02:21:59 --> Model Class Initialized
INFO - 2016-11-13 02:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-13 02:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:21:59 --> Final output sent to browser
DEBUG - 2016-11-13 02:21:59 --> Total execution time: 0.4346
INFO - 2016-11-13 02:22:10 --> Config Class Initialized
INFO - 2016-11-13 02:22:10 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:22:10 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:22:10 --> Utf8 Class Initialized
INFO - 2016-11-13 02:22:10 --> URI Class Initialized
INFO - 2016-11-13 02:22:10 --> Router Class Initialized
INFO - 2016-11-13 02:22:10 --> Output Class Initialized
INFO - 2016-11-13 02:22:10 --> Security Class Initialized
DEBUG - 2016-11-13 02:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:22:10 --> Input Class Initialized
INFO - 2016-11-13 02:22:10 --> Language Class Initialized
INFO - 2016-11-13 02:22:10 --> Loader Class Initialized
INFO - 2016-11-13 02:22:10 --> Helper loaded: url_helper
INFO - 2016-11-13 02:22:10 --> Helper loaded: form_helper
INFO - 2016-11-13 02:22:10 --> Database Driver Class Initialized
INFO - 2016-11-13 02:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:22:10 --> Controller Class Initialized
INFO - 2016-11-13 02:22:10 --> Model Class Initialized
INFO - 2016-11-13 02:22:10 --> Model Class Initialized
INFO - 2016-11-13 02:22:10 --> Model Class Initialized
INFO - 2016-11-13 02:22:10 --> Model Class Initialized
DEBUG - 2016-11-13 02:22:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-13 02:22:10 --> Model Class Initialized
INFO - 2016-11-13 02:22:10 --> Final output sent to browser
DEBUG - 2016-11-13 02:22:11 --> Total execution time: 0.3655
INFO - 2016-11-13 02:22:11 --> Config Class Initialized
INFO - 2016-11-13 02:22:11 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:22:11 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:22:11 --> Utf8 Class Initialized
INFO - 2016-11-13 02:22:11 --> URI Class Initialized
DEBUG - 2016-11-13 02:22:11 --> No URI present. Default controller set.
INFO - 2016-11-13 02:22:11 --> Router Class Initialized
INFO - 2016-11-13 02:22:11 --> Output Class Initialized
INFO - 2016-11-13 02:22:11 --> Security Class Initialized
DEBUG - 2016-11-13 02:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:22:11 --> Input Class Initialized
INFO - 2016-11-13 02:22:11 --> Language Class Initialized
INFO - 2016-11-13 02:22:11 --> Loader Class Initialized
INFO - 2016-11-13 02:22:11 --> Helper loaded: url_helper
INFO - 2016-11-13 02:22:11 --> Helper loaded: form_helper
INFO - 2016-11-13 02:22:11 --> Database Driver Class Initialized
INFO - 2016-11-13 02:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:22:11 --> Controller Class Initialized
INFO - 2016-11-13 02:22:11 --> Model Class Initialized
INFO - 2016-11-13 02:22:11 --> Model Class Initialized
INFO - 2016-11-13 02:22:11 --> Model Class Initialized
INFO - 2016-11-13 02:22:11 --> Model Class Initialized
INFO - 2016-11-13 02:22:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:22:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:22:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:22:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:22:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:22:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:22:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:22:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:22:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:22:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:22:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:22:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:22:11 --> Final output sent to browser
DEBUG - 2016-11-13 02:22:11 --> Total execution time: 0.5909
INFO - 2016-11-13 02:22:26 --> Config Class Initialized
INFO - 2016-11-13 02:22:26 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:22:26 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:22:26 --> Utf8 Class Initialized
INFO - 2016-11-13 02:22:26 --> URI Class Initialized
INFO - 2016-11-13 02:22:26 --> Router Class Initialized
INFO - 2016-11-13 02:22:26 --> Output Class Initialized
INFO - 2016-11-13 02:22:26 --> Security Class Initialized
DEBUG - 2016-11-13 02:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:22:26 --> Input Class Initialized
INFO - 2016-11-13 02:22:26 --> Language Class Initialized
INFO - 2016-11-13 02:22:26 --> Loader Class Initialized
INFO - 2016-11-13 02:22:26 --> Helper loaded: url_helper
INFO - 2016-11-13 02:22:26 --> Helper loaded: form_helper
INFO - 2016-11-13 02:22:26 --> Database Driver Class Initialized
INFO - 2016-11-13 02:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:22:26 --> Controller Class Initialized
INFO - 2016-11-13 02:22:26 --> Model Class Initialized
INFO - 2016-11-13 02:22:26 --> Form Validation Class Initialized
INFO - 2016-11-13 02:22:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:22:26 --> Final output sent to browser
DEBUG - 2016-11-13 02:22:26 --> Total execution time: 0.3468
INFO - 2016-11-13 02:22:34 --> Config Class Initialized
INFO - 2016-11-13 02:22:34 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:22:34 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:22:34 --> Utf8 Class Initialized
INFO - 2016-11-13 02:22:34 --> URI Class Initialized
INFO - 2016-11-13 02:22:34 --> Router Class Initialized
INFO - 2016-11-13 02:22:34 --> Output Class Initialized
INFO - 2016-11-13 02:22:34 --> Security Class Initialized
DEBUG - 2016-11-13 02:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:22:34 --> Input Class Initialized
INFO - 2016-11-13 02:22:34 --> Language Class Initialized
INFO - 2016-11-13 02:22:34 --> Loader Class Initialized
INFO - 2016-11-13 02:22:34 --> Helper loaded: url_helper
INFO - 2016-11-13 02:22:34 --> Helper loaded: form_helper
INFO - 2016-11-13 02:22:34 --> Database Driver Class Initialized
INFO - 2016-11-13 02:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:22:34 --> Controller Class Initialized
INFO - 2016-11-13 02:22:34 --> Model Class Initialized
INFO - 2016-11-13 02:22:34 --> Form Validation Class Initialized
INFO - 2016-11-13 02:22:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:22:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:22:34 --> Final output sent to browser
DEBUG - 2016-11-13 02:22:34 --> Total execution time: 0.5518
INFO - 2016-11-13 02:28:30 --> Config Class Initialized
INFO - 2016-11-13 02:28:30 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:28:30 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:28:30 --> Utf8 Class Initialized
INFO - 2016-11-13 02:28:30 --> URI Class Initialized
DEBUG - 2016-11-13 02:28:30 --> No URI present. Default controller set.
INFO - 2016-11-13 02:28:30 --> Router Class Initialized
INFO - 2016-11-13 02:28:30 --> Output Class Initialized
INFO - 2016-11-13 02:28:30 --> Security Class Initialized
DEBUG - 2016-11-13 02:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:28:30 --> Input Class Initialized
INFO - 2016-11-13 02:28:30 --> Language Class Initialized
INFO - 2016-11-13 02:28:30 --> Loader Class Initialized
INFO - 2016-11-13 02:28:30 --> Helper loaded: url_helper
INFO - 2016-11-13 02:28:30 --> Helper loaded: form_helper
INFO - 2016-11-13 02:28:30 --> Database Driver Class Initialized
INFO - 2016-11-13 02:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:28:30 --> Controller Class Initialized
INFO - 2016-11-13 02:28:30 --> Model Class Initialized
INFO - 2016-11-13 02:28:30 --> Model Class Initialized
INFO - 2016-11-13 02:28:30 --> Model Class Initialized
INFO - 2016-11-13 02:28:30 --> Model Class Initialized
INFO - 2016-11-13 02:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:28:30 --> Final output sent to browser
DEBUG - 2016-11-13 02:28:30 --> Total execution time: 0.5978
INFO - 2016-11-13 02:28:33 --> Config Class Initialized
INFO - 2016-11-13 02:28:33 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:28:33 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:28:33 --> Utf8 Class Initialized
INFO - 2016-11-13 02:28:33 --> URI Class Initialized
INFO - 2016-11-13 02:28:33 --> Router Class Initialized
INFO - 2016-11-13 02:28:33 --> Output Class Initialized
INFO - 2016-11-13 02:28:33 --> Security Class Initialized
DEBUG - 2016-11-13 02:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:28:33 --> Input Class Initialized
INFO - 2016-11-13 02:28:33 --> Language Class Initialized
INFO - 2016-11-13 02:28:33 --> Loader Class Initialized
INFO - 2016-11-13 02:28:33 --> Helper loaded: url_helper
INFO - 2016-11-13 02:28:33 --> Helper loaded: form_helper
INFO - 2016-11-13 02:28:33 --> Database Driver Class Initialized
INFO - 2016-11-13 02:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:28:33 --> Controller Class Initialized
INFO - 2016-11-13 02:28:33 --> Model Class Initialized
INFO - 2016-11-13 02:28:33 --> Form Validation Class Initialized
INFO - 2016-11-13 02:28:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:28:33 --> Final output sent to browser
DEBUG - 2016-11-13 02:28:33 --> Total execution time: 0.3267
INFO - 2016-11-13 02:28:55 --> Config Class Initialized
INFO - 2016-11-13 02:28:55 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:28:55 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:28:55 --> Utf8 Class Initialized
INFO - 2016-11-13 02:28:55 --> URI Class Initialized
INFO - 2016-11-13 02:28:55 --> Router Class Initialized
INFO - 2016-11-13 02:28:55 --> Output Class Initialized
INFO - 2016-11-13 02:28:55 --> Security Class Initialized
DEBUG - 2016-11-13 02:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:28:55 --> Input Class Initialized
INFO - 2016-11-13 02:28:55 --> Language Class Initialized
INFO - 2016-11-13 02:28:55 --> Loader Class Initialized
INFO - 2016-11-13 02:28:55 --> Helper loaded: url_helper
INFO - 2016-11-13 02:28:55 --> Helper loaded: form_helper
INFO - 2016-11-13 02:28:55 --> Database Driver Class Initialized
INFO - 2016-11-13 02:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:28:55 --> Controller Class Initialized
INFO - 2016-11-13 02:28:55 --> Model Class Initialized
INFO - 2016-11-13 02:28:55 --> Form Validation Class Initialized
INFO - 2016-11-13 02:28:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:28:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:28:56 --> Final output sent to browser
DEBUG - 2016-11-13 02:28:56 --> Total execution time: 0.4540
INFO - 2016-11-13 02:29:55 --> Config Class Initialized
INFO - 2016-11-13 02:29:55 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:29:55 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:29:55 --> Utf8 Class Initialized
INFO - 2016-11-13 02:29:55 --> URI Class Initialized
DEBUG - 2016-11-13 02:29:55 --> No URI present. Default controller set.
INFO - 2016-11-13 02:29:55 --> Router Class Initialized
INFO - 2016-11-13 02:29:55 --> Output Class Initialized
INFO - 2016-11-13 02:29:55 --> Security Class Initialized
DEBUG - 2016-11-13 02:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:29:55 --> Input Class Initialized
INFO - 2016-11-13 02:29:55 --> Language Class Initialized
INFO - 2016-11-13 02:29:55 --> Loader Class Initialized
INFO - 2016-11-13 02:29:55 --> Helper loaded: url_helper
INFO - 2016-11-13 02:29:55 --> Helper loaded: form_helper
INFO - 2016-11-13 02:29:55 --> Database Driver Class Initialized
INFO - 2016-11-13 02:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:29:55 --> Controller Class Initialized
INFO - 2016-11-13 02:29:55 --> Model Class Initialized
INFO - 2016-11-13 02:29:55 --> Model Class Initialized
INFO - 2016-11-13 02:29:55 --> Model Class Initialized
INFO - 2016-11-13 02:29:55 --> Model Class Initialized
INFO - 2016-11-13 02:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:29:55 --> Final output sent to browser
DEBUG - 2016-11-13 02:29:55 --> Total execution time: 0.5939
INFO - 2016-11-13 02:30:24 --> Config Class Initialized
INFO - 2016-11-13 02:30:24 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:30:24 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:30:24 --> Utf8 Class Initialized
INFO - 2016-11-13 02:30:24 --> URI Class Initialized
INFO - 2016-11-13 02:30:24 --> Router Class Initialized
INFO - 2016-11-13 02:30:24 --> Output Class Initialized
INFO - 2016-11-13 02:30:24 --> Security Class Initialized
DEBUG - 2016-11-13 02:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:30:24 --> Input Class Initialized
INFO - 2016-11-13 02:30:24 --> Language Class Initialized
INFO - 2016-11-13 02:30:24 --> Loader Class Initialized
INFO - 2016-11-13 02:30:24 --> Helper loaded: url_helper
INFO - 2016-11-13 02:30:24 --> Helper loaded: form_helper
INFO - 2016-11-13 02:30:24 --> Database Driver Class Initialized
INFO - 2016-11-13 02:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:30:24 --> Controller Class Initialized
INFO - 2016-11-13 02:30:24 --> Model Class Initialized
INFO - 2016-11-13 02:30:24 --> Form Validation Class Initialized
INFO - 2016-11-13 02:30:25 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:30:25 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:30:25 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-10', '3', '1', '2016-11-13 02:30:25', '1', '')
INFO - 2016-11-13 02:30:25 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:30:28 --> Config Class Initialized
INFO - 2016-11-13 02:30:28 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:30:28 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:30:28 --> Utf8 Class Initialized
INFO - 2016-11-13 02:30:28 --> URI Class Initialized
INFO - 2016-11-13 02:30:28 --> Router Class Initialized
INFO - 2016-11-13 02:30:28 --> Output Class Initialized
INFO - 2016-11-13 02:30:28 --> Security Class Initialized
DEBUG - 2016-11-13 02:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:30:28 --> Input Class Initialized
INFO - 2016-11-13 02:30:28 --> Language Class Initialized
INFO - 2016-11-13 02:30:28 --> Loader Class Initialized
INFO - 2016-11-13 02:30:28 --> Helper loaded: url_helper
INFO - 2016-11-13 02:30:28 --> Helper loaded: form_helper
INFO - 2016-11-13 02:30:28 --> Database Driver Class Initialized
INFO - 2016-11-13 02:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:30:28 --> Controller Class Initialized
INFO - 2016-11-13 02:30:28 --> Model Class Initialized
INFO - 2016-11-13 02:30:28 --> Form Validation Class Initialized
INFO - 2016-11-13 02:30:28 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:30:28 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:30:28 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-10', '3', '1', '2016-11-13 02:30:28', '1', '')
INFO - 2016-11-13 02:30:28 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:30:28 --> Config Class Initialized
INFO - 2016-11-13 02:30:28 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:30:28 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:30:28 --> Utf8 Class Initialized
INFO - 2016-11-13 02:30:28 --> URI Class Initialized
INFO - 2016-11-13 02:30:28 --> Router Class Initialized
INFO - 2016-11-13 02:30:28 --> Output Class Initialized
INFO - 2016-11-13 02:30:28 --> Security Class Initialized
DEBUG - 2016-11-13 02:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:30:28 --> Input Class Initialized
INFO - 2016-11-13 02:30:28 --> Config Class Initialized
INFO - 2016-11-13 02:30:28 --> Hooks Class Initialized
INFO - 2016-11-13 02:30:28 --> Language Class Initialized
DEBUG - 2016-11-13 02:30:28 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:30:28 --> Loader Class Initialized
INFO - 2016-11-13 02:30:28 --> Utf8 Class Initialized
INFO - 2016-11-13 02:30:28 --> URI Class Initialized
INFO - 2016-11-13 02:30:28 --> Helper loaded: url_helper
INFO - 2016-11-13 02:30:28 --> Router Class Initialized
INFO - 2016-11-13 02:30:28 --> Helper loaded: form_helper
INFO - 2016-11-13 02:30:28 --> Output Class Initialized
INFO - 2016-11-13 02:30:28 --> Database Driver Class Initialized
INFO - 2016-11-13 02:30:28 --> Security Class Initialized
INFO - 2016-11-13 02:30:28 --> Config Class Initialized
INFO - 2016-11-13 02:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:30:28 --> Controller Class Initialized
INFO - 2016-11-13 02:30:28 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:30:28 --> Input Class Initialized
INFO - 2016-11-13 02:30:28 --> Model Class Initialized
DEBUG - 2016-11-13 02:30:28 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:30:28 --> Language Class Initialized
INFO - 2016-11-13 02:30:28 --> Utf8 Class Initialized
INFO - 2016-11-13 02:30:28 --> Form Validation Class Initialized
INFO - 2016-11-13 02:30:29 --> URI Class Initialized
INFO - 2016-11-13 02:30:29 --> Loader Class Initialized
INFO - 2016-11-13 02:30:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:30:29 --> Helper loaded: url_helper
INFO - 2016-11-13 02:30:29 --> Router Class Initialized
ERROR - 2016-11-13 02:30:29 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:30:29 --> Output Class Initialized
INFO - 2016-11-13 02:30:29 --> Helper loaded: form_helper
INFO - 2016-11-13 02:30:29 --> Config Class Initialized
INFO - 2016-11-13 02:30:29 --> Hooks Class Initialized
INFO - 2016-11-13 02:30:29 --> Database Driver Class Initialized
INFO - 2016-11-13 02:30:29 --> Security Class Initialized
DEBUG - 2016-11-13 02:30:29 --> UTF-8 Support Enabled
DEBUG - 2016-11-13 02:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:30:29 --> Utf8 Class Initialized
ERROR - 2016-11-13 02:30:29 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-10', '3', '1', '2016-11-13 02:30:29', '1', '')
INFO - 2016-11-13 02:30:29 --> Input Class Initialized
INFO - 2016-11-13 02:30:29 --> URI Class Initialized
INFO - 2016-11-13 02:30:29 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:30:29 --> Language Class Initialized
INFO - 2016-11-13 02:30:29 --> Router Class Initialized
INFO - 2016-11-13 02:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:30:29 --> Loader Class Initialized
INFO - 2016-11-13 02:30:29 --> Config Class Initialized
INFO - 2016-11-13 02:30:29 --> Controller Class Initialized
INFO - 2016-11-13 02:30:29 --> Output Class Initialized
INFO - 2016-11-13 02:30:29 --> Hooks Class Initialized
INFO - 2016-11-13 02:30:29 --> Helper loaded: url_helper
INFO - 2016-11-13 02:30:29 --> Security Class Initialized
INFO - 2016-11-13 02:30:29 --> Model Class Initialized
INFO - 2016-11-13 02:30:29 --> Helper loaded: form_helper
DEBUG - 2016-11-13 02:30:29 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:30:29 --> Form Validation Class Initialized
INFO - 2016-11-13 02:30:29 --> Utf8 Class Initialized
DEBUG - 2016-11-13 02:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:30:29 --> Database Driver Class Initialized
INFO - 2016-11-13 02:30:29 --> Input Class Initialized
INFO - 2016-11-13 02:30:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:30:29 --> URI Class Initialized
INFO - 2016-11-13 02:30:29 --> Language Class Initialized
INFO - 2016-11-13 02:30:29 --> Router Class Initialized
ERROR - 2016-11-13 02:30:29 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:30:29 --> Loader Class Initialized
INFO - 2016-11-13 02:30:29 --> Output Class Initialized
INFO - 2016-11-13 02:30:29 --> Helper loaded: url_helper
ERROR - 2016-11-13 02:30:29 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-10', '3', '1', '2016-11-13 02:30:29', '1', '')
INFO - 2016-11-13 02:30:29 --> Security Class Initialized
INFO - 2016-11-13 02:30:29 --> Config Class Initialized
INFO - 2016-11-13 02:30:29 --> Helper loaded: form_helper
INFO - 2016-11-13 02:30:29 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:30:29 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:30:29 --> Database Driver Class Initialized
DEBUG - 2016-11-13 02:30:29 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:30:29 --> Input Class Initialized
INFO - 2016-11-13 02:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:30:29 --> Utf8 Class Initialized
INFO - 2016-11-13 02:30:29 --> Controller Class Initialized
INFO - 2016-11-13 02:30:29 --> Language Class Initialized
INFO - 2016-11-13 02:30:29 --> Model Class Initialized
INFO - 2016-11-13 02:30:29 --> URI Class Initialized
INFO - 2016-11-13 02:30:29 --> Loader Class Initialized
INFO - 2016-11-13 02:30:29 --> Form Validation Class Initialized
INFO - 2016-11-13 02:30:29 --> Router Class Initialized
INFO - 2016-11-13 02:30:29 --> Helper loaded: url_helper
INFO - 2016-11-13 02:30:29 --> Config Class Initialized
INFO - 2016-11-13 02:30:29 --> Output Class Initialized
INFO - 2016-11-13 02:30:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:30:29 --> Helper loaded: form_helper
INFO - 2016-11-13 02:30:29 --> Hooks Class Initialized
ERROR - 2016-11-13 02:30:29 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:30:29 --> Security Class Initialized
DEBUG - 2016-11-13 02:30:29 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:30:29 --> Database Driver Class Initialized
INFO - 2016-11-13 02:30:29 --> Utf8 Class Initialized
DEBUG - 2016-11-13 02:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:30:29 --> Input Class Initialized
INFO - 2016-11-13 02:30:29 --> URI Class Initialized
ERROR - 2016-11-13 02:30:29 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-10', '3', '1', '2016-11-13 02:30:29', '1', '')
INFO - 2016-11-13 02:30:29 --> Language Class Initialized
INFO - 2016-11-13 02:30:29 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:30:29 --> Router Class Initialized
INFO - 2016-11-13 02:30:29 --> Loader Class Initialized
INFO - 2016-11-13 02:30:29 --> Output Class Initialized
INFO - 2016-11-13 02:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:30:29 --> Helper loaded: url_helper
INFO - 2016-11-13 02:30:29 --> Controller Class Initialized
INFO - 2016-11-13 02:30:29 --> Security Class Initialized
INFO - 2016-11-13 02:30:29 --> Model Class Initialized
INFO - 2016-11-13 02:30:29 --> Helper loaded: form_helper
DEBUG - 2016-11-13 02:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:30:29 --> Database Driver Class Initialized
INFO - 2016-11-13 02:30:29 --> Form Validation Class Initialized
INFO - 2016-11-13 02:30:29 --> Input Class Initialized
INFO - 2016-11-13 02:30:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:30:29 --> Language Class Initialized
ERROR - 2016-11-13 02:30:29 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:30:29 --> Loader Class Initialized
INFO - 2016-11-13 02:30:29 --> Helper loaded: url_helper
INFO - 2016-11-13 02:30:29 --> Helper loaded: form_helper
ERROR - 2016-11-13 02:30:29 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-10', '3', '1', '2016-11-13 02:30:29', '1', '')
INFO - 2016-11-13 02:30:29 --> Database Driver Class Initialized
INFO - 2016-11-13 02:30:30 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:30:30 --> Controller Class Initialized
INFO - 2016-11-13 02:30:30 --> Model Class Initialized
INFO - 2016-11-13 02:30:30 --> Form Validation Class Initialized
INFO - 2016-11-13 02:30:30 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:30:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:30:30 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-10', '3', '1', '2016-11-13 02:30:30', '1', '')
INFO - 2016-11-13 02:30:30 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:30:30 --> Controller Class Initialized
INFO - 2016-11-13 02:30:30 --> Model Class Initialized
INFO - 2016-11-13 02:30:30 --> Form Validation Class Initialized
INFO - 2016-11-13 02:30:30 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:30:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:30:30 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-10', '3', '1', '2016-11-13 02:30:30', '1', '')
INFO - 2016-11-13 02:30:30 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:30:30 --> Controller Class Initialized
INFO - 2016-11-13 02:30:30 --> Model Class Initialized
INFO - 2016-11-13 02:30:30 --> Form Validation Class Initialized
INFO - 2016-11-13 02:30:30 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:30:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:30:30 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-10', '3', '1', '2016-11-13 02:30:30', '1', '')
INFO - 2016-11-13 02:30:30 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:30:33 --> Config Class Initialized
INFO - 2016-11-13 02:30:33 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:30:33 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:30:33 --> Utf8 Class Initialized
INFO - 2016-11-13 02:30:33 --> URI Class Initialized
INFO - 2016-11-13 02:30:33 --> Router Class Initialized
INFO - 2016-11-13 02:30:33 --> Output Class Initialized
INFO - 2016-11-13 02:30:34 --> Security Class Initialized
DEBUG - 2016-11-13 02:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:30:34 --> Input Class Initialized
INFO - 2016-11-13 02:30:34 --> Language Class Initialized
INFO - 2016-11-13 02:30:34 --> Loader Class Initialized
INFO - 2016-11-13 02:30:34 --> Helper loaded: url_helper
INFO - 2016-11-13 02:30:34 --> Helper loaded: form_helper
INFO - 2016-11-13 02:30:34 --> Database Driver Class Initialized
INFO - 2016-11-13 02:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:30:34 --> Controller Class Initialized
INFO - 2016-11-13 02:30:34 --> Model Class Initialized
INFO - 2016-11-13 02:30:34 --> Form Validation Class Initialized
INFO - 2016-11-13 02:30:34 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:30:34 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:30:34 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-10', '3', '1', '2016-11-13 02:30:34', '1', '')
INFO - 2016-11-13 02:30:34 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:30:35 --> Config Class Initialized
INFO - 2016-11-13 02:30:35 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:30:35 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:30:35 --> Utf8 Class Initialized
INFO - 2016-11-13 02:30:35 --> URI Class Initialized
DEBUG - 2016-11-13 02:30:35 --> No URI present. Default controller set.
INFO - 2016-11-13 02:30:35 --> Router Class Initialized
INFO - 2016-11-13 02:30:35 --> Output Class Initialized
INFO - 2016-11-13 02:30:35 --> Security Class Initialized
DEBUG - 2016-11-13 02:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:30:35 --> Input Class Initialized
INFO - 2016-11-13 02:30:35 --> Language Class Initialized
INFO - 2016-11-13 02:30:35 --> Loader Class Initialized
INFO - 2016-11-13 02:30:35 --> Helper loaded: url_helper
INFO - 2016-11-13 02:30:35 --> Helper loaded: form_helper
INFO - 2016-11-13 02:30:35 --> Database Driver Class Initialized
INFO - 2016-11-13 02:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:30:35 --> Controller Class Initialized
INFO - 2016-11-13 02:30:35 --> Model Class Initialized
INFO - 2016-11-13 02:30:35 --> Model Class Initialized
INFO - 2016-11-13 02:30:35 --> Model Class Initialized
INFO - 2016-11-13 02:30:35 --> Model Class Initialized
INFO - 2016-11-13 02:30:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:30:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:30:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:30:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:30:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:30:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:30:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:30:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:30:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:30:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:30:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:30:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:30:35 --> Final output sent to browser
DEBUG - 2016-11-13 02:30:35 --> Total execution time: 0.6255
INFO - 2016-11-13 02:30:38 --> Config Class Initialized
INFO - 2016-11-13 02:30:38 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:30:38 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:30:38 --> Utf8 Class Initialized
INFO - 2016-11-13 02:30:38 --> URI Class Initialized
INFO - 2016-11-13 02:30:38 --> Router Class Initialized
INFO - 2016-11-13 02:30:38 --> Output Class Initialized
INFO - 2016-11-13 02:30:38 --> Security Class Initialized
DEBUG - 2016-11-13 02:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:30:38 --> Input Class Initialized
INFO - 2016-11-13 02:30:38 --> Language Class Initialized
INFO - 2016-11-13 02:30:38 --> Loader Class Initialized
INFO - 2016-11-13 02:30:38 --> Helper loaded: url_helper
INFO - 2016-11-13 02:30:38 --> Helper loaded: form_helper
INFO - 2016-11-13 02:30:38 --> Database Driver Class Initialized
INFO - 2016-11-13 02:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:30:38 --> Controller Class Initialized
INFO - 2016-11-13 02:30:38 --> Model Class Initialized
INFO - 2016-11-13 02:30:38 --> Form Validation Class Initialized
INFO - 2016-11-13 02:30:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:30:38 --> Final output sent to browser
DEBUG - 2016-11-13 02:30:38 --> Total execution time: 0.3326
INFO - 2016-11-13 02:30:40 --> Config Class Initialized
INFO - 2016-11-13 02:30:40 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:30:40 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:30:40 --> Utf8 Class Initialized
INFO - 2016-11-13 02:30:40 --> URI Class Initialized
DEBUG - 2016-11-13 02:30:40 --> No URI present. Default controller set.
INFO - 2016-11-13 02:30:40 --> Router Class Initialized
INFO - 2016-11-13 02:30:40 --> Output Class Initialized
INFO - 2016-11-13 02:30:40 --> Security Class Initialized
DEBUG - 2016-11-13 02:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:30:40 --> Input Class Initialized
INFO - 2016-11-13 02:30:40 --> Language Class Initialized
INFO - 2016-11-13 02:30:40 --> Loader Class Initialized
INFO - 2016-11-13 02:30:40 --> Helper loaded: url_helper
INFO - 2016-11-13 02:30:40 --> Helper loaded: form_helper
INFO - 2016-11-13 02:30:40 --> Database Driver Class Initialized
INFO - 2016-11-13 02:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:30:40 --> Controller Class Initialized
INFO - 2016-11-13 02:30:40 --> Model Class Initialized
INFO - 2016-11-13 02:30:40 --> Model Class Initialized
INFO - 2016-11-13 02:30:40 --> Model Class Initialized
INFO - 2016-11-13 02:30:40 --> Model Class Initialized
INFO - 2016-11-13 02:30:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:30:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:30:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:30:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:30:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:30:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:30:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:30:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:30:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:30:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:30:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:30:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:30:41 --> Final output sent to browser
DEBUG - 2016-11-13 02:30:41 --> Total execution time: 0.6749
INFO - 2016-11-13 02:30:51 --> Config Class Initialized
INFO - 2016-11-13 02:30:51 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:30:51 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:30:51 --> Utf8 Class Initialized
INFO - 2016-11-13 02:30:51 --> URI Class Initialized
INFO - 2016-11-13 02:30:51 --> Router Class Initialized
INFO - 2016-11-13 02:30:51 --> Output Class Initialized
INFO - 2016-11-13 02:30:51 --> Security Class Initialized
DEBUG - 2016-11-13 02:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:30:51 --> Input Class Initialized
INFO - 2016-11-13 02:30:51 --> Language Class Initialized
INFO - 2016-11-13 02:30:51 --> Loader Class Initialized
INFO - 2016-11-13 02:30:51 --> Helper loaded: url_helper
INFO - 2016-11-13 02:30:51 --> Helper loaded: form_helper
INFO - 2016-11-13 02:30:51 --> Database Driver Class Initialized
INFO - 2016-11-13 02:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:30:51 --> Controller Class Initialized
INFO - 2016-11-13 02:30:51 --> Model Class Initialized
INFO - 2016-11-13 02:30:51 --> Form Validation Class Initialized
INFO - 2016-11-13 02:30:51 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:30:51 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:30:52 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-26', '3', '2', '2016-11-13 02:30:51', '1', '')
INFO - 2016-11-13 02:30:52 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:30:53 --> Config Class Initialized
INFO - 2016-11-13 02:30:53 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:30:53 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:30:53 --> Utf8 Class Initialized
INFO - 2016-11-13 02:30:53 --> URI Class Initialized
INFO - 2016-11-13 02:30:53 --> Router Class Initialized
INFO - 2016-11-13 02:30:53 --> Output Class Initialized
INFO - 2016-11-13 02:30:53 --> Security Class Initialized
DEBUG - 2016-11-13 02:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:30:53 --> Input Class Initialized
INFO - 2016-11-13 02:30:53 --> Language Class Initialized
INFO - 2016-11-13 02:30:53 --> Loader Class Initialized
INFO - 2016-11-13 02:30:53 --> Config Class Initialized
INFO - 2016-11-13 02:30:53 --> Helper loaded: url_helper
INFO - 2016-11-13 02:30:53 --> Hooks Class Initialized
INFO - 2016-11-13 02:30:53 --> Helper loaded: form_helper
DEBUG - 2016-11-13 02:30:53 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:30:53 --> Database Driver Class Initialized
INFO - 2016-11-13 02:30:53 --> Utf8 Class Initialized
INFO - 2016-11-13 02:30:53 --> URI Class Initialized
INFO - 2016-11-13 02:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:30:53 --> Router Class Initialized
INFO - 2016-11-13 02:30:53 --> Controller Class Initialized
INFO - 2016-11-13 02:30:53 --> Model Class Initialized
INFO - 2016-11-13 02:30:53 --> Config Class Initialized
INFO - 2016-11-13 02:30:53 --> Output Class Initialized
INFO - 2016-11-13 02:30:53 --> Form Validation Class Initialized
INFO - 2016-11-13 02:30:53 --> Hooks Class Initialized
INFO - 2016-11-13 02:30:53 --> Security Class Initialized
DEBUG - 2016-11-13 02:30:53 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:30:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-13 02:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:30:53 --> Utf8 Class Initialized
ERROR - 2016-11-13 02:30:53 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:30:53 --> Input Class Initialized
INFO - 2016-11-13 02:30:53 --> URI Class Initialized
INFO - 2016-11-13 02:30:53 --> Language Class Initialized
INFO - 2016-11-13 02:30:53 --> Router Class Initialized
INFO - 2016-11-13 02:30:53 --> Loader Class Initialized
INFO - 2016-11-13 02:30:53 --> Config Class Initialized
ERROR - 2016-11-13 02:30:53 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-26', '3', '2', '2016-11-13 02:30:53', '1', '')
INFO - 2016-11-13 02:30:53 --> Hooks Class Initialized
INFO - 2016-11-13 02:30:53 --> Output Class Initialized
INFO - 2016-11-13 02:30:54 --> Helper loaded: url_helper
DEBUG - 2016-11-13 02:30:54 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:30:54 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:30:54 --> Security Class Initialized
INFO - 2016-11-13 02:30:54 --> Helper loaded: form_helper
INFO - 2016-11-13 02:30:54 --> Utf8 Class Initialized
DEBUG - 2016-11-13 02:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:30:54 --> Database Driver Class Initialized
INFO - 2016-11-13 02:30:54 --> Input Class Initialized
INFO - 2016-11-13 02:30:54 --> Config Class Initialized
INFO - 2016-11-13 02:30:54 --> URI Class Initialized
INFO - 2016-11-13 02:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:30:54 --> Hooks Class Initialized
INFO - 2016-11-13 02:30:54 --> Router Class Initialized
INFO - 2016-11-13 02:30:54 --> Controller Class Initialized
INFO - 2016-11-13 02:30:54 --> Language Class Initialized
DEBUG - 2016-11-13 02:30:54 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:30:54 --> Output Class Initialized
INFO - 2016-11-13 02:30:54 --> Model Class Initialized
INFO - 2016-11-13 02:30:54 --> Loader Class Initialized
INFO - 2016-11-13 02:30:54 --> Utf8 Class Initialized
INFO - 2016-11-13 02:30:54 --> Security Class Initialized
INFO - 2016-11-13 02:30:54 --> URI Class Initialized
INFO - 2016-11-13 02:30:54 --> Form Validation Class Initialized
INFO - 2016-11-13 02:30:54 --> Helper loaded: url_helper
DEBUG - 2016-11-13 02:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:30:54 --> Config Class Initialized
INFO - 2016-11-13 02:30:54 --> Router Class Initialized
INFO - 2016-11-13 02:30:54 --> Helper loaded: form_helper
INFO - 2016-11-13 02:30:54 --> Hooks Class Initialized
INFO - 2016-11-13 02:30:54 --> Input Class Initialized
INFO - 2016-11-13 02:30:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:30:54 --> Output Class Initialized
INFO - 2016-11-13 02:30:54 --> Language Class Initialized
INFO - 2016-11-13 02:30:54 --> Database Driver Class Initialized
DEBUG - 2016-11-13 02:30:54 --> UTF-8 Support Enabled
ERROR - 2016-11-13 02:30:54 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:30:54 --> Utf8 Class Initialized
INFO - 2016-11-13 02:30:54 --> Loader Class Initialized
INFO - 2016-11-13 02:30:54 --> Security Class Initialized
INFO - 2016-11-13 02:30:54 --> URI Class Initialized
INFO - 2016-11-13 02:30:54 --> Helper loaded: url_helper
DEBUG - 2016-11-13 02:30:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-11-13 02:30:54 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-26', '3', '2', '2016-11-13 02:30:54', '1', '')
INFO - 2016-11-13 02:30:54 --> Router Class Initialized
INFO - 2016-11-13 02:30:54 --> Helper loaded: form_helper
INFO - 2016-11-13 02:30:54 --> Input Class Initialized
INFO - 2016-11-13 02:30:54 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:30:54 --> Database Driver Class Initialized
INFO - 2016-11-13 02:30:54 --> Config Class Initialized
INFO - 2016-11-13 02:30:54 --> Language Class Initialized
INFO - 2016-11-13 02:30:54 --> Output Class Initialized
INFO - 2016-11-13 02:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:30:54 --> Hooks Class Initialized
INFO - 2016-11-13 02:30:54 --> Loader Class Initialized
INFO - 2016-11-13 02:30:54 --> Controller Class Initialized
INFO - 2016-11-13 02:30:54 --> Security Class Initialized
DEBUG - 2016-11-13 02:30:54 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:30:54 --> Model Class Initialized
INFO - 2016-11-13 02:30:54 --> Helper loaded: url_helper
INFO - 2016-11-13 02:30:54 --> Utf8 Class Initialized
DEBUG - 2016-11-13 02:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:30:54 --> URI Class Initialized
INFO - 2016-11-13 02:30:54 --> Helper loaded: form_helper
INFO - 2016-11-13 02:30:54 --> Form Validation Class Initialized
INFO - 2016-11-13 02:30:54 --> Input Class Initialized
INFO - 2016-11-13 02:30:54 --> Language Class Initialized
INFO - 2016-11-13 02:30:54 --> Database Driver Class Initialized
INFO - 2016-11-13 02:30:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:30:54 --> Router Class Initialized
INFO - 2016-11-13 02:30:54 --> Config Class Initialized
INFO - 2016-11-13 02:30:54 --> Loader Class Initialized
INFO - 2016-11-13 02:30:54 --> Hooks Class Initialized
ERROR - 2016-11-13 02:30:54 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:30:54 --> Output Class Initialized
INFO - 2016-11-13 02:30:54 --> Helper loaded: url_helper
INFO - 2016-11-13 02:30:54 --> Security Class Initialized
DEBUG - 2016-11-13 02:30:54 --> UTF-8 Support Enabled
ERROR - 2016-11-13 02:30:54 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-26', '3', '2', '2016-11-13 02:30:54', '1', '')
INFO - 2016-11-13 02:30:54 --> Utf8 Class Initialized
INFO - 2016-11-13 02:30:54 --> Helper loaded: form_helper
DEBUG - 2016-11-13 02:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:30:54 --> URI Class Initialized
INFO - 2016-11-13 02:30:54 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:30:54 --> Database Driver Class Initialized
INFO - 2016-11-13 02:30:54 --> Input Class Initialized
INFO - 2016-11-13 02:30:54 --> Language Class Initialized
INFO - 2016-11-13 02:30:54 --> Router Class Initialized
INFO - 2016-11-13 02:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:30:54 --> Loader Class Initialized
INFO - 2016-11-13 02:30:54 --> Controller Class Initialized
INFO - 2016-11-13 02:30:54 --> Output Class Initialized
INFO - 2016-11-13 02:30:54 --> Model Class Initialized
INFO - 2016-11-13 02:30:54 --> Helper loaded: url_helper
INFO - 2016-11-13 02:30:54 --> Security Class Initialized
INFO - 2016-11-13 02:30:54 --> Helper loaded: form_helper
INFO - 2016-11-13 02:30:54 --> Form Validation Class Initialized
DEBUG - 2016-11-13 02:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:30:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:30:54 --> Database Driver Class Initialized
INFO - 2016-11-13 02:30:54 --> Input Class Initialized
INFO - 2016-11-13 02:30:54 --> Language Class Initialized
ERROR - 2016-11-13 02:30:54 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-13 02:30:54 --> Loader Class Initialized
INFO - 2016-11-13 02:30:54 --> Helper loaded: url_helper
ERROR - 2016-11-13 02:30:54 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-26', '3', '2', '2016-11-13 02:30:54', '1', '')
INFO - 2016-11-13 02:30:54 --> Helper loaded: form_helper
INFO - 2016-11-13 02:30:54 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:30:54 --> Database Driver Class Initialized
INFO - 2016-11-13 02:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:30:55 --> Controller Class Initialized
INFO - 2016-11-13 02:30:55 --> Model Class Initialized
INFO - 2016-11-13 02:30:55 --> Form Validation Class Initialized
INFO - 2016-11-13 02:30:55 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:30:55 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:30:55 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-26', '3', '2', '2016-11-13 02:30:55', '1', '')
INFO - 2016-11-13 02:30:55 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:30:55 --> Controller Class Initialized
INFO - 2016-11-13 02:30:55 --> Model Class Initialized
INFO - 2016-11-13 02:30:55 --> Form Validation Class Initialized
INFO - 2016-11-13 02:30:55 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:30:55 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:30:55 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-26', '3', '2', '2016-11-13 02:30:55', '1', '')
INFO - 2016-11-13 02:30:55 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:30:55 --> Controller Class Initialized
INFO - 2016-11-13 02:30:55 --> Model Class Initialized
INFO - 2016-11-13 02:30:55 --> Form Validation Class Initialized
INFO - 2016-11-13 02:30:55 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:30:55 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:30:55 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-26', '3', '2', '2016-11-13 02:30:55', '1', '')
INFO - 2016-11-13 02:30:55 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:30:55 --> Controller Class Initialized
INFO - 2016-11-13 02:30:55 --> Model Class Initialized
INFO - 2016-11-13 02:30:55 --> Form Validation Class Initialized
INFO - 2016-11-13 02:30:55 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-13 02:30:55 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-13 02:30:55 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-26', '3', '2', '2016-11-13 02:30:55', '1', '')
INFO - 2016-11-13 02:30:55 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-13 02:31:34 --> Config Class Initialized
INFO - 2016-11-13 02:31:34 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:31:34 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:31:34 --> Utf8 Class Initialized
INFO - 2016-11-13 02:31:34 --> URI Class Initialized
DEBUG - 2016-11-13 02:31:34 --> No URI present. Default controller set.
INFO - 2016-11-13 02:31:34 --> Router Class Initialized
INFO - 2016-11-13 02:31:34 --> Output Class Initialized
INFO - 2016-11-13 02:31:34 --> Security Class Initialized
DEBUG - 2016-11-13 02:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:31:34 --> Input Class Initialized
INFO - 2016-11-13 02:31:34 --> Language Class Initialized
INFO - 2016-11-13 02:31:34 --> Loader Class Initialized
INFO - 2016-11-13 02:31:34 --> Helper loaded: url_helper
INFO - 2016-11-13 02:31:34 --> Helper loaded: form_helper
INFO - 2016-11-13 02:31:34 --> Database Driver Class Initialized
INFO - 2016-11-13 02:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:31:34 --> Controller Class Initialized
INFO - 2016-11-13 02:31:34 --> Model Class Initialized
INFO - 2016-11-13 02:31:34 --> Model Class Initialized
INFO - 2016-11-13 02:31:34 --> Model Class Initialized
INFO - 2016-11-13 02:31:34 --> Model Class Initialized
INFO - 2016-11-13 02:31:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:31:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:31:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:31:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:31:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:31:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:31:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:31:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:31:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:31:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:31:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:31:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:31:35 --> Final output sent to browser
DEBUG - 2016-11-13 02:31:35 --> Total execution time: 0.6595
INFO - 2016-11-13 02:31:44 --> Config Class Initialized
INFO - 2016-11-13 02:31:44 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:31:44 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:31:44 --> Utf8 Class Initialized
INFO - 2016-11-13 02:31:44 --> URI Class Initialized
INFO - 2016-11-13 02:31:44 --> Router Class Initialized
INFO - 2016-11-13 02:31:44 --> Output Class Initialized
INFO - 2016-11-13 02:31:44 --> Security Class Initialized
DEBUG - 2016-11-13 02:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:31:44 --> Input Class Initialized
INFO - 2016-11-13 02:31:44 --> Language Class Initialized
INFO - 2016-11-13 02:31:44 --> Loader Class Initialized
INFO - 2016-11-13 02:31:44 --> Helper loaded: url_helper
INFO - 2016-11-13 02:31:44 --> Helper loaded: form_helper
INFO - 2016-11-13 02:31:44 --> Database Driver Class Initialized
INFO - 2016-11-13 02:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:31:44 --> Controller Class Initialized
INFO - 2016-11-13 02:31:44 --> Model Class Initialized
INFO - 2016-11-13 02:31:44 --> Form Validation Class Initialized
INFO - 2016-11-13 02:31:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:31:44 --> Final output sent to browser
DEBUG - 2016-11-13 02:31:44 --> Total execution time: 0.3405
INFO - 2016-11-13 02:31:52 --> Config Class Initialized
INFO - 2016-11-13 02:31:52 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:31:52 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:31:52 --> Utf8 Class Initialized
INFO - 2016-11-13 02:31:52 --> URI Class Initialized
INFO - 2016-11-13 02:31:52 --> Router Class Initialized
INFO - 2016-11-13 02:31:52 --> Output Class Initialized
INFO - 2016-11-13 02:31:52 --> Security Class Initialized
DEBUG - 2016-11-13 02:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:31:53 --> Input Class Initialized
INFO - 2016-11-13 02:31:53 --> Language Class Initialized
INFO - 2016-11-13 02:31:53 --> Loader Class Initialized
INFO - 2016-11-13 02:31:53 --> Helper loaded: url_helper
INFO - 2016-11-13 02:31:53 --> Helper loaded: form_helper
INFO - 2016-11-13 02:31:53 --> Database Driver Class Initialized
INFO - 2016-11-13 02:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:31:53 --> Controller Class Initialized
INFO - 2016-11-13 02:31:53 --> Model Class Initialized
INFO - 2016-11-13 02:31:53 --> Form Validation Class Initialized
INFO - 2016-11-13 02:31:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:31:53 --> Final output sent to browser
DEBUG - 2016-11-13 02:31:53 --> Total execution time: 0.3526
INFO - 2016-11-13 02:31:58 --> Config Class Initialized
INFO - 2016-11-13 02:31:58 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:31:58 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:31:58 --> Utf8 Class Initialized
INFO - 2016-11-13 02:31:58 --> URI Class Initialized
INFO - 2016-11-13 02:31:58 --> Router Class Initialized
INFO - 2016-11-13 02:31:58 --> Output Class Initialized
INFO - 2016-11-13 02:31:58 --> Security Class Initialized
DEBUG - 2016-11-13 02:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:31:58 --> Input Class Initialized
INFO - 2016-11-13 02:31:58 --> Language Class Initialized
INFO - 2016-11-13 02:31:58 --> Loader Class Initialized
INFO - 2016-11-13 02:31:58 --> Helper loaded: url_helper
INFO - 2016-11-13 02:31:58 --> Helper loaded: form_helper
INFO - 2016-11-13 02:31:58 --> Database Driver Class Initialized
INFO - 2016-11-13 02:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:31:58 --> Controller Class Initialized
INFO - 2016-11-13 02:31:58 --> Model Class Initialized
INFO - 2016-11-13 02:31:58 --> Form Validation Class Initialized
INFO - 2016-11-13 02:31:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:31:58 --> Final output sent to browser
DEBUG - 2016-11-13 02:31:58 --> Total execution time: 0.3631
INFO - 2016-11-13 02:32:02 --> Config Class Initialized
INFO - 2016-11-13 02:32:02 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:32:02 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:02 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:02 --> URI Class Initialized
INFO - 2016-11-13 02:32:02 --> Router Class Initialized
INFO - 2016-11-13 02:32:02 --> Output Class Initialized
INFO - 2016-11-13 02:32:02 --> Security Class Initialized
DEBUG - 2016-11-13 02:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:02 --> Input Class Initialized
INFO - 2016-11-13 02:32:02 --> Language Class Initialized
INFO - 2016-11-13 02:32:02 --> Loader Class Initialized
INFO - 2016-11-13 02:32:02 --> Helper loaded: url_helper
INFO - 2016-11-13 02:32:02 --> Helper loaded: form_helper
INFO - 2016-11-13 02:32:02 --> Database Driver Class Initialized
INFO - 2016-11-13 02:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:02 --> Controller Class Initialized
INFO - 2016-11-13 02:32:02 --> Model Class Initialized
INFO - 2016-11-13 02:32:02 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:02 --> Final output sent to browser
DEBUG - 2016-11-13 02:32:02 --> Total execution time: 0.3515
INFO - 2016-11-13 02:32:02 --> Config Class Initialized
INFO - 2016-11-13 02:32:02 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:32:02 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:02 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:02 --> URI Class Initialized
INFO - 2016-11-13 02:32:02 --> Router Class Initialized
INFO - 2016-11-13 02:32:02 --> Output Class Initialized
INFO - 2016-11-13 02:32:02 --> Security Class Initialized
DEBUG - 2016-11-13 02:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:02 --> Input Class Initialized
INFO - 2016-11-13 02:32:02 --> Language Class Initialized
INFO - 2016-11-13 02:32:02 --> Loader Class Initialized
INFO - 2016-11-13 02:32:02 --> Helper loaded: url_helper
INFO - 2016-11-13 02:32:02 --> Helper loaded: form_helper
INFO - 2016-11-13 02:32:02 --> Database Driver Class Initialized
INFO - 2016-11-13 02:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:03 --> Controller Class Initialized
INFO - 2016-11-13 02:32:03 --> Model Class Initialized
INFO - 2016-11-13 02:32:03 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:03 --> Final output sent to browser
DEBUG - 2016-11-13 02:32:03 --> Total execution time: 0.3552
INFO - 2016-11-13 02:32:08 --> Config Class Initialized
INFO - 2016-11-13 02:32:08 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:32:08 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:08 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:09 --> URI Class Initialized
INFO - 2016-11-13 02:32:09 --> Router Class Initialized
INFO - 2016-11-13 02:32:09 --> Output Class Initialized
INFO - 2016-11-13 02:32:09 --> Security Class Initialized
DEBUG - 2016-11-13 02:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:09 --> Input Class Initialized
INFO - 2016-11-13 02:32:09 --> Language Class Initialized
INFO - 2016-11-13 02:32:09 --> Loader Class Initialized
INFO - 2016-11-13 02:32:09 --> Helper loaded: url_helper
INFO - 2016-11-13 02:32:09 --> Helper loaded: form_helper
INFO - 2016-11-13 02:32:09 --> Database Driver Class Initialized
INFO - 2016-11-13 02:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:09 --> Controller Class Initialized
INFO - 2016-11-13 02:32:09 --> Model Class Initialized
INFO - 2016-11-13 02:32:09 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:09 --> Final output sent to browser
DEBUG - 2016-11-13 02:32:09 --> Total execution time: 0.3580
INFO - 2016-11-13 02:32:09 --> Config Class Initialized
INFO - 2016-11-13 02:32:09 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:32:09 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:09 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:09 --> URI Class Initialized
INFO - 2016-11-13 02:32:09 --> Router Class Initialized
INFO - 2016-11-13 02:32:09 --> Output Class Initialized
INFO - 2016-11-13 02:32:09 --> Security Class Initialized
DEBUG - 2016-11-13 02:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:09 --> Input Class Initialized
INFO - 2016-11-13 02:32:09 --> Language Class Initialized
INFO - 2016-11-13 02:32:09 --> Config Class Initialized
INFO - 2016-11-13 02:32:09 --> Loader Class Initialized
INFO - 2016-11-13 02:32:09 --> Hooks Class Initialized
INFO - 2016-11-13 02:32:09 --> Helper loaded: url_helper
DEBUG - 2016-11-13 02:32:09 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:09 --> Helper loaded: form_helper
INFO - 2016-11-13 02:32:09 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:09 --> URI Class Initialized
INFO - 2016-11-13 02:32:09 --> Database Driver Class Initialized
INFO - 2016-11-13 02:32:09 --> Router Class Initialized
INFO - 2016-11-13 02:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:09 --> Controller Class Initialized
INFO - 2016-11-13 02:32:09 --> Output Class Initialized
INFO - 2016-11-13 02:32:10 --> Config Class Initialized
INFO - 2016-11-13 02:32:10 --> Security Class Initialized
INFO - 2016-11-13 02:32:10 --> Model Class Initialized
INFO - 2016-11-13 02:32:10 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-13 02:32:10 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:10 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:10 --> Input Class Initialized
INFO - 2016-11-13 02:32:10 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:10 --> Language Class Initialized
INFO - 2016-11-13 02:32:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:10 --> URI Class Initialized
INFO - 2016-11-13 02:32:10 --> Loader Class Initialized
INFO - 2016-11-13 02:32:10 --> Final output sent to browser
INFO - 2016-11-13 02:32:10 --> Router Class Initialized
DEBUG - 2016-11-13 02:32:10 --> Total execution time: 0.4721
INFO - 2016-11-13 02:32:10 --> Config Class Initialized
INFO - 2016-11-13 02:32:10 --> Helper loaded: url_helper
INFO - 2016-11-13 02:32:10 --> Output Class Initialized
INFO - 2016-11-13 02:32:10 --> Hooks Class Initialized
INFO - 2016-11-13 02:32:10 --> Helper loaded: form_helper
DEBUG - 2016-11-13 02:32:10 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:10 --> Security Class Initialized
INFO - 2016-11-13 02:32:10 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:10 --> Database Driver Class Initialized
DEBUG - 2016-11-13 02:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:10 --> URI Class Initialized
INFO - 2016-11-13 02:32:10 --> Input Class Initialized
INFO - 2016-11-13 02:32:10 --> Controller Class Initialized
INFO - 2016-11-13 02:32:10 --> Router Class Initialized
INFO - 2016-11-13 02:32:10 --> Language Class Initialized
INFO - 2016-11-13 02:32:10 --> Model Class Initialized
INFO - 2016-11-13 02:32:10 --> Config Class Initialized
INFO - 2016-11-13 02:32:10 --> Output Class Initialized
INFO - 2016-11-13 02:32:10 --> Loader Class Initialized
INFO - 2016-11-13 02:32:10 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:10 --> Hooks Class Initialized
INFO - 2016-11-13 02:32:10 --> Security Class Initialized
INFO - 2016-11-13 02:32:10 --> Helper loaded: url_helper
DEBUG - 2016-11-13 02:32:10 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:10 --> Helper loaded: form_helper
DEBUG - 2016-11-13 02:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:10 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:10 --> Input Class Initialized
INFO - 2016-11-13 02:32:10 --> Final output sent to browser
INFO - 2016-11-13 02:32:10 --> URI Class Initialized
INFO - 2016-11-13 02:32:10 --> Database Driver Class Initialized
DEBUG - 2016-11-13 02:32:10 --> Total execution time: 0.5802
INFO - 2016-11-13 02:32:10 --> Language Class Initialized
INFO - 2016-11-13 02:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:10 --> Router Class Initialized
INFO - 2016-11-13 02:32:10 --> Loader Class Initialized
INFO - 2016-11-13 02:32:10 --> Controller Class Initialized
INFO - 2016-11-13 02:32:10 --> Output Class Initialized
INFO - 2016-11-13 02:32:10 --> Config Class Initialized
INFO - 2016-11-13 02:32:10 --> Helper loaded: url_helper
INFO - 2016-11-13 02:32:10 --> Security Class Initialized
INFO - 2016-11-13 02:32:10 --> Model Class Initialized
INFO - 2016-11-13 02:32:10 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:10 --> Helper loaded: form_helper
INFO - 2016-11-13 02:32:10 --> Form Validation Class Initialized
DEBUG - 2016-11-13 02:32:10 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:10 --> Input Class Initialized
INFO - 2016-11-13 02:32:10 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:10 --> Database Driver Class Initialized
INFO - 2016-11-13 02:32:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:10 --> Language Class Initialized
INFO - 2016-11-13 02:32:10 --> URI Class Initialized
INFO - 2016-11-13 02:32:10 --> Final output sent to browser
INFO - 2016-11-13 02:32:10 --> Loader Class Initialized
INFO - 2016-11-13 02:32:10 --> Config Class Initialized
INFO - 2016-11-13 02:32:10 --> Router Class Initialized
INFO - 2016-11-13 02:32:10 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:32:10 --> Total execution time: 0.6332
INFO - 2016-11-13 02:32:10 --> Helper loaded: url_helper
INFO - 2016-11-13 02:32:10 --> Output Class Initialized
INFO - 2016-11-13 02:32:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-13 02:32:10 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:10 --> Helper loaded: form_helper
INFO - 2016-11-13 02:32:10 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:10 --> Security Class Initialized
INFO - 2016-11-13 02:32:10 --> Controller Class Initialized
INFO - 2016-11-13 02:32:10 --> Database Driver Class Initialized
INFO - 2016-11-13 02:32:10 --> URI Class Initialized
INFO - 2016-11-13 02:32:10 --> Model Class Initialized
DEBUG - 2016-11-13 02:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:10 --> Input Class Initialized
INFO - 2016-11-13 02:32:10 --> Router Class Initialized
INFO - 2016-11-13 02:32:10 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:10 --> Language Class Initialized
INFO - 2016-11-13 02:32:10 --> Config Class Initialized
INFO - 2016-11-13 02:32:10 --> Output Class Initialized
INFO - 2016-11-13 02:32:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:10 --> Loader Class Initialized
INFO - 2016-11-13 02:32:10 --> Hooks Class Initialized
INFO - 2016-11-13 02:32:10 --> Security Class Initialized
INFO - 2016-11-13 02:32:10 --> Final output sent to browser
DEBUG - 2016-11-13 02:32:10 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:10 --> Helper loaded: url_helper
DEBUG - 2016-11-13 02:32:10 --> Total execution time: 0.7208
INFO - 2016-11-13 02:32:10 --> Utf8 Class Initialized
DEBUG - 2016-11-13 02:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:10 --> Input Class Initialized
INFO - 2016-11-13 02:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:10 --> Helper loaded: form_helper
INFO - 2016-11-13 02:32:10 --> URI Class Initialized
INFO - 2016-11-13 02:32:10 --> Controller Class Initialized
INFO - 2016-11-13 02:32:10 --> Database Driver Class Initialized
INFO - 2016-11-13 02:32:10 --> Language Class Initialized
INFO - 2016-11-13 02:32:11 --> Router Class Initialized
INFO - 2016-11-13 02:32:11 --> Model Class Initialized
INFO - 2016-11-13 02:32:11 --> Config Class Initialized
INFO - 2016-11-13 02:32:11 --> Loader Class Initialized
INFO - 2016-11-13 02:32:11 --> Hooks Class Initialized
INFO - 2016-11-13 02:32:11 --> Output Class Initialized
INFO - 2016-11-13 02:32:11 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:11 --> Helper loaded: url_helper
INFO - 2016-11-13 02:32:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-13 02:32:11 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:11 --> Security Class Initialized
INFO - 2016-11-13 02:32:11 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:11 --> Helper loaded: form_helper
DEBUG - 2016-11-13 02:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:11 --> Final output sent to browser
INFO - 2016-11-13 02:32:11 --> Database Driver Class Initialized
INFO - 2016-11-13 02:32:11 --> URI Class Initialized
DEBUG - 2016-11-13 02:32:11 --> Total execution time: 0.7693
INFO - 2016-11-13 02:32:11 --> Input Class Initialized
INFO - 2016-11-13 02:32:11 --> Router Class Initialized
INFO - 2016-11-13 02:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:11 --> Config Class Initialized
INFO - 2016-11-13 02:32:11 --> Language Class Initialized
INFO - 2016-11-13 02:32:11 --> Controller Class Initialized
INFO - 2016-11-13 02:32:11 --> Hooks Class Initialized
INFO - 2016-11-13 02:32:11 --> Output Class Initialized
INFO - 2016-11-13 02:32:11 --> Model Class Initialized
INFO - 2016-11-13 02:32:11 --> Loader Class Initialized
INFO - 2016-11-13 02:32:11 --> Security Class Initialized
DEBUG - 2016-11-13 02:32:11 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:11 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:11 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:11 --> Helper loaded: url_helper
DEBUG - 2016-11-13 02:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:11 --> URI Class Initialized
INFO - 2016-11-13 02:32:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:11 --> Helper loaded: form_helper
INFO - 2016-11-13 02:32:11 --> Input Class Initialized
INFO - 2016-11-13 02:32:11 --> Final output sent to browser
INFO - 2016-11-13 02:32:11 --> Router Class Initialized
INFO - 2016-11-13 02:32:11 --> Database Driver Class Initialized
DEBUG - 2016-11-13 02:32:11 --> Total execution time: 0.7970
INFO - 2016-11-13 02:32:11 --> Language Class Initialized
INFO - 2016-11-13 02:32:11 --> Config Class Initialized
INFO - 2016-11-13 02:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:11 --> Controller Class Initialized
INFO - 2016-11-13 02:32:11 --> Hooks Class Initialized
INFO - 2016-11-13 02:32:11 --> Loader Class Initialized
INFO - 2016-11-13 02:32:11 --> Output Class Initialized
INFO - 2016-11-13 02:32:11 --> Model Class Initialized
DEBUG - 2016-11-13 02:32:11 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:11 --> Security Class Initialized
INFO - 2016-11-13 02:32:11 --> Helper loaded: url_helper
INFO - 2016-11-13 02:32:11 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:11 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:11 --> Helper loaded: form_helper
DEBUG - 2016-11-13 02:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:11 --> Input Class Initialized
INFO - 2016-11-13 02:32:11 --> Database Driver Class Initialized
INFO - 2016-11-13 02:32:11 --> URI Class Initialized
INFO - 2016-11-13 02:32:11 --> Language Class Initialized
INFO - 2016-11-13 02:32:11 --> Config Class Initialized
INFO - 2016-11-13 02:32:11 --> Final output sent to browser
INFO - 2016-11-13 02:32:11 --> Loader Class Initialized
INFO - 2016-11-13 02:32:11 --> Hooks Class Initialized
INFO - 2016-11-13 02:32:11 --> Router Class Initialized
DEBUG - 2016-11-13 02:32:11 --> Total execution time: 0.8092
INFO - 2016-11-13 02:32:11 --> Helper loaded: url_helper
DEBUG - 2016-11-13 02:32:11 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:11 --> Output Class Initialized
INFO - 2016-11-13 02:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:11 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:11 --> Helper loaded: form_helper
INFO - 2016-11-13 02:32:11 --> Controller Class Initialized
INFO - 2016-11-13 02:32:11 --> Security Class Initialized
INFO - 2016-11-13 02:32:11 --> Model Class Initialized
INFO - 2016-11-13 02:32:11 --> URI Class Initialized
INFO - 2016-11-13 02:32:11 --> Database Driver Class Initialized
DEBUG - 2016-11-13 02:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:11 --> Router Class Initialized
INFO - 2016-11-13 02:32:11 --> Config Class Initialized
INFO - 2016-11-13 02:32:11 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:11 --> Input Class Initialized
INFO - 2016-11-13 02:32:11 --> Hooks Class Initialized
INFO - 2016-11-13 02:32:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:11 --> Output Class Initialized
INFO - 2016-11-13 02:32:11 --> Language Class Initialized
DEBUG - 2016-11-13 02:32:11 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:11 --> Final output sent to browser
INFO - 2016-11-13 02:32:11 --> Security Class Initialized
INFO - 2016-11-13 02:32:11 --> Loader Class Initialized
INFO - 2016-11-13 02:32:11 --> Utf8 Class Initialized
DEBUG - 2016-11-13 02:32:11 --> Total execution time: 0.8768
INFO - 2016-11-13 02:32:11 --> URI Class Initialized
DEBUG - 2016-11-13 02:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:11 --> Helper loaded: url_helper
INFO - 2016-11-13 02:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:11 --> Input Class Initialized
INFO - 2016-11-13 02:32:11 --> Router Class Initialized
INFO - 2016-11-13 02:32:11 --> Helper loaded: form_helper
INFO - 2016-11-13 02:32:11 --> Controller Class Initialized
INFO - 2016-11-13 02:32:11 --> Language Class Initialized
INFO - 2016-11-13 02:32:11 --> Config Class Initialized
INFO - 2016-11-13 02:32:11 --> Database Driver Class Initialized
INFO - 2016-11-13 02:32:11 --> Output Class Initialized
INFO - 2016-11-13 02:32:11 --> Model Class Initialized
INFO - 2016-11-13 02:32:11 --> Hooks Class Initialized
INFO - 2016-11-13 02:32:11 --> Loader Class Initialized
INFO - 2016-11-13 02:32:11 --> Security Class Initialized
INFO - 2016-11-13 02:32:11 --> Form Validation Class Initialized
DEBUG - 2016-11-13 02:32:11 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:11 --> Helper loaded: url_helper
INFO - 2016-11-13 02:32:11 --> Utf8 Class Initialized
DEBUG - 2016-11-13 02:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:11 --> Input Class Initialized
INFO - 2016-11-13 02:32:11 --> Helper loaded: form_helper
INFO - 2016-11-13 02:32:11 --> URI Class Initialized
INFO - 2016-11-13 02:32:11 --> Final output sent to browser
INFO - 2016-11-13 02:32:11 --> Database Driver Class Initialized
INFO - 2016-11-13 02:32:11 --> Language Class Initialized
DEBUG - 2016-11-13 02:32:11 --> Total execution time: 0.9506
INFO - 2016-11-13 02:32:12 --> Router Class Initialized
INFO - 2016-11-13 02:32:12 --> Loader Class Initialized
INFO - 2016-11-13 02:32:12 --> Config Class Initialized
INFO - 2016-11-13 02:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:12 --> Output Class Initialized
INFO - 2016-11-13 02:32:12 --> Controller Class Initialized
INFO - 2016-11-13 02:32:12 --> Hooks Class Initialized
INFO - 2016-11-13 02:32:12 --> Helper loaded: url_helper
INFO - 2016-11-13 02:32:12 --> Model Class Initialized
INFO - 2016-11-13 02:32:12 --> Security Class Initialized
DEBUG - 2016-11-13 02:32:12 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:12 --> Helper loaded: form_helper
INFO - 2016-11-13 02:32:12 --> Utf8 Class Initialized
DEBUG - 2016-11-13 02:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:12 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:12 --> URI Class Initialized
INFO - 2016-11-13 02:32:12 --> Database Driver Class Initialized
INFO - 2016-11-13 02:32:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:12 --> Input Class Initialized
INFO - 2016-11-13 02:32:12 --> Router Class Initialized
INFO - 2016-11-13 02:32:12 --> Language Class Initialized
INFO - 2016-11-13 02:32:12 --> Final output sent to browser
DEBUG - 2016-11-13 02:32:12 --> Total execution time: 1.0100
INFO - 2016-11-13 02:32:12 --> Output Class Initialized
INFO - 2016-11-13 02:32:12 --> Loader Class Initialized
INFO - 2016-11-13 02:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:12 --> Config Class Initialized
INFO - 2016-11-13 02:32:12 --> Security Class Initialized
INFO - 2016-11-13 02:32:12 --> Helper loaded: url_helper
INFO - 2016-11-13 02:32:12 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:12 --> Controller Class Initialized
INFO - 2016-11-13 02:32:12 --> Helper loaded: form_helper
DEBUG - 2016-11-13 02:32:12 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:12 --> Input Class Initialized
INFO - 2016-11-13 02:32:12 --> Model Class Initialized
INFO - 2016-11-13 02:32:12 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:12 --> Database Driver Class Initialized
INFO - 2016-11-13 02:32:12 --> Language Class Initialized
INFO - 2016-11-13 02:32:12 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:12 --> URI Class Initialized
INFO - 2016-11-13 02:32:12 --> Loader Class Initialized
INFO - 2016-11-13 02:32:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:12 --> Router Class Initialized
INFO - 2016-11-13 02:32:12 --> Helper loaded: url_helper
INFO - 2016-11-13 02:32:12 --> Output Class Initialized
INFO - 2016-11-13 02:32:12 --> Final output sent to browser
INFO - 2016-11-13 02:32:12 --> Helper loaded: form_helper
DEBUG - 2016-11-13 02:32:12 --> Total execution time: 1.0708
INFO - 2016-11-13 02:32:12 --> Security Class Initialized
INFO - 2016-11-13 02:32:12 --> Database Driver Class Initialized
INFO - 2016-11-13 02:32:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-13 02:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:12 --> Controller Class Initialized
INFO - 2016-11-13 02:32:12 --> Input Class Initialized
INFO - 2016-11-13 02:32:12 --> Config Class Initialized
INFO - 2016-11-13 02:32:12 --> Model Class Initialized
INFO - 2016-11-13 02:32:12 --> Hooks Class Initialized
INFO - 2016-11-13 02:32:12 --> Language Class Initialized
INFO - 2016-11-13 02:32:12 --> Form Validation Class Initialized
DEBUG - 2016-11-13 02:32:12 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:12 --> Loader Class Initialized
INFO - 2016-11-13 02:32:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:12 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:12 --> Helper loaded: url_helper
INFO - 2016-11-13 02:32:12 --> URI Class Initialized
INFO - 2016-11-13 02:32:12 --> Final output sent to browser
INFO - 2016-11-13 02:32:12 --> Helper loaded: form_helper
DEBUG - 2016-11-13 02:32:12 --> Total execution time: 1.1270
INFO - 2016-11-13 02:32:12 --> Router Class Initialized
INFO - 2016-11-13 02:32:12 --> Database Driver Class Initialized
INFO - 2016-11-13 02:32:12 --> Config Class Initialized
INFO - 2016-11-13 02:32:12 --> Output Class Initialized
INFO - 2016-11-13 02:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:12 --> Hooks Class Initialized
INFO - 2016-11-13 02:32:12 --> Controller Class Initialized
INFO - 2016-11-13 02:32:12 --> Security Class Initialized
DEBUG - 2016-11-13 02:32:12 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:12 --> Model Class Initialized
DEBUG - 2016-11-13 02:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:12 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:12 --> Input Class Initialized
INFO - 2016-11-13 02:32:12 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:12 --> URI Class Initialized
INFO - 2016-11-13 02:32:12 --> Language Class Initialized
INFO - 2016-11-13 02:32:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:12 --> Router Class Initialized
INFO - 2016-11-13 02:32:12 --> Final output sent to browser
INFO - 2016-11-13 02:32:12 --> Loader Class Initialized
INFO - 2016-11-13 02:32:12 --> Output Class Initialized
DEBUG - 2016-11-13 02:32:12 --> Total execution time: 1.2002
INFO - 2016-11-13 02:32:12 --> Helper loaded: url_helper
INFO - 2016-11-13 02:32:12 --> Security Class Initialized
INFO - 2016-11-13 02:32:12 --> Config Class Initialized
INFO - 2016-11-13 02:32:12 --> Helper loaded: form_helper
INFO - 2016-11-13 02:32:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-13 02:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:12 --> Hooks Class Initialized
INFO - 2016-11-13 02:32:13 --> Input Class Initialized
INFO - 2016-11-13 02:32:13 --> Database Driver Class Initialized
INFO - 2016-11-13 02:32:13 --> Controller Class Initialized
DEBUG - 2016-11-13 02:32:13 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:13 --> Language Class Initialized
INFO - 2016-11-13 02:32:13 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:13 --> Model Class Initialized
INFO - 2016-11-13 02:32:13 --> URI Class Initialized
INFO - 2016-11-13 02:32:13 --> Loader Class Initialized
INFO - 2016-11-13 02:32:13 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:13 --> Router Class Initialized
INFO - 2016-11-13 02:32:13 --> Helper loaded: url_helper
INFO - 2016-11-13 02:32:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:13 --> Output Class Initialized
INFO - 2016-11-13 02:32:13 --> Helper loaded: form_helper
INFO - 2016-11-13 02:32:13 --> Final output sent to browser
INFO - 2016-11-13 02:32:13 --> Security Class Initialized
DEBUG - 2016-11-13 02:32:13 --> Total execution time: 1.2768
INFO - 2016-11-13 02:32:13 --> Database Driver Class Initialized
INFO - 2016-11-13 02:32:13 --> Config Class Initialized
INFO - 2016-11-13 02:32:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-13 02:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:13 --> Input Class Initialized
INFO - 2016-11-13 02:32:13 --> Hooks Class Initialized
INFO - 2016-11-13 02:32:13 --> Controller Class Initialized
INFO - 2016-11-13 02:32:13 --> Language Class Initialized
INFO - 2016-11-13 02:32:13 --> Model Class Initialized
DEBUG - 2016-11-13 02:32:13 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:13 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:13 --> Loader Class Initialized
INFO - 2016-11-13 02:32:13 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:13 --> Helper loaded: url_helper
INFO - 2016-11-13 02:32:13 --> URI Class Initialized
INFO - 2016-11-13 02:32:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:13 --> Helper loaded: form_helper
INFO - 2016-11-13 02:32:13 --> Router Class Initialized
INFO - 2016-11-13 02:32:13 --> Final output sent to browser
INFO - 2016-11-13 02:32:13 --> Output Class Initialized
INFO - 2016-11-13 02:32:13 --> Database Driver Class Initialized
DEBUG - 2016-11-13 02:32:13 --> Total execution time: 1.3145
INFO - 2016-11-13 02:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:13 --> Config Class Initialized
INFO - 2016-11-13 02:32:13 --> Security Class Initialized
INFO - 2016-11-13 02:32:13 --> Controller Class Initialized
INFO - 2016-11-13 02:32:13 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:13 --> Model Class Initialized
DEBUG - 2016-11-13 02:32:13 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:13 --> Input Class Initialized
INFO - 2016-11-13 02:32:13 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:13 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:13 --> Language Class Initialized
INFO - 2016-11-13 02:32:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:13 --> URI Class Initialized
INFO - 2016-11-13 02:32:13 --> Loader Class Initialized
INFO - 2016-11-13 02:32:13 --> Final output sent to browser
INFO - 2016-11-13 02:32:13 --> Router Class Initialized
INFO - 2016-11-13 02:32:13 --> Helper loaded: url_helper
DEBUG - 2016-11-13 02:32:13 --> Total execution time: 1.2903
INFO - 2016-11-13 02:32:13 --> Output Class Initialized
INFO - 2016-11-13 02:32:13 --> Helper loaded: form_helper
INFO - 2016-11-13 02:32:13 --> Config Class Initialized
INFO - 2016-11-13 02:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:13 --> Security Class Initialized
INFO - 2016-11-13 02:32:13 --> Hooks Class Initialized
INFO - 2016-11-13 02:32:13 --> Controller Class Initialized
INFO - 2016-11-13 02:32:13 --> Database Driver Class Initialized
DEBUG - 2016-11-13 02:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:13 --> Model Class Initialized
DEBUG - 2016-11-13 02:32:13 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:13 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:13 --> Input Class Initialized
INFO - 2016-11-13 02:32:13 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:13 --> URI Class Initialized
INFO - 2016-11-13 02:32:13 --> Language Class Initialized
INFO - 2016-11-13 02:32:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:13 --> Router Class Initialized
INFO - 2016-11-13 02:32:13 --> Loader Class Initialized
INFO - 2016-11-13 02:32:13 --> Final output sent to browser
INFO - 2016-11-13 02:32:13 --> Output Class Initialized
INFO - 2016-11-13 02:32:13 --> Helper loaded: url_helper
DEBUG - 2016-11-13 02:32:13 --> Total execution time: 1.2149
INFO - 2016-11-13 02:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:13 --> Config Class Initialized
INFO - 2016-11-13 02:32:13 --> Controller Class Initialized
INFO - 2016-11-13 02:32:13 --> Security Class Initialized
INFO - 2016-11-13 02:32:13 --> Helper loaded: form_helper
INFO - 2016-11-13 02:32:13 --> Hooks Class Initialized
INFO - 2016-11-13 02:32:13 --> Database Driver Class Initialized
DEBUG - 2016-11-13 02:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:13 --> Model Class Initialized
DEBUG - 2016-11-13 02:32:13 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:13 --> Input Class Initialized
INFO - 2016-11-13 02:32:13 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:13 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:13 --> Language Class Initialized
INFO - 2016-11-13 02:32:13 --> URI Class Initialized
INFO - 2016-11-13 02:32:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:13 --> Loader Class Initialized
INFO - 2016-11-13 02:32:13 --> Router Class Initialized
INFO - 2016-11-13 02:32:13 --> Final output sent to browser
DEBUG - 2016-11-13 02:32:14 --> Total execution time: 1.2459
INFO - 2016-11-13 02:32:14 --> Helper loaded: url_helper
INFO - 2016-11-13 02:32:14 --> Output Class Initialized
INFO - 2016-11-13 02:32:14 --> Config Class Initialized
INFO - 2016-11-13 02:32:14 --> Helper loaded: form_helper
INFO - 2016-11-13 02:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:14 --> Security Class Initialized
INFO - 2016-11-13 02:32:14 --> Hooks Class Initialized
INFO - 2016-11-13 02:32:14 --> Database Driver Class Initialized
INFO - 2016-11-13 02:32:14 --> Controller Class Initialized
DEBUG - 2016-11-13 02:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-13 02:32:14 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:14 --> Model Class Initialized
INFO - 2016-11-13 02:32:14 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:14 --> Input Class Initialized
INFO - 2016-11-13 02:32:14 --> Language Class Initialized
INFO - 2016-11-13 02:32:14 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:14 --> URI Class Initialized
INFO - 2016-11-13 02:32:14 --> Loader Class Initialized
INFO - 2016-11-13 02:32:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:14 --> Router Class Initialized
INFO - 2016-11-13 02:32:14 --> Helper loaded: url_helper
INFO - 2016-11-13 02:32:14 --> Output Class Initialized
INFO - 2016-11-13 02:32:14 --> Final output sent to browser
INFO - 2016-11-13 02:32:14 --> Helper loaded: form_helper
DEBUG - 2016-11-13 02:32:14 --> Total execution time: 1.2507
INFO - 2016-11-13 02:32:14 --> Security Class Initialized
INFO - 2016-11-13 02:32:14 --> Config Class Initialized
INFO - 2016-11-13 02:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:14 --> Database Driver Class Initialized
DEBUG - 2016-11-13 02:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:14 --> Hooks Class Initialized
INFO - 2016-11-13 02:32:14 --> Controller Class Initialized
INFO - 2016-11-13 02:32:14 --> Input Class Initialized
DEBUG - 2016-11-13 02:32:14 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:14 --> Model Class Initialized
INFO - 2016-11-13 02:32:14 --> Language Class Initialized
INFO - 2016-11-13 02:32:14 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:14 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:14 --> URI Class Initialized
INFO - 2016-11-13 02:32:14 --> Loader Class Initialized
INFO - 2016-11-13 02:32:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:14 --> Helper loaded: url_helper
INFO - 2016-11-13 02:32:14 --> Router Class Initialized
INFO - 2016-11-13 02:32:14 --> Final output sent to browser
INFO - 2016-11-13 02:32:14 --> Helper loaded: form_helper
INFO - 2016-11-13 02:32:14 --> Output Class Initialized
DEBUG - 2016-11-13 02:32:14 --> Total execution time: 1.2280
INFO - 2016-11-13 02:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:14 --> Config Class Initialized
INFO - 2016-11-13 02:32:14 --> Database Driver Class Initialized
INFO - 2016-11-13 02:32:14 --> Security Class Initialized
INFO - 2016-11-13 02:32:14 --> Controller Class Initialized
INFO - 2016-11-13 02:32:14 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:14 --> Model Class Initialized
DEBUG - 2016-11-13 02:32:14 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:14 --> Input Class Initialized
INFO - 2016-11-13 02:32:14 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:14 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:14 --> Language Class Initialized
INFO - 2016-11-13 02:32:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:14 --> URI Class Initialized
INFO - 2016-11-13 02:32:14 --> Loader Class Initialized
INFO - 2016-11-13 02:32:14 --> Router Class Initialized
INFO - 2016-11-13 02:32:14 --> Final output sent to browser
DEBUG - 2016-11-13 02:32:14 --> Total execution time: 1.2123
INFO - 2016-11-13 02:32:14 --> Helper loaded: url_helper
INFO - 2016-11-13 02:32:14 --> Output Class Initialized
INFO - 2016-11-13 02:32:14 --> Helper loaded: form_helper
INFO - 2016-11-13 02:32:14 --> Config Class Initialized
INFO - 2016-11-13 02:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:14 --> Hooks Class Initialized
INFO - 2016-11-13 02:32:14 --> Security Class Initialized
INFO - 2016-11-13 02:32:14 --> Controller Class Initialized
INFO - 2016-11-13 02:32:14 --> Database Driver Class Initialized
INFO - 2016-11-13 02:32:14 --> Model Class Initialized
DEBUG - 2016-11-13 02:32:14 --> UTF-8 Support Enabled
DEBUG - 2016-11-13 02:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:14 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:14 --> Input Class Initialized
INFO - 2016-11-13 02:32:14 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:14 --> URI Class Initialized
INFO - 2016-11-13 02:32:14 --> Language Class Initialized
INFO - 2016-11-13 02:32:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:14 --> Loader Class Initialized
INFO - 2016-11-13 02:32:14 --> Router Class Initialized
INFO - 2016-11-13 02:32:14 --> Final output sent to browser
INFO - 2016-11-13 02:32:14 --> Output Class Initialized
INFO - 2016-11-13 02:32:14 --> Helper loaded: url_helper
DEBUG - 2016-11-13 02:32:14 --> Total execution time: 1.2353
INFO - 2016-11-13 02:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:14 --> Config Class Initialized
INFO - 2016-11-13 02:32:14 --> Helper loaded: form_helper
INFO - 2016-11-13 02:32:14 --> Security Class Initialized
INFO - 2016-11-13 02:32:14 --> Controller Class Initialized
INFO - 2016-11-13 02:32:14 --> Hooks Class Initialized
INFO - 2016-11-13 02:32:14 --> Database Driver Class Initialized
INFO - 2016-11-13 02:32:14 --> Model Class Initialized
DEBUG - 2016-11-13 02:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-13 02:32:14 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:14 --> Input Class Initialized
INFO - 2016-11-13 02:32:14 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:14 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:15 --> Language Class Initialized
INFO - 2016-11-13 02:32:15 --> URI Class Initialized
INFO - 2016-11-13 02:32:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:15 --> Loader Class Initialized
INFO - 2016-11-13 02:32:15 --> Final output sent to browser
INFO - 2016-11-13 02:32:15 --> Router Class Initialized
DEBUG - 2016-11-13 02:32:15 --> Total execution time: 1.2221
INFO - 2016-11-13 02:32:15 --> Helper loaded: url_helper
INFO - 2016-11-13 02:32:15 --> Output Class Initialized
INFO - 2016-11-13 02:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:15 --> Config Class Initialized
INFO - 2016-11-13 02:32:15 --> Helper loaded: form_helper
INFO - 2016-11-13 02:32:15 --> Security Class Initialized
INFO - 2016-11-13 02:32:15 --> Hooks Class Initialized
INFO - 2016-11-13 02:32:15 --> Controller Class Initialized
INFO - 2016-11-13 02:32:15 --> Database Driver Class Initialized
DEBUG - 2016-11-13 02:32:15 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:15 --> Model Class Initialized
DEBUG - 2016-11-13 02:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:15 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:15 --> Input Class Initialized
INFO - 2016-11-13 02:32:15 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:15 --> URI Class Initialized
INFO - 2016-11-13 02:32:15 --> Language Class Initialized
INFO - 2016-11-13 02:32:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:15 --> Loader Class Initialized
INFO - 2016-11-13 02:32:15 --> Router Class Initialized
INFO - 2016-11-13 02:32:15 --> Final output sent to browser
INFO - 2016-11-13 02:32:15 --> Output Class Initialized
INFO - 2016-11-13 02:32:15 --> Helper loaded: url_helper
DEBUG - 2016-11-13 02:32:15 --> Total execution time: 1.2316
INFO - 2016-11-13 02:32:15 --> Security Class Initialized
INFO - 2016-11-13 02:32:15 --> Helper loaded: form_helper
INFO - 2016-11-13 02:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:15 --> Config Class Initialized
DEBUG - 2016-11-13 02:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:15 --> Database Driver Class Initialized
INFO - 2016-11-13 02:32:15 --> Hooks Class Initialized
INFO - 2016-11-13 02:32:15 --> Controller Class Initialized
INFO - 2016-11-13 02:32:15 --> Input Class Initialized
DEBUG - 2016-11-13 02:32:15 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:32:15 --> Model Class Initialized
INFO - 2016-11-13 02:32:15 --> Language Class Initialized
INFO - 2016-11-13 02:32:15 --> Utf8 Class Initialized
INFO - 2016-11-13 02:32:15 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:15 --> Loader Class Initialized
INFO - 2016-11-13 02:32:15 --> URI Class Initialized
INFO - 2016-11-13 02:32:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:15 --> Helper loaded: url_helper
INFO - 2016-11-13 02:32:15 --> Router Class Initialized
INFO - 2016-11-13 02:32:15 --> Final output sent to browser
INFO - 2016-11-13 02:32:15 --> Helper loaded: form_helper
DEBUG - 2016-11-13 02:32:15 --> Total execution time: 1.2254
INFO - 2016-11-13 02:32:15 --> Output Class Initialized
INFO - 2016-11-13 02:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:15 --> Database Driver Class Initialized
INFO - 2016-11-13 02:32:15 --> Security Class Initialized
INFO - 2016-11-13 02:32:15 --> Controller Class Initialized
INFO - 2016-11-13 02:32:15 --> Model Class Initialized
DEBUG - 2016-11-13 02:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:32:15 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:15 --> Input Class Initialized
INFO - 2016-11-13 02:32:15 --> Language Class Initialized
INFO - 2016-11-13 02:32:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:15 --> Final output sent to browser
INFO - 2016-11-13 02:32:15 --> Loader Class Initialized
DEBUG - 2016-11-13 02:32:15 --> Total execution time: 1.1703
INFO - 2016-11-13 02:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:15 --> Helper loaded: url_helper
INFO - 2016-11-13 02:32:15 --> Controller Class Initialized
INFO - 2016-11-13 02:32:15 --> Model Class Initialized
INFO - 2016-11-13 02:32:15 --> Helper loaded: form_helper
INFO - 2016-11-13 02:32:15 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:15 --> Database Driver Class Initialized
INFO - 2016-11-13 02:32:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:15 --> Final output sent to browser
DEBUG - 2016-11-13 02:32:15 --> Total execution time: 1.1531
INFO - 2016-11-13 02:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:15 --> Controller Class Initialized
INFO - 2016-11-13 02:32:15 --> Model Class Initialized
INFO - 2016-11-13 02:32:15 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:15 --> Final output sent to browser
DEBUG - 2016-11-13 02:32:16 --> Total execution time: 1.0881
INFO - 2016-11-13 02:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:16 --> Controller Class Initialized
INFO - 2016-11-13 02:32:16 --> Model Class Initialized
INFO - 2016-11-13 02:32:16 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:16 --> Final output sent to browser
DEBUG - 2016-11-13 02:32:16 --> Total execution time: 1.0075
INFO - 2016-11-13 02:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:32:16 --> Controller Class Initialized
INFO - 2016-11-13 02:32:16 --> Model Class Initialized
INFO - 2016-11-13 02:32:16 --> Form Validation Class Initialized
INFO - 2016-11-13 02:32:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:32:16 --> Final output sent to browser
DEBUG - 2016-11-13 02:32:16 --> Total execution time: 0.9014
INFO - 2016-11-13 02:33:42 --> Config Class Initialized
INFO - 2016-11-13 02:33:42 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:33:42 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:33:42 --> Utf8 Class Initialized
INFO - 2016-11-13 02:33:42 --> URI Class Initialized
INFO - 2016-11-13 02:33:42 --> Router Class Initialized
INFO - 2016-11-13 02:33:42 --> Output Class Initialized
INFO - 2016-11-13 02:33:42 --> Security Class Initialized
DEBUG - 2016-11-13 02:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:33:42 --> Input Class Initialized
INFO - 2016-11-13 02:33:42 --> Language Class Initialized
INFO - 2016-11-13 02:33:42 --> Loader Class Initialized
INFO - 2016-11-13 02:33:42 --> Helper loaded: url_helper
INFO - 2016-11-13 02:33:42 --> Helper loaded: form_helper
INFO - 2016-11-13 02:33:42 --> Database Driver Class Initialized
INFO - 2016-11-13 02:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:33:42 --> Controller Class Initialized
INFO - 2016-11-13 02:33:42 --> Model Class Initialized
INFO - 2016-11-13 02:33:42 --> Form Validation Class Initialized
INFO - 2016-11-13 02:33:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:33:42 --> Final output sent to browser
DEBUG - 2016-11-13 02:33:42 --> Total execution time: 0.3671
INFO - 2016-11-13 02:34:37 --> Config Class Initialized
INFO - 2016-11-13 02:34:37 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:34:37 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:34:37 --> Utf8 Class Initialized
INFO - 2016-11-13 02:34:37 --> URI Class Initialized
DEBUG - 2016-11-13 02:34:37 --> No URI present. Default controller set.
INFO - 2016-11-13 02:34:37 --> Router Class Initialized
INFO - 2016-11-13 02:34:37 --> Output Class Initialized
INFO - 2016-11-13 02:34:37 --> Security Class Initialized
DEBUG - 2016-11-13 02:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:34:37 --> Input Class Initialized
INFO - 2016-11-13 02:34:37 --> Language Class Initialized
INFO - 2016-11-13 02:34:37 --> Loader Class Initialized
INFO - 2016-11-13 02:34:37 --> Helper loaded: url_helper
INFO - 2016-11-13 02:34:37 --> Helper loaded: form_helper
INFO - 2016-11-13 02:34:37 --> Database Driver Class Initialized
INFO - 2016-11-13 02:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:34:37 --> Controller Class Initialized
INFO - 2016-11-13 02:34:37 --> Model Class Initialized
INFO - 2016-11-13 02:34:37 --> Model Class Initialized
INFO - 2016-11-13 02:34:37 --> Model Class Initialized
INFO - 2016-11-13 02:34:37 --> Model Class Initialized
INFO - 2016-11-13 02:34:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:34:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:34:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:34:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:34:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:34:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:34:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:34:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:34:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:34:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:34:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:34:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:34:37 --> Final output sent to browser
DEBUG - 2016-11-13 02:34:37 --> Total execution time: 0.7209
INFO - 2016-11-13 02:38:41 --> Config Class Initialized
INFO - 2016-11-13 02:38:41 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:38:41 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:38:41 --> Utf8 Class Initialized
INFO - 2016-11-13 02:38:41 --> URI Class Initialized
DEBUG - 2016-11-13 02:38:41 --> No URI present. Default controller set.
INFO - 2016-11-13 02:38:41 --> Router Class Initialized
INFO - 2016-11-13 02:38:42 --> Output Class Initialized
INFO - 2016-11-13 02:38:42 --> Security Class Initialized
DEBUG - 2016-11-13 02:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:38:42 --> Input Class Initialized
INFO - 2016-11-13 02:38:42 --> Language Class Initialized
INFO - 2016-11-13 02:38:42 --> Loader Class Initialized
INFO - 2016-11-13 02:38:42 --> Helper loaded: url_helper
INFO - 2016-11-13 02:38:42 --> Helper loaded: form_helper
INFO - 2016-11-13 02:38:42 --> Database Driver Class Initialized
INFO - 2016-11-13 02:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:38:42 --> Controller Class Initialized
INFO - 2016-11-13 02:38:42 --> Model Class Initialized
INFO - 2016-11-13 02:38:42 --> Model Class Initialized
INFO - 2016-11-13 02:38:42 --> Model Class Initialized
INFO - 2016-11-13 02:38:42 --> Model Class Initialized
INFO - 2016-11-13 02:38:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:38:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:38:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:38:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:38:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:38:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:38:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:38:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:38:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:38:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:38:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:38:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:38:42 --> Final output sent to browser
DEBUG - 2016-11-13 02:38:42 --> Total execution time: 0.7514
INFO - 2016-11-13 02:39:01 --> Config Class Initialized
INFO - 2016-11-13 02:39:01 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:39:01 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:39:01 --> Utf8 Class Initialized
INFO - 2016-11-13 02:39:01 --> URI Class Initialized
INFO - 2016-11-13 02:39:01 --> Router Class Initialized
INFO - 2016-11-13 02:39:01 --> Output Class Initialized
INFO - 2016-11-13 02:39:01 --> Security Class Initialized
DEBUG - 2016-11-13 02:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:39:01 --> Input Class Initialized
INFO - 2016-11-13 02:39:01 --> Language Class Initialized
INFO - 2016-11-13 02:39:01 --> Loader Class Initialized
INFO - 2016-11-13 02:39:01 --> Helper loaded: url_helper
INFO - 2016-11-13 02:39:01 --> Helper loaded: form_helper
INFO - 2016-11-13 02:39:01 --> Database Driver Class Initialized
INFO - 2016-11-13 02:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:39:01 --> Controller Class Initialized
INFO - 2016-11-13 02:39:01 --> Model Class Initialized
INFO - 2016-11-13 02:39:01 --> Form Validation Class Initialized
INFO - 2016-11-13 02:39:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:39:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:39:02 --> Final output sent to browser
DEBUG - 2016-11-13 02:39:02 --> Total execution time: 0.4925
INFO - 2016-11-13 02:40:31 --> Config Class Initialized
INFO - 2016-11-13 02:40:31 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:40:31 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:40:31 --> Utf8 Class Initialized
INFO - 2016-11-13 02:40:31 --> URI Class Initialized
DEBUG - 2016-11-13 02:40:31 --> No URI present. Default controller set.
INFO - 2016-11-13 02:40:31 --> Router Class Initialized
INFO - 2016-11-13 02:40:31 --> Output Class Initialized
INFO - 2016-11-13 02:40:31 --> Security Class Initialized
DEBUG - 2016-11-13 02:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:40:31 --> Input Class Initialized
INFO - 2016-11-13 02:40:31 --> Language Class Initialized
INFO - 2016-11-13 02:40:32 --> Loader Class Initialized
INFO - 2016-11-13 02:40:32 --> Helper loaded: url_helper
INFO - 2016-11-13 02:40:32 --> Helper loaded: form_helper
INFO - 2016-11-13 02:40:32 --> Database Driver Class Initialized
INFO - 2016-11-13 02:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:40:32 --> Controller Class Initialized
INFO - 2016-11-13 02:40:32 --> Model Class Initialized
INFO - 2016-11-13 02:40:32 --> Model Class Initialized
INFO - 2016-11-13 02:40:32 --> Model Class Initialized
INFO - 2016-11-13 02:40:32 --> Model Class Initialized
INFO - 2016-11-13 02:40:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:40:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:40:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:40:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:40:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:40:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:40:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:40:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:40:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:40:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:40:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:40:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:40:32 --> Final output sent to browser
DEBUG - 2016-11-13 02:40:32 --> Total execution time: 0.6854
INFO - 2016-11-13 02:40:45 --> Config Class Initialized
INFO - 2016-11-13 02:40:45 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:40:45 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:40:45 --> Utf8 Class Initialized
INFO - 2016-11-13 02:40:45 --> URI Class Initialized
INFO - 2016-11-13 02:40:45 --> Router Class Initialized
INFO - 2016-11-13 02:40:45 --> Output Class Initialized
INFO - 2016-11-13 02:40:45 --> Security Class Initialized
DEBUG - 2016-11-13 02:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:40:45 --> Input Class Initialized
INFO - 2016-11-13 02:40:45 --> Language Class Initialized
INFO - 2016-11-13 02:40:45 --> Loader Class Initialized
INFO - 2016-11-13 02:40:45 --> Helper loaded: url_helper
INFO - 2016-11-13 02:40:45 --> Helper loaded: form_helper
INFO - 2016-11-13 02:40:45 --> Database Driver Class Initialized
INFO - 2016-11-13 02:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:40:45 --> Controller Class Initialized
INFO - 2016-11-13 02:40:45 --> Model Class Initialized
INFO - 2016-11-13 02:40:45 --> Form Validation Class Initialized
INFO - 2016-11-13 02:40:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:40:45 --> Final output sent to browser
DEBUG - 2016-11-13 02:40:45 --> Total execution time: 0.3665
INFO - 2016-11-13 02:40:48 --> Config Class Initialized
INFO - 2016-11-13 02:40:48 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:40:48 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:40:48 --> Utf8 Class Initialized
INFO - 2016-11-13 02:40:48 --> URI Class Initialized
INFO - 2016-11-13 02:40:48 --> Router Class Initialized
INFO - 2016-11-13 02:40:48 --> Output Class Initialized
INFO - 2016-11-13 02:40:48 --> Security Class Initialized
DEBUG - 2016-11-13 02:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:40:48 --> Input Class Initialized
INFO - 2016-11-13 02:40:48 --> Language Class Initialized
INFO - 2016-11-13 02:40:48 --> Loader Class Initialized
INFO - 2016-11-13 02:40:48 --> Helper loaded: url_helper
INFO - 2016-11-13 02:40:48 --> Helper loaded: form_helper
INFO - 2016-11-13 02:40:48 --> Database Driver Class Initialized
INFO - 2016-11-13 02:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:40:48 --> Controller Class Initialized
INFO - 2016-11-13 02:40:48 --> Model Class Initialized
INFO - 2016-11-13 02:40:48 --> Form Validation Class Initialized
INFO - 2016-11-13 02:40:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:40:48 --> Final output sent to browser
DEBUG - 2016-11-13 02:40:49 --> Total execution time: 0.5363
INFO - 2016-11-13 02:40:51 --> Config Class Initialized
INFO - 2016-11-13 02:40:51 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:40:51 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:40:51 --> Utf8 Class Initialized
INFO - 2016-11-13 02:40:51 --> URI Class Initialized
INFO - 2016-11-13 02:40:51 --> Router Class Initialized
INFO - 2016-11-13 02:40:51 --> Output Class Initialized
INFO - 2016-11-13 02:40:51 --> Security Class Initialized
DEBUG - 2016-11-13 02:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:40:51 --> Input Class Initialized
INFO - 2016-11-13 02:40:51 --> Language Class Initialized
INFO - 2016-11-13 02:40:51 --> Loader Class Initialized
INFO - 2016-11-13 02:40:51 --> Helper loaded: url_helper
INFO - 2016-11-13 02:40:51 --> Helper loaded: form_helper
INFO - 2016-11-13 02:40:51 --> Database Driver Class Initialized
INFO - 2016-11-13 02:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:40:51 --> Controller Class Initialized
INFO - 2016-11-13 02:40:51 --> Model Class Initialized
INFO - 2016-11-13 02:40:51 --> Form Validation Class Initialized
INFO - 2016-11-13 02:40:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:40:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:40:51 --> Final output sent to browser
DEBUG - 2016-11-13 02:40:51 --> Total execution time: 0.5148
INFO - 2016-11-13 02:40:58 --> Config Class Initialized
INFO - 2016-11-13 02:40:58 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:40:58 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:40:58 --> Utf8 Class Initialized
INFO - 2016-11-13 02:40:58 --> URI Class Initialized
INFO - 2016-11-13 02:40:58 --> Router Class Initialized
INFO - 2016-11-13 02:40:58 --> Output Class Initialized
INFO - 2016-11-13 02:40:58 --> Security Class Initialized
DEBUG - 2016-11-13 02:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:40:58 --> Input Class Initialized
INFO - 2016-11-13 02:40:58 --> Language Class Initialized
INFO - 2016-11-13 02:40:58 --> Loader Class Initialized
INFO - 2016-11-13 02:40:59 --> Helper loaded: url_helper
INFO - 2016-11-13 02:40:59 --> Helper loaded: form_helper
INFO - 2016-11-13 02:40:59 --> Database Driver Class Initialized
INFO - 2016-11-13 02:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:40:59 --> Controller Class Initialized
INFO - 2016-11-13 02:40:59 --> Model Class Initialized
INFO - 2016-11-13 02:40:59 --> Form Validation Class Initialized
INFO - 2016-11-13 02:40:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:40:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:40:59 --> Final output sent to browser
DEBUG - 2016-11-13 02:40:59 --> Total execution time: 0.4826
INFO - 2016-11-13 02:42:57 --> Config Class Initialized
INFO - 2016-11-13 02:42:57 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:42:57 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:42:57 --> Utf8 Class Initialized
INFO - 2016-11-13 02:42:57 --> URI Class Initialized
DEBUG - 2016-11-13 02:42:57 --> No URI present. Default controller set.
INFO - 2016-11-13 02:42:57 --> Router Class Initialized
INFO - 2016-11-13 02:42:57 --> Output Class Initialized
INFO - 2016-11-13 02:42:57 --> Security Class Initialized
DEBUG - 2016-11-13 02:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:42:57 --> Input Class Initialized
INFO - 2016-11-13 02:42:57 --> Language Class Initialized
INFO - 2016-11-13 02:42:57 --> Loader Class Initialized
INFO - 2016-11-13 02:42:57 --> Helper loaded: url_helper
INFO - 2016-11-13 02:42:57 --> Helper loaded: form_helper
INFO - 2016-11-13 02:42:57 --> Database Driver Class Initialized
INFO - 2016-11-13 02:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:42:58 --> Controller Class Initialized
INFO - 2016-11-13 02:42:58 --> Model Class Initialized
INFO - 2016-11-13 02:42:58 --> Model Class Initialized
INFO - 2016-11-13 02:42:58 --> Model Class Initialized
INFO - 2016-11-13 02:42:58 --> Model Class Initialized
INFO - 2016-11-13 02:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:42:58 --> Final output sent to browser
DEBUG - 2016-11-13 02:42:58 --> Total execution time: 0.6952
INFO - 2016-11-13 02:43:12 --> Config Class Initialized
INFO - 2016-11-13 02:43:12 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:43:13 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:43:13 --> Utf8 Class Initialized
INFO - 2016-11-13 02:43:13 --> URI Class Initialized
INFO - 2016-11-13 02:43:13 --> Router Class Initialized
INFO - 2016-11-13 02:43:13 --> Output Class Initialized
INFO - 2016-11-13 02:43:13 --> Security Class Initialized
DEBUG - 2016-11-13 02:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:43:13 --> Input Class Initialized
INFO - 2016-11-13 02:43:13 --> Language Class Initialized
INFO - 2016-11-13 02:43:13 --> Loader Class Initialized
INFO - 2016-11-13 02:43:13 --> Helper loaded: url_helper
INFO - 2016-11-13 02:43:13 --> Helper loaded: form_helper
INFO - 2016-11-13 02:43:13 --> Database Driver Class Initialized
INFO - 2016-11-13 02:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:43:13 --> Controller Class Initialized
INFO - 2016-11-13 02:43:13 --> Model Class Initialized
INFO - 2016-11-13 02:43:13 --> Form Validation Class Initialized
INFO - 2016-11-13 02:43:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:43:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:43:13 --> Final output sent to browser
DEBUG - 2016-11-13 02:43:13 --> Total execution time: 0.4908
INFO - 2016-11-13 02:43:38 --> Config Class Initialized
INFO - 2016-11-13 02:43:38 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:43:38 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:43:38 --> Utf8 Class Initialized
INFO - 2016-11-13 02:43:38 --> URI Class Initialized
DEBUG - 2016-11-13 02:43:38 --> No URI present. Default controller set.
INFO - 2016-11-13 02:43:38 --> Router Class Initialized
INFO - 2016-11-13 02:43:38 --> Output Class Initialized
INFO - 2016-11-13 02:43:38 --> Security Class Initialized
DEBUG - 2016-11-13 02:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:43:38 --> Input Class Initialized
INFO - 2016-11-13 02:43:38 --> Language Class Initialized
INFO - 2016-11-13 02:43:38 --> Loader Class Initialized
INFO - 2016-11-13 02:43:38 --> Helper loaded: url_helper
INFO - 2016-11-13 02:43:38 --> Helper loaded: form_helper
INFO - 2016-11-13 02:43:38 --> Database Driver Class Initialized
INFO - 2016-11-13 02:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:43:38 --> Controller Class Initialized
INFO - 2016-11-13 02:43:38 --> Model Class Initialized
INFO - 2016-11-13 02:43:38 --> Model Class Initialized
INFO - 2016-11-13 02:43:38 --> Model Class Initialized
INFO - 2016-11-13 02:43:38 --> Model Class Initialized
INFO - 2016-11-13 02:43:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:43:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:43:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:43:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:43:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:43:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:43:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:43:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:43:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:43:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:43:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:43:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:43:38 --> Final output sent to browser
DEBUG - 2016-11-13 02:43:38 --> Total execution time: 0.6981
INFO - 2016-11-13 02:46:32 --> Config Class Initialized
INFO - 2016-11-13 02:46:32 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:46:32 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:46:32 --> Utf8 Class Initialized
INFO - 2016-11-13 02:46:32 --> URI Class Initialized
INFO - 2016-11-13 02:46:32 --> Router Class Initialized
INFO - 2016-11-13 02:46:32 --> Output Class Initialized
INFO - 2016-11-13 02:46:32 --> Security Class Initialized
DEBUG - 2016-11-13 02:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:46:32 --> Input Class Initialized
INFO - 2016-11-13 02:46:32 --> Language Class Initialized
INFO - 2016-11-13 02:46:32 --> Loader Class Initialized
INFO - 2016-11-13 02:46:32 --> Helper loaded: url_helper
INFO - 2016-11-13 02:46:32 --> Helper loaded: form_helper
INFO - 2016-11-13 02:46:32 --> Database Driver Class Initialized
INFO - 2016-11-13 02:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:46:32 --> Controller Class Initialized
INFO - 2016-11-13 02:46:32 --> Model Class Initialized
INFO - 2016-11-13 02:46:32 --> Model Class Initialized
INFO - 2016-11-13 02:46:32 --> Model Class Initialized
INFO - 2016-11-13 02:46:32 --> Model Class Initialized
DEBUG - 2016-11-13 02:46:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-13 02:46:32 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-13 02:46:32 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-13 02:46:32 --> Config Class Initialized
INFO - 2016-11-13 02:46:32 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:46:32 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:46:32 --> Utf8 Class Initialized
INFO - 2016-11-13 02:46:32 --> URI Class Initialized
DEBUG - 2016-11-13 02:46:32 --> No URI present. Default controller set.
INFO - 2016-11-13 02:46:32 --> Router Class Initialized
INFO - 2016-11-13 02:46:32 --> Output Class Initialized
INFO - 2016-11-13 02:46:32 --> Security Class Initialized
DEBUG - 2016-11-13 02:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:46:32 --> Input Class Initialized
INFO - 2016-11-13 02:46:32 --> Language Class Initialized
INFO - 2016-11-13 02:46:32 --> Loader Class Initialized
INFO - 2016-11-13 02:46:32 --> Helper loaded: url_helper
INFO - 2016-11-13 02:46:32 --> Helper loaded: form_helper
INFO - 2016-11-13 02:46:32 --> Database Driver Class Initialized
INFO - 2016-11-13 02:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:46:32 --> Controller Class Initialized
INFO - 2016-11-13 02:46:32 --> Model Class Initialized
INFO - 2016-11-13 02:46:32 --> Model Class Initialized
INFO - 2016-11-13 02:46:33 --> Model Class Initialized
INFO - 2016-11-13 02:46:33 --> Model Class Initialized
INFO - 2016-11-13 02:46:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:46:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-13 02:46:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:46:33 --> Final output sent to browser
DEBUG - 2016-11-13 02:46:33 --> Total execution time: 0.4872
INFO - 2016-11-13 02:46:46 --> Config Class Initialized
INFO - 2016-11-13 02:46:46 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:46:46 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:46:46 --> Utf8 Class Initialized
INFO - 2016-11-13 02:46:46 --> URI Class Initialized
INFO - 2016-11-13 02:46:46 --> Router Class Initialized
INFO - 2016-11-13 02:46:46 --> Output Class Initialized
INFO - 2016-11-13 02:46:46 --> Security Class Initialized
DEBUG - 2016-11-13 02:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:46:46 --> Input Class Initialized
INFO - 2016-11-13 02:46:46 --> Language Class Initialized
INFO - 2016-11-13 02:46:46 --> Loader Class Initialized
INFO - 2016-11-13 02:46:46 --> Helper loaded: url_helper
INFO - 2016-11-13 02:46:46 --> Helper loaded: form_helper
INFO - 2016-11-13 02:46:46 --> Database Driver Class Initialized
INFO - 2016-11-13 02:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:46:46 --> Controller Class Initialized
INFO - 2016-11-13 02:46:46 --> Model Class Initialized
INFO - 2016-11-13 02:46:46 --> Model Class Initialized
INFO - 2016-11-13 02:46:46 --> Model Class Initialized
INFO - 2016-11-13 02:46:46 --> Model Class Initialized
DEBUG - 2016-11-13 02:46:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-13 02:46:46 --> Model Class Initialized
INFO - 2016-11-13 02:46:46 --> Final output sent to browser
DEBUG - 2016-11-13 02:46:46 --> Total execution time: 0.4263
INFO - 2016-11-13 02:46:46 --> Config Class Initialized
INFO - 2016-11-13 02:46:46 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:46:47 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:46:47 --> Utf8 Class Initialized
INFO - 2016-11-13 02:46:47 --> URI Class Initialized
DEBUG - 2016-11-13 02:46:47 --> No URI present. Default controller set.
INFO - 2016-11-13 02:46:47 --> Router Class Initialized
INFO - 2016-11-13 02:46:47 --> Output Class Initialized
INFO - 2016-11-13 02:46:47 --> Security Class Initialized
DEBUG - 2016-11-13 02:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:46:47 --> Input Class Initialized
INFO - 2016-11-13 02:46:47 --> Language Class Initialized
INFO - 2016-11-13 02:46:47 --> Loader Class Initialized
INFO - 2016-11-13 02:46:47 --> Helper loaded: url_helper
INFO - 2016-11-13 02:46:47 --> Helper loaded: form_helper
INFO - 2016-11-13 02:46:47 --> Database Driver Class Initialized
INFO - 2016-11-13 02:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:46:47 --> Controller Class Initialized
INFO - 2016-11-13 02:46:47 --> Model Class Initialized
INFO - 2016-11-13 02:46:47 --> Model Class Initialized
INFO - 2016-11-13 02:46:47 --> Model Class Initialized
INFO - 2016-11-13 02:46:47 --> Model Class Initialized
INFO - 2016-11-13 02:46:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:46:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:46:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:46:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-13 02:46:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-13 02:46:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-13 02:46:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-13 02:46:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-13 02:46:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-13 02:46:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:46:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:46:47 --> Final output sent to browser
DEBUG - 2016-11-13 02:46:47 --> Total execution time: 0.6427
INFO - 2016-11-13 02:48:07 --> Config Class Initialized
INFO - 2016-11-13 02:48:07 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:48:07 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:48:08 --> Utf8 Class Initialized
INFO - 2016-11-13 02:48:08 --> URI Class Initialized
INFO - 2016-11-13 02:48:08 --> Router Class Initialized
INFO - 2016-11-13 02:48:08 --> Output Class Initialized
INFO - 2016-11-13 02:48:08 --> Security Class Initialized
DEBUG - 2016-11-13 02:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:48:08 --> Input Class Initialized
INFO - 2016-11-13 02:48:08 --> Language Class Initialized
INFO - 2016-11-13 02:48:08 --> Loader Class Initialized
INFO - 2016-11-13 02:48:08 --> Helper loaded: url_helper
INFO - 2016-11-13 02:48:08 --> Helper loaded: form_helper
INFO - 2016-11-13 02:48:08 --> Database Driver Class Initialized
INFO - 2016-11-13 02:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:48:08 --> Controller Class Initialized
INFO - 2016-11-13 02:48:08 --> Model Class Initialized
INFO - 2016-11-13 02:48:08 --> Form Validation Class Initialized
INFO - 2016-11-13 02:48:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:48:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-13 02:48:08 --> Final output sent to browser
DEBUG - 2016-11-13 02:48:08 --> Total execution time: 0.4791
INFO - 2016-11-13 02:58:20 --> Config Class Initialized
INFO - 2016-11-13 02:58:20 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:58:20 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:58:20 --> Utf8 Class Initialized
INFO - 2016-11-13 02:58:20 --> URI Class Initialized
INFO - 2016-11-13 02:58:20 --> Router Class Initialized
INFO - 2016-11-13 02:58:20 --> Output Class Initialized
INFO - 2016-11-13 02:58:20 --> Security Class Initialized
DEBUG - 2016-11-13 02:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:58:20 --> Input Class Initialized
INFO - 2016-11-13 02:58:20 --> Language Class Initialized
INFO - 2016-11-13 02:58:20 --> Loader Class Initialized
INFO - 2016-11-13 02:58:20 --> Helper loaded: url_helper
INFO - 2016-11-13 02:58:20 --> Helper loaded: form_helper
INFO - 2016-11-13 02:58:20 --> Database Driver Class Initialized
INFO - 2016-11-13 02:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:58:20 --> Controller Class Initialized
INFO - 2016-11-13 02:58:20 --> Model Class Initialized
INFO - 2016-11-13 02:58:20 --> Model Class Initialized
INFO - 2016-11-13 02:58:20 --> Model Class Initialized
INFO - 2016-11-13 02:58:20 --> Model Class Initialized
DEBUG - 2016-11-13 02:58:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-13 02:58:20 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-13 02:58:21 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-13 02:58:21 --> Config Class Initialized
INFO - 2016-11-13 02:58:21 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:58:21 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:58:21 --> Utf8 Class Initialized
INFO - 2016-11-13 02:58:21 --> URI Class Initialized
DEBUG - 2016-11-13 02:58:21 --> No URI present. Default controller set.
INFO - 2016-11-13 02:58:21 --> Router Class Initialized
INFO - 2016-11-13 02:58:21 --> Output Class Initialized
INFO - 2016-11-13 02:58:21 --> Security Class Initialized
DEBUG - 2016-11-13 02:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:58:21 --> Input Class Initialized
INFO - 2016-11-13 02:58:21 --> Language Class Initialized
INFO - 2016-11-13 02:58:21 --> Loader Class Initialized
INFO - 2016-11-13 02:58:21 --> Helper loaded: url_helper
INFO - 2016-11-13 02:58:21 --> Helper loaded: form_helper
INFO - 2016-11-13 02:58:21 --> Database Driver Class Initialized
INFO - 2016-11-13 02:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:58:21 --> Controller Class Initialized
INFO - 2016-11-13 02:58:21 --> Model Class Initialized
INFO - 2016-11-13 02:58:21 --> Model Class Initialized
INFO - 2016-11-13 02:58:21 --> Model Class Initialized
INFO - 2016-11-13 02:58:21 --> Model Class Initialized
INFO - 2016-11-13 02:58:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:58:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-13 02:58:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:58:21 --> Final output sent to browser
DEBUG - 2016-11-13 02:58:21 --> Total execution time: 0.4995
INFO - 2016-11-13 02:58:32 --> Config Class Initialized
INFO - 2016-11-13 02:58:32 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:58:32 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:58:32 --> Utf8 Class Initialized
INFO - 2016-11-13 02:58:32 --> URI Class Initialized
INFO - 2016-11-13 02:58:32 --> Router Class Initialized
INFO - 2016-11-13 02:58:32 --> Output Class Initialized
INFO - 2016-11-13 02:58:32 --> Security Class Initialized
DEBUG - 2016-11-13 02:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:58:32 --> Input Class Initialized
INFO - 2016-11-13 02:58:32 --> Language Class Initialized
INFO - 2016-11-13 02:58:32 --> Loader Class Initialized
INFO - 2016-11-13 02:58:32 --> Helper loaded: url_helper
INFO - 2016-11-13 02:58:32 --> Helper loaded: form_helper
INFO - 2016-11-13 02:58:32 --> Database Driver Class Initialized
INFO - 2016-11-13 02:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:58:32 --> Controller Class Initialized
INFO - 2016-11-13 02:58:32 --> Model Class Initialized
INFO - 2016-11-13 02:58:32 --> Model Class Initialized
INFO - 2016-11-13 02:58:32 --> Model Class Initialized
INFO - 2016-11-13 02:58:32 --> Model Class Initialized
DEBUG - 2016-11-13 02:58:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-13 02:58:32 --> Model Class Initialized
INFO - 2016-11-13 02:58:32 --> Final output sent to browser
DEBUG - 2016-11-13 02:58:32 --> Total execution time: 0.4369
INFO - 2016-11-13 02:58:32 --> Config Class Initialized
INFO - 2016-11-13 02:58:33 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:58:33 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:58:33 --> Utf8 Class Initialized
INFO - 2016-11-13 02:58:33 --> URI Class Initialized
DEBUG - 2016-11-13 02:58:33 --> No URI present. Default controller set.
INFO - 2016-11-13 02:58:33 --> Router Class Initialized
INFO - 2016-11-13 02:58:33 --> Output Class Initialized
INFO - 2016-11-13 02:58:33 --> Security Class Initialized
DEBUG - 2016-11-13 02:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:58:33 --> Input Class Initialized
INFO - 2016-11-13 02:58:33 --> Language Class Initialized
INFO - 2016-11-13 02:58:33 --> Loader Class Initialized
INFO - 2016-11-13 02:58:33 --> Helper loaded: url_helper
INFO - 2016-11-13 02:58:33 --> Helper loaded: form_helper
INFO - 2016-11-13 02:58:33 --> Database Driver Class Initialized
INFO - 2016-11-13 02:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:58:33 --> Controller Class Initialized
INFO - 2016-11-13 02:58:33 --> Model Class Initialized
INFO - 2016-11-13 02:58:33 --> Model Class Initialized
INFO - 2016-11-13 02:58:33 --> Model Class Initialized
INFO - 2016-11-13 02:58:33 --> Model Class Initialized
INFO - 2016-11-13 02:58:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:58:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:58:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:58:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:58:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:58:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:58:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:58:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:58:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:58:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:58:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:58:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:58:33 --> Final output sent to browser
DEBUG - 2016-11-13 02:58:33 --> Total execution time: 0.6710
INFO - 2016-11-13 02:58:39 --> Config Class Initialized
INFO - 2016-11-13 02:58:39 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:58:39 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:58:39 --> Utf8 Class Initialized
INFO - 2016-11-13 02:58:39 --> URI Class Initialized
INFO - 2016-11-13 02:58:39 --> Router Class Initialized
INFO - 2016-11-13 02:58:39 --> Output Class Initialized
INFO - 2016-11-13 02:58:39 --> Security Class Initialized
DEBUG - 2016-11-13 02:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:58:39 --> Input Class Initialized
INFO - 2016-11-13 02:58:40 --> Language Class Initialized
INFO - 2016-11-13 02:58:40 --> Loader Class Initialized
INFO - 2016-11-13 02:58:40 --> Helper loaded: url_helper
INFO - 2016-11-13 02:58:40 --> Helper loaded: form_helper
INFO - 2016-11-13 02:58:40 --> Database Driver Class Initialized
INFO - 2016-11-13 02:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:58:40 --> Controller Class Initialized
INFO - 2016-11-13 02:58:40 --> Model Class Initialized
INFO - 2016-11-13 02:58:40 --> Form Validation Class Initialized
INFO - 2016-11-13 02:58:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:58:40 --> Final output sent to browser
DEBUG - 2016-11-13 02:58:40 --> Total execution time: 0.3692
INFO - 2016-11-13 02:58:49 --> Config Class Initialized
INFO - 2016-11-13 02:58:49 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:58:49 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:58:49 --> Utf8 Class Initialized
INFO - 2016-11-13 02:58:49 --> URI Class Initialized
INFO - 2016-11-13 02:58:49 --> Router Class Initialized
INFO - 2016-11-13 02:58:49 --> Output Class Initialized
INFO - 2016-11-13 02:58:49 --> Security Class Initialized
DEBUG - 2016-11-13 02:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:58:49 --> Input Class Initialized
INFO - 2016-11-13 02:58:49 --> Language Class Initialized
INFO - 2016-11-13 02:58:49 --> Loader Class Initialized
INFO - 2016-11-13 02:58:49 --> Helper loaded: url_helper
INFO - 2016-11-13 02:58:49 --> Helper loaded: form_helper
INFO - 2016-11-13 02:58:49 --> Database Driver Class Initialized
INFO - 2016-11-13 02:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:58:49 --> Controller Class Initialized
INFO - 2016-11-13 02:58:49 --> Model Class Initialized
INFO - 2016-11-13 02:58:49 --> Form Validation Class Initialized
INFO - 2016-11-13 02:58:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 02:58:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:58:50 --> Final output sent to browser
DEBUG - 2016-11-13 02:58:50 --> Total execution time: 0.5154
INFO - 2016-11-13 02:59:12 --> Config Class Initialized
INFO - 2016-11-13 02:59:12 --> Hooks Class Initialized
DEBUG - 2016-11-13 02:59:12 --> UTF-8 Support Enabled
INFO - 2016-11-13 02:59:12 --> Utf8 Class Initialized
INFO - 2016-11-13 02:59:12 --> URI Class Initialized
DEBUG - 2016-11-13 02:59:12 --> No URI present. Default controller set.
INFO - 2016-11-13 02:59:12 --> Router Class Initialized
INFO - 2016-11-13 02:59:12 --> Output Class Initialized
INFO - 2016-11-13 02:59:12 --> Security Class Initialized
DEBUG - 2016-11-13 02:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 02:59:12 --> Input Class Initialized
INFO - 2016-11-13 02:59:12 --> Language Class Initialized
INFO - 2016-11-13 02:59:12 --> Loader Class Initialized
INFO - 2016-11-13 02:59:12 --> Helper loaded: url_helper
INFO - 2016-11-13 02:59:12 --> Helper loaded: form_helper
INFO - 2016-11-13 02:59:12 --> Database Driver Class Initialized
INFO - 2016-11-13 02:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 02:59:12 --> Controller Class Initialized
INFO - 2016-11-13 02:59:12 --> Model Class Initialized
INFO - 2016-11-13 02:59:12 --> Model Class Initialized
INFO - 2016-11-13 02:59:12 --> Model Class Initialized
INFO - 2016-11-13 02:59:12 --> Model Class Initialized
INFO - 2016-11-13 02:59:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 02:59:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 02:59:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 02:59:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 02:59:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 02:59:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 02:59:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 02:59:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 02:59:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 02:59:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 02:59:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 02:59:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 02:59:12 --> Final output sent to browser
DEBUG - 2016-11-13 02:59:12 --> Total execution time: 0.7116
INFO - 2016-11-13 03:10:59 --> Config Class Initialized
INFO - 2016-11-13 03:10:59 --> Hooks Class Initialized
DEBUG - 2016-11-13 03:10:59 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:10:59 --> Utf8 Class Initialized
INFO - 2016-11-13 03:10:59 --> URI Class Initialized
DEBUG - 2016-11-13 03:10:59 --> No URI present. Default controller set.
INFO - 2016-11-13 03:10:59 --> Router Class Initialized
INFO - 2016-11-13 03:10:59 --> Output Class Initialized
INFO - 2016-11-13 03:10:59 --> Security Class Initialized
DEBUG - 2016-11-13 03:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:10:59 --> Input Class Initialized
INFO - 2016-11-13 03:10:59 --> Language Class Initialized
INFO - 2016-11-13 03:10:59 --> Loader Class Initialized
INFO - 2016-11-13 03:10:59 --> Helper loaded: url_helper
INFO - 2016-11-13 03:10:59 --> Helper loaded: form_helper
INFO - 2016-11-13 03:10:59 --> Database Driver Class Initialized
INFO - 2016-11-13 03:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:10:59 --> Controller Class Initialized
INFO - 2016-11-13 03:10:59 --> Model Class Initialized
INFO - 2016-11-13 03:10:59 --> Model Class Initialized
INFO - 2016-11-13 03:10:59 --> Model Class Initialized
INFO - 2016-11-13 03:10:59 --> Model Class Initialized
INFO - 2016-11-13 03:10:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 03:10:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 03:10:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 03:10:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 03:10:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 03:10:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 03:10:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 03:10:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 03:10:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 03:10:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 03:10:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 03:10:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 03:10:59 --> Final output sent to browser
DEBUG - 2016-11-13 03:10:59 --> Total execution time: 0.6637
INFO - 2016-11-13 03:11:06 --> Config Class Initialized
INFO - 2016-11-13 03:11:06 --> Hooks Class Initialized
DEBUG - 2016-11-13 03:11:06 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:11:06 --> Utf8 Class Initialized
INFO - 2016-11-13 03:11:06 --> URI Class Initialized
DEBUG - 2016-11-13 03:11:06 --> No URI present. Default controller set.
INFO - 2016-11-13 03:11:06 --> Router Class Initialized
INFO - 2016-11-13 03:11:06 --> Output Class Initialized
INFO - 2016-11-13 03:11:06 --> Security Class Initialized
DEBUG - 2016-11-13 03:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:11:06 --> Input Class Initialized
INFO - 2016-11-13 03:11:06 --> Language Class Initialized
INFO - 2016-11-13 03:11:06 --> Loader Class Initialized
INFO - 2016-11-13 03:11:06 --> Helper loaded: url_helper
INFO - 2016-11-13 03:11:06 --> Helper loaded: form_helper
INFO - 2016-11-13 03:11:06 --> Database Driver Class Initialized
INFO - 2016-11-13 03:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:11:06 --> Controller Class Initialized
INFO - 2016-11-13 03:11:06 --> Model Class Initialized
INFO - 2016-11-13 03:11:06 --> Model Class Initialized
INFO - 2016-11-13 03:11:06 --> Model Class Initialized
INFO - 2016-11-13 03:11:06 --> Model Class Initialized
INFO - 2016-11-13 03:11:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 03:11:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 03:11:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 03:11:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 03:11:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 03:11:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 03:11:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 03:11:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 03:11:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 03:11:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 03:11:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 03:11:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 03:11:07 --> Final output sent to browser
DEBUG - 2016-11-13 03:11:07 --> Total execution time: 0.6976
INFO - 2016-11-13 03:11:31 --> Config Class Initialized
INFO - 2016-11-13 03:11:31 --> Hooks Class Initialized
DEBUG - 2016-11-13 03:11:31 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:11:31 --> Utf8 Class Initialized
INFO - 2016-11-13 03:11:31 --> URI Class Initialized
DEBUG - 2016-11-13 03:11:31 --> No URI present. Default controller set.
INFO - 2016-11-13 03:11:31 --> Router Class Initialized
INFO - 2016-11-13 03:11:31 --> Output Class Initialized
INFO - 2016-11-13 03:11:31 --> Security Class Initialized
DEBUG - 2016-11-13 03:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:11:31 --> Input Class Initialized
INFO - 2016-11-13 03:11:31 --> Language Class Initialized
INFO - 2016-11-13 03:11:31 --> Loader Class Initialized
INFO - 2016-11-13 03:11:31 --> Helper loaded: url_helper
INFO - 2016-11-13 03:11:31 --> Helper loaded: form_helper
INFO - 2016-11-13 03:11:31 --> Database Driver Class Initialized
INFO - 2016-11-13 03:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:11:31 --> Controller Class Initialized
INFO - 2016-11-13 03:11:31 --> Model Class Initialized
INFO - 2016-11-13 03:11:31 --> Model Class Initialized
INFO - 2016-11-13 03:11:31 --> Model Class Initialized
INFO - 2016-11-13 03:11:32 --> Model Class Initialized
INFO - 2016-11-13 03:11:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 03:11:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 03:11:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 03:11:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 03:11:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 03:11:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 03:11:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 03:11:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 03:11:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 03:11:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 03:11:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 03:11:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 03:11:32 --> Final output sent to browser
DEBUG - 2016-11-13 03:11:32 --> Total execution time: 0.7201
INFO - 2016-11-13 03:11:56 --> Config Class Initialized
INFO - 2016-11-13 03:11:56 --> Hooks Class Initialized
DEBUG - 2016-11-13 03:11:56 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:11:56 --> Utf8 Class Initialized
INFO - 2016-11-13 03:11:56 --> URI Class Initialized
DEBUG - 2016-11-13 03:11:56 --> No URI present. Default controller set.
INFO - 2016-11-13 03:11:56 --> Router Class Initialized
INFO - 2016-11-13 03:11:56 --> Output Class Initialized
INFO - 2016-11-13 03:11:56 --> Security Class Initialized
DEBUG - 2016-11-13 03:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:11:56 --> Input Class Initialized
INFO - 2016-11-13 03:11:56 --> Language Class Initialized
INFO - 2016-11-13 03:11:56 --> Loader Class Initialized
INFO - 2016-11-13 03:11:56 --> Helper loaded: url_helper
INFO - 2016-11-13 03:11:56 --> Helper loaded: form_helper
INFO - 2016-11-13 03:11:56 --> Database Driver Class Initialized
INFO - 2016-11-13 03:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:11:56 --> Controller Class Initialized
INFO - 2016-11-13 03:11:56 --> Model Class Initialized
INFO - 2016-11-13 03:11:57 --> Model Class Initialized
INFO - 2016-11-13 03:11:57 --> Model Class Initialized
INFO - 2016-11-13 03:11:57 --> Model Class Initialized
INFO - 2016-11-13 03:11:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 03:11:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 03:11:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 03:11:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 03:11:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 03:11:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 03:11:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 03:11:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 03:11:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 03:11:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 03:11:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 03:11:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 03:11:57 --> Final output sent to browser
DEBUG - 2016-11-13 03:11:57 --> Total execution time: 0.6974
INFO - 2016-11-13 03:12:58 --> Config Class Initialized
INFO - 2016-11-13 03:12:58 --> Hooks Class Initialized
DEBUG - 2016-11-13 03:12:58 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:12:58 --> Utf8 Class Initialized
INFO - 2016-11-13 03:12:58 --> URI Class Initialized
DEBUG - 2016-11-13 03:12:58 --> No URI present. Default controller set.
INFO - 2016-11-13 03:12:58 --> Router Class Initialized
INFO - 2016-11-13 03:12:58 --> Output Class Initialized
INFO - 2016-11-13 03:12:58 --> Security Class Initialized
DEBUG - 2016-11-13 03:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:12:58 --> Input Class Initialized
INFO - 2016-11-13 03:12:58 --> Language Class Initialized
INFO - 2016-11-13 03:12:58 --> Loader Class Initialized
INFO - 2016-11-13 03:12:58 --> Helper loaded: url_helper
INFO - 2016-11-13 03:12:58 --> Helper loaded: form_helper
INFO - 2016-11-13 03:12:58 --> Database Driver Class Initialized
INFO - 2016-11-13 03:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:12:58 --> Controller Class Initialized
INFO - 2016-11-13 03:12:58 --> Model Class Initialized
INFO - 2016-11-13 03:12:58 --> Model Class Initialized
INFO - 2016-11-13 03:12:58 --> Model Class Initialized
INFO - 2016-11-13 03:12:58 --> Model Class Initialized
INFO - 2016-11-13 03:12:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 03:12:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 03:12:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 03:12:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 03:12:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 03:12:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 03:12:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 03:12:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 03:12:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 03:12:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 03:12:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 03:12:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 03:12:59 --> Final output sent to browser
DEBUG - 2016-11-13 03:12:59 --> Total execution time: 0.6944
INFO - 2016-11-13 03:13:51 --> Config Class Initialized
INFO - 2016-11-13 03:13:51 --> Hooks Class Initialized
DEBUG - 2016-11-13 03:13:51 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:13:51 --> Utf8 Class Initialized
INFO - 2016-11-13 03:13:51 --> URI Class Initialized
DEBUG - 2016-11-13 03:13:51 --> No URI present. Default controller set.
INFO - 2016-11-13 03:13:51 --> Router Class Initialized
INFO - 2016-11-13 03:13:51 --> Output Class Initialized
INFO - 2016-11-13 03:13:51 --> Security Class Initialized
DEBUG - 2016-11-13 03:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:13:51 --> Input Class Initialized
INFO - 2016-11-13 03:13:51 --> Language Class Initialized
INFO - 2016-11-13 03:13:51 --> Loader Class Initialized
INFO - 2016-11-13 03:13:51 --> Helper loaded: url_helper
INFO - 2016-11-13 03:13:51 --> Helper loaded: form_helper
INFO - 2016-11-13 03:13:52 --> Database Driver Class Initialized
INFO - 2016-11-13 03:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:13:52 --> Controller Class Initialized
INFO - 2016-11-13 03:13:52 --> Model Class Initialized
INFO - 2016-11-13 03:13:52 --> Model Class Initialized
INFO - 2016-11-13 03:13:52 --> Model Class Initialized
INFO - 2016-11-13 03:13:52 --> Model Class Initialized
INFO - 2016-11-13 03:13:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 03:13:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 03:13:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 03:13:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 03:13:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 03:13:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 03:13:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 03:13:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 03:13:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 03:13:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 03:13:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 03:13:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 03:13:52 --> Final output sent to browser
DEBUG - 2016-11-13 03:13:52 --> Total execution time: 0.6878
INFO - 2016-11-13 03:20:08 --> Config Class Initialized
INFO - 2016-11-13 03:20:08 --> Hooks Class Initialized
DEBUG - 2016-11-13 03:20:08 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:20:08 --> Utf8 Class Initialized
INFO - 2016-11-13 03:20:08 --> URI Class Initialized
INFO - 2016-11-13 03:20:08 --> Router Class Initialized
INFO - 2016-11-13 03:20:08 --> Output Class Initialized
INFO - 2016-11-13 03:20:08 --> Security Class Initialized
DEBUG - 2016-11-13 03:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:20:08 --> Input Class Initialized
INFO - 2016-11-13 03:20:08 --> Language Class Initialized
INFO - 2016-11-13 03:20:08 --> Loader Class Initialized
INFO - 2016-11-13 03:20:08 --> Helper loaded: url_helper
INFO - 2016-11-13 03:20:08 --> Helper loaded: form_helper
INFO - 2016-11-13 03:20:08 --> Database Driver Class Initialized
INFO - 2016-11-13 03:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:20:09 --> Controller Class Initialized
INFO - 2016-11-13 03:20:09 --> Model Class Initialized
INFO - 2016-11-13 03:20:09 --> Model Class Initialized
INFO - 2016-11-13 03:20:09 --> Model Class Initialized
INFO - 2016-11-13 03:20:09 --> Model Class Initialized
DEBUG - 2016-11-13 03:20:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-13 03:20:09 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-13 03:20:09 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-13 03:20:09 --> Config Class Initialized
INFO - 2016-11-13 03:20:09 --> Hooks Class Initialized
DEBUG - 2016-11-13 03:20:09 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:20:09 --> Utf8 Class Initialized
INFO - 2016-11-13 03:20:09 --> URI Class Initialized
DEBUG - 2016-11-13 03:20:09 --> No URI present. Default controller set.
INFO - 2016-11-13 03:20:09 --> Router Class Initialized
INFO - 2016-11-13 03:20:09 --> Output Class Initialized
INFO - 2016-11-13 03:20:09 --> Security Class Initialized
DEBUG - 2016-11-13 03:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:20:09 --> Input Class Initialized
INFO - 2016-11-13 03:20:09 --> Language Class Initialized
INFO - 2016-11-13 03:20:09 --> Loader Class Initialized
INFO - 2016-11-13 03:20:09 --> Helper loaded: url_helper
INFO - 2016-11-13 03:20:09 --> Helper loaded: form_helper
INFO - 2016-11-13 03:20:09 --> Database Driver Class Initialized
INFO - 2016-11-13 03:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:20:09 --> Controller Class Initialized
INFO - 2016-11-13 03:20:09 --> Model Class Initialized
INFO - 2016-11-13 03:20:09 --> Model Class Initialized
INFO - 2016-11-13 03:20:09 --> Model Class Initialized
INFO - 2016-11-13 03:20:09 --> Model Class Initialized
INFO - 2016-11-13 03:20:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 03:20:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-13 03:20:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 03:20:09 --> Final output sent to browser
DEBUG - 2016-11-13 03:20:09 --> Total execution time: 0.5032
INFO - 2016-11-13 03:47:34 --> Config Class Initialized
INFO - 2016-11-13 03:47:34 --> Hooks Class Initialized
DEBUG - 2016-11-13 03:47:35 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:47:35 --> Utf8 Class Initialized
INFO - 2016-11-13 03:47:35 --> URI Class Initialized
DEBUG - 2016-11-13 03:47:35 --> No URI present. Default controller set.
INFO - 2016-11-13 03:47:35 --> Router Class Initialized
INFO - 2016-11-13 03:47:35 --> Output Class Initialized
INFO - 2016-11-13 03:47:35 --> Security Class Initialized
DEBUG - 2016-11-13 03:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:47:35 --> Input Class Initialized
INFO - 2016-11-13 03:47:35 --> Language Class Initialized
INFO - 2016-11-13 03:47:35 --> Loader Class Initialized
INFO - 2016-11-13 03:47:35 --> Helper loaded: url_helper
INFO - 2016-11-13 03:47:35 --> Helper loaded: form_helper
INFO - 2016-11-13 03:47:35 --> Database Driver Class Initialized
INFO - 2016-11-13 03:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:47:35 --> Controller Class Initialized
INFO - 2016-11-13 03:47:36 --> Model Class Initialized
INFO - 2016-11-13 03:47:36 --> Model Class Initialized
INFO - 2016-11-13 03:47:36 --> Model Class Initialized
INFO - 2016-11-13 03:47:36 --> Model Class Initialized
INFO - 2016-11-13 03:47:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 03:47:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-13 03:47:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 03:47:36 --> Final output sent to browser
DEBUG - 2016-11-13 03:47:36 --> Total execution time: 1.7814
INFO - 2016-11-13 03:47:50 --> Config Class Initialized
INFO - 2016-11-13 03:47:50 --> Hooks Class Initialized
DEBUG - 2016-11-13 03:47:50 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:47:50 --> Utf8 Class Initialized
INFO - 2016-11-13 03:47:50 --> URI Class Initialized
INFO - 2016-11-13 03:47:50 --> Router Class Initialized
INFO - 2016-11-13 03:47:50 --> Output Class Initialized
INFO - 2016-11-13 03:47:50 --> Security Class Initialized
DEBUG - 2016-11-13 03:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:47:50 --> Input Class Initialized
INFO - 2016-11-13 03:47:50 --> Language Class Initialized
INFO - 2016-11-13 03:47:50 --> Loader Class Initialized
INFO - 2016-11-13 03:47:50 --> Helper loaded: url_helper
INFO - 2016-11-13 03:47:50 --> Helper loaded: form_helper
INFO - 2016-11-13 03:47:50 --> Database Driver Class Initialized
INFO - 2016-11-13 03:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:47:50 --> Controller Class Initialized
INFO - 2016-11-13 03:47:50 --> Model Class Initialized
INFO - 2016-11-13 03:47:50 --> Model Class Initialized
INFO - 2016-11-13 03:47:50 --> Model Class Initialized
INFO - 2016-11-13 03:47:50 --> Model Class Initialized
DEBUG - 2016-11-13 03:47:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-13 03:47:50 --> Model Class Initialized
INFO - 2016-11-13 03:47:50 --> Final output sent to browser
DEBUG - 2016-11-13 03:47:50 --> Total execution time: 0.6921
INFO - 2016-11-13 03:47:50 --> Config Class Initialized
INFO - 2016-11-13 03:47:50 --> Hooks Class Initialized
DEBUG - 2016-11-13 03:47:50 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:47:50 --> Utf8 Class Initialized
INFO - 2016-11-13 03:47:50 --> URI Class Initialized
DEBUG - 2016-11-13 03:47:50 --> No URI present. Default controller set.
INFO - 2016-11-13 03:47:50 --> Router Class Initialized
INFO - 2016-11-13 03:47:51 --> Output Class Initialized
INFO - 2016-11-13 03:47:51 --> Security Class Initialized
DEBUG - 2016-11-13 03:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:47:51 --> Input Class Initialized
INFO - 2016-11-13 03:47:51 --> Language Class Initialized
INFO - 2016-11-13 03:47:51 --> Loader Class Initialized
INFO - 2016-11-13 03:47:51 --> Helper loaded: url_helper
INFO - 2016-11-13 03:47:51 --> Helper loaded: form_helper
INFO - 2016-11-13 03:47:51 --> Database Driver Class Initialized
INFO - 2016-11-13 03:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:47:51 --> Controller Class Initialized
INFO - 2016-11-13 03:47:51 --> Model Class Initialized
INFO - 2016-11-13 03:47:51 --> Model Class Initialized
INFO - 2016-11-13 03:47:51 --> Model Class Initialized
INFO - 2016-11-13 03:47:51 --> Model Class Initialized
INFO - 2016-11-13 03:47:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 03:47:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 03:47:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 03:47:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 03:47:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 03:47:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 03:47:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 03:47:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 03:47:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 03:47:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 03:47:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 03:47:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 03:47:52 --> Final output sent to browser
DEBUG - 2016-11-13 03:47:52 --> Total execution time: 1.3593
INFO - 2016-11-13 03:48:33 --> Config Class Initialized
INFO - 2016-11-13 03:48:33 --> Hooks Class Initialized
DEBUG - 2016-11-13 03:48:33 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:48:33 --> Utf8 Class Initialized
INFO - 2016-11-13 03:48:33 --> URI Class Initialized
DEBUG - 2016-11-13 03:48:33 --> No URI present. Default controller set.
INFO - 2016-11-13 03:48:33 --> Router Class Initialized
INFO - 2016-11-13 03:48:33 --> Output Class Initialized
INFO - 2016-11-13 03:48:33 --> Security Class Initialized
DEBUG - 2016-11-13 03:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:48:33 --> Input Class Initialized
INFO - 2016-11-13 03:48:33 --> Language Class Initialized
INFO - 2016-11-13 03:48:34 --> Loader Class Initialized
INFO - 2016-11-13 03:48:34 --> Helper loaded: url_helper
INFO - 2016-11-13 03:48:34 --> Helper loaded: form_helper
INFO - 2016-11-13 03:48:34 --> Database Driver Class Initialized
INFO - 2016-11-13 03:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:48:34 --> Controller Class Initialized
INFO - 2016-11-13 03:48:34 --> Model Class Initialized
INFO - 2016-11-13 03:48:34 --> Model Class Initialized
INFO - 2016-11-13 03:48:34 --> Model Class Initialized
INFO - 2016-11-13 03:48:34 --> Model Class Initialized
INFO - 2016-11-13 03:48:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 03:48:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 03:48:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 03:48:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 03:48:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 03:48:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 03:48:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 03:48:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 03:48:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 03:48:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 03:48:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 03:48:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 03:48:34 --> Final output sent to browser
DEBUG - 2016-11-13 03:48:34 --> Total execution time: 0.7969
INFO - 2016-11-13 03:48:47 --> Config Class Initialized
INFO - 2016-11-13 03:48:47 --> Hooks Class Initialized
DEBUG - 2016-11-13 03:48:47 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:48:47 --> Utf8 Class Initialized
INFO - 2016-11-13 03:48:47 --> URI Class Initialized
INFO - 2016-11-13 03:48:47 --> Router Class Initialized
INFO - 2016-11-13 03:48:47 --> Output Class Initialized
INFO - 2016-11-13 03:48:47 --> Security Class Initialized
DEBUG - 2016-11-13 03:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:48:47 --> Input Class Initialized
INFO - 2016-11-13 03:48:47 --> Language Class Initialized
INFO - 2016-11-13 03:48:47 --> Loader Class Initialized
INFO - 2016-11-13 03:48:47 --> Helper loaded: url_helper
INFO - 2016-11-13 03:48:47 --> Helper loaded: form_helper
INFO - 2016-11-13 03:48:47 --> Database Driver Class Initialized
INFO - 2016-11-13 03:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:48:47 --> Controller Class Initialized
INFO - 2016-11-13 03:48:47 --> Model Class Initialized
INFO - 2016-11-13 03:48:48 --> Form Validation Class Initialized
INFO - 2016-11-13 03:48:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 03:48:48 --> Final output sent to browser
DEBUG - 2016-11-13 03:48:48 --> Total execution time: 0.5591
INFO - 2016-11-13 03:49:03 --> Config Class Initialized
INFO - 2016-11-13 03:49:03 --> Hooks Class Initialized
DEBUG - 2016-11-13 03:49:03 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:49:03 --> Utf8 Class Initialized
INFO - 2016-11-13 03:49:03 --> URI Class Initialized
INFO - 2016-11-13 03:49:03 --> Router Class Initialized
INFO - 2016-11-13 03:49:03 --> Output Class Initialized
INFO - 2016-11-13 03:49:03 --> Security Class Initialized
DEBUG - 2016-11-13 03:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:49:03 --> Input Class Initialized
INFO - 2016-11-13 03:49:03 --> Language Class Initialized
INFO - 2016-11-13 03:49:03 --> Loader Class Initialized
INFO - 2016-11-13 03:49:03 --> Helper loaded: url_helper
INFO - 2016-11-13 03:49:03 --> Helper loaded: form_helper
INFO - 2016-11-13 03:49:03 --> Database Driver Class Initialized
INFO - 2016-11-13 03:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:49:03 --> Controller Class Initialized
INFO - 2016-11-13 03:49:03 --> Model Class Initialized
INFO - 2016-11-13 03:49:03 --> Form Validation Class Initialized
INFO - 2016-11-13 03:49:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 03:49:13 --> Config Class Initialized
INFO - 2016-11-13 03:49:13 --> Hooks Class Initialized
DEBUG - 2016-11-13 03:49:13 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:49:13 --> Utf8 Class Initialized
INFO - 2016-11-13 03:49:13 --> URI Class Initialized
INFO - 2016-11-13 03:49:13 --> Router Class Initialized
INFO - 2016-11-13 03:49:13 --> Output Class Initialized
INFO - 2016-11-13 03:49:13 --> Security Class Initialized
DEBUG - 2016-11-13 03:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:49:13 --> Input Class Initialized
INFO - 2016-11-13 03:49:13 --> Language Class Initialized
INFO - 2016-11-13 03:49:13 --> Loader Class Initialized
INFO - 2016-11-13 03:49:13 --> Helper loaded: url_helper
INFO - 2016-11-13 03:49:13 --> Helper loaded: form_helper
INFO - 2016-11-13 03:49:13 --> Database Driver Class Initialized
INFO - 2016-11-13 03:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:49:14 --> Controller Class Initialized
INFO - 2016-11-13 03:49:14 --> Model Class Initialized
INFO - 2016-11-13 03:49:14 --> Form Validation Class Initialized
INFO - 2016-11-13 03:49:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 03:49:15 --> Config Class Initialized
INFO - 2016-11-13 03:49:15 --> Hooks Class Initialized
DEBUG - 2016-11-13 03:49:15 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:49:15 --> Utf8 Class Initialized
INFO - 2016-11-13 03:49:15 --> URI Class Initialized
INFO - 2016-11-13 03:49:15 --> Router Class Initialized
INFO - 2016-11-13 03:49:15 --> Output Class Initialized
INFO - 2016-11-13 03:49:15 --> Security Class Initialized
DEBUG - 2016-11-13 03:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:49:15 --> Input Class Initialized
INFO - 2016-11-13 03:49:15 --> Language Class Initialized
INFO - 2016-11-13 03:49:15 --> Loader Class Initialized
INFO - 2016-11-13 03:49:15 --> Helper loaded: url_helper
INFO - 2016-11-13 03:49:15 --> Helper loaded: form_helper
INFO - 2016-11-13 03:49:15 --> Database Driver Class Initialized
INFO - 2016-11-13 03:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:49:15 --> Controller Class Initialized
INFO - 2016-11-13 03:49:15 --> Model Class Initialized
INFO - 2016-11-13 03:49:15 --> Form Validation Class Initialized
INFO - 2016-11-13 03:49:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 03:49:28 --> Config Class Initialized
INFO - 2016-11-13 03:49:28 --> Hooks Class Initialized
DEBUG - 2016-11-13 03:49:28 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:49:28 --> Utf8 Class Initialized
INFO - 2016-11-13 03:49:28 --> URI Class Initialized
INFO - 2016-11-13 03:49:28 --> Router Class Initialized
INFO - 2016-11-13 03:49:28 --> Output Class Initialized
INFO - 2016-11-13 03:49:28 --> Security Class Initialized
DEBUG - 2016-11-13 03:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:49:28 --> Input Class Initialized
INFO - 2016-11-13 03:49:28 --> Language Class Initialized
INFO - 2016-11-13 03:49:28 --> Config Class Initialized
INFO - 2016-11-13 03:49:28 --> Loader Class Initialized
INFO - 2016-11-13 03:49:28 --> Hooks Class Initialized
INFO - 2016-11-13 03:49:28 --> Helper loaded: url_helper
DEBUG - 2016-11-13 03:49:28 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:49:28 --> Helper loaded: form_helper
INFO - 2016-11-13 03:49:28 --> Utf8 Class Initialized
INFO - 2016-11-13 03:49:28 --> URI Class Initialized
INFO - 2016-11-13 03:49:28 --> Database Driver Class Initialized
INFO - 2016-11-13 03:49:28 --> Router Class Initialized
INFO - 2016-11-13 03:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:49:28 --> Output Class Initialized
INFO - 2016-11-13 03:49:28 --> Controller Class Initialized
INFO - 2016-11-13 03:49:28 --> Model Class Initialized
INFO - 2016-11-13 03:49:28 --> Security Class Initialized
INFO - 2016-11-13 03:49:28 --> Form Validation Class Initialized
DEBUG - 2016-11-13 03:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:49:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 03:49:28 --> Input Class Initialized
INFO - 2016-11-13 03:49:28 --> Language Class Initialized
INFO - 2016-11-13 03:49:28 --> Loader Class Initialized
INFO - 2016-11-13 03:49:28 --> Helper loaded: url_helper
INFO - 2016-11-13 03:49:28 --> Helper loaded: form_helper
INFO - 2016-11-13 03:49:28 --> Database Driver Class Initialized
INFO - 2016-11-13 03:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:49:28 --> Controller Class Initialized
INFO - 2016-11-13 03:49:29 --> Model Class Initialized
INFO - 2016-11-13 03:49:29 --> Form Validation Class Initialized
INFO - 2016-11-13 03:49:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 03:49:45 --> Config Class Initialized
INFO - 2016-11-13 03:49:45 --> Hooks Class Initialized
DEBUG - 2016-11-13 03:49:45 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:49:45 --> Utf8 Class Initialized
INFO - 2016-11-13 03:49:46 --> URI Class Initialized
INFO - 2016-11-13 03:49:46 --> Router Class Initialized
INFO - 2016-11-13 03:49:46 --> Output Class Initialized
INFO - 2016-11-13 03:49:46 --> Security Class Initialized
INFO - 2016-11-13 03:49:46 --> Config Class Initialized
DEBUG - 2016-11-13 03:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:49:46 --> Hooks Class Initialized
INFO - 2016-11-13 03:49:46 --> Input Class Initialized
DEBUG - 2016-11-13 03:49:46 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:49:46 --> Language Class Initialized
INFO - 2016-11-13 03:49:46 --> Utf8 Class Initialized
INFO - 2016-11-13 03:49:46 --> URI Class Initialized
INFO - 2016-11-13 03:49:46 --> Loader Class Initialized
INFO - 2016-11-13 03:49:46 --> Router Class Initialized
INFO - 2016-11-13 03:49:46 --> Helper loaded: url_helper
INFO - 2016-11-13 03:49:46 --> Output Class Initialized
INFO - 2016-11-13 03:49:46 --> Helper loaded: form_helper
INFO - 2016-11-13 03:49:46 --> Security Class Initialized
INFO - 2016-11-13 03:49:46 --> Database Driver Class Initialized
DEBUG - 2016-11-13 03:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:49:46 --> Input Class Initialized
INFO - 2016-11-13 03:49:46 --> Controller Class Initialized
INFO - 2016-11-13 03:49:46 --> Language Class Initialized
INFO - 2016-11-13 03:49:46 --> Model Class Initialized
INFO - 2016-11-13 03:49:46 --> Loader Class Initialized
INFO - 2016-11-13 03:49:46 --> Form Validation Class Initialized
INFO - 2016-11-13 03:49:46 --> Helper loaded: url_helper
INFO - 2016-11-13 03:49:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 03:49:46 --> Helper loaded: form_helper
INFO - 2016-11-13 03:49:46 --> Database Driver Class Initialized
INFO - 2016-11-13 03:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:49:46 --> Controller Class Initialized
INFO - 2016-11-13 03:49:46 --> Model Class Initialized
INFO - 2016-11-13 03:49:46 --> Form Validation Class Initialized
INFO - 2016-11-13 03:49:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 03:50:14 --> Config Class Initialized
INFO - 2016-11-13 03:50:14 --> Hooks Class Initialized
DEBUG - 2016-11-13 03:50:14 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:50:14 --> Utf8 Class Initialized
INFO - 2016-11-13 03:50:14 --> URI Class Initialized
INFO - 2016-11-13 03:50:14 --> Router Class Initialized
INFO - 2016-11-13 03:50:14 --> Output Class Initialized
INFO - 2016-11-13 03:50:14 --> Security Class Initialized
DEBUG - 2016-11-13 03:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:50:14 --> Input Class Initialized
INFO - 2016-11-13 03:50:14 --> Config Class Initialized
INFO - 2016-11-13 03:50:14 --> Language Class Initialized
INFO - 2016-11-13 03:50:14 --> Hooks Class Initialized
INFO - 2016-11-13 03:50:14 --> Loader Class Initialized
DEBUG - 2016-11-13 03:50:14 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:50:14 --> Utf8 Class Initialized
INFO - 2016-11-13 03:50:14 --> Helper loaded: url_helper
INFO - 2016-11-13 03:50:14 --> URI Class Initialized
INFO - 2016-11-13 03:50:14 --> Helper loaded: form_helper
INFO - 2016-11-13 03:50:14 --> Router Class Initialized
INFO - 2016-11-13 03:50:14 --> Database Driver Class Initialized
INFO - 2016-11-13 03:50:14 --> Output Class Initialized
INFO - 2016-11-13 03:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:50:14 --> Security Class Initialized
INFO - 2016-11-13 03:50:14 --> Controller Class Initialized
INFO - 2016-11-13 03:50:14 --> Model Class Initialized
DEBUG - 2016-11-13 03:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:50:14 --> Form Validation Class Initialized
INFO - 2016-11-13 03:50:14 --> Input Class Initialized
INFO - 2016-11-13 03:50:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 03:50:14 --> Language Class Initialized
INFO - 2016-11-13 03:50:14 --> Loader Class Initialized
INFO - 2016-11-13 03:50:14 --> Helper loaded: url_helper
INFO - 2016-11-13 03:50:14 --> Helper loaded: form_helper
INFO - 2016-11-13 03:50:14 --> Database Driver Class Initialized
INFO - 2016-11-13 03:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:50:14 --> Controller Class Initialized
INFO - 2016-11-13 03:50:14 --> Model Class Initialized
INFO - 2016-11-13 03:50:14 --> Form Validation Class Initialized
INFO - 2016-11-13 03:50:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 03:50:15 --> Config Class Initialized
INFO - 2016-11-13 03:50:15 --> Hooks Class Initialized
DEBUG - 2016-11-13 03:50:15 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:50:15 --> Utf8 Class Initialized
INFO - 2016-11-13 03:50:15 --> URI Class Initialized
INFO - 2016-11-13 03:50:15 --> Router Class Initialized
INFO - 2016-11-13 03:50:15 --> Output Class Initialized
INFO - 2016-11-13 03:50:15 --> Security Class Initialized
DEBUG - 2016-11-13 03:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:50:15 --> Input Class Initialized
INFO - 2016-11-13 03:50:15 --> Language Class Initialized
INFO - 2016-11-13 03:50:15 --> Config Class Initialized
INFO - 2016-11-13 03:50:15 --> Hooks Class Initialized
INFO - 2016-11-13 03:50:15 --> Loader Class Initialized
INFO - 2016-11-13 03:50:15 --> Helper loaded: url_helper
DEBUG - 2016-11-13 03:50:15 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:50:15 --> Helper loaded: form_helper
INFO - 2016-11-13 03:50:15 --> Utf8 Class Initialized
INFO - 2016-11-13 03:50:15 --> URI Class Initialized
INFO - 2016-11-13 03:50:15 --> Database Driver Class Initialized
INFO - 2016-11-13 03:50:15 --> Router Class Initialized
INFO - 2016-11-13 03:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:50:15 --> Output Class Initialized
INFO - 2016-11-13 03:50:15 --> Controller Class Initialized
INFO - 2016-11-13 03:50:15 --> Model Class Initialized
INFO - 2016-11-13 03:50:15 --> Security Class Initialized
INFO - 2016-11-13 03:50:15 --> Form Validation Class Initialized
DEBUG - 2016-11-13 03:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:50:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 03:50:15 --> Input Class Initialized
INFO - 2016-11-13 03:50:15 --> Language Class Initialized
INFO - 2016-11-13 03:50:15 --> Loader Class Initialized
INFO - 2016-11-13 03:50:15 --> Helper loaded: url_helper
INFO - 2016-11-13 03:50:15 --> Helper loaded: form_helper
INFO - 2016-11-13 03:50:15 --> Database Driver Class Initialized
INFO - 2016-11-13 03:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:50:15 --> Controller Class Initialized
INFO - 2016-11-13 03:50:15 --> Model Class Initialized
INFO - 2016-11-13 03:50:15 --> Form Validation Class Initialized
INFO - 2016-11-13 03:50:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 03:50:29 --> Config Class Initialized
INFO - 2016-11-13 03:50:29 --> Hooks Class Initialized
DEBUG - 2016-11-13 03:50:29 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:50:29 --> Utf8 Class Initialized
INFO - 2016-11-13 03:50:29 --> URI Class Initialized
DEBUG - 2016-11-13 03:50:29 --> No URI present. Default controller set.
INFO - 2016-11-13 03:50:29 --> Router Class Initialized
INFO - 2016-11-13 03:50:29 --> Output Class Initialized
INFO - 2016-11-13 03:50:29 --> Security Class Initialized
DEBUG - 2016-11-13 03:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:50:29 --> Input Class Initialized
INFO - 2016-11-13 03:50:29 --> Language Class Initialized
INFO - 2016-11-13 03:50:29 --> Loader Class Initialized
INFO - 2016-11-13 03:50:29 --> Helper loaded: url_helper
INFO - 2016-11-13 03:50:29 --> Helper loaded: form_helper
INFO - 2016-11-13 03:50:29 --> Database Driver Class Initialized
INFO - 2016-11-13 03:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:50:29 --> Controller Class Initialized
INFO - 2016-11-13 03:50:30 --> Model Class Initialized
INFO - 2016-11-13 03:50:30 --> Model Class Initialized
INFO - 2016-11-13 03:50:30 --> Model Class Initialized
INFO - 2016-11-13 03:50:30 --> Model Class Initialized
INFO - 2016-11-13 03:50:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 03:50:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 03:50:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 03:50:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 03:50:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 03:50:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 03:50:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 03:50:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 03:50:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 03:50:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 03:50:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 03:50:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 03:50:30 --> Final output sent to browser
DEBUG - 2016-11-13 03:50:30 --> Total execution time: 0.9161
INFO - 2016-11-13 03:59:54 --> Config Class Initialized
INFO - 2016-11-13 03:59:54 --> Hooks Class Initialized
DEBUG - 2016-11-13 03:59:54 --> UTF-8 Support Enabled
INFO - 2016-11-13 03:59:54 --> Utf8 Class Initialized
INFO - 2016-11-13 03:59:54 --> URI Class Initialized
INFO - 2016-11-13 03:59:55 --> Router Class Initialized
INFO - 2016-11-13 03:59:55 --> Output Class Initialized
INFO - 2016-11-13 03:59:55 --> Security Class Initialized
DEBUG - 2016-11-13 03:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 03:59:55 --> Input Class Initialized
INFO - 2016-11-13 03:59:55 --> Language Class Initialized
INFO - 2016-11-13 03:59:55 --> Loader Class Initialized
INFO - 2016-11-13 03:59:55 --> Helper loaded: url_helper
INFO - 2016-11-13 03:59:55 --> Helper loaded: form_helper
INFO - 2016-11-13 03:59:55 --> Database Driver Class Initialized
INFO - 2016-11-13 03:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 03:59:55 --> Controller Class Initialized
INFO - 2016-11-13 03:59:55 --> Model Class Initialized
INFO - 2016-11-13 03:59:55 --> Form Validation Class Initialized
INFO - 2016-11-13 03:59:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 03:59:55 --> Final output sent to browser
DEBUG - 2016-11-13 03:59:55 --> Total execution time: 0.4418
INFO - 2016-11-13 04:00:14 --> Config Class Initialized
INFO - 2016-11-13 04:00:14 --> Hooks Class Initialized
DEBUG - 2016-11-13 04:00:14 --> UTF-8 Support Enabled
INFO - 2016-11-13 04:00:14 --> Utf8 Class Initialized
INFO - 2016-11-13 04:00:14 --> URI Class Initialized
INFO - 2016-11-13 04:00:14 --> Router Class Initialized
INFO - 2016-11-13 04:00:14 --> Output Class Initialized
INFO - 2016-11-13 04:00:14 --> Security Class Initialized
DEBUG - 2016-11-13 04:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 04:00:14 --> Input Class Initialized
INFO - 2016-11-13 04:00:14 --> Language Class Initialized
INFO - 2016-11-13 04:00:14 --> Loader Class Initialized
INFO - 2016-11-13 04:00:14 --> Helper loaded: url_helper
INFO - 2016-11-13 04:00:14 --> Helper loaded: form_helper
INFO - 2016-11-13 04:00:14 --> Database Driver Class Initialized
INFO - 2016-11-13 04:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 04:00:14 --> Controller Class Initialized
INFO - 2016-11-13 04:00:14 --> Model Class Initialized
INFO - 2016-11-13 04:00:14 --> Model Class Initialized
INFO - 2016-11-13 04:00:14 --> Model Class Initialized
INFO - 2016-11-13 04:00:14 --> Model Class Initialized
DEBUG - 2016-11-13 04:00:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-13 04:00:14 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-13 04:00:15 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-13 04:00:15 --> Config Class Initialized
INFO - 2016-11-13 04:00:15 --> Hooks Class Initialized
DEBUG - 2016-11-13 04:00:15 --> UTF-8 Support Enabled
INFO - 2016-11-13 04:00:15 --> Utf8 Class Initialized
INFO - 2016-11-13 04:00:15 --> URI Class Initialized
DEBUG - 2016-11-13 04:00:15 --> No URI present. Default controller set.
INFO - 2016-11-13 04:00:15 --> Router Class Initialized
INFO - 2016-11-13 04:00:15 --> Output Class Initialized
INFO - 2016-11-13 04:00:15 --> Security Class Initialized
DEBUG - 2016-11-13 04:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 04:00:15 --> Input Class Initialized
INFO - 2016-11-13 04:00:15 --> Language Class Initialized
INFO - 2016-11-13 04:00:15 --> Loader Class Initialized
INFO - 2016-11-13 04:00:15 --> Helper loaded: url_helper
INFO - 2016-11-13 04:00:15 --> Helper loaded: form_helper
INFO - 2016-11-13 04:00:15 --> Database Driver Class Initialized
INFO - 2016-11-13 04:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 04:00:15 --> Controller Class Initialized
INFO - 2016-11-13 04:00:15 --> Model Class Initialized
INFO - 2016-11-13 04:00:15 --> Model Class Initialized
INFO - 2016-11-13 04:00:15 --> Model Class Initialized
INFO - 2016-11-13 04:00:15 --> Model Class Initialized
INFO - 2016-11-13 04:00:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 04:00:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-13 04:00:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 04:00:15 --> Final output sent to browser
DEBUG - 2016-11-13 04:00:15 --> Total execution time: 0.4995
INFO - 2016-11-13 13:51:37 --> Config Class Initialized
INFO - 2016-11-13 13:51:37 --> Hooks Class Initialized
DEBUG - 2016-11-13 13:51:37 --> UTF-8 Support Enabled
INFO - 2016-11-13 13:51:37 --> Utf8 Class Initialized
INFO - 2016-11-13 13:51:38 --> URI Class Initialized
DEBUG - 2016-11-13 13:51:38 --> No URI present. Default controller set.
INFO - 2016-11-13 13:51:38 --> Router Class Initialized
INFO - 2016-11-13 13:51:38 --> Output Class Initialized
INFO - 2016-11-13 13:51:38 --> Security Class Initialized
DEBUG - 2016-11-13 13:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 13:51:38 --> Input Class Initialized
INFO - 2016-11-13 13:51:38 --> Language Class Initialized
INFO - 2016-11-13 13:51:38 --> Loader Class Initialized
INFO - 2016-11-13 13:51:39 --> Helper loaded: url_helper
INFO - 2016-11-13 13:51:39 --> Helper loaded: form_helper
INFO - 2016-11-13 13:51:39 --> Database Driver Class Initialized
INFO - 2016-11-13 13:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 13:51:39 --> Controller Class Initialized
INFO - 2016-11-13 13:51:39 --> Model Class Initialized
INFO - 2016-11-13 13:51:39 --> Model Class Initialized
INFO - 2016-11-13 13:51:40 --> Model Class Initialized
INFO - 2016-11-13 13:51:40 --> Model Class Initialized
INFO - 2016-11-13 13:51:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 13:51:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-13 13:51:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 13:51:40 --> Final output sent to browser
DEBUG - 2016-11-13 13:51:40 --> Total execution time: 2.8013
INFO - 2016-11-13 13:51:59 --> Config Class Initialized
INFO - 2016-11-13 13:51:59 --> Hooks Class Initialized
DEBUG - 2016-11-13 13:51:59 --> UTF-8 Support Enabled
INFO - 2016-11-13 13:51:59 --> Utf8 Class Initialized
INFO - 2016-11-13 13:51:59 --> URI Class Initialized
INFO - 2016-11-13 13:51:59 --> Router Class Initialized
INFO - 2016-11-13 13:51:59 --> Output Class Initialized
INFO - 2016-11-13 13:51:59 --> Security Class Initialized
DEBUG - 2016-11-13 13:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 13:51:59 --> Input Class Initialized
INFO - 2016-11-13 13:51:59 --> Language Class Initialized
INFO - 2016-11-13 13:51:59 --> Loader Class Initialized
INFO - 2016-11-13 13:51:59 --> Helper loaded: url_helper
INFO - 2016-11-13 13:51:59 --> Helper loaded: form_helper
INFO - 2016-11-13 13:51:59 --> Database Driver Class Initialized
INFO - 2016-11-13 13:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 13:51:59 --> Controller Class Initialized
INFO - 2016-11-13 13:51:59 --> Model Class Initialized
INFO - 2016-11-13 13:51:59 --> Model Class Initialized
INFO - 2016-11-13 13:51:59 --> Model Class Initialized
INFO - 2016-11-13 13:51:59 --> Model Class Initialized
DEBUG - 2016-11-13 13:51:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-13 13:51:59 --> Model Class Initialized
INFO - 2016-11-13 13:52:00 --> Final output sent to browser
DEBUG - 2016-11-13 13:52:00 --> Total execution time: 0.9169
INFO - 2016-11-13 13:52:00 --> Config Class Initialized
INFO - 2016-11-13 13:52:00 --> Hooks Class Initialized
DEBUG - 2016-11-13 13:52:00 --> UTF-8 Support Enabled
INFO - 2016-11-13 13:52:00 --> Utf8 Class Initialized
INFO - 2016-11-13 13:52:00 --> URI Class Initialized
DEBUG - 2016-11-13 13:52:00 --> No URI present. Default controller set.
INFO - 2016-11-13 13:52:00 --> Router Class Initialized
INFO - 2016-11-13 13:52:00 --> Output Class Initialized
INFO - 2016-11-13 13:52:00 --> Security Class Initialized
DEBUG - 2016-11-13 13:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 13:52:00 --> Input Class Initialized
INFO - 2016-11-13 13:52:00 --> Language Class Initialized
INFO - 2016-11-13 13:52:00 --> Loader Class Initialized
INFO - 2016-11-13 13:52:00 --> Helper loaded: url_helper
INFO - 2016-11-13 13:52:00 --> Helper loaded: form_helper
INFO - 2016-11-13 13:52:00 --> Database Driver Class Initialized
INFO - 2016-11-13 13:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 13:52:00 --> Controller Class Initialized
INFO - 2016-11-13 13:52:00 --> Model Class Initialized
INFO - 2016-11-13 13:52:00 --> Model Class Initialized
INFO - 2016-11-13 13:52:00 --> Model Class Initialized
INFO - 2016-11-13 13:52:00 --> Model Class Initialized
INFO - 2016-11-13 13:52:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 13:52:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 13:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 13:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 13:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 13:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 13:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 13:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 13:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 13:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 13:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 13:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 13:52:01 --> Final output sent to browser
DEBUG - 2016-11-13 13:52:02 --> Total execution time: 1.5569
INFO - 2016-11-13 13:52:10 --> Config Class Initialized
INFO - 2016-11-13 13:52:10 --> Hooks Class Initialized
DEBUG - 2016-11-13 13:52:10 --> UTF-8 Support Enabled
INFO - 2016-11-13 13:52:10 --> Utf8 Class Initialized
INFO - 2016-11-13 13:52:10 --> URI Class Initialized
DEBUG - 2016-11-13 13:52:10 --> No URI present. Default controller set.
INFO - 2016-11-13 13:52:10 --> Router Class Initialized
INFO - 2016-11-13 13:52:10 --> Output Class Initialized
INFO - 2016-11-13 13:52:10 --> Security Class Initialized
DEBUG - 2016-11-13 13:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 13:52:11 --> Input Class Initialized
INFO - 2016-11-13 13:52:11 --> Language Class Initialized
INFO - 2016-11-13 13:52:11 --> Loader Class Initialized
INFO - 2016-11-13 13:52:11 --> Helper loaded: url_helper
INFO - 2016-11-13 13:52:11 --> Helper loaded: form_helper
INFO - 2016-11-13 13:52:11 --> Database Driver Class Initialized
INFO - 2016-11-13 13:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 13:52:11 --> Controller Class Initialized
INFO - 2016-11-13 13:52:11 --> Model Class Initialized
INFO - 2016-11-13 13:52:11 --> Model Class Initialized
INFO - 2016-11-13 13:52:11 --> Model Class Initialized
INFO - 2016-11-13 13:52:11 --> Model Class Initialized
INFO - 2016-11-13 13:52:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 13:52:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 13:52:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 13:52:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 13:52:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 13:52:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 13:52:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 13:52:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 13:52:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 13:52:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 13:52:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 13:52:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 13:52:11 --> Final output sent to browser
DEBUG - 2016-11-13 13:52:11 --> Total execution time: 0.7911
INFO - 2016-11-13 13:52:35 --> Config Class Initialized
INFO - 2016-11-13 13:52:35 --> Hooks Class Initialized
DEBUG - 2016-11-13 13:52:35 --> UTF-8 Support Enabled
INFO - 2016-11-13 13:52:35 --> Utf8 Class Initialized
INFO - 2016-11-13 13:52:35 --> URI Class Initialized
INFO - 2016-11-13 13:52:35 --> Router Class Initialized
INFO - 2016-11-13 13:52:35 --> Output Class Initialized
INFO - 2016-11-13 13:52:35 --> Security Class Initialized
DEBUG - 2016-11-13 13:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 13:52:35 --> Input Class Initialized
INFO - 2016-11-13 13:52:36 --> Language Class Initialized
INFO - 2016-11-13 13:52:36 --> Loader Class Initialized
INFO - 2016-11-13 13:52:36 --> Helper loaded: url_helper
INFO - 2016-11-13 13:52:36 --> Helper loaded: form_helper
INFO - 2016-11-13 13:52:36 --> Database Driver Class Initialized
INFO - 2016-11-13 13:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 13:52:36 --> Controller Class Initialized
INFO - 2016-11-13 13:52:36 --> Model Class Initialized
INFO - 2016-11-13 13:52:36 --> Model Class Initialized
INFO - 2016-11-13 13:52:36 --> Model Class Initialized
INFO - 2016-11-13 13:52:36 --> Model Class Initialized
DEBUG - 2016-11-13 13:52:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-13 13:52:36 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-13 13:52:36 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-13 13:52:36 --> Config Class Initialized
INFO - 2016-11-13 13:52:36 --> Hooks Class Initialized
DEBUG - 2016-11-13 13:52:36 --> UTF-8 Support Enabled
INFO - 2016-11-13 13:52:36 --> Utf8 Class Initialized
INFO - 2016-11-13 13:52:36 --> URI Class Initialized
DEBUG - 2016-11-13 13:52:36 --> No URI present. Default controller set.
INFO - 2016-11-13 13:52:36 --> Router Class Initialized
INFO - 2016-11-13 13:52:36 --> Output Class Initialized
INFO - 2016-11-13 13:52:36 --> Security Class Initialized
DEBUG - 2016-11-13 13:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 13:52:36 --> Input Class Initialized
INFO - 2016-11-13 13:52:36 --> Language Class Initialized
INFO - 2016-11-13 13:52:36 --> Loader Class Initialized
INFO - 2016-11-13 13:52:36 --> Helper loaded: url_helper
INFO - 2016-11-13 13:52:36 --> Helper loaded: form_helper
INFO - 2016-11-13 13:52:36 --> Database Driver Class Initialized
INFO - 2016-11-13 13:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 13:52:36 --> Controller Class Initialized
INFO - 2016-11-13 13:52:36 --> Model Class Initialized
INFO - 2016-11-13 13:52:36 --> Model Class Initialized
INFO - 2016-11-13 13:52:36 --> Model Class Initialized
INFO - 2016-11-13 13:52:36 --> Model Class Initialized
INFO - 2016-11-13 13:52:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 13:52:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-13 13:52:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 13:52:36 --> Final output sent to browser
DEBUG - 2016-11-13 13:52:37 --> Total execution time: 0.6291
INFO - 2016-11-13 22:36:10 --> Config Class Initialized
INFO - 2016-11-13 22:36:10 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:36:10 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:36:10 --> Utf8 Class Initialized
INFO - 2016-11-13 22:36:10 --> URI Class Initialized
DEBUG - 2016-11-13 22:36:10 --> No URI present. Default controller set.
INFO - 2016-11-13 22:36:10 --> Router Class Initialized
INFO - 2016-11-13 22:36:10 --> Output Class Initialized
INFO - 2016-11-13 22:36:11 --> Security Class Initialized
DEBUG - 2016-11-13 22:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:36:11 --> Input Class Initialized
INFO - 2016-11-13 22:36:11 --> Language Class Initialized
INFO - 2016-11-13 22:36:11 --> Loader Class Initialized
INFO - 2016-11-13 22:36:11 --> Helper loaded: url_helper
INFO - 2016-11-13 22:36:11 --> Helper loaded: form_helper
INFO - 2016-11-13 22:36:11 --> Database Driver Class Initialized
INFO - 2016-11-13 22:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:36:12 --> Controller Class Initialized
INFO - 2016-11-13 22:36:12 --> Model Class Initialized
INFO - 2016-11-13 22:36:12 --> Model Class Initialized
INFO - 2016-11-13 22:36:12 --> Model Class Initialized
INFO - 2016-11-13 22:36:12 --> Model Class Initialized
INFO - 2016-11-13 22:36:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 22:36:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-13 22:36:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 22:36:13 --> Final output sent to browser
DEBUG - 2016-11-13 22:36:13 --> Total execution time: 3.0026
INFO - 2016-11-13 22:36:26 --> Config Class Initialized
INFO - 2016-11-13 22:36:26 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:36:26 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:36:26 --> Utf8 Class Initialized
INFO - 2016-11-13 22:36:26 --> URI Class Initialized
INFO - 2016-11-13 22:36:26 --> Router Class Initialized
INFO - 2016-11-13 22:36:26 --> Output Class Initialized
INFO - 2016-11-13 22:36:26 --> Security Class Initialized
DEBUG - 2016-11-13 22:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:36:26 --> Input Class Initialized
INFO - 2016-11-13 22:36:26 --> Language Class Initialized
INFO - 2016-11-13 22:36:26 --> Loader Class Initialized
INFO - 2016-11-13 22:36:26 --> Helper loaded: url_helper
INFO - 2016-11-13 22:36:26 --> Helper loaded: form_helper
INFO - 2016-11-13 22:36:26 --> Database Driver Class Initialized
INFO - 2016-11-13 22:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:36:26 --> Controller Class Initialized
INFO - 2016-11-13 22:36:26 --> Model Class Initialized
INFO - 2016-11-13 22:36:26 --> Model Class Initialized
INFO - 2016-11-13 22:36:26 --> Model Class Initialized
INFO - 2016-11-13 22:36:27 --> Model Class Initialized
DEBUG - 2016-11-13 22:36:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-13 22:36:27 --> Model Class Initialized
INFO - 2016-11-13 22:36:27 --> Final output sent to browser
DEBUG - 2016-11-13 22:36:27 --> Total execution time: 0.6601
INFO - 2016-11-13 22:36:27 --> Config Class Initialized
INFO - 2016-11-13 22:36:27 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:36:27 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:36:27 --> Utf8 Class Initialized
INFO - 2016-11-13 22:36:27 --> URI Class Initialized
DEBUG - 2016-11-13 22:36:27 --> No URI present. Default controller set.
INFO - 2016-11-13 22:36:27 --> Router Class Initialized
INFO - 2016-11-13 22:36:27 --> Output Class Initialized
INFO - 2016-11-13 22:36:27 --> Security Class Initialized
DEBUG - 2016-11-13 22:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:36:27 --> Input Class Initialized
INFO - 2016-11-13 22:36:27 --> Language Class Initialized
INFO - 2016-11-13 22:36:27 --> Loader Class Initialized
INFO - 2016-11-13 22:36:27 --> Helper loaded: url_helper
INFO - 2016-11-13 22:36:27 --> Helper loaded: form_helper
INFO - 2016-11-13 22:36:27 --> Database Driver Class Initialized
INFO - 2016-11-13 22:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:36:27 --> Controller Class Initialized
INFO - 2016-11-13 22:36:27 --> Model Class Initialized
INFO - 2016-11-13 22:36:27 --> Model Class Initialized
INFO - 2016-11-13 22:36:27 --> Model Class Initialized
INFO - 2016-11-13 22:36:27 --> Model Class Initialized
INFO - 2016-11-13 22:36:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 22:36:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 22:36:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 22:36:28 --> Final output sent to browser
DEBUG - 2016-11-13 22:36:28 --> Total execution time: 1.1942
INFO - 2016-11-13 22:36:40 --> Config Class Initialized
INFO - 2016-11-13 22:36:40 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:36:40 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:36:40 --> Utf8 Class Initialized
INFO - 2016-11-13 22:36:40 --> URI Class Initialized
INFO - 2016-11-13 22:36:40 --> Router Class Initialized
INFO - 2016-11-13 22:36:40 --> Output Class Initialized
INFO - 2016-11-13 22:36:40 --> Security Class Initialized
DEBUG - 2016-11-13 22:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:36:40 --> Input Class Initialized
INFO - 2016-11-13 22:36:40 --> Language Class Initialized
INFO - 2016-11-13 22:36:40 --> Loader Class Initialized
INFO - 2016-11-13 22:36:40 --> Helper loaded: url_helper
INFO - 2016-11-13 22:36:40 --> Helper loaded: form_helper
INFO - 2016-11-13 22:36:40 --> Database Driver Class Initialized
INFO - 2016-11-13 22:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:36:40 --> Controller Class Initialized
INFO - 2016-11-13 22:36:40 --> Model Class Initialized
INFO - 2016-11-13 22:36:40 --> Form Validation Class Initialized
INFO - 2016-11-13 22:36:40 --> Final output sent to browser
DEBUG - 2016-11-13 22:36:40 --> Total execution time: 0.5563
INFO - 2016-11-13 22:36:46 --> Config Class Initialized
INFO - 2016-11-13 22:36:46 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:36:46 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:36:46 --> Utf8 Class Initialized
INFO - 2016-11-13 22:36:46 --> URI Class Initialized
DEBUG - 2016-11-13 22:36:46 --> No URI present. Default controller set.
INFO - 2016-11-13 22:36:46 --> Router Class Initialized
INFO - 2016-11-13 22:36:46 --> Output Class Initialized
INFO - 2016-11-13 22:36:46 --> Security Class Initialized
DEBUG - 2016-11-13 22:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:36:46 --> Input Class Initialized
INFO - 2016-11-13 22:36:46 --> Language Class Initialized
INFO - 2016-11-13 22:36:46 --> Loader Class Initialized
INFO - 2016-11-13 22:36:46 --> Helper loaded: url_helper
INFO - 2016-11-13 22:36:46 --> Helper loaded: form_helper
INFO - 2016-11-13 22:36:46 --> Database Driver Class Initialized
INFO - 2016-11-13 22:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:36:46 --> Controller Class Initialized
INFO - 2016-11-13 22:36:46 --> Model Class Initialized
INFO - 2016-11-13 22:36:46 --> Model Class Initialized
INFO - 2016-11-13 22:36:46 --> Model Class Initialized
INFO - 2016-11-13 22:36:46 --> Model Class Initialized
INFO - 2016-11-13 22:36:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 22:36:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 22:36:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 22:36:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 22:36:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 22:36:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 22:36:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 22:36:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 22:36:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 22:36:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 22:36:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 22:36:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 22:36:47 --> Final output sent to browser
DEBUG - 2016-11-13 22:36:47 --> Total execution time: 0.8632
INFO - 2016-11-13 22:36:54 --> Config Class Initialized
INFO - 2016-11-13 22:36:54 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:36:54 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:36:54 --> Utf8 Class Initialized
INFO - 2016-11-13 22:36:54 --> URI Class Initialized
INFO - 2016-11-13 22:36:54 --> Router Class Initialized
INFO - 2016-11-13 22:36:54 --> Output Class Initialized
INFO - 2016-11-13 22:36:54 --> Security Class Initialized
DEBUG - 2016-11-13 22:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:36:54 --> Input Class Initialized
INFO - 2016-11-13 22:36:54 --> Language Class Initialized
INFO - 2016-11-13 22:36:54 --> Loader Class Initialized
INFO - 2016-11-13 22:36:54 --> Helper loaded: url_helper
INFO - 2016-11-13 22:36:54 --> Helper loaded: form_helper
INFO - 2016-11-13 22:36:54 --> Database Driver Class Initialized
INFO - 2016-11-13 22:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:36:54 --> Controller Class Initialized
INFO - 2016-11-13 22:36:54 --> Model Class Initialized
INFO - 2016-11-13 22:36:54 --> Form Validation Class Initialized
ERROR - 2016-11-13 22:36:55 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-13 22:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-13 22:36:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 22:36:55 --> Final output sent to browser
DEBUG - 2016-11-13 22:36:55 --> Total execution time: 0.7527
INFO - 2016-11-13 22:37:20 --> Config Class Initialized
INFO - 2016-11-13 22:37:21 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:37:21 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:37:21 --> Utf8 Class Initialized
INFO - 2016-11-13 22:37:21 --> URI Class Initialized
INFO - 2016-11-13 22:37:21 --> Router Class Initialized
INFO - 2016-11-13 22:37:21 --> Output Class Initialized
INFO - 2016-11-13 22:37:21 --> Security Class Initialized
DEBUG - 2016-11-13 22:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:37:21 --> Input Class Initialized
INFO - 2016-11-13 22:37:21 --> Language Class Initialized
INFO - 2016-11-13 22:37:21 --> Loader Class Initialized
INFO - 2016-11-13 22:37:21 --> Helper loaded: url_helper
INFO - 2016-11-13 22:37:21 --> Helper loaded: form_helper
INFO - 2016-11-13 22:37:21 --> Database Driver Class Initialized
INFO - 2016-11-13 22:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:37:21 --> Controller Class Initialized
INFO - 2016-11-13 22:37:21 --> Model Class Initialized
INFO - 2016-11-13 22:37:21 --> Form Validation Class Initialized
INFO - 2016-11-13 22:37:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 22:37:21 --> Final output sent to browser
DEBUG - 2016-11-13 22:37:21 --> Total execution time: 0.5499
INFO - 2016-11-13 22:38:18 --> Config Class Initialized
INFO - 2016-11-13 22:38:18 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:38:19 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:38:19 --> Utf8 Class Initialized
INFO - 2016-11-13 22:38:19 --> URI Class Initialized
DEBUG - 2016-11-13 22:38:19 --> No URI present. Default controller set.
INFO - 2016-11-13 22:38:19 --> Router Class Initialized
INFO - 2016-11-13 22:38:19 --> Output Class Initialized
INFO - 2016-11-13 22:38:19 --> Security Class Initialized
DEBUG - 2016-11-13 22:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:38:19 --> Input Class Initialized
INFO - 2016-11-13 22:38:19 --> Language Class Initialized
INFO - 2016-11-13 22:38:19 --> Loader Class Initialized
INFO - 2016-11-13 22:38:19 --> Helper loaded: url_helper
INFO - 2016-11-13 22:38:19 --> Helper loaded: form_helper
INFO - 2016-11-13 22:38:19 --> Database Driver Class Initialized
INFO - 2016-11-13 22:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:38:19 --> Controller Class Initialized
INFO - 2016-11-13 22:38:19 --> Model Class Initialized
INFO - 2016-11-13 22:38:19 --> Model Class Initialized
INFO - 2016-11-13 22:38:19 --> Model Class Initialized
INFO - 2016-11-13 22:38:19 --> Model Class Initialized
INFO - 2016-11-13 22:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 22:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 22:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 22:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 22:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 22:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 22:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 22:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 22:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 22:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 22:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 22:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 22:38:19 --> Final output sent to browser
DEBUG - 2016-11-13 22:38:19 --> Total execution time: 0.8153
INFO - 2016-11-13 22:38:23 --> Config Class Initialized
INFO - 2016-11-13 22:38:23 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:38:23 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:38:23 --> Utf8 Class Initialized
INFO - 2016-11-13 22:38:23 --> URI Class Initialized
INFO - 2016-11-13 22:38:23 --> Router Class Initialized
INFO - 2016-11-13 22:38:23 --> Output Class Initialized
INFO - 2016-11-13 22:38:23 --> Security Class Initialized
DEBUG - 2016-11-13 22:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:38:24 --> Input Class Initialized
INFO - 2016-11-13 22:38:24 --> Language Class Initialized
INFO - 2016-11-13 22:38:24 --> Loader Class Initialized
INFO - 2016-11-13 22:38:24 --> Helper loaded: url_helper
INFO - 2016-11-13 22:38:24 --> Helper loaded: form_helper
INFO - 2016-11-13 22:38:24 --> Database Driver Class Initialized
INFO - 2016-11-13 22:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:38:24 --> Controller Class Initialized
INFO - 2016-11-13 22:38:24 --> Model Class Initialized
INFO - 2016-11-13 22:38:24 --> Form Validation Class Initialized
INFO - 2016-11-13 22:38:26 --> Config Class Initialized
INFO - 2016-11-13 22:38:26 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:38:26 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:38:26 --> Utf8 Class Initialized
INFO - 2016-11-13 22:38:26 --> URI Class Initialized
INFO - 2016-11-13 22:38:26 --> Router Class Initialized
INFO - 2016-11-13 22:38:26 --> Output Class Initialized
INFO - 2016-11-13 22:38:26 --> Security Class Initialized
DEBUG - 2016-11-13 22:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:38:26 --> Input Class Initialized
INFO - 2016-11-13 22:38:26 --> Language Class Initialized
INFO - 2016-11-13 22:38:26 --> Loader Class Initialized
INFO - 2016-11-13 22:38:26 --> Helper loaded: url_helper
INFO - 2016-11-13 22:38:26 --> Helper loaded: form_helper
INFO - 2016-11-13 22:38:26 --> Database Driver Class Initialized
INFO - 2016-11-13 22:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:38:26 --> Controller Class Initialized
INFO - 2016-11-13 22:38:26 --> Model Class Initialized
INFO - 2016-11-13 22:38:26 --> Form Validation Class Initialized
INFO - 2016-11-13 22:38:29 --> Config Class Initialized
INFO - 2016-11-13 22:38:29 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:38:29 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:38:29 --> Utf8 Class Initialized
INFO - 2016-11-13 22:38:29 --> URI Class Initialized
INFO - 2016-11-13 22:38:29 --> Router Class Initialized
INFO - 2016-11-13 22:38:29 --> Output Class Initialized
INFO - 2016-11-13 22:38:29 --> Security Class Initialized
DEBUG - 2016-11-13 22:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:38:29 --> Input Class Initialized
INFO - 2016-11-13 22:38:29 --> Language Class Initialized
INFO - 2016-11-13 22:38:29 --> Loader Class Initialized
INFO - 2016-11-13 22:38:29 --> Helper loaded: url_helper
INFO - 2016-11-13 22:38:29 --> Helper loaded: form_helper
INFO - 2016-11-13 22:38:29 --> Database Driver Class Initialized
INFO - 2016-11-13 22:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:38:29 --> Controller Class Initialized
INFO - 2016-11-13 22:38:29 --> Model Class Initialized
INFO - 2016-11-13 22:38:29 --> Config Class Initialized
INFO - 2016-11-13 22:38:29 --> Form Validation Class Initialized
INFO - 2016-11-13 22:38:29 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:38:29 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:38:29 --> Utf8 Class Initialized
INFO - 2016-11-13 22:38:29 --> URI Class Initialized
INFO - 2016-11-13 22:38:29 --> Router Class Initialized
INFO - 2016-11-13 22:38:29 --> Output Class Initialized
INFO - 2016-11-13 22:38:29 --> Security Class Initialized
DEBUG - 2016-11-13 22:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:38:30 --> Config Class Initialized
INFO - 2016-11-13 22:38:30 --> Input Class Initialized
INFO - 2016-11-13 22:38:30 --> Hooks Class Initialized
INFO - 2016-11-13 22:38:30 --> Language Class Initialized
DEBUG - 2016-11-13 22:38:30 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:38:30 --> Loader Class Initialized
INFO - 2016-11-13 22:38:30 --> Utf8 Class Initialized
INFO - 2016-11-13 22:38:30 --> URI Class Initialized
INFO - 2016-11-13 22:38:30 --> Helper loaded: url_helper
INFO - 2016-11-13 22:38:30 --> Router Class Initialized
INFO - 2016-11-13 22:38:30 --> Helper loaded: form_helper
INFO - 2016-11-13 22:38:30 --> Output Class Initialized
INFO - 2016-11-13 22:38:30 --> Database Driver Class Initialized
INFO - 2016-11-13 22:38:30 --> Security Class Initialized
INFO - 2016-11-13 22:38:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-13 22:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:38:30 --> Controller Class Initialized
INFO - 2016-11-13 22:38:30 --> Input Class Initialized
INFO - 2016-11-13 22:38:30 --> Model Class Initialized
INFO - 2016-11-13 22:38:30 --> Language Class Initialized
INFO - 2016-11-13 22:38:30 --> Form Validation Class Initialized
INFO - 2016-11-13 22:38:30 --> Loader Class Initialized
INFO - 2016-11-13 22:38:30 --> Helper loaded: url_helper
INFO - 2016-11-13 22:38:30 --> Helper loaded: form_helper
INFO - 2016-11-13 22:38:30 --> Database Driver Class Initialized
INFO - 2016-11-13 22:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:38:30 --> Controller Class Initialized
INFO - 2016-11-13 22:38:30 --> Model Class Initialized
INFO - 2016-11-13 22:38:30 --> Config Class Initialized
INFO - 2016-11-13 22:38:30 --> Form Validation Class Initialized
INFO - 2016-11-13 22:38:30 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:38:30 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:38:30 --> Utf8 Class Initialized
INFO - 2016-11-13 22:38:30 --> URI Class Initialized
INFO - 2016-11-13 22:38:30 --> Router Class Initialized
INFO - 2016-11-13 22:38:30 --> Output Class Initialized
INFO - 2016-11-13 22:38:30 --> Security Class Initialized
DEBUG - 2016-11-13 22:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:38:30 --> Input Class Initialized
INFO - 2016-11-13 22:38:30 --> Language Class Initialized
INFO - 2016-11-13 22:38:30 --> Loader Class Initialized
INFO - 2016-11-13 22:38:30 --> Helper loaded: url_helper
INFO - 2016-11-13 22:38:30 --> Helper loaded: form_helper
INFO - 2016-11-13 22:38:30 --> Config Class Initialized
INFO - 2016-11-13 22:38:30 --> Database Driver Class Initialized
INFO - 2016-11-13 22:38:30 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:38:30 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:38:30 --> Utf8 Class Initialized
INFO - 2016-11-13 22:38:30 --> Controller Class Initialized
INFO - 2016-11-13 22:38:30 --> URI Class Initialized
INFO - 2016-11-13 22:38:30 --> Model Class Initialized
INFO - 2016-11-13 22:38:30 --> Router Class Initialized
INFO - 2016-11-13 22:38:30 --> Form Validation Class Initialized
INFO - 2016-11-13 22:38:31 --> Output Class Initialized
INFO - 2016-11-13 22:38:31 --> Security Class Initialized
INFO - 2016-11-13 22:38:31 --> Config Class Initialized
DEBUG - 2016-11-13 22:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:38:31 --> Hooks Class Initialized
INFO - 2016-11-13 22:38:31 --> Input Class Initialized
DEBUG - 2016-11-13 22:38:31 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:38:31 --> Language Class Initialized
INFO - 2016-11-13 22:38:31 --> Utf8 Class Initialized
INFO - 2016-11-13 22:38:31 --> URI Class Initialized
INFO - 2016-11-13 22:38:31 --> Loader Class Initialized
INFO - 2016-11-13 22:38:31 --> Router Class Initialized
INFO - 2016-11-13 22:38:31 --> Helper loaded: url_helper
INFO - 2016-11-13 22:38:31 --> Output Class Initialized
INFO - 2016-11-13 22:38:31 --> Helper loaded: form_helper
INFO - 2016-11-13 22:38:31 --> Security Class Initialized
INFO - 2016-11-13 22:38:31 --> Config Class Initialized
INFO - 2016-11-13 22:38:31 --> Database Driver Class Initialized
INFO - 2016-11-13 22:38:31 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-13 22:38:31 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:38:31 --> Input Class Initialized
INFO - 2016-11-13 22:38:31 --> Controller Class Initialized
INFO - 2016-11-13 22:38:31 --> Utf8 Class Initialized
INFO - 2016-11-13 22:38:31 --> Language Class Initialized
INFO - 2016-11-13 22:38:31 --> Model Class Initialized
INFO - 2016-11-13 22:38:31 --> URI Class Initialized
INFO - 2016-11-13 22:38:31 --> Loader Class Initialized
INFO - 2016-11-13 22:38:31 --> Form Validation Class Initialized
INFO - 2016-11-13 22:38:31 --> Router Class Initialized
INFO - 2016-11-13 22:38:31 --> Helper loaded: url_helper
INFO - 2016-11-13 22:38:31 --> Config Class Initialized
INFO - 2016-11-13 22:38:31 --> Output Class Initialized
INFO - 2016-11-13 22:38:31 --> Helper loaded: form_helper
INFO - 2016-11-13 22:38:31 --> Hooks Class Initialized
INFO - 2016-11-13 22:38:31 --> Security Class Initialized
DEBUG - 2016-11-13 22:38:31 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:38:31 --> Database Driver Class Initialized
DEBUG - 2016-11-13 22:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:38:31 --> Utf8 Class Initialized
INFO - 2016-11-13 22:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:38:31 --> Input Class Initialized
INFO - 2016-11-13 22:38:31 --> URI Class Initialized
INFO - 2016-11-13 22:38:31 --> Controller Class Initialized
INFO - 2016-11-13 22:38:31 --> Language Class Initialized
INFO - 2016-11-13 22:38:31 --> Router Class Initialized
INFO - 2016-11-13 22:38:31 --> Model Class Initialized
INFO - 2016-11-13 22:38:31 --> Loader Class Initialized
INFO - 2016-11-13 22:38:31 --> Output Class Initialized
INFO - 2016-11-13 22:38:31 --> Form Validation Class Initialized
INFO - 2016-11-13 22:38:31 --> Config Class Initialized
INFO - 2016-11-13 22:38:31 --> Helper loaded: url_helper
INFO - 2016-11-13 22:38:31 --> Security Class Initialized
INFO - 2016-11-13 22:38:31 --> Hooks Class Initialized
INFO - 2016-11-13 22:38:31 --> Helper loaded: form_helper
DEBUG - 2016-11-13 22:38:31 --> UTF-8 Support Enabled
DEBUG - 2016-11-13 22:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:38:31 --> Database Driver Class Initialized
INFO - 2016-11-13 22:38:31 --> Utf8 Class Initialized
INFO - 2016-11-13 22:38:31 --> Input Class Initialized
INFO - 2016-11-13 22:38:31 --> Language Class Initialized
INFO - 2016-11-13 22:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:38:31 --> URI Class Initialized
INFO - 2016-11-13 22:38:31 --> Loader Class Initialized
INFO - 2016-11-13 22:38:31 --> Controller Class Initialized
INFO - 2016-11-13 22:38:31 --> Router Class Initialized
INFO - 2016-11-13 22:38:31 --> Model Class Initialized
INFO - 2016-11-13 22:38:31 --> Config Class Initialized
INFO - 2016-11-13 22:38:31 --> Helper loaded: url_helper
INFO - 2016-11-13 22:38:31 --> Output Class Initialized
INFO - 2016-11-13 22:38:31 --> Form Validation Class Initialized
INFO - 2016-11-13 22:38:31 --> Helper loaded: form_helper
INFO - 2016-11-13 22:38:31 --> Hooks Class Initialized
INFO - 2016-11-13 22:38:31 --> Security Class Initialized
DEBUG - 2016-11-13 22:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:38:32 --> Database Driver Class Initialized
DEBUG - 2016-11-13 22:38:32 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:38:32 --> Utf8 Class Initialized
INFO - 2016-11-13 22:38:32 --> Input Class Initialized
INFO - 2016-11-13 22:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:38:32 --> Language Class Initialized
INFO - 2016-11-13 22:38:32 --> URI Class Initialized
INFO - 2016-11-13 22:38:32 --> Controller Class Initialized
INFO - 2016-11-13 22:38:32 --> Config Class Initialized
INFO - 2016-11-13 22:38:32 --> Model Class Initialized
INFO - 2016-11-13 22:38:32 --> Router Class Initialized
INFO - 2016-11-13 22:38:32 --> Hooks Class Initialized
INFO - 2016-11-13 22:38:32 --> Loader Class Initialized
INFO - 2016-11-13 22:38:32 --> Form Validation Class Initialized
INFO - 2016-11-13 22:38:32 --> Output Class Initialized
DEBUG - 2016-11-13 22:38:32 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:38:32 --> Helper loaded: url_helper
INFO - 2016-11-13 22:38:32 --> Security Class Initialized
INFO - 2016-11-13 22:38:32 --> Utf8 Class Initialized
INFO - 2016-11-13 22:38:32 --> Helper loaded: form_helper
DEBUG - 2016-11-13 22:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:38:32 --> URI Class Initialized
INFO - 2016-11-13 22:38:32 --> Input Class Initialized
INFO - 2016-11-13 22:38:32 --> Database Driver Class Initialized
INFO - 2016-11-13 22:38:32 --> Router Class Initialized
INFO - 2016-11-13 22:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:38:32 --> Language Class Initialized
INFO - 2016-11-13 22:38:32 --> Output Class Initialized
INFO - 2016-11-13 22:38:32 --> Controller Class Initialized
INFO - 2016-11-13 22:38:32 --> Model Class Initialized
INFO - 2016-11-13 22:38:32 --> Security Class Initialized
INFO - 2016-11-13 22:38:32 --> Loader Class Initialized
INFO - 2016-11-13 22:38:32 --> Form Validation Class Initialized
INFO - 2016-11-13 22:38:32 --> Helper loaded: url_helper
DEBUG - 2016-11-13 22:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:38:32 --> Input Class Initialized
INFO - 2016-11-13 22:38:32 --> Helper loaded: form_helper
INFO - 2016-11-13 22:38:32 --> Language Class Initialized
INFO - 2016-11-13 22:38:32 --> Database Driver Class Initialized
INFO - 2016-11-13 22:38:32 --> Loader Class Initialized
INFO - 2016-11-13 22:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:38:32 --> Helper loaded: url_helper
INFO - 2016-11-13 22:38:32 --> Controller Class Initialized
INFO - 2016-11-13 22:38:32 --> Model Class Initialized
INFO - 2016-11-13 22:38:32 --> Helper loaded: form_helper
INFO - 2016-11-13 22:38:32 --> Form Validation Class Initialized
INFO - 2016-11-13 22:38:32 --> Database Driver Class Initialized
INFO - 2016-11-13 22:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:38:32 --> Controller Class Initialized
INFO - 2016-11-13 22:38:32 --> Model Class Initialized
INFO - 2016-11-13 22:38:32 --> Form Validation Class Initialized
INFO - 2016-11-13 22:39:00 --> Config Class Initialized
INFO - 2016-11-13 22:39:00 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:39:00 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:39:00 --> Utf8 Class Initialized
INFO - 2016-11-13 22:39:00 --> URI Class Initialized
DEBUG - 2016-11-13 22:39:00 --> No URI present. Default controller set.
INFO - 2016-11-13 22:39:00 --> Router Class Initialized
INFO - 2016-11-13 22:39:00 --> Output Class Initialized
INFO - 2016-11-13 22:39:00 --> Security Class Initialized
DEBUG - 2016-11-13 22:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:39:01 --> Input Class Initialized
INFO - 2016-11-13 22:39:01 --> Language Class Initialized
INFO - 2016-11-13 22:39:01 --> Loader Class Initialized
INFO - 2016-11-13 22:39:01 --> Helper loaded: url_helper
INFO - 2016-11-13 22:39:01 --> Helper loaded: form_helper
INFO - 2016-11-13 22:39:01 --> Database Driver Class Initialized
INFO - 2016-11-13 22:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:39:01 --> Controller Class Initialized
INFO - 2016-11-13 22:39:01 --> Model Class Initialized
INFO - 2016-11-13 22:39:01 --> Model Class Initialized
INFO - 2016-11-13 22:39:01 --> Model Class Initialized
INFO - 2016-11-13 22:39:01 --> Model Class Initialized
INFO - 2016-11-13 22:39:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 22:39:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 22:39:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 22:39:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 22:39:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 22:39:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 22:39:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 22:39:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 22:39:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 22:39:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 22:39:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 22:39:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 22:39:01 --> Final output sent to browser
DEBUG - 2016-11-13 22:39:01 --> Total execution time: 0.9612
INFO - 2016-11-13 22:39:08 --> Config Class Initialized
INFO - 2016-11-13 22:39:08 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:39:08 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:39:08 --> Utf8 Class Initialized
INFO - 2016-11-13 22:39:08 --> URI Class Initialized
INFO - 2016-11-13 22:39:08 --> Router Class Initialized
INFO - 2016-11-13 22:39:08 --> Output Class Initialized
INFO - 2016-11-13 22:39:08 --> Security Class Initialized
DEBUG - 2016-11-13 22:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:39:08 --> Input Class Initialized
INFO - 2016-11-13 22:39:08 --> Language Class Initialized
INFO - 2016-11-13 22:39:08 --> Loader Class Initialized
INFO - 2016-11-13 22:39:08 --> Helper loaded: url_helper
INFO - 2016-11-13 22:39:08 --> Helper loaded: form_helper
INFO - 2016-11-13 22:39:08 --> Database Driver Class Initialized
INFO - 2016-11-13 22:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:39:08 --> Controller Class Initialized
INFO - 2016-11-13 22:39:08 --> Model Class Initialized
INFO - 2016-11-13 22:39:08 --> Form Validation Class Initialized
INFO - 2016-11-13 22:39:09 --> Config Class Initialized
INFO - 2016-11-13 22:39:09 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:39:09 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:39:09 --> Utf8 Class Initialized
INFO - 2016-11-13 22:39:09 --> URI Class Initialized
INFO - 2016-11-13 22:39:09 --> Router Class Initialized
INFO - 2016-11-13 22:39:09 --> Output Class Initialized
INFO - 2016-11-13 22:39:09 --> Security Class Initialized
DEBUG - 2016-11-13 22:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:39:09 --> Config Class Initialized
INFO - 2016-11-13 22:39:09 --> Input Class Initialized
INFO - 2016-11-13 22:39:09 --> Hooks Class Initialized
INFO - 2016-11-13 22:39:09 --> Language Class Initialized
DEBUG - 2016-11-13 22:39:09 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:39:09 --> Loader Class Initialized
INFO - 2016-11-13 22:39:09 --> Utf8 Class Initialized
INFO - 2016-11-13 22:39:09 --> URI Class Initialized
INFO - 2016-11-13 22:39:09 --> Helper loaded: url_helper
INFO - 2016-11-13 22:39:09 --> Config Class Initialized
INFO - 2016-11-13 22:39:09 --> Router Class Initialized
INFO - 2016-11-13 22:39:10 --> Helper loaded: form_helper
INFO - 2016-11-13 22:39:10 --> Hooks Class Initialized
INFO - 2016-11-13 22:39:10 --> Output Class Initialized
DEBUG - 2016-11-13 22:39:10 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:39:10 --> Database Driver Class Initialized
INFO - 2016-11-13 22:39:10 --> Security Class Initialized
INFO - 2016-11-13 22:39:10 --> Utf8 Class Initialized
INFO - 2016-11-13 22:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:39:10 --> URI Class Initialized
INFO - 2016-11-13 22:39:10 --> Controller Class Initialized
DEBUG - 2016-11-13 22:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:39:10 --> Input Class Initialized
INFO - 2016-11-13 22:39:10 --> Config Class Initialized
INFO - 2016-11-13 22:39:10 --> Router Class Initialized
INFO - 2016-11-13 22:39:10 --> Model Class Initialized
INFO - 2016-11-13 22:39:10 --> Language Class Initialized
INFO - 2016-11-13 22:39:10 --> Hooks Class Initialized
INFO - 2016-11-13 22:39:10 --> Output Class Initialized
INFO - 2016-11-13 22:39:10 --> Form Validation Class Initialized
INFO - 2016-11-13 22:39:10 --> Loader Class Initialized
DEBUG - 2016-11-13 22:39:10 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:39:10 --> Security Class Initialized
INFO - 2016-11-13 22:39:10 --> Utf8 Class Initialized
INFO - 2016-11-13 22:39:10 --> Helper loaded: url_helper
INFO - 2016-11-13 22:39:10 --> URI Class Initialized
DEBUG - 2016-11-13 22:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:39:10 --> Helper loaded: form_helper
INFO - 2016-11-13 22:39:10 --> Input Class Initialized
INFO - 2016-11-13 22:39:10 --> Router Class Initialized
INFO - 2016-11-13 22:39:10 --> Language Class Initialized
INFO - 2016-11-13 22:39:10 --> Database Driver Class Initialized
INFO - 2016-11-13 22:39:10 --> Output Class Initialized
INFO - 2016-11-13 22:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:39:10 --> Loader Class Initialized
INFO - 2016-11-13 22:39:10 --> Config Class Initialized
INFO - 2016-11-13 22:39:10 --> Security Class Initialized
INFO - 2016-11-13 22:39:10 --> Controller Class Initialized
INFO - 2016-11-13 22:39:10 --> Hooks Class Initialized
INFO - 2016-11-13 22:39:10 --> Helper loaded: url_helper
DEBUG - 2016-11-13 22:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-13 22:39:10 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:39:10 --> Model Class Initialized
INFO - 2016-11-13 22:39:10 --> Helper loaded: form_helper
INFO - 2016-11-13 22:39:10 --> Input Class Initialized
INFO - 2016-11-13 22:39:10 --> Utf8 Class Initialized
INFO - 2016-11-13 22:39:10 --> Database Driver Class Initialized
INFO - 2016-11-13 22:39:10 --> Language Class Initialized
INFO - 2016-11-13 22:39:10 --> Form Validation Class Initialized
INFO - 2016-11-13 22:39:10 --> URI Class Initialized
INFO - 2016-11-13 22:39:10 --> Loader Class Initialized
INFO - 2016-11-13 22:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:39:10 --> Router Class Initialized
INFO - 2016-11-13 22:39:10 --> Controller Class Initialized
INFO - 2016-11-13 22:39:10 --> Helper loaded: url_helper
INFO - 2016-11-13 22:39:10 --> Output Class Initialized
INFO - 2016-11-13 22:39:10 --> Model Class Initialized
INFO - 2016-11-13 22:39:10 --> Helper loaded: form_helper
INFO - 2016-11-13 22:39:10 --> Form Validation Class Initialized
INFO - 2016-11-13 22:39:10 --> Security Class Initialized
DEBUG - 2016-11-13 22:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:39:10 --> Database Driver Class Initialized
INFO - 2016-11-13 22:39:10 --> Input Class Initialized
INFO - 2016-11-13 22:39:10 --> Language Class Initialized
INFO - 2016-11-13 22:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:39:10 --> Loader Class Initialized
INFO - 2016-11-13 22:39:10 --> Controller Class Initialized
INFO - 2016-11-13 22:39:10 --> Model Class Initialized
INFO - 2016-11-13 22:39:10 --> Helper loaded: url_helper
INFO - 2016-11-13 22:39:10 --> Form Validation Class Initialized
INFO - 2016-11-13 22:39:10 --> Helper loaded: form_helper
INFO - 2016-11-13 22:39:10 --> Database Driver Class Initialized
INFO - 2016-11-13 22:39:10 --> Config Class Initialized
INFO - 2016-11-13 22:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:39:10 --> Hooks Class Initialized
INFO - 2016-11-13 22:39:10 --> Controller Class Initialized
DEBUG - 2016-11-13 22:39:11 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:39:11 --> Utf8 Class Initialized
INFO - 2016-11-13 22:39:11 --> Model Class Initialized
INFO - 2016-11-13 22:39:11 --> URI Class Initialized
INFO - 2016-11-13 22:39:11 --> Form Validation Class Initialized
INFO - 2016-11-13 22:39:11 --> Router Class Initialized
INFO - 2016-11-13 22:39:11 --> Output Class Initialized
INFO - 2016-11-13 22:39:11 --> Security Class Initialized
INFO - 2016-11-13 22:39:11 --> Config Class Initialized
DEBUG - 2016-11-13 22:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:39:11 --> Input Class Initialized
INFO - 2016-11-13 22:39:11 --> Hooks Class Initialized
INFO - 2016-11-13 22:39:11 --> Language Class Initialized
DEBUG - 2016-11-13 22:39:11 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:39:11 --> Utf8 Class Initialized
INFO - 2016-11-13 22:39:11 --> Loader Class Initialized
INFO - 2016-11-13 22:39:11 --> URI Class Initialized
INFO - 2016-11-13 22:39:11 --> Helper loaded: url_helper
INFO - 2016-11-13 22:39:11 --> Router Class Initialized
INFO - 2016-11-13 22:39:11 --> Helper loaded: form_helper
INFO - 2016-11-13 22:39:11 --> Output Class Initialized
INFO - 2016-11-13 22:39:11 --> Config Class Initialized
INFO - 2016-11-13 22:39:11 --> Database Driver Class Initialized
INFO - 2016-11-13 22:39:11 --> Security Class Initialized
INFO - 2016-11-13 22:39:11 --> Hooks Class Initialized
INFO - 2016-11-13 22:39:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-13 22:39:11 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:39:11 --> Controller Class Initialized
DEBUG - 2016-11-13 22:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:39:11 --> Utf8 Class Initialized
INFO - 2016-11-13 22:39:11 --> Input Class Initialized
INFO - 2016-11-13 22:39:11 --> Model Class Initialized
INFO - 2016-11-13 22:39:11 --> Language Class Initialized
INFO - 2016-11-13 22:39:11 --> URI Class Initialized
INFO - 2016-11-13 22:39:11 --> Form Validation Class Initialized
INFO - 2016-11-13 22:39:11 --> Router Class Initialized
INFO - 2016-11-13 22:39:11 --> Loader Class Initialized
INFO - 2016-11-13 22:39:11 --> Config Class Initialized
INFO - 2016-11-13 22:39:11 --> Helper loaded: url_helper
INFO - 2016-11-13 22:39:11 --> Hooks Class Initialized
INFO - 2016-11-13 22:39:11 --> Output Class Initialized
INFO - 2016-11-13 22:39:11 --> Security Class Initialized
DEBUG - 2016-11-13 22:39:11 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:39:11 --> Helper loaded: form_helper
DEBUG - 2016-11-13 22:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:39:11 --> Utf8 Class Initialized
INFO - 2016-11-13 22:39:11 --> Database Driver Class Initialized
INFO - 2016-11-13 22:39:11 --> Input Class Initialized
INFO - 2016-11-13 22:39:11 --> URI Class Initialized
INFO - 2016-11-13 22:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:39:11 --> Language Class Initialized
INFO - 2016-11-13 22:39:11 --> Router Class Initialized
INFO - 2016-11-13 22:39:11 --> Controller Class Initialized
INFO - 2016-11-13 22:39:11 --> Loader Class Initialized
INFO - 2016-11-13 22:39:11 --> Output Class Initialized
INFO - 2016-11-13 22:39:11 --> Model Class Initialized
INFO - 2016-11-13 22:39:11 --> Config Class Initialized
INFO - 2016-11-13 22:39:11 --> Helper loaded: url_helper
INFO - 2016-11-13 22:39:11 --> Form Validation Class Initialized
INFO - 2016-11-13 22:39:11 --> Security Class Initialized
INFO - 2016-11-13 22:39:11 --> Hooks Class Initialized
INFO - 2016-11-13 22:39:11 --> Helper loaded: form_helper
DEBUG - 2016-11-13 22:39:11 --> UTF-8 Support Enabled
DEBUG - 2016-11-13 22:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:39:11 --> Database Driver Class Initialized
INFO - 2016-11-13 22:39:11 --> Utf8 Class Initialized
INFO - 2016-11-13 22:39:11 --> Input Class Initialized
INFO - 2016-11-13 22:39:11 --> Language Class Initialized
INFO - 2016-11-13 22:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:39:12 --> URI Class Initialized
INFO - 2016-11-13 22:39:12 --> Loader Class Initialized
INFO - 2016-11-13 22:39:12 --> Controller Class Initialized
INFO - 2016-11-13 22:39:12 --> Router Class Initialized
INFO - 2016-11-13 22:39:12 --> Model Class Initialized
INFO - 2016-11-13 22:39:12 --> Helper loaded: url_helper
INFO - 2016-11-13 22:39:12 --> Output Class Initialized
INFO - 2016-11-13 22:39:12 --> Config Class Initialized
INFO - 2016-11-13 22:39:12 --> Helper loaded: form_helper
INFO - 2016-11-13 22:39:12 --> Form Validation Class Initialized
INFO - 2016-11-13 22:39:12 --> Hooks Class Initialized
INFO - 2016-11-13 22:39:12 --> Security Class Initialized
INFO - 2016-11-13 22:39:12 --> Database Driver Class Initialized
DEBUG - 2016-11-13 22:39:12 --> UTF-8 Support Enabled
DEBUG - 2016-11-13 22:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:39:12 --> Input Class Initialized
INFO - 2016-11-13 22:39:12 --> Utf8 Class Initialized
INFO - 2016-11-13 22:39:12 --> Controller Class Initialized
INFO - 2016-11-13 22:39:12 --> URI Class Initialized
INFO - 2016-11-13 22:39:12 --> Language Class Initialized
INFO - 2016-11-13 22:39:12 --> Model Class Initialized
INFO - 2016-11-13 22:39:12 --> Router Class Initialized
INFO - 2016-11-13 22:39:12 --> Loader Class Initialized
INFO - 2016-11-13 22:39:12 --> Config Class Initialized
INFO - 2016-11-13 22:39:12 --> Form Validation Class Initialized
INFO - 2016-11-13 22:39:12 --> Helper loaded: url_helper
INFO - 2016-11-13 22:39:12 --> Output Class Initialized
INFO - 2016-11-13 22:39:12 --> Hooks Class Initialized
INFO - 2016-11-13 22:39:12 --> Security Class Initialized
DEBUG - 2016-11-13 22:39:12 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:39:12 --> Helper loaded: form_helper
DEBUG - 2016-11-13 22:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:39:12 --> Utf8 Class Initialized
INFO - 2016-11-13 22:39:12 --> Input Class Initialized
INFO - 2016-11-13 22:39:12 --> Database Driver Class Initialized
INFO - 2016-11-13 22:39:12 --> URI Class Initialized
INFO - 2016-11-13 22:39:12 --> Language Class Initialized
INFO - 2016-11-13 22:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:39:12 --> Router Class Initialized
INFO - 2016-11-13 22:39:12 --> Controller Class Initialized
INFO - 2016-11-13 22:39:12 --> Loader Class Initialized
INFO - 2016-11-13 22:39:12 --> Model Class Initialized
INFO - 2016-11-13 22:39:12 --> Output Class Initialized
INFO - 2016-11-13 22:39:12 --> Config Class Initialized
INFO - 2016-11-13 22:39:12 --> Helper loaded: url_helper
INFO - 2016-11-13 22:39:12 --> Form Validation Class Initialized
INFO - 2016-11-13 22:39:12 --> Security Class Initialized
INFO - 2016-11-13 22:39:12 --> Hooks Class Initialized
INFO - 2016-11-13 22:39:12 --> Helper loaded: form_helper
DEBUG - 2016-11-13 22:39:12 --> UTF-8 Support Enabled
DEBUG - 2016-11-13 22:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:39:12 --> Database Driver Class Initialized
INFO - 2016-11-13 22:39:12 --> Utf8 Class Initialized
INFO - 2016-11-13 22:39:12 --> Input Class Initialized
INFO - 2016-11-13 22:39:12 --> Language Class Initialized
INFO - 2016-11-13 22:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:39:12 --> URI Class Initialized
INFO - 2016-11-13 22:39:12 --> Loader Class Initialized
INFO - 2016-11-13 22:39:12 --> Controller Class Initialized
INFO - 2016-11-13 22:39:12 --> Router Class Initialized
INFO - 2016-11-13 22:39:12 --> Config Class Initialized
INFO - 2016-11-13 22:39:12 --> Helper loaded: url_helper
INFO - 2016-11-13 22:39:12 --> Model Class Initialized
INFO - 2016-11-13 22:39:12 --> Hooks Class Initialized
INFO - 2016-11-13 22:39:12 --> Output Class Initialized
INFO - 2016-11-13 22:39:12 --> Helper loaded: form_helper
INFO - 2016-11-13 22:39:12 --> Form Validation Class Initialized
DEBUG - 2016-11-13 22:39:12 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:39:12 --> Security Class Initialized
INFO - 2016-11-13 22:39:12 --> Utf8 Class Initialized
INFO - 2016-11-13 22:39:12 --> Database Driver Class Initialized
DEBUG - 2016-11-13 22:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:39:12 --> URI Class Initialized
INFO - 2016-11-13 22:39:12 --> Controller Class Initialized
INFO - 2016-11-13 22:39:12 --> Input Class Initialized
INFO - 2016-11-13 22:39:12 --> Router Class Initialized
INFO - 2016-11-13 22:39:12 --> Model Class Initialized
INFO - 2016-11-13 22:39:12 --> Language Class Initialized
INFO - 2016-11-13 22:39:12 --> Output Class Initialized
INFO - 2016-11-13 22:39:12 --> Form Validation Class Initialized
INFO - 2016-11-13 22:39:12 --> Loader Class Initialized
INFO - 2016-11-13 22:39:12 --> Security Class Initialized
INFO - 2016-11-13 22:39:12 --> Helper loaded: url_helper
DEBUG - 2016-11-13 22:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:39:13 --> Helper loaded: form_helper
INFO - 2016-11-13 22:39:13 --> Input Class Initialized
INFO - 2016-11-13 22:39:13 --> Language Class Initialized
INFO - 2016-11-13 22:39:13 --> Database Driver Class Initialized
INFO - 2016-11-13 22:39:13 --> Loader Class Initialized
INFO - 2016-11-13 22:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:39:13 --> Helper loaded: url_helper
INFO - 2016-11-13 22:39:13 --> Controller Class Initialized
INFO - 2016-11-13 22:39:13 --> Model Class Initialized
INFO - 2016-11-13 22:39:13 --> Helper loaded: form_helper
INFO - 2016-11-13 22:39:13 --> Form Validation Class Initialized
INFO - 2016-11-13 22:39:13 --> Database Driver Class Initialized
INFO - 2016-11-13 22:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:39:13 --> Controller Class Initialized
INFO - 2016-11-13 22:39:13 --> Model Class Initialized
INFO - 2016-11-13 22:39:13 --> Form Validation Class Initialized
INFO - 2016-11-13 22:40:57 --> Config Class Initialized
INFO - 2016-11-13 22:40:57 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:40:57 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:40:57 --> Utf8 Class Initialized
INFO - 2016-11-13 22:40:57 --> URI Class Initialized
INFO - 2016-11-13 22:40:57 --> Router Class Initialized
INFO - 2016-11-13 22:40:57 --> Output Class Initialized
INFO - 2016-11-13 22:40:57 --> Security Class Initialized
DEBUG - 2016-11-13 22:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:40:57 --> Input Class Initialized
INFO - 2016-11-13 22:40:57 --> Language Class Initialized
INFO - 2016-11-13 22:40:58 --> Loader Class Initialized
INFO - 2016-11-13 22:40:58 --> Helper loaded: url_helper
INFO - 2016-11-13 22:40:58 --> Helper loaded: form_helper
INFO - 2016-11-13 22:40:58 --> Database Driver Class Initialized
INFO - 2016-11-13 22:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:40:58 --> Controller Class Initialized
INFO - 2016-11-13 22:40:58 --> Model Class Initialized
INFO - 2016-11-13 22:40:58 --> Form Validation Class Initialized
INFO - 2016-11-13 22:41:02 --> Config Class Initialized
INFO - 2016-11-13 22:41:02 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:41:02 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:41:02 --> Utf8 Class Initialized
INFO - 2016-11-13 22:41:02 --> URI Class Initialized
INFO - 2016-11-13 22:41:02 --> Router Class Initialized
INFO - 2016-11-13 22:41:02 --> Output Class Initialized
INFO - 2016-11-13 22:41:02 --> Security Class Initialized
DEBUG - 2016-11-13 22:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:41:02 --> Input Class Initialized
INFO - 2016-11-13 22:41:02 --> Language Class Initialized
INFO - 2016-11-13 22:41:02 --> Loader Class Initialized
INFO - 2016-11-13 22:41:02 --> Helper loaded: url_helper
INFO - 2016-11-13 22:41:03 --> Helper loaded: form_helper
INFO - 2016-11-13 22:41:03 --> Database Driver Class Initialized
INFO - 2016-11-13 22:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:41:03 --> Controller Class Initialized
INFO - 2016-11-13 22:41:03 --> Model Class Initialized
INFO - 2016-11-13 22:41:03 --> Form Validation Class Initialized
INFO - 2016-11-13 22:41:07 --> Config Class Initialized
INFO - 2016-11-13 22:41:07 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:41:08 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:41:08 --> Utf8 Class Initialized
INFO - 2016-11-13 22:41:08 --> URI Class Initialized
INFO - 2016-11-13 22:41:08 --> Router Class Initialized
INFO - 2016-11-13 22:41:08 --> Output Class Initialized
INFO - 2016-11-13 22:41:08 --> Security Class Initialized
DEBUG - 2016-11-13 22:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:41:08 --> Input Class Initialized
INFO - 2016-11-13 22:41:08 --> Language Class Initialized
INFO - 2016-11-13 22:41:08 --> Loader Class Initialized
INFO - 2016-11-13 22:41:08 --> Helper loaded: url_helper
INFO - 2016-11-13 22:41:08 --> Helper loaded: form_helper
INFO - 2016-11-13 22:41:08 --> Database Driver Class Initialized
INFO - 2016-11-13 22:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:41:08 --> Controller Class Initialized
INFO - 2016-11-13 22:41:08 --> Model Class Initialized
INFO - 2016-11-13 22:41:08 --> Form Validation Class Initialized
INFO - 2016-11-13 22:41:08 --> Config Class Initialized
INFO - 2016-11-13 22:41:08 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:41:08 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:41:08 --> Utf8 Class Initialized
INFO - 2016-11-13 22:41:08 --> URI Class Initialized
INFO - 2016-11-13 22:41:09 --> Router Class Initialized
INFO - 2016-11-13 22:41:09 --> Output Class Initialized
INFO - 2016-11-13 22:41:09 --> Security Class Initialized
DEBUG - 2016-11-13 22:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:41:09 --> Input Class Initialized
INFO - 2016-11-13 22:41:09 --> Language Class Initialized
INFO - 2016-11-13 22:41:09 --> Config Class Initialized
INFO - 2016-11-13 22:41:09 --> Loader Class Initialized
INFO - 2016-11-13 22:41:09 --> Hooks Class Initialized
INFO - 2016-11-13 22:41:09 --> Helper loaded: url_helper
DEBUG - 2016-11-13 22:41:09 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:41:09 --> Helper loaded: form_helper
INFO - 2016-11-13 22:41:09 --> Utf8 Class Initialized
INFO - 2016-11-13 22:41:09 --> URI Class Initialized
INFO - 2016-11-13 22:41:09 --> Database Driver Class Initialized
INFO - 2016-11-13 22:41:09 --> Router Class Initialized
INFO - 2016-11-13 22:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:41:09 --> Config Class Initialized
INFO - 2016-11-13 22:41:09 --> Controller Class Initialized
INFO - 2016-11-13 22:41:09 --> Hooks Class Initialized
INFO - 2016-11-13 22:41:09 --> Output Class Initialized
INFO - 2016-11-13 22:41:09 --> Model Class Initialized
DEBUG - 2016-11-13 22:41:09 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:41:09 --> Security Class Initialized
INFO - 2016-11-13 22:41:09 --> Form Validation Class Initialized
INFO - 2016-11-13 22:41:09 --> Utf8 Class Initialized
DEBUG - 2016-11-13 22:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:41:09 --> URI Class Initialized
INFO - 2016-11-13 22:41:09 --> Input Class Initialized
INFO - 2016-11-13 22:41:09 --> Language Class Initialized
INFO - 2016-11-13 22:41:09 --> Router Class Initialized
INFO - 2016-11-13 22:41:09 --> Config Class Initialized
INFO - 2016-11-13 22:41:09 --> Loader Class Initialized
INFO - 2016-11-13 22:41:09 --> Hooks Class Initialized
INFO - 2016-11-13 22:41:09 --> Output Class Initialized
INFO - 2016-11-13 22:41:09 --> Helper loaded: url_helper
DEBUG - 2016-11-13 22:41:09 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:41:09 --> Security Class Initialized
INFO - 2016-11-13 22:41:09 --> Utf8 Class Initialized
INFO - 2016-11-13 22:41:09 --> Helper loaded: form_helper
DEBUG - 2016-11-13 22:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:41:09 --> URI Class Initialized
INFO - 2016-11-13 22:41:09 --> Database Driver Class Initialized
INFO - 2016-11-13 22:41:09 --> Input Class Initialized
INFO - 2016-11-13 22:41:09 --> Language Class Initialized
INFO - 2016-11-13 22:41:09 --> Router Class Initialized
INFO - 2016-11-13 22:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:41:09 --> Loader Class Initialized
INFO - 2016-11-13 22:41:09 --> Config Class Initialized
INFO - 2016-11-13 22:41:09 --> Controller Class Initialized
INFO - 2016-11-13 22:41:09 --> Output Class Initialized
INFO - 2016-11-13 22:41:09 --> Hooks Class Initialized
INFO - 2016-11-13 22:41:09 --> Helper loaded: url_helper
INFO - 2016-11-13 22:41:09 --> Model Class Initialized
INFO - 2016-11-13 22:41:09 --> Security Class Initialized
DEBUG - 2016-11-13 22:41:09 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:41:09 --> Form Validation Class Initialized
INFO - 2016-11-13 22:41:09 --> Utf8 Class Initialized
INFO - 2016-11-13 22:41:09 --> Helper loaded: form_helper
DEBUG - 2016-11-13 22:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:41:09 --> Database Driver Class Initialized
INFO - 2016-11-13 22:41:09 --> Input Class Initialized
INFO - 2016-11-13 22:41:09 --> URI Class Initialized
INFO - 2016-11-13 22:41:09 --> Config Class Initialized
INFO - 2016-11-13 22:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:41:09 --> Language Class Initialized
INFO - 2016-11-13 22:41:09 --> Hooks Class Initialized
INFO - 2016-11-13 22:41:09 --> Router Class Initialized
INFO - 2016-11-13 22:41:09 --> Controller Class Initialized
INFO - 2016-11-13 22:41:09 --> Output Class Initialized
DEBUG - 2016-11-13 22:41:09 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:41:09 --> Loader Class Initialized
INFO - 2016-11-13 22:41:09 --> Model Class Initialized
INFO - 2016-11-13 22:41:09 --> Utf8 Class Initialized
INFO - 2016-11-13 22:41:09 --> Helper loaded: url_helper
INFO - 2016-11-13 22:41:09 --> Security Class Initialized
INFO - 2016-11-13 22:41:09 --> URI Class Initialized
INFO - 2016-11-13 22:41:09 --> Form Validation Class Initialized
DEBUG - 2016-11-13 22:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:41:10 --> Helper loaded: form_helper
INFO - 2016-11-13 22:41:10 --> Config Class Initialized
INFO - 2016-11-13 22:41:10 --> Input Class Initialized
INFO - 2016-11-13 22:41:10 --> Router Class Initialized
INFO - 2016-11-13 22:41:10 --> Database Driver Class Initialized
INFO - 2016-11-13 22:41:10 --> Hooks Class Initialized
INFO - 2016-11-13 22:41:10 --> Language Class Initialized
INFO - 2016-11-13 22:41:10 --> Output Class Initialized
INFO - 2016-11-13 22:41:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-13 22:41:10 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:41:10 --> Security Class Initialized
INFO - 2016-11-13 22:41:10 --> Controller Class Initialized
INFO - 2016-11-13 22:41:10 --> Loader Class Initialized
INFO - 2016-11-13 22:41:10 --> Utf8 Class Initialized
INFO - 2016-11-13 22:41:10 --> Model Class Initialized
INFO - 2016-11-13 22:41:10 --> Helper loaded: url_helper
INFO - 2016-11-13 22:41:10 --> URI Class Initialized
DEBUG - 2016-11-13 22:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:41:10 --> Form Validation Class Initialized
INFO - 2016-11-13 22:41:10 --> Router Class Initialized
INFO - 2016-11-13 22:41:10 --> Config Class Initialized
INFO - 2016-11-13 22:41:10 --> Helper loaded: form_helper
INFO - 2016-11-13 22:41:10 --> Input Class Initialized
INFO - 2016-11-13 22:41:10 --> Hooks Class Initialized
INFO - 2016-11-13 22:41:10 --> Language Class Initialized
INFO - 2016-11-13 22:41:10 --> Database Driver Class Initialized
INFO - 2016-11-13 22:41:10 --> Output Class Initialized
DEBUG - 2016-11-13 22:41:10 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:41:10 --> Security Class Initialized
INFO - 2016-11-13 22:41:10 --> Loader Class Initialized
INFO - 2016-11-13 22:41:10 --> Controller Class Initialized
INFO - 2016-11-13 22:41:10 --> Utf8 Class Initialized
DEBUG - 2016-11-13 22:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:41:10 --> Helper loaded: url_helper
INFO - 2016-11-13 22:41:10 --> Model Class Initialized
INFO - 2016-11-13 22:41:10 --> URI Class Initialized
INFO - 2016-11-13 22:41:10 --> Helper loaded: form_helper
INFO - 2016-11-13 22:41:10 --> Input Class Initialized
INFO - 2016-11-13 22:41:10 --> Router Class Initialized
INFO - 2016-11-13 22:41:10 --> Form Validation Class Initialized
INFO - 2016-11-13 22:41:10 --> Database Driver Class Initialized
INFO - 2016-11-13 22:41:10 --> Language Class Initialized
INFO - 2016-11-13 22:41:10 --> Output Class Initialized
INFO - 2016-11-13 22:41:10 --> Loader Class Initialized
INFO - 2016-11-13 22:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:41:10 --> Controller Class Initialized
INFO - 2016-11-13 22:41:10 --> Security Class Initialized
INFO - 2016-11-13 22:41:10 --> Helper loaded: url_helper
DEBUG - 2016-11-13 22:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:41:10 --> Model Class Initialized
INFO - 2016-11-13 22:41:10 --> Helper loaded: form_helper
INFO - 2016-11-13 22:41:10 --> Input Class Initialized
INFO - 2016-11-13 22:41:10 --> Form Validation Class Initialized
INFO - 2016-11-13 22:41:10 --> Database Driver Class Initialized
INFO - 2016-11-13 22:41:10 --> Language Class Initialized
INFO - 2016-11-13 22:41:10 --> Loader Class Initialized
INFO - 2016-11-13 22:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:41:10 --> Helper loaded: url_helper
INFO - 2016-11-13 22:41:10 --> Controller Class Initialized
INFO - 2016-11-13 22:41:10 --> Model Class Initialized
INFO - 2016-11-13 22:41:10 --> Helper loaded: form_helper
INFO - 2016-11-13 22:41:10 --> Form Validation Class Initialized
INFO - 2016-11-13 22:41:10 --> Database Driver Class Initialized
INFO - 2016-11-13 22:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:41:10 --> Controller Class Initialized
INFO - 2016-11-13 22:41:10 --> Model Class Initialized
INFO - 2016-11-13 22:41:10 --> Form Validation Class Initialized
INFO - 2016-11-13 22:42:37 --> Config Class Initialized
INFO - 2016-11-13 22:42:37 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:42:37 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:42:37 --> Utf8 Class Initialized
INFO - 2016-11-13 22:42:37 --> URI Class Initialized
DEBUG - 2016-11-13 22:42:37 --> No URI present. Default controller set.
INFO - 2016-11-13 22:42:37 --> Router Class Initialized
INFO - 2016-11-13 22:42:37 --> Output Class Initialized
INFO - 2016-11-13 22:42:37 --> Security Class Initialized
DEBUG - 2016-11-13 22:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:42:37 --> Input Class Initialized
INFO - 2016-11-13 22:42:38 --> Language Class Initialized
INFO - 2016-11-13 22:42:38 --> Loader Class Initialized
INFO - 2016-11-13 22:42:38 --> Helper loaded: url_helper
INFO - 2016-11-13 22:42:38 --> Helper loaded: form_helper
INFO - 2016-11-13 22:42:38 --> Database Driver Class Initialized
INFO - 2016-11-13 22:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:42:38 --> Controller Class Initialized
INFO - 2016-11-13 22:42:38 --> Model Class Initialized
INFO - 2016-11-13 22:42:38 --> Model Class Initialized
INFO - 2016-11-13 22:42:38 --> Model Class Initialized
INFO - 2016-11-13 22:42:38 --> Model Class Initialized
INFO - 2016-11-13 22:42:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 22:42:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 22:42:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 22:42:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 22:42:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 22:42:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 22:42:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 22:42:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 22:42:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 22:42:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 22:42:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 22:42:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 22:42:38 --> Final output sent to browser
DEBUG - 2016-11-13 22:42:38 --> Total execution time: 0.9003
INFO - 2016-11-13 22:42:42 --> Config Class Initialized
INFO - 2016-11-13 22:42:42 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:42:42 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:42:42 --> Utf8 Class Initialized
INFO - 2016-11-13 22:42:42 --> URI Class Initialized
INFO - 2016-11-13 22:42:42 --> Router Class Initialized
INFO - 2016-11-13 22:42:42 --> Output Class Initialized
INFO - 2016-11-13 22:42:42 --> Security Class Initialized
DEBUG - 2016-11-13 22:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:42:42 --> Input Class Initialized
INFO - 2016-11-13 22:42:42 --> Language Class Initialized
INFO - 2016-11-13 22:42:42 --> Loader Class Initialized
INFO - 2016-11-13 22:42:42 --> Helper loaded: url_helper
INFO - 2016-11-13 22:42:43 --> Helper loaded: form_helper
INFO - 2016-11-13 22:42:43 --> Database Driver Class Initialized
INFO - 2016-11-13 22:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:42:43 --> Controller Class Initialized
INFO - 2016-11-13 22:42:43 --> Model Class Initialized
INFO - 2016-11-13 22:42:43 --> Form Validation Class Initialized
INFO - 2016-11-13 22:42:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 22:42:43 --> Final output sent to browser
DEBUG - 2016-11-13 22:42:43 --> Total execution time: 0.4647
INFO - 2016-11-13 22:43:05 --> Config Class Initialized
INFO - 2016-11-13 22:43:06 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:43:06 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:43:06 --> Utf8 Class Initialized
INFO - 2016-11-13 22:43:06 --> URI Class Initialized
INFO - 2016-11-13 22:43:06 --> Router Class Initialized
INFO - 2016-11-13 22:43:06 --> Output Class Initialized
INFO - 2016-11-13 22:43:06 --> Security Class Initialized
DEBUG - 2016-11-13 22:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:43:06 --> Input Class Initialized
INFO - 2016-11-13 22:43:06 --> Language Class Initialized
INFO - 2016-11-13 22:43:06 --> Loader Class Initialized
INFO - 2016-11-13 22:43:06 --> Helper loaded: url_helper
INFO - 2016-11-13 22:43:06 --> Helper loaded: form_helper
INFO - 2016-11-13 22:43:06 --> Database Driver Class Initialized
INFO - 2016-11-13 22:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:43:06 --> Controller Class Initialized
INFO - 2016-11-13 22:43:06 --> Model Class Initialized
INFO - 2016-11-13 22:43:06 --> Form Validation Class Initialized
INFO - 2016-11-13 22:43:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 22:44:10 --> Config Class Initialized
INFO - 2016-11-13 22:44:10 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:44:10 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:44:10 --> Utf8 Class Initialized
INFO - 2016-11-13 22:44:10 --> URI Class Initialized
DEBUG - 2016-11-13 22:44:10 --> No URI present. Default controller set.
INFO - 2016-11-13 22:44:10 --> Router Class Initialized
INFO - 2016-11-13 22:44:10 --> Output Class Initialized
INFO - 2016-11-13 22:44:10 --> Security Class Initialized
DEBUG - 2016-11-13 22:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:44:10 --> Input Class Initialized
INFO - 2016-11-13 22:44:10 --> Language Class Initialized
INFO - 2016-11-13 22:44:10 --> Loader Class Initialized
INFO - 2016-11-13 22:44:10 --> Helper loaded: url_helper
INFO - 2016-11-13 22:44:10 --> Helper loaded: form_helper
INFO - 2016-11-13 22:44:10 --> Database Driver Class Initialized
INFO - 2016-11-13 22:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:44:10 --> Controller Class Initialized
INFO - 2016-11-13 22:44:10 --> Model Class Initialized
INFO - 2016-11-13 22:44:10 --> Model Class Initialized
INFO - 2016-11-13 22:44:10 --> Model Class Initialized
INFO - 2016-11-13 22:44:10 --> Model Class Initialized
INFO - 2016-11-13 22:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 22:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 22:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 22:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 22:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 22:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 22:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 22:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 22:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 22:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 22:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 22:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 22:44:10 --> Final output sent to browser
DEBUG - 2016-11-13 22:44:10 --> Total execution time: 0.8737
INFO - 2016-11-13 22:44:24 --> Config Class Initialized
INFO - 2016-11-13 22:44:24 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:44:24 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:44:24 --> Utf8 Class Initialized
INFO - 2016-11-13 22:44:24 --> URI Class Initialized
INFO - 2016-11-13 22:44:24 --> Router Class Initialized
INFO - 2016-11-13 22:44:24 --> Output Class Initialized
INFO - 2016-11-13 22:44:24 --> Security Class Initialized
DEBUG - 2016-11-13 22:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:44:24 --> Input Class Initialized
INFO - 2016-11-13 22:44:24 --> Language Class Initialized
INFO - 2016-11-13 22:44:24 --> Loader Class Initialized
INFO - 2016-11-13 22:44:24 --> Helper loaded: url_helper
INFO - 2016-11-13 22:44:24 --> Helper loaded: form_helper
INFO - 2016-11-13 22:44:24 --> Database Driver Class Initialized
INFO - 2016-11-13 22:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:44:24 --> Controller Class Initialized
INFO - 2016-11-13 22:44:24 --> Model Class Initialized
INFO - 2016-11-13 22:44:24 --> Form Validation Class Initialized
INFO - 2016-11-13 22:44:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 22:44:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 22:44:25 --> Final output sent to browser
DEBUG - 2016-11-13 22:44:25 --> Total execution time: 0.6157
INFO - 2016-11-13 22:44:27 --> Config Class Initialized
INFO - 2016-11-13 22:44:27 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:44:27 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:44:27 --> Utf8 Class Initialized
INFO - 2016-11-13 22:44:28 --> URI Class Initialized
INFO - 2016-11-13 22:44:28 --> Router Class Initialized
INFO - 2016-11-13 22:44:28 --> Output Class Initialized
INFO - 2016-11-13 22:44:28 --> Security Class Initialized
DEBUG - 2016-11-13 22:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:44:28 --> Input Class Initialized
INFO - 2016-11-13 22:44:28 --> Language Class Initialized
INFO - 2016-11-13 22:44:28 --> Loader Class Initialized
INFO - 2016-11-13 22:44:28 --> Helper loaded: url_helper
INFO - 2016-11-13 22:44:28 --> Helper loaded: form_helper
INFO - 2016-11-13 22:44:28 --> Database Driver Class Initialized
INFO - 2016-11-13 22:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:44:28 --> Controller Class Initialized
INFO - 2016-11-13 22:44:28 --> Model Class Initialized
INFO - 2016-11-13 22:44:28 --> Form Validation Class Initialized
INFO - 2016-11-13 22:44:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 22:44:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 22:44:28 --> Final output sent to browser
DEBUG - 2016-11-13 22:44:28 --> Total execution time: 0.5977
INFO - 2016-11-13 22:44:35 --> Config Class Initialized
INFO - 2016-11-13 22:44:35 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:44:35 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:44:35 --> Utf8 Class Initialized
INFO - 2016-11-13 22:44:35 --> URI Class Initialized
DEBUG - 2016-11-13 22:44:35 --> No URI present. Default controller set.
INFO - 2016-11-13 22:44:35 --> Router Class Initialized
INFO - 2016-11-13 22:44:35 --> Output Class Initialized
INFO - 2016-11-13 22:44:35 --> Security Class Initialized
DEBUG - 2016-11-13 22:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:44:35 --> Input Class Initialized
INFO - 2016-11-13 22:44:35 --> Language Class Initialized
INFO - 2016-11-13 22:44:35 --> Loader Class Initialized
INFO - 2016-11-13 22:44:35 --> Helper loaded: url_helper
INFO - 2016-11-13 22:44:35 --> Helper loaded: form_helper
INFO - 2016-11-13 22:44:35 --> Database Driver Class Initialized
INFO - 2016-11-13 22:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:44:35 --> Controller Class Initialized
INFO - 2016-11-13 22:44:35 --> Model Class Initialized
INFO - 2016-11-13 22:44:36 --> Model Class Initialized
INFO - 2016-11-13 22:44:36 --> Model Class Initialized
INFO - 2016-11-13 22:44:36 --> Model Class Initialized
INFO - 2016-11-13 22:44:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 22:44:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 22:44:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 22:44:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 22:44:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 22:44:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 22:44:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 22:44:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 22:44:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 22:44:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 22:44:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 22:44:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 22:44:36 --> Final output sent to browser
DEBUG - 2016-11-13 22:44:36 --> Total execution time: 0.8614
INFO - 2016-11-13 22:45:43 --> Config Class Initialized
INFO - 2016-11-13 22:45:43 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:45:43 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:45:43 --> Utf8 Class Initialized
INFO - 2016-11-13 22:45:43 --> URI Class Initialized
DEBUG - 2016-11-13 22:45:43 --> No URI present. Default controller set.
INFO - 2016-11-13 22:45:43 --> Router Class Initialized
INFO - 2016-11-13 22:45:43 --> Output Class Initialized
INFO - 2016-11-13 22:45:43 --> Security Class Initialized
DEBUG - 2016-11-13 22:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:45:43 --> Input Class Initialized
INFO - 2016-11-13 22:45:43 --> Language Class Initialized
INFO - 2016-11-13 22:45:43 --> Loader Class Initialized
INFO - 2016-11-13 22:45:43 --> Helper loaded: url_helper
INFO - 2016-11-13 22:45:43 --> Helper loaded: form_helper
INFO - 2016-11-13 22:45:43 --> Database Driver Class Initialized
INFO - 2016-11-13 22:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:45:43 --> Controller Class Initialized
INFO - 2016-11-13 22:45:43 --> Model Class Initialized
INFO - 2016-11-13 22:45:43 --> Model Class Initialized
INFO - 2016-11-13 22:45:43 --> Model Class Initialized
INFO - 2016-11-13 22:45:43 --> Model Class Initialized
INFO - 2016-11-13 22:45:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 22:45:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 22:45:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 22:45:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 22:45:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 22:45:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 22:45:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 22:45:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 22:45:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 22:45:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 22:45:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 22:45:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 22:45:44 --> Final output sent to browser
DEBUG - 2016-11-13 22:45:44 --> Total execution time: 0.8921
INFO - 2016-11-13 22:45:48 --> Config Class Initialized
INFO - 2016-11-13 22:45:48 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:45:48 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:45:48 --> Utf8 Class Initialized
INFO - 2016-11-13 22:45:48 --> URI Class Initialized
INFO - 2016-11-13 22:45:48 --> Router Class Initialized
INFO - 2016-11-13 22:45:48 --> Output Class Initialized
INFO - 2016-11-13 22:45:49 --> Security Class Initialized
DEBUG - 2016-11-13 22:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:45:49 --> Input Class Initialized
INFO - 2016-11-13 22:45:49 --> Language Class Initialized
INFO - 2016-11-13 22:45:49 --> Loader Class Initialized
INFO - 2016-11-13 22:45:49 --> Helper loaded: url_helper
INFO - 2016-11-13 22:45:49 --> Helper loaded: form_helper
INFO - 2016-11-13 22:45:49 --> Database Driver Class Initialized
INFO - 2016-11-13 22:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:45:49 --> Controller Class Initialized
INFO - 2016-11-13 22:45:49 --> Model Class Initialized
INFO - 2016-11-13 22:45:49 --> Form Validation Class Initialized
INFO - 2016-11-13 22:45:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 22:45:49 --> Final output sent to browser
DEBUG - 2016-11-13 22:45:49 --> Total execution time: 0.4901
INFO - 2016-11-13 22:45:57 --> Config Class Initialized
INFO - 2016-11-13 22:45:57 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:45:57 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:45:57 --> Utf8 Class Initialized
INFO - 2016-11-13 22:45:57 --> URI Class Initialized
INFO - 2016-11-13 22:45:57 --> Router Class Initialized
INFO - 2016-11-13 22:45:57 --> Output Class Initialized
INFO - 2016-11-13 22:45:57 --> Security Class Initialized
DEBUG - 2016-11-13 22:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:45:57 --> Input Class Initialized
INFO - 2016-11-13 22:45:57 --> Language Class Initialized
INFO - 2016-11-13 22:45:57 --> Loader Class Initialized
INFO - 2016-11-13 22:45:57 --> Helper loaded: url_helper
INFO - 2016-11-13 22:45:57 --> Helper loaded: form_helper
INFO - 2016-11-13 22:45:57 --> Database Driver Class Initialized
INFO - 2016-11-13 22:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:45:57 --> Controller Class Initialized
INFO - 2016-11-13 22:45:57 --> Model Class Initialized
INFO - 2016-11-13 22:45:57 --> Form Validation Class Initialized
INFO - 2016-11-13 22:45:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 22:45:57 --> Final output sent to browser
DEBUG - 2016-11-13 22:45:57 --> Total execution time: 0.4836
INFO - 2016-11-13 22:46:07 --> Config Class Initialized
INFO - 2016-11-13 22:46:07 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:46:07 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:46:07 --> Utf8 Class Initialized
INFO - 2016-11-13 22:46:07 --> URI Class Initialized
INFO - 2016-11-13 22:46:07 --> Router Class Initialized
INFO - 2016-11-13 22:46:07 --> Output Class Initialized
INFO - 2016-11-13 22:46:07 --> Security Class Initialized
DEBUG - 2016-11-13 22:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:46:07 --> Input Class Initialized
INFO - 2016-11-13 22:46:07 --> Language Class Initialized
INFO - 2016-11-13 22:46:07 --> Loader Class Initialized
INFO - 2016-11-13 22:46:07 --> Helper loaded: url_helper
INFO - 2016-11-13 22:46:07 --> Helper loaded: form_helper
INFO - 2016-11-13 22:46:07 --> Database Driver Class Initialized
INFO - 2016-11-13 22:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:46:07 --> Controller Class Initialized
INFO - 2016-11-13 22:46:07 --> Model Class Initialized
INFO - 2016-11-13 22:46:07 --> Form Validation Class Initialized
INFO - 2016-11-13 22:46:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-13 22:46:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 22:46:07 --> Final output sent to browser
DEBUG - 2016-11-13 22:46:07 --> Total execution time: 0.6407
INFO - 2016-11-13 22:46:32 --> Config Class Initialized
INFO - 2016-11-13 22:46:32 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:46:32 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:46:32 --> Utf8 Class Initialized
INFO - 2016-11-13 22:46:32 --> URI Class Initialized
DEBUG - 2016-11-13 22:46:32 --> No URI present. Default controller set.
INFO - 2016-11-13 22:46:32 --> Router Class Initialized
INFO - 2016-11-13 22:46:32 --> Output Class Initialized
INFO - 2016-11-13 22:46:32 --> Security Class Initialized
DEBUG - 2016-11-13 22:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:46:32 --> Input Class Initialized
INFO - 2016-11-13 22:46:32 --> Language Class Initialized
INFO - 2016-11-13 22:46:32 --> Loader Class Initialized
INFO - 2016-11-13 22:46:32 --> Helper loaded: url_helper
INFO - 2016-11-13 22:46:32 --> Helper loaded: form_helper
INFO - 2016-11-13 22:46:32 --> Database Driver Class Initialized
INFO - 2016-11-13 22:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:46:32 --> Controller Class Initialized
INFO - 2016-11-13 22:46:32 --> Model Class Initialized
INFO - 2016-11-13 22:46:32 --> Model Class Initialized
INFO - 2016-11-13 22:46:32 --> Model Class Initialized
INFO - 2016-11-13 22:46:32 --> Model Class Initialized
INFO - 2016-11-13 22:46:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 22:46:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-13 22:46:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-13 22:46:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-13 22:46:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-13 22:46:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-13 22:46:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-13 22:46:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-13 22:46:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-13 22:46:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-13 22:46:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-13 22:46:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 22:46:33 --> Final output sent to browser
DEBUG - 2016-11-13 22:46:33 --> Total execution time: 0.9163
INFO - 2016-11-13 22:48:55 --> Config Class Initialized
INFO - 2016-11-13 22:48:55 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:48:55 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:48:55 --> Utf8 Class Initialized
INFO - 2016-11-13 22:48:55 --> URI Class Initialized
INFO - 2016-11-13 22:48:55 --> Router Class Initialized
INFO - 2016-11-13 22:48:55 --> Output Class Initialized
INFO - 2016-11-13 22:48:56 --> Security Class Initialized
DEBUG - 2016-11-13 22:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:48:56 --> Input Class Initialized
INFO - 2016-11-13 22:48:56 --> Language Class Initialized
INFO - 2016-11-13 22:48:56 --> Loader Class Initialized
INFO - 2016-11-13 22:48:56 --> Helper loaded: url_helper
INFO - 2016-11-13 22:48:56 --> Helper loaded: form_helper
INFO - 2016-11-13 22:48:56 --> Database Driver Class Initialized
INFO - 2016-11-13 22:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:48:56 --> Controller Class Initialized
INFO - 2016-11-13 22:48:56 --> Model Class Initialized
INFO - 2016-11-13 22:48:56 --> Model Class Initialized
INFO - 2016-11-13 22:48:56 --> Model Class Initialized
INFO - 2016-11-13 22:48:56 --> Model Class Initialized
DEBUG - 2016-11-13 22:48:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-13 22:48:56 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-13 22:48:56 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-13 22:48:56 --> Config Class Initialized
INFO - 2016-11-13 22:48:56 --> Hooks Class Initialized
DEBUG - 2016-11-13 22:48:56 --> UTF-8 Support Enabled
INFO - 2016-11-13 22:48:56 --> Utf8 Class Initialized
INFO - 2016-11-13 22:48:56 --> URI Class Initialized
DEBUG - 2016-11-13 22:48:56 --> No URI present. Default controller set.
INFO - 2016-11-13 22:48:56 --> Router Class Initialized
INFO - 2016-11-13 22:48:56 --> Output Class Initialized
INFO - 2016-11-13 22:48:56 --> Security Class Initialized
DEBUG - 2016-11-13 22:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 22:48:56 --> Input Class Initialized
INFO - 2016-11-13 22:48:56 --> Language Class Initialized
INFO - 2016-11-13 22:48:56 --> Loader Class Initialized
INFO - 2016-11-13 22:48:56 --> Helper loaded: url_helper
INFO - 2016-11-13 22:48:56 --> Helper loaded: form_helper
INFO - 2016-11-13 22:48:56 --> Database Driver Class Initialized
INFO - 2016-11-13 22:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 22:48:56 --> Controller Class Initialized
INFO - 2016-11-13 22:48:56 --> Model Class Initialized
INFO - 2016-11-13 22:48:56 --> Model Class Initialized
INFO - 2016-11-13 22:48:56 --> Model Class Initialized
INFO - 2016-11-13 22:48:56 --> Model Class Initialized
INFO - 2016-11-13 22:48:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-13 22:48:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-13 22:48:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-13 22:48:57 --> Final output sent to browser
DEBUG - 2016-11-13 22:48:57 --> Total execution time: 0.5552
