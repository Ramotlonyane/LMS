<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-09 12:20:37 --> Config Class Initialized
INFO - 2016-11-09 12:20:37 --> Hooks Class Initialized
DEBUG - 2016-11-09 12:20:37 --> UTF-8 Support Enabled
INFO - 2016-11-09 12:20:37 --> Utf8 Class Initialized
INFO - 2016-11-09 12:20:37 --> URI Class Initialized
DEBUG - 2016-11-09 12:20:37 --> No URI present. Default controller set.
INFO - 2016-11-09 12:20:37 --> Router Class Initialized
INFO - 2016-11-09 12:20:38 --> Output Class Initialized
INFO - 2016-11-09 12:20:38 --> Security Class Initialized
DEBUG - 2016-11-09 12:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 12:20:38 --> Input Class Initialized
INFO - 2016-11-09 12:20:38 --> Language Class Initialized
INFO - 2016-11-09 12:20:38 --> Loader Class Initialized
INFO - 2016-11-09 12:20:38 --> Helper loaded: url_helper
INFO - 2016-11-09 12:20:38 --> Helper loaded: form_helper
INFO - 2016-11-09 12:20:38 --> Database Driver Class Initialized
INFO - 2016-11-09 12:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 12:20:38 --> Controller Class Initialized
INFO - 2016-11-09 12:20:38 --> Model Class Initialized
INFO - 2016-11-09 12:20:38 --> Model Class Initialized
INFO - 2016-11-09 12:20:38 --> Model Class Initialized
INFO - 2016-11-09 12:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 12:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-09 12:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 12:20:38 --> Final output sent to browser
DEBUG - 2016-11-09 12:20:38 --> Total execution time: 1.1371
INFO - 2016-11-09 12:21:07 --> Config Class Initialized
INFO - 2016-11-09 12:21:07 --> Hooks Class Initialized
DEBUG - 2016-11-09 12:21:07 --> UTF-8 Support Enabled
INFO - 2016-11-09 12:21:07 --> Utf8 Class Initialized
INFO - 2016-11-09 12:21:07 --> URI Class Initialized
INFO - 2016-11-09 12:21:07 --> Router Class Initialized
INFO - 2016-11-09 12:21:07 --> Output Class Initialized
INFO - 2016-11-09 12:21:07 --> Security Class Initialized
DEBUG - 2016-11-09 12:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 12:21:07 --> Input Class Initialized
INFO - 2016-11-09 12:21:07 --> Language Class Initialized
INFO - 2016-11-09 12:21:07 --> Loader Class Initialized
INFO - 2016-11-09 12:21:07 --> Helper loaded: url_helper
INFO - 2016-11-09 12:21:07 --> Helper loaded: form_helper
INFO - 2016-11-09 12:21:07 --> Database Driver Class Initialized
INFO - 2016-11-09 12:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 12:21:07 --> Controller Class Initialized
INFO - 2016-11-09 12:21:07 --> Model Class Initialized
INFO - 2016-11-09 12:21:07 --> Model Class Initialized
INFO - 2016-11-09 12:21:07 --> Model Class Initialized
DEBUG - 2016-11-09 12:21:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-09 12:21:07 --> Model Class Initialized
INFO - 2016-11-09 12:21:07 --> Final output sent to browser
DEBUG - 2016-11-09 12:21:07 --> Total execution time: 0.4916
INFO - 2016-11-09 12:21:07 --> Config Class Initialized
INFO - 2016-11-09 12:21:07 --> Hooks Class Initialized
DEBUG - 2016-11-09 12:21:07 --> UTF-8 Support Enabled
INFO - 2016-11-09 12:21:07 --> Utf8 Class Initialized
INFO - 2016-11-09 12:21:07 --> URI Class Initialized
DEBUG - 2016-11-09 12:21:07 --> No URI present. Default controller set.
INFO - 2016-11-09 12:21:07 --> Router Class Initialized
INFO - 2016-11-09 12:21:07 --> Output Class Initialized
INFO - 2016-11-09 12:21:07 --> Security Class Initialized
DEBUG - 2016-11-09 12:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 12:21:07 --> Input Class Initialized
INFO - 2016-11-09 12:21:07 --> Language Class Initialized
INFO - 2016-11-09 12:21:07 --> Loader Class Initialized
INFO - 2016-11-09 12:21:07 --> Helper loaded: url_helper
INFO - 2016-11-09 12:21:07 --> Helper loaded: form_helper
INFO - 2016-11-09 12:21:07 --> Database Driver Class Initialized
INFO - 2016-11-09 12:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 12:21:07 --> Controller Class Initialized
INFO - 2016-11-09 12:21:07 --> Model Class Initialized
INFO - 2016-11-09 12:21:07 --> Model Class Initialized
INFO - 2016-11-09 12:21:07 --> Model Class Initialized
INFO - 2016-11-09 12:21:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 12:21:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 12:21:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 12:21:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 12:21:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 12:21:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 12:21:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 12:21:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 12:21:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 12:21:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 12:21:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 12:21:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 12:21:08 --> Final output sent to browser
DEBUG - 2016-11-09 12:21:08 --> Total execution time: 0.9432
INFO - 2016-11-09 12:21:40 --> Config Class Initialized
INFO - 2016-11-09 12:21:40 --> Hooks Class Initialized
DEBUG - 2016-11-09 12:21:40 --> UTF-8 Support Enabled
INFO - 2016-11-09 12:21:40 --> Utf8 Class Initialized
INFO - 2016-11-09 12:21:40 --> URI Class Initialized
INFO - 2016-11-09 12:21:40 --> Router Class Initialized
INFO - 2016-11-09 12:21:40 --> Output Class Initialized
INFO - 2016-11-09 12:21:40 --> Security Class Initialized
DEBUG - 2016-11-09 12:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 12:21:40 --> Input Class Initialized
INFO - 2016-11-09 12:21:40 --> Language Class Initialized
INFO - 2016-11-09 12:21:40 --> Loader Class Initialized
INFO - 2016-11-09 12:21:40 --> Helper loaded: url_helper
INFO - 2016-11-09 12:21:40 --> Helper loaded: form_helper
INFO - 2016-11-09 12:21:40 --> Database Driver Class Initialized
INFO - 2016-11-09 12:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 12:21:40 --> Controller Class Initialized
INFO - 2016-11-09 12:21:40 --> Model Class Initialized
INFO - 2016-11-09 12:21:40 --> Model Class Initialized
INFO - 2016-11-09 12:21:40 --> Model Class Initialized
DEBUG - 2016-11-09 12:21:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-09 12:21:40 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 127
ERROR - 2016-11-09 12:21:40 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 127
INFO - 2016-11-09 12:21:40 --> Config Class Initialized
INFO - 2016-11-09 12:21:40 --> Hooks Class Initialized
DEBUG - 2016-11-09 12:21:40 --> UTF-8 Support Enabled
INFO - 2016-11-09 12:21:40 --> Utf8 Class Initialized
INFO - 2016-11-09 12:21:40 --> URI Class Initialized
DEBUG - 2016-11-09 12:21:40 --> No URI present. Default controller set.
INFO - 2016-11-09 12:21:40 --> Router Class Initialized
INFO - 2016-11-09 12:21:40 --> Output Class Initialized
INFO - 2016-11-09 12:21:40 --> Security Class Initialized
DEBUG - 2016-11-09 12:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 12:21:40 --> Input Class Initialized
INFO - 2016-11-09 12:21:40 --> Language Class Initialized
INFO - 2016-11-09 12:21:40 --> Loader Class Initialized
INFO - 2016-11-09 12:21:40 --> Helper loaded: url_helper
INFO - 2016-11-09 12:21:40 --> Helper loaded: form_helper
INFO - 2016-11-09 12:21:40 --> Database Driver Class Initialized
INFO - 2016-11-09 12:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 12:21:40 --> Controller Class Initialized
INFO - 2016-11-09 12:21:40 --> Model Class Initialized
INFO - 2016-11-09 12:21:40 --> Model Class Initialized
INFO - 2016-11-09 12:21:40 --> Model Class Initialized
INFO - 2016-11-09 12:21:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 12:21:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-09 12:21:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 12:21:40 --> Final output sent to browser
DEBUG - 2016-11-09 12:21:40 --> Total execution time: 0.1790
INFO - 2016-11-09 12:21:53 --> Config Class Initialized
INFO - 2016-11-09 12:21:53 --> Hooks Class Initialized
DEBUG - 2016-11-09 12:21:53 --> UTF-8 Support Enabled
INFO - 2016-11-09 12:21:53 --> Utf8 Class Initialized
INFO - 2016-11-09 12:21:53 --> URI Class Initialized
INFO - 2016-11-09 12:21:53 --> Router Class Initialized
INFO - 2016-11-09 12:21:53 --> Output Class Initialized
INFO - 2016-11-09 12:21:53 --> Security Class Initialized
DEBUG - 2016-11-09 12:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 12:21:53 --> Input Class Initialized
INFO - 2016-11-09 12:21:53 --> Language Class Initialized
INFO - 2016-11-09 12:21:53 --> Loader Class Initialized
INFO - 2016-11-09 12:21:53 --> Helper loaded: url_helper
INFO - 2016-11-09 12:21:53 --> Helper loaded: form_helper
INFO - 2016-11-09 12:21:53 --> Database Driver Class Initialized
INFO - 2016-11-09 12:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 12:21:53 --> Controller Class Initialized
INFO - 2016-11-09 12:21:53 --> Model Class Initialized
INFO - 2016-11-09 12:21:53 --> Model Class Initialized
INFO - 2016-11-09 12:21:53 --> Model Class Initialized
DEBUG - 2016-11-09 12:21:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-09 12:21:53 --> Model Class Initialized
INFO - 2016-11-09 12:21:53 --> Final output sent to browser
DEBUG - 2016-11-09 12:21:53 --> Total execution time: 0.1812
INFO - 2016-11-09 12:21:54 --> Config Class Initialized
INFO - 2016-11-09 12:21:54 --> Hooks Class Initialized
DEBUG - 2016-11-09 12:21:54 --> UTF-8 Support Enabled
INFO - 2016-11-09 12:21:54 --> Utf8 Class Initialized
INFO - 2016-11-09 12:21:54 --> URI Class Initialized
DEBUG - 2016-11-09 12:21:54 --> No URI present. Default controller set.
INFO - 2016-11-09 12:21:54 --> Router Class Initialized
INFO - 2016-11-09 12:21:54 --> Output Class Initialized
INFO - 2016-11-09 12:21:54 --> Security Class Initialized
DEBUG - 2016-11-09 12:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 12:21:54 --> Input Class Initialized
INFO - 2016-11-09 12:21:54 --> Language Class Initialized
INFO - 2016-11-09 12:21:54 --> Loader Class Initialized
INFO - 2016-11-09 12:21:54 --> Helper loaded: url_helper
INFO - 2016-11-09 12:21:54 --> Helper loaded: form_helper
INFO - 2016-11-09 12:21:54 --> Database Driver Class Initialized
INFO - 2016-11-09 12:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 12:21:54 --> Controller Class Initialized
INFO - 2016-11-09 12:21:54 --> Model Class Initialized
INFO - 2016-11-09 12:21:54 --> Model Class Initialized
INFO - 2016-11-09 12:21:54 --> Model Class Initialized
INFO - 2016-11-09 12:21:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 12:21:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 12:21:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 12:21:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 12:21:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 12:21:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 12:21:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 12:21:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 12:21:54 --> Final output sent to browser
DEBUG - 2016-11-09 12:21:54 --> Total execution time: 0.2272
INFO - 2016-11-09 12:22:03 --> Config Class Initialized
INFO - 2016-11-09 12:22:03 --> Hooks Class Initialized
DEBUG - 2016-11-09 12:22:03 --> UTF-8 Support Enabled
INFO - 2016-11-09 12:22:03 --> Utf8 Class Initialized
INFO - 2016-11-09 12:22:03 --> URI Class Initialized
INFO - 2016-11-09 12:22:03 --> Router Class Initialized
INFO - 2016-11-09 12:22:03 --> Output Class Initialized
INFO - 2016-11-09 12:22:03 --> Security Class Initialized
DEBUG - 2016-11-09 12:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 12:22:03 --> Input Class Initialized
INFO - 2016-11-09 12:22:03 --> Language Class Initialized
INFO - 2016-11-09 12:22:03 --> Loader Class Initialized
INFO - 2016-11-09 12:22:03 --> Helper loaded: url_helper
INFO - 2016-11-09 12:22:03 --> Helper loaded: form_helper
INFO - 2016-11-09 12:22:03 --> Database Driver Class Initialized
INFO - 2016-11-09 12:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 12:22:03 --> Controller Class Initialized
INFO - 2016-11-09 12:22:03 --> Model Class Initialized
INFO - 2016-11-09 12:22:03 --> Model Class Initialized
INFO - 2016-11-09 12:22:03 --> Model Class Initialized
DEBUG - 2016-11-09 12:22:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-09 12:22:03 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 127
ERROR - 2016-11-09 12:22:03 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 127
INFO - 2016-11-09 12:22:03 --> Config Class Initialized
INFO - 2016-11-09 12:22:03 --> Hooks Class Initialized
DEBUG - 2016-11-09 12:22:03 --> UTF-8 Support Enabled
INFO - 2016-11-09 12:22:03 --> Utf8 Class Initialized
INFO - 2016-11-09 12:22:03 --> URI Class Initialized
DEBUG - 2016-11-09 12:22:03 --> No URI present. Default controller set.
INFO - 2016-11-09 12:22:03 --> Router Class Initialized
INFO - 2016-11-09 12:22:03 --> Output Class Initialized
INFO - 2016-11-09 12:22:03 --> Security Class Initialized
DEBUG - 2016-11-09 12:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 12:22:03 --> Input Class Initialized
INFO - 2016-11-09 12:22:03 --> Language Class Initialized
INFO - 2016-11-09 12:22:03 --> Loader Class Initialized
INFO - 2016-11-09 12:22:03 --> Helper loaded: url_helper
INFO - 2016-11-09 12:22:03 --> Helper loaded: form_helper
INFO - 2016-11-09 12:22:03 --> Database Driver Class Initialized
INFO - 2016-11-09 12:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 12:22:03 --> Controller Class Initialized
INFO - 2016-11-09 12:22:03 --> Model Class Initialized
INFO - 2016-11-09 12:22:03 --> Model Class Initialized
INFO - 2016-11-09 12:22:03 --> Model Class Initialized
INFO - 2016-11-09 12:22:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 12:22:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-09 12:22:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 12:22:03 --> Final output sent to browser
DEBUG - 2016-11-09 12:22:03 --> Total execution time: 0.1875
INFO - 2016-11-09 12:22:14 --> Config Class Initialized
INFO - 2016-11-09 12:22:14 --> Hooks Class Initialized
DEBUG - 2016-11-09 12:22:14 --> UTF-8 Support Enabled
INFO - 2016-11-09 12:22:14 --> Utf8 Class Initialized
INFO - 2016-11-09 12:22:14 --> URI Class Initialized
INFO - 2016-11-09 12:22:14 --> Router Class Initialized
INFO - 2016-11-09 12:22:14 --> Output Class Initialized
INFO - 2016-11-09 12:22:14 --> Security Class Initialized
DEBUG - 2016-11-09 12:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 12:22:14 --> Input Class Initialized
INFO - 2016-11-09 12:22:14 --> Language Class Initialized
INFO - 2016-11-09 12:22:14 --> Loader Class Initialized
INFO - 2016-11-09 12:22:14 --> Helper loaded: url_helper
INFO - 2016-11-09 12:22:14 --> Helper loaded: form_helper
INFO - 2016-11-09 12:22:15 --> Database Driver Class Initialized
INFO - 2016-11-09 12:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 12:22:15 --> Controller Class Initialized
INFO - 2016-11-09 12:22:15 --> Model Class Initialized
INFO - 2016-11-09 12:22:15 --> Model Class Initialized
INFO - 2016-11-09 12:22:15 --> Model Class Initialized
DEBUG - 2016-11-09 12:22:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-09 12:22:15 --> Model Class Initialized
INFO - 2016-11-09 12:22:15 --> Final output sent to browser
DEBUG - 2016-11-09 12:22:15 --> Total execution time: 0.5064
INFO - 2016-11-09 12:22:15 --> Config Class Initialized
INFO - 2016-11-09 12:22:15 --> Hooks Class Initialized
DEBUG - 2016-11-09 12:22:15 --> UTF-8 Support Enabled
INFO - 2016-11-09 12:22:15 --> Utf8 Class Initialized
INFO - 2016-11-09 12:22:15 --> URI Class Initialized
DEBUG - 2016-11-09 12:22:15 --> No URI present. Default controller set.
INFO - 2016-11-09 12:22:15 --> Router Class Initialized
INFO - 2016-11-09 12:22:15 --> Output Class Initialized
INFO - 2016-11-09 12:22:15 --> Security Class Initialized
DEBUG - 2016-11-09 12:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 12:22:15 --> Input Class Initialized
INFO - 2016-11-09 12:22:15 --> Language Class Initialized
INFO - 2016-11-09 12:22:15 --> Loader Class Initialized
INFO - 2016-11-09 12:22:15 --> Helper loaded: url_helper
INFO - 2016-11-09 12:22:15 --> Helper loaded: form_helper
INFO - 2016-11-09 12:22:15 --> Database Driver Class Initialized
INFO - 2016-11-09 12:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 12:22:15 --> Controller Class Initialized
INFO - 2016-11-09 12:22:15 --> Model Class Initialized
INFO - 2016-11-09 12:22:15 --> Model Class Initialized
INFO - 2016-11-09 12:22:15 --> Model Class Initialized
INFO - 2016-11-09 12:22:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 12:22:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 12:22:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 12:22:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-09 12:22:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-09 12:22:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-09 12:22:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-09 12:22:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-09 12:22:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-09 12:22:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 12:22:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 12:22:15 --> Final output sent to browser
DEBUG - 2016-11-09 12:22:15 --> Total execution time: 0.5575
INFO - 2016-11-09 12:22:57 --> Config Class Initialized
INFO - 2016-11-09 12:22:57 --> Hooks Class Initialized
DEBUG - 2016-11-09 12:22:57 --> UTF-8 Support Enabled
INFO - 2016-11-09 12:22:57 --> Utf8 Class Initialized
INFO - 2016-11-09 12:22:57 --> URI Class Initialized
INFO - 2016-11-09 12:22:57 --> Router Class Initialized
INFO - 2016-11-09 12:22:57 --> Output Class Initialized
INFO - 2016-11-09 12:22:57 --> Security Class Initialized
DEBUG - 2016-11-09 12:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 12:22:57 --> Input Class Initialized
INFO - 2016-11-09 12:22:57 --> Language Class Initialized
INFO - 2016-11-09 12:22:57 --> Loader Class Initialized
INFO - 2016-11-09 12:22:57 --> Helper loaded: url_helper
INFO - 2016-11-09 12:22:57 --> Helper loaded: form_helper
INFO - 2016-11-09 12:22:57 --> Database Driver Class Initialized
INFO - 2016-11-09 12:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 12:22:57 --> Controller Class Initialized
INFO - 2016-11-09 12:22:57 --> Model Class Initialized
INFO - 2016-11-09 12:22:57 --> Model Class Initialized
INFO - 2016-11-09 12:22:57 --> Model Class Initialized
DEBUG - 2016-11-09 12:22:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-09 12:22:57 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 127
ERROR - 2016-11-09 12:22:57 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 127
INFO - 2016-11-09 12:22:57 --> Config Class Initialized
INFO - 2016-11-09 12:22:57 --> Hooks Class Initialized
DEBUG - 2016-11-09 12:22:57 --> UTF-8 Support Enabled
INFO - 2016-11-09 12:22:57 --> Utf8 Class Initialized
INFO - 2016-11-09 12:22:57 --> URI Class Initialized
DEBUG - 2016-11-09 12:22:57 --> No URI present. Default controller set.
INFO - 2016-11-09 12:22:57 --> Router Class Initialized
INFO - 2016-11-09 12:22:57 --> Output Class Initialized
INFO - 2016-11-09 12:22:57 --> Security Class Initialized
DEBUG - 2016-11-09 12:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 12:22:57 --> Input Class Initialized
INFO - 2016-11-09 12:22:57 --> Language Class Initialized
INFO - 2016-11-09 12:22:57 --> Loader Class Initialized
INFO - 2016-11-09 12:22:57 --> Helper loaded: url_helper
INFO - 2016-11-09 12:22:57 --> Helper loaded: form_helper
INFO - 2016-11-09 12:22:57 --> Database Driver Class Initialized
INFO - 2016-11-09 12:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 12:22:57 --> Controller Class Initialized
INFO - 2016-11-09 12:22:57 --> Model Class Initialized
INFO - 2016-11-09 12:22:57 --> Model Class Initialized
INFO - 2016-11-09 12:22:57 --> Model Class Initialized
INFO - 2016-11-09 12:22:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 12:22:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-09 12:22:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 12:22:57 --> Final output sent to browser
DEBUG - 2016-11-09 12:22:57 --> Total execution time: 0.2035
INFO - 2016-11-09 12:23:34 --> Config Class Initialized
INFO - 2016-11-09 12:23:34 --> Hooks Class Initialized
DEBUG - 2016-11-09 12:23:34 --> UTF-8 Support Enabled
INFO - 2016-11-09 12:23:34 --> Utf8 Class Initialized
INFO - 2016-11-09 12:23:34 --> URI Class Initialized
INFO - 2016-11-09 12:23:34 --> Router Class Initialized
INFO - 2016-11-09 12:23:34 --> Output Class Initialized
INFO - 2016-11-09 12:23:34 --> Security Class Initialized
DEBUG - 2016-11-09 12:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 12:23:34 --> Input Class Initialized
INFO - 2016-11-09 12:23:34 --> Language Class Initialized
INFO - 2016-11-09 12:23:34 --> Loader Class Initialized
INFO - 2016-11-09 12:23:34 --> Helper loaded: url_helper
INFO - 2016-11-09 12:23:34 --> Helper loaded: form_helper
INFO - 2016-11-09 12:23:34 --> Database Driver Class Initialized
INFO - 2016-11-09 12:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 12:23:34 --> Controller Class Initialized
INFO - 2016-11-09 12:23:34 --> Model Class Initialized
INFO - 2016-11-09 12:23:34 --> Model Class Initialized
INFO - 2016-11-09 12:23:34 --> Model Class Initialized
DEBUG - 2016-11-09 12:23:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-09 12:23:34 --> Model Class Initialized
INFO - 2016-11-09 12:23:34 --> Final output sent to browser
DEBUG - 2016-11-09 12:23:34 --> Total execution time: 0.1911
INFO - 2016-11-09 12:23:42 --> Config Class Initialized
INFO - 2016-11-09 12:23:42 --> Hooks Class Initialized
DEBUG - 2016-11-09 12:23:42 --> UTF-8 Support Enabled
INFO - 2016-11-09 12:23:42 --> Utf8 Class Initialized
INFO - 2016-11-09 12:23:42 --> URI Class Initialized
INFO - 2016-11-09 12:23:42 --> Router Class Initialized
INFO - 2016-11-09 12:23:42 --> Output Class Initialized
INFO - 2016-11-09 12:23:42 --> Security Class Initialized
DEBUG - 2016-11-09 12:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 12:23:42 --> Input Class Initialized
INFO - 2016-11-09 12:23:42 --> Language Class Initialized
INFO - 2016-11-09 12:23:42 --> Loader Class Initialized
INFO - 2016-11-09 12:23:42 --> Helper loaded: url_helper
INFO - 2016-11-09 12:23:42 --> Helper loaded: form_helper
INFO - 2016-11-09 12:23:42 --> Database Driver Class Initialized
INFO - 2016-11-09 12:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 12:23:42 --> Controller Class Initialized
INFO - 2016-11-09 12:23:42 --> Model Class Initialized
INFO - 2016-11-09 12:23:42 --> Model Class Initialized
INFO - 2016-11-09 12:23:42 --> Model Class Initialized
DEBUG - 2016-11-09 12:23:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-09 12:23:42 --> Model Class Initialized
INFO - 2016-11-09 12:23:42 --> Final output sent to browser
DEBUG - 2016-11-09 12:23:42 --> Total execution time: 0.1914
INFO - 2016-11-09 12:23:42 --> Config Class Initialized
INFO - 2016-11-09 12:23:42 --> Hooks Class Initialized
DEBUG - 2016-11-09 12:23:42 --> UTF-8 Support Enabled
INFO - 2016-11-09 12:23:42 --> Utf8 Class Initialized
INFO - 2016-11-09 12:23:42 --> URI Class Initialized
DEBUG - 2016-11-09 12:23:42 --> No URI present. Default controller set.
INFO - 2016-11-09 12:23:42 --> Router Class Initialized
INFO - 2016-11-09 12:23:42 --> Output Class Initialized
INFO - 2016-11-09 12:23:42 --> Security Class Initialized
DEBUG - 2016-11-09 12:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 12:23:42 --> Input Class Initialized
INFO - 2016-11-09 12:23:42 --> Language Class Initialized
INFO - 2016-11-09 12:23:42 --> Loader Class Initialized
INFO - 2016-11-09 12:23:42 --> Helper loaded: url_helper
INFO - 2016-11-09 12:23:42 --> Helper loaded: form_helper
INFO - 2016-11-09 12:23:42 --> Database Driver Class Initialized
INFO - 2016-11-09 12:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 12:23:42 --> Controller Class Initialized
INFO - 2016-11-09 12:23:42 --> Model Class Initialized
INFO - 2016-11-09 12:23:42 --> Model Class Initialized
INFO - 2016-11-09 12:23:42 --> Model Class Initialized
INFO - 2016-11-09 12:23:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 12:23:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 12:23:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 12:23:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 12:23:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 12:23:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 12:23:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 12:23:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 12:23:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 12:23:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 12:23:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 12:23:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 12:23:42 --> Final output sent to browser
DEBUG - 2016-11-09 12:23:42 --> Total execution time: 0.2699
INFO - 2016-11-09 12:25:13 --> Config Class Initialized
INFO - 2016-11-09 12:25:13 --> Hooks Class Initialized
DEBUG - 2016-11-09 12:25:13 --> UTF-8 Support Enabled
INFO - 2016-11-09 12:25:13 --> Utf8 Class Initialized
INFO - 2016-11-09 12:25:13 --> URI Class Initialized
DEBUG - 2016-11-09 12:25:13 --> No URI present. Default controller set.
INFO - 2016-11-09 12:25:13 --> Router Class Initialized
INFO - 2016-11-09 12:25:13 --> Output Class Initialized
INFO - 2016-11-09 12:25:13 --> Security Class Initialized
DEBUG - 2016-11-09 12:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 12:25:13 --> Input Class Initialized
INFO - 2016-11-09 12:25:13 --> Language Class Initialized
INFO - 2016-11-09 12:25:13 --> Loader Class Initialized
INFO - 2016-11-09 12:25:13 --> Helper loaded: url_helper
INFO - 2016-11-09 12:25:13 --> Helper loaded: form_helper
INFO - 2016-11-09 12:25:13 --> Database Driver Class Initialized
INFO - 2016-11-09 12:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 12:25:13 --> Controller Class Initialized
INFO - 2016-11-09 12:25:13 --> Model Class Initialized
INFO - 2016-11-09 12:25:13 --> Model Class Initialized
INFO - 2016-11-09 12:25:13 --> Model Class Initialized
INFO - 2016-11-09 12:25:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 12:25:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 12:25:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 12:25:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 12:25:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 12:25:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 12:25:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 12:25:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 12:25:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 12:25:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 12:25:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 12:25:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 12:25:13 --> Final output sent to browser
DEBUG - 2016-11-09 12:25:13 --> Total execution time: 0.3340
INFO - 2016-11-09 12:25:18 --> Config Class Initialized
INFO - 2016-11-09 12:25:18 --> Hooks Class Initialized
DEBUG - 2016-11-09 12:25:18 --> UTF-8 Support Enabled
INFO - 2016-11-09 12:25:18 --> Utf8 Class Initialized
INFO - 2016-11-09 12:25:18 --> URI Class Initialized
INFO - 2016-11-09 12:25:18 --> Router Class Initialized
INFO - 2016-11-09 12:25:18 --> Output Class Initialized
INFO - 2016-11-09 12:25:18 --> Security Class Initialized
DEBUG - 2016-11-09 12:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 12:25:18 --> Input Class Initialized
INFO - 2016-11-09 12:25:18 --> Language Class Initialized
INFO - 2016-11-09 12:25:18 --> Loader Class Initialized
INFO - 2016-11-09 12:25:18 --> Helper loaded: url_helper
INFO - 2016-11-09 12:25:18 --> Helper loaded: form_helper
INFO - 2016-11-09 12:25:18 --> Database Driver Class Initialized
INFO - 2016-11-09 12:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 12:25:18 --> Controller Class Initialized
INFO - 2016-11-09 12:25:18 --> Form Validation Class Initialized
INFO - 2016-11-09 12:25:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 12:25:19 --> Final output sent to browser
DEBUG - 2016-11-09 12:25:19 --> Total execution time: 0.6315
INFO - 2016-11-09 12:25:20 --> Config Class Initialized
INFO - 2016-11-09 12:25:20 --> Hooks Class Initialized
DEBUG - 2016-11-09 12:25:20 --> UTF-8 Support Enabled
INFO - 2016-11-09 12:25:20 --> Utf8 Class Initialized
INFO - 2016-11-09 12:25:20 --> URI Class Initialized
DEBUG - 2016-11-09 12:25:20 --> No URI present. Default controller set.
INFO - 2016-11-09 12:25:20 --> Router Class Initialized
INFO - 2016-11-09 12:25:20 --> Output Class Initialized
INFO - 2016-11-09 12:25:20 --> Security Class Initialized
DEBUG - 2016-11-09 12:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 12:25:20 --> Input Class Initialized
INFO - 2016-11-09 12:25:20 --> Language Class Initialized
INFO - 2016-11-09 12:25:20 --> Loader Class Initialized
INFO - 2016-11-09 12:25:20 --> Helper loaded: url_helper
INFO - 2016-11-09 12:25:20 --> Helper loaded: form_helper
INFO - 2016-11-09 12:25:20 --> Database Driver Class Initialized
INFO - 2016-11-09 12:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 12:25:20 --> Controller Class Initialized
INFO - 2016-11-09 12:25:20 --> Model Class Initialized
INFO - 2016-11-09 12:25:20 --> Model Class Initialized
INFO - 2016-11-09 12:25:20 --> Model Class Initialized
INFO - 2016-11-09 12:25:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 12:25:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 12:25:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 12:25:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 12:25:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 12:25:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 12:25:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 12:25:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 12:25:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 12:25:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 12:25:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 12:25:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 12:25:20 --> Final output sent to browser
DEBUG - 2016-11-09 12:25:20 --> Total execution time: 0.3442
INFO - 2016-11-09 12:31:42 --> Config Class Initialized
INFO - 2016-11-09 12:31:42 --> Hooks Class Initialized
DEBUG - 2016-11-09 12:31:42 --> UTF-8 Support Enabled
INFO - 2016-11-09 12:31:42 --> Utf8 Class Initialized
INFO - 2016-11-09 12:31:42 --> URI Class Initialized
DEBUG - 2016-11-09 12:31:42 --> No URI present. Default controller set.
INFO - 2016-11-09 12:31:42 --> Router Class Initialized
INFO - 2016-11-09 12:31:42 --> Output Class Initialized
INFO - 2016-11-09 12:31:42 --> Security Class Initialized
DEBUG - 2016-11-09 12:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 12:31:42 --> Input Class Initialized
INFO - 2016-11-09 12:31:42 --> Language Class Initialized
INFO - 2016-11-09 12:31:42 --> Loader Class Initialized
INFO - 2016-11-09 12:31:42 --> Helper loaded: url_helper
INFO - 2016-11-09 12:31:42 --> Helper loaded: form_helper
INFO - 2016-11-09 12:31:42 --> Database Driver Class Initialized
INFO - 2016-11-09 12:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 12:31:42 --> Controller Class Initialized
INFO - 2016-11-09 12:31:42 --> Model Class Initialized
INFO - 2016-11-09 12:31:42 --> Model Class Initialized
INFO - 2016-11-09 12:31:42 --> Model Class Initialized
INFO - 2016-11-09 12:31:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 12:31:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 12:31:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 12:31:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 12:31:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 12:31:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 12:31:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 12:31:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 12:31:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 12:31:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 12:31:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 12:31:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 12:31:42 --> Final output sent to browser
DEBUG - 2016-11-09 12:31:42 --> Total execution time: 0.3237
INFO - 2016-11-09 12:32:24 --> Config Class Initialized
INFO - 2016-11-09 12:32:24 --> Hooks Class Initialized
DEBUG - 2016-11-09 12:32:24 --> UTF-8 Support Enabled
INFO - 2016-11-09 12:32:24 --> Utf8 Class Initialized
INFO - 2016-11-09 12:32:24 --> URI Class Initialized
DEBUG - 2016-11-09 12:32:24 --> No URI present. Default controller set.
INFO - 2016-11-09 12:32:24 --> Router Class Initialized
INFO - 2016-11-09 12:32:24 --> Output Class Initialized
INFO - 2016-11-09 12:32:24 --> Security Class Initialized
DEBUG - 2016-11-09 12:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 12:32:24 --> Input Class Initialized
INFO - 2016-11-09 12:32:24 --> Language Class Initialized
INFO - 2016-11-09 12:32:24 --> Loader Class Initialized
INFO - 2016-11-09 12:32:24 --> Helper loaded: url_helper
INFO - 2016-11-09 12:32:24 --> Helper loaded: form_helper
INFO - 2016-11-09 12:32:24 --> Database Driver Class Initialized
INFO - 2016-11-09 12:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 12:32:24 --> Controller Class Initialized
INFO - 2016-11-09 12:32:24 --> Model Class Initialized
INFO - 2016-11-09 12:32:24 --> Model Class Initialized
INFO - 2016-11-09 12:32:24 --> Model Class Initialized
INFO - 2016-11-09 12:32:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 12:32:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 12:32:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 12:32:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 12:32:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 12:32:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 12:32:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 12:32:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 12:32:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 12:32:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 12:32:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 12:32:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 12:32:25 --> Final output sent to browser
DEBUG - 2016-11-09 12:32:25 --> Total execution time: 0.3226
INFO - 2016-11-09 13:04:45 --> Config Class Initialized
INFO - 2016-11-09 13:04:45 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:04:45 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:04:45 --> Utf8 Class Initialized
INFO - 2016-11-09 13:04:45 --> URI Class Initialized
INFO - 2016-11-09 13:04:45 --> Router Class Initialized
INFO - 2016-11-09 13:04:45 --> Output Class Initialized
INFO - 2016-11-09 13:04:45 --> Security Class Initialized
DEBUG - 2016-11-09 13:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:04:45 --> Input Class Initialized
INFO - 2016-11-09 13:04:45 --> Language Class Initialized
INFO - 2016-11-09 13:04:45 --> Loader Class Initialized
INFO - 2016-11-09 13:04:45 --> Helper loaded: url_helper
INFO - 2016-11-09 13:04:45 --> Helper loaded: form_helper
INFO - 2016-11-09 13:04:45 --> Database Driver Class Initialized
INFO - 2016-11-09 13:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:04:45 --> Controller Class Initialized
INFO - 2016-11-09 13:04:45 --> Model Class Initialized
INFO - 2016-11-09 13:04:45 --> Model Class Initialized
INFO - 2016-11-09 13:04:45 --> Model Class Initialized
DEBUG - 2016-11-09 13:04:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-09 13:04:45 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 124
ERROR - 2016-11-09 13:04:45 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 124
INFO - 2016-11-09 13:04:45 --> Config Class Initialized
INFO - 2016-11-09 13:04:45 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:04:45 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:04:45 --> Utf8 Class Initialized
INFO - 2016-11-09 13:04:45 --> URI Class Initialized
DEBUG - 2016-11-09 13:04:45 --> No URI present. Default controller set.
INFO - 2016-11-09 13:04:45 --> Router Class Initialized
INFO - 2016-11-09 13:04:45 --> Output Class Initialized
INFO - 2016-11-09 13:04:45 --> Security Class Initialized
DEBUG - 2016-11-09 13:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:04:45 --> Input Class Initialized
INFO - 2016-11-09 13:04:45 --> Language Class Initialized
INFO - 2016-11-09 13:04:45 --> Loader Class Initialized
INFO - 2016-11-09 13:04:45 --> Helper loaded: url_helper
INFO - 2016-11-09 13:04:45 --> Helper loaded: form_helper
INFO - 2016-11-09 13:04:45 --> Database Driver Class Initialized
INFO - 2016-11-09 13:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:04:45 --> Controller Class Initialized
INFO - 2016-11-09 13:04:45 --> Model Class Initialized
INFO - 2016-11-09 13:04:45 --> Model Class Initialized
INFO - 2016-11-09 13:04:45 --> Model Class Initialized
INFO - 2016-11-09 13:04:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 13:04:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-09 13:04:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 13:04:45 --> Final output sent to browser
DEBUG - 2016-11-09 13:04:45 --> Total execution time: 0.2142
INFO - 2016-11-09 13:04:52 --> Config Class Initialized
INFO - 2016-11-09 13:04:52 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:04:52 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:04:52 --> Utf8 Class Initialized
INFO - 2016-11-09 13:04:52 --> URI Class Initialized
INFO - 2016-11-09 13:04:52 --> Router Class Initialized
INFO - 2016-11-09 13:04:52 --> Output Class Initialized
INFO - 2016-11-09 13:04:52 --> Security Class Initialized
DEBUG - 2016-11-09 13:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:04:52 --> Input Class Initialized
INFO - 2016-11-09 13:04:52 --> Language Class Initialized
INFO - 2016-11-09 13:04:52 --> Loader Class Initialized
INFO - 2016-11-09 13:04:52 --> Helper loaded: url_helper
INFO - 2016-11-09 13:04:52 --> Helper loaded: form_helper
INFO - 2016-11-09 13:04:52 --> Database Driver Class Initialized
INFO - 2016-11-09 13:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:04:52 --> Controller Class Initialized
INFO - 2016-11-09 13:04:52 --> Model Class Initialized
INFO - 2016-11-09 13:04:52 --> Model Class Initialized
INFO - 2016-11-09 13:04:52 --> Model Class Initialized
DEBUG - 2016-11-09 13:04:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-09 13:04:53 --> Model Class Initialized
INFO - 2016-11-09 13:04:53 --> Final output sent to browser
DEBUG - 2016-11-09 13:04:53 --> Total execution time: 0.2151
INFO - 2016-11-09 13:04:53 --> Config Class Initialized
INFO - 2016-11-09 13:04:53 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:04:53 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:04:53 --> Utf8 Class Initialized
INFO - 2016-11-09 13:04:53 --> URI Class Initialized
DEBUG - 2016-11-09 13:04:53 --> No URI present. Default controller set.
INFO - 2016-11-09 13:04:53 --> Router Class Initialized
INFO - 2016-11-09 13:04:53 --> Output Class Initialized
INFO - 2016-11-09 13:04:53 --> Security Class Initialized
DEBUG - 2016-11-09 13:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:04:53 --> Input Class Initialized
INFO - 2016-11-09 13:04:53 --> Language Class Initialized
INFO - 2016-11-09 13:04:53 --> Loader Class Initialized
INFO - 2016-11-09 13:04:53 --> Helper loaded: url_helper
INFO - 2016-11-09 13:04:53 --> Helper loaded: form_helper
INFO - 2016-11-09 13:04:53 --> Database Driver Class Initialized
INFO - 2016-11-09 13:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:04:53 --> Controller Class Initialized
INFO - 2016-11-09 13:04:53 --> Model Class Initialized
INFO - 2016-11-09 13:04:53 --> Model Class Initialized
INFO - 2016-11-09 13:04:53 --> Model Class Initialized
INFO - 2016-11-09 13:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 13:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 13:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 13:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-09 13:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-09 13:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-09 13:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-09 13:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-09 13:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-09 13:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 13:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 13:04:53 --> Final output sent to browser
DEBUG - 2016-11-09 13:04:53 --> Total execution time: 0.2901
INFO - 2016-11-09 13:05:04 --> Config Class Initialized
INFO - 2016-11-09 13:05:04 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:05:04 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:05:04 --> Utf8 Class Initialized
INFO - 2016-11-09 13:05:04 --> URI Class Initialized
DEBUG - 2016-11-09 13:05:04 --> No URI present. Default controller set.
INFO - 2016-11-09 13:05:04 --> Router Class Initialized
INFO - 2016-11-09 13:05:04 --> Output Class Initialized
INFO - 2016-11-09 13:05:04 --> Security Class Initialized
DEBUG - 2016-11-09 13:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:05:04 --> Input Class Initialized
INFO - 2016-11-09 13:05:04 --> Language Class Initialized
INFO - 2016-11-09 13:05:04 --> Loader Class Initialized
INFO - 2016-11-09 13:05:04 --> Helper loaded: url_helper
INFO - 2016-11-09 13:05:04 --> Helper loaded: form_helper
INFO - 2016-11-09 13:05:04 --> Database Driver Class Initialized
INFO - 2016-11-09 13:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:05:04 --> Controller Class Initialized
INFO - 2016-11-09 13:05:04 --> Model Class Initialized
INFO - 2016-11-09 13:05:04 --> Model Class Initialized
INFO - 2016-11-09 13:05:04 --> Model Class Initialized
INFO - 2016-11-09 13:05:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 13:05:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 13:05:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 13:05:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-09 13:05:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-09 13:05:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-09 13:05:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-09 13:05:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-09 13:05:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-09 13:05:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 13:05:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 13:05:04 --> Final output sent to browser
DEBUG - 2016-11-09 13:05:04 --> Total execution time: 0.3005
INFO - 2016-11-09 13:05:22 --> Config Class Initialized
INFO - 2016-11-09 13:05:22 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:05:22 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:05:22 --> Utf8 Class Initialized
INFO - 2016-11-09 13:05:22 --> URI Class Initialized
DEBUG - 2016-11-09 13:05:22 --> No URI present. Default controller set.
INFO - 2016-11-09 13:05:22 --> Router Class Initialized
INFO - 2016-11-09 13:05:22 --> Output Class Initialized
INFO - 2016-11-09 13:05:22 --> Security Class Initialized
DEBUG - 2016-11-09 13:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:05:22 --> Input Class Initialized
INFO - 2016-11-09 13:05:22 --> Language Class Initialized
INFO - 2016-11-09 13:05:22 --> Loader Class Initialized
INFO - 2016-11-09 13:05:22 --> Helper loaded: url_helper
INFO - 2016-11-09 13:05:22 --> Helper loaded: form_helper
INFO - 2016-11-09 13:05:22 --> Database Driver Class Initialized
INFO - 2016-11-09 13:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:05:22 --> Controller Class Initialized
INFO - 2016-11-09 13:05:22 --> Model Class Initialized
INFO - 2016-11-09 13:05:22 --> Model Class Initialized
INFO - 2016-11-09 13:05:22 --> Model Class Initialized
INFO - 2016-11-09 13:05:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 13:05:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 13:05:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 13:05:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-09 13:05:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-09 13:05:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-09 13:05:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-09 13:05:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-09 13:05:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-09 13:05:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 13:05:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 13:05:22 --> Final output sent to browser
DEBUG - 2016-11-09 13:05:22 --> Total execution time: 0.3330
INFO - 2016-11-09 13:05:48 --> Config Class Initialized
INFO - 2016-11-09 13:05:48 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:05:48 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:05:48 --> Utf8 Class Initialized
INFO - 2016-11-09 13:05:48 --> URI Class Initialized
INFO - 2016-11-09 13:05:48 --> Router Class Initialized
INFO - 2016-11-09 13:05:48 --> Output Class Initialized
INFO - 2016-11-09 13:05:48 --> Security Class Initialized
DEBUG - 2016-11-09 13:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:05:48 --> Input Class Initialized
INFO - 2016-11-09 13:05:48 --> Language Class Initialized
INFO - 2016-11-09 13:05:48 --> Loader Class Initialized
INFO - 2016-11-09 13:05:48 --> Helper loaded: url_helper
INFO - 2016-11-09 13:05:48 --> Helper loaded: form_helper
INFO - 2016-11-09 13:05:48 --> Database Driver Class Initialized
INFO - 2016-11-09 13:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:05:48 --> Controller Class Initialized
INFO - 2016-11-09 13:05:48 --> Model Class Initialized
INFO - 2016-11-09 13:05:48 --> Model Class Initialized
INFO - 2016-11-09 13:05:48 --> Model Class Initialized
DEBUG - 2016-11-09 13:05:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-09 13:05:48 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 124
ERROR - 2016-11-09 13:05:48 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 124
INFO - 2016-11-09 13:05:48 --> Config Class Initialized
INFO - 2016-11-09 13:05:48 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:05:48 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:05:48 --> Utf8 Class Initialized
INFO - 2016-11-09 13:05:48 --> URI Class Initialized
DEBUG - 2016-11-09 13:05:48 --> No URI present. Default controller set.
INFO - 2016-11-09 13:05:48 --> Router Class Initialized
INFO - 2016-11-09 13:05:48 --> Output Class Initialized
INFO - 2016-11-09 13:05:48 --> Security Class Initialized
DEBUG - 2016-11-09 13:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:05:48 --> Input Class Initialized
INFO - 2016-11-09 13:05:48 --> Language Class Initialized
INFO - 2016-11-09 13:05:48 --> Loader Class Initialized
INFO - 2016-11-09 13:05:48 --> Helper loaded: url_helper
INFO - 2016-11-09 13:05:48 --> Helper loaded: form_helper
INFO - 2016-11-09 13:05:48 --> Database Driver Class Initialized
INFO - 2016-11-09 13:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:05:48 --> Controller Class Initialized
INFO - 2016-11-09 13:05:48 --> Model Class Initialized
INFO - 2016-11-09 13:05:49 --> Model Class Initialized
INFO - 2016-11-09 13:05:49 --> Model Class Initialized
INFO - 2016-11-09 13:05:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 13:05:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-09 13:05:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 13:05:49 --> Final output sent to browser
DEBUG - 2016-11-09 13:05:49 --> Total execution time: 0.2224
INFO - 2016-11-09 13:06:01 --> Config Class Initialized
INFO - 2016-11-09 13:06:01 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:06:01 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:06:01 --> Utf8 Class Initialized
INFO - 2016-11-09 13:06:01 --> URI Class Initialized
INFO - 2016-11-09 13:06:01 --> Router Class Initialized
INFO - 2016-11-09 13:06:01 --> Output Class Initialized
INFO - 2016-11-09 13:06:01 --> Security Class Initialized
DEBUG - 2016-11-09 13:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:06:01 --> Input Class Initialized
INFO - 2016-11-09 13:06:01 --> Language Class Initialized
INFO - 2016-11-09 13:06:01 --> Loader Class Initialized
INFO - 2016-11-09 13:06:01 --> Helper loaded: url_helper
INFO - 2016-11-09 13:06:01 --> Helper loaded: form_helper
INFO - 2016-11-09 13:06:01 --> Database Driver Class Initialized
INFO - 2016-11-09 13:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:06:01 --> Controller Class Initialized
INFO - 2016-11-09 13:06:01 --> Model Class Initialized
INFO - 2016-11-09 13:06:01 --> Model Class Initialized
INFO - 2016-11-09 13:06:01 --> Model Class Initialized
DEBUG - 2016-11-09 13:06:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-09 13:06:01 --> Model Class Initialized
INFO - 2016-11-09 13:06:01 --> Final output sent to browser
DEBUG - 2016-11-09 13:06:01 --> Total execution time: 0.2165
INFO - 2016-11-09 13:06:01 --> Config Class Initialized
INFO - 2016-11-09 13:06:01 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:06:01 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:06:01 --> Utf8 Class Initialized
INFO - 2016-11-09 13:06:01 --> URI Class Initialized
DEBUG - 2016-11-09 13:06:01 --> No URI present. Default controller set.
INFO - 2016-11-09 13:06:01 --> Router Class Initialized
INFO - 2016-11-09 13:06:01 --> Output Class Initialized
INFO - 2016-11-09 13:06:01 --> Security Class Initialized
DEBUG - 2016-11-09 13:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:06:01 --> Input Class Initialized
INFO - 2016-11-09 13:06:01 --> Language Class Initialized
INFO - 2016-11-09 13:06:01 --> Loader Class Initialized
INFO - 2016-11-09 13:06:01 --> Helper loaded: url_helper
INFO - 2016-11-09 13:06:01 --> Helper loaded: form_helper
INFO - 2016-11-09 13:06:01 --> Database Driver Class Initialized
INFO - 2016-11-09 13:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:06:01 --> Controller Class Initialized
INFO - 2016-11-09 13:06:01 --> Model Class Initialized
INFO - 2016-11-09 13:06:01 --> Model Class Initialized
INFO - 2016-11-09 13:06:01 --> Model Class Initialized
INFO - 2016-11-09 13:06:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 13:06:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 13:06:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 13:06:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 13:06:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 13:06:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 13:06:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 13:06:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 13:06:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 13:06:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 13:06:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 13:06:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 13:06:01 --> Final output sent to browser
DEBUG - 2016-11-09 13:06:01 --> Total execution time: 0.2918
INFO - 2016-11-09 13:09:34 --> Config Class Initialized
INFO - 2016-11-09 13:09:34 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:09:34 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:09:34 --> Utf8 Class Initialized
INFO - 2016-11-09 13:09:34 --> URI Class Initialized
DEBUG - 2016-11-09 13:09:34 --> No URI present. Default controller set.
INFO - 2016-11-09 13:09:34 --> Router Class Initialized
INFO - 2016-11-09 13:09:34 --> Output Class Initialized
INFO - 2016-11-09 13:09:34 --> Security Class Initialized
DEBUG - 2016-11-09 13:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:09:34 --> Input Class Initialized
INFO - 2016-11-09 13:09:34 --> Language Class Initialized
INFO - 2016-11-09 13:09:34 --> Loader Class Initialized
INFO - 2016-11-09 13:09:34 --> Helper loaded: url_helper
INFO - 2016-11-09 13:09:34 --> Helper loaded: form_helper
INFO - 2016-11-09 13:09:34 --> Database Driver Class Initialized
INFO - 2016-11-09 13:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:09:34 --> Controller Class Initialized
INFO - 2016-11-09 13:09:34 --> Model Class Initialized
INFO - 2016-11-09 13:09:34 --> Model Class Initialized
INFO - 2016-11-09 13:09:34 --> Model Class Initialized
INFO - 2016-11-09 13:09:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 13:09:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 13:09:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 13:09:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 13:09:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 13:09:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 13:09:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 13:09:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 13:09:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 13:09:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 13:09:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 13:09:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 13:09:34 --> Final output sent to browser
DEBUG - 2016-11-09 13:09:34 --> Total execution time: 0.2952
INFO - 2016-11-09 13:18:52 --> Config Class Initialized
INFO - 2016-11-09 13:18:52 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:18:52 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:18:52 --> Utf8 Class Initialized
INFO - 2016-11-09 13:18:52 --> URI Class Initialized
DEBUG - 2016-11-09 13:18:52 --> No URI present. Default controller set.
INFO - 2016-11-09 13:18:52 --> Router Class Initialized
INFO - 2016-11-09 13:18:52 --> Output Class Initialized
INFO - 2016-11-09 13:18:52 --> Security Class Initialized
DEBUG - 2016-11-09 13:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:18:52 --> Input Class Initialized
INFO - 2016-11-09 13:18:52 --> Language Class Initialized
INFO - 2016-11-09 13:18:52 --> Loader Class Initialized
INFO - 2016-11-09 13:18:52 --> Helper loaded: url_helper
INFO - 2016-11-09 13:18:52 --> Helper loaded: form_helper
INFO - 2016-11-09 13:18:52 --> Database Driver Class Initialized
INFO - 2016-11-09 13:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:18:52 --> Controller Class Initialized
INFO - 2016-11-09 13:18:52 --> Model Class Initialized
INFO - 2016-11-09 13:18:52 --> Model Class Initialized
INFO - 2016-11-09 13:18:52 --> Model Class Initialized
INFO - 2016-11-09 13:18:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 13:18:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 13:18:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 13:18:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
ERROR - 2016-11-09 13:18:52 --> Severity: Error --> Call to undefined method stdClass::strtotime() C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
INFO - 2016-11-09 13:19:05 --> Config Class Initialized
INFO - 2016-11-09 13:19:05 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:19:05 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:19:05 --> Utf8 Class Initialized
INFO - 2016-11-09 13:19:05 --> URI Class Initialized
DEBUG - 2016-11-09 13:19:05 --> No URI present. Default controller set.
INFO - 2016-11-09 13:19:05 --> Router Class Initialized
INFO - 2016-11-09 13:19:05 --> Output Class Initialized
INFO - 2016-11-09 13:19:05 --> Security Class Initialized
DEBUG - 2016-11-09 13:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:19:05 --> Input Class Initialized
INFO - 2016-11-09 13:19:05 --> Language Class Initialized
INFO - 2016-11-09 13:19:05 --> Loader Class Initialized
INFO - 2016-11-09 13:19:05 --> Helper loaded: url_helper
INFO - 2016-11-09 13:19:06 --> Helper loaded: form_helper
INFO - 2016-11-09 13:19:06 --> Database Driver Class Initialized
INFO - 2016-11-09 13:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:19:06 --> Controller Class Initialized
INFO - 2016-11-09 13:19:06 --> Model Class Initialized
INFO - 2016-11-09 13:19:06 --> Model Class Initialized
INFO - 2016-11-09 13:19:06 --> Model Class Initialized
INFO - 2016-11-09 13:19:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 13:19:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 13:19:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 13:19:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
ERROR - 2016-11-09 13:19:06 --> Severity: Error --> Call to undefined method stdClass::strtotime() C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
INFO - 2016-11-09 13:20:21 --> Config Class Initialized
INFO - 2016-11-09 13:20:21 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:20:21 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:20:21 --> Utf8 Class Initialized
INFO - 2016-11-09 13:20:21 --> URI Class Initialized
DEBUG - 2016-11-09 13:20:21 --> No URI present. Default controller set.
INFO - 2016-11-09 13:20:21 --> Router Class Initialized
INFO - 2016-11-09 13:20:21 --> Output Class Initialized
INFO - 2016-11-09 13:20:21 --> Security Class Initialized
DEBUG - 2016-11-09 13:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:20:21 --> Input Class Initialized
INFO - 2016-11-09 13:20:21 --> Language Class Initialized
INFO - 2016-11-09 13:20:21 --> Loader Class Initialized
INFO - 2016-11-09 13:20:21 --> Helper loaded: url_helper
INFO - 2016-11-09 13:20:21 --> Helper loaded: form_helper
INFO - 2016-11-09 13:20:21 --> Database Driver Class Initialized
INFO - 2016-11-09 13:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:20:21 --> Controller Class Initialized
INFO - 2016-11-09 13:20:21 --> Model Class Initialized
INFO - 2016-11-09 13:20:21 --> Model Class Initialized
INFO - 2016-11-09 13:20:21 --> Model Class Initialized
INFO - 2016-11-09 13:20:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 13:20:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 13:20:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 13:20:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 13:20:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 13:20:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 13:20:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 13:20:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 13:20:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 13:20:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 13:20:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 13:20:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 13:20:21 --> Final output sent to browser
DEBUG - 2016-11-09 13:20:21 --> Total execution time: 0.3101
INFO - 2016-11-09 13:20:27 --> Config Class Initialized
INFO - 2016-11-09 13:20:27 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:20:27 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:20:27 --> Utf8 Class Initialized
INFO - 2016-11-09 13:20:27 --> URI Class Initialized
INFO - 2016-11-09 13:20:27 --> Router Class Initialized
INFO - 2016-11-09 13:20:27 --> Output Class Initialized
INFO - 2016-11-09 13:20:28 --> Security Class Initialized
DEBUG - 2016-11-09 13:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:20:28 --> Input Class Initialized
INFO - 2016-11-09 13:20:28 --> Language Class Initialized
INFO - 2016-11-09 13:20:28 --> Loader Class Initialized
INFO - 2016-11-09 13:20:28 --> Helper loaded: url_helper
INFO - 2016-11-09 13:20:28 --> Helper loaded: form_helper
INFO - 2016-11-09 13:20:28 --> Database Driver Class Initialized
INFO - 2016-11-09 13:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:20:28 --> Controller Class Initialized
INFO - 2016-11-09 13:20:28 --> Model Class Initialized
INFO - 2016-11-09 13:20:28 --> Form Validation Class Initialized
INFO - 2016-11-09 13:20:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 13:20:28 --> Final output sent to browser
DEBUG - 2016-11-09 13:20:28 --> Total execution time: 0.3444
INFO - 2016-11-09 13:20:29 --> Config Class Initialized
INFO - 2016-11-09 13:20:29 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:20:29 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:20:29 --> Utf8 Class Initialized
INFO - 2016-11-09 13:20:29 --> URI Class Initialized
DEBUG - 2016-11-09 13:20:29 --> No URI present. Default controller set.
INFO - 2016-11-09 13:20:29 --> Router Class Initialized
INFO - 2016-11-09 13:20:29 --> Output Class Initialized
INFO - 2016-11-09 13:20:30 --> Security Class Initialized
DEBUG - 2016-11-09 13:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:20:30 --> Input Class Initialized
INFO - 2016-11-09 13:20:30 --> Language Class Initialized
INFO - 2016-11-09 13:20:30 --> Loader Class Initialized
INFO - 2016-11-09 13:20:30 --> Helper loaded: url_helper
INFO - 2016-11-09 13:20:30 --> Helper loaded: form_helper
INFO - 2016-11-09 13:20:30 --> Database Driver Class Initialized
INFO - 2016-11-09 13:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:20:30 --> Controller Class Initialized
INFO - 2016-11-09 13:20:30 --> Model Class Initialized
INFO - 2016-11-09 13:20:30 --> Model Class Initialized
INFO - 2016-11-09 13:20:30 --> Model Class Initialized
INFO - 2016-11-09 13:20:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 13:20:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 13:20:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 13:20:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 13:20:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 13:20:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 13:20:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 13:20:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 13:20:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 13:20:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 13:20:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 13:20:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 13:20:30 --> Final output sent to browser
DEBUG - 2016-11-09 13:20:30 --> Total execution time: 0.3610
INFO - 2016-11-09 13:21:27 --> Config Class Initialized
INFO - 2016-11-09 13:21:27 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:21:27 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:21:27 --> Utf8 Class Initialized
INFO - 2016-11-09 13:21:27 --> URI Class Initialized
INFO - 2016-11-09 13:21:27 --> Router Class Initialized
INFO - 2016-11-09 13:21:27 --> Output Class Initialized
INFO - 2016-11-09 13:21:27 --> Security Class Initialized
DEBUG - 2016-11-09 13:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:21:27 --> Input Class Initialized
INFO - 2016-11-09 13:21:27 --> Language Class Initialized
INFO - 2016-11-09 13:21:27 --> Loader Class Initialized
INFO - 2016-11-09 13:21:27 --> Helper loaded: url_helper
INFO - 2016-11-09 13:21:27 --> Helper loaded: form_helper
INFO - 2016-11-09 13:21:27 --> Database Driver Class Initialized
INFO - 2016-11-09 13:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:21:27 --> Controller Class Initialized
INFO - 2016-11-09 13:21:27 --> Model Class Initialized
INFO - 2016-11-09 13:21:27 --> Form Validation Class Initialized
INFO - 2016-11-09 13:21:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 13:22:14 --> Config Class Initialized
INFO - 2016-11-09 13:22:14 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:22:14 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:22:14 --> Utf8 Class Initialized
INFO - 2016-11-09 13:22:14 --> URI Class Initialized
DEBUG - 2016-11-09 13:22:14 --> No URI present. Default controller set.
INFO - 2016-11-09 13:22:14 --> Router Class Initialized
INFO - 2016-11-09 13:22:14 --> Output Class Initialized
INFO - 2016-11-09 13:22:14 --> Security Class Initialized
DEBUG - 2016-11-09 13:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:22:14 --> Input Class Initialized
INFO - 2016-11-09 13:22:14 --> Language Class Initialized
INFO - 2016-11-09 13:22:14 --> Loader Class Initialized
INFO - 2016-11-09 13:22:14 --> Helper loaded: url_helper
INFO - 2016-11-09 13:22:14 --> Helper loaded: form_helper
INFO - 2016-11-09 13:22:14 --> Database Driver Class Initialized
INFO - 2016-11-09 13:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:22:14 --> Controller Class Initialized
INFO - 2016-11-09 13:22:14 --> Model Class Initialized
INFO - 2016-11-09 13:22:14 --> Model Class Initialized
INFO - 2016-11-09 13:22:14 --> Model Class Initialized
INFO - 2016-11-09 13:22:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 13:22:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 13:22:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 13:22:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 13:22:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 13:22:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 13:22:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 13:22:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 13:22:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 13:22:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 13:22:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 13:22:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 13:22:14 --> Final output sent to browser
DEBUG - 2016-11-09 13:22:14 --> Total execution time: 0.3009
INFO - 2016-11-09 13:24:10 --> Config Class Initialized
INFO - 2016-11-09 13:24:10 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:24:10 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:24:10 --> Utf8 Class Initialized
INFO - 2016-11-09 13:24:10 --> URI Class Initialized
DEBUG - 2016-11-09 13:24:10 --> No URI present. Default controller set.
INFO - 2016-11-09 13:24:10 --> Router Class Initialized
INFO - 2016-11-09 13:24:10 --> Output Class Initialized
INFO - 2016-11-09 13:24:10 --> Security Class Initialized
DEBUG - 2016-11-09 13:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:24:10 --> Input Class Initialized
INFO - 2016-11-09 13:24:10 --> Language Class Initialized
INFO - 2016-11-09 13:24:10 --> Loader Class Initialized
INFO - 2016-11-09 13:24:10 --> Helper loaded: url_helper
INFO - 2016-11-09 13:24:10 --> Helper loaded: form_helper
INFO - 2016-11-09 13:24:10 --> Database Driver Class Initialized
INFO - 2016-11-09 13:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:24:10 --> Controller Class Initialized
INFO - 2016-11-09 13:24:10 --> Model Class Initialized
INFO - 2016-11-09 13:24:10 --> Model Class Initialized
INFO - 2016-11-09 13:24:10 --> Model Class Initialized
INFO - 2016-11-09 13:24:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 13:24:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 13:24:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 13:24:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 13:24:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 13:24:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 13:24:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 13:24:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 13:24:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 13:24:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 13:24:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 13:24:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 13:24:10 --> Final output sent to browser
DEBUG - 2016-11-09 13:24:10 --> Total execution time: 0.2955
INFO - 2016-11-09 13:24:17 --> Config Class Initialized
INFO - 2016-11-09 13:24:17 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:24:17 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:24:17 --> Utf8 Class Initialized
INFO - 2016-11-09 13:24:17 --> URI Class Initialized
INFO - 2016-11-09 13:24:17 --> Router Class Initialized
INFO - 2016-11-09 13:24:17 --> Output Class Initialized
INFO - 2016-11-09 13:24:17 --> Security Class Initialized
DEBUG - 2016-11-09 13:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:24:17 --> Input Class Initialized
INFO - 2016-11-09 13:24:17 --> Language Class Initialized
INFO - 2016-11-09 13:24:17 --> Loader Class Initialized
INFO - 2016-11-09 13:24:17 --> Helper loaded: url_helper
INFO - 2016-11-09 13:24:17 --> Helper loaded: form_helper
INFO - 2016-11-09 13:24:17 --> Database Driver Class Initialized
INFO - 2016-11-09 13:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:24:17 --> Controller Class Initialized
INFO - 2016-11-09 13:24:18 --> Model Class Initialized
INFO - 2016-11-09 13:24:18 --> Form Validation Class Initialized
INFO - 2016-11-09 13:24:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 13:24:18 --> Final output sent to browser
DEBUG - 2016-11-09 13:24:18 --> Total execution time: 0.4164
INFO - 2016-11-09 13:24:22 --> Config Class Initialized
INFO - 2016-11-09 13:24:22 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:24:22 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:24:22 --> Utf8 Class Initialized
INFO - 2016-11-09 13:24:22 --> URI Class Initialized
DEBUG - 2016-11-09 13:24:22 --> No URI present. Default controller set.
INFO - 2016-11-09 13:24:22 --> Router Class Initialized
INFO - 2016-11-09 13:24:22 --> Output Class Initialized
INFO - 2016-11-09 13:24:22 --> Security Class Initialized
DEBUG - 2016-11-09 13:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:24:22 --> Input Class Initialized
INFO - 2016-11-09 13:24:22 --> Language Class Initialized
INFO - 2016-11-09 13:24:22 --> Loader Class Initialized
INFO - 2016-11-09 13:24:22 --> Helper loaded: url_helper
INFO - 2016-11-09 13:24:22 --> Helper loaded: form_helper
INFO - 2016-11-09 13:24:22 --> Database Driver Class Initialized
INFO - 2016-11-09 13:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:24:22 --> Controller Class Initialized
INFO - 2016-11-09 13:24:22 --> Model Class Initialized
INFO - 2016-11-09 13:24:22 --> Model Class Initialized
INFO - 2016-11-09 13:24:22 --> Model Class Initialized
INFO - 2016-11-09 13:24:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 13:24:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 13:24:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 13:24:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 13:24:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 13:24:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 13:24:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 13:24:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 13:24:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 13:24:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 13:24:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 13:24:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 13:24:23 --> Final output sent to browser
DEBUG - 2016-11-09 13:24:23 --> Total execution time: 0.3236
INFO - 2016-11-09 13:24:40 --> Config Class Initialized
INFO - 2016-11-09 13:24:40 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:24:40 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:24:40 --> Utf8 Class Initialized
INFO - 2016-11-09 13:24:40 --> URI Class Initialized
INFO - 2016-11-09 13:24:40 --> Router Class Initialized
INFO - 2016-11-09 13:24:40 --> Output Class Initialized
INFO - 2016-11-09 13:24:40 --> Security Class Initialized
DEBUG - 2016-11-09 13:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:24:40 --> Input Class Initialized
INFO - 2016-11-09 13:24:40 --> Language Class Initialized
INFO - 2016-11-09 13:24:40 --> Loader Class Initialized
INFO - 2016-11-09 13:24:40 --> Helper loaded: url_helper
INFO - 2016-11-09 13:24:40 --> Helper loaded: form_helper
INFO - 2016-11-09 13:24:40 --> Database Driver Class Initialized
INFO - 2016-11-09 13:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:24:40 --> Controller Class Initialized
INFO - 2016-11-09 13:24:40 --> Model Class Initialized
INFO - 2016-11-09 13:24:40 --> Form Validation Class Initialized
INFO - 2016-11-09 13:24:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 13:27:05 --> Config Class Initialized
INFO - 2016-11-09 13:27:05 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:27:05 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:27:05 --> Utf8 Class Initialized
INFO - 2016-11-09 13:27:05 --> URI Class Initialized
INFO - 2016-11-09 13:27:05 --> Router Class Initialized
INFO - 2016-11-09 13:27:05 --> Output Class Initialized
INFO - 2016-11-09 13:27:05 --> Security Class Initialized
DEBUG - 2016-11-09 13:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:27:05 --> Input Class Initialized
INFO - 2016-11-09 13:27:05 --> Language Class Initialized
INFO - 2016-11-09 13:27:05 --> Loader Class Initialized
INFO - 2016-11-09 13:27:05 --> Helper loaded: url_helper
INFO - 2016-11-09 13:27:05 --> Helper loaded: form_helper
INFO - 2016-11-09 13:27:05 --> Database Driver Class Initialized
INFO - 2016-11-09 13:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:27:05 --> Controller Class Initialized
INFO - 2016-11-09 13:27:05 --> Model Class Initialized
INFO - 2016-11-09 13:27:05 --> Form Validation Class Initialized
INFO - 2016-11-09 13:27:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 13:27:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 13:27:05 --> Final output sent to browser
DEBUG - 2016-11-09 13:27:05 --> Total execution time: 0.3195
INFO - 2016-11-09 13:27:09 --> Config Class Initialized
INFO - 2016-11-09 13:27:09 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:27:09 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:27:09 --> Utf8 Class Initialized
INFO - 2016-11-09 13:27:09 --> URI Class Initialized
DEBUG - 2016-11-09 13:27:09 --> No URI present. Default controller set.
INFO - 2016-11-09 13:27:09 --> Router Class Initialized
INFO - 2016-11-09 13:27:09 --> Output Class Initialized
INFO - 2016-11-09 13:27:09 --> Security Class Initialized
DEBUG - 2016-11-09 13:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:27:09 --> Input Class Initialized
INFO - 2016-11-09 13:27:09 --> Language Class Initialized
INFO - 2016-11-09 13:27:09 --> Loader Class Initialized
INFO - 2016-11-09 13:27:09 --> Helper loaded: url_helper
INFO - 2016-11-09 13:27:09 --> Helper loaded: form_helper
INFO - 2016-11-09 13:27:09 --> Database Driver Class Initialized
INFO - 2016-11-09 13:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:27:09 --> Controller Class Initialized
INFO - 2016-11-09 13:27:09 --> Model Class Initialized
INFO - 2016-11-09 13:27:09 --> Model Class Initialized
INFO - 2016-11-09 13:27:09 --> Model Class Initialized
INFO - 2016-11-09 13:27:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 13:27:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 13:27:39 --> Config Class Initialized
INFO - 2016-11-09 13:27:39 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:27:39 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:27:39 --> Utf8 Class Initialized
INFO - 2016-11-09 13:27:39 --> URI Class Initialized
DEBUG - 2016-11-09 13:27:39 --> No URI present. Default controller set.
INFO - 2016-11-09 13:27:39 --> Router Class Initialized
INFO - 2016-11-09 13:27:39 --> Output Class Initialized
INFO - 2016-11-09 13:27:39 --> Security Class Initialized
DEBUG - 2016-11-09 13:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:27:39 --> Input Class Initialized
INFO - 2016-11-09 13:27:39 --> Language Class Initialized
INFO - 2016-11-09 13:27:39 --> Loader Class Initialized
INFO - 2016-11-09 13:27:39 --> Helper loaded: url_helper
INFO - 2016-11-09 13:27:39 --> Helper loaded: form_helper
INFO - 2016-11-09 13:27:39 --> Database Driver Class Initialized
INFO - 2016-11-09 13:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:27:39 --> Controller Class Initialized
INFO - 2016-11-09 13:27:39 --> Model Class Initialized
INFO - 2016-11-09 13:27:39 --> Model Class Initialized
INFO - 2016-11-09 13:27:39 --> Model Class Initialized
INFO - 2016-11-09 13:27:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 13:27:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 13:27:40 --> Config Class Initialized
INFO - 2016-11-09 13:27:40 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:27:40 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:27:40 --> Utf8 Class Initialized
INFO - 2016-11-09 13:27:40 --> URI Class Initialized
DEBUG - 2016-11-09 13:27:40 --> No URI present. Default controller set.
INFO - 2016-11-09 13:27:40 --> Router Class Initialized
INFO - 2016-11-09 13:27:40 --> Output Class Initialized
INFO - 2016-11-09 13:27:40 --> Security Class Initialized
DEBUG - 2016-11-09 13:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:27:40 --> Input Class Initialized
INFO - 2016-11-09 13:27:40 --> Language Class Initialized
INFO - 2016-11-09 13:27:40 --> Loader Class Initialized
INFO - 2016-11-09 13:27:40 --> Helper loaded: url_helper
INFO - 2016-11-09 13:27:40 --> Helper loaded: form_helper
INFO - 2016-11-09 13:27:40 --> Database Driver Class Initialized
INFO - 2016-11-09 13:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:27:40 --> Controller Class Initialized
INFO - 2016-11-09 13:27:40 --> Model Class Initialized
INFO - 2016-11-09 13:27:40 --> Model Class Initialized
INFO - 2016-11-09 13:27:40 --> Model Class Initialized
INFO - 2016-11-09 13:27:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 13:27:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 13:27:41 --> Config Class Initialized
INFO - 2016-11-09 13:27:41 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:27:41 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:27:41 --> Utf8 Class Initialized
INFO - 2016-11-09 13:27:41 --> URI Class Initialized
DEBUG - 2016-11-09 13:27:41 --> No URI present. Default controller set.
INFO - 2016-11-09 13:27:41 --> Router Class Initialized
INFO - 2016-11-09 13:27:41 --> Output Class Initialized
INFO - 2016-11-09 13:27:41 --> Security Class Initialized
DEBUG - 2016-11-09 13:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:27:41 --> Input Class Initialized
INFO - 2016-11-09 13:27:41 --> Language Class Initialized
INFO - 2016-11-09 13:27:41 --> Loader Class Initialized
INFO - 2016-11-09 13:27:41 --> Helper loaded: url_helper
INFO - 2016-11-09 13:27:41 --> Helper loaded: form_helper
INFO - 2016-11-09 13:27:41 --> Database Driver Class Initialized
INFO - 2016-11-09 13:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:27:41 --> Controller Class Initialized
INFO - 2016-11-09 13:27:41 --> Model Class Initialized
INFO - 2016-11-09 13:27:41 --> Model Class Initialized
INFO - 2016-11-09 13:27:41 --> Model Class Initialized
INFO - 2016-11-09 13:27:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 13:27:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 13:27:41 --> Config Class Initialized
INFO - 2016-11-09 13:27:41 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:27:41 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:27:41 --> Utf8 Class Initialized
INFO - 2016-11-09 13:27:41 --> URI Class Initialized
DEBUG - 2016-11-09 13:27:41 --> No URI present. Default controller set.
INFO - 2016-11-09 13:27:41 --> Router Class Initialized
INFO - 2016-11-09 13:27:41 --> Output Class Initialized
INFO - 2016-11-09 13:27:41 --> Security Class Initialized
DEBUG - 2016-11-09 13:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:27:41 --> Input Class Initialized
INFO - 2016-11-09 13:27:41 --> Language Class Initialized
INFO - 2016-11-09 13:27:41 --> Loader Class Initialized
INFO - 2016-11-09 13:27:41 --> Helper loaded: url_helper
INFO - 2016-11-09 13:27:41 --> Helper loaded: form_helper
INFO - 2016-11-09 13:27:41 --> Database Driver Class Initialized
INFO - 2016-11-09 13:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:27:41 --> Config Class Initialized
INFO - 2016-11-09 13:27:41 --> Controller Class Initialized
INFO - 2016-11-09 13:27:41 --> Hooks Class Initialized
INFO - 2016-11-09 13:27:41 --> Model Class Initialized
DEBUG - 2016-11-09 13:27:41 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:27:41 --> Model Class Initialized
INFO - 2016-11-09 13:27:41 --> Utf8 Class Initialized
INFO - 2016-11-09 13:27:41 --> Model Class Initialized
INFO - 2016-11-09 13:27:41 --> URI Class Initialized
INFO - 2016-11-09 13:27:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
DEBUG - 2016-11-09 13:27:41 --> No URI present. Default controller set.
INFO - 2016-11-09 13:27:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 13:27:41 --> Router Class Initialized
INFO - 2016-11-09 13:27:41 --> Output Class Initialized
INFO - 2016-11-09 13:27:41 --> Security Class Initialized
DEBUG - 2016-11-09 13:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:27:41 --> Input Class Initialized
INFO - 2016-11-09 13:27:41 --> Language Class Initialized
INFO - 2016-11-09 13:27:41 --> Loader Class Initialized
INFO - 2016-11-09 13:27:41 --> Helper loaded: url_helper
INFO - 2016-11-09 13:27:41 --> Helper loaded: form_helper
INFO - 2016-11-09 13:27:41 --> Database Driver Class Initialized
INFO - 2016-11-09 13:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:27:41 --> Controller Class Initialized
INFO - 2016-11-09 13:27:42 --> Model Class Initialized
INFO - 2016-11-09 13:27:42 --> Model Class Initialized
INFO - 2016-11-09 13:27:42 --> Model Class Initialized
INFO - 2016-11-09 13:27:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 13:27:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 13:28:10 --> Config Class Initialized
INFO - 2016-11-09 13:28:10 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:28:10 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:28:10 --> Utf8 Class Initialized
INFO - 2016-11-09 13:28:10 --> URI Class Initialized
DEBUG - 2016-11-09 13:28:10 --> No URI present. Default controller set.
INFO - 2016-11-09 13:28:10 --> Router Class Initialized
INFO - 2016-11-09 13:28:10 --> Output Class Initialized
INFO - 2016-11-09 13:28:10 --> Security Class Initialized
DEBUG - 2016-11-09 13:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:28:10 --> Input Class Initialized
INFO - 2016-11-09 13:28:10 --> Language Class Initialized
INFO - 2016-11-09 13:28:10 --> Loader Class Initialized
INFO - 2016-11-09 13:28:10 --> Helper loaded: url_helper
INFO - 2016-11-09 13:28:10 --> Helper loaded: form_helper
INFO - 2016-11-09 13:28:11 --> Database Driver Class Initialized
INFO - 2016-11-09 13:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:28:11 --> Controller Class Initialized
INFO - 2016-11-09 13:28:11 --> Model Class Initialized
INFO - 2016-11-09 13:28:11 --> Model Class Initialized
INFO - 2016-11-09 13:28:11 --> Model Class Initialized
INFO - 2016-11-09 13:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 13:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 13:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 13:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 13:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 13:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 13:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 13:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 13:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 13:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 13:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 13:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 13:28:11 --> Final output sent to browser
DEBUG - 2016-11-09 13:28:11 --> Total execution time: 0.3144
INFO - 2016-11-09 13:28:15 --> Config Class Initialized
INFO - 2016-11-09 13:28:15 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:28:15 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:28:15 --> Utf8 Class Initialized
INFO - 2016-11-09 13:28:15 --> URI Class Initialized
DEBUG - 2016-11-09 13:28:15 --> No URI present. Default controller set.
INFO - 2016-11-09 13:28:15 --> Router Class Initialized
INFO - 2016-11-09 13:28:15 --> Output Class Initialized
INFO - 2016-11-09 13:28:15 --> Security Class Initialized
DEBUG - 2016-11-09 13:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:28:15 --> Input Class Initialized
INFO - 2016-11-09 13:28:15 --> Language Class Initialized
INFO - 2016-11-09 13:28:15 --> Loader Class Initialized
INFO - 2016-11-09 13:28:15 --> Helper loaded: url_helper
INFO - 2016-11-09 13:28:15 --> Helper loaded: form_helper
INFO - 2016-11-09 13:28:15 --> Database Driver Class Initialized
INFO - 2016-11-09 13:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:28:15 --> Controller Class Initialized
INFO - 2016-11-09 13:28:15 --> Model Class Initialized
INFO - 2016-11-09 13:28:15 --> Model Class Initialized
INFO - 2016-11-09 13:28:15 --> Model Class Initialized
INFO - 2016-11-09 13:28:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 13:28:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 13:28:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 13:28:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 13:28:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 13:28:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 13:28:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 13:28:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 13:28:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 13:28:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 13:28:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 13:28:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 13:28:15 --> Final output sent to browser
DEBUG - 2016-11-09 13:28:15 --> Total execution time: 0.3493
INFO - 2016-11-09 13:28:50 --> Config Class Initialized
INFO - 2016-11-09 13:28:50 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:28:50 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:28:50 --> Utf8 Class Initialized
INFO - 2016-11-09 13:28:50 --> URI Class Initialized
INFO - 2016-11-09 13:28:50 --> Router Class Initialized
INFO - 2016-11-09 13:28:50 --> Output Class Initialized
INFO - 2016-11-09 13:28:50 --> Security Class Initialized
DEBUG - 2016-11-09 13:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:28:50 --> Input Class Initialized
INFO - 2016-11-09 13:28:50 --> Language Class Initialized
INFO - 2016-11-09 13:28:50 --> Loader Class Initialized
INFO - 2016-11-09 13:28:50 --> Helper loaded: url_helper
INFO - 2016-11-09 13:28:50 --> Helper loaded: form_helper
INFO - 2016-11-09 13:28:50 --> Database Driver Class Initialized
INFO - 2016-11-09 13:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:28:50 --> Controller Class Initialized
INFO - 2016-11-09 13:28:50 --> Model Class Initialized
INFO - 2016-11-09 13:28:50 --> Form Validation Class Initialized
INFO - 2016-11-09 13:28:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 13:28:50 --> Final output sent to browser
DEBUG - 2016-11-09 13:28:50 --> Total execution time: 0.1999
INFO - 2016-11-09 13:28:52 --> Config Class Initialized
INFO - 2016-11-09 13:28:52 --> Hooks Class Initialized
DEBUG - 2016-11-09 13:28:52 --> UTF-8 Support Enabled
INFO - 2016-11-09 13:28:52 --> Utf8 Class Initialized
INFO - 2016-11-09 13:28:52 --> URI Class Initialized
DEBUG - 2016-11-09 13:28:52 --> No URI present. Default controller set.
INFO - 2016-11-09 13:28:52 --> Router Class Initialized
INFO - 2016-11-09 13:28:52 --> Output Class Initialized
INFO - 2016-11-09 13:28:52 --> Security Class Initialized
DEBUG - 2016-11-09 13:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 13:28:52 --> Input Class Initialized
INFO - 2016-11-09 13:28:52 --> Language Class Initialized
INFO - 2016-11-09 13:28:52 --> Loader Class Initialized
INFO - 2016-11-09 13:28:52 --> Helper loaded: url_helper
INFO - 2016-11-09 13:28:52 --> Helper loaded: form_helper
INFO - 2016-11-09 13:28:52 --> Database Driver Class Initialized
INFO - 2016-11-09 13:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 13:28:52 --> Controller Class Initialized
INFO - 2016-11-09 13:28:52 --> Model Class Initialized
INFO - 2016-11-09 13:28:52 --> Model Class Initialized
INFO - 2016-11-09 13:28:52 --> Model Class Initialized
INFO - 2016-11-09 13:28:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 13:28:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 13:28:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 13:28:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 13:28:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 13:28:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 13:28:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 13:28:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 13:28:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 13:28:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 13:28:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 13:28:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 13:28:52 --> Final output sent to browser
DEBUG - 2016-11-09 13:28:52 --> Total execution time: 0.3785
INFO - 2016-11-09 14:44:09 --> Config Class Initialized
INFO - 2016-11-09 14:44:09 --> Hooks Class Initialized
DEBUG - 2016-11-09 14:44:09 --> UTF-8 Support Enabled
INFO - 2016-11-09 14:44:09 --> Utf8 Class Initialized
INFO - 2016-11-09 14:44:09 --> URI Class Initialized
INFO - 2016-11-09 14:44:09 --> Router Class Initialized
INFO - 2016-11-09 14:44:09 --> Output Class Initialized
INFO - 2016-11-09 14:44:09 --> Security Class Initialized
DEBUG - 2016-11-09 14:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 14:44:09 --> Input Class Initialized
INFO - 2016-11-09 14:44:09 --> Language Class Initialized
INFO - 2016-11-09 14:44:09 --> Loader Class Initialized
INFO - 2016-11-09 14:44:09 --> Helper loaded: url_helper
INFO - 2016-11-09 14:44:09 --> Helper loaded: form_helper
INFO - 2016-11-09 14:44:09 --> Database Driver Class Initialized
INFO - 2016-11-09 14:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 14:44:09 --> Controller Class Initialized
INFO - 2016-11-09 14:44:09 --> Model Class Initialized
INFO - 2016-11-09 14:44:09 --> Form Validation Class Initialized
INFO - 2016-11-09 14:44:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 14:44:09 --> Final output sent to browser
DEBUG - 2016-11-09 14:44:09 --> Total execution time: 0.2084
INFO - 2016-11-09 14:44:12 --> Config Class Initialized
INFO - 2016-11-09 14:44:12 --> Hooks Class Initialized
DEBUG - 2016-11-09 14:44:12 --> UTF-8 Support Enabled
INFO - 2016-11-09 14:44:12 --> Utf8 Class Initialized
INFO - 2016-11-09 14:44:12 --> URI Class Initialized
DEBUG - 2016-11-09 14:44:12 --> No URI present. Default controller set.
INFO - 2016-11-09 14:44:12 --> Router Class Initialized
INFO - 2016-11-09 14:44:12 --> Output Class Initialized
INFO - 2016-11-09 14:44:12 --> Security Class Initialized
DEBUG - 2016-11-09 14:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 14:44:12 --> Input Class Initialized
INFO - 2016-11-09 14:44:12 --> Language Class Initialized
INFO - 2016-11-09 14:44:12 --> Loader Class Initialized
INFO - 2016-11-09 14:44:12 --> Helper loaded: url_helper
INFO - 2016-11-09 14:44:12 --> Helper loaded: form_helper
INFO - 2016-11-09 14:44:12 --> Database Driver Class Initialized
INFO - 2016-11-09 14:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 14:44:12 --> Controller Class Initialized
INFO - 2016-11-09 14:44:12 --> Model Class Initialized
INFO - 2016-11-09 14:44:12 --> Model Class Initialized
INFO - 2016-11-09 14:44:12 --> Model Class Initialized
INFO - 2016-11-09 14:44:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 14:44:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 14:44:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 14:44:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 14:44:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 14:44:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 14:44:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 14:44:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 14:44:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 14:44:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 14:44:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 14:44:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 14:44:12 --> Final output sent to browser
DEBUG - 2016-11-09 14:44:12 --> Total execution time: 0.3261
INFO - 2016-11-09 15:04:09 --> Config Class Initialized
INFO - 2016-11-09 15:04:10 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:04:10 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:04:10 --> Utf8 Class Initialized
INFO - 2016-11-09 15:04:10 --> URI Class Initialized
DEBUG - 2016-11-09 15:04:10 --> No URI present. Default controller set.
INFO - 2016-11-09 15:04:10 --> Router Class Initialized
INFO - 2016-11-09 15:04:10 --> Output Class Initialized
INFO - 2016-11-09 15:04:10 --> Security Class Initialized
DEBUG - 2016-11-09 15:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:04:10 --> Input Class Initialized
INFO - 2016-11-09 15:04:10 --> Language Class Initialized
INFO - 2016-11-09 15:04:10 --> Loader Class Initialized
INFO - 2016-11-09 15:04:10 --> Helper loaded: url_helper
INFO - 2016-11-09 15:04:10 --> Helper loaded: form_helper
INFO - 2016-11-09 15:04:10 --> Database Driver Class Initialized
INFO - 2016-11-09 15:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:04:10 --> Controller Class Initialized
INFO - 2016-11-09 15:04:10 --> Model Class Initialized
INFO - 2016-11-09 15:04:10 --> Model Class Initialized
INFO - 2016-11-09 15:04:10 --> Model Class Initialized
INFO - 2016-11-09 15:04:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:04:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:04:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:04:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:04:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:04:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:04:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:04:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:04:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:04:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:04:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:04:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:04:10 --> Final output sent to browser
DEBUG - 2016-11-09 15:04:10 --> Total execution time: 0.3795
INFO - 2016-11-09 15:06:27 --> Config Class Initialized
INFO - 2016-11-09 15:06:27 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:06:27 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:06:27 --> Utf8 Class Initialized
INFO - 2016-11-09 15:06:27 --> URI Class Initialized
INFO - 2016-11-09 15:06:27 --> Router Class Initialized
INFO - 2016-11-09 15:06:27 --> Output Class Initialized
INFO - 2016-11-09 15:06:27 --> Security Class Initialized
DEBUG - 2016-11-09 15:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:06:27 --> Input Class Initialized
INFO - 2016-11-09 15:06:27 --> Language Class Initialized
INFO - 2016-11-09 15:06:27 --> Loader Class Initialized
INFO - 2016-11-09 15:06:27 --> Helper loaded: url_helper
INFO - 2016-11-09 15:06:27 --> Helper loaded: form_helper
INFO - 2016-11-09 15:06:27 --> Database Driver Class Initialized
INFO - 2016-11-09 15:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:06:28 --> Controller Class Initialized
INFO - 2016-11-09 15:06:28 --> Model Class Initialized
INFO - 2016-11-09 15:06:28 --> Form Validation Class Initialized
INFO - 2016-11-09 15:06:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 15:06:28 --> Final output sent to browser
DEBUG - 2016-11-09 15:06:28 --> Total execution time: 0.4094
INFO - 2016-11-09 15:06:29 --> Config Class Initialized
INFO - 2016-11-09 15:06:29 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:06:29 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:06:29 --> Utf8 Class Initialized
INFO - 2016-11-09 15:06:29 --> URI Class Initialized
DEBUG - 2016-11-09 15:06:29 --> No URI present. Default controller set.
INFO - 2016-11-09 15:06:29 --> Router Class Initialized
INFO - 2016-11-09 15:06:29 --> Output Class Initialized
INFO - 2016-11-09 15:06:29 --> Security Class Initialized
DEBUG - 2016-11-09 15:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:06:29 --> Input Class Initialized
INFO - 2016-11-09 15:06:29 --> Language Class Initialized
INFO - 2016-11-09 15:06:29 --> Loader Class Initialized
INFO - 2016-11-09 15:06:29 --> Helper loaded: url_helper
INFO - 2016-11-09 15:06:29 --> Helper loaded: form_helper
INFO - 2016-11-09 15:06:29 --> Database Driver Class Initialized
INFO - 2016-11-09 15:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:06:29 --> Controller Class Initialized
INFO - 2016-11-09 15:06:29 --> Model Class Initialized
INFO - 2016-11-09 15:06:29 --> Model Class Initialized
INFO - 2016-11-09 15:06:29 --> Model Class Initialized
INFO - 2016-11-09 15:06:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:06:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:06:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:06:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:06:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:06:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:06:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:06:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:06:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:06:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:06:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:06:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:06:29 --> Final output sent to browser
DEBUG - 2016-11-09 15:06:29 --> Total execution time: 0.3859
INFO - 2016-11-09 15:07:24 --> Config Class Initialized
INFO - 2016-11-09 15:07:24 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:07:25 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:07:25 --> Utf8 Class Initialized
INFO - 2016-11-09 15:07:25 --> URI Class Initialized
DEBUG - 2016-11-09 15:07:25 --> No URI present. Default controller set.
INFO - 2016-11-09 15:07:25 --> Router Class Initialized
INFO - 2016-11-09 15:07:25 --> Output Class Initialized
INFO - 2016-11-09 15:07:25 --> Security Class Initialized
DEBUG - 2016-11-09 15:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:07:25 --> Input Class Initialized
INFO - 2016-11-09 15:07:25 --> Language Class Initialized
INFO - 2016-11-09 15:07:25 --> Loader Class Initialized
INFO - 2016-11-09 15:07:25 --> Helper loaded: url_helper
INFO - 2016-11-09 15:07:25 --> Helper loaded: form_helper
INFO - 2016-11-09 15:07:25 --> Database Driver Class Initialized
INFO - 2016-11-09 15:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:07:25 --> Controller Class Initialized
INFO - 2016-11-09 15:07:25 --> Model Class Initialized
INFO - 2016-11-09 15:07:25 --> Model Class Initialized
INFO - 2016-11-09 15:07:25 --> Model Class Initialized
INFO - 2016-11-09 15:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:07:25 --> Final output sent to browser
DEBUG - 2016-11-09 15:07:25 --> Total execution time: 0.3346
INFO - 2016-11-09 15:07:30 --> Config Class Initialized
INFO - 2016-11-09 15:07:30 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:07:30 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:07:30 --> Utf8 Class Initialized
INFO - 2016-11-09 15:07:30 --> URI Class Initialized
DEBUG - 2016-11-09 15:07:30 --> No URI present. Default controller set.
INFO - 2016-11-09 15:07:30 --> Router Class Initialized
INFO - 2016-11-09 15:07:30 --> Output Class Initialized
INFO - 2016-11-09 15:07:30 --> Security Class Initialized
DEBUG - 2016-11-09 15:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:07:30 --> Input Class Initialized
INFO - 2016-11-09 15:07:30 --> Language Class Initialized
INFO - 2016-11-09 15:07:30 --> Loader Class Initialized
INFO - 2016-11-09 15:07:30 --> Helper loaded: url_helper
INFO - 2016-11-09 15:07:30 --> Helper loaded: form_helper
INFO - 2016-11-09 15:07:30 --> Database Driver Class Initialized
INFO - 2016-11-09 15:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:07:30 --> Controller Class Initialized
INFO - 2016-11-09 15:07:30 --> Model Class Initialized
INFO - 2016-11-09 15:07:30 --> Model Class Initialized
INFO - 2016-11-09 15:07:30 --> Model Class Initialized
INFO - 2016-11-09 15:07:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:07:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:07:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:07:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:07:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:07:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:07:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:07:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:07:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:07:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:07:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:07:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:07:30 --> Final output sent to browser
DEBUG - 2016-11-09 15:07:30 --> Total execution time: 0.3375
INFO - 2016-11-09 15:11:49 --> Config Class Initialized
INFO - 2016-11-09 15:11:49 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:11:49 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:11:49 --> Utf8 Class Initialized
INFO - 2016-11-09 15:11:49 --> URI Class Initialized
INFO - 2016-11-09 15:11:49 --> Router Class Initialized
INFO - 2016-11-09 15:11:49 --> Output Class Initialized
INFO - 2016-11-09 15:11:49 --> Security Class Initialized
DEBUG - 2016-11-09 15:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:11:49 --> Input Class Initialized
INFO - 2016-11-09 15:11:49 --> Language Class Initialized
INFO - 2016-11-09 15:11:49 --> Loader Class Initialized
INFO - 2016-11-09 15:11:49 --> Helper loaded: url_helper
INFO - 2016-11-09 15:11:49 --> Helper loaded: form_helper
INFO - 2016-11-09 15:11:49 --> Database Driver Class Initialized
INFO - 2016-11-09 15:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:11:49 --> Controller Class Initialized
INFO - 2016-11-09 15:11:49 --> Model Class Initialized
INFO - 2016-11-09 15:11:49 --> Form Validation Class Initialized
INFO - 2016-11-09 15:11:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 15:11:49 --> Final output sent to browser
DEBUG - 2016-11-09 15:11:49 --> Total execution time: 0.2258
INFO - 2016-11-09 15:11:51 --> Config Class Initialized
INFO - 2016-11-09 15:11:51 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:11:51 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:11:51 --> Utf8 Class Initialized
INFO - 2016-11-09 15:11:51 --> URI Class Initialized
DEBUG - 2016-11-09 15:11:51 --> No URI present. Default controller set.
INFO - 2016-11-09 15:11:51 --> Router Class Initialized
INFO - 2016-11-09 15:11:51 --> Output Class Initialized
INFO - 2016-11-09 15:11:51 --> Security Class Initialized
DEBUG - 2016-11-09 15:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:11:51 --> Input Class Initialized
INFO - 2016-11-09 15:11:51 --> Language Class Initialized
INFO - 2016-11-09 15:11:51 --> Loader Class Initialized
INFO - 2016-11-09 15:11:51 --> Helper loaded: url_helper
INFO - 2016-11-09 15:11:51 --> Helper loaded: form_helper
INFO - 2016-11-09 15:11:51 --> Database Driver Class Initialized
INFO - 2016-11-09 15:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:11:51 --> Controller Class Initialized
INFO - 2016-11-09 15:11:51 --> Model Class Initialized
INFO - 2016-11-09 15:11:51 --> Model Class Initialized
INFO - 2016-11-09 15:11:51 --> Model Class Initialized
INFO - 2016-11-09 15:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:11:51 --> Final output sent to browser
DEBUG - 2016-11-09 15:11:51 --> Total execution time: 0.3907
INFO - 2016-11-09 15:29:44 --> Config Class Initialized
INFO - 2016-11-09 15:29:44 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:29:44 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:29:44 --> Utf8 Class Initialized
INFO - 2016-11-09 15:29:44 --> URI Class Initialized
DEBUG - 2016-11-09 15:29:44 --> No URI present. Default controller set.
INFO - 2016-11-09 15:29:44 --> Router Class Initialized
INFO - 2016-11-09 15:29:44 --> Output Class Initialized
INFO - 2016-11-09 15:29:44 --> Security Class Initialized
DEBUG - 2016-11-09 15:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:29:44 --> Input Class Initialized
INFO - 2016-11-09 15:29:44 --> Language Class Initialized
INFO - 2016-11-09 15:29:44 --> Loader Class Initialized
INFO - 2016-11-09 15:29:44 --> Helper loaded: url_helper
INFO - 2016-11-09 15:29:44 --> Helper loaded: form_helper
INFO - 2016-11-09 15:29:44 --> Database Driver Class Initialized
INFO - 2016-11-09 15:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:29:44 --> Controller Class Initialized
INFO - 2016-11-09 15:29:44 --> Model Class Initialized
INFO - 2016-11-09 15:29:44 --> Model Class Initialized
INFO - 2016-11-09 15:29:44 --> Model Class Initialized
INFO - 2016-11-09 15:29:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:29:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:29:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:29:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:29:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:29:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:29:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:29:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:29:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:29:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:29:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:29:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:29:44 --> Final output sent to browser
DEBUG - 2016-11-09 15:29:44 --> Total execution time: 0.3630
INFO - 2016-11-09 15:29:47 --> Config Class Initialized
INFO - 2016-11-09 15:29:47 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:29:47 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:29:47 --> Utf8 Class Initialized
INFO - 2016-11-09 15:29:47 --> URI Class Initialized
INFO - 2016-11-09 15:29:47 --> Router Class Initialized
INFO - 2016-11-09 15:29:47 --> Output Class Initialized
INFO - 2016-11-09 15:29:47 --> Security Class Initialized
DEBUG - 2016-11-09 15:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:29:47 --> Input Class Initialized
INFO - 2016-11-09 15:29:47 --> Language Class Initialized
INFO - 2016-11-09 15:29:47 --> Loader Class Initialized
INFO - 2016-11-09 15:29:47 --> Helper loaded: url_helper
INFO - 2016-11-09 15:29:47 --> Helper loaded: form_helper
INFO - 2016-11-09 15:29:47 --> Database Driver Class Initialized
INFO - 2016-11-09 15:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:29:47 --> Controller Class Initialized
INFO - 2016-11-09 15:29:47 --> Model Class Initialized
INFO - 2016-11-09 15:29:47 --> Form Validation Class Initialized
INFO - 2016-11-09 15:29:47 --> Final output sent to browser
DEBUG - 2016-11-09 15:29:47 --> Total execution time: 0.3555
INFO - 2016-11-09 15:29:55 --> Config Class Initialized
INFO - 2016-11-09 15:29:55 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:29:55 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:29:55 --> Utf8 Class Initialized
INFO - 2016-11-09 15:29:55 --> URI Class Initialized
DEBUG - 2016-11-09 15:29:55 --> No URI present. Default controller set.
INFO - 2016-11-09 15:29:55 --> Router Class Initialized
INFO - 2016-11-09 15:29:55 --> Output Class Initialized
INFO - 2016-11-09 15:29:55 --> Security Class Initialized
DEBUG - 2016-11-09 15:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:29:55 --> Input Class Initialized
INFO - 2016-11-09 15:29:55 --> Language Class Initialized
INFO - 2016-11-09 15:29:55 --> Loader Class Initialized
INFO - 2016-11-09 15:29:55 --> Helper loaded: url_helper
INFO - 2016-11-09 15:29:55 --> Helper loaded: form_helper
INFO - 2016-11-09 15:29:55 --> Database Driver Class Initialized
INFO - 2016-11-09 15:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:29:55 --> Controller Class Initialized
INFO - 2016-11-09 15:29:55 --> Model Class Initialized
INFO - 2016-11-09 15:29:55 --> Model Class Initialized
INFO - 2016-11-09 15:29:55 --> Model Class Initialized
INFO - 2016-11-09 15:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:29:55 --> Final output sent to browser
DEBUG - 2016-11-09 15:29:55 --> Total execution time: 0.3519
INFO - 2016-11-09 15:30:16 --> Config Class Initialized
INFO - 2016-11-09 15:30:16 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:30:16 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:30:16 --> Utf8 Class Initialized
INFO - 2016-11-09 15:30:16 --> URI Class Initialized
DEBUG - 2016-11-09 15:30:16 --> No URI present. Default controller set.
INFO - 2016-11-09 15:30:16 --> Router Class Initialized
INFO - 2016-11-09 15:30:16 --> Output Class Initialized
INFO - 2016-11-09 15:30:16 --> Security Class Initialized
DEBUG - 2016-11-09 15:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:30:16 --> Input Class Initialized
INFO - 2016-11-09 15:30:16 --> Language Class Initialized
INFO - 2016-11-09 15:30:16 --> Loader Class Initialized
INFO - 2016-11-09 15:30:16 --> Helper loaded: url_helper
INFO - 2016-11-09 15:30:16 --> Helper loaded: form_helper
INFO - 2016-11-09 15:30:16 --> Database Driver Class Initialized
INFO - 2016-11-09 15:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:30:16 --> Controller Class Initialized
INFO - 2016-11-09 15:30:16 --> Model Class Initialized
INFO - 2016-11-09 15:30:16 --> Model Class Initialized
INFO - 2016-11-09 15:30:16 --> Model Class Initialized
INFO - 2016-11-09 15:30:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:30:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:30:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:30:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:30:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:30:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:30:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:30:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:30:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:30:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:30:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:30:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:30:17 --> Final output sent to browser
DEBUG - 2016-11-09 15:30:17 --> Total execution time: 0.3384
INFO - 2016-11-09 15:30:19 --> Config Class Initialized
INFO - 2016-11-09 15:30:19 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:30:19 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:30:19 --> Utf8 Class Initialized
INFO - 2016-11-09 15:30:19 --> URI Class Initialized
INFO - 2016-11-09 15:30:19 --> Router Class Initialized
INFO - 2016-11-09 15:30:19 --> Output Class Initialized
INFO - 2016-11-09 15:30:19 --> Security Class Initialized
DEBUG - 2016-11-09 15:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:30:19 --> Input Class Initialized
INFO - 2016-11-09 15:30:19 --> Language Class Initialized
INFO - 2016-11-09 15:30:19 --> Loader Class Initialized
INFO - 2016-11-09 15:30:19 --> Helper loaded: url_helper
INFO - 2016-11-09 15:30:19 --> Helper loaded: form_helper
INFO - 2016-11-09 15:30:19 --> Database Driver Class Initialized
INFO - 2016-11-09 15:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:30:19 --> Controller Class Initialized
INFO - 2016-11-09 15:30:19 --> Model Class Initialized
INFO - 2016-11-09 15:30:19 --> Form Validation Class Initialized
INFO - 2016-11-09 15:30:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 15:30:19 --> Final output sent to browser
DEBUG - 2016-11-09 15:30:19 --> Total execution time: 0.4182
INFO - 2016-11-09 15:35:35 --> Config Class Initialized
INFO - 2016-11-09 15:35:35 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:35:35 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:35:35 --> Utf8 Class Initialized
INFO - 2016-11-09 15:35:35 --> URI Class Initialized
INFO - 2016-11-09 15:35:35 --> Router Class Initialized
INFO - 2016-11-09 15:35:35 --> Output Class Initialized
INFO - 2016-11-09 15:35:35 --> Security Class Initialized
DEBUG - 2016-11-09 15:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:35:35 --> Input Class Initialized
INFO - 2016-11-09 15:35:35 --> Language Class Initialized
INFO - 2016-11-09 15:35:35 --> Loader Class Initialized
INFO - 2016-11-09 15:35:35 --> Helper loaded: url_helper
INFO - 2016-11-09 15:35:35 --> Helper loaded: form_helper
INFO - 2016-11-09 15:35:35 --> Database Driver Class Initialized
INFO - 2016-11-09 15:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:35:35 --> Controller Class Initialized
INFO - 2016-11-09 15:35:35 --> Model Class Initialized
INFO - 2016-11-09 15:35:35 --> Form Validation Class Initialized
ERROR - 2016-11-09 15:35:35 --> Severity: Notice --> Undefined variable: dateValidation C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 47
INFO - 2016-11-09 15:35:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 15:35:35 --> Final output sent to browser
DEBUG - 2016-11-09 15:35:35 --> Total execution time: 0.2524
INFO - 2016-11-09 15:37:54 --> Config Class Initialized
INFO - 2016-11-09 15:37:54 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:37:54 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:37:54 --> Utf8 Class Initialized
INFO - 2016-11-09 15:37:54 --> URI Class Initialized
INFO - 2016-11-09 15:37:54 --> Router Class Initialized
INFO - 2016-11-09 15:37:54 --> Output Class Initialized
INFO - 2016-11-09 15:37:54 --> Security Class Initialized
DEBUG - 2016-11-09 15:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:37:54 --> Input Class Initialized
INFO - 2016-11-09 15:37:54 --> Language Class Initialized
INFO - 2016-11-09 15:37:54 --> Loader Class Initialized
INFO - 2016-11-09 15:37:54 --> Helper loaded: url_helper
INFO - 2016-11-09 15:37:54 --> Helper loaded: form_helper
INFO - 2016-11-09 15:37:54 --> Database Driver Class Initialized
INFO - 2016-11-09 15:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:37:54 --> Controller Class Initialized
INFO - 2016-11-09 15:37:54 --> Model Class Initialized
INFO - 2016-11-09 15:37:54 --> Form Validation Class Initialized
ERROR - 2016-11-09 15:37:54 --> Severity: Notice --> Undefined variable: dateValidation C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 47
INFO - 2016-11-09 15:37:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 15:37:54 --> Final output sent to browser
DEBUG - 2016-11-09 15:37:54 --> Total execution time: 0.2252
INFO - 2016-11-09 15:38:27 --> Config Class Initialized
INFO - 2016-11-09 15:38:27 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:38:27 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:38:27 --> Utf8 Class Initialized
INFO - 2016-11-09 15:38:27 --> URI Class Initialized
INFO - 2016-11-09 15:38:27 --> Router Class Initialized
INFO - 2016-11-09 15:38:27 --> Output Class Initialized
INFO - 2016-11-09 15:38:27 --> Security Class Initialized
DEBUG - 2016-11-09 15:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:38:27 --> Input Class Initialized
INFO - 2016-11-09 15:38:27 --> Language Class Initialized
INFO - 2016-11-09 15:38:27 --> Loader Class Initialized
INFO - 2016-11-09 15:38:27 --> Helper loaded: url_helper
INFO - 2016-11-09 15:38:27 --> Helper loaded: form_helper
INFO - 2016-11-09 15:38:27 --> Database Driver Class Initialized
INFO - 2016-11-09 15:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:38:27 --> Controller Class Initialized
INFO - 2016-11-09 15:38:27 --> Model Class Initialized
INFO - 2016-11-09 15:38:27 --> Form Validation Class Initialized
ERROR - 2016-11-09 15:38:27 --> Severity: Notice --> Undefined variable: validation C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 47
INFO - 2016-11-09 15:38:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 15:38:27 --> Final output sent to browser
DEBUG - 2016-11-09 15:38:27 --> Total execution time: 0.2169
INFO - 2016-11-09 15:39:05 --> Config Class Initialized
INFO - 2016-11-09 15:39:05 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:39:05 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:39:05 --> Utf8 Class Initialized
INFO - 2016-11-09 15:39:06 --> URI Class Initialized
INFO - 2016-11-09 15:39:06 --> Router Class Initialized
INFO - 2016-11-09 15:39:06 --> Output Class Initialized
INFO - 2016-11-09 15:39:06 --> Security Class Initialized
DEBUG - 2016-11-09 15:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:39:06 --> Input Class Initialized
INFO - 2016-11-09 15:39:06 --> Language Class Initialized
INFO - 2016-11-09 15:39:06 --> Loader Class Initialized
INFO - 2016-11-09 15:39:06 --> Helper loaded: url_helper
INFO - 2016-11-09 15:39:06 --> Helper loaded: form_helper
INFO - 2016-11-09 15:39:06 --> Database Driver Class Initialized
INFO - 2016-11-09 15:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:39:06 --> Controller Class Initialized
INFO - 2016-11-09 15:39:06 --> Model Class Initialized
INFO - 2016-11-09 15:39:06 --> Form Validation Class Initialized
INFO - 2016-11-09 15:39:06 --> Final output sent to browser
DEBUG - 2016-11-09 15:39:06 --> Total execution time: 0.2038
INFO - 2016-11-09 15:39:45 --> Config Class Initialized
INFO - 2016-11-09 15:39:45 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:39:45 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:39:45 --> Utf8 Class Initialized
INFO - 2016-11-09 15:39:45 --> URI Class Initialized
INFO - 2016-11-09 15:39:45 --> Router Class Initialized
INFO - 2016-11-09 15:39:45 --> Output Class Initialized
INFO - 2016-11-09 15:39:45 --> Security Class Initialized
DEBUG - 2016-11-09 15:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:39:45 --> Input Class Initialized
INFO - 2016-11-09 15:39:45 --> Language Class Initialized
INFO - 2016-11-09 15:39:45 --> Loader Class Initialized
INFO - 2016-11-09 15:39:45 --> Helper loaded: url_helper
INFO - 2016-11-09 15:39:45 --> Helper loaded: form_helper
INFO - 2016-11-09 15:39:45 --> Database Driver Class Initialized
INFO - 2016-11-09 15:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:39:45 --> Controller Class Initialized
INFO - 2016-11-09 15:39:45 --> Model Class Initialized
INFO - 2016-11-09 15:39:45 --> Form Validation Class Initialized
INFO - 2016-11-09 15:39:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 15:39:45 --> Final output sent to browser
DEBUG - 2016-11-09 15:39:45 --> Total execution time: 0.2099
INFO - 2016-11-09 15:41:32 --> Config Class Initialized
INFO - 2016-11-09 15:41:32 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:41:32 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:41:32 --> Utf8 Class Initialized
INFO - 2016-11-09 15:41:32 --> URI Class Initialized
INFO - 2016-11-09 15:41:32 --> Router Class Initialized
INFO - 2016-11-09 15:41:32 --> Output Class Initialized
INFO - 2016-11-09 15:41:32 --> Security Class Initialized
DEBUG - 2016-11-09 15:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:41:32 --> Input Class Initialized
INFO - 2016-11-09 15:41:32 --> Language Class Initialized
INFO - 2016-11-09 15:41:32 --> Loader Class Initialized
INFO - 2016-11-09 15:41:32 --> Helper loaded: url_helper
INFO - 2016-11-09 15:41:32 --> Helper loaded: form_helper
INFO - 2016-11-09 15:41:32 --> Database Driver Class Initialized
INFO - 2016-11-09 15:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:41:32 --> Controller Class Initialized
INFO - 2016-11-09 15:41:32 --> Model Class Initialized
INFO - 2016-11-09 15:41:32 --> Form Validation Class Initialized
INFO - 2016-11-09 15:41:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 15:41:32 --> Final output sent to browser
DEBUG - 2016-11-09 15:41:32 --> Total execution time: 0.2113
INFO - 2016-11-09 15:41:36 --> Config Class Initialized
INFO - 2016-11-09 15:41:36 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:41:36 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:41:36 --> Utf8 Class Initialized
INFO - 2016-11-09 15:41:36 --> URI Class Initialized
DEBUG - 2016-11-09 15:41:36 --> No URI present. Default controller set.
INFO - 2016-11-09 15:41:36 --> Router Class Initialized
INFO - 2016-11-09 15:41:36 --> Output Class Initialized
INFO - 2016-11-09 15:41:36 --> Security Class Initialized
DEBUG - 2016-11-09 15:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:41:36 --> Input Class Initialized
INFO - 2016-11-09 15:41:36 --> Language Class Initialized
INFO - 2016-11-09 15:41:36 --> Loader Class Initialized
INFO - 2016-11-09 15:41:36 --> Helper loaded: url_helper
INFO - 2016-11-09 15:41:36 --> Helper loaded: form_helper
INFO - 2016-11-09 15:41:36 --> Database Driver Class Initialized
INFO - 2016-11-09 15:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:41:36 --> Controller Class Initialized
INFO - 2016-11-09 15:41:36 --> Model Class Initialized
INFO - 2016-11-09 15:41:36 --> Model Class Initialized
INFO - 2016-11-09 15:41:36 --> Model Class Initialized
INFO - 2016-11-09 15:41:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:41:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:41:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:41:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:41:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:41:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:41:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:41:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:41:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:41:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:41:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:41:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:41:37 --> Final output sent to browser
DEBUG - 2016-11-09 15:41:37 --> Total execution time: 0.3385
INFO - 2016-11-09 15:41:47 --> Config Class Initialized
INFO - 2016-11-09 15:41:47 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:41:47 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:41:47 --> Utf8 Class Initialized
INFO - 2016-11-09 15:41:47 --> URI Class Initialized
INFO - 2016-11-09 15:41:47 --> Router Class Initialized
INFO - 2016-11-09 15:41:48 --> Output Class Initialized
INFO - 2016-11-09 15:41:48 --> Security Class Initialized
DEBUG - 2016-11-09 15:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:41:48 --> Input Class Initialized
INFO - 2016-11-09 15:41:48 --> Language Class Initialized
INFO - 2016-11-09 15:41:48 --> Loader Class Initialized
INFO - 2016-11-09 15:41:48 --> Helper loaded: url_helper
INFO - 2016-11-09 15:41:48 --> Helper loaded: form_helper
INFO - 2016-11-09 15:41:48 --> Database Driver Class Initialized
INFO - 2016-11-09 15:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:41:48 --> Controller Class Initialized
INFO - 2016-11-09 15:41:48 --> Model Class Initialized
INFO - 2016-11-09 15:41:48 --> Form Validation Class Initialized
INFO - 2016-11-09 15:41:48 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-09 15:41:48 --> Unable to find callback validation rule: compareDate
ERROR - 2016-11-09 15:41:48 --> Could not find the language line "form_validation_compareDate"
DEBUG - 2016-11-09 15:41:48 --> Unable to find callback validation rule: compareDate
ERROR - 2016-11-09 15:41:48 --> Could not find the language line "form_validation_compareDate"
INFO - 2016-11-09 15:41:48 --> Final output sent to browser
DEBUG - 2016-11-09 15:41:48 --> Total execution time: 0.7334
INFO - 2016-11-09 15:42:37 --> Config Class Initialized
INFO - 2016-11-09 15:42:37 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:42:38 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:42:38 --> Utf8 Class Initialized
INFO - 2016-11-09 15:42:38 --> URI Class Initialized
INFO - 2016-11-09 15:42:38 --> Router Class Initialized
INFO - 2016-11-09 15:42:38 --> Output Class Initialized
INFO - 2016-11-09 15:42:38 --> Security Class Initialized
DEBUG - 2016-11-09 15:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:42:38 --> Input Class Initialized
INFO - 2016-11-09 15:42:38 --> Language Class Initialized
INFO - 2016-11-09 15:42:38 --> Loader Class Initialized
INFO - 2016-11-09 15:42:38 --> Helper loaded: url_helper
INFO - 2016-11-09 15:42:38 --> Helper loaded: form_helper
INFO - 2016-11-09 15:42:38 --> Database Driver Class Initialized
INFO - 2016-11-09 15:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:42:38 --> Controller Class Initialized
INFO - 2016-11-09 15:42:38 --> Model Class Initialized
INFO - 2016-11-09 15:42:38 --> Form Validation Class Initialized
INFO - 2016-11-09 15:42:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-09 15:42:38 --> Unable to find callback validation rule: compareDate
ERROR - 2016-11-09 15:42:38 --> Could not find the language line "form_validation_compareDate"
DEBUG - 2016-11-09 15:42:38 --> Unable to find callback validation rule: compareDate
ERROR - 2016-11-09 15:42:38 --> Could not find the language line "form_validation_compareDate"
INFO - 2016-11-09 15:42:38 --> Final output sent to browser
DEBUG - 2016-11-09 15:42:38 --> Total execution time: 0.2491
INFO - 2016-11-09 15:42:39 --> Config Class Initialized
INFO - 2016-11-09 15:42:39 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:42:39 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:42:39 --> Utf8 Class Initialized
INFO - 2016-11-09 15:42:39 --> URI Class Initialized
DEBUG - 2016-11-09 15:42:39 --> No URI present. Default controller set.
INFO - 2016-11-09 15:42:39 --> Router Class Initialized
INFO - 2016-11-09 15:42:39 --> Output Class Initialized
INFO - 2016-11-09 15:42:39 --> Security Class Initialized
DEBUG - 2016-11-09 15:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:42:39 --> Input Class Initialized
INFO - 2016-11-09 15:42:39 --> Language Class Initialized
INFO - 2016-11-09 15:42:39 --> Loader Class Initialized
INFO - 2016-11-09 15:42:39 --> Helper loaded: url_helper
INFO - 2016-11-09 15:42:39 --> Helper loaded: form_helper
INFO - 2016-11-09 15:42:39 --> Database Driver Class Initialized
INFO - 2016-11-09 15:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:42:39 --> Controller Class Initialized
INFO - 2016-11-09 15:42:39 --> Model Class Initialized
INFO - 2016-11-09 15:42:39 --> Model Class Initialized
INFO - 2016-11-09 15:42:39 --> Model Class Initialized
INFO - 2016-11-09 15:42:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:42:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:42:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:42:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:42:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:42:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:42:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:42:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:42:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:42:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:42:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:42:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:42:40 --> Final output sent to browser
DEBUG - 2016-11-09 15:42:40 --> Total execution time: 0.5587
INFO - 2016-11-09 15:42:50 --> Config Class Initialized
INFO - 2016-11-09 15:42:50 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:42:50 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:42:50 --> Utf8 Class Initialized
INFO - 2016-11-09 15:42:50 --> URI Class Initialized
INFO - 2016-11-09 15:42:50 --> Router Class Initialized
INFO - 2016-11-09 15:42:50 --> Output Class Initialized
INFO - 2016-11-09 15:42:50 --> Security Class Initialized
DEBUG - 2016-11-09 15:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:42:50 --> Input Class Initialized
INFO - 2016-11-09 15:42:50 --> Language Class Initialized
INFO - 2016-11-09 15:42:50 --> Loader Class Initialized
INFO - 2016-11-09 15:42:50 --> Helper loaded: url_helper
INFO - 2016-11-09 15:42:50 --> Helper loaded: form_helper
INFO - 2016-11-09 15:42:50 --> Database Driver Class Initialized
INFO - 2016-11-09 15:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:42:50 --> Controller Class Initialized
INFO - 2016-11-09 15:42:50 --> Model Class Initialized
INFO - 2016-11-09 15:42:50 --> Form Validation Class Initialized
INFO - 2016-11-09 15:42:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-09 15:42:50 --> Unable to find callback validation rule: compareDate
ERROR - 2016-11-09 15:42:50 --> Could not find the language line "form_validation_compareDate"
DEBUG - 2016-11-09 15:42:50 --> Unable to find callback validation rule: compareDate
ERROR - 2016-11-09 15:42:50 --> Could not find the language line "form_validation_compareDate"
INFO - 2016-11-09 15:42:50 --> Final output sent to browser
DEBUG - 2016-11-09 15:42:50 --> Total execution time: 0.2567
INFO - 2016-11-09 15:44:08 --> Config Class Initialized
INFO - 2016-11-09 15:44:08 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:44:08 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:44:08 --> Utf8 Class Initialized
INFO - 2016-11-09 15:44:09 --> URI Class Initialized
INFO - 2016-11-09 15:44:09 --> Router Class Initialized
INFO - 2016-11-09 15:44:09 --> Output Class Initialized
INFO - 2016-11-09 15:44:09 --> Security Class Initialized
DEBUG - 2016-11-09 15:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:44:09 --> Input Class Initialized
INFO - 2016-11-09 15:44:09 --> Language Class Initialized
INFO - 2016-11-09 15:44:09 --> Loader Class Initialized
INFO - 2016-11-09 15:44:09 --> Helper loaded: url_helper
INFO - 2016-11-09 15:44:09 --> Helper loaded: form_helper
INFO - 2016-11-09 15:44:09 --> Database Driver Class Initialized
INFO - 2016-11-09 15:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:44:09 --> Controller Class Initialized
INFO - 2016-11-09 15:44:09 --> Model Class Initialized
INFO - 2016-11-09 15:44:09 --> Form Validation Class Initialized
INFO - 2016-11-09 15:44:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-09 15:44:09 --> Unable to find callback validation rule: compareDate
ERROR - 2016-11-09 15:44:09 --> Could not find the language line "form_validation_compareDate"
DEBUG - 2016-11-09 15:44:09 --> Unable to find callback validation rule: compareDate
ERROR - 2016-11-09 15:44:09 --> Could not find the language line "form_validation_compareDate"
INFO - 2016-11-09 15:44:09 --> Final output sent to browser
DEBUG - 2016-11-09 15:44:09 --> Total execution time: 0.2448
INFO - 2016-11-09 15:44:09 --> Config Class Initialized
INFO - 2016-11-09 15:44:09 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:44:10 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:44:10 --> Utf8 Class Initialized
INFO - 2016-11-09 15:44:10 --> URI Class Initialized
DEBUG - 2016-11-09 15:44:10 --> No URI present. Default controller set.
INFO - 2016-11-09 15:44:10 --> Router Class Initialized
INFO - 2016-11-09 15:44:10 --> Output Class Initialized
INFO - 2016-11-09 15:44:10 --> Security Class Initialized
DEBUG - 2016-11-09 15:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:44:10 --> Input Class Initialized
INFO - 2016-11-09 15:44:10 --> Language Class Initialized
INFO - 2016-11-09 15:44:10 --> Loader Class Initialized
INFO - 2016-11-09 15:44:10 --> Helper loaded: url_helper
INFO - 2016-11-09 15:44:10 --> Helper loaded: form_helper
INFO - 2016-11-09 15:44:10 --> Database Driver Class Initialized
INFO - 2016-11-09 15:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:44:10 --> Controller Class Initialized
INFO - 2016-11-09 15:44:10 --> Model Class Initialized
INFO - 2016-11-09 15:44:10 --> Model Class Initialized
INFO - 2016-11-09 15:44:10 --> Model Class Initialized
INFO - 2016-11-09 15:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:44:10 --> Final output sent to browser
DEBUG - 2016-11-09 15:44:10 --> Total execution time: 0.3332
INFO - 2016-11-09 15:44:16 --> Config Class Initialized
INFO - 2016-11-09 15:44:16 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:44:16 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:44:16 --> Utf8 Class Initialized
INFO - 2016-11-09 15:44:16 --> URI Class Initialized
INFO - 2016-11-09 15:44:16 --> Router Class Initialized
INFO - 2016-11-09 15:44:16 --> Output Class Initialized
INFO - 2016-11-09 15:44:16 --> Security Class Initialized
DEBUG - 2016-11-09 15:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:44:16 --> Input Class Initialized
INFO - 2016-11-09 15:44:16 --> Language Class Initialized
INFO - 2016-11-09 15:44:16 --> Loader Class Initialized
INFO - 2016-11-09 15:44:16 --> Helper loaded: url_helper
INFO - 2016-11-09 15:44:16 --> Helper loaded: form_helper
INFO - 2016-11-09 15:44:16 --> Database Driver Class Initialized
INFO - 2016-11-09 15:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:44:16 --> Controller Class Initialized
INFO - 2016-11-09 15:44:16 --> Model Class Initialized
INFO - 2016-11-09 15:44:16 --> Form Validation Class Initialized
INFO - 2016-11-09 15:44:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-09 15:44:16 --> Unable to find callback validation rule: compareDate
ERROR - 2016-11-09 15:44:16 --> Could not find the language line "form_validation_compareDate"
DEBUG - 2016-11-09 15:44:16 --> Unable to find callback validation rule: compareDate
ERROR - 2016-11-09 15:44:16 --> Could not find the language line "form_validation_compareDate"
INFO - 2016-11-09 15:44:16 --> Final output sent to browser
DEBUG - 2016-11-09 15:44:16 --> Total execution time: 0.2470
INFO - 2016-11-09 15:45:38 --> Config Class Initialized
INFO - 2016-11-09 15:45:38 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:45:38 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:45:38 --> Utf8 Class Initialized
INFO - 2016-11-09 15:45:38 --> URI Class Initialized
INFO - 2016-11-09 15:45:38 --> Router Class Initialized
INFO - 2016-11-09 15:45:38 --> Output Class Initialized
INFO - 2016-11-09 15:45:38 --> Security Class Initialized
DEBUG - 2016-11-09 15:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:45:38 --> Input Class Initialized
INFO - 2016-11-09 15:45:38 --> Language Class Initialized
INFO - 2016-11-09 15:45:38 --> Loader Class Initialized
INFO - 2016-11-09 15:45:38 --> Helper loaded: url_helper
INFO - 2016-11-09 15:45:38 --> Helper loaded: form_helper
INFO - 2016-11-09 15:45:38 --> Database Driver Class Initialized
INFO - 2016-11-09 15:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:45:38 --> Controller Class Initialized
INFO - 2016-11-09 15:45:38 --> Model Class Initialized
INFO - 2016-11-09 15:45:38 --> Form Validation Class Initialized
INFO - 2016-11-09 15:45:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-09 15:45:38 --> Unable to find callback validation rule: compareDate
ERROR - 2016-11-09 15:45:38 --> Could not find the language line "form_validation_compareDate"
DEBUG - 2016-11-09 15:45:38 --> Unable to find callback validation rule: compareDate
ERROR - 2016-11-09 15:45:38 --> Could not find the language line "form_validation_compareDate"
INFO - 2016-11-09 15:45:38 --> Final output sent to browser
DEBUG - 2016-11-09 15:45:38 --> Total execution time: 0.2661
INFO - 2016-11-09 15:45:39 --> Config Class Initialized
INFO - 2016-11-09 15:45:39 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:45:39 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:45:39 --> Utf8 Class Initialized
INFO - 2016-11-09 15:45:39 --> URI Class Initialized
DEBUG - 2016-11-09 15:45:39 --> No URI present. Default controller set.
INFO - 2016-11-09 15:45:39 --> Router Class Initialized
INFO - 2016-11-09 15:45:39 --> Output Class Initialized
INFO - 2016-11-09 15:45:39 --> Security Class Initialized
DEBUG - 2016-11-09 15:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:45:39 --> Input Class Initialized
INFO - 2016-11-09 15:45:39 --> Language Class Initialized
INFO - 2016-11-09 15:45:39 --> Loader Class Initialized
INFO - 2016-11-09 15:45:39 --> Helper loaded: url_helper
INFO - 2016-11-09 15:45:39 --> Helper loaded: form_helper
INFO - 2016-11-09 15:45:39 --> Database Driver Class Initialized
INFO - 2016-11-09 15:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:45:39 --> Controller Class Initialized
INFO - 2016-11-09 15:45:39 --> Model Class Initialized
INFO - 2016-11-09 15:45:39 --> Model Class Initialized
INFO - 2016-11-09 15:45:39 --> Model Class Initialized
INFO - 2016-11-09 15:45:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:45:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:45:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:45:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:45:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:45:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:45:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:45:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:45:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:45:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:45:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:45:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:45:39 --> Final output sent to browser
DEBUG - 2016-11-09 15:45:39 --> Total execution time: 0.3541
INFO - 2016-11-09 15:45:42 --> Config Class Initialized
INFO - 2016-11-09 15:45:42 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:45:42 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:45:42 --> Utf8 Class Initialized
INFO - 2016-11-09 15:45:42 --> URI Class Initialized
INFO - 2016-11-09 15:45:42 --> Router Class Initialized
INFO - 2016-11-09 15:45:42 --> Output Class Initialized
INFO - 2016-11-09 15:45:42 --> Security Class Initialized
DEBUG - 2016-11-09 15:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:45:42 --> Input Class Initialized
INFO - 2016-11-09 15:45:42 --> Language Class Initialized
INFO - 2016-11-09 15:45:42 --> Loader Class Initialized
INFO - 2016-11-09 15:45:42 --> Helper loaded: url_helper
INFO - 2016-11-09 15:45:42 --> Helper loaded: form_helper
INFO - 2016-11-09 15:45:42 --> Database Driver Class Initialized
INFO - 2016-11-09 15:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:45:42 --> Controller Class Initialized
INFO - 2016-11-09 15:45:42 --> Model Class Initialized
INFO - 2016-11-09 15:45:42 --> Form Validation Class Initialized
INFO - 2016-11-09 15:45:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-09 15:45:42 --> Unable to find callback validation rule: compareDate
ERROR - 2016-11-09 15:45:42 --> Could not find the language line "form_validation_compareDate"
DEBUG - 2016-11-09 15:45:42 --> Unable to find callback validation rule: compareDate
ERROR - 2016-11-09 15:45:42 --> Could not find the language line "form_validation_compareDate"
INFO - 2016-11-09 15:45:42 --> Final output sent to browser
DEBUG - 2016-11-09 15:45:42 --> Total execution time: 0.2762
INFO - 2016-11-09 15:47:14 --> Config Class Initialized
INFO - 2016-11-09 15:47:14 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:47:14 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:47:14 --> Utf8 Class Initialized
INFO - 2016-11-09 15:47:14 --> URI Class Initialized
INFO - 2016-11-09 15:47:14 --> Router Class Initialized
INFO - 2016-11-09 15:47:14 --> Output Class Initialized
INFO - 2016-11-09 15:47:14 --> Security Class Initialized
DEBUG - 2016-11-09 15:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:47:14 --> Input Class Initialized
INFO - 2016-11-09 15:47:14 --> Language Class Initialized
INFO - 2016-11-09 15:47:14 --> Loader Class Initialized
INFO - 2016-11-09 15:47:14 --> Helper loaded: url_helper
INFO - 2016-11-09 15:47:14 --> Helper loaded: form_helper
INFO - 2016-11-09 15:47:14 --> Database Driver Class Initialized
INFO - 2016-11-09 15:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:47:14 --> Controller Class Initialized
INFO - 2016-11-09 15:47:14 --> Model Class Initialized
INFO - 2016-11-09 15:47:14 --> Form Validation Class Initialized
INFO - 2016-11-09 15:47:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 15:47:14 --> Final output sent to browser
DEBUG - 2016-11-09 15:47:14 --> Total execution time: 0.2191
INFO - 2016-11-09 15:47:18 --> Config Class Initialized
INFO - 2016-11-09 15:47:18 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:47:18 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:47:18 --> Utf8 Class Initialized
INFO - 2016-11-09 15:47:18 --> URI Class Initialized
DEBUG - 2016-11-09 15:47:18 --> No URI present. Default controller set.
INFO - 2016-11-09 15:47:18 --> Router Class Initialized
INFO - 2016-11-09 15:47:18 --> Output Class Initialized
INFO - 2016-11-09 15:47:18 --> Security Class Initialized
DEBUG - 2016-11-09 15:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:47:18 --> Input Class Initialized
INFO - 2016-11-09 15:47:18 --> Language Class Initialized
INFO - 2016-11-09 15:47:18 --> Loader Class Initialized
INFO - 2016-11-09 15:47:18 --> Helper loaded: url_helper
INFO - 2016-11-09 15:47:18 --> Helper loaded: form_helper
INFO - 2016-11-09 15:47:18 --> Database Driver Class Initialized
INFO - 2016-11-09 15:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:47:18 --> Controller Class Initialized
INFO - 2016-11-09 15:47:18 --> Model Class Initialized
INFO - 2016-11-09 15:47:18 --> Model Class Initialized
INFO - 2016-11-09 15:47:18 --> Model Class Initialized
INFO - 2016-11-09 15:47:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:47:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:47:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:47:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:47:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:47:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:47:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:47:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:47:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:47:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:47:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:47:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:47:18 --> Final output sent to browser
DEBUG - 2016-11-09 15:47:19 --> Total execution time: 0.3661
INFO - 2016-11-09 15:47:23 --> Config Class Initialized
INFO - 2016-11-09 15:47:23 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:47:23 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:47:23 --> Utf8 Class Initialized
INFO - 2016-11-09 15:47:23 --> URI Class Initialized
INFO - 2016-11-09 15:47:23 --> Router Class Initialized
INFO - 2016-11-09 15:47:23 --> Output Class Initialized
INFO - 2016-11-09 15:47:23 --> Security Class Initialized
DEBUG - 2016-11-09 15:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:47:23 --> Input Class Initialized
INFO - 2016-11-09 15:47:23 --> Language Class Initialized
INFO - 2016-11-09 15:47:23 --> Loader Class Initialized
INFO - 2016-11-09 15:47:23 --> Helper loaded: url_helper
INFO - 2016-11-09 15:47:23 --> Helper loaded: form_helper
INFO - 2016-11-09 15:47:23 --> Database Driver Class Initialized
INFO - 2016-11-09 15:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:47:23 --> Controller Class Initialized
INFO - 2016-11-09 15:47:23 --> Model Class Initialized
INFO - 2016-11-09 15:47:23 --> Form Validation Class Initialized
INFO - 2016-11-09 15:47:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 15:47:23 --> Final output sent to browser
DEBUG - 2016-11-09 15:47:23 --> Total execution time: 0.4204
INFO - 2016-11-09 15:47:39 --> Config Class Initialized
INFO - 2016-11-09 15:47:39 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:47:39 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:47:39 --> Utf8 Class Initialized
INFO - 2016-11-09 15:47:39 --> URI Class Initialized
DEBUG - 2016-11-09 15:47:39 --> No URI present. Default controller set.
INFO - 2016-11-09 15:47:39 --> Router Class Initialized
INFO - 2016-11-09 15:47:39 --> Output Class Initialized
INFO - 2016-11-09 15:47:39 --> Security Class Initialized
DEBUG - 2016-11-09 15:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:47:39 --> Input Class Initialized
INFO - 2016-11-09 15:47:39 --> Language Class Initialized
INFO - 2016-11-09 15:47:39 --> Loader Class Initialized
INFO - 2016-11-09 15:47:39 --> Helper loaded: url_helper
INFO - 2016-11-09 15:47:39 --> Helper loaded: form_helper
INFO - 2016-11-09 15:47:39 --> Database Driver Class Initialized
INFO - 2016-11-09 15:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:47:39 --> Controller Class Initialized
INFO - 2016-11-09 15:47:39 --> Model Class Initialized
INFO - 2016-11-09 15:47:39 --> Model Class Initialized
INFO - 2016-11-09 15:47:39 --> Model Class Initialized
INFO - 2016-11-09 15:47:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:47:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:47:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:47:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:47:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:47:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:47:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:47:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:47:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:47:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:47:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:47:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:47:39 --> Final output sent to browser
DEBUG - 2016-11-09 15:47:39 --> Total execution time: 0.3602
INFO - 2016-11-09 15:47:55 --> Config Class Initialized
INFO - 2016-11-09 15:47:55 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:47:55 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:47:55 --> Utf8 Class Initialized
INFO - 2016-11-09 15:47:55 --> URI Class Initialized
INFO - 2016-11-09 15:47:55 --> Router Class Initialized
INFO - 2016-11-09 15:47:55 --> Output Class Initialized
INFO - 2016-11-09 15:47:55 --> Security Class Initialized
DEBUG - 2016-11-09 15:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:47:55 --> Input Class Initialized
INFO - 2016-11-09 15:47:55 --> Language Class Initialized
INFO - 2016-11-09 15:47:55 --> Loader Class Initialized
INFO - 2016-11-09 15:47:55 --> Helper loaded: url_helper
INFO - 2016-11-09 15:47:55 --> Helper loaded: form_helper
INFO - 2016-11-09 15:47:55 --> Database Driver Class Initialized
INFO - 2016-11-09 15:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:47:55 --> Controller Class Initialized
INFO - 2016-11-09 15:47:55 --> Model Class Initialized
INFO - 2016-11-09 15:47:55 --> Form Validation Class Initialized
INFO - 2016-11-09 15:47:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 15:47:55 --> Final output sent to browser
DEBUG - 2016-11-09 15:47:55 --> Total execution time: 0.4036
INFO - 2016-11-09 15:50:59 --> Config Class Initialized
INFO - 2016-11-09 15:50:59 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:50:59 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:50:59 --> Utf8 Class Initialized
INFO - 2016-11-09 15:50:59 --> URI Class Initialized
DEBUG - 2016-11-09 15:50:59 --> No URI present. Default controller set.
INFO - 2016-11-09 15:50:59 --> Router Class Initialized
INFO - 2016-11-09 15:50:59 --> Output Class Initialized
INFO - 2016-11-09 15:50:59 --> Security Class Initialized
DEBUG - 2016-11-09 15:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:50:59 --> Input Class Initialized
INFO - 2016-11-09 15:50:59 --> Language Class Initialized
INFO - 2016-11-09 15:50:59 --> Loader Class Initialized
INFO - 2016-11-09 15:50:59 --> Helper loaded: url_helper
INFO - 2016-11-09 15:50:59 --> Helper loaded: form_helper
INFO - 2016-11-09 15:50:59 --> Database Driver Class Initialized
INFO - 2016-11-09 15:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:50:59 --> Controller Class Initialized
INFO - 2016-11-09 15:50:59 --> Model Class Initialized
INFO - 2016-11-09 15:50:59 --> Model Class Initialized
INFO - 2016-11-09 15:50:59 --> Model Class Initialized
INFO - 2016-11-09 15:50:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:50:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:50:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:50:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:50:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:50:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:50:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:50:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:50:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:50:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:50:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:50:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:50:59 --> Final output sent to browser
DEBUG - 2016-11-09 15:50:59 --> Total execution time: 0.3696
INFO - 2016-11-09 15:51:00 --> Config Class Initialized
INFO - 2016-11-09 15:51:00 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:51:00 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:51:00 --> Utf8 Class Initialized
INFO - 2016-11-09 15:51:00 --> URI Class Initialized
DEBUG - 2016-11-09 15:51:00 --> No URI present. Default controller set.
INFO - 2016-11-09 15:51:00 --> Router Class Initialized
INFO - 2016-11-09 15:51:00 --> Output Class Initialized
INFO - 2016-11-09 15:51:00 --> Security Class Initialized
DEBUG - 2016-11-09 15:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:51:00 --> Input Class Initialized
INFO - 2016-11-09 15:51:00 --> Language Class Initialized
INFO - 2016-11-09 15:51:00 --> Loader Class Initialized
INFO - 2016-11-09 15:51:00 --> Helper loaded: url_helper
INFO - 2016-11-09 15:51:00 --> Helper loaded: form_helper
INFO - 2016-11-09 15:51:00 --> Database Driver Class Initialized
INFO - 2016-11-09 15:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:51:00 --> Controller Class Initialized
INFO - 2016-11-09 15:51:00 --> Model Class Initialized
INFO - 2016-11-09 15:51:00 --> Model Class Initialized
INFO - 2016-11-09 15:51:00 --> Model Class Initialized
INFO - 2016-11-09 15:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:51:00 --> Final output sent to browser
DEBUG - 2016-11-09 15:51:00 --> Total execution time: 0.3947
INFO - 2016-11-09 15:51:05 --> Config Class Initialized
INFO - 2016-11-09 15:51:05 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:51:05 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:51:05 --> Utf8 Class Initialized
INFO - 2016-11-09 15:51:05 --> URI Class Initialized
DEBUG - 2016-11-09 15:51:05 --> No URI present. Default controller set.
INFO - 2016-11-09 15:51:05 --> Router Class Initialized
INFO - 2016-11-09 15:51:05 --> Output Class Initialized
INFO - 2016-11-09 15:51:05 --> Security Class Initialized
DEBUG - 2016-11-09 15:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:51:05 --> Input Class Initialized
INFO - 2016-11-09 15:51:05 --> Language Class Initialized
INFO - 2016-11-09 15:51:05 --> Loader Class Initialized
INFO - 2016-11-09 15:51:05 --> Helper loaded: url_helper
INFO - 2016-11-09 15:51:05 --> Helper loaded: form_helper
INFO - 2016-11-09 15:51:05 --> Database Driver Class Initialized
INFO - 2016-11-09 15:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:51:05 --> Controller Class Initialized
INFO - 2016-11-09 15:51:05 --> Model Class Initialized
INFO - 2016-11-09 15:51:05 --> Model Class Initialized
INFO - 2016-11-09 15:51:05 --> Model Class Initialized
INFO - 2016-11-09 15:51:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:51:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:51:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:51:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:51:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:51:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:51:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:51:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:51:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:51:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:51:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:51:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:51:05 --> Final output sent to browser
DEBUG - 2016-11-09 15:51:05 --> Total execution time: 0.3761
INFO - 2016-11-09 15:51:13 --> Config Class Initialized
INFO - 2016-11-09 15:51:13 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:51:13 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:51:13 --> Utf8 Class Initialized
INFO - 2016-11-09 15:51:13 --> URI Class Initialized
INFO - 2016-11-09 15:51:13 --> Router Class Initialized
INFO - 2016-11-09 15:51:13 --> Output Class Initialized
INFO - 2016-11-09 15:51:13 --> Security Class Initialized
DEBUG - 2016-11-09 15:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:51:13 --> Input Class Initialized
INFO - 2016-11-09 15:51:13 --> Language Class Initialized
INFO - 2016-11-09 15:51:13 --> Loader Class Initialized
INFO - 2016-11-09 15:51:13 --> Helper loaded: url_helper
INFO - 2016-11-09 15:51:13 --> Helper loaded: form_helper
INFO - 2016-11-09 15:51:13 --> Database Driver Class Initialized
INFO - 2016-11-09 15:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:51:13 --> Controller Class Initialized
INFO - 2016-11-09 15:51:13 --> Model Class Initialized
INFO - 2016-11-09 15:51:13 --> Form Validation Class Initialized
INFO - 2016-11-09 15:51:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 15:51:13 --> Final output sent to browser
DEBUG - 2016-11-09 15:51:13 --> Total execution time: 0.2325
INFO - 2016-11-09 15:51:16 --> Config Class Initialized
INFO - 2016-11-09 15:51:16 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:51:16 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:51:16 --> Utf8 Class Initialized
INFO - 2016-11-09 15:51:16 --> URI Class Initialized
DEBUG - 2016-11-09 15:51:16 --> No URI present. Default controller set.
INFO - 2016-11-09 15:51:16 --> Router Class Initialized
INFO - 2016-11-09 15:51:16 --> Output Class Initialized
INFO - 2016-11-09 15:51:16 --> Security Class Initialized
DEBUG - 2016-11-09 15:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:51:16 --> Input Class Initialized
INFO - 2016-11-09 15:51:16 --> Language Class Initialized
INFO - 2016-11-09 15:51:16 --> Loader Class Initialized
INFO - 2016-11-09 15:51:16 --> Helper loaded: url_helper
INFO - 2016-11-09 15:51:16 --> Helper loaded: form_helper
INFO - 2016-11-09 15:51:16 --> Database Driver Class Initialized
INFO - 2016-11-09 15:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:51:16 --> Controller Class Initialized
INFO - 2016-11-09 15:51:16 --> Model Class Initialized
INFO - 2016-11-09 15:51:16 --> Model Class Initialized
INFO - 2016-11-09 15:51:16 --> Model Class Initialized
INFO - 2016-11-09 15:51:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:51:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:51:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:51:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:51:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:51:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:51:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:51:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:51:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:51:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:51:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:51:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:51:16 --> Final output sent to browser
DEBUG - 2016-11-09 15:51:16 --> Total execution time: 0.3840
INFO - 2016-11-09 15:51:22 --> Config Class Initialized
INFO - 2016-11-09 15:51:22 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:51:22 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:51:22 --> Utf8 Class Initialized
INFO - 2016-11-09 15:51:22 --> URI Class Initialized
INFO - 2016-11-09 15:51:22 --> Router Class Initialized
INFO - 2016-11-09 15:51:22 --> Output Class Initialized
INFO - 2016-11-09 15:51:22 --> Security Class Initialized
DEBUG - 2016-11-09 15:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:51:22 --> Input Class Initialized
INFO - 2016-11-09 15:51:22 --> Language Class Initialized
INFO - 2016-11-09 15:51:22 --> Loader Class Initialized
INFO - 2016-11-09 15:51:22 --> Helper loaded: url_helper
INFO - 2016-11-09 15:51:23 --> Helper loaded: form_helper
INFO - 2016-11-09 15:51:23 --> Database Driver Class Initialized
INFO - 2016-11-09 15:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:51:23 --> Controller Class Initialized
INFO - 2016-11-09 15:51:23 --> Model Class Initialized
INFO - 2016-11-09 15:51:23 --> Form Validation Class Initialized
INFO - 2016-11-09 15:51:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 15:51:23 --> Final output sent to browser
DEBUG - 2016-11-09 15:51:23 --> Total execution time: 0.2436
INFO - 2016-11-09 15:51:26 --> Config Class Initialized
INFO - 2016-11-09 15:51:26 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:51:26 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:51:26 --> Utf8 Class Initialized
INFO - 2016-11-09 15:51:26 --> URI Class Initialized
DEBUG - 2016-11-09 15:51:26 --> No URI present. Default controller set.
INFO - 2016-11-09 15:51:26 --> Router Class Initialized
INFO - 2016-11-09 15:51:26 --> Output Class Initialized
INFO - 2016-11-09 15:51:26 --> Security Class Initialized
DEBUG - 2016-11-09 15:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:51:26 --> Input Class Initialized
INFO - 2016-11-09 15:51:26 --> Language Class Initialized
INFO - 2016-11-09 15:51:26 --> Loader Class Initialized
INFO - 2016-11-09 15:51:26 --> Helper loaded: url_helper
INFO - 2016-11-09 15:51:26 --> Helper loaded: form_helper
INFO - 2016-11-09 15:51:26 --> Database Driver Class Initialized
INFO - 2016-11-09 15:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:51:26 --> Controller Class Initialized
INFO - 2016-11-09 15:51:26 --> Model Class Initialized
INFO - 2016-11-09 15:51:26 --> Model Class Initialized
INFO - 2016-11-09 15:51:26 --> Model Class Initialized
INFO - 2016-11-09 15:51:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:51:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:51:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:51:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:51:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:51:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:51:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:51:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:51:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:51:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:51:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:51:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:51:26 --> Final output sent to browser
DEBUG - 2016-11-09 15:51:26 --> Total execution time: 0.3936
INFO - 2016-11-09 15:52:09 --> Config Class Initialized
INFO - 2016-11-09 15:52:09 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:52:09 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:52:09 --> Utf8 Class Initialized
INFO - 2016-11-09 15:52:09 --> URI Class Initialized
INFO - 2016-11-09 15:52:09 --> Router Class Initialized
INFO - 2016-11-09 15:52:09 --> Output Class Initialized
INFO - 2016-11-09 15:52:09 --> Security Class Initialized
DEBUG - 2016-11-09 15:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:52:09 --> Input Class Initialized
INFO - 2016-11-09 15:52:09 --> Language Class Initialized
INFO - 2016-11-09 15:52:09 --> Loader Class Initialized
INFO - 2016-11-09 15:52:09 --> Helper loaded: url_helper
INFO - 2016-11-09 15:52:09 --> Helper loaded: form_helper
INFO - 2016-11-09 15:52:09 --> Database Driver Class Initialized
INFO - 2016-11-09 15:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:52:09 --> Controller Class Initialized
INFO - 2016-11-09 15:52:09 --> Model Class Initialized
INFO - 2016-11-09 15:52:09 --> Form Validation Class Initialized
INFO - 2016-11-09 15:52:09 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-09 15:52:09 --> Severity: Notice --> Undefined variable: start C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 78
ERROR - 2016-11-09 15:52:09 --> Severity: Notice --> Undefined variable: end C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 79
INFO - 2016-11-09 15:52:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:52:09 --> Final output sent to browser
DEBUG - 2016-11-09 15:52:09 --> Total execution time: 0.7777
INFO - 2016-11-09 15:53:26 --> Config Class Initialized
INFO - 2016-11-09 15:53:26 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:53:26 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:53:26 --> Utf8 Class Initialized
INFO - 2016-11-09 15:53:26 --> URI Class Initialized
INFO - 2016-11-09 15:53:26 --> Router Class Initialized
INFO - 2016-11-09 15:53:26 --> Output Class Initialized
INFO - 2016-11-09 15:53:26 --> Security Class Initialized
DEBUG - 2016-11-09 15:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:53:26 --> Input Class Initialized
INFO - 2016-11-09 15:53:26 --> Language Class Initialized
INFO - 2016-11-09 15:53:26 --> Loader Class Initialized
INFO - 2016-11-09 15:53:26 --> Helper loaded: url_helper
INFO - 2016-11-09 15:53:26 --> Helper loaded: form_helper
INFO - 2016-11-09 15:53:26 --> Database Driver Class Initialized
INFO - 2016-11-09 15:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:53:26 --> Controller Class Initialized
INFO - 2016-11-09 15:53:26 --> Model Class Initialized
INFO - 2016-11-09 15:53:26 --> Form Validation Class Initialized
INFO - 2016-11-09 15:53:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 15:53:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:53:26 --> Final output sent to browser
DEBUG - 2016-11-09 15:53:26 --> Total execution time: 0.3610
INFO - 2016-11-09 15:53:28 --> Config Class Initialized
INFO - 2016-11-09 15:53:28 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:53:28 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:53:28 --> Utf8 Class Initialized
INFO - 2016-11-09 15:53:28 --> URI Class Initialized
DEBUG - 2016-11-09 15:53:28 --> No URI present. Default controller set.
INFO - 2016-11-09 15:53:28 --> Router Class Initialized
INFO - 2016-11-09 15:53:28 --> Output Class Initialized
INFO - 2016-11-09 15:53:28 --> Security Class Initialized
DEBUG - 2016-11-09 15:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:53:28 --> Input Class Initialized
INFO - 2016-11-09 15:53:28 --> Language Class Initialized
INFO - 2016-11-09 15:53:28 --> Loader Class Initialized
INFO - 2016-11-09 15:53:28 --> Helper loaded: url_helper
INFO - 2016-11-09 15:53:28 --> Helper loaded: form_helper
INFO - 2016-11-09 15:53:28 --> Database Driver Class Initialized
INFO - 2016-11-09 15:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:53:28 --> Controller Class Initialized
INFO - 2016-11-09 15:53:28 --> Model Class Initialized
INFO - 2016-11-09 15:53:28 --> Model Class Initialized
INFO - 2016-11-09 15:53:28 --> Model Class Initialized
INFO - 2016-11-09 15:53:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:53:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:53:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:53:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:53:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:53:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:53:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:53:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:53:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:53:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:53:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:53:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:53:29 --> Final output sent to browser
DEBUG - 2016-11-09 15:53:29 --> Total execution time: 0.4218
INFO - 2016-11-09 15:54:54 --> Config Class Initialized
INFO - 2016-11-09 15:54:54 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:54:54 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:54:54 --> Utf8 Class Initialized
INFO - 2016-11-09 15:54:54 --> URI Class Initialized
INFO - 2016-11-09 15:54:54 --> Router Class Initialized
INFO - 2016-11-09 15:54:54 --> Output Class Initialized
INFO - 2016-11-09 15:54:54 --> Security Class Initialized
DEBUG - 2016-11-09 15:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:54:54 --> Input Class Initialized
INFO - 2016-11-09 15:54:54 --> Language Class Initialized
INFO - 2016-11-09 15:54:54 --> Loader Class Initialized
INFO - 2016-11-09 15:54:54 --> Helper loaded: url_helper
INFO - 2016-11-09 15:54:55 --> Helper loaded: form_helper
INFO - 2016-11-09 15:54:55 --> Database Driver Class Initialized
INFO - 2016-11-09 15:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:54:55 --> Controller Class Initialized
INFO - 2016-11-09 15:54:55 --> Model Class Initialized
INFO - 2016-11-09 15:54:55 --> Form Validation Class Initialized
INFO - 2016-11-09 15:54:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 15:54:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:54:55 --> Final output sent to browser
DEBUG - 2016-11-09 15:54:55 --> Total execution time: 0.6976
INFO - 2016-11-09 15:54:56 --> Config Class Initialized
INFO - 2016-11-09 15:54:56 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:54:56 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:54:56 --> Utf8 Class Initialized
INFO - 2016-11-09 15:54:56 --> URI Class Initialized
DEBUG - 2016-11-09 15:54:56 --> No URI present. Default controller set.
INFO - 2016-11-09 15:54:56 --> Router Class Initialized
INFO - 2016-11-09 15:54:56 --> Output Class Initialized
INFO - 2016-11-09 15:54:56 --> Security Class Initialized
DEBUG - 2016-11-09 15:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:54:56 --> Input Class Initialized
INFO - 2016-11-09 15:54:56 --> Language Class Initialized
INFO - 2016-11-09 15:54:56 --> Loader Class Initialized
INFO - 2016-11-09 15:54:56 --> Helper loaded: url_helper
INFO - 2016-11-09 15:54:56 --> Helper loaded: form_helper
INFO - 2016-11-09 15:54:56 --> Database Driver Class Initialized
INFO - 2016-11-09 15:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:54:56 --> Controller Class Initialized
INFO - 2016-11-09 15:54:56 --> Model Class Initialized
INFO - 2016-11-09 15:54:56 --> Model Class Initialized
INFO - 2016-11-09 15:54:56 --> Model Class Initialized
INFO - 2016-11-09 15:54:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:54:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:54:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:54:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:54:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:54:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:54:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:54:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:54:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:54:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:54:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:54:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:54:56 --> Final output sent to browser
DEBUG - 2016-11-09 15:54:56 --> Total execution time: 0.4307
INFO - 2016-11-09 15:55:16 --> Config Class Initialized
INFO - 2016-11-09 15:55:16 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:55:16 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:55:16 --> Utf8 Class Initialized
INFO - 2016-11-09 15:55:16 --> URI Class Initialized
DEBUG - 2016-11-09 15:55:16 --> No URI present. Default controller set.
INFO - 2016-11-09 15:55:16 --> Router Class Initialized
INFO - 2016-11-09 15:55:16 --> Output Class Initialized
INFO - 2016-11-09 15:55:16 --> Security Class Initialized
DEBUG - 2016-11-09 15:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:55:16 --> Input Class Initialized
INFO - 2016-11-09 15:55:16 --> Language Class Initialized
INFO - 2016-11-09 15:55:16 --> Loader Class Initialized
INFO - 2016-11-09 15:55:16 --> Helper loaded: url_helper
INFO - 2016-11-09 15:55:16 --> Helper loaded: form_helper
INFO - 2016-11-09 15:55:16 --> Database Driver Class Initialized
INFO - 2016-11-09 15:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:55:16 --> Controller Class Initialized
INFO - 2016-11-09 15:55:16 --> Model Class Initialized
INFO - 2016-11-09 15:55:16 --> Model Class Initialized
INFO - 2016-11-09 15:55:16 --> Model Class Initialized
INFO - 2016-11-09 15:55:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:55:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:55:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:55:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:55:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:55:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:55:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:55:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:55:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:55:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:55:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:55:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:55:16 --> Final output sent to browser
DEBUG - 2016-11-09 15:55:16 --> Total execution time: 0.3964
INFO - 2016-11-09 15:57:13 --> Config Class Initialized
INFO - 2016-11-09 15:57:13 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:57:13 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:57:13 --> Utf8 Class Initialized
INFO - 2016-11-09 15:57:13 --> URI Class Initialized
DEBUG - 2016-11-09 15:57:13 --> No URI present. Default controller set.
INFO - 2016-11-09 15:57:13 --> Router Class Initialized
INFO - 2016-11-09 15:57:13 --> Output Class Initialized
INFO - 2016-11-09 15:57:13 --> Security Class Initialized
DEBUG - 2016-11-09 15:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:57:13 --> Input Class Initialized
INFO - 2016-11-09 15:57:14 --> Language Class Initialized
INFO - 2016-11-09 15:57:14 --> Loader Class Initialized
INFO - 2016-11-09 15:57:14 --> Helper loaded: url_helper
INFO - 2016-11-09 15:57:14 --> Helper loaded: form_helper
INFO - 2016-11-09 15:57:14 --> Database Driver Class Initialized
INFO - 2016-11-09 15:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:57:14 --> Controller Class Initialized
INFO - 2016-11-09 15:57:14 --> Model Class Initialized
INFO - 2016-11-09 15:57:14 --> Model Class Initialized
INFO - 2016-11-09 15:57:14 --> Model Class Initialized
INFO - 2016-11-09 15:57:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:57:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:57:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:57:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:57:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:57:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:57:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:57:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:57:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:57:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:57:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:57:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:57:14 --> Final output sent to browser
DEBUG - 2016-11-09 15:57:14 --> Total execution time: 0.3794
INFO - 2016-11-09 15:57:31 --> Config Class Initialized
INFO - 2016-11-09 15:57:31 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:57:31 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:57:31 --> Utf8 Class Initialized
INFO - 2016-11-09 15:57:31 --> URI Class Initialized
INFO - 2016-11-09 15:57:31 --> Router Class Initialized
INFO - 2016-11-09 15:57:31 --> Output Class Initialized
INFO - 2016-11-09 15:57:31 --> Security Class Initialized
DEBUG - 2016-11-09 15:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:57:31 --> Input Class Initialized
INFO - 2016-11-09 15:57:31 --> Language Class Initialized
INFO - 2016-11-09 15:57:31 --> Loader Class Initialized
INFO - 2016-11-09 15:57:31 --> Helper loaded: url_helper
INFO - 2016-11-09 15:57:31 --> Helper loaded: form_helper
INFO - 2016-11-09 15:57:31 --> Database Driver Class Initialized
INFO - 2016-11-09 15:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:57:31 --> Controller Class Initialized
INFO - 2016-11-09 15:57:31 --> Model Class Initialized
INFO - 2016-11-09 15:57:31 --> Form Validation Class Initialized
INFO - 2016-11-09 15:57:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 15:57:31 --> Final output sent to browser
DEBUG - 2016-11-09 15:57:31 --> Total execution time: 0.4020
INFO - 2016-11-09 15:57:37 --> Config Class Initialized
INFO - 2016-11-09 15:57:37 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:57:37 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:57:37 --> Utf8 Class Initialized
INFO - 2016-11-09 15:57:37 --> URI Class Initialized
DEBUG - 2016-11-09 15:57:37 --> No URI present. Default controller set.
INFO - 2016-11-09 15:57:37 --> Router Class Initialized
INFO - 2016-11-09 15:57:37 --> Output Class Initialized
INFO - 2016-11-09 15:57:37 --> Security Class Initialized
DEBUG - 2016-11-09 15:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:57:37 --> Input Class Initialized
INFO - 2016-11-09 15:57:37 --> Language Class Initialized
INFO - 2016-11-09 15:57:37 --> Loader Class Initialized
INFO - 2016-11-09 15:57:37 --> Helper loaded: url_helper
INFO - 2016-11-09 15:57:37 --> Helper loaded: form_helper
INFO - 2016-11-09 15:57:38 --> Database Driver Class Initialized
INFO - 2016-11-09 15:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:57:38 --> Controller Class Initialized
INFO - 2016-11-09 15:57:38 --> Model Class Initialized
INFO - 2016-11-09 15:57:38 --> Model Class Initialized
INFO - 2016-11-09 15:57:38 --> Model Class Initialized
INFO - 2016-11-09 15:57:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:57:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:57:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:57:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:57:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:57:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:57:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:57:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:57:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:57:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:57:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:57:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:57:38 --> Final output sent to browser
DEBUG - 2016-11-09 15:57:38 --> Total execution time: 0.3912
INFO - 2016-11-09 15:58:22 --> Config Class Initialized
INFO - 2016-11-09 15:58:22 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:58:22 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:58:22 --> Utf8 Class Initialized
INFO - 2016-11-09 15:58:22 --> URI Class Initialized
INFO - 2016-11-09 15:58:22 --> Router Class Initialized
INFO - 2016-11-09 15:58:22 --> Output Class Initialized
INFO - 2016-11-09 15:58:22 --> Security Class Initialized
DEBUG - 2016-11-09 15:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:58:22 --> Input Class Initialized
INFO - 2016-11-09 15:58:22 --> Language Class Initialized
INFO - 2016-11-09 15:58:22 --> Loader Class Initialized
INFO - 2016-11-09 15:58:22 --> Helper loaded: url_helper
INFO - 2016-11-09 15:58:22 --> Helper loaded: form_helper
INFO - 2016-11-09 15:58:22 --> Database Driver Class Initialized
INFO - 2016-11-09 15:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:58:22 --> Controller Class Initialized
INFO - 2016-11-09 15:58:22 --> Model Class Initialized
INFO - 2016-11-09 15:58:22 --> Form Validation Class Initialized
INFO - 2016-11-09 15:58:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 15:58:22 --> Final output sent to browser
DEBUG - 2016-11-09 15:58:22 --> Total execution time: 0.2430
INFO - 2016-11-09 15:58:24 --> Config Class Initialized
INFO - 2016-11-09 15:58:24 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:58:24 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:58:24 --> Utf8 Class Initialized
INFO - 2016-11-09 15:58:24 --> URI Class Initialized
DEBUG - 2016-11-09 15:58:24 --> No URI present. Default controller set.
INFO - 2016-11-09 15:58:24 --> Router Class Initialized
INFO - 2016-11-09 15:58:24 --> Output Class Initialized
INFO - 2016-11-09 15:58:25 --> Security Class Initialized
DEBUG - 2016-11-09 15:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:58:25 --> Input Class Initialized
INFO - 2016-11-09 15:58:25 --> Language Class Initialized
INFO - 2016-11-09 15:58:25 --> Loader Class Initialized
INFO - 2016-11-09 15:58:25 --> Helper loaded: url_helper
INFO - 2016-11-09 15:58:25 --> Helper loaded: form_helper
INFO - 2016-11-09 15:58:25 --> Database Driver Class Initialized
INFO - 2016-11-09 15:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:58:25 --> Controller Class Initialized
INFO - 2016-11-09 15:58:25 --> Model Class Initialized
INFO - 2016-11-09 15:58:25 --> Model Class Initialized
INFO - 2016-11-09 15:58:25 --> Model Class Initialized
INFO - 2016-11-09 15:58:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:58:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:58:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:58:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:58:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:58:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:58:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:58:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:58:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:58:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:58:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:58:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:58:25 --> Final output sent to browser
DEBUG - 2016-11-09 15:58:25 --> Total execution time: 0.4111
INFO - 2016-11-09 15:58:33 --> Config Class Initialized
INFO - 2016-11-09 15:58:33 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:58:34 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:58:34 --> Utf8 Class Initialized
INFO - 2016-11-09 15:58:34 --> URI Class Initialized
INFO - 2016-11-09 15:58:34 --> Router Class Initialized
INFO - 2016-11-09 15:58:34 --> Output Class Initialized
INFO - 2016-11-09 15:58:34 --> Security Class Initialized
DEBUG - 2016-11-09 15:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:58:34 --> Input Class Initialized
INFO - 2016-11-09 15:58:34 --> Language Class Initialized
INFO - 2016-11-09 15:58:34 --> Loader Class Initialized
INFO - 2016-11-09 15:58:34 --> Helper loaded: url_helper
INFO - 2016-11-09 15:58:34 --> Helper loaded: form_helper
INFO - 2016-11-09 15:58:34 --> Database Driver Class Initialized
INFO - 2016-11-09 15:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:58:34 --> Controller Class Initialized
INFO - 2016-11-09 15:58:34 --> Model Class Initialized
INFO - 2016-11-09 15:58:34 --> Form Validation Class Initialized
INFO - 2016-11-09 15:58:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 15:58:34 --> Final output sent to browser
DEBUG - 2016-11-09 15:58:34 --> Total execution time: 0.7066
INFO - 2016-11-09 15:58:36 --> Config Class Initialized
INFO - 2016-11-09 15:58:36 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:58:36 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:58:36 --> Utf8 Class Initialized
INFO - 2016-11-09 15:58:36 --> URI Class Initialized
DEBUG - 2016-11-09 15:58:36 --> No URI present. Default controller set.
INFO - 2016-11-09 15:58:36 --> Router Class Initialized
INFO - 2016-11-09 15:58:36 --> Output Class Initialized
INFO - 2016-11-09 15:58:36 --> Security Class Initialized
DEBUG - 2016-11-09 15:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:58:36 --> Input Class Initialized
INFO - 2016-11-09 15:58:36 --> Language Class Initialized
INFO - 2016-11-09 15:58:36 --> Loader Class Initialized
INFO - 2016-11-09 15:58:36 --> Helper loaded: url_helper
INFO - 2016-11-09 15:58:36 --> Helper loaded: form_helper
INFO - 2016-11-09 15:58:36 --> Database Driver Class Initialized
INFO - 2016-11-09 15:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:58:36 --> Controller Class Initialized
INFO - 2016-11-09 15:58:36 --> Model Class Initialized
INFO - 2016-11-09 15:58:36 --> Model Class Initialized
INFO - 2016-11-09 15:58:36 --> Model Class Initialized
INFO - 2016-11-09 15:58:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:58:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:58:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:58:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:58:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:58:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:58:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:58:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:58:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:58:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:58:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:58:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:58:36 --> Final output sent to browser
DEBUG - 2016-11-09 15:58:36 --> Total execution time: 0.4539
INFO - 2016-11-09 15:59:00 --> Config Class Initialized
INFO - 2016-11-09 15:59:00 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:59:00 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:59:00 --> Utf8 Class Initialized
INFO - 2016-11-09 15:59:00 --> URI Class Initialized
INFO - 2016-11-09 15:59:00 --> Router Class Initialized
INFO - 2016-11-09 15:59:00 --> Output Class Initialized
INFO - 2016-11-09 15:59:00 --> Security Class Initialized
DEBUG - 2016-11-09 15:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:59:00 --> Input Class Initialized
INFO - 2016-11-09 15:59:00 --> Language Class Initialized
ERROR - 2016-11-09 15:59:00 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 37
INFO - 2016-11-09 15:59:01 --> Config Class Initialized
INFO - 2016-11-09 15:59:01 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:59:02 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:59:02 --> Utf8 Class Initialized
INFO - 2016-11-09 15:59:02 --> URI Class Initialized
DEBUG - 2016-11-09 15:59:02 --> No URI present. Default controller set.
INFO - 2016-11-09 15:59:02 --> Router Class Initialized
INFO - 2016-11-09 15:59:02 --> Output Class Initialized
INFO - 2016-11-09 15:59:02 --> Security Class Initialized
DEBUG - 2016-11-09 15:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:59:02 --> Input Class Initialized
INFO - 2016-11-09 15:59:02 --> Language Class Initialized
INFO - 2016-11-09 15:59:02 --> Loader Class Initialized
INFO - 2016-11-09 15:59:02 --> Helper loaded: url_helper
INFO - 2016-11-09 15:59:02 --> Helper loaded: form_helper
INFO - 2016-11-09 15:59:02 --> Database Driver Class Initialized
INFO - 2016-11-09 15:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:59:02 --> Controller Class Initialized
INFO - 2016-11-09 15:59:02 --> Model Class Initialized
INFO - 2016-11-09 15:59:02 --> Model Class Initialized
INFO - 2016-11-09 15:59:02 --> Model Class Initialized
INFO - 2016-11-09 15:59:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:59:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:59:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:59:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:59:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:59:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:59:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:59:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:59:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:59:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:59:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:59:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:59:02 --> Final output sent to browser
DEBUG - 2016-11-09 15:59:02 --> Total execution time: 0.4538
INFO - 2016-11-09 15:59:12 --> Config Class Initialized
INFO - 2016-11-09 15:59:12 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:59:12 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:59:12 --> Utf8 Class Initialized
INFO - 2016-11-09 15:59:12 --> URI Class Initialized
INFO - 2016-11-09 15:59:12 --> Router Class Initialized
INFO - 2016-11-09 15:59:12 --> Output Class Initialized
INFO - 2016-11-09 15:59:12 --> Security Class Initialized
DEBUG - 2016-11-09 15:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:59:12 --> Input Class Initialized
INFO - 2016-11-09 15:59:12 --> Language Class Initialized
INFO - 2016-11-09 15:59:12 --> Loader Class Initialized
INFO - 2016-11-09 15:59:12 --> Helper loaded: url_helper
INFO - 2016-11-09 15:59:12 --> Helper loaded: form_helper
INFO - 2016-11-09 15:59:12 --> Database Driver Class Initialized
INFO - 2016-11-09 15:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:59:12 --> Controller Class Initialized
INFO - 2016-11-09 15:59:13 --> Model Class Initialized
INFO - 2016-11-09 15:59:13 --> Form Validation Class Initialized
INFO - 2016-11-09 15:59:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 15:59:13 --> Final output sent to browser
DEBUG - 2016-11-09 15:59:13 --> Total execution time: 0.2386
INFO - 2016-11-09 15:59:15 --> Config Class Initialized
INFO - 2016-11-09 15:59:15 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:59:15 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:59:15 --> Utf8 Class Initialized
INFO - 2016-11-09 15:59:15 --> URI Class Initialized
DEBUG - 2016-11-09 15:59:15 --> No URI present. Default controller set.
INFO - 2016-11-09 15:59:15 --> Router Class Initialized
INFO - 2016-11-09 15:59:15 --> Output Class Initialized
INFO - 2016-11-09 15:59:15 --> Security Class Initialized
DEBUG - 2016-11-09 15:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:59:15 --> Input Class Initialized
INFO - 2016-11-09 15:59:15 --> Language Class Initialized
INFO - 2016-11-09 15:59:15 --> Loader Class Initialized
INFO - 2016-11-09 15:59:15 --> Helper loaded: url_helper
INFO - 2016-11-09 15:59:15 --> Helper loaded: form_helper
INFO - 2016-11-09 15:59:15 --> Database Driver Class Initialized
INFO - 2016-11-09 15:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:59:15 --> Controller Class Initialized
INFO - 2016-11-09 15:59:15 --> Model Class Initialized
INFO - 2016-11-09 15:59:15 --> Model Class Initialized
INFO - 2016-11-09 15:59:15 --> Model Class Initialized
INFO - 2016-11-09 15:59:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:59:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:59:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:59:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:59:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:59:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:59:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:59:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:59:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:59:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:59:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:59:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:59:15 --> Final output sent to browser
DEBUG - 2016-11-09 15:59:15 --> Total execution time: 0.4163
INFO - 2016-11-09 15:59:27 --> Config Class Initialized
INFO - 2016-11-09 15:59:27 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:59:27 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:59:27 --> Utf8 Class Initialized
INFO - 2016-11-09 15:59:27 --> URI Class Initialized
INFO - 2016-11-09 15:59:27 --> Router Class Initialized
INFO - 2016-11-09 15:59:27 --> Output Class Initialized
INFO - 2016-11-09 15:59:27 --> Security Class Initialized
DEBUG - 2016-11-09 15:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:59:27 --> Input Class Initialized
INFO - 2016-11-09 15:59:27 --> Language Class Initialized
INFO - 2016-11-09 15:59:27 --> Loader Class Initialized
INFO - 2016-11-09 15:59:27 --> Helper loaded: url_helper
INFO - 2016-11-09 15:59:27 --> Helper loaded: form_helper
INFO - 2016-11-09 15:59:27 --> Database Driver Class Initialized
INFO - 2016-11-09 15:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:59:27 --> Controller Class Initialized
INFO - 2016-11-09 15:59:27 --> Model Class Initialized
INFO - 2016-11-09 15:59:27 --> Form Validation Class Initialized
INFO - 2016-11-09 15:59:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 15:59:27 --> Final output sent to browser
DEBUG - 2016-11-09 15:59:27 --> Total execution time: 0.2661
INFO - 2016-11-09 15:59:30 --> Config Class Initialized
INFO - 2016-11-09 15:59:30 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:59:30 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:59:30 --> Utf8 Class Initialized
INFO - 2016-11-09 15:59:30 --> URI Class Initialized
DEBUG - 2016-11-09 15:59:30 --> No URI present. Default controller set.
INFO - 2016-11-09 15:59:30 --> Router Class Initialized
INFO - 2016-11-09 15:59:30 --> Output Class Initialized
INFO - 2016-11-09 15:59:30 --> Security Class Initialized
DEBUG - 2016-11-09 15:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:59:30 --> Input Class Initialized
INFO - 2016-11-09 15:59:30 --> Language Class Initialized
INFO - 2016-11-09 15:59:30 --> Loader Class Initialized
INFO - 2016-11-09 15:59:30 --> Helper loaded: url_helper
INFO - 2016-11-09 15:59:30 --> Helper loaded: form_helper
INFO - 2016-11-09 15:59:30 --> Database Driver Class Initialized
INFO - 2016-11-09 15:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:59:30 --> Controller Class Initialized
INFO - 2016-11-09 15:59:30 --> Model Class Initialized
INFO - 2016-11-09 15:59:30 --> Model Class Initialized
INFO - 2016-11-09 15:59:30 --> Model Class Initialized
INFO - 2016-11-09 15:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:59:30 --> Final output sent to browser
DEBUG - 2016-11-09 15:59:30 --> Total execution time: 0.4189
INFO - 2016-11-09 15:59:38 --> Config Class Initialized
INFO - 2016-11-09 15:59:38 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:59:39 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:59:39 --> Utf8 Class Initialized
INFO - 2016-11-09 15:59:39 --> URI Class Initialized
INFO - 2016-11-09 15:59:39 --> Router Class Initialized
INFO - 2016-11-09 15:59:39 --> Output Class Initialized
INFO - 2016-11-09 15:59:39 --> Security Class Initialized
DEBUG - 2016-11-09 15:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:59:39 --> Input Class Initialized
INFO - 2016-11-09 15:59:39 --> Language Class Initialized
INFO - 2016-11-09 15:59:39 --> Loader Class Initialized
INFO - 2016-11-09 15:59:39 --> Helper loaded: url_helper
INFO - 2016-11-09 15:59:39 --> Helper loaded: form_helper
INFO - 2016-11-09 15:59:39 --> Database Driver Class Initialized
INFO - 2016-11-09 15:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:59:39 --> Controller Class Initialized
INFO - 2016-11-09 15:59:39 --> Model Class Initialized
INFO - 2016-11-09 15:59:39 --> Form Validation Class Initialized
INFO - 2016-11-09 15:59:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 15:59:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:59:39 --> Final output sent to browser
DEBUG - 2016-11-09 15:59:39 --> Total execution time: 0.7590
INFO - 2016-11-09 15:59:42 --> Config Class Initialized
INFO - 2016-11-09 15:59:42 --> Hooks Class Initialized
DEBUG - 2016-11-09 15:59:42 --> UTF-8 Support Enabled
INFO - 2016-11-09 15:59:42 --> Utf8 Class Initialized
INFO - 2016-11-09 15:59:42 --> URI Class Initialized
DEBUG - 2016-11-09 15:59:42 --> No URI present. Default controller set.
INFO - 2016-11-09 15:59:42 --> Router Class Initialized
INFO - 2016-11-09 15:59:42 --> Output Class Initialized
INFO - 2016-11-09 15:59:42 --> Security Class Initialized
DEBUG - 2016-11-09 15:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 15:59:42 --> Input Class Initialized
INFO - 2016-11-09 15:59:42 --> Language Class Initialized
INFO - 2016-11-09 15:59:42 --> Loader Class Initialized
INFO - 2016-11-09 15:59:42 --> Helper loaded: url_helper
INFO - 2016-11-09 15:59:42 --> Helper loaded: form_helper
INFO - 2016-11-09 15:59:42 --> Database Driver Class Initialized
INFO - 2016-11-09 15:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 15:59:42 --> Controller Class Initialized
INFO - 2016-11-09 15:59:42 --> Model Class Initialized
INFO - 2016-11-09 15:59:42 --> Model Class Initialized
INFO - 2016-11-09 15:59:42 --> Model Class Initialized
INFO - 2016-11-09 15:59:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 15:59:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 15:59:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 15:59:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 15:59:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 15:59:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 15:59:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 15:59:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 15:59:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 15:59:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 15:59:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 15:59:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 15:59:42 --> Final output sent to browser
DEBUG - 2016-11-09 15:59:42 --> Total execution time: 0.4044
INFO - 2016-11-09 16:02:09 --> Config Class Initialized
INFO - 2016-11-09 16:02:09 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:02:09 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:02:09 --> Utf8 Class Initialized
INFO - 2016-11-09 16:02:09 --> URI Class Initialized
INFO - 2016-11-09 16:02:09 --> Router Class Initialized
INFO - 2016-11-09 16:02:09 --> Output Class Initialized
INFO - 2016-11-09 16:02:09 --> Security Class Initialized
DEBUG - 2016-11-09 16:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:02:09 --> Input Class Initialized
INFO - 2016-11-09 16:02:09 --> Language Class Initialized
INFO - 2016-11-09 16:02:09 --> Loader Class Initialized
INFO - 2016-11-09 16:02:09 --> Helper loaded: url_helper
INFO - 2016-11-09 16:02:09 --> Helper loaded: form_helper
INFO - 2016-11-09 16:02:09 --> Database Driver Class Initialized
INFO - 2016-11-09 16:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:02:09 --> Controller Class Initialized
INFO - 2016-11-09 16:02:09 --> Model Class Initialized
INFO - 2016-11-09 16:02:09 --> Form Validation Class Initialized
INFO - 2016-11-09 16:02:09 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-09 16:02:09 --> Severity: Notice --> Undefined variable: startDate C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 78
ERROR - 2016-11-09 16:02:09 --> Severity: Notice --> Undefined variable: endDate C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 79
INFO - 2016-11-09 16:02:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:02:09 --> Final output sent to browser
DEBUG - 2016-11-09 16:02:09 --> Total execution time: 0.4315
INFO - 2016-11-09 16:02:13 --> Config Class Initialized
INFO - 2016-11-09 16:02:13 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:02:13 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:02:13 --> Utf8 Class Initialized
INFO - 2016-11-09 16:02:13 --> URI Class Initialized
DEBUG - 2016-11-09 16:02:13 --> No URI present. Default controller set.
INFO - 2016-11-09 16:02:13 --> Router Class Initialized
INFO - 2016-11-09 16:02:13 --> Output Class Initialized
INFO - 2016-11-09 16:02:13 --> Security Class Initialized
DEBUG - 2016-11-09 16:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:02:13 --> Input Class Initialized
INFO - 2016-11-09 16:02:13 --> Language Class Initialized
INFO - 2016-11-09 16:02:13 --> Loader Class Initialized
INFO - 2016-11-09 16:02:13 --> Helper loaded: url_helper
INFO - 2016-11-09 16:02:13 --> Helper loaded: form_helper
INFO - 2016-11-09 16:02:13 --> Database Driver Class Initialized
INFO - 2016-11-09 16:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:02:14 --> Controller Class Initialized
INFO - 2016-11-09 16:02:14 --> Model Class Initialized
INFO - 2016-11-09 16:02:14 --> Model Class Initialized
INFO - 2016-11-09 16:02:14 --> Model Class Initialized
INFO - 2016-11-09 16:02:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:02:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:02:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:02:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:02:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:02:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:02:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:02:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:02:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:02:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:02:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:02:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:02:14 --> Final output sent to browser
DEBUG - 2016-11-09 16:02:14 --> Total execution time: 0.4080
INFO - 2016-11-09 16:04:50 --> Config Class Initialized
INFO - 2016-11-09 16:04:50 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:04:51 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:04:51 --> Utf8 Class Initialized
INFO - 2016-11-09 16:04:51 --> URI Class Initialized
INFO - 2016-11-09 16:04:51 --> Router Class Initialized
INFO - 2016-11-09 16:04:51 --> Output Class Initialized
INFO - 2016-11-09 16:04:51 --> Security Class Initialized
DEBUG - 2016-11-09 16:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:04:51 --> Input Class Initialized
INFO - 2016-11-09 16:04:51 --> Language Class Initialized
INFO - 2016-11-09 16:04:51 --> Loader Class Initialized
INFO - 2016-11-09 16:04:51 --> Helper loaded: url_helper
INFO - 2016-11-09 16:04:51 --> Helper loaded: form_helper
INFO - 2016-11-09 16:04:51 --> Database Driver Class Initialized
INFO - 2016-11-09 16:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:04:51 --> Controller Class Initialized
INFO - 2016-11-09 16:04:51 --> Model Class Initialized
INFO - 2016-11-09 16:04:51 --> Form Validation Class Initialized
INFO - 2016-11-09 16:04:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 16:04:51 --> Final output sent to browser
DEBUG - 2016-11-09 16:04:51 --> Total execution time: 0.3861
INFO - 2016-11-09 16:05:05 --> Config Class Initialized
INFO - 2016-11-09 16:05:05 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:05:05 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:05:05 --> Utf8 Class Initialized
INFO - 2016-11-09 16:05:05 --> URI Class Initialized
DEBUG - 2016-11-09 16:05:05 --> No URI present. Default controller set.
INFO - 2016-11-09 16:05:05 --> Router Class Initialized
INFO - 2016-11-09 16:05:05 --> Output Class Initialized
INFO - 2016-11-09 16:05:05 --> Security Class Initialized
DEBUG - 2016-11-09 16:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:05:05 --> Input Class Initialized
INFO - 2016-11-09 16:05:05 --> Language Class Initialized
INFO - 2016-11-09 16:05:05 --> Loader Class Initialized
INFO - 2016-11-09 16:05:05 --> Helper loaded: url_helper
INFO - 2016-11-09 16:05:05 --> Helper loaded: form_helper
INFO - 2016-11-09 16:05:05 --> Database Driver Class Initialized
INFO - 2016-11-09 16:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:05:05 --> Controller Class Initialized
INFO - 2016-11-09 16:05:05 --> Model Class Initialized
INFO - 2016-11-09 16:05:05 --> Model Class Initialized
INFO - 2016-11-09 16:05:05 --> Model Class Initialized
INFO - 2016-11-09 16:05:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:05:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:05:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:05:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:05:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:05:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:05:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:05:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:05:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:05:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:05:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:05:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:05:05 --> Final output sent to browser
DEBUG - 2016-11-09 16:05:06 --> Total execution time: 0.4060
INFO - 2016-11-09 16:05:16 --> Config Class Initialized
INFO - 2016-11-09 16:05:16 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:05:16 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:05:16 --> Utf8 Class Initialized
INFO - 2016-11-09 16:05:16 --> URI Class Initialized
INFO - 2016-11-09 16:05:16 --> Router Class Initialized
INFO - 2016-11-09 16:05:16 --> Output Class Initialized
INFO - 2016-11-09 16:05:16 --> Security Class Initialized
DEBUG - 2016-11-09 16:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:05:16 --> Input Class Initialized
INFO - 2016-11-09 16:05:16 --> Language Class Initialized
INFO - 2016-11-09 16:05:16 --> Loader Class Initialized
INFO - 2016-11-09 16:05:16 --> Helper loaded: url_helper
INFO - 2016-11-09 16:05:16 --> Helper loaded: form_helper
INFO - 2016-11-09 16:05:16 --> Database Driver Class Initialized
INFO - 2016-11-09 16:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:05:16 --> Controller Class Initialized
INFO - 2016-11-09 16:05:16 --> Model Class Initialized
INFO - 2016-11-09 16:05:16 --> Form Validation Class Initialized
INFO - 2016-11-09 16:05:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 16:05:16 --> Final output sent to browser
DEBUG - 2016-11-09 16:05:16 --> Total execution time: 0.2585
INFO - 2016-11-09 16:05:34 --> Config Class Initialized
INFO - 2016-11-09 16:05:34 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:05:34 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:05:34 --> Utf8 Class Initialized
INFO - 2016-11-09 16:05:34 --> URI Class Initialized
DEBUG - 2016-11-09 16:05:34 --> No URI present. Default controller set.
INFO - 2016-11-09 16:05:34 --> Router Class Initialized
INFO - 2016-11-09 16:05:34 --> Output Class Initialized
INFO - 2016-11-09 16:05:34 --> Security Class Initialized
DEBUG - 2016-11-09 16:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:05:34 --> Input Class Initialized
INFO - 2016-11-09 16:05:34 --> Language Class Initialized
INFO - 2016-11-09 16:05:34 --> Loader Class Initialized
INFO - 2016-11-09 16:05:34 --> Helper loaded: url_helper
INFO - 2016-11-09 16:05:34 --> Helper loaded: form_helper
INFO - 2016-11-09 16:05:34 --> Database Driver Class Initialized
INFO - 2016-11-09 16:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:05:34 --> Controller Class Initialized
INFO - 2016-11-09 16:05:34 --> Model Class Initialized
INFO - 2016-11-09 16:05:34 --> Model Class Initialized
INFO - 2016-11-09 16:05:34 --> Model Class Initialized
INFO - 2016-11-09 16:05:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:05:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:05:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:05:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:05:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:05:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:05:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:05:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:05:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:05:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:05:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:05:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:05:35 --> Final output sent to browser
DEBUG - 2016-11-09 16:05:35 --> Total execution time: 0.4174
INFO - 2016-11-09 16:10:10 --> Config Class Initialized
INFO - 2016-11-09 16:10:10 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:10:10 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:10:10 --> Utf8 Class Initialized
INFO - 2016-11-09 16:10:10 --> URI Class Initialized
DEBUG - 2016-11-09 16:10:10 --> No URI present. Default controller set.
INFO - 2016-11-09 16:10:10 --> Router Class Initialized
INFO - 2016-11-09 16:10:10 --> Output Class Initialized
INFO - 2016-11-09 16:10:10 --> Security Class Initialized
DEBUG - 2016-11-09 16:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:10:10 --> Input Class Initialized
INFO - 2016-11-09 16:10:10 --> Language Class Initialized
INFO - 2016-11-09 16:10:10 --> Loader Class Initialized
INFO - 2016-11-09 16:10:10 --> Helper loaded: url_helper
INFO - 2016-11-09 16:10:10 --> Helper loaded: form_helper
INFO - 2016-11-09 16:10:11 --> Database Driver Class Initialized
INFO - 2016-11-09 16:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:10:11 --> Controller Class Initialized
INFO - 2016-11-09 16:10:11 --> Model Class Initialized
INFO - 2016-11-09 16:10:11 --> Model Class Initialized
INFO - 2016-11-09 16:10:11 --> Model Class Initialized
INFO - 2016-11-09 16:10:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:10:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:10:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:10:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:10:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:10:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:10:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:10:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:10:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:10:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:10:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:10:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:10:11 --> Final output sent to browser
DEBUG - 2016-11-09 16:10:11 --> Total execution time: 0.4470
INFO - 2016-11-09 16:10:13 --> Config Class Initialized
INFO - 2016-11-09 16:10:13 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:10:13 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:10:13 --> Utf8 Class Initialized
INFO - 2016-11-09 16:10:13 --> URI Class Initialized
INFO - 2016-11-09 16:10:13 --> Router Class Initialized
INFO - 2016-11-09 16:10:13 --> Output Class Initialized
INFO - 2016-11-09 16:10:13 --> Security Class Initialized
DEBUG - 2016-11-09 16:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:10:13 --> Input Class Initialized
INFO - 2016-11-09 16:10:13 --> Language Class Initialized
INFO - 2016-11-09 16:10:13 --> Loader Class Initialized
INFO - 2016-11-09 16:10:13 --> Helper loaded: url_helper
INFO - 2016-11-09 16:10:13 --> Helper loaded: form_helper
INFO - 2016-11-09 16:10:13 --> Database Driver Class Initialized
INFO - 2016-11-09 16:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:10:13 --> Controller Class Initialized
INFO - 2016-11-09 16:10:13 --> Model Class Initialized
INFO - 2016-11-09 16:10:13 --> Form Validation Class Initialized
INFO - 2016-11-09 16:10:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 16:10:14 --> Final output sent to browser
DEBUG - 2016-11-09 16:10:14 --> Total execution time: 0.2571
INFO - 2016-11-09 16:12:17 --> Config Class Initialized
INFO - 2016-11-09 16:12:17 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:12:17 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:12:17 --> Utf8 Class Initialized
INFO - 2016-11-09 16:12:17 --> URI Class Initialized
INFO - 2016-11-09 16:12:17 --> Router Class Initialized
INFO - 2016-11-09 16:12:17 --> Output Class Initialized
INFO - 2016-11-09 16:12:17 --> Security Class Initialized
DEBUG - 2016-11-09 16:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:12:17 --> Input Class Initialized
INFO - 2016-11-09 16:12:17 --> Language Class Initialized
INFO - 2016-11-09 16:12:17 --> Loader Class Initialized
INFO - 2016-11-09 16:12:17 --> Helper loaded: url_helper
INFO - 2016-11-09 16:12:17 --> Helper loaded: form_helper
INFO - 2016-11-09 16:12:18 --> Database Driver Class Initialized
INFO - 2016-11-09 16:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:12:18 --> Controller Class Initialized
INFO - 2016-11-09 16:12:18 --> Model Class Initialized
INFO - 2016-11-09 16:12:18 --> Form Validation Class Initialized
INFO - 2016-11-09 16:12:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 16:12:18 --> Final output sent to browser
DEBUG - 2016-11-09 16:12:18 --> Total execution time: 0.2550
INFO - 2016-11-09 16:12:19 --> Config Class Initialized
INFO - 2016-11-09 16:12:19 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:12:19 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:12:19 --> Utf8 Class Initialized
INFO - 2016-11-09 16:12:19 --> URI Class Initialized
DEBUG - 2016-11-09 16:12:19 --> No URI present. Default controller set.
INFO - 2016-11-09 16:12:20 --> Router Class Initialized
INFO - 2016-11-09 16:12:20 --> Output Class Initialized
INFO - 2016-11-09 16:12:20 --> Security Class Initialized
DEBUG - 2016-11-09 16:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:12:20 --> Input Class Initialized
INFO - 2016-11-09 16:12:20 --> Language Class Initialized
INFO - 2016-11-09 16:12:20 --> Loader Class Initialized
INFO - 2016-11-09 16:12:20 --> Helper loaded: url_helper
INFO - 2016-11-09 16:12:20 --> Helper loaded: form_helper
INFO - 2016-11-09 16:12:20 --> Database Driver Class Initialized
INFO - 2016-11-09 16:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:12:20 --> Controller Class Initialized
INFO - 2016-11-09 16:12:20 --> Model Class Initialized
INFO - 2016-11-09 16:12:20 --> Model Class Initialized
INFO - 2016-11-09 16:12:20 --> Model Class Initialized
INFO - 2016-11-09 16:12:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:12:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:12:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:12:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:12:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:12:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:12:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:12:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:12:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:12:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:12:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:12:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:12:20 --> Final output sent to browser
DEBUG - 2016-11-09 16:12:20 --> Total execution time: 0.4852
INFO - 2016-11-09 16:12:23 --> Config Class Initialized
INFO - 2016-11-09 16:12:23 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:12:23 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:12:23 --> Utf8 Class Initialized
INFO - 2016-11-09 16:12:23 --> URI Class Initialized
INFO - 2016-11-09 16:12:23 --> Router Class Initialized
INFO - 2016-11-09 16:12:23 --> Output Class Initialized
INFO - 2016-11-09 16:12:23 --> Security Class Initialized
DEBUG - 2016-11-09 16:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:12:23 --> Input Class Initialized
INFO - 2016-11-09 16:12:23 --> Language Class Initialized
INFO - 2016-11-09 16:12:23 --> Loader Class Initialized
INFO - 2016-11-09 16:12:23 --> Helper loaded: url_helper
INFO - 2016-11-09 16:12:23 --> Helper loaded: form_helper
INFO - 2016-11-09 16:12:23 --> Database Driver Class Initialized
INFO - 2016-11-09 16:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:12:23 --> Controller Class Initialized
INFO - 2016-11-09 16:12:23 --> Model Class Initialized
INFO - 2016-11-09 16:12:23 --> Form Validation Class Initialized
INFO - 2016-11-09 16:12:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 16:12:23 --> Final output sent to browser
DEBUG - 2016-11-09 16:12:23 --> Total execution time: 0.4671
INFO - 2016-11-09 16:12:47 --> Config Class Initialized
INFO - 2016-11-09 16:12:47 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:12:47 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:12:47 --> Utf8 Class Initialized
INFO - 2016-11-09 16:12:47 --> URI Class Initialized
INFO - 2016-11-09 16:12:47 --> Router Class Initialized
INFO - 2016-11-09 16:12:48 --> Output Class Initialized
INFO - 2016-11-09 16:12:48 --> Security Class Initialized
DEBUG - 2016-11-09 16:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:12:48 --> Input Class Initialized
INFO - 2016-11-09 16:12:48 --> Language Class Initialized
INFO - 2016-11-09 16:12:48 --> Loader Class Initialized
INFO - 2016-11-09 16:12:48 --> Helper loaded: url_helper
INFO - 2016-11-09 16:12:48 --> Helper loaded: form_helper
INFO - 2016-11-09 16:12:48 --> Database Driver Class Initialized
INFO - 2016-11-09 16:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:12:48 --> Controller Class Initialized
INFO - 2016-11-09 16:12:48 --> Model Class Initialized
INFO - 2016-11-09 16:12:48 --> Form Validation Class Initialized
INFO - 2016-11-09 16:12:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 16:12:48 --> Final output sent to browser
DEBUG - 2016-11-09 16:12:48 --> Total execution time: 0.2483
INFO - 2016-11-09 16:12:49 --> Config Class Initialized
INFO - 2016-11-09 16:12:49 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:12:49 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:12:50 --> Utf8 Class Initialized
INFO - 2016-11-09 16:12:50 --> URI Class Initialized
DEBUG - 2016-11-09 16:12:50 --> No URI present. Default controller set.
INFO - 2016-11-09 16:12:50 --> Router Class Initialized
INFO - 2016-11-09 16:12:50 --> Output Class Initialized
INFO - 2016-11-09 16:12:50 --> Security Class Initialized
DEBUG - 2016-11-09 16:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:12:50 --> Input Class Initialized
INFO - 2016-11-09 16:12:50 --> Language Class Initialized
INFO - 2016-11-09 16:12:50 --> Loader Class Initialized
INFO - 2016-11-09 16:12:50 --> Helper loaded: url_helper
INFO - 2016-11-09 16:12:50 --> Helper loaded: form_helper
INFO - 2016-11-09 16:12:50 --> Database Driver Class Initialized
INFO - 2016-11-09 16:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:12:50 --> Controller Class Initialized
INFO - 2016-11-09 16:12:50 --> Model Class Initialized
INFO - 2016-11-09 16:12:50 --> Model Class Initialized
INFO - 2016-11-09 16:12:50 --> Model Class Initialized
INFO - 2016-11-09 16:12:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:12:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:12:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:12:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:12:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:12:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:12:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:12:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:12:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:12:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:12:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:12:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:12:50 --> Final output sent to browser
DEBUG - 2016-11-09 16:12:50 --> Total execution time: 0.4629
INFO - 2016-11-09 16:12:52 --> Config Class Initialized
INFO - 2016-11-09 16:12:52 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:12:52 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:12:52 --> Utf8 Class Initialized
INFO - 2016-11-09 16:12:52 --> URI Class Initialized
INFO - 2016-11-09 16:12:52 --> Router Class Initialized
INFO - 2016-11-09 16:12:53 --> Output Class Initialized
INFO - 2016-11-09 16:12:53 --> Security Class Initialized
DEBUG - 2016-11-09 16:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:12:53 --> Input Class Initialized
INFO - 2016-11-09 16:12:53 --> Language Class Initialized
INFO - 2016-11-09 16:12:53 --> Loader Class Initialized
INFO - 2016-11-09 16:12:53 --> Helper loaded: url_helper
INFO - 2016-11-09 16:12:53 --> Helper loaded: form_helper
INFO - 2016-11-09 16:12:53 --> Database Driver Class Initialized
INFO - 2016-11-09 16:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:12:53 --> Controller Class Initialized
INFO - 2016-11-09 16:12:53 --> Model Class Initialized
INFO - 2016-11-09 16:12:53 --> Form Validation Class Initialized
INFO - 2016-11-09 16:12:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 16:12:53 --> Final output sent to browser
DEBUG - 2016-11-09 16:12:53 --> Total execution time: 0.2583
INFO - 2016-11-09 16:15:32 --> Config Class Initialized
INFO - 2016-11-09 16:15:32 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:15:32 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:15:32 --> Utf8 Class Initialized
INFO - 2016-11-09 16:15:32 --> URI Class Initialized
INFO - 2016-11-09 16:15:32 --> Router Class Initialized
INFO - 2016-11-09 16:15:32 --> Output Class Initialized
INFO - 2016-11-09 16:15:32 --> Security Class Initialized
DEBUG - 2016-11-09 16:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:15:32 --> Input Class Initialized
INFO - 2016-11-09 16:15:32 --> Language Class Initialized
INFO - 2016-11-09 16:15:32 --> Loader Class Initialized
INFO - 2016-11-09 16:15:32 --> Helper loaded: url_helper
INFO - 2016-11-09 16:15:32 --> Helper loaded: form_helper
INFO - 2016-11-09 16:15:32 --> Database Driver Class Initialized
INFO - 2016-11-09 16:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:15:32 --> Controller Class Initialized
INFO - 2016-11-09 16:15:32 --> Model Class Initialized
INFO - 2016-11-09 16:15:32 --> Form Validation Class Initialized
INFO - 2016-11-09 16:15:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 16:15:32 --> Final output sent to browser
DEBUG - 2016-11-09 16:15:32 --> Total execution time: 0.2607
INFO - 2016-11-09 16:15:35 --> Config Class Initialized
INFO - 2016-11-09 16:15:35 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:15:35 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:15:35 --> Utf8 Class Initialized
INFO - 2016-11-09 16:15:35 --> URI Class Initialized
DEBUG - 2016-11-09 16:15:35 --> No URI present. Default controller set.
INFO - 2016-11-09 16:15:35 --> Router Class Initialized
INFO - 2016-11-09 16:15:35 --> Output Class Initialized
INFO - 2016-11-09 16:15:35 --> Security Class Initialized
DEBUG - 2016-11-09 16:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:15:35 --> Input Class Initialized
INFO - 2016-11-09 16:15:35 --> Language Class Initialized
INFO - 2016-11-09 16:15:35 --> Loader Class Initialized
INFO - 2016-11-09 16:15:35 --> Helper loaded: url_helper
INFO - 2016-11-09 16:15:35 --> Helper loaded: form_helper
INFO - 2016-11-09 16:15:35 --> Database Driver Class Initialized
INFO - 2016-11-09 16:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:15:35 --> Controller Class Initialized
INFO - 2016-11-09 16:15:35 --> Model Class Initialized
INFO - 2016-11-09 16:15:36 --> Model Class Initialized
INFO - 2016-11-09 16:15:36 --> Model Class Initialized
INFO - 2016-11-09 16:15:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:15:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:15:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:15:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:15:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:15:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:15:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:15:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:15:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:15:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:15:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:15:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:15:36 --> Final output sent to browser
DEBUG - 2016-11-09 16:15:36 --> Total execution time: 0.4229
INFO - 2016-11-09 16:15:38 --> Config Class Initialized
INFO - 2016-11-09 16:15:39 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:15:39 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:15:39 --> Utf8 Class Initialized
INFO - 2016-11-09 16:15:39 --> URI Class Initialized
INFO - 2016-11-09 16:15:39 --> Router Class Initialized
INFO - 2016-11-09 16:15:39 --> Output Class Initialized
INFO - 2016-11-09 16:15:39 --> Security Class Initialized
DEBUG - 2016-11-09 16:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:15:39 --> Input Class Initialized
INFO - 2016-11-09 16:15:39 --> Language Class Initialized
INFO - 2016-11-09 16:15:39 --> Loader Class Initialized
INFO - 2016-11-09 16:15:39 --> Helper loaded: url_helper
INFO - 2016-11-09 16:15:39 --> Helper loaded: form_helper
INFO - 2016-11-09 16:15:39 --> Database Driver Class Initialized
INFO - 2016-11-09 16:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:15:39 --> Controller Class Initialized
INFO - 2016-11-09 16:15:39 --> Model Class Initialized
INFO - 2016-11-09 16:15:39 --> Form Validation Class Initialized
INFO - 2016-11-09 16:15:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 16:15:39 --> Final output sent to browser
DEBUG - 2016-11-09 16:15:39 --> Total execution time: 0.6216
INFO - 2016-11-09 16:15:41 --> Config Class Initialized
INFO - 2016-11-09 16:15:41 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:15:41 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:15:41 --> Utf8 Class Initialized
INFO - 2016-11-09 16:15:41 --> URI Class Initialized
DEBUG - 2016-11-09 16:15:41 --> No URI present. Default controller set.
INFO - 2016-11-09 16:15:41 --> Router Class Initialized
INFO - 2016-11-09 16:15:41 --> Output Class Initialized
INFO - 2016-11-09 16:15:41 --> Security Class Initialized
DEBUG - 2016-11-09 16:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:15:41 --> Input Class Initialized
INFO - 2016-11-09 16:15:41 --> Language Class Initialized
INFO - 2016-11-09 16:15:41 --> Loader Class Initialized
INFO - 2016-11-09 16:15:41 --> Helper loaded: url_helper
INFO - 2016-11-09 16:15:41 --> Helper loaded: form_helper
INFO - 2016-11-09 16:15:41 --> Database Driver Class Initialized
INFO - 2016-11-09 16:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:15:41 --> Controller Class Initialized
INFO - 2016-11-09 16:15:41 --> Model Class Initialized
INFO - 2016-11-09 16:15:41 --> Model Class Initialized
INFO - 2016-11-09 16:15:41 --> Model Class Initialized
INFO - 2016-11-09 16:15:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:15:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:15:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:15:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:15:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:15:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:15:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:15:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:15:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:15:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:15:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:15:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:15:42 --> Final output sent to browser
DEBUG - 2016-11-09 16:15:42 --> Total execution time: 0.4931
INFO - 2016-11-09 16:15:47 --> Config Class Initialized
INFO - 2016-11-09 16:15:47 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:15:47 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:15:47 --> Utf8 Class Initialized
INFO - 2016-11-09 16:15:47 --> URI Class Initialized
INFO - 2016-11-09 16:15:47 --> Router Class Initialized
INFO - 2016-11-09 16:15:47 --> Output Class Initialized
INFO - 2016-11-09 16:15:47 --> Security Class Initialized
DEBUG - 2016-11-09 16:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:15:47 --> Input Class Initialized
INFO - 2016-11-09 16:15:47 --> Language Class Initialized
INFO - 2016-11-09 16:15:47 --> Loader Class Initialized
INFO - 2016-11-09 16:15:47 --> Helper loaded: url_helper
INFO - 2016-11-09 16:15:47 --> Helper loaded: form_helper
INFO - 2016-11-09 16:15:47 --> Database Driver Class Initialized
INFO - 2016-11-09 16:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:15:47 --> Controller Class Initialized
INFO - 2016-11-09 16:15:47 --> Model Class Initialized
INFO - 2016-11-09 16:15:47 --> Form Validation Class Initialized
INFO - 2016-11-09 16:15:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 16:15:47 --> Final output sent to browser
DEBUG - 2016-11-09 16:15:47 --> Total execution time: 0.2608
INFO - 2016-11-09 16:15:50 --> Config Class Initialized
INFO - 2016-11-09 16:15:50 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:15:50 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:15:50 --> Utf8 Class Initialized
INFO - 2016-11-09 16:15:50 --> URI Class Initialized
DEBUG - 2016-11-09 16:15:50 --> No URI present. Default controller set.
INFO - 2016-11-09 16:15:50 --> Router Class Initialized
INFO - 2016-11-09 16:15:50 --> Output Class Initialized
INFO - 2016-11-09 16:15:50 --> Security Class Initialized
DEBUG - 2016-11-09 16:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:15:50 --> Input Class Initialized
INFO - 2016-11-09 16:15:50 --> Language Class Initialized
INFO - 2016-11-09 16:15:50 --> Loader Class Initialized
INFO - 2016-11-09 16:15:50 --> Helper loaded: url_helper
INFO - 2016-11-09 16:15:50 --> Helper loaded: form_helper
INFO - 2016-11-09 16:15:50 --> Database Driver Class Initialized
INFO - 2016-11-09 16:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:15:50 --> Controller Class Initialized
INFO - 2016-11-09 16:15:50 --> Model Class Initialized
INFO - 2016-11-09 16:15:50 --> Model Class Initialized
INFO - 2016-11-09 16:15:50 --> Model Class Initialized
INFO - 2016-11-09 16:15:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:15:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:15:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:15:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:15:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:15:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:15:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:15:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:15:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:15:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:15:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:15:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:15:51 --> Final output sent to browser
DEBUG - 2016-11-09 16:15:51 --> Total execution time: 0.4327
INFO - 2016-11-09 16:15:56 --> Config Class Initialized
INFO - 2016-11-09 16:15:56 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:15:56 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:15:56 --> Utf8 Class Initialized
INFO - 2016-11-09 16:15:56 --> URI Class Initialized
INFO - 2016-11-09 16:15:56 --> Router Class Initialized
INFO - 2016-11-09 16:15:56 --> Output Class Initialized
INFO - 2016-11-09 16:15:56 --> Security Class Initialized
DEBUG - 2016-11-09 16:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:15:56 --> Input Class Initialized
INFO - 2016-11-09 16:15:56 --> Language Class Initialized
INFO - 2016-11-09 16:15:56 --> Loader Class Initialized
INFO - 2016-11-09 16:15:56 --> Helper loaded: url_helper
INFO - 2016-11-09 16:15:56 --> Helper loaded: form_helper
INFO - 2016-11-09 16:15:56 --> Database Driver Class Initialized
INFO - 2016-11-09 16:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:15:56 --> Controller Class Initialized
INFO - 2016-11-09 16:15:56 --> Model Class Initialized
INFO - 2016-11-09 16:15:56 --> Form Validation Class Initialized
INFO - 2016-11-09 16:15:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 16:15:56 --> Final output sent to browser
DEBUG - 2016-11-09 16:15:56 --> Total execution time: 0.2791
INFO - 2016-11-09 16:16:09 --> Config Class Initialized
INFO - 2016-11-09 16:16:09 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:16:10 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:16:10 --> Utf8 Class Initialized
INFO - 2016-11-09 16:16:10 --> URI Class Initialized
DEBUG - 2016-11-09 16:16:10 --> No URI present. Default controller set.
INFO - 2016-11-09 16:16:10 --> Router Class Initialized
INFO - 2016-11-09 16:16:10 --> Output Class Initialized
INFO - 2016-11-09 16:16:10 --> Security Class Initialized
DEBUG - 2016-11-09 16:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:16:10 --> Input Class Initialized
INFO - 2016-11-09 16:16:10 --> Language Class Initialized
INFO - 2016-11-09 16:16:10 --> Loader Class Initialized
INFO - 2016-11-09 16:16:10 --> Helper loaded: url_helper
INFO - 2016-11-09 16:16:10 --> Helper loaded: form_helper
INFO - 2016-11-09 16:16:10 --> Database Driver Class Initialized
INFO - 2016-11-09 16:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:16:10 --> Controller Class Initialized
INFO - 2016-11-09 16:16:10 --> Model Class Initialized
INFO - 2016-11-09 16:16:10 --> Model Class Initialized
INFO - 2016-11-09 16:16:10 --> Model Class Initialized
INFO - 2016-11-09 16:16:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:16:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:16:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:16:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:16:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:16:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:16:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:16:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:16:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:16:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:16:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:16:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:16:10 --> Final output sent to browser
DEBUG - 2016-11-09 16:16:10 --> Total execution time: 0.4223
INFO - 2016-11-09 16:16:16 --> Config Class Initialized
INFO - 2016-11-09 16:16:16 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:16:16 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:16:16 --> Utf8 Class Initialized
INFO - 2016-11-09 16:16:16 --> URI Class Initialized
INFO - 2016-11-09 16:16:17 --> Router Class Initialized
INFO - 2016-11-09 16:16:17 --> Output Class Initialized
INFO - 2016-11-09 16:16:17 --> Security Class Initialized
DEBUG - 2016-11-09 16:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:16:17 --> Input Class Initialized
INFO - 2016-11-09 16:16:17 --> Language Class Initialized
INFO - 2016-11-09 16:16:17 --> Loader Class Initialized
INFO - 2016-11-09 16:16:17 --> Helper loaded: url_helper
INFO - 2016-11-09 16:16:17 --> Helper loaded: form_helper
INFO - 2016-11-09 16:16:17 --> Database Driver Class Initialized
INFO - 2016-11-09 16:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:16:17 --> Controller Class Initialized
INFO - 2016-11-09 16:16:17 --> Model Class Initialized
INFO - 2016-11-09 16:16:17 --> Form Validation Class Initialized
INFO - 2016-11-09 16:16:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 16:16:17 --> Final output sent to browser
DEBUG - 2016-11-09 16:16:17 --> Total execution time: 0.2674
INFO - 2016-11-09 16:17:18 --> Config Class Initialized
INFO - 2016-11-09 16:17:18 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:17:18 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:17:18 --> Utf8 Class Initialized
INFO - 2016-11-09 16:17:18 --> URI Class Initialized
DEBUG - 2016-11-09 16:17:18 --> No URI present. Default controller set.
INFO - 2016-11-09 16:17:18 --> Router Class Initialized
INFO - 2016-11-09 16:17:18 --> Output Class Initialized
INFO - 2016-11-09 16:17:18 --> Security Class Initialized
DEBUG - 2016-11-09 16:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:17:18 --> Input Class Initialized
INFO - 2016-11-09 16:17:18 --> Language Class Initialized
INFO - 2016-11-09 16:17:18 --> Loader Class Initialized
INFO - 2016-11-09 16:17:19 --> Helper loaded: url_helper
INFO - 2016-11-09 16:17:19 --> Helper loaded: form_helper
INFO - 2016-11-09 16:17:19 --> Database Driver Class Initialized
INFO - 2016-11-09 16:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:17:19 --> Controller Class Initialized
INFO - 2016-11-09 16:17:19 --> Model Class Initialized
INFO - 2016-11-09 16:17:19 --> Model Class Initialized
INFO - 2016-11-09 16:17:19 --> Model Class Initialized
INFO - 2016-11-09 16:17:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:17:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:17:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:17:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:17:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:17:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:17:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:17:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:17:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:17:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:17:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:17:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:17:19 --> Final output sent to browser
DEBUG - 2016-11-09 16:17:19 --> Total execution time: 0.4324
INFO - 2016-11-09 16:17:26 --> Config Class Initialized
INFO - 2016-11-09 16:17:26 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:17:26 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:17:26 --> Utf8 Class Initialized
INFO - 2016-11-09 16:17:26 --> URI Class Initialized
INFO - 2016-11-09 16:17:26 --> Router Class Initialized
INFO - 2016-11-09 16:17:26 --> Output Class Initialized
INFO - 2016-11-09 16:17:26 --> Security Class Initialized
DEBUG - 2016-11-09 16:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:17:26 --> Input Class Initialized
INFO - 2016-11-09 16:17:26 --> Language Class Initialized
INFO - 2016-11-09 16:17:26 --> Loader Class Initialized
INFO - 2016-11-09 16:17:26 --> Helper loaded: url_helper
INFO - 2016-11-09 16:17:26 --> Helper loaded: form_helper
INFO - 2016-11-09 16:17:26 --> Database Driver Class Initialized
INFO - 2016-11-09 16:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:17:26 --> Controller Class Initialized
INFO - 2016-11-09 16:17:26 --> Model Class Initialized
INFO - 2016-11-09 16:17:26 --> Form Validation Class Initialized
INFO - 2016-11-09 16:17:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 16:17:26 --> Final output sent to browser
DEBUG - 2016-11-09 16:17:26 --> Total execution time: 0.2735
INFO - 2016-11-09 16:17:30 --> Config Class Initialized
INFO - 2016-11-09 16:17:30 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:17:30 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:17:30 --> Utf8 Class Initialized
INFO - 2016-11-09 16:17:30 --> URI Class Initialized
DEBUG - 2016-11-09 16:17:30 --> No URI present. Default controller set.
INFO - 2016-11-09 16:17:30 --> Router Class Initialized
INFO - 2016-11-09 16:17:30 --> Output Class Initialized
INFO - 2016-11-09 16:17:30 --> Security Class Initialized
DEBUG - 2016-11-09 16:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:17:30 --> Input Class Initialized
INFO - 2016-11-09 16:17:30 --> Language Class Initialized
INFO - 2016-11-09 16:17:30 --> Loader Class Initialized
INFO - 2016-11-09 16:17:30 --> Helper loaded: url_helper
INFO - 2016-11-09 16:17:30 --> Helper loaded: form_helper
INFO - 2016-11-09 16:17:30 --> Database Driver Class Initialized
INFO - 2016-11-09 16:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:17:30 --> Controller Class Initialized
INFO - 2016-11-09 16:17:30 --> Model Class Initialized
INFO - 2016-11-09 16:17:30 --> Model Class Initialized
INFO - 2016-11-09 16:17:30 --> Model Class Initialized
INFO - 2016-11-09 16:17:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:17:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:17:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:17:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:17:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:17:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:17:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:17:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:17:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:17:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:17:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:17:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:17:30 --> Final output sent to browser
DEBUG - 2016-11-09 16:17:30 --> Total execution time: 0.4281
INFO - 2016-11-09 16:17:42 --> Config Class Initialized
INFO - 2016-11-09 16:17:42 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:17:42 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:17:42 --> Utf8 Class Initialized
INFO - 2016-11-09 16:17:42 --> URI Class Initialized
INFO - 2016-11-09 16:17:42 --> Router Class Initialized
INFO - 2016-11-09 16:17:42 --> Output Class Initialized
INFO - 2016-11-09 16:17:42 --> Security Class Initialized
DEBUG - 2016-11-09 16:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:17:42 --> Input Class Initialized
INFO - 2016-11-09 16:17:42 --> Language Class Initialized
INFO - 2016-11-09 16:17:42 --> Loader Class Initialized
INFO - 2016-11-09 16:17:42 --> Helper loaded: url_helper
INFO - 2016-11-09 16:17:42 --> Helper loaded: form_helper
INFO - 2016-11-09 16:17:42 --> Database Driver Class Initialized
INFO - 2016-11-09 16:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:17:42 --> Controller Class Initialized
INFO - 2016-11-09 16:17:42 --> Model Class Initialized
INFO - 2016-11-09 16:17:42 --> Form Validation Class Initialized
INFO - 2016-11-09 16:17:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 16:17:42 --> Final output sent to browser
DEBUG - 2016-11-09 16:17:42 --> Total execution time: 0.2735
INFO - 2016-11-09 16:18:46 --> Config Class Initialized
INFO - 2016-11-09 16:18:46 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:18:46 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:18:46 --> Utf8 Class Initialized
INFO - 2016-11-09 16:18:46 --> URI Class Initialized
DEBUG - 2016-11-09 16:18:46 --> No URI present. Default controller set.
INFO - 2016-11-09 16:18:46 --> Router Class Initialized
INFO - 2016-11-09 16:18:46 --> Output Class Initialized
INFO - 2016-11-09 16:18:46 --> Security Class Initialized
DEBUG - 2016-11-09 16:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:18:46 --> Input Class Initialized
INFO - 2016-11-09 16:18:46 --> Language Class Initialized
INFO - 2016-11-09 16:18:46 --> Loader Class Initialized
INFO - 2016-11-09 16:18:46 --> Helper loaded: url_helper
INFO - 2016-11-09 16:18:46 --> Helper loaded: form_helper
INFO - 2016-11-09 16:18:46 --> Database Driver Class Initialized
INFO - 2016-11-09 16:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:18:46 --> Controller Class Initialized
INFO - 2016-11-09 16:18:46 --> Model Class Initialized
INFO - 2016-11-09 16:18:46 --> Model Class Initialized
INFO - 2016-11-09 16:18:46 --> Model Class Initialized
INFO - 2016-11-09 16:18:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:18:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:18:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:18:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:18:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:18:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:18:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:18:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:18:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:18:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:18:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:18:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:18:46 --> Final output sent to browser
DEBUG - 2016-11-09 16:18:47 --> Total execution time: 0.4166
INFO - 2016-11-09 16:18:49 --> Config Class Initialized
INFO - 2016-11-09 16:18:49 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:18:49 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:18:49 --> Utf8 Class Initialized
INFO - 2016-11-09 16:18:49 --> URI Class Initialized
INFO - 2016-11-09 16:18:49 --> Router Class Initialized
INFO - 2016-11-09 16:18:49 --> Output Class Initialized
INFO - 2016-11-09 16:18:49 --> Security Class Initialized
DEBUG - 2016-11-09 16:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:18:49 --> Input Class Initialized
INFO - 2016-11-09 16:18:49 --> Language Class Initialized
INFO - 2016-11-09 16:18:49 --> Loader Class Initialized
INFO - 2016-11-09 16:18:49 --> Helper loaded: url_helper
INFO - 2016-11-09 16:18:49 --> Helper loaded: form_helper
INFO - 2016-11-09 16:18:49 --> Database Driver Class Initialized
INFO - 2016-11-09 16:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:18:49 --> Controller Class Initialized
INFO - 2016-11-09 16:18:49 --> Model Class Initialized
INFO - 2016-11-09 16:18:49 --> Form Validation Class Initialized
INFO - 2016-11-09 16:18:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 16:18:49 --> Final output sent to browser
DEBUG - 2016-11-09 16:18:49 --> Total execution time: 0.2522
INFO - 2016-11-09 16:19:09 --> Config Class Initialized
INFO - 2016-11-09 16:19:09 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:19:09 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:19:09 --> Utf8 Class Initialized
INFO - 2016-11-09 16:19:09 --> URI Class Initialized
INFO - 2016-11-09 16:19:09 --> Router Class Initialized
INFO - 2016-11-09 16:19:09 --> Output Class Initialized
INFO - 2016-11-09 16:19:09 --> Security Class Initialized
DEBUG - 2016-11-09 16:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:19:09 --> Input Class Initialized
INFO - 2016-11-09 16:19:09 --> Language Class Initialized
INFO - 2016-11-09 16:19:09 --> Loader Class Initialized
INFO - 2016-11-09 16:19:09 --> Helper loaded: url_helper
INFO - 2016-11-09 16:19:09 --> Helper loaded: form_helper
INFO - 2016-11-09 16:19:09 --> Database Driver Class Initialized
INFO - 2016-11-09 16:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:19:09 --> Controller Class Initialized
INFO - 2016-11-09 16:19:09 --> Model Class Initialized
INFO - 2016-11-09 16:19:09 --> Form Validation Class Initialized
INFO - 2016-11-09 16:19:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 16:19:09 --> Final output sent to browser
DEBUG - 2016-11-09 16:19:09 --> Total execution time: 0.2601
INFO - 2016-11-09 16:19:40 --> Config Class Initialized
INFO - 2016-11-09 16:19:40 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:19:40 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:19:40 --> Utf8 Class Initialized
INFO - 2016-11-09 16:19:40 --> URI Class Initialized
INFO - 2016-11-09 16:19:40 --> Router Class Initialized
INFO - 2016-11-09 16:19:40 --> Output Class Initialized
INFO - 2016-11-09 16:19:40 --> Security Class Initialized
DEBUG - 2016-11-09 16:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:19:40 --> Input Class Initialized
INFO - 2016-11-09 16:19:40 --> Language Class Initialized
INFO - 2016-11-09 16:19:40 --> Loader Class Initialized
INFO - 2016-11-09 16:19:40 --> Helper loaded: url_helper
INFO - 2016-11-09 16:19:40 --> Helper loaded: form_helper
INFO - 2016-11-09 16:19:40 --> Database Driver Class Initialized
INFO - 2016-11-09 16:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:19:40 --> Controller Class Initialized
INFO - 2016-11-09 16:19:40 --> Model Class Initialized
INFO - 2016-11-09 16:19:40 --> Form Validation Class Initialized
INFO - 2016-11-09 16:19:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 16:19:40 --> Final output sent to browser
DEBUG - 2016-11-09 16:19:40 --> Total execution time: 0.2611
INFO - 2016-11-09 16:19:41 --> Config Class Initialized
INFO - 2016-11-09 16:19:41 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:19:41 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:19:42 --> Utf8 Class Initialized
INFO - 2016-11-09 16:19:42 --> URI Class Initialized
DEBUG - 2016-11-09 16:19:42 --> No URI present. Default controller set.
INFO - 2016-11-09 16:19:42 --> Router Class Initialized
INFO - 2016-11-09 16:19:42 --> Output Class Initialized
INFO - 2016-11-09 16:19:42 --> Security Class Initialized
DEBUG - 2016-11-09 16:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:19:42 --> Input Class Initialized
INFO - 2016-11-09 16:19:42 --> Language Class Initialized
INFO - 2016-11-09 16:19:42 --> Loader Class Initialized
INFO - 2016-11-09 16:19:42 --> Helper loaded: url_helper
INFO - 2016-11-09 16:19:42 --> Helper loaded: form_helper
INFO - 2016-11-09 16:19:42 --> Database Driver Class Initialized
INFO - 2016-11-09 16:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:19:42 --> Controller Class Initialized
INFO - 2016-11-09 16:19:42 --> Model Class Initialized
INFO - 2016-11-09 16:19:42 --> Model Class Initialized
INFO - 2016-11-09 16:19:42 --> Model Class Initialized
INFO - 2016-11-09 16:19:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:19:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:19:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:19:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:19:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:19:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:19:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:19:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:19:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:19:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:19:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:19:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:19:42 --> Final output sent to browser
DEBUG - 2016-11-09 16:19:42 --> Total execution time: 0.4859
INFO - 2016-11-09 16:19:44 --> Config Class Initialized
INFO - 2016-11-09 16:19:44 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:19:44 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:19:44 --> Utf8 Class Initialized
INFO - 2016-11-09 16:19:44 --> URI Class Initialized
INFO - 2016-11-09 16:19:44 --> Router Class Initialized
INFO - 2016-11-09 16:19:45 --> Output Class Initialized
INFO - 2016-11-09 16:19:45 --> Security Class Initialized
DEBUG - 2016-11-09 16:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:19:45 --> Input Class Initialized
INFO - 2016-11-09 16:19:45 --> Language Class Initialized
INFO - 2016-11-09 16:19:45 --> Loader Class Initialized
INFO - 2016-11-09 16:19:45 --> Helper loaded: url_helper
INFO - 2016-11-09 16:19:45 --> Helper loaded: form_helper
INFO - 2016-11-09 16:19:45 --> Database Driver Class Initialized
INFO - 2016-11-09 16:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:19:45 --> Controller Class Initialized
INFO - 2016-11-09 16:19:45 --> Model Class Initialized
INFO - 2016-11-09 16:19:45 --> Form Validation Class Initialized
INFO - 2016-11-09 16:19:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 16:19:45 --> Final output sent to browser
DEBUG - 2016-11-09 16:19:45 --> Total execution time: 0.4519
INFO - 2016-11-09 16:20:54 --> Config Class Initialized
INFO - 2016-11-09 16:20:54 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:20:54 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:20:54 --> Utf8 Class Initialized
INFO - 2016-11-09 16:20:54 --> URI Class Initialized
INFO - 2016-11-09 16:20:54 --> Router Class Initialized
INFO - 2016-11-09 16:20:54 --> Output Class Initialized
INFO - 2016-11-09 16:20:54 --> Security Class Initialized
DEBUG - 2016-11-09 16:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:20:54 --> Input Class Initialized
INFO - 2016-11-09 16:20:54 --> Language Class Initialized
INFO - 2016-11-09 16:20:54 --> Loader Class Initialized
INFO - 2016-11-09 16:20:54 --> Helper loaded: url_helper
INFO - 2016-11-09 16:20:54 --> Helper loaded: form_helper
INFO - 2016-11-09 16:20:54 --> Database Driver Class Initialized
INFO - 2016-11-09 16:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:20:54 --> Controller Class Initialized
INFO - 2016-11-09 16:20:54 --> Model Class Initialized
INFO - 2016-11-09 16:20:54 --> Form Validation Class Initialized
INFO - 2016-11-09 16:20:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 16:20:54 --> Final output sent to browser
DEBUG - 2016-11-09 16:20:54 --> Total execution time: 0.2699
INFO - 2016-11-09 16:20:56 --> Config Class Initialized
INFO - 2016-11-09 16:20:56 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:20:56 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:20:56 --> Utf8 Class Initialized
INFO - 2016-11-09 16:20:56 --> URI Class Initialized
INFO - 2016-11-09 16:20:56 --> Router Class Initialized
INFO - 2016-11-09 16:20:56 --> Output Class Initialized
INFO - 2016-11-09 16:20:56 --> Security Class Initialized
DEBUG - 2016-11-09 16:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:20:56 --> Input Class Initialized
INFO - 2016-11-09 16:20:56 --> Language Class Initialized
INFO - 2016-11-09 16:20:56 --> Loader Class Initialized
INFO - 2016-11-09 16:20:56 --> Helper loaded: url_helper
INFO - 2016-11-09 16:20:56 --> Helper loaded: form_helper
INFO - 2016-11-09 16:20:56 --> Database Driver Class Initialized
INFO - 2016-11-09 16:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:20:56 --> Controller Class Initialized
INFO - 2016-11-09 16:20:56 --> Model Class Initialized
INFO - 2016-11-09 16:20:56 --> Form Validation Class Initialized
INFO - 2016-11-09 16:20:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 16:20:57 --> Final output sent to browser
DEBUG - 2016-11-09 16:20:57 --> Total execution time: 0.2791
INFO - 2016-11-09 16:22:25 --> Config Class Initialized
INFO - 2016-11-09 16:22:25 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:22:25 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:22:25 --> Utf8 Class Initialized
INFO - 2016-11-09 16:22:25 --> URI Class Initialized
INFO - 2016-11-09 16:22:25 --> Router Class Initialized
INFO - 2016-11-09 16:22:25 --> Output Class Initialized
INFO - 2016-11-09 16:22:25 --> Security Class Initialized
DEBUG - 2016-11-09 16:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:22:25 --> Input Class Initialized
INFO - 2016-11-09 16:22:25 --> Language Class Initialized
INFO - 2016-11-09 16:22:25 --> Loader Class Initialized
INFO - 2016-11-09 16:22:25 --> Helper loaded: url_helper
INFO - 2016-11-09 16:22:25 --> Helper loaded: form_helper
INFO - 2016-11-09 16:22:25 --> Database Driver Class Initialized
INFO - 2016-11-09 16:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:22:25 --> Controller Class Initialized
INFO - 2016-11-09 16:22:25 --> Model Class Initialized
INFO - 2016-11-09 16:22:25 --> Form Validation Class Initialized
INFO - 2016-11-09 16:22:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 16:22:25 --> Final output sent to browser
DEBUG - 2016-11-09 16:22:25 --> Total execution time: 0.2764
INFO - 2016-11-09 16:22:29 --> Config Class Initialized
INFO - 2016-11-09 16:22:29 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:22:29 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:22:29 --> Utf8 Class Initialized
INFO - 2016-11-09 16:22:29 --> URI Class Initialized
DEBUG - 2016-11-09 16:22:29 --> No URI present. Default controller set.
INFO - 2016-11-09 16:22:29 --> Router Class Initialized
INFO - 2016-11-09 16:22:30 --> Output Class Initialized
INFO - 2016-11-09 16:22:30 --> Security Class Initialized
DEBUG - 2016-11-09 16:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:22:30 --> Input Class Initialized
INFO - 2016-11-09 16:22:30 --> Language Class Initialized
INFO - 2016-11-09 16:22:30 --> Loader Class Initialized
INFO - 2016-11-09 16:22:30 --> Helper loaded: url_helper
INFO - 2016-11-09 16:22:30 --> Helper loaded: form_helper
INFO - 2016-11-09 16:22:30 --> Database Driver Class Initialized
INFO - 2016-11-09 16:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:22:30 --> Controller Class Initialized
INFO - 2016-11-09 16:22:30 --> Model Class Initialized
INFO - 2016-11-09 16:22:30 --> Model Class Initialized
INFO - 2016-11-09 16:22:30 --> Model Class Initialized
INFO - 2016-11-09 16:22:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:22:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:22:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:22:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:22:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:22:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:22:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:22:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:22:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:22:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:22:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:22:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:22:30 --> Final output sent to browser
DEBUG - 2016-11-09 16:22:30 --> Total execution time: 0.4494
INFO - 2016-11-09 16:22:40 --> Config Class Initialized
INFO - 2016-11-09 16:22:40 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:22:40 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:22:40 --> Utf8 Class Initialized
INFO - 2016-11-09 16:22:40 --> URI Class Initialized
INFO - 2016-11-09 16:22:40 --> Router Class Initialized
INFO - 2016-11-09 16:22:40 --> Output Class Initialized
INFO - 2016-11-09 16:22:40 --> Security Class Initialized
DEBUG - 2016-11-09 16:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:22:40 --> Input Class Initialized
INFO - 2016-11-09 16:22:40 --> Language Class Initialized
INFO - 2016-11-09 16:22:40 --> Loader Class Initialized
INFO - 2016-11-09 16:22:40 --> Helper loaded: url_helper
INFO - 2016-11-09 16:22:40 --> Helper loaded: form_helper
INFO - 2016-11-09 16:22:40 --> Database Driver Class Initialized
INFO - 2016-11-09 16:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:22:40 --> Controller Class Initialized
INFO - 2016-11-09 16:22:40 --> Model Class Initialized
INFO - 2016-11-09 16:22:40 --> Form Validation Class Initialized
INFO - 2016-11-09 16:22:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 16:22:40 --> Final output sent to browser
DEBUG - 2016-11-09 16:22:40 --> Total execution time: 0.2925
INFO - 2016-11-09 16:22:42 --> Config Class Initialized
INFO - 2016-11-09 16:22:42 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:22:42 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:22:42 --> Utf8 Class Initialized
INFO - 2016-11-09 16:22:42 --> URI Class Initialized
DEBUG - 2016-11-09 16:22:42 --> No URI present. Default controller set.
INFO - 2016-11-09 16:22:42 --> Router Class Initialized
INFO - 2016-11-09 16:22:42 --> Output Class Initialized
INFO - 2016-11-09 16:22:42 --> Security Class Initialized
DEBUG - 2016-11-09 16:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:22:42 --> Input Class Initialized
INFO - 2016-11-09 16:22:42 --> Language Class Initialized
INFO - 2016-11-09 16:22:42 --> Loader Class Initialized
INFO - 2016-11-09 16:22:42 --> Helper loaded: url_helper
INFO - 2016-11-09 16:22:42 --> Helper loaded: form_helper
INFO - 2016-11-09 16:22:42 --> Database Driver Class Initialized
INFO - 2016-11-09 16:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:22:42 --> Controller Class Initialized
INFO - 2016-11-09 16:22:42 --> Model Class Initialized
INFO - 2016-11-09 16:22:42 --> Model Class Initialized
INFO - 2016-11-09 16:22:42 --> Model Class Initialized
INFO - 2016-11-09 16:22:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:22:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:22:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:22:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:22:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:22:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:22:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:22:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:22:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:22:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:22:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:22:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:22:43 --> Final output sent to browser
DEBUG - 2016-11-09 16:22:43 --> Total execution time: 0.4405
INFO - 2016-11-09 16:25:33 --> Config Class Initialized
INFO - 2016-11-09 16:25:33 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:25:33 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:25:33 --> Utf8 Class Initialized
INFO - 2016-11-09 16:25:33 --> URI Class Initialized
DEBUG - 2016-11-09 16:25:33 --> No URI present. Default controller set.
INFO - 2016-11-09 16:25:33 --> Router Class Initialized
INFO - 2016-11-09 16:25:33 --> Output Class Initialized
INFO - 2016-11-09 16:25:33 --> Security Class Initialized
DEBUG - 2016-11-09 16:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:25:33 --> Input Class Initialized
INFO - 2016-11-09 16:25:33 --> Language Class Initialized
INFO - 2016-11-09 16:25:33 --> Loader Class Initialized
INFO - 2016-11-09 16:25:33 --> Helper loaded: url_helper
INFO - 2016-11-09 16:25:33 --> Helper loaded: form_helper
INFO - 2016-11-09 16:25:33 --> Database Driver Class Initialized
INFO - 2016-11-09 16:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:25:33 --> Controller Class Initialized
INFO - 2016-11-09 16:25:33 --> Model Class Initialized
INFO - 2016-11-09 16:25:33 --> Model Class Initialized
INFO - 2016-11-09 16:25:33 --> Model Class Initialized
INFO - 2016-11-09 16:25:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:25:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:25:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:25:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:25:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:25:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:25:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:25:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:25:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:25:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:25:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:25:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:25:33 --> Final output sent to browser
DEBUG - 2016-11-09 16:25:33 --> Total execution time: 0.4282
INFO - 2016-11-09 16:25:36 --> Config Class Initialized
INFO - 2016-11-09 16:25:36 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:25:36 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:25:37 --> Utf8 Class Initialized
INFO - 2016-11-09 16:25:37 --> URI Class Initialized
INFO - 2016-11-09 16:25:37 --> Router Class Initialized
INFO - 2016-11-09 16:25:37 --> Output Class Initialized
INFO - 2016-11-09 16:25:37 --> Security Class Initialized
DEBUG - 2016-11-09 16:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:25:37 --> Input Class Initialized
INFO - 2016-11-09 16:25:37 --> Language Class Initialized
INFO - 2016-11-09 16:25:37 --> Loader Class Initialized
INFO - 2016-11-09 16:25:37 --> Helper loaded: url_helper
INFO - 2016-11-09 16:25:37 --> Helper loaded: form_helper
INFO - 2016-11-09 16:25:37 --> Database Driver Class Initialized
INFO - 2016-11-09 16:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:25:37 --> Controller Class Initialized
INFO - 2016-11-09 16:25:37 --> Model Class Initialized
INFO - 2016-11-09 16:25:37 --> Form Validation Class Initialized
INFO - 2016-11-09 16:25:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 16:25:37 --> Final output sent to browser
DEBUG - 2016-11-09 16:25:37 --> Total execution time: 0.6669
INFO - 2016-11-09 16:25:42 --> Config Class Initialized
INFO - 2016-11-09 16:25:42 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:25:42 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:25:42 --> Utf8 Class Initialized
INFO - 2016-11-09 16:25:42 --> URI Class Initialized
DEBUG - 2016-11-09 16:25:42 --> No URI present. Default controller set.
INFO - 2016-11-09 16:25:42 --> Router Class Initialized
INFO - 2016-11-09 16:25:42 --> Output Class Initialized
INFO - 2016-11-09 16:25:42 --> Security Class Initialized
DEBUG - 2016-11-09 16:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:25:42 --> Input Class Initialized
INFO - 2016-11-09 16:25:42 --> Language Class Initialized
INFO - 2016-11-09 16:25:42 --> Loader Class Initialized
INFO - 2016-11-09 16:25:42 --> Helper loaded: url_helper
INFO - 2016-11-09 16:25:42 --> Helper loaded: form_helper
INFO - 2016-11-09 16:25:42 --> Database Driver Class Initialized
INFO - 2016-11-09 16:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:25:42 --> Controller Class Initialized
INFO - 2016-11-09 16:25:42 --> Model Class Initialized
INFO - 2016-11-09 16:25:42 --> Model Class Initialized
INFO - 2016-11-09 16:25:42 --> Model Class Initialized
INFO - 2016-11-09 16:25:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:25:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:25:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:25:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:25:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:25:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:25:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:25:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:25:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:25:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:25:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:25:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:25:42 --> Final output sent to browser
DEBUG - 2016-11-09 16:25:42 --> Total execution time: 0.4613
INFO - 2016-11-09 16:26:30 --> Config Class Initialized
INFO - 2016-11-09 16:26:30 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:26:30 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:26:30 --> Utf8 Class Initialized
INFO - 2016-11-09 16:26:30 --> URI Class Initialized
DEBUG - 2016-11-09 16:26:30 --> No URI present. Default controller set.
INFO - 2016-11-09 16:26:30 --> Router Class Initialized
INFO - 2016-11-09 16:26:30 --> Output Class Initialized
INFO - 2016-11-09 16:26:30 --> Security Class Initialized
DEBUG - 2016-11-09 16:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:26:30 --> Input Class Initialized
INFO - 2016-11-09 16:26:30 --> Language Class Initialized
INFO - 2016-11-09 16:26:30 --> Loader Class Initialized
INFO - 2016-11-09 16:26:30 --> Helper loaded: url_helper
INFO - 2016-11-09 16:26:30 --> Helper loaded: form_helper
INFO - 2016-11-09 16:26:30 --> Database Driver Class Initialized
INFO - 2016-11-09 16:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:26:30 --> Controller Class Initialized
INFO - 2016-11-09 16:26:30 --> Model Class Initialized
INFO - 2016-11-09 16:26:30 --> Model Class Initialized
INFO - 2016-11-09 16:26:30 --> Model Class Initialized
INFO - 2016-11-09 16:26:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:26:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:26:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:26:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:26:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:26:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:26:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:26:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:26:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:26:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:26:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:26:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:26:30 --> Final output sent to browser
DEBUG - 2016-11-09 16:26:30 --> Total execution time: 0.4637
INFO - 2016-11-09 16:26:33 --> Config Class Initialized
INFO - 2016-11-09 16:26:33 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:26:33 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:26:33 --> Utf8 Class Initialized
INFO - 2016-11-09 16:26:33 --> URI Class Initialized
INFO - 2016-11-09 16:26:33 --> Router Class Initialized
INFO - 2016-11-09 16:26:33 --> Output Class Initialized
INFO - 2016-11-09 16:26:33 --> Security Class Initialized
DEBUG - 2016-11-09 16:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:26:33 --> Input Class Initialized
INFO - 2016-11-09 16:26:33 --> Language Class Initialized
INFO - 2016-11-09 16:26:33 --> Loader Class Initialized
INFO - 2016-11-09 16:26:33 --> Helper loaded: url_helper
INFO - 2016-11-09 16:26:33 --> Helper loaded: form_helper
INFO - 2016-11-09 16:26:33 --> Database Driver Class Initialized
INFO - 2016-11-09 16:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:26:33 --> Controller Class Initialized
INFO - 2016-11-09 16:26:33 --> Model Class Initialized
INFO - 2016-11-09 16:26:33 --> Form Validation Class Initialized
INFO - 2016-11-09 16:26:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 16:26:33 --> Final output sent to browser
DEBUG - 2016-11-09 16:26:33 --> Total execution time: 0.2689
INFO - 2016-11-09 16:26:46 --> Config Class Initialized
INFO - 2016-11-09 16:26:46 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:26:46 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:26:46 --> Utf8 Class Initialized
INFO - 2016-11-09 16:26:46 --> URI Class Initialized
DEBUG - 2016-11-09 16:26:46 --> No URI present. Default controller set.
INFO - 2016-11-09 16:26:46 --> Router Class Initialized
INFO - 2016-11-09 16:26:46 --> Output Class Initialized
INFO - 2016-11-09 16:26:46 --> Security Class Initialized
DEBUG - 2016-11-09 16:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:26:46 --> Input Class Initialized
INFO - 2016-11-09 16:26:46 --> Language Class Initialized
INFO - 2016-11-09 16:26:46 --> Loader Class Initialized
INFO - 2016-11-09 16:26:46 --> Helper loaded: url_helper
INFO - 2016-11-09 16:26:46 --> Helper loaded: form_helper
INFO - 2016-11-09 16:26:46 --> Database Driver Class Initialized
INFO - 2016-11-09 16:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:26:46 --> Controller Class Initialized
INFO - 2016-11-09 16:26:46 --> Model Class Initialized
INFO - 2016-11-09 16:26:46 --> Model Class Initialized
INFO - 2016-11-09 16:26:46 --> Model Class Initialized
INFO - 2016-11-09 16:26:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:26:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:26:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:26:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:26:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:26:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:26:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:26:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:26:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:26:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:26:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:26:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:26:46 --> Final output sent to browser
DEBUG - 2016-11-09 16:26:46 --> Total execution time: 0.4608
INFO - 2016-11-09 16:32:10 --> Config Class Initialized
INFO - 2016-11-09 16:32:10 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:32:10 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:32:10 --> Utf8 Class Initialized
INFO - 2016-11-09 16:32:10 --> URI Class Initialized
INFO - 2016-11-09 16:32:10 --> Router Class Initialized
INFO - 2016-11-09 16:32:10 --> Output Class Initialized
INFO - 2016-11-09 16:32:11 --> Security Class Initialized
DEBUG - 2016-11-09 16:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:32:11 --> Input Class Initialized
INFO - 2016-11-09 16:32:11 --> Language Class Initialized
INFO - 2016-11-09 16:32:11 --> Loader Class Initialized
INFO - 2016-11-09 16:32:11 --> Helper loaded: url_helper
INFO - 2016-11-09 16:32:11 --> Helper loaded: form_helper
INFO - 2016-11-09 16:32:11 --> Database Driver Class Initialized
INFO - 2016-11-09 16:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:32:11 --> Controller Class Initialized
INFO - 2016-11-09 16:32:11 --> Model Class Initialized
INFO - 2016-11-09 16:32:11 --> Form Validation Class Initialized
INFO - 2016-11-09 16:32:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 16:32:11 --> Final output sent to browser
DEBUG - 2016-11-09 16:32:11 --> Total execution time: 0.4810
INFO - 2016-11-09 16:32:13 --> Config Class Initialized
INFO - 2016-11-09 16:32:13 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:32:13 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:32:13 --> Utf8 Class Initialized
INFO - 2016-11-09 16:32:13 --> URI Class Initialized
DEBUG - 2016-11-09 16:32:13 --> No URI present. Default controller set.
INFO - 2016-11-09 16:32:13 --> Router Class Initialized
INFO - 2016-11-09 16:32:13 --> Output Class Initialized
INFO - 2016-11-09 16:32:13 --> Security Class Initialized
DEBUG - 2016-11-09 16:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:32:13 --> Input Class Initialized
INFO - 2016-11-09 16:32:13 --> Language Class Initialized
INFO - 2016-11-09 16:32:13 --> Loader Class Initialized
INFO - 2016-11-09 16:32:13 --> Helper loaded: url_helper
INFO - 2016-11-09 16:32:13 --> Helper loaded: form_helper
INFO - 2016-11-09 16:32:13 --> Database Driver Class Initialized
INFO - 2016-11-09 16:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:32:14 --> Controller Class Initialized
INFO - 2016-11-09 16:32:14 --> Model Class Initialized
INFO - 2016-11-09 16:32:14 --> Model Class Initialized
INFO - 2016-11-09 16:32:14 --> Model Class Initialized
INFO - 2016-11-09 16:32:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:32:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:32:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:32:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:32:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:32:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:32:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:32:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:32:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:32:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:32:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:32:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:32:14 --> Final output sent to browser
DEBUG - 2016-11-09 16:32:14 --> Total execution time: 0.4590
INFO - 2016-11-09 16:33:59 --> Config Class Initialized
INFO - 2016-11-09 16:33:59 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:33:59 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:33:59 --> Utf8 Class Initialized
INFO - 2016-11-09 16:33:59 --> URI Class Initialized
DEBUG - 2016-11-09 16:33:59 --> No URI present. Default controller set.
INFO - 2016-11-09 16:33:59 --> Router Class Initialized
INFO - 2016-11-09 16:33:59 --> Output Class Initialized
INFO - 2016-11-09 16:33:59 --> Security Class Initialized
DEBUG - 2016-11-09 16:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:33:59 --> Input Class Initialized
INFO - 2016-11-09 16:33:59 --> Language Class Initialized
INFO - 2016-11-09 16:33:59 --> Loader Class Initialized
INFO - 2016-11-09 16:33:59 --> Helper loaded: url_helper
INFO - 2016-11-09 16:33:59 --> Helper loaded: form_helper
INFO - 2016-11-09 16:33:59 --> Database Driver Class Initialized
INFO - 2016-11-09 16:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:33:59 --> Controller Class Initialized
INFO - 2016-11-09 16:33:59 --> Model Class Initialized
INFO - 2016-11-09 16:33:59 --> Model Class Initialized
INFO - 2016-11-09 16:33:59 --> Model Class Initialized
INFO - 2016-11-09 16:33:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:33:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:33:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:33:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:34:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:34:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:34:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:34:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:34:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:34:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:34:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:34:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:34:00 --> Final output sent to browser
DEBUG - 2016-11-09 16:34:00 --> Total execution time: 0.4471
INFO - 2016-11-09 16:34:52 --> Config Class Initialized
INFO - 2016-11-09 16:34:52 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:34:52 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:34:52 --> Utf8 Class Initialized
INFO - 2016-11-09 16:34:52 --> URI Class Initialized
DEBUG - 2016-11-09 16:34:52 --> No URI present. Default controller set.
INFO - 2016-11-09 16:34:52 --> Router Class Initialized
INFO - 2016-11-09 16:34:52 --> Output Class Initialized
INFO - 2016-11-09 16:34:52 --> Security Class Initialized
DEBUG - 2016-11-09 16:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:34:52 --> Input Class Initialized
INFO - 2016-11-09 16:34:52 --> Language Class Initialized
INFO - 2016-11-09 16:34:52 --> Loader Class Initialized
INFO - 2016-11-09 16:34:52 --> Helper loaded: url_helper
INFO - 2016-11-09 16:34:52 --> Helper loaded: form_helper
INFO - 2016-11-09 16:34:52 --> Database Driver Class Initialized
INFO - 2016-11-09 16:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:34:52 --> Controller Class Initialized
INFO - 2016-11-09 16:34:53 --> Model Class Initialized
INFO - 2016-11-09 16:34:53 --> Model Class Initialized
INFO - 2016-11-09 16:34:53 --> Model Class Initialized
INFO - 2016-11-09 16:34:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:34:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:34:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:34:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:34:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:34:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:34:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:34:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:34:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:34:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:34:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:34:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:34:53 --> Final output sent to browser
DEBUG - 2016-11-09 16:34:53 --> Total execution time: 0.5037
INFO - 2016-11-09 16:35:32 --> Config Class Initialized
INFO - 2016-11-09 16:35:32 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:35:32 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:35:32 --> Utf8 Class Initialized
INFO - 2016-11-09 16:35:32 --> URI Class Initialized
DEBUG - 2016-11-09 16:35:32 --> No URI present. Default controller set.
INFO - 2016-11-09 16:35:32 --> Router Class Initialized
INFO - 2016-11-09 16:35:32 --> Output Class Initialized
INFO - 2016-11-09 16:35:32 --> Security Class Initialized
DEBUG - 2016-11-09 16:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:35:32 --> Input Class Initialized
INFO - 2016-11-09 16:35:32 --> Language Class Initialized
INFO - 2016-11-09 16:35:32 --> Loader Class Initialized
INFO - 2016-11-09 16:35:32 --> Helper loaded: url_helper
INFO - 2016-11-09 16:35:32 --> Helper loaded: form_helper
INFO - 2016-11-09 16:35:32 --> Database Driver Class Initialized
INFO - 2016-11-09 16:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:35:32 --> Controller Class Initialized
INFO - 2016-11-09 16:35:32 --> Model Class Initialized
INFO - 2016-11-09 16:35:32 --> Model Class Initialized
INFO - 2016-11-09 16:35:33 --> Model Class Initialized
INFO - 2016-11-09 16:35:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:35:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:35:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:35:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:35:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:35:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:35:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:35:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:35:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:35:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:35:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:35:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:35:33 --> Final output sent to browser
DEBUG - 2016-11-09 16:35:33 --> Total execution time: 0.4912
INFO - 2016-11-09 16:37:23 --> Config Class Initialized
INFO - 2016-11-09 16:37:23 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:37:23 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:37:23 --> Utf8 Class Initialized
INFO - 2016-11-09 16:37:23 --> URI Class Initialized
DEBUG - 2016-11-09 16:37:23 --> No URI present. Default controller set.
INFO - 2016-11-09 16:37:23 --> Router Class Initialized
INFO - 2016-11-09 16:37:23 --> Output Class Initialized
INFO - 2016-11-09 16:37:23 --> Security Class Initialized
DEBUG - 2016-11-09 16:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:37:23 --> Input Class Initialized
INFO - 2016-11-09 16:37:23 --> Language Class Initialized
INFO - 2016-11-09 16:37:23 --> Loader Class Initialized
INFO - 2016-11-09 16:37:23 --> Helper loaded: url_helper
INFO - 2016-11-09 16:37:23 --> Helper loaded: form_helper
INFO - 2016-11-09 16:37:23 --> Database Driver Class Initialized
INFO - 2016-11-09 16:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:37:23 --> Controller Class Initialized
INFO - 2016-11-09 16:37:23 --> Model Class Initialized
INFO - 2016-11-09 16:37:23 --> Model Class Initialized
INFO - 2016-11-09 16:37:23 --> Model Class Initialized
INFO - 2016-11-09 16:37:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:37:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:37:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:37:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:37:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:37:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:37:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:37:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:37:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:37:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:37:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:37:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:37:23 --> Final output sent to browser
DEBUG - 2016-11-09 16:37:23 --> Total execution time: 0.4632
INFO - 2016-11-09 16:42:32 --> Config Class Initialized
INFO - 2016-11-09 16:42:32 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:42:32 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:42:32 --> Utf8 Class Initialized
INFO - 2016-11-09 16:42:32 --> URI Class Initialized
INFO - 2016-11-09 16:42:32 --> Router Class Initialized
INFO - 2016-11-09 16:42:32 --> Output Class Initialized
INFO - 2016-11-09 16:42:32 --> Security Class Initialized
DEBUG - 2016-11-09 16:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:42:32 --> Input Class Initialized
INFO - 2016-11-09 16:42:32 --> Language Class Initialized
INFO - 2016-11-09 16:42:32 --> Loader Class Initialized
INFO - 2016-11-09 16:42:32 --> Helper loaded: url_helper
INFO - 2016-11-09 16:42:32 --> Helper loaded: form_helper
INFO - 2016-11-09 16:42:32 --> Database Driver Class Initialized
INFO - 2016-11-09 16:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:42:32 --> Controller Class Initialized
INFO - 2016-11-09 16:42:32 --> Model Class Initialized
INFO - 2016-11-09 16:42:32 --> Model Class Initialized
INFO - 2016-11-09 16:42:32 --> Model Class Initialized
DEBUG - 2016-11-09 16:42:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-09 16:42:32 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 124
ERROR - 2016-11-09 16:42:32 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 124
INFO - 2016-11-09 16:42:32 --> Config Class Initialized
INFO - 2016-11-09 16:42:32 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:42:32 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:42:32 --> Utf8 Class Initialized
INFO - 2016-11-09 16:42:32 --> URI Class Initialized
DEBUG - 2016-11-09 16:42:32 --> No URI present. Default controller set.
INFO - 2016-11-09 16:42:32 --> Router Class Initialized
INFO - 2016-11-09 16:42:32 --> Output Class Initialized
INFO - 2016-11-09 16:42:32 --> Security Class Initialized
DEBUG - 2016-11-09 16:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:42:32 --> Input Class Initialized
INFO - 2016-11-09 16:42:32 --> Language Class Initialized
INFO - 2016-11-09 16:42:32 --> Loader Class Initialized
INFO - 2016-11-09 16:42:32 --> Helper loaded: url_helper
INFO - 2016-11-09 16:42:32 --> Helper loaded: form_helper
INFO - 2016-11-09 16:42:32 --> Database Driver Class Initialized
INFO - 2016-11-09 16:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:42:32 --> Controller Class Initialized
INFO - 2016-11-09 16:42:32 --> Model Class Initialized
INFO - 2016-11-09 16:42:32 --> Model Class Initialized
INFO - 2016-11-09 16:42:32 --> Model Class Initialized
INFO - 2016-11-09 16:42:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:42:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-09 16:42:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:42:32 --> Final output sent to browser
DEBUG - 2016-11-09 16:42:32 --> Total execution time: 0.3322
INFO - 2016-11-09 16:43:06 --> Config Class Initialized
INFO - 2016-11-09 16:43:06 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:43:06 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:43:06 --> Utf8 Class Initialized
INFO - 2016-11-09 16:43:06 --> URI Class Initialized
INFO - 2016-11-09 16:43:06 --> Router Class Initialized
INFO - 2016-11-09 16:43:06 --> Output Class Initialized
INFO - 2016-11-09 16:43:06 --> Security Class Initialized
DEBUG - 2016-11-09 16:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:43:06 --> Input Class Initialized
INFO - 2016-11-09 16:43:06 --> Language Class Initialized
INFO - 2016-11-09 16:43:06 --> Loader Class Initialized
INFO - 2016-11-09 16:43:06 --> Helper loaded: url_helper
INFO - 2016-11-09 16:43:06 --> Helper loaded: form_helper
INFO - 2016-11-09 16:43:06 --> Database Driver Class Initialized
INFO - 2016-11-09 16:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:43:06 --> Controller Class Initialized
INFO - 2016-11-09 16:43:06 --> Model Class Initialized
INFO - 2016-11-09 16:43:06 --> Model Class Initialized
INFO - 2016-11-09 16:43:06 --> Model Class Initialized
DEBUG - 2016-11-09 16:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-09 16:43:06 --> Model Class Initialized
INFO - 2016-11-09 16:43:06 --> Final output sent to browser
DEBUG - 2016-11-09 16:43:06 --> Total execution time: 0.2817
INFO - 2016-11-09 16:43:12 --> Config Class Initialized
INFO - 2016-11-09 16:43:12 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:43:12 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:43:12 --> Utf8 Class Initialized
INFO - 2016-11-09 16:43:12 --> URI Class Initialized
INFO - 2016-11-09 16:43:12 --> Router Class Initialized
INFO - 2016-11-09 16:43:12 --> Output Class Initialized
INFO - 2016-11-09 16:43:12 --> Security Class Initialized
DEBUG - 2016-11-09 16:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:43:12 --> Input Class Initialized
INFO - 2016-11-09 16:43:12 --> Language Class Initialized
INFO - 2016-11-09 16:43:12 --> Loader Class Initialized
INFO - 2016-11-09 16:43:12 --> Helper loaded: url_helper
INFO - 2016-11-09 16:43:12 --> Helper loaded: form_helper
INFO - 2016-11-09 16:43:12 --> Database Driver Class Initialized
INFO - 2016-11-09 16:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:43:12 --> Controller Class Initialized
INFO - 2016-11-09 16:43:12 --> Model Class Initialized
INFO - 2016-11-09 16:43:12 --> Model Class Initialized
INFO - 2016-11-09 16:43:12 --> Model Class Initialized
DEBUG - 2016-11-09 16:43:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-09 16:43:12 --> Model Class Initialized
INFO - 2016-11-09 16:43:12 --> Final output sent to browser
DEBUG - 2016-11-09 16:43:12 --> Total execution time: 0.3040
INFO - 2016-11-09 16:43:12 --> Config Class Initialized
INFO - 2016-11-09 16:43:12 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:43:12 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:43:12 --> Utf8 Class Initialized
INFO - 2016-11-09 16:43:12 --> URI Class Initialized
DEBUG - 2016-11-09 16:43:12 --> No URI present. Default controller set.
INFO - 2016-11-09 16:43:12 --> Router Class Initialized
INFO - 2016-11-09 16:43:12 --> Output Class Initialized
INFO - 2016-11-09 16:43:12 --> Security Class Initialized
DEBUG - 2016-11-09 16:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:43:12 --> Input Class Initialized
INFO - 2016-11-09 16:43:12 --> Language Class Initialized
INFO - 2016-11-09 16:43:12 --> Loader Class Initialized
INFO - 2016-11-09 16:43:12 --> Helper loaded: url_helper
INFO - 2016-11-09 16:43:12 --> Helper loaded: form_helper
INFO - 2016-11-09 16:43:12 --> Database Driver Class Initialized
INFO - 2016-11-09 16:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:43:12 --> Controller Class Initialized
INFO - 2016-11-09 16:43:12 --> Model Class Initialized
INFO - 2016-11-09 16:43:12 --> Model Class Initialized
INFO - 2016-11-09 16:43:12 --> Model Class Initialized
INFO - 2016-11-09 16:43:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:43:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:43:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:43:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:43:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:43:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:43:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:43:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:43:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:43:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:43:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:43:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:43:12 --> Final output sent to browser
DEBUG - 2016-11-09 16:43:12 --> Total execution time: 0.4614
INFO - 2016-11-09 16:50:53 --> Config Class Initialized
INFO - 2016-11-09 16:50:53 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:50:53 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:50:53 --> Utf8 Class Initialized
INFO - 2016-11-09 16:50:53 --> URI Class Initialized
DEBUG - 2016-11-09 16:50:53 --> No URI present. Default controller set.
INFO - 2016-11-09 16:50:53 --> Router Class Initialized
INFO - 2016-11-09 16:50:53 --> Output Class Initialized
INFO - 2016-11-09 16:50:53 --> Security Class Initialized
DEBUG - 2016-11-09 16:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:50:53 --> Input Class Initialized
INFO - 2016-11-09 16:50:53 --> Language Class Initialized
ERROR - 2016-11-09 16:50:53 --> Severity: Parsing Error --> syntax error, unexpected '$queryEmployee' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Auth.php 56
INFO - 2016-11-09 16:51:09 --> Config Class Initialized
INFO - 2016-11-09 16:51:09 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:51:09 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:51:09 --> Utf8 Class Initialized
INFO - 2016-11-09 16:51:09 --> URI Class Initialized
DEBUG - 2016-11-09 16:51:09 --> No URI present. Default controller set.
INFO - 2016-11-09 16:51:09 --> Router Class Initialized
INFO - 2016-11-09 16:51:09 --> Output Class Initialized
INFO - 2016-11-09 16:51:09 --> Security Class Initialized
DEBUG - 2016-11-09 16:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:51:09 --> Input Class Initialized
INFO - 2016-11-09 16:51:09 --> Language Class Initialized
INFO - 2016-11-09 16:51:09 --> Loader Class Initialized
INFO - 2016-11-09 16:51:09 --> Helper loaded: url_helper
INFO - 2016-11-09 16:51:09 --> Helper loaded: form_helper
INFO - 2016-11-09 16:51:09 --> Database Driver Class Initialized
INFO - 2016-11-09 16:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:51:09 --> Controller Class Initialized
INFO - 2016-11-09 16:51:09 --> Model Class Initialized
INFO - 2016-11-09 16:51:09 --> Model Class Initialized
INFO - 2016-11-09 16:51:09 --> Model Class Initialized
INFO - 2016-11-09 16:51:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:51:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:51:41 --> Config Class Initialized
INFO - 2016-11-09 16:51:41 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:51:41 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:51:41 --> Utf8 Class Initialized
INFO - 2016-11-09 16:51:41 --> URI Class Initialized
DEBUG - 2016-11-09 16:51:41 --> No URI present. Default controller set.
INFO - 2016-11-09 16:51:41 --> Router Class Initialized
INFO - 2016-11-09 16:51:41 --> Output Class Initialized
INFO - 2016-11-09 16:51:41 --> Security Class Initialized
DEBUG - 2016-11-09 16:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:51:41 --> Input Class Initialized
INFO - 2016-11-09 16:51:41 --> Language Class Initialized
INFO - 2016-11-09 16:51:41 --> Loader Class Initialized
INFO - 2016-11-09 16:51:41 --> Helper loaded: url_helper
INFO - 2016-11-09 16:51:41 --> Helper loaded: form_helper
INFO - 2016-11-09 16:51:41 --> Database Driver Class Initialized
INFO - 2016-11-09 16:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:51:41 --> Controller Class Initialized
INFO - 2016-11-09 16:51:41 --> Model Class Initialized
INFO - 2016-11-09 16:51:41 --> Model Class Initialized
INFO - 2016-11-09 16:51:41 --> Model Class Initialized
INFO - 2016-11-09 16:51:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:51:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:52:06 --> Config Class Initialized
INFO - 2016-11-09 16:52:06 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:52:06 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:52:06 --> Utf8 Class Initialized
INFO - 2016-11-09 16:52:06 --> URI Class Initialized
DEBUG - 2016-11-09 16:52:06 --> No URI present. Default controller set.
INFO - 2016-11-09 16:52:06 --> Router Class Initialized
INFO - 2016-11-09 16:52:06 --> Output Class Initialized
INFO - 2016-11-09 16:52:06 --> Security Class Initialized
DEBUG - 2016-11-09 16:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:52:06 --> Input Class Initialized
INFO - 2016-11-09 16:52:06 --> Language Class Initialized
INFO - 2016-11-09 16:52:06 --> Loader Class Initialized
INFO - 2016-11-09 16:52:06 --> Helper loaded: url_helper
INFO - 2016-11-09 16:52:06 --> Helper loaded: form_helper
INFO - 2016-11-09 16:52:06 --> Database Driver Class Initialized
INFO - 2016-11-09 16:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:52:06 --> Controller Class Initialized
INFO - 2016-11-09 16:52:06 --> Model Class Initialized
INFO - 2016-11-09 16:52:06 --> Model Class Initialized
INFO - 2016-11-09 16:52:06 --> Model Class Initialized
INFO - 2016-11-09 16:52:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:52:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 16:58:33 --> Config Class Initialized
INFO - 2016-11-09 16:58:33 --> Hooks Class Initialized
DEBUG - 2016-11-09 16:58:33 --> UTF-8 Support Enabled
INFO - 2016-11-09 16:58:33 --> Utf8 Class Initialized
INFO - 2016-11-09 16:58:33 --> URI Class Initialized
DEBUG - 2016-11-09 16:58:33 --> No URI present. Default controller set.
INFO - 2016-11-09 16:58:33 --> Router Class Initialized
INFO - 2016-11-09 16:58:33 --> Output Class Initialized
INFO - 2016-11-09 16:58:33 --> Security Class Initialized
DEBUG - 2016-11-09 16:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 16:58:33 --> Input Class Initialized
INFO - 2016-11-09 16:58:33 --> Language Class Initialized
INFO - 2016-11-09 16:58:33 --> Loader Class Initialized
INFO - 2016-11-09 16:58:33 --> Helper loaded: url_helper
INFO - 2016-11-09 16:58:33 --> Helper loaded: form_helper
INFO - 2016-11-09 16:58:33 --> Database Driver Class Initialized
INFO - 2016-11-09 16:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 16:58:33 --> Controller Class Initialized
INFO - 2016-11-09 16:58:33 --> Model Class Initialized
INFO - 2016-11-09 16:58:33 --> Model Class Initialized
INFO - 2016-11-09 16:58:33 --> Model Class Initialized
INFO - 2016-11-09 16:58:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 16:58:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-09 16:58:33 --> Severity: Warning --> Missing argument 2 for Leave_application_m::all_leave_application(), called in C:\xampp\htdocs\LMS\app\controllers\Auth.php on line 59 and defined C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 7
INFO - 2016-11-09 16:58:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 16:58:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 16:58:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 16:58:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 16:58:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 16:58:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 16:58:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 16:58:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 16:58:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 16:58:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 16:58:33 --> Final output sent to browser
DEBUG - 2016-11-09 16:58:33 --> Total execution time: 0.5028
INFO - 2016-11-09 17:01:01 --> Config Class Initialized
INFO - 2016-11-09 17:01:01 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:01:01 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:01:01 --> Utf8 Class Initialized
INFO - 2016-11-09 17:01:01 --> URI Class Initialized
DEBUG - 2016-11-09 17:01:01 --> No URI present. Default controller set.
INFO - 2016-11-09 17:01:01 --> Router Class Initialized
INFO - 2016-11-09 17:01:01 --> Output Class Initialized
INFO - 2016-11-09 17:01:01 --> Security Class Initialized
DEBUG - 2016-11-09 17:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:01:01 --> Input Class Initialized
INFO - 2016-11-09 17:01:01 --> Language Class Initialized
INFO - 2016-11-09 17:01:01 --> Loader Class Initialized
INFO - 2016-11-09 17:01:01 --> Helper loaded: url_helper
INFO - 2016-11-09 17:01:01 --> Helper loaded: form_helper
INFO - 2016-11-09 17:01:01 --> Database Driver Class Initialized
INFO - 2016-11-09 17:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:01:01 --> Controller Class Initialized
INFO - 2016-11-09 17:01:01 --> Model Class Initialized
INFO - 2016-11-09 17:01:01 --> Model Class Initialized
INFO - 2016-11-09 17:01:01 --> Model Class Initialized
INFO - 2016-11-09 17:01:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:01:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-09 17:01:01 --> Severity: Warning --> Missing argument 2 for Leave_application_m::all_leave_application(), called in C:\xampp\htdocs\LMS\app\controllers\Auth.php on line 59 and defined C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 7
INFO - 2016-11-09 17:01:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 17:01:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 17:01:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 17:01:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 17:01:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 17:01:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 17:01:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 17:01:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 17:01:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 17:01:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 17:01:01 --> Final output sent to browser
DEBUG - 2016-11-09 17:01:01 --> Total execution time: 0.5017
INFO - 2016-11-09 17:01:56 --> Config Class Initialized
INFO - 2016-11-09 17:01:56 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:01:56 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:01:56 --> Utf8 Class Initialized
INFO - 2016-11-09 17:01:56 --> URI Class Initialized
DEBUG - 2016-11-09 17:01:57 --> No URI present. Default controller set.
INFO - 2016-11-09 17:01:57 --> Router Class Initialized
INFO - 2016-11-09 17:01:57 --> Output Class Initialized
INFO - 2016-11-09 17:01:57 --> Security Class Initialized
DEBUG - 2016-11-09 17:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:01:57 --> Input Class Initialized
INFO - 2016-11-09 17:01:57 --> Language Class Initialized
INFO - 2016-11-09 17:01:57 --> Loader Class Initialized
INFO - 2016-11-09 17:01:57 --> Helper loaded: url_helper
INFO - 2016-11-09 17:01:57 --> Helper loaded: form_helper
INFO - 2016-11-09 17:01:57 --> Database Driver Class Initialized
INFO - 2016-11-09 17:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:01:57 --> Controller Class Initialized
INFO - 2016-11-09 17:01:57 --> Model Class Initialized
INFO - 2016-11-09 17:01:57 --> Model Class Initialized
INFO - 2016-11-09 17:01:57 --> Model Class Initialized
INFO - 2016-11-09 17:01:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:01:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-09 17:01:57 --> Severity: Warning --> Missing argument 2 for Leave_application_m::all_leave_application(), called in C:\xampp\htdocs\LMS\app\controllers\Auth.php on line 59 and defined C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 7
INFO - 2016-11-09 17:01:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 17:01:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 17:01:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 17:01:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 17:01:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 17:01:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 17:01:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 17:01:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 17:01:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 17:01:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 17:01:57 --> Final output sent to browser
DEBUG - 2016-11-09 17:01:57 --> Total execution time: 0.4851
INFO - 2016-11-09 17:03:23 --> Config Class Initialized
INFO - 2016-11-09 17:03:23 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:03:23 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:03:23 --> Utf8 Class Initialized
INFO - 2016-11-09 17:03:23 --> URI Class Initialized
DEBUG - 2016-11-09 17:03:23 --> No URI present. Default controller set.
INFO - 2016-11-09 17:03:23 --> Router Class Initialized
INFO - 2016-11-09 17:03:23 --> Output Class Initialized
INFO - 2016-11-09 17:03:23 --> Security Class Initialized
DEBUG - 2016-11-09 17:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:03:23 --> Input Class Initialized
INFO - 2016-11-09 17:03:23 --> Language Class Initialized
INFO - 2016-11-09 17:03:23 --> Loader Class Initialized
INFO - 2016-11-09 17:03:23 --> Helper loaded: url_helper
INFO - 2016-11-09 17:03:23 --> Helper loaded: form_helper
INFO - 2016-11-09 17:03:23 --> Database Driver Class Initialized
INFO - 2016-11-09 17:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:03:23 --> Controller Class Initialized
INFO - 2016-11-09 17:03:23 --> Model Class Initialized
INFO - 2016-11-09 17:03:23 --> Model Class Initialized
INFO - 2016-11-09 17:03:23 --> Model Class Initialized
INFO - 2016-11-09 17:03:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:03:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-09 17:03:23 --> Severity: Notice --> Undefined variable: limit C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 8
INFO - 2016-11-09 17:03:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 17:03:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
ERROR - 2016-11-09 17:03:23 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result() C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 13
INFO - 2016-11-09 17:03:45 --> Config Class Initialized
INFO - 2016-11-09 17:03:45 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:03:45 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:03:45 --> Utf8 Class Initialized
INFO - 2016-11-09 17:03:45 --> URI Class Initialized
DEBUG - 2016-11-09 17:03:45 --> No URI present. Default controller set.
INFO - 2016-11-09 17:03:45 --> Router Class Initialized
INFO - 2016-11-09 17:03:45 --> Output Class Initialized
INFO - 2016-11-09 17:03:45 --> Security Class Initialized
DEBUG - 2016-11-09 17:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:03:45 --> Input Class Initialized
INFO - 2016-11-09 17:03:45 --> Language Class Initialized
INFO - 2016-11-09 17:03:45 --> Loader Class Initialized
INFO - 2016-11-09 17:03:45 --> Helper loaded: url_helper
INFO - 2016-11-09 17:03:45 --> Helper loaded: form_helper
INFO - 2016-11-09 17:03:45 --> Database Driver Class Initialized
INFO - 2016-11-09 17:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:03:45 --> Controller Class Initialized
INFO - 2016-11-09 17:03:45 --> Model Class Initialized
INFO - 2016-11-09 17:03:45 --> Model Class Initialized
INFO - 2016-11-09 17:03:45 --> Model Class Initialized
INFO - 2016-11-09 17:03:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:03:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-09 17:03:45 --> Severity: Warning --> Missing argument 2 for Leave_application_m::all_leave_application(), called in C:\xampp\htdocs\LMS\app\controllers\Auth.php on line 59 and defined C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 7
ERROR - 2016-11-09 17:03:45 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 11
INFO - 2016-11-09 17:03:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 17:03:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
ERROR - 2016-11-09 17:03:45 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result() C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 13
INFO - 2016-11-09 17:04:02 --> Config Class Initialized
INFO - 2016-11-09 17:04:02 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:04:02 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:04:02 --> Utf8 Class Initialized
INFO - 2016-11-09 17:04:02 --> URI Class Initialized
DEBUG - 2016-11-09 17:04:02 --> No URI present. Default controller set.
INFO - 2016-11-09 17:04:02 --> Router Class Initialized
INFO - 2016-11-09 17:04:03 --> Output Class Initialized
INFO - 2016-11-09 17:04:03 --> Security Class Initialized
DEBUG - 2016-11-09 17:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:04:03 --> Input Class Initialized
INFO - 2016-11-09 17:04:03 --> Language Class Initialized
INFO - 2016-11-09 17:04:03 --> Loader Class Initialized
INFO - 2016-11-09 17:04:03 --> Helper loaded: url_helper
INFO - 2016-11-09 17:04:03 --> Helper loaded: form_helper
INFO - 2016-11-09 17:04:03 --> Database Driver Class Initialized
INFO - 2016-11-09 17:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:04:03 --> Controller Class Initialized
INFO - 2016-11-09 17:04:03 --> Model Class Initialized
INFO - 2016-11-09 17:04:03 --> Model Class Initialized
INFO - 2016-11-09 17:04:03 --> Model Class Initialized
INFO - 2016-11-09 17:04:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:04:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 17:04:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 17:04:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
ERROR - 2016-11-09 17:04:03 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result() C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 13
INFO - 2016-11-09 17:15:05 --> Config Class Initialized
INFO - 2016-11-09 17:15:05 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:15:05 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:15:05 --> Utf8 Class Initialized
INFO - 2016-11-09 17:15:05 --> URI Class Initialized
DEBUG - 2016-11-09 17:15:05 --> No URI present. Default controller set.
INFO - 2016-11-09 17:15:05 --> Router Class Initialized
INFO - 2016-11-09 17:15:05 --> Output Class Initialized
INFO - 2016-11-09 17:15:05 --> Security Class Initialized
DEBUG - 2016-11-09 17:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:15:05 --> Input Class Initialized
INFO - 2016-11-09 17:15:05 --> Language Class Initialized
INFO - 2016-11-09 17:15:05 --> Loader Class Initialized
INFO - 2016-11-09 17:15:05 --> Helper loaded: url_helper
INFO - 2016-11-09 17:15:05 --> Helper loaded: form_helper
INFO - 2016-11-09 17:15:05 --> Database Driver Class Initialized
INFO - 2016-11-09 17:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:15:05 --> Controller Class Initialized
INFO - 2016-11-09 17:15:05 --> Model Class Initialized
INFO - 2016-11-09 17:15:05 --> Model Class Initialized
INFO - 2016-11-09 17:15:05 --> Model Class Initialized
INFO - 2016-11-09 17:15:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:15:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 17:15:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 17:15:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
ERROR - 2016-11-09 17:15:05 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result() C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 13
INFO - 2016-11-09 17:15:25 --> Config Class Initialized
INFO - 2016-11-09 17:15:25 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:15:25 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:15:25 --> Utf8 Class Initialized
INFO - 2016-11-09 17:15:25 --> URI Class Initialized
DEBUG - 2016-11-09 17:15:25 --> No URI present. Default controller set.
INFO - 2016-11-09 17:15:25 --> Router Class Initialized
INFO - 2016-11-09 17:15:25 --> Output Class Initialized
INFO - 2016-11-09 17:15:25 --> Security Class Initialized
DEBUG - 2016-11-09 17:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:15:25 --> Input Class Initialized
INFO - 2016-11-09 17:15:25 --> Language Class Initialized
INFO - 2016-11-09 17:15:25 --> Loader Class Initialized
INFO - 2016-11-09 17:15:25 --> Helper loaded: url_helper
INFO - 2016-11-09 17:15:25 --> Helper loaded: form_helper
INFO - 2016-11-09 17:15:25 --> Database Driver Class Initialized
INFO - 2016-11-09 17:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:15:25 --> Controller Class Initialized
INFO - 2016-11-09 17:15:25 --> Model Class Initialized
INFO - 2016-11-09 17:15:25 --> Model Class Initialized
INFO - 2016-11-09 17:15:25 --> Model Class Initialized
INFO - 2016-11-09 17:15:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:15:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 17:15:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 17:15:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
ERROR - 2016-11-09 17:15:25 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result() C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 14
INFO - 2016-11-09 17:16:09 --> Config Class Initialized
INFO - 2016-11-09 17:16:09 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:16:09 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:16:09 --> Utf8 Class Initialized
INFO - 2016-11-09 17:16:09 --> URI Class Initialized
DEBUG - 2016-11-09 17:16:09 --> No URI present. Default controller set.
INFO - 2016-11-09 17:16:09 --> Router Class Initialized
INFO - 2016-11-09 17:16:09 --> Output Class Initialized
INFO - 2016-11-09 17:16:09 --> Security Class Initialized
DEBUG - 2016-11-09 17:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:16:09 --> Input Class Initialized
INFO - 2016-11-09 17:16:09 --> Language Class Initialized
INFO - 2016-11-09 17:16:09 --> Loader Class Initialized
INFO - 2016-11-09 17:16:09 --> Helper loaded: url_helper
INFO - 2016-11-09 17:16:09 --> Helper loaded: form_helper
INFO - 2016-11-09 17:16:09 --> Database Driver Class Initialized
INFO - 2016-11-09 17:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:16:09 --> Controller Class Initialized
INFO - 2016-11-09 17:16:09 --> Model Class Initialized
INFO - 2016-11-09 17:16:09 --> Model Class Initialized
INFO - 2016-11-09 17:16:09 --> Model Class Initialized
INFO - 2016-11-09 17:16:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:16:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 17:16:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 17:16:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
ERROR - 2016-11-09 17:16:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Undefined property: mysqli::$startDate C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Undefined property: mysqli::$endDate C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Undefined property: mysqli::$applicationDate C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Undefined property: mysqli::$numberOfDays C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Undefined property: mysqli_result::$startDate C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Undefined property: mysqli_result::$endDate C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Undefined property: mysqli_result::$applicationDate C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:10 --> Severity: Notice --> Undefined property: mysqli_result::$numberOfDays C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:16:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
INFO - 2016-11-09 17:16:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 17:16:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 17:16:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 17:16:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 17:16:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 17:16:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 17:16:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 17:16:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 17:16:11 --> Final output sent to browser
DEBUG - 2016-11-09 17:16:11 --> Total execution time: 2.3356
INFO - 2016-11-09 17:21:30 --> Config Class Initialized
INFO - 2016-11-09 17:21:30 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:21:30 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:21:30 --> Utf8 Class Initialized
INFO - 2016-11-09 17:21:30 --> URI Class Initialized
DEBUG - 2016-11-09 17:21:30 --> No URI present. Default controller set.
INFO - 2016-11-09 17:21:30 --> Router Class Initialized
INFO - 2016-11-09 17:21:30 --> Output Class Initialized
INFO - 2016-11-09 17:21:30 --> Security Class Initialized
DEBUG - 2016-11-09 17:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:21:30 --> Input Class Initialized
INFO - 2016-11-09 17:21:30 --> Language Class Initialized
INFO - 2016-11-09 17:21:30 --> Loader Class Initialized
INFO - 2016-11-09 17:21:30 --> Helper loaded: url_helper
INFO - 2016-11-09 17:21:30 --> Helper loaded: form_helper
INFO - 2016-11-09 17:21:30 --> Database Driver Class Initialized
INFO - 2016-11-09 17:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:21:30 --> Controller Class Initialized
INFO - 2016-11-09 17:21:30 --> Model Class Initialized
INFO - 2016-11-09 17:21:30 --> Model Class Initialized
INFO - 2016-11-09 17:21:30 --> Model Class Initialized
INFO - 2016-11-09 17:21:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:21:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 17:21:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 17:21:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
ERROR - 2016-11-09 17:21:30 --> Severity: Notice --> Undefined property: mysqli::$startDate C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:21:30 --> Severity: Notice --> Undefined property: mysqli::$endDate C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:21:30 --> Severity: Notice --> Undefined property: mysqli::$applicationDate C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:21:30 --> Severity: Notice --> Undefined property: mysqli::$numberOfDays C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Undefined property: mysqli_result::$startDate C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Undefined property: mysqli_result::$endDate C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Undefined property: mysqli_result::$applicationDate C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Undefined property: mysqli_result::$numberOfDays C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
INFO - 2016-11-09 17:21:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 17:21:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 17:21:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 17:21:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 17:21:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 17:21:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 17:21:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 17:21:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 17:21:31 --> Final output sent to browser
DEBUG - 2016-11-09 17:21:31 --> Total execution time: 0.9555
INFO - 2016-11-09 17:22:30 --> Config Class Initialized
INFO - 2016-11-09 17:22:30 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:22:30 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:22:30 --> Utf8 Class Initialized
INFO - 2016-11-09 17:22:30 --> URI Class Initialized
DEBUG - 2016-11-09 17:22:30 --> No URI present. Default controller set.
INFO - 2016-11-09 17:22:30 --> Router Class Initialized
INFO - 2016-11-09 17:22:30 --> Output Class Initialized
INFO - 2016-11-09 17:22:30 --> Security Class Initialized
DEBUG - 2016-11-09 17:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:22:30 --> Input Class Initialized
INFO - 2016-11-09 17:22:30 --> Language Class Initialized
INFO - 2016-11-09 17:22:30 --> Loader Class Initialized
INFO - 2016-11-09 17:22:30 --> Helper loaded: url_helper
INFO - 2016-11-09 17:22:30 --> Helper loaded: form_helper
INFO - 2016-11-09 17:22:30 --> Database Driver Class Initialized
INFO - 2016-11-09 17:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:22:31 --> Controller Class Initialized
INFO - 2016-11-09 17:22:31 --> Model Class Initialized
INFO - 2016-11-09 17:22:31 --> Model Class Initialized
INFO - 2016-11-09 17:22:31 --> Model Class Initialized
INFO - 2016-11-09 17:22:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:22:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-09 17:22:31 --> Query error: Not unique table/alias: 'applicationData' - Invalid query: SELECT *
FROM `applicationData`, `applicationData`
WHERE `idEmployee` = '18'
INFO - 2016-11-09 17:22:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-09 17:22:44 --> Config Class Initialized
INFO - 2016-11-09 17:22:44 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:22:44 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:22:44 --> Utf8 Class Initialized
INFO - 2016-11-09 17:22:44 --> URI Class Initialized
DEBUG - 2016-11-09 17:22:44 --> No URI present. Default controller set.
INFO - 2016-11-09 17:22:44 --> Router Class Initialized
INFO - 2016-11-09 17:22:44 --> Output Class Initialized
INFO - 2016-11-09 17:22:44 --> Security Class Initialized
DEBUG - 2016-11-09 17:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:22:44 --> Input Class Initialized
INFO - 2016-11-09 17:22:44 --> Language Class Initialized
INFO - 2016-11-09 17:22:44 --> Loader Class Initialized
INFO - 2016-11-09 17:22:44 --> Helper loaded: url_helper
INFO - 2016-11-09 17:22:44 --> Helper loaded: form_helper
INFO - 2016-11-09 17:22:44 --> Database Driver Class Initialized
INFO - 2016-11-09 17:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:22:44 --> Controller Class Initialized
INFO - 2016-11-09 17:22:44 --> Model Class Initialized
INFO - 2016-11-09 17:22:44 --> Model Class Initialized
INFO - 2016-11-09 17:22:44 --> Model Class Initialized
INFO - 2016-11-09 17:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 17:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 17:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
ERROR - 2016-11-09 17:22:44 --> Severity: Notice --> Undefined property: mysqli::$startDate C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:22:44 --> Severity: Notice --> Undefined property: mysqli::$endDate C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:22:44 --> Severity: Notice --> Undefined property: mysqli::$applicationDate C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:22:44 --> Severity: Notice --> Undefined property: mysqli::$numberOfDays C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:22:44 --> Severity: Notice --> Undefined property: mysqli_result::$startDate C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:22:44 --> Severity: Notice --> Undefined property: mysqli_result::$endDate C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:22:44 --> Severity: Notice --> Undefined property: mysqli_result::$applicationDate C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:22:45 --> Severity: Notice --> Undefined property: mysqli_result::$numberOfDays C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:22:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:22:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:22:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:22:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:22:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:22:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:22:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:22:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:22:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:22:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:22:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:22:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:22:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:22:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:22:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:22:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:22:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:22:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:22:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:22:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
ERROR - 2016-11-09 17:22:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 17
ERROR - 2016-11-09 17:22:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 18
ERROR - 2016-11-09 17:22:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 19
ERROR - 2016-11-09 17:22:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 20
INFO - 2016-11-09 17:22:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 17:22:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 17:22:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 17:22:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 17:22:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 17:22:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 17:22:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 17:22:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 17:22:45 --> Final output sent to browser
DEBUG - 2016-11-09 17:22:45 --> Total execution time: 0.9619
INFO - 2016-11-09 17:23:02 --> Config Class Initialized
INFO - 2016-11-09 17:23:02 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:23:02 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:23:02 --> Utf8 Class Initialized
INFO - 2016-11-09 17:23:02 --> URI Class Initialized
DEBUG - 2016-11-09 17:23:02 --> No URI present. Default controller set.
INFO - 2016-11-09 17:23:02 --> Router Class Initialized
INFO - 2016-11-09 17:23:02 --> Output Class Initialized
INFO - 2016-11-09 17:23:02 --> Security Class Initialized
DEBUG - 2016-11-09 17:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:23:02 --> Input Class Initialized
INFO - 2016-11-09 17:23:02 --> Language Class Initialized
INFO - 2016-11-09 17:23:02 --> Loader Class Initialized
INFO - 2016-11-09 17:23:02 --> Helper loaded: url_helper
INFO - 2016-11-09 17:23:02 --> Helper loaded: form_helper
INFO - 2016-11-09 17:23:02 --> Database Driver Class Initialized
INFO - 2016-11-09 17:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:23:02 --> Controller Class Initialized
INFO - 2016-11-09 17:23:02 --> Model Class Initialized
INFO - 2016-11-09 17:23:02 --> Model Class Initialized
INFO - 2016-11-09 17:23:02 --> Model Class Initialized
INFO - 2016-11-09 17:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 17:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 17:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 17:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 17:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 17:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 17:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 17:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 17:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 17:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 17:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 17:23:02 --> Final output sent to browser
DEBUG - 2016-11-09 17:23:02 --> Total execution time: 0.5031
INFO - 2016-11-09 17:23:18 --> Config Class Initialized
INFO - 2016-11-09 17:23:18 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:23:18 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:23:18 --> Utf8 Class Initialized
INFO - 2016-11-09 17:23:18 --> URI Class Initialized
INFO - 2016-11-09 17:23:18 --> Router Class Initialized
INFO - 2016-11-09 17:23:18 --> Output Class Initialized
INFO - 2016-11-09 17:23:18 --> Security Class Initialized
DEBUG - 2016-11-09 17:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:23:18 --> Input Class Initialized
INFO - 2016-11-09 17:23:18 --> Language Class Initialized
INFO - 2016-11-09 17:23:18 --> Loader Class Initialized
INFO - 2016-11-09 17:23:18 --> Helper loaded: url_helper
INFO - 2016-11-09 17:23:18 --> Helper loaded: form_helper
INFO - 2016-11-09 17:23:18 --> Database Driver Class Initialized
INFO - 2016-11-09 17:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:23:18 --> Controller Class Initialized
INFO - 2016-11-09 17:23:18 --> Model Class Initialized
INFO - 2016-11-09 17:23:18 --> Model Class Initialized
INFO - 2016-11-09 17:23:18 --> Model Class Initialized
DEBUG - 2016-11-09 17:23:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-09 17:23:18 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 124
ERROR - 2016-11-09 17:23:18 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 124
INFO - 2016-11-09 17:23:18 --> Config Class Initialized
INFO - 2016-11-09 17:23:18 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:23:18 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:23:18 --> Utf8 Class Initialized
INFO - 2016-11-09 17:23:18 --> URI Class Initialized
DEBUG - 2016-11-09 17:23:18 --> No URI present. Default controller set.
INFO - 2016-11-09 17:23:18 --> Router Class Initialized
INFO - 2016-11-09 17:23:18 --> Output Class Initialized
INFO - 2016-11-09 17:23:18 --> Security Class Initialized
DEBUG - 2016-11-09 17:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:23:18 --> Input Class Initialized
INFO - 2016-11-09 17:23:18 --> Language Class Initialized
INFO - 2016-11-09 17:23:18 --> Loader Class Initialized
INFO - 2016-11-09 17:23:18 --> Helper loaded: url_helper
INFO - 2016-11-09 17:23:18 --> Helper loaded: form_helper
INFO - 2016-11-09 17:23:18 --> Database Driver Class Initialized
INFO - 2016-11-09 17:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:23:18 --> Controller Class Initialized
INFO - 2016-11-09 17:23:18 --> Model Class Initialized
INFO - 2016-11-09 17:23:18 --> Model Class Initialized
INFO - 2016-11-09 17:23:18 --> Model Class Initialized
INFO - 2016-11-09 17:23:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:23:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-09 17:23:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 17:23:18 --> Final output sent to browser
DEBUG - 2016-11-09 17:23:18 --> Total execution time: 0.3616
INFO - 2016-11-09 17:23:29 --> Config Class Initialized
INFO - 2016-11-09 17:23:29 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:23:29 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:23:29 --> Utf8 Class Initialized
INFO - 2016-11-09 17:23:29 --> URI Class Initialized
INFO - 2016-11-09 17:23:29 --> Router Class Initialized
INFO - 2016-11-09 17:23:29 --> Output Class Initialized
INFO - 2016-11-09 17:23:29 --> Security Class Initialized
DEBUG - 2016-11-09 17:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:23:30 --> Input Class Initialized
INFO - 2016-11-09 17:23:30 --> Language Class Initialized
INFO - 2016-11-09 17:23:30 --> Loader Class Initialized
INFO - 2016-11-09 17:23:30 --> Helper loaded: url_helper
INFO - 2016-11-09 17:23:30 --> Helper loaded: form_helper
INFO - 2016-11-09 17:23:30 --> Database Driver Class Initialized
INFO - 2016-11-09 17:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:23:30 --> Controller Class Initialized
INFO - 2016-11-09 17:23:30 --> Model Class Initialized
INFO - 2016-11-09 17:23:30 --> Model Class Initialized
INFO - 2016-11-09 17:23:30 --> Model Class Initialized
DEBUG - 2016-11-09 17:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-09 17:23:30 --> Model Class Initialized
INFO - 2016-11-09 17:23:30 --> Final output sent to browser
DEBUG - 2016-11-09 17:23:30 --> Total execution time: 0.3305
INFO - 2016-11-09 17:23:30 --> Config Class Initialized
INFO - 2016-11-09 17:23:30 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:23:30 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:23:30 --> Utf8 Class Initialized
INFO - 2016-11-09 17:23:30 --> URI Class Initialized
DEBUG - 2016-11-09 17:23:30 --> No URI present. Default controller set.
INFO - 2016-11-09 17:23:30 --> Router Class Initialized
INFO - 2016-11-09 17:23:30 --> Output Class Initialized
INFO - 2016-11-09 17:23:30 --> Security Class Initialized
DEBUG - 2016-11-09 17:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:23:30 --> Input Class Initialized
INFO - 2016-11-09 17:23:30 --> Language Class Initialized
INFO - 2016-11-09 17:23:30 --> Loader Class Initialized
INFO - 2016-11-09 17:23:30 --> Helper loaded: url_helper
INFO - 2016-11-09 17:23:30 --> Helper loaded: form_helper
INFO - 2016-11-09 17:23:30 --> Database Driver Class Initialized
INFO - 2016-11-09 17:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:23:30 --> Controller Class Initialized
INFO - 2016-11-09 17:23:30 --> Model Class Initialized
INFO - 2016-11-09 17:23:30 --> Model Class Initialized
INFO - 2016-11-09 17:23:30 --> Model Class Initialized
INFO - 2016-11-09 17:23:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:23:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 17:23:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 17:23:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 17:23:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 17:23:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 17:23:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 17:23:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 17:23:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 17:23:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 17:23:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 17:23:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 17:23:30 --> Final output sent to browser
DEBUG - 2016-11-09 17:23:30 --> Total execution time: 0.5295
INFO - 2016-11-09 17:24:13 --> Config Class Initialized
INFO - 2016-11-09 17:24:13 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:24:13 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:24:13 --> Utf8 Class Initialized
INFO - 2016-11-09 17:24:13 --> URI Class Initialized
DEBUG - 2016-11-09 17:24:13 --> No URI present. Default controller set.
INFO - 2016-11-09 17:24:13 --> Router Class Initialized
INFO - 2016-11-09 17:24:13 --> Output Class Initialized
INFO - 2016-11-09 17:24:13 --> Security Class Initialized
DEBUG - 2016-11-09 17:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:24:13 --> Input Class Initialized
INFO - 2016-11-09 17:24:13 --> Language Class Initialized
INFO - 2016-11-09 17:24:13 --> Loader Class Initialized
INFO - 2016-11-09 17:24:13 --> Helper loaded: url_helper
INFO - 2016-11-09 17:24:13 --> Helper loaded: form_helper
INFO - 2016-11-09 17:24:13 --> Database Driver Class Initialized
INFO - 2016-11-09 17:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:24:13 --> Controller Class Initialized
INFO - 2016-11-09 17:24:13 --> Model Class Initialized
INFO - 2016-11-09 17:24:14 --> Model Class Initialized
INFO - 2016-11-09 17:24:14 --> Model Class Initialized
INFO - 2016-11-09 17:24:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:24:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-09 17:24:14 --> Severity: Warning --> Missing argument 1 for Leave_application_m::all_leave_application(), called in C:\xampp\htdocs\LMS\app\controllers\Auth.php on line 59 and defined C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 7
ERROR - 2016-11-09 17:24:14 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 11
INFO - 2016-11-09 17:24:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 17:24:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 17:24:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 17:24:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 17:24:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 17:24:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 17:24:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 17:24:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 17:24:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 17:24:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 17:24:14 --> Final output sent to browser
DEBUG - 2016-11-09 17:24:14 --> Total execution time: 0.5907
INFO - 2016-11-09 17:24:21 --> Config Class Initialized
INFO - 2016-11-09 17:24:21 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:24:21 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:24:21 --> Utf8 Class Initialized
INFO - 2016-11-09 17:24:21 --> URI Class Initialized
DEBUG - 2016-11-09 17:24:21 --> No URI present. Default controller set.
INFO - 2016-11-09 17:24:22 --> Router Class Initialized
INFO - 2016-11-09 17:24:22 --> Output Class Initialized
INFO - 2016-11-09 17:24:22 --> Security Class Initialized
DEBUG - 2016-11-09 17:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:24:22 --> Input Class Initialized
INFO - 2016-11-09 17:24:22 --> Language Class Initialized
INFO - 2016-11-09 17:24:22 --> Loader Class Initialized
INFO - 2016-11-09 17:24:22 --> Helper loaded: url_helper
INFO - 2016-11-09 17:24:22 --> Helper loaded: form_helper
INFO - 2016-11-09 17:24:22 --> Database Driver Class Initialized
INFO - 2016-11-09 17:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:24:22 --> Controller Class Initialized
INFO - 2016-11-09 17:24:22 --> Model Class Initialized
INFO - 2016-11-09 17:24:22 --> Model Class Initialized
INFO - 2016-11-09 17:24:22 --> Model Class Initialized
INFO - 2016-11-09 17:24:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:24:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 17:24:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 17:24:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 17:24:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 17:24:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 17:24:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 17:24:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 17:24:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 17:24:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 17:24:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 17:24:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 17:24:22 --> Final output sent to browser
DEBUG - 2016-11-09 17:24:22 --> Total execution time: 0.5516
INFO - 2016-11-09 17:24:35 --> Config Class Initialized
INFO - 2016-11-09 17:24:35 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:24:35 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:24:35 --> Utf8 Class Initialized
INFO - 2016-11-09 17:24:35 --> URI Class Initialized
DEBUG - 2016-11-09 17:24:35 --> No URI present. Default controller set.
INFO - 2016-11-09 17:24:35 --> Router Class Initialized
INFO - 2016-11-09 17:24:35 --> Output Class Initialized
INFO - 2016-11-09 17:24:35 --> Security Class Initialized
DEBUG - 2016-11-09 17:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:24:35 --> Input Class Initialized
INFO - 2016-11-09 17:24:35 --> Language Class Initialized
INFO - 2016-11-09 17:24:35 --> Loader Class Initialized
INFO - 2016-11-09 17:24:35 --> Helper loaded: url_helper
INFO - 2016-11-09 17:24:35 --> Helper loaded: form_helper
INFO - 2016-11-09 17:24:35 --> Database Driver Class Initialized
INFO - 2016-11-09 17:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:24:35 --> Controller Class Initialized
INFO - 2016-11-09 17:24:35 --> Model Class Initialized
INFO - 2016-11-09 17:24:35 --> Model Class Initialized
INFO - 2016-11-09 17:24:35 --> Model Class Initialized
INFO - 2016-11-09 17:24:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:24:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 17:24:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 17:24:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 17:24:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 17:24:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 17:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 17:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 17:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 17:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 17:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 17:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 17:24:36 --> Final output sent to browser
DEBUG - 2016-11-09 17:24:36 --> Total execution time: 0.5349
INFO - 2016-11-09 17:24:57 --> Config Class Initialized
INFO - 2016-11-09 17:24:57 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:24:57 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:24:57 --> Utf8 Class Initialized
INFO - 2016-11-09 17:24:57 --> URI Class Initialized
DEBUG - 2016-11-09 17:24:57 --> No URI present. Default controller set.
INFO - 2016-11-09 17:24:57 --> Router Class Initialized
INFO - 2016-11-09 17:24:57 --> Output Class Initialized
INFO - 2016-11-09 17:24:57 --> Security Class Initialized
DEBUG - 2016-11-09 17:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:24:57 --> Input Class Initialized
INFO - 2016-11-09 17:24:57 --> Language Class Initialized
INFO - 2016-11-09 17:24:57 --> Loader Class Initialized
INFO - 2016-11-09 17:24:57 --> Helper loaded: url_helper
INFO - 2016-11-09 17:24:57 --> Helper loaded: form_helper
INFO - 2016-11-09 17:24:57 --> Database Driver Class Initialized
INFO - 2016-11-09 17:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:24:57 --> Controller Class Initialized
INFO - 2016-11-09 17:24:57 --> Model Class Initialized
INFO - 2016-11-09 17:24:57 --> Model Class Initialized
INFO - 2016-11-09 17:24:57 --> Model Class Initialized
INFO - 2016-11-09 17:24:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:24:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 17:24:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 17:24:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 17:24:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 17:24:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 17:24:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 17:24:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 17:24:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 17:24:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 17:24:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 17:24:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 17:24:57 --> Final output sent to browser
DEBUG - 2016-11-09 17:24:57 --> Total execution time: 0.4926
INFO - 2016-11-09 17:25:36 --> Config Class Initialized
INFO - 2016-11-09 17:25:36 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:25:36 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:25:36 --> Utf8 Class Initialized
INFO - 2016-11-09 17:25:36 --> URI Class Initialized
INFO - 2016-11-09 17:25:36 --> Router Class Initialized
INFO - 2016-11-09 17:25:36 --> Output Class Initialized
INFO - 2016-11-09 17:25:36 --> Security Class Initialized
DEBUG - 2016-11-09 17:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:25:36 --> Input Class Initialized
INFO - 2016-11-09 17:25:36 --> Language Class Initialized
INFO - 2016-11-09 17:25:36 --> Loader Class Initialized
INFO - 2016-11-09 17:25:36 --> Helper loaded: url_helper
INFO - 2016-11-09 17:25:36 --> Helper loaded: form_helper
INFO - 2016-11-09 17:25:36 --> Database Driver Class Initialized
INFO - 2016-11-09 17:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:25:36 --> Controller Class Initialized
INFO - 2016-11-09 17:25:36 --> Model Class Initialized
INFO - 2016-11-09 17:25:36 --> Model Class Initialized
INFO - 2016-11-09 17:25:36 --> Model Class Initialized
DEBUG - 2016-11-09 17:25:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-09 17:25:36 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 124
ERROR - 2016-11-09 17:25:36 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 124
INFO - 2016-11-09 17:25:36 --> Config Class Initialized
INFO - 2016-11-09 17:25:36 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:25:36 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:25:36 --> Utf8 Class Initialized
INFO - 2016-11-09 17:25:36 --> URI Class Initialized
DEBUG - 2016-11-09 17:25:36 --> No URI present. Default controller set.
INFO - 2016-11-09 17:25:36 --> Router Class Initialized
INFO - 2016-11-09 17:25:36 --> Output Class Initialized
INFO - 2016-11-09 17:25:36 --> Security Class Initialized
DEBUG - 2016-11-09 17:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:25:36 --> Input Class Initialized
INFO - 2016-11-09 17:25:36 --> Language Class Initialized
INFO - 2016-11-09 17:25:36 --> Loader Class Initialized
INFO - 2016-11-09 17:25:36 --> Helper loaded: url_helper
INFO - 2016-11-09 17:25:36 --> Helper loaded: form_helper
INFO - 2016-11-09 17:25:36 --> Database Driver Class Initialized
INFO - 2016-11-09 17:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:25:36 --> Controller Class Initialized
INFO - 2016-11-09 17:25:36 --> Model Class Initialized
INFO - 2016-11-09 17:25:36 --> Model Class Initialized
INFO - 2016-11-09 17:25:36 --> Model Class Initialized
INFO - 2016-11-09 17:25:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:25:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-09 17:25:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 17:25:37 --> Final output sent to browser
DEBUG - 2016-11-09 17:25:37 --> Total execution time: 0.5640
INFO - 2016-11-09 17:26:19 --> Config Class Initialized
INFO - 2016-11-09 17:26:19 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:26:19 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:26:19 --> Utf8 Class Initialized
INFO - 2016-11-09 17:26:19 --> URI Class Initialized
INFO - 2016-11-09 17:26:19 --> Router Class Initialized
INFO - 2016-11-09 17:26:19 --> Output Class Initialized
INFO - 2016-11-09 17:26:19 --> Security Class Initialized
DEBUG - 2016-11-09 17:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:26:19 --> Input Class Initialized
INFO - 2016-11-09 17:26:19 --> Language Class Initialized
INFO - 2016-11-09 17:26:19 --> Loader Class Initialized
INFO - 2016-11-09 17:26:19 --> Helper loaded: url_helper
INFO - 2016-11-09 17:26:19 --> Helper loaded: form_helper
INFO - 2016-11-09 17:26:19 --> Database Driver Class Initialized
INFO - 2016-11-09 17:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:26:19 --> Controller Class Initialized
INFO - 2016-11-09 17:26:19 --> Model Class Initialized
INFO - 2016-11-09 17:26:19 --> Model Class Initialized
INFO - 2016-11-09 17:26:19 --> Model Class Initialized
DEBUG - 2016-11-09 17:26:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-09 17:26:19 --> Model Class Initialized
INFO - 2016-11-09 17:26:19 --> Final output sent to browser
DEBUG - 2016-11-09 17:26:19 --> Total execution time: 0.3358
INFO - 2016-11-09 17:26:19 --> Config Class Initialized
INFO - 2016-11-09 17:26:19 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:26:20 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:26:20 --> Utf8 Class Initialized
INFO - 2016-11-09 17:26:20 --> URI Class Initialized
DEBUG - 2016-11-09 17:26:20 --> No URI present. Default controller set.
INFO - 2016-11-09 17:26:20 --> Router Class Initialized
INFO - 2016-11-09 17:26:20 --> Output Class Initialized
INFO - 2016-11-09 17:26:20 --> Security Class Initialized
DEBUG - 2016-11-09 17:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:26:20 --> Input Class Initialized
INFO - 2016-11-09 17:26:20 --> Language Class Initialized
INFO - 2016-11-09 17:26:20 --> Loader Class Initialized
INFO - 2016-11-09 17:26:20 --> Helper loaded: url_helper
INFO - 2016-11-09 17:26:20 --> Helper loaded: form_helper
INFO - 2016-11-09 17:26:20 --> Database Driver Class Initialized
INFO - 2016-11-09 17:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:26:20 --> Controller Class Initialized
INFO - 2016-11-09 17:26:20 --> Model Class Initialized
INFO - 2016-11-09 17:26:20 --> Model Class Initialized
INFO - 2016-11-09 17:26:20 --> Model Class Initialized
INFO - 2016-11-09 17:26:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:26:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 17:26:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 17:26:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 17:26:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 17:26:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 17:26:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 17:26:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 17:26:20 --> Final output sent to browser
DEBUG - 2016-11-09 17:26:20 --> Total execution time: 0.6188
INFO - 2016-11-09 17:26:43 --> Config Class Initialized
INFO - 2016-11-09 17:26:43 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:26:43 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:26:43 --> Utf8 Class Initialized
INFO - 2016-11-09 17:26:43 --> URI Class Initialized
INFO - 2016-11-09 17:26:43 --> Router Class Initialized
INFO - 2016-11-09 17:26:43 --> Output Class Initialized
INFO - 2016-11-09 17:26:43 --> Security Class Initialized
DEBUG - 2016-11-09 17:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:26:43 --> Input Class Initialized
INFO - 2016-11-09 17:26:43 --> Language Class Initialized
INFO - 2016-11-09 17:26:43 --> Loader Class Initialized
INFO - 2016-11-09 17:26:43 --> Helper loaded: url_helper
INFO - 2016-11-09 17:26:43 --> Helper loaded: form_helper
INFO - 2016-11-09 17:26:43 --> Database Driver Class Initialized
INFO - 2016-11-09 17:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:26:43 --> Controller Class Initialized
INFO - 2016-11-09 17:26:43 --> Model Class Initialized
INFO - 2016-11-09 17:26:43 --> Model Class Initialized
INFO - 2016-11-09 17:26:43 --> Model Class Initialized
DEBUG - 2016-11-09 17:26:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-09 17:26:43 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 124
ERROR - 2016-11-09 17:26:43 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 124
INFO - 2016-11-09 17:26:44 --> Config Class Initialized
INFO - 2016-11-09 17:26:44 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:26:44 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:26:44 --> Utf8 Class Initialized
INFO - 2016-11-09 17:26:44 --> URI Class Initialized
DEBUG - 2016-11-09 17:26:44 --> No URI present. Default controller set.
INFO - 2016-11-09 17:26:44 --> Router Class Initialized
INFO - 2016-11-09 17:26:44 --> Output Class Initialized
INFO - 2016-11-09 17:26:44 --> Security Class Initialized
DEBUG - 2016-11-09 17:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:26:44 --> Input Class Initialized
INFO - 2016-11-09 17:26:44 --> Language Class Initialized
INFO - 2016-11-09 17:26:44 --> Loader Class Initialized
INFO - 2016-11-09 17:26:44 --> Helper loaded: url_helper
INFO - 2016-11-09 17:26:44 --> Helper loaded: form_helper
INFO - 2016-11-09 17:26:44 --> Database Driver Class Initialized
INFO - 2016-11-09 17:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:26:44 --> Controller Class Initialized
INFO - 2016-11-09 17:26:44 --> Model Class Initialized
INFO - 2016-11-09 17:26:44 --> Model Class Initialized
INFO - 2016-11-09 17:26:44 --> Model Class Initialized
INFO - 2016-11-09 17:26:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:26:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-09 17:26:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 17:26:44 --> Final output sent to browser
DEBUG - 2016-11-09 17:26:44 --> Total execution time: 0.3674
INFO - 2016-11-09 17:29:39 --> Config Class Initialized
INFO - 2016-11-09 17:29:39 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:29:39 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:29:39 --> Utf8 Class Initialized
INFO - 2016-11-09 17:29:39 --> URI Class Initialized
INFO - 2016-11-09 17:29:39 --> Router Class Initialized
INFO - 2016-11-09 17:29:39 --> Output Class Initialized
INFO - 2016-11-09 17:29:39 --> Security Class Initialized
DEBUG - 2016-11-09 17:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:29:39 --> Input Class Initialized
INFO - 2016-11-09 17:29:39 --> Language Class Initialized
INFO - 2016-11-09 17:29:39 --> Loader Class Initialized
INFO - 2016-11-09 17:29:39 --> Helper loaded: url_helper
INFO - 2016-11-09 17:29:39 --> Helper loaded: form_helper
INFO - 2016-11-09 17:29:39 --> Database Driver Class Initialized
INFO - 2016-11-09 17:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:29:39 --> Controller Class Initialized
INFO - 2016-11-09 17:29:39 --> Model Class Initialized
INFO - 2016-11-09 17:29:39 --> Model Class Initialized
INFO - 2016-11-09 17:29:39 --> Model Class Initialized
DEBUG - 2016-11-09 17:29:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-09 17:29:39 --> Model Class Initialized
INFO - 2016-11-09 17:29:39 --> Final output sent to browser
DEBUG - 2016-11-09 17:29:39 --> Total execution time: 0.3410
INFO - 2016-11-09 17:29:39 --> Config Class Initialized
INFO - 2016-11-09 17:29:39 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:29:39 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:29:39 --> Utf8 Class Initialized
INFO - 2016-11-09 17:29:39 --> URI Class Initialized
DEBUG - 2016-11-09 17:29:39 --> No URI present. Default controller set.
INFO - 2016-11-09 17:29:39 --> Router Class Initialized
INFO - 2016-11-09 17:29:40 --> Output Class Initialized
INFO - 2016-11-09 17:29:40 --> Security Class Initialized
DEBUG - 2016-11-09 17:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:29:40 --> Input Class Initialized
INFO - 2016-11-09 17:29:40 --> Language Class Initialized
INFO - 2016-11-09 17:29:40 --> Loader Class Initialized
INFO - 2016-11-09 17:29:40 --> Helper loaded: url_helper
INFO - 2016-11-09 17:29:40 --> Helper loaded: form_helper
INFO - 2016-11-09 17:29:40 --> Database Driver Class Initialized
INFO - 2016-11-09 17:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:29:40 --> Controller Class Initialized
INFO - 2016-11-09 17:29:40 --> Model Class Initialized
INFO - 2016-11-09 17:29:40 --> Model Class Initialized
INFO - 2016-11-09 17:29:40 --> Model Class Initialized
INFO - 2016-11-09 17:29:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:29:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 17:29:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 17:29:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 17:29:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 17:29:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 17:29:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 17:29:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 17:29:40 --> Final output sent to browser
DEBUG - 2016-11-09 17:29:40 --> Total execution time: 0.4423
INFO - 2016-11-09 17:32:17 --> Config Class Initialized
INFO - 2016-11-09 17:32:17 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:32:17 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:32:17 --> Utf8 Class Initialized
INFO - 2016-11-09 17:32:17 --> URI Class Initialized
DEBUG - 2016-11-09 17:32:17 --> No URI present. Default controller set.
INFO - 2016-11-09 17:32:17 --> Router Class Initialized
INFO - 2016-11-09 17:32:17 --> Output Class Initialized
INFO - 2016-11-09 17:32:17 --> Security Class Initialized
DEBUG - 2016-11-09 17:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:32:17 --> Input Class Initialized
INFO - 2016-11-09 17:32:17 --> Language Class Initialized
INFO - 2016-11-09 17:32:17 --> Loader Class Initialized
INFO - 2016-11-09 17:32:17 --> Helper loaded: url_helper
INFO - 2016-11-09 17:32:17 --> Helper loaded: form_helper
INFO - 2016-11-09 17:32:17 --> Database Driver Class Initialized
INFO - 2016-11-09 17:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:32:17 --> Controller Class Initialized
INFO - 2016-11-09 17:32:17 --> Model Class Initialized
INFO - 2016-11-09 17:32:17 --> Model Class Initialized
INFO - 2016-11-09 17:32:17 --> Model Class Initialized
INFO - 2016-11-09 17:32:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:32:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 17:32:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 17:32:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 17:32:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 17:32:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 17:32:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 17:32:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 17:32:17 --> Final output sent to browser
DEBUG - 2016-11-09 17:32:17 --> Total execution time: 0.5007
INFO - 2016-11-09 17:36:07 --> Config Class Initialized
INFO - 2016-11-09 17:36:07 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:36:07 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:36:07 --> Utf8 Class Initialized
INFO - 2016-11-09 17:36:07 --> URI Class Initialized
INFO - 2016-11-09 17:36:07 --> Router Class Initialized
INFO - 2016-11-09 17:36:07 --> Output Class Initialized
INFO - 2016-11-09 17:36:07 --> Security Class Initialized
DEBUG - 2016-11-09 17:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:36:07 --> Input Class Initialized
INFO - 2016-11-09 17:36:07 --> Language Class Initialized
INFO - 2016-11-09 17:36:07 --> Loader Class Initialized
INFO - 2016-11-09 17:36:07 --> Helper loaded: url_helper
INFO - 2016-11-09 17:36:07 --> Helper loaded: form_helper
INFO - 2016-11-09 17:36:07 --> Database Driver Class Initialized
INFO - 2016-11-09 17:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:36:07 --> Controller Class Initialized
INFO - 2016-11-09 17:36:07 --> Model Class Initialized
INFO - 2016-11-09 17:36:07 --> Model Class Initialized
INFO - 2016-11-09 17:36:07 --> Model Class Initialized
DEBUG - 2016-11-09 17:36:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-09 17:36:07 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 124
ERROR - 2016-11-09 17:36:07 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 124
INFO - 2016-11-09 17:36:07 --> Config Class Initialized
INFO - 2016-11-09 17:36:07 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:36:07 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:36:07 --> Utf8 Class Initialized
INFO - 2016-11-09 17:36:07 --> URI Class Initialized
DEBUG - 2016-11-09 17:36:07 --> No URI present. Default controller set.
INFO - 2016-11-09 17:36:07 --> Router Class Initialized
INFO - 2016-11-09 17:36:07 --> Output Class Initialized
INFO - 2016-11-09 17:36:07 --> Security Class Initialized
DEBUG - 2016-11-09 17:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:36:07 --> Input Class Initialized
INFO - 2016-11-09 17:36:07 --> Language Class Initialized
INFO - 2016-11-09 17:36:07 --> Loader Class Initialized
INFO - 2016-11-09 17:36:07 --> Helper loaded: url_helper
INFO - 2016-11-09 17:36:07 --> Helper loaded: form_helper
INFO - 2016-11-09 17:36:07 --> Database Driver Class Initialized
INFO - 2016-11-09 17:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:36:07 --> Controller Class Initialized
INFO - 2016-11-09 17:36:07 --> Model Class Initialized
INFO - 2016-11-09 17:36:07 --> Model Class Initialized
INFO - 2016-11-09 17:36:07 --> Model Class Initialized
INFO - 2016-11-09 17:36:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:36:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-09 17:36:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 17:36:07 --> Final output sent to browser
DEBUG - 2016-11-09 17:36:07 --> Total execution time: 0.3825
INFO - 2016-11-09 17:36:19 --> Config Class Initialized
INFO - 2016-11-09 17:36:19 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:36:19 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:36:19 --> Utf8 Class Initialized
INFO - 2016-11-09 17:36:19 --> URI Class Initialized
INFO - 2016-11-09 17:36:19 --> Router Class Initialized
INFO - 2016-11-09 17:36:19 --> Output Class Initialized
INFO - 2016-11-09 17:36:19 --> Security Class Initialized
DEBUG - 2016-11-09 17:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:36:19 --> Input Class Initialized
INFO - 2016-11-09 17:36:19 --> Language Class Initialized
INFO - 2016-11-09 17:36:19 --> Loader Class Initialized
INFO - 2016-11-09 17:36:19 --> Helper loaded: url_helper
INFO - 2016-11-09 17:36:19 --> Helper loaded: form_helper
INFO - 2016-11-09 17:36:19 --> Database Driver Class Initialized
INFO - 2016-11-09 17:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:36:19 --> Controller Class Initialized
INFO - 2016-11-09 17:36:19 --> Model Class Initialized
INFO - 2016-11-09 17:36:19 --> Model Class Initialized
INFO - 2016-11-09 17:36:19 --> Model Class Initialized
DEBUG - 2016-11-09 17:36:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-09 17:36:19 --> Model Class Initialized
INFO - 2016-11-09 17:36:19 --> Final output sent to browser
DEBUG - 2016-11-09 17:36:19 --> Total execution time: 0.3661
INFO - 2016-11-09 17:36:19 --> Config Class Initialized
INFO - 2016-11-09 17:36:19 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:36:19 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:36:19 --> Utf8 Class Initialized
INFO - 2016-11-09 17:36:19 --> URI Class Initialized
DEBUG - 2016-11-09 17:36:19 --> No URI present. Default controller set.
INFO - 2016-11-09 17:36:19 --> Router Class Initialized
INFO - 2016-11-09 17:36:19 --> Output Class Initialized
INFO - 2016-11-09 17:36:19 --> Security Class Initialized
DEBUG - 2016-11-09 17:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:36:19 --> Input Class Initialized
INFO - 2016-11-09 17:36:19 --> Language Class Initialized
INFO - 2016-11-09 17:36:19 --> Loader Class Initialized
INFO - 2016-11-09 17:36:19 --> Helper loaded: url_helper
INFO - 2016-11-09 17:36:19 --> Helper loaded: form_helper
INFO - 2016-11-09 17:36:19 --> Database Driver Class Initialized
INFO - 2016-11-09 17:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:36:19 --> Controller Class Initialized
INFO - 2016-11-09 17:36:19 --> Model Class Initialized
INFO - 2016-11-09 17:36:20 --> Model Class Initialized
INFO - 2016-11-09 17:36:20 --> Model Class Initialized
INFO - 2016-11-09 17:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 17:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 17:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 17:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 17:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 17:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 17:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 17:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 17:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 17:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 17:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 17:36:20 --> Final output sent to browser
DEBUG - 2016-11-09 17:36:20 --> Total execution time: 0.5329
INFO - 2016-11-09 17:44:29 --> Config Class Initialized
INFO - 2016-11-09 17:44:29 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:44:29 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:44:29 --> Utf8 Class Initialized
INFO - 2016-11-09 17:44:29 --> URI Class Initialized
DEBUG - 2016-11-09 17:44:29 --> No URI present. Default controller set.
INFO - 2016-11-09 17:44:29 --> Router Class Initialized
INFO - 2016-11-09 17:44:29 --> Output Class Initialized
INFO - 2016-11-09 17:44:29 --> Security Class Initialized
DEBUG - 2016-11-09 17:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:44:29 --> Input Class Initialized
INFO - 2016-11-09 17:44:29 --> Language Class Initialized
INFO - 2016-11-09 17:44:29 --> Loader Class Initialized
INFO - 2016-11-09 17:44:29 --> Helper loaded: url_helper
INFO - 2016-11-09 17:44:29 --> Helper loaded: form_helper
INFO - 2016-11-09 17:44:29 --> Database Driver Class Initialized
INFO - 2016-11-09 17:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:44:29 --> Controller Class Initialized
INFO - 2016-11-09 17:44:29 --> Model Class Initialized
INFO - 2016-11-09 17:44:29 --> Model Class Initialized
INFO - 2016-11-09 17:44:29 --> Model Class Initialized
INFO - 2016-11-09 17:44:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:44:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 17:44:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 17:44:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 17:44:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 17:44:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 17:44:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 17:44:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 17:44:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 17:44:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 17:44:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 17:44:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 17:44:30 --> Final output sent to browser
DEBUG - 2016-11-09 17:44:30 --> Total execution time: 0.5459
INFO - 2016-11-09 17:44:43 --> Config Class Initialized
INFO - 2016-11-09 17:44:43 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:44:43 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:44:43 --> Utf8 Class Initialized
INFO - 2016-11-09 17:44:43 --> URI Class Initialized
INFO - 2016-11-09 17:44:43 --> Router Class Initialized
INFO - 2016-11-09 17:44:43 --> Output Class Initialized
INFO - 2016-11-09 17:44:43 --> Security Class Initialized
DEBUG - 2016-11-09 17:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:44:43 --> Input Class Initialized
INFO - 2016-11-09 17:44:43 --> Language Class Initialized
INFO - 2016-11-09 17:44:43 --> Loader Class Initialized
INFO - 2016-11-09 17:44:43 --> Helper loaded: url_helper
INFO - 2016-11-09 17:44:43 --> Helper loaded: form_helper
INFO - 2016-11-09 17:44:43 --> Database Driver Class Initialized
INFO - 2016-11-09 17:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:44:43 --> Controller Class Initialized
INFO - 2016-11-09 17:44:43 --> Form Validation Class Initialized
INFO - 2016-11-09 17:44:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 17:44:43 --> Final output sent to browser
DEBUG - 2016-11-09 17:44:43 --> Total execution time: 0.3128
INFO - 2016-11-09 17:44:49 --> Config Class Initialized
INFO - 2016-11-09 17:44:49 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:44:49 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:44:49 --> Utf8 Class Initialized
INFO - 2016-11-09 17:44:49 --> URI Class Initialized
DEBUG - 2016-11-09 17:44:49 --> No URI present. Default controller set.
INFO - 2016-11-09 17:44:49 --> Router Class Initialized
INFO - 2016-11-09 17:44:49 --> Output Class Initialized
INFO - 2016-11-09 17:44:49 --> Security Class Initialized
DEBUG - 2016-11-09 17:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:44:49 --> Input Class Initialized
INFO - 2016-11-09 17:44:49 --> Language Class Initialized
INFO - 2016-11-09 17:44:49 --> Loader Class Initialized
INFO - 2016-11-09 17:44:49 --> Helper loaded: url_helper
INFO - 2016-11-09 17:44:49 --> Helper loaded: form_helper
INFO - 2016-11-09 17:44:49 --> Database Driver Class Initialized
INFO - 2016-11-09 17:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:44:49 --> Controller Class Initialized
INFO - 2016-11-09 17:44:49 --> Model Class Initialized
INFO - 2016-11-09 17:44:50 --> Model Class Initialized
INFO - 2016-11-09 17:44:50 --> Model Class Initialized
INFO - 2016-11-09 17:44:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:44:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 17:44:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 17:44:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 17:44:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 17:44:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 17:44:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 17:44:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 17:44:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 17:44:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 17:44:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 17:44:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 17:44:50 --> Final output sent to browser
DEBUG - 2016-11-09 17:44:50 --> Total execution time: 0.5665
INFO - 2016-11-09 17:45:01 --> Config Class Initialized
INFO - 2016-11-09 17:45:01 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:45:01 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:45:01 --> Utf8 Class Initialized
INFO - 2016-11-09 17:45:01 --> URI Class Initialized
INFO - 2016-11-09 17:45:01 --> Router Class Initialized
INFO - 2016-11-09 17:45:01 --> Output Class Initialized
INFO - 2016-11-09 17:45:01 --> Security Class Initialized
DEBUG - 2016-11-09 17:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:45:01 --> Input Class Initialized
INFO - 2016-11-09 17:45:01 --> Language Class Initialized
INFO - 2016-11-09 17:45:01 --> Loader Class Initialized
INFO - 2016-11-09 17:45:01 --> Helper loaded: url_helper
INFO - 2016-11-09 17:45:01 --> Helper loaded: form_helper
INFO - 2016-11-09 17:45:01 --> Database Driver Class Initialized
INFO - 2016-11-09 17:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:45:01 --> Controller Class Initialized
INFO - 2016-11-09 17:45:01 --> Form Validation Class Initialized
INFO - 2016-11-09 17:45:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 17:45:01 --> Final output sent to browser
DEBUG - 2016-11-09 17:45:01 --> Total execution time: 0.3326
INFO - 2016-11-09 17:45:07 --> Config Class Initialized
INFO - 2016-11-09 17:45:07 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:45:08 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:45:08 --> Utf8 Class Initialized
INFO - 2016-11-09 17:45:08 --> URI Class Initialized
DEBUG - 2016-11-09 17:45:08 --> No URI present. Default controller set.
INFO - 2016-11-09 17:45:08 --> Router Class Initialized
INFO - 2016-11-09 17:45:08 --> Output Class Initialized
INFO - 2016-11-09 17:45:08 --> Security Class Initialized
DEBUG - 2016-11-09 17:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:45:08 --> Input Class Initialized
INFO - 2016-11-09 17:45:08 --> Language Class Initialized
INFO - 2016-11-09 17:45:08 --> Loader Class Initialized
INFO - 2016-11-09 17:45:08 --> Helper loaded: url_helper
INFO - 2016-11-09 17:45:08 --> Helper loaded: form_helper
INFO - 2016-11-09 17:45:08 --> Database Driver Class Initialized
INFO - 2016-11-09 17:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:45:08 --> Controller Class Initialized
INFO - 2016-11-09 17:45:08 --> Model Class Initialized
INFO - 2016-11-09 17:45:08 --> Model Class Initialized
INFO - 2016-11-09 17:45:08 --> Model Class Initialized
INFO - 2016-11-09 17:45:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:45:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 17:45:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 17:45:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 17:45:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 17:45:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 17:45:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 17:45:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 17:45:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 17:45:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 17:45:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 17:45:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 17:45:08 --> Final output sent to browser
DEBUG - 2016-11-09 17:45:08 --> Total execution time: 0.5565
INFO - 2016-11-09 17:47:06 --> Config Class Initialized
INFO - 2016-11-09 17:47:06 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:47:06 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:47:06 --> Utf8 Class Initialized
INFO - 2016-11-09 17:47:06 --> URI Class Initialized
DEBUG - 2016-11-09 17:47:06 --> No URI present. Default controller set.
INFO - 2016-11-09 17:47:06 --> Router Class Initialized
INFO - 2016-11-09 17:47:06 --> Output Class Initialized
INFO - 2016-11-09 17:47:06 --> Security Class Initialized
DEBUG - 2016-11-09 17:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:47:06 --> Input Class Initialized
INFO - 2016-11-09 17:47:06 --> Language Class Initialized
INFO - 2016-11-09 17:47:06 --> Loader Class Initialized
INFO - 2016-11-09 17:47:06 --> Helper loaded: url_helper
INFO - 2016-11-09 17:47:06 --> Helper loaded: form_helper
INFO - 2016-11-09 17:47:06 --> Database Driver Class Initialized
INFO - 2016-11-09 17:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:47:06 --> Controller Class Initialized
INFO - 2016-11-09 17:47:06 --> Model Class Initialized
INFO - 2016-11-09 17:47:06 --> Model Class Initialized
INFO - 2016-11-09 17:47:06 --> Model Class Initialized
INFO - 2016-11-09 17:47:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:47:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 17:47:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 17:47:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 17:47:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 17:47:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 17:47:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 17:47:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 17:47:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 17:47:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 17:47:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 17:47:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 17:47:06 --> Final output sent to browser
DEBUG - 2016-11-09 17:47:06 --> Total execution time: 0.5791
INFO - 2016-11-09 17:47:09 --> Config Class Initialized
INFO - 2016-11-09 17:47:09 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:47:09 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:47:10 --> Utf8 Class Initialized
INFO - 2016-11-09 17:47:10 --> URI Class Initialized
INFO - 2016-11-09 17:47:10 --> Router Class Initialized
INFO - 2016-11-09 17:47:10 --> Output Class Initialized
INFO - 2016-11-09 17:47:10 --> Security Class Initialized
DEBUG - 2016-11-09 17:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:47:10 --> Input Class Initialized
INFO - 2016-11-09 17:47:10 --> Language Class Initialized
INFO - 2016-11-09 17:47:10 --> Loader Class Initialized
INFO - 2016-11-09 17:47:10 --> Helper loaded: url_helper
INFO - 2016-11-09 17:47:10 --> Helper loaded: form_helper
INFO - 2016-11-09 17:47:10 --> Database Driver Class Initialized
INFO - 2016-11-09 17:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:47:10 --> Controller Class Initialized
INFO - 2016-11-09 17:47:10 --> Form Validation Class Initialized
INFO - 2016-11-09 17:47:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 17:47:10 --> Final output sent to browser
DEBUG - 2016-11-09 17:47:10 --> Total execution time: 0.3123
INFO - 2016-11-09 17:47:17 --> Config Class Initialized
INFO - 2016-11-09 17:47:17 --> Hooks Class Initialized
DEBUG - 2016-11-09 17:47:17 --> UTF-8 Support Enabled
INFO - 2016-11-09 17:47:17 --> Utf8 Class Initialized
INFO - 2016-11-09 17:47:17 --> URI Class Initialized
DEBUG - 2016-11-09 17:47:17 --> No URI present. Default controller set.
INFO - 2016-11-09 17:47:17 --> Router Class Initialized
INFO - 2016-11-09 17:47:17 --> Output Class Initialized
INFO - 2016-11-09 17:47:17 --> Security Class Initialized
DEBUG - 2016-11-09 17:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 17:47:17 --> Input Class Initialized
INFO - 2016-11-09 17:47:17 --> Language Class Initialized
INFO - 2016-11-09 17:47:17 --> Loader Class Initialized
INFO - 2016-11-09 17:47:17 --> Helper loaded: url_helper
INFO - 2016-11-09 17:47:17 --> Helper loaded: form_helper
INFO - 2016-11-09 17:47:17 --> Database Driver Class Initialized
INFO - 2016-11-09 17:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 17:47:17 --> Controller Class Initialized
INFO - 2016-11-09 17:47:17 --> Model Class Initialized
INFO - 2016-11-09 17:47:17 --> Model Class Initialized
INFO - 2016-11-09 17:47:17 --> Model Class Initialized
INFO - 2016-11-09 17:47:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 17:47:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 17:47:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 17:47:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 17:47:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 17:47:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 17:47:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 17:47:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 17:47:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 17:47:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 17:47:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 17:47:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 17:47:17 --> Final output sent to browser
DEBUG - 2016-11-09 17:47:18 --> Total execution time: 0.5650
INFO - 2016-11-09 18:25:13 --> Config Class Initialized
INFO - 2016-11-09 18:25:13 --> Hooks Class Initialized
DEBUG - 2016-11-09 18:25:13 --> UTF-8 Support Enabled
INFO - 2016-11-09 18:25:13 --> Utf8 Class Initialized
INFO - 2016-11-09 18:25:13 --> URI Class Initialized
DEBUG - 2016-11-09 18:25:13 --> No URI present. Default controller set.
INFO - 2016-11-09 18:25:13 --> Router Class Initialized
INFO - 2016-11-09 18:25:13 --> Output Class Initialized
INFO - 2016-11-09 18:25:13 --> Security Class Initialized
DEBUG - 2016-11-09 18:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 18:25:13 --> Input Class Initialized
INFO - 2016-11-09 18:25:13 --> Language Class Initialized
INFO - 2016-11-09 18:25:13 --> Loader Class Initialized
INFO - 2016-11-09 18:25:14 --> Helper loaded: url_helper
INFO - 2016-11-09 18:25:14 --> Helper loaded: form_helper
INFO - 2016-11-09 18:25:14 --> Database Driver Class Initialized
INFO - 2016-11-09 18:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 18:25:14 --> Controller Class Initialized
INFO - 2016-11-09 18:25:14 --> Model Class Initialized
INFO - 2016-11-09 18:25:14 --> Model Class Initialized
INFO - 2016-11-09 18:25:14 --> Model Class Initialized
INFO - 2016-11-09 18:25:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 18:25:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 18:25:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 18:25:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 18:25:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 18:25:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 18:25:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 18:25:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 18:25:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 18:25:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 18:25:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 18:25:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 18:25:14 --> Final output sent to browser
DEBUG - 2016-11-09 18:25:14 --> Total execution time: 0.5659
INFO - 2016-11-09 18:25:16 --> Config Class Initialized
INFO - 2016-11-09 18:25:16 --> Hooks Class Initialized
DEBUG - 2016-11-09 18:25:16 --> UTF-8 Support Enabled
INFO - 2016-11-09 18:25:16 --> Utf8 Class Initialized
INFO - 2016-11-09 18:25:16 --> URI Class Initialized
DEBUG - 2016-11-09 18:25:16 --> No URI present. Default controller set.
INFO - 2016-11-09 18:25:16 --> Router Class Initialized
INFO - 2016-11-09 18:25:16 --> Output Class Initialized
INFO - 2016-11-09 18:25:16 --> Security Class Initialized
DEBUG - 2016-11-09 18:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 18:25:16 --> Input Class Initialized
INFO - 2016-11-09 18:25:16 --> Language Class Initialized
INFO - 2016-11-09 18:25:16 --> Loader Class Initialized
INFO - 2016-11-09 18:25:16 --> Helper loaded: url_helper
INFO - 2016-11-09 18:25:16 --> Helper loaded: form_helper
INFO - 2016-11-09 18:25:16 --> Database Driver Class Initialized
INFO - 2016-11-09 18:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 18:25:17 --> Controller Class Initialized
INFO - 2016-11-09 18:25:17 --> Model Class Initialized
INFO - 2016-11-09 18:25:17 --> Model Class Initialized
INFO - 2016-11-09 18:25:17 --> Model Class Initialized
INFO - 2016-11-09 18:25:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 18:25:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 18:25:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 18:25:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 18:25:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 18:25:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 18:25:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 18:25:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 18:25:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 18:25:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 18:25:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 18:25:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 18:25:17 --> Final output sent to browser
DEBUG - 2016-11-09 18:25:17 --> Total execution time: 0.5756
INFO - 2016-11-09 18:43:19 --> Config Class Initialized
INFO - 2016-11-09 18:43:19 --> Hooks Class Initialized
DEBUG - 2016-11-09 18:43:19 --> UTF-8 Support Enabled
INFO - 2016-11-09 18:43:19 --> Utf8 Class Initialized
INFO - 2016-11-09 18:43:19 --> URI Class Initialized
DEBUG - 2016-11-09 18:43:19 --> No URI present. Default controller set.
INFO - 2016-11-09 18:43:19 --> Router Class Initialized
INFO - 2016-11-09 18:43:19 --> Output Class Initialized
INFO - 2016-11-09 18:43:19 --> Security Class Initialized
DEBUG - 2016-11-09 18:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 18:43:19 --> Input Class Initialized
INFO - 2016-11-09 18:43:19 --> Language Class Initialized
INFO - 2016-11-09 18:43:19 --> Loader Class Initialized
INFO - 2016-11-09 18:43:19 --> Helper loaded: url_helper
INFO - 2016-11-09 18:43:19 --> Helper loaded: form_helper
INFO - 2016-11-09 18:43:19 --> Database Driver Class Initialized
INFO - 2016-11-09 18:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 18:43:19 --> Controller Class Initialized
INFO - 2016-11-09 18:43:19 --> Model Class Initialized
INFO - 2016-11-09 18:43:19 --> Model Class Initialized
INFO - 2016-11-09 18:43:19 --> Model Class Initialized
INFO - 2016-11-09 18:43:19 --> Model Class Initialized
INFO - 2016-11-09 18:43:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 18:43:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 18:43:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 18:43:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 18:43:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 18:43:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 18:43:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 18:43:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 18:43:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 18:43:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 18:43:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 18:43:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 18:43:20 --> Final output sent to browser
DEBUG - 2016-11-09 18:43:20 --> Total execution time: 0.6054
INFO - 2016-11-09 18:44:21 --> Config Class Initialized
INFO - 2016-11-09 18:44:21 --> Hooks Class Initialized
DEBUG - 2016-11-09 18:44:21 --> UTF-8 Support Enabled
INFO - 2016-11-09 18:44:21 --> Utf8 Class Initialized
INFO - 2016-11-09 18:44:21 --> URI Class Initialized
DEBUG - 2016-11-09 18:44:21 --> No URI present. Default controller set.
INFO - 2016-11-09 18:44:21 --> Router Class Initialized
INFO - 2016-11-09 18:44:21 --> Output Class Initialized
INFO - 2016-11-09 18:44:21 --> Security Class Initialized
DEBUG - 2016-11-09 18:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 18:44:21 --> Input Class Initialized
INFO - 2016-11-09 18:44:21 --> Language Class Initialized
INFO - 2016-11-09 18:44:21 --> Loader Class Initialized
INFO - 2016-11-09 18:44:21 --> Helper loaded: url_helper
INFO - 2016-11-09 18:44:21 --> Helper loaded: form_helper
INFO - 2016-11-09 18:44:21 --> Database Driver Class Initialized
INFO - 2016-11-09 18:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 18:44:21 --> Controller Class Initialized
INFO - 2016-11-09 18:44:22 --> Model Class Initialized
INFO - 2016-11-09 18:44:22 --> Model Class Initialized
INFO - 2016-11-09 18:44:22 --> Model Class Initialized
INFO - 2016-11-09 18:44:22 --> Model Class Initialized
INFO - 2016-11-09 18:44:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 18:44:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 18:44:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 18:44:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 18:44:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 18:44:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 18:44:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 18:44:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 18:44:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 18:44:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 18:44:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 18:44:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 18:44:22 --> Final output sent to browser
DEBUG - 2016-11-09 18:44:22 --> Total execution time: 0.6148
INFO - 2016-11-09 18:46:42 --> Config Class Initialized
INFO - 2016-11-09 18:46:42 --> Hooks Class Initialized
DEBUG - 2016-11-09 18:46:42 --> UTF-8 Support Enabled
INFO - 2016-11-09 18:46:42 --> Utf8 Class Initialized
INFO - 2016-11-09 18:46:42 --> URI Class Initialized
DEBUG - 2016-11-09 18:46:42 --> No URI present. Default controller set.
INFO - 2016-11-09 18:46:42 --> Router Class Initialized
INFO - 2016-11-09 18:46:42 --> Output Class Initialized
INFO - 2016-11-09 18:46:42 --> Security Class Initialized
DEBUG - 2016-11-09 18:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 18:46:42 --> Input Class Initialized
INFO - 2016-11-09 18:46:42 --> Language Class Initialized
INFO - 2016-11-09 18:46:42 --> Loader Class Initialized
INFO - 2016-11-09 18:46:42 --> Helper loaded: url_helper
INFO - 2016-11-09 18:46:42 --> Helper loaded: form_helper
INFO - 2016-11-09 18:46:42 --> Database Driver Class Initialized
INFO - 2016-11-09 18:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 18:46:42 --> Controller Class Initialized
INFO - 2016-11-09 18:46:42 --> Model Class Initialized
INFO - 2016-11-09 18:46:42 --> Model Class Initialized
INFO - 2016-11-09 18:46:42 --> Model Class Initialized
INFO - 2016-11-09 18:46:42 --> Model Class Initialized
INFO - 2016-11-09 18:46:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 18:46:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 18:46:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 18:46:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 18:46:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 18:46:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 18:46:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 18:46:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 18:46:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 18:46:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 18:46:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 18:46:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 18:46:43 --> Final output sent to browser
DEBUG - 2016-11-09 18:46:43 --> Total execution time: 0.5826
INFO - 2016-11-09 18:47:13 --> Config Class Initialized
INFO - 2016-11-09 18:47:13 --> Hooks Class Initialized
DEBUG - 2016-11-09 18:47:13 --> UTF-8 Support Enabled
INFO - 2016-11-09 18:47:13 --> Utf8 Class Initialized
INFO - 2016-11-09 18:47:13 --> URI Class Initialized
DEBUG - 2016-11-09 18:47:13 --> No URI present. Default controller set.
INFO - 2016-11-09 18:47:13 --> Router Class Initialized
INFO - 2016-11-09 18:47:13 --> Output Class Initialized
INFO - 2016-11-09 18:47:13 --> Security Class Initialized
DEBUG - 2016-11-09 18:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 18:47:13 --> Input Class Initialized
INFO - 2016-11-09 18:47:13 --> Language Class Initialized
INFO - 2016-11-09 18:47:13 --> Loader Class Initialized
INFO - 2016-11-09 18:47:13 --> Helper loaded: url_helper
INFO - 2016-11-09 18:47:13 --> Helper loaded: form_helper
INFO - 2016-11-09 18:47:13 --> Database Driver Class Initialized
INFO - 2016-11-09 18:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 18:47:13 --> Controller Class Initialized
INFO - 2016-11-09 18:47:13 --> Model Class Initialized
INFO - 2016-11-09 18:47:13 --> Model Class Initialized
INFO - 2016-11-09 18:47:13 --> Model Class Initialized
INFO - 2016-11-09 18:47:13 --> Model Class Initialized
INFO - 2016-11-09 18:47:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 18:47:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 18:47:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 18:47:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 18:47:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 18:47:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 18:47:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 18:47:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 18:47:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 18:47:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 18:47:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 18:47:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 18:47:13 --> Final output sent to browser
DEBUG - 2016-11-09 18:47:13 --> Total execution time: 0.5730
INFO - 2016-11-09 18:47:54 --> Config Class Initialized
INFO - 2016-11-09 18:47:54 --> Hooks Class Initialized
DEBUG - 2016-11-09 18:47:54 --> UTF-8 Support Enabled
INFO - 2016-11-09 18:47:54 --> Utf8 Class Initialized
INFO - 2016-11-09 18:47:54 --> URI Class Initialized
DEBUG - 2016-11-09 18:47:54 --> No URI present. Default controller set.
INFO - 2016-11-09 18:47:54 --> Router Class Initialized
INFO - 2016-11-09 18:47:54 --> Output Class Initialized
INFO - 2016-11-09 18:47:54 --> Security Class Initialized
DEBUG - 2016-11-09 18:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 18:47:54 --> Input Class Initialized
INFO - 2016-11-09 18:47:54 --> Language Class Initialized
INFO - 2016-11-09 18:47:54 --> Loader Class Initialized
INFO - 2016-11-09 18:47:55 --> Helper loaded: url_helper
INFO - 2016-11-09 18:47:55 --> Helper loaded: form_helper
INFO - 2016-11-09 18:47:55 --> Database Driver Class Initialized
INFO - 2016-11-09 18:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 18:47:55 --> Controller Class Initialized
INFO - 2016-11-09 18:47:55 --> Model Class Initialized
INFO - 2016-11-09 18:47:55 --> Model Class Initialized
INFO - 2016-11-09 18:47:55 --> Model Class Initialized
INFO - 2016-11-09 18:47:55 --> Model Class Initialized
INFO - 2016-11-09 18:47:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 18:47:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 18:47:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 18:47:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 18:47:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 18:47:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 18:47:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 18:47:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 18:47:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 18:47:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 18:47:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 18:47:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 18:47:55 --> Final output sent to browser
DEBUG - 2016-11-09 18:47:55 --> Total execution time: 0.6947
INFO - 2016-11-09 18:48:51 --> Config Class Initialized
INFO - 2016-11-09 18:48:51 --> Hooks Class Initialized
DEBUG - 2016-11-09 18:48:51 --> UTF-8 Support Enabled
INFO - 2016-11-09 18:48:51 --> Utf8 Class Initialized
INFO - 2016-11-09 18:48:51 --> URI Class Initialized
DEBUG - 2016-11-09 18:48:51 --> No URI present. Default controller set.
INFO - 2016-11-09 18:48:51 --> Router Class Initialized
INFO - 2016-11-09 18:48:51 --> Output Class Initialized
INFO - 2016-11-09 18:48:51 --> Security Class Initialized
DEBUG - 2016-11-09 18:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 18:48:51 --> Input Class Initialized
INFO - 2016-11-09 18:48:51 --> Language Class Initialized
INFO - 2016-11-09 18:48:51 --> Loader Class Initialized
INFO - 2016-11-09 18:48:51 --> Helper loaded: url_helper
INFO - 2016-11-09 18:48:51 --> Helper loaded: form_helper
INFO - 2016-11-09 18:48:51 --> Database Driver Class Initialized
INFO - 2016-11-09 18:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 18:48:51 --> Controller Class Initialized
INFO - 2016-11-09 18:48:51 --> Model Class Initialized
INFO - 2016-11-09 18:48:51 --> Model Class Initialized
INFO - 2016-11-09 18:48:51 --> Model Class Initialized
INFO - 2016-11-09 18:48:51 --> Model Class Initialized
INFO - 2016-11-09 18:48:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 18:48:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 18:48:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 18:48:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 18:48:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 18:48:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 18:48:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 18:48:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 18:48:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 18:48:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 18:48:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 18:48:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 18:48:51 --> Final output sent to browser
DEBUG - 2016-11-09 18:48:51 --> Total execution time: 0.6197
INFO - 2016-11-09 18:53:21 --> Config Class Initialized
INFO - 2016-11-09 18:53:21 --> Hooks Class Initialized
DEBUG - 2016-11-09 18:53:21 --> UTF-8 Support Enabled
INFO - 2016-11-09 18:53:21 --> Utf8 Class Initialized
INFO - 2016-11-09 18:53:21 --> URI Class Initialized
INFO - 2016-11-09 18:53:21 --> Router Class Initialized
INFO - 2016-11-09 18:53:21 --> Output Class Initialized
INFO - 2016-11-09 18:53:21 --> Security Class Initialized
DEBUG - 2016-11-09 18:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 18:53:21 --> Input Class Initialized
INFO - 2016-11-09 18:53:21 --> Language Class Initialized
INFO - 2016-11-09 18:53:21 --> Loader Class Initialized
INFO - 2016-11-09 18:53:21 --> Helper loaded: url_helper
INFO - 2016-11-09 18:53:21 --> Helper loaded: form_helper
INFO - 2016-11-09 18:53:21 --> Database Driver Class Initialized
INFO - 2016-11-09 18:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 18:53:21 --> Controller Class Initialized
INFO - 2016-11-09 18:53:21 --> Model Class Initialized
INFO - 2016-11-09 18:53:21 --> Form Validation Class Initialized
INFO - 2016-11-09 18:53:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-09 18:53:21 --> Final output sent to browser
DEBUG - 2016-11-09 18:53:21 --> Total execution time: 0.3344
INFO - 2016-11-09 18:53:23 --> Config Class Initialized
INFO - 2016-11-09 18:53:23 --> Hooks Class Initialized
DEBUG - 2016-11-09 18:53:23 --> UTF-8 Support Enabled
INFO - 2016-11-09 18:53:23 --> Utf8 Class Initialized
INFO - 2016-11-09 18:53:23 --> URI Class Initialized
DEBUG - 2016-11-09 18:53:23 --> No URI present. Default controller set.
INFO - 2016-11-09 18:53:23 --> Router Class Initialized
INFO - 2016-11-09 18:53:23 --> Output Class Initialized
INFO - 2016-11-09 18:53:23 --> Security Class Initialized
DEBUG - 2016-11-09 18:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-09 18:53:23 --> Input Class Initialized
INFO - 2016-11-09 18:53:23 --> Language Class Initialized
INFO - 2016-11-09 18:53:23 --> Loader Class Initialized
INFO - 2016-11-09 18:53:23 --> Helper loaded: url_helper
INFO - 2016-11-09 18:53:23 --> Helper loaded: form_helper
INFO - 2016-11-09 18:53:23 --> Database Driver Class Initialized
INFO - 2016-11-09 18:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-09 18:53:23 --> Controller Class Initialized
INFO - 2016-11-09 18:53:23 --> Model Class Initialized
INFO - 2016-11-09 18:53:23 --> Model Class Initialized
INFO - 2016-11-09 18:53:23 --> Model Class Initialized
INFO - 2016-11-09 18:53:23 --> Model Class Initialized
INFO - 2016-11-09 18:53:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-09 18:53:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-09 18:53:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-09 18:53:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-09 18:53:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-09 18:53:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-09 18:53:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-09 18:53:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-09 18:53:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-09 18:53:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-09 18:53:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-09 18:53:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-09 18:53:23 --> Final output sent to browser
DEBUG - 2016-11-09 18:53:23 --> Total execution time: 0.6297
