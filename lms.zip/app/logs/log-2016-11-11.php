<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-11 13:09:15 --> Config Class Initialized
INFO - 2016-11-11 13:09:15 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:09:15 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:09:15 --> Utf8 Class Initialized
INFO - 2016-11-11 13:09:15 --> URI Class Initialized
DEBUG - 2016-11-11 13:09:16 --> No URI present. Default controller set.
INFO - 2016-11-11 13:09:16 --> Router Class Initialized
INFO - 2016-11-11 13:09:16 --> Output Class Initialized
INFO - 2016-11-11 13:09:16 --> Security Class Initialized
DEBUG - 2016-11-11 13:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:09:16 --> Input Class Initialized
INFO - 2016-11-11 13:09:16 --> Language Class Initialized
INFO - 2016-11-11 13:09:16 --> Loader Class Initialized
INFO - 2016-11-11 13:09:16 --> Helper loaded: url_helper
INFO - 2016-11-11 13:09:16 --> Helper loaded: form_helper
INFO - 2016-11-11 13:09:17 --> Database Driver Class Initialized
INFO - 2016-11-11 13:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:09:17 --> Controller Class Initialized
INFO - 2016-11-11 13:09:17 --> Model Class Initialized
INFO - 2016-11-11 13:09:17 --> Model Class Initialized
INFO - 2016-11-11 13:09:17 --> Model Class Initialized
INFO - 2016-11-11 13:09:18 --> Model Class Initialized
INFO - 2016-11-11 13:09:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:09:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-11 13:09:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:09:18 --> Final output sent to browser
DEBUG - 2016-11-11 13:09:18 --> Total execution time: 2.8957
INFO - 2016-11-11 13:09:30 --> Config Class Initialized
INFO - 2016-11-11 13:09:30 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:09:30 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:09:30 --> Utf8 Class Initialized
INFO - 2016-11-11 13:09:30 --> URI Class Initialized
INFO - 2016-11-11 13:09:30 --> Router Class Initialized
INFO - 2016-11-11 13:09:30 --> Output Class Initialized
INFO - 2016-11-11 13:09:30 --> Security Class Initialized
DEBUG - 2016-11-11 13:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:09:30 --> Input Class Initialized
INFO - 2016-11-11 13:09:30 --> Language Class Initialized
INFO - 2016-11-11 13:09:30 --> Loader Class Initialized
INFO - 2016-11-11 13:09:30 --> Helper loaded: url_helper
INFO - 2016-11-11 13:09:30 --> Helper loaded: form_helper
INFO - 2016-11-11 13:09:30 --> Database Driver Class Initialized
INFO - 2016-11-11 13:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:09:30 --> Controller Class Initialized
INFO - 2016-11-11 13:09:30 --> Model Class Initialized
INFO - 2016-11-11 13:09:30 --> Model Class Initialized
INFO - 2016-11-11 13:09:30 --> Model Class Initialized
INFO - 2016-11-11 13:09:30 --> Model Class Initialized
DEBUG - 2016-11-11 13:09:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-11 13:09:31 --> Model Class Initialized
INFO - 2016-11-11 13:09:31 --> Final output sent to browser
DEBUG - 2016-11-11 13:09:31 --> Total execution time: 0.6911
INFO - 2016-11-11 13:09:31 --> Config Class Initialized
INFO - 2016-11-11 13:09:31 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:09:31 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:09:31 --> Utf8 Class Initialized
INFO - 2016-11-11 13:09:31 --> URI Class Initialized
DEBUG - 2016-11-11 13:09:31 --> No URI present. Default controller set.
INFO - 2016-11-11 13:09:31 --> Router Class Initialized
INFO - 2016-11-11 13:09:31 --> Output Class Initialized
INFO - 2016-11-11 13:09:31 --> Security Class Initialized
DEBUG - 2016-11-11 13:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:09:31 --> Input Class Initialized
INFO - 2016-11-11 13:09:31 --> Language Class Initialized
INFO - 2016-11-11 13:09:31 --> Loader Class Initialized
INFO - 2016-11-11 13:09:31 --> Helper loaded: url_helper
INFO - 2016-11-11 13:09:31 --> Helper loaded: form_helper
INFO - 2016-11-11 13:09:31 --> Database Driver Class Initialized
INFO - 2016-11-11 13:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:09:31 --> Controller Class Initialized
INFO - 2016-11-11 13:09:31 --> Model Class Initialized
INFO - 2016-11-11 13:09:31 --> Model Class Initialized
INFO - 2016-11-11 13:09:31 --> Model Class Initialized
INFO - 2016-11-11 13:09:31 --> Model Class Initialized
INFO - 2016-11-11 13:09:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:09:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 13:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 13:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 13:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 13:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 13:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 13:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 13:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 13:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 13:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 13:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:09:32 --> Final output sent to browser
DEBUG - 2016-11-11 13:09:32 --> Total execution time: 1.3392
INFO - 2016-11-11 13:10:03 --> Config Class Initialized
INFO - 2016-11-11 13:10:03 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:10:03 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:10:03 --> Utf8 Class Initialized
INFO - 2016-11-11 13:10:03 --> URI Class Initialized
INFO - 2016-11-11 13:10:03 --> Router Class Initialized
INFO - 2016-11-11 13:10:03 --> Output Class Initialized
INFO - 2016-11-11 13:10:03 --> Security Class Initialized
DEBUG - 2016-11-11 13:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:10:03 --> Input Class Initialized
INFO - 2016-11-11 13:10:03 --> Language Class Initialized
INFO - 2016-11-11 13:10:03 --> Loader Class Initialized
INFO - 2016-11-11 13:10:03 --> Helper loaded: url_helper
INFO - 2016-11-11 13:10:03 --> Helper loaded: form_helper
INFO - 2016-11-11 13:10:03 --> Database Driver Class Initialized
INFO - 2016-11-11 13:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:10:03 --> Controller Class Initialized
INFO - 2016-11-11 13:10:03 --> Model Class Initialized
INFO - 2016-11-11 13:10:03 --> Model Class Initialized
INFO - 2016-11-11 13:10:03 --> Model Class Initialized
INFO - 2016-11-11 13:10:03 --> Model Class Initialized
DEBUG - 2016-11-11 13:10:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-11 13:10:03 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
ERROR - 2016-11-11 13:10:03 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
INFO - 2016-11-11 13:10:03 --> Config Class Initialized
INFO - 2016-11-11 13:10:03 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:10:03 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:10:03 --> Utf8 Class Initialized
INFO - 2016-11-11 13:10:03 --> URI Class Initialized
DEBUG - 2016-11-11 13:10:03 --> No URI present. Default controller set.
INFO - 2016-11-11 13:10:03 --> Router Class Initialized
INFO - 2016-11-11 13:10:03 --> Output Class Initialized
INFO - 2016-11-11 13:10:03 --> Security Class Initialized
DEBUG - 2016-11-11 13:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:10:03 --> Input Class Initialized
INFO - 2016-11-11 13:10:03 --> Language Class Initialized
INFO - 2016-11-11 13:10:03 --> Loader Class Initialized
INFO - 2016-11-11 13:10:03 --> Helper loaded: url_helper
INFO - 2016-11-11 13:10:03 --> Helper loaded: form_helper
INFO - 2016-11-11 13:10:03 --> Database Driver Class Initialized
INFO - 2016-11-11 13:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:10:03 --> Controller Class Initialized
INFO - 2016-11-11 13:10:03 --> Model Class Initialized
INFO - 2016-11-11 13:10:03 --> Model Class Initialized
INFO - 2016-11-11 13:10:03 --> Model Class Initialized
INFO - 2016-11-11 13:10:03 --> Model Class Initialized
INFO - 2016-11-11 13:10:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:10:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-11 13:10:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:10:03 --> Final output sent to browser
DEBUG - 2016-11-11 13:10:03 --> Total execution time: 0.2071
INFO - 2016-11-11 13:10:09 --> Config Class Initialized
INFO - 2016-11-11 13:10:09 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:10:09 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:10:09 --> Utf8 Class Initialized
INFO - 2016-11-11 13:10:09 --> URI Class Initialized
INFO - 2016-11-11 13:10:09 --> Router Class Initialized
INFO - 2016-11-11 13:10:09 --> Output Class Initialized
INFO - 2016-11-11 13:10:09 --> Security Class Initialized
DEBUG - 2016-11-11 13:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:10:09 --> Input Class Initialized
INFO - 2016-11-11 13:10:09 --> Language Class Initialized
INFO - 2016-11-11 13:10:09 --> Loader Class Initialized
INFO - 2016-11-11 13:10:10 --> Helper loaded: url_helper
INFO - 2016-11-11 13:10:10 --> Helper loaded: form_helper
INFO - 2016-11-11 13:10:10 --> Database Driver Class Initialized
INFO - 2016-11-11 13:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:10:10 --> Controller Class Initialized
INFO - 2016-11-11 13:10:10 --> Model Class Initialized
INFO - 2016-11-11 13:10:10 --> Model Class Initialized
INFO - 2016-11-11 13:10:10 --> Model Class Initialized
INFO - 2016-11-11 13:10:10 --> Model Class Initialized
DEBUG - 2016-11-11 13:10:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-11 13:10:10 --> Model Class Initialized
INFO - 2016-11-11 13:10:10 --> Final output sent to browser
DEBUG - 2016-11-11 13:10:10 --> Total execution time: 0.1725
INFO - 2016-11-11 13:10:10 --> Config Class Initialized
INFO - 2016-11-11 13:10:10 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:10:10 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:10:10 --> Utf8 Class Initialized
INFO - 2016-11-11 13:10:10 --> URI Class Initialized
DEBUG - 2016-11-11 13:10:10 --> No URI present. Default controller set.
INFO - 2016-11-11 13:10:10 --> Router Class Initialized
INFO - 2016-11-11 13:10:10 --> Output Class Initialized
INFO - 2016-11-11 13:10:10 --> Security Class Initialized
DEBUG - 2016-11-11 13:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:10:10 --> Input Class Initialized
INFO - 2016-11-11 13:10:10 --> Language Class Initialized
INFO - 2016-11-11 13:10:10 --> Loader Class Initialized
INFO - 2016-11-11 13:10:10 --> Helper loaded: url_helper
INFO - 2016-11-11 13:10:10 --> Helper loaded: form_helper
INFO - 2016-11-11 13:10:10 --> Database Driver Class Initialized
INFO - 2016-11-11 13:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:10:10 --> Controller Class Initialized
INFO - 2016-11-11 13:10:10 --> Model Class Initialized
INFO - 2016-11-11 13:10:10 --> Model Class Initialized
INFO - 2016-11-11 13:10:10 --> Model Class Initialized
INFO - 2016-11-11 13:10:10 --> Model Class Initialized
INFO - 2016-11-11 13:10:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:10:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 13:10:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 13:10:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-11 13:10:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-11 13:10:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-11 13:10:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-11 13:10:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-11 13:10:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-11 13:10:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 13:10:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:10:10 --> Final output sent to browser
DEBUG - 2016-11-11 13:10:10 --> Total execution time: 0.6524
INFO - 2016-11-11 13:10:22 --> Config Class Initialized
INFO - 2016-11-11 13:10:22 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:10:22 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:10:22 --> Utf8 Class Initialized
INFO - 2016-11-11 13:10:22 --> URI Class Initialized
INFO - 2016-11-11 13:10:22 --> Router Class Initialized
INFO - 2016-11-11 13:10:22 --> Output Class Initialized
INFO - 2016-11-11 13:10:22 --> Security Class Initialized
DEBUG - 2016-11-11 13:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:10:22 --> Input Class Initialized
INFO - 2016-11-11 13:10:22 --> Language Class Initialized
INFO - 2016-11-11 13:10:23 --> Loader Class Initialized
INFO - 2016-11-11 13:10:23 --> Helper loaded: url_helper
INFO - 2016-11-11 13:10:23 --> Helper loaded: form_helper
INFO - 2016-11-11 13:10:23 --> Database Driver Class Initialized
INFO - 2016-11-11 13:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:10:23 --> Controller Class Initialized
INFO - 2016-11-11 13:10:23 --> Model Class Initialized
INFO - 2016-11-11 13:10:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-11 13:10:23 --> Final output sent to browser
DEBUG - 2016-11-11 13:10:23 --> Total execution time: 0.3973
INFO - 2016-11-11 13:10:42 --> Config Class Initialized
INFO - 2016-11-11 13:10:42 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:10:42 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:10:42 --> Utf8 Class Initialized
INFO - 2016-11-11 13:10:42 --> URI Class Initialized
INFO - 2016-11-11 13:10:42 --> Router Class Initialized
INFO - 2016-11-11 13:10:42 --> Output Class Initialized
INFO - 2016-11-11 13:10:42 --> Security Class Initialized
DEBUG - 2016-11-11 13:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:10:42 --> Input Class Initialized
INFO - 2016-11-11 13:10:42 --> Language Class Initialized
INFO - 2016-11-11 13:10:43 --> Loader Class Initialized
INFO - 2016-11-11 13:10:43 --> Helper loaded: url_helper
INFO - 2016-11-11 13:10:43 --> Helper loaded: form_helper
INFO - 2016-11-11 13:10:43 --> Database Driver Class Initialized
INFO - 2016-11-11 13:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:10:43 --> Controller Class Initialized
INFO - 2016-11-11 13:10:43 --> Model Class Initialized
INFO - 2016-11-11 13:10:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-11 13:10:43 --> Final output sent to browser
DEBUG - 2016-11-11 13:10:43 --> Total execution time: 0.1595
INFO - 2016-11-11 13:10:54 --> Config Class Initialized
INFO - 2016-11-11 13:10:54 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:10:54 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:10:55 --> Utf8 Class Initialized
INFO - 2016-11-11 13:10:55 --> URI Class Initialized
INFO - 2016-11-11 13:10:55 --> Router Class Initialized
INFO - 2016-11-11 13:10:55 --> Output Class Initialized
INFO - 2016-11-11 13:10:55 --> Security Class Initialized
DEBUG - 2016-11-11 13:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:10:55 --> Input Class Initialized
INFO - 2016-11-11 13:10:55 --> Language Class Initialized
INFO - 2016-11-11 13:10:55 --> Loader Class Initialized
INFO - 2016-11-11 13:10:55 --> Helper loaded: url_helper
INFO - 2016-11-11 13:10:55 --> Helper loaded: form_helper
INFO - 2016-11-11 13:10:55 --> Database Driver Class Initialized
INFO - 2016-11-11 13:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:10:55 --> Controller Class Initialized
INFO - 2016-11-11 13:10:55 --> Model Class Initialized
INFO - 2016-11-11 13:10:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-11 13:10:55 --> Final output sent to browser
DEBUG - 2016-11-11 13:10:55 --> Total execution time: 0.2867
INFO - 2016-11-11 13:11:01 --> Config Class Initialized
INFO - 2016-11-11 13:11:01 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:11:01 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:11:01 --> Utf8 Class Initialized
INFO - 2016-11-11 13:11:01 --> URI Class Initialized
DEBUG - 2016-11-11 13:11:01 --> No URI present. Default controller set.
INFO - 2016-11-11 13:11:01 --> Router Class Initialized
INFO - 2016-11-11 13:11:01 --> Output Class Initialized
INFO - 2016-11-11 13:11:01 --> Security Class Initialized
DEBUG - 2016-11-11 13:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:11:01 --> Input Class Initialized
INFO - 2016-11-11 13:11:02 --> Language Class Initialized
INFO - 2016-11-11 13:11:02 --> Loader Class Initialized
INFO - 2016-11-11 13:11:02 --> Helper loaded: url_helper
INFO - 2016-11-11 13:11:02 --> Helper loaded: form_helper
INFO - 2016-11-11 13:11:02 --> Database Driver Class Initialized
INFO - 2016-11-11 13:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:11:02 --> Controller Class Initialized
INFO - 2016-11-11 13:11:02 --> Model Class Initialized
INFO - 2016-11-11 13:11:02 --> Model Class Initialized
INFO - 2016-11-11 13:11:02 --> Model Class Initialized
INFO - 2016-11-11 13:11:02 --> Model Class Initialized
INFO - 2016-11-11 13:11:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:11:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 13:11:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 13:11:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-11 13:11:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-11 13:11:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-11 13:11:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-11 13:11:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-11 13:11:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-11 13:11:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 13:11:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:11:02 --> Final output sent to browser
DEBUG - 2016-11-11 13:11:02 --> Total execution time: 0.2835
INFO - 2016-11-11 13:11:17 --> Config Class Initialized
INFO - 2016-11-11 13:11:17 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:11:17 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:11:17 --> Utf8 Class Initialized
INFO - 2016-11-11 13:11:17 --> URI Class Initialized
INFO - 2016-11-11 13:11:17 --> Router Class Initialized
INFO - 2016-11-11 13:11:17 --> Output Class Initialized
INFO - 2016-11-11 13:11:17 --> Security Class Initialized
DEBUG - 2016-11-11 13:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:11:17 --> Input Class Initialized
INFO - 2016-11-11 13:11:17 --> Language Class Initialized
INFO - 2016-11-11 13:11:17 --> Loader Class Initialized
INFO - 2016-11-11 13:11:17 --> Helper loaded: url_helper
INFO - 2016-11-11 13:11:17 --> Helper loaded: form_helper
INFO - 2016-11-11 13:11:17 --> Database Driver Class Initialized
INFO - 2016-11-11 13:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:11:17 --> Controller Class Initialized
INFO - 2016-11-11 13:11:17 --> Model Class Initialized
INFO - 2016-11-11 13:11:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-11 13:11:17 --> Final output sent to browser
DEBUG - 2016-11-11 13:11:17 --> Total execution time: 0.1619
INFO - 2016-11-11 13:11:24 --> Config Class Initialized
INFO - 2016-11-11 13:11:24 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:11:24 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:11:24 --> Utf8 Class Initialized
INFO - 2016-11-11 13:11:24 --> URI Class Initialized
INFO - 2016-11-11 13:11:24 --> Router Class Initialized
INFO - 2016-11-11 13:11:24 --> Output Class Initialized
INFO - 2016-11-11 13:11:24 --> Security Class Initialized
DEBUG - 2016-11-11 13:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:11:24 --> Input Class Initialized
INFO - 2016-11-11 13:11:24 --> Language Class Initialized
INFO - 2016-11-11 13:11:24 --> Loader Class Initialized
INFO - 2016-11-11 13:11:24 --> Helper loaded: url_helper
INFO - 2016-11-11 13:11:24 --> Helper loaded: form_helper
INFO - 2016-11-11 13:11:24 --> Database Driver Class Initialized
INFO - 2016-11-11 13:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:11:24 --> Controller Class Initialized
INFO - 2016-11-11 13:11:24 --> Model Class Initialized
INFO - 2016-11-11 13:11:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-11 13:11:24 --> Final output sent to browser
DEBUG - 2016-11-11 13:11:24 --> Total execution time: 0.1729
INFO - 2016-11-11 13:11:27 --> Config Class Initialized
INFO - 2016-11-11 13:11:27 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:11:27 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:11:27 --> Utf8 Class Initialized
INFO - 2016-11-11 13:11:27 --> URI Class Initialized
DEBUG - 2016-11-11 13:11:27 --> No URI present. Default controller set.
INFO - 2016-11-11 13:11:27 --> Router Class Initialized
INFO - 2016-11-11 13:11:27 --> Output Class Initialized
INFO - 2016-11-11 13:11:27 --> Security Class Initialized
DEBUG - 2016-11-11 13:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:11:27 --> Input Class Initialized
INFO - 2016-11-11 13:11:27 --> Language Class Initialized
INFO - 2016-11-11 13:11:27 --> Loader Class Initialized
INFO - 2016-11-11 13:11:27 --> Helper loaded: url_helper
INFO - 2016-11-11 13:11:27 --> Helper loaded: form_helper
INFO - 2016-11-11 13:11:27 --> Database Driver Class Initialized
INFO - 2016-11-11 13:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:11:28 --> Controller Class Initialized
INFO - 2016-11-11 13:11:28 --> Model Class Initialized
INFO - 2016-11-11 13:11:28 --> Model Class Initialized
INFO - 2016-11-11 13:11:28 --> Model Class Initialized
INFO - 2016-11-11 13:11:28 --> Model Class Initialized
INFO - 2016-11-11 13:11:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:11:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 13:11:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 13:11:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-11 13:11:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-11 13:11:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-11 13:11:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-11 13:11:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-11 13:11:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-11 13:11:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 13:11:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:11:28 --> Final output sent to browser
DEBUG - 2016-11-11 13:11:28 --> Total execution time: 0.2883
INFO - 2016-11-11 13:11:42 --> Config Class Initialized
INFO - 2016-11-11 13:11:42 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:11:42 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:11:42 --> Utf8 Class Initialized
INFO - 2016-11-11 13:11:42 --> URI Class Initialized
INFO - 2016-11-11 13:11:42 --> Router Class Initialized
INFO - 2016-11-11 13:11:42 --> Output Class Initialized
INFO - 2016-11-11 13:11:42 --> Security Class Initialized
DEBUG - 2016-11-11 13:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:11:42 --> Input Class Initialized
INFO - 2016-11-11 13:11:42 --> Language Class Initialized
INFO - 2016-11-11 13:11:42 --> Loader Class Initialized
INFO - 2016-11-11 13:11:42 --> Helper loaded: url_helper
INFO - 2016-11-11 13:11:42 --> Helper loaded: form_helper
INFO - 2016-11-11 13:11:42 --> Database Driver Class Initialized
INFO - 2016-11-11 13:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:11:42 --> Controller Class Initialized
INFO - 2016-11-11 13:11:42 --> Model Class Initialized
INFO - 2016-11-11 13:11:42 --> Model Class Initialized
INFO - 2016-11-11 13:11:42 --> Model Class Initialized
INFO - 2016-11-11 13:11:42 --> Model Class Initialized
DEBUG - 2016-11-11 13:11:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-11 13:11:42 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
ERROR - 2016-11-11 13:11:42 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
INFO - 2016-11-11 13:11:42 --> Config Class Initialized
INFO - 2016-11-11 13:11:42 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:11:42 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:11:42 --> Utf8 Class Initialized
INFO - 2016-11-11 13:11:42 --> URI Class Initialized
DEBUG - 2016-11-11 13:11:42 --> No URI present. Default controller set.
INFO - 2016-11-11 13:11:42 --> Router Class Initialized
INFO - 2016-11-11 13:11:42 --> Output Class Initialized
INFO - 2016-11-11 13:11:42 --> Security Class Initialized
DEBUG - 2016-11-11 13:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:11:42 --> Input Class Initialized
INFO - 2016-11-11 13:11:42 --> Language Class Initialized
INFO - 2016-11-11 13:11:42 --> Loader Class Initialized
INFO - 2016-11-11 13:11:42 --> Helper loaded: url_helper
INFO - 2016-11-11 13:11:42 --> Helper loaded: form_helper
INFO - 2016-11-11 13:11:42 --> Database Driver Class Initialized
INFO - 2016-11-11 13:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:11:42 --> Controller Class Initialized
INFO - 2016-11-11 13:11:42 --> Model Class Initialized
INFO - 2016-11-11 13:11:42 --> Model Class Initialized
INFO - 2016-11-11 13:11:42 --> Model Class Initialized
INFO - 2016-11-11 13:11:42 --> Model Class Initialized
INFO - 2016-11-11 13:11:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:11:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-11 13:11:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:11:42 --> Final output sent to browser
DEBUG - 2016-11-11 13:11:43 --> Total execution time: 0.3768
INFO - 2016-11-11 13:11:52 --> Config Class Initialized
INFO - 2016-11-11 13:11:52 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:11:52 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:11:52 --> Utf8 Class Initialized
INFO - 2016-11-11 13:11:52 --> URI Class Initialized
INFO - 2016-11-11 13:11:52 --> Router Class Initialized
INFO - 2016-11-11 13:11:52 --> Output Class Initialized
INFO - 2016-11-11 13:11:52 --> Security Class Initialized
DEBUG - 2016-11-11 13:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:11:52 --> Input Class Initialized
INFO - 2016-11-11 13:11:52 --> Language Class Initialized
INFO - 2016-11-11 13:11:52 --> Loader Class Initialized
INFO - 2016-11-11 13:11:52 --> Helper loaded: url_helper
INFO - 2016-11-11 13:11:52 --> Helper loaded: form_helper
INFO - 2016-11-11 13:11:52 --> Database Driver Class Initialized
INFO - 2016-11-11 13:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:11:52 --> Controller Class Initialized
INFO - 2016-11-11 13:11:52 --> Model Class Initialized
INFO - 2016-11-11 13:11:52 --> Model Class Initialized
INFO - 2016-11-11 13:11:52 --> Model Class Initialized
INFO - 2016-11-11 13:11:52 --> Model Class Initialized
DEBUG - 2016-11-11 13:11:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-11 13:11:52 --> Model Class Initialized
INFO - 2016-11-11 13:11:52 --> Final output sent to browser
DEBUG - 2016-11-11 13:11:52 --> Total execution time: 0.1773
INFO - 2016-11-11 13:11:52 --> Config Class Initialized
INFO - 2016-11-11 13:11:52 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:11:52 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:11:52 --> Utf8 Class Initialized
INFO - 2016-11-11 13:11:52 --> URI Class Initialized
DEBUG - 2016-11-11 13:11:52 --> No URI present. Default controller set.
INFO - 2016-11-11 13:11:52 --> Router Class Initialized
INFO - 2016-11-11 13:11:52 --> Output Class Initialized
INFO - 2016-11-11 13:11:52 --> Security Class Initialized
DEBUG - 2016-11-11 13:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:11:52 --> Input Class Initialized
INFO - 2016-11-11 13:11:52 --> Language Class Initialized
INFO - 2016-11-11 13:11:52 --> Loader Class Initialized
INFO - 2016-11-11 13:11:52 --> Helper loaded: url_helper
INFO - 2016-11-11 13:11:52 --> Helper loaded: form_helper
INFO - 2016-11-11 13:11:52 --> Database Driver Class Initialized
INFO - 2016-11-11 13:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:11:52 --> Controller Class Initialized
INFO - 2016-11-11 13:11:52 --> Model Class Initialized
INFO - 2016-11-11 13:11:52 --> Model Class Initialized
INFO - 2016-11-11 13:11:52 --> Model Class Initialized
INFO - 2016-11-11 13:11:52 --> Model Class Initialized
INFO - 2016-11-11 13:11:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:11:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 13:11:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 13:11:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 13:11:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 13:11:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 13:11:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 13:11:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 13:11:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 13:11:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 13:11:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 13:11:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:11:52 --> Final output sent to browser
DEBUG - 2016-11-11 13:11:52 --> Total execution time: 0.2748
INFO - 2016-11-11 13:16:42 --> Config Class Initialized
INFO - 2016-11-11 13:16:42 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:16:42 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:16:42 --> Utf8 Class Initialized
INFO - 2016-11-11 13:16:42 --> URI Class Initialized
DEBUG - 2016-11-11 13:16:42 --> No URI present. Default controller set.
INFO - 2016-11-11 13:16:42 --> Router Class Initialized
INFO - 2016-11-11 13:16:42 --> Output Class Initialized
INFO - 2016-11-11 13:16:42 --> Security Class Initialized
DEBUG - 2016-11-11 13:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:16:42 --> Input Class Initialized
INFO - 2016-11-11 13:16:42 --> Language Class Initialized
INFO - 2016-11-11 13:16:42 --> Loader Class Initialized
INFO - 2016-11-11 13:16:42 --> Helper loaded: url_helper
INFO - 2016-11-11 13:16:42 --> Helper loaded: form_helper
INFO - 2016-11-11 13:16:42 --> Database Driver Class Initialized
INFO - 2016-11-11 13:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:16:42 --> Controller Class Initialized
INFO - 2016-11-11 13:16:42 --> Model Class Initialized
INFO - 2016-11-11 13:16:42 --> Model Class Initialized
INFO - 2016-11-11 13:16:42 --> Model Class Initialized
INFO - 2016-11-11 13:16:42 --> Model Class Initialized
INFO - 2016-11-11 13:16:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:16:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 13:16:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 13:16:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 13:16:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 13:16:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 13:16:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 13:16:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 13:16:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 13:16:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 13:16:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 13:16:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:16:43 --> Final output sent to browser
DEBUG - 2016-11-11 13:16:43 --> Total execution time: 0.3044
INFO - 2016-11-11 13:16:44 --> Config Class Initialized
INFO - 2016-11-11 13:16:44 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:16:44 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:16:44 --> Utf8 Class Initialized
INFO - 2016-11-11 13:16:44 --> URI Class Initialized
DEBUG - 2016-11-11 13:16:44 --> No URI present. Default controller set.
INFO - 2016-11-11 13:16:44 --> Router Class Initialized
INFO - 2016-11-11 13:16:44 --> Output Class Initialized
INFO - 2016-11-11 13:16:44 --> Security Class Initialized
DEBUG - 2016-11-11 13:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:16:45 --> Input Class Initialized
INFO - 2016-11-11 13:16:45 --> Language Class Initialized
INFO - 2016-11-11 13:16:45 --> Loader Class Initialized
INFO - 2016-11-11 13:16:45 --> Helper loaded: url_helper
INFO - 2016-11-11 13:16:45 --> Helper loaded: form_helper
INFO - 2016-11-11 13:16:45 --> Database Driver Class Initialized
INFO - 2016-11-11 13:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:16:45 --> Controller Class Initialized
INFO - 2016-11-11 13:16:45 --> Model Class Initialized
INFO - 2016-11-11 13:16:45 --> Model Class Initialized
INFO - 2016-11-11 13:16:45 --> Model Class Initialized
INFO - 2016-11-11 13:16:45 --> Model Class Initialized
INFO - 2016-11-11 13:16:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:16:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 13:16:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 13:16:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 13:16:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 13:16:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 13:16:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 13:16:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 13:16:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 13:16:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 13:16:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 13:16:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:16:45 --> Final output sent to browser
DEBUG - 2016-11-11 13:16:45 --> Total execution time: 0.3655
INFO - 2016-11-11 13:21:26 --> Config Class Initialized
INFO - 2016-11-11 13:21:26 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:21:26 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:21:26 --> Utf8 Class Initialized
INFO - 2016-11-11 13:21:26 --> URI Class Initialized
DEBUG - 2016-11-11 13:21:26 --> No URI present. Default controller set.
INFO - 2016-11-11 13:21:26 --> Router Class Initialized
INFO - 2016-11-11 13:21:26 --> Output Class Initialized
INFO - 2016-11-11 13:21:26 --> Security Class Initialized
DEBUG - 2016-11-11 13:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:21:26 --> Input Class Initialized
INFO - 2016-11-11 13:21:26 --> Language Class Initialized
INFO - 2016-11-11 13:21:26 --> Loader Class Initialized
INFO - 2016-11-11 13:21:26 --> Helper loaded: url_helper
INFO - 2016-11-11 13:21:26 --> Helper loaded: form_helper
INFO - 2016-11-11 13:21:26 --> Database Driver Class Initialized
INFO - 2016-11-11 13:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:21:26 --> Controller Class Initialized
INFO - 2016-11-11 13:21:26 --> Model Class Initialized
INFO - 2016-11-11 13:21:26 --> Model Class Initialized
INFO - 2016-11-11 13:21:26 --> Model Class Initialized
INFO - 2016-11-11 13:21:26 --> Model Class Initialized
INFO - 2016-11-11 13:21:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:21:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 13:21:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 13:21:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 13:21:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 13:21:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 13:21:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 13:21:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 13:21:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 13:21:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 13:21:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 13:21:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:21:26 --> Final output sent to browser
DEBUG - 2016-11-11 13:21:26 --> Total execution time: 0.2971
INFO - 2016-11-11 13:24:52 --> Config Class Initialized
INFO - 2016-11-11 13:24:52 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:24:52 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:24:52 --> Utf8 Class Initialized
INFO - 2016-11-11 13:24:52 --> URI Class Initialized
DEBUG - 2016-11-11 13:24:52 --> No URI present. Default controller set.
INFO - 2016-11-11 13:24:52 --> Router Class Initialized
INFO - 2016-11-11 13:24:52 --> Output Class Initialized
INFO - 2016-11-11 13:24:52 --> Security Class Initialized
DEBUG - 2016-11-11 13:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:24:52 --> Input Class Initialized
INFO - 2016-11-11 13:24:52 --> Language Class Initialized
INFO - 2016-11-11 13:24:52 --> Loader Class Initialized
INFO - 2016-11-11 13:24:52 --> Helper loaded: url_helper
INFO - 2016-11-11 13:24:52 --> Helper loaded: form_helper
INFO - 2016-11-11 13:24:52 --> Database Driver Class Initialized
INFO - 2016-11-11 13:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:24:52 --> Controller Class Initialized
INFO - 2016-11-11 13:24:52 --> Model Class Initialized
INFO - 2016-11-11 13:24:52 --> Model Class Initialized
INFO - 2016-11-11 13:24:52 --> Model Class Initialized
INFO - 2016-11-11 13:24:52 --> Model Class Initialized
INFO - 2016-11-11 13:24:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:24:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 13:24:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 13:24:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 13:24:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 13:24:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 13:24:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 13:24:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 13:24:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 13:24:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 13:24:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 13:24:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:24:52 --> Final output sent to browser
DEBUG - 2016-11-11 13:24:52 --> Total execution time: 0.2918
INFO - 2016-11-11 13:34:52 --> Config Class Initialized
INFO - 2016-11-11 13:34:52 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:34:52 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:34:52 --> Utf8 Class Initialized
INFO - 2016-11-11 13:34:52 --> URI Class Initialized
INFO - 2016-11-11 13:34:52 --> Router Class Initialized
INFO - 2016-11-11 13:34:52 --> Output Class Initialized
INFO - 2016-11-11 13:34:52 --> Security Class Initialized
DEBUG - 2016-11-11 13:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:34:52 --> Input Class Initialized
INFO - 2016-11-11 13:34:52 --> Language Class Initialized
INFO - 2016-11-11 13:34:52 --> Loader Class Initialized
INFO - 2016-11-11 13:34:52 --> Helper loaded: url_helper
INFO - 2016-11-11 13:34:52 --> Helper loaded: form_helper
INFO - 2016-11-11 13:34:52 --> Database Driver Class Initialized
INFO - 2016-11-11 13:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:34:52 --> Controller Class Initialized
INFO - 2016-11-11 13:34:52 --> Model Class Initialized
INFO - 2016-11-11 13:34:52 --> Model Class Initialized
INFO - 2016-11-11 13:34:52 --> Model Class Initialized
INFO - 2016-11-11 13:34:52 --> Model Class Initialized
DEBUG - 2016-11-11 13:34:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-11 13:34:52 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
ERROR - 2016-11-11 13:34:52 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
INFO - 2016-11-11 13:34:52 --> Config Class Initialized
INFO - 2016-11-11 13:34:52 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:34:52 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:34:52 --> Utf8 Class Initialized
INFO - 2016-11-11 13:34:52 --> URI Class Initialized
DEBUG - 2016-11-11 13:34:52 --> No URI present. Default controller set.
INFO - 2016-11-11 13:34:52 --> Router Class Initialized
INFO - 2016-11-11 13:34:52 --> Output Class Initialized
INFO - 2016-11-11 13:34:52 --> Security Class Initialized
DEBUG - 2016-11-11 13:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:34:52 --> Input Class Initialized
INFO - 2016-11-11 13:34:52 --> Language Class Initialized
INFO - 2016-11-11 13:34:52 --> Loader Class Initialized
INFO - 2016-11-11 13:34:52 --> Helper loaded: url_helper
INFO - 2016-11-11 13:34:52 --> Helper loaded: form_helper
INFO - 2016-11-11 13:34:52 --> Database Driver Class Initialized
INFO - 2016-11-11 13:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:34:52 --> Controller Class Initialized
INFO - 2016-11-11 13:34:52 --> Model Class Initialized
INFO - 2016-11-11 13:34:52 --> Model Class Initialized
INFO - 2016-11-11 13:34:52 --> Model Class Initialized
INFO - 2016-11-11 13:34:52 --> Model Class Initialized
INFO - 2016-11-11 13:34:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:34:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-11 13:34:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:34:52 --> Final output sent to browser
DEBUG - 2016-11-11 13:34:52 --> Total execution time: 0.2150
INFO - 2016-11-11 13:36:39 --> Config Class Initialized
INFO - 2016-11-11 13:36:39 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:36:39 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:36:39 --> Utf8 Class Initialized
INFO - 2016-11-11 13:36:39 --> URI Class Initialized
INFO - 2016-11-11 13:36:39 --> Router Class Initialized
INFO - 2016-11-11 13:36:39 --> Output Class Initialized
INFO - 2016-11-11 13:36:39 --> Security Class Initialized
DEBUG - 2016-11-11 13:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:36:39 --> Input Class Initialized
INFO - 2016-11-11 13:36:39 --> Language Class Initialized
INFO - 2016-11-11 13:36:39 --> Loader Class Initialized
INFO - 2016-11-11 13:36:39 --> Helper loaded: url_helper
INFO - 2016-11-11 13:36:39 --> Helper loaded: form_helper
INFO - 2016-11-11 13:36:39 --> Database Driver Class Initialized
INFO - 2016-11-11 13:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:36:39 --> Controller Class Initialized
INFO - 2016-11-11 13:36:39 --> Model Class Initialized
INFO - 2016-11-11 13:36:39 --> Model Class Initialized
INFO - 2016-11-11 13:36:39 --> Model Class Initialized
INFO - 2016-11-11 13:36:39 --> Model Class Initialized
DEBUG - 2016-11-11 13:36:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-11 13:36:39 --> Model Class Initialized
INFO - 2016-11-11 13:36:39 --> Final output sent to browser
DEBUG - 2016-11-11 13:36:39 --> Total execution time: 0.1976
INFO - 2016-11-11 13:36:39 --> Config Class Initialized
INFO - 2016-11-11 13:36:39 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:36:39 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:36:39 --> Utf8 Class Initialized
INFO - 2016-11-11 13:36:39 --> URI Class Initialized
DEBUG - 2016-11-11 13:36:39 --> No URI present. Default controller set.
INFO - 2016-11-11 13:36:39 --> Router Class Initialized
INFO - 2016-11-11 13:36:39 --> Output Class Initialized
INFO - 2016-11-11 13:36:39 --> Security Class Initialized
DEBUG - 2016-11-11 13:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:36:39 --> Input Class Initialized
INFO - 2016-11-11 13:36:39 --> Language Class Initialized
INFO - 2016-11-11 13:36:39 --> Loader Class Initialized
INFO - 2016-11-11 13:36:39 --> Helper loaded: url_helper
INFO - 2016-11-11 13:36:39 --> Helper loaded: form_helper
INFO - 2016-11-11 13:36:39 --> Database Driver Class Initialized
INFO - 2016-11-11 13:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:36:39 --> Controller Class Initialized
INFO - 2016-11-11 13:36:39 --> Model Class Initialized
INFO - 2016-11-11 13:36:39 --> Model Class Initialized
INFO - 2016-11-11 13:36:39 --> Model Class Initialized
INFO - 2016-11-11 13:36:39 --> Model Class Initialized
INFO - 2016-11-11 13:36:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:36:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 13:36:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 13:36:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 13:36:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 13:36:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 13:36:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 13:36:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 13:36:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 13:36:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 13:36:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 13:36:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:36:39 --> Final output sent to browser
DEBUG - 2016-11-11 13:36:39 --> Total execution time: 0.3023
INFO - 2016-11-11 13:36:51 --> Config Class Initialized
INFO - 2016-11-11 13:36:51 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:36:51 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:36:51 --> Utf8 Class Initialized
INFO - 2016-11-11 13:36:51 --> URI Class Initialized
INFO - 2016-11-11 13:36:51 --> Router Class Initialized
INFO - 2016-11-11 13:36:51 --> Output Class Initialized
INFO - 2016-11-11 13:36:51 --> Security Class Initialized
DEBUG - 2016-11-11 13:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:36:51 --> Input Class Initialized
INFO - 2016-11-11 13:36:51 --> Language Class Initialized
INFO - 2016-11-11 13:36:51 --> Loader Class Initialized
INFO - 2016-11-11 13:36:51 --> Helper loaded: url_helper
INFO - 2016-11-11 13:36:51 --> Helper loaded: form_helper
INFO - 2016-11-11 13:36:51 --> Database Driver Class Initialized
INFO - 2016-11-11 13:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:36:51 --> Controller Class Initialized
INFO - 2016-11-11 13:36:51 --> Model Class Initialized
INFO - 2016-11-11 13:36:51 --> Model Class Initialized
INFO - 2016-11-11 13:36:51 --> Model Class Initialized
INFO - 2016-11-11 13:36:51 --> Model Class Initialized
DEBUG - 2016-11-11 13:36:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-11 13:36:51 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
ERROR - 2016-11-11 13:36:51 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
INFO - 2016-11-11 13:36:51 --> Config Class Initialized
INFO - 2016-11-11 13:36:51 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:36:51 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:36:51 --> Utf8 Class Initialized
INFO - 2016-11-11 13:36:51 --> URI Class Initialized
DEBUG - 2016-11-11 13:36:51 --> No URI present. Default controller set.
INFO - 2016-11-11 13:36:51 --> Router Class Initialized
INFO - 2016-11-11 13:36:51 --> Output Class Initialized
INFO - 2016-11-11 13:36:51 --> Security Class Initialized
DEBUG - 2016-11-11 13:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:36:51 --> Input Class Initialized
INFO - 2016-11-11 13:36:51 --> Language Class Initialized
INFO - 2016-11-11 13:36:51 --> Loader Class Initialized
INFO - 2016-11-11 13:36:51 --> Helper loaded: url_helper
INFO - 2016-11-11 13:36:51 --> Helper loaded: form_helper
INFO - 2016-11-11 13:36:51 --> Database Driver Class Initialized
INFO - 2016-11-11 13:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:36:51 --> Controller Class Initialized
INFO - 2016-11-11 13:36:51 --> Model Class Initialized
INFO - 2016-11-11 13:36:51 --> Model Class Initialized
INFO - 2016-11-11 13:36:51 --> Model Class Initialized
INFO - 2016-11-11 13:36:51 --> Model Class Initialized
INFO - 2016-11-11 13:36:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:36:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-11 13:36:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:36:51 --> Final output sent to browser
DEBUG - 2016-11-11 13:36:51 --> Total execution time: 0.2226
INFO - 2016-11-11 13:37:04 --> Config Class Initialized
INFO - 2016-11-11 13:37:04 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:37:04 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:37:04 --> Utf8 Class Initialized
INFO - 2016-11-11 13:37:04 --> URI Class Initialized
INFO - 2016-11-11 13:37:04 --> Router Class Initialized
INFO - 2016-11-11 13:37:04 --> Output Class Initialized
INFO - 2016-11-11 13:37:04 --> Security Class Initialized
DEBUG - 2016-11-11 13:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:37:04 --> Input Class Initialized
INFO - 2016-11-11 13:37:04 --> Language Class Initialized
INFO - 2016-11-11 13:37:04 --> Loader Class Initialized
INFO - 2016-11-11 13:37:04 --> Helper loaded: url_helper
INFO - 2016-11-11 13:37:04 --> Helper loaded: form_helper
INFO - 2016-11-11 13:37:04 --> Database Driver Class Initialized
INFO - 2016-11-11 13:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:37:04 --> Controller Class Initialized
INFO - 2016-11-11 13:37:04 --> Model Class Initialized
INFO - 2016-11-11 13:37:04 --> Model Class Initialized
INFO - 2016-11-11 13:37:04 --> Model Class Initialized
INFO - 2016-11-11 13:37:04 --> Model Class Initialized
DEBUG - 2016-11-11 13:37:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-11 13:37:04 --> Model Class Initialized
INFO - 2016-11-11 13:37:04 --> Final output sent to browser
DEBUG - 2016-11-11 13:37:04 --> Total execution time: 0.2132
INFO - 2016-11-11 13:37:04 --> Config Class Initialized
INFO - 2016-11-11 13:37:04 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:37:04 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:37:04 --> Utf8 Class Initialized
INFO - 2016-11-11 13:37:04 --> URI Class Initialized
DEBUG - 2016-11-11 13:37:04 --> No URI present. Default controller set.
INFO - 2016-11-11 13:37:04 --> Router Class Initialized
INFO - 2016-11-11 13:37:04 --> Output Class Initialized
INFO - 2016-11-11 13:37:04 --> Security Class Initialized
DEBUG - 2016-11-11 13:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:37:04 --> Input Class Initialized
INFO - 2016-11-11 13:37:04 --> Language Class Initialized
INFO - 2016-11-11 13:37:05 --> Loader Class Initialized
INFO - 2016-11-11 13:37:05 --> Helper loaded: url_helper
INFO - 2016-11-11 13:37:05 --> Helper loaded: form_helper
INFO - 2016-11-11 13:37:05 --> Database Driver Class Initialized
INFO - 2016-11-11 13:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:37:05 --> Controller Class Initialized
INFO - 2016-11-11 13:37:05 --> Model Class Initialized
INFO - 2016-11-11 13:37:05 --> Model Class Initialized
INFO - 2016-11-11 13:37:05 --> Model Class Initialized
INFO - 2016-11-11 13:37:05 --> Model Class Initialized
INFO - 2016-11-11 13:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 13:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 13:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 13:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 13:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 13:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 13:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 13:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 13:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 13:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 13:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:37:05 --> Final output sent to browser
DEBUG - 2016-11-11 13:37:05 --> Total execution time: 0.3127
INFO - 2016-11-11 13:37:35 --> Config Class Initialized
INFO - 2016-11-11 13:37:35 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:37:35 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:37:35 --> Utf8 Class Initialized
INFO - 2016-11-11 13:37:35 --> URI Class Initialized
INFO - 2016-11-11 13:37:35 --> Router Class Initialized
INFO - 2016-11-11 13:37:35 --> Output Class Initialized
INFO - 2016-11-11 13:37:35 --> Security Class Initialized
DEBUG - 2016-11-11 13:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:37:35 --> Input Class Initialized
INFO - 2016-11-11 13:37:35 --> Language Class Initialized
INFO - 2016-11-11 13:37:35 --> Loader Class Initialized
INFO - 2016-11-11 13:37:35 --> Helper loaded: url_helper
INFO - 2016-11-11 13:37:35 --> Helper loaded: form_helper
INFO - 2016-11-11 13:37:35 --> Database Driver Class Initialized
INFO - 2016-11-11 13:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:37:35 --> Controller Class Initialized
INFO - 2016-11-11 13:37:35 --> Model Class Initialized
INFO - 2016-11-11 13:37:35 --> Model Class Initialized
INFO - 2016-11-11 13:37:35 --> Model Class Initialized
INFO - 2016-11-11 13:37:35 --> Model Class Initialized
DEBUG - 2016-11-11 13:37:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-11 13:37:35 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
ERROR - 2016-11-11 13:37:35 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
INFO - 2016-11-11 13:37:35 --> Config Class Initialized
INFO - 2016-11-11 13:37:35 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:37:35 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:37:35 --> Utf8 Class Initialized
INFO - 2016-11-11 13:37:35 --> URI Class Initialized
DEBUG - 2016-11-11 13:37:35 --> No URI present. Default controller set.
INFO - 2016-11-11 13:37:35 --> Router Class Initialized
INFO - 2016-11-11 13:37:35 --> Output Class Initialized
INFO - 2016-11-11 13:37:35 --> Security Class Initialized
DEBUG - 2016-11-11 13:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:37:35 --> Input Class Initialized
INFO - 2016-11-11 13:37:35 --> Language Class Initialized
INFO - 2016-11-11 13:37:35 --> Loader Class Initialized
INFO - 2016-11-11 13:37:35 --> Helper loaded: url_helper
INFO - 2016-11-11 13:37:35 --> Helper loaded: form_helper
INFO - 2016-11-11 13:37:35 --> Database Driver Class Initialized
INFO - 2016-11-11 13:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:37:36 --> Controller Class Initialized
INFO - 2016-11-11 13:37:36 --> Model Class Initialized
INFO - 2016-11-11 13:37:36 --> Model Class Initialized
INFO - 2016-11-11 13:37:36 --> Model Class Initialized
INFO - 2016-11-11 13:37:36 --> Model Class Initialized
INFO - 2016-11-11 13:37:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:37:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-11 13:37:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:37:36 --> Final output sent to browser
DEBUG - 2016-11-11 13:37:36 --> Total execution time: 0.2206
INFO - 2016-11-11 13:37:53 --> Config Class Initialized
INFO - 2016-11-11 13:37:53 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:37:53 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:37:53 --> Utf8 Class Initialized
INFO - 2016-11-11 13:37:53 --> URI Class Initialized
INFO - 2016-11-11 13:37:53 --> Router Class Initialized
INFO - 2016-11-11 13:37:53 --> Output Class Initialized
INFO - 2016-11-11 13:37:53 --> Security Class Initialized
DEBUG - 2016-11-11 13:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:37:53 --> Input Class Initialized
INFO - 2016-11-11 13:37:53 --> Language Class Initialized
INFO - 2016-11-11 13:37:53 --> Loader Class Initialized
INFO - 2016-11-11 13:37:53 --> Helper loaded: url_helper
INFO - 2016-11-11 13:37:53 --> Helper loaded: form_helper
INFO - 2016-11-11 13:37:53 --> Database Driver Class Initialized
INFO - 2016-11-11 13:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:37:53 --> Controller Class Initialized
INFO - 2016-11-11 13:37:53 --> Model Class Initialized
INFO - 2016-11-11 13:37:53 --> Model Class Initialized
INFO - 2016-11-11 13:37:53 --> Model Class Initialized
INFO - 2016-11-11 13:37:53 --> Model Class Initialized
DEBUG - 2016-11-11 13:37:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-11 13:37:53 --> Model Class Initialized
INFO - 2016-11-11 13:37:53 --> Final output sent to browser
DEBUG - 2016-11-11 13:37:53 --> Total execution time: 0.2197
INFO - 2016-11-11 13:37:53 --> Config Class Initialized
INFO - 2016-11-11 13:37:53 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:37:53 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:37:53 --> Utf8 Class Initialized
INFO - 2016-11-11 13:37:54 --> URI Class Initialized
DEBUG - 2016-11-11 13:37:54 --> No URI present. Default controller set.
INFO - 2016-11-11 13:37:54 --> Router Class Initialized
INFO - 2016-11-11 13:37:54 --> Output Class Initialized
INFO - 2016-11-11 13:37:54 --> Security Class Initialized
DEBUG - 2016-11-11 13:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:37:54 --> Input Class Initialized
INFO - 2016-11-11 13:37:54 --> Language Class Initialized
INFO - 2016-11-11 13:37:54 --> Loader Class Initialized
INFO - 2016-11-11 13:37:54 --> Helper loaded: url_helper
INFO - 2016-11-11 13:37:54 --> Helper loaded: form_helper
INFO - 2016-11-11 13:37:54 --> Database Driver Class Initialized
INFO - 2016-11-11 13:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:37:54 --> Controller Class Initialized
INFO - 2016-11-11 13:37:54 --> Model Class Initialized
INFO - 2016-11-11 13:37:54 --> Model Class Initialized
INFO - 2016-11-11 13:37:54 --> Model Class Initialized
INFO - 2016-11-11 13:37:54 --> Model Class Initialized
INFO - 2016-11-11 13:37:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:37:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 13:37:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 13:37:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 13:37:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 13:37:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 13:37:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 13:37:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 13:37:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 13:37:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 13:37:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 13:37:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:37:54 --> Final output sent to browser
DEBUG - 2016-11-11 13:37:54 --> Total execution time: 0.3176
INFO - 2016-11-11 13:38:06 --> Config Class Initialized
INFO - 2016-11-11 13:38:06 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:38:06 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:38:06 --> Utf8 Class Initialized
INFO - 2016-11-11 13:38:06 --> URI Class Initialized
INFO - 2016-11-11 13:38:06 --> Router Class Initialized
INFO - 2016-11-11 13:38:06 --> Output Class Initialized
INFO - 2016-11-11 13:38:06 --> Security Class Initialized
DEBUG - 2016-11-11 13:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:38:06 --> Input Class Initialized
INFO - 2016-11-11 13:38:06 --> Language Class Initialized
INFO - 2016-11-11 13:38:06 --> Loader Class Initialized
INFO - 2016-11-11 13:38:06 --> Helper loaded: url_helper
INFO - 2016-11-11 13:38:06 --> Helper loaded: form_helper
INFO - 2016-11-11 13:38:06 --> Database Driver Class Initialized
INFO - 2016-11-11 13:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:38:07 --> Controller Class Initialized
INFO - 2016-11-11 13:38:07 --> Model Class Initialized
INFO - 2016-11-11 13:38:07 --> Model Class Initialized
INFO - 2016-11-11 13:38:07 --> Model Class Initialized
INFO - 2016-11-11 13:38:07 --> Model Class Initialized
DEBUG - 2016-11-11 13:38:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-11 13:38:07 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
ERROR - 2016-11-11 13:38:07 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
INFO - 2016-11-11 13:38:07 --> Config Class Initialized
INFO - 2016-11-11 13:38:07 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:38:07 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:38:07 --> Utf8 Class Initialized
INFO - 2016-11-11 13:38:07 --> URI Class Initialized
DEBUG - 2016-11-11 13:38:07 --> No URI present. Default controller set.
INFO - 2016-11-11 13:38:07 --> Router Class Initialized
INFO - 2016-11-11 13:38:07 --> Output Class Initialized
INFO - 2016-11-11 13:38:07 --> Security Class Initialized
DEBUG - 2016-11-11 13:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:38:07 --> Input Class Initialized
INFO - 2016-11-11 13:38:07 --> Language Class Initialized
INFO - 2016-11-11 13:38:07 --> Loader Class Initialized
INFO - 2016-11-11 13:38:07 --> Helper loaded: url_helper
INFO - 2016-11-11 13:38:07 --> Helper loaded: form_helper
INFO - 2016-11-11 13:38:07 --> Database Driver Class Initialized
INFO - 2016-11-11 13:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:38:07 --> Controller Class Initialized
INFO - 2016-11-11 13:38:07 --> Model Class Initialized
INFO - 2016-11-11 13:38:07 --> Model Class Initialized
INFO - 2016-11-11 13:38:07 --> Model Class Initialized
INFO - 2016-11-11 13:38:07 --> Model Class Initialized
INFO - 2016-11-11 13:38:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:38:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-11 13:38:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:38:07 --> Final output sent to browser
DEBUG - 2016-11-11 13:38:07 --> Total execution time: 0.2438
INFO - 2016-11-11 13:38:22 --> Config Class Initialized
INFO - 2016-11-11 13:38:22 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:38:22 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:38:22 --> Utf8 Class Initialized
INFO - 2016-11-11 13:38:22 --> URI Class Initialized
INFO - 2016-11-11 13:38:22 --> Router Class Initialized
INFO - 2016-11-11 13:38:22 --> Output Class Initialized
INFO - 2016-11-11 13:38:22 --> Security Class Initialized
DEBUG - 2016-11-11 13:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:38:22 --> Input Class Initialized
INFO - 2016-11-11 13:38:22 --> Language Class Initialized
INFO - 2016-11-11 13:38:22 --> Loader Class Initialized
INFO - 2016-11-11 13:38:22 --> Helper loaded: url_helper
INFO - 2016-11-11 13:38:22 --> Helper loaded: form_helper
INFO - 2016-11-11 13:38:22 --> Database Driver Class Initialized
INFO - 2016-11-11 13:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:38:22 --> Controller Class Initialized
INFO - 2016-11-11 13:38:22 --> Model Class Initialized
INFO - 2016-11-11 13:38:22 --> Model Class Initialized
INFO - 2016-11-11 13:38:22 --> Model Class Initialized
INFO - 2016-11-11 13:38:22 --> Model Class Initialized
DEBUG - 2016-11-11 13:38:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-11 13:38:22 --> Model Class Initialized
INFO - 2016-11-11 13:38:22 --> Final output sent to browser
DEBUG - 2016-11-11 13:38:22 --> Total execution time: 0.2152
INFO - 2016-11-11 13:38:22 --> Config Class Initialized
INFO - 2016-11-11 13:38:22 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:38:22 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:38:22 --> Utf8 Class Initialized
INFO - 2016-11-11 13:38:22 --> URI Class Initialized
DEBUG - 2016-11-11 13:38:22 --> No URI present. Default controller set.
INFO - 2016-11-11 13:38:22 --> Router Class Initialized
INFO - 2016-11-11 13:38:22 --> Output Class Initialized
INFO - 2016-11-11 13:38:22 --> Security Class Initialized
DEBUG - 2016-11-11 13:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:38:22 --> Input Class Initialized
INFO - 2016-11-11 13:38:22 --> Language Class Initialized
INFO - 2016-11-11 13:38:22 --> Loader Class Initialized
INFO - 2016-11-11 13:38:22 --> Helper loaded: url_helper
INFO - 2016-11-11 13:38:22 --> Helper loaded: form_helper
INFO - 2016-11-11 13:38:22 --> Database Driver Class Initialized
INFO - 2016-11-11 13:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:38:22 --> Controller Class Initialized
INFO - 2016-11-11 13:38:22 --> Model Class Initialized
INFO - 2016-11-11 13:38:22 --> Model Class Initialized
INFO - 2016-11-11 13:38:22 --> Model Class Initialized
INFO - 2016-11-11 13:38:22 --> Model Class Initialized
INFO - 2016-11-11 13:38:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:38:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 13:38:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 13:38:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 13:38:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 13:38:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 13:38:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 13:38:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 13:38:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 13:38:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 13:38:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 13:38:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:38:22 --> Final output sent to browser
DEBUG - 2016-11-11 13:38:22 --> Total execution time: 0.3282
INFO - 2016-11-11 13:38:30 --> Config Class Initialized
INFO - 2016-11-11 13:38:30 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:38:30 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:38:30 --> Utf8 Class Initialized
INFO - 2016-11-11 13:38:30 --> URI Class Initialized
INFO - 2016-11-11 13:38:30 --> Router Class Initialized
INFO - 2016-11-11 13:38:30 --> Output Class Initialized
INFO - 2016-11-11 13:38:30 --> Security Class Initialized
DEBUG - 2016-11-11 13:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:38:30 --> Input Class Initialized
INFO - 2016-11-11 13:38:30 --> Language Class Initialized
INFO - 2016-11-11 13:38:30 --> Loader Class Initialized
INFO - 2016-11-11 13:38:30 --> Helper loaded: url_helper
INFO - 2016-11-11 13:38:30 --> Helper loaded: form_helper
INFO - 2016-11-11 13:38:30 --> Database Driver Class Initialized
INFO - 2016-11-11 13:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:38:30 --> Controller Class Initialized
INFO - 2016-11-11 13:38:30 --> Model Class Initialized
INFO - 2016-11-11 13:38:30 --> Model Class Initialized
INFO - 2016-11-11 13:38:30 --> Model Class Initialized
INFO - 2016-11-11 13:38:30 --> Model Class Initialized
DEBUG - 2016-11-11 13:38:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-11 13:38:30 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
ERROR - 2016-11-11 13:38:30 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
INFO - 2016-11-11 13:38:30 --> Config Class Initialized
INFO - 2016-11-11 13:38:30 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:38:30 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:38:30 --> Utf8 Class Initialized
INFO - 2016-11-11 13:38:30 --> URI Class Initialized
DEBUG - 2016-11-11 13:38:30 --> No URI present. Default controller set.
INFO - 2016-11-11 13:38:30 --> Router Class Initialized
INFO - 2016-11-11 13:38:31 --> Output Class Initialized
INFO - 2016-11-11 13:38:31 --> Security Class Initialized
DEBUG - 2016-11-11 13:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:38:31 --> Input Class Initialized
INFO - 2016-11-11 13:38:31 --> Language Class Initialized
INFO - 2016-11-11 13:38:31 --> Loader Class Initialized
INFO - 2016-11-11 13:38:31 --> Helper loaded: url_helper
INFO - 2016-11-11 13:38:31 --> Helper loaded: form_helper
INFO - 2016-11-11 13:38:31 --> Database Driver Class Initialized
INFO - 2016-11-11 13:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:38:31 --> Controller Class Initialized
INFO - 2016-11-11 13:38:31 --> Model Class Initialized
INFO - 2016-11-11 13:38:31 --> Model Class Initialized
INFO - 2016-11-11 13:38:31 --> Model Class Initialized
INFO - 2016-11-11 13:38:31 --> Model Class Initialized
INFO - 2016-11-11 13:38:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:38:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-11 13:38:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:38:31 --> Final output sent to browser
DEBUG - 2016-11-11 13:38:31 --> Total execution time: 0.2386
INFO - 2016-11-11 13:38:43 --> Config Class Initialized
INFO - 2016-11-11 13:38:43 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:38:43 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:38:43 --> Utf8 Class Initialized
INFO - 2016-11-11 13:38:43 --> URI Class Initialized
INFO - 2016-11-11 13:38:43 --> Router Class Initialized
INFO - 2016-11-11 13:38:43 --> Output Class Initialized
INFO - 2016-11-11 13:38:43 --> Security Class Initialized
DEBUG - 2016-11-11 13:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:38:43 --> Input Class Initialized
INFO - 2016-11-11 13:38:43 --> Language Class Initialized
INFO - 2016-11-11 13:38:43 --> Loader Class Initialized
INFO - 2016-11-11 13:38:43 --> Helper loaded: url_helper
INFO - 2016-11-11 13:38:43 --> Helper loaded: form_helper
INFO - 2016-11-11 13:38:43 --> Database Driver Class Initialized
INFO - 2016-11-11 13:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:38:43 --> Controller Class Initialized
INFO - 2016-11-11 13:38:43 --> Model Class Initialized
INFO - 2016-11-11 13:38:43 --> Model Class Initialized
INFO - 2016-11-11 13:38:43 --> Model Class Initialized
INFO - 2016-11-11 13:38:44 --> Model Class Initialized
DEBUG - 2016-11-11 13:38:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-11 13:38:44 --> Model Class Initialized
INFO - 2016-11-11 13:38:44 --> Final output sent to browser
DEBUG - 2016-11-11 13:38:44 --> Total execution time: 0.2361
INFO - 2016-11-11 13:38:44 --> Config Class Initialized
INFO - 2016-11-11 13:38:44 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:38:44 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:38:44 --> Utf8 Class Initialized
INFO - 2016-11-11 13:38:44 --> URI Class Initialized
DEBUG - 2016-11-11 13:38:44 --> No URI present. Default controller set.
INFO - 2016-11-11 13:38:44 --> Router Class Initialized
INFO - 2016-11-11 13:38:44 --> Output Class Initialized
INFO - 2016-11-11 13:38:44 --> Security Class Initialized
DEBUG - 2016-11-11 13:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:38:44 --> Input Class Initialized
INFO - 2016-11-11 13:38:44 --> Language Class Initialized
INFO - 2016-11-11 13:38:44 --> Loader Class Initialized
INFO - 2016-11-11 13:38:44 --> Helper loaded: url_helper
INFO - 2016-11-11 13:38:44 --> Helper loaded: form_helper
INFO - 2016-11-11 13:38:44 --> Database Driver Class Initialized
INFO - 2016-11-11 13:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:38:44 --> Controller Class Initialized
INFO - 2016-11-11 13:38:44 --> Model Class Initialized
INFO - 2016-11-11 13:38:44 --> Model Class Initialized
INFO - 2016-11-11 13:38:44 --> Model Class Initialized
INFO - 2016-11-11 13:38:44 --> Model Class Initialized
INFO - 2016-11-11 13:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 13:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 13:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 13:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 13:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 13:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 13:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 13:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 13:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 13:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 13:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:38:44 --> Final output sent to browser
DEBUG - 2016-11-11 13:38:44 --> Total execution time: 0.6196
INFO - 2016-11-11 13:42:52 --> Config Class Initialized
INFO - 2016-11-11 13:42:52 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:42:52 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:42:52 --> Utf8 Class Initialized
INFO - 2016-11-11 13:42:52 --> URI Class Initialized
DEBUG - 2016-11-11 13:42:52 --> No URI present. Default controller set.
INFO - 2016-11-11 13:42:52 --> Router Class Initialized
INFO - 2016-11-11 13:42:52 --> Output Class Initialized
INFO - 2016-11-11 13:42:52 --> Security Class Initialized
DEBUG - 2016-11-11 13:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:42:52 --> Input Class Initialized
INFO - 2016-11-11 13:42:52 --> Language Class Initialized
INFO - 2016-11-11 13:42:52 --> Loader Class Initialized
INFO - 2016-11-11 13:42:52 --> Helper loaded: url_helper
INFO - 2016-11-11 13:42:52 --> Helper loaded: form_helper
INFO - 2016-11-11 13:42:52 --> Database Driver Class Initialized
INFO - 2016-11-11 13:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:42:52 --> Controller Class Initialized
INFO - 2016-11-11 13:42:52 --> Model Class Initialized
INFO - 2016-11-11 13:42:52 --> Model Class Initialized
INFO - 2016-11-11 13:42:52 --> Model Class Initialized
INFO - 2016-11-11 13:42:52 --> Model Class Initialized
INFO - 2016-11-11 13:42:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:42:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 13:42:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 13:42:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 13:42:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 13:42:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 13:42:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 13:42:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 13:42:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 13:42:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 13:42:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 13:42:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:42:52 --> Final output sent to browser
DEBUG - 2016-11-11 13:42:52 --> Total execution time: 0.3350
INFO - 2016-11-11 13:43:32 --> Config Class Initialized
INFO - 2016-11-11 13:43:32 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:43:32 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:43:32 --> Utf8 Class Initialized
INFO - 2016-11-11 13:43:32 --> URI Class Initialized
INFO - 2016-11-11 13:43:32 --> Router Class Initialized
INFO - 2016-11-11 13:43:32 --> Output Class Initialized
INFO - 2016-11-11 13:43:32 --> Security Class Initialized
DEBUG - 2016-11-11 13:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:43:32 --> Input Class Initialized
INFO - 2016-11-11 13:43:32 --> Language Class Initialized
INFO - 2016-11-11 13:43:32 --> Loader Class Initialized
INFO - 2016-11-11 13:43:32 --> Helper loaded: url_helper
INFO - 2016-11-11 13:43:32 --> Helper loaded: form_helper
INFO - 2016-11-11 13:43:32 --> Database Driver Class Initialized
INFO - 2016-11-11 13:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:43:32 --> Controller Class Initialized
INFO - 2016-11-11 13:43:32 --> Model Class Initialized
INFO - 2016-11-11 13:43:32 --> Model Class Initialized
INFO - 2016-11-11 13:43:32 --> Model Class Initialized
INFO - 2016-11-11 13:43:32 --> Model Class Initialized
DEBUG - 2016-11-11 13:43:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-11 13:43:32 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
ERROR - 2016-11-11 13:43:32 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
INFO - 2016-11-11 13:43:33 --> Config Class Initialized
INFO - 2016-11-11 13:43:33 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:43:33 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:43:33 --> Utf8 Class Initialized
INFO - 2016-11-11 13:43:33 --> URI Class Initialized
DEBUG - 2016-11-11 13:43:33 --> No URI present. Default controller set.
INFO - 2016-11-11 13:43:33 --> Router Class Initialized
INFO - 2016-11-11 13:43:33 --> Output Class Initialized
INFO - 2016-11-11 13:43:33 --> Security Class Initialized
DEBUG - 2016-11-11 13:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:43:33 --> Input Class Initialized
INFO - 2016-11-11 13:43:33 --> Language Class Initialized
INFO - 2016-11-11 13:43:33 --> Loader Class Initialized
INFO - 2016-11-11 13:43:33 --> Helper loaded: url_helper
INFO - 2016-11-11 13:43:33 --> Helper loaded: form_helper
INFO - 2016-11-11 13:43:33 --> Database Driver Class Initialized
INFO - 2016-11-11 13:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:43:33 --> Controller Class Initialized
INFO - 2016-11-11 13:43:33 --> Model Class Initialized
INFO - 2016-11-11 13:43:33 --> Model Class Initialized
INFO - 2016-11-11 13:43:33 --> Model Class Initialized
INFO - 2016-11-11 13:43:33 --> Model Class Initialized
INFO - 2016-11-11 13:43:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:43:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-11 13:43:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:43:33 --> Final output sent to browser
DEBUG - 2016-11-11 13:43:33 --> Total execution time: 0.2411
INFO - 2016-11-11 13:43:45 --> Config Class Initialized
INFO - 2016-11-11 13:43:45 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:43:45 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:43:45 --> Utf8 Class Initialized
INFO - 2016-11-11 13:43:45 --> URI Class Initialized
INFO - 2016-11-11 13:43:45 --> Router Class Initialized
INFO - 2016-11-11 13:43:45 --> Output Class Initialized
INFO - 2016-11-11 13:43:45 --> Security Class Initialized
DEBUG - 2016-11-11 13:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:43:45 --> Input Class Initialized
INFO - 2016-11-11 13:43:45 --> Language Class Initialized
INFO - 2016-11-11 13:43:45 --> Loader Class Initialized
INFO - 2016-11-11 13:43:45 --> Helper loaded: url_helper
INFO - 2016-11-11 13:43:45 --> Helper loaded: form_helper
INFO - 2016-11-11 13:43:45 --> Database Driver Class Initialized
INFO - 2016-11-11 13:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:43:45 --> Controller Class Initialized
INFO - 2016-11-11 13:43:45 --> Model Class Initialized
INFO - 2016-11-11 13:43:45 --> Model Class Initialized
INFO - 2016-11-11 13:43:45 --> Model Class Initialized
INFO - 2016-11-11 13:43:45 --> Model Class Initialized
DEBUG - 2016-11-11 13:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-11 13:43:45 --> Model Class Initialized
INFO - 2016-11-11 13:43:45 --> Final output sent to browser
DEBUG - 2016-11-11 13:43:45 --> Total execution time: 0.2419
INFO - 2016-11-11 13:43:45 --> Config Class Initialized
INFO - 2016-11-11 13:43:45 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:43:45 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:43:45 --> Utf8 Class Initialized
INFO - 2016-11-11 13:43:45 --> URI Class Initialized
DEBUG - 2016-11-11 13:43:45 --> No URI present. Default controller set.
INFO - 2016-11-11 13:43:45 --> Router Class Initialized
INFO - 2016-11-11 13:43:45 --> Output Class Initialized
INFO - 2016-11-11 13:43:45 --> Security Class Initialized
DEBUG - 2016-11-11 13:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:43:45 --> Input Class Initialized
INFO - 2016-11-11 13:43:45 --> Language Class Initialized
INFO - 2016-11-11 13:43:45 --> Loader Class Initialized
INFO - 2016-11-11 13:43:45 --> Helper loaded: url_helper
INFO - 2016-11-11 13:43:45 --> Helper loaded: form_helper
INFO - 2016-11-11 13:43:46 --> Database Driver Class Initialized
INFO - 2016-11-11 13:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:43:46 --> Controller Class Initialized
INFO - 2016-11-11 13:43:46 --> Model Class Initialized
INFO - 2016-11-11 13:43:46 --> Model Class Initialized
INFO - 2016-11-11 13:43:46 --> Model Class Initialized
INFO - 2016-11-11 13:43:46 --> Model Class Initialized
INFO - 2016-11-11 13:43:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:43:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 13:43:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 13:43:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 13:43:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 13:43:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 13:43:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 13:43:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 13:43:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 13:43:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 13:43:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 13:43:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:43:46 --> Final output sent to browser
DEBUG - 2016-11-11 13:43:46 --> Total execution time: 0.4105
INFO - 2016-11-11 13:45:01 --> Config Class Initialized
INFO - 2016-11-11 13:45:01 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:45:01 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:45:01 --> Utf8 Class Initialized
INFO - 2016-11-11 13:45:01 --> URI Class Initialized
DEBUG - 2016-11-11 13:45:01 --> No URI present. Default controller set.
INFO - 2016-11-11 13:45:01 --> Router Class Initialized
INFO - 2016-11-11 13:45:01 --> Output Class Initialized
INFO - 2016-11-11 13:45:01 --> Security Class Initialized
DEBUG - 2016-11-11 13:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:45:01 --> Input Class Initialized
INFO - 2016-11-11 13:45:01 --> Language Class Initialized
INFO - 2016-11-11 13:45:01 --> Loader Class Initialized
INFO - 2016-11-11 13:45:01 --> Helper loaded: url_helper
INFO - 2016-11-11 13:45:01 --> Helper loaded: form_helper
INFO - 2016-11-11 13:45:01 --> Database Driver Class Initialized
INFO - 2016-11-11 13:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:45:01 --> Controller Class Initialized
INFO - 2016-11-11 13:45:01 --> Model Class Initialized
INFO - 2016-11-11 13:45:01 --> Model Class Initialized
INFO - 2016-11-11 13:45:01 --> Model Class Initialized
INFO - 2016-11-11 13:45:01 --> Model Class Initialized
INFO - 2016-11-11 13:45:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:45:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 13:45:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 13:45:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 13:45:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 13:45:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 13:45:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 13:45:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 13:45:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 13:45:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 13:45:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 13:45:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:45:01 --> Final output sent to browser
DEBUG - 2016-11-11 13:45:01 --> Total execution time: 0.3479
INFO - 2016-11-11 13:45:20 --> Config Class Initialized
INFO - 2016-11-11 13:45:20 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:45:20 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:45:20 --> Utf8 Class Initialized
INFO - 2016-11-11 13:45:20 --> URI Class Initialized
INFO - 2016-11-11 13:45:20 --> Router Class Initialized
INFO - 2016-11-11 13:45:20 --> Output Class Initialized
INFO - 2016-11-11 13:45:20 --> Security Class Initialized
DEBUG - 2016-11-11 13:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:45:20 --> Input Class Initialized
INFO - 2016-11-11 13:45:20 --> Language Class Initialized
INFO - 2016-11-11 13:45:20 --> Loader Class Initialized
INFO - 2016-11-11 13:45:20 --> Helper loaded: url_helper
INFO - 2016-11-11 13:45:20 --> Helper loaded: form_helper
INFO - 2016-11-11 13:45:20 --> Database Driver Class Initialized
INFO - 2016-11-11 13:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:45:20 --> Controller Class Initialized
INFO - 2016-11-11 13:45:20 --> Model Class Initialized
INFO - 2016-11-11 13:45:20 --> Model Class Initialized
INFO - 2016-11-11 13:45:20 --> Model Class Initialized
INFO - 2016-11-11 13:45:20 --> Model Class Initialized
DEBUG - 2016-11-11 13:45:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-11 13:45:20 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
ERROR - 2016-11-11 13:45:20 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
INFO - 2016-11-11 13:45:20 --> Config Class Initialized
INFO - 2016-11-11 13:45:20 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:45:20 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:45:20 --> Utf8 Class Initialized
INFO - 2016-11-11 13:45:20 --> URI Class Initialized
DEBUG - 2016-11-11 13:45:20 --> No URI present. Default controller set.
INFO - 2016-11-11 13:45:20 --> Router Class Initialized
INFO - 2016-11-11 13:45:20 --> Output Class Initialized
INFO - 2016-11-11 13:45:20 --> Security Class Initialized
DEBUG - 2016-11-11 13:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:45:20 --> Input Class Initialized
INFO - 2016-11-11 13:45:20 --> Language Class Initialized
INFO - 2016-11-11 13:45:20 --> Loader Class Initialized
INFO - 2016-11-11 13:45:20 --> Helper loaded: url_helper
INFO - 2016-11-11 13:45:20 --> Helper loaded: form_helper
INFO - 2016-11-11 13:45:20 --> Database Driver Class Initialized
INFO - 2016-11-11 13:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:45:20 --> Controller Class Initialized
INFO - 2016-11-11 13:45:20 --> Model Class Initialized
INFO - 2016-11-11 13:45:20 --> Model Class Initialized
INFO - 2016-11-11 13:45:20 --> Model Class Initialized
INFO - 2016-11-11 13:45:20 --> Model Class Initialized
INFO - 2016-11-11 13:45:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:45:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-11 13:45:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:45:20 --> Final output sent to browser
DEBUG - 2016-11-11 13:45:20 --> Total execution time: 0.2551
INFO - 2016-11-11 13:46:03 --> Config Class Initialized
INFO - 2016-11-11 13:46:03 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:46:03 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:46:03 --> Utf8 Class Initialized
INFO - 2016-11-11 13:46:03 --> URI Class Initialized
INFO - 2016-11-11 13:46:03 --> Router Class Initialized
INFO - 2016-11-11 13:46:03 --> Output Class Initialized
INFO - 2016-11-11 13:46:03 --> Security Class Initialized
DEBUG - 2016-11-11 13:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:46:03 --> Input Class Initialized
INFO - 2016-11-11 13:46:03 --> Language Class Initialized
INFO - 2016-11-11 13:46:03 --> Loader Class Initialized
INFO - 2016-11-11 13:46:03 --> Helper loaded: url_helper
INFO - 2016-11-11 13:46:03 --> Helper loaded: form_helper
INFO - 2016-11-11 13:46:03 --> Database Driver Class Initialized
INFO - 2016-11-11 13:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:46:03 --> Controller Class Initialized
INFO - 2016-11-11 13:46:03 --> Model Class Initialized
INFO - 2016-11-11 13:46:03 --> Model Class Initialized
INFO - 2016-11-11 13:46:03 --> Model Class Initialized
INFO - 2016-11-11 13:46:03 --> Model Class Initialized
DEBUG - 2016-11-11 13:46:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-11 13:46:03 --> Model Class Initialized
INFO - 2016-11-11 13:46:03 --> Final output sent to browser
DEBUG - 2016-11-11 13:46:03 --> Total execution time: 0.2135
INFO - 2016-11-11 13:46:04 --> Config Class Initialized
INFO - 2016-11-11 13:46:04 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:46:04 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:46:04 --> Utf8 Class Initialized
INFO - 2016-11-11 13:46:04 --> URI Class Initialized
DEBUG - 2016-11-11 13:46:04 --> No URI present. Default controller set.
INFO - 2016-11-11 13:46:04 --> Router Class Initialized
INFO - 2016-11-11 13:46:04 --> Output Class Initialized
INFO - 2016-11-11 13:46:04 --> Security Class Initialized
DEBUG - 2016-11-11 13:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:46:04 --> Input Class Initialized
INFO - 2016-11-11 13:46:04 --> Language Class Initialized
INFO - 2016-11-11 13:46:04 --> Loader Class Initialized
INFO - 2016-11-11 13:46:04 --> Helper loaded: url_helper
INFO - 2016-11-11 13:46:04 --> Helper loaded: form_helper
INFO - 2016-11-11 13:46:04 --> Database Driver Class Initialized
INFO - 2016-11-11 13:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:46:04 --> Controller Class Initialized
INFO - 2016-11-11 13:46:04 --> Model Class Initialized
INFO - 2016-11-11 13:46:04 --> Model Class Initialized
INFO - 2016-11-11 13:46:04 --> Model Class Initialized
INFO - 2016-11-11 13:46:04 --> Model Class Initialized
INFO - 2016-11-11 13:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 13:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 13:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 13:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 13:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 13:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 13:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 13:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 13:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 13:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 13:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:46:04 --> Final output sent to browser
DEBUG - 2016-11-11 13:46:04 --> Total execution time: 0.3379
INFO - 2016-11-11 13:46:06 --> Config Class Initialized
INFO - 2016-11-11 13:46:06 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:46:06 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:46:06 --> Utf8 Class Initialized
INFO - 2016-11-11 13:46:06 --> URI Class Initialized
DEBUG - 2016-11-11 13:46:06 --> No URI present. Default controller set.
INFO - 2016-11-11 13:46:06 --> Router Class Initialized
INFO - 2016-11-11 13:46:06 --> Output Class Initialized
INFO - 2016-11-11 13:46:06 --> Security Class Initialized
DEBUG - 2016-11-11 13:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:46:06 --> Input Class Initialized
INFO - 2016-11-11 13:46:06 --> Language Class Initialized
INFO - 2016-11-11 13:46:06 --> Loader Class Initialized
INFO - 2016-11-11 13:46:06 --> Helper loaded: url_helper
INFO - 2016-11-11 13:46:06 --> Helper loaded: form_helper
INFO - 2016-11-11 13:46:06 --> Database Driver Class Initialized
INFO - 2016-11-11 13:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:46:06 --> Controller Class Initialized
INFO - 2016-11-11 13:46:06 --> Model Class Initialized
INFO - 2016-11-11 13:46:06 --> Model Class Initialized
INFO - 2016-11-11 13:46:06 --> Model Class Initialized
INFO - 2016-11-11 13:46:06 --> Model Class Initialized
INFO - 2016-11-11 13:46:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:46:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 13:46:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 13:46:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 13:46:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 13:46:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 13:46:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 13:46:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 13:46:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 13:46:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 13:46:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 13:46:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:46:06 --> Final output sent to browser
DEBUG - 2016-11-11 13:46:06 --> Total execution time: 0.3968
INFO - 2016-11-11 13:46:34 --> Config Class Initialized
INFO - 2016-11-11 13:46:34 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:46:35 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:46:35 --> Utf8 Class Initialized
INFO - 2016-11-11 13:46:35 --> URI Class Initialized
DEBUG - 2016-11-11 13:46:35 --> No URI present. Default controller set.
INFO - 2016-11-11 13:46:35 --> Router Class Initialized
INFO - 2016-11-11 13:46:35 --> Output Class Initialized
INFO - 2016-11-11 13:46:35 --> Security Class Initialized
DEBUG - 2016-11-11 13:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:46:35 --> Input Class Initialized
INFO - 2016-11-11 13:46:35 --> Language Class Initialized
INFO - 2016-11-11 13:46:35 --> Loader Class Initialized
INFO - 2016-11-11 13:46:35 --> Helper loaded: url_helper
INFO - 2016-11-11 13:46:35 --> Helper loaded: form_helper
INFO - 2016-11-11 13:46:35 --> Database Driver Class Initialized
INFO - 2016-11-11 13:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:46:35 --> Controller Class Initialized
INFO - 2016-11-11 13:46:35 --> Model Class Initialized
INFO - 2016-11-11 13:46:35 --> Model Class Initialized
INFO - 2016-11-11 13:46:35 --> Model Class Initialized
INFO - 2016-11-11 13:46:35 --> Model Class Initialized
INFO - 2016-11-11 13:46:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:46:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 13:46:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 13:46:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 13:46:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 13:46:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 13:46:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 13:46:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 13:46:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 13:46:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 13:46:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 13:46:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:46:35 --> Final output sent to browser
DEBUG - 2016-11-11 13:46:35 --> Total execution time: 0.3703
INFO - 2016-11-11 13:46:38 --> Config Class Initialized
INFO - 2016-11-11 13:46:38 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:46:38 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:46:38 --> Utf8 Class Initialized
INFO - 2016-11-11 13:46:38 --> URI Class Initialized
DEBUG - 2016-11-11 13:46:38 --> No URI present. Default controller set.
INFO - 2016-11-11 13:46:38 --> Router Class Initialized
INFO - 2016-11-11 13:46:38 --> Output Class Initialized
INFO - 2016-11-11 13:46:38 --> Security Class Initialized
DEBUG - 2016-11-11 13:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:46:38 --> Input Class Initialized
INFO - 2016-11-11 13:46:38 --> Language Class Initialized
INFO - 2016-11-11 13:46:38 --> Loader Class Initialized
INFO - 2016-11-11 13:46:38 --> Helper loaded: url_helper
INFO - 2016-11-11 13:46:38 --> Helper loaded: form_helper
INFO - 2016-11-11 13:46:38 --> Database Driver Class Initialized
INFO - 2016-11-11 13:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:46:38 --> Controller Class Initialized
INFO - 2016-11-11 13:46:38 --> Model Class Initialized
INFO - 2016-11-11 13:46:38 --> Model Class Initialized
INFO - 2016-11-11 13:46:38 --> Model Class Initialized
INFO - 2016-11-11 13:46:39 --> Model Class Initialized
INFO - 2016-11-11 13:46:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:46:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 13:46:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 13:46:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 13:46:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 13:46:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 13:46:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 13:46:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 13:46:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 13:46:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 13:46:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 13:46:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:46:39 --> Final output sent to browser
DEBUG - 2016-11-11 13:46:39 --> Total execution time: 0.3705
INFO - 2016-11-11 13:55:23 --> Config Class Initialized
INFO - 2016-11-11 13:55:23 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:55:23 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:55:23 --> Utf8 Class Initialized
INFO - 2016-11-11 13:55:23 --> URI Class Initialized
DEBUG - 2016-11-11 13:55:23 --> No URI present. Default controller set.
INFO - 2016-11-11 13:55:23 --> Router Class Initialized
INFO - 2016-11-11 13:55:23 --> Output Class Initialized
INFO - 2016-11-11 13:55:23 --> Security Class Initialized
DEBUG - 2016-11-11 13:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:55:23 --> Input Class Initialized
INFO - 2016-11-11 13:55:23 --> Language Class Initialized
INFO - 2016-11-11 13:55:24 --> Loader Class Initialized
INFO - 2016-11-11 13:55:24 --> Helper loaded: url_helper
INFO - 2016-11-11 13:55:24 --> Helper loaded: form_helper
INFO - 2016-11-11 13:55:24 --> Database Driver Class Initialized
INFO - 2016-11-11 13:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:55:24 --> Controller Class Initialized
INFO - 2016-11-11 13:55:24 --> Model Class Initialized
INFO - 2016-11-11 13:55:24 --> Model Class Initialized
INFO - 2016-11-11 13:55:24 --> Model Class Initialized
INFO - 2016-11-11 13:55:24 --> Model Class Initialized
INFO - 2016-11-11 13:55:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:55:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 13:55:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 13:55:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 13:55:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 13:55:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 13:55:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 13:55:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 13:55:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 13:55:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 13:55:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 13:55:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:55:24 --> Final output sent to browser
DEBUG - 2016-11-11 13:55:24 --> Total execution time: 0.3587
INFO - 2016-11-11 13:57:46 --> Config Class Initialized
INFO - 2016-11-11 13:57:46 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:57:46 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:57:46 --> Utf8 Class Initialized
INFO - 2016-11-11 13:57:46 --> URI Class Initialized
INFO - 2016-11-11 13:57:46 --> Router Class Initialized
INFO - 2016-11-11 13:57:46 --> Output Class Initialized
INFO - 2016-11-11 13:57:46 --> Security Class Initialized
DEBUG - 2016-11-11 13:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:57:46 --> Input Class Initialized
INFO - 2016-11-11 13:57:46 --> Language Class Initialized
INFO - 2016-11-11 13:57:46 --> Loader Class Initialized
INFO - 2016-11-11 13:57:46 --> Helper loaded: url_helper
INFO - 2016-11-11 13:57:46 --> Helper loaded: form_helper
INFO - 2016-11-11 13:57:46 --> Database Driver Class Initialized
INFO - 2016-11-11 13:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:57:46 --> Controller Class Initialized
INFO - 2016-11-11 13:57:46 --> Model Class Initialized
INFO - 2016-11-11 13:57:46 --> Model Class Initialized
INFO - 2016-11-11 13:57:46 --> Model Class Initialized
INFO - 2016-11-11 13:57:46 --> Model Class Initialized
DEBUG - 2016-11-11 13:57:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-11 13:57:46 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
ERROR - 2016-11-11 13:57:46 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
INFO - 2016-11-11 13:57:46 --> Config Class Initialized
INFO - 2016-11-11 13:57:46 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:57:46 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:57:46 --> Utf8 Class Initialized
INFO - 2016-11-11 13:57:46 --> URI Class Initialized
DEBUG - 2016-11-11 13:57:46 --> No URI present. Default controller set.
INFO - 2016-11-11 13:57:46 --> Router Class Initialized
INFO - 2016-11-11 13:57:46 --> Output Class Initialized
INFO - 2016-11-11 13:57:46 --> Security Class Initialized
DEBUG - 2016-11-11 13:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:57:46 --> Input Class Initialized
INFO - 2016-11-11 13:57:47 --> Language Class Initialized
INFO - 2016-11-11 13:57:47 --> Loader Class Initialized
INFO - 2016-11-11 13:57:47 --> Helper loaded: url_helper
INFO - 2016-11-11 13:57:47 --> Helper loaded: form_helper
INFO - 2016-11-11 13:57:47 --> Database Driver Class Initialized
INFO - 2016-11-11 13:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:57:47 --> Controller Class Initialized
INFO - 2016-11-11 13:57:47 --> Model Class Initialized
INFO - 2016-11-11 13:57:47 --> Model Class Initialized
INFO - 2016-11-11 13:57:47 --> Model Class Initialized
INFO - 2016-11-11 13:57:47 --> Model Class Initialized
INFO - 2016-11-11 13:57:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:57:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-11 13:57:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:57:47 --> Final output sent to browser
DEBUG - 2016-11-11 13:57:47 --> Total execution time: 0.2512
INFO - 2016-11-11 13:57:53 --> Config Class Initialized
INFO - 2016-11-11 13:57:53 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:57:53 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:57:53 --> Utf8 Class Initialized
INFO - 2016-11-11 13:57:54 --> URI Class Initialized
INFO - 2016-11-11 13:57:54 --> Router Class Initialized
INFO - 2016-11-11 13:57:54 --> Output Class Initialized
INFO - 2016-11-11 13:57:54 --> Security Class Initialized
DEBUG - 2016-11-11 13:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:57:54 --> Input Class Initialized
INFO - 2016-11-11 13:57:54 --> Language Class Initialized
INFO - 2016-11-11 13:57:54 --> Loader Class Initialized
INFO - 2016-11-11 13:57:54 --> Helper loaded: url_helper
INFO - 2016-11-11 13:57:54 --> Helper loaded: form_helper
INFO - 2016-11-11 13:57:54 --> Database Driver Class Initialized
INFO - 2016-11-11 13:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:57:54 --> Controller Class Initialized
INFO - 2016-11-11 13:57:54 --> Model Class Initialized
INFO - 2016-11-11 13:57:54 --> Model Class Initialized
INFO - 2016-11-11 13:57:54 --> Model Class Initialized
INFO - 2016-11-11 13:57:54 --> Model Class Initialized
DEBUG - 2016-11-11 13:57:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-11 13:57:54 --> Model Class Initialized
INFO - 2016-11-11 13:57:54 --> Final output sent to browser
DEBUG - 2016-11-11 13:57:54 --> Total execution time: 0.2542
INFO - 2016-11-11 13:57:54 --> Config Class Initialized
INFO - 2016-11-11 13:57:54 --> Hooks Class Initialized
DEBUG - 2016-11-11 13:57:54 --> UTF-8 Support Enabled
INFO - 2016-11-11 13:57:54 --> Utf8 Class Initialized
INFO - 2016-11-11 13:57:54 --> URI Class Initialized
DEBUG - 2016-11-11 13:57:54 --> No URI present. Default controller set.
INFO - 2016-11-11 13:57:54 --> Router Class Initialized
INFO - 2016-11-11 13:57:54 --> Output Class Initialized
INFO - 2016-11-11 13:57:54 --> Security Class Initialized
DEBUG - 2016-11-11 13:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 13:57:54 --> Input Class Initialized
INFO - 2016-11-11 13:57:54 --> Language Class Initialized
INFO - 2016-11-11 13:57:54 --> Loader Class Initialized
INFO - 2016-11-11 13:57:54 --> Helper loaded: url_helper
INFO - 2016-11-11 13:57:54 --> Helper loaded: form_helper
INFO - 2016-11-11 13:57:54 --> Database Driver Class Initialized
INFO - 2016-11-11 13:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 13:57:54 --> Controller Class Initialized
INFO - 2016-11-11 13:57:54 --> Model Class Initialized
INFO - 2016-11-11 13:57:54 --> Model Class Initialized
INFO - 2016-11-11 13:57:54 --> Model Class Initialized
INFO - 2016-11-11 13:57:54 --> Model Class Initialized
INFO - 2016-11-11 13:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 13:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 13:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 13:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-11 13:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-11 13:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-11 13:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-11 13:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-11 13:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-11 13:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 13:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 13:57:54 --> Final output sent to browser
DEBUG - 2016-11-11 13:57:54 --> Total execution time: 0.3240
INFO - 2016-11-11 14:07:46 --> Config Class Initialized
INFO - 2016-11-11 14:07:46 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:07:46 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:07:46 --> Utf8 Class Initialized
INFO - 2016-11-11 14:07:46 --> URI Class Initialized
DEBUG - 2016-11-11 14:07:47 --> No URI present. Default controller set.
INFO - 2016-11-11 14:07:47 --> Router Class Initialized
INFO - 2016-11-11 14:07:47 --> Output Class Initialized
INFO - 2016-11-11 14:07:47 --> Security Class Initialized
DEBUG - 2016-11-11 14:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:07:47 --> Input Class Initialized
INFO - 2016-11-11 14:07:47 --> Language Class Initialized
INFO - 2016-11-11 14:07:47 --> Loader Class Initialized
INFO - 2016-11-11 14:07:47 --> Helper loaded: url_helper
INFO - 2016-11-11 14:07:47 --> Helper loaded: form_helper
INFO - 2016-11-11 14:07:47 --> Database Driver Class Initialized
INFO - 2016-11-11 14:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:07:47 --> Controller Class Initialized
INFO - 2016-11-11 14:07:47 --> Model Class Initialized
INFO - 2016-11-11 14:07:47 --> Model Class Initialized
INFO - 2016-11-11 14:07:47 --> Model Class Initialized
INFO - 2016-11-11 14:07:47 --> Model Class Initialized
INFO - 2016-11-11 14:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-11 14:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-11 14:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-11 14:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-11 14:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-11 14:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-11 14:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:07:47 --> Final output sent to browser
DEBUG - 2016-11-11 14:07:47 --> Total execution time: 0.3698
INFO - 2016-11-11 14:08:01 --> Config Class Initialized
INFO - 2016-11-11 14:08:01 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:08:01 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:08:01 --> Utf8 Class Initialized
INFO - 2016-11-11 14:08:01 --> URI Class Initialized
INFO - 2016-11-11 14:08:01 --> Router Class Initialized
INFO - 2016-11-11 14:08:01 --> Output Class Initialized
INFO - 2016-11-11 14:08:01 --> Security Class Initialized
DEBUG - 2016-11-11 14:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:08:01 --> Input Class Initialized
INFO - 2016-11-11 14:08:01 --> Language Class Initialized
INFO - 2016-11-11 14:08:01 --> Loader Class Initialized
INFO - 2016-11-11 14:08:01 --> Helper loaded: url_helper
INFO - 2016-11-11 14:08:01 --> Helper loaded: form_helper
INFO - 2016-11-11 14:08:01 --> Database Driver Class Initialized
INFO - 2016-11-11 14:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:08:02 --> Controller Class Initialized
INFO - 2016-11-11 14:08:02 --> Model Class Initialized
INFO - 2016-11-11 14:08:02 --> Model Class Initialized
INFO - 2016-11-11 14:08:02 --> Model Class Initialized
INFO - 2016-11-11 14:08:02 --> Model Class Initialized
DEBUG - 2016-11-11 14:08:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-11 14:08:02 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
ERROR - 2016-11-11 14:08:02 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
INFO - 2016-11-11 14:08:02 --> Config Class Initialized
INFO - 2016-11-11 14:08:02 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:08:02 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:08:02 --> Utf8 Class Initialized
INFO - 2016-11-11 14:08:02 --> URI Class Initialized
DEBUG - 2016-11-11 14:08:02 --> No URI present. Default controller set.
INFO - 2016-11-11 14:08:02 --> Router Class Initialized
INFO - 2016-11-11 14:08:02 --> Output Class Initialized
INFO - 2016-11-11 14:08:02 --> Security Class Initialized
DEBUG - 2016-11-11 14:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:08:02 --> Input Class Initialized
INFO - 2016-11-11 14:08:02 --> Language Class Initialized
INFO - 2016-11-11 14:08:02 --> Loader Class Initialized
INFO - 2016-11-11 14:08:02 --> Helper loaded: url_helper
INFO - 2016-11-11 14:08:02 --> Helper loaded: form_helper
INFO - 2016-11-11 14:08:02 --> Database Driver Class Initialized
INFO - 2016-11-11 14:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:08:02 --> Controller Class Initialized
INFO - 2016-11-11 14:08:02 --> Model Class Initialized
INFO - 2016-11-11 14:08:02 --> Model Class Initialized
INFO - 2016-11-11 14:08:02 --> Model Class Initialized
INFO - 2016-11-11 14:08:02 --> Model Class Initialized
INFO - 2016-11-11 14:08:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:08:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-11 14:08:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:08:02 --> Final output sent to browser
DEBUG - 2016-11-11 14:08:02 --> Total execution time: 0.2650
INFO - 2016-11-11 14:08:11 --> Config Class Initialized
INFO - 2016-11-11 14:08:11 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:08:11 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:08:11 --> Utf8 Class Initialized
INFO - 2016-11-11 14:08:11 --> URI Class Initialized
INFO - 2016-11-11 14:08:11 --> Router Class Initialized
INFO - 2016-11-11 14:08:11 --> Output Class Initialized
INFO - 2016-11-11 14:08:11 --> Security Class Initialized
DEBUG - 2016-11-11 14:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:08:11 --> Input Class Initialized
INFO - 2016-11-11 14:08:11 --> Language Class Initialized
INFO - 2016-11-11 14:08:11 --> Loader Class Initialized
INFO - 2016-11-11 14:08:11 --> Helper loaded: url_helper
INFO - 2016-11-11 14:08:11 --> Helper loaded: form_helper
INFO - 2016-11-11 14:08:11 --> Database Driver Class Initialized
INFO - 2016-11-11 14:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:08:11 --> Controller Class Initialized
INFO - 2016-11-11 14:08:11 --> Model Class Initialized
INFO - 2016-11-11 14:08:11 --> Model Class Initialized
INFO - 2016-11-11 14:08:11 --> Model Class Initialized
INFO - 2016-11-11 14:08:11 --> Model Class Initialized
DEBUG - 2016-11-11 14:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-11 14:08:11 --> Model Class Initialized
INFO - 2016-11-11 14:08:11 --> Final output sent to browser
DEBUG - 2016-11-11 14:08:11 --> Total execution time: 0.2602
INFO - 2016-11-11 14:08:11 --> Config Class Initialized
INFO - 2016-11-11 14:08:11 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:08:11 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:08:11 --> Utf8 Class Initialized
INFO - 2016-11-11 14:08:11 --> URI Class Initialized
DEBUG - 2016-11-11 14:08:11 --> No URI present. Default controller set.
INFO - 2016-11-11 14:08:11 --> Router Class Initialized
INFO - 2016-11-11 14:08:11 --> Output Class Initialized
INFO - 2016-11-11 14:08:11 --> Security Class Initialized
DEBUG - 2016-11-11 14:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:08:11 --> Input Class Initialized
INFO - 2016-11-11 14:08:11 --> Language Class Initialized
INFO - 2016-11-11 14:08:11 --> Loader Class Initialized
INFO - 2016-11-11 14:08:11 --> Helper loaded: url_helper
INFO - 2016-11-11 14:08:11 --> Helper loaded: form_helper
INFO - 2016-11-11 14:08:11 --> Database Driver Class Initialized
INFO - 2016-11-11 14:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:08:11 --> Controller Class Initialized
INFO - 2016-11-11 14:08:11 --> Model Class Initialized
INFO - 2016-11-11 14:08:11 --> Model Class Initialized
INFO - 2016-11-11 14:08:11 --> Model Class Initialized
INFO - 2016-11-11 14:08:11 --> Model Class Initialized
INFO - 2016-11-11 14:08:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:08:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:08:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:08:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:08:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:08:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:08:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:08:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:08:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:08:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:08:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:08:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:08:11 --> Final output sent to browser
DEBUG - 2016-11-11 14:08:11 --> Total execution time: 0.3436
INFO - 2016-11-11 14:08:25 --> Config Class Initialized
INFO - 2016-11-11 14:08:25 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:08:25 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:08:25 --> Utf8 Class Initialized
INFO - 2016-11-11 14:08:25 --> URI Class Initialized
DEBUG - 2016-11-11 14:08:25 --> No URI present. Default controller set.
INFO - 2016-11-11 14:08:25 --> Router Class Initialized
INFO - 2016-11-11 14:08:25 --> Output Class Initialized
INFO - 2016-11-11 14:08:25 --> Security Class Initialized
DEBUG - 2016-11-11 14:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:08:25 --> Input Class Initialized
INFO - 2016-11-11 14:08:25 --> Language Class Initialized
INFO - 2016-11-11 14:08:25 --> Loader Class Initialized
INFO - 2016-11-11 14:08:25 --> Helper loaded: url_helper
INFO - 2016-11-11 14:08:25 --> Helper loaded: form_helper
INFO - 2016-11-11 14:08:25 --> Database Driver Class Initialized
INFO - 2016-11-11 14:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:08:25 --> Controller Class Initialized
INFO - 2016-11-11 14:08:25 --> Model Class Initialized
INFO - 2016-11-11 14:08:25 --> Model Class Initialized
INFO - 2016-11-11 14:08:25 --> Model Class Initialized
INFO - 2016-11-11 14:08:25 --> Model Class Initialized
INFO - 2016-11-11 14:08:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:08:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:08:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:08:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:08:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:08:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:08:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:08:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:08:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:08:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:08:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:08:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:08:25 --> Final output sent to browser
DEBUG - 2016-11-11 14:08:25 --> Total execution time: 0.3760
INFO - 2016-11-11 14:09:51 --> Config Class Initialized
INFO - 2016-11-11 14:09:51 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:09:51 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:09:51 --> Utf8 Class Initialized
INFO - 2016-11-11 14:09:51 --> URI Class Initialized
DEBUG - 2016-11-11 14:09:51 --> No URI present. Default controller set.
INFO - 2016-11-11 14:09:51 --> Router Class Initialized
INFO - 2016-11-11 14:09:51 --> Output Class Initialized
INFO - 2016-11-11 14:09:51 --> Security Class Initialized
DEBUG - 2016-11-11 14:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:09:51 --> Input Class Initialized
INFO - 2016-11-11 14:09:51 --> Language Class Initialized
INFO - 2016-11-11 14:09:51 --> Loader Class Initialized
INFO - 2016-11-11 14:09:51 --> Helper loaded: url_helper
INFO - 2016-11-11 14:09:51 --> Helper loaded: form_helper
INFO - 2016-11-11 14:09:52 --> Database Driver Class Initialized
INFO - 2016-11-11 14:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:09:52 --> Controller Class Initialized
INFO - 2016-11-11 14:09:52 --> Model Class Initialized
INFO - 2016-11-11 14:09:52 --> Model Class Initialized
INFO - 2016-11-11 14:09:52 --> Model Class Initialized
INFO - 2016-11-11 14:09:52 --> Model Class Initialized
INFO - 2016-11-11 14:09:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:09:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:09:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:09:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:09:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:09:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:09:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:09:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:09:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:09:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:09:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:09:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:09:52 --> Final output sent to browser
DEBUG - 2016-11-11 14:09:52 --> Total execution time: 0.4043
INFO - 2016-11-11 14:16:46 --> Config Class Initialized
INFO - 2016-11-11 14:16:46 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:16:46 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:16:46 --> Utf8 Class Initialized
INFO - 2016-11-11 14:16:46 --> URI Class Initialized
DEBUG - 2016-11-11 14:16:46 --> No URI present. Default controller set.
INFO - 2016-11-11 14:16:46 --> Router Class Initialized
INFO - 2016-11-11 14:16:46 --> Output Class Initialized
INFO - 2016-11-11 14:16:46 --> Security Class Initialized
DEBUG - 2016-11-11 14:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:16:46 --> Input Class Initialized
INFO - 2016-11-11 14:16:46 --> Language Class Initialized
INFO - 2016-11-11 14:16:46 --> Loader Class Initialized
INFO - 2016-11-11 14:16:47 --> Helper loaded: url_helper
INFO - 2016-11-11 14:16:47 --> Helper loaded: form_helper
INFO - 2016-11-11 14:16:47 --> Database Driver Class Initialized
INFO - 2016-11-11 14:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:16:47 --> Controller Class Initialized
INFO - 2016-11-11 14:16:47 --> Model Class Initialized
INFO - 2016-11-11 14:16:47 --> Model Class Initialized
INFO - 2016-11-11 14:16:47 --> Model Class Initialized
INFO - 2016-11-11 14:16:47 --> Model Class Initialized
INFO - 2016-11-11 14:16:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:16:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:16:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:16:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:16:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:16:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:16:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:16:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:16:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:16:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:16:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:16:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:16:47 --> Final output sent to browser
DEBUG - 2016-11-11 14:16:47 --> Total execution time: 0.3796
INFO - 2016-11-11 14:16:51 --> Config Class Initialized
INFO - 2016-11-11 14:16:51 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:16:51 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:16:51 --> Utf8 Class Initialized
INFO - 2016-11-11 14:16:51 --> URI Class Initialized
DEBUG - 2016-11-11 14:16:51 --> No URI present. Default controller set.
INFO - 2016-11-11 14:16:51 --> Router Class Initialized
INFO - 2016-11-11 14:16:51 --> Output Class Initialized
INFO - 2016-11-11 14:16:51 --> Security Class Initialized
DEBUG - 2016-11-11 14:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:16:51 --> Input Class Initialized
INFO - 2016-11-11 14:16:51 --> Language Class Initialized
INFO - 2016-11-11 14:16:51 --> Loader Class Initialized
INFO - 2016-11-11 14:16:51 --> Helper loaded: url_helper
INFO - 2016-11-11 14:16:51 --> Helper loaded: form_helper
INFO - 2016-11-11 14:16:51 --> Database Driver Class Initialized
INFO - 2016-11-11 14:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:16:51 --> Controller Class Initialized
INFO - 2016-11-11 14:16:51 --> Model Class Initialized
INFO - 2016-11-11 14:16:51 --> Model Class Initialized
INFO - 2016-11-11 14:16:51 --> Model Class Initialized
INFO - 2016-11-11 14:16:51 --> Model Class Initialized
INFO - 2016-11-11 14:16:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:16:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:16:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:16:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:16:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:16:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:16:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:16:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:16:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:16:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:16:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:16:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:16:51 --> Final output sent to browser
DEBUG - 2016-11-11 14:16:51 --> Total execution time: 0.3828
INFO - 2016-11-11 14:19:34 --> Config Class Initialized
INFO - 2016-11-11 14:19:34 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:19:34 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:19:34 --> Utf8 Class Initialized
INFO - 2016-11-11 14:19:34 --> URI Class Initialized
DEBUG - 2016-11-11 14:19:34 --> No URI present. Default controller set.
INFO - 2016-11-11 14:19:34 --> Router Class Initialized
INFO - 2016-11-11 14:19:34 --> Output Class Initialized
INFO - 2016-11-11 14:19:34 --> Security Class Initialized
DEBUG - 2016-11-11 14:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:19:34 --> Input Class Initialized
INFO - 2016-11-11 14:19:34 --> Language Class Initialized
INFO - 2016-11-11 14:19:34 --> Loader Class Initialized
INFO - 2016-11-11 14:19:34 --> Helper loaded: url_helper
INFO - 2016-11-11 14:19:34 --> Helper loaded: form_helper
INFO - 2016-11-11 14:19:34 --> Database Driver Class Initialized
INFO - 2016-11-11 14:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:19:34 --> Controller Class Initialized
INFO - 2016-11-11 14:19:34 --> Model Class Initialized
INFO - 2016-11-11 14:19:34 --> Model Class Initialized
INFO - 2016-11-11 14:19:34 --> Model Class Initialized
INFO - 2016-11-11 14:19:34 --> Model Class Initialized
INFO - 2016-11-11 14:19:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:19:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:19:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:19:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:19:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:19:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:19:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:19:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:19:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:19:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:19:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:19:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:19:34 --> Final output sent to browser
DEBUG - 2016-11-11 14:19:34 --> Total execution time: 0.3560
INFO - 2016-11-11 14:20:19 --> Config Class Initialized
INFO - 2016-11-11 14:20:19 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:20:19 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:20:19 --> Utf8 Class Initialized
INFO - 2016-11-11 14:20:19 --> URI Class Initialized
DEBUG - 2016-11-11 14:20:20 --> No URI present. Default controller set.
INFO - 2016-11-11 14:20:20 --> Router Class Initialized
INFO - 2016-11-11 14:20:20 --> Output Class Initialized
INFO - 2016-11-11 14:20:20 --> Security Class Initialized
DEBUG - 2016-11-11 14:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:20:20 --> Input Class Initialized
INFO - 2016-11-11 14:20:20 --> Language Class Initialized
INFO - 2016-11-11 14:20:20 --> Loader Class Initialized
INFO - 2016-11-11 14:20:20 --> Helper loaded: url_helper
INFO - 2016-11-11 14:20:20 --> Helper loaded: form_helper
INFO - 2016-11-11 14:20:20 --> Database Driver Class Initialized
INFO - 2016-11-11 14:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:20:20 --> Controller Class Initialized
INFO - 2016-11-11 14:20:20 --> Model Class Initialized
INFO - 2016-11-11 14:20:20 --> Model Class Initialized
INFO - 2016-11-11 14:20:20 --> Model Class Initialized
INFO - 2016-11-11 14:20:20 --> Model Class Initialized
INFO - 2016-11-11 14:20:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:20:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:20:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:20:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:20:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:20:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:20:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:20:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:20:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:20:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:20:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:20:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:20:20 --> Final output sent to browser
DEBUG - 2016-11-11 14:20:20 --> Total execution time: 0.3722
INFO - 2016-11-11 14:21:58 --> Config Class Initialized
INFO - 2016-11-11 14:21:58 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:21:58 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:21:59 --> Utf8 Class Initialized
INFO - 2016-11-11 14:21:59 --> URI Class Initialized
DEBUG - 2016-11-11 14:21:59 --> No URI present. Default controller set.
INFO - 2016-11-11 14:21:59 --> Router Class Initialized
INFO - 2016-11-11 14:21:59 --> Output Class Initialized
INFO - 2016-11-11 14:21:59 --> Security Class Initialized
DEBUG - 2016-11-11 14:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:21:59 --> Input Class Initialized
INFO - 2016-11-11 14:21:59 --> Language Class Initialized
INFO - 2016-11-11 14:21:59 --> Loader Class Initialized
INFO - 2016-11-11 14:21:59 --> Helper loaded: url_helper
INFO - 2016-11-11 14:21:59 --> Helper loaded: form_helper
INFO - 2016-11-11 14:21:59 --> Database Driver Class Initialized
INFO - 2016-11-11 14:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:21:59 --> Controller Class Initialized
INFO - 2016-11-11 14:21:59 --> Model Class Initialized
INFO - 2016-11-11 14:21:59 --> Model Class Initialized
INFO - 2016-11-11 14:21:59 --> Model Class Initialized
INFO - 2016-11-11 14:21:59 --> Model Class Initialized
INFO - 2016-11-11 14:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:21:59 --> Final output sent to browser
DEBUG - 2016-11-11 14:21:59 --> Total execution time: 0.3868
INFO - 2016-11-11 14:25:41 --> Config Class Initialized
INFO - 2016-11-11 14:25:41 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:25:41 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:25:41 --> Utf8 Class Initialized
INFO - 2016-11-11 14:25:41 --> URI Class Initialized
DEBUG - 2016-11-11 14:25:41 --> No URI present. Default controller set.
INFO - 2016-11-11 14:25:41 --> Router Class Initialized
INFO - 2016-11-11 14:25:41 --> Output Class Initialized
INFO - 2016-11-11 14:25:41 --> Security Class Initialized
DEBUG - 2016-11-11 14:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:25:41 --> Input Class Initialized
INFO - 2016-11-11 14:25:41 --> Language Class Initialized
INFO - 2016-11-11 14:25:41 --> Loader Class Initialized
INFO - 2016-11-11 14:25:41 --> Helper loaded: url_helper
INFO - 2016-11-11 14:25:41 --> Helper loaded: form_helper
INFO - 2016-11-11 14:25:41 --> Database Driver Class Initialized
INFO - 2016-11-11 14:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:25:41 --> Controller Class Initialized
INFO - 2016-11-11 14:25:41 --> Model Class Initialized
INFO - 2016-11-11 14:25:41 --> Model Class Initialized
INFO - 2016-11-11 14:25:41 --> Model Class Initialized
INFO - 2016-11-11 14:25:41 --> Model Class Initialized
INFO - 2016-11-11 14:25:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:25:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:25:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:25:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:25:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:25:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:25:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:25:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:25:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:25:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:25:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:25:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:25:41 --> Final output sent to browser
DEBUG - 2016-11-11 14:25:41 --> Total execution time: 0.6737
INFO - 2016-11-11 14:25:45 --> Config Class Initialized
INFO - 2016-11-11 14:25:45 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:25:45 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:25:45 --> Utf8 Class Initialized
INFO - 2016-11-11 14:25:45 --> URI Class Initialized
DEBUG - 2016-11-11 14:25:45 --> No URI present. Default controller set.
INFO - 2016-11-11 14:25:45 --> Router Class Initialized
INFO - 2016-11-11 14:25:45 --> Output Class Initialized
INFO - 2016-11-11 14:25:45 --> Security Class Initialized
DEBUG - 2016-11-11 14:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:25:45 --> Input Class Initialized
INFO - 2016-11-11 14:25:45 --> Language Class Initialized
INFO - 2016-11-11 14:25:45 --> Loader Class Initialized
INFO - 2016-11-11 14:25:45 --> Helper loaded: url_helper
INFO - 2016-11-11 14:25:45 --> Helper loaded: form_helper
INFO - 2016-11-11 14:25:45 --> Database Driver Class Initialized
INFO - 2016-11-11 14:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:25:45 --> Controller Class Initialized
INFO - 2016-11-11 14:25:45 --> Model Class Initialized
INFO - 2016-11-11 14:25:45 --> Model Class Initialized
INFO - 2016-11-11 14:25:45 --> Model Class Initialized
INFO - 2016-11-11 14:25:45 --> Model Class Initialized
INFO - 2016-11-11 14:25:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:25:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:25:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:25:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:25:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:25:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:25:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:25:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:25:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:25:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:25:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:25:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:25:45 --> Final output sent to browser
DEBUG - 2016-11-11 14:25:45 --> Total execution time: 0.4089
INFO - 2016-11-11 14:27:26 --> Config Class Initialized
INFO - 2016-11-11 14:27:26 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:27:26 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:27:26 --> Utf8 Class Initialized
INFO - 2016-11-11 14:27:26 --> URI Class Initialized
DEBUG - 2016-11-11 14:27:26 --> No URI present. Default controller set.
INFO - 2016-11-11 14:27:26 --> Router Class Initialized
INFO - 2016-11-11 14:27:26 --> Output Class Initialized
INFO - 2016-11-11 14:27:26 --> Security Class Initialized
DEBUG - 2016-11-11 14:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:27:26 --> Input Class Initialized
INFO - 2016-11-11 14:27:26 --> Language Class Initialized
INFO - 2016-11-11 14:27:26 --> Loader Class Initialized
INFO - 2016-11-11 14:27:26 --> Helper loaded: url_helper
INFO - 2016-11-11 14:27:26 --> Helper loaded: form_helper
INFO - 2016-11-11 14:27:26 --> Database Driver Class Initialized
INFO - 2016-11-11 14:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:27:26 --> Controller Class Initialized
INFO - 2016-11-11 14:27:26 --> Model Class Initialized
INFO - 2016-11-11 14:27:26 --> Model Class Initialized
INFO - 2016-11-11 14:27:26 --> Model Class Initialized
INFO - 2016-11-11 14:27:26 --> Model Class Initialized
INFO - 2016-11-11 14:27:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:27:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:27:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:27:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:27:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:27:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:27:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:27:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:27:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:27:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:27:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:27:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:27:26 --> Final output sent to browser
DEBUG - 2016-11-11 14:27:26 --> Total execution time: 0.4047
INFO - 2016-11-11 14:27:27 --> Config Class Initialized
INFO - 2016-11-11 14:27:27 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:27:27 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:27:27 --> Utf8 Class Initialized
INFO - 2016-11-11 14:27:27 --> URI Class Initialized
DEBUG - 2016-11-11 14:27:27 --> No URI present. Default controller set.
INFO - 2016-11-11 14:27:27 --> Router Class Initialized
INFO - 2016-11-11 14:27:27 --> Output Class Initialized
INFO - 2016-11-11 14:27:27 --> Security Class Initialized
DEBUG - 2016-11-11 14:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:27:27 --> Input Class Initialized
INFO - 2016-11-11 14:27:27 --> Language Class Initialized
INFO - 2016-11-11 14:27:27 --> Loader Class Initialized
INFO - 2016-11-11 14:27:27 --> Helper loaded: url_helper
INFO - 2016-11-11 14:27:27 --> Helper loaded: form_helper
INFO - 2016-11-11 14:27:27 --> Database Driver Class Initialized
INFO - 2016-11-11 14:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:27:27 --> Controller Class Initialized
INFO - 2016-11-11 14:27:27 --> Model Class Initialized
INFO - 2016-11-11 14:27:27 --> Model Class Initialized
INFO - 2016-11-11 14:27:27 --> Model Class Initialized
INFO - 2016-11-11 14:27:27 --> Model Class Initialized
INFO - 2016-11-11 14:27:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:27:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:27:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:27:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:27:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:27:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:27:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:27:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:27:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:27:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:27:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:27:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:27:27 --> Final output sent to browser
DEBUG - 2016-11-11 14:27:27 --> Total execution time: 0.4293
INFO - 2016-11-11 14:30:44 --> Config Class Initialized
INFO - 2016-11-11 14:30:44 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:30:44 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:30:44 --> Utf8 Class Initialized
INFO - 2016-11-11 14:30:44 --> URI Class Initialized
DEBUG - 2016-11-11 14:30:44 --> No URI present. Default controller set.
INFO - 2016-11-11 14:30:44 --> Router Class Initialized
INFO - 2016-11-11 14:30:44 --> Output Class Initialized
INFO - 2016-11-11 14:30:44 --> Security Class Initialized
DEBUG - 2016-11-11 14:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:30:44 --> Input Class Initialized
INFO - 2016-11-11 14:30:44 --> Language Class Initialized
INFO - 2016-11-11 14:30:44 --> Loader Class Initialized
INFO - 2016-11-11 14:30:44 --> Helper loaded: url_helper
INFO - 2016-11-11 14:30:44 --> Helper loaded: form_helper
INFO - 2016-11-11 14:30:44 --> Database Driver Class Initialized
INFO - 2016-11-11 14:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:30:44 --> Controller Class Initialized
INFO - 2016-11-11 14:30:44 --> Model Class Initialized
INFO - 2016-11-11 14:30:44 --> Model Class Initialized
INFO - 2016-11-11 14:30:44 --> Model Class Initialized
INFO - 2016-11-11 14:30:44 --> Model Class Initialized
INFO - 2016-11-11 14:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:30:44 --> Final output sent to browser
DEBUG - 2016-11-11 14:30:44 --> Total execution time: 0.4151
INFO - 2016-11-11 14:36:39 --> Config Class Initialized
INFO - 2016-11-11 14:36:39 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:36:39 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:36:39 --> Utf8 Class Initialized
INFO - 2016-11-11 14:36:39 --> URI Class Initialized
DEBUG - 2016-11-11 14:36:39 --> No URI present. Default controller set.
INFO - 2016-11-11 14:36:39 --> Router Class Initialized
INFO - 2016-11-11 14:36:39 --> Output Class Initialized
INFO - 2016-11-11 14:36:39 --> Security Class Initialized
DEBUG - 2016-11-11 14:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:36:39 --> Input Class Initialized
INFO - 2016-11-11 14:36:39 --> Language Class Initialized
INFO - 2016-11-11 14:36:39 --> Loader Class Initialized
INFO - 2016-11-11 14:36:39 --> Helper loaded: url_helper
INFO - 2016-11-11 14:36:39 --> Helper loaded: form_helper
INFO - 2016-11-11 14:36:39 --> Database Driver Class Initialized
INFO - 2016-11-11 14:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:36:39 --> Controller Class Initialized
INFO - 2016-11-11 14:36:39 --> Model Class Initialized
INFO - 2016-11-11 14:36:39 --> Model Class Initialized
INFO - 2016-11-11 14:36:39 --> Model Class Initialized
INFO - 2016-11-11 14:36:39 --> Model Class Initialized
INFO - 2016-11-11 14:36:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:36:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:36:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:36:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:36:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:36:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:36:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:36:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:36:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:36:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:36:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:36:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:36:40 --> Final output sent to browser
DEBUG - 2016-11-11 14:36:40 --> Total execution time: 0.6751
INFO - 2016-11-11 14:36:43 --> Config Class Initialized
INFO - 2016-11-11 14:36:43 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:36:43 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:36:43 --> Utf8 Class Initialized
INFO - 2016-11-11 14:36:43 --> URI Class Initialized
DEBUG - 2016-11-11 14:36:43 --> No URI present. Default controller set.
INFO - 2016-11-11 14:36:43 --> Router Class Initialized
INFO - 2016-11-11 14:36:43 --> Output Class Initialized
INFO - 2016-11-11 14:36:43 --> Security Class Initialized
DEBUG - 2016-11-11 14:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:36:43 --> Input Class Initialized
INFO - 2016-11-11 14:36:43 --> Language Class Initialized
INFO - 2016-11-11 14:36:43 --> Loader Class Initialized
INFO - 2016-11-11 14:36:43 --> Helper loaded: url_helper
INFO - 2016-11-11 14:36:43 --> Helper loaded: form_helper
INFO - 2016-11-11 14:36:43 --> Database Driver Class Initialized
INFO - 2016-11-11 14:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:36:43 --> Controller Class Initialized
INFO - 2016-11-11 14:36:43 --> Model Class Initialized
INFO - 2016-11-11 14:36:43 --> Model Class Initialized
INFO - 2016-11-11 14:36:43 --> Model Class Initialized
INFO - 2016-11-11 14:36:43 --> Model Class Initialized
INFO - 2016-11-11 14:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:36:43 --> Final output sent to browser
DEBUG - 2016-11-11 14:36:43 --> Total execution time: 0.4207
INFO - 2016-11-11 14:37:52 --> Config Class Initialized
INFO - 2016-11-11 14:37:52 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:37:52 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:37:52 --> Utf8 Class Initialized
INFO - 2016-11-11 14:37:52 --> URI Class Initialized
DEBUG - 2016-11-11 14:37:52 --> No URI present. Default controller set.
INFO - 2016-11-11 14:37:52 --> Router Class Initialized
INFO - 2016-11-11 14:37:52 --> Output Class Initialized
INFO - 2016-11-11 14:37:52 --> Security Class Initialized
DEBUG - 2016-11-11 14:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:37:52 --> Input Class Initialized
INFO - 2016-11-11 14:37:52 --> Language Class Initialized
INFO - 2016-11-11 14:37:52 --> Loader Class Initialized
INFO - 2016-11-11 14:37:52 --> Helper loaded: url_helper
INFO - 2016-11-11 14:37:52 --> Helper loaded: form_helper
INFO - 2016-11-11 14:37:52 --> Database Driver Class Initialized
INFO - 2016-11-11 14:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:37:52 --> Controller Class Initialized
INFO - 2016-11-11 14:37:52 --> Model Class Initialized
INFO - 2016-11-11 14:37:52 --> Model Class Initialized
INFO - 2016-11-11 14:37:52 --> Model Class Initialized
INFO - 2016-11-11 14:37:52 --> Model Class Initialized
INFO - 2016-11-11 14:37:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:37:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:37:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:37:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:37:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:37:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:37:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:37:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:37:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:37:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:37:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:37:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:37:52 --> Final output sent to browser
DEBUG - 2016-11-11 14:37:52 --> Total execution time: 0.4232
INFO - 2016-11-11 14:40:03 --> Config Class Initialized
INFO - 2016-11-11 14:40:03 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:40:03 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:40:03 --> Utf8 Class Initialized
INFO - 2016-11-11 14:40:03 --> URI Class Initialized
DEBUG - 2016-11-11 14:40:03 --> No URI present. Default controller set.
INFO - 2016-11-11 14:40:03 --> Router Class Initialized
INFO - 2016-11-11 14:40:03 --> Output Class Initialized
INFO - 2016-11-11 14:40:03 --> Security Class Initialized
DEBUG - 2016-11-11 14:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:40:03 --> Input Class Initialized
INFO - 2016-11-11 14:40:03 --> Language Class Initialized
INFO - 2016-11-11 14:40:03 --> Loader Class Initialized
INFO - 2016-11-11 14:40:03 --> Helper loaded: url_helper
INFO - 2016-11-11 14:40:03 --> Helper loaded: form_helper
INFO - 2016-11-11 14:40:03 --> Database Driver Class Initialized
INFO - 2016-11-11 14:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:40:03 --> Controller Class Initialized
INFO - 2016-11-11 14:40:03 --> Model Class Initialized
INFO - 2016-11-11 14:40:03 --> Model Class Initialized
INFO - 2016-11-11 14:40:03 --> Model Class Initialized
INFO - 2016-11-11 14:40:03 --> Model Class Initialized
INFO - 2016-11-11 14:40:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:40:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:40:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:40:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:40:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:40:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:40:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:40:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:40:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:40:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:40:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:40:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:40:03 --> Final output sent to browser
DEBUG - 2016-11-11 14:40:03 --> Total execution time: 0.3962
INFO - 2016-11-11 14:40:48 --> Config Class Initialized
INFO - 2016-11-11 14:40:48 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:40:48 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:40:48 --> Utf8 Class Initialized
INFO - 2016-11-11 14:40:48 --> URI Class Initialized
DEBUG - 2016-11-11 14:40:48 --> No URI present. Default controller set.
INFO - 2016-11-11 14:40:48 --> Router Class Initialized
INFO - 2016-11-11 14:40:48 --> Output Class Initialized
INFO - 2016-11-11 14:40:48 --> Security Class Initialized
DEBUG - 2016-11-11 14:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:40:48 --> Input Class Initialized
INFO - 2016-11-11 14:40:48 --> Language Class Initialized
INFO - 2016-11-11 14:40:48 --> Loader Class Initialized
INFO - 2016-11-11 14:40:48 --> Helper loaded: url_helper
INFO - 2016-11-11 14:40:48 --> Helper loaded: form_helper
INFO - 2016-11-11 14:40:48 --> Database Driver Class Initialized
INFO - 2016-11-11 14:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:40:48 --> Controller Class Initialized
INFO - 2016-11-11 14:40:48 --> Model Class Initialized
INFO - 2016-11-11 14:40:48 --> Model Class Initialized
INFO - 2016-11-11 14:40:48 --> Model Class Initialized
INFO - 2016-11-11 14:40:48 --> Model Class Initialized
INFO - 2016-11-11 14:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:40:48 --> Final output sent to browser
DEBUG - 2016-11-11 14:40:48 --> Total execution time: 0.3843
INFO - 2016-11-11 14:40:52 --> Config Class Initialized
INFO - 2016-11-11 14:40:52 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:40:52 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:40:52 --> Utf8 Class Initialized
INFO - 2016-11-11 14:40:52 --> URI Class Initialized
DEBUG - 2016-11-11 14:40:52 --> No URI present. Default controller set.
INFO - 2016-11-11 14:40:52 --> Router Class Initialized
INFO - 2016-11-11 14:40:52 --> Output Class Initialized
INFO - 2016-11-11 14:40:52 --> Security Class Initialized
DEBUG - 2016-11-11 14:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:40:52 --> Input Class Initialized
INFO - 2016-11-11 14:40:52 --> Language Class Initialized
INFO - 2016-11-11 14:40:52 --> Loader Class Initialized
INFO - 2016-11-11 14:40:52 --> Helper loaded: url_helper
INFO - 2016-11-11 14:40:52 --> Helper loaded: form_helper
INFO - 2016-11-11 14:40:52 --> Database Driver Class Initialized
INFO - 2016-11-11 14:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:40:52 --> Controller Class Initialized
INFO - 2016-11-11 14:40:52 --> Model Class Initialized
INFO - 2016-11-11 14:40:52 --> Model Class Initialized
INFO - 2016-11-11 14:40:52 --> Model Class Initialized
INFO - 2016-11-11 14:40:52 --> Model Class Initialized
INFO - 2016-11-11 14:40:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:40:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:40:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:40:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:40:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:40:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:40:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:40:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:40:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:40:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:40:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:40:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:40:52 --> Final output sent to browser
DEBUG - 2016-11-11 14:40:52 --> Total execution time: 0.4213
INFO - 2016-11-11 14:43:49 --> Config Class Initialized
INFO - 2016-11-11 14:43:49 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:43:49 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:43:49 --> Utf8 Class Initialized
INFO - 2016-11-11 14:43:49 --> URI Class Initialized
DEBUG - 2016-11-11 14:43:49 --> No URI present. Default controller set.
INFO - 2016-11-11 14:43:49 --> Router Class Initialized
INFO - 2016-11-11 14:43:49 --> Output Class Initialized
INFO - 2016-11-11 14:43:49 --> Security Class Initialized
DEBUG - 2016-11-11 14:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:43:49 --> Input Class Initialized
INFO - 2016-11-11 14:43:49 --> Language Class Initialized
INFO - 2016-11-11 14:43:49 --> Loader Class Initialized
INFO - 2016-11-11 14:43:49 --> Helper loaded: url_helper
INFO - 2016-11-11 14:43:49 --> Helper loaded: form_helper
INFO - 2016-11-11 14:43:49 --> Database Driver Class Initialized
INFO - 2016-11-11 14:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:43:49 --> Controller Class Initialized
INFO - 2016-11-11 14:43:49 --> Model Class Initialized
INFO - 2016-11-11 14:43:49 --> Model Class Initialized
INFO - 2016-11-11 14:43:49 --> Model Class Initialized
INFO - 2016-11-11 14:43:49 --> Model Class Initialized
INFO - 2016-11-11 14:43:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:43:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:43:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:43:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:43:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:43:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:43:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:43:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:43:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:43:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:43:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:43:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:43:49 --> Final output sent to browser
DEBUG - 2016-11-11 14:43:49 --> Total execution time: 0.4273
INFO - 2016-11-11 14:43:49 --> Config Class Initialized
INFO - 2016-11-11 14:43:49 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:43:49 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:43:49 --> Utf8 Class Initialized
INFO - 2016-11-11 14:43:49 --> URI Class Initialized
DEBUG - 2016-11-11 14:43:49 --> No URI present. Default controller set.
INFO - 2016-11-11 14:43:49 --> Router Class Initialized
INFO - 2016-11-11 14:43:49 --> Output Class Initialized
INFO - 2016-11-11 14:43:49 --> Security Class Initialized
DEBUG - 2016-11-11 14:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:43:49 --> Input Class Initialized
INFO - 2016-11-11 14:43:49 --> Language Class Initialized
INFO - 2016-11-11 14:43:50 --> Loader Class Initialized
INFO - 2016-11-11 14:43:50 --> Helper loaded: url_helper
INFO - 2016-11-11 14:43:50 --> Helper loaded: form_helper
INFO - 2016-11-11 14:43:50 --> Database Driver Class Initialized
INFO - 2016-11-11 14:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:43:50 --> Controller Class Initialized
INFO - 2016-11-11 14:43:50 --> Model Class Initialized
INFO - 2016-11-11 14:43:50 --> Model Class Initialized
INFO - 2016-11-11 14:43:50 --> Model Class Initialized
INFO - 2016-11-11 14:43:50 --> Model Class Initialized
INFO - 2016-11-11 14:43:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:43:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:43:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:43:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:43:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:43:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:43:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:43:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:43:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:43:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:43:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:43:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:43:50 --> Final output sent to browser
DEBUG - 2016-11-11 14:43:50 --> Total execution time: 0.4102
INFO - 2016-11-11 14:43:54 --> Config Class Initialized
INFO - 2016-11-11 14:43:54 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:43:54 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:43:54 --> Utf8 Class Initialized
INFO - 2016-11-11 14:43:54 --> URI Class Initialized
INFO - 2016-11-11 14:43:54 --> Router Class Initialized
INFO - 2016-11-11 14:43:54 --> Output Class Initialized
INFO - 2016-11-11 14:43:54 --> Security Class Initialized
DEBUG - 2016-11-11 14:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:43:54 --> Input Class Initialized
INFO - 2016-11-11 14:43:54 --> Language Class Initialized
INFO - 2016-11-11 14:43:54 --> Loader Class Initialized
INFO - 2016-11-11 14:43:54 --> Helper loaded: url_helper
INFO - 2016-11-11 14:43:54 --> Helper loaded: form_helper
INFO - 2016-11-11 14:43:54 --> Database Driver Class Initialized
INFO - 2016-11-11 14:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:43:54 --> Controller Class Initialized
INFO - 2016-11-11 14:43:54 --> Model Class Initialized
INFO - 2016-11-11 14:43:54 --> Model Class Initialized
INFO - 2016-11-11 14:43:54 --> Model Class Initialized
INFO - 2016-11-11 14:43:54 --> Model Class Initialized
DEBUG - 2016-11-11 14:43:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-11 14:43:54 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
ERROR - 2016-11-11 14:43:54 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
INFO - 2016-11-11 14:43:54 --> Config Class Initialized
INFO - 2016-11-11 14:43:54 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:43:54 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:43:54 --> Utf8 Class Initialized
INFO - 2016-11-11 14:43:54 --> URI Class Initialized
DEBUG - 2016-11-11 14:43:54 --> No URI present. Default controller set.
INFO - 2016-11-11 14:43:54 --> Router Class Initialized
INFO - 2016-11-11 14:43:54 --> Output Class Initialized
INFO - 2016-11-11 14:43:54 --> Security Class Initialized
DEBUG - 2016-11-11 14:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:43:54 --> Input Class Initialized
INFO - 2016-11-11 14:43:54 --> Language Class Initialized
INFO - 2016-11-11 14:43:54 --> Loader Class Initialized
INFO - 2016-11-11 14:43:54 --> Helper loaded: url_helper
INFO - 2016-11-11 14:43:54 --> Helper loaded: form_helper
INFO - 2016-11-11 14:43:54 --> Database Driver Class Initialized
INFO - 2016-11-11 14:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:43:54 --> Controller Class Initialized
INFO - 2016-11-11 14:43:54 --> Model Class Initialized
INFO - 2016-11-11 14:43:54 --> Model Class Initialized
INFO - 2016-11-11 14:43:54 --> Model Class Initialized
INFO - 2016-11-11 14:43:54 --> Model Class Initialized
INFO - 2016-11-11 14:43:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:43:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-11 14:43:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:43:54 --> Final output sent to browser
DEBUG - 2016-11-11 14:43:54 --> Total execution time: 0.2844
INFO - 2016-11-11 14:44:02 --> Config Class Initialized
INFO - 2016-11-11 14:44:02 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:44:02 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:44:02 --> Utf8 Class Initialized
INFO - 2016-11-11 14:44:02 --> URI Class Initialized
INFO - 2016-11-11 14:44:02 --> Router Class Initialized
INFO - 2016-11-11 14:44:02 --> Output Class Initialized
INFO - 2016-11-11 14:44:02 --> Security Class Initialized
DEBUG - 2016-11-11 14:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:44:02 --> Input Class Initialized
INFO - 2016-11-11 14:44:02 --> Language Class Initialized
INFO - 2016-11-11 14:44:02 --> Loader Class Initialized
INFO - 2016-11-11 14:44:02 --> Helper loaded: url_helper
INFO - 2016-11-11 14:44:02 --> Helper loaded: form_helper
INFO - 2016-11-11 14:44:02 --> Database Driver Class Initialized
INFO - 2016-11-11 14:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:44:02 --> Controller Class Initialized
INFO - 2016-11-11 14:44:02 --> Model Class Initialized
INFO - 2016-11-11 14:44:02 --> Model Class Initialized
INFO - 2016-11-11 14:44:02 --> Model Class Initialized
INFO - 2016-11-11 14:44:02 --> Model Class Initialized
DEBUG - 2016-11-11 14:44:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-11 14:44:02 --> Model Class Initialized
INFO - 2016-11-11 14:44:02 --> Final output sent to browser
DEBUG - 2016-11-11 14:44:02 --> Total execution time: 0.2731
INFO - 2016-11-11 14:44:02 --> Config Class Initialized
INFO - 2016-11-11 14:44:02 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:44:02 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:44:02 --> Utf8 Class Initialized
INFO - 2016-11-11 14:44:02 --> URI Class Initialized
DEBUG - 2016-11-11 14:44:02 --> No URI present. Default controller set.
INFO - 2016-11-11 14:44:02 --> Router Class Initialized
INFO - 2016-11-11 14:44:02 --> Output Class Initialized
INFO - 2016-11-11 14:44:02 --> Security Class Initialized
DEBUG - 2016-11-11 14:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:44:02 --> Input Class Initialized
INFO - 2016-11-11 14:44:02 --> Language Class Initialized
INFO - 2016-11-11 14:44:02 --> Loader Class Initialized
INFO - 2016-11-11 14:44:02 --> Helper loaded: url_helper
INFO - 2016-11-11 14:44:02 --> Helper loaded: form_helper
INFO - 2016-11-11 14:44:02 --> Database Driver Class Initialized
INFO - 2016-11-11 14:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:44:02 --> Controller Class Initialized
INFO - 2016-11-11 14:44:02 --> Model Class Initialized
INFO - 2016-11-11 14:44:02 --> Model Class Initialized
INFO - 2016-11-11 14:44:02 --> Model Class Initialized
INFO - 2016-11-11 14:44:02 --> Model Class Initialized
INFO - 2016-11-11 14:44:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:44:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:44:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:44:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:44:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:44:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:44:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:44:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:44:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:44:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:44:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:44:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:44:02 --> Final output sent to browser
DEBUG - 2016-11-11 14:44:02 --> Total execution time: 0.3875
INFO - 2016-11-11 14:45:31 --> Config Class Initialized
INFO - 2016-11-11 14:45:31 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:45:31 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:45:31 --> Utf8 Class Initialized
INFO - 2016-11-11 14:45:31 --> URI Class Initialized
DEBUG - 2016-11-11 14:45:31 --> No URI present. Default controller set.
INFO - 2016-11-11 14:45:31 --> Router Class Initialized
INFO - 2016-11-11 14:45:31 --> Output Class Initialized
INFO - 2016-11-11 14:45:31 --> Security Class Initialized
DEBUG - 2016-11-11 14:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:45:31 --> Input Class Initialized
INFO - 2016-11-11 14:45:31 --> Language Class Initialized
INFO - 2016-11-11 14:45:31 --> Loader Class Initialized
INFO - 2016-11-11 14:45:31 --> Helper loaded: url_helper
INFO - 2016-11-11 14:45:31 --> Helper loaded: form_helper
INFO - 2016-11-11 14:45:31 --> Database Driver Class Initialized
INFO - 2016-11-11 14:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:45:31 --> Controller Class Initialized
INFO - 2016-11-11 14:45:31 --> Model Class Initialized
INFO - 2016-11-11 14:45:31 --> Model Class Initialized
INFO - 2016-11-11 14:45:31 --> Model Class Initialized
INFO - 2016-11-11 14:45:32 --> Model Class Initialized
INFO - 2016-11-11 14:45:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:45:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:45:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:45:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:45:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:45:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:45:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:45:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:45:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:45:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:45:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:45:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:45:32 --> Final output sent to browser
DEBUG - 2016-11-11 14:45:32 --> Total execution time: 0.4145
INFO - 2016-11-11 14:46:06 --> Config Class Initialized
INFO - 2016-11-11 14:46:06 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:46:06 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:46:06 --> Utf8 Class Initialized
INFO - 2016-11-11 14:46:06 --> URI Class Initialized
DEBUG - 2016-11-11 14:46:06 --> No URI present. Default controller set.
INFO - 2016-11-11 14:46:06 --> Router Class Initialized
INFO - 2016-11-11 14:46:06 --> Output Class Initialized
INFO - 2016-11-11 14:46:06 --> Security Class Initialized
DEBUG - 2016-11-11 14:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:46:06 --> Input Class Initialized
INFO - 2016-11-11 14:46:06 --> Language Class Initialized
INFO - 2016-11-11 14:46:06 --> Loader Class Initialized
INFO - 2016-11-11 14:46:06 --> Helper loaded: url_helper
INFO - 2016-11-11 14:46:07 --> Helper loaded: form_helper
INFO - 2016-11-11 14:46:07 --> Database Driver Class Initialized
INFO - 2016-11-11 14:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:46:07 --> Controller Class Initialized
INFO - 2016-11-11 14:46:07 --> Model Class Initialized
INFO - 2016-11-11 14:46:07 --> Model Class Initialized
INFO - 2016-11-11 14:46:07 --> Model Class Initialized
INFO - 2016-11-11 14:46:07 --> Model Class Initialized
INFO - 2016-11-11 14:46:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:46:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:46:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:46:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:46:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:46:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:46:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:46:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:46:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:46:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:46:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:46:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:46:07 --> Final output sent to browser
DEBUG - 2016-11-11 14:46:07 --> Total execution time: 0.7725
INFO - 2016-11-11 14:48:12 --> Config Class Initialized
INFO - 2016-11-11 14:48:12 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:48:12 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:48:12 --> Utf8 Class Initialized
INFO - 2016-11-11 14:48:12 --> URI Class Initialized
DEBUG - 2016-11-11 14:48:12 --> No URI present. Default controller set.
INFO - 2016-11-11 14:48:12 --> Router Class Initialized
INFO - 2016-11-11 14:48:12 --> Output Class Initialized
INFO - 2016-11-11 14:48:12 --> Security Class Initialized
DEBUG - 2016-11-11 14:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:48:12 --> Input Class Initialized
INFO - 2016-11-11 14:48:12 --> Language Class Initialized
INFO - 2016-11-11 14:48:12 --> Loader Class Initialized
INFO - 2016-11-11 14:48:12 --> Helper loaded: url_helper
INFO - 2016-11-11 14:48:12 --> Helper loaded: form_helper
INFO - 2016-11-11 14:48:12 --> Database Driver Class Initialized
INFO - 2016-11-11 14:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:48:12 --> Controller Class Initialized
INFO - 2016-11-11 14:48:12 --> Model Class Initialized
INFO - 2016-11-11 14:48:12 --> Model Class Initialized
INFO - 2016-11-11 14:48:12 --> Model Class Initialized
INFO - 2016-11-11 14:48:12 --> Model Class Initialized
INFO - 2016-11-11 14:48:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:48:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:48:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:48:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:48:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:48:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:48:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:48:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:48:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:48:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:48:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:48:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:48:13 --> Final output sent to browser
DEBUG - 2016-11-11 14:48:13 --> Total execution time: 0.4680
INFO - 2016-11-11 14:49:24 --> Config Class Initialized
INFO - 2016-11-11 14:49:24 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:49:24 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:49:24 --> Utf8 Class Initialized
INFO - 2016-11-11 14:49:24 --> URI Class Initialized
DEBUG - 2016-11-11 14:49:24 --> No URI present. Default controller set.
INFO - 2016-11-11 14:49:24 --> Router Class Initialized
INFO - 2016-11-11 14:49:24 --> Output Class Initialized
INFO - 2016-11-11 14:49:24 --> Security Class Initialized
DEBUG - 2016-11-11 14:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:49:24 --> Input Class Initialized
INFO - 2016-11-11 14:49:24 --> Language Class Initialized
INFO - 2016-11-11 14:49:24 --> Loader Class Initialized
INFO - 2016-11-11 14:49:24 --> Helper loaded: url_helper
INFO - 2016-11-11 14:49:24 --> Helper loaded: form_helper
INFO - 2016-11-11 14:49:24 --> Database Driver Class Initialized
INFO - 2016-11-11 14:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:49:24 --> Controller Class Initialized
INFO - 2016-11-11 14:49:24 --> Model Class Initialized
INFO - 2016-11-11 14:49:24 --> Model Class Initialized
INFO - 2016-11-11 14:49:24 --> Model Class Initialized
INFO - 2016-11-11 14:49:24 --> Model Class Initialized
INFO - 2016-11-11 14:49:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:49:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:49:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:49:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:49:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:49:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:49:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:49:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:49:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:49:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:49:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:49:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:49:24 --> Final output sent to browser
DEBUG - 2016-11-11 14:49:24 --> Total execution time: 0.4106
INFO - 2016-11-11 14:51:27 --> Config Class Initialized
INFO - 2016-11-11 14:51:27 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:51:27 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:51:27 --> Utf8 Class Initialized
INFO - 2016-11-11 14:51:27 --> URI Class Initialized
DEBUG - 2016-11-11 14:51:27 --> No URI present. Default controller set.
INFO - 2016-11-11 14:51:27 --> Router Class Initialized
INFO - 2016-11-11 14:51:27 --> Output Class Initialized
INFO - 2016-11-11 14:51:27 --> Security Class Initialized
DEBUG - 2016-11-11 14:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:51:27 --> Input Class Initialized
INFO - 2016-11-11 14:51:27 --> Language Class Initialized
INFO - 2016-11-11 14:51:27 --> Loader Class Initialized
INFO - 2016-11-11 14:51:27 --> Helper loaded: url_helper
INFO - 2016-11-11 14:51:27 --> Helper loaded: form_helper
INFO - 2016-11-11 14:51:27 --> Database Driver Class Initialized
INFO - 2016-11-11 14:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:51:27 --> Controller Class Initialized
INFO - 2016-11-11 14:51:27 --> Model Class Initialized
INFO - 2016-11-11 14:51:27 --> Model Class Initialized
INFO - 2016-11-11 14:51:27 --> Model Class Initialized
INFO - 2016-11-11 14:51:27 --> Model Class Initialized
INFO - 2016-11-11 14:51:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:51:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:51:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:51:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:51:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:51:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:51:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:51:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:51:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:51:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:51:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:51:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:51:27 --> Final output sent to browser
DEBUG - 2016-11-11 14:51:27 --> Total execution time: 0.4173
INFO - 2016-11-11 14:51:56 --> Config Class Initialized
INFO - 2016-11-11 14:51:56 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:51:56 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:51:56 --> Utf8 Class Initialized
INFO - 2016-11-11 14:51:56 --> URI Class Initialized
DEBUG - 2016-11-11 14:51:56 --> No URI present. Default controller set.
INFO - 2016-11-11 14:51:56 --> Router Class Initialized
INFO - 2016-11-11 14:51:56 --> Output Class Initialized
INFO - 2016-11-11 14:51:57 --> Security Class Initialized
DEBUG - 2016-11-11 14:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:51:57 --> Input Class Initialized
INFO - 2016-11-11 14:51:57 --> Language Class Initialized
INFO - 2016-11-11 14:51:57 --> Loader Class Initialized
INFO - 2016-11-11 14:51:57 --> Helper loaded: url_helper
INFO - 2016-11-11 14:51:57 --> Helper loaded: form_helper
INFO - 2016-11-11 14:51:57 --> Database Driver Class Initialized
INFO - 2016-11-11 14:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:51:57 --> Controller Class Initialized
INFO - 2016-11-11 14:51:57 --> Model Class Initialized
INFO - 2016-11-11 14:51:57 --> Model Class Initialized
INFO - 2016-11-11 14:51:57 --> Model Class Initialized
INFO - 2016-11-11 14:51:57 --> Model Class Initialized
INFO - 2016-11-11 14:51:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:51:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:51:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:51:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:51:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:51:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:51:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:51:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:51:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:51:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:51:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:51:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:51:57 --> Final output sent to browser
DEBUG - 2016-11-11 14:51:57 --> Total execution time: 0.4369
INFO - 2016-11-11 14:52:56 --> Config Class Initialized
INFO - 2016-11-11 14:52:56 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:52:56 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:52:56 --> Utf8 Class Initialized
INFO - 2016-11-11 14:52:56 --> URI Class Initialized
DEBUG - 2016-11-11 14:52:56 --> No URI present. Default controller set.
INFO - 2016-11-11 14:52:56 --> Router Class Initialized
INFO - 2016-11-11 14:52:56 --> Output Class Initialized
INFO - 2016-11-11 14:52:56 --> Security Class Initialized
DEBUG - 2016-11-11 14:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:52:56 --> Input Class Initialized
INFO - 2016-11-11 14:52:56 --> Language Class Initialized
INFO - 2016-11-11 14:52:56 --> Loader Class Initialized
INFO - 2016-11-11 14:52:56 --> Helper loaded: url_helper
INFO - 2016-11-11 14:52:56 --> Helper loaded: form_helper
INFO - 2016-11-11 14:52:56 --> Database Driver Class Initialized
INFO - 2016-11-11 14:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:52:56 --> Controller Class Initialized
INFO - 2016-11-11 14:52:56 --> Model Class Initialized
INFO - 2016-11-11 14:52:56 --> Model Class Initialized
INFO - 2016-11-11 14:52:56 --> Model Class Initialized
INFO - 2016-11-11 14:52:56 --> Model Class Initialized
INFO - 2016-11-11 14:52:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:52:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:52:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:52:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:52:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:52:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:52:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:52:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:52:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:52:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:52:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:52:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:52:57 --> Final output sent to browser
DEBUG - 2016-11-11 14:52:57 --> Total execution time: 0.4189
INFO - 2016-11-11 14:53:51 --> Config Class Initialized
INFO - 2016-11-11 14:53:51 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:53:51 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:53:51 --> Utf8 Class Initialized
INFO - 2016-11-11 14:53:51 --> URI Class Initialized
INFO - 2016-11-11 14:53:51 --> Router Class Initialized
INFO - 2016-11-11 14:53:51 --> Output Class Initialized
INFO - 2016-11-11 14:53:51 --> Security Class Initialized
DEBUG - 2016-11-11 14:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:53:51 --> Input Class Initialized
INFO - 2016-11-11 14:53:51 --> Language Class Initialized
INFO - 2016-11-11 14:53:51 --> Loader Class Initialized
INFO - 2016-11-11 14:53:51 --> Helper loaded: url_helper
INFO - 2016-11-11 14:53:51 --> Helper loaded: form_helper
INFO - 2016-11-11 14:53:51 --> Database Driver Class Initialized
INFO - 2016-11-11 14:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:53:51 --> Controller Class Initialized
INFO - 2016-11-11 14:53:51 --> Model Class Initialized
INFO - 2016-11-11 14:53:51 --> Model Class Initialized
INFO - 2016-11-11 14:53:51 --> Model Class Initialized
INFO - 2016-11-11 14:53:51 --> Model Class Initialized
DEBUG - 2016-11-11 14:53:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-11 14:53:51 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
ERROR - 2016-11-11 14:53:51 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
INFO - 2016-11-11 14:53:51 --> Config Class Initialized
INFO - 2016-11-11 14:53:51 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:53:51 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:53:51 --> Utf8 Class Initialized
INFO - 2016-11-11 14:53:51 --> URI Class Initialized
DEBUG - 2016-11-11 14:53:51 --> No URI present. Default controller set.
INFO - 2016-11-11 14:53:51 --> Router Class Initialized
INFO - 2016-11-11 14:53:51 --> Output Class Initialized
INFO - 2016-11-11 14:53:51 --> Security Class Initialized
DEBUG - 2016-11-11 14:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:53:51 --> Input Class Initialized
INFO - 2016-11-11 14:53:51 --> Language Class Initialized
INFO - 2016-11-11 14:53:51 --> Loader Class Initialized
INFO - 2016-11-11 14:53:51 --> Helper loaded: url_helper
INFO - 2016-11-11 14:53:51 --> Helper loaded: form_helper
INFO - 2016-11-11 14:53:51 --> Database Driver Class Initialized
INFO - 2016-11-11 14:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:53:52 --> Controller Class Initialized
INFO - 2016-11-11 14:53:52 --> Model Class Initialized
INFO - 2016-11-11 14:53:52 --> Model Class Initialized
INFO - 2016-11-11 14:53:52 --> Model Class Initialized
INFO - 2016-11-11 14:53:52 --> Model Class Initialized
INFO - 2016-11-11 14:53:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:53:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-11 14:53:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:53:52 --> Final output sent to browser
DEBUG - 2016-11-11 14:53:52 --> Total execution time: 0.2873
INFO - 2016-11-11 14:54:00 --> Config Class Initialized
INFO - 2016-11-11 14:54:01 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:54:01 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:54:01 --> Utf8 Class Initialized
INFO - 2016-11-11 14:54:01 --> URI Class Initialized
INFO - 2016-11-11 14:54:01 --> Router Class Initialized
INFO - 2016-11-11 14:54:01 --> Output Class Initialized
INFO - 2016-11-11 14:54:01 --> Security Class Initialized
DEBUG - 2016-11-11 14:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:54:01 --> Input Class Initialized
INFO - 2016-11-11 14:54:01 --> Language Class Initialized
INFO - 2016-11-11 14:54:01 --> Loader Class Initialized
INFO - 2016-11-11 14:54:01 --> Helper loaded: url_helper
INFO - 2016-11-11 14:54:01 --> Helper loaded: form_helper
INFO - 2016-11-11 14:54:01 --> Database Driver Class Initialized
INFO - 2016-11-11 14:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:54:01 --> Controller Class Initialized
INFO - 2016-11-11 14:54:01 --> Model Class Initialized
INFO - 2016-11-11 14:54:01 --> Model Class Initialized
INFO - 2016-11-11 14:54:01 --> Model Class Initialized
INFO - 2016-11-11 14:54:01 --> Model Class Initialized
DEBUG - 2016-11-11 14:54:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-11 14:54:01 --> Model Class Initialized
INFO - 2016-11-11 14:54:01 --> Final output sent to browser
DEBUG - 2016-11-11 14:54:01 --> Total execution time: 0.2860
INFO - 2016-11-11 14:54:01 --> Config Class Initialized
INFO - 2016-11-11 14:54:01 --> Hooks Class Initialized
DEBUG - 2016-11-11 14:54:01 --> UTF-8 Support Enabled
INFO - 2016-11-11 14:54:01 --> Utf8 Class Initialized
INFO - 2016-11-11 14:54:01 --> URI Class Initialized
DEBUG - 2016-11-11 14:54:01 --> No URI present. Default controller set.
INFO - 2016-11-11 14:54:01 --> Router Class Initialized
INFO - 2016-11-11 14:54:01 --> Output Class Initialized
INFO - 2016-11-11 14:54:01 --> Security Class Initialized
DEBUG - 2016-11-11 14:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 14:54:01 --> Input Class Initialized
INFO - 2016-11-11 14:54:01 --> Language Class Initialized
INFO - 2016-11-11 14:54:01 --> Loader Class Initialized
INFO - 2016-11-11 14:54:01 --> Helper loaded: url_helper
INFO - 2016-11-11 14:54:01 --> Helper loaded: form_helper
INFO - 2016-11-11 14:54:01 --> Database Driver Class Initialized
INFO - 2016-11-11 14:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 14:54:01 --> Controller Class Initialized
INFO - 2016-11-11 14:54:01 --> Model Class Initialized
INFO - 2016-11-11 14:54:01 --> Model Class Initialized
INFO - 2016-11-11 14:54:01 --> Model Class Initialized
INFO - 2016-11-11 14:54:01 --> Model Class Initialized
INFO - 2016-11-11 14:54:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 14:54:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 14:54:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 14:54:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 14:54:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 14:54:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 14:54:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 14:54:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 14:54:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 14:54:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 14:54:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 14:54:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 14:54:01 --> Final output sent to browser
DEBUG - 2016-11-11 14:54:01 --> Total execution time: 0.4012
INFO - 2016-11-11 21:29:28 --> Config Class Initialized
INFO - 2016-11-11 21:29:29 --> Hooks Class Initialized
DEBUG - 2016-11-11 21:29:29 --> UTF-8 Support Enabled
INFO - 2016-11-11 21:29:29 --> Utf8 Class Initialized
INFO - 2016-11-11 21:29:29 --> URI Class Initialized
DEBUG - 2016-11-11 21:29:29 --> No URI present. Default controller set.
INFO - 2016-11-11 21:29:29 --> Router Class Initialized
INFO - 2016-11-11 21:29:29 --> Output Class Initialized
INFO - 2016-11-11 21:29:30 --> Security Class Initialized
DEBUG - 2016-11-11 21:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 21:29:30 --> Input Class Initialized
INFO - 2016-11-11 21:29:30 --> Language Class Initialized
INFO - 2016-11-11 21:29:30 --> Loader Class Initialized
INFO - 2016-11-11 21:29:30 --> Helper loaded: url_helper
INFO - 2016-11-11 21:29:30 --> Helper loaded: form_helper
INFO - 2016-11-11 21:29:31 --> Database Driver Class Initialized
INFO - 2016-11-11 21:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 21:29:31 --> Controller Class Initialized
INFO - 2016-11-11 21:29:31 --> Model Class Initialized
INFO - 2016-11-11 21:29:31 --> Model Class Initialized
INFO - 2016-11-11 21:29:31 --> Model Class Initialized
INFO - 2016-11-11 21:29:31 --> Model Class Initialized
INFO - 2016-11-11 21:29:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 21:29:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-11 21:29:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 21:29:32 --> Final output sent to browser
DEBUG - 2016-11-11 21:29:32 --> Total execution time: 3.7144
INFO - 2016-11-11 21:29:42 --> Config Class Initialized
INFO - 2016-11-11 21:29:42 --> Hooks Class Initialized
DEBUG - 2016-11-11 21:29:42 --> UTF-8 Support Enabled
INFO - 2016-11-11 21:29:42 --> Utf8 Class Initialized
INFO - 2016-11-11 21:29:42 --> URI Class Initialized
INFO - 2016-11-11 21:29:42 --> Router Class Initialized
INFO - 2016-11-11 21:29:43 --> Output Class Initialized
INFO - 2016-11-11 21:29:43 --> Security Class Initialized
DEBUG - 2016-11-11 21:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 21:29:43 --> Input Class Initialized
INFO - 2016-11-11 21:29:43 --> Language Class Initialized
INFO - 2016-11-11 21:29:43 --> Loader Class Initialized
INFO - 2016-11-11 21:29:43 --> Helper loaded: url_helper
INFO - 2016-11-11 21:29:43 --> Helper loaded: form_helper
INFO - 2016-11-11 21:29:43 --> Database Driver Class Initialized
INFO - 2016-11-11 21:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 21:29:43 --> Controller Class Initialized
INFO - 2016-11-11 21:29:43 --> Model Class Initialized
INFO - 2016-11-11 21:29:43 --> Model Class Initialized
INFO - 2016-11-11 21:29:43 --> Model Class Initialized
INFO - 2016-11-11 21:29:43 --> Model Class Initialized
DEBUG - 2016-11-11 21:29:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-11 21:29:43 --> Model Class Initialized
INFO - 2016-11-11 21:29:43 --> Final output sent to browser
DEBUG - 2016-11-11 21:29:43 --> Total execution time: 0.5652
INFO - 2016-11-11 21:29:43 --> Config Class Initialized
INFO - 2016-11-11 21:29:43 --> Hooks Class Initialized
DEBUG - 2016-11-11 21:29:43 --> UTF-8 Support Enabled
INFO - 2016-11-11 21:29:43 --> Utf8 Class Initialized
INFO - 2016-11-11 21:29:43 --> URI Class Initialized
DEBUG - 2016-11-11 21:29:43 --> No URI present. Default controller set.
INFO - 2016-11-11 21:29:43 --> Router Class Initialized
INFO - 2016-11-11 21:29:43 --> Output Class Initialized
INFO - 2016-11-11 21:29:43 --> Security Class Initialized
DEBUG - 2016-11-11 21:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 21:29:43 --> Input Class Initialized
INFO - 2016-11-11 21:29:43 --> Language Class Initialized
INFO - 2016-11-11 21:29:43 --> Loader Class Initialized
INFO - 2016-11-11 21:29:43 --> Helper loaded: url_helper
INFO - 2016-11-11 21:29:43 --> Helper loaded: form_helper
INFO - 2016-11-11 21:29:43 --> Database Driver Class Initialized
INFO - 2016-11-11 21:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 21:29:43 --> Controller Class Initialized
INFO - 2016-11-11 21:29:43 --> Model Class Initialized
INFO - 2016-11-11 21:29:43 --> Model Class Initialized
INFO - 2016-11-11 21:29:43 --> Model Class Initialized
INFO - 2016-11-11 21:29:43 --> Model Class Initialized
INFO - 2016-11-11 21:29:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 21:29:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 21:29:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 21:29:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 21:29:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 21:29:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 21:29:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 21:29:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 21:29:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 21:29:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 21:29:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 21:29:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 21:29:44 --> Final output sent to browser
DEBUG - 2016-11-11 21:29:44 --> Total execution time: 1.1006
INFO - 2016-11-11 21:34:04 --> Config Class Initialized
INFO - 2016-11-11 21:34:04 --> Hooks Class Initialized
DEBUG - 2016-11-11 21:34:04 --> UTF-8 Support Enabled
INFO - 2016-11-11 21:34:05 --> Utf8 Class Initialized
INFO - 2016-11-11 21:34:05 --> URI Class Initialized
INFO - 2016-11-11 21:34:05 --> Router Class Initialized
INFO - 2016-11-11 21:34:05 --> Output Class Initialized
INFO - 2016-11-11 21:34:05 --> Security Class Initialized
DEBUG - 2016-11-11 21:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 21:34:05 --> Input Class Initialized
INFO - 2016-11-11 21:34:05 --> Language Class Initialized
INFO - 2016-11-11 21:34:05 --> Loader Class Initialized
INFO - 2016-11-11 21:34:05 --> Helper loaded: url_helper
INFO - 2016-11-11 21:34:05 --> Helper loaded: form_helper
INFO - 2016-11-11 21:34:05 --> Database Driver Class Initialized
INFO - 2016-11-11 21:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 21:34:05 --> Controller Class Initialized
INFO - 2016-11-11 21:34:05 --> Model Class Initialized
INFO - 2016-11-11 21:34:05 --> Form Validation Class Initialized
INFO - 2016-11-11 21:34:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-11 21:34:05 --> Final output sent to browser
DEBUG - 2016-11-11 21:34:05 --> Total execution time: 0.6438
INFO - 2016-11-11 21:34:07 --> Config Class Initialized
INFO - 2016-11-11 21:34:07 --> Hooks Class Initialized
DEBUG - 2016-11-11 21:34:07 --> UTF-8 Support Enabled
INFO - 2016-11-11 21:34:07 --> Utf8 Class Initialized
INFO - 2016-11-11 21:34:07 --> URI Class Initialized
DEBUG - 2016-11-11 21:34:07 --> No URI present. Default controller set.
INFO - 2016-11-11 21:34:07 --> Router Class Initialized
INFO - 2016-11-11 21:34:07 --> Output Class Initialized
INFO - 2016-11-11 21:34:07 --> Security Class Initialized
DEBUG - 2016-11-11 21:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 21:34:07 --> Input Class Initialized
INFO - 2016-11-11 21:34:07 --> Language Class Initialized
INFO - 2016-11-11 21:34:07 --> Loader Class Initialized
INFO - 2016-11-11 21:34:07 --> Helper loaded: url_helper
INFO - 2016-11-11 21:34:07 --> Helper loaded: form_helper
INFO - 2016-11-11 21:34:07 --> Database Driver Class Initialized
INFO - 2016-11-11 21:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 21:34:07 --> Controller Class Initialized
INFO - 2016-11-11 21:34:07 --> Model Class Initialized
INFO - 2016-11-11 21:34:07 --> Model Class Initialized
INFO - 2016-11-11 21:34:07 --> Model Class Initialized
INFO - 2016-11-11 21:34:07 --> Model Class Initialized
INFO - 2016-11-11 21:34:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 21:34:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 21:34:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 21:34:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 21:34:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 21:34:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 21:34:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 21:34:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 21:34:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 21:34:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 21:34:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 21:34:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 21:34:08 --> Final output sent to browser
DEBUG - 2016-11-11 21:34:08 --> Total execution time: 0.4920
INFO - 2016-11-11 21:34:12 --> Config Class Initialized
INFO - 2016-11-11 21:34:12 --> Hooks Class Initialized
DEBUG - 2016-11-11 21:34:12 --> UTF-8 Support Enabled
INFO - 2016-11-11 21:34:12 --> Utf8 Class Initialized
INFO - 2016-11-11 21:34:12 --> URI Class Initialized
INFO - 2016-11-11 21:34:12 --> Router Class Initialized
INFO - 2016-11-11 21:34:12 --> Output Class Initialized
INFO - 2016-11-11 21:34:12 --> Security Class Initialized
DEBUG - 2016-11-11 21:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 21:34:12 --> Input Class Initialized
INFO - 2016-11-11 21:34:12 --> Language Class Initialized
INFO - 2016-11-11 21:34:12 --> Loader Class Initialized
INFO - 2016-11-11 21:34:12 --> Helper loaded: url_helper
INFO - 2016-11-11 21:34:12 --> Helper loaded: form_helper
INFO - 2016-11-11 21:34:12 --> Database Driver Class Initialized
INFO - 2016-11-11 21:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 21:34:12 --> Controller Class Initialized
INFO - 2016-11-11 21:34:12 --> Model Class Initialized
INFO - 2016-11-11 21:34:12 --> Form Validation Class Initialized
INFO - 2016-11-11 21:34:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-11 21:34:12 --> Final output sent to browser
DEBUG - 2016-11-11 21:34:12 --> Total execution time: 0.2537
INFO - 2016-11-11 21:34:13 --> Config Class Initialized
INFO - 2016-11-11 21:34:13 --> Hooks Class Initialized
DEBUG - 2016-11-11 21:34:13 --> UTF-8 Support Enabled
INFO - 2016-11-11 21:34:13 --> Utf8 Class Initialized
INFO - 2016-11-11 21:34:13 --> URI Class Initialized
DEBUG - 2016-11-11 21:34:13 --> No URI present. Default controller set.
INFO - 2016-11-11 21:34:13 --> Router Class Initialized
INFO - 2016-11-11 21:34:13 --> Output Class Initialized
INFO - 2016-11-11 21:34:13 --> Security Class Initialized
DEBUG - 2016-11-11 21:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 21:34:14 --> Input Class Initialized
INFO - 2016-11-11 21:34:14 --> Language Class Initialized
INFO - 2016-11-11 21:34:14 --> Loader Class Initialized
INFO - 2016-11-11 21:34:14 --> Helper loaded: url_helper
INFO - 2016-11-11 21:34:14 --> Helper loaded: form_helper
INFO - 2016-11-11 21:34:14 --> Database Driver Class Initialized
INFO - 2016-11-11 21:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 21:34:14 --> Controller Class Initialized
INFO - 2016-11-11 21:34:14 --> Model Class Initialized
INFO - 2016-11-11 21:34:14 --> Model Class Initialized
INFO - 2016-11-11 21:34:14 --> Model Class Initialized
INFO - 2016-11-11 21:34:14 --> Model Class Initialized
INFO - 2016-11-11 21:34:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 21:34:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 21:34:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 21:34:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 21:34:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 21:34:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 21:34:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 21:34:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 21:34:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 21:34:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 21:34:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 21:34:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 21:34:14 --> Final output sent to browser
DEBUG - 2016-11-11 21:34:14 --> Total execution time: 0.4780
INFO - 2016-11-11 21:34:17 --> Config Class Initialized
INFO - 2016-11-11 21:34:17 --> Hooks Class Initialized
DEBUG - 2016-11-11 21:34:17 --> UTF-8 Support Enabled
INFO - 2016-11-11 21:34:17 --> Utf8 Class Initialized
INFO - 2016-11-11 21:34:17 --> URI Class Initialized
INFO - 2016-11-11 21:34:17 --> Router Class Initialized
INFO - 2016-11-11 21:34:17 --> Output Class Initialized
INFO - 2016-11-11 21:34:17 --> Security Class Initialized
DEBUG - 2016-11-11 21:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 21:34:17 --> Input Class Initialized
INFO - 2016-11-11 21:34:17 --> Language Class Initialized
INFO - 2016-11-11 21:34:17 --> Loader Class Initialized
INFO - 2016-11-11 21:34:18 --> Helper loaded: url_helper
INFO - 2016-11-11 21:34:18 --> Helper loaded: form_helper
INFO - 2016-11-11 21:34:18 --> Database Driver Class Initialized
INFO - 2016-11-11 21:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 21:34:18 --> Controller Class Initialized
INFO - 2016-11-11 21:34:18 --> Model Class Initialized
INFO - 2016-11-11 21:34:18 --> Form Validation Class Initialized
INFO - 2016-11-11 21:34:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-11 21:34:18 --> Final output sent to browser
DEBUG - 2016-11-11 21:34:18 --> Total execution time: 0.2752
INFO - 2016-11-11 21:34:19 --> Config Class Initialized
INFO - 2016-11-11 21:34:19 --> Hooks Class Initialized
DEBUG - 2016-11-11 21:34:19 --> UTF-8 Support Enabled
INFO - 2016-11-11 21:34:19 --> Utf8 Class Initialized
INFO - 2016-11-11 21:34:19 --> URI Class Initialized
DEBUG - 2016-11-11 21:34:19 --> No URI present. Default controller set.
INFO - 2016-11-11 21:34:19 --> Router Class Initialized
INFO - 2016-11-11 21:34:19 --> Output Class Initialized
INFO - 2016-11-11 21:34:19 --> Security Class Initialized
DEBUG - 2016-11-11 21:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 21:34:19 --> Input Class Initialized
INFO - 2016-11-11 21:34:19 --> Language Class Initialized
INFO - 2016-11-11 21:34:19 --> Loader Class Initialized
INFO - 2016-11-11 21:34:19 --> Helper loaded: url_helper
INFO - 2016-11-11 21:34:19 --> Helper loaded: form_helper
INFO - 2016-11-11 21:34:19 --> Database Driver Class Initialized
INFO - 2016-11-11 21:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 21:34:19 --> Controller Class Initialized
INFO - 2016-11-11 21:34:19 --> Model Class Initialized
INFO - 2016-11-11 21:34:20 --> Model Class Initialized
INFO - 2016-11-11 21:34:20 --> Model Class Initialized
INFO - 2016-11-11 21:34:20 --> Model Class Initialized
INFO - 2016-11-11 21:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 21:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 21:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 21:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 21:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 21:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 21:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 21:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 21:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 21:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 21:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 21:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 21:34:20 --> Final output sent to browser
DEBUG - 2016-11-11 21:34:20 --> Total execution time: 0.4836
INFO - 2016-11-11 21:34:26 --> Config Class Initialized
INFO - 2016-11-11 21:34:26 --> Hooks Class Initialized
DEBUG - 2016-11-11 21:34:26 --> UTF-8 Support Enabled
INFO - 2016-11-11 21:34:26 --> Utf8 Class Initialized
INFO - 2016-11-11 21:34:26 --> URI Class Initialized
INFO - 2016-11-11 21:34:26 --> Router Class Initialized
INFO - 2016-11-11 21:34:26 --> Output Class Initialized
INFO - 2016-11-11 21:34:26 --> Security Class Initialized
DEBUG - 2016-11-11 21:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 21:34:26 --> Input Class Initialized
INFO - 2016-11-11 21:34:26 --> Language Class Initialized
INFO - 2016-11-11 21:34:26 --> Loader Class Initialized
INFO - 2016-11-11 21:34:26 --> Helper loaded: url_helper
INFO - 2016-11-11 21:34:26 --> Helper loaded: form_helper
INFO - 2016-11-11 21:34:26 --> Database Driver Class Initialized
INFO - 2016-11-11 21:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 21:34:26 --> Controller Class Initialized
INFO - 2016-11-11 21:34:26 --> Model Class Initialized
INFO - 2016-11-11 21:34:26 --> Model Class Initialized
INFO - 2016-11-11 21:34:26 --> Model Class Initialized
INFO - 2016-11-11 21:34:26 --> Model Class Initialized
DEBUG - 2016-11-11 21:34:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-11 21:34:26 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
ERROR - 2016-11-11 21:34:26 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
INFO - 2016-11-11 21:34:26 --> Config Class Initialized
INFO - 2016-11-11 21:34:26 --> Hooks Class Initialized
DEBUG - 2016-11-11 21:34:26 --> UTF-8 Support Enabled
INFO - 2016-11-11 21:34:26 --> Utf8 Class Initialized
INFO - 2016-11-11 21:34:26 --> URI Class Initialized
DEBUG - 2016-11-11 21:34:26 --> No URI present. Default controller set.
INFO - 2016-11-11 21:34:26 --> Router Class Initialized
INFO - 2016-11-11 21:34:27 --> Output Class Initialized
INFO - 2016-11-11 21:34:27 --> Security Class Initialized
DEBUG - 2016-11-11 21:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 21:34:27 --> Input Class Initialized
INFO - 2016-11-11 21:34:27 --> Language Class Initialized
INFO - 2016-11-11 21:34:27 --> Loader Class Initialized
INFO - 2016-11-11 21:34:27 --> Helper loaded: url_helper
INFO - 2016-11-11 21:34:27 --> Helper loaded: form_helper
INFO - 2016-11-11 21:34:27 --> Database Driver Class Initialized
INFO - 2016-11-11 21:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 21:34:27 --> Controller Class Initialized
INFO - 2016-11-11 21:34:27 --> Model Class Initialized
INFO - 2016-11-11 21:34:27 --> Model Class Initialized
INFO - 2016-11-11 21:34:27 --> Model Class Initialized
INFO - 2016-11-11 21:34:27 --> Model Class Initialized
INFO - 2016-11-11 21:34:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 21:34:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-11 21:34:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 21:34:27 --> Final output sent to browser
DEBUG - 2016-11-11 21:34:27 --> Total execution time: 0.4511
INFO - 2016-11-11 21:34:27 --> Config Class Initialized
INFO - 2016-11-11 21:34:27 --> Hooks Class Initialized
DEBUG - 2016-11-11 21:34:27 --> UTF-8 Support Enabled
INFO - 2016-11-11 21:34:27 --> Utf8 Class Initialized
INFO - 2016-11-11 21:34:27 --> URI Class Initialized
INFO - 2016-11-11 21:34:27 --> Router Class Initialized
INFO - 2016-11-11 21:34:27 --> Output Class Initialized
INFO - 2016-11-11 21:34:27 --> Security Class Initialized
DEBUG - 2016-11-11 21:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 21:34:27 --> Input Class Initialized
INFO - 2016-11-11 21:34:27 --> Language Class Initialized
INFO - 2016-11-11 21:34:27 --> Loader Class Initialized
INFO - 2016-11-11 21:34:27 --> Helper loaded: url_helper
INFO - 2016-11-11 21:34:27 --> Helper loaded: form_helper
INFO - 2016-11-11 21:34:27 --> Database Driver Class Initialized
INFO - 2016-11-11 21:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 21:34:27 --> Controller Class Initialized
INFO - 2016-11-11 21:34:27 --> Model Class Initialized
INFO - 2016-11-11 21:34:27 --> Model Class Initialized
INFO - 2016-11-11 21:34:27 --> Model Class Initialized
INFO - 2016-11-11 21:34:27 --> Model Class Initialized
DEBUG - 2016-11-11 21:34:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-11 21:34:27 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
ERROR - 2016-11-11 21:34:27 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
INFO - 2016-11-11 21:34:27 --> Config Class Initialized
INFO - 2016-11-11 21:34:27 --> Hooks Class Initialized
DEBUG - 2016-11-11 21:34:27 --> UTF-8 Support Enabled
INFO - 2016-11-11 21:34:27 --> Utf8 Class Initialized
INFO - 2016-11-11 21:34:27 --> URI Class Initialized
DEBUG - 2016-11-11 21:34:27 --> No URI present. Default controller set.
INFO - 2016-11-11 21:34:27 --> Router Class Initialized
INFO - 2016-11-11 21:34:27 --> Output Class Initialized
INFO - 2016-11-11 21:34:27 --> Security Class Initialized
DEBUG - 2016-11-11 21:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 21:34:27 --> Input Class Initialized
INFO - 2016-11-11 21:34:27 --> Language Class Initialized
INFO - 2016-11-11 21:34:27 --> Loader Class Initialized
INFO - 2016-11-11 21:34:27 --> Helper loaded: url_helper
INFO - 2016-11-11 21:34:27 --> Helper loaded: form_helper
INFO - 2016-11-11 21:34:27 --> Database Driver Class Initialized
INFO - 2016-11-11 21:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 21:34:27 --> Controller Class Initialized
INFO - 2016-11-11 21:34:27 --> Model Class Initialized
INFO - 2016-11-11 21:34:27 --> Model Class Initialized
INFO - 2016-11-11 21:34:27 --> Model Class Initialized
INFO - 2016-11-11 21:34:27 --> Model Class Initialized
INFO - 2016-11-11 21:34:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 21:34:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-11 21:34:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 21:34:27 --> Final output sent to browser
DEBUG - 2016-11-11 21:34:27 --> Total execution time: 0.3192
INFO - 2016-11-11 22:16:50 --> Config Class Initialized
INFO - 2016-11-11 22:16:50 --> Hooks Class Initialized
DEBUG - 2016-11-11 22:16:50 --> UTF-8 Support Enabled
INFO - 2016-11-11 22:16:50 --> Utf8 Class Initialized
INFO - 2016-11-11 22:16:50 --> URI Class Initialized
DEBUG - 2016-11-11 22:16:50 --> No URI present. Default controller set.
INFO - 2016-11-11 22:16:50 --> Router Class Initialized
INFO - 2016-11-11 22:16:50 --> Output Class Initialized
INFO - 2016-11-11 22:16:51 --> Security Class Initialized
DEBUG - 2016-11-11 22:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 22:16:51 --> Input Class Initialized
INFO - 2016-11-11 22:16:51 --> Language Class Initialized
INFO - 2016-11-11 22:16:51 --> Loader Class Initialized
INFO - 2016-11-11 22:16:51 --> Helper loaded: url_helper
INFO - 2016-11-11 22:16:51 --> Helper loaded: form_helper
INFO - 2016-11-11 22:16:51 --> Database Driver Class Initialized
INFO - 2016-11-11 22:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 22:16:51 --> Controller Class Initialized
INFO - 2016-11-11 22:16:52 --> Model Class Initialized
INFO - 2016-11-11 22:16:52 --> Model Class Initialized
INFO - 2016-11-11 22:16:52 --> Model Class Initialized
INFO - 2016-11-11 22:16:52 --> Model Class Initialized
INFO - 2016-11-11 22:16:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 22:16:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-11 22:16:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 22:16:52 --> Final output sent to browser
DEBUG - 2016-11-11 22:16:52 --> Total execution time: 2.4180
INFO - 2016-11-11 22:17:02 --> Config Class Initialized
INFO - 2016-11-11 22:17:02 --> Hooks Class Initialized
DEBUG - 2016-11-11 22:17:02 --> UTF-8 Support Enabled
INFO - 2016-11-11 22:17:02 --> Utf8 Class Initialized
INFO - 2016-11-11 22:17:02 --> URI Class Initialized
INFO - 2016-11-11 22:17:02 --> Router Class Initialized
INFO - 2016-11-11 22:17:02 --> Output Class Initialized
INFO - 2016-11-11 22:17:02 --> Security Class Initialized
DEBUG - 2016-11-11 22:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 22:17:02 --> Input Class Initialized
INFO - 2016-11-11 22:17:02 --> Language Class Initialized
INFO - 2016-11-11 22:17:02 --> Loader Class Initialized
INFO - 2016-11-11 22:17:02 --> Helper loaded: url_helper
INFO - 2016-11-11 22:17:02 --> Helper loaded: form_helper
INFO - 2016-11-11 22:17:02 --> Database Driver Class Initialized
INFO - 2016-11-11 22:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 22:17:02 --> Controller Class Initialized
INFO - 2016-11-11 22:17:02 --> Model Class Initialized
INFO - 2016-11-11 22:17:02 --> Model Class Initialized
INFO - 2016-11-11 22:17:02 --> Model Class Initialized
INFO - 2016-11-11 22:17:02 --> Model Class Initialized
DEBUG - 2016-11-11 22:17:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-11 22:17:02 --> Model Class Initialized
INFO - 2016-11-11 22:17:02 --> Final output sent to browser
DEBUG - 2016-11-11 22:17:02 --> Total execution time: 0.3713
INFO - 2016-11-11 22:17:02 --> Config Class Initialized
INFO - 2016-11-11 22:17:02 --> Hooks Class Initialized
DEBUG - 2016-11-11 22:17:03 --> UTF-8 Support Enabled
INFO - 2016-11-11 22:17:03 --> Utf8 Class Initialized
INFO - 2016-11-11 22:17:03 --> URI Class Initialized
DEBUG - 2016-11-11 22:17:03 --> No URI present. Default controller set.
INFO - 2016-11-11 22:17:03 --> Router Class Initialized
INFO - 2016-11-11 22:17:03 --> Output Class Initialized
INFO - 2016-11-11 22:17:03 --> Security Class Initialized
DEBUG - 2016-11-11 22:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 22:17:03 --> Input Class Initialized
INFO - 2016-11-11 22:17:03 --> Language Class Initialized
INFO - 2016-11-11 22:17:03 --> Loader Class Initialized
INFO - 2016-11-11 22:17:03 --> Helper loaded: url_helper
INFO - 2016-11-11 22:17:03 --> Helper loaded: form_helper
INFO - 2016-11-11 22:17:03 --> Database Driver Class Initialized
INFO - 2016-11-11 22:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 22:17:03 --> Controller Class Initialized
INFO - 2016-11-11 22:17:03 --> Model Class Initialized
INFO - 2016-11-11 22:17:03 --> Model Class Initialized
INFO - 2016-11-11 22:17:03 --> Model Class Initialized
INFO - 2016-11-11 22:17:03 --> Model Class Initialized
INFO - 2016-11-11 22:17:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 22:17:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 22:17:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 22:17:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 22:17:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 22:17:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 22:17:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 22:17:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 22:17:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 22:17:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 22:17:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 22:17:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 22:17:03 --> Final output sent to browser
DEBUG - 2016-11-11 22:17:03 --> Total execution time: 0.8929
INFO - 2016-11-11 22:59:31 --> Config Class Initialized
INFO - 2016-11-11 22:59:31 --> Hooks Class Initialized
DEBUG - 2016-11-11 22:59:31 --> UTF-8 Support Enabled
INFO - 2016-11-11 22:59:31 --> Utf8 Class Initialized
INFO - 2016-11-11 22:59:31 --> URI Class Initialized
DEBUG - 2016-11-11 22:59:31 --> No URI present. Default controller set.
INFO - 2016-11-11 22:59:31 --> Router Class Initialized
INFO - 2016-11-11 22:59:32 --> Output Class Initialized
INFO - 2016-11-11 22:59:32 --> Security Class Initialized
DEBUG - 2016-11-11 22:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 22:59:32 --> Input Class Initialized
INFO - 2016-11-11 22:59:32 --> Language Class Initialized
INFO - 2016-11-11 22:59:32 --> Loader Class Initialized
INFO - 2016-11-11 22:59:33 --> Helper loaded: url_helper
INFO - 2016-11-11 22:59:33 --> Helper loaded: form_helper
INFO - 2016-11-11 22:59:33 --> Database Driver Class Initialized
INFO - 2016-11-11 22:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 22:59:33 --> Controller Class Initialized
INFO - 2016-11-11 22:59:33 --> Model Class Initialized
INFO - 2016-11-11 22:59:33 --> Model Class Initialized
INFO - 2016-11-11 22:59:34 --> Model Class Initialized
INFO - 2016-11-11 22:59:34 --> Model Class Initialized
INFO - 2016-11-11 22:59:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 22:59:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 22:59:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 22:59:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 22:59:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 22:59:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 22:59:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 22:59:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 22:59:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 22:59:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 22:59:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 22:59:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 22:59:34 --> Final output sent to browser
DEBUG - 2016-11-11 22:59:34 --> Total execution time: 3.8685
INFO - 2016-11-11 23:03:11 --> Config Class Initialized
INFO - 2016-11-11 23:03:12 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:03:12 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:03:12 --> Utf8 Class Initialized
INFO - 2016-11-11 23:03:12 --> URI Class Initialized
DEBUG - 2016-11-11 23:03:12 --> No URI present. Default controller set.
INFO - 2016-11-11 23:03:12 --> Router Class Initialized
INFO - 2016-11-11 23:03:12 --> Output Class Initialized
INFO - 2016-11-11 23:03:12 --> Security Class Initialized
DEBUG - 2016-11-11 23:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:03:12 --> Input Class Initialized
INFO - 2016-11-11 23:03:12 --> Language Class Initialized
INFO - 2016-11-11 23:03:12 --> Loader Class Initialized
INFO - 2016-11-11 23:03:12 --> Helper loaded: url_helper
INFO - 2016-11-11 23:03:12 --> Helper loaded: form_helper
INFO - 2016-11-11 23:03:12 --> Database Driver Class Initialized
INFO - 2016-11-11 23:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:03:12 --> Controller Class Initialized
INFO - 2016-11-11 23:03:12 --> Model Class Initialized
INFO - 2016-11-11 23:03:12 --> Model Class Initialized
INFO - 2016-11-11 23:03:12 --> Model Class Initialized
INFO - 2016-11-11 23:03:12 --> Model Class Initialized
INFO - 2016-11-11 23:03:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:03:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:03:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:03:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:03:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:03:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:03:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:03:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:03:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:03:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:03:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:03:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:03:12 --> Final output sent to browser
DEBUG - 2016-11-11 23:03:12 --> Total execution time: 1.0189
INFO - 2016-11-11 23:04:09 --> Config Class Initialized
INFO - 2016-11-11 23:04:09 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:04:09 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:04:09 --> Utf8 Class Initialized
INFO - 2016-11-11 23:04:09 --> URI Class Initialized
DEBUG - 2016-11-11 23:04:09 --> No URI present. Default controller set.
INFO - 2016-11-11 23:04:09 --> Router Class Initialized
INFO - 2016-11-11 23:04:09 --> Output Class Initialized
INFO - 2016-11-11 23:04:09 --> Security Class Initialized
DEBUG - 2016-11-11 23:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:04:09 --> Input Class Initialized
INFO - 2016-11-11 23:04:09 --> Language Class Initialized
INFO - 2016-11-11 23:04:09 --> Loader Class Initialized
INFO - 2016-11-11 23:04:09 --> Helper loaded: url_helper
INFO - 2016-11-11 23:04:09 --> Helper loaded: form_helper
INFO - 2016-11-11 23:04:09 --> Database Driver Class Initialized
INFO - 2016-11-11 23:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:04:09 --> Controller Class Initialized
INFO - 2016-11-11 23:04:09 --> Model Class Initialized
INFO - 2016-11-11 23:04:09 --> Model Class Initialized
INFO - 2016-11-11 23:04:09 --> Model Class Initialized
INFO - 2016-11-11 23:04:09 --> Model Class Initialized
INFO - 2016-11-11 23:04:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:04:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:04:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:04:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:04:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:04:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:04:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:04:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:04:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:04:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:04:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:04:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:04:09 --> Final output sent to browser
DEBUG - 2016-11-11 23:04:09 --> Total execution time: 0.5071
INFO - 2016-11-11 23:15:14 --> Config Class Initialized
INFO - 2016-11-11 23:15:14 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:15:14 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:15:14 --> Utf8 Class Initialized
INFO - 2016-11-11 23:15:14 --> URI Class Initialized
DEBUG - 2016-11-11 23:15:14 --> No URI present. Default controller set.
INFO - 2016-11-11 23:15:14 --> Router Class Initialized
INFO - 2016-11-11 23:15:15 --> Output Class Initialized
INFO - 2016-11-11 23:15:15 --> Security Class Initialized
DEBUG - 2016-11-11 23:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:15:15 --> Input Class Initialized
INFO - 2016-11-11 23:15:15 --> Language Class Initialized
INFO - 2016-11-11 23:15:15 --> Loader Class Initialized
INFO - 2016-11-11 23:15:15 --> Helper loaded: url_helper
INFO - 2016-11-11 23:15:15 --> Helper loaded: form_helper
INFO - 2016-11-11 23:15:16 --> Database Driver Class Initialized
INFO - 2016-11-11 23:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:15:16 --> Controller Class Initialized
INFO - 2016-11-11 23:15:16 --> Model Class Initialized
INFO - 2016-11-11 23:15:16 --> Model Class Initialized
INFO - 2016-11-11 23:15:16 --> Model Class Initialized
INFO - 2016-11-11 23:15:16 --> Model Class Initialized
INFO - 2016-11-11 23:15:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:15:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:15:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:15:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:15:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:15:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:15:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:15:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:15:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:15:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:15:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:15:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:15:16 --> Final output sent to browser
DEBUG - 2016-11-11 23:15:16 --> Total execution time: 2.8046
INFO - 2016-11-11 23:17:38 --> Config Class Initialized
INFO - 2016-11-11 23:17:38 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:17:38 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:17:38 --> Utf8 Class Initialized
INFO - 2016-11-11 23:17:38 --> URI Class Initialized
DEBUG - 2016-11-11 23:17:38 --> No URI present. Default controller set.
INFO - 2016-11-11 23:17:38 --> Router Class Initialized
INFO - 2016-11-11 23:17:38 --> Output Class Initialized
INFO - 2016-11-11 23:17:38 --> Security Class Initialized
DEBUG - 2016-11-11 23:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:17:39 --> Input Class Initialized
INFO - 2016-11-11 23:17:39 --> Language Class Initialized
INFO - 2016-11-11 23:17:39 --> Loader Class Initialized
INFO - 2016-11-11 23:17:39 --> Helper loaded: url_helper
INFO - 2016-11-11 23:17:39 --> Helper loaded: form_helper
INFO - 2016-11-11 23:17:39 --> Database Driver Class Initialized
INFO - 2016-11-11 23:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:17:39 --> Controller Class Initialized
INFO - 2016-11-11 23:17:39 --> Model Class Initialized
INFO - 2016-11-11 23:17:39 --> Model Class Initialized
INFO - 2016-11-11 23:17:39 --> Model Class Initialized
INFO - 2016-11-11 23:17:39 --> Model Class Initialized
INFO - 2016-11-11 23:17:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:17:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:17:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:17:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:17:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:17:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:17:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:17:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:17:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:17:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:17:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:17:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:17:39 --> Final output sent to browser
DEBUG - 2016-11-11 23:17:39 --> Total execution time: 0.4431
INFO - 2016-11-11 23:18:25 --> Config Class Initialized
INFO - 2016-11-11 23:18:25 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:18:25 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:18:25 --> Utf8 Class Initialized
INFO - 2016-11-11 23:18:25 --> URI Class Initialized
DEBUG - 2016-11-11 23:18:25 --> No URI present. Default controller set.
INFO - 2016-11-11 23:18:25 --> Router Class Initialized
INFO - 2016-11-11 23:18:25 --> Output Class Initialized
INFO - 2016-11-11 23:18:25 --> Security Class Initialized
DEBUG - 2016-11-11 23:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:18:25 --> Input Class Initialized
INFO - 2016-11-11 23:18:25 --> Language Class Initialized
INFO - 2016-11-11 23:18:25 --> Loader Class Initialized
INFO - 2016-11-11 23:18:25 --> Helper loaded: url_helper
INFO - 2016-11-11 23:18:25 --> Helper loaded: form_helper
INFO - 2016-11-11 23:18:25 --> Database Driver Class Initialized
INFO - 2016-11-11 23:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:18:25 --> Controller Class Initialized
INFO - 2016-11-11 23:18:25 --> Model Class Initialized
INFO - 2016-11-11 23:18:25 --> Model Class Initialized
INFO - 2016-11-11 23:18:25 --> Model Class Initialized
INFO - 2016-11-11 23:18:25 --> Model Class Initialized
INFO - 2016-11-11 23:18:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:18:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:18:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:18:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:18:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:18:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:18:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:18:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:18:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:18:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:18:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:18:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:18:25 --> Final output sent to browser
DEBUG - 2016-11-11 23:18:25 --> Total execution time: 0.4398
INFO - 2016-11-11 23:18:43 --> Config Class Initialized
INFO - 2016-11-11 23:18:43 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:18:43 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:18:43 --> Utf8 Class Initialized
INFO - 2016-11-11 23:18:43 --> URI Class Initialized
DEBUG - 2016-11-11 23:18:43 --> No URI present. Default controller set.
INFO - 2016-11-11 23:18:43 --> Router Class Initialized
INFO - 2016-11-11 23:18:43 --> Output Class Initialized
INFO - 2016-11-11 23:18:43 --> Security Class Initialized
DEBUG - 2016-11-11 23:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:18:43 --> Input Class Initialized
INFO - 2016-11-11 23:18:43 --> Language Class Initialized
INFO - 2016-11-11 23:18:43 --> Loader Class Initialized
INFO - 2016-11-11 23:18:43 --> Helper loaded: url_helper
INFO - 2016-11-11 23:18:43 --> Helper loaded: form_helper
INFO - 2016-11-11 23:18:43 --> Database Driver Class Initialized
INFO - 2016-11-11 23:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:18:43 --> Controller Class Initialized
INFO - 2016-11-11 23:18:43 --> Model Class Initialized
INFO - 2016-11-11 23:18:43 --> Model Class Initialized
INFO - 2016-11-11 23:18:43 --> Model Class Initialized
INFO - 2016-11-11 23:18:43 --> Model Class Initialized
INFO - 2016-11-11 23:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:18:43 --> Final output sent to browser
DEBUG - 2016-11-11 23:18:43 --> Total execution time: 0.4375
INFO - 2016-11-11 23:19:04 --> Config Class Initialized
INFO - 2016-11-11 23:19:04 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:19:04 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:19:04 --> Utf8 Class Initialized
INFO - 2016-11-11 23:19:04 --> URI Class Initialized
DEBUG - 2016-11-11 23:19:04 --> No URI present. Default controller set.
INFO - 2016-11-11 23:19:04 --> Router Class Initialized
INFO - 2016-11-11 23:19:04 --> Output Class Initialized
INFO - 2016-11-11 23:19:04 --> Security Class Initialized
DEBUG - 2016-11-11 23:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:19:04 --> Input Class Initialized
INFO - 2016-11-11 23:19:04 --> Language Class Initialized
INFO - 2016-11-11 23:19:04 --> Loader Class Initialized
INFO - 2016-11-11 23:19:04 --> Helper loaded: url_helper
INFO - 2016-11-11 23:19:04 --> Helper loaded: form_helper
INFO - 2016-11-11 23:19:04 --> Database Driver Class Initialized
INFO - 2016-11-11 23:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:19:04 --> Controller Class Initialized
INFO - 2016-11-11 23:19:04 --> Model Class Initialized
INFO - 2016-11-11 23:19:04 --> Model Class Initialized
INFO - 2016-11-11 23:19:04 --> Model Class Initialized
INFO - 2016-11-11 23:19:04 --> Model Class Initialized
INFO - 2016-11-11 23:19:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:19:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:19:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:19:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:19:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:19:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:19:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:19:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:19:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:19:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:19:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:19:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:19:04 --> Final output sent to browser
DEBUG - 2016-11-11 23:19:04 --> Total execution time: 0.4911
INFO - 2016-11-11 23:19:59 --> Config Class Initialized
INFO - 2016-11-11 23:19:59 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:19:59 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:19:59 --> Utf8 Class Initialized
INFO - 2016-11-11 23:19:59 --> URI Class Initialized
DEBUG - 2016-11-11 23:19:59 --> No URI present. Default controller set.
INFO - 2016-11-11 23:19:59 --> Router Class Initialized
INFO - 2016-11-11 23:19:59 --> Output Class Initialized
INFO - 2016-11-11 23:19:59 --> Security Class Initialized
DEBUG - 2016-11-11 23:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:19:59 --> Input Class Initialized
INFO - 2016-11-11 23:19:59 --> Language Class Initialized
INFO - 2016-11-11 23:19:59 --> Loader Class Initialized
INFO - 2016-11-11 23:19:59 --> Helper loaded: url_helper
INFO - 2016-11-11 23:19:59 --> Helper loaded: form_helper
INFO - 2016-11-11 23:19:59 --> Database Driver Class Initialized
INFO - 2016-11-11 23:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:19:59 --> Controller Class Initialized
INFO - 2016-11-11 23:19:59 --> Model Class Initialized
INFO - 2016-11-11 23:19:59 --> Model Class Initialized
INFO - 2016-11-11 23:19:59 --> Model Class Initialized
INFO - 2016-11-11 23:19:59 --> Model Class Initialized
INFO - 2016-11-11 23:19:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:19:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:19:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:19:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:19:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:19:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:19:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:19:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:19:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:19:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:19:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:19:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:19:59 --> Final output sent to browser
DEBUG - 2016-11-11 23:19:59 --> Total execution time: 0.4512
INFO - 2016-11-11 23:21:56 --> Config Class Initialized
INFO - 2016-11-11 23:21:56 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:21:56 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:21:56 --> Utf8 Class Initialized
INFO - 2016-11-11 23:21:56 --> URI Class Initialized
DEBUG - 2016-11-11 23:21:56 --> No URI present. Default controller set.
INFO - 2016-11-11 23:21:56 --> Router Class Initialized
INFO - 2016-11-11 23:21:56 --> Output Class Initialized
INFO - 2016-11-11 23:21:56 --> Security Class Initialized
DEBUG - 2016-11-11 23:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:21:56 --> Input Class Initialized
INFO - 2016-11-11 23:21:56 --> Language Class Initialized
INFO - 2016-11-11 23:21:56 --> Loader Class Initialized
INFO - 2016-11-11 23:21:56 --> Helper loaded: url_helper
INFO - 2016-11-11 23:21:56 --> Helper loaded: form_helper
INFO - 2016-11-11 23:21:56 --> Database Driver Class Initialized
INFO - 2016-11-11 23:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:21:56 --> Controller Class Initialized
INFO - 2016-11-11 23:21:56 --> Model Class Initialized
INFO - 2016-11-11 23:21:56 --> Model Class Initialized
INFO - 2016-11-11 23:21:56 --> Model Class Initialized
INFO - 2016-11-11 23:21:56 --> Model Class Initialized
INFO - 2016-11-11 23:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:21:56 --> Final output sent to browser
DEBUG - 2016-11-11 23:21:56 --> Total execution time: 0.4574
INFO - 2016-11-11 23:29:21 --> Config Class Initialized
INFO - 2016-11-11 23:29:21 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:29:21 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:29:21 --> Utf8 Class Initialized
INFO - 2016-11-11 23:29:21 --> URI Class Initialized
DEBUG - 2016-11-11 23:29:21 --> No URI present. Default controller set.
INFO - 2016-11-11 23:29:21 --> Router Class Initialized
INFO - 2016-11-11 23:29:21 --> Output Class Initialized
INFO - 2016-11-11 23:29:21 --> Security Class Initialized
DEBUG - 2016-11-11 23:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:29:21 --> Input Class Initialized
INFO - 2016-11-11 23:29:21 --> Language Class Initialized
INFO - 2016-11-11 23:29:21 --> Loader Class Initialized
INFO - 2016-11-11 23:29:21 --> Helper loaded: url_helper
INFO - 2016-11-11 23:29:21 --> Helper loaded: form_helper
INFO - 2016-11-11 23:29:21 --> Database Driver Class Initialized
INFO - 2016-11-11 23:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:29:22 --> Controller Class Initialized
INFO - 2016-11-11 23:29:22 --> Model Class Initialized
INFO - 2016-11-11 23:29:22 --> Model Class Initialized
INFO - 2016-11-11 23:29:22 --> Model Class Initialized
INFO - 2016-11-11 23:29:22 --> Model Class Initialized
INFO - 2016-11-11 23:29:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:29:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:29:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:29:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:29:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:29:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:29:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:29:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:29:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:29:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:29:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:29:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:29:22 --> Final output sent to browser
DEBUG - 2016-11-11 23:29:22 --> Total execution time: 0.5061
INFO - 2016-11-11 23:34:37 --> Config Class Initialized
INFO - 2016-11-11 23:34:37 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:34:37 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:34:37 --> Utf8 Class Initialized
INFO - 2016-11-11 23:34:37 --> URI Class Initialized
DEBUG - 2016-11-11 23:34:37 --> No URI present. Default controller set.
INFO - 2016-11-11 23:34:37 --> Router Class Initialized
INFO - 2016-11-11 23:34:37 --> Output Class Initialized
INFO - 2016-11-11 23:34:37 --> Security Class Initialized
DEBUG - 2016-11-11 23:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:34:37 --> Input Class Initialized
INFO - 2016-11-11 23:34:37 --> Language Class Initialized
INFO - 2016-11-11 23:34:37 --> Loader Class Initialized
INFO - 2016-11-11 23:34:37 --> Helper loaded: url_helper
INFO - 2016-11-11 23:34:37 --> Helper loaded: form_helper
INFO - 2016-11-11 23:34:37 --> Database Driver Class Initialized
INFO - 2016-11-11 23:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:34:37 --> Controller Class Initialized
INFO - 2016-11-11 23:34:37 --> Model Class Initialized
INFO - 2016-11-11 23:34:37 --> Model Class Initialized
INFO - 2016-11-11 23:34:37 --> Model Class Initialized
INFO - 2016-11-11 23:34:37 --> Model Class Initialized
INFO - 2016-11-11 23:34:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:34:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:34:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:34:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:34:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:34:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:34:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:34:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:34:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:34:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:34:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:34:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:34:37 --> Final output sent to browser
DEBUG - 2016-11-11 23:34:37 --> Total execution time: 0.4717
INFO - 2016-11-11 23:34:56 --> Config Class Initialized
INFO - 2016-11-11 23:34:56 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:34:56 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:34:56 --> Utf8 Class Initialized
INFO - 2016-11-11 23:34:56 --> URI Class Initialized
DEBUG - 2016-11-11 23:34:56 --> No URI present. Default controller set.
INFO - 2016-11-11 23:34:56 --> Router Class Initialized
INFO - 2016-11-11 23:34:56 --> Output Class Initialized
INFO - 2016-11-11 23:34:56 --> Security Class Initialized
DEBUG - 2016-11-11 23:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:34:56 --> Input Class Initialized
INFO - 2016-11-11 23:34:56 --> Language Class Initialized
INFO - 2016-11-11 23:34:56 --> Loader Class Initialized
INFO - 2016-11-11 23:34:56 --> Helper loaded: url_helper
INFO - 2016-11-11 23:34:56 --> Helper loaded: form_helper
INFO - 2016-11-11 23:34:56 --> Database Driver Class Initialized
INFO - 2016-11-11 23:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:34:57 --> Controller Class Initialized
INFO - 2016-11-11 23:34:57 --> Model Class Initialized
INFO - 2016-11-11 23:34:57 --> Model Class Initialized
INFO - 2016-11-11 23:34:57 --> Model Class Initialized
INFO - 2016-11-11 23:34:57 --> Model Class Initialized
INFO - 2016-11-11 23:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:34:57 --> Final output sent to browser
DEBUG - 2016-11-11 23:34:57 --> Total execution time: 0.4772
INFO - 2016-11-11 23:35:33 --> Config Class Initialized
INFO - 2016-11-11 23:35:33 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:35:33 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:35:33 --> Utf8 Class Initialized
INFO - 2016-11-11 23:35:33 --> URI Class Initialized
DEBUG - 2016-11-11 23:35:33 --> No URI present. Default controller set.
INFO - 2016-11-11 23:35:33 --> Router Class Initialized
INFO - 2016-11-11 23:35:33 --> Output Class Initialized
INFO - 2016-11-11 23:35:33 --> Security Class Initialized
DEBUG - 2016-11-11 23:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:35:33 --> Input Class Initialized
INFO - 2016-11-11 23:35:33 --> Language Class Initialized
INFO - 2016-11-11 23:35:33 --> Loader Class Initialized
INFO - 2016-11-11 23:35:33 --> Helper loaded: url_helper
INFO - 2016-11-11 23:35:33 --> Helper loaded: form_helper
INFO - 2016-11-11 23:35:33 --> Database Driver Class Initialized
INFO - 2016-11-11 23:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:35:33 --> Controller Class Initialized
INFO - 2016-11-11 23:35:33 --> Model Class Initialized
INFO - 2016-11-11 23:35:33 --> Model Class Initialized
INFO - 2016-11-11 23:35:33 --> Model Class Initialized
INFO - 2016-11-11 23:35:33 --> Model Class Initialized
INFO - 2016-11-11 23:35:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:35:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:35:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:35:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:35:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:35:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:35:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:35:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:35:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:35:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:35:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:35:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:35:33 --> Final output sent to browser
DEBUG - 2016-11-11 23:35:33 --> Total execution time: 0.4947
INFO - 2016-11-11 23:35:50 --> Config Class Initialized
INFO - 2016-11-11 23:35:50 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:35:50 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:35:50 --> Utf8 Class Initialized
INFO - 2016-11-11 23:35:50 --> URI Class Initialized
DEBUG - 2016-11-11 23:35:50 --> No URI present. Default controller set.
INFO - 2016-11-11 23:35:50 --> Router Class Initialized
INFO - 2016-11-11 23:35:50 --> Output Class Initialized
INFO - 2016-11-11 23:35:50 --> Security Class Initialized
DEBUG - 2016-11-11 23:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:35:50 --> Input Class Initialized
INFO - 2016-11-11 23:35:50 --> Language Class Initialized
INFO - 2016-11-11 23:35:50 --> Loader Class Initialized
INFO - 2016-11-11 23:35:50 --> Helper loaded: url_helper
INFO - 2016-11-11 23:35:50 --> Helper loaded: form_helper
INFO - 2016-11-11 23:35:50 --> Database Driver Class Initialized
INFO - 2016-11-11 23:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:35:50 --> Controller Class Initialized
INFO - 2016-11-11 23:35:50 --> Model Class Initialized
INFO - 2016-11-11 23:35:50 --> Model Class Initialized
INFO - 2016-11-11 23:35:50 --> Model Class Initialized
INFO - 2016-11-11 23:35:50 --> Model Class Initialized
INFO - 2016-11-11 23:35:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:35:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:35:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:35:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:35:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:35:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:35:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:35:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:35:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:35:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:35:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:35:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:35:51 --> Final output sent to browser
DEBUG - 2016-11-11 23:35:51 --> Total execution time: 0.4903
INFO - 2016-11-11 23:36:00 --> Config Class Initialized
INFO - 2016-11-11 23:36:00 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:36:00 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:36:00 --> Utf8 Class Initialized
INFO - 2016-11-11 23:36:00 --> URI Class Initialized
DEBUG - 2016-11-11 23:36:00 --> No URI present. Default controller set.
INFO - 2016-11-11 23:36:00 --> Router Class Initialized
INFO - 2016-11-11 23:36:00 --> Output Class Initialized
INFO - 2016-11-11 23:36:00 --> Security Class Initialized
DEBUG - 2016-11-11 23:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:36:00 --> Input Class Initialized
INFO - 2016-11-11 23:36:00 --> Language Class Initialized
INFO - 2016-11-11 23:36:00 --> Loader Class Initialized
INFO - 2016-11-11 23:36:00 --> Helper loaded: url_helper
INFO - 2016-11-11 23:36:00 --> Helper loaded: form_helper
INFO - 2016-11-11 23:36:00 --> Database Driver Class Initialized
INFO - 2016-11-11 23:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:36:00 --> Controller Class Initialized
INFO - 2016-11-11 23:36:00 --> Model Class Initialized
INFO - 2016-11-11 23:36:00 --> Model Class Initialized
INFO - 2016-11-11 23:36:01 --> Model Class Initialized
INFO - 2016-11-11 23:36:01 --> Model Class Initialized
INFO - 2016-11-11 23:36:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:36:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:36:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:36:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:36:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:36:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:36:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:36:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:36:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:36:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:36:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:36:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:36:01 --> Final output sent to browser
DEBUG - 2016-11-11 23:36:01 --> Total execution time: 0.4810
INFO - 2016-11-11 23:36:56 --> Config Class Initialized
INFO - 2016-11-11 23:36:56 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:36:56 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:36:56 --> Utf8 Class Initialized
INFO - 2016-11-11 23:36:56 --> URI Class Initialized
DEBUG - 2016-11-11 23:36:56 --> No URI present. Default controller set.
INFO - 2016-11-11 23:36:56 --> Router Class Initialized
INFO - 2016-11-11 23:36:56 --> Output Class Initialized
INFO - 2016-11-11 23:36:56 --> Security Class Initialized
DEBUG - 2016-11-11 23:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:36:56 --> Input Class Initialized
INFO - 2016-11-11 23:36:56 --> Language Class Initialized
INFO - 2016-11-11 23:36:56 --> Loader Class Initialized
INFO - 2016-11-11 23:36:56 --> Helper loaded: url_helper
INFO - 2016-11-11 23:36:56 --> Helper loaded: form_helper
INFO - 2016-11-11 23:36:56 --> Database Driver Class Initialized
INFO - 2016-11-11 23:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:36:56 --> Controller Class Initialized
INFO - 2016-11-11 23:36:56 --> Model Class Initialized
INFO - 2016-11-11 23:36:56 --> Model Class Initialized
INFO - 2016-11-11 23:36:56 --> Model Class Initialized
INFO - 2016-11-11 23:36:56 --> Model Class Initialized
INFO - 2016-11-11 23:36:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:36:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:36:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:36:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:36:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:36:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:36:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:36:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:36:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:36:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:36:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:36:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:36:57 --> Final output sent to browser
DEBUG - 2016-11-11 23:36:57 --> Total execution time: 0.5080
INFO - 2016-11-11 23:38:29 --> Config Class Initialized
INFO - 2016-11-11 23:38:29 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:38:29 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:38:29 --> Utf8 Class Initialized
INFO - 2016-11-11 23:38:29 --> URI Class Initialized
DEBUG - 2016-11-11 23:38:29 --> No URI present. Default controller set.
INFO - 2016-11-11 23:38:29 --> Router Class Initialized
INFO - 2016-11-11 23:38:29 --> Output Class Initialized
INFO - 2016-11-11 23:38:29 --> Security Class Initialized
DEBUG - 2016-11-11 23:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:38:29 --> Input Class Initialized
INFO - 2016-11-11 23:38:29 --> Language Class Initialized
INFO - 2016-11-11 23:38:29 --> Loader Class Initialized
INFO - 2016-11-11 23:38:29 --> Helper loaded: url_helper
INFO - 2016-11-11 23:38:29 --> Helper loaded: form_helper
INFO - 2016-11-11 23:38:29 --> Database Driver Class Initialized
INFO - 2016-11-11 23:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:38:29 --> Controller Class Initialized
INFO - 2016-11-11 23:38:29 --> Model Class Initialized
INFO - 2016-11-11 23:38:29 --> Model Class Initialized
INFO - 2016-11-11 23:38:29 --> Model Class Initialized
INFO - 2016-11-11 23:38:29 --> Model Class Initialized
INFO - 2016-11-11 23:38:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:38:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:38:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:38:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:38:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:38:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:38:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:38:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:38:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:38:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:38:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:38:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:38:29 --> Final output sent to browser
DEBUG - 2016-11-11 23:38:29 --> Total execution time: 0.4628
INFO - 2016-11-11 23:38:44 --> Config Class Initialized
INFO - 2016-11-11 23:38:44 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:38:44 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:38:44 --> Utf8 Class Initialized
INFO - 2016-11-11 23:38:44 --> URI Class Initialized
DEBUG - 2016-11-11 23:38:44 --> No URI present. Default controller set.
INFO - 2016-11-11 23:38:44 --> Router Class Initialized
INFO - 2016-11-11 23:38:44 --> Output Class Initialized
INFO - 2016-11-11 23:38:44 --> Security Class Initialized
DEBUG - 2016-11-11 23:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:38:44 --> Input Class Initialized
INFO - 2016-11-11 23:38:44 --> Language Class Initialized
INFO - 2016-11-11 23:38:44 --> Loader Class Initialized
INFO - 2016-11-11 23:38:44 --> Helper loaded: url_helper
INFO - 2016-11-11 23:38:44 --> Helper loaded: form_helper
INFO - 2016-11-11 23:38:44 --> Database Driver Class Initialized
INFO - 2016-11-11 23:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:38:44 --> Controller Class Initialized
INFO - 2016-11-11 23:38:44 --> Model Class Initialized
INFO - 2016-11-11 23:38:44 --> Model Class Initialized
INFO - 2016-11-11 23:38:44 --> Model Class Initialized
INFO - 2016-11-11 23:38:44 --> Model Class Initialized
INFO - 2016-11-11 23:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:38:44 --> Final output sent to browser
DEBUG - 2016-11-11 23:38:44 --> Total execution time: 0.4736
INFO - 2016-11-11 23:39:03 --> Config Class Initialized
INFO - 2016-11-11 23:39:03 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:39:03 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:39:03 --> Utf8 Class Initialized
INFO - 2016-11-11 23:39:03 --> URI Class Initialized
DEBUG - 2016-11-11 23:39:03 --> No URI present. Default controller set.
INFO - 2016-11-11 23:39:03 --> Router Class Initialized
INFO - 2016-11-11 23:39:03 --> Output Class Initialized
INFO - 2016-11-11 23:39:03 --> Security Class Initialized
DEBUG - 2016-11-11 23:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:39:03 --> Input Class Initialized
INFO - 2016-11-11 23:39:03 --> Language Class Initialized
INFO - 2016-11-11 23:39:03 --> Loader Class Initialized
INFO - 2016-11-11 23:39:03 --> Helper loaded: url_helper
INFO - 2016-11-11 23:39:03 --> Helper loaded: form_helper
INFO - 2016-11-11 23:39:03 --> Database Driver Class Initialized
INFO - 2016-11-11 23:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:39:03 --> Controller Class Initialized
INFO - 2016-11-11 23:39:03 --> Model Class Initialized
INFO - 2016-11-11 23:39:03 --> Model Class Initialized
INFO - 2016-11-11 23:39:03 --> Model Class Initialized
INFO - 2016-11-11 23:39:03 --> Model Class Initialized
INFO - 2016-11-11 23:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:39:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:39:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:39:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:39:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:39:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:39:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:39:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:39:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:39:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:39:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:39:04 --> Final output sent to browser
DEBUG - 2016-11-11 23:39:04 --> Total execution time: 0.4877
INFO - 2016-11-11 23:39:11 --> Config Class Initialized
INFO - 2016-11-11 23:39:11 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:39:11 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:39:11 --> Utf8 Class Initialized
INFO - 2016-11-11 23:39:11 --> URI Class Initialized
DEBUG - 2016-11-11 23:39:11 --> No URI present. Default controller set.
INFO - 2016-11-11 23:39:11 --> Router Class Initialized
INFO - 2016-11-11 23:39:11 --> Output Class Initialized
INFO - 2016-11-11 23:39:11 --> Security Class Initialized
DEBUG - 2016-11-11 23:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:39:11 --> Input Class Initialized
INFO - 2016-11-11 23:39:11 --> Language Class Initialized
INFO - 2016-11-11 23:39:11 --> Loader Class Initialized
INFO - 2016-11-11 23:39:11 --> Helper loaded: url_helper
INFO - 2016-11-11 23:39:11 --> Helper loaded: form_helper
INFO - 2016-11-11 23:39:11 --> Database Driver Class Initialized
INFO - 2016-11-11 23:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:39:11 --> Controller Class Initialized
INFO - 2016-11-11 23:39:11 --> Model Class Initialized
INFO - 2016-11-11 23:39:11 --> Model Class Initialized
INFO - 2016-11-11 23:39:11 --> Model Class Initialized
INFO - 2016-11-11 23:39:11 --> Model Class Initialized
INFO - 2016-11-11 23:39:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:39:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:39:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:39:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:39:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:39:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:39:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:39:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:39:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:39:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:39:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:39:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:39:12 --> Final output sent to browser
DEBUG - 2016-11-11 23:39:12 --> Total execution time: 0.4923
INFO - 2016-11-11 23:40:50 --> Config Class Initialized
INFO - 2016-11-11 23:40:50 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:40:50 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:40:50 --> Utf8 Class Initialized
INFO - 2016-11-11 23:40:50 --> URI Class Initialized
DEBUG - 2016-11-11 23:40:50 --> No URI present. Default controller set.
INFO - 2016-11-11 23:40:50 --> Router Class Initialized
INFO - 2016-11-11 23:40:50 --> Output Class Initialized
INFO - 2016-11-11 23:40:50 --> Security Class Initialized
DEBUG - 2016-11-11 23:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:40:50 --> Input Class Initialized
INFO - 2016-11-11 23:40:50 --> Language Class Initialized
INFO - 2016-11-11 23:40:50 --> Loader Class Initialized
INFO - 2016-11-11 23:40:50 --> Helper loaded: url_helper
INFO - 2016-11-11 23:40:50 --> Helper loaded: form_helper
INFO - 2016-11-11 23:40:50 --> Database Driver Class Initialized
INFO - 2016-11-11 23:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:40:50 --> Controller Class Initialized
INFO - 2016-11-11 23:40:50 --> Model Class Initialized
INFO - 2016-11-11 23:40:50 --> Model Class Initialized
INFO - 2016-11-11 23:40:50 --> Model Class Initialized
INFO - 2016-11-11 23:40:50 --> Model Class Initialized
INFO - 2016-11-11 23:40:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:40:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:40:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:40:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:40:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:40:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:40:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:40:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:40:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:40:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:40:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:40:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:40:50 --> Final output sent to browser
DEBUG - 2016-11-11 23:40:50 --> Total execution time: 0.4726
INFO - 2016-11-11 23:41:31 --> Config Class Initialized
INFO - 2016-11-11 23:41:31 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:41:31 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:41:31 --> Utf8 Class Initialized
INFO - 2016-11-11 23:41:31 --> URI Class Initialized
DEBUG - 2016-11-11 23:41:31 --> No URI present. Default controller set.
INFO - 2016-11-11 23:41:31 --> Router Class Initialized
INFO - 2016-11-11 23:41:31 --> Output Class Initialized
INFO - 2016-11-11 23:41:31 --> Security Class Initialized
DEBUG - 2016-11-11 23:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:41:31 --> Input Class Initialized
INFO - 2016-11-11 23:41:31 --> Language Class Initialized
INFO - 2016-11-11 23:41:31 --> Loader Class Initialized
INFO - 2016-11-11 23:41:31 --> Helper loaded: url_helper
INFO - 2016-11-11 23:41:31 --> Helper loaded: form_helper
INFO - 2016-11-11 23:41:31 --> Database Driver Class Initialized
INFO - 2016-11-11 23:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:41:31 --> Controller Class Initialized
INFO - 2016-11-11 23:41:31 --> Model Class Initialized
INFO - 2016-11-11 23:41:31 --> Model Class Initialized
INFO - 2016-11-11 23:41:31 --> Model Class Initialized
INFO - 2016-11-11 23:41:31 --> Model Class Initialized
INFO - 2016-11-11 23:41:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:41:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:41:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:41:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:41:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:41:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:41:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:41:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:41:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:41:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:41:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:41:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:41:31 --> Final output sent to browser
DEBUG - 2016-11-11 23:41:31 --> Total execution time: 0.4846
INFO - 2016-11-11 23:42:42 --> Config Class Initialized
INFO - 2016-11-11 23:42:42 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:42:42 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:42:42 --> Utf8 Class Initialized
INFO - 2016-11-11 23:42:42 --> URI Class Initialized
DEBUG - 2016-11-11 23:42:42 --> No URI present. Default controller set.
INFO - 2016-11-11 23:42:42 --> Router Class Initialized
INFO - 2016-11-11 23:42:42 --> Output Class Initialized
INFO - 2016-11-11 23:42:42 --> Security Class Initialized
DEBUG - 2016-11-11 23:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:42:43 --> Input Class Initialized
INFO - 2016-11-11 23:42:43 --> Language Class Initialized
INFO - 2016-11-11 23:42:43 --> Loader Class Initialized
INFO - 2016-11-11 23:42:43 --> Helper loaded: url_helper
INFO - 2016-11-11 23:42:43 --> Helper loaded: form_helper
INFO - 2016-11-11 23:42:43 --> Database Driver Class Initialized
INFO - 2016-11-11 23:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:42:43 --> Controller Class Initialized
INFO - 2016-11-11 23:42:43 --> Model Class Initialized
INFO - 2016-11-11 23:42:43 --> Model Class Initialized
INFO - 2016-11-11 23:42:43 --> Model Class Initialized
INFO - 2016-11-11 23:42:43 --> Model Class Initialized
INFO - 2016-11-11 23:42:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:42:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:42:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:42:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:42:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:42:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:42:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:42:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:42:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:42:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:42:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:42:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:42:43 --> Final output sent to browser
DEBUG - 2016-11-11 23:42:43 --> Total execution time: 0.4945
INFO - 2016-11-11 23:43:54 --> Config Class Initialized
INFO - 2016-11-11 23:43:54 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:43:54 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:43:55 --> Utf8 Class Initialized
INFO - 2016-11-11 23:43:55 --> URI Class Initialized
DEBUG - 2016-11-11 23:43:55 --> No URI present. Default controller set.
INFO - 2016-11-11 23:43:55 --> Router Class Initialized
INFO - 2016-11-11 23:43:55 --> Output Class Initialized
INFO - 2016-11-11 23:43:55 --> Security Class Initialized
DEBUG - 2016-11-11 23:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:43:55 --> Input Class Initialized
INFO - 2016-11-11 23:43:55 --> Language Class Initialized
INFO - 2016-11-11 23:43:55 --> Loader Class Initialized
INFO - 2016-11-11 23:43:55 --> Helper loaded: url_helper
INFO - 2016-11-11 23:43:55 --> Helper loaded: form_helper
INFO - 2016-11-11 23:43:55 --> Database Driver Class Initialized
INFO - 2016-11-11 23:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:43:55 --> Controller Class Initialized
INFO - 2016-11-11 23:43:55 --> Model Class Initialized
INFO - 2016-11-11 23:43:55 --> Model Class Initialized
INFO - 2016-11-11 23:43:55 --> Model Class Initialized
INFO - 2016-11-11 23:43:55 --> Model Class Initialized
INFO - 2016-11-11 23:43:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:43:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:43:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:43:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:43:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:43:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:43:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:43:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:43:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:43:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:43:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:43:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:43:55 --> Final output sent to browser
DEBUG - 2016-11-11 23:43:55 --> Total execution time: 0.4667
INFO - 2016-11-11 23:44:18 --> Config Class Initialized
INFO - 2016-11-11 23:44:18 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:44:18 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:44:18 --> Utf8 Class Initialized
INFO - 2016-11-11 23:44:18 --> URI Class Initialized
DEBUG - 2016-11-11 23:44:18 --> No URI present. Default controller set.
INFO - 2016-11-11 23:44:18 --> Router Class Initialized
INFO - 2016-11-11 23:44:18 --> Output Class Initialized
INFO - 2016-11-11 23:44:18 --> Security Class Initialized
DEBUG - 2016-11-11 23:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:44:18 --> Input Class Initialized
INFO - 2016-11-11 23:44:18 --> Language Class Initialized
INFO - 2016-11-11 23:44:18 --> Loader Class Initialized
INFO - 2016-11-11 23:44:18 --> Helper loaded: url_helper
INFO - 2016-11-11 23:44:18 --> Helper loaded: form_helper
INFO - 2016-11-11 23:44:18 --> Database Driver Class Initialized
INFO - 2016-11-11 23:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:44:18 --> Controller Class Initialized
INFO - 2016-11-11 23:44:18 --> Model Class Initialized
INFO - 2016-11-11 23:44:18 --> Model Class Initialized
INFO - 2016-11-11 23:44:18 --> Model Class Initialized
INFO - 2016-11-11 23:44:18 --> Model Class Initialized
INFO - 2016-11-11 23:44:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:44:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:44:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:44:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:44:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:44:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:44:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:44:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:44:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:44:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:44:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:44:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:44:18 --> Final output sent to browser
DEBUG - 2016-11-11 23:44:18 --> Total execution time: 0.4981
INFO - 2016-11-11 23:44:37 --> Config Class Initialized
INFO - 2016-11-11 23:44:37 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:44:37 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:44:37 --> Utf8 Class Initialized
INFO - 2016-11-11 23:44:37 --> URI Class Initialized
DEBUG - 2016-11-11 23:44:37 --> No URI present. Default controller set.
INFO - 2016-11-11 23:44:37 --> Router Class Initialized
INFO - 2016-11-11 23:44:37 --> Output Class Initialized
INFO - 2016-11-11 23:44:38 --> Security Class Initialized
DEBUG - 2016-11-11 23:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:44:38 --> Input Class Initialized
INFO - 2016-11-11 23:44:38 --> Language Class Initialized
INFO - 2016-11-11 23:44:38 --> Loader Class Initialized
INFO - 2016-11-11 23:44:38 --> Helper loaded: url_helper
INFO - 2016-11-11 23:44:38 --> Helper loaded: form_helper
INFO - 2016-11-11 23:44:38 --> Database Driver Class Initialized
INFO - 2016-11-11 23:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:44:38 --> Controller Class Initialized
INFO - 2016-11-11 23:44:38 --> Model Class Initialized
INFO - 2016-11-11 23:44:38 --> Model Class Initialized
INFO - 2016-11-11 23:44:38 --> Model Class Initialized
INFO - 2016-11-11 23:44:38 --> Model Class Initialized
INFO - 2016-11-11 23:44:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:44:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:44:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:44:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:44:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:44:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:44:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:44:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:44:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:44:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:44:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:44:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:44:38 --> Final output sent to browser
DEBUG - 2016-11-11 23:44:38 --> Total execution time: 0.5418
INFO - 2016-11-11 23:44:54 --> Config Class Initialized
INFO - 2016-11-11 23:44:54 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:44:54 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:44:54 --> Utf8 Class Initialized
INFO - 2016-11-11 23:44:54 --> URI Class Initialized
DEBUG - 2016-11-11 23:44:54 --> No URI present. Default controller set.
INFO - 2016-11-11 23:44:54 --> Router Class Initialized
INFO - 2016-11-11 23:44:54 --> Output Class Initialized
INFO - 2016-11-11 23:44:54 --> Security Class Initialized
DEBUG - 2016-11-11 23:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:44:54 --> Input Class Initialized
INFO - 2016-11-11 23:44:54 --> Language Class Initialized
INFO - 2016-11-11 23:44:54 --> Loader Class Initialized
INFO - 2016-11-11 23:44:54 --> Helper loaded: url_helper
INFO - 2016-11-11 23:44:54 --> Helper loaded: form_helper
INFO - 2016-11-11 23:44:54 --> Database Driver Class Initialized
INFO - 2016-11-11 23:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:44:54 --> Controller Class Initialized
INFO - 2016-11-11 23:44:54 --> Model Class Initialized
INFO - 2016-11-11 23:44:54 --> Model Class Initialized
INFO - 2016-11-11 23:44:54 --> Model Class Initialized
INFO - 2016-11-11 23:44:54 --> Model Class Initialized
INFO - 2016-11-11 23:44:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:44:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:44:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:44:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:44:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:44:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:44:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:44:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:44:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:44:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:44:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:44:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:44:55 --> Final output sent to browser
DEBUG - 2016-11-11 23:44:55 --> Total execution time: 0.4817
INFO - 2016-11-11 23:44:56 --> Config Class Initialized
INFO - 2016-11-11 23:44:56 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:44:56 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:44:56 --> Utf8 Class Initialized
INFO - 2016-11-11 23:44:56 --> URI Class Initialized
DEBUG - 2016-11-11 23:44:56 --> No URI present. Default controller set.
INFO - 2016-11-11 23:44:56 --> Router Class Initialized
INFO - 2016-11-11 23:44:56 --> Output Class Initialized
INFO - 2016-11-11 23:44:56 --> Security Class Initialized
DEBUG - 2016-11-11 23:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:44:56 --> Input Class Initialized
INFO - 2016-11-11 23:44:56 --> Language Class Initialized
INFO - 2016-11-11 23:44:56 --> Loader Class Initialized
INFO - 2016-11-11 23:44:56 --> Helper loaded: url_helper
INFO - 2016-11-11 23:44:56 --> Helper loaded: form_helper
INFO - 2016-11-11 23:44:56 --> Database Driver Class Initialized
INFO - 2016-11-11 23:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:44:56 --> Controller Class Initialized
INFO - 2016-11-11 23:44:56 --> Model Class Initialized
INFO - 2016-11-11 23:44:56 --> Model Class Initialized
INFO - 2016-11-11 23:44:56 --> Model Class Initialized
INFO - 2016-11-11 23:44:56 --> Model Class Initialized
INFO - 2016-11-11 23:44:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:44:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:44:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:44:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:44:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:44:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:44:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:44:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:44:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:44:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:44:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:44:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:44:56 --> Final output sent to browser
DEBUG - 2016-11-11 23:44:56 --> Total execution time: 0.4972
INFO - 2016-11-11 23:46:15 --> Config Class Initialized
INFO - 2016-11-11 23:46:15 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:46:15 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:46:15 --> Utf8 Class Initialized
INFO - 2016-11-11 23:46:15 --> URI Class Initialized
DEBUG - 2016-11-11 23:46:15 --> No URI present. Default controller set.
INFO - 2016-11-11 23:46:15 --> Router Class Initialized
INFO - 2016-11-11 23:46:15 --> Output Class Initialized
INFO - 2016-11-11 23:46:15 --> Security Class Initialized
DEBUG - 2016-11-11 23:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:46:16 --> Input Class Initialized
INFO - 2016-11-11 23:46:16 --> Language Class Initialized
INFO - 2016-11-11 23:46:16 --> Loader Class Initialized
INFO - 2016-11-11 23:46:16 --> Helper loaded: url_helper
INFO - 2016-11-11 23:46:16 --> Helper loaded: form_helper
INFO - 2016-11-11 23:46:16 --> Database Driver Class Initialized
INFO - 2016-11-11 23:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:46:16 --> Controller Class Initialized
INFO - 2016-11-11 23:46:16 --> Model Class Initialized
INFO - 2016-11-11 23:46:16 --> Model Class Initialized
INFO - 2016-11-11 23:46:16 --> Model Class Initialized
INFO - 2016-11-11 23:46:16 --> Model Class Initialized
INFO - 2016-11-11 23:46:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:46:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:46:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:46:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:46:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:46:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-11 23:46:16 --> Severity: Notice --> Undefined property: stdClass::$statuaName C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 26
INFO - 2016-11-11 23:46:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:46:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:46:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:46:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:46:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:46:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:46:16 --> Final output sent to browser
DEBUG - 2016-11-11 23:46:16 --> Total execution time: 0.6461
INFO - 2016-11-11 23:46:37 --> Config Class Initialized
INFO - 2016-11-11 23:46:37 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:46:37 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:46:37 --> Utf8 Class Initialized
INFO - 2016-11-11 23:46:37 --> URI Class Initialized
DEBUG - 2016-11-11 23:46:37 --> No URI present. Default controller set.
INFO - 2016-11-11 23:46:37 --> Router Class Initialized
INFO - 2016-11-11 23:46:37 --> Output Class Initialized
INFO - 2016-11-11 23:46:37 --> Security Class Initialized
DEBUG - 2016-11-11 23:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:46:37 --> Input Class Initialized
INFO - 2016-11-11 23:46:37 --> Language Class Initialized
INFO - 2016-11-11 23:46:37 --> Loader Class Initialized
INFO - 2016-11-11 23:46:37 --> Helper loaded: url_helper
INFO - 2016-11-11 23:46:37 --> Helper loaded: form_helper
INFO - 2016-11-11 23:46:38 --> Database Driver Class Initialized
INFO - 2016-11-11 23:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:46:38 --> Controller Class Initialized
INFO - 2016-11-11 23:46:38 --> Model Class Initialized
INFO - 2016-11-11 23:46:38 --> Model Class Initialized
INFO - 2016-11-11 23:46:38 --> Model Class Initialized
INFO - 2016-11-11 23:46:38 --> Model Class Initialized
INFO - 2016-11-11 23:46:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:46:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:46:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:46:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:46:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:46:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:46:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:46:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:46:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:46:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:46:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:46:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:46:38 --> Final output sent to browser
DEBUG - 2016-11-11 23:46:38 --> Total execution time: 0.4947
INFO - 2016-11-11 23:46:58 --> Config Class Initialized
INFO - 2016-11-11 23:46:58 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:46:58 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:46:58 --> Utf8 Class Initialized
INFO - 2016-11-11 23:46:58 --> URI Class Initialized
DEBUG - 2016-11-11 23:46:59 --> No URI present. Default controller set.
INFO - 2016-11-11 23:46:59 --> Router Class Initialized
INFO - 2016-11-11 23:46:59 --> Output Class Initialized
INFO - 2016-11-11 23:46:59 --> Security Class Initialized
DEBUG - 2016-11-11 23:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:46:59 --> Input Class Initialized
INFO - 2016-11-11 23:46:59 --> Language Class Initialized
INFO - 2016-11-11 23:46:59 --> Loader Class Initialized
INFO - 2016-11-11 23:46:59 --> Helper loaded: url_helper
INFO - 2016-11-11 23:46:59 --> Helper loaded: form_helper
INFO - 2016-11-11 23:46:59 --> Database Driver Class Initialized
INFO - 2016-11-11 23:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:46:59 --> Controller Class Initialized
INFO - 2016-11-11 23:46:59 --> Model Class Initialized
INFO - 2016-11-11 23:46:59 --> Model Class Initialized
INFO - 2016-11-11 23:46:59 --> Model Class Initialized
INFO - 2016-11-11 23:46:59 --> Model Class Initialized
INFO - 2016-11-11 23:46:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:46:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:46:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:46:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:46:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:46:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:46:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:46:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:46:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:46:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:46:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:46:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:46:59 --> Final output sent to browser
DEBUG - 2016-11-11 23:46:59 --> Total execution time: 0.5491
INFO - 2016-11-11 23:47:29 --> Config Class Initialized
INFO - 2016-11-11 23:47:29 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:47:29 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:47:29 --> Utf8 Class Initialized
INFO - 2016-11-11 23:47:29 --> URI Class Initialized
DEBUG - 2016-11-11 23:47:29 --> No URI present. Default controller set.
INFO - 2016-11-11 23:47:29 --> Router Class Initialized
INFO - 2016-11-11 23:47:29 --> Output Class Initialized
INFO - 2016-11-11 23:47:29 --> Security Class Initialized
DEBUG - 2016-11-11 23:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:47:29 --> Input Class Initialized
INFO - 2016-11-11 23:47:29 --> Language Class Initialized
INFO - 2016-11-11 23:47:29 --> Loader Class Initialized
INFO - 2016-11-11 23:47:29 --> Helper loaded: url_helper
INFO - 2016-11-11 23:47:29 --> Helper loaded: form_helper
INFO - 2016-11-11 23:47:29 --> Database Driver Class Initialized
INFO - 2016-11-11 23:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:47:29 --> Controller Class Initialized
INFO - 2016-11-11 23:47:29 --> Model Class Initialized
INFO - 2016-11-11 23:47:29 --> Model Class Initialized
INFO - 2016-11-11 23:47:29 --> Model Class Initialized
INFO - 2016-11-11 23:47:29 --> Model Class Initialized
INFO - 2016-11-11 23:47:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:47:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:47:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:47:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:47:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:47:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:47:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:47:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:47:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:47:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:47:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:47:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:47:29 --> Final output sent to browser
DEBUG - 2016-11-11 23:47:29 --> Total execution time: 0.5033
INFO - 2016-11-11 23:48:07 --> Config Class Initialized
INFO - 2016-11-11 23:48:07 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:48:07 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:48:07 --> Utf8 Class Initialized
INFO - 2016-11-11 23:48:07 --> URI Class Initialized
DEBUG - 2016-11-11 23:48:07 --> No URI present. Default controller set.
INFO - 2016-11-11 23:48:07 --> Router Class Initialized
INFO - 2016-11-11 23:48:07 --> Output Class Initialized
INFO - 2016-11-11 23:48:07 --> Security Class Initialized
DEBUG - 2016-11-11 23:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:48:07 --> Input Class Initialized
INFO - 2016-11-11 23:48:07 --> Language Class Initialized
INFO - 2016-11-11 23:48:07 --> Loader Class Initialized
INFO - 2016-11-11 23:48:07 --> Helper loaded: url_helper
INFO - 2016-11-11 23:48:07 --> Helper loaded: form_helper
INFO - 2016-11-11 23:48:07 --> Database Driver Class Initialized
INFO - 2016-11-11 23:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:48:07 --> Controller Class Initialized
INFO - 2016-11-11 23:48:07 --> Model Class Initialized
INFO - 2016-11-11 23:48:07 --> Model Class Initialized
INFO - 2016-11-11 23:48:07 --> Model Class Initialized
INFO - 2016-11-11 23:48:07 --> Model Class Initialized
INFO - 2016-11-11 23:48:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:48:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:48:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:48:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:48:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:48:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:48:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:48:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:48:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:48:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:48:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:48:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:48:08 --> Final output sent to browser
DEBUG - 2016-11-11 23:48:08 --> Total execution time: 0.5164
INFO - 2016-11-11 23:48:27 --> Config Class Initialized
INFO - 2016-11-11 23:48:27 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:48:27 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:48:27 --> Utf8 Class Initialized
INFO - 2016-11-11 23:48:27 --> URI Class Initialized
DEBUG - 2016-11-11 23:48:27 --> No URI present. Default controller set.
INFO - 2016-11-11 23:48:27 --> Router Class Initialized
INFO - 2016-11-11 23:48:27 --> Output Class Initialized
INFO - 2016-11-11 23:48:27 --> Security Class Initialized
DEBUG - 2016-11-11 23:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:48:27 --> Input Class Initialized
INFO - 2016-11-11 23:48:27 --> Language Class Initialized
INFO - 2016-11-11 23:48:27 --> Loader Class Initialized
INFO - 2016-11-11 23:48:27 --> Helper loaded: url_helper
INFO - 2016-11-11 23:48:27 --> Helper loaded: form_helper
INFO - 2016-11-11 23:48:27 --> Database Driver Class Initialized
INFO - 2016-11-11 23:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:48:27 --> Controller Class Initialized
INFO - 2016-11-11 23:48:27 --> Model Class Initialized
INFO - 2016-11-11 23:48:27 --> Model Class Initialized
INFO - 2016-11-11 23:48:27 --> Model Class Initialized
INFO - 2016-11-11 23:48:27 --> Model Class Initialized
INFO - 2016-11-11 23:48:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:48:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:48:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:48:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:48:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:48:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:48:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:48:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:48:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:48:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:48:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:48:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:48:27 --> Final output sent to browser
DEBUG - 2016-11-11 23:48:27 --> Total execution time: 0.5361
INFO - 2016-11-11 23:50:02 --> Config Class Initialized
INFO - 2016-11-11 23:50:02 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:50:02 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:50:02 --> Utf8 Class Initialized
INFO - 2016-11-11 23:50:02 --> URI Class Initialized
DEBUG - 2016-11-11 23:50:02 --> No URI present. Default controller set.
INFO - 2016-11-11 23:50:02 --> Router Class Initialized
INFO - 2016-11-11 23:50:02 --> Output Class Initialized
INFO - 2016-11-11 23:50:02 --> Security Class Initialized
DEBUG - 2016-11-11 23:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:50:02 --> Input Class Initialized
INFO - 2016-11-11 23:50:02 --> Language Class Initialized
INFO - 2016-11-11 23:50:02 --> Loader Class Initialized
INFO - 2016-11-11 23:50:02 --> Helper loaded: url_helper
INFO - 2016-11-11 23:50:02 --> Helper loaded: form_helper
INFO - 2016-11-11 23:50:02 --> Database Driver Class Initialized
INFO - 2016-11-11 23:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:50:02 --> Controller Class Initialized
INFO - 2016-11-11 23:50:02 --> Model Class Initialized
INFO - 2016-11-11 23:50:02 --> Model Class Initialized
INFO - 2016-11-11 23:50:02 --> Model Class Initialized
INFO - 2016-11-11 23:50:02 --> Model Class Initialized
INFO - 2016-11-11 23:50:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:50:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:50:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:50:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:50:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:50:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-11 23:50:02 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 30
ERROR - 2016-11-11 23:50:02 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 30
ERROR - 2016-11-11 23:50:02 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 30
ERROR - 2016-11-11 23:50:02 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 30
ERROR - 2016-11-11 23:50:02 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 30
INFO - 2016-11-11 23:50:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:50:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:50:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:50:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:50:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:50:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:50:02 --> Final output sent to browser
DEBUG - 2016-11-11 23:50:02 --> Total execution time: 0.6368
INFO - 2016-11-11 23:50:36 --> Config Class Initialized
INFO - 2016-11-11 23:50:36 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:50:36 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:50:36 --> Utf8 Class Initialized
INFO - 2016-11-11 23:50:36 --> URI Class Initialized
DEBUG - 2016-11-11 23:50:36 --> No URI present. Default controller set.
INFO - 2016-11-11 23:50:36 --> Router Class Initialized
INFO - 2016-11-11 23:50:36 --> Output Class Initialized
INFO - 2016-11-11 23:50:36 --> Security Class Initialized
DEBUG - 2016-11-11 23:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:50:36 --> Input Class Initialized
INFO - 2016-11-11 23:50:36 --> Language Class Initialized
INFO - 2016-11-11 23:50:36 --> Loader Class Initialized
INFO - 2016-11-11 23:50:36 --> Helper loaded: url_helper
INFO - 2016-11-11 23:50:36 --> Helper loaded: form_helper
INFO - 2016-11-11 23:50:36 --> Database Driver Class Initialized
INFO - 2016-11-11 23:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:50:36 --> Controller Class Initialized
INFO - 2016-11-11 23:50:36 --> Model Class Initialized
INFO - 2016-11-11 23:50:36 --> Model Class Initialized
INFO - 2016-11-11 23:50:36 --> Model Class Initialized
INFO - 2016-11-11 23:50:36 --> Model Class Initialized
INFO - 2016-11-11 23:50:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:50:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:50:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:50:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:50:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:50:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:50:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:50:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:50:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:50:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:50:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:50:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:50:36 --> Final output sent to browser
DEBUG - 2016-11-11 23:50:36 --> Total execution time: 0.5399
INFO - 2016-11-11 23:50:43 --> Config Class Initialized
INFO - 2016-11-11 23:50:43 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:50:43 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:50:43 --> Utf8 Class Initialized
INFO - 2016-11-11 23:50:43 --> URI Class Initialized
DEBUG - 2016-11-11 23:50:43 --> No URI present. Default controller set.
INFO - 2016-11-11 23:50:43 --> Router Class Initialized
INFO - 2016-11-11 23:50:43 --> Output Class Initialized
INFO - 2016-11-11 23:50:43 --> Security Class Initialized
DEBUG - 2016-11-11 23:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:50:44 --> Input Class Initialized
INFO - 2016-11-11 23:50:44 --> Language Class Initialized
INFO - 2016-11-11 23:50:44 --> Loader Class Initialized
INFO - 2016-11-11 23:50:44 --> Helper loaded: url_helper
INFO - 2016-11-11 23:50:44 --> Helper loaded: form_helper
INFO - 2016-11-11 23:50:44 --> Database Driver Class Initialized
INFO - 2016-11-11 23:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:50:44 --> Controller Class Initialized
INFO - 2016-11-11 23:50:44 --> Model Class Initialized
INFO - 2016-11-11 23:50:44 --> Model Class Initialized
INFO - 2016-11-11 23:50:44 --> Model Class Initialized
INFO - 2016-11-11 23:50:44 --> Model Class Initialized
INFO - 2016-11-11 23:50:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:50:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:50:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:50:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:50:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:50:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:50:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:50:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:50:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:50:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:50:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:50:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:50:44 --> Final output sent to browser
DEBUG - 2016-11-11 23:50:44 --> Total execution time: 0.5534
INFO - 2016-11-11 23:52:10 --> Config Class Initialized
INFO - 2016-11-11 23:52:10 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:52:10 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:52:10 --> Utf8 Class Initialized
INFO - 2016-11-11 23:52:10 --> URI Class Initialized
DEBUG - 2016-11-11 23:52:10 --> No URI present. Default controller set.
INFO - 2016-11-11 23:52:10 --> Router Class Initialized
INFO - 2016-11-11 23:52:10 --> Output Class Initialized
INFO - 2016-11-11 23:52:10 --> Security Class Initialized
DEBUG - 2016-11-11 23:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:52:10 --> Input Class Initialized
INFO - 2016-11-11 23:52:10 --> Language Class Initialized
INFO - 2016-11-11 23:52:10 --> Loader Class Initialized
INFO - 2016-11-11 23:52:10 --> Helper loaded: url_helper
INFO - 2016-11-11 23:52:10 --> Helper loaded: form_helper
INFO - 2016-11-11 23:52:10 --> Database Driver Class Initialized
INFO - 2016-11-11 23:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:52:10 --> Controller Class Initialized
INFO - 2016-11-11 23:52:10 --> Model Class Initialized
INFO - 2016-11-11 23:52:10 --> Model Class Initialized
INFO - 2016-11-11 23:52:10 --> Model Class Initialized
INFO - 2016-11-11 23:52:10 --> Model Class Initialized
INFO - 2016-11-11 23:52:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:52:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:52:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:52:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:52:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:52:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:52:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:52:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:52:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:52:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:52:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:52:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:52:10 --> Final output sent to browser
DEBUG - 2016-11-11 23:52:11 --> Total execution time: 0.5551
INFO - 2016-11-11 23:52:32 --> Config Class Initialized
INFO - 2016-11-11 23:52:32 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:52:32 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:52:32 --> Utf8 Class Initialized
INFO - 2016-11-11 23:52:32 --> URI Class Initialized
DEBUG - 2016-11-11 23:52:32 --> No URI present. Default controller set.
INFO - 2016-11-11 23:52:32 --> Router Class Initialized
INFO - 2016-11-11 23:52:32 --> Output Class Initialized
INFO - 2016-11-11 23:52:32 --> Security Class Initialized
DEBUG - 2016-11-11 23:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:52:32 --> Input Class Initialized
INFO - 2016-11-11 23:52:32 --> Language Class Initialized
INFO - 2016-11-11 23:52:32 --> Loader Class Initialized
INFO - 2016-11-11 23:52:32 --> Helper loaded: url_helper
INFO - 2016-11-11 23:52:32 --> Helper loaded: form_helper
INFO - 2016-11-11 23:52:32 --> Database Driver Class Initialized
INFO - 2016-11-11 23:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:52:32 --> Controller Class Initialized
INFO - 2016-11-11 23:52:32 --> Model Class Initialized
INFO - 2016-11-11 23:52:32 --> Model Class Initialized
INFO - 2016-11-11 23:52:32 --> Model Class Initialized
INFO - 2016-11-11 23:52:32 --> Model Class Initialized
INFO - 2016-11-11 23:52:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:52:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:52:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:52:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:52:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:52:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:52:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:52:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:52:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:52:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:52:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:52:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:52:32 --> Final output sent to browser
DEBUG - 2016-11-11 23:52:32 --> Total execution time: 0.5368
INFO - 2016-11-11 23:54:35 --> Config Class Initialized
INFO - 2016-11-11 23:54:35 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:54:35 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:54:35 --> Utf8 Class Initialized
INFO - 2016-11-11 23:54:35 --> URI Class Initialized
DEBUG - 2016-11-11 23:54:35 --> No URI present. Default controller set.
INFO - 2016-11-11 23:54:35 --> Router Class Initialized
INFO - 2016-11-11 23:54:35 --> Output Class Initialized
INFO - 2016-11-11 23:54:35 --> Security Class Initialized
DEBUG - 2016-11-11 23:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:54:35 --> Input Class Initialized
INFO - 2016-11-11 23:54:35 --> Language Class Initialized
INFO - 2016-11-11 23:54:35 --> Loader Class Initialized
INFO - 2016-11-11 23:54:35 --> Helper loaded: url_helper
INFO - 2016-11-11 23:54:35 --> Helper loaded: form_helper
INFO - 2016-11-11 23:54:35 --> Database Driver Class Initialized
INFO - 2016-11-11 23:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:54:35 --> Controller Class Initialized
INFO - 2016-11-11 23:54:35 --> Model Class Initialized
INFO - 2016-11-11 23:54:35 --> Model Class Initialized
INFO - 2016-11-11 23:54:35 --> Model Class Initialized
INFO - 2016-11-11 23:54:35 --> Model Class Initialized
INFO - 2016-11-11 23:54:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:54:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:54:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:54:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:54:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:54:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:54:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:54:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:54:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:54:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:54:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:54:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:54:35 --> Final output sent to browser
DEBUG - 2016-11-11 23:54:35 --> Total execution time: 0.5448
INFO - 2016-11-11 23:55:10 --> Config Class Initialized
INFO - 2016-11-11 23:55:10 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:55:10 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:55:10 --> Utf8 Class Initialized
INFO - 2016-11-11 23:55:11 --> URI Class Initialized
DEBUG - 2016-11-11 23:55:11 --> No URI present. Default controller set.
INFO - 2016-11-11 23:55:11 --> Router Class Initialized
INFO - 2016-11-11 23:55:11 --> Output Class Initialized
INFO - 2016-11-11 23:55:11 --> Security Class Initialized
DEBUG - 2016-11-11 23:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:55:11 --> Input Class Initialized
INFO - 2016-11-11 23:55:11 --> Language Class Initialized
INFO - 2016-11-11 23:55:11 --> Loader Class Initialized
INFO - 2016-11-11 23:55:11 --> Helper loaded: url_helper
INFO - 2016-11-11 23:55:11 --> Helper loaded: form_helper
INFO - 2016-11-11 23:55:11 --> Database Driver Class Initialized
INFO - 2016-11-11 23:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:55:11 --> Controller Class Initialized
INFO - 2016-11-11 23:55:11 --> Model Class Initialized
INFO - 2016-11-11 23:55:11 --> Model Class Initialized
INFO - 2016-11-11 23:55:11 --> Model Class Initialized
INFO - 2016-11-11 23:55:11 --> Model Class Initialized
INFO - 2016-11-11 23:55:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:55:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:55:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:55:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:55:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:55:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-11 23:55:11 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 26
INFO - 2016-11-11 23:55:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:55:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:55:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:55:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:55:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:55:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:55:11 --> Final output sent to browser
DEBUG - 2016-11-11 23:55:11 --> Total execution time: 0.5610
INFO - 2016-11-11 23:55:49 --> Config Class Initialized
INFO - 2016-11-11 23:55:49 --> Hooks Class Initialized
DEBUG - 2016-11-11 23:55:49 --> UTF-8 Support Enabled
INFO - 2016-11-11 23:55:49 --> Utf8 Class Initialized
INFO - 2016-11-11 23:55:49 --> URI Class Initialized
DEBUG - 2016-11-11 23:55:49 --> No URI present. Default controller set.
INFO - 2016-11-11 23:55:49 --> Router Class Initialized
INFO - 2016-11-11 23:55:49 --> Output Class Initialized
INFO - 2016-11-11 23:55:49 --> Security Class Initialized
DEBUG - 2016-11-11 23:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-11 23:55:49 --> Input Class Initialized
INFO - 2016-11-11 23:55:49 --> Language Class Initialized
INFO - 2016-11-11 23:55:49 --> Loader Class Initialized
INFO - 2016-11-11 23:55:49 --> Helper loaded: url_helper
INFO - 2016-11-11 23:55:49 --> Helper loaded: form_helper
INFO - 2016-11-11 23:55:49 --> Database Driver Class Initialized
INFO - 2016-11-11 23:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-11 23:55:49 --> Controller Class Initialized
INFO - 2016-11-11 23:55:49 --> Model Class Initialized
INFO - 2016-11-11 23:55:49 --> Model Class Initialized
INFO - 2016-11-11 23:55:49 --> Model Class Initialized
INFO - 2016-11-11 23:55:49 --> Model Class Initialized
INFO - 2016-11-11 23:55:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-11 23:55:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-11 23:55:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-11 23:55:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-11 23:55:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-11 23:55:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-11 23:55:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-11 23:55:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-11 23:55:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-11 23:55:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-11 23:55:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-11 23:55:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-11 23:55:50 --> Final output sent to browser
DEBUG - 2016-11-11 23:55:50 --> Total execution time: 0.5904
