<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-01 14:26:15 --> Config Class Initialized
INFO - 2016-12-01 14:26:15 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:26:16 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:26:16 --> Utf8 Class Initialized
INFO - 2016-12-01 14:26:16 --> URI Class Initialized
DEBUG - 2016-12-01 14:26:16 --> No URI present. Default controller set.
INFO - 2016-12-01 14:26:16 --> Router Class Initialized
INFO - 2016-12-01 14:26:16 --> Output Class Initialized
INFO - 2016-12-01 14:26:16 --> Security Class Initialized
DEBUG - 2016-12-01 14:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:26:16 --> Input Class Initialized
INFO - 2016-12-01 14:26:16 --> Language Class Initialized
INFO - 2016-12-01 14:26:16 --> Loader Class Initialized
INFO - 2016-12-01 14:26:16 --> Helper loaded: url_helper
INFO - 2016-12-01 14:26:16 --> Helper loaded: form_helper
INFO - 2016-12-01 14:26:16 --> Database Driver Class Initialized
INFO - 2016-12-01 14:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:26:17 --> Controller Class Initialized
INFO - 2016-12-01 14:26:17 --> Model Class Initialized
INFO - 2016-12-01 14:26:17 --> Model Class Initialized
INFO - 2016-12-01 14:26:17 --> Model Class Initialized
INFO - 2016-12-01 14:26:17 --> Model Class Initialized
INFO - 2016-12-01 14:26:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:26:17 --> Pagination Class Initialized
INFO - 2016-12-01 14:26:17 --> Helper loaded: app_helper
INFO - 2016-12-01 14:26:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 14:26:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-01 14:26:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 14:26:17 --> Final output sent to browser
DEBUG - 2016-12-01 14:26:17 --> Total execution time: 2.0205
INFO - 2016-12-01 14:26:40 --> Config Class Initialized
INFO - 2016-12-01 14:26:40 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:26:40 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:26:40 --> Utf8 Class Initialized
INFO - 2016-12-01 14:26:40 --> URI Class Initialized
INFO - 2016-12-01 14:26:40 --> Router Class Initialized
INFO - 2016-12-01 14:26:40 --> Output Class Initialized
INFO - 2016-12-01 14:26:40 --> Security Class Initialized
DEBUG - 2016-12-01 14:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:26:40 --> Input Class Initialized
INFO - 2016-12-01 14:26:40 --> Language Class Initialized
INFO - 2016-12-01 14:26:40 --> Loader Class Initialized
INFO - 2016-12-01 14:26:40 --> Helper loaded: url_helper
INFO - 2016-12-01 14:26:40 --> Helper loaded: form_helper
INFO - 2016-12-01 14:26:40 --> Database Driver Class Initialized
INFO - 2016-12-01 14:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:26:40 --> Controller Class Initialized
INFO - 2016-12-01 14:26:40 --> Model Class Initialized
INFO - 2016-12-01 14:26:40 --> Model Class Initialized
INFO - 2016-12-01 14:26:40 --> Model Class Initialized
INFO - 2016-12-01 14:26:40 --> Model Class Initialized
INFO - 2016-12-01 14:26:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:26:40 --> Pagination Class Initialized
INFO - 2016-12-01 14:26:40 --> Helper loaded: app_helper
DEBUG - 2016-12-01 14:26:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:26:40 --> Model Class Initialized
INFO - 2016-12-01 14:26:40 --> Final output sent to browser
DEBUG - 2016-12-01 14:26:40 --> Total execution time: 0.3277
INFO - 2016-12-01 14:26:40 --> Config Class Initialized
INFO - 2016-12-01 14:26:40 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:26:40 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:26:40 --> Utf8 Class Initialized
INFO - 2016-12-01 14:26:40 --> URI Class Initialized
DEBUG - 2016-12-01 14:26:40 --> No URI present. Default controller set.
INFO - 2016-12-01 14:26:40 --> Router Class Initialized
INFO - 2016-12-01 14:26:40 --> Output Class Initialized
INFO - 2016-12-01 14:26:40 --> Security Class Initialized
DEBUG - 2016-12-01 14:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:26:40 --> Input Class Initialized
INFO - 2016-12-01 14:26:40 --> Language Class Initialized
INFO - 2016-12-01 14:26:40 --> Loader Class Initialized
INFO - 2016-12-01 14:26:40 --> Helper loaded: url_helper
INFO - 2016-12-01 14:26:40 --> Helper loaded: form_helper
INFO - 2016-12-01 14:26:40 --> Database Driver Class Initialized
INFO - 2016-12-01 14:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:26:40 --> Controller Class Initialized
INFO - 2016-12-01 14:26:40 --> Model Class Initialized
INFO - 2016-12-01 14:26:40 --> Model Class Initialized
INFO - 2016-12-01 14:26:40 --> Model Class Initialized
INFO - 2016-12-01 14:26:40 --> Model Class Initialized
INFO - 2016-12-01 14:26:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:26:40 --> Pagination Class Initialized
INFO - 2016-12-01 14:26:40 --> Helper loaded: app_helper
INFO - 2016-12-01 14:26:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 14:26:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 14:26:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 14:26:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 14:26:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 14:26:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 14:26:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-01 14:26:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 14:26:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 14:26:41 --> Final output sent to browser
DEBUG - 2016-12-01 14:26:41 --> Total execution time: 0.7718
INFO - 2016-12-01 14:26:50 --> Config Class Initialized
INFO - 2016-12-01 14:26:50 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:26:50 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:26:50 --> Utf8 Class Initialized
INFO - 2016-12-01 14:26:50 --> URI Class Initialized
INFO - 2016-12-01 14:26:50 --> Router Class Initialized
INFO - 2016-12-01 14:26:50 --> Output Class Initialized
INFO - 2016-12-01 14:26:50 --> Security Class Initialized
DEBUG - 2016-12-01 14:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:26:50 --> Input Class Initialized
INFO - 2016-12-01 14:26:50 --> Language Class Initialized
INFO - 2016-12-01 14:26:50 --> Loader Class Initialized
INFO - 2016-12-01 14:26:50 --> Helper loaded: url_helper
INFO - 2016-12-01 14:26:50 --> Helper loaded: form_helper
INFO - 2016-12-01 14:26:50 --> Database Driver Class Initialized
INFO - 2016-12-01 14:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:26:50 --> Controller Class Initialized
INFO - 2016-12-01 14:26:50 --> Model Class Initialized
INFO - 2016-12-01 14:26:50 --> Form Validation Class Initialized
INFO - 2016-12-01 14:26:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:26:50 --> Pagination Class Initialized
INFO - 2016-12-01 14:26:50 --> Helper loaded: app_helper
INFO - 2016-12-01 14:26:50 --> Email Class Initialized
INFO - 2016-12-01 14:26:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 14:26:50 --> Final output sent to browser
DEBUG - 2016-12-01 14:26:50 --> Total execution time: 0.2938
INFO - 2016-12-01 14:26:52 --> Config Class Initialized
INFO - 2016-12-01 14:26:52 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:26:52 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:26:52 --> Utf8 Class Initialized
INFO - 2016-12-01 14:26:52 --> URI Class Initialized
INFO - 2016-12-01 14:26:52 --> Router Class Initialized
INFO - 2016-12-01 14:26:52 --> Output Class Initialized
INFO - 2016-12-01 14:26:52 --> Security Class Initialized
DEBUG - 2016-12-01 14:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:26:52 --> Input Class Initialized
INFO - 2016-12-01 14:26:52 --> Language Class Initialized
INFO - 2016-12-01 14:26:52 --> Loader Class Initialized
INFO - 2016-12-01 14:26:52 --> Helper loaded: url_helper
INFO - 2016-12-01 14:26:52 --> Helper loaded: form_helper
INFO - 2016-12-01 14:26:52 --> Database Driver Class Initialized
INFO - 2016-12-01 14:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:26:52 --> Controller Class Initialized
INFO - 2016-12-01 14:26:52 --> Model Class Initialized
INFO - 2016-12-01 14:26:52 --> Model Class Initialized
INFO - 2016-12-01 14:26:52 --> Model Class Initialized
INFO - 2016-12-01 14:26:52 --> Model Class Initialized
INFO - 2016-12-01 14:26:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:26:52 --> Pagination Class Initialized
INFO - 2016-12-01 14:26:52 --> Helper loaded: app_helper
DEBUG - 2016-12-01 14:26:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-12-01 14:26:52 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-12-01 14:26:52 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-12-01 14:26:52 --> Config Class Initialized
INFO - 2016-12-01 14:26:52 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:26:52 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:26:52 --> Utf8 Class Initialized
INFO - 2016-12-01 14:26:52 --> URI Class Initialized
DEBUG - 2016-12-01 14:26:52 --> No URI present. Default controller set.
INFO - 2016-12-01 14:26:52 --> Router Class Initialized
INFO - 2016-12-01 14:26:52 --> Output Class Initialized
INFO - 2016-12-01 14:26:52 --> Security Class Initialized
DEBUG - 2016-12-01 14:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:26:52 --> Input Class Initialized
INFO - 2016-12-01 14:26:52 --> Language Class Initialized
INFO - 2016-12-01 14:26:52 --> Loader Class Initialized
INFO - 2016-12-01 14:26:52 --> Helper loaded: url_helper
INFO - 2016-12-01 14:26:52 --> Helper loaded: form_helper
INFO - 2016-12-01 14:26:52 --> Database Driver Class Initialized
INFO - 2016-12-01 14:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:26:52 --> Controller Class Initialized
INFO - 2016-12-01 14:26:52 --> Model Class Initialized
INFO - 2016-12-01 14:26:52 --> Model Class Initialized
INFO - 2016-12-01 14:26:52 --> Model Class Initialized
INFO - 2016-12-01 14:26:52 --> Model Class Initialized
INFO - 2016-12-01 14:26:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:26:52 --> Pagination Class Initialized
INFO - 2016-12-01 14:26:52 --> Helper loaded: app_helper
INFO - 2016-12-01 14:26:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 14:26:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-01 14:26:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 14:26:52 --> Final output sent to browser
DEBUG - 2016-12-01 14:26:52 --> Total execution time: 0.2728
INFO - 2016-12-01 14:27:39 --> Config Class Initialized
INFO - 2016-12-01 14:27:39 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:27:39 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:27:39 --> Utf8 Class Initialized
INFO - 2016-12-01 14:27:39 --> URI Class Initialized
INFO - 2016-12-01 14:27:39 --> Router Class Initialized
INFO - 2016-12-01 14:27:39 --> Output Class Initialized
INFO - 2016-12-01 14:27:39 --> Security Class Initialized
DEBUG - 2016-12-01 14:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:27:39 --> Input Class Initialized
INFO - 2016-12-01 14:27:39 --> Language Class Initialized
INFO - 2016-12-01 14:27:39 --> Loader Class Initialized
INFO - 2016-12-01 14:27:39 --> Helper loaded: url_helper
INFO - 2016-12-01 14:27:39 --> Helper loaded: form_helper
INFO - 2016-12-01 14:27:39 --> Database Driver Class Initialized
INFO - 2016-12-01 14:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:27:39 --> Controller Class Initialized
INFO - 2016-12-01 14:27:39 --> Model Class Initialized
INFO - 2016-12-01 14:27:39 --> Model Class Initialized
INFO - 2016-12-01 14:27:39 --> Model Class Initialized
INFO - 2016-12-01 14:27:39 --> Model Class Initialized
INFO - 2016-12-01 14:27:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:27:39 --> Pagination Class Initialized
INFO - 2016-12-01 14:27:39 --> Helper loaded: app_helper
DEBUG - 2016-12-01 14:27:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:27:39 --> Model Class Initialized
INFO - 2016-12-01 14:27:39 --> Final output sent to browser
DEBUG - 2016-12-01 14:27:39 --> Total execution time: 0.2364
INFO - 2016-12-01 14:27:39 --> Config Class Initialized
INFO - 2016-12-01 14:27:39 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:27:39 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:27:39 --> Utf8 Class Initialized
INFO - 2016-12-01 14:27:39 --> URI Class Initialized
DEBUG - 2016-12-01 14:27:39 --> No URI present. Default controller set.
INFO - 2016-12-01 14:27:39 --> Router Class Initialized
INFO - 2016-12-01 14:27:39 --> Output Class Initialized
INFO - 2016-12-01 14:27:39 --> Security Class Initialized
DEBUG - 2016-12-01 14:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:27:39 --> Input Class Initialized
INFO - 2016-12-01 14:27:39 --> Language Class Initialized
INFO - 2016-12-01 14:27:39 --> Loader Class Initialized
INFO - 2016-12-01 14:27:39 --> Helper loaded: url_helper
INFO - 2016-12-01 14:27:39 --> Helper loaded: form_helper
INFO - 2016-12-01 14:27:39 --> Database Driver Class Initialized
INFO - 2016-12-01 14:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:27:39 --> Controller Class Initialized
INFO - 2016-12-01 14:27:39 --> Model Class Initialized
INFO - 2016-12-01 14:27:39 --> Model Class Initialized
INFO - 2016-12-01 14:27:39 --> Model Class Initialized
INFO - 2016-12-01 14:27:39 --> Model Class Initialized
INFO - 2016-12-01 14:27:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:27:39 --> Pagination Class Initialized
INFO - 2016-12-01 14:27:39 --> Helper loaded: app_helper
INFO - 2016-12-01 14:27:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 14:27:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 14:27:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 14:27:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 14:27:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 14:27:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 14:27:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 14:27:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 14:27:39 --> Final output sent to browser
DEBUG - 2016-12-01 14:27:39 --> Total execution time: 0.3340
INFO - 2016-12-01 14:27:47 --> Config Class Initialized
INFO - 2016-12-01 14:27:47 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:27:47 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:27:47 --> Utf8 Class Initialized
INFO - 2016-12-01 14:27:47 --> URI Class Initialized
INFO - 2016-12-01 14:27:47 --> Router Class Initialized
INFO - 2016-12-01 14:27:47 --> Output Class Initialized
INFO - 2016-12-01 14:27:47 --> Security Class Initialized
DEBUG - 2016-12-01 14:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:27:47 --> Input Class Initialized
INFO - 2016-12-01 14:27:47 --> Language Class Initialized
INFO - 2016-12-01 14:27:47 --> Loader Class Initialized
INFO - 2016-12-01 14:27:47 --> Helper loaded: url_helper
INFO - 2016-12-01 14:27:47 --> Helper loaded: form_helper
INFO - 2016-12-01 14:27:47 --> Database Driver Class Initialized
INFO - 2016-12-01 14:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:27:47 --> Controller Class Initialized
INFO - 2016-12-01 14:27:47 --> Model Class Initialized
INFO - 2016-12-01 14:27:48 --> Form Validation Class Initialized
INFO - 2016-12-01 14:27:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:27:48 --> Pagination Class Initialized
INFO - 2016-12-01 14:27:48 --> Helper loaded: app_helper
INFO - 2016-12-01 14:27:48 --> Email Class Initialized
INFO - 2016-12-01 14:27:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 13:27:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 13:27:48 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 13:27:48 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 13:27:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 13:27:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 13:27:49 --> Final output sent to browser
DEBUG - 2016-12-01 13:27:49 --> Total execution time: 1.6368
INFO - 2016-12-01 14:29:22 --> Config Class Initialized
INFO - 2016-12-01 14:29:22 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:29:22 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:29:22 --> Utf8 Class Initialized
INFO - 2016-12-01 14:29:22 --> URI Class Initialized
DEBUG - 2016-12-01 14:29:22 --> No URI present. Default controller set.
INFO - 2016-12-01 14:29:22 --> Router Class Initialized
INFO - 2016-12-01 14:29:22 --> Output Class Initialized
INFO - 2016-12-01 14:29:22 --> Security Class Initialized
DEBUG - 2016-12-01 14:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:29:22 --> Input Class Initialized
INFO - 2016-12-01 14:29:22 --> Language Class Initialized
INFO - 2016-12-01 14:29:22 --> Loader Class Initialized
INFO - 2016-12-01 14:29:22 --> Helper loaded: url_helper
INFO - 2016-12-01 14:29:22 --> Helper loaded: form_helper
INFO - 2016-12-01 14:29:22 --> Database Driver Class Initialized
INFO - 2016-12-01 14:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:29:22 --> Controller Class Initialized
INFO - 2016-12-01 14:29:22 --> Model Class Initialized
INFO - 2016-12-01 14:29:22 --> Model Class Initialized
INFO - 2016-12-01 14:29:22 --> Model Class Initialized
INFO - 2016-12-01 14:29:22 --> Model Class Initialized
INFO - 2016-12-01 14:29:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:29:22 --> Pagination Class Initialized
INFO - 2016-12-01 14:29:22 --> Helper loaded: app_helper
INFO - 2016-12-01 14:29:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 14:29:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 14:29:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 14:29:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 14:29:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 14:29:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 14:29:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 14:29:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 14:29:22 --> Final output sent to browser
DEBUG - 2016-12-01 14:29:22 --> Total execution time: 0.3263
INFO - 2016-12-01 14:33:20 --> Config Class Initialized
INFO - 2016-12-01 14:33:20 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:33:20 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:33:20 --> Utf8 Class Initialized
INFO - 2016-12-01 14:33:20 --> URI Class Initialized
DEBUG - 2016-12-01 14:33:20 --> No URI present. Default controller set.
INFO - 2016-12-01 14:33:20 --> Router Class Initialized
INFO - 2016-12-01 14:33:20 --> Output Class Initialized
INFO - 2016-12-01 14:33:20 --> Security Class Initialized
DEBUG - 2016-12-01 14:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:33:20 --> Input Class Initialized
INFO - 2016-12-01 14:33:20 --> Language Class Initialized
INFO - 2016-12-01 14:33:20 --> Loader Class Initialized
INFO - 2016-12-01 14:33:20 --> Helper loaded: url_helper
INFO - 2016-12-01 14:33:20 --> Helper loaded: form_helper
INFO - 2016-12-01 14:33:20 --> Database Driver Class Initialized
INFO - 2016-12-01 14:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:33:20 --> Controller Class Initialized
INFO - 2016-12-01 14:33:20 --> Model Class Initialized
INFO - 2016-12-01 14:33:20 --> Model Class Initialized
INFO - 2016-12-01 14:33:20 --> Model Class Initialized
INFO - 2016-12-01 14:33:20 --> Model Class Initialized
INFO - 2016-12-01 14:33:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:33:20 --> Pagination Class Initialized
INFO - 2016-12-01 14:33:20 --> Helper loaded: app_helper
INFO - 2016-12-01 14:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 14:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 14:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 14:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 14:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 14:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 14:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 14:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 14:33:20 --> Final output sent to browser
DEBUG - 2016-12-01 14:33:20 --> Total execution time: 0.3574
INFO - 2016-12-01 14:33:43 --> Config Class Initialized
INFO - 2016-12-01 14:33:43 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:33:43 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:33:43 --> Utf8 Class Initialized
INFO - 2016-12-01 14:33:43 --> URI Class Initialized
INFO - 2016-12-01 14:33:43 --> Router Class Initialized
INFO - 2016-12-01 14:33:43 --> Output Class Initialized
INFO - 2016-12-01 14:33:43 --> Security Class Initialized
DEBUG - 2016-12-01 14:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:33:43 --> Input Class Initialized
INFO - 2016-12-01 14:33:43 --> Language Class Initialized
INFO - 2016-12-01 14:33:43 --> Loader Class Initialized
INFO - 2016-12-01 14:33:43 --> Helper loaded: url_helper
INFO - 2016-12-01 14:33:43 --> Helper loaded: form_helper
INFO - 2016-12-01 14:33:43 --> Database Driver Class Initialized
INFO - 2016-12-01 14:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:33:43 --> Controller Class Initialized
INFO - 2016-12-01 14:33:43 --> Model Class Initialized
INFO - 2016-12-01 14:33:43 --> Form Validation Class Initialized
INFO - 2016-12-01 14:33:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:33:43 --> Pagination Class Initialized
INFO - 2016-12-01 14:33:43 --> Helper loaded: app_helper
INFO - 2016-12-01 14:33:43 --> Email Class Initialized
INFO - 2016-12-01 14:33:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 13:33:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 13:33:43 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 13:33:44 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 13:33:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 13:33:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 13:33:44 --> Final output sent to browser
DEBUG - 2016-12-01 13:33:44 --> Total execution time: 1.3503
INFO - 2016-12-01 14:34:25 --> Config Class Initialized
INFO - 2016-12-01 14:34:25 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:34:25 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:34:25 --> Utf8 Class Initialized
INFO - 2016-12-01 14:34:25 --> URI Class Initialized
DEBUG - 2016-12-01 14:34:25 --> No URI present. Default controller set.
INFO - 2016-12-01 14:34:25 --> Router Class Initialized
INFO - 2016-12-01 14:34:25 --> Output Class Initialized
INFO - 2016-12-01 14:34:25 --> Security Class Initialized
DEBUG - 2016-12-01 14:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:34:25 --> Input Class Initialized
INFO - 2016-12-01 14:34:25 --> Language Class Initialized
INFO - 2016-12-01 14:34:25 --> Loader Class Initialized
INFO - 2016-12-01 14:34:25 --> Helper loaded: url_helper
INFO - 2016-12-01 14:34:25 --> Helper loaded: form_helper
INFO - 2016-12-01 14:34:25 --> Database Driver Class Initialized
INFO - 2016-12-01 14:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:34:25 --> Controller Class Initialized
INFO - 2016-12-01 14:34:25 --> Model Class Initialized
INFO - 2016-12-01 14:34:25 --> Model Class Initialized
INFO - 2016-12-01 14:34:25 --> Model Class Initialized
INFO - 2016-12-01 14:34:25 --> Model Class Initialized
INFO - 2016-12-01 14:34:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:34:25 --> Pagination Class Initialized
INFO - 2016-12-01 14:34:25 --> Helper loaded: app_helper
INFO - 2016-12-01 14:34:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 14:34:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 14:34:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 14:34:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 14:34:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 14:34:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 14:34:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 14:34:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 14:34:25 --> Final output sent to browser
DEBUG - 2016-12-01 14:34:25 --> Total execution time: 0.5052
INFO - 2016-12-01 14:40:21 --> Config Class Initialized
INFO - 2016-12-01 14:40:21 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:40:21 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:40:21 --> Utf8 Class Initialized
INFO - 2016-12-01 14:40:21 --> URI Class Initialized
INFO - 2016-12-01 14:40:21 --> Router Class Initialized
INFO - 2016-12-01 14:40:21 --> Output Class Initialized
INFO - 2016-12-01 14:40:21 --> Security Class Initialized
DEBUG - 2016-12-01 14:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:40:21 --> Input Class Initialized
INFO - 2016-12-01 14:40:21 --> Language Class Initialized
ERROR - 2016-12-01 14:40:21 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 216
INFO - 2016-12-01 14:41:27 --> Config Class Initialized
INFO - 2016-12-01 14:41:28 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:41:28 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:41:28 --> Utf8 Class Initialized
INFO - 2016-12-01 14:41:28 --> URI Class Initialized
DEBUG - 2016-12-01 14:41:28 --> No URI present. Default controller set.
INFO - 2016-12-01 14:41:28 --> Router Class Initialized
INFO - 2016-12-01 14:41:28 --> Output Class Initialized
INFO - 2016-12-01 14:41:28 --> Security Class Initialized
DEBUG - 2016-12-01 14:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:41:28 --> Input Class Initialized
INFO - 2016-12-01 14:41:28 --> Language Class Initialized
INFO - 2016-12-01 14:41:28 --> Loader Class Initialized
INFO - 2016-12-01 14:41:28 --> Helper loaded: url_helper
INFO - 2016-12-01 14:41:28 --> Helper loaded: form_helper
INFO - 2016-12-01 14:41:28 --> Database Driver Class Initialized
INFO - 2016-12-01 14:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:41:28 --> Controller Class Initialized
INFO - 2016-12-01 14:41:28 --> Model Class Initialized
INFO - 2016-12-01 14:41:28 --> Model Class Initialized
INFO - 2016-12-01 14:41:28 --> Model Class Initialized
INFO - 2016-12-01 14:41:28 --> Model Class Initialized
INFO - 2016-12-01 14:41:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:41:28 --> Pagination Class Initialized
INFO - 2016-12-01 14:41:28 --> Helper loaded: app_helper
INFO - 2016-12-01 14:41:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 14:41:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 14:41:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 14:41:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 14:41:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 14:41:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 14:41:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 14:41:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 14:41:28 --> Final output sent to browser
DEBUG - 2016-12-01 14:41:28 --> Total execution time: 0.3620
INFO - 2016-12-01 14:41:36 --> Config Class Initialized
INFO - 2016-12-01 14:41:36 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:41:36 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:41:36 --> Utf8 Class Initialized
INFO - 2016-12-01 14:41:36 --> URI Class Initialized
INFO - 2016-12-01 14:41:36 --> Router Class Initialized
INFO - 2016-12-01 14:41:36 --> Output Class Initialized
INFO - 2016-12-01 14:41:36 --> Security Class Initialized
DEBUG - 2016-12-01 14:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:41:36 --> Input Class Initialized
INFO - 2016-12-01 14:41:36 --> Language Class Initialized
INFO - 2016-12-01 14:41:36 --> Loader Class Initialized
INFO - 2016-12-01 14:41:36 --> Helper loaded: url_helper
INFO - 2016-12-01 14:41:36 --> Helper loaded: form_helper
INFO - 2016-12-01 14:41:36 --> Database Driver Class Initialized
INFO - 2016-12-01 14:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:41:36 --> Controller Class Initialized
INFO - 2016-12-01 14:41:36 --> Model Class Initialized
INFO - 2016-12-01 14:41:36 --> Form Validation Class Initialized
INFO - 2016-12-01 14:41:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:41:36 --> Pagination Class Initialized
INFO - 2016-12-01 14:41:36 --> Helper loaded: app_helper
INFO - 2016-12-01 14:41:36 --> Email Class Initialized
INFO - 2016-12-01 14:41:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 13:41:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 13:41:36 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 13:41:37 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 13:41:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 13:41:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 13:41:38 --> Final output sent to browser
DEBUG - 2016-12-01 13:41:38 --> Total execution time: 2.3359
INFO - 2016-12-01 14:46:41 --> Config Class Initialized
INFO - 2016-12-01 14:46:41 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:46:41 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:46:41 --> Utf8 Class Initialized
INFO - 2016-12-01 14:46:41 --> URI Class Initialized
DEBUG - 2016-12-01 14:46:41 --> No URI present. Default controller set.
INFO - 2016-12-01 14:46:41 --> Router Class Initialized
INFO - 2016-12-01 14:46:41 --> Output Class Initialized
INFO - 2016-12-01 14:46:41 --> Security Class Initialized
DEBUG - 2016-12-01 14:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:46:41 --> Input Class Initialized
INFO - 2016-12-01 14:46:41 --> Language Class Initialized
INFO - 2016-12-01 14:46:41 --> Loader Class Initialized
INFO - 2016-12-01 14:46:41 --> Helper loaded: url_helper
INFO - 2016-12-01 14:46:41 --> Helper loaded: form_helper
INFO - 2016-12-01 14:46:41 --> Database Driver Class Initialized
INFO - 2016-12-01 14:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:46:41 --> Controller Class Initialized
INFO - 2016-12-01 14:46:41 --> Model Class Initialized
INFO - 2016-12-01 14:46:41 --> Model Class Initialized
INFO - 2016-12-01 14:46:41 --> Model Class Initialized
INFO - 2016-12-01 14:46:41 --> Model Class Initialized
INFO - 2016-12-01 14:46:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:46:41 --> Pagination Class Initialized
INFO - 2016-12-01 14:46:41 --> Helper loaded: app_helper
INFO - 2016-12-01 14:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 14:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 14:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 14:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 14:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 14:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 14:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 14:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 14:46:41 --> Final output sent to browser
DEBUG - 2016-12-01 14:46:41 --> Total execution time: 0.4420
INFO - 2016-12-01 14:47:49 --> Config Class Initialized
INFO - 2016-12-01 14:47:49 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:47:49 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:47:49 --> Utf8 Class Initialized
INFO - 2016-12-01 14:47:49 --> URI Class Initialized
DEBUG - 2016-12-01 14:47:49 --> No URI present. Default controller set.
INFO - 2016-12-01 14:47:49 --> Router Class Initialized
INFO - 2016-12-01 14:47:49 --> Output Class Initialized
INFO - 2016-12-01 14:47:49 --> Security Class Initialized
DEBUG - 2016-12-01 14:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:47:49 --> Input Class Initialized
INFO - 2016-12-01 14:47:49 --> Language Class Initialized
INFO - 2016-12-01 14:47:49 --> Loader Class Initialized
INFO - 2016-12-01 14:47:49 --> Helper loaded: url_helper
INFO - 2016-12-01 14:47:49 --> Helper loaded: form_helper
INFO - 2016-12-01 14:47:49 --> Database Driver Class Initialized
INFO - 2016-12-01 14:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:47:49 --> Controller Class Initialized
INFO - 2016-12-01 14:47:49 --> Model Class Initialized
INFO - 2016-12-01 14:47:49 --> Model Class Initialized
INFO - 2016-12-01 14:47:49 --> Model Class Initialized
INFO - 2016-12-01 14:47:49 --> Model Class Initialized
INFO - 2016-12-01 14:47:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:47:49 --> Pagination Class Initialized
INFO - 2016-12-01 14:47:49 --> Helper loaded: app_helper
INFO - 2016-12-01 14:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 14:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 14:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 14:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 14:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 14:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 14:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 14:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 14:47:49 --> Final output sent to browser
DEBUG - 2016-12-01 14:47:49 --> Total execution time: 0.3185
INFO - 2016-12-01 14:48:42 --> Config Class Initialized
INFO - 2016-12-01 14:48:42 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:48:42 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:48:42 --> Utf8 Class Initialized
INFO - 2016-12-01 14:48:42 --> URI Class Initialized
INFO - 2016-12-01 14:48:42 --> Router Class Initialized
INFO - 2016-12-01 14:48:42 --> Output Class Initialized
INFO - 2016-12-01 14:48:42 --> Security Class Initialized
DEBUG - 2016-12-01 14:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:48:42 --> Input Class Initialized
INFO - 2016-12-01 14:48:42 --> Language Class Initialized
INFO - 2016-12-01 14:48:42 --> Loader Class Initialized
INFO - 2016-12-01 14:48:42 --> Helper loaded: url_helper
INFO - 2016-12-01 14:48:42 --> Helper loaded: form_helper
INFO - 2016-12-01 14:48:43 --> Database Driver Class Initialized
INFO - 2016-12-01 14:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:48:43 --> Controller Class Initialized
INFO - 2016-12-01 14:48:43 --> Model Class Initialized
INFO - 2016-12-01 14:48:43 --> Form Validation Class Initialized
INFO - 2016-12-01 14:48:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:48:43 --> Pagination Class Initialized
INFO - 2016-12-01 14:48:43 --> Helper loaded: app_helper
INFO - 2016-12-01 14:48:43 --> Email Class Initialized
INFO - 2016-12-01 14:48:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 13:48:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 13:48:43 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 13:48:43 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 13:48:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 13:48:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 13:48:44 --> Final output sent to browser
DEBUG - 2016-12-01 13:48:44 --> Total execution time: 1.2495
INFO - 2016-12-01 14:49:31 --> Config Class Initialized
INFO - 2016-12-01 14:49:31 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:49:31 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:49:31 --> Utf8 Class Initialized
INFO - 2016-12-01 14:49:31 --> URI Class Initialized
INFO - 2016-12-01 14:49:31 --> Router Class Initialized
INFO - 2016-12-01 14:49:31 --> Output Class Initialized
INFO - 2016-12-01 14:49:31 --> Security Class Initialized
DEBUG - 2016-12-01 14:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:49:31 --> Input Class Initialized
INFO - 2016-12-01 14:49:31 --> Language Class Initialized
INFO - 2016-12-01 14:49:31 --> Loader Class Initialized
INFO - 2016-12-01 14:49:31 --> Helper loaded: url_helper
INFO - 2016-12-01 14:49:31 --> Helper loaded: form_helper
INFO - 2016-12-01 14:49:31 --> Database Driver Class Initialized
INFO - 2016-12-01 14:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:49:31 --> Controller Class Initialized
INFO - 2016-12-01 14:49:31 --> Model Class Initialized
INFO - 2016-12-01 14:49:31 --> Form Validation Class Initialized
INFO - 2016-12-01 14:49:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:49:31 --> Pagination Class Initialized
INFO - 2016-12-01 14:49:31 --> Helper loaded: app_helper
INFO - 2016-12-01 14:49:31 --> Email Class Initialized
INFO - 2016-12-01 14:49:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 13:49:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 13:49:32 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 13:49:32 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 13:49:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 13:49:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 13:49:32 --> Final output sent to browser
DEBUG - 2016-12-01 13:49:32 --> Total execution time: 1.1540
INFO - 2016-12-01 14:51:21 --> Config Class Initialized
INFO - 2016-12-01 14:51:21 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:51:21 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:51:21 --> Utf8 Class Initialized
INFO - 2016-12-01 14:51:21 --> URI Class Initialized
INFO - 2016-12-01 14:51:21 --> Router Class Initialized
INFO - 2016-12-01 14:51:21 --> Output Class Initialized
INFO - 2016-12-01 14:51:21 --> Security Class Initialized
DEBUG - 2016-12-01 14:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:51:21 --> Input Class Initialized
INFO - 2016-12-01 14:51:21 --> Language Class Initialized
INFO - 2016-12-01 14:51:21 --> Loader Class Initialized
INFO - 2016-12-01 14:51:21 --> Helper loaded: url_helper
INFO - 2016-12-01 14:51:21 --> Helper loaded: form_helper
INFO - 2016-12-01 14:51:21 --> Database Driver Class Initialized
INFO - 2016-12-01 14:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:51:21 --> Controller Class Initialized
INFO - 2016-12-01 14:51:21 --> Model Class Initialized
INFO - 2016-12-01 14:51:21 --> Form Validation Class Initialized
INFO - 2016-12-01 14:51:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:51:21 --> Pagination Class Initialized
INFO - 2016-12-01 14:51:21 --> Helper loaded: app_helper
INFO - 2016-12-01 14:51:21 --> Email Class Initialized
INFO - 2016-12-01 14:51:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 13:51:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 13:51:21 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-12-01 13:51:23 --> Severity: Warning --> fsockopen(): unable to connect to localhost:465 (No connection could be made because the target machine actively refused it.
) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-12-01 13:51:23 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 13:51:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
ERROR - 2016-12-01 13:51:25 --> Severity: Warning --> fsockopen(): unable to connect to localhost:465 (No connection could be made because the target machine actively refused it.
) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-12-01 13:51:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 13:51:25 --> Final output sent to browser
DEBUG - 2016-12-01 13:51:25 --> Total execution time: 4.5587
INFO - 2016-12-01 14:51:44 --> Config Class Initialized
INFO - 2016-12-01 14:51:45 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:51:45 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:51:45 --> Utf8 Class Initialized
INFO - 2016-12-01 14:51:45 --> URI Class Initialized
DEBUG - 2016-12-01 14:51:45 --> No URI present. Default controller set.
INFO - 2016-12-01 14:51:45 --> Router Class Initialized
INFO - 2016-12-01 14:51:45 --> Output Class Initialized
INFO - 2016-12-01 14:51:45 --> Security Class Initialized
DEBUG - 2016-12-01 14:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:51:45 --> Input Class Initialized
INFO - 2016-12-01 14:51:45 --> Language Class Initialized
INFO - 2016-12-01 14:51:45 --> Loader Class Initialized
INFO - 2016-12-01 14:51:45 --> Helper loaded: url_helper
INFO - 2016-12-01 14:51:45 --> Helper loaded: form_helper
INFO - 2016-12-01 14:51:45 --> Database Driver Class Initialized
INFO - 2016-12-01 14:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:51:45 --> Controller Class Initialized
INFO - 2016-12-01 14:51:45 --> Model Class Initialized
INFO - 2016-12-01 14:51:45 --> Model Class Initialized
INFO - 2016-12-01 14:51:45 --> Model Class Initialized
INFO - 2016-12-01 14:51:45 --> Model Class Initialized
INFO - 2016-12-01 14:51:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:51:45 --> Pagination Class Initialized
INFO - 2016-12-01 14:51:45 --> Helper loaded: app_helper
INFO - 2016-12-01 14:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 14:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 14:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 14:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 14:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 14:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 14:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 14:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 14:51:45 --> Final output sent to browser
DEBUG - 2016-12-01 14:51:45 --> Total execution time: 0.3819
INFO - 2016-12-01 14:52:16 --> Config Class Initialized
INFO - 2016-12-01 14:52:16 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:52:16 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:52:16 --> Utf8 Class Initialized
INFO - 2016-12-01 14:52:16 --> URI Class Initialized
INFO - 2016-12-01 14:52:16 --> Router Class Initialized
INFO - 2016-12-01 14:52:16 --> Output Class Initialized
INFO - 2016-12-01 14:52:16 --> Security Class Initialized
DEBUG - 2016-12-01 14:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:52:16 --> Input Class Initialized
INFO - 2016-12-01 14:52:16 --> Language Class Initialized
INFO - 2016-12-01 14:52:16 --> Loader Class Initialized
INFO - 2016-12-01 14:52:16 --> Helper loaded: url_helper
INFO - 2016-12-01 14:52:16 --> Helper loaded: form_helper
INFO - 2016-12-01 14:52:16 --> Database Driver Class Initialized
INFO - 2016-12-01 14:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:52:16 --> Controller Class Initialized
INFO - 2016-12-01 14:52:16 --> Model Class Initialized
INFO - 2016-12-01 14:52:16 --> Form Validation Class Initialized
INFO - 2016-12-01 14:52:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:52:16 --> Pagination Class Initialized
INFO - 2016-12-01 14:52:16 --> Helper loaded: app_helper
INFO - 2016-12-01 14:52:16 --> Email Class Initialized
INFO - 2016-12-01 14:52:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 13:52:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 13:52:17 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-12-01 13:52:19 --> Severity: Warning --> fsockopen(): unable to connect to localhost:465 (No connection could be made because the target machine actively refused it.
) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-12-01 13:52:19 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 13:52:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
ERROR - 2016-12-01 13:52:21 --> Severity: Warning --> fsockopen(): unable to connect to localhost:465 (No connection could be made because the target machine actively refused it.
) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-12-01 13:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 13:52:21 --> Final output sent to browser
DEBUG - 2016-12-01 13:52:21 --> Total execution time: 4.6568
INFO - 2016-12-01 14:53:44 --> Config Class Initialized
INFO - 2016-12-01 14:53:44 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:53:44 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:53:44 --> Utf8 Class Initialized
INFO - 2016-12-01 14:53:44 --> URI Class Initialized
DEBUG - 2016-12-01 14:53:44 --> No URI present. Default controller set.
INFO - 2016-12-01 14:53:44 --> Router Class Initialized
INFO - 2016-12-01 14:53:44 --> Output Class Initialized
INFO - 2016-12-01 14:53:44 --> Security Class Initialized
DEBUG - 2016-12-01 14:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:53:44 --> Input Class Initialized
INFO - 2016-12-01 14:53:44 --> Language Class Initialized
INFO - 2016-12-01 14:53:44 --> Loader Class Initialized
INFO - 2016-12-01 14:53:44 --> Helper loaded: url_helper
INFO - 2016-12-01 14:53:44 --> Helper loaded: form_helper
INFO - 2016-12-01 14:53:44 --> Database Driver Class Initialized
INFO - 2016-12-01 14:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:53:44 --> Controller Class Initialized
INFO - 2016-12-01 14:53:44 --> Model Class Initialized
INFO - 2016-12-01 14:53:44 --> Model Class Initialized
INFO - 2016-12-01 14:53:44 --> Model Class Initialized
INFO - 2016-12-01 14:53:44 --> Model Class Initialized
INFO - 2016-12-01 14:53:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:53:44 --> Pagination Class Initialized
INFO - 2016-12-01 14:53:44 --> Helper loaded: app_helper
INFO - 2016-12-01 14:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 14:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 14:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 14:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 14:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 14:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 14:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 14:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 14:53:44 --> Final output sent to browser
DEBUG - 2016-12-01 14:53:44 --> Total execution time: 0.5119
INFO - 2016-12-01 14:54:18 --> Config Class Initialized
INFO - 2016-12-01 14:54:18 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:54:18 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:54:18 --> Utf8 Class Initialized
INFO - 2016-12-01 14:54:18 --> URI Class Initialized
DEBUG - 2016-12-01 14:54:18 --> No URI present. Default controller set.
INFO - 2016-12-01 14:54:18 --> Router Class Initialized
INFO - 2016-12-01 14:54:18 --> Output Class Initialized
INFO - 2016-12-01 14:54:18 --> Security Class Initialized
DEBUG - 2016-12-01 14:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:54:18 --> Input Class Initialized
INFO - 2016-12-01 14:54:18 --> Language Class Initialized
INFO - 2016-12-01 14:54:18 --> Loader Class Initialized
INFO - 2016-12-01 14:54:18 --> Helper loaded: url_helper
INFO - 2016-12-01 14:54:18 --> Helper loaded: form_helper
INFO - 2016-12-01 14:54:18 --> Database Driver Class Initialized
INFO - 2016-12-01 14:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:54:18 --> Controller Class Initialized
INFO - 2016-12-01 14:54:18 --> Model Class Initialized
INFO - 2016-12-01 14:54:18 --> Model Class Initialized
INFO - 2016-12-01 14:54:18 --> Model Class Initialized
INFO - 2016-12-01 14:54:18 --> Model Class Initialized
INFO - 2016-12-01 14:54:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:54:18 --> Pagination Class Initialized
INFO - 2016-12-01 14:54:18 --> Helper loaded: app_helper
INFO - 2016-12-01 14:54:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 14:54:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 14:54:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 14:54:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 14:54:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 14:54:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 14:54:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 14:54:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 14:54:18 --> Final output sent to browser
DEBUG - 2016-12-01 14:54:18 --> Total execution time: 0.3756
INFO - 2016-12-01 14:54:39 --> Config Class Initialized
INFO - 2016-12-01 14:54:39 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:54:39 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:54:40 --> Utf8 Class Initialized
INFO - 2016-12-01 14:54:40 --> URI Class Initialized
INFO - 2016-12-01 14:54:40 --> Router Class Initialized
INFO - 2016-12-01 14:54:40 --> Output Class Initialized
INFO - 2016-12-01 14:54:40 --> Security Class Initialized
DEBUG - 2016-12-01 14:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:54:40 --> Input Class Initialized
INFO - 2016-12-01 14:54:40 --> Language Class Initialized
INFO - 2016-12-01 14:54:40 --> Loader Class Initialized
INFO - 2016-12-01 14:54:40 --> Helper loaded: url_helper
INFO - 2016-12-01 14:54:40 --> Helper loaded: form_helper
INFO - 2016-12-01 14:54:40 --> Database Driver Class Initialized
INFO - 2016-12-01 14:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:54:40 --> Controller Class Initialized
INFO - 2016-12-01 14:54:40 --> Model Class Initialized
INFO - 2016-12-01 14:54:40 --> Form Validation Class Initialized
INFO - 2016-12-01 14:54:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:54:40 --> Pagination Class Initialized
INFO - 2016-12-01 14:54:40 --> Helper loaded: app_helper
INFO - 2016-12-01 14:54:40 --> Email Class Initialized
INFO - 2016-12-01 14:54:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 13:54:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 13:54:40 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 13:54:40 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 13:54:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 13:54:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 13:54:41 --> Final output sent to browser
DEBUG - 2016-12-01 13:54:41 --> Total execution time: 1.7724
INFO - 2016-12-01 14:55:13 --> Config Class Initialized
INFO - 2016-12-01 14:55:13 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:55:13 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:55:13 --> Utf8 Class Initialized
INFO - 2016-12-01 14:55:13 --> URI Class Initialized
DEBUG - 2016-12-01 14:55:13 --> No URI present. Default controller set.
INFO - 2016-12-01 14:55:13 --> Router Class Initialized
INFO - 2016-12-01 14:55:13 --> Output Class Initialized
INFO - 2016-12-01 14:55:13 --> Security Class Initialized
DEBUG - 2016-12-01 14:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:55:13 --> Input Class Initialized
INFO - 2016-12-01 14:55:13 --> Language Class Initialized
INFO - 2016-12-01 14:55:13 --> Loader Class Initialized
INFO - 2016-12-01 14:55:13 --> Helper loaded: url_helper
INFO - 2016-12-01 14:55:13 --> Helper loaded: form_helper
INFO - 2016-12-01 14:55:13 --> Database Driver Class Initialized
INFO - 2016-12-01 14:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:55:13 --> Controller Class Initialized
INFO - 2016-12-01 14:55:13 --> Model Class Initialized
INFO - 2016-12-01 14:55:13 --> Model Class Initialized
INFO - 2016-12-01 14:55:13 --> Model Class Initialized
INFO - 2016-12-01 14:55:13 --> Model Class Initialized
INFO - 2016-12-01 14:55:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:55:13 --> Pagination Class Initialized
INFO - 2016-12-01 14:55:13 --> Helper loaded: app_helper
INFO - 2016-12-01 14:55:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 14:55:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 14:55:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 14:55:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 14:55:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 14:55:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 14:55:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 14:55:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 14:55:13 --> Final output sent to browser
DEBUG - 2016-12-01 14:55:14 --> Total execution time: 0.4300
INFO - 2016-12-01 14:55:27 --> Config Class Initialized
INFO - 2016-12-01 14:55:27 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:55:27 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:55:27 --> Utf8 Class Initialized
INFO - 2016-12-01 14:55:27 --> URI Class Initialized
INFO - 2016-12-01 14:55:27 --> Router Class Initialized
INFO - 2016-12-01 14:55:27 --> Output Class Initialized
INFO - 2016-12-01 14:55:27 --> Security Class Initialized
DEBUG - 2016-12-01 14:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:55:27 --> Input Class Initialized
INFO - 2016-12-01 14:55:27 --> Language Class Initialized
INFO - 2016-12-01 14:55:27 --> Loader Class Initialized
INFO - 2016-12-01 14:55:27 --> Helper loaded: url_helper
INFO - 2016-12-01 14:55:27 --> Helper loaded: form_helper
INFO - 2016-12-01 14:55:27 --> Database Driver Class Initialized
INFO - 2016-12-01 14:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:55:27 --> Controller Class Initialized
INFO - 2016-12-01 14:55:27 --> Model Class Initialized
INFO - 2016-12-01 14:55:27 --> Form Validation Class Initialized
INFO - 2016-12-01 14:55:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 14:55:27 --> Pagination Class Initialized
INFO - 2016-12-01 14:55:27 --> Helper loaded: app_helper
INFO - 2016-12-01 14:55:27 --> Email Class Initialized
INFO - 2016-12-01 14:55:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 13:55:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 13:55:27 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 13:55:27 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 13:55:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 13:55:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 13:55:28 --> Final output sent to browser
DEBUG - 2016-12-01 13:55:28 --> Total execution time: 1.7072
INFO - 2016-12-01 15:12:39 --> Config Class Initialized
INFO - 2016-12-01 15:12:39 --> Hooks Class Initialized
DEBUG - 2016-12-01 15:12:39 --> UTF-8 Support Enabled
INFO - 2016-12-01 15:12:39 --> Utf8 Class Initialized
INFO - 2016-12-01 15:12:39 --> URI Class Initialized
INFO - 2016-12-01 15:12:39 --> Router Class Initialized
INFO - 2016-12-01 15:12:39 --> Output Class Initialized
INFO - 2016-12-01 15:12:39 --> Security Class Initialized
DEBUG - 2016-12-01 15:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 15:12:39 --> Input Class Initialized
INFO - 2016-12-01 15:12:39 --> Language Class Initialized
INFO - 2016-12-01 15:12:39 --> Loader Class Initialized
INFO - 2016-12-01 15:12:39 --> Helper loaded: url_helper
INFO - 2016-12-01 15:12:39 --> Helper loaded: form_helper
INFO - 2016-12-01 15:12:39 --> Database Driver Class Initialized
INFO - 2016-12-01 15:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 15:12:39 --> Controller Class Initialized
INFO - 2016-12-01 15:12:39 --> Model Class Initialized
INFO - 2016-12-01 15:12:39 --> Form Validation Class Initialized
INFO - 2016-12-01 15:12:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 15:12:39 --> Pagination Class Initialized
INFO - 2016-12-01 15:12:39 --> Helper loaded: app_helper
INFO - 2016-12-01 15:12:39 --> Email Class Initialized
INFO - 2016-12-01 15:12:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 14:12:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 14:12:40 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 14:12:40 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 14:12:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 14:12:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 14:12:41 --> Final output sent to browser
DEBUG - 2016-12-01 14:12:41 --> Total execution time: 1.6414
INFO - 2016-12-01 15:12:52 --> Config Class Initialized
INFO - 2016-12-01 15:12:52 --> Hooks Class Initialized
DEBUG - 2016-12-01 15:12:52 --> UTF-8 Support Enabled
INFO - 2016-12-01 15:12:52 --> Utf8 Class Initialized
INFO - 2016-12-01 15:12:52 --> URI Class Initialized
DEBUG - 2016-12-01 15:12:52 --> No URI present. Default controller set.
INFO - 2016-12-01 15:12:52 --> Router Class Initialized
INFO - 2016-12-01 15:12:52 --> Output Class Initialized
INFO - 2016-12-01 15:12:52 --> Security Class Initialized
DEBUG - 2016-12-01 15:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 15:12:52 --> Input Class Initialized
INFO - 2016-12-01 15:12:52 --> Language Class Initialized
INFO - 2016-12-01 15:12:52 --> Loader Class Initialized
INFO - 2016-12-01 15:12:52 --> Helper loaded: url_helper
INFO - 2016-12-01 15:12:52 --> Helper loaded: form_helper
INFO - 2016-12-01 15:12:52 --> Database Driver Class Initialized
INFO - 2016-12-01 15:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 15:12:52 --> Controller Class Initialized
INFO - 2016-12-01 15:12:52 --> Model Class Initialized
INFO - 2016-12-01 15:12:52 --> Model Class Initialized
INFO - 2016-12-01 15:12:52 --> Model Class Initialized
INFO - 2016-12-01 15:12:52 --> Model Class Initialized
INFO - 2016-12-01 15:12:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 15:12:52 --> Pagination Class Initialized
INFO - 2016-12-01 15:12:52 --> Helper loaded: app_helper
INFO - 2016-12-01 15:12:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 15:12:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 15:12:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 15:12:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 15:12:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 15:12:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 15:12:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 15:12:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 15:12:52 --> Final output sent to browser
DEBUG - 2016-12-01 15:12:52 --> Total execution time: 0.3927
INFO - 2016-12-01 15:13:14 --> Config Class Initialized
INFO - 2016-12-01 15:13:14 --> Hooks Class Initialized
DEBUG - 2016-12-01 15:13:14 --> UTF-8 Support Enabled
INFO - 2016-12-01 15:13:14 --> Utf8 Class Initialized
INFO - 2016-12-01 15:13:14 --> URI Class Initialized
INFO - 2016-12-01 15:13:14 --> Router Class Initialized
INFO - 2016-12-01 15:13:14 --> Output Class Initialized
INFO - 2016-12-01 15:13:14 --> Security Class Initialized
DEBUG - 2016-12-01 15:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 15:13:14 --> Input Class Initialized
INFO - 2016-12-01 15:13:14 --> Language Class Initialized
INFO - 2016-12-01 15:13:14 --> Loader Class Initialized
INFO - 2016-12-01 15:13:14 --> Helper loaded: url_helper
INFO - 2016-12-01 15:13:14 --> Helper loaded: form_helper
INFO - 2016-12-01 15:13:14 --> Database Driver Class Initialized
INFO - 2016-12-01 15:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 15:13:14 --> Controller Class Initialized
INFO - 2016-12-01 15:13:14 --> Model Class Initialized
INFO - 2016-12-01 15:13:14 --> Form Validation Class Initialized
INFO - 2016-12-01 15:13:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 15:13:14 --> Pagination Class Initialized
INFO - 2016-12-01 15:13:14 --> Helper loaded: app_helper
INFO - 2016-12-01 15:13:14 --> Email Class Initialized
INFO - 2016-12-01 15:13:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 14:13:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 14:13:15 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 14:13:15 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 14:13:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 14:13:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 14:13:16 --> Final output sent to browser
DEBUG - 2016-12-01 14:13:16 --> Total execution time: 1.7313
INFO - 2016-12-01 15:16:58 --> Config Class Initialized
INFO - 2016-12-01 15:16:58 --> Hooks Class Initialized
DEBUG - 2016-12-01 15:16:58 --> UTF-8 Support Enabled
INFO - 2016-12-01 15:16:58 --> Utf8 Class Initialized
INFO - 2016-12-01 15:16:58 --> URI Class Initialized
INFO - 2016-12-01 15:16:58 --> Router Class Initialized
INFO - 2016-12-01 15:16:58 --> Output Class Initialized
INFO - 2016-12-01 15:16:58 --> Security Class Initialized
DEBUG - 2016-12-01 15:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 15:16:58 --> Input Class Initialized
INFO - 2016-12-01 15:16:58 --> Language Class Initialized
INFO - 2016-12-01 15:16:58 --> Loader Class Initialized
INFO - 2016-12-01 15:16:58 --> Helper loaded: url_helper
INFO - 2016-12-01 15:16:58 --> Helper loaded: form_helper
INFO - 2016-12-01 15:16:58 --> Database Driver Class Initialized
INFO - 2016-12-01 15:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 15:16:58 --> Controller Class Initialized
INFO - 2016-12-01 15:16:58 --> Model Class Initialized
INFO - 2016-12-01 15:16:58 --> Form Validation Class Initialized
INFO - 2016-12-01 15:16:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 15:16:58 --> Pagination Class Initialized
INFO - 2016-12-01 15:16:58 --> Helper loaded: app_helper
INFO - 2016-12-01 15:16:58 --> Email Class Initialized
INFO - 2016-12-01 15:16:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 14:16:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 14:16:58 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 14:16:59 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 14:16:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 14:17:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 14:17:00 --> Final output sent to browser
DEBUG - 2016-12-01 14:17:00 --> Total execution time: 2.1697
INFO - 2016-12-01 15:18:31 --> Config Class Initialized
INFO - 2016-12-01 15:18:31 --> Hooks Class Initialized
DEBUG - 2016-12-01 15:18:31 --> UTF-8 Support Enabled
INFO - 2016-12-01 15:18:31 --> Utf8 Class Initialized
INFO - 2016-12-01 15:18:31 --> URI Class Initialized
DEBUG - 2016-12-01 15:18:31 --> No URI present. Default controller set.
INFO - 2016-12-01 15:18:31 --> Router Class Initialized
INFO - 2016-12-01 15:18:31 --> Output Class Initialized
INFO - 2016-12-01 15:18:31 --> Security Class Initialized
DEBUG - 2016-12-01 15:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 15:18:31 --> Input Class Initialized
INFO - 2016-12-01 15:18:31 --> Language Class Initialized
INFO - 2016-12-01 15:18:31 --> Loader Class Initialized
INFO - 2016-12-01 15:18:31 --> Helper loaded: url_helper
INFO - 2016-12-01 15:18:31 --> Helper loaded: form_helper
INFO - 2016-12-01 15:18:31 --> Database Driver Class Initialized
INFO - 2016-12-01 15:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 15:18:31 --> Controller Class Initialized
INFO - 2016-12-01 15:18:32 --> Model Class Initialized
INFO - 2016-12-01 15:18:32 --> Model Class Initialized
INFO - 2016-12-01 15:18:32 --> Model Class Initialized
INFO - 2016-12-01 15:18:32 --> Model Class Initialized
INFO - 2016-12-01 15:18:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 15:18:32 --> Pagination Class Initialized
INFO - 2016-12-01 15:18:32 --> Helper loaded: app_helper
INFO - 2016-12-01 15:18:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 15:18:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 15:18:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 15:18:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 15:18:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 15:18:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 15:18:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 15:18:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 15:18:32 --> Final output sent to browser
DEBUG - 2016-12-01 15:18:32 --> Total execution time: 0.3873
INFO - 2016-12-01 15:18:52 --> Config Class Initialized
INFO - 2016-12-01 15:18:52 --> Hooks Class Initialized
DEBUG - 2016-12-01 15:18:52 --> UTF-8 Support Enabled
INFO - 2016-12-01 15:18:52 --> Utf8 Class Initialized
INFO - 2016-12-01 15:18:52 --> URI Class Initialized
DEBUG - 2016-12-01 15:18:52 --> No URI present. Default controller set.
INFO - 2016-12-01 15:18:52 --> Router Class Initialized
INFO - 2016-12-01 15:18:52 --> Output Class Initialized
INFO - 2016-12-01 15:18:52 --> Security Class Initialized
DEBUG - 2016-12-01 15:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 15:18:52 --> Input Class Initialized
INFO - 2016-12-01 15:18:52 --> Language Class Initialized
INFO - 2016-12-01 15:18:52 --> Loader Class Initialized
INFO - 2016-12-01 15:18:52 --> Helper loaded: url_helper
INFO - 2016-12-01 15:18:52 --> Helper loaded: form_helper
INFO - 2016-12-01 15:18:52 --> Database Driver Class Initialized
INFO - 2016-12-01 15:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 15:18:52 --> Controller Class Initialized
INFO - 2016-12-01 15:18:52 --> Model Class Initialized
INFO - 2016-12-01 15:18:52 --> Model Class Initialized
INFO - 2016-12-01 15:18:52 --> Model Class Initialized
INFO - 2016-12-01 15:18:52 --> Model Class Initialized
INFO - 2016-12-01 15:18:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 15:18:52 --> Pagination Class Initialized
INFO - 2016-12-01 15:18:52 --> Helper loaded: app_helper
INFO - 2016-12-01 15:18:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 15:18:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 15:18:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 15:18:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 15:18:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 15:18:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 15:18:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 15:18:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 15:18:52 --> Final output sent to browser
DEBUG - 2016-12-01 15:18:52 --> Total execution time: 0.3903
INFO - 2016-12-01 15:19:00 --> Config Class Initialized
INFO - 2016-12-01 15:19:00 --> Hooks Class Initialized
DEBUG - 2016-12-01 15:19:00 --> UTF-8 Support Enabled
INFO - 2016-12-01 15:19:00 --> Utf8 Class Initialized
INFO - 2016-12-01 15:19:00 --> URI Class Initialized
INFO - 2016-12-01 15:19:00 --> Router Class Initialized
INFO - 2016-12-01 15:19:01 --> Output Class Initialized
INFO - 2016-12-01 15:19:01 --> Security Class Initialized
DEBUG - 2016-12-01 15:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 15:19:01 --> Input Class Initialized
INFO - 2016-12-01 15:19:01 --> Language Class Initialized
INFO - 2016-12-01 15:19:01 --> Loader Class Initialized
INFO - 2016-12-01 15:19:01 --> Helper loaded: url_helper
INFO - 2016-12-01 15:19:01 --> Helper loaded: form_helper
INFO - 2016-12-01 15:19:01 --> Database Driver Class Initialized
INFO - 2016-12-01 15:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 15:19:01 --> Controller Class Initialized
INFO - 2016-12-01 15:19:01 --> Model Class Initialized
INFO - 2016-12-01 15:19:01 --> Form Validation Class Initialized
INFO - 2016-12-01 15:19:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 15:19:01 --> Pagination Class Initialized
INFO - 2016-12-01 15:19:01 --> Helper loaded: app_helper
INFO - 2016-12-01 15:19:01 --> Email Class Initialized
INFO - 2016-12-01 15:19:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 14:19:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 14:19:01 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 14:19:01 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 14:19:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 14:19:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 14:19:03 --> Final output sent to browser
DEBUG - 2016-12-01 14:19:03 --> Total execution time: 2.0785
INFO - 2016-12-01 15:41:05 --> Config Class Initialized
INFO - 2016-12-01 15:41:05 --> Hooks Class Initialized
DEBUG - 2016-12-01 15:41:05 --> UTF-8 Support Enabled
INFO - 2016-12-01 15:41:05 --> Utf8 Class Initialized
INFO - 2016-12-01 15:41:05 --> URI Class Initialized
DEBUG - 2016-12-01 15:41:05 --> No URI present. Default controller set.
INFO - 2016-12-01 15:41:05 --> Router Class Initialized
INFO - 2016-12-01 15:41:05 --> Output Class Initialized
INFO - 2016-12-01 15:41:05 --> Security Class Initialized
DEBUG - 2016-12-01 15:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 15:41:05 --> Input Class Initialized
INFO - 2016-12-01 15:41:05 --> Language Class Initialized
INFO - 2016-12-01 15:41:05 --> Loader Class Initialized
INFO - 2016-12-01 15:41:05 --> Helper loaded: url_helper
INFO - 2016-12-01 15:41:05 --> Helper loaded: form_helper
INFO - 2016-12-01 15:41:05 --> Database Driver Class Initialized
INFO - 2016-12-01 15:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 15:41:05 --> Controller Class Initialized
INFO - 2016-12-01 15:41:05 --> Model Class Initialized
INFO - 2016-12-01 15:41:05 --> Model Class Initialized
INFO - 2016-12-01 15:41:05 --> Model Class Initialized
INFO - 2016-12-01 15:41:05 --> Model Class Initialized
INFO - 2016-12-01 15:41:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 15:41:05 --> Pagination Class Initialized
INFO - 2016-12-01 15:41:05 --> Helper loaded: app_helper
INFO - 2016-12-01 15:41:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 15:41:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 15:41:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 15:41:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 15:41:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 15:41:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 15:41:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 15:41:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 15:41:05 --> Final output sent to browser
DEBUG - 2016-12-01 15:41:05 --> Total execution time: 0.4210
INFO - 2016-12-01 15:41:16 --> Config Class Initialized
INFO - 2016-12-01 15:41:16 --> Hooks Class Initialized
DEBUG - 2016-12-01 15:41:16 --> UTF-8 Support Enabled
INFO - 2016-12-01 15:41:16 --> Utf8 Class Initialized
INFO - 2016-12-01 15:41:16 --> URI Class Initialized
INFO - 2016-12-01 15:41:16 --> Router Class Initialized
INFO - 2016-12-01 15:41:16 --> Output Class Initialized
INFO - 2016-12-01 15:41:16 --> Security Class Initialized
DEBUG - 2016-12-01 15:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 15:41:16 --> Input Class Initialized
INFO - 2016-12-01 15:41:16 --> Language Class Initialized
INFO - 2016-12-01 15:41:16 --> Loader Class Initialized
INFO - 2016-12-01 15:41:16 --> Helper loaded: url_helper
INFO - 2016-12-01 15:41:16 --> Helper loaded: form_helper
INFO - 2016-12-01 15:41:16 --> Database Driver Class Initialized
INFO - 2016-12-01 15:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 15:41:16 --> Controller Class Initialized
INFO - 2016-12-01 15:41:16 --> Model Class Initialized
INFO - 2016-12-01 15:41:16 --> Form Validation Class Initialized
INFO - 2016-12-01 15:41:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 15:41:16 --> Pagination Class Initialized
INFO - 2016-12-01 15:41:16 --> Helper loaded: app_helper
INFO - 2016-12-01 15:41:16 --> Email Class Initialized
INFO - 2016-12-01 15:41:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 14:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 14:41:17 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 14:41:22 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 14:41:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 14:41:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 14:41:22 --> Final output sent to browser
DEBUG - 2016-12-01 14:41:22 --> Total execution time: 5.6462
INFO - 2016-12-01 15:55:34 --> Config Class Initialized
INFO - 2016-12-01 15:55:34 --> Hooks Class Initialized
DEBUG - 2016-12-01 15:55:34 --> UTF-8 Support Enabled
INFO - 2016-12-01 15:55:34 --> Utf8 Class Initialized
INFO - 2016-12-01 15:55:34 --> URI Class Initialized
DEBUG - 2016-12-01 15:55:34 --> No URI present. Default controller set.
INFO - 2016-12-01 15:55:34 --> Router Class Initialized
INFO - 2016-12-01 15:55:34 --> Output Class Initialized
INFO - 2016-12-01 15:55:34 --> Security Class Initialized
DEBUG - 2016-12-01 15:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 15:55:34 --> Input Class Initialized
INFO - 2016-12-01 15:55:34 --> Language Class Initialized
INFO - 2016-12-01 15:55:34 --> Loader Class Initialized
INFO - 2016-12-01 15:55:34 --> Helper loaded: url_helper
INFO - 2016-12-01 15:55:34 --> Helper loaded: form_helper
INFO - 2016-12-01 15:55:34 --> Database Driver Class Initialized
INFO - 2016-12-01 15:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 15:55:34 --> Controller Class Initialized
INFO - 2016-12-01 15:55:34 --> Model Class Initialized
INFO - 2016-12-01 15:55:34 --> Model Class Initialized
INFO - 2016-12-01 15:55:34 --> Model Class Initialized
INFO - 2016-12-01 15:55:34 --> Model Class Initialized
INFO - 2016-12-01 15:55:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 15:55:34 --> Pagination Class Initialized
INFO - 2016-12-01 15:55:34 --> Helper loaded: app_helper
INFO - 2016-12-01 15:55:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 15:55:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 15:55:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 15:55:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 15:55:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 15:55:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 15:55:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 15:55:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 15:55:34 --> Final output sent to browser
DEBUG - 2016-12-01 15:55:34 --> Total execution time: 0.4038
INFO - 2016-12-01 15:55:44 --> Config Class Initialized
INFO - 2016-12-01 15:55:44 --> Hooks Class Initialized
DEBUG - 2016-12-01 15:55:44 --> UTF-8 Support Enabled
INFO - 2016-12-01 15:55:44 --> Utf8 Class Initialized
INFO - 2016-12-01 15:55:44 --> URI Class Initialized
INFO - 2016-12-01 15:55:44 --> Router Class Initialized
INFO - 2016-12-01 15:55:44 --> Output Class Initialized
INFO - 2016-12-01 15:55:44 --> Security Class Initialized
DEBUG - 2016-12-01 15:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 15:55:44 --> Input Class Initialized
INFO - 2016-12-01 15:55:44 --> Language Class Initialized
INFO - 2016-12-01 15:55:44 --> Loader Class Initialized
INFO - 2016-12-01 15:55:44 --> Helper loaded: url_helper
INFO - 2016-12-01 15:55:44 --> Helper loaded: form_helper
INFO - 2016-12-01 15:55:44 --> Database Driver Class Initialized
INFO - 2016-12-01 15:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 15:55:44 --> Controller Class Initialized
INFO - 2016-12-01 15:55:44 --> Model Class Initialized
INFO - 2016-12-01 15:55:44 --> Form Validation Class Initialized
INFO - 2016-12-01 15:55:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 15:55:44 --> Pagination Class Initialized
INFO - 2016-12-01 15:55:44 --> Helper loaded: app_helper
INFO - 2016-12-01 15:55:44 --> Email Class Initialized
INFO - 2016-12-01 15:55:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 14:55:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 14:55:44 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-12-01 14:55:47 --> Severity: Warning --> fsockopen(): unable to connect to localhost:465 (No connection could be made because the target machine actively refused it.
) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-12-01 14:55:47 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 14:55:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
ERROR - 2016-12-01 14:55:49 --> Severity: Warning --> fsockopen(): unable to connect to localhost:465 (No connection could be made because the target machine actively refused it.
) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-12-01 14:55:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 14:55:49 --> Final output sent to browser
DEBUG - 2016-12-01 14:55:49 --> Total execution time: 4.5782
INFO - 2016-12-01 15:56:44 --> Config Class Initialized
INFO - 2016-12-01 15:56:44 --> Hooks Class Initialized
DEBUG - 2016-12-01 15:56:44 --> UTF-8 Support Enabled
INFO - 2016-12-01 15:56:44 --> Utf8 Class Initialized
INFO - 2016-12-01 15:56:44 --> URI Class Initialized
INFO - 2016-12-01 15:56:44 --> Router Class Initialized
INFO - 2016-12-01 15:56:44 --> Output Class Initialized
INFO - 2016-12-01 15:56:44 --> Security Class Initialized
DEBUG - 2016-12-01 15:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 15:56:44 --> Input Class Initialized
INFO - 2016-12-01 15:56:44 --> Language Class Initialized
INFO - 2016-12-01 15:56:44 --> Loader Class Initialized
INFO - 2016-12-01 15:56:44 --> Helper loaded: url_helper
INFO - 2016-12-01 15:56:44 --> Helper loaded: form_helper
INFO - 2016-12-01 15:56:45 --> Database Driver Class Initialized
INFO - 2016-12-01 15:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 15:56:45 --> Controller Class Initialized
INFO - 2016-12-01 15:56:45 --> Model Class Initialized
INFO - 2016-12-01 15:56:45 --> Form Validation Class Initialized
INFO - 2016-12-01 15:56:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 15:56:45 --> Pagination Class Initialized
INFO - 2016-12-01 15:56:45 --> Helper loaded: app_helper
INFO - 2016-12-01 15:56:45 --> Email Class Initialized
INFO - 2016-12-01 15:56:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 14:56:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 14:56:45 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-12-01 14:56:47 --> Severity: Warning --> fsockopen(): unable to connect to localhost:25 (No connection could be made because the target machine actively refused it.
) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-12-01 14:56:47 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 14:56:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
ERROR - 2016-12-01 14:56:49 --> Severity: Warning --> fsockopen(): unable to connect to localhost:25 (No connection could be made because the target machine actively refused it.
) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-12-01 14:56:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 14:56:49 --> Final output sent to browser
DEBUG - 2016-12-01 14:56:49 --> Total execution time: 4.6673
INFO - 2016-12-01 15:58:26 --> Config Class Initialized
INFO - 2016-12-01 15:58:26 --> Hooks Class Initialized
DEBUG - 2016-12-01 15:58:26 --> UTF-8 Support Enabled
INFO - 2016-12-01 15:58:26 --> Utf8 Class Initialized
INFO - 2016-12-01 15:58:26 --> URI Class Initialized
DEBUG - 2016-12-01 15:58:26 --> No URI present. Default controller set.
INFO - 2016-12-01 15:58:26 --> Router Class Initialized
INFO - 2016-12-01 15:58:26 --> Output Class Initialized
INFO - 2016-12-01 15:58:26 --> Security Class Initialized
DEBUG - 2016-12-01 15:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 15:58:26 --> Input Class Initialized
INFO - 2016-12-01 15:58:26 --> Language Class Initialized
INFO - 2016-12-01 15:58:26 --> Loader Class Initialized
INFO - 2016-12-01 15:58:26 --> Helper loaded: url_helper
INFO - 2016-12-01 15:58:26 --> Helper loaded: form_helper
INFO - 2016-12-01 15:58:27 --> Database Driver Class Initialized
INFO - 2016-12-01 15:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 15:58:27 --> Controller Class Initialized
INFO - 2016-12-01 15:58:27 --> Model Class Initialized
INFO - 2016-12-01 15:58:27 --> Model Class Initialized
INFO - 2016-12-01 15:58:27 --> Model Class Initialized
INFO - 2016-12-01 15:58:27 --> Model Class Initialized
INFO - 2016-12-01 15:58:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 15:58:27 --> Pagination Class Initialized
INFO - 2016-12-01 15:58:27 --> Helper loaded: app_helper
INFO - 2016-12-01 15:58:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 15:58:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 15:58:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 15:58:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 15:58:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 15:58:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 15:58:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 15:58:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 15:58:27 --> Final output sent to browser
DEBUG - 2016-12-01 15:58:27 --> Total execution time: 0.4314
INFO - 2016-12-01 15:59:38 --> Config Class Initialized
INFO - 2016-12-01 15:59:38 --> Hooks Class Initialized
DEBUG - 2016-12-01 15:59:38 --> UTF-8 Support Enabled
INFO - 2016-12-01 15:59:38 --> Utf8 Class Initialized
INFO - 2016-12-01 15:59:38 --> URI Class Initialized
DEBUG - 2016-12-01 15:59:38 --> No URI present. Default controller set.
INFO - 2016-12-01 15:59:38 --> Router Class Initialized
INFO - 2016-12-01 15:59:38 --> Output Class Initialized
INFO - 2016-12-01 15:59:38 --> Security Class Initialized
DEBUG - 2016-12-01 15:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 15:59:38 --> Input Class Initialized
INFO - 2016-12-01 15:59:38 --> Language Class Initialized
INFO - 2016-12-01 15:59:38 --> Loader Class Initialized
INFO - 2016-12-01 15:59:38 --> Helper loaded: url_helper
INFO - 2016-12-01 15:59:38 --> Helper loaded: form_helper
INFO - 2016-12-01 15:59:39 --> Database Driver Class Initialized
INFO - 2016-12-01 15:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 15:59:39 --> Controller Class Initialized
INFO - 2016-12-01 15:59:39 --> Model Class Initialized
INFO - 2016-12-01 15:59:39 --> Model Class Initialized
INFO - 2016-12-01 15:59:39 --> Model Class Initialized
INFO - 2016-12-01 15:59:39 --> Model Class Initialized
INFO - 2016-12-01 15:59:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 15:59:39 --> Pagination Class Initialized
INFO - 2016-12-01 15:59:39 --> Helper loaded: app_helper
INFO - 2016-12-01 15:59:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 15:59:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 15:59:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 15:59:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 15:59:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 15:59:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 15:59:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 15:59:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 15:59:39 --> Final output sent to browser
DEBUG - 2016-12-01 15:59:39 --> Total execution time: 0.4015
INFO - 2016-12-01 15:59:56 --> Config Class Initialized
INFO - 2016-12-01 15:59:56 --> Hooks Class Initialized
DEBUG - 2016-12-01 15:59:56 --> UTF-8 Support Enabled
INFO - 2016-12-01 15:59:56 --> Utf8 Class Initialized
INFO - 2016-12-01 15:59:56 --> URI Class Initialized
INFO - 2016-12-01 15:59:56 --> Router Class Initialized
INFO - 2016-12-01 15:59:56 --> Output Class Initialized
INFO - 2016-12-01 15:59:56 --> Security Class Initialized
DEBUG - 2016-12-01 15:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 15:59:56 --> Input Class Initialized
INFO - 2016-12-01 15:59:56 --> Language Class Initialized
INFO - 2016-12-01 15:59:56 --> Loader Class Initialized
INFO - 2016-12-01 15:59:56 --> Helper loaded: url_helper
INFO - 2016-12-01 15:59:56 --> Helper loaded: form_helper
INFO - 2016-12-01 15:59:56 --> Database Driver Class Initialized
INFO - 2016-12-01 15:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 15:59:56 --> Controller Class Initialized
INFO - 2016-12-01 15:59:56 --> Model Class Initialized
INFO - 2016-12-01 15:59:56 --> Form Validation Class Initialized
INFO - 2016-12-01 15:59:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 15:59:56 --> Pagination Class Initialized
INFO - 2016-12-01 15:59:56 --> Helper loaded: app_helper
INFO - 2016-12-01 15:59:56 --> Email Class Initialized
INFO - 2016-12-01 15:59:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 14:59:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 14:59:56 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-12-01 14:59:58 --> Severity: Warning --> fsockopen(): unable to connect to localhost:465 (No connection could be made because the target machine actively refused it.
) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-12-01 14:59:58 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 14:59:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
ERROR - 2016-12-01 15:00:00 --> Severity: Warning --> fsockopen(): unable to connect to localhost:465 (No connection could be made because the target machine actively refused it.
) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-12-01 15:00:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 15:00:01 --> Final output sent to browser
DEBUG - 2016-12-01 15:00:01 --> Total execution time: 4.7304
INFO - 2016-12-01 16:11:59 --> Config Class Initialized
INFO - 2016-12-01 16:11:59 --> Hooks Class Initialized
DEBUG - 2016-12-01 16:11:59 --> UTF-8 Support Enabled
INFO - 2016-12-01 16:11:59 --> Utf8 Class Initialized
INFO - 2016-12-01 16:11:59 --> URI Class Initialized
DEBUG - 2016-12-01 16:11:59 --> No URI present. Default controller set.
INFO - 2016-12-01 16:11:59 --> Router Class Initialized
INFO - 2016-12-01 16:11:59 --> Output Class Initialized
INFO - 2016-12-01 16:11:59 --> Security Class Initialized
DEBUG - 2016-12-01 16:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 16:11:59 --> Input Class Initialized
INFO - 2016-12-01 16:11:59 --> Language Class Initialized
INFO - 2016-12-01 16:11:59 --> Loader Class Initialized
INFO - 2016-12-01 16:11:59 --> Helper loaded: url_helper
INFO - 2016-12-01 16:11:59 --> Helper loaded: form_helper
INFO - 2016-12-01 16:11:59 --> Database Driver Class Initialized
INFO - 2016-12-01 16:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 16:11:59 --> Controller Class Initialized
INFO - 2016-12-01 16:11:59 --> Model Class Initialized
INFO - 2016-12-01 16:11:59 --> Model Class Initialized
INFO - 2016-12-01 16:11:59 --> Model Class Initialized
INFO - 2016-12-01 16:11:59 --> Model Class Initialized
INFO - 2016-12-01 16:11:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 16:11:59 --> Pagination Class Initialized
INFO - 2016-12-01 16:11:59 --> Helper loaded: app_helper
INFO - 2016-12-01 16:11:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 16:11:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 16:11:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 16:11:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 16:11:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 16:11:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 16:11:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 16:11:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 16:11:59 --> Final output sent to browser
DEBUG - 2016-12-01 16:11:59 --> Total execution time: 0.4814
INFO - 2016-12-01 16:12:12 --> Config Class Initialized
INFO - 2016-12-01 16:12:12 --> Hooks Class Initialized
DEBUG - 2016-12-01 16:12:12 --> UTF-8 Support Enabled
INFO - 2016-12-01 16:12:12 --> Utf8 Class Initialized
INFO - 2016-12-01 16:12:12 --> URI Class Initialized
INFO - 2016-12-01 16:12:12 --> Router Class Initialized
INFO - 2016-12-01 16:12:12 --> Output Class Initialized
INFO - 2016-12-01 16:12:12 --> Security Class Initialized
DEBUG - 2016-12-01 16:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 16:12:12 --> Input Class Initialized
INFO - 2016-12-01 16:12:12 --> Language Class Initialized
INFO - 2016-12-01 16:12:12 --> Loader Class Initialized
INFO - 2016-12-01 16:12:12 --> Helper loaded: url_helper
INFO - 2016-12-01 16:12:12 --> Helper loaded: form_helper
INFO - 2016-12-01 16:12:12 --> Database Driver Class Initialized
INFO - 2016-12-01 16:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 16:12:13 --> Controller Class Initialized
INFO - 2016-12-01 16:12:13 --> Model Class Initialized
INFO - 2016-12-01 16:12:13 --> Form Validation Class Initialized
INFO - 2016-12-01 16:12:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 16:12:13 --> Pagination Class Initialized
INFO - 2016-12-01 16:12:13 --> Helper loaded: app_helper
INFO - 2016-12-01 16:12:13 --> Email Class Initialized
INFO - 2016-12-01 16:12:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 15:12:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 15:12:13 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 15:12:13 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 15:12:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 15:12:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 15:12:14 --> Final output sent to browser
DEBUG - 2016-12-01 15:12:14 --> Total execution time: 1.8973
INFO - 2016-12-01 16:27:32 --> Config Class Initialized
INFO - 2016-12-01 16:27:32 --> Hooks Class Initialized
DEBUG - 2016-12-01 16:27:32 --> UTF-8 Support Enabled
INFO - 2016-12-01 16:27:32 --> Utf8 Class Initialized
INFO - 2016-12-01 16:27:32 --> URI Class Initialized
INFO - 2016-12-01 16:27:32 --> Router Class Initialized
INFO - 2016-12-01 16:27:32 --> Output Class Initialized
INFO - 2016-12-01 16:27:32 --> Security Class Initialized
DEBUG - 2016-12-01 16:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 16:27:33 --> Input Class Initialized
INFO - 2016-12-01 16:27:33 --> Language Class Initialized
INFO - 2016-12-01 16:27:33 --> Loader Class Initialized
INFO - 2016-12-01 16:27:33 --> Helper loaded: url_helper
INFO - 2016-12-01 16:27:33 --> Helper loaded: form_helper
INFO - 2016-12-01 16:27:33 --> Database Driver Class Initialized
INFO - 2016-12-01 16:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 16:27:33 --> Controller Class Initialized
INFO - 2016-12-01 16:27:33 --> Model Class Initialized
INFO - 2016-12-01 16:27:33 --> Form Validation Class Initialized
INFO - 2016-12-01 16:27:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 16:27:33 --> Pagination Class Initialized
INFO - 2016-12-01 16:27:33 --> Helper loaded: app_helper
INFO - 2016-12-01 16:27:33 --> Email Class Initialized
INFO - 2016-12-01 16:27:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 15:27:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 15:27:33 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 15:27:33 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 15:27:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 15:27:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 15:27:34 --> Final output sent to browser
DEBUG - 2016-12-01 15:27:34 --> Total execution time: 1.6494
INFO - 2016-12-01 16:41:25 --> Config Class Initialized
INFO - 2016-12-01 16:41:25 --> Hooks Class Initialized
DEBUG - 2016-12-01 16:41:25 --> UTF-8 Support Enabled
INFO - 2016-12-01 16:41:25 --> Utf8 Class Initialized
INFO - 2016-12-01 16:41:25 --> URI Class Initialized
DEBUG - 2016-12-01 16:41:25 --> No URI present. Default controller set.
INFO - 2016-12-01 16:41:25 --> Router Class Initialized
INFO - 2016-12-01 16:41:25 --> Output Class Initialized
INFO - 2016-12-01 16:41:25 --> Security Class Initialized
DEBUG - 2016-12-01 16:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 16:41:25 --> Input Class Initialized
INFO - 2016-12-01 16:41:25 --> Language Class Initialized
INFO - 2016-12-01 16:41:25 --> Loader Class Initialized
INFO - 2016-12-01 16:41:26 --> Helper loaded: url_helper
INFO - 2016-12-01 16:41:26 --> Helper loaded: form_helper
INFO - 2016-12-01 16:41:26 --> Database Driver Class Initialized
INFO - 2016-12-01 16:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 16:41:26 --> Controller Class Initialized
INFO - 2016-12-01 16:41:26 --> Model Class Initialized
INFO - 2016-12-01 16:41:26 --> Model Class Initialized
INFO - 2016-12-01 16:41:26 --> Model Class Initialized
INFO - 2016-12-01 16:41:26 --> Model Class Initialized
INFO - 2016-12-01 16:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 16:41:26 --> Pagination Class Initialized
INFO - 2016-12-01 16:41:26 --> Helper loaded: app_helper
INFO - 2016-12-01 16:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 16:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 16:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 16:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 16:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 16:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 16:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 16:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 16:41:26 --> Final output sent to browser
DEBUG - 2016-12-01 16:41:26 --> Total execution time: 0.5435
INFO - 2016-12-01 16:41:58 --> Config Class Initialized
INFO - 2016-12-01 16:41:58 --> Hooks Class Initialized
DEBUG - 2016-12-01 16:41:58 --> UTF-8 Support Enabled
INFO - 2016-12-01 16:41:58 --> Utf8 Class Initialized
INFO - 2016-12-01 16:41:58 --> URI Class Initialized
INFO - 2016-12-01 16:41:58 --> Router Class Initialized
INFO - 2016-12-01 16:41:58 --> Output Class Initialized
INFO - 2016-12-01 16:41:58 --> Security Class Initialized
DEBUG - 2016-12-01 16:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 16:41:58 --> Input Class Initialized
INFO - 2016-12-01 16:41:58 --> Language Class Initialized
INFO - 2016-12-01 16:41:58 --> Loader Class Initialized
INFO - 2016-12-01 16:41:59 --> Helper loaded: url_helper
INFO - 2016-12-01 16:41:59 --> Helper loaded: form_helper
INFO - 2016-12-01 16:41:59 --> Database Driver Class Initialized
INFO - 2016-12-01 16:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 16:41:59 --> Controller Class Initialized
INFO - 2016-12-01 16:41:59 --> Model Class Initialized
INFO - 2016-12-01 16:41:59 --> Form Validation Class Initialized
INFO - 2016-12-01 16:41:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 16:41:59 --> Pagination Class Initialized
INFO - 2016-12-01 16:41:59 --> Helper loaded: app_helper
INFO - 2016-12-01 16:41:59 --> Email Class Initialized
INFO - 2016-12-01 16:41:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 15:41:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 15:41:59 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 15:41:59 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 15:42:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 15:42:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 15:42:00 --> Final output sent to browser
DEBUG - 2016-12-01 15:42:00 --> Total execution time: 1.7741
INFO - 2016-12-01 16:42:34 --> Config Class Initialized
INFO - 2016-12-01 16:42:34 --> Hooks Class Initialized
DEBUG - 2016-12-01 16:42:34 --> UTF-8 Support Enabled
INFO - 2016-12-01 16:42:34 --> Utf8 Class Initialized
INFO - 2016-12-01 16:42:34 --> URI Class Initialized
DEBUG - 2016-12-01 16:42:34 --> No URI present. Default controller set.
INFO - 2016-12-01 16:42:34 --> Router Class Initialized
INFO - 2016-12-01 16:42:34 --> Output Class Initialized
INFO - 2016-12-01 16:42:34 --> Security Class Initialized
DEBUG - 2016-12-01 16:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 16:42:34 --> Input Class Initialized
INFO - 2016-12-01 16:42:34 --> Language Class Initialized
INFO - 2016-12-01 16:42:34 --> Loader Class Initialized
INFO - 2016-12-01 16:42:34 --> Helper loaded: url_helper
INFO - 2016-12-01 16:42:34 --> Helper loaded: form_helper
INFO - 2016-12-01 16:42:34 --> Database Driver Class Initialized
INFO - 2016-12-01 16:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 16:42:34 --> Controller Class Initialized
INFO - 2016-12-01 16:42:34 --> Model Class Initialized
INFO - 2016-12-01 16:42:34 --> Model Class Initialized
INFO - 2016-12-01 16:42:34 --> Model Class Initialized
INFO - 2016-12-01 16:42:34 --> Model Class Initialized
INFO - 2016-12-01 16:42:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 16:42:34 --> Pagination Class Initialized
INFO - 2016-12-01 16:42:34 --> Helper loaded: app_helper
INFO - 2016-12-01 16:42:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 16:42:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 16:42:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 16:42:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 16:42:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 16:42:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 16:42:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 16:42:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 16:42:34 --> Final output sent to browser
DEBUG - 2016-12-01 16:42:34 --> Total execution time: 0.4378
INFO - 2016-12-01 16:43:47 --> Config Class Initialized
INFO - 2016-12-01 16:43:47 --> Hooks Class Initialized
DEBUG - 2016-12-01 16:43:47 --> UTF-8 Support Enabled
INFO - 2016-12-01 16:43:47 --> Utf8 Class Initialized
INFO - 2016-12-01 16:43:47 --> URI Class Initialized
DEBUG - 2016-12-01 16:43:47 --> No URI present. Default controller set.
INFO - 2016-12-01 16:43:47 --> Router Class Initialized
INFO - 2016-12-01 16:43:47 --> Output Class Initialized
INFO - 2016-12-01 16:43:47 --> Security Class Initialized
DEBUG - 2016-12-01 16:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 16:43:47 --> Input Class Initialized
INFO - 2016-12-01 16:43:47 --> Language Class Initialized
INFO - 2016-12-01 16:43:47 --> Loader Class Initialized
INFO - 2016-12-01 16:43:47 --> Helper loaded: url_helper
INFO - 2016-12-01 16:43:47 --> Helper loaded: form_helper
INFO - 2016-12-01 16:43:47 --> Database Driver Class Initialized
INFO - 2016-12-01 16:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 16:43:47 --> Controller Class Initialized
INFO - 2016-12-01 16:43:47 --> Model Class Initialized
INFO - 2016-12-01 16:43:47 --> Model Class Initialized
INFO - 2016-12-01 16:43:47 --> Model Class Initialized
INFO - 2016-12-01 16:43:47 --> Model Class Initialized
INFO - 2016-12-01 16:43:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 16:43:47 --> Pagination Class Initialized
INFO - 2016-12-01 16:43:47 --> Helper loaded: app_helper
INFO - 2016-12-01 16:43:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 16:43:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 16:43:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 16:43:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 16:43:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 16:43:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 16:43:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 16:43:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 16:43:47 --> Final output sent to browser
DEBUG - 2016-12-01 16:43:47 --> Total execution time: 0.4371
INFO - 2016-12-01 16:43:55 --> Config Class Initialized
INFO - 2016-12-01 16:43:55 --> Hooks Class Initialized
DEBUG - 2016-12-01 16:43:55 --> UTF-8 Support Enabled
INFO - 2016-12-01 16:43:55 --> Utf8 Class Initialized
INFO - 2016-12-01 16:43:55 --> URI Class Initialized
INFO - 2016-12-01 16:43:55 --> Router Class Initialized
INFO - 2016-12-01 16:43:55 --> Output Class Initialized
INFO - 2016-12-01 16:43:55 --> Security Class Initialized
DEBUG - 2016-12-01 16:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 16:43:55 --> Input Class Initialized
INFO - 2016-12-01 16:43:55 --> Language Class Initialized
INFO - 2016-12-01 16:43:55 --> Loader Class Initialized
INFO - 2016-12-01 16:43:55 --> Helper loaded: url_helper
INFO - 2016-12-01 16:43:55 --> Helper loaded: form_helper
INFO - 2016-12-01 16:43:55 --> Database Driver Class Initialized
INFO - 2016-12-01 16:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 16:43:55 --> Controller Class Initialized
INFO - 2016-12-01 16:43:55 --> Model Class Initialized
INFO - 2016-12-01 16:43:55 --> Form Validation Class Initialized
INFO - 2016-12-01 16:43:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 16:43:55 --> Pagination Class Initialized
INFO - 2016-12-01 16:43:55 --> Helper loaded: app_helper
INFO - 2016-12-01 16:43:55 --> Email Class Initialized
INFO - 2016-12-01 16:43:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 15:43:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 15:43:56 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 15:43:56 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 15:43:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 15:43:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 15:43:57 --> Final output sent to browser
DEBUG - 2016-12-01 15:43:58 --> Total execution time: 2.3432
INFO - 2016-12-01 16:46:56 --> Config Class Initialized
INFO - 2016-12-01 16:46:56 --> Hooks Class Initialized
DEBUG - 2016-12-01 16:46:56 --> UTF-8 Support Enabled
INFO - 2016-12-01 16:46:56 --> Utf8 Class Initialized
INFO - 2016-12-01 16:46:56 --> URI Class Initialized
DEBUG - 2016-12-01 16:46:56 --> No URI present. Default controller set.
INFO - 2016-12-01 16:46:56 --> Router Class Initialized
INFO - 2016-12-01 16:46:56 --> Output Class Initialized
INFO - 2016-12-01 16:46:56 --> Security Class Initialized
DEBUG - 2016-12-01 16:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 16:46:56 --> Input Class Initialized
INFO - 2016-12-01 16:46:56 --> Language Class Initialized
INFO - 2016-12-01 16:46:56 --> Loader Class Initialized
INFO - 2016-12-01 16:46:56 --> Helper loaded: url_helper
INFO - 2016-12-01 16:46:56 --> Helper loaded: form_helper
INFO - 2016-12-01 16:46:56 --> Database Driver Class Initialized
INFO - 2016-12-01 16:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 16:46:56 --> Controller Class Initialized
INFO - 2016-12-01 16:46:56 --> Model Class Initialized
INFO - 2016-12-01 16:46:56 --> Model Class Initialized
INFO - 2016-12-01 16:46:56 --> Model Class Initialized
INFO - 2016-12-01 16:46:56 --> Model Class Initialized
INFO - 2016-12-01 16:46:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 16:46:56 --> Pagination Class Initialized
INFO - 2016-12-01 16:46:56 --> Helper loaded: app_helper
INFO - 2016-12-01 16:46:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 16:46:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 16:46:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 16:46:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 16:46:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 16:46:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 16:46:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 16:46:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 16:46:56 --> Final output sent to browser
DEBUG - 2016-12-01 16:46:56 --> Total execution time: 0.4979
INFO - 2016-12-01 16:48:06 --> Config Class Initialized
INFO - 2016-12-01 16:48:06 --> Hooks Class Initialized
DEBUG - 2016-12-01 16:48:06 --> UTF-8 Support Enabled
INFO - 2016-12-01 16:48:06 --> Utf8 Class Initialized
INFO - 2016-12-01 16:48:06 --> URI Class Initialized
INFO - 2016-12-01 16:48:06 --> Router Class Initialized
INFO - 2016-12-01 16:48:06 --> Output Class Initialized
INFO - 2016-12-01 16:48:06 --> Security Class Initialized
DEBUG - 2016-12-01 16:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 16:48:06 --> Input Class Initialized
INFO - 2016-12-01 16:48:06 --> Language Class Initialized
INFO - 2016-12-01 16:48:06 --> Loader Class Initialized
INFO - 2016-12-01 16:48:06 --> Helper loaded: url_helper
INFO - 2016-12-01 16:48:06 --> Helper loaded: form_helper
INFO - 2016-12-01 16:48:06 --> Database Driver Class Initialized
INFO - 2016-12-01 16:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 16:48:07 --> Controller Class Initialized
INFO - 2016-12-01 16:48:07 --> Model Class Initialized
INFO - 2016-12-01 16:48:07 --> Form Validation Class Initialized
INFO - 2016-12-01 16:48:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 16:48:07 --> Pagination Class Initialized
INFO - 2016-12-01 16:48:07 --> Helper loaded: app_helper
INFO - 2016-12-01 16:48:07 --> Email Class Initialized
INFO - 2016-12-01 16:48:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 15:48:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 15:48:07 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 15:48:07 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 15:48:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 15:48:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 15:48:08 --> Final output sent to browser
DEBUG - 2016-12-01 15:48:08 --> Total execution time: 1.7481
INFO - 2016-12-01 16:49:48 --> Config Class Initialized
INFO - 2016-12-01 16:49:48 --> Hooks Class Initialized
DEBUG - 2016-12-01 16:49:48 --> UTF-8 Support Enabled
INFO - 2016-12-01 16:49:48 --> Utf8 Class Initialized
INFO - 2016-12-01 16:49:48 --> URI Class Initialized
DEBUG - 2016-12-01 16:49:48 --> No URI present. Default controller set.
INFO - 2016-12-01 16:49:48 --> Router Class Initialized
INFO - 2016-12-01 16:49:48 --> Output Class Initialized
INFO - 2016-12-01 16:49:48 --> Security Class Initialized
DEBUG - 2016-12-01 16:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 16:49:48 --> Input Class Initialized
INFO - 2016-12-01 16:49:48 --> Language Class Initialized
INFO - 2016-12-01 16:49:48 --> Loader Class Initialized
INFO - 2016-12-01 16:49:48 --> Helper loaded: url_helper
INFO - 2016-12-01 16:49:48 --> Helper loaded: form_helper
INFO - 2016-12-01 16:49:48 --> Database Driver Class Initialized
INFO - 2016-12-01 16:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 16:49:48 --> Controller Class Initialized
INFO - 2016-12-01 16:49:48 --> Model Class Initialized
INFO - 2016-12-01 16:49:48 --> Model Class Initialized
INFO - 2016-12-01 16:49:48 --> Model Class Initialized
INFO - 2016-12-01 16:49:48 --> Model Class Initialized
INFO - 2016-12-01 16:49:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 16:49:48 --> Pagination Class Initialized
INFO - 2016-12-01 16:49:48 --> Helper loaded: app_helper
INFO - 2016-12-01 16:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 16:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 16:49:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 16:49:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 16:49:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 16:49:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 16:49:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 16:49:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 16:49:49 --> Final output sent to browser
DEBUG - 2016-12-01 16:49:49 --> Total execution time: 0.4313
INFO - 2016-12-01 16:49:58 --> Config Class Initialized
INFO - 2016-12-01 16:49:58 --> Hooks Class Initialized
DEBUG - 2016-12-01 16:49:58 --> UTF-8 Support Enabled
INFO - 2016-12-01 16:49:58 --> Utf8 Class Initialized
INFO - 2016-12-01 16:49:58 --> URI Class Initialized
INFO - 2016-12-01 16:49:58 --> Router Class Initialized
INFO - 2016-12-01 16:49:58 --> Output Class Initialized
INFO - 2016-12-01 16:49:58 --> Security Class Initialized
DEBUG - 2016-12-01 16:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 16:49:58 --> Input Class Initialized
INFO - 2016-12-01 16:49:58 --> Language Class Initialized
INFO - 2016-12-01 16:49:58 --> Loader Class Initialized
INFO - 2016-12-01 16:49:58 --> Helper loaded: url_helper
INFO - 2016-12-01 16:49:58 --> Helper loaded: form_helper
INFO - 2016-12-01 16:49:58 --> Database Driver Class Initialized
INFO - 2016-12-01 16:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 16:49:58 --> Controller Class Initialized
INFO - 2016-12-01 16:49:58 --> Model Class Initialized
INFO - 2016-12-01 16:49:58 --> Form Validation Class Initialized
INFO - 2016-12-01 16:49:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 16:49:58 --> Pagination Class Initialized
INFO - 2016-12-01 16:49:58 --> Helper loaded: app_helper
INFO - 2016-12-01 16:49:58 --> Email Class Initialized
INFO - 2016-12-01 16:49:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 15:49:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 15:49:58 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 15:49:59 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 15:49:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 15:50:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 15:50:00 --> Final output sent to browser
DEBUG - 2016-12-01 15:50:00 --> Total execution time: 1.9388
INFO - 2016-12-01 19:17:55 --> Config Class Initialized
INFO - 2016-12-01 19:17:55 --> Hooks Class Initialized
DEBUG - 2016-12-01 19:17:55 --> UTF-8 Support Enabled
INFO - 2016-12-01 19:17:55 --> Utf8 Class Initialized
INFO - 2016-12-01 19:17:55 --> URI Class Initialized
DEBUG - 2016-12-01 19:17:55 --> No URI present. Default controller set.
INFO - 2016-12-01 19:17:55 --> Router Class Initialized
INFO - 2016-12-01 19:17:55 --> Output Class Initialized
INFO - 2016-12-01 19:17:55 --> Security Class Initialized
DEBUG - 2016-12-01 19:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 19:17:55 --> Input Class Initialized
INFO - 2016-12-01 19:17:55 --> Language Class Initialized
INFO - 2016-12-01 19:17:55 --> Loader Class Initialized
INFO - 2016-12-01 19:17:55 --> Helper loaded: url_helper
INFO - 2016-12-01 19:17:56 --> Helper loaded: form_helper
INFO - 2016-12-01 19:17:56 --> Database Driver Class Initialized
INFO - 2016-12-01 19:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 19:17:56 --> Controller Class Initialized
INFO - 2016-12-01 19:17:56 --> Model Class Initialized
INFO - 2016-12-01 19:17:56 --> Model Class Initialized
INFO - 2016-12-01 19:17:56 --> Model Class Initialized
INFO - 2016-12-01 19:17:56 --> Model Class Initialized
INFO - 2016-12-01 19:17:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 19:17:56 --> Pagination Class Initialized
INFO - 2016-12-01 19:17:56 --> Helper loaded: app_helper
INFO - 2016-12-01 19:17:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 19:17:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-01 19:17:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 19:17:56 --> Final output sent to browser
DEBUG - 2016-12-01 19:17:56 --> Total execution time: 1.7902
INFO - 2016-12-01 19:18:22 --> Config Class Initialized
INFO - 2016-12-01 19:18:22 --> Hooks Class Initialized
DEBUG - 2016-12-01 19:18:22 --> UTF-8 Support Enabled
INFO - 2016-12-01 19:18:22 --> Utf8 Class Initialized
INFO - 2016-12-01 19:18:22 --> URI Class Initialized
INFO - 2016-12-01 19:18:22 --> Router Class Initialized
INFO - 2016-12-01 19:18:22 --> Output Class Initialized
INFO - 2016-12-01 19:18:22 --> Security Class Initialized
DEBUG - 2016-12-01 19:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 19:18:22 --> Input Class Initialized
INFO - 2016-12-01 19:18:22 --> Language Class Initialized
INFO - 2016-12-01 19:18:22 --> Loader Class Initialized
INFO - 2016-12-01 19:18:22 --> Helper loaded: url_helper
INFO - 2016-12-01 19:18:22 --> Helper loaded: form_helper
INFO - 2016-12-01 19:18:22 --> Database Driver Class Initialized
INFO - 2016-12-01 19:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 19:18:22 --> Controller Class Initialized
INFO - 2016-12-01 19:18:22 --> Model Class Initialized
INFO - 2016-12-01 19:18:22 --> Model Class Initialized
INFO - 2016-12-01 19:18:22 --> Model Class Initialized
INFO - 2016-12-01 19:18:22 --> Model Class Initialized
INFO - 2016-12-01 19:18:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 19:18:22 --> Pagination Class Initialized
INFO - 2016-12-01 19:18:22 --> Helper loaded: app_helper
DEBUG - 2016-12-01 19:18:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 19:18:22 --> Model Class Initialized
INFO - 2016-12-01 19:18:22 --> Final output sent to browser
DEBUG - 2016-12-01 19:18:23 --> Total execution time: 0.4663
INFO - 2016-12-01 19:18:23 --> Config Class Initialized
INFO - 2016-12-01 19:18:23 --> Hooks Class Initialized
DEBUG - 2016-12-01 19:18:23 --> UTF-8 Support Enabled
INFO - 2016-12-01 19:18:23 --> Utf8 Class Initialized
INFO - 2016-12-01 19:18:23 --> URI Class Initialized
DEBUG - 2016-12-01 19:18:23 --> No URI present. Default controller set.
INFO - 2016-12-01 19:18:23 --> Router Class Initialized
INFO - 2016-12-01 19:18:23 --> Output Class Initialized
INFO - 2016-12-01 19:18:23 --> Security Class Initialized
DEBUG - 2016-12-01 19:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 19:18:23 --> Input Class Initialized
INFO - 2016-12-01 19:18:23 --> Language Class Initialized
INFO - 2016-12-01 19:18:23 --> Loader Class Initialized
INFO - 2016-12-01 19:18:23 --> Helper loaded: url_helper
INFO - 2016-12-01 19:18:23 --> Helper loaded: form_helper
INFO - 2016-12-01 19:18:23 --> Database Driver Class Initialized
INFO - 2016-12-01 19:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 19:18:23 --> Controller Class Initialized
INFO - 2016-12-01 19:18:23 --> Model Class Initialized
INFO - 2016-12-01 19:18:23 --> Model Class Initialized
INFO - 2016-12-01 19:18:23 --> Model Class Initialized
INFO - 2016-12-01 19:18:23 --> Model Class Initialized
INFO - 2016-12-01 19:18:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 19:18:23 --> Pagination Class Initialized
INFO - 2016-12-01 19:18:23 --> Helper loaded: app_helper
INFO - 2016-12-01 19:18:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 19:18:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 19:18:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 19:18:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 19:18:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 19:18:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 19:18:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 19:18:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 19:18:23 --> Final output sent to browser
DEBUG - 2016-12-01 19:18:23 --> Total execution time: 0.6981
INFO - 2016-12-01 19:19:02 --> Config Class Initialized
INFO - 2016-12-01 19:19:02 --> Hooks Class Initialized
DEBUG - 2016-12-01 19:19:02 --> UTF-8 Support Enabled
INFO - 2016-12-01 19:19:02 --> Utf8 Class Initialized
INFO - 2016-12-01 19:19:02 --> URI Class Initialized
DEBUG - 2016-12-01 19:19:02 --> No URI present. Default controller set.
INFO - 2016-12-01 19:19:02 --> Router Class Initialized
INFO - 2016-12-01 19:19:02 --> Output Class Initialized
INFO - 2016-12-01 19:19:02 --> Security Class Initialized
DEBUG - 2016-12-01 19:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 19:19:02 --> Input Class Initialized
INFO - 2016-12-01 19:19:02 --> Language Class Initialized
INFO - 2016-12-01 19:19:02 --> Loader Class Initialized
INFO - 2016-12-01 19:19:02 --> Helper loaded: url_helper
INFO - 2016-12-01 19:19:02 --> Helper loaded: form_helper
INFO - 2016-12-01 19:19:02 --> Database Driver Class Initialized
INFO - 2016-12-01 19:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 19:19:02 --> Controller Class Initialized
INFO - 2016-12-01 19:19:02 --> Model Class Initialized
INFO - 2016-12-01 19:19:02 --> Model Class Initialized
INFO - 2016-12-01 19:19:02 --> Model Class Initialized
INFO - 2016-12-01 19:19:02 --> Model Class Initialized
INFO - 2016-12-01 19:19:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 19:19:02 --> Pagination Class Initialized
INFO - 2016-12-01 19:19:02 --> Helper loaded: app_helper
INFO - 2016-12-01 19:19:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 19:19:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 19:19:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 19:19:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 19:19:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 19:19:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 19:19:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 19:19:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 19:19:02 --> Final output sent to browser
DEBUG - 2016-12-01 19:19:02 --> Total execution time: 0.4255
INFO - 2016-12-01 19:19:23 --> Config Class Initialized
INFO - 2016-12-01 19:19:23 --> Hooks Class Initialized
DEBUG - 2016-12-01 19:19:23 --> UTF-8 Support Enabled
INFO - 2016-12-01 19:19:23 --> Utf8 Class Initialized
INFO - 2016-12-01 19:19:23 --> URI Class Initialized
INFO - 2016-12-01 19:19:23 --> Router Class Initialized
INFO - 2016-12-01 19:19:23 --> Output Class Initialized
INFO - 2016-12-01 19:19:23 --> Security Class Initialized
DEBUG - 2016-12-01 19:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 19:19:23 --> Input Class Initialized
INFO - 2016-12-01 19:19:23 --> Language Class Initialized
INFO - 2016-12-01 19:19:23 --> Loader Class Initialized
INFO - 2016-12-01 19:19:23 --> Helper loaded: url_helper
INFO - 2016-12-01 19:19:23 --> Helper loaded: form_helper
INFO - 2016-12-01 19:19:23 --> Database Driver Class Initialized
INFO - 2016-12-01 19:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 19:19:23 --> Controller Class Initialized
INFO - 2016-12-01 19:19:23 --> Model Class Initialized
INFO - 2016-12-01 19:19:23 --> Form Validation Class Initialized
INFO - 2016-12-01 19:19:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 19:19:23 --> Pagination Class Initialized
INFO - 2016-12-01 19:19:23 --> Helper loaded: app_helper
INFO - 2016-12-01 19:19:23 --> Email Class Initialized
INFO - 2016-12-01 19:19:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 19:19:23 --> Final output sent to browser
DEBUG - 2016-12-01 19:19:23 --> Total execution time: 0.4717
INFO - 2016-12-01 19:19:34 --> Config Class Initialized
INFO - 2016-12-01 19:19:34 --> Hooks Class Initialized
DEBUG - 2016-12-01 19:19:34 --> UTF-8 Support Enabled
INFO - 2016-12-01 19:19:34 --> Utf8 Class Initialized
INFO - 2016-12-01 19:19:34 --> URI Class Initialized
INFO - 2016-12-01 19:19:34 --> Router Class Initialized
INFO - 2016-12-01 19:19:34 --> Output Class Initialized
INFO - 2016-12-01 19:19:34 --> Security Class Initialized
DEBUG - 2016-12-01 19:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 19:19:34 --> Input Class Initialized
INFO - 2016-12-01 19:19:34 --> Language Class Initialized
INFO - 2016-12-01 19:19:34 --> Loader Class Initialized
INFO - 2016-12-01 19:19:34 --> Helper loaded: url_helper
INFO - 2016-12-01 19:19:34 --> Helper loaded: form_helper
INFO - 2016-12-01 19:19:34 --> Database Driver Class Initialized
INFO - 2016-12-01 19:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 19:19:34 --> Controller Class Initialized
INFO - 2016-12-01 19:19:34 --> Model Class Initialized
INFO - 2016-12-01 19:19:34 --> Form Validation Class Initialized
INFO - 2016-12-01 19:19:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 19:19:34 --> Pagination Class Initialized
INFO - 2016-12-01 19:19:34 --> Helper loaded: app_helper
INFO - 2016-12-01 19:19:34 --> Email Class Initialized
INFO - 2016-12-01 19:19:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 18:19:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 18:19:34 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 18:19:44 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-12-01 18:20:19 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\LMS\sys\libraries\Email.php 2218
INFO - 2016-12-01 19:21:04 --> Config Class Initialized
INFO - 2016-12-01 19:21:04 --> Hooks Class Initialized
DEBUG - 2016-12-01 19:21:04 --> UTF-8 Support Enabled
INFO - 2016-12-01 19:21:04 --> Utf8 Class Initialized
INFO - 2016-12-01 19:21:04 --> URI Class Initialized
INFO - 2016-12-01 19:21:04 --> Router Class Initialized
INFO - 2016-12-01 19:21:04 --> Output Class Initialized
INFO - 2016-12-01 19:21:04 --> Security Class Initialized
DEBUG - 2016-12-01 19:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 19:21:04 --> Input Class Initialized
INFO - 2016-12-01 19:21:04 --> Language Class Initialized
INFO - 2016-12-01 19:21:04 --> Loader Class Initialized
INFO - 2016-12-01 19:21:04 --> Helper loaded: url_helper
INFO - 2016-12-01 19:21:04 --> Helper loaded: form_helper
INFO - 2016-12-01 19:21:04 --> Database Driver Class Initialized
INFO - 2016-12-01 19:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 19:21:04 --> Controller Class Initialized
INFO - 2016-12-01 19:21:04 --> Model Class Initialized
INFO - 2016-12-01 19:21:04 --> Form Validation Class Initialized
INFO - 2016-12-01 19:21:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 19:21:04 --> Pagination Class Initialized
INFO - 2016-12-01 19:21:04 --> Helper loaded: app_helper
INFO - 2016-12-01 19:21:04 --> Email Class Initialized
INFO - 2016-12-01 19:21:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 18:21:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 18:21:04 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 18:21:20 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 18:21:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 18:21:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 18:21:22 --> Final output sent to browser
DEBUG - 2016-12-01 18:21:22 --> Total execution time: 18.7409
INFO - 2016-12-01 19:40:33 --> Config Class Initialized
INFO - 2016-12-01 19:40:33 --> Hooks Class Initialized
DEBUG - 2016-12-01 19:40:33 --> UTF-8 Support Enabled
INFO - 2016-12-01 19:40:33 --> Utf8 Class Initialized
INFO - 2016-12-01 19:40:33 --> URI Class Initialized
DEBUG - 2016-12-01 19:40:33 --> No URI present. Default controller set.
INFO - 2016-12-01 19:40:33 --> Router Class Initialized
INFO - 2016-12-01 19:40:33 --> Output Class Initialized
INFO - 2016-12-01 19:40:33 --> Security Class Initialized
DEBUG - 2016-12-01 19:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 19:40:33 --> Input Class Initialized
INFO - 2016-12-01 19:40:33 --> Language Class Initialized
INFO - 2016-12-01 19:40:33 --> Loader Class Initialized
INFO - 2016-12-01 19:40:33 --> Helper loaded: url_helper
INFO - 2016-12-01 19:40:33 --> Helper loaded: form_helper
INFO - 2016-12-01 19:40:33 --> Database Driver Class Initialized
INFO - 2016-12-01 19:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 19:40:33 --> Controller Class Initialized
INFO - 2016-12-01 19:40:33 --> Model Class Initialized
INFO - 2016-12-01 19:40:33 --> Model Class Initialized
INFO - 2016-12-01 19:40:33 --> Model Class Initialized
INFO - 2016-12-01 19:40:33 --> Model Class Initialized
INFO - 2016-12-01 19:40:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 19:40:33 --> Pagination Class Initialized
INFO - 2016-12-01 19:40:33 --> Helper loaded: app_helper
INFO - 2016-12-01 19:40:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 19:40:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 19:40:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 19:40:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 19:40:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 19:40:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 19:40:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 19:40:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 19:40:33 --> Final output sent to browser
DEBUG - 2016-12-01 19:40:33 --> Total execution time: 0.5483
INFO - 2016-12-01 19:47:46 --> Config Class Initialized
INFO - 2016-12-01 19:47:46 --> Hooks Class Initialized
DEBUG - 2016-12-01 19:47:46 --> UTF-8 Support Enabled
INFO - 2016-12-01 19:47:46 --> Utf8 Class Initialized
INFO - 2016-12-01 19:47:46 --> URI Class Initialized
DEBUG - 2016-12-01 19:47:46 --> No URI present. Default controller set.
INFO - 2016-12-01 19:47:46 --> Router Class Initialized
INFO - 2016-12-01 19:47:46 --> Output Class Initialized
INFO - 2016-12-01 19:47:46 --> Security Class Initialized
DEBUG - 2016-12-01 19:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 19:47:46 --> Input Class Initialized
INFO - 2016-12-01 19:47:46 --> Language Class Initialized
INFO - 2016-12-01 19:47:46 --> Loader Class Initialized
INFO - 2016-12-01 19:47:46 --> Helper loaded: url_helper
INFO - 2016-12-01 19:47:46 --> Helper loaded: form_helper
INFO - 2016-12-01 19:47:46 --> Database Driver Class Initialized
INFO - 2016-12-01 19:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 19:47:46 --> Controller Class Initialized
INFO - 2016-12-01 19:47:46 --> Model Class Initialized
INFO - 2016-12-01 19:47:46 --> Model Class Initialized
INFO - 2016-12-01 19:47:46 --> Model Class Initialized
INFO - 2016-12-01 19:47:46 --> Model Class Initialized
INFO - 2016-12-01 19:47:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 19:47:46 --> Pagination Class Initialized
INFO - 2016-12-01 19:47:46 --> Helper loaded: app_helper
INFO - 2016-12-01 19:47:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 19:47:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 19:47:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 19:47:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 19:47:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 19:47:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 19:47:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 19:47:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 19:47:47 --> Final output sent to browser
DEBUG - 2016-12-01 19:47:47 --> Total execution time: 0.7971
INFO - 2016-12-01 19:48:37 --> Config Class Initialized
INFO - 2016-12-01 19:48:38 --> Hooks Class Initialized
DEBUG - 2016-12-01 19:48:38 --> UTF-8 Support Enabled
INFO - 2016-12-01 19:48:38 --> Utf8 Class Initialized
INFO - 2016-12-01 19:48:38 --> URI Class Initialized
INFO - 2016-12-01 19:48:38 --> Router Class Initialized
INFO - 2016-12-01 19:48:38 --> Output Class Initialized
INFO - 2016-12-01 19:48:38 --> Security Class Initialized
DEBUG - 2016-12-01 19:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 19:48:38 --> Input Class Initialized
INFO - 2016-12-01 19:48:38 --> Language Class Initialized
INFO - 2016-12-01 19:48:38 --> Loader Class Initialized
INFO - 2016-12-01 19:48:38 --> Helper loaded: url_helper
INFO - 2016-12-01 19:48:38 --> Helper loaded: form_helper
INFO - 2016-12-01 19:48:38 --> Database Driver Class Initialized
INFO - 2016-12-01 19:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 19:48:38 --> Controller Class Initialized
INFO - 2016-12-01 19:48:38 --> Model Class Initialized
INFO - 2016-12-01 19:48:38 --> Form Validation Class Initialized
INFO - 2016-12-01 19:48:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 19:48:38 --> Pagination Class Initialized
INFO - 2016-12-01 19:48:38 --> Helper loaded: app_helper
INFO - 2016-12-01 19:48:38 --> Email Class Initialized
INFO - 2016-12-01 19:48:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 18:48:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 18:48:38 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-12-01 18:49:00 --> Severity: Warning --> fsockopen(): SSL: The operation completed successfully.
 C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-12-01 18:49:00 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-12-01 18:49:00 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.googlemail.com:465 (Unknown error) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-12-01 18:49:00 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 18:49:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
ERROR - 2016-12-01 18:49:22 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\LMS\sys\core\Common.php 599
INFO - 2016-12-01 19:53:12 --> Config Class Initialized
INFO - 2016-12-01 19:53:13 --> Hooks Class Initialized
DEBUG - 2016-12-01 19:53:13 --> UTF-8 Support Enabled
INFO - 2016-12-01 19:53:13 --> Utf8 Class Initialized
INFO - 2016-12-01 19:53:13 --> URI Class Initialized
INFO - 2016-12-01 19:53:13 --> Router Class Initialized
INFO - 2016-12-01 19:53:13 --> Output Class Initialized
INFO - 2016-12-01 19:53:13 --> Security Class Initialized
DEBUG - 2016-12-01 19:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 19:53:13 --> Input Class Initialized
INFO - 2016-12-01 19:53:13 --> Language Class Initialized
INFO - 2016-12-01 19:53:13 --> Loader Class Initialized
INFO - 2016-12-01 19:53:13 --> Helper loaded: url_helper
INFO - 2016-12-01 19:53:13 --> Helper loaded: form_helper
INFO - 2016-12-01 19:53:13 --> Database Driver Class Initialized
INFO - 2016-12-01 19:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 19:53:13 --> Controller Class Initialized
INFO - 2016-12-01 19:53:13 --> Model Class Initialized
INFO - 2016-12-01 19:53:13 --> Form Validation Class Initialized
INFO - 2016-12-01 19:53:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 19:53:13 --> Pagination Class Initialized
INFO - 2016-12-01 19:53:13 --> Helper loaded: app_helper
INFO - 2016-12-01 19:53:13 --> Email Class Initialized
INFO - 2016-12-01 19:53:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 18:53:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 18:53:13 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-12-01 18:54:15 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\LMS\sys\core\Common.php 599
INFO - 2016-12-01 19:54:49 --> Config Class Initialized
INFO - 2016-12-01 19:54:49 --> Hooks Class Initialized
DEBUG - 2016-12-01 19:54:49 --> UTF-8 Support Enabled
INFO - 2016-12-01 19:54:49 --> Utf8 Class Initialized
INFO - 2016-12-01 19:54:49 --> URI Class Initialized
DEBUG - 2016-12-01 19:54:49 --> No URI present. Default controller set.
INFO - 2016-12-01 19:54:49 --> Router Class Initialized
INFO - 2016-12-01 19:54:49 --> Output Class Initialized
INFO - 2016-12-01 19:54:49 --> Security Class Initialized
DEBUG - 2016-12-01 19:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 19:54:49 --> Input Class Initialized
INFO - 2016-12-01 19:54:49 --> Language Class Initialized
INFO - 2016-12-01 19:54:49 --> Loader Class Initialized
INFO - 2016-12-01 19:54:49 --> Helper loaded: url_helper
INFO - 2016-12-01 19:54:49 --> Helper loaded: form_helper
INFO - 2016-12-01 19:54:49 --> Database Driver Class Initialized
INFO - 2016-12-01 19:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 19:54:49 --> Controller Class Initialized
INFO - 2016-12-01 19:54:49 --> Model Class Initialized
INFO - 2016-12-01 19:54:49 --> Model Class Initialized
INFO - 2016-12-01 19:54:49 --> Model Class Initialized
INFO - 2016-12-01 19:54:49 --> Model Class Initialized
INFO - 2016-12-01 19:54:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 19:54:49 --> Pagination Class Initialized
INFO - 2016-12-01 19:54:49 --> Helper loaded: app_helper
INFO - 2016-12-01 19:54:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 19:54:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 19:54:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 19:54:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 19:54:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 19:54:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 19:54:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 19:54:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 19:54:49 --> Final output sent to browser
DEBUG - 2016-12-01 19:54:49 --> Total execution time: 0.5373
INFO - 2016-12-01 19:58:50 --> Config Class Initialized
INFO - 2016-12-01 19:58:50 --> Hooks Class Initialized
DEBUG - 2016-12-01 19:58:50 --> UTF-8 Support Enabled
INFO - 2016-12-01 19:58:50 --> Utf8 Class Initialized
INFO - 2016-12-01 19:58:50 --> URI Class Initialized
DEBUG - 2016-12-01 19:58:50 --> No URI present. Default controller set.
INFO - 2016-12-01 19:58:50 --> Router Class Initialized
INFO - 2016-12-01 19:58:50 --> Output Class Initialized
INFO - 2016-12-01 19:58:50 --> Security Class Initialized
DEBUG - 2016-12-01 19:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 19:58:50 --> Input Class Initialized
INFO - 2016-12-01 19:58:50 --> Language Class Initialized
INFO - 2016-12-01 19:58:50 --> Loader Class Initialized
INFO - 2016-12-01 19:58:50 --> Helper loaded: url_helper
INFO - 2016-12-01 19:58:50 --> Helper loaded: form_helper
INFO - 2016-12-01 19:58:50 --> Database Driver Class Initialized
INFO - 2016-12-01 19:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 19:58:50 --> Controller Class Initialized
INFO - 2016-12-01 19:58:50 --> Model Class Initialized
INFO - 2016-12-01 19:58:50 --> Model Class Initialized
INFO - 2016-12-01 19:58:50 --> Model Class Initialized
INFO - 2016-12-01 19:58:50 --> Model Class Initialized
INFO - 2016-12-01 19:58:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 19:58:50 --> Pagination Class Initialized
INFO - 2016-12-01 19:58:50 --> Helper loaded: app_helper
INFO - 2016-12-01 19:58:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 19:58:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 19:58:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 19:58:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 19:58:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 19:58:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 19:58:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 19:58:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 19:58:50 --> Final output sent to browser
DEBUG - 2016-12-01 19:58:50 --> Total execution time: 0.4832
INFO - 2016-12-01 19:59:28 --> Config Class Initialized
INFO - 2016-12-01 19:59:28 --> Hooks Class Initialized
DEBUG - 2016-12-01 19:59:28 --> UTF-8 Support Enabled
INFO - 2016-12-01 19:59:28 --> Utf8 Class Initialized
INFO - 2016-12-01 19:59:28 --> URI Class Initialized
INFO - 2016-12-01 19:59:28 --> Router Class Initialized
INFO - 2016-12-01 19:59:28 --> Output Class Initialized
INFO - 2016-12-01 19:59:28 --> Security Class Initialized
DEBUG - 2016-12-01 19:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 19:59:28 --> Input Class Initialized
INFO - 2016-12-01 19:59:28 --> Language Class Initialized
INFO - 2016-12-01 19:59:28 --> Loader Class Initialized
INFO - 2016-12-01 19:59:28 --> Helper loaded: url_helper
INFO - 2016-12-01 19:59:28 --> Helper loaded: form_helper
INFO - 2016-12-01 19:59:28 --> Database Driver Class Initialized
INFO - 2016-12-01 19:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 19:59:28 --> Controller Class Initialized
INFO - 2016-12-01 19:59:28 --> Model Class Initialized
INFO - 2016-12-01 19:59:28 --> Form Validation Class Initialized
INFO - 2016-12-01 19:59:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 19:59:28 --> Pagination Class Initialized
INFO - 2016-12-01 19:59:28 --> Helper loaded: app_helper
INFO - 2016-12-01 19:59:28 --> Email Class Initialized
INFO - 2016-12-01 19:59:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 18:59:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 18:59:28 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 18:59:43 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 18:59:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
ERROR - 2016-12-01 18:59:59 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\LMS\sys\libraries\Email.php 2218
INFO - 2016-12-01 20:01:58 --> Config Class Initialized
INFO - 2016-12-01 20:01:58 --> Hooks Class Initialized
DEBUG - 2016-12-01 20:01:58 --> UTF-8 Support Enabled
INFO - 2016-12-01 20:01:58 --> Utf8 Class Initialized
INFO - 2016-12-01 20:01:58 --> URI Class Initialized
INFO - 2016-12-01 20:01:58 --> Router Class Initialized
INFO - 2016-12-01 20:01:59 --> Output Class Initialized
INFO - 2016-12-01 20:01:59 --> Security Class Initialized
DEBUG - 2016-12-01 20:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 20:01:59 --> Input Class Initialized
INFO - 2016-12-01 20:01:59 --> Language Class Initialized
INFO - 2016-12-01 20:01:59 --> Loader Class Initialized
INFO - 2016-12-01 20:01:59 --> Helper loaded: url_helper
INFO - 2016-12-01 20:01:59 --> Helper loaded: form_helper
INFO - 2016-12-01 20:01:59 --> Database Driver Class Initialized
INFO - 2016-12-01 20:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 20:01:59 --> Controller Class Initialized
INFO - 2016-12-01 20:01:59 --> Model Class Initialized
INFO - 2016-12-01 20:01:59 --> Form Validation Class Initialized
INFO - 2016-12-01 20:01:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 20:01:59 --> Pagination Class Initialized
INFO - 2016-12-01 20:01:59 --> Helper loaded: app_helper
INFO - 2016-12-01 20:01:59 --> Email Class Initialized
INFO - 2016-12-01 20:01:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 19:01:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 19:01:59 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-12-01 19:03:00 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\LMS\sys\core\Common.php 599
INFO - 2016-12-01 20:03:55 --> Config Class Initialized
INFO - 2016-12-01 20:03:55 --> Hooks Class Initialized
DEBUG - 2016-12-01 20:03:55 --> UTF-8 Support Enabled
INFO - 2016-12-01 20:03:55 --> Utf8 Class Initialized
INFO - 2016-12-01 20:03:55 --> URI Class Initialized
DEBUG - 2016-12-01 20:03:55 --> No URI present. Default controller set.
INFO - 2016-12-01 20:03:55 --> Router Class Initialized
INFO - 2016-12-01 20:03:55 --> Output Class Initialized
INFO - 2016-12-01 20:03:55 --> Security Class Initialized
DEBUG - 2016-12-01 20:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 20:03:55 --> Input Class Initialized
INFO - 2016-12-01 20:03:55 --> Language Class Initialized
INFO - 2016-12-01 20:03:55 --> Loader Class Initialized
INFO - 2016-12-01 20:03:55 --> Helper loaded: url_helper
INFO - 2016-12-01 20:03:55 --> Helper loaded: form_helper
INFO - 2016-12-01 20:03:55 --> Database Driver Class Initialized
INFO - 2016-12-01 20:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 20:03:55 --> Controller Class Initialized
INFO - 2016-12-01 20:03:55 --> Model Class Initialized
INFO - 2016-12-01 20:03:55 --> Model Class Initialized
INFO - 2016-12-01 20:03:55 --> Model Class Initialized
INFO - 2016-12-01 20:03:55 --> Model Class Initialized
INFO - 2016-12-01 20:03:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 20:03:55 --> Pagination Class Initialized
INFO - 2016-12-01 20:03:55 --> Helper loaded: app_helper
INFO - 2016-12-01 20:03:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 20:03:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 20:03:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 20:03:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 20:03:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 20:03:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 20:03:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 20:03:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 20:03:55 --> Final output sent to browser
DEBUG - 2016-12-01 20:03:55 --> Total execution time: 0.4514
INFO - 2016-12-01 20:04:15 --> Config Class Initialized
INFO - 2016-12-01 20:04:15 --> Hooks Class Initialized
DEBUG - 2016-12-01 20:04:15 --> UTF-8 Support Enabled
INFO - 2016-12-01 20:04:15 --> Utf8 Class Initialized
INFO - 2016-12-01 20:04:15 --> URI Class Initialized
INFO - 2016-12-01 20:04:15 --> Router Class Initialized
INFO - 2016-12-01 20:04:15 --> Output Class Initialized
INFO - 2016-12-01 20:04:15 --> Security Class Initialized
DEBUG - 2016-12-01 20:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 20:04:15 --> Input Class Initialized
INFO - 2016-12-01 20:04:15 --> Language Class Initialized
INFO - 2016-12-01 20:04:16 --> Loader Class Initialized
INFO - 2016-12-01 20:04:16 --> Helper loaded: url_helper
INFO - 2016-12-01 20:04:16 --> Helper loaded: form_helper
INFO - 2016-12-01 20:04:16 --> Database Driver Class Initialized
INFO - 2016-12-01 20:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 20:04:16 --> Controller Class Initialized
INFO - 2016-12-01 20:04:16 --> Model Class Initialized
INFO - 2016-12-01 20:04:16 --> Form Validation Class Initialized
INFO - 2016-12-01 20:04:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 20:04:16 --> Pagination Class Initialized
INFO - 2016-12-01 20:04:16 --> Helper loaded: app_helper
INFO - 2016-12-01 20:04:16 --> Email Class Initialized
INFO - 2016-12-01 20:04:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 19:04:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 19:04:16 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 19:04:18 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 19:04:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 19:04:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 19:04:20 --> Final output sent to browser
DEBUG - 2016-12-01 19:04:20 --> Total execution time: 4.1861
INFO - 2016-12-01 20:05:54 --> Config Class Initialized
INFO - 2016-12-01 20:05:54 --> Hooks Class Initialized
DEBUG - 2016-12-01 20:05:54 --> UTF-8 Support Enabled
INFO - 2016-12-01 20:05:55 --> Utf8 Class Initialized
INFO - 2016-12-01 20:05:55 --> URI Class Initialized
INFO - 2016-12-01 20:05:55 --> Router Class Initialized
INFO - 2016-12-01 20:05:55 --> Output Class Initialized
INFO - 2016-12-01 20:05:55 --> Security Class Initialized
DEBUG - 2016-12-01 20:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 20:05:55 --> Input Class Initialized
INFO - 2016-12-01 20:05:55 --> Language Class Initialized
INFO - 2016-12-01 20:05:55 --> Loader Class Initialized
INFO - 2016-12-01 20:05:55 --> Helper loaded: url_helper
INFO - 2016-12-01 20:05:55 --> Helper loaded: form_helper
INFO - 2016-12-01 20:05:55 --> Database Driver Class Initialized
INFO - 2016-12-01 20:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 20:05:55 --> Controller Class Initialized
INFO - 2016-12-01 20:05:55 --> Model Class Initialized
INFO - 2016-12-01 20:05:55 --> Form Validation Class Initialized
INFO - 2016-12-01 20:05:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 20:05:55 --> Pagination Class Initialized
INFO - 2016-12-01 20:05:55 --> Helper loaded: app_helper
INFO - 2016-12-01 20:05:55 --> Email Class Initialized
INFO - 2016-12-01 20:05:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 19:05:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 19:05:55 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-12-01 19:06:17 --> Severity: Warning --> fsockopen(): SSL: The operation completed successfully.
 C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-12-01 19:06:17 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-12-01 19:06:17 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.googlemail.com:465 (Unknown error) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-12-01 19:06:17 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 19:06:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 19:06:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 19:06:18 --> Final output sent to browser
DEBUG - 2016-12-01 19:06:18 --> Total execution time: 23.2464
INFO - 2016-12-01 20:07:05 --> Config Class Initialized
INFO - 2016-12-01 20:07:05 --> Hooks Class Initialized
DEBUG - 2016-12-01 20:07:05 --> UTF-8 Support Enabled
INFO - 2016-12-01 20:07:05 --> Utf8 Class Initialized
INFO - 2016-12-01 20:07:05 --> URI Class Initialized
DEBUG - 2016-12-01 20:07:05 --> No URI present. Default controller set.
INFO - 2016-12-01 20:07:05 --> Router Class Initialized
INFO - 2016-12-01 20:07:05 --> Output Class Initialized
INFO - 2016-12-01 20:07:05 --> Security Class Initialized
DEBUG - 2016-12-01 20:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 20:07:05 --> Input Class Initialized
INFO - 2016-12-01 20:07:05 --> Language Class Initialized
INFO - 2016-12-01 20:07:05 --> Loader Class Initialized
INFO - 2016-12-01 20:07:05 --> Helper loaded: url_helper
INFO - 2016-12-01 20:07:05 --> Helper loaded: form_helper
INFO - 2016-12-01 20:07:05 --> Database Driver Class Initialized
INFO - 2016-12-01 20:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 20:07:05 --> Controller Class Initialized
INFO - 2016-12-01 20:07:05 --> Model Class Initialized
INFO - 2016-12-01 20:07:05 --> Model Class Initialized
INFO - 2016-12-01 20:07:05 --> Model Class Initialized
INFO - 2016-12-01 20:07:05 --> Model Class Initialized
INFO - 2016-12-01 20:07:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 20:07:06 --> Pagination Class Initialized
INFO - 2016-12-01 20:07:06 --> Helper loaded: app_helper
INFO - 2016-12-01 20:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 20:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 20:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 20:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 20:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 20:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 20:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 20:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 20:07:06 --> Final output sent to browser
DEBUG - 2016-12-01 20:07:06 --> Total execution time: 0.6038
INFO - 2016-12-01 20:07:06 --> Config Class Initialized
INFO - 2016-12-01 20:07:06 --> Hooks Class Initialized
DEBUG - 2016-12-01 20:07:06 --> UTF-8 Support Enabled
INFO - 2016-12-01 20:07:06 --> Utf8 Class Initialized
INFO - 2016-12-01 20:07:06 --> URI Class Initialized
DEBUG - 2016-12-01 20:07:06 --> No URI present. Default controller set.
INFO - 2016-12-01 20:07:06 --> Router Class Initialized
INFO - 2016-12-01 20:07:06 --> Output Class Initialized
INFO - 2016-12-01 20:07:06 --> Security Class Initialized
DEBUG - 2016-12-01 20:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 20:07:06 --> Input Class Initialized
INFO - 2016-12-01 20:07:06 --> Language Class Initialized
INFO - 2016-12-01 20:07:06 --> Loader Class Initialized
INFO - 2016-12-01 20:07:06 --> Helper loaded: url_helper
INFO - 2016-12-01 20:07:06 --> Helper loaded: form_helper
INFO - 2016-12-01 20:07:06 --> Database Driver Class Initialized
INFO - 2016-12-01 20:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 20:07:06 --> Controller Class Initialized
INFO - 2016-12-01 20:07:06 --> Model Class Initialized
INFO - 2016-12-01 20:07:06 --> Model Class Initialized
INFO - 2016-12-01 20:07:06 --> Model Class Initialized
INFO - 2016-12-01 20:07:06 --> Model Class Initialized
INFO - 2016-12-01 20:07:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 20:07:06 --> Pagination Class Initialized
INFO - 2016-12-01 20:07:06 --> Helper loaded: app_helper
INFO - 2016-12-01 20:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 20:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 20:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 20:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 20:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 20:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 20:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 20:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 20:07:06 --> Final output sent to browser
DEBUG - 2016-12-01 20:07:06 --> Total execution time: 0.5454
INFO - 2016-12-01 20:07:24 --> Config Class Initialized
INFO - 2016-12-01 20:07:24 --> Hooks Class Initialized
DEBUG - 2016-12-01 20:07:24 --> UTF-8 Support Enabled
INFO - 2016-12-01 20:07:24 --> Utf8 Class Initialized
INFO - 2016-12-01 20:07:24 --> URI Class Initialized
INFO - 2016-12-01 20:07:24 --> Router Class Initialized
INFO - 2016-12-01 20:07:24 --> Output Class Initialized
INFO - 2016-12-01 20:07:24 --> Security Class Initialized
DEBUG - 2016-12-01 20:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 20:07:24 --> Input Class Initialized
INFO - 2016-12-01 20:07:24 --> Language Class Initialized
INFO - 2016-12-01 20:07:24 --> Loader Class Initialized
INFO - 2016-12-01 20:07:24 --> Helper loaded: url_helper
INFO - 2016-12-01 20:07:24 --> Helper loaded: form_helper
INFO - 2016-12-01 20:07:24 --> Database Driver Class Initialized
INFO - 2016-12-01 20:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 20:07:24 --> Controller Class Initialized
INFO - 2016-12-01 20:07:24 --> Model Class Initialized
INFO - 2016-12-01 20:07:24 --> Form Validation Class Initialized
INFO - 2016-12-01 20:07:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 20:07:24 --> Pagination Class Initialized
INFO - 2016-12-01 20:07:24 --> Helper loaded: app_helper
INFO - 2016-12-01 20:07:24 --> Email Class Initialized
INFO - 2016-12-01 20:07:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 19:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 19:07:25 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 19:07:32 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 19:07:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 19:07:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 19:07:49 --> Final output sent to browser
DEBUG - 2016-12-01 19:07:49 --> Total execution time: 24.7534
INFO - 2016-12-01 20:08:19 --> Config Class Initialized
INFO - 2016-12-01 20:08:19 --> Hooks Class Initialized
DEBUG - 2016-12-01 20:08:19 --> UTF-8 Support Enabled
INFO - 2016-12-01 20:08:19 --> Utf8 Class Initialized
INFO - 2016-12-01 20:08:19 --> URI Class Initialized
DEBUG - 2016-12-01 20:08:19 --> No URI present. Default controller set.
INFO - 2016-12-01 20:08:19 --> Router Class Initialized
INFO - 2016-12-01 20:08:19 --> Output Class Initialized
INFO - 2016-12-01 20:08:19 --> Security Class Initialized
DEBUG - 2016-12-01 20:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 20:08:19 --> Input Class Initialized
INFO - 2016-12-01 20:08:19 --> Language Class Initialized
INFO - 2016-12-01 20:08:19 --> Loader Class Initialized
INFO - 2016-12-01 20:08:19 --> Helper loaded: url_helper
INFO - 2016-12-01 20:08:19 --> Helper loaded: form_helper
INFO - 2016-12-01 20:08:19 --> Database Driver Class Initialized
INFO - 2016-12-01 20:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 20:08:19 --> Controller Class Initialized
INFO - 2016-12-01 20:08:19 --> Model Class Initialized
INFO - 2016-12-01 20:08:19 --> Model Class Initialized
INFO - 2016-12-01 20:08:19 --> Model Class Initialized
INFO - 2016-12-01 20:08:19 --> Model Class Initialized
INFO - 2016-12-01 20:08:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 20:08:19 --> Pagination Class Initialized
INFO - 2016-12-01 20:08:19 --> Helper loaded: app_helper
INFO - 2016-12-01 20:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 20:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 20:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 20:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 20:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 20:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 20:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 20:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 20:08:19 --> Final output sent to browser
DEBUG - 2016-12-01 20:08:19 --> Total execution time: 0.5335
INFO - 2016-12-01 20:09:59 --> Config Class Initialized
INFO - 2016-12-01 20:09:59 --> Hooks Class Initialized
DEBUG - 2016-12-01 20:09:59 --> UTF-8 Support Enabled
INFO - 2016-12-01 20:09:59 --> Utf8 Class Initialized
INFO - 2016-12-01 20:09:59 --> URI Class Initialized
DEBUG - 2016-12-01 20:09:59 --> No URI present. Default controller set.
INFO - 2016-12-01 20:09:59 --> Router Class Initialized
INFO - 2016-12-01 20:09:59 --> Output Class Initialized
INFO - 2016-12-01 20:09:59 --> Security Class Initialized
DEBUG - 2016-12-01 20:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 20:09:59 --> Input Class Initialized
INFO - 2016-12-01 20:09:59 --> Language Class Initialized
INFO - 2016-12-01 20:09:59 --> Loader Class Initialized
INFO - 2016-12-01 20:09:59 --> Helper loaded: url_helper
INFO - 2016-12-01 20:09:59 --> Helper loaded: form_helper
INFO - 2016-12-01 20:09:59 --> Database Driver Class Initialized
INFO - 2016-12-01 20:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 20:09:59 --> Controller Class Initialized
INFO - 2016-12-01 20:09:59 --> Model Class Initialized
INFO - 2016-12-01 20:09:59 --> Model Class Initialized
INFO - 2016-12-01 20:09:59 --> Model Class Initialized
INFO - 2016-12-01 20:09:59 --> Model Class Initialized
INFO - 2016-12-01 20:09:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 20:09:59 --> Pagination Class Initialized
INFO - 2016-12-01 20:10:00 --> Helper loaded: app_helper
INFO - 2016-12-01 20:10:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 20:10:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 20:10:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 20:10:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 20:10:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 20:10:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 20:10:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 20:10:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 20:10:00 --> Final output sent to browser
DEBUG - 2016-12-01 20:10:00 --> Total execution time: 0.5261
INFO - 2016-12-01 20:10:15 --> Config Class Initialized
INFO - 2016-12-01 20:10:15 --> Hooks Class Initialized
DEBUG - 2016-12-01 20:10:15 --> UTF-8 Support Enabled
INFO - 2016-12-01 20:10:15 --> Utf8 Class Initialized
INFO - 2016-12-01 20:10:15 --> URI Class Initialized
INFO - 2016-12-01 20:10:15 --> Router Class Initialized
INFO - 2016-12-01 20:10:15 --> Output Class Initialized
INFO - 2016-12-01 20:10:15 --> Security Class Initialized
DEBUG - 2016-12-01 20:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 20:10:15 --> Input Class Initialized
INFO - 2016-12-01 20:10:15 --> Language Class Initialized
INFO - 2016-12-01 20:10:15 --> Loader Class Initialized
INFO - 2016-12-01 20:10:15 --> Helper loaded: url_helper
INFO - 2016-12-01 20:10:15 --> Helper loaded: form_helper
INFO - 2016-12-01 20:10:15 --> Database Driver Class Initialized
INFO - 2016-12-01 20:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 20:10:15 --> Controller Class Initialized
INFO - 2016-12-01 20:10:15 --> Model Class Initialized
INFO - 2016-12-01 20:10:15 --> Form Validation Class Initialized
INFO - 2016-12-01 20:10:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 20:10:15 --> Pagination Class Initialized
INFO - 2016-12-01 20:10:15 --> Helper loaded: app_helper
INFO - 2016-12-01 20:10:15 --> Email Class Initialized
INFO - 2016-12-01 20:10:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 19:10:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 19:10:15 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 19:10:16 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 19:10:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 19:10:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 19:10:29 --> Final output sent to browser
DEBUG - 2016-12-01 19:10:29 --> Total execution time: 14.4023
INFO - 2016-12-01 20:12:48 --> Config Class Initialized
INFO - 2016-12-01 20:12:48 --> Hooks Class Initialized
DEBUG - 2016-12-01 20:12:48 --> UTF-8 Support Enabled
INFO - 2016-12-01 20:12:48 --> Utf8 Class Initialized
INFO - 2016-12-01 20:12:48 --> URI Class Initialized
DEBUG - 2016-12-01 20:12:48 --> No URI present. Default controller set.
INFO - 2016-12-01 20:12:48 --> Router Class Initialized
INFO - 2016-12-01 20:12:48 --> Output Class Initialized
INFO - 2016-12-01 20:12:48 --> Security Class Initialized
DEBUG - 2016-12-01 20:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 20:12:48 --> Input Class Initialized
INFO - 2016-12-01 20:12:48 --> Language Class Initialized
INFO - 2016-12-01 20:12:48 --> Loader Class Initialized
INFO - 2016-12-01 20:12:48 --> Helper loaded: url_helper
INFO - 2016-12-01 20:12:48 --> Helper loaded: form_helper
INFO - 2016-12-01 20:12:48 --> Database Driver Class Initialized
INFO - 2016-12-01 20:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 20:12:48 --> Controller Class Initialized
INFO - 2016-12-01 20:12:48 --> Model Class Initialized
INFO - 2016-12-01 20:12:48 --> Model Class Initialized
INFO - 2016-12-01 20:12:48 --> Model Class Initialized
INFO - 2016-12-01 20:12:48 --> Model Class Initialized
INFO - 2016-12-01 20:12:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 20:12:48 --> Pagination Class Initialized
INFO - 2016-12-01 20:12:48 --> Helper loaded: app_helper
INFO - 2016-12-01 20:12:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 20:12:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 20:12:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 20:12:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 20:12:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 20:12:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 20:12:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 20:12:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 20:12:49 --> Final output sent to browser
DEBUG - 2016-12-01 20:12:49 --> Total execution time: 0.5558
INFO - 2016-12-01 21:33:02 --> Config Class Initialized
INFO - 2016-12-01 21:33:03 --> Hooks Class Initialized
DEBUG - 2016-12-01 21:33:03 --> UTF-8 Support Enabled
INFO - 2016-12-01 21:33:03 --> Utf8 Class Initialized
INFO - 2016-12-01 21:33:03 --> URI Class Initialized
DEBUG - 2016-12-01 21:33:03 --> No URI present. Default controller set.
INFO - 2016-12-01 21:33:03 --> Router Class Initialized
INFO - 2016-12-01 21:33:03 --> Output Class Initialized
INFO - 2016-12-01 21:33:03 --> Security Class Initialized
DEBUG - 2016-12-01 21:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 21:33:03 --> Input Class Initialized
INFO - 2016-12-01 21:33:03 --> Language Class Initialized
INFO - 2016-12-01 21:33:03 --> Loader Class Initialized
INFO - 2016-12-01 21:33:03 --> Helper loaded: url_helper
INFO - 2016-12-01 21:33:03 --> Helper loaded: form_helper
INFO - 2016-12-01 21:33:03 --> Database Driver Class Initialized
INFO - 2016-12-01 21:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 21:33:03 --> Controller Class Initialized
INFO - 2016-12-01 21:33:03 --> Model Class Initialized
INFO - 2016-12-01 21:33:03 --> Model Class Initialized
INFO - 2016-12-01 21:33:03 --> Model Class Initialized
INFO - 2016-12-01 21:33:03 --> Model Class Initialized
INFO - 2016-12-01 21:33:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 21:33:03 --> Pagination Class Initialized
INFO - 2016-12-01 21:33:03 --> Helper loaded: app_helper
INFO - 2016-12-01 21:33:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 21:33:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 21:33:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 21:33:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 21:33:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 21:33:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 21:33:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 21:33:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 21:33:03 --> Final output sent to browser
DEBUG - 2016-12-01 21:33:03 --> Total execution time: 0.6156
INFO - 2016-12-01 21:34:29 --> Config Class Initialized
INFO - 2016-12-01 21:34:29 --> Hooks Class Initialized
DEBUG - 2016-12-01 21:34:29 --> UTF-8 Support Enabled
INFO - 2016-12-01 21:34:29 --> Utf8 Class Initialized
INFO - 2016-12-01 21:34:29 --> URI Class Initialized
INFO - 2016-12-01 21:34:29 --> Router Class Initialized
INFO - 2016-12-01 21:34:29 --> Output Class Initialized
INFO - 2016-12-01 21:34:29 --> Security Class Initialized
DEBUG - 2016-12-01 21:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 21:34:29 --> Input Class Initialized
INFO - 2016-12-01 21:34:29 --> Language Class Initialized
INFO - 2016-12-01 21:34:29 --> Loader Class Initialized
INFO - 2016-12-01 21:34:29 --> Helper loaded: url_helper
INFO - 2016-12-01 21:34:29 --> Helper loaded: form_helper
INFO - 2016-12-01 21:34:29 --> Database Driver Class Initialized
INFO - 2016-12-01 21:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 21:34:29 --> Controller Class Initialized
INFO - 2016-12-01 21:34:29 --> Model Class Initialized
INFO - 2016-12-01 21:34:29 --> Form Validation Class Initialized
INFO - 2016-12-01 21:34:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 21:34:29 --> Pagination Class Initialized
INFO - 2016-12-01 21:34:29 --> Helper loaded: app_helper
INFO - 2016-12-01 21:34:29 --> Email Class Initialized
INFO - 2016-12-01 21:34:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 20:34:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 20:34:29 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 20:34:38 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 20:34:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 20:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 20:34:57 --> Final output sent to browser
DEBUG - 2016-12-01 20:34:57 --> Total execution time: 27.9840
INFO - 2016-12-01 21:40:36 --> Config Class Initialized
INFO - 2016-12-01 21:40:36 --> Hooks Class Initialized
DEBUG - 2016-12-01 21:40:36 --> UTF-8 Support Enabled
INFO - 2016-12-01 21:40:36 --> Utf8 Class Initialized
INFO - 2016-12-01 21:40:36 --> URI Class Initialized
DEBUG - 2016-12-01 21:40:36 --> No URI present. Default controller set.
INFO - 2016-12-01 21:40:36 --> Router Class Initialized
INFO - 2016-12-01 21:40:36 --> Output Class Initialized
INFO - 2016-12-01 21:40:36 --> Security Class Initialized
DEBUG - 2016-12-01 21:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 21:40:36 --> Input Class Initialized
INFO - 2016-12-01 21:40:36 --> Language Class Initialized
INFO - 2016-12-01 21:40:36 --> Loader Class Initialized
INFO - 2016-12-01 21:40:36 --> Helper loaded: url_helper
INFO - 2016-12-01 21:40:36 --> Helper loaded: form_helper
INFO - 2016-12-01 21:40:36 --> Database Driver Class Initialized
INFO - 2016-12-01 21:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 21:40:36 --> Controller Class Initialized
INFO - 2016-12-01 21:40:36 --> Model Class Initialized
INFO - 2016-12-01 21:40:36 --> Model Class Initialized
INFO - 2016-12-01 21:40:36 --> Model Class Initialized
INFO - 2016-12-01 21:40:36 --> Model Class Initialized
INFO - 2016-12-01 21:40:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 21:40:36 --> Pagination Class Initialized
INFO - 2016-12-01 21:40:36 --> Helper loaded: app_helper
INFO - 2016-12-01 21:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 21:40:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 21:40:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 21:40:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 21:40:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 21:40:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 21:40:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 21:40:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 21:40:37 --> Final output sent to browser
DEBUG - 2016-12-01 21:40:37 --> Total execution time: 0.7480
INFO - 2016-12-01 21:41:22 --> Config Class Initialized
INFO - 2016-12-01 21:41:22 --> Hooks Class Initialized
DEBUG - 2016-12-01 21:41:23 --> UTF-8 Support Enabled
INFO - 2016-12-01 21:41:23 --> Utf8 Class Initialized
INFO - 2016-12-01 21:41:23 --> URI Class Initialized
INFO - 2016-12-01 21:41:23 --> Router Class Initialized
INFO - 2016-12-01 21:41:23 --> Output Class Initialized
INFO - 2016-12-01 21:41:23 --> Security Class Initialized
DEBUG - 2016-12-01 21:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 21:41:23 --> Input Class Initialized
INFO - 2016-12-01 21:41:23 --> Language Class Initialized
INFO - 2016-12-01 21:41:23 --> Loader Class Initialized
INFO - 2016-12-01 21:41:23 --> Helper loaded: url_helper
INFO - 2016-12-01 21:41:23 --> Helper loaded: form_helper
INFO - 2016-12-01 21:41:23 --> Database Driver Class Initialized
INFO - 2016-12-01 21:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 21:41:23 --> Controller Class Initialized
INFO - 2016-12-01 21:41:23 --> Model Class Initialized
INFO - 2016-12-01 21:41:23 --> Form Validation Class Initialized
INFO - 2016-12-01 21:41:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 21:41:23 --> Pagination Class Initialized
INFO - 2016-12-01 21:41:23 --> Helper loaded: app_helper
INFO - 2016-12-01 21:41:23 --> Email Class Initialized
INFO - 2016-12-01 21:41:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 20:41:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 20:41:23 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-12-01 20:41:55 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\LMS\sys\core\Common.php 599
INFO - 2016-12-01 21:42:15 --> Config Class Initialized
INFO - 2016-12-01 21:42:15 --> Hooks Class Initialized
DEBUG - 2016-12-01 21:42:15 --> UTF-8 Support Enabled
INFO - 2016-12-01 21:42:15 --> Utf8 Class Initialized
INFO - 2016-12-01 21:42:15 --> URI Class Initialized
DEBUG - 2016-12-01 21:42:16 --> No URI present. Default controller set.
INFO - 2016-12-01 21:42:16 --> Router Class Initialized
INFO - 2016-12-01 21:42:16 --> Output Class Initialized
INFO - 2016-12-01 21:42:16 --> Security Class Initialized
DEBUG - 2016-12-01 21:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 21:42:16 --> Input Class Initialized
INFO - 2016-12-01 21:42:16 --> Language Class Initialized
INFO - 2016-12-01 21:42:16 --> Loader Class Initialized
INFO - 2016-12-01 21:42:16 --> Helper loaded: url_helper
INFO - 2016-12-01 21:42:16 --> Helper loaded: form_helper
INFO - 2016-12-01 21:42:16 --> Database Driver Class Initialized
INFO - 2016-12-01 21:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 21:42:16 --> Controller Class Initialized
INFO - 2016-12-01 21:42:16 --> Model Class Initialized
INFO - 2016-12-01 21:42:16 --> Model Class Initialized
INFO - 2016-12-01 21:42:16 --> Model Class Initialized
INFO - 2016-12-01 21:42:16 --> Model Class Initialized
INFO - 2016-12-01 21:42:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 21:42:16 --> Pagination Class Initialized
INFO - 2016-12-01 21:42:16 --> Helper loaded: app_helper
INFO - 2016-12-01 21:42:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 21:42:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 21:42:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 21:42:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 21:42:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 21:42:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 21:42:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 21:42:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 21:42:16 --> Final output sent to browser
DEBUG - 2016-12-01 21:42:16 --> Total execution time: 0.5251
INFO - 2016-12-01 21:42:47 --> Config Class Initialized
INFO - 2016-12-01 21:42:47 --> Hooks Class Initialized
DEBUG - 2016-12-01 21:42:47 --> UTF-8 Support Enabled
INFO - 2016-12-01 21:42:47 --> Utf8 Class Initialized
INFO - 2016-12-01 21:42:47 --> URI Class Initialized
DEBUG - 2016-12-01 21:42:47 --> No URI present. Default controller set.
INFO - 2016-12-01 21:42:47 --> Router Class Initialized
INFO - 2016-12-01 21:42:47 --> Output Class Initialized
INFO - 2016-12-01 21:42:47 --> Security Class Initialized
DEBUG - 2016-12-01 21:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 21:42:47 --> Input Class Initialized
INFO - 2016-12-01 21:42:47 --> Language Class Initialized
INFO - 2016-12-01 21:42:47 --> Loader Class Initialized
INFO - 2016-12-01 21:42:47 --> Helper loaded: url_helper
INFO - 2016-12-01 21:42:47 --> Helper loaded: form_helper
INFO - 2016-12-01 21:42:47 --> Database Driver Class Initialized
INFO - 2016-12-01 21:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 21:42:47 --> Controller Class Initialized
INFO - 2016-12-01 21:42:47 --> Model Class Initialized
INFO - 2016-12-01 21:42:47 --> Model Class Initialized
INFO - 2016-12-01 21:42:47 --> Model Class Initialized
INFO - 2016-12-01 21:42:47 --> Model Class Initialized
INFO - 2016-12-01 21:42:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 21:42:47 --> Pagination Class Initialized
INFO - 2016-12-01 21:42:47 --> Helper loaded: app_helper
INFO - 2016-12-01 21:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 21:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 21:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 21:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 21:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 21:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 21:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 21:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 21:42:47 --> Final output sent to browser
DEBUG - 2016-12-01 21:42:47 --> Total execution time: 0.5054
INFO - 2016-12-01 21:43:22 --> Config Class Initialized
INFO - 2016-12-01 21:43:22 --> Hooks Class Initialized
DEBUG - 2016-12-01 21:43:22 --> UTF-8 Support Enabled
INFO - 2016-12-01 21:43:22 --> Utf8 Class Initialized
INFO - 2016-12-01 21:43:22 --> URI Class Initialized
INFO - 2016-12-01 21:43:22 --> Router Class Initialized
INFO - 2016-12-01 21:43:22 --> Output Class Initialized
INFO - 2016-12-01 21:43:22 --> Security Class Initialized
DEBUG - 2016-12-01 21:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 21:43:22 --> Input Class Initialized
INFO - 2016-12-01 21:43:22 --> Language Class Initialized
INFO - 2016-12-01 21:43:22 --> Loader Class Initialized
INFO - 2016-12-01 21:43:22 --> Helper loaded: url_helper
INFO - 2016-12-01 21:43:22 --> Helper loaded: form_helper
INFO - 2016-12-01 21:43:22 --> Database Driver Class Initialized
INFO - 2016-12-01 21:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 21:43:22 --> Controller Class Initialized
INFO - 2016-12-01 21:43:22 --> Model Class Initialized
INFO - 2016-12-01 21:43:22 --> Form Validation Class Initialized
INFO - 2016-12-01 21:43:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 21:43:22 --> Pagination Class Initialized
INFO - 2016-12-01 21:43:22 --> Helper loaded: app_helper
INFO - 2016-12-01 21:43:22 --> Email Class Initialized
INFO - 2016-12-01 21:43:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 20:43:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 20:43:22 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-12-01 20:44:01 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\LMS\sys\core\Common.php 599
INFO - 2016-12-01 21:44:28 --> Config Class Initialized
INFO - 2016-12-01 21:44:29 --> Hooks Class Initialized
DEBUG - 2016-12-01 21:44:29 --> UTF-8 Support Enabled
INFO - 2016-12-01 21:44:29 --> Utf8 Class Initialized
INFO - 2016-12-01 21:44:29 --> URI Class Initialized
INFO - 2016-12-01 21:44:29 --> Router Class Initialized
INFO - 2016-12-01 21:44:29 --> Output Class Initialized
INFO - 2016-12-01 21:44:29 --> Security Class Initialized
DEBUG - 2016-12-01 21:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 21:44:29 --> Input Class Initialized
INFO - 2016-12-01 21:44:29 --> Language Class Initialized
INFO - 2016-12-01 21:44:29 --> Loader Class Initialized
INFO - 2016-12-01 21:44:29 --> Helper loaded: url_helper
INFO - 2016-12-01 21:44:29 --> Helper loaded: form_helper
INFO - 2016-12-01 21:44:29 --> Database Driver Class Initialized
INFO - 2016-12-01 21:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 21:44:29 --> Controller Class Initialized
INFO - 2016-12-01 21:44:29 --> Model Class Initialized
INFO - 2016-12-01 21:44:29 --> Form Validation Class Initialized
INFO - 2016-12-01 21:44:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 21:44:29 --> Pagination Class Initialized
INFO - 2016-12-01 21:44:29 --> Helper loaded: app_helper
INFO - 2016-12-01 21:44:29 --> Email Class Initialized
INFO - 2016-12-01 21:44:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 20:44:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 20:44:29 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-12-01 20:45:02 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\LMS\sys\core\Common.php 599
INFO - 2016-12-01 21:48:19 --> Config Class Initialized
INFO - 2016-12-01 21:48:19 --> Hooks Class Initialized
DEBUG - 2016-12-01 21:48:19 --> UTF-8 Support Enabled
INFO - 2016-12-01 21:48:19 --> Utf8 Class Initialized
INFO - 2016-12-01 21:48:19 --> URI Class Initialized
DEBUG - 2016-12-01 21:48:19 --> No URI present. Default controller set.
INFO - 2016-12-01 21:48:19 --> Router Class Initialized
INFO - 2016-12-01 21:48:19 --> Output Class Initialized
INFO - 2016-12-01 21:48:19 --> Security Class Initialized
DEBUG - 2016-12-01 21:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 21:48:19 --> Input Class Initialized
INFO - 2016-12-01 21:48:19 --> Language Class Initialized
INFO - 2016-12-01 21:48:19 --> Loader Class Initialized
INFO - 2016-12-01 21:48:19 --> Helper loaded: url_helper
INFO - 2016-12-01 21:48:19 --> Helper loaded: form_helper
INFO - 2016-12-01 21:48:19 --> Database Driver Class Initialized
INFO - 2016-12-01 21:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 21:48:19 --> Controller Class Initialized
INFO - 2016-12-01 21:48:19 --> Model Class Initialized
INFO - 2016-12-01 21:48:19 --> Model Class Initialized
INFO - 2016-12-01 21:48:19 --> Model Class Initialized
INFO - 2016-12-01 21:48:19 --> Model Class Initialized
INFO - 2016-12-01 21:48:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 21:48:19 --> Pagination Class Initialized
INFO - 2016-12-01 21:48:19 --> Helper loaded: app_helper
INFO - 2016-12-01 21:48:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 21:48:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 21:48:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 21:48:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 21:48:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 21:48:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 21:48:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 21:48:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 21:48:19 --> Final output sent to browser
DEBUG - 2016-12-01 21:48:19 --> Total execution time: 0.5155
INFO - 2016-12-01 21:49:39 --> Config Class Initialized
INFO - 2016-12-01 21:49:39 --> Hooks Class Initialized
DEBUG - 2016-12-01 21:49:39 --> UTF-8 Support Enabled
INFO - 2016-12-01 21:49:39 --> Utf8 Class Initialized
INFO - 2016-12-01 21:49:39 --> URI Class Initialized
DEBUG - 2016-12-01 21:49:39 --> No URI present. Default controller set.
INFO - 2016-12-01 21:49:39 --> Router Class Initialized
INFO - 2016-12-01 21:49:39 --> Output Class Initialized
INFO - 2016-12-01 21:49:39 --> Security Class Initialized
DEBUG - 2016-12-01 21:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 21:49:39 --> Input Class Initialized
INFO - 2016-12-01 21:49:39 --> Language Class Initialized
INFO - 2016-12-01 21:49:39 --> Loader Class Initialized
INFO - 2016-12-01 21:49:39 --> Helper loaded: url_helper
INFO - 2016-12-01 21:49:39 --> Helper loaded: form_helper
INFO - 2016-12-01 21:49:39 --> Database Driver Class Initialized
INFO - 2016-12-01 21:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 21:49:39 --> Controller Class Initialized
INFO - 2016-12-01 21:49:39 --> Model Class Initialized
INFO - 2016-12-01 21:49:39 --> Model Class Initialized
INFO - 2016-12-01 21:49:39 --> Model Class Initialized
INFO - 2016-12-01 21:49:39 --> Model Class Initialized
INFO - 2016-12-01 21:49:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 21:49:39 --> Pagination Class Initialized
INFO - 2016-12-01 21:49:39 --> Helper loaded: app_helper
INFO - 2016-12-01 21:49:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 21:49:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 21:49:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 21:49:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 21:49:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 21:49:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 21:49:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 21:49:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 21:49:40 --> Final output sent to browser
DEBUG - 2016-12-01 21:49:40 --> Total execution time: 0.4867
INFO - 2016-12-01 22:18:33 --> Config Class Initialized
INFO - 2016-12-01 22:18:33 --> Hooks Class Initialized
DEBUG - 2016-12-01 22:18:33 --> UTF-8 Support Enabled
INFO - 2016-12-01 22:18:33 --> Utf8 Class Initialized
INFO - 2016-12-01 22:18:33 --> URI Class Initialized
INFO - 2016-12-01 22:18:33 --> Router Class Initialized
INFO - 2016-12-01 22:18:33 --> Output Class Initialized
INFO - 2016-12-01 22:18:33 --> Security Class Initialized
DEBUG - 2016-12-01 22:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 22:18:33 --> Input Class Initialized
INFO - 2016-12-01 22:18:33 --> Language Class Initialized
INFO - 2016-12-01 22:18:33 --> Loader Class Initialized
INFO - 2016-12-01 22:18:33 --> Helper loaded: url_helper
INFO - 2016-12-01 22:18:33 --> Helper loaded: form_helper
INFO - 2016-12-01 22:18:33 --> Database Driver Class Initialized
INFO - 2016-12-01 22:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 22:18:33 --> Controller Class Initialized
INFO - 2016-12-01 22:18:33 --> Model Class Initialized
INFO - 2016-12-01 22:18:33 --> Form Validation Class Initialized
INFO - 2016-12-01 22:18:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 22:18:33 --> Pagination Class Initialized
INFO - 2016-12-01 22:18:33 --> Helper loaded: app_helper
INFO - 2016-12-01 22:18:33 --> Email Class Initialized
INFO - 2016-12-01 22:18:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 22:18:33 --> Final output sent to browser
DEBUG - 2016-12-01 22:18:33 --> Total execution time: 0.4641
INFO - 2016-12-01 22:50:26 --> Config Class Initialized
INFO - 2016-12-01 22:50:26 --> Hooks Class Initialized
DEBUG - 2016-12-01 22:50:26 --> UTF-8 Support Enabled
INFO - 2016-12-01 22:50:26 --> Utf8 Class Initialized
INFO - 2016-12-01 22:50:27 --> URI Class Initialized
INFO - 2016-12-01 22:50:27 --> Router Class Initialized
INFO - 2016-12-01 22:50:27 --> Output Class Initialized
INFO - 2016-12-01 22:50:27 --> Security Class Initialized
DEBUG - 2016-12-01 22:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 22:50:27 --> Input Class Initialized
INFO - 2016-12-01 22:50:27 --> Language Class Initialized
INFO - 2016-12-01 22:50:27 --> Loader Class Initialized
INFO - 2016-12-01 22:50:27 --> Helper loaded: url_helper
INFO - 2016-12-01 22:50:27 --> Helper loaded: form_helper
INFO - 2016-12-01 22:50:27 --> Database Driver Class Initialized
INFO - 2016-12-01 22:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 22:50:27 --> Controller Class Initialized
INFO - 2016-12-01 22:50:27 --> Model Class Initialized
INFO - 2016-12-01 22:50:27 --> Form Validation Class Initialized
INFO - 2016-12-01 22:50:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 22:50:27 --> Pagination Class Initialized
INFO - 2016-12-01 22:50:27 --> Helper loaded: app_helper
INFO - 2016-12-01 22:50:27 --> Email Class Initialized
INFO - 2016-12-01 22:50:27 --> Config Class Initialized
INFO - 2016-12-01 22:50:27 --> Hooks Class Initialized
DEBUG - 2016-12-01 22:50:27 --> UTF-8 Support Enabled
INFO - 2016-12-01 22:50:27 --> Utf8 Class Initialized
INFO - 2016-12-01 22:50:27 --> URI Class Initialized
INFO - 2016-12-01 22:50:27 --> Router Class Initialized
INFO - 2016-12-01 22:50:27 --> Output Class Initialized
INFO - 2016-12-01 22:50:27 --> Security Class Initialized
DEBUG - 2016-12-01 22:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 22:50:27 --> Input Class Initialized
INFO - 2016-12-01 22:50:27 --> Language Class Initialized
INFO - 2016-12-01 22:50:27 --> Loader Class Initialized
INFO - 2016-12-01 22:50:27 --> Helper loaded: url_helper
INFO - 2016-12-01 22:50:27 --> Helper loaded: form_helper
INFO - 2016-12-01 22:50:27 --> Database Driver Class Initialized
INFO - 2016-12-01 22:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 22:50:27 --> Controller Class Initialized
INFO - 2016-12-01 22:50:27 --> Model Class Initialized
INFO - 2016-12-01 22:50:27 --> Model Class Initialized
INFO - 2016-12-01 22:50:27 --> Model Class Initialized
INFO - 2016-12-01 22:50:27 --> Model Class Initialized
INFO - 2016-12-01 22:50:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 22:50:27 --> Pagination Class Initialized
INFO - 2016-12-01 22:50:27 --> Helper loaded: app_helper
INFO - 2016-12-01 22:50:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 22:50:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-01 22:50:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 22:50:27 --> Final output sent to browser
DEBUG - 2016-12-01 22:50:27 --> Total execution time: 0.3987
INFO - 2016-12-01 22:50:46 --> Config Class Initialized
INFO - 2016-12-01 22:50:46 --> Hooks Class Initialized
DEBUG - 2016-12-01 22:50:46 --> UTF-8 Support Enabled
INFO - 2016-12-01 22:50:46 --> Utf8 Class Initialized
INFO - 2016-12-01 22:50:46 --> URI Class Initialized
INFO - 2016-12-01 22:50:46 --> Router Class Initialized
INFO - 2016-12-01 22:50:46 --> Output Class Initialized
INFO - 2016-12-01 22:50:46 --> Security Class Initialized
DEBUG - 2016-12-01 22:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 22:50:46 --> Input Class Initialized
INFO - 2016-12-01 22:50:46 --> Language Class Initialized
INFO - 2016-12-01 22:50:46 --> Loader Class Initialized
INFO - 2016-12-01 22:50:46 --> Helper loaded: url_helper
INFO - 2016-12-01 22:50:46 --> Helper loaded: form_helper
INFO - 2016-12-01 22:50:46 --> Database Driver Class Initialized
INFO - 2016-12-01 22:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 22:50:47 --> Controller Class Initialized
INFO - 2016-12-01 22:50:47 --> Model Class Initialized
INFO - 2016-12-01 22:50:47 --> Form Validation Class Initialized
INFO - 2016-12-01 22:50:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 22:50:47 --> Pagination Class Initialized
INFO - 2016-12-01 22:50:47 --> Helper loaded: app_helper
INFO - 2016-12-01 22:50:47 --> Email Class Initialized
INFO - 2016-12-01 22:50:47 --> Config Class Initialized
INFO - 2016-12-01 22:50:47 --> Hooks Class Initialized
DEBUG - 2016-12-01 22:50:47 --> UTF-8 Support Enabled
INFO - 2016-12-01 22:50:47 --> Utf8 Class Initialized
INFO - 2016-12-01 22:50:47 --> URI Class Initialized
INFO - 2016-12-01 22:50:47 --> Router Class Initialized
INFO - 2016-12-01 22:50:47 --> Output Class Initialized
INFO - 2016-12-01 22:50:47 --> Security Class Initialized
DEBUG - 2016-12-01 22:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 22:50:47 --> Input Class Initialized
INFO - 2016-12-01 22:50:47 --> Language Class Initialized
INFO - 2016-12-01 22:50:47 --> Loader Class Initialized
INFO - 2016-12-01 22:50:47 --> Helper loaded: url_helper
INFO - 2016-12-01 22:50:47 --> Helper loaded: form_helper
INFO - 2016-12-01 22:50:47 --> Database Driver Class Initialized
INFO - 2016-12-01 22:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 22:50:47 --> Controller Class Initialized
INFO - 2016-12-01 22:50:47 --> Model Class Initialized
INFO - 2016-12-01 22:50:47 --> Model Class Initialized
INFO - 2016-12-01 22:50:47 --> Model Class Initialized
INFO - 2016-12-01 22:50:47 --> Model Class Initialized
INFO - 2016-12-01 22:50:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 22:50:47 --> Pagination Class Initialized
INFO - 2016-12-01 22:50:47 --> Helper loaded: app_helper
INFO - 2016-12-01 22:50:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 22:50:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-01 22:50:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 22:50:47 --> Final output sent to browser
DEBUG - 2016-12-01 22:50:47 --> Total execution time: 0.3969
INFO - 2016-12-01 22:51:11 --> Config Class Initialized
INFO - 2016-12-01 22:51:11 --> Hooks Class Initialized
DEBUG - 2016-12-01 22:51:11 --> UTF-8 Support Enabled
INFO - 2016-12-01 22:51:11 --> Utf8 Class Initialized
INFO - 2016-12-01 22:51:11 --> URI Class Initialized
INFO - 2016-12-01 22:51:11 --> Router Class Initialized
INFO - 2016-12-01 22:51:11 --> Output Class Initialized
INFO - 2016-12-01 22:51:11 --> Security Class Initialized
DEBUG - 2016-12-01 22:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 22:51:11 --> Input Class Initialized
INFO - 2016-12-01 22:51:11 --> Language Class Initialized
INFO - 2016-12-01 22:51:11 --> Loader Class Initialized
INFO - 2016-12-01 22:51:11 --> Helper loaded: url_helper
INFO - 2016-12-01 22:51:11 --> Helper loaded: form_helper
INFO - 2016-12-01 22:51:11 --> Database Driver Class Initialized
INFO - 2016-12-01 22:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 22:51:11 --> Controller Class Initialized
INFO - 2016-12-01 22:51:11 --> Model Class Initialized
INFO - 2016-12-01 22:51:11 --> Form Validation Class Initialized
INFO - 2016-12-01 22:51:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 22:51:11 --> Pagination Class Initialized
INFO - 2016-12-01 22:51:11 --> Helper loaded: app_helper
INFO - 2016-12-01 22:51:11 --> Email Class Initialized
INFO - 2016-12-01 22:51:11 --> Config Class Initialized
INFO - 2016-12-01 22:51:11 --> Hooks Class Initialized
DEBUG - 2016-12-01 22:51:11 --> UTF-8 Support Enabled
INFO - 2016-12-01 22:51:11 --> Utf8 Class Initialized
INFO - 2016-12-01 22:51:11 --> URI Class Initialized
INFO - 2016-12-01 22:51:11 --> Router Class Initialized
INFO - 2016-12-01 22:51:11 --> Output Class Initialized
INFO - 2016-12-01 22:51:11 --> Security Class Initialized
DEBUG - 2016-12-01 22:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 22:51:11 --> Input Class Initialized
INFO - 2016-12-01 22:51:11 --> Language Class Initialized
INFO - 2016-12-01 22:51:11 --> Loader Class Initialized
INFO - 2016-12-01 22:51:12 --> Helper loaded: url_helper
INFO - 2016-12-01 22:51:12 --> Helper loaded: form_helper
INFO - 2016-12-01 22:51:12 --> Database Driver Class Initialized
INFO - 2016-12-01 22:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 22:51:12 --> Controller Class Initialized
INFO - 2016-12-01 22:51:12 --> Model Class Initialized
INFO - 2016-12-01 22:51:12 --> Model Class Initialized
INFO - 2016-12-01 22:51:12 --> Model Class Initialized
INFO - 2016-12-01 22:51:12 --> Model Class Initialized
INFO - 2016-12-01 22:51:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 22:51:12 --> Pagination Class Initialized
INFO - 2016-12-01 22:51:12 --> Helper loaded: app_helper
INFO - 2016-12-01 22:51:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 22:51:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-01 22:51:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 22:51:12 --> Final output sent to browser
DEBUG - 2016-12-01 22:51:12 --> Total execution time: 0.4343
INFO - 2016-12-01 22:51:19 --> Config Class Initialized
INFO - 2016-12-01 22:51:19 --> Hooks Class Initialized
DEBUG - 2016-12-01 22:51:19 --> UTF-8 Support Enabled
INFO - 2016-12-01 22:51:19 --> Utf8 Class Initialized
INFO - 2016-12-01 22:51:19 --> URI Class Initialized
DEBUG - 2016-12-01 22:51:19 --> No URI present. Default controller set.
INFO - 2016-12-01 22:51:19 --> Router Class Initialized
INFO - 2016-12-01 22:51:19 --> Output Class Initialized
INFO - 2016-12-01 22:51:19 --> Security Class Initialized
DEBUG - 2016-12-01 22:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 22:51:19 --> Input Class Initialized
INFO - 2016-12-01 22:51:19 --> Language Class Initialized
INFO - 2016-12-01 22:51:19 --> Loader Class Initialized
INFO - 2016-12-01 22:51:19 --> Helper loaded: url_helper
INFO - 2016-12-01 22:51:19 --> Helper loaded: form_helper
INFO - 2016-12-01 22:51:19 --> Database Driver Class Initialized
INFO - 2016-12-01 22:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 22:51:19 --> Controller Class Initialized
INFO - 2016-12-01 22:51:19 --> Model Class Initialized
INFO - 2016-12-01 22:51:19 --> Model Class Initialized
INFO - 2016-12-01 22:51:19 --> Model Class Initialized
INFO - 2016-12-01 22:51:19 --> Model Class Initialized
INFO - 2016-12-01 22:51:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 22:51:19 --> Pagination Class Initialized
INFO - 2016-12-01 22:51:19 --> Helper loaded: app_helper
INFO - 2016-12-01 22:51:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 22:51:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-01 22:51:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 22:51:19 --> Final output sent to browser
DEBUG - 2016-12-01 22:51:19 --> Total execution time: 0.4074
INFO - 2016-12-01 22:51:44 --> Config Class Initialized
INFO - 2016-12-01 22:51:44 --> Hooks Class Initialized
DEBUG - 2016-12-01 22:51:44 --> UTF-8 Support Enabled
INFO - 2016-12-01 22:51:44 --> Utf8 Class Initialized
INFO - 2016-12-01 22:51:44 --> URI Class Initialized
INFO - 2016-12-01 22:51:44 --> Router Class Initialized
INFO - 2016-12-01 22:51:44 --> Output Class Initialized
INFO - 2016-12-01 22:51:44 --> Security Class Initialized
DEBUG - 2016-12-01 22:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 22:51:44 --> Input Class Initialized
INFO - 2016-12-01 22:51:44 --> Language Class Initialized
INFO - 2016-12-01 22:51:44 --> Loader Class Initialized
INFO - 2016-12-01 22:51:44 --> Helper loaded: url_helper
INFO - 2016-12-01 22:51:44 --> Helper loaded: form_helper
INFO - 2016-12-01 22:51:44 --> Database Driver Class Initialized
INFO - 2016-12-01 22:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 22:51:44 --> Controller Class Initialized
INFO - 2016-12-01 22:51:44 --> Model Class Initialized
INFO - 2016-12-01 22:51:44 --> Model Class Initialized
INFO - 2016-12-01 22:51:44 --> Model Class Initialized
INFO - 2016-12-01 22:51:44 --> Model Class Initialized
INFO - 2016-12-01 22:51:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 22:51:44 --> Pagination Class Initialized
INFO - 2016-12-01 22:51:44 --> Helper loaded: app_helper
DEBUG - 2016-12-01 22:51:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 22:51:44 --> Model Class Initialized
INFO - 2016-12-01 22:51:44 --> Final output sent to browser
DEBUG - 2016-12-01 22:51:44 --> Total execution time: 0.3139
INFO - 2016-12-01 22:51:44 --> Config Class Initialized
INFO - 2016-12-01 22:51:44 --> Hooks Class Initialized
DEBUG - 2016-12-01 22:51:44 --> UTF-8 Support Enabled
INFO - 2016-12-01 22:51:44 --> Utf8 Class Initialized
INFO - 2016-12-01 22:51:44 --> URI Class Initialized
DEBUG - 2016-12-01 22:51:44 --> No URI present. Default controller set.
INFO - 2016-12-01 22:51:44 --> Router Class Initialized
INFO - 2016-12-01 22:51:44 --> Output Class Initialized
INFO - 2016-12-01 22:51:44 --> Security Class Initialized
DEBUG - 2016-12-01 22:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 22:51:45 --> Input Class Initialized
INFO - 2016-12-01 22:51:45 --> Language Class Initialized
INFO - 2016-12-01 22:51:45 --> Loader Class Initialized
INFO - 2016-12-01 22:51:45 --> Helper loaded: url_helper
INFO - 2016-12-01 22:51:45 --> Helper loaded: form_helper
INFO - 2016-12-01 22:51:45 --> Database Driver Class Initialized
INFO - 2016-12-01 22:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 22:51:45 --> Controller Class Initialized
INFO - 2016-12-01 22:51:45 --> Model Class Initialized
INFO - 2016-12-01 22:51:45 --> Model Class Initialized
INFO - 2016-12-01 22:51:45 --> Model Class Initialized
INFO - 2016-12-01 22:51:45 --> Model Class Initialized
INFO - 2016-12-01 22:51:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 22:51:45 --> Pagination Class Initialized
INFO - 2016-12-01 22:51:45 --> Helper loaded: app_helper
INFO - 2016-12-01 22:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 22:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 22:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 22:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 22:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 22:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 22:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 22:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 22:51:45 --> Final output sent to browser
DEBUG - 2016-12-01 22:51:45 --> Total execution time: 0.4211
INFO - 2016-12-01 22:52:36 --> Config Class Initialized
INFO - 2016-12-01 22:52:36 --> Hooks Class Initialized
DEBUG - 2016-12-01 22:52:36 --> UTF-8 Support Enabled
INFO - 2016-12-01 22:52:36 --> Utf8 Class Initialized
INFO - 2016-12-01 22:52:36 --> URI Class Initialized
INFO - 2016-12-01 22:52:36 --> Router Class Initialized
INFO - 2016-12-01 22:52:36 --> Output Class Initialized
INFO - 2016-12-01 22:52:36 --> Security Class Initialized
DEBUG - 2016-12-01 22:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 22:52:36 --> Input Class Initialized
INFO - 2016-12-01 22:52:36 --> Language Class Initialized
INFO - 2016-12-01 22:52:36 --> Loader Class Initialized
INFO - 2016-12-01 22:52:36 --> Helper loaded: url_helper
INFO - 2016-12-01 22:52:36 --> Helper loaded: form_helper
INFO - 2016-12-01 22:52:36 --> Database Driver Class Initialized
INFO - 2016-12-01 22:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 22:52:36 --> Controller Class Initialized
INFO - 2016-12-01 22:52:36 --> Model Class Initialized
INFO - 2016-12-01 22:52:36 --> Form Validation Class Initialized
INFO - 2016-12-01 22:52:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 22:52:36 --> Pagination Class Initialized
INFO - 2016-12-01 22:52:36 --> Helper loaded: app_helper
INFO - 2016-12-01 22:52:36 --> Email Class Initialized
INFO - 2016-12-01 22:52:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 21:52:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 21:52:36 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 21:52:38 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 21:52:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 21:52:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 21:52:40 --> Final output sent to browser
DEBUG - 2016-12-01 21:52:40 --> Total execution time: 4.1823
INFO - 2016-12-01 22:53:15 --> Config Class Initialized
INFO - 2016-12-01 22:53:15 --> Hooks Class Initialized
DEBUG - 2016-12-01 22:53:15 --> UTF-8 Support Enabled
INFO - 2016-12-01 22:53:15 --> Utf8 Class Initialized
INFO - 2016-12-01 22:53:15 --> URI Class Initialized
INFO - 2016-12-01 22:53:15 --> Router Class Initialized
INFO - 2016-12-01 22:53:15 --> Output Class Initialized
INFO - 2016-12-01 22:53:15 --> Security Class Initialized
DEBUG - 2016-12-01 22:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 22:53:15 --> Input Class Initialized
INFO - 2016-12-01 22:53:15 --> Language Class Initialized
INFO - 2016-12-01 22:53:15 --> Loader Class Initialized
INFO - 2016-12-01 22:53:15 --> Helper loaded: url_helper
INFO - 2016-12-01 22:53:15 --> Helper loaded: form_helper
INFO - 2016-12-01 22:53:15 --> Database Driver Class Initialized
INFO - 2016-12-01 22:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 22:53:15 --> Controller Class Initialized
INFO - 2016-12-01 22:53:15 --> Model Class Initialized
INFO - 2016-12-01 22:53:15 --> Form Validation Class Initialized
INFO - 2016-12-01 22:53:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 22:53:15 --> Pagination Class Initialized
INFO - 2016-12-01 22:53:15 --> Helper loaded: app_helper
INFO - 2016-12-01 22:53:15 --> Email Class Initialized
INFO - 2016-12-01 22:53:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 21:53:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 21:53:15 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 21:53:19 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 21:53:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 21:53:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 21:53:24 --> Final output sent to browser
DEBUG - 2016-12-01 21:53:24 --> Total execution time: 9.4075
INFO - 2016-12-01 23:01:06 --> Config Class Initialized
INFO - 2016-12-01 23:01:06 --> Hooks Class Initialized
DEBUG - 2016-12-01 23:01:06 --> UTF-8 Support Enabled
INFO - 2016-12-01 23:01:06 --> Utf8 Class Initialized
INFO - 2016-12-01 23:01:06 --> URI Class Initialized
DEBUG - 2016-12-01 23:01:06 --> No URI present. Default controller set.
INFO - 2016-12-01 23:01:06 --> Router Class Initialized
INFO - 2016-12-01 23:01:06 --> Output Class Initialized
INFO - 2016-12-01 23:01:06 --> Security Class Initialized
DEBUG - 2016-12-01 23:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 23:01:06 --> Input Class Initialized
INFO - 2016-12-01 23:01:06 --> Language Class Initialized
INFO - 2016-12-01 23:01:06 --> Loader Class Initialized
INFO - 2016-12-01 23:01:06 --> Helper loaded: url_helper
INFO - 2016-12-01 23:01:06 --> Helper loaded: form_helper
INFO - 2016-12-01 23:01:06 --> Database Driver Class Initialized
INFO - 2016-12-01 23:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 23:01:06 --> Controller Class Initialized
INFO - 2016-12-01 23:01:06 --> Model Class Initialized
INFO - 2016-12-01 23:01:06 --> Model Class Initialized
INFO - 2016-12-01 23:01:06 --> Model Class Initialized
INFO - 2016-12-01 23:01:06 --> Model Class Initialized
INFO - 2016-12-01 23:01:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 23:01:06 --> Pagination Class Initialized
INFO - 2016-12-01 23:01:06 --> Helper loaded: app_helper
INFO - 2016-12-01 23:01:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-01 23:01:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-01 23:01:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-01 23:01:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-01 23:01:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 23:01:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-01 23:01:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-01 23:01:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-01 23:01:07 --> Final output sent to browser
DEBUG - 2016-12-01 23:01:07 --> Total execution time: 0.7276
INFO - 2016-12-01 23:01:21 --> Config Class Initialized
INFO - 2016-12-01 23:01:21 --> Hooks Class Initialized
DEBUG - 2016-12-01 23:01:21 --> UTF-8 Support Enabled
INFO - 2016-12-01 23:01:21 --> Utf8 Class Initialized
INFO - 2016-12-01 23:01:21 --> URI Class Initialized
INFO - 2016-12-01 23:01:21 --> Router Class Initialized
INFO - 2016-12-01 23:01:21 --> Output Class Initialized
INFO - 2016-12-01 23:01:21 --> Security Class Initialized
DEBUG - 2016-12-01 23:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 23:01:21 --> Input Class Initialized
INFO - 2016-12-01 23:01:21 --> Language Class Initialized
INFO - 2016-12-01 23:01:21 --> Loader Class Initialized
INFO - 2016-12-01 23:01:21 --> Helper loaded: url_helper
INFO - 2016-12-01 23:01:22 --> Helper loaded: form_helper
INFO - 2016-12-01 23:01:22 --> Database Driver Class Initialized
INFO - 2016-12-01 23:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 23:01:22 --> Controller Class Initialized
INFO - 2016-12-01 23:01:22 --> Model Class Initialized
INFO - 2016-12-01 23:01:22 --> Form Validation Class Initialized
INFO - 2016-12-01 23:01:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-01 23:01:22 --> Pagination Class Initialized
INFO - 2016-12-01 23:01:22 --> Helper loaded: app_helper
INFO - 2016-12-01 23:01:22 --> Email Class Initialized
INFO - 2016-12-01 23:01:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-01 22:01:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-01 22:01:22 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-01 22:01:23 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-01 22:01:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-01 22:01:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-01 22:01:25 --> Final output sent to browser
DEBUG - 2016-12-01 22:01:25 --> Total execution time: 3.7994
