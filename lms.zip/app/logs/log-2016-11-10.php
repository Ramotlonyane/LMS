<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-10 11:08:38 --> Config Class Initialized
INFO - 2016-11-10 11:08:38 --> Hooks Class Initialized
DEBUG - 2016-11-10 11:08:38 --> UTF-8 Support Enabled
INFO - 2016-11-10 11:08:38 --> Utf8 Class Initialized
INFO - 2016-11-10 11:08:38 --> URI Class Initialized
DEBUG - 2016-11-10 11:08:39 --> No URI present. Default controller set.
INFO - 2016-11-10 11:08:39 --> Router Class Initialized
INFO - 2016-11-10 11:08:39 --> Output Class Initialized
INFO - 2016-11-10 11:08:39 --> Security Class Initialized
DEBUG - 2016-11-10 11:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 11:08:39 --> Input Class Initialized
INFO - 2016-11-10 11:08:39 --> Language Class Initialized
INFO - 2016-11-10 11:08:39 --> Loader Class Initialized
INFO - 2016-11-10 11:08:39 --> Helper loaded: url_helper
INFO - 2016-11-10 11:08:39 --> Helper loaded: form_helper
INFO - 2016-11-10 11:08:39 --> Database Driver Class Initialized
INFO - 2016-11-10 11:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 11:08:39 --> Controller Class Initialized
INFO - 2016-11-10 11:08:40 --> Model Class Initialized
INFO - 2016-11-10 11:08:40 --> Model Class Initialized
INFO - 2016-11-10 11:08:40 --> Model Class Initialized
INFO - 2016-11-10 11:08:40 --> Model Class Initialized
INFO - 2016-11-10 11:08:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 11:08:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 11:08:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 11:08:40 --> Final output sent to browser
DEBUG - 2016-11-10 11:08:40 --> Total execution time: 1.5011
INFO - 2016-11-10 11:12:06 --> Config Class Initialized
INFO - 2016-11-10 11:12:06 --> Hooks Class Initialized
DEBUG - 2016-11-10 11:12:06 --> UTF-8 Support Enabled
INFO - 2016-11-10 11:12:06 --> Utf8 Class Initialized
INFO - 2016-11-10 11:12:06 --> URI Class Initialized
INFO - 2016-11-10 11:12:06 --> Router Class Initialized
INFO - 2016-11-10 11:12:06 --> Output Class Initialized
INFO - 2016-11-10 11:12:06 --> Security Class Initialized
DEBUG - 2016-11-10 11:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 11:12:06 --> Input Class Initialized
INFO - 2016-11-10 11:12:06 --> Language Class Initialized
INFO - 2016-11-10 11:12:06 --> Loader Class Initialized
INFO - 2016-11-10 11:12:06 --> Helper loaded: url_helper
INFO - 2016-11-10 11:12:06 --> Helper loaded: form_helper
INFO - 2016-11-10 11:12:06 --> Database Driver Class Initialized
INFO - 2016-11-10 11:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 11:12:06 --> Controller Class Initialized
INFO - 2016-11-10 11:12:06 --> Model Class Initialized
INFO - 2016-11-10 11:12:06 --> Model Class Initialized
INFO - 2016-11-10 11:12:06 --> Model Class Initialized
INFO - 2016-11-10 11:12:06 --> Model Class Initialized
DEBUG - 2016-11-10 11:12:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 11:12:06 --> Model Class Initialized
INFO - 2016-11-10 11:12:06 --> Final output sent to browser
DEBUG - 2016-11-10 11:12:06 --> Total execution time: 0.6260
INFO - 2016-11-10 11:12:06 --> Config Class Initialized
INFO - 2016-11-10 11:12:06 --> Hooks Class Initialized
DEBUG - 2016-11-10 11:12:06 --> UTF-8 Support Enabled
INFO - 2016-11-10 11:12:06 --> Utf8 Class Initialized
INFO - 2016-11-10 11:12:06 --> URI Class Initialized
DEBUG - 2016-11-10 11:12:06 --> No URI present. Default controller set.
INFO - 2016-11-10 11:12:06 --> Router Class Initialized
INFO - 2016-11-10 11:12:06 --> Output Class Initialized
INFO - 2016-11-10 11:12:06 --> Security Class Initialized
DEBUG - 2016-11-10 11:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 11:12:06 --> Input Class Initialized
INFO - 2016-11-10 11:12:06 --> Language Class Initialized
INFO - 2016-11-10 11:12:06 --> Loader Class Initialized
INFO - 2016-11-10 11:12:07 --> Helper loaded: url_helper
INFO - 2016-11-10 11:12:07 --> Helper loaded: form_helper
INFO - 2016-11-10 11:12:07 --> Database Driver Class Initialized
INFO - 2016-11-10 11:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 11:12:07 --> Controller Class Initialized
INFO - 2016-11-10 11:12:07 --> Model Class Initialized
INFO - 2016-11-10 11:12:07 --> Model Class Initialized
INFO - 2016-11-10 11:12:07 --> Model Class Initialized
INFO - 2016-11-10 11:12:07 --> Model Class Initialized
INFO - 2016-11-10 11:12:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 11:12:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 11:12:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 11:12:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 11:12:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 11:12:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 11:12:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 11:12:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 11:12:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 11:12:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 11:12:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 11:12:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 11:12:07 --> Final output sent to browser
DEBUG - 2016-11-10 11:12:07 --> Total execution time: 0.7747
INFO - 2016-11-10 11:12:11 --> Config Class Initialized
INFO - 2016-11-10 11:12:11 --> Hooks Class Initialized
DEBUG - 2016-11-10 11:12:11 --> UTF-8 Support Enabled
INFO - 2016-11-10 11:12:11 --> Utf8 Class Initialized
INFO - 2016-11-10 11:12:11 --> URI Class Initialized
DEBUG - 2016-11-10 11:12:11 --> No URI present. Default controller set.
INFO - 2016-11-10 11:12:11 --> Router Class Initialized
INFO - 2016-11-10 11:12:11 --> Output Class Initialized
INFO - 2016-11-10 11:12:11 --> Security Class Initialized
DEBUG - 2016-11-10 11:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 11:12:11 --> Input Class Initialized
INFO - 2016-11-10 11:12:11 --> Language Class Initialized
INFO - 2016-11-10 11:12:11 --> Loader Class Initialized
INFO - 2016-11-10 11:12:11 --> Helper loaded: url_helper
INFO - 2016-11-10 11:12:11 --> Helper loaded: form_helper
INFO - 2016-11-10 11:12:11 --> Database Driver Class Initialized
INFO - 2016-11-10 11:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 11:12:11 --> Controller Class Initialized
INFO - 2016-11-10 11:12:11 --> Model Class Initialized
INFO - 2016-11-10 11:12:11 --> Model Class Initialized
INFO - 2016-11-10 11:12:11 --> Model Class Initialized
INFO - 2016-11-10 11:12:11 --> Model Class Initialized
INFO - 2016-11-10 11:12:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 11:12:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 11:12:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 11:12:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 11:12:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 11:12:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 11:12:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 11:12:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 11:12:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 11:12:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 11:12:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 11:12:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 11:12:11 --> Final output sent to browser
DEBUG - 2016-11-10 11:12:11 --> Total execution time: 0.2773
INFO - 2016-11-10 11:12:15 --> Config Class Initialized
INFO - 2016-11-10 11:12:15 --> Hooks Class Initialized
DEBUG - 2016-11-10 11:12:16 --> UTF-8 Support Enabled
INFO - 2016-11-10 11:12:16 --> Utf8 Class Initialized
INFO - 2016-11-10 11:12:16 --> URI Class Initialized
INFO - 2016-11-10 11:12:16 --> Router Class Initialized
INFO - 2016-11-10 11:12:16 --> Output Class Initialized
INFO - 2016-11-10 11:12:16 --> Security Class Initialized
DEBUG - 2016-11-10 11:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 11:12:16 --> Input Class Initialized
INFO - 2016-11-10 11:12:16 --> Language Class Initialized
INFO - 2016-11-10 11:12:16 --> Loader Class Initialized
INFO - 2016-11-10 11:12:16 --> Helper loaded: url_helper
INFO - 2016-11-10 11:12:16 --> Helper loaded: form_helper
INFO - 2016-11-10 11:12:16 --> Database Driver Class Initialized
INFO - 2016-11-10 11:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 11:12:16 --> Controller Class Initialized
INFO - 2016-11-10 11:12:16 --> Model Class Initialized
INFO - 2016-11-10 11:12:16 --> Form Validation Class Initialized
INFO - 2016-11-10 11:12:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-10 11:12:16 --> Final output sent to browser
DEBUG - 2016-11-10 11:12:16 --> Total execution time: 0.4792
INFO - 2016-11-10 11:12:18 --> Config Class Initialized
INFO - 2016-11-10 11:12:18 --> Hooks Class Initialized
DEBUG - 2016-11-10 11:12:18 --> UTF-8 Support Enabled
INFO - 2016-11-10 11:12:18 --> Utf8 Class Initialized
INFO - 2016-11-10 11:12:18 --> URI Class Initialized
DEBUG - 2016-11-10 11:12:18 --> No URI present. Default controller set.
INFO - 2016-11-10 11:12:18 --> Router Class Initialized
INFO - 2016-11-10 11:12:18 --> Output Class Initialized
INFO - 2016-11-10 11:12:18 --> Security Class Initialized
DEBUG - 2016-11-10 11:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 11:12:18 --> Input Class Initialized
INFO - 2016-11-10 11:12:18 --> Language Class Initialized
INFO - 2016-11-10 11:12:18 --> Loader Class Initialized
INFO - 2016-11-10 11:12:18 --> Helper loaded: url_helper
INFO - 2016-11-10 11:12:18 --> Helper loaded: form_helper
INFO - 2016-11-10 11:12:18 --> Database Driver Class Initialized
INFO - 2016-11-10 11:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 11:12:18 --> Controller Class Initialized
INFO - 2016-11-10 11:12:18 --> Model Class Initialized
INFO - 2016-11-10 11:12:18 --> Model Class Initialized
INFO - 2016-11-10 11:12:18 --> Model Class Initialized
INFO - 2016-11-10 11:12:18 --> Model Class Initialized
INFO - 2016-11-10 11:12:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 11:12:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 11:12:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 11:12:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 11:12:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 11:12:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 11:12:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 11:12:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 11:12:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 11:12:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 11:12:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 11:12:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 11:12:18 --> Final output sent to browser
DEBUG - 2016-11-10 11:12:18 --> Total execution time: 0.2803
INFO - 2016-11-10 11:19:02 --> Config Class Initialized
INFO - 2016-11-10 11:19:02 --> Hooks Class Initialized
DEBUG - 2016-11-10 11:19:02 --> UTF-8 Support Enabled
INFO - 2016-11-10 11:19:02 --> Utf8 Class Initialized
INFO - 2016-11-10 11:19:02 --> URI Class Initialized
INFO - 2016-11-10 11:19:02 --> Router Class Initialized
INFO - 2016-11-10 11:19:02 --> Output Class Initialized
INFO - 2016-11-10 11:19:02 --> Security Class Initialized
DEBUG - 2016-11-10 11:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 11:19:02 --> Input Class Initialized
INFO - 2016-11-10 11:19:02 --> Language Class Initialized
INFO - 2016-11-10 11:19:02 --> Loader Class Initialized
INFO - 2016-11-10 11:19:02 --> Helper loaded: url_helper
INFO - 2016-11-10 11:19:02 --> Helper loaded: form_helper
INFO - 2016-11-10 11:19:02 --> Database Driver Class Initialized
INFO - 2016-11-10 11:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 11:19:02 --> Controller Class Initialized
INFO - 2016-11-10 11:19:02 --> Model Class Initialized
INFO - 2016-11-10 11:19:02 --> Model Class Initialized
INFO - 2016-11-10 11:19:02 --> Model Class Initialized
INFO - 2016-11-10 11:19:02 --> Model Class Initialized
DEBUG - 2016-11-10 11:19:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 11:19:02 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 129
ERROR - 2016-11-10 11:19:02 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 129
INFO - 2016-11-10 11:19:02 --> Config Class Initialized
INFO - 2016-11-10 11:19:02 --> Hooks Class Initialized
DEBUG - 2016-11-10 11:19:02 --> UTF-8 Support Enabled
INFO - 2016-11-10 11:19:02 --> Utf8 Class Initialized
INFO - 2016-11-10 11:19:02 --> URI Class Initialized
DEBUG - 2016-11-10 11:19:02 --> No URI present. Default controller set.
INFO - 2016-11-10 11:19:02 --> Router Class Initialized
INFO - 2016-11-10 11:19:02 --> Output Class Initialized
INFO - 2016-11-10 11:19:02 --> Security Class Initialized
DEBUG - 2016-11-10 11:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 11:19:02 --> Input Class Initialized
INFO - 2016-11-10 11:19:02 --> Language Class Initialized
INFO - 2016-11-10 11:19:02 --> Loader Class Initialized
INFO - 2016-11-10 11:19:02 --> Helper loaded: url_helper
INFO - 2016-11-10 11:19:02 --> Helper loaded: form_helper
INFO - 2016-11-10 11:19:02 --> Database Driver Class Initialized
INFO - 2016-11-10 11:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 11:19:02 --> Controller Class Initialized
INFO - 2016-11-10 11:19:02 --> Model Class Initialized
INFO - 2016-11-10 11:19:02 --> Model Class Initialized
INFO - 2016-11-10 11:19:02 --> Model Class Initialized
INFO - 2016-11-10 11:19:02 --> Model Class Initialized
INFO - 2016-11-10 11:19:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 11:19:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 11:19:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 11:19:02 --> Final output sent to browser
DEBUG - 2016-11-10 11:19:02 --> Total execution time: 0.2067
INFO - 2016-11-10 11:19:15 --> Config Class Initialized
INFO - 2016-11-10 11:19:15 --> Hooks Class Initialized
DEBUG - 2016-11-10 11:19:15 --> UTF-8 Support Enabled
INFO - 2016-11-10 11:19:15 --> Utf8 Class Initialized
INFO - 2016-11-10 11:19:15 --> URI Class Initialized
INFO - 2016-11-10 11:19:15 --> Router Class Initialized
INFO - 2016-11-10 11:19:15 --> Output Class Initialized
INFO - 2016-11-10 11:19:15 --> Security Class Initialized
DEBUG - 2016-11-10 11:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 11:19:15 --> Input Class Initialized
INFO - 2016-11-10 11:19:15 --> Language Class Initialized
INFO - 2016-11-10 11:19:15 --> Loader Class Initialized
INFO - 2016-11-10 11:19:15 --> Helper loaded: url_helper
INFO - 2016-11-10 11:19:15 --> Helper loaded: form_helper
INFO - 2016-11-10 11:19:15 --> Database Driver Class Initialized
INFO - 2016-11-10 11:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 11:19:15 --> Controller Class Initialized
INFO - 2016-11-10 11:19:15 --> Model Class Initialized
INFO - 2016-11-10 11:19:15 --> Model Class Initialized
INFO - 2016-11-10 11:19:15 --> Model Class Initialized
INFO - 2016-11-10 11:19:15 --> Model Class Initialized
DEBUG - 2016-11-10 11:19:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 11:19:15 --> Model Class Initialized
INFO - 2016-11-10 11:19:15 --> Final output sent to browser
DEBUG - 2016-11-10 11:19:15 --> Total execution time: 0.1829
INFO - 2016-11-10 11:19:15 --> Config Class Initialized
INFO - 2016-11-10 11:19:15 --> Hooks Class Initialized
DEBUG - 2016-11-10 11:19:15 --> UTF-8 Support Enabled
INFO - 2016-11-10 11:19:15 --> Utf8 Class Initialized
INFO - 2016-11-10 11:19:15 --> URI Class Initialized
DEBUG - 2016-11-10 11:19:15 --> No URI present. Default controller set.
INFO - 2016-11-10 11:19:15 --> Router Class Initialized
INFO - 2016-11-10 11:19:15 --> Output Class Initialized
INFO - 2016-11-10 11:19:15 --> Security Class Initialized
DEBUG - 2016-11-10 11:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 11:19:16 --> Input Class Initialized
INFO - 2016-11-10 11:19:16 --> Language Class Initialized
INFO - 2016-11-10 11:19:16 --> Loader Class Initialized
INFO - 2016-11-10 11:19:16 --> Helper loaded: url_helper
INFO - 2016-11-10 11:19:16 --> Helper loaded: form_helper
INFO - 2016-11-10 11:19:16 --> Database Driver Class Initialized
INFO - 2016-11-10 11:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 11:19:16 --> Controller Class Initialized
INFO - 2016-11-10 11:19:16 --> Model Class Initialized
INFO - 2016-11-10 11:19:16 --> Model Class Initialized
INFO - 2016-11-10 11:19:16 --> Model Class Initialized
INFO - 2016-11-10 11:19:16 --> Model Class Initialized
INFO - 2016-11-10 11:19:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 11:19:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 11:19:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 11:19:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-10 11:19:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-10 11:19:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-10 11:19:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-10 11:19:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-10 11:19:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-10 11:19:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 11:19:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 11:19:16 --> Final output sent to browser
DEBUG - 2016-11-10 11:19:16 --> Total execution time: 0.2955
INFO - 2016-11-10 11:22:10 --> Config Class Initialized
INFO - 2016-11-10 11:22:10 --> Hooks Class Initialized
DEBUG - 2016-11-10 11:22:10 --> UTF-8 Support Enabled
INFO - 2016-11-10 11:22:10 --> Utf8 Class Initialized
INFO - 2016-11-10 11:22:10 --> URI Class Initialized
INFO - 2016-11-10 11:22:10 --> Router Class Initialized
INFO - 2016-11-10 11:22:10 --> Output Class Initialized
INFO - 2016-11-10 11:22:10 --> Security Class Initialized
DEBUG - 2016-11-10 11:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 11:22:10 --> Input Class Initialized
INFO - 2016-11-10 11:22:10 --> Language Class Initialized
INFO - 2016-11-10 11:22:10 --> Loader Class Initialized
INFO - 2016-11-10 11:22:10 --> Helper loaded: url_helper
INFO - 2016-11-10 11:22:10 --> Helper loaded: form_helper
INFO - 2016-11-10 11:22:10 --> Database Driver Class Initialized
INFO - 2016-11-10 11:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 11:22:10 --> Controller Class Initialized
INFO - 2016-11-10 11:22:10 --> Model Class Initialized
INFO - 2016-11-10 11:22:10 --> Model Class Initialized
INFO - 2016-11-10 11:22:10 --> Model Class Initialized
INFO - 2016-11-10 11:22:10 --> Model Class Initialized
DEBUG - 2016-11-10 11:22:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 11:22:10 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 129
ERROR - 2016-11-10 11:22:10 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 129
INFO - 2016-11-10 11:22:10 --> Config Class Initialized
INFO - 2016-11-10 11:22:10 --> Hooks Class Initialized
DEBUG - 2016-11-10 11:22:10 --> UTF-8 Support Enabled
INFO - 2016-11-10 11:22:10 --> Utf8 Class Initialized
INFO - 2016-11-10 11:22:10 --> URI Class Initialized
DEBUG - 2016-11-10 11:22:10 --> No URI present. Default controller set.
INFO - 2016-11-10 11:22:10 --> Router Class Initialized
INFO - 2016-11-10 11:22:10 --> Output Class Initialized
INFO - 2016-11-10 11:22:10 --> Security Class Initialized
DEBUG - 2016-11-10 11:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 11:22:10 --> Input Class Initialized
INFO - 2016-11-10 11:22:10 --> Language Class Initialized
INFO - 2016-11-10 11:22:10 --> Loader Class Initialized
INFO - 2016-11-10 11:22:10 --> Helper loaded: url_helper
INFO - 2016-11-10 11:22:10 --> Helper loaded: form_helper
INFO - 2016-11-10 11:22:10 --> Database Driver Class Initialized
INFO - 2016-11-10 11:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 11:22:10 --> Controller Class Initialized
INFO - 2016-11-10 11:22:10 --> Model Class Initialized
INFO - 2016-11-10 11:22:10 --> Model Class Initialized
INFO - 2016-11-10 11:22:10 --> Model Class Initialized
INFO - 2016-11-10 11:22:10 --> Model Class Initialized
INFO - 2016-11-10 11:22:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 11:22:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 11:22:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 11:22:10 --> Final output sent to browser
DEBUG - 2016-11-10 11:22:10 --> Total execution time: 0.2093
INFO - 2016-11-10 11:22:21 --> Config Class Initialized
INFO - 2016-11-10 11:22:21 --> Hooks Class Initialized
DEBUG - 2016-11-10 11:22:21 --> UTF-8 Support Enabled
INFO - 2016-11-10 11:22:21 --> Utf8 Class Initialized
INFO - 2016-11-10 11:22:21 --> URI Class Initialized
INFO - 2016-11-10 11:22:21 --> Router Class Initialized
INFO - 2016-11-10 11:22:21 --> Output Class Initialized
INFO - 2016-11-10 11:22:21 --> Security Class Initialized
DEBUG - 2016-11-10 11:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 11:22:21 --> Input Class Initialized
INFO - 2016-11-10 11:22:21 --> Language Class Initialized
INFO - 2016-11-10 11:22:21 --> Loader Class Initialized
INFO - 2016-11-10 11:22:21 --> Helper loaded: url_helper
INFO - 2016-11-10 11:22:21 --> Helper loaded: form_helper
INFO - 2016-11-10 11:22:21 --> Database Driver Class Initialized
INFO - 2016-11-10 11:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 11:22:21 --> Controller Class Initialized
INFO - 2016-11-10 11:22:21 --> Model Class Initialized
INFO - 2016-11-10 11:22:21 --> Model Class Initialized
INFO - 2016-11-10 11:22:21 --> Model Class Initialized
INFO - 2016-11-10 11:22:21 --> Model Class Initialized
DEBUG - 2016-11-10 11:22:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 11:22:21 --> Model Class Initialized
INFO - 2016-11-10 11:22:21 --> Final output sent to browser
DEBUG - 2016-11-10 11:22:21 --> Total execution time: 0.1799
INFO - 2016-11-10 11:22:21 --> Config Class Initialized
INFO - 2016-11-10 11:22:21 --> Hooks Class Initialized
DEBUG - 2016-11-10 11:22:21 --> UTF-8 Support Enabled
INFO - 2016-11-10 11:22:21 --> Utf8 Class Initialized
INFO - 2016-11-10 11:22:21 --> URI Class Initialized
DEBUG - 2016-11-10 11:22:21 --> No URI present. Default controller set.
INFO - 2016-11-10 11:22:21 --> Router Class Initialized
INFO - 2016-11-10 11:22:21 --> Output Class Initialized
INFO - 2016-11-10 11:22:21 --> Security Class Initialized
DEBUG - 2016-11-10 11:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 11:22:21 --> Input Class Initialized
INFO - 2016-11-10 11:22:21 --> Language Class Initialized
INFO - 2016-11-10 11:22:21 --> Loader Class Initialized
INFO - 2016-11-10 11:22:21 --> Helper loaded: url_helper
INFO - 2016-11-10 11:22:21 --> Helper loaded: form_helper
INFO - 2016-11-10 11:22:21 --> Database Driver Class Initialized
INFO - 2016-11-10 11:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 11:22:21 --> Controller Class Initialized
INFO - 2016-11-10 11:22:21 --> Model Class Initialized
INFO - 2016-11-10 11:22:21 --> Model Class Initialized
INFO - 2016-11-10 11:22:21 --> Model Class Initialized
INFO - 2016-11-10 11:22:21 --> Model Class Initialized
INFO - 2016-11-10 11:22:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 11:22:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 11:22:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 11:22:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 11:22:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 11:22:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 11:22:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 11:22:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 11:22:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 11:22:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 11:22:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 11:22:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 11:22:22 --> Final output sent to browser
DEBUG - 2016-11-10 11:22:22 --> Total execution time: 0.2746
INFO - 2016-11-10 11:23:07 --> Config Class Initialized
INFO - 2016-11-10 11:23:07 --> Hooks Class Initialized
DEBUG - 2016-11-10 11:23:07 --> UTF-8 Support Enabled
INFO - 2016-11-10 11:23:07 --> Utf8 Class Initialized
INFO - 2016-11-10 11:23:07 --> URI Class Initialized
INFO - 2016-11-10 11:23:07 --> Router Class Initialized
INFO - 2016-11-10 11:23:07 --> Output Class Initialized
INFO - 2016-11-10 11:23:07 --> Security Class Initialized
DEBUG - 2016-11-10 11:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 11:23:07 --> Input Class Initialized
INFO - 2016-11-10 11:23:07 --> Language Class Initialized
INFO - 2016-11-10 11:23:07 --> Loader Class Initialized
INFO - 2016-11-10 11:23:07 --> Helper loaded: url_helper
INFO - 2016-11-10 11:23:07 --> Helper loaded: form_helper
INFO - 2016-11-10 11:23:07 --> Database Driver Class Initialized
INFO - 2016-11-10 11:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 11:23:07 --> Controller Class Initialized
INFO - 2016-11-10 11:23:07 --> Model Class Initialized
INFO - 2016-11-10 11:23:07 --> Model Class Initialized
INFO - 2016-11-10 11:23:07 --> Model Class Initialized
INFO - 2016-11-10 11:23:07 --> Model Class Initialized
DEBUG - 2016-11-10 11:23:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 11:23:07 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 129
ERROR - 2016-11-10 11:23:07 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 129
INFO - 2016-11-10 11:23:07 --> Config Class Initialized
INFO - 2016-11-10 11:23:07 --> Hooks Class Initialized
DEBUG - 2016-11-10 11:23:07 --> UTF-8 Support Enabled
INFO - 2016-11-10 11:23:07 --> Utf8 Class Initialized
INFO - 2016-11-10 11:23:07 --> URI Class Initialized
DEBUG - 2016-11-10 11:23:07 --> No URI present. Default controller set.
INFO - 2016-11-10 11:23:07 --> Router Class Initialized
INFO - 2016-11-10 11:23:07 --> Output Class Initialized
INFO - 2016-11-10 11:23:07 --> Security Class Initialized
DEBUG - 2016-11-10 11:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 11:23:07 --> Input Class Initialized
INFO - 2016-11-10 11:23:07 --> Language Class Initialized
INFO - 2016-11-10 11:23:07 --> Loader Class Initialized
INFO - 2016-11-10 11:23:07 --> Helper loaded: url_helper
INFO - 2016-11-10 11:23:07 --> Helper loaded: form_helper
INFO - 2016-11-10 11:23:07 --> Database Driver Class Initialized
INFO - 2016-11-10 11:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 11:23:07 --> Controller Class Initialized
INFO - 2016-11-10 11:23:07 --> Model Class Initialized
INFO - 2016-11-10 11:23:07 --> Model Class Initialized
INFO - 2016-11-10 11:23:07 --> Model Class Initialized
INFO - 2016-11-10 11:23:07 --> Model Class Initialized
INFO - 2016-11-10 11:23:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 11:23:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 11:23:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 11:23:08 --> Final output sent to browser
DEBUG - 2016-11-10 11:23:08 --> Total execution time: 0.2103
INFO - 2016-11-10 11:23:15 --> Config Class Initialized
INFO - 2016-11-10 11:23:15 --> Hooks Class Initialized
DEBUG - 2016-11-10 11:23:15 --> UTF-8 Support Enabled
INFO - 2016-11-10 11:23:15 --> Utf8 Class Initialized
INFO - 2016-11-10 11:23:15 --> URI Class Initialized
INFO - 2016-11-10 11:23:15 --> Router Class Initialized
INFO - 2016-11-10 11:23:15 --> Output Class Initialized
INFO - 2016-11-10 11:23:15 --> Security Class Initialized
DEBUG - 2016-11-10 11:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 11:23:15 --> Input Class Initialized
INFO - 2016-11-10 11:23:15 --> Language Class Initialized
INFO - 2016-11-10 11:23:15 --> Loader Class Initialized
INFO - 2016-11-10 11:23:15 --> Helper loaded: url_helper
INFO - 2016-11-10 11:23:15 --> Helper loaded: form_helper
INFO - 2016-11-10 11:23:15 --> Database Driver Class Initialized
INFO - 2016-11-10 11:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 11:23:15 --> Controller Class Initialized
INFO - 2016-11-10 11:23:15 --> Model Class Initialized
INFO - 2016-11-10 11:23:15 --> Model Class Initialized
INFO - 2016-11-10 11:23:15 --> Model Class Initialized
INFO - 2016-11-10 11:23:15 --> Model Class Initialized
DEBUG - 2016-11-10 11:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 11:23:15 --> Model Class Initialized
INFO - 2016-11-10 11:23:15 --> Final output sent to browser
DEBUG - 2016-11-10 11:23:15 --> Total execution time: 0.1838
INFO - 2016-11-10 11:23:15 --> Config Class Initialized
INFO - 2016-11-10 11:23:15 --> Hooks Class Initialized
DEBUG - 2016-11-10 11:23:15 --> UTF-8 Support Enabled
INFO - 2016-11-10 11:23:15 --> Utf8 Class Initialized
INFO - 2016-11-10 11:23:15 --> URI Class Initialized
DEBUG - 2016-11-10 11:23:15 --> No URI present. Default controller set.
INFO - 2016-11-10 11:23:15 --> Router Class Initialized
INFO - 2016-11-10 11:23:15 --> Output Class Initialized
INFO - 2016-11-10 11:23:15 --> Security Class Initialized
DEBUG - 2016-11-10 11:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 11:23:15 --> Input Class Initialized
INFO - 2016-11-10 11:23:15 --> Language Class Initialized
INFO - 2016-11-10 11:23:15 --> Loader Class Initialized
INFO - 2016-11-10 11:23:15 --> Helper loaded: url_helper
INFO - 2016-11-10 11:23:15 --> Helper loaded: form_helper
INFO - 2016-11-10 11:23:15 --> Database Driver Class Initialized
INFO - 2016-11-10 11:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 11:23:15 --> Controller Class Initialized
INFO - 2016-11-10 11:23:15 --> Model Class Initialized
INFO - 2016-11-10 11:23:15 --> Model Class Initialized
INFO - 2016-11-10 11:23:15 --> Model Class Initialized
INFO - 2016-11-10 11:23:15 --> Model Class Initialized
INFO - 2016-11-10 11:23:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 11:23:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 11:23:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 11:23:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 11:23:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 11:23:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 11:23:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 11:23:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 11:23:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 11:23:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 11:23:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 11:23:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 11:23:15 --> Final output sent to browser
DEBUG - 2016-11-10 11:23:15 --> Total execution time: 0.2913
INFO - 2016-11-10 11:24:15 --> Config Class Initialized
INFO - 2016-11-10 11:24:15 --> Hooks Class Initialized
DEBUG - 2016-11-10 11:24:15 --> UTF-8 Support Enabled
INFO - 2016-11-10 11:24:15 --> Utf8 Class Initialized
INFO - 2016-11-10 11:24:15 --> URI Class Initialized
INFO - 2016-11-10 11:24:15 --> Router Class Initialized
INFO - 2016-11-10 11:24:15 --> Output Class Initialized
INFO - 2016-11-10 11:24:15 --> Security Class Initialized
DEBUG - 2016-11-10 11:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 11:24:15 --> Input Class Initialized
INFO - 2016-11-10 11:24:15 --> Language Class Initialized
INFO - 2016-11-10 11:24:15 --> Loader Class Initialized
INFO - 2016-11-10 11:24:15 --> Helper loaded: url_helper
INFO - 2016-11-10 11:24:15 --> Helper loaded: form_helper
INFO - 2016-11-10 11:24:15 --> Database Driver Class Initialized
INFO - 2016-11-10 11:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 11:24:15 --> Controller Class Initialized
INFO - 2016-11-10 11:24:15 --> Model Class Initialized
INFO - 2016-11-10 11:24:15 --> Model Class Initialized
INFO - 2016-11-10 11:24:15 --> Model Class Initialized
INFO - 2016-11-10 11:24:15 --> Model Class Initialized
DEBUG - 2016-11-10 11:24:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 11:24:15 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 129
ERROR - 2016-11-10 11:24:15 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 129
INFO - 2016-11-10 11:24:15 --> Config Class Initialized
INFO - 2016-11-10 11:24:15 --> Hooks Class Initialized
DEBUG - 2016-11-10 11:24:15 --> UTF-8 Support Enabled
INFO - 2016-11-10 11:24:15 --> Utf8 Class Initialized
INFO - 2016-11-10 11:24:15 --> URI Class Initialized
DEBUG - 2016-11-10 11:24:15 --> No URI present. Default controller set.
INFO - 2016-11-10 11:24:15 --> Router Class Initialized
INFO - 2016-11-10 11:24:15 --> Output Class Initialized
INFO - 2016-11-10 11:24:15 --> Security Class Initialized
DEBUG - 2016-11-10 11:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 11:24:15 --> Input Class Initialized
INFO - 2016-11-10 11:24:15 --> Language Class Initialized
INFO - 2016-11-10 11:24:15 --> Loader Class Initialized
INFO - 2016-11-10 11:24:15 --> Helper loaded: url_helper
INFO - 2016-11-10 11:24:15 --> Helper loaded: form_helper
INFO - 2016-11-10 11:24:15 --> Database Driver Class Initialized
INFO - 2016-11-10 11:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 11:24:15 --> Controller Class Initialized
INFO - 2016-11-10 11:24:15 --> Model Class Initialized
INFO - 2016-11-10 11:24:15 --> Model Class Initialized
INFO - 2016-11-10 11:24:16 --> Model Class Initialized
INFO - 2016-11-10 11:24:16 --> Model Class Initialized
INFO - 2016-11-10 11:24:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 11:24:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 11:24:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 11:24:16 --> Final output sent to browser
DEBUG - 2016-11-10 11:24:16 --> Total execution time: 0.2185
INFO - 2016-11-10 11:24:38 --> Config Class Initialized
INFO - 2016-11-10 11:24:38 --> Hooks Class Initialized
DEBUG - 2016-11-10 11:24:38 --> UTF-8 Support Enabled
INFO - 2016-11-10 11:24:38 --> Utf8 Class Initialized
INFO - 2016-11-10 11:24:38 --> URI Class Initialized
INFO - 2016-11-10 11:24:38 --> Router Class Initialized
INFO - 2016-11-10 11:24:38 --> Output Class Initialized
INFO - 2016-11-10 11:24:38 --> Security Class Initialized
DEBUG - 2016-11-10 11:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 11:24:38 --> Input Class Initialized
INFO - 2016-11-10 11:24:38 --> Language Class Initialized
INFO - 2016-11-10 11:24:38 --> Loader Class Initialized
INFO - 2016-11-10 11:24:38 --> Helper loaded: url_helper
INFO - 2016-11-10 11:24:38 --> Helper loaded: form_helper
INFO - 2016-11-10 11:24:38 --> Database Driver Class Initialized
INFO - 2016-11-10 11:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 11:24:38 --> Controller Class Initialized
INFO - 2016-11-10 11:24:38 --> Model Class Initialized
INFO - 2016-11-10 11:24:38 --> Model Class Initialized
INFO - 2016-11-10 11:24:38 --> Model Class Initialized
INFO - 2016-11-10 11:24:38 --> Model Class Initialized
DEBUG - 2016-11-10 11:24:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 11:24:38 --> Model Class Initialized
INFO - 2016-11-10 11:24:38 --> Final output sent to browser
DEBUG - 2016-11-10 11:24:38 --> Total execution time: 0.2094
INFO - 2016-11-10 11:24:38 --> Config Class Initialized
INFO - 2016-11-10 11:24:38 --> Hooks Class Initialized
DEBUG - 2016-11-10 11:24:38 --> UTF-8 Support Enabled
INFO - 2016-11-10 11:24:38 --> Utf8 Class Initialized
INFO - 2016-11-10 11:24:38 --> URI Class Initialized
DEBUG - 2016-11-10 11:24:38 --> No URI present. Default controller set.
INFO - 2016-11-10 11:24:38 --> Router Class Initialized
INFO - 2016-11-10 11:24:38 --> Output Class Initialized
INFO - 2016-11-10 11:24:38 --> Security Class Initialized
DEBUG - 2016-11-10 11:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 11:24:38 --> Input Class Initialized
INFO - 2016-11-10 11:24:38 --> Language Class Initialized
INFO - 2016-11-10 11:24:38 --> Loader Class Initialized
INFO - 2016-11-10 11:24:38 --> Helper loaded: url_helper
INFO - 2016-11-10 11:24:38 --> Helper loaded: form_helper
INFO - 2016-11-10 11:24:38 --> Database Driver Class Initialized
INFO - 2016-11-10 11:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 11:24:38 --> Controller Class Initialized
INFO - 2016-11-10 11:24:38 --> Model Class Initialized
INFO - 2016-11-10 11:24:38 --> Model Class Initialized
INFO - 2016-11-10 11:24:38 --> Model Class Initialized
INFO - 2016-11-10 11:24:38 --> Model Class Initialized
INFO - 2016-11-10 11:24:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 11:24:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 11:24:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 11:24:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 11:24:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 11:24:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 11:24:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 11:24:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 11:24:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 11:24:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 11:24:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 11:24:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 11:24:38 --> Final output sent to browser
DEBUG - 2016-11-10 11:24:38 --> Total execution time: 0.2937
INFO - 2016-11-10 11:30:42 --> Config Class Initialized
INFO - 2016-11-10 11:30:42 --> Hooks Class Initialized
DEBUG - 2016-11-10 11:30:42 --> UTF-8 Support Enabled
INFO - 2016-11-10 11:30:42 --> Utf8 Class Initialized
INFO - 2016-11-10 11:30:42 --> URI Class Initialized
INFO - 2016-11-10 11:30:42 --> Router Class Initialized
INFO - 2016-11-10 11:30:42 --> Output Class Initialized
INFO - 2016-11-10 11:30:42 --> Security Class Initialized
DEBUG - 2016-11-10 11:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 11:30:42 --> Input Class Initialized
INFO - 2016-11-10 11:30:42 --> Language Class Initialized
INFO - 2016-11-10 11:30:42 --> Loader Class Initialized
INFO - 2016-11-10 11:30:42 --> Helper loaded: url_helper
INFO - 2016-11-10 11:30:42 --> Helper loaded: form_helper
INFO - 2016-11-10 11:30:42 --> Database Driver Class Initialized
INFO - 2016-11-10 11:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 11:30:42 --> Controller Class Initialized
INFO - 2016-11-10 11:30:42 --> Model Class Initialized
INFO - 2016-11-10 11:30:42 --> Form Validation Class Initialized
INFO - 2016-11-10 11:30:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-10 11:30:42 --> Final output sent to browser
DEBUG - 2016-11-10 11:30:42 --> Total execution time: 0.2697
INFO - 2016-11-10 11:30:43 --> Config Class Initialized
INFO - 2016-11-10 11:30:43 --> Hooks Class Initialized
DEBUG - 2016-11-10 11:30:44 --> UTF-8 Support Enabled
INFO - 2016-11-10 11:30:44 --> Utf8 Class Initialized
INFO - 2016-11-10 11:30:44 --> URI Class Initialized
DEBUG - 2016-11-10 11:30:44 --> No URI present. Default controller set.
INFO - 2016-11-10 11:30:44 --> Router Class Initialized
INFO - 2016-11-10 11:30:44 --> Output Class Initialized
INFO - 2016-11-10 11:30:44 --> Security Class Initialized
DEBUG - 2016-11-10 11:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 11:30:44 --> Input Class Initialized
INFO - 2016-11-10 11:30:44 --> Language Class Initialized
INFO - 2016-11-10 11:30:44 --> Loader Class Initialized
INFO - 2016-11-10 11:30:44 --> Helper loaded: url_helper
INFO - 2016-11-10 11:30:44 --> Helper loaded: form_helper
INFO - 2016-11-10 11:30:44 --> Database Driver Class Initialized
INFO - 2016-11-10 11:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 11:30:44 --> Controller Class Initialized
INFO - 2016-11-10 11:30:44 --> Model Class Initialized
INFO - 2016-11-10 11:30:44 --> Model Class Initialized
INFO - 2016-11-10 11:30:44 --> Model Class Initialized
INFO - 2016-11-10 11:30:44 --> Model Class Initialized
INFO - 2016-11-10 11:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 11:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 11:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 11:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 11:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 11:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 11:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 11:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 11:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 11:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 11:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 11:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 11:30:44 --> Final output sent to browser
DEBUG - 2016-11-10 11:30:44 --> Total execution time: 0.3464
INFO - 2016-11-10 12:16:56 --> Config Class Initialized
INFO - 2016-11-10 12:16:56 --> Hooks Class Initialized
DEBUG - 2016-11-10 12:16:56 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:16:56 --> Utf8 Class Initialized
INFO - 2016-11-10 12:16:56 --> URI Class Initialized
DEBUG - 2016-11-10 12:16:56 --> No URI present. Default controller set.
INFO - 2016-11-10 12:16:56 --> Router Class Initialized
INFO - 2016-11-10 12:16:56 --> Output Class Initialized
INFO - 2016-11-10 12:16:56 --> Security Class Initialized
DEBUG - 2016-11-10 12:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:16:56 --> Input Class Initialized
INFO - 2016-11-10 12:16:56 --> Language Class Initialized
INFO - 2016-11-10 12:16:56 --> Loader Class Initialized
INFO - 2016-11-10 12:16:56 --> Helper loaded: url_helper
INFO - 2016-11-10 12:16:56 --> Helper loaded: form_helper
INFO - 2016-11-10 12:16:56 --> Database Driver Class Initialized
INFO - 2016-11-10 12:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:16:56 --> Controller Class Initialized
INFO - 2016-11-10 12:16:56 --> Model Class Initialized
INFO - 2016-11-10 12:16:56 --> Model Class Initialized
INFO - 2016-11-10 12:16:56 --> Model Class Initialized
INFO - 2016-11-10 12:16:56 --> Model Class Initialized
INFO - 2016-11-10 12:16:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 12:16:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 12:16:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 12:16:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 12:16:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 12:16:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 12:16:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 12:16:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 12:16:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 12:16:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 12:16:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 12:16:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 12:16:56 --> Final output sent to browser
DEBUG - 2016-11-10 12:16:56 --> Total execution time: 0.3095
INFO - 2016-11-10 12:33:31 --> Config Class Initialized
INFO - 2016-11-10 12:33:31 --> Hooks Class Initialized
DEBUG - 2016-11-10 12:33:31 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:33:31 --> Utf8 Class Initialized
INFO - 2016-11-10 12:33:31 --> URI Class Initialized
DEBUG - 2016-11-10 12:33:31 --> No URI present. Default controller set.
INFO - 2016-11-10 12:33:31 --> Router Class Initialized
INFO - 2016-11-10 12:33:31 --> Output Class Initialized
INFO - 2016-11-10 12:33:31 --> Security Class Initialized
DEBUG - 2016-11-10 12:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:33:31 --> Input Class Initialized
INFO - 2016-11-10 12:33:31 --> Language Class Initialized
INFO - 2016-11-10 12:33:31 --> Loader Class Initialized
INFO - 2016-11-10 12:33:31 --> Helper loaded: url_helper
INFO - 2016-11-10 12:33:31 --> Helper loaded: form_helper
INFO - 2016-11-10 12:33:31 --> Database Driver Class Initialized
INFO - 2016-11-10 12:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:33:31 --> Controller Class Initialized
INFO - 2016-11-10 12:33:31 --> Model Class Initialized
INFO - 2016-11-10 12:33:31 --> Model Class Initialized
INFO - 2016-11-10 12:33:31 --> Model Class Initialized
INFO - 2016-11-10 12:33:31 --> Model Class Initialized
INFO - 2016-11-10 12:33:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 12:33:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 12:33:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 12:33:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 12:33:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 12:33:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 12:33:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 12:33:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 12:33:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 12:33:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 12:33:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 12:33:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 12:33:31 --> Final output sent to browser
DEBUG - 2016-11-10 12:33:31 --> Total execution time: 0.3480
INFO - 2016-11-10 12:34:06 --> Config Class Initialized
INFO - 2016-11-10 12:34:06 --> Hooks Class Initialized
DEBUG - 2016-11-10 12:34:06 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:34:06 --> Utf8 Class Initialized
INFO - 2016-11-10 12:34:06 --> URI Class Initialized
DEBUG - 2016-11-10 12:34:06 --> No URI present. Default controller set.
INFO - 2016-11-10 12:34:06 --> Router Class Initialized
INFO - 2016-11-10 12:34:06 --> Output Class Initialized
INFO - 2016-11-10 12:34:06 --> Security Class Initialized
DEBUG - 2016-11-10 12:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:34:06 --> Input Class Initialized
INFO - 2016-11-10 12:34:06 --> Language Class Initialized
INFO - 2016-11-10 12:34:06 --> Loader Class Initialized
INFO - 2016-11-10 12:34:06 --> Helper loaded: url_helper
INFO - 2016-11-10 12:34:06 --> Helper loaded: form_helper
INFO - 2016-11-10 12:34:06 --> Database Driver Class Initialized
INFO - 2016-11-10 12:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:34:06 --> Controller Class Initialized
INFO - 2016-11-10 12:34:06 --> Model Class Initialized
INFO - 2016-11-10 12:34:06 --> Model Class Initialized
INFO - 2016-11-10 12:34:06 --> Model Class Initialized
INFO - 2016-11-10 12:34:06 --> Model Class Initialized
INFO - 2016-11-10 12:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 12:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 12:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 12:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 12:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 12:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 12:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
ERROR - 2016-11-10 12:34:06 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_records.php 20
ERROR - 2016-11-10 12:34:07 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_records.php 20
ERROR - 2016-11-10 12:34:07 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_records.php 20
ERROR - 2016-11-10 12:34:07 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_records.php 20
ERROR - 2016-11-10 12:34:07 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_records.php 20
ERROR - 2016-11-10 12:34:07 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_records.php 20
ERROR - 2016-11-10 12:34:07 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_records.php 20
ERROR - 2016-11-10 12:34:07 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_records.php 20
ERROR - 2016-11-10 12:34:07 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_records.php 20
INFO - 2016-11-10 12:34:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 12:34:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 12:34:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 12:34:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 12:34:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 12:34:07 --> Final output sent to browser
DEBUG - 2016-11-10 12:34:07 --> Total execution time: 0.4151
INFO - 2016-11-10 12:34:49 --> Config Class Initialized
INFO - 2016-11-10 12:34:49 --> Hooks Class Initialized
DEBUG - 2016-11-10 12:34:49 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:34:49 --> Utf8 Class Initialized
INFO - 2016-11-10 12:34:49 --> URI Class Initialized
DEBUG - 2016-11-10 12:34:49 --> No URI present. Default controller set.
INFO - 2016-11-10 12:34:49 --> Router Class Initialized
INFO - 2016-11-10 12:34:49 --> Output Class Initialized
INFO - 2016-11-10 12:34:49 --> Security Class Initialized
DEBUG - 2016-11-10 12:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:34:49 --> Input Class Initialized
INFO - 2016-11-10 12:34:49 --> Language Class Initialized
INFO - 2016-11-10 12:34:49 --> Loader Class Initialized
INFO - 2016-11-10 12:34:49 --> Helper loaded: url_helper
INFO - 2016-11-10 12:34:49 --> Helper loaded: form_helper
INFO - 2016-11-10 12:34:49 --> Database Driver Class Initialized
INFO - 2016-11-10 12:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:34:49 --> Controller Class Initialized
INFO - 2016-11-10 12:34:49 --> Model Class Initialized
INFO - 2016-11-10 12:34:49 --> Model Class Initialized
INFO - 2016-11-10 12:34:49 --> Model Class Initialized
INFO - 2016-11-10 12:34:49 --> Model Class Initialized
INFO - 2016-11-10 12:34:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 12:34:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 12:34:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 12:34:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 12:34:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 12:34:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 12:34:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 12:34:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 12:34:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 12:34:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 12:34:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 12:34:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 12:34:50 --> Final output sent to browser
DEBUG - 2016-11-10 12:34:50 --> Total execution time: 0.4622
INFO - 2016-11-10 12:36:27 --> Config Class Initialized
INFO - 2016-11-10 12:36:27 --> Hooks Class Initialized
DEBUG - 2016-11-10 12:36:27 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:36:27 --> Utf8 Class Initialized
INFO - 2016-11-10 12:36:27 --> URI Class Initialized
DEBUG - 2016-11-10 12:36:27 --> No URI present. Default controller set.
INFO - 2016-11-10 12:36:27 --> Router Class Initialized
INFO - 2016-11-10 12:36:27 --> Output Class Initialized
INFO - 2016-11-10 12:36:27 --> Security Class Initialized
DEBUG - 2016-11-10 12:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:36:27 --> Input Class Initialized
INFO - 2016-11-10 12:36:27 --> Language Class Initialized
INFO - 2016-11-10 12:36:27 --> Loader Class Initialized
INFO - 2016-11-10 12:36:27 --> Helper loaded: url_helper
INFO - 2016-11-10 12:36:27 --> Helper loaded: form_helper
INFO - 2016-11-10 12:36:27 --> Database Driver Class Initialized
INFO - 2016-11-10 12:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:36:27 --> Controller Class Initialized
INFO - 2016-11-10 12:36:27 --> Model Class Initialized
INFO - 2016-11-10 12:36:27 --> Model Class Initialized
INFO - 2016-11-10 12:36:27 --> Model Class Initialized
INFO - 2016-11-10 12:36:27 --> Model Class Initialized
INFO - 2016-11-10 12:36:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 12:36:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 12:36:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 12:36:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 12:36:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 12:36:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 12:36:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 12:36:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 12:36:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 12:36:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 12:36:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 12:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 12:36:28 --> Final output sent to browser
DEBUG - 2016-11-10 12:36:28 --> Total execution time: 0.3392
INFO - 2016-11-10 12:38:04 --> Config Class Initialized
INFO - 2016-11-10 12:38:04 --> Hooks Class Initialized
DEBUG - 2016-11-10 12:38:04 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:38:04 --> Utf8 Class Initialized
INFO - 2016-11-10 12:38:04 --> URI Class Initialized
DEBUG - 2016-11-10 12:38:04 --> No URI present. Default controller set.
INFO - 2016-11-10 12:38:04 --> Router Class Initialized
INFO - 2016-11-10 12:38:04 --> Output Class Initialized
INFO - 2016-11-10 12:38:04 --> Security Class Initialized
DEBUG - 2016-11-10 12:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:38:04 --> Input Class Initialized
INFO - 2016-11-10 12:38:04 --> Language Class Initialized
INFO - 2016-11-10 12:38:04 --> Loader Class Initialized
INFO - 2016-11-10 12:38:04 --> Helper loaded: url_helper
INFO - 2016-11-10 12:38:04 --> Helper loaded: form_helper
INFO - 2016-11-10 12:38:04 --> Database Driver Class Initialized
INFO - 2016-11-10 12:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:38:04 --> Controller Class Initialized
INFO - 2016-11-10 12:38:04 --> Model Class Initialized
INFO - 2016-11-10 12:38:04 --> Model Class Initialized
INFO - 2016-11-10 12:38:04 --> Model Class Initialized
INFO - 2016-11-10 12:38:04 --> Model Class Initialized
INFO - 2016-11-10 12:38:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 12:38:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 12:38:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 12:38:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 12:38:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 12:38:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 12:38:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 12:38:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 12:38:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 12:38:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 12:38:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 12:38:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 12:38:04 --> Final output sent to browser
DEBUG - 2016-11-10 12:38:04 --> Total execution time: 0.3297
INFO - 2016-11-10 12:38:16 --> Config Class Initialized
INFO - 2016-11-10 12:38:16 --> Hooks Class Initialized
DEBUG - 2016-11-10 12:38:16 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:38:16 --> Utf8 Class Initialized
INFO - 2016-11-10 12:38:16 --> URI Class Initialized
INFO - 2016-11-10 12:38:16 --> Router Class Initialized
INFO - 2016-11-10 12:38:16 --> Output Class Initialized
INFO - 2016-11-10 12:38:16 --> Security Class Initialized
DEBUG - 2016-11-10 12:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:38:16 --> Input Class Initialized
INFO - 2016-11-10 12:38:16 --> Language Class Initialized
INFO - 2016-11-10 12:38:16 --> Loader Class Initialized
INFO - 2016-11-10 12:38:16 --> Helper loaded: url_helper
INFO - 2016-11-10 12:38:16 --> Helper loaded: form_helper
INFO - 2016-11-10 12:38:16 --> Database Driver Class Initialized
INFO - 2016-11-10 12:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:38:16 --> Controller Class Initialized
INFO - 2016-11-10 12:38:16 --> Model Class Initialized
INFO - 2016-11-10 12:38:17 --> Form Validation Class Initialized
INFO - 2016-11-10 12:38:17 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-10 12:38:17 --> Severity: Error --> Call to undefined method Leave_record_m::all_leave_record() C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 72
INFO - 2016-11-10 12:42:13 --> Config Class Initialized
INFO - 2016-11-10 12:42:13 --> Hooks Class Initialized
DEBUG - 2016-11-10 12:42:13 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:42:13 --> Utf8 Class Initialized
INFO - 2016-11-10 12:42:13 --> URI Class Initialized
DEBUG - 2016-11-10 12:42:13 --> No URI present. Default controller set.
INFO - 2016-11-10 12:42:13 --> Router Class Initialized
INFO - 2016-11-10 12:42:13 --> Output Class Initialized
INFO - 2016-11-10 12:42:13 --> Security Class Initialized
DEBUG - 2016-11-10 12:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:42:13 --> Input Class Initialized
INFO - 2016-11-10 12:42:13 --> Language Class Initialized
INFO - 2016-11-10 12:42:13 --> Loader Class Initialized
INFO - 2016-11-10 12:42:13 --> Helper loaded: url_helper
INFO - 2016-11-10 12:42:13 --> Helper loaded: form_helper
INFO - 2016-11-10 12:42:13 --> Database Driver Class Initialized
INFO - 2016-11-10 12:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:42:13 --> Controller Class Initialized
INFO - 2016-11-10 12:42:13 --> Model Class Initialized
INFO - 2016-11-10 12:42:13 --> Model Class Initialized
INFO - 2016-11-10 12:42:13 --> Model Class Initialized
INFO - 2016-11-10 12:42:13 --> Model Class Initialized
INFO - 2016-11-10 12:42:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 12:42:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 12:42:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 12:42:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 12:42:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 12:42:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 12:42:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 12:42:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
ERROR - 2016-11-10 12:42:14 --> Severity: Notice --> Undefined property: stdClass::$startDate C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 16
ERROR - 2016-11-10 12:42:14 --> Severity: Notice --> Undefined property: stdClass::$endDate C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 12:42:14 --> Severity: Notice --> Undefined property: stdClass::$applicationDate C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 18
ERROR - 2016-11-10 12:42:14 --> Severity: Notice --> Undefined property: stdClass::$numberOfDays C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 19
INFO - 2016-11-10 12:42:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 12:42:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 12:42:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 12:42:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 12:42:14 --> Final output sent to browser
DEBUG - 2016-11-10 12:42:14 --> Total execution time: 0.3456
INFO - 2016-11-10 12:42:30 --> Config Class Initialized
INFO - 2016-11-10 12:42:30 --> Hooks Class Initialized
DEBUG - 2016-11-10 12:42:30 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:42:30 --> Utf8 Class Initialized
INFO - 2016-11-10 12:42:30 --> URI Class Initialized
INFO - 2016-11-10 12:42:30 --> Router Class Initialized
INFO - 2016-11-10 12:42:30 --> Output Class Initialized
INFO - 2016-11-10 12:42:30 --> Security Class Initialized
DEBUG - 2016-11-10 12:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:42:30 --> Input Class Initialized
INFO - 2016-11-10 12:42:30 --> Language Class Initialized
INFO - 2016-11-10 12:42:30 --> Loader Class Initialized
INFO - 2016-11-10 12:42:30 --> Helper loaded: url_helper
INFO - 2016-11-10 12:42:30 --> Helper loaded: form_helper
INFO - 2016-11-10 12:42:30 --> Database Driver Class Initialized
INFO - 2016-11-10 12:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:42:30 --> Controller Class Initialized
INFO - 2016-11-10 12:42:30 --> Model Class Initialized
INFO - 2016-11-10 12:42:30 --> Form Validation Class Initialized
INFO - 2016-11-10 12:42:30 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-10 12:42:30 --> Severity: Error --> Call to undefined method Leave_record_m::all_leave_record() C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 72
INFO - 2016-11-10 12:51:11 --> Config Class Initialized
INFO - 2016-11-10 12:51:11 --> Hooks Class Initialized
DEBUG - 2016-11-10 12:51:11 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:51:11 --> Utf8 Class Initialized
INFO - 2016-11-10 12:51:11 --> URI Class Initialized
INFO - 2016-11-10 12:51:11 --> Router Class Initialized
INFO - 2016-11-10 12:51:11 --> Output Class Initialized
INFO - 2016-11-10 12:51:11 --> Security Class Initialized
DEBUG - 2016-11-10 12:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:51:11 --> Input Class Initialized
INFO - 2016-11-10 12:51:11 --> Language Class Initialized
INFO - 2016-11-10 12:51:11 --> Loader Class Initialized
INFO - 2016-11-10 12:51:11 --> Helper loaded: url_helper
INFO - 2016-11-10 12:51:11 --> Helper loaded: form_helper
INFO - 2016-11-10 12:51:11 --> Database Driver Class Initialized
INFO - 2016-11-10 12:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:51:11 --> Controller Class Initialized
INFO - 2016-11-10 12:51:11 --> Model Class Initialized
INFO - 2016-11-10 12:51:11 --> Form Validation Class Initialized
INFO - 2016-11-10 12:51:11 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-10 12:51:11 --> Severity: Error --> Call to undefined method Leave_record_m::all_leave_record() C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 72
INFO - 2016-11-10 12:52:03 --> Config Class Initialized
INFO - 2016-11-10 12:52:03 --> Hooks Class Initialized
DEBUG - 2016-11-10 12:52:03 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:52:03 --> Utf8 Class Initialized
INFO - 2016-11-10 12:52:03 --> URI Class Initialized
INFO - 2016-11-10 12:52:03 --> Router Class Initialized
INFO - 2016-11-10 12:52:03 --> Output Class Initialized
INFO - 2016-11-10 12:52:03 --> Security Class Initialized
DEBUG - 2016-11-10 12:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:52:03 --> Input Class Initialized
INFO - 2016-11-10 12:52:04 --> Language Class Initialized
INFO - 2016-11-10 12:52:04 --> Loader Class Initialized
INFO - 2016-11-10 12:52:04 --> Helper loaded: url_helper
INFO - 2016-11-10 12:52:04 --> Helper loaded: form_helper
INFO - 2016-11-10 12:52:04 --> Database Driver Class Initialized
INFO - 2016-11-10 12:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:52:04 --> Controller Class Initialized
INFO - 2016-11-10 12:52:04 --> Model Class Initialized
INFO - 2016-11-10 12:52:04 --> Form Validation Class Initialized
INFO - 2016-11-10 12:52:04 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-10 12:52:04 --> Severity: Error --> Call to undefined method Leave_record_m::all_leave_record() C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 72
INFO - 2016-11-10 12:53:26 --> Config Class Initialized
INFO - 2016-11-10 12:53:26 --> Hooks Class Initialized
DEBUG - 2016-11-10 12:53:26 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:53:26 --> Utf8 Class Initialized
INFO - 2016-11-10 12:53:26 --> URI Class Initialized
INFO - 2016-11-10 12:53:26 --> Router Class Initialized
INFO - 2016-11-10 12:53:26 --> Output Class Initialized
INFO - 2016-11-10 12:53:26 --> Security Class Initialized
DEBUG - 2016-11-10 12:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:53:26 --> Input Class Initialized
INFO - 2016-11-10 12:53:26 --> Language Class Initialized
INFO - 2016-11-10 12:53:26 --> Loader Class Initialized
INFO - 2016-11-10 12:53:26 --> Helper loaded: url_helper
INFO - 2016-11-10 12:53:26 --> Helper loaded: form_helper
INFO - 2016-11-10 12:53:26 --> Database Driver Class Initialized
INFO - 2016-11-10 12:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:53:26 --> Controller Class Initialized
INFO - 2016-11-10 12:53:26 --> Model Class Initialized
INFO - 2016-11-10 12:53:26 --> Form Validation Class Initialized
INFO - 2016-11-10 12:53:26 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-10 12:53:26 --> Severity: Notice --> Undefined property: stdClass::$endDate C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 12:53:26 --> Severity: Notice --> Undefined property: stdClass::$applicationDate C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 18
ERROR - 2016-11-10 12:53:26 --> Severity: Notice --> Undefined property: stdClass::$numberOfDays C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 19
ERROR - 2016-11-10 12:53:26 --> Severity: Notice --> Undefined property: stdClass::$endDate C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 12:53:26 --> Severity: Notice --> Undefined property: stdClass::$applicationDate C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 18
ERROR - 2016-11-10 12:53:26 --> Severity: Notice --> Undefined property: stdClass::$numberOfDays C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 19
ERROR - 2016-11-10 12:53:26 --> Severity: Notice --> Undefined property: stdClass::$endDate C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 12:53:26 --> Severity: Notice --> Undefined property: stdClass::$applicationDate C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 18
ERROR - 2016-11-10 12:53:26 --> Severity: Notice --> Undefined property: stdClass::$numberOfDays C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 19
ERROR - 2016-11-10 12:53:26 --> Severity: Notice --> Undefined property: stdClass::$endDate C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 12:53:26 --> Severity: Notice --> Undefined property: stdClass::$applicationDate C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 18
ERROR - 2016-11-10 12:53:26 --> Severity: Notice --> Undefined property: stdClass::$numberOfDays C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 19
ERROR - 2016-11-10 12:53:26 --> Severity: Notice --> Undefined property: stdClass::$endDate C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 12:53:26 --> Severity: Notice --> Undefined property: stdClass::$applicationDate C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 18
ERROR - 2016-11-10 12:53:26 --> Severity: Notice --> Undefined property: stdClass::$numberOfDays C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 19
INFO - 2016-11-10 12:53:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 12:53:26 --> Final output sent to browser
DEBUG - 2016-11-10 12:53:26 --> Total execution time: 0.7110
INFO - 2016-11-10 12:53:32 --> Config Class Initialized
INFO - 2016-11-10 12:53:32 --> Hooks Class Initialized
DEBUG - 2016-11-10 12:53:32 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:53:32 --> Utf8 Class Initialized
INFO - 2016-11-10 12:53:32 --> URI Class Initialized
DEBUG - 2016-11-10 12:53:32 --> No URI present. Default controller set.
INFO - 2016-11-10 12:53:32 --> Router Class Initialized
INFO - 2016-11-10 12:53:32 --> Output Class Initialized
INFO - 2016-11-10 12:53:32 --> Security Class Initialized
DEBUG - 2016-11-10 12:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:53:32 --> Input Class Initialized
INFO - 2016-11-10 12:53:32 --> Language Class Initialized
INFO - 2016-11-10 12:53:32 --> Loader Class Initialized
INFO - 2016-11-10 12:53:32 --> Helper loaded: url_helper
INFO - 2016-11-10 12:53:32 --> Helper loaded: form_helper
INFO - 2016-11-10 12:53:33 --> Database Driver Class Initialized
INFO - 2016-11-10 12:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:53:33 --> Controller Class Initialized
INFO - 2016-11-10 12:53:33 --> Model Class Initialized
INFO - 2016-11-10 12:53:33 --> Model Class Initialized
INFO - 2016-11-10 12:53:33 --> Model Class Initialized
INFO - 2016-11-10 12:53:33 --> Model Class Initialized
INFO - 2016-11-10 12:53:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 12:53:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 12:53:33 --> Severity: Error --> Call to undefined method Leave_record_m::all_leave_records() C:\xampp\htdocs\LMS\app\controllers\Auth.php 59
INFO - 2016-11-10 12:53:35 --> Config Class Initialized
INFO - 2016-11-10 12:53:35 --> Hooks Class Initialized
DEBUG - 2016-11-10 12:53:35 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:53:35 --> Utf8 Class Initialized
INFO - 2016-11-10 12:53:35 --> URI Class Initialized
DEBUG - 2016-11-10 12:53:35 --> No URI present. Default controller set.
INFO - 2016-11-10 12:53:35 --> Router Class Initialized
INFO - 2016-11-10 12:53:35 --> Output Class Initialized
INFO - 2016-11-10 12:53:35 --> Security Class Initialized
DEBUG - 2016-11-10 12:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:53:35 --> Input Class Initialized
INFO - 2016-11-10 12:53:35 --> Language Class Initialized
INFO - 2016-11-10 12:53:35 --> Loader Class Initialized
INFO - 2016-11-10 12:53:35 --> Helper loaded: url_helper
INFO - 2016-11-10 12:53:35 --> Helper loaded: form_helper
INFO - 2016-11-10 12:53:35 --> Database Driver Class Initialized
INFO - 2016-11-10 12:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:53:35 --> Controller Class Initialized
INFO - 2016-11-10 12:53:35 --> Model Class Initialized
INFO - 2016-11-10 12:53:35 --> Model Class Initialized
INFO - 2016-11-10 12:53:35 --> Model Class Initialized
INFO - 2016-11-10 12:53:35 --> Model Class Initialized
INFO - 2016-11-10 12:53:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 12:53:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 12:53:35 --> Severity: Error --> Call to undefined method Leave_record_m::all_leave_records() C:\xampp\htdocs\LMS\app\controllers\Auth.php 59
INFO - 2016-11-10 12:53:36 --> Config Class Initialized
INFO - 2016-11-10 12:53:36 --> Hooks Class Initialized
DEBUG - 2016-11-10 12:53:36 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:53:36 --> Utf8 Class Initialized
INFO - 2016-11-10 12:53:36 --> URI Class Initialized
DEBUG - 2016-11-10 12:53:36 --> No URI present. Default controller set.
INFO - 2016-11-10 12:53:36 --> Router Class Initialized
INFO - 2016-11-10 12:53:36 --> Output Class Initialized
INFO - 2016-11-10 12:53:36 --> Security Class Initialized
DEBUG - 2016-11-10 12:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:53:36 --> Input Class Initialized
INFO - 2016-11-10 12:53:36 --> Language Class Initialized
INFO - 2016-11-10 12:53:36 --> Loader Class Initialized
INFO - 2016-11-10 12:53:36 --> Helper loaded: url_helper
INFO - 2016-11-10 12:53:36 --> Helper loaded: form_helper
INFO - 2016-11-10 12:53:36 --> Database Driver Class Initialized
INFO - 2016-11-10 12:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:53:36 --> Controller Class Initialized
INFO - 2016-11-10 12:53:36 --> Model Class Initialized
INFO - 2016-11-10 12:53:36 --> Model Class Initialized
INFO - 2016-11-10 12:53:36 --> Model Class Initialized
INFO - 2016-11-10 12:53:36 --> Model Class Initialized
INFO - 2016-11-10 12:53:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 12:53:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 12:53:36 --> Severity: Error --> Call to undefined method Leave_record_m::all_leave_records() C:\xampp\htdocs\LMS\app\controllers\Auth.php 59
INFO - 2016-11-10 12:53:37 --> Config Class Initialized
INFO - 2016-11-10 12:53:37 --> Hooks Class Initialized
DEBUG - 2016-11-10 12:53:37 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:53:37 --> Utf8 Class Initialized
INFO - 2016-11-10 12:53:37 --> URI Class Initialized
DEBUG - 2016-11-10 12:53:37 --> No URI present. Default controller set.
INFO - 2016-11-10 12:53:37 --> Router Class Initialized
INFO - 2016-11-10 12:53:37 --> Output Class Initialized
INFO - 2016-11-10 12:53:37 --> Security Class Initialized
DEBUG - 2016-11-10 12:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:53:37 --> Input Class Initialized
INFO - 2016-11-10 12:53:37 --> Language Class Initialized
INFO - 2016-11-10 12:53:37 --> Loader Class Initialized
INFO - 2016-11-10 12:53:37 --> Helper loaded: url_helper
INFO - 2016-11-10 12:53:37 --> Helper loaded: form_helper
INFO - 2016-11-10 12:53:37 --> Config Class Initialized
INFO - 2016-11-10 12:53:37 --> Hooks Class Initialized
INFO - 2016-11-10 12:53:37 --> Database Driver Class Initialized
DEBUG - 2016-11-10 12:53:37 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:53:37 --> Utf8 Class Initialized
INFO - 2016-11-10 12:53:37 --> Controller Class Initialized
INFO - 2016-11-10 12:53:37 --> URI Class Initialized
INFO - 2016-11-10 12:53:37 --> Model Class Initialized
DEBUG - 2016-11-10 12:53:37 --> No URI present. Default controller set.
INFO - 2016-11-10 12:53:37 --> Model Class Initialized
INFO - 2016-11-10 12:53:37 --> Router Class Initialized
INFO - 2016-11-10 12:53:37 --> Model Class Initialized
INFO - 2016-11-10 12:53:37 --> Output Class Initialized
INFO - 2016-11-10 12:53:37 --> Model Class Initialized
INFO - 2016-11-10 12:53:37 --> Security Class Initialized
INFO - 2016-11-10 12:53:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
DEBUG - 2016-11-10 12:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:53:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 12:53:37 --> Input Class Initialized
INFO - 2016-11-10 12:53:37 --> Language Class Initialized
ERROR - 2016-11-10 12:53:37 --> Severity: Error --> Call to undefined method Leave_record_m::all_leave_records() C:\xampp\htdocs\LMS\app\controllers\Auth.php 59
INFO - 2016-11-10 12:53:37 --> Loader Class Initialized
INFO - 2016-11-10 12:53:37 --> Helper loaded: url_helper
INFO - 2016-11-10 12:53:37 --> Helper loaded: form_helper
INFO - 2016-11-10 12:53:37 --> Database Driver Class Initialized
INFO - 2016-11-10 12:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:53:37 --> Controller Class Initialized
INFO - 2016-11-10 12:53:37 --> Model Class Initialized
INFO - 2016-11-10 12:53:37 --> Model Class Initialized
INFO - 2016-11-10 12:53:37 --> Model Class Initialized
INFO - 2016-11-10 12:53:37 --> Model Class Initialized
INFO - 2016-11-10 12:53:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 12:53:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 12:53:37 --> Severity: Error --> Call to undefined method Leave_record_m::all_leave_records() C:\xampp\htdocs\LMS\app\controllers\Auth.php 59
INFO - 2016-11-10 12:53:40 --> Config Class Initialized
INFO - 2016-11-10 12:53:40 --> Hooks Class Initialized
DEBUG - 2016-11-10 12:53:40 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:53:40 --> Utf8 Class Initialized
INFO - 2016-11-10 12:53:40 --> URI Class Initialized
DEBUG - 2016-11-10 12:53:40 --> No URI present. Default controller set.
INFO - 2016-11-10 12:53:40 --> Router Class Initialized
INFO - 2016-11-10 12:53:40 --> Output Class Initialized
INFO - 2016-11-10 12:53:40 --> Security Class Initialized
DEBUG - 2016-11-10 12:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:53:40 --> Input Class Initialized
INFO - 2016-11-10 12:53:40 --> Language Class Initialized
INFO - 2016-11-10 12:53:40 --> Loader Class Initialized
INFO - 2016-11-10 12:53:40 --> Helper loaded: url_helper
INFO - 2016-11-10 12:53:40 --> Helper loaded: form_helper
INFO - 2016-11-10 12:53:40 --> Database Driver Class Initialized
INFO - 2016-11-10 12:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:53:40 --> Controller Class Initialized
INFO - 2016-11-10 12:53:40 --> Model Class Initialized
INFO - 2016-11-10 12:53:40 --> Model Class Initialized
INFO - 2016-11-10 12:53:40 --> Model Class Initialized
INFO - 2016-11-10 12:53:40 --> Model Class Initialized
INFO - 2016-11-10 12:53:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 12:53:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 12:53:41 --> Severity: Error --> Call to undefined method Leave_record_m::all_leave_records() C:\xampp\htdocs\LMS\app\controllers\Auth.php 59
INFO - 2016-11-10 12:54:00 --> Config Class Initialized
INFO - 2016-11-10 12:54:00 --> Hooks Class Initialized
DEBUG - 2016-11-10 12:54:00 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:54:00 --> Utf8 Class Initialized
INFO - 2016-11-10 12:54:00 --> URI Class Initialized
DEBUG - 2016-11-10 12:54:00 --> No URI present. Default controller set.
INFO - 2016-11-10 12:54:00 --> Router Class Initialized
INFO - 2016-11-10 12:54:00 --> Output Class Initialized
INFO - 2016-11-10 12:54:00 --> Security Class Initialized
DEBUG - 2016-11-10 12:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:54:00 --> Input Class Initialized
INFO - 2016-11-10 12:54:00 --> Language Class Initialized
INFO - 2016-11-10 12:54:00 --> Loader Class Initialized
INFO - 2016-11-10 12:54:00 --> Helper loaded: url_helper
INFO - 2016-11-10 12:54:00 --> Helper loaded: form_helper
INFO - 2016-11-10 12:54:00 --> Database Driver Class Initialized
INFO - 2016-11-10 12:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:54:00 --> Controller Class Initialized
INFO - 2016-11-10 12:54:00 --> Model Class Initialized
INFO - 2016-11-10 12:54:00 --> Model Class Initialized
INFO - 2016-11-10 12:54:00 --> Model Class Initialized
INFO - 2016-11-10 12:54:00 --> Model Class Initialized
INFO - 2016-11-10 12:54:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 12:54:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 12:54:00 --> Severity: Error --> Call to undefined method Leave_record_m::all_leave_records() C:\xampp\htdocs\LMS\app\controllers\Auth.php 59
INFO - 2016-11-10 12:54:11 --> Config Class Initialized
INFO - 2016-11-10 12:54:11 --> Hooks Class Initialized
DEBUG - 2016-11-10 12:54:11 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:54:11 --> Utf8 Class Initialized
INFO - 2016-11-10 12:54:11 --> URI Class Initialized
DEBUG - 2016-11-10 12:54:11 --> No URI present. Default controller set.
INFO - 2016-11-10 12:54:11 --> Router Class Initialized
INFO - 2016-11-10 12:54:11 --> Output Class Initialized
INFO - 2016-11-10 12:54:11 --> Security Class Initialized
DEBUG - 2016-11-10 12:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:54:11 --> Input Class Initialized
INFO - 2016-11-10 12:54:11 --> Language Class Initialized
INFO - 2016-11-10 12:54:11 --> Loader Class Initialized
INFO - 2016-11-10 12:54:11 --> Helper loaded: url_helper
INFO - 2016-11-10 12:54:11 --> Helper loaded: form_helper
INFO - 2016-11-10 12:54:11 --> Database Driver Class Initialized
INFO - 2016-11-10 12:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:54:11 --> Controller Class Initialized
INFO - 2016-11-10 12:54:11 --> Model Class Initialized
INFO - 2016-11-10 12:54:11 --> Model Class Initialized
INFO - 2016-11-10 12:54:11 --> Model Class Initialized
INFO - 2016-11-10 12:54:11 --> Model Class Initialized
INFO - 2016-11-10 12:54:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 12:54:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 12:54:11 --> Severity: Error --> Call to undefined method Leave_record_m::all_leave_records() C:\xampp\htdocs\LMS\app\controllers\Auth.php 59
INFO - 2016-11-10 12:54:11 --> Config Class Initialized
INFO - 2016-11-10 12:54:11 --> Hooks Class Initialized
DEBUG - 2016-11-10 12:54:12 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:54:12 --> Utf8 Class Initialized
INFO - 2016-11-10 12:54:12 --> URI Class Initialized
DEBUG - 2016-11-10 12:54:12 --> No URI present. Default controller set.
INFO - 2016-11-10 12:54:12 --> Router Class Initialized
INFO - 2016-11-10 12:54:12 --> Output Class Initialized
INFO - 2016-11-10 12:54:12 --> Security Class Initialized
DEBUG - 2016-11-10 12:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:54:12 --> Input Class Initialized
INFO - 2016-11-10 12:54:12 --> Language Class Initialized
INFO - 2016-11-10 12:54:12 --> Loader Class Initialized
INFO - 2016-11-10 12:54:12 --> Helper loaded: url_helper
INFO - 2016-11-10 12:54:12 --> Helper loaded: form_helper
INFO - 2016-11-10 12:54:12 --> Config Class Initialized
INFO - 2016-11-10 12:54:12 --> Database Driver Class Initialized
INFO - 2016-11-10 12:54:12 --> Hooks Class Initialized
DEBUG - 2016-11-10 12:54:12 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:54:12 --> Utf8 Class Initialized
INFO - 2016-11-10 12:54:12 --> Controller Class Initialized
INFO - 2016-11-10 12:54:12 --> URI Class Initialized
INFO - 2016-11-10 12:54:12 --> Model Class Initialized
DEBUG - 2016-11-10 12:54:12 --> No URI present. Default controller set.
INFO - 2016-11-10 12:54:12 --> Model Class Initialized
INFO - 2016-11-10 12:54:12 --> Router Class Initialized
INFO - 2016-11-10 12:54:12 --> Model Class Initialized
INFO - 2016-11-10 12:54:12 --> Output Class Initialized
INFO - 2016-11-10 12:54:12 --> Model Class Initialized
INFO - 2016-11-10 12:54:12 --> Security Class Initialized
INFO - 2016-11-10 12:54:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
DEBUG - 2016-11-10 12:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:54:12 --> Input Class Initialized
INFO - 2016-11-10 12:54:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 12:54:12 --> Config Class Initialized
ERROR - 2016-11-10 12:54:12 --> Severity: Error --> Call to undefined method Leave_record_m::all_leave_records() C:\xampp\htdocs\LMS\app\controllers\Auth.php 59
INFO - 2016-11-10 12:54:12 --> Hooks Class Initialized
INFO - 2016-11-10 12:54:12 --> Language Class Initialized
INFO - 2016-11-10 12:54:12 --> Loader Class Initialized
DEBUG - 2016-11-10 12:54:12 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:54:12 --> Utf8 Class Initialized
INFO - 2016-11-10 12:54:12 --> Helper loaded: url_helper
INFO - 2016-11-10 12:54:12 --> URI Class Initialized
INFO - 2016-11-10 12:54:12 --> Helper loaded: form_helper
DEBUG - 2016-11-10 12:54:12 --> No URI present. Default controller set.
INFO - 2016-11-10 12:54:12 --> Database Driver Class Initialized
INFO - 2016-11-10 12:54:12 --> Router Class Initialized
INFO - 2016-11-10 12:54:12 --> Output Class Initialized
INFO - 2016-11-10 12:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:54:12 --> Security Class Initialized
INFO - 2016-11-10 12:54:12 --> Controller Class Initialized
INFO - 2016-11-10 12:54:12 --> Model Class Initialized
DEBUG - 2016-11-10 12:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:54:12 --> Model Class Initialized
INFO - 2016-11-10 12:54:12 --> Input Class Initialized
INFO - 2016-11-10 12:54:12 --> Model Class Initialized
INFO - 2016-11-10 12:54:12 --> Language Class Initialized
INFO - 2016-11-10 12:54:12 --> Model Class Initialized
INFO - 2016-11-10 12:54:12 --> Loader Class Initialized
INFO - 2016-11-10 12:54:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 12:54:12 --> Helper loaded: url_helper
INFO - 2016-11-10 12:54:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 12:54:12 --> Helper loaded: form_helper
ERROR - 2016-11-10 12:54:12 --> Severity: Error --> Call to undefined method Leave_record_m::all_leave_records() C:\xampp\htdocs\LMS\app\controllers\Auth.php 59
INFO - 2016-11-10 12:54:12 --> Database Driver Class Initialized
INFO - 2016-11-10 12:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:54:12 --> Controller Class Initialized
INFO - 2016-11-10 12:54:12 --> Model Class Initialized
INFO - 2016-11-10 12:54:12 --> Model Class Initialized
INFO - 2016-11-10 12:54:12 --> Model Class Initialized
INFO - 2016-11-10 12:54:12 --> Model Class Initialized
INFO - 2016-11-10 12:54:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 12:54:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 12:54:12 --> Severity: Error --> Call to undefined method Leave_record_m::all_leave_records() C:\xampp\htdocs\LMS\app\controllers\Auth.php 59
INFO - 2016-11-10 12:54:13 --> Config Class Initialized
INFO - 2016-11-10 12:54:13 --> Hooks Class Initialized
DEBUG - 2016-11-10 12:54:13 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:54:13 --> Utf8 Class Initialized
INFO - 2016-11-10 12:54:13 --> URI Class Initialized
DEBUG - 2016-11-10 12:54:13 --> No URI present. Default controller set.
INFO - 2016-11-10 12:54:13 --> Router Class Initialized
INFO - 2016-11-10 12:54:13 --> Output Class Initialized
INFO - 2016-11-10 12:54:13 --> Security Class Initialized
DEBUG - 2016-11-10 12:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:54:13 --> Input Class Initialized
INFO - 2016-11-10 12:54:13 --> Language Class Initialized
INFO - 2016-11-10 12:54:13 --> Loader Class Initialized
INFO - 2016-11-10 12:54:13 --> Helper loaded: url_helper
INFO - 2016-11-10 12:54:13 --> Helper loaded: form_helper
INFO - 2016-11-10 12:54:13 --> Database Driver Class Initialized
INFO - 2016-11-10 12:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:54:13 --> Controller Class Initialized
INFO - 2016-11-10 12:54:13 --> Model Class Initialized
INFO - 2016-11-10 12:54:14 --> Model Class Initialized
INFO - 2016-11-10 12:54:14 --> Model Class Initialized
INFO - 2016-11-10 12:54:14 --> Model Class Initialized
INFO - 2016-11-10 12:54:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 12:54:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 12:54:14 --> Severity: Error --> Call to undefined method Leave_record_m::all_leave_records() C:\xampp\htdocs\LMS\app\controllers\Auth.php 59
INFO - 2016-11-10 12:55:55 --> Config Class Initialized
INFO - 2016-11-10 12:55:55 --> Hooks Class Initialized
DEBUG - 2016-11-10 12:55:55 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:55:55 --> Utf8 Class Initialized
INFO - 2016-11-10 12:55:55 --> URI Class Initialized
DEBUG - 2016-11-10 12:55:55 --> No URI present. Default controller set.
INFO - 2016-11-10 12:55:55 --> Router Class Initialized
INFO - 2016-11-10 12:55:55 --> Output Class Initialized
INFO - 2016-11-10 12:55:55 --> Security Class Initialized
DEBUG - 2016-11-10 12:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:55:55 --> Input Class Initialized
INFO - 2016-11-10 12:55:55 --> Language Class Initialized
INFO - 2016-11-10 12:55:55 --> Loader Class Initialized
INFO - 2016-11-10 12:55:55 --> Helper loaded: url_helper
INFO - 2016-11-10 12:55:55 --> Helper loaded: form_helper
INFO - 2016-11-10 12:55:55 --> Database Driver Class Initialized
INFO - 2016-11-10 12:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:55:55 --> Controller Class Initialized
INFO - 2016-11-10 12:55:55 --> Model Class Initialized
INFO - 2016-11-10 12:55:55 --> Model Class Initialized
INFO - 2016-11-10 12:55:55 --> Model Class Initialized
INFO - 2016-11-10 12:55:55 --> Model Class Initialized
INFO - 2016-11-10 12:55:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 12:55:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 12:55:55 --> Severity: Error --> Call to undefined method Leave_record_m::all_leave_records() C:\xampp\htdocs\LMS\app\controllers\Auth.php 59
INFO - 2016-11-10 12:55:56 --> Config Class Initialized
INFO - 2016-11-10 12:55:56 --> Hooks Class Initialized
DEBUG - 2016-11-10 12:55:56 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:55:56 --> Utf8 Class Initialized
INFO - 2016-11-10 12:55:56 --> URI Class Initialized
DEBUG - 2016-11-10 12:55:56 --> No URI present. Default controller set.
INFO - 2016-11-10 12:55:56 --> Router Class Initialized
INFO - 2016-11-10 12:55:56 --> Output Class Initialized
INFO - 2016-11-10 12:55:56 --> Security Class Initialized
DEBUG - 2016-11-10 12:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:55:56 --> Input Class Initialized
INFO - 2016-11-10 12:55:56 --> Language Class Initialized
INFO - 2016-11-10 12:55:56 --> Loader Class Initialized
INFO - 2016-11-10 12:55:56 --> Helper loaded: url_helper
INFO - 2016-11-10 12:55:56 --> Helper loaded: form_helper
INFO - 2016-11-10 12:55:56 --> Database Driver Class Initialized
INFO - 2016-11-10 12:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:55:56 --> Controller Class Initialized
INFO - 2016-11-10 12:55:56 --> Model Class Initialized
INFO - 2016-11-10 12:55:56 --> Model Class Initialized
INFO - 2016-11-10 12:55:56 --> Model Class Initialized
INFO - 2016-11-10 12:55:56 --> Model Class Initialized
INFO - 2016-11-10 12:55:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 12:55:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 12:55:57 --> Severity: Error --> Call to undefined method Leave_record_m::all_leave_records() C:\xampp\htdocs\LMS\app\controllers\Auth.php 59
INFO - 2016-11-10 12:56:21 --> Config Class Initialized
INFO - 2016-11-10 12:56:21 --> Hooks Class Initialized
DEBUG - 2016-11-10 12:56:21 --> UTF-8 Support Enabled
INFO - 2016-11-10 12:56:21 --> Utf8 Class Initialized
INFO - 2016-11-10 12:56:21 --> URI Class Initialized
DEBUG - 2016-11-10 12:56:21 --> No URI present. Default controller set.
INFO - 2016-11-10 12:56:21 --> Router Class Initialized
INFO - 2016-11-10 12:56:21 --> Output Class Initialized
INFO - 2016-11-10 12:56:21 --> Security Class Initialized
DEBUG - 2016-11-10 12:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 12:56:21 --> Input Class Initialized
INFO - 2016-11-10 12:56:21 --> Language Class Initialized
INFO - 2016-11-10 12:56:21 --> Loader Class Initialized
INFO - 2016-11-10 12:56:21 --> Helper loaded: url_helper
INFO - 2016-11-10 12:56:21 --> Helper loaded: form_helper
INFO - 2016-11-10 12:56:21 --> Database Driver Class Initialized
INFO - 2016-11-10 12:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 12:56:21 --> Controller Class Initialized
INFO - 2016-11-10 12:56:21 --> Model Class Initialized
INFO - 2016-11-10 12:56:21 --> Model Class Initialized
INFO - 2016-11-10 12:56:21 --> Model Class Initialized
INFO - 2016-11-10 12:56:21 --> Model Class Initialized
INFO - 2016-11-10 12:56:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 12:56:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 12:56:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 12:56:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 12:56:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 12:56:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 12:56:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 12:56:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 12:56:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 12:56:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 12:56:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 12:56:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 12:56:21 --> Final output sent to browser
DEBUG - 2016-11-10 12:56:21 --> Total execution time: 0.3523
INFO - 2016-11-10 13:07:57 --> Config Class Initialized
INFO - 2016-11-10 13:07:57 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:07:57 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:07:57 --> Utf8 Class Initialized
INFO - 2016-11-10 13:07:57 --> URI Class Initialized
DEBUG - 2016-11-10 13:07:57 --> No URI present. Default controller set.
INFO - 2016-11-10 13:07:57 --> Router Class Initialized
INFO - 2016-11-10 13:07:57 --> Output Class Initialized
INFO - 2016-11-10 13:07:57 --> Security Class Initialized
DEBUG - 2016-11-10 13:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:07:57 --> Input Class Initialized
INFO - 2016-11-10 13:07:57 --> Language Class Initialized
INFO - 2016-11-10 13:07:57 --> Loader Class Initialized
INFO - 2016-11-10 13:07:57 --> Helper loaded: url_helper
INFO - 2016-11-10 13:07:57 --> Helper loaded: form_helper
INFO - 2016-11-10 13:07:57 --> Database Driver Class Initialized
INFO - 2016-11-10 13:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:07:57 --> Controller Class Initialized
INFO - 2016-11-10 13:07:57 --> Model Class Initialized
INFO - 2016-11-10 13:07:57 --> Model Class Initialized
INFO - 2016-11-10 13:07:57 --> Model Class Initialized
ERROR - 2016-11-10 13:07:57 --> Severity: Parsing Error --> syntax error, unexpected 'return' (T_RETURN) C:\xampp\htdocs\LMS\app\models\Leave_record_m.php 27
INFO - 2016-11-10 13:08:25 --> Config Class Initialized
INFO - 2016-11-10 13:08:25 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:08:25 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:08:25 --> Utf8 Class Initialized
INFO - 2016-11-10 13:08:25 --> URI Class Initialized
DEBUG - 2016-11-10 13:08:25 --> No URI present. Default controller set.
INFO - 2016-11-10 13:08:25 --> Router Class Initialized
INFO - 2016-11-10 13:08:25 --> Output Class Initialized
INFO - 2016-11-10 13:08:25 --> Security Class Initialized
DEBUG - 2016-11-10 13:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:08:25 --> Input Class Initialized
INFO - 2016-11-10 13:08:25 --> Language Class Initialized
INFO - 2016-11-10 13:08:25 --> Loader Class Initialized
INFO - 2016-11-10 13:08:25 --> Helper loaded: url_helper
INFO - 2016-11-10 13:08:25 --> Helper loaded: form_helper
INFO - 2016-11-10 13:08:25 --> Database Driver Class Initialized
INFO - 2016-11-10 13:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:08:25 --> Controller Class Initialized
INFO - 2016-11-10 13:08:25 --> Model Class Initialized
INFO - 2016-11-10 13:08:25 --> Model Class Initialized
INFO - 2016-11-10 13:08:25 --> Model Class Initialized
ERROR - 2016-11-10 13:08:25 --> Severity: Parsing Error --> syntax error, unexpected 'return' (T_RETURN) C:\xampp\htdocs\LMS\app\models\Leave_record_m.php 27
INFO - 2016-11-10 13:09:26 --> Config Class Initialized
INFO - 2016-11-10 13:09:26 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:09:26 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:09:26 --> Utf8 Class Initialized
INFO - 2016-11-10 13:09:26 --> URI Class Initialized
DEBUG - 2016-11-10 13:09:26 --> No URI present. Default controller set.
INFO - 2016-11-10 13:09:26 --> Router Class Initialized
INFO - 2016-11-10 13:09:26 --> Output Class Initialized
INFO - 2016-11-10 13:09:26 --> Security Class Initialized
DEBUG - 2016-11-10 13:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:09:26 --> Input Class Initialized
INFO - 2016-11-10 13:09:26 --> Language Class Initialized
INFO - 2016-11-10 13:09:26 --> Loader Class Initialized
INFO - 2016-11-10 13:09:26 --> Helper loaded: url_helper
INFO - 2016-11-10 13:09:26 --> Helper loaded: form_helper
INFO - 2016-11-10 13:09:26 --> Database Driver Class Initialized
INFO - 2016-11-10 13:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:09:26 --> Controller Class Initialized
INFO - 2016-11-10 13:09:26 --> Model Class Initialized
INFO - 2016-11-10 13:09:26 --> Model Class Initialized
INFO - 2016-11-10 13:09:26 --> Model Class Initialized
INFO - 2016-11-10 13:09:26 --> Model Class Initialized
INFO - 2016-11-10 13:09:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:09:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:09:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:09:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:09:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:09:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:09:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:09:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
ERROR - 2016-11-10 13:09:26 --> Severity: Notice --> Undefined property: stdClass::$idEmployee C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 16
ERROR - 2016-11-10 13:09:26 --> Severity: Notice --> Undefined property: stdClass::$idLeaveType C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:09:26 --> Severity: Notice --> Undefined property: stdClass::$idEmployee C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 16
ERROR - 2016-11-10 13:09:26 --> Severity: Notice --> Undefined property: stdClass::$idLeaveType C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:09:26 --> Severity: Notice --> Undefined property: stdClass::$idEmployee C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 16
ERROR - 2016-11-10 13:09:26 --> Severity: Notice --> Undefined property: stdClass::$idLeaveType C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:09:26 --> Severity: Notice --> Undefined property: stdClass::$idEmployee C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 16
ERROR - 2016-11-10 13:09:26 --> Severity: Notice --> Undefined property: stdClass::$idLeaveType C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:09:26 --> Severity: Notice --> Undefined property: stdClass::$idEmployee C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 16
ERROR - 2016-11-10 13:09:26 --> Severity: Notice --> Undefined property: stdClass::$idLeaveType C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
INFO - 2016-11-10 13:09:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:09:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:09:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:09:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:09:26 --> Final output sent to browser
DEBUG - 2016-11-10 13:09:26 --> Total execution time: 0.4694
INFO - 2016-11-10 13:10:17 --> Config Class Initialized
INFO - 2016-11-10 13:10:17 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:10:17 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:10:17 --> Utf8 Class Initialized
INFO - 2016-11-10 13:10:17 --> URI Class Initialized
DEBUG - 2016-11-10 13:10:17 --> No URI present. Default controller set.
INFO - 2016-11-10 13:10:17 --> Router Class Initialized
INFO - 2016-11-10 13:10:17 --> Output Class Initialized
INFO - 2016-11-10 13:10:17 --> Security Class Initialized
DEBUG - 2016-11-10 13:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:10:17 --> Input Class Initialized
INFO - 2016-11-10 13:10:17 --> Language Class Initialized
INFO - 2016-11-10 13:10:17 --> Loader Class Initialized
INFO - 2016-11-10 13:10:17 --> Helper loaded: url_helper
INFO - 2016-11-10 13:10:17 --> Helper loaded: form_helper
INFO - 2016-11-10 13:10:17 --> Database Driver Class Initialized
INFO - 2016-11-10 13:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:10:17 --> Controller Class Initialized
INFO - 2016-11-10 13:10:17 --> Model Class Initialized
INFO - 2016-11-10 13:10:17 --> Model Class Initialized
INFO - 2016-11-10 13:10:17 --> Model Class Initialized
INFO - 2016-11-10 13:10:17 --> Model Class Initialized
INFO - 2016-11-10 13:10:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:10:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:10:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:10:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:10:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:10:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:10:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:10:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
ERROR - 2016-11-10 13:10:17 --> Severity: Notice --> Undefined property: stdClass::$idLeaveType C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:10:17 --> Severity: Notice --> Undefined property: stdClass::$idLeaveType C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:10:17 --> Severity: Notice --> Undefined property: stdClass::$idLeaveType C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:10:17 --> Severity: Notice --> Undefined property: stdClass::$idLeaveType C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:10:17 --> Severity: Notice --> Undefined property: stdClass::$idLeaveType C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
INFO - 2016-11-10 13:10:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:10:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:10:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:10:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:10:17 --> Final output sent to browser
DEBUG - 2016-11-10 13:10:17 --> Total execution time: 0.3888
INFO - 2016-11-10 13:11:04 --> Config Class Initialized
INFO - 2016-11-10 13:11:04 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:11:04 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:11:04 --> Utf8 Class Initialized
INFO - 2016-11-10 13:11:04 --> URI Class Initialized
DEBUG - 2016-11-10 13:11:04 --> No URI present. Default controller set.
INFO - 2016-11-10 13:11:04 --> Router Class Initialized
INFO - 2016-11-10 13:11:04 --> Output Class Initialized
INFO - 2016-11-10 13:11:04 --> Security Class Initialized
DEBUG - 2016-11-10 13:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:11:04 --> Input Class Initialized
INFO - 2016-11-10 13:11:04 --> Language Class Initialized
INFO - 2016-11-10 13:11:04 --> Loader Class Initialized
INFO - 2016-11-10 13:11:04 --> Helper loaded: url_helper
INFO - 2016-11-10 13:11:04 --> Helper loaded: form_helper
INFO - 2016-11-10 13:11:04 --> Database Driver Class Initialized
INFO - 2016-11-10 13:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:11:04 --> Controller Class Initialized
INFO - 2016-11-10 13:11:04 --> Model Class Initialized
INFO - 2016-11-10 13:11:04 --> Model Class Initialized
INFO - 2016-11-10 13:11:04 --> Model Class Initialized
INFO - 2016-11-10 13:11:04 --> Model Class Initialized
INFO - 2016-11-10 13:11:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:11:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:11:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:11:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:11:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:11:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:11:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:11:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:11:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:11:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:11:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:11:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:11:05 --> Final output sent to browser
DEBUG - 2016-11-10 13:11:05 --> Total execution time: 0.3564
INFO - 2016-11-10 13:11:47 --> Config Class Initialized
INFO - 2016-11-10 13:11:47 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:11:47 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:11:47 --> Utf8 Class Initialized
INFO - 2016-11-10 13:11:47 --> URI Class Initialized
DEBUG - 2016-11-10 13:11:47 --> No URI present. Default controller set.
INFO - 2016-11-10 13:11:47 --> Router Class Initialized
INFO - 2016-11-10 13:11:47 --> Output Class Initialized
INFO - 2016-11-10 13:11:47 --> Security Class Initialized
DEBUG - 2016-11-10 13:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:11:47 --> Input Class Initialized
INFO - 2016-11-10 13:11:47 --> Language Class Initialized
INFO - 2016-11-10 13:11:47 --> Loader Class Initialized
INFO - 2016-11-10 13:11:47 --> Helper loaded: url_helper
INFO - 2016-11-10 13:11:47 --> Helper loaded: form_helper
INFO - 2016-11-10 13:11:47 --> Database Driver Class Initialized
INFO - 2016-11-10 13:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:11:47 --> Controller Class Initialized
INFO - 2016-11-10 13:11:47 --> Model Class Initialized
INFO - 2016-11-10 13:11:47 --> Model Class Initialized
INFO - 2016-11-10 13:11:47 --> Model Class Initialized
INFO - 2016-11-10 13:11:47 --> Model Class Initialized
INFO - 2016-11-10 13:11:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:11:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:11:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:11:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:11:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:11:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:11:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:11:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:11:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:11:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:11:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:11:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:11:47 --> Final output sent to browser
DEBUG - 2016-11-10 13:11:47 --> Total execution time: 0.3591
INFO - 2016-11-10 13:12:55 --> Config Class Initialized
INFO - 2016-11-10 13:12:55 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:12:55 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:12:55 --> Utf8 Class Initialized
INFO - 2016-11-10 13:12:55 --> URI Class Initialized
DEBUG - 2016-11-10 13:12:55 --> No URI present. Default controller set.
INFO - 2016-11-10 13:12:55 --> Router Class Initialized
INFO - 2016-11-10 13:12:55 --> Output Class Initialized
INFO - 2016-11-10 13:12:55 --> Security Class Initialized
DEBUG - 2016-11-10 13:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:12:55 --> Input Class Initialized
INFO - 2016-11-10 13:12:55 --> Language Class Initialized
INFO - 2016-11-10 13:12:55 --> Loader Class Initialized
INFO - 2016-11-10 13:12:55 --> Helper loaded: url_helper
INFO - 2016-11-10 13:12:55 --> Helper loaded: form_helper
INFO - 2016-11-10 13:12:55 --> Database Driver Class Initialized
INFO - 2016-11-10 13:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:12:55 --> Controller Class Initialized
INFO - 2016-11-10 13:12:55 --> Model Class Initialized
INFO - 2016-11-10 13:12:55 --> Model Class Initialized
INFO - 2016-11-10 13:12:55 --> Model Class Initialized
INFO - 2016-11-10 13:12:55 --> Model Class Initialized
INFO - 2016-11-10 13:12:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:12:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 13:12:55 --> Query error: Unknown column 'em.idEmployee' in 'on clause' - Invalid query: SELECT `em`.`surname`, `lt`.`name`, `lv`.`numberOfLeaves`, `lv`.`description`
FROM `leaveRecord` `lv`
LEFT JOIN `employee` as `em` ON `em`.`idEmployee` = `lv`.`id`
LEFT JOIN `leaveType` as `lt` ON `lt`.`idLeaveType` = `lv`.`id`
INFO - 2016-11-10 13:12:55 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 13:13:49 --> Config Class Initialized
INFO - 2016-11-10 13:13:49 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:13:49 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:13:49 --> Utf8 Class Initialized
INFO - 2016-11-10 13:13:49 --> URI Class Initialized
DEBUG - 2016-11-10 13:13:49 --> No URI present. Default controller set.
INFO - 2016-11-10 13:13:49 --> Router Class Initialized
INFO - 2016-11-10 13:13:49 --> Output Class Initialized
INFO - 2016-11-10 13:13:49 --> Security Class Initialized
DEBUG - 2016-11-10 13:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:13:49 --> Input Class Initialized
INFO - 2016-11-10 13:13:49 --> Language Class Initialized
INFO - 2016-11-10 13:13:49 --> Loader Class Initialized
INFO - 2016-11-10 13:13:49 --> Helper loaded: url_helper
INFO - 2016-11-10 13:13:49 --> Helper loaded: form_helper
INFO - 2016-11-10 13:13:49 --> Database Driver Class Initialized
INFO - 2016-11-10 13:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:13:49 --> Controller Class Initialized
INFO - 2016-11-10 13:13:49 --> Model Class Initialized
INFO - 2016-11-10 13:13:49 --> Model Class Initialized
INFO - 2016-11-10 13:13:49 --> Model Class Initialized
INFO - 2016-11-10 13:13:49 --> Model Class Initialized
INFO - 2016-11-10 13:13:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:13:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:13:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:13:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:13:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:13:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:13:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:13:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:13:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:13:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:13:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:13:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:13:49 --> Final output sent to browser
DEBUG - 2016-11-10 13:13:49 --> Total execution time: 0.3498
INFO - 2016-11-10 13:15:51 --> Config Class Initialized
INFO - 2016-11-10 13:15:51 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:15:51 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:15:51 --> Utf8 Class Initialized
INFO - 2016-11-10 13:15:51 --> URI Class Initialized
DEBUG - 2016-11-10 13:15:51 --> No URI present. Default controller set.
INFO - 2016-11-10 13:15:51 --> Router Class Initialized
INFO - 2016-11-10 13:15:51 --> Output Class Initialized
INFO - 2016-11-10 13:15:51 --> Security Class Initialized
DEBUG - 2016-11-10 13:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:15:51 --> Input Class Initialized
INFO - 2016-11-10 13:15:51 --> Language Class Initialized
INFO - 2016-11-10 13:15:51 --> Loader Class Initialized
INFO - 2016-11-10 13:15:51 --> Helper loaded: url_helper
INFO - 2016-11-10 13:15:51 --> Helper loaded: form_helper
INFO - 2016-11-10 13:15:51 --> Database Driver Class Initialized
INFO - 2016-11-10 13:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:15:51 --> Controller Class Initialized
INFO - 2016-11-10 13:15:51 --> Model Class Initialized
INFO - 2016-11-10 13:15:51 --> Model Class Initialized
INFO - 2016-11-10 13:15:51 --> Model Class Initialized
INFO - 2016-11-10 13:15:51 --> Model Class Initialized
INFO - 2016-11-10 13:15:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:15:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:15:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:15:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:15:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:15:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:15:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:15:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:15:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:15:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:15:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:15:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:15:52 --> Final output sent to browser
DEBUG - 2016-11-10 13:15:52 --> Total execution time: 0.3514
INFO - 2016-11-10 13:16:12 --> Config Class Initialized
INFO - 2016-11-10 13:16:12 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:16:12 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:16:12 --> Utf8 Class Initialized
INFO - 2016-11-10 13:16:12 --> URI Class Initialized
DEBUG - 2016-11-10 13:16:12 --> No URI present. Default controller set.
INFO - 2016-11-10 13:16:12 --> Router Class Initialized
INFO - 2016-11-10 13:16:12 --> Output Class Initialized
INFO - 2016-11-10 13:16:12 --> Security Class Initialized
DEBUG - 2016-11-10 13:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:16:12 --> Input Class Initialized
INFO - 2016-11-10 13:16:12 --> Language Class Initialized
INFO - 2016-11-10 13:16:12 --> Loader Class Initialized
INFO - 2016-11-10 13:16:12 --> Helper loaded: url_helper
INFO - 2016-11-10 13:16:12 --> Helper loaded: form_helper
INFO - 2016-11-10 13:16:13 --> Database Driver Class Initialized
INFO - 2016-11-10 13:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:16:13 --> Controller Class Initialized
INFO - 2016-11-10 13:16:13 --> Model Class Initialized
INFO - 2016-11-10 13:16:13 --> Model Class Initialized
INFO - 2016-11-10 13:16:13 --> Model Class Initialized
INFO - 2016-11-10 13:16:13 --> Model Class Initialized
INFO - 2016-11-10 13:16:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:16:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:16:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:16:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:16:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:16:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:16:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:16:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:16:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:16:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:16:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:16:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:16:13 --> Final output sent to browser
DEBUG - 2016-11-10 13:16:13 --> Total execution time: 0.3637
INFO - 2016-11-10 13:16:30 --> Config Class Initialized
INFO - 2016-11-10 13:16:30 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:16:30 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:16:30 --> Utf8 Class Initialized
INFO - 2016-11-10 13:16:30 --> URI Class Initialized
DEBUG - 2016-11-10 13:16:30 --> No URI present. Default controller set.
INFO - 2016-11-10 13:16:30 --> Router Class Initialized
INFO - 2016-11-10 13:16:30 --> Output Class Initialized
INFO - 2016-11-10 13:16:30 --> Security Class Initialized
DEBUG - 2016-11-10 13:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:16:30 --> Input Class Initialized
INFO - 2016-11-10 13:16:30 --> Language Class Initialized
INFO - 2016-11-10 13:16:30 --> Loader Class Initialized
INFO - 2016-11-10 13:16:30 --> Helper loaded: url_helper
INFO - 2016-11-10 13:16:30 --> Helper loaded: form_helper
INFO - 2016-11-10 13:16:30 --> Database Driver Class Initialized
INFO - 2016-11-10 13:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:16:30 --> Controller Class Initialized
INFO - 2016-11-10 13:16:30 --> Model Class Initialized
INFO - 2016-11-10 13:16:30 --> Model Class Initialized
INFO - 2016-11-10 13:16:30 --> Model Class Initialized
INFO - 2016-11-10 13:16:30 --> Model Class Initialized
INFO - 2016-11-10 13:16:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:16:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:16:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:16:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:16:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:16:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:16:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:16:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:16:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:16:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:16:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:16:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:16:30 --> Final output sent to browser
DEBUG - 2016-11-10 13:16:30 --> Total execution time: 0.4303
INFO - 2016-11-10 13:16:53 --> Config Class Initialized
INFO - 2016-11-10 13:16:53 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:16:53 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:16:53 --> Utf8 Class Initialized
INFO - 2016-11-10 13:16:53 --> URI Class Initialized
DEBUG - 2016-11-10 13:16:53 --> No URI present. Default controller set.
INFO - 2016-11-10 13:16:53 --> Router Class Initialized
INFO - 2016-11-10 13:16:53 --> Output Class Initialized
INFO - 2016-11-10 13:16:53 --> Security Class Initialized
DEBUG - 2016-11-10 13:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:16:53 --> Input Class Initialized
INFO - 2016-11-10 13:16:53 --> Language Class Initialized
INFO - 2016-11-10 13:16:53 --> Loader Class Initialized
INFO - 2016-11-10 13:16:53 --> Helper loaded: url_helper
INFO - 2016-11-10 13:16:53 --> Helper loaded: form_helper
INFO - 2016-11-10 13:16:53 --> Database Driver Class Initialized
INFO - 2016-11-10 13:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:16:53 --> Controller Class Initialized
INFO - 2016-11-10 13:16:53 --> Model Class Initialized
INFO - 2016-11-10 13:16:53 --> Model Class Initialized
INFO - 2016-11-10 13:16:53 --> Model Class Initialized
INFO - 2016-11-10 13:16:53 --> Model Class Initialized
INFO - 2016-11-10 13:16:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:16:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:16:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:16:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:16:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:16:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:16:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:16:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:16:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:16:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:16:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:16:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:16:53 --> Final output sent to browser
DEBUG - 2016-11-10 13:16:53 --> Total execution time: 0.3992
INFO - 2016-11-10 13:17:06 --> Config Class Initialized
INFO - 2016-11-10 13:17:06 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:17:06 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:17:06 --> Utf8 Class Initialized
INFO - 2016-11-10 13:17:06 --> URI Class Initialized
DEBUG - 2016-11-10 13:17:06 --> No URI present. Default controller set.
INFO - 2016-11-10 13:17:06 --> Router Class Initialized
INFO - 2016-11-10 13:17:06 --> Output Class Initialized
INFO - 2016-11-10 13:17:06 --> Security Class Initialized
DEBUG - 2016-11-10 13:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:17:06 --> Input Class Initialized
INFO - 2016-11-10 13:17:06 --> Language Class Initialized
INFO - 2016-11-10 13:17:06 --> Loader Class Initialized
INFO - 2016-11-10 13:17:06 --> Helper loaded: url_helper
INFO - 2016-11-10 13:17:06 --> Helper loaded: form_helper
INFO - 2016-11-10 13:17:06 --> Database Driver Class Initialized
INFO - 2016-11-10 13:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:17:06 --> Controller Class Initialized
INFO - 2016-11-10 13:17:06 --> Model Class Initialized
INFO - 2016-11-10 13:17:06 --> Model Class Initialized
INFO - 2016-11-10 13:17:06 --> Model Class Initialized
INFO - 2016-11-10 13:17:06 --> Model Class Initialized
INFO - 2016-11-10 13:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:17:06 --> Final output sent to browser
DEBUG - 2016-11-10 13:17:06 --> Total execution time: 0.4286
INFO - 2016-11-10 13:17:21 --> Config Class Initialized
INFO - 2016-11-10 13:17:21 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:17:21 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:17:21 --> Utf8 Class Initialized
INFO - 2016-11-10 13:17:21 --> URI Class Initialized
DEBUG - 2016-11-10 13:17:21 --> No URI present. Default controller set.
INFO - 2016-11-10 13:17:21 --> Router Class Initialized
INFO - 2016-11-10 13:17:21 --> Output Class Initialized
INFO - 2016-11-10 13:17:21 --> Security Class Initialized
DEBUG - 2016-11-10 13:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:17:21 --> Input Class Initialized
INFO - 2016-11-10 13:17:21 --> Language Class Initialized
INFO - 2016-11-10 13:17:21 --> Loader Class Initialized
INFO - 2016-11-10 13:17:21 --> Helper loaded: url_helper
INFO - 2016-11-10 13:17:21 --> Helper loaded: form_helper
INFO - 2016-11-10 13:17:21 --> Database Driver Class Initialized
INFO - 2016-11-10 13:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:17:21 --> Controller Class Initialized
INFO - 2016-11-10 13:17:21 --> Model Class Initialized
INFO - 2016-11-10 13:17:21 --> Model Class Initialized
INFO - 2016-11-10 13:17:21 --> Model Class Initialized
INFO - 2016-11-10 13:17:21 --> Model Class Initialized
INFO - 2016-11-10 13:17:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:17:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:17:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:17:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:17:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:17:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:17:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:17:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:17:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:17:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:17:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:17:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:17:21 --> Final output sent to browser
DEBUG - 2016-11-10 13:17:21 --> Total execution time: 0.4006
INFO - 2016-11-10 13:17:33 --> Config Class Initialized
INFO - 2016-11-10 13:17:33 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:17:33 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:17:33 --> Utf8 Class Initialized
INFO - 2016-11-10 13:17:33 --> URI Class Initialized
DEBUG - 2016-11-10 13:17:33 --> No URI present. Default controller set.
INFO - 2016-11-10 13:17:33 --> Router Class Initialized
INFO - 2016-11-10 13:17:33 --> Output Class Initialized
INFO - 2016-11-10 13:17:33 --> Security Class Initialized
DEBUG - 2016-11-10 13:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:17:33 --> Input Class Initialized
INFO - 2016-11-10 13:17:33 --> Language Class Initialized
INFO - 2016-11-10 13:17:33 --> Loader Class Initialized
INFO - 2016-11-10 13:17:33 --> Helper loaded: url_helper
INFO - 2016-11-10 13:17:33 --> Helper loaded: form_helper
INFO - 2016-11-10 13:17:33 --> Database Driver Class Initialized
INFO - 2016-11-10 13:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:17:33 --> Controller Class Initialized
INFO - 2016-11-10 13:17:33 --> Model Class Initialized
INFO - 2016-11-10 13:17:33 --> Model Class Initialized
INFO - 2016-11-10 13:17:33 --> Model Class Initialized
INFO - 2016-11-10 13:17:33 --> Model Class Initialized
INFO - 2016-11-10 13:17:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:17:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 13:17:33 --> Query error: Unknown column 'lt.name' in 'field list' - Invalid query: SELECT `em`.`surname`, `lt`.`name`, `lv`.`numberOfLeaves`, `lv`.`description`
FROM `leaveRecord` `lv`
RIGHT JOIN `employee` as `em` ON `em`.`id` = `lv`.`id`
INFO - 2016-11-10 13:17:33 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 13:17:51 --> Config Class Initialized
INFO - 2016-11-10 13:17:51 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:17:51 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:17:51 --> Utf8 Class Initialized
INFO - 2016-11-10 13:17:51 --> URI Class Initialized
DEBUG - 2016-11-10 13:17:51 --> No URI present. Default controller set.
INFO - 2016-11-10 13:17:51 --> Router Class Initialized
INFO - 2016-11-10 13:17:51 --> Output Class Initialized
INFO - 2016-11-10 13:17:51 --> Security Class Initialized
DEBUG - 2016-11-10 13:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:17:51 --> Input Class Initialized
INFO - 2016-11-10 13:17:51 --> Language Class Initialized
INFO - 2016-11-10 13:17:51 --> Loader Class Initialized
INFO - 2016-11-10 13:17:51 --> Helper loaded: url_helper
INFO - 2016-11-10 13:17:51 --> Helper loaded: form_helper
INFO - 2016-11-10 13:17:51 --> Database Driver Class Initialized
INFO - 2016-11-10 13:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:17:51 --> Controller Class Initialized
INFO - 2016-11-10 13:17:51 --> Model Class Initialized
INFO - 2016-11-10 13:17:51 --> Model Class Initialized
INFO - 2016-11-10 13:17:51 --> Model Class Initialized
INFO - 2016-11-10 13:17:51 --> Model Class Initialized
INFO - 2016-11-10 13:17:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:17:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:17:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:17:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:17:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:17:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:17:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:17:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
ERROR - 2016-11-10 13:17:51 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:17:51 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:17:52 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:17:52 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:17:52 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:17:52 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:17:52 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:17:52 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:17:52 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
INFO - 2016-11-10 13:17:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:17:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:17:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:17:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:17:52 --> Final output sent to browser
DEBUG - 2016-11-10 13:17:52 --> Total execution time: 0.5288
INFO - 2016-11-10 13:18:51 --> Config Class Initialized
INFO - 2016-11-10 13:18:51 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:18:51 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:18:51 --> Utf8 Class Initialized
INFO - 2016-11-10 13:18:51 --> URI Class Initialized
DEBUG - 2016-11-10 13:18:51 --> No URI present. Default controller set.
INFO - 2016-11-10 13:18:51 --> Router Class Initialized
INFO - 2016-11-10 13:18:51 --> Output Class Initialized
INFO - 2016-11-10 13:18:51 --> Security Class Initialized
DEBUG - 2016-11-10 13:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:18:51 --> Input Class Initialized
INFO - 2016-11-10 13:18:51 --> Language Class Initialized
INFO - 2016-11-10 13:18:51 --> Loader Class Initialized
INFO - 2016-11-10 13:18:51 --> Helper loaded: url_helper
INFO - 2016-11-10 13:18:51 --> Helper loaded: form_helper
INFO - 2016-11-10 13:18:51 --> Database Driver Class Initialized
INFO - 2016-11-10 13:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:18:51 --> Controller Class Initialized
INFO - 2016-11-10 13:18:51 --> Model Class Initialized
INFO - 2016-11-10 13:18:51 --> Model Class Initialized
INFO - 2016-11-10 13:18:51 --> Model Class Initialized
INFO - 2016-11-10 13:18:51 --> Model Class Initialized
INFO - 2016-11-10 13:18:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:18:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:18:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:18:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:18:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:18:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:18:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:18:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:18:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:18:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:18:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:18:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:18:51 --> Final output sent to browser
DEBUG - 2016-11-10 13:18:51 --> Total execution time: 0.3814
INFO - 2016-11-10 13:19:11 --> Config Class Initialized
INFO - 2016-11-10 13:19:11 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:19:11 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:19:11 --> Utf8 Class Initialized
INFO - 2016-11-10 13:19:11 --> URI Class Initialized
DEBUG - 2016-11-10 13:19:11 --> No URI present. Default controller set.
INFO - 2016-11-10 13:19:11 --> Router Class Initialized
INFO - 2016-11-10 13:19:11 --> Output Class Initialized
INFO - 2016-11-10 13:19:11 --> Security Class Initialized
DEBUG - 2016-11-10 13:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:19:11 --> Input Class Initialized
INFO - 2016-11-10 13:19:11 --> Language Class Initialized
INFO - 2016-11-10 13:19:11 --> Loader Class Initialized
INFO - 2016-11-10 13:19:11 --> Helper loaded: url_helper
INFO - 2016-11-10 13:19:11 --> Helper loaded: form_helper
INFO - 2016-11-10 13:19:11 --> Database Driver Class Initialized
INFO - 2016-11-10 13:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:19:11 --> Controller Class Initialized
INFO - 2016-11-10 13:19:11 --> Model Class Initialized
INFO - 2016-11-10 13:19:11 --> Model Class Initialized
INFO - 2016-11-10 13:19:11 --> Model Class Initialized
INFO - 2016-11-10 13:19:11 --> Model Class Initialized
INFO - 2016-11-10 13:19:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:19:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:19:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:19:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:19:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:19:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:19:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:19:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:19:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:19:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:19:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:19:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:19:11 --> Final output sent to browser
DEBUG - 2016-11-10 13:19:11 --> Total execution time: 0.4352
INFO - 2016-11-10 13:19:21 --> Config Class Initialized
INFO - 2016-11-10 13:19:21 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:19:21 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:19:21 --> Utf8 Class Initialized
INFO - 2016-11-10 13:19:21 --> URI Class Initialized
DEBUG - 2016-11-10 13:19:21 --> No URI present. Default controller set.
INFO - 2016-11-10 13:19:21 --> Router Class Initialized
INFO - 2016-11-10 13:19:21 --> Output Class Initialized
INFO - 2016-11-10 13:19:21 --> Security Class Initialized
DEBUG - 2016-11-10 13:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:19:21 --> Input Class Initialized
INFO - 2016-11-10 13:19:21 --> Language Class Initialized
INFO - 2016-11-10 13:19:21 --> Loader Class Initialized
INFO - 2016-11-10 13:19:21 --> Helper loaded: url_helper
INFO - 2016-11-10 13:19:21 --> Helper loaded: form_helper
INFO - 2016-11-10 13:19:21 --> Database Driver Class Initialized
INFO - 2016-11-10 13:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:19:21 --> Controller Class Initialized
INFO - 2016-11-10 13:19:21 --> Model Class Initialized
INFO - 2016-11-10 13:19:21 --> Model Class Initialized
INFO - 2016-11-10 13:19:21 --> Model Class Initialized
INFO - 2016-11-10 13:19:21 --> Model Class Initialized
INFO - 2016-11-10 13:19:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:19:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:19:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:19:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:19:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:19:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:19:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:19:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:19:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:19:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:19:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:19:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:19:21 --> Final output sent to browser
DEBUG - 2016-11-10 13:19:21 --> Total execution time: 0.4576
INFO - 2016-11-10 13:19:39 --> Config Class Initialized
INFO - 2016-11-10 13:19:39 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:19:39 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:19:39 --> Utf8 Class Initialized
INFO - 2016-11-10 13:19:39 --> URI Class Initialized
DEBUG - 2016-11-10 13:19:39 --> No URI present. Default controller set.
INFO - 2016-11-10 13:19:39 --> Router Class Initialized
INFO - 2016-11-10 13:19:39 --> Output Class Initialized
INFO - 2016-11-10 13:19:39 --> Security Class Initialized
DEBUG - 2016-11-10 13:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:19:39 --> Input Class Initialized
INFO - 2016-11-10 13:19:39 --> Language Class Initialized
INFO - 2016-11-10 13:19:39 --> Loader Class Initialized
INFO - 2016-11-10 13:19:39 --> Helper loaded: url_helper
INFO - 2016-11-10 13:19:39 --> Helper loaded: form_helper
INFO - 2016-11-10 13:19:39 --> Database Driver Class Initialized
INFO - 2016-11-10 13:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:19:39 --> Controller Class Initialized
INFO - 2016-11-10 13:19:39 --> Model Class Initialized
INFO - 2016-11-10 13:19:39 --> Model Class Initialized
INFO - 2016-11-10 13:19:39 --> Model Class Initialized
INFO - 2016-11-10 13:19:39 --> Model Class Initialized
INFO - 2016-11-10 13:19:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:19:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:19:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:19:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:19:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:19:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:19:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:19:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:19:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:19:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:19:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:19:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:19:39 --> Final output sent to browser
DEBUG - 2016-11-10 13:19:39 --> Total execution time: 0.4491
INFO - 2016-11-10 13:21:44 --> Config Class Initialized
INFO - 2016-11-10 13:21:44 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:21:44 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:21:44 --> Utf8 Class Initialized
INFO - 2016-11-10 13:21:44 --> URI Class Initialized
DEBUG - 2016-11-10 13:21:44 --> No URI present. Default controller set.
INFO - 2016-11-10 13:21:44 --> Router Class Initialized
INFO - 2016-11-10 13:21:44 --> Output Class Initialized
INFO - 2016-11-10 13:21:44 --> Security Class Initialized
DEBUG - 2016-11-10 13:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:21:44 --> Input Class Initialized
INFO - 2016-11-10 13:21:44 --> Language Class Initialized
INFO - 2016-11-10 13:21:44 --> Loader Class Initialized
INFO - 2016-11-10 13:21:44 --> Helper loaded: url_helper
INFO - 2016-11-10 13:21:44 --> Helper loaded: form_helper
INFO - 2016-11-10 13:21:44 --> Database Driver Class Initialized
INFO - 2016-11-10 13:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:21:44 --> Controller Class Initialized
INFO - 2016-11-10 13:21:44 --> Model Class Initialized
INFO - 2016-11-10 13:21:44 --> Model Class Initialized
INFO - 2016-11-10 13:21:44 --> Model Class Initialized
INFO - 2016-11-10 13:21:44 --> Model Class Initialized
INFO - 2016-11-10 13:21:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:21:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 13:21:44 --> Query error: Unknown column 'lt.name' in 'field list' - Invalid query: SELECT `lv`.`numberOfLeaves`, `lv`.`description`, `em`.`surname`, `lt`.`name`
FROM `leaveRecord` `lv`
RIGHT JOIN `employee` as `em` ON `em`.`id` = `lv`.`id`
INFO - 2016-11-10 13:21:44 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 13:21:59 --> Config Class Initialized
INFO - 2016-11-10 13:21:59 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:21:59 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:21:59 --> Utf8 Class Initialized
INFO - 2016-11-10 13:21:59 --> URI Class Initialized
DEBUG - 2016-11-10 13:21:59 --> No URI present. Default controller set.
INFO - 2016-11-10 13:21:59 --> Router Class Initialized
INFO - 2016-11-10 13:21:59 --> Output Class Initialized
INFO - 2016-11-10 13:21:59 --> Security Class Initialized
DEBUG - 2016-11-10 13:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:21:59 --> Input Class Initialized
INFO - 2016-11-10 13:21:59 --> Language Class Initialized
INFO - 2016-11-10 13:21:59 --> Loader Class Initialized
INFO - 2016-11-10 13:21:59 --> Helper loaded: url_helper
INFO - 2016-11-10 13:21:59 --> Helper loaded: form_helper
INFO - 2016-11-10 13:21:59 --> Database Driver Class Initialized
INFO - 2016-11-10 13:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:21:59 --> Controller Class Initialized
INFO - 2016-11-10 13:21:59 --> Model Class Initialized
INFO - 2016-11-10 13:21:59 --> Model Class Initialized
INFO - 2016-11-10 13:21:59 --> Model Class Initialized
INFO - 2016-11-10 13:21:59 --> Model Class Initialized
INFO - 2016-11-10 13:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:21:59 --> Final output sent to browser
DEBUG - 2016-11-10 13:21:59 --> Total execution time: 0.3867
INFO - 2016-11-10 13:22:30 --> Config Class Initialized
INFO - 2016-11-10 13:22:30 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:22:30 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:22:30 --> Utf8 Class Initialized
INFO - 2016-11-10 13:22:30 --> URI Class Initialized
DEBUG - 2016-11-10 13:22:30 --> No URI present. Default controller set.
INFO - 2016-11-10 13:22:30 --> Router Class Initialized
INFO - 2016-11-10 13:22:30 --> Output Class Initialized
INFO - 2016-11-10 13:22:30 --> Security Class Initialized
DEBUG - 2016-11-10 13:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:22:30 --> Input Class Initialized
INFO - 2016-11-10 13:22:30 --> Language Class Initialized
INFO - 2016-11-10 13:22:30 --> Loader Class Initialized
INFO - 2016-11-10 13:22:30 --> Helper loaded: url_helper
INFO - 2016-11-10 13:22:30 --> Helper loaded: form_helper
INFO - 2016-11-10 13:22:30 --> Database Driver Class Initialized
INFO - 2016-11-10 13:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:22:30 --> Controller Class Initialized
INFO - 2016-11-10 13:22:30 --> Model Class Initialized
INFO - 2016-11-10 13:22:30 --> Model Class Initialized
INFO - 2016-11-10 13:22:30 --> Model Class Initialized
INFO - 2016-11-10 13:22:30 --> Model Class Initialized
INFO - 2016-11-10 13:22:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:22:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:22:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:22:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:22:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:22:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:22:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:22:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:22:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:22:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:22:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:22:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:22:30 --> Final output sent to browser
DEBUG - 2016-11-10 13:22:31 --> Total execution time: 0.3887
INFO - 2016-11-10 13:23:39 --> Config Class Initialized
INFO - 2016-11-10 13:23:39 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:23:39 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:23:39 --> Utf8 Class Initialized
INFO - 2016-11-10 13:23:39 --> URI Class Initialized
DEBUG - 2016-11-10 13:23:39 --> No URI present. Default controller set.
INFO - 2016-11-10 13:23:39 --> Router Class Initialized
INFO - 2016-11-10 13:23:39 --> Output Class Initialized
INFO - 2016-11-10 13:23:39 --> Security Class Initialized
DEBUG - 2016-11-10 13:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:23:39 --> Input Class Initialized
INFO - 2016-11-10 13:23:39 --> Language Class Initialized
INFO - 2016-11-10 13:23:39 --> Loader Class Initialized
INFO - 2016-11-10 13:23:39 --> Helper loaded: url_helper
INFO - 2016-11-10 13:23:39 --> Helper loaded: form_helper
INFO - 2016-11-10 13:23:39 --> Database Driver Class Initialized
INFO - 2016-11-10 13:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:23:39 --> Controller Class Initialized
INFO - 2016-11-10 13:23:39 --> Model Class Initialized
INFO - 2016-11-10 13:23:39 --> Model Class Initialized
INFO - 2016-11-10 13:23:39 --> Model Class Initialized
INFO - 2016-11-10 13:23:39 --> Model Class Initialized
INFO - 2016-11-10 13:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:23:39 --> Final output sent to browser
DEBUG - 2016-11-10 13:23:39 --> Total execution time: 0.4142
INFO - 2016-11-10 13:23:50 --> Config Class Initialized
INFO - 2016-11-10 13:23:50 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:23:50 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:23:50 --> Utf8 Class Initialized
INFO - 2016-11-10 13:23:50 --> URI Class Initialized
DEBUG - 2016-11-10 13:23:50 --> No URI present. Default controller set.
INFO - 2016-11-10 13:23:50 --> Router Class Initialized
INFO - 2016-11-10 13:23:50 --> Output Class Initialized
INFO - 2016-11-10 13:23:50 --> Security Class Initialized
DEBUG - 2016-11-10 13:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:23:50 --> Input Class Initialized
INFO - 2016-11-10 13:23:50 --> Language Class Initialized
INFO - 2016-11-10 13:23:50 --> Loader Class Initialized
INFO - 2016-11-10 13:23:50 --> Helper loaded: url_helper
INFO - 2016-11-10 13:23:50 --> Helper loaded: form_helper
INFO - 2016-11-10 13:23:50 --> Database Driver Class Initialized
INFO - 2016-11-10 13:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:23:50 --> Controller Class Initialized
INFO - 2016-11-10 13:23:50 --> Model Class Initialized
INFO - 2016-11-10 13:23:50 --> Model Class Initialized
INFO - 2016-11-10 13:23:50 --> Model Class Initialized
INFO - 2016-11-10 13:23:50 --> Model Class Initialized
INFO - 2016-11-10 13:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:23:50 --> Final output sent to browser
DEBUG - 2016-11-10 13:23:50 --> Total execution time: 0.4036
INFO - 2016-11-10 13:24:12 --> Config Class Initialized
INFO - 2016-11-10 13:24:12 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:24:12 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:24:12 --> Utf8 Class Initialized
INFO - 2016-11-10 13:24:12 --> URI Class Initialized
DEBUG - 2016-11-10 13:24:12 --> No URI present. Default controller set.
INFO - 2016-11-10 13:24:12 --> Router Class Initialized
INFO - 2016-11-10 13:24:12 --> Output Class Initialized
INFO - 2016-11-10 13:24:12 --> Security Class Initialized
DEBUG - 2016-11-10 13:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:24:12 --> Input Class Initialized
INFO - 2016-11-10 13:24:12 --> Language Class Initialized
INFO - 2016-11-10 13:24:12 --> Loader Class Initialized
INFO - 2016-11-10 13:24:12 --> Helper loaded: url_helper
INFO - 2016-11-10 13:24:12 --> Helper loaded: form_helper
INFO - 2016-11-10 13:24:12 --> Database Driver Class Initialized
INFO - 2016-11-10 13:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:24:12 --> Controller Class Initialized
INFO - 2016-11-10 13:24:12 --> Model Class Initialized
INFO - 2016-11-10 13:24:12 --> Model Class Initialized
INFO - 2016-11-10 13:24:12 --> Model Class Initialized
INFO - 2016-11-10 13:24:12 --> Model Class Initialized
INFO - 2016-11-10 13:24:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:24:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:24:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:24:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:24:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:24:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:24:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:24:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:24:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:24:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:24:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:24:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:24:13 --> Final output sent to browser
DEBUG - 2016-11-10 13:24:13 --> Total execution time: 0.4168
INFO - 2016-11-10 13:24:27 --> Config Class Initialized
INFO - 2016-11-10 13:24:27 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:24:27 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:24:27 --> Utf8 Class Initialized
INFO - 2016-11-10 13:24:27 --> URI Class Initialized
DEBUG - 2016-11-10 13:24:27 --> No URI present. Default controller set.
INFO - 2016-11-10 13:24:27 --> Router Class Initialized
INFO - 2016-11-10 13:24:27 --> Output Class Initialized
INFO - 2016-11-10 13:24:27 --> Security Class Initialized
DEBUG - 2016-11-10 13:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:24:27 --> Input Class Initialized
INFO - 2016-11-10 13:24:27 --> Language Class Initialized
INFO - 2016-11-10 13:24:27 --> Loader Class Initialized
INFO - 2016-11-10 13:24:27 --> Helper loaded: url_helper
INFO - 2016-11-10 13:24:27 --> Helper loaded: form_helper
INFO - 2016-11-10 13:24:27 --> Database Driver Class Initialized
INFO - 2016-11-10 13:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:24:27 --> Controller Class Initialized
INFO - 2016-11-10 13:24:27 --> Model Class Initialized
INFO - 2016-11-10 13:24:27 --> Model Class Initialized
INFO - 2016-11-10 13:24:27 --> Model Class Initialized
INFO - 2016-11-10 13:24:27 --> Model Class Initialized
INFO - 2016-11-10 13:24:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:24:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:24:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:24:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:24:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:24:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:24:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:24:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:24:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:24:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:24:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:24:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:24:28 --> Final output sent to browser
DEBUG - 2016-11-10 13:24:28 --> Total execution time: 0.4184
INFO - 2016-11-10 13:24:57 --> Config Class Initialized
INFO - 2016-11-10 13:24:58 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:24:58 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:24:58 --> Utf8 Class Initialized
INFO - 2016-11-10 13:24:58 --> URI Class Initialized
DEBUG - 2016-11-10 13:24:58 --> No URI present. Default controller set.
INFO - 2016-11-10 13:24:58 --> Router Class Initialized
INFO - 2016-11-10 13:24:58 --> Output Class Initialized
INFO - 2016-11-10 13:24:58 --> Security Class Initialized
DEBUG - 2016-11-10 13:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:24:58 --> Input Class Initialized
INFO - 2016-11-10 13:24:58 --> Language Class Initialized
INFO - 2016-11-10 13:24:58 --> Loader Class Initialized
INFO - 2016-11-10 13:24:58 --> Helper loaded: url_helper
INFO - 2016-11-10 13:24:58 --> Helper loaded: form_helper
INFO - 2016-11-10 13:24:58 --> Database Driver Class Initialized
INFO - 2016-11-10 13:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:24:58 --> Controller Class Initialized
INFO - 2016-11-10 13:24:58 --> Model Class Initialized
INFO - 2016-11-10 13:24:58 --> Model Class Initialized
INFO - 2016-11-10 13:24:58 --> Model Class Initialized
INFO - 2016-11-10 13:24:58 --> Model Class Initialized
INFO - 2016-11-10 13:24:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:24:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:24:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:24:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:24:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:24:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:24:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:24:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
ERROR - 2016-11-10 13:24:58 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:24:58 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:24:58 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:24:58 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:24:58 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:24:58 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:24:58 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:24:58 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:24:58 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
INFO - 2016-11-10 13:24:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:24:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:24:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:24:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:24:58 --> Final output sent to browser
DEBUG - 2016-11-10 13:24:58 --> Total execution time: 0.5865
INFO - 2016-11-10 13:25:12 --> Config Class Initialized
INFO - 2016-11-10 13:25:12 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:25:12 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:25:12 --> Utf8 Class Initialized
INFO - 2016-11-10 13:25:12 --> URI Class Initialized
DEBUG - 2016-11-10 13:25:12 --> No URI present. Default controller set.
INFO - 2016-11-10 13:25:12 --> Router Class Initialized
INFO - 2016-11-10 13:25:12 --> Output Class Initialized
INFO - 2016-11-10 13:25:12 --> Security Class Initialized
DEBUG - 2016-11-10 13:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:25:13 --> Input Class Initialized
INFO - 2016-11-10 13:25:13 --> Language Class Initialized
INFO - 2016-11-10 13:25:13 --> Loader Class Initialized
INFO - 2016-11-10 13:25:13 --> Helper loaded: url_helper
INFO - 2016-11-10 13:25:13 --> Helper loaded: form_helper
INFO - 2016-11-10 13:25:13 --> Database Driver Class Initialized
INFO - 2016-11-10 13:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:25:13 --> Controller Class Initialized
INFO - 2016-11-10 13:25:13 --> Model Class Initialized
INFO - 2016-11-10 13:25:13 --> Model Class Initialized
INFO - 2016-11-10 13:25:13 --> Model Class Initialized
INFO - 2016-11-10 13:25:13 --> Model Class Initialized
INFO - 2016-11-10 13:25:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:25:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:25:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:25:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:25:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:25:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:25:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:25:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
ERROR - 2016-11-10 13:25:13 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:25:13 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:25:13 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:25:13 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:25:13 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
INFO - 2016-11-10 13:25:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:25:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:25:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:25:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:25:13 --> Final output sent to browser
DEBUG - 2016-11-10 13:25:13 --> Total execution time: 0.4618
INFO - 2016-11-10 13:25:34 --> Config Class Initialized
INFO - 2016-11-10 13:25:34 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:25:34 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:25:34 --> Utf8 Class Initialized
INFO - 2016-11-10 13:25:35 --> URI Class Initialized
DEBUG - 2016-11-10 13:25:35 --> No URI present. Default controller set.
INFO - 2016-11-10 13:25:35 --> Router Class Initialized
INFO - 2016-11-10 13:25:35 --> Output Class Initialized
INFO - 2016-11-10 13:25:35 --> Security Class Initialized
DEBUG - 2016-11-10 13:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:25:35 --> Input Class Initialized
INFO - 2016-11-10 13:25:35 --> Language Class Initialized
INFO - 2016-11-10 13:25:35 --> Loader Class Initialized
INFO - 2016-11-10 13:25:35 --> Helper loaded: url_helper
INFO - 2016-11-10 13:25:35 --> Helper loaded: form_helper
INFO - 2016-11-10 13:25:35 --> Database Driver Class Initialized
INFO - 2016-11-10 13:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:25:35 --> Controller Class Initialized
INFO - 2016-11-10 13:25:35 --> Model Class Initialized
INFO - 2016-11-10 13:25:35 --> Model Class Initialized
INFO - 2016-11-10 13:25:35 --> Model Class Initialized
INFO - 2016-11-10 13:25:35 --> Model Class Initialized
INFO - 2016-11-10 13:25:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:25:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:25:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:25:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:25:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:25:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:25:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:25:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
ERROR - 2016-11-10 13:25:35 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:25:35 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 13:25:35 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
INFO - 2016-11-10 13:25:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:25:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:25:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:25:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:25:35 --> Final output sent to browser
DEBUG - 2016-11-10 13:25:35 --> Total execution time: 0.4243
INFO - 2016-11-10 13:26:04 --> Config Class Initialized
INFO - 2016-11-10 13:26:04 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:26:04 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:26:04 --> Utf8 Class Initialized
INFO - 2016-11-10 13:26:04 --> URI Class Initialized
DEBUG - 2016-11-10 13:26:04 --> No URI present. Default controller set.
INFO - 2016-11-10 13:26:04 --> Router Class Initialized
INFO - 2016-11-10 13:26:04 --> Output Class Initialized
INFO - 2016-11-10 13:26:04 --> Security Class Initialized
DEBUG - 2016-11-10 13:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:26:04 --> Input Class Initialized
INFO - 2016-11-10 13:26:04 --> Language Class Initialized
INFO - 2016-11-10 13:26:04 --> Loader Class Initialized
INFO - 2016-11-10 13:26:04 --> Helper loaded: url_helper
INFO - 2016-11-10 13:26:04 --> Helper loaded: form_helper
INFO - 2016-11-10 13:26:04 --> Database Driver Class Initialized
INFO - 2016-11-10 13:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:26:04 --> Controller Class Initialized
INFO - 2016-11-10 13:26:04 --> Model Class Initialized
INFO - 2016-11-10 13:26:04 --> Model Class Initialized
INFO - 2016-11-10 13:26:04 --> Model Class Initialized
INFO - 2016-11-10 13:26:04 --> Model Class Initialized
INFO - 2016-11-10 13:26:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:26:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:26:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:26:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:26:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:26:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:26:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:26:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:26:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:26:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:26:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:26:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:26:04 --> Final output sent to browser
DEBUG - 2016-11-10 13:26:04 --> Total execution time: 0.4006
INFO - 2016-11-10 13:26:24 --> Config Class Initialized
INFO - 2016-11-10 13:26:24 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:26:24 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:26:24 --> Utf8 Class Initialized
INFO - 2016-11-10 13:26:24 --> URI Class Initialized
DEBUG - 2016-11-10 13:26:24 --> No URI present. Default controller set.
INFO - 2016-11-10 13:26:24 --> Router Class Initialized
INFO - 2016-11-10 13:26:24 --> Output Class Initialized
INFO - 2016-11-10 13:26:24 --> Security Class Initialized
DEBUG - 2016-11-10 13:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:26:24 --> Input Class Initialized
INFO - 2016-11-10 13:26:24 --> Language Class Initialized
INFO - 2016-11-10 13:26:24 --> Loader Class Initialized
INFO - 2016-11-10 13:26:24 --> Helper loaded: url_helper
INFO - 2016-11-10 13:26:24 --> Helper loaded: form_helper
INFO - 2016-11-10 13:26:24 --> Database Driver Class Initialized
INFO - 2016-11-10 13:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:26:24 --> Controller Class Initialized
INFO - 2016-11-10 13:26:24 --> Model Class Initialized
INFO - 2016-11-10 13:26:24 --> Model Class Initialized
INFO - 2016-11-10 13:26:24 --> Model Class Initialized
INFO - 2016-11-10 13:26:24 --> Model Class Initialized
INFO - 2016-11-10 13:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:26:24 --> Final output sent to browser
DEBUG - 2016-11-10 13:26:24 --> Total execution time: 0.3973
INFO - 2016-11-10 13:26:35 --> Config Class Initialized
INFO - 2016-11-10 13:26:35 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:26:35 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:26:35 --> Utf8 Class Initialized
INFO - 2016-11-10 13:26:35 --> URI Class Initialized
DEBUG - 2016-11-10 13:26:35 --> No URI present. Default controller set.
INFO - 2016-11-10 13:26:35 --> Router Class Initialized
INFO - 2016-11-10 13:26:35 --> Output Class Initialized
INFO - 2016-11-10 13:26:35 --> Security Class Initialized
DEBUG - 2016-11-10 13:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:26:35 --> Input Class Initialized
INFO - 2016-11-10 13:26:35 --> Language Class Initialized
INFO - 2016-11-10 13:26:35 --> Loader Class Initialized
INFO - 2016-11-10 13:26:35 --> Helper loaded: url_helper
INFO - 2016-11-10 13:26:35 --> Helper loaded: form_helper
INFO - 2016-11-10 13:26:35 --> Database Driver Class Initialized
INFO - 2016-11-10 13:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:26:35 --> Controller Class Initialized
INFO - 2016-11-10 13:26:35 --> Model Class Initialized
INFO - 2016-11-10 13:26:35 --> Model Class Initialized
INFO - 2016-11-10 13:26:35 --> Model Class Initialized
INFO - 2016-11-10 13:26:35 --> Model Class Initialized
INFO - 2016-11-10 13:26:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:26:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:26:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:26:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:26:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:26:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:26:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:26:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:26:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:26:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:26:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:26:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:26:36 --> Final output sent to browser
DEBUG - 2016-11-10 13:26:36 --> Total execution time: 0.4213
INFO - 2016-11-10 13:26:47 --> Config Class Initialized
INFO - 2016-11-10 13:26:47 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:26:47 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:26:47 --> Utf8 Class Initialized
INFO - 2016-11-10 13:26:47 --> URI Class Initialized
DEBUG - 2016-11-10 13:26:47 --> No URI present. Default controller set.
INFO - 2016-11-10 13:26:47 --> Router Class Initialized
INFO - 2016-11-10 13:26:47 --> Output Class Initialized
INFO - 2016-11-10 13:26:47 --> Security Class Initialized
DEBUG - 2016-11-10 13:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:26:47 --> Input Class Initialized
INFO - 2016-11-10 13:26:47 --> Language Class Initialized
INFO - 2016-11-10 13:26:48 --> Loader Class Initialized
INFO - 2016-11-10 13:26:48 --> Helper loaded: url_helper
INFO - 2016-11-10 13:26:48 --> Helper loaded: form_helper
INFO - 2016-11-10 13:26:48 --> Database Driver Class Initialized
INFO - 2016-11-10 13:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:26:48 --> Controller Class Initialized
INFO - 2016-11-10 13:26:48 --> Model Class Initialized
INFO - 2016-11-10 13:26:48 --> Model Class Initialized
INFO - 2016-11-10 13:26:48 --> Model Class Initialized
INFO - 2016-11-10 13:26:48 --> Model Class Initialized
INFO - 2016-11-10 13:26:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:26:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:26:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:26:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:26:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:26:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:26:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:26:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:26:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:26:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:26:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:26:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:26:48 --> Final output sent to browser
DEBUG - 2016-11-10 13:26:48 --> Total execution time: 0.4048
INFO - 2016-11-10 13:27:01 --> Config Class Initialized
INFO - 2016-11-10 13:27:01 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:27:01 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:27:01 --> Utf8 Class Initialized
INFO - 2016-11-10 13:27:01 --> URI Class Initialized
DEBUG - 2016-11-10 13:27:01 --> No URI present. Default controller set.
INFO - 2016-11-10 13:27:01 --> Router Class Initialized
INFO - 2016-11-10 13:27:01 --> Output Class Initialized
INFO - 2016-11-10 13:27:01 --> Security Class Initialized
DEBUG - 2016-11-10 13:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:27:01 --> Input Class Initialized
INFO - 2016-11-10 13:27:01 --> Language Class Initialized
INFO - 2016-11-10 13:27:01 --> Loader Class Initialized
INFO - 2016-11-10 13:27:01 --> Helper loaded: url_helper
INFO - 2016-11-10 13:27:01 --> Helper loaded: form_helper
INFO - 2016-11-10 13:27:01 --> Database Driver Class Initialized
INFO - 2016-11-10 13:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:27:01 --> Controller Class Initialized
INFO - 2016-11-10 13:27:01 --> Model Class Initialized
INFO - 2016-11-10 13:27:01 --> Model Class Initialized
INFO - 2016-11-10 13:27:01 --> Model Class Initialized
INFO - 2016-11-10 13:27:01 --> Model Class Initialized
INFO - 2016-11-10 13:27:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:27:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:27:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:27:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:27:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:27:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:27:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:27:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:27:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:27:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:27:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:27:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:27:01 --> Final output sent to browser
DEBUG - 2016-11-10 13:27:01 --> Total execution time: 0.4033
INFO - 2016-11-10 13:27:30 --> Config Class Initialized
INFO - 2016-11-10 13:27:30 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:27:30 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:27:30 --> Utf8 Class Initialized
INFO - 2016-11-10 13:27:30 --> URI Class Initialized
DEBUG - 2016-11-10 13:27:30 --> No URI present. Default controller set.
INFO - 2016-11-10 13:27:30 --> Router Class Initialized
INFO - 2016-11-10 13:27:30 --> Output Class Initialized
INFO - 2016-11-10 13:27:30 --> Security Class Initialized
DEBUG - 2016-11-10 13:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:27:30 --> Input Class Initialized
INFO - 2016-11-10 13:27:30 --> Language Class Initialized
INFO - 2016-11-10 13:27:30 --> Loader Class Initialized
INFO - 2016-11-10 13:27:30 --> Helper loaded: url_helper
INFO - 2016-11-10 13:27:30 --> Helper loaded: form_helper
INFO - 2016-11-10 13:27:30 --> Database Driver Class Initialized
INFO - 2016-11-10 13:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:27:30 --> Controller Class Initialized
INFO - 2016-11-10 13:27:30 --> Model Class Initialized
INFO - 2016-11-10 13:27:30 --> Model Class Initialized
INFO - 2016-11-10 13:27:31 --> Model Class Initialized
INFO - 2016-11-10 13:27:31 --> Model Class Initialized
INFO - 2016-11-10 13:27:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:27:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:27:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:27:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:27:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:27:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:27:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:27:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:27:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:27:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:27:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:27:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:27:31 --> Final output sent to browser
DEBUG - 2016-11-10 13:27:31 --> Total execution time: 0.4359
INFO - 2016-11-10 13:27:53 --> Config Class Initialized
INFO - 2016-11-10 13:27:53 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:27:53 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:27:53 --> Utf8 Class Initialized
INFO - 2016-11-10 13:27:53 --> URI Class Initialized
DEBUG - 2016-11-10 13:27:53 --> No URI present. Default controller set.
INFO - 2016-11-10 13:27:53 --> Router Class Initialized
INFO - 2016-11-10 13:27:53 --> Output Class Initialized
INFO - 2016-11-10 13:27:53 --> Security Class Initialized
DEBUG - 2016-11-10 13:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:27:53 --> Input Class Initialized
INFO - 2016-11-10 13:27:53 --> Language Class Initialized
INFO - 2016-11-10 13:27:53 --> Loader Class Initialized
INFO - 2016-11-10 13:27:53 --> Helper loaded: url_helper
INFO - 2016-11-10 13:27:53 --> Helper loaded: form_helper
INFO - 2016-11-10 13:27:53 --> Database Driver Class Initialized
INFO - 2016-11-10 13:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:27:53 --> Controller Class Initialized
INFO - 2016-11-10 13:27:53 --> Model Class Initialized
INFO - 2016-11-10 13:27:53 --> Model Class Initialized
INFO - 2016-11-10 13:27:53 --> Model Class Initialized
INFO - 2016-11-10 13:27:53 --> Model Class Initialized
INFO - 2016-11-10 13:27:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:27:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:27:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:27:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:27:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:27:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:27:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:27:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:27:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:27:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:27:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:27:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:27:53 --> Final output sent to browser
DEBUG - 2016-11-10 13:27:53 --> Total execution time: 0.4123
INFO - 2016-11-10 13:28:34 --> Config Class Initialized
INFO - 2016-11-10 13:28:34 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:28:34 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:28:34 --> Utf8 Class Initialized
INFO - 2016-11-10 13:28:34 --> URI Class Initialized
DEBUG - 2016-11-10 13:28:34 --> No URI present. Default controller set.
INFO - 2016-11-10 13:28:34 --> Router Class Initialized
INFO - 2016-11-10 13:28:34 --> Output Class Initialized
INFO - 2016-11-10 13:28:34 --> Security Class Initialized
DEBUG - 2016-11-10 13:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:28:34 --> Input Class Initialized
INFO - 2016-11-10 13:28:34 --> Language Class Initialized
INFO - 2016-11-10 13:28:34 --> Loader Class Initialized
INFO - 2016-11-10 13:28:34 --> Helper loaded: url_helper
INFO - 2016-11-10 13:28:34 --> Helper loaded: form_helper
INFO - 2016-11-10 13:28:34 --> Database Driver Class Initialized
INFO - 2016-11-10 13:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:28:34 --> Controller Class Initialized
INFO - 2016-11-10 13:28:34 --> Model Class Initialized
INFO - 2016-11-10 13:28:34 --> Model Class Initialized
INFO - 2016-11-10 13:28:34 --> Model Class Initialized
INFO - 2016-11-10 13:28:34 --> Model Class Initialized
INFO - 2016-11-10 13:28:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:28:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 13:28:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'OUTER JOIN `employee` as `em` ON `em`.`id` = `lv`.`id`
RIGHT JOIN `leaveType` as' at line 3 - Invalid query: SELECT `lv`.`numberOfLeaves`, `lv`.`description`, `em`.`surname`, `lt`.`name`
FROM `leaveRecord` `lv`
OUTER JOIN `employee` as `em` ON `em`.`id` = `lv`.`id`
RIGHT JOIN `leaveType` as `lt` ON `lt`.`id` = `lv`.`id`
INFO - 2016-11-10 13:28:34 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 13:28:42 --> Config Class Initialized
INFO - 2016-11-10 13:28:42 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:28:42 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:28:42 --> Utf8 Class Initialized
INFO - 2016-11-10 13:28:42 --> URI Class Initialized
DEBUG - 2016-11-10 13:28:42 --> No URI present. Default controller set.
INFO - 2016-11-10 13:28:42 --> Router Class Initialized
INFO - 2016-11-10 13:28:42 --> Output Class Initialized
INFO - 2016-11-10 13:28:42 --> Security Class Initialized
DEBUG - 2016-11-10 13:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:28:42 --> Input Class Initialized
INFO - 2016-11-10 13:28:42 --> Language Class Initialized
INFO - 2016-11-10 13:28:42 --> Loader Class Initialized
INFO - 2016-11-10 13:28:42 --> Helper loaded: url_helper
INFO - 2016-11-10 13:28:42 --> Helper loaded: form_helper
INFO - 2016-11-10 13:28:42 --> Database Driver Class Initialized
INFO - 2016-11-10 13:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:28:42 --> Controller Class Initialized
INFO - 2016-11-10 13:28:42 --> Model Class Initialized
INFO - 2016-11-10 13:28:42 --> Model Class Initialized
INFO - 2016-11-10 13:28:42 --> Model Class Initialized
INFO - 2016-11-10 13:28:42 --> Model Class Initialized
INFO - 2016-11-10 13:28:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:28:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:28:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:28:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:28:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:28:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:28:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:28:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:28:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:28:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:28:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:28:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:28:42 --> Final output sent to browser
DEBUG - 2016-11-10 13:28:42 --> Total execution time: 0.4407
INFO - 2016-11-10 13:29:57 --> Config Class Initialized
INFO - 2016-11-10 13:29:57 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:29:57 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:29:57 --> Utf8 Class Initialized
INFO - 2016-11-10 13:29:57 --> URI Class Initialized
DEBUG - 2016-11-10 13:29:57 --> No URI present. Default controller set.
INFO - 2016-11-10 13:29:57 --> Router Class Initialized
INFO - 2016-11-10 13:29:57 --> Output Class Initialized
INFO - 2016-11-10 13:29:57 --> Security Class Initialized
DEBUG - 2016-11-10 13:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:29:57 --> Input Class Initialized
INFO - 2016-11-10 13:29:57 --> Language Class Initialized
INFO - 2016-11-10 13:29:57 --> Loader Class Initialized
INFO - 2016-11-10 13:29:57 --> Helper loaded: url_helper
INFO - 2016-11-10 13:29:57 --> Helper loaded: form_helper
INFO - 2016-11-10 13:29:57 --> Database Driver Class Initialized
INFO - 2016-11-10 13:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:29:57 --> Controller Class Initialized
INFO - 2016-11-10 13:29:57 --> Model Class Initialized
INFO - 2016-11-10 13:29:57 --> Model Class Initialized
INFO - 2016-11-10 13:29:57 --> Model Class Initialized
INFO - 2016-11-10 13:29:57 --> Model Class Initialized
INFO - 2016-11-10 13:29:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:29:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:29:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:29:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:29:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:29:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:29:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:29:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:29:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:29:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:29:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:29:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:29:57 --> Final output sent to browser
DEBUG - 2016-11-10 13:29:57 --> Total execution time: 0.4250
INFO - 2016-11-10 13:30:34 --> Config Class Initialized
INFO - 2016-11-10 13:30:34 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:30:34 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:30:34 --> Utf8 Class Initialized
INFO - 2016-11-10 13:30:34 --> URI Class Initialized
DEBUG - 2016-11-10 13:30:34 --> No URI present. Default controller set.
INFO - 2016-11-10 13:30:34 --> Router Class Initialized
INFO - 2016-11-10 13:30:34 --> Output Class Initialized
INFO - 2016-11-10 13:30:34 --> Security Class Initialized
DEBUG - 2016-11-10 13:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:30:34 --> Input Class Initialized
INFO - 2016-11-10 13:30:35 --> Language Class Initialized
INFO - 2016-11-10 13:30:35 --> Loader Class Initialized
INFO - 2016-11-10 13:30:35 --> Helper loaded: url_helper
INFO - 2016-11-10 13:30:35 --> Helper loaded: form_helper
INFO - 2016-11-10 13:30:35 --> Database Driver Class Initialized
INFO - 2016-11-10 13:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:30:35 --> Controller Class Initialized
INFO - 2016-11-10 13:30:35 --> Model Class Initialized
INFO - 2016-11-10 13:30:35 --> Model Class Initialized
INFO - 2016-11-10 13:30:35 --> Model Class Initialized
INFO - 2016-11-10 13:30:35 --> Model Class Initialized
INFO - 2016-11-10 13:30:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:30:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:30:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:30:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:30:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:30:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:30:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:30:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:30:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:30:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:30:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:30:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:30:35 --> Final output sent to browser
DEBUG - 2016-11-10 13:30:35 --> Total execution time: 0.4103
INFO - 2016-11-10 13:31:30 --> Config Class Initialized
INFO - 2016-11-10 13:31:30 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:31:30 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:31:30 --> Utf8 Class Initialized
INFO - 2016-11-10 13:31:30 --> URI Class Initialized
DEBUG - 2016-11-10 13:31:30 --> No URI present. Default controller set.
INFO - 2016-11-10 13:31:30 --> Router Class Initialized
INFO - 2016-11-10 13:31:30 --> Output Class Initialized
INFO - 2016-11-10 13:31:30 --> Security Class Initialized
DEBUG - 2016-11-10 13:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:31:30 --> Input Class Initialized
INFO - 2016-11-10 13:31:30 --> Language Class Initialized
INFO - 2016-11-10 13:31:30 --> Loader Class Initialized
INFO - 2016-11-10 13:31:30 --> Helper loaded: url_helper
INFO - 2016-11-10 13:31:30 --> Helper loaded: form_helper
INFO - 2016-11-10 13:31:30 --> Database Driver Class Initialized
INFO - 2016-11-10 13:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:31:30 --> Controller Class Initialized
INFO - 2016-11-10 13:31:30 --> Model Class Initialized
INFO - 2016-11-10 13:31:30 --> Model Class Initialized
INFO - 2016-11-10 13:31:30 --> Model Class Initialized
INFO - 2016-11-10 13:31:30 --> Model Class Initialized
INFO - 2016-11-10 13:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:31:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:31:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:31:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:31:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:31:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:31:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:31:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:31:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:31:31 --> Final output sent to browser
DEBUG - 2016-11-10 13:31:31 --> Total execution time: 0.4015
INFO - 2016-11-10 13:31:50 --> Config Class Initialized
INFO - 2016-11-10 13:31:50 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:31:50 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:31:50 --> Utf8 Class Initialized
INFO - 2016-11-10 13:31:50 --> URI Class Initialized
DEBUG - 2016-11-10 13:31:50 --> No URI present. Default controller set.
INFO - 2016-11-10 13:31:50 --> Router Class Initialized
INFO - 2016-11-10 13:31:50 --> Output Class Initialized
INFO - 2016-11-10 13:31:50 --> Security Class Initialized
DEBUG - 2016-11-10 13:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:31:50 --> Input Class Initialized
INFO - 2016-11-10 13:31:50 --> Language Class Initialized
INFO - 2016-11-10 13:31:50 --> Loader Class Initialized
INFO - 2016-11-10 13:31:50 --> Helper loaded: url_helper
INFO - 2016-11-10 13:31:50 --> Helper loaded: form_helper
INFO - 2016-11-10 13:31:50 --> Database Driver Class Initialized
INFO - 2016-11-10 13:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:31:50 --> Controller Class Initialized
INFO - 2016-11-10 13:31:50 --> Model Class Initialized
INFO - 2016-11-10 13:31:50 --> Model Class Initialized
INFO - 2016-11-10 13:31:50 --> Model Class Initialized
INFO - 2016-11-10 13:31:50 --> Model Class Initialized
INFO - 2016-11-10 13:31:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:31:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:31:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:31:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:31:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:31:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:31:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:31:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:31:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:31:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:31:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:31:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:31:50 --> Final output sent to browser
DEBUG - 2016-11-10 13:31:50 --> Total execution time: 0.4315
INFO - 2016-11-10 13:32:02 --> Config Class Initialized
INFO - 2016-11-10 13:32:02 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:32:02 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:32:02 --> Utf8 Class Initialized
INFO - 2016-11-10 13:32:02 --> URI Class Initialized
DEBUG - 2016-11-10 13:32:02 --> No URI present. Default controller set.
INFO - 2016-11-10 13:32:02 --> Router Class Initialized
INFO - 2016-11-10 13:32:02 --> Output Class Initialized
INFO - 2016-11-10 13:32:02 --> Security Class Initialized
DEBUG - 2016-11-10 13:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:32:02 --> Input Class Initialized
INFO - 2016-11-10 13:32:02 --> Language Class Initialized
INFO - 2016-11-10 13:32:02 --> Loader Class Initialized
INFO - 2016-11-10 13:32:02 --> Helper loaded: url_helper
INFO - 2016-11-10 13:32:02 --> Helper loaded: form_helper
INFO - 2016-11-10 13:32:02 --> Database Driver Class Initialized
INFO - 2016-11-10 13:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:32:02 --> Controller Class Initialized
INFO - 2016-11-10 13:32:02 --> Model Class Initialized
INFO - 2016-11-10 13:32:02 --> Model Class Initialized
INFO - 2016-11-10 13:32:02 --> Model Class Initialized
INFO - 2016-11-10 13:32:02 --> Model Class Initialized
INFO - 2016-11-10 13:32:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:32:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:32:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:32:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:32:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:32:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:32:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:32:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:32:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:32:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:32:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:32:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:32:03 --> Final output sent to browser
DEBUG - 2016-11-10 13:32:03 --> Total execution time: 0.4318
INFO - 2016-11-10 13:32:07 --> Config Class Initialized
INFO - 2016-11-10 13:32:07 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:32:07 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:32:07 --> Utf8 Class Initialized
INFO - 2016-11-10 13:32:07 --> URI Class Initialized
DEBUG - 2016-11-10 13:32:07 --> No URI present. Default controller set.
INFO - 2016-11-10 13:32:07 --> Router Class Initialized
INFO - 2016-11-10 13:32:07 --> Output Class Initialized
INFO - 2016-11-10 13:32:07 --> Security Class Initialized
DEBUG - 2016-11-10 13:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:32:07 --> Input Class Initialized
INFO - 2016-11-10 13:32:07 --> Language Class Initialized
INFO - 2016-11-10 13:32:07 --> Loader Class Initialized
INFO - 2016-11-10 13:32:07 --> Helper loaded: url_helper
INFO - 2016-11-10 13:32:07 --> Helper loaded: form_helper
INFO - 2016-11-10 13:32:07 --> Database Driver Class Initialized
INFO - 2016-11-10 13:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:32:07 --> Controller Class Initialized
INFO - 2016-11-10 13:32:07 --> Model Class Initialized
INFO - 2016-11-10 13:32:07 --> Model Class Initialized
INFO - 2016-11-10 13:32:07 --> Model Class Initialized
INFO - 2016-11-10 13:32:07 --> Model Class Initialized
INFO - 2016-11-10 13:32:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:32:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:32:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:32:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:32:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:32:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:32:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:32:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:32:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:32:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:32:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:32:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:32:07 --> Final output sent to browser
DEBUG - 2016-11-10 13:32:07 --> Total execution time: 0.4491
INFO - 2016-11-10 13:32:18 --> Config Class Initialized
INFO - 2016-11-10 13:32:18 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:32:18 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:32:18 --> Utf8 Class Initialized
INFO - 2016-11-10 13:32:18 --> URI Class Initialized
DEBUG - 2016-11-10 13:32:18 --> No URI present. Default controller set.
INFO - 2016-11-10 13:32:18 --> Router Class Initialized
INFO - 2016-11-10 13:32:18 --> Output Class Initialized
INFO - 2016-11-10 13:32:18 --> Security Class Initialized
DEBUG - 2016-11-10 13:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:32:18 --> Input Class Initialized
INFO - 2016-11-10 13:32:18 --> Language Class Initialized
INFO - 2016-11-10 13:32:18 --> Loader Class Initialized
INFO - 2016-11-10 13:32:18 --> Helper loaded: url_helper
INFO - 2016-11-10 13:32:18 --> Helper loaded: form_helper
INFO - 2016-11-10 13:32:18 --> Database Driver Class Initialized
INFO - 2016-11-10 13:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:32:18 --> Controller Class Initialized
INFO - 2016-11-10 13:32:18 --> Model Class Initialized
INFO - 2016-11-10 13:32:18 --> Model Class Initialized
INFO - 2016-11-10 13:32:18 --> Model Class Initialized
INFO - 2016-11-10 13:32:18 --> Model Class Initialized
INFO - 2016-11-10 13:32:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:32:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:32:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:32:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:32:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:32:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:32:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:32:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:32:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:32:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:32:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:32:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:32:18 --> Final output sent to browser
DEBUG - 2016-11-10 13:32:18 --> Total execution time: 0.4217
INFO - 2016-11-10 13:32:33 --> Config Class Initialized
INFO - 2016-11-10 13:32:33 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:32:33 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:32:33 --> Utf8 Class Initialized
INFO - 2016-11-10 13:32:33 --> URI Class Initialized
DEBUG - 2016-11-10 13:32:33 --> No URI present. Default controller set.
INFO - 2016-11-10 13:32:33 --> Router Class Initialized
INFO - 2016-11-10 13:32:33 --> Output Class Initialized
INFO - 2016-11-10 13:32:33 --> Security Class Initialized
DEBUG - 2016-11-10 13:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:32:33 --> Input Class Initialized
INFO - 2016-11-10 13:32:33 --> Language Class Initialized
INFO - 2016-11-10 13:32:33 --> Loader Class Initialized
INFO - 2016-11-10 13:32:33 --> Helper loaded: url_helper
INFO - 2016-11-10 13:32:33 --> Helper loaded: form_helper
INFO - 2016-11-10 13:32:33 --> Database Driver Class Initialized
INFO - 2016-11-10 13:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:32:33 --> Controller Class Initialized
INFO - 2016-11-10 13:32:33 --> Model Class Initialized
INFO - 2016-11-10 13:32:33 --> Model Class Initialized
INFO - 2016-11-10 13:32:33 --> Model Class Initialized
INFO - 2016-11-10 13:32:33 --> Model Class Initialized
INFO - 2016-11-10 13:32:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:32:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:32:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:32:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:32:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:32:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:32:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:32:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:32:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:32:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:32:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:32:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:32:33 --> Final output sent to browser
DEBUG - 2016-11-10 13:32:33 --> Total execution time: 0.4414
INFO - 2016-11-10 13:33:17 --> Config Class Initialized
INFO - 2016-11-10 13:33:17 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:33:17 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:33:17 --> Utf8 Class Initialized
INFO - 2016-11-10 13:33:17 --> URI Class Initialized
DEBUG - 2016-11-10 13:33:17 --> No URI present. Default controller set.
INFO - 2016-11-10 13:33:17 --> Router Class Initialized
INFO - 2016-11-10 13:33:17 --> Output Class Initialized
INFO - 2016-11-10 13:33:17 --> Security Class Initialized
DEBUG - 2016-11-10 13:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:33:17 --> Input Class Initialized
INFO - 2016-11-10 13:33:17 --> Language Class Initialized
INFO - 2016-11-10 13:33:17 --> Loader Class Initialized
INFO - 2016-11-10 13:33:17 --> Helper loaded: url_helper
INFO - 2016-11-10 13:33:17 --> Helper loaded: form_helper
INFO - 2016-11-10 13:33:17 --> Database Driver Class Initialized
INFO - 2016-11-10 13:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:33:17 --> Controller Class Initialized
INFO - 2016-11-10 13:33:17 --> Model Class Initialized
INFO - 2016-11-10 13:33:17 --> Model Class Initialized
INFO - 2016-11-10 13:33:17 --> Model Class Initialized
INFO - 2016-11-10 13:33:17 --> Model Class Initialized
INFO - 2016-11-10 13:33:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:33:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:33:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:33:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:33:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:33:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:33:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:33:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:33:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:33:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:33:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:33:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:33:17 --> Final output sent to browser
DEBUG - 2016-11-10 13:33:17 --> Total execution time: 0.4248
INFO - 2016-11-10 13:33:53 --> Config Class Initialized
INFO - 2016-11-10 13:33:53 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:33:53 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:33:53 --> Utf8 Class Initialized
INFO - 2016-11-10 13:33:53 --> URI Class Initialized
DEBUG - 2016-11-10 13:33:53 --> No URI present. Default controller set.
INFO - 2016-11-10 13:33:53 --> Router Class Initialized
INFO - 2016-11-10 13:33:53 --> Output Class Initialized
INFO - 2016-11-10 13:33:53 --> Security Class Initialized
DEBUG - 2016-11-10 13:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:33:53 --> Input Class Initialized
INFO - 2016-11-10 13:33:53 --> Language Class Initialized
INFO - 2016-11-10 13:33:53 --> Loader Class Initialized
INFO - 2016-11-10 13:33:53 --> Helper loaded: url_helper
INFO - 2016-11-10 13:33:53 --> Helper loaded: form_helper
INFO - 2016-11-10 13:33:53 --> Database Driver Class Initialized
INFO - 2016-11-10 13:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:33:53 --> Controller Class Initialized
INFO - 2016-11-10 13:33:53 --> Model Class Initialized
INFO - 2016-11-10 13:33:53 --> Model Class Initialized
INFO - 2016-11-10 13:33:53 --> Model Class Initialized
INFO - 2016-11-10 13:33:53 --> Model Class Initialized
INFO - 2016-11-10 13:33:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:33:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:33:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:33:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:33:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:33:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:33:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:33:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:33:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:33:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:33:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:33:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:33:53 --> Final output sent to browser
DEBUG - 2016-11-10 13:33:53 --> Total execution time: 0.4519
INFO - 2016-11-10 13:34:03 --> Config Class Initialized
INFO - 2016-11-10 13:34:03 --> Hooks Class Initialized
DEBUG - 2016-11-10 13:34:03 --> UTF-8 Support Enabled
INFO - 2016-11-10 13:34:03 --> Utf8 Class Initialized
INFO - 2016-11-10 13:34:03 --> URI Class Initialized
DEBUG - 2016-11-10 13:34:03 --> No URI present. Default controller set.
INFO - 2016-11-10 13:34:03 --> Router Class Initialized
INFO - 2016-11-10 13:34:03 --> Output Class Initialized
INFO - 2016-11-10 13:34:03 --> Security Class Initialized
DEBUG - 2016-11-10 13:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 13:34:03 --> Input Class Initialized
INFO - 2016-11-10 13:34:03 --> Language Class Initialized
INFO - 2016-11-10 13:34:03 --> Loader Class Initialized
INFO - 2016-11-10 13:34:03 --> Helper loaded: url_helper
INFO - 2016-11-10 13:34:03 --> Helper loaded: form_helper
INFO - 2016-11-10 13:34:03 --> Database Driver Class Initialized
INFO - 2016-11-10 13:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 13:34:03 --> Controller Class Initialized
INFO - 2016-11-10 13:34:03 --> Model Class Initialized
INFO - 2016-11-10 13:34:03 --> Model Class Initialized
INFO - 2016-11-10 13:34:03 --> Model Class Initialized
INFO - 2016-11-10 13:34:03 --> Model Class Initialized
INFO - 2016-11-10 13:34:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 13:34:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 13:34:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 13:34:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 13:34:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 13:34:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 13:34:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 13:34:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 13:34:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 13:34:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 13:34:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 13:34:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 13:34:04 --> Final output sent to browser
DEBUG - 2016-11-10 13:34:04 --> Total execution time: 0.4553
INFO - 2016-11-10 14:47:14 --> Config Class Initialized
INFO - 2016-11-10 14:47:14 --> Hooks Class Initialized
DEBUG - 2016-11-10 14:47:14 --> UTF-8 Support Enabled
INFO - 2016-11-10 14:47:14 --> Utf8 Class Initialized
INFO - 2016-11-10 14:47:14 --> URI Class Initialized
DEBUG - 2016-11-10 14:47:14 --> No URI present. Default controller set.
INFO - 2016-11-10 14:47:14 --> Router Class Initialized
INFO - 2016-11-10 14:47:14 --> Output Class Initialized
INFO - 2016-11-10 14:47:14 --> Security Class Initialized
DEBUG - 2016-11-10 14:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 14:47:14 --> Input Class Initialized
INFO - 2016-11-10 14:47:14 --> Language Class Initialized
INFO - 2016-11-10 14:47:14 --> Loader Class Initialized
INFO - 2016-11-10 14:47:14 --> Helper loaded: url_helper
INFO - 2016-11-10 14:47:14 --> Helper loaded: form_helper
INFO - 2016-11-10 14:47:14 --> Database Driver Class Initialized
INFO - 2016-11-10 14:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 14:47:14 --> Controller Class Initialized
INFO - 2016-11-10 14:47:14 --> Model Class Initialized
INFO - 2016-11-10 14:47:14 --> Model Class Initialized
INFO - 2016-11-10 14:47:14 --> Model Class Initialized
INFO - 2016-11-10 14:47:14 --> Model Class Initialized
INFO - 2016-11-10 14:47:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 14:47:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 14:47:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 14:47:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 14:47:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 14:47:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 14:47:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 14:47:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 14:47:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 14:47:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 14:47:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 14:47:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 14:47:15 --> Final output sent to browser
DEBUG - 2016-11-10 14:47:15 --> Total execution time: 0.4530
INFO - 2016-11-10 14:47:56 --> Config Class Initialized
INFO - 2016-11-10 14:47:56 --> Hooks Class Initialized
DEBUG - 2016-11-10 14:47:56 --> UTF-8 Support Enabled
INFO - 2016-11-10 14:47:56 --> Utf8 Class Initialized
INFO - 2016-11-10 14:47:56 --> URI Class Initialized
DEBUG - 2016-11-10 14:47:56 --> No URI present. Default controller set.
INFO - 2016-11-10 14:47:56 --> Router Class Initialized
INFO - 2016-11-10 14:47:56 --> Output Class Initialized
INFO - 2016-11-10 14:47:56 --> Security Class Initialized
DEBUG - 2016-11-10 14:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 14:47:57 --> Input Class Initialized
INFO - 2016-11-10 14:47:57 --> Language Class Initialized
INFO - 2016-11-10 14:47:57 --> Loader Class Initialized
INFO - 2016-11-10 14:47:57 --> Helper loaded: url_helper
INFO - 2016-11-10 14:47:57 --> Helper loaded: form_helper
INFO - 2016-11-10 14:47:57 --> Database Driver Class Initialized
INFO - 2016-11-10 14:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 14:47:57 --> Controller Class Initialized
INFO - 2016-11-10 14:47:57 --> Model Class Initialized
INFO - 2016-11-10 14:47:57 --> Model Class Initialized
INFO - 2016-11-10 14:47:57 --> Model Class Initialized
INFO - 2016-11-10 14:47:57 --> Model Class Initialized
INFO - 2016-11-10 14:47:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 14:47:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 14:47:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 14:47:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 14:47:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 14:47:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 14:47:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 14:47:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 14:47:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 14:47:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 14:47:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 14:47:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 14:47:57 --> Final output sent to browser
DEBUG - 2016-11-10 14:47:57 --> Total execution time: 0.4382
INFO - 2016-11-10 14:48:13 --> Config Class Initialized
INFO - 2016-11-10 14:48:13 --> Hooks Class Initialized
DEBUG - 2016-11-10 14:48:13 --> UTF-8 Support Enabled
INFO - 2016-11-10 14:48:13 --> Utf8 Class Initialized
INFO - 2016-11-10 14:48:13 --> URI Class Initialized
DEBUG - 2016-11-10 14:48:13 --> No URI present. Default controller set.
INFO - 2016-11-10 14:48:13 --> Router Class Initialized
INFO - 2016-11-10 14:48:13 --> Output Class Initialized
INFO - 2016-11-10 14:48:14 --> Security Class Initialized
DEBUG - 2016-11-10 14:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 14:48:14 --> Input Class Initialized
INFO - 2016-11-10 14:48:14 --> Language Class Initialized
INFO - 2016-11-10 14:48:14 --> Loader Class Initialized
INFO - 2016-11-10 14:48:14 --> Helper loaded: url_helper
INFO - 2016-11-10 14:48:14 --> Helper loaded: form_helper
INFO - 2016-11-10 14:48:14 --> Database Driver Class Initialized
INFO - 2016-11-10 14:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 14:48:14 --> Controller Class Initialized
INFO - 2016-11-10 14:48:14 --> Model Class Initialized
INFO - 2016-11-10 14:48:14 --> Model Class Initialized
INFO - 2016-11-10 14:48:14 --> Model Class Initialized
INFO - 2016-11-10 14:48:14 --> Model Class Initialized
INFO - 2016-11-10 14:48:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 14:48:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 14:48:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 14:48:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 14:48:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 14:48:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 14:48:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 14:48:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 14:48:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 14:48:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 14:48:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 14:48:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 14:48:14 --> Final output sent to browser
DEBUG - 2016-11-10 14:48:14 --> Total execution time: 0.4539
INFO - 2016-11-10 14:48:48 --> Config Class Initialized
INFO - 2016-11-10 14:48:48 --> Hooks Class Initialized
DEBUG - 2016-11-10 14:48:49 --> UTF-8 Support Enabled
INFO - 2016-11-10 14:48:49 --> Utf8 Class Initialized
INFO - 2016-11-10 14:48:49 --> URI Class Initialized
DEBUG - 2016-11-10 14:48:49 --> No URI present. Default controller set.
INFO - 2016-11-10 14:48:49 --> Router Class Initialized
INFO - 2016-11-10 14:48:49 --> Output Class Initialized
INFO - 2016-11-10 14:48:49 --> Security Class Initialized
DEBUG - 2016-11-10 14:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 14:48:49 --> Input Class Initialized
INFO - 2016-11-10 14:48:49 --> Language Class Initialized
INFO - 2016-11-10 14:48:49 --> Loader Class Initialized
INFO - 2016-11-10 14:48:49 --> Helper loaded: url_helper
INFO - 2016-11-10 14:48:49 --> Helper loaded: form_helper
INFO - 2016-11-10 14:48:49 --> Database Driver Class Initialized
INFO - 2016-11-10 14:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 14:48:49 --> Controller Class Initialized
INFO - 2016-11-10 14:48:49 --> Model Class Initialized
INFO - 2016-11-10 14:48:49 --> Model Class Initialized
INFO - 2016-11-10 14:48:49 --> Model Class Initialized
INFO - 2016-11-10 14:48:49 --> Model Class Initialized
INFO - 2016-11-10 14:48:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 14:48:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 14:48:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 14:48:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 14:48:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 14:48:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 14:48:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 14:48:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 14:48:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 14:48:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 14:48:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 14:48:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 14:48:49 --> Final output sent to browser
DEBUG - 2016-11-10 14:48:49 --> Total execution time: 0.4527
INFO - 2016-11-10 14:49:30 --> Config Class Initialized
INFO - 2016-11-10 14:49:30 --> Hooks Class Initialized
DEBUG - 2016-11-10 14:49:30 --> UTF-8 Support Enabled
INFO - 2016-11-10 14:49:30 --> Utf8 Class Initialized
INFO - 2016-11-10 14:49:30 --> URI Class Initialized
DEBUG - 2016-11-10 14:49:30 --> No URI present. Default controller set.
INFO - 2016-11-10 14:49:30 --> Router Class Initialized
INFO - 2016-11-10 14:49:30 --> Output Class Initialized
INFO - 2016-11-10 14:49:30 --> Security Class Initialized
DEBUG - 2016-11-10 14:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 14:49:30 --> Input Class Initialized
INFO - 2016-11-10 14:49:30 --> Language Class Initialized
INFO - 2016-11-10 14:49:31 --> Loader Class Initialized
INFO - 2016-11-10 14:49:31 --> Helper loaded: url_helper
INFO - 2016-11-10 14:49:31 --> Helper loaded: form_helper
INFO - 2016-11-10 14:49:31 --> Database Driver Class Initialized
INFO - 2016-11-10 14:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 14:49:31 --> Controller Class Initialized
INFO - 2016-11-10 14:49:31 --> Model Class Initialized
INFO - 2016-11-10 14:49:31 --> Model Class Initialized
INFO - 2016-11-10 14:49:31 --> Model Class Initialized
INFO - 2016-11-10 14:49:31 --> Model Class Initialized
INFO - 2016-11-10 14:49:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 14:49:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 14:49:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 14:49:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 14:49:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 14:49:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 14:49:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 14:49:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
ERROR - 2016-11-10 14:49:31 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 14:49:31 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 14:49:31 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 14:49:31 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 14:49:31 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
INFO - 2016-11-10 14:49:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 14:49:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 14:49:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 14:49:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 14:49:31 --> Final output sent to browser
DEBUG - 2016-11-10 14:49:31 --> Total execution time: 0.5388
INFO - 2016-11-10 14:49:48 --> Config Class Initialized
INFO - 2016-11-10 14:49:48 --> Hooks Class Initialized
DEBUG - 2016-11-10 14:49:48 --> UTF-8 Support Enabled
INFO - 2016-11-10 14:49:48 --> Utf8 Class Initialized
INFO - 2016-11-10 14:49:48 --> URI Class Initialized
DEBUG - 2016-11-10 14:49:48 --> No URI present. Default controller set.
INFO - 2016-11-10 14:49:48 --> Router Class Initialized
INFO - 2016-11-10 14:49:48 --> Output Class Initialized
INFO - 2016-11-10 14:49:48 --> Security Class Initialized
DEBUG - 2016-11-10 14:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 14:49:48 --> Input Class Initialized
INFO - 2016-11-10 14:49:48 --> Language Class Initialized
INFO - 2016-11-10 14:49:48 --> Loader Class Initialized
INFO - 2016-11-10 14:49:48 --> Helper loaded: url_helper
INFO - 2016-11-10 14:49:48 --> Helper loaded: form_helper
INFO - 2016-11-10 14:49:48 --> Database Driver Class Initialized
INFO - 2016-11-10 14:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 14:49:48 --> Controller Class Initialized
INFO - 2016-11-10 14:49:48 --> Model Class Initialized
INFO - 2016-11-10 14:49:48 --> Model Class Initialized
INFO - 2016-11-10 14:49:48 --> Model Class Initialized
INFO - 2016-11-10 14:49:48 --> Model Class Initialized
INFO - 2016-11-10 14:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 14:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 14:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 14:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 14:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 14:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 14:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 14:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
ERROR - 2016-11-10 14:49:48 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 14:49:48 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 14:49:48 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 14:49:48 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 14:49:48 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 14:49:48 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 14:49:48 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 14:49:48 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
ERROR - 2016-11-10 14:49:48 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 17
INFO - 2016-11-10 14:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 14:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 14:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 14:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 14:49:48 --> Final output sent to browser
DEBUG - 2016-11-10 14:49:48 --> Total execution time: 0.5685
INFO - 2016-11-10 14:50:48 --> Config Class Initialized
INFO - 2016-11-10 14:50:48 --> Hooks Class Initialized
DEBUG - 2016-11-10 14:50:48 --> UTF-8 Support Enabled
INFO - 2016-11-10 14:50:48 --> Utf8 Class Initialized
INFO - 2016-11-10 14:50:48 --> URI Class Initialized
DEBUG - 2016-11-10 14:50:48 --> No URI present. Default controller set.
INFO - 2016-11-10 14:50:48 --> Router Class Initialized
INFO - 2016-11-10 14:50:48 --> Output Class Initialized
INFO - 2016-11-10 14:50:48 --> Security Class Initialized
DEBUG - 2016-11-10 14:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 14:50:48 --> Input Class Initialized
INFO - 2016-11-10 14:50:49 --> Language Class Initialized
INFO - 2016-11-10 14:50:49 --> Loader Class Initialized
INFO - 2016-11-10 14:50:49 --> Helper loaded: url_helper
INFO - 2016-11-10 14:50:49 --> Helper loaded: form_helper
INFO - 2016-11-10 14:50:49 --> Database Driver Class Initialized
INFO - 2016-11-10 14:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 14:50:49 --> Controller Class Initialized
INFO - 2016-11-10 14:50:49 --> Model Class Initialized
INFO - 2016-11-10 14:50:49 --> Model Class Initialized
INFO - 2016-11-10 14:50:49 --> Model Class Initialized
INFO - 2016-11-10 14:50:49 --> Model Class Initialized
INFO - 2016-11-10 14:50:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 14:50:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 14:50:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 14:50:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 14:50:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 14:50:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 14:50:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 14:50:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 14:50:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 14:50:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 14:50:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 14:50:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 14:50:49 --> Final output sent to browser
DEBUG - 2016-11-10 14:50:49 --> Total execution time: 0.4603
INFO - 2016-11-10 14:52:33 --> Config Class Initialized
INFO - 2016-11-10 14:52:33 --> Hooks Class Initialized
DEBUG - 2016-11-10 14:52:33 --> UTF-8 Support Enabled
INFO - 2016-11-10 14:52:33 --> Utf8 Class Initialized
INFO - 2016-11-10 14:52:33 --> URI Class Initialized
DEBUG - 2016-11-10 14:52:33 --> No URI present. Default controller set.
INFO - 2016-11-10 14:52:33 --> Router Class Initialized
INFO - 2016-11-10 14:52:33 --> Output Class Initialized
INFO - 2016-11-10 14:52:33 --> Security Class Initialized
DEBUG - 2016-11-10 14:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 14:52:33 --> Input Class Initialized
INFO - 2016-11-10 14:52:33 --> Language Class Initialized
INFO - 2016-11-10 14:52:33 --> Loader Class Initialized
INFO - 2016-11-10 14:52:33 --> Helper loaded: url_helper
INFO - 2016-11-10 14:52:33 --> Helper loaded: form_helper
INFO - 2016-11-10 14:52:33 --> Database Driver Class Initialized
INFO - 2016-11-10 14:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 14:52:33 --> Controller Class Initialized
INFO - 2016-11-10 14:52:33 --> Model Class Initialized
INFO - 2016-11-10 14:52:33 --> Model Class Initialized
INFO - 2016-11-10 14:52:33 --> Model Class Initialized
INFO - 2016-11-10 14:52:33 --> Model Class Initialized
INFO - 2016-11-10 14:52:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 14:52:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 14:52:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 14:52:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 14:52:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 14:52:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 14:52:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 14:52:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 14:52:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 14:52:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 14:52:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 14:52:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 14:52:33 --> Final output sent to browser
DEBUG - 2016-11-10 14:52:33 --> Total execution time: 0.4755
INFO - 2016-11-10 14:53:51 --> Config Class Initialized
INFO - 2016-11-10 14:53:51 --> Hooks Class Initialized
DEBUG - 2016-11-10 14:53:51 --> UTF-8 Support Enabled
INFO - 2016-11-10 14:53:51 --> Utf8 Class Initialized
INFO - 2016-11-10 14:53:51 --> URI Class Initialized
DEBUG - 2016-11-10 14:53:51 --> No URI present. Default controller set.
INFO - 2016-11-10 14:53:51 --> Router Class Initialized
INFO - 2016-11-10 14:53:51 --> Output Class Initialized
INFO - 2016-11-10 14:53:51 --> Security Class Initialized
DEBUG - 2016-11-10 14:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 14:53:51 --> Input Class Initialized
INFO - 2016-11-10 14:53:51 --> Language Class Initialized
INFO - 2016-11-10 14:53:51 --> Loader Class Initialized
INFO - 2016-11-10 14:53:51 --> Helper loaded: url_helper
INFO - 2016-11-10 14:53:51 --> Helper loaded: form_helper
INFO - 2016-11-10 14:53:51 --> Database Driver Class Initialized
INFO - 2016-11-10 14:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 14:53:51 --> Controller Class Initialized
INFO - 2016-11-10 14:53:51 --> Model Class Initialized
INFO - 2016-11-10 14:53:51 --> Model Class Initialized
INFO - 2016-11-10 14:53:51 --> Model Class Initialized
INFO - 2016-11-10 14:53:51 --> Model Class Initialized
INFO - 2016-11-10 14:53:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 14:53:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 14:53:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 14:53:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 14:53:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 14:53:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 14:53:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 14:53:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 14:53:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 14:53:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 14:53:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 14:53:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 14:53:52 --> Final output sent to browser
DEBUG - 2016-11-10 14:53:52 --> Total execution time: 0.4677
INFO - 2016-11-10 14:55:30 --> Config Class Initialized
INFO - 2016-11-10 14:55:30 --> Hooks Class Initialized
DEBUG - 2016-11-10 14:55:30 --> UTF-8 Support Enabled
INFO - 2016-11-10 14:55:30 --> Utf8 Class Initialized
INFO - 2016-11-10 14:55:30 --> URI Class Initialized
INFO - 2016-11-10 14:55:30 --> Router Class Initialized
INFO - 2016-11-10 14:55:30 --> Output Class Initialized
INFO - 2016-11-10 14:55:30 --> Security Class Initialized
DEBUG - 2016-11-10 14:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 14:55:30 --> Input Class Initialized
INFO - 2016-11-10 14:55:30 --> Language Class Initialized
INFO - 2016-11-10 14:55:30 --> Loader Class Initialized
INFO - 2016-11-10 14:55:30 --> Helper loaded: url_helper
INFO - 2016-11-10 14:55:30 --> Helper loaded: form_helper
INFO - 2016-11-10 14:55:30 --> Database Driver Class Initialized
INFO - 2016-11-10 14:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 14:55:30 --> Controller Class Initialized
INFO - 2016-11-10 14:55:30 --> Model Class Initialized
INFO - 2016-11-10 14:55:30 --> Form Validation Class Initialized
INFO - 2016-11-10 14:55:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-10 14:55:30 --> Final output sent to browser
DEBUG - 2016-11-10 14:55:30 --> Total execution time: 0.2757
INFO - 2016-11-10 14:55:33 --> Config Class Initialized
INFO - 2016-11-10 14:55:33 --> Hooks Class Initialized
DEBUG - 2016-11-10 14:55:33 --> UTF-8 Support Enabled
INFO - 2016-11-10 14:55:33 --> Utf8 Class Initialized
INFO - 2016-11-10 14:55:33 --> URI Class Initialized
DEBUG - 2016-11-10 14:55:33 --> No URI present. Default controller set.
INFO - 2016-11-10 14:55:33 --> Router Class Initialized
INFO - 2016-11-10 14:55:33 --> Output Class Initialized
INFO - 2016-11-10 14:55:33 --> Security Class Initialized
DEBUG - 2016-11-10 14:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 14:55:33 --> Input Class Initialized
INFO - 2016-11-10 14:55:33 --> Language Class Initialized
INFO - 2016-11-10 14:55:33 --> Loader Class Initialized
INFO - 2016-11-10 14:55:33 --> Helper loaded: url_helper
INFO - 2016-11-10 14:55:33 --> Helper loaded: form_helper
INFO - 2016-11-10 14:55:33 --> Database Driver Class Initialized
INFO - 2016-11-10 14:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 14:55:33 --> Controller Class Initialized
INFO - 2016-11-10 14:55:33 --> Model Class Initialized
INFO - 2016-11-10 14:55:33 --> Model Class Initialized
INFO - 2016-11-10 14:55:33 --> Model Class Initialized
INFO - 2016-11-10 14:55:33 --> Model Class Initialized
INFO - 2016-11-10 14:55:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 14:55:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 14:55:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 14:55:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 14:55:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 14:55:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 14:55:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 14:55:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 14:55:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 14:55:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 14:55:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 14:55:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 14:55:33 --> Final output sent to browser
DEBUG - 2016-11-10 14:55:33 --> Total execution time: 0.4517
INFO - 2016-11-10 14:55:40 --> Config Class Initialized
INFO - 2016-11-10 14:55:40 --> Hooks Class Initialized
DEBUG - 2016-11-10 14:55:40 --> UTF-8 Support Enabled
INFO - 2016-11-10 14:55:40 --> Utf8 Class Initialized
INFO - 2016-11-10 14:55:40 --> URI Class Initialized
INFO - 2016-11-10 14:55:40 --> Router Class Initialized
INFO - 2016-11-10 14:55:40 --> Output Class Initialized
INFO - 2016-11-10 14:55:40 --> Security Class Initialized
DEBUG - 2016-11-10 14:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 14:55:40 --> Input Class Initialized
INFO - 2016-11-10 14:55:40 --> Language Class Initialized
INFO - 2016-11-10 14:55:40 --> Loader Class Initialized
INFO - 2016-11-10 14:55:40 --> Helper loaded: url_helper
INFO - 2016-11-10 14:55:40 --> Helper loaded: form_helper
INFO - 2016-11-10 14:55:40 --> Database Driver Class Initialized
INFO - 2016-11-10 14:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 14:55:40 --> Controller Class Initialized
INFO - 2016-11-10 14:55:40 --> Model Class Initialized
INFO - 2016-11-10 14:55:41 --> Form Validation Class Initialized
INFO - 2016-11-10 14:55:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-10 14:55:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 14:55:41 --> Final output sent to browser
DEBUG - 2016-11-10 14:55:41 --> Total execution time: 0.5891
INFO - 2016-11-10 14:55:43 --> Config Class Initialized
INFO - 2016-11-10 14:55:43 --> Hooks Class Initialized
DEBUG - 2016-11-10 14:55:43 --> UTF-8 Support Enabled
INFO - 2016-11-10 14:55:43 --> Utf8 Class Initialized
INFO - 2016-11-10 14:55:43 --> URI Class Initialized
DEBUG - 2016-11-10 14:55:43 --> No URI present. Default controller set.
INFO - 2016-11-10 14:55:43 --> Router Class Initialized
INFO - 2016-11-10 14:55:43 --> Output Class Initialized
INFO - 2016-11-10 14:55:43 --> Security Class Initialized
DEBUG - 2016-11-10 14:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 14:55:43 --> Input Class Initialized
INFO - 2016-11-10 14:55:43 --> Language Class Initialized
INFO - 2016-11-10 14:55:43 --> Loader Class Initialized
INFO - 2016-11-10 14:55:43 --> Helper loaded: url_helper
INFO - 2016-11-10 14:55:43 --> Helper loaded: form_helper
INFO - 2016-11-10 14:55:43 --> Database Driver Class Initialized
INFO - 2016-11-10 14:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 14:55:43 --> Controller Class Initialized
INFO - 2016-11-10 14:55:43 --> Model Class Initialized
INFO - 2016-11-10 14:55:43 --> Model Class Initialized
INFO - 2016-11-10 14:55:43 --> Model Class Initialized
INFO - 2016-11-10 14:55:43 --> Model Class Initialized
INFO - 2016-11-10 14:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 14:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 14:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 14:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 14:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 14:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 14:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 14:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 14:55:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 14:55:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 14:55:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 14:55:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 14:55:44 --> Final output sent to browser
DEBUG - 2016-11-10 14:55:44 --> Total execution time: 0.4574
INFO - 2016-11-10 14:56:17 --> Config Class Initialized
INFO - 2016-11-10 14:56:17 --> Hooks Class Initialized
DEBUG - 2016-11-10 14:56:17 --> UTF-8 Support Enabled
INFO - 2016-11-10 14:56:17 --> Utf8 Class Initialized
INFO - 2016-11-10 14:56:17 --> URI Class Initialized
DEBUG - 2016-11-10 14:56:17 --> No URI present. Default controller set.
INFO - 2016-11-10 14:56:17 --> Router Class Initialized
INFO - 2016-11-10 14:56:17 --> Output Class Initialized
INFO - 2016-11-10 14:56:17 --> Security Class Initialized
DEBUG - 2016-11-10 14:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 14:56:17 --> Input Class Initialized
INFO - 2016-11-10 14:56:17 --> Language Class Initialized
INFO - 2016-11-10 14:56:17 --> Loader Class Initialized
INFO - 2016-11-10 14:56:17 --> Helper loaded: url_helper
INFO - 2016-11-10 14:56:17 --> Helper loaded: form_helper
INFO - 2016-11-10 14:56:17 --> Database Driver Class Initialized
INFO - 2016-11-10 14:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 14:56:17 --> Controller Class Initialized
INFO - 2016-11-10 14:56:17 --> Model Class Initialized
INFO - 2016-11-10 14:56:17 --> Model Class Initialized
INFO - 2016-11-10 14:56:17 --> Model Class Initialized
INFO - 2016-11-10 14:56:17 --> Model Class Initialized
INFO - 2016-11-10 14:56:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 14:56:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 14:56:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 14:56:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 14:56:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 14:56:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 14:56:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 14:56:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 14:56:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 14:56:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 14:56:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 14:56:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 14:56:18 --> Final output sent to browser
DEBUG - 2016-11-10 14:56:18 --> Total execution time: 0.4895
INFO - 2016-11-10 14:56:43 --> Config Class Initialized
INFO - 2016-11-10 14:56:43 --> Hooks Class Initialized
DEBUG - 2016-11-10 14:56:43 --> UTF-8 Support Enabled
INFO - 2016-11-10 14:56:43 --> Utf8 Class Initialized
INFO - 2016-11-10 14:56:43 --> URI Class Initialized
DEBUG - 2016-11-10 14:56:43 --> No URI present. Default controller set.
INFO - 2016-11-10 14:56:43 --> Router Class Initialized
INFO - 2016-11-10 14:56:43 --> Output Class Initialized
INFO - 2016-11-10 14:56:43 --> Security Class Initialized
DEBUG - 2016-11-10 14:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 14:56:43 --> Input Class Initialized
INFO - 2016-11-10 14:56:43 --> Language Class Initialized
INFO - 2016-11-10 14:56:43 --> Loader Class Initialized
INFO - 2016-11-10 14:56:43 --> Helper loaded: url_helper
INFO - 2016-11-10 14:56:43 --> Helper loaded: form_helper
INFO - 2016-11-10 14:56:43 --> Database Driver Class Initialized
INFO - 2016-11-10 14:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 14:56:43 --> Controller Class Initialized
INFO - 2016-11-10 14:56:43 --> Model Class Initialized
INFO - 2016-11-10 14:56:43 --> Model Class Initialized
INFO - 2016-11-10 14:56:43 --> Model Class Initialized
INFO - 2016-11-10 14:56:43 --> Model Class Initialized
INFO - 2016-11-10 14:56:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 14:56:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 14:56:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 14:56:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 14:56:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 14:56:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 14:56:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 14:56:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 14:56:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 14:56:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 14:56:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 14:56:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 14:56:43 --> Final output sent to browser
DEBUG - 2016-11-10 14:56:43 --> Total execution time: 0.4891
INFO - 2016-11-10 15:07:16 --> Config Class Initialized
INFO - 2016-11-10 15:07:16 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:07:16 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:07:16 --> Utf8 Class Initialized
INFO - 2016-11-10 15:07:16 --> URI Class Initialized
DEBUG - 2016-11-10 15:07:16 --> No URI present. Default controller set.
INFO - 2016-11-10 15:07:16 --> Router Class Initialized
INFO - 2016-11-10 15:07:16 --> Output Class Initialized
INFO - 2016-11-10 15:07:16 --> Security Class Initialized
DEBUG - 2016-11-10 15:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:07:17 --> Input Class Initialized
INFO - 2016-11-10 15:07:17 --> Language Class Initialized
INFO - 2016-11-10 15:07:17 --> Loader Class Initialized
INFO - 2016-11-10 15:07:17 --> Helper loaded: url_helper
INFO - 2016-11-10 15:07:17 --> Helper loaded: form_helper
INFO - 2016-11-10 15:07:17 --> Database Driver Class Initialized
INFO - 2016-11-10 15:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:07:17 --> Controller Class Initialized
INFO - 2016-11-10 15:07:17 --> Model Class Initialized
INFO - 2016-11-10 15:07:17 --> Model Class Initialized
INFO - 2016-11-10 15:07:17 --> Model Class Initialized
INFO - 2016-11-10 15:07:17 --> Model Class Initialized
INFO - 2016-11-10 15:07:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:07:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 15:07:34 --> Config Class Initialized
INFO - 2016-11-10 15:07:34 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:07:34 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:07:34 --> Utf8 Class Initialized
INFO - 2016-11-10 15:07:34 --> URI Class Initialized
DEBUG - 2016-11-10 15:07:34 --> No URI present. Default controller set.
INFO - 2016-11-10 15:07:34 --> Router Class Initialized
INFO - 2016-11-10 15:07:34 --> Output Class Initialized
INFO - 2016-11-10 15:07:34 --> Security Class Initialized
DEBUG - 2016-11-10 15:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:07:34 --> Input Class Initialized
INFO - 2016-11-10 15:07:34 --> Language Class Initialized
INFO - 2016-11-10 15:07:34 --> Loader Class Initialized
INFO - 2016-11-10 15:07:34 --> Helper loaded: url_helper
INFO - 2016-11-10 15:07:34 --> Helper loaded: form_helper
INFO - 2016-11-10 15:07:34 --> Database Driver Class Initialized
INFO - 2016-11-10 15:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:07:34 --> Controller Class Initialized
INFO - 2016-11-10 15:07:34 --> Model Class Initialized
INFO - 2016-11-10 15:07:34 --> Model Class Initialized
INFO - 2016-11-10 15:07:34 --> Model Class Initialized
INFO - 2016-11-10 15:07:34 --> Model Class Initialized
INFO - 2016-11-10 15:07:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:07:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 15:07:35 --> Config Class Initialized
INFO - 2016-11-10 15:07:35 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:07:35 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:07:35 --> Utf8 Class Initialized
INFO - 2016-11-10 15:07:35 --> URI Class Initialized
DEBUG - 2016-11-10 15:07:35 --> No URI present. Default controller set.
INFO - 2016-11-10 15:07:35 --> Router Class Initialized
INFO - 2016-11-10 15:07:35 --> Output Class Initialized
INFO - 2016-11-10 15:07:35 --> Security Class Initialized
DEBUG - 2016-11-10 15:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:07:35 --> Input Class Initialized
INFO - 2016-11-10 15:07:35 --> Language Class Initialized
INFO - 2016-11-10 15:07:35 --> Loader Class Initialized
INFO - 2016-11-10 15:07:35 --> Helper loaded: url_helper
INFO - 2016-11-10 15:07:35 --> Helper loaded: form_helper
INFO - 2016-11-10 15:07:35 --> Database Driver Class Initialized
INFO - 2016-11-10 15:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:07:35 --> Controller Class Initialized
INFO - 2016-11-10 15:07:35 --> Model Class Initialized
INFO - 2016-11-10 15:07:35 --> Model Class Initialized
INFO - 2016-11-10 15:07:35 --> Model Class Initialized
INFO - 2016-11-10 15:07:35 --> Model Class Initialized
INFO - 2016-11-10 15:07:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:07:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 15:07:45 --> Config Class Initialized
INFO - 2016-11-10 15:07:45 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:07:45 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:07:45 --> Utf8 Class Initialized
INFO - 2016-11-10 15:07:45 --> URI Class Initialized
INFO - 2016-11-10 15:07:45 --> Router Class Initialized
INFO - 2016-11-10 15:07:45 --> Output Class Initialized
INFO - 2016-11-10 15:07:45 --> Security Class Initialized
DEBUG - 2016-11-10 15:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:07:45 --> Input Class Initialized
INFO - 2016-11-10 15:07:45 --> Language Class Initialized
INFO - 2016-11-10 15:07:45 --> Loader Class Initialized
INFO - 2016-11-10 15:07:45 --> Helper loaded: url_helper
INFO - 2016-11-10 15:07:45 --> Helper loaded: form_helper
INFO - 2016-11-10 15:07:45 --> Database Driver Class Initialized
INFO - 2016-11-10 15:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:07:45 --> Controller Class Initialized
INFO - 2016-11-10 15:07:45 --> Model Class Initialized
INFO - 2016-11-10 15:07:45 --> Model Class Initialized
INFO - 2016-11-10 15:07:45 --> Model Class Initialized
INFO - 2016-11-10 15:07:45 --> Model Class Initialized
DEBUG - 2016-11-10 15:07:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 15:07:45 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 134
ERROR - 2016-11-10 15:07:45 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 134
INFO - 2016-11-10 15:07:45 --> Config Class Initialized
INFO - 2016-11-10 15:07:45 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:07:45 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:07:45 --> Utf8 Class Initialized
INFO - 2016-11-10 15:07:45 --> URI Class Initialized
DEBUG - 2016-11-10 15:07:45 --> No URI present. Default controller set.
INFO - 2016-11-10 15:07:45 --> Router Class Initialized
INFO - 2016-11-10 15:07:45 --> Output Class Initialized
INFO - 2016-11-10 15:07:45 --> Security Class Initialized
DEBUG - 2016-11-10 15:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:07:45 --> Input Class Initialized
INFO - 2016-11-10 15:07:45 --> Language Class Initialized
INFO - 2016-11-10 15:07:45 --> Loader Class Initialized
INFO - 2016-11-10 15:07:45 --> Helper loaded: url_helper
INFO - 2016-11-10 15:07:45 --> Helper loaded: form_helper
INFO - 2016-11-10 15:07:45 --> Database Driver Class Initialized
INFO - 2016-11-10 15:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:07:45 --> Controller Class Initialized
INFO - 2016-11-10 15:07:45 --> Model Class Initialized
INFO - 2016-11-10 15:07:45 --> Model Class Initialized
INFO - 2016-11-10 15:07:45 --> Model Class Initialized
INFO - 2016-11-10 15:07:45 --> Model Class Initialized
INFO - 2016-11-10 15:07:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:07:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 15:07:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 15:07:45 --> Final output sent to browser
DEBUG - 2016-11-10 15:07:45 --> Total execution time: 0.3231
INFO - 2016-11-10 15:08:19 --> Config Class Initialized
INFO - 2016-11-10 15:08:19 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:08:19 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:08:19 --> Utf8 Class Initialized
INFO - 2016-11-10 15:08:19 --> URI Class Initialized
INFO - 2016-11-10 15:08:19 --> Router Class Initialized
INFO - 2016-11-10 15:08:19 --> Output Class Initialized
INFO - 2016-11-10 15:08:19 --> Security Class Initialized
DEBUG - 2016-11-10 15:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:08:19 --> Input Class Initialized
INFO - 2016-11-10 15:08:19 --> Language Class Initialized
INFO - 2016-11-10 15:08:19 --> Loader Class Initialized
INFO - 2016-11-10 15:08:19 --> Helper loaded: url_helper
INFO - 2016-11-10 15:08:19 --> Helper loaded: form_helper
INFO - 2016-11-10 15:08:19 --> Database Driver Class Initialized
INFO - 2016-11-10 15:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:08:19 --> Controller Class Initialized
INFO - 2016-11-10 15:08:19 --> Model Class Initialized
INFO - 2016-11-10 15:08:19 --> Model Class Initialized
INFO - 2016-11-10 15:08:19 --> Model Class Initialized
INFO - 2016-11-10 15:08:19 --> Model Class Initialized
DEBUG - 2016-11-10 15:08:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 15:08:19 --> Model Class Initialized
INFO - 2016-11-10 15:08:19 --> Final output sent to browser
DEBUG - 2016-11-10 15:08:19 --> Total execution time: 0.4135
INFO - 2016-11-10 15:08:19 --> Config Class Initialized
INFO - 2016-11-10 15:08:19 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:08:19 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:08:19 --> Utf8 Class Initialized
INFO - 2016-11-10 15:08:19 --> URI Class Initialized
DEBUG - 2016-11-10 15:08:19 --> No URI present. Default controller set.
INFO - 2016-11-10 15:08:19 --> Router Class Initialized
INFO - 2016-11-10 15:08:19 --> Output Class Initialized
INFO - 2016-11-10 15:08:19 --> Security Class Initialized
DEBUG - 2016-11-10 15:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:08:19 --> Input Class Initialized
INFO - 2016-11-10 15:08:19 --> Language Class Initialized
INFO - 2016-11-10 15:08:19 --> Loader Class Initialized
INFO - 2016-11-10 15:08:19 --> Helper loaded: url_helper
INFO - 2016-11-10 15:08:19 --> Helper loaded: form_helper
INFO - 2016-11-10 15:08:19 --> Database Driver Class Initialized
INFO - 2016-11-10 15:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:08:19 --> Controller Class Initialized
INFO - 2016-11-10 15:08:19 --> Model Class Initialized
INFO - 2016-11-10 15:08:19 --> Model Class Initialized
INFO - 2016-11-10 15:08:19 --> Model Class Initialized
INFO - 2016-11-10 15:08:19 --> Model Class Initialized
INFO - 2016-11-10 15:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 15:12:12 --> Config Class Initialized
INFO - 2016-11-10 15:12:12 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:12:12 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:12:12 --> Utf8 Class Initialized
INFO - 2016-11-10 15:12:12 --> URI Class Initialized
DEBUG - 2016-11-10 15:12:12 --> No URI present. Default controller set.
INFO - 2016-11-10 15:12:12 --> Router Class Initialized
INFO - 2016-11-10 15:12:12 --> Output Class Initialized
INFO - 2016-11-10 15:12:12 --> Security Class Initialized
DEBUG - 2016-11-10 15:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:12:12 --> Input Class Initialized
INFO - 2016-11-10 15:12:12 --> Language Class Initialized
INFO - 2016-11-10 15:12:12 --> Loader Class Initialized
INFO - 2016-11-10 15:12:12 --> Helper loaded: url_helper
INFO - 2016-11-10 15:12:12 --> Helper loaded: form_helper
INFO - 2016-11-10 15:12:12 --> Database Driver Class Initialized
INFO - 2016-11-10 15:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:12:12 --> Controller Class Initialized
INFO - 2016-11-10 15:12:12 --> Model Class Initialized
INFO - 2016-11-10 15:12:12 --> Model Class Initialized
INFO - 2016-11-10 15:12:12 --> Model Class Initialized
INFO - 2016-11-10 15:12:12 --> Model Class Initialized
INFO - 2016-11-10 15:12:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:12:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 15:12:12 --> Query error: Unknown column 'surname' in 'field list' - Invalid query: SELECT `id`, `surname`
FROM `leaveRecord`
WHERE `idEmployee` = 15
INFO - 2016-11-10 15:12:12 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 15:13:24 --> Config Class Initialized
INFO - 2016-11-10 15:13:24 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:13:24 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:13:24 --> Utf8 Class Initialized
INFO - 2016-11-10 15:13:24 --> URI Class Initialized
DEBUG - 2016-11-10 15:13:24 --> No URI present. Default controller set.
INFO - 2016-11-10 15:13:24 --> Router Class Initialized
INFO - 2016-11-10 15:13:24 --> Output Class Initialized
INFO - 2016-11-10 15:13:24 --> Security Class Initialized
DEBUG - 2016-11-10 15:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:13:24 --> Input Class Initialized
INFO - 2016-11-10 15:13:24 --> Language Class Initialized
INFO - 2016-11-10 15:13:24 --> Loader Class Initialized
INFO - 2016-11-10 15:13:25 --> Helper loaded: url_helper
INFO - 2016-11-10 15:13:25 --> Helper loaded: form_helper
INFO - 2016-11-10 15:13:25 --> Database Driver Class Initialized
INFO - 2016-11-10 15:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:13:25 --> Controller Class Initialized
INFO - 2016-11-10 15:13:25 --> Model Class Initialized
INFO - 2016-11-10 15:13:25 --> Model Class Initialized
INFO - 2016-11-10 15:13:25 --> Model Class Initialized
INFO - 2016-11-10 15:13:25 --> Model Class Initialized
INFO - 2016-11-10 15:13:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:13:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 15:13:25 --> Query error: Unknown column 'idEmployee' in 'where clause' - Invalid query: SELECT `id`, `surname`
FROM `employee`
WHERE `idEmployee` = 15
INFO - 2016-11-10 15:13:25 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 15:13:26 --> Config Class Initialized
INFO - 2016-11-10 15:13:26 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:13:26 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:13:26 --> Utf8 Class Initialized
INFO - 2016-11-10 15:13:26 --> URI Class Initialized
DEBUG - 2016-11-10 15:13:26 --> No URI present. Default controller set.
INFO - 2016-11-10 15:13:26 --> Router Class Initialized
INFO - 2016-11-10 15:13:26 --> Output Class Initialized
INFO - 2016-11-10 15:13:26 --> Security Class Initialized
DEBUG - 2016-11-10 15:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:13:26 --> Input Class Initialized
INFO - 2016-11-10 15:13:26 --> Language Class Initialized
INFO - 2016-11-10 15:13:26 --> Loader Class Initialized
INFO - 2016-11-10 15:13:26 --> Helper loaded: url_helper
INFO - 2016-11-10 15:13:26 --> Helper loaded: form_helper
INFO - 2016-11-10 15:13:26 --> Database Driver Class Initialized
INFO - 2016-11-10 15:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:13:26 --> Controller Class Initialized
INFO - 2016-11-10 15:13:26 --> Model Class Initialized
INFO - 2016-11-10 15:13:26 --> Model Class Initialized
INFO - 2016-11-10 15:13:26 --> Model Class Initialized
INFO - 2016-11-10 15:13:26 --> Model Class Initialized
INFO - 2016-11-10 15:13:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:13:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 15:13:26 --> Query error: Unknown column 'idEmployee' in 'where clause' - Invalid query: SELECT `id`, `surname`
FROM `employee`
WHERE `idEmployee` = 15
INFO - 2016-11-10 15:13:26 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 15:17:15 --> Config Class Initialized
INFO - 2016-11-10 15:17:15 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:17:15 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:17:15 --> Utf8 Class Initialized
INFO - 2016-11-10 15:17:15 --> URI Class Initialized
DEBUG - 2016-11-10 15:17:15 --> No URI present. Default controller set.
INFO - 2016-11-10 15:17:15 --> Router Class Initialized
INFO - 2016-11-10 15:17:15 --> Output Class Initialized
INFO - 2016-11-10 15:17:15 --> Security Class Initialized
DEBUG - 2016-11-10 15:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:17:15 --> Input Class Initialized
INFO - 2016-11-10 15:17:15 --> Language Class Initialized
INFO - 2016-11-10 15:17:15 --> Loader Class Initialized
INFO - 2016-11-10 15:17:15 --> Helper loaded: url_helper
INFO - 2016-11-10 15:17:15 --> Helper loaded: form_helper
INFO - 2016-11-10 15:17:15 --> Database Driver Class Initialized
INFO - 2016-11-10 15:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:17:15 --> Controller Class Initialized
INFO - 2016-11-10 15:17:15 --> Model Class Initialized
INFO - 2016-11-10 15:17:15 --> Model Class Initialized
INFO - 2016-11-10 15:17:15 --> Model Class Initialized
INFO - 2016-11-10 15:17:15 --> Model Class Initialized
INFO - 2016-11-10 15:17:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:17:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 15:17:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `idEmployee` = 15' at line 2 - Invalid query: SELECT `id`, `surname`
WHERE `idEmployee` = 15
INFO - 2016-11-10 15:17:15 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 15:17:16 --> Config Class Initialized
INFO - 2016-11-10 15:17:16 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:17:16 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:17:16 --> Utf8 Class Initialized
INFO - 2016-11-10 15:17:16 --> URI Class Initialized
DEBUG - 2016-11-10 15:17:17 --> No URI present. Default controller set.
INFO - 2016-11-10 15:17:17 --> Router Class Initialized
INFO - 2016-11-10 15:17:17 --> Output Class Initialized
INFO - 2016-11-10 15:17:17 --> Security Class Initialized
DEBUG - 2016-11-10 15:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:17:17 --> Input Class Initialized
INFO - 2016-11-10 15:17:17 --> Language Class Initialized
INFO - 2016-11-10 15:17:17 --> Loader Class Initialized
INFO - 2016-11-10 15:17:17 --> Helper loaded: url_helper
INFO - 2016-11-10 15:17:17 --> Helper loaded: form_helper
INFO - 2016-11-10 15:17:17 --> Database Driver Class Initialized
INFO - 2016-11-10 15:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:17:17 --> Controller Class Initialized
INFO - 2016-11-10 15:17:17 --> Model Class Initialized
INFO - 2016-11-10 15:17:17 --> Model Class Initialized
INFO - 2016-11-10 15:17:17 --> Model Class Initialized
INFO - 2016-11-10 15:17:17 --> Model Class Initialized
INFO - 2016-11-10 15:17:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:17:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 15:17:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `idEmployee` = 15' at line 2 - Invalid query: SELECT `id`, `surname`
WHERE `idEmployee` = 15
INFO - 2016-11-10 15:17:17 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 15:18:42 --> Config Class Initialized
INFO - 2016-11-10 15:18:42 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:18:42 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:18:42 --> Utf8 Class Initialized
INFO - 2016-11-10 15:18:42 --> URI Class Initialized
DEBUG - 2016-11-10 15:18:42 --> No URI present. Default controller set.
INFO - 2016-11-10 15:18:42 --> Router Class Initialized
INFO - 2016-11-10 15:18:42 --> Output Class Initialized
INFO - 2016-11-10 15:18:42 --> Security Class Initialized
DEBUG - 2016-11-10 15:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:18:43 --> Input Class Initialized
INFO - 2016-11-10 15:18:43 --> Language Class Initialized
INFO - 2016-11-10 15:18:43 --> Loader Class Initialized
INFO - 2016-11-10 15:18:43 --> Helper loaded: url_helper
INFO - 2016-11-10 15:18:43 --> Helper loaded: form_helper
INFO - 2016-11-10 15:18:43 --> Database Driver Class Initialized
INFO - 2016-11-10 15:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:18:43 --> Controller Class Initialized
INFO - 2016-11-10 15:18:43 --> Model Class Initialized
INFO - 2016-11-10 15:18:43 --> Model Class Initialized
INFO - 2016-11-10 15:18:43 --> Model Class Initialized
INFO - 2016-11-10 15:18:43 --> Model Class Initialized
INFO - 2016-11-10 15:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 15:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 15:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 15:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 15:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 15:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 15:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 15:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 15:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 15:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 15:18:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 15:18:43 --> Final output sent to browser
DEBUG - 2016-11-10 15:18:43 --> Total execution time: 0.4501
INFO - 2016-11-10 15:19:51 --> Config Class Initialized
INFO - 2016-11-10 15:19:51 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:19:51 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:19:51 --> Utf8 Class Initialized
INFO - 2016-11-10 15:19:51 --> URI Class Initialized
DEBUG - 2016-11-10 15:19:51 --> No URI present. Default controller set.
INFO - 2016-11-10 15:19:51 --> Router Class Initialized
INFO - 2016-11-10 15:19:51 --> Output Class Initialized
INFO - 2016-11-10 15:19:51 --> Security Class Initialized
DEBUG - 2016-11-10 15:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:19:51 --> Input Class Initialized
INFO - 2016-11-10 15:19:51 --> Language Class Initialized
INFO - 2016-11-10 15:19:51 --> Loader Class Initialized
INFO - 2016-11-10 15:19:51 --> Helper loaded: url_helper
INFO - 2016-11-10 15:19:51 --> Helper loaded: form_helper
INFO - 2016-11-10 15:19:51 --> Database Driver Class Initialized
INFO - 2016-11-10 15:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:19:51 --> Controller Class Initialized
INFO - 2016-11-10 15:19:51 --> Model Class Initialized
INFO - 2016-11-10 15:19:51 --> Model Class Initialized
INFO - 2016-11-10 15:19:51 --> Model Class Initialized
INFO - 2016-11-10 15:19:51 --> Model Class Initialized
INFO - 2016-11-10 15:19:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:19:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 15:19:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 15:19:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 15:19:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 15:19:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 15:19:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 15:19:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 15:19:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 15:19:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 15:19:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 15:19:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 15:19:51 --> Final output sent to browser
DEBUG - 2016-11-10 15:19:51 --> Total execution time: 0.4534
INFO - 2016-11-10 15:20:02 --> Config Class Initialized
INFO - 2016-11-10 15:20:02 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:20:02 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:20:02 --> Utf8 Class Initialized
INFO - 2016-11-10 15:20:02 --> URI Class Initialized
INFO - 2016-11-10 15:20:02 --> Router Class Initialized
INFO - 2016-11-10 15:20:02 --> Output Class Initialized
INFO - 2016-11-10 15:20:02 --> Security Class Initialized
DEBUG - 2016-11-10 15:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:20:02 --> Input Class Initialized
INFO - 2016-11-10 15:20:02 --> Language Class Initialized
INFO - 2016-11-10 15:20:02 --> Loader Class Initialized
INFO - 2016-11-10 15:20:02 --> Helper loaded: url_helper
INFO - 2016-11-10 15:20:02 --> Helper loaded: form_helper
INFO - 2016-11-10 15:20:02 --> Database Driver Class Initialized
INFO - 2016-11-10 15:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:20:02 --> Controller Class Initialized
INFO - 2016-11-10 15:20:02 --> Model Class Initialized
INFO - 2016-11-10 15:20:02 --> Model Class Initialized
INFO - 2016-11-10 15:20:02 --> Model Class Initialized
INFO - 2016-11-10 15:20:02 --> Model Class Initialized
DEBUG - 2016-11-10 15:20:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 15:20:02 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 133
ERROR - 2016-11-10 15:20:02 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 133
INFO - 2016-11-10 15:20:02 --> Config Class Initialized
INFO - 2016-11-10 15:20:02 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:20:02 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:20:02 --> Utf8 Class Initialized
INFO - 2016-11-10 15:20:03 --> URI Class Initialized
DEBUG - 2016-11-10 15:20:03 --> No URI present. Default controller set.
INFO - 2016-11-10 15:20:03 --> Router Class Initialized
INFO - 2016-11-10 15:20:03 --> Output Class Initialized
INFO - 2016-11-10 15:20:03 --> Security Class Initialized
DEBUG - 2016-11-10 15:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:20:03 --> Input Class Initialized
INFO - 2016-11-10 15:20:03 --> Language Class Initialized
INFO - 2016-11-10 15:20:03 --> Loader Class Initialized
INFO - 2016-11-10 15:20:03 --> Helper loaded: url_helper
INFO - 2016-11-10 15:20:03 --> Helper loaded: form_helper
INFO - 2016-11-10 15:20:03 --> Database Driver Class Initialized
INFO - 2016-11-10 15:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:20:03 --> Controller Class Initialized
INFO - 2016-11-10 15:20:03 --> Model Class Initialized
INFO - 2016-11-10 15:20:03 --> Model Class Initialized
INFO - 2016-11-10 15:20:03 --> Model Class Initialized
INFO - 2016-11-10 15:20:03 --> Model Class Initialized
INFO - 2016-11-10 15:20:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:20:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 15:20:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 15:20:03 --> Final output sent to browser
DEBUG - 2016-11-10 15:20:03 --> Total execution time: 0.3354
INFO - 2016-11-10 15:20:43 --> Config Class Initialized
INFO - 2016-11-10 15:20:43 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:20:43 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:20:43 --> Utf8 Class Initialized
INFO - 2016-11-10 15:20:43 --> URI Class Initialized
INFO - 2016-11-10 15:20:43 --> Router Class Initialized
INFO - 2016-11-10 15:20:43 --> Output Class Initialized
INFO - 2016-11-10 15:20:43 --> Security Class Initialized
DEBUG - 2016-11-10 15:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:20:43 --> Input Class Initialized
INFO - 2016-11-10 15:20:43 --> Language Class Initialized
INFO - 2016-11-10 15:20:43 --> Loader Class Initialized
INFO - 2016-11-10 15:20:43 --> Helper loaded: url_helper
INFO - 2016-11-10 15:20:43 --> Helper loaded: form_helper
INFO - 2016-11-10 15:20:43 --> Database Driver Class Initialized
INFO - 2016-11-10 15:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:20:43 --> Controller Class Initialized
INFO - 2016-11-10 15:20:43 --> Model Class Initialized
INFO - 2016-11-10 15:20:43 --> Model Class Initialized
INFO - 2016-11-10 15:20:43 --> Model Class Initialized
INFO - 2016-11-10 15:20:43 --> Model Class Initialized
DEBUG - 2016-11-10 15:20:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 15:20:43 --> Model Class Initialized
INFO - 2016-11-10 15:20:43 --> Final output sent to browser
DEBUG - 2016-11-10 15:20:43 --> Total execution time: 0.2901
INFO - 2016-11-10 15:20:43 --> Config Class Initialized
INFO - 2016-11-10 15:20:43 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:20:43 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:20:43 --> Utf8 Class Initialized
INFO - 2016-11-10 15:20:43 --> URI Class Initialized
DEBUG - 2016-11-10 15:20:43 --> No URI present. Default controller set.
INFO - 2016-11-10 15:20:43 --> Router Class Initialized
INFO - 2016-11-10 15:20:43 --> Output Class Initialized
INFO - 2016-11-10 15:20:43 --> Security Class Initialized
DEBUG - 2016-11-10 15:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:20:43 --> Input Class Initialized
INFO - 2016-11-10 15:20:43 --> Language Class Initialized
INFO - 2016-11-10 15:20:43 --> Loader Class Initialized
INFO - 2016-11-10 15:20:43 --> Helper loaded: url_helper
INFO - 2016-11-10 15:20:43 --> Helper loaded: form_helper
INFO - 2016-11-10 15:20:43 --> Database Driver Class Initialized
INFO - 2016-11-10 15:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:20:43 --> Controller Class Initialized
INFO - 2016-11-10 15:20:43 --> Model Class Initialized
INFO - 2016-11-10 15:20:43 --> Model Class Initialized
INFO - 2016-11-10 15:20:43 --> Model Class Initialized
INFO - 2016-11-10 15:20:43 --> Model Class Initialized
INFO - 2016-11-10 15:20:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:20:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 15:20:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 15:20:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 15:20:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 15:20:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 15:20:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 15:20:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 15:20:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 15:20:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 15:20:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 15:20:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 15:20:44 --> Final output sent to browser
DEBUG - 2016-11-10 15:20:44 --> Total execution time: 0.4541
INFO - 2016-11-10 15:23:08 --> Config Class Initialized
INFO - 2016-11-10 15:23:08 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:23:08 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:23:08 --> Utf8 Class Initialized
INFO - 2016-11-10 15:23:08 --> URI Class Initialized
DEBUG - 2016-11-10 15:23:08 --> No URI present. Default controller set.
INFO - 2016-11-10 15:23:08 --> Router Class Initialized
INFO - 2016-11-10 15:23:08 --> Output Class Initialized
INFO - 2016-11-10 15:23:08 --> Security Class Initialized
DEBUG - 2016-11-10 15:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:23:08 --> Input Class Initialized
INFO - 2016-11-10 15:23:08 --> Language Class Initialized
INFO - 2016-11-10 15:23:08 --> Loader Class Initialized
INFO - 2016-11-10 15:23:08 --> Helper loaded: url_helper
INFO - 2016-11-10 15:23:08 --> Helper loaded: form_helper
INFO - 2016-11-10 15:23:08 --> Database Driver Class Initialized
INFO - 2016-11-10 15:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:23:08 --> Controller Class Initialized
INFO - 2016-11-10 15:23:08 --> Model Class Initialized
INFO - 2016-11-10 15:23:08 --> Model Class Initialized
INFO - 2016-11-10 15:23:08 --> Model Class Initialized
INFO - 2016-11-10 15:23:08 --> Model Class Initialized
INFO - 2016-11-10 15:23:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:23:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 15:23:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 15:23:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 15:23:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 15:23:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 15:23:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 15:23:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 15:23:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 15:23:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 15:23:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 15:23:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 15:23:08 --> Final output sent to browser
DEBUG - 2016-11-10 15:23:08 --> Total execution time: 0.4517
INFO - 2016-11-10 15:25:46 --> Config Class Initialized
INFO - 2016-11-10 15:25:46 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:25:46 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:25:46 --> Utf8 Class Initialized
INFO - 2016-11-10 15:25:46 --> URI Class Initialized
DEBUG - 2016-11-10 15:25:46 --> No URI present. Default controller set.
INFO - 2016-11-10 15:25:46 --> Router Class Initialized
INFO - 2016-11-10 15:25:46 --> Output Class Initialized
INFO - 2016-11-10 15:25:46 --> Security Class Initialized
DEBUG - 2016-11-10 15:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:25:46 --> Input Class Initialized
INFO - 2016-11-10 15:25:46 --> Language Class Initialized
INFO - 2016-11-10 15:25:46 --> Loader Class Initialized
INFO - 2016-11-10 15:25:46 --> Helper loaded: url_helper
INFO - 2016-11-10 15:25:46 --> Helper loaded: form_helper
INFO - 2016-11-10 15:25:46 --> Database Driver Class Initialized
INFO - 2016-11-10 15:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:25:46 --> Controller Class Initialized
INFO - 2016-11-10 15:25:46 --> Model Class Initialized
INFO - 2016-11-10 15:25:46 --> Model Class Initialized
INFO - 2016-11-10 15:25:46 --> Model Class Initialized
INFO - 2016-11-10 15:25:46 --> Model Class Initialized
INFO - 2016-11-10 15:25:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:25:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 15:25:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 15:25:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 15:25:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 15:25:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 15:25:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 15:25:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 15:25:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 15:25:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 15:25:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 15:25:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 15:25:46 --> Final output sent to browser
DEBUG - 2016-11-10 15:25:46 --> Total execution time: 0.5117
INFO - 2016-11-10 15:30:03 --> Config Class Initialized
INFO - 2016-11-10 15:30:03 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:30:03 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:30:03 --> Utf8 Class Initialized
INFO - 2016-11-10 15:30:03 --> URI Class Initialized
DEBUG - 2016-11-10 15:30:03 --> No URI present. Default controller set.
INFO - 2016-11-10 15:30:03 --> Router Class Initialized
INFO - 2016-11-10 15:30:03 --> Output Class Initialized
INFO - 2016-11-10 15:30:03 --> Security Class Initialized
DEBUG - 2016-11-10 15:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:30:03 --> Input Class Initialized
INFO - 2016-11-10 15:30:03 --> Language Class Initialized
INFO - 2016-11-10 15:30:03 --> Loader Class Initialized
INFO - 2016-11-10 15:30:03 --> Helper loaded: url_helper
INFO - 2016-11-10 15:30:04 --> Helper loaded: form_helper
INFO - 2016-11-10 15:30:04 --> Database Driver Class Initialized
INFO - 2016-11-10 15:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:30:04 --> Controller Class Initialized
INFO - 2016-11-10 15:30:04 --> Model Class Initialized
INFO - 2016-11-10 15:30:04 --> Model Class Initialized
INFO - 2016-11-10 15:30:04 --> Model Class Initialized
INFO - 2016-11-10 15:30:04 --> Model Class Initialized
INFO - 2016-11-10 15:30:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:30:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 15:30:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 15:30:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 15:30:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 15:30:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 15:30:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 15:30:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 15:30:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 15:30:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 15:30:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 15:30:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 15:30:04 --> Final output sent to browser
DEBUG - 2016-11-10 15:30:04 --> Total execution time: 0.5057
INFO - 2016-11-10 15:31:45 --> Config Class Initialized
INFO - 2016-11-10 15:31:45 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:31:45 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:31:45 --> Utf8 Class Initialized
INFO - 2016-11-10 15:31:45 --> URI Class Initialized
DEBUG - 2016-11-10 15:31:45 --> No URI present. Default controller set.
INFO - 2016-11-10 15:31:45 --> Router Class Initialized
INFO - 2016-11-10 15:31:45 --> Output Class Initialized
INFO - 2016-11-10 15:31:45 --> Security Class Initialized
DEBUG - 2016-11-10 15:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:31:45 --> Input Class Initialized
INFO - 2016-11-10 15:31:45 --> Language Class Initialized
INFO - 2016-11-10 15:31:45 --> Loader Class Initialized
INFO - 2016-11-10 15:31:45 --> Helper loaded: url_helper
INFO - 2016-11-10 15:31:45 --> Helper loaded: form_helper
INFO - 2016-11-10 15:31:45 --> Database Driver Class Initialized
INFO - 2016-11-10 15:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:31:45 --> Controller Class Initialized
INFO - 2016-11-10 15:31:45 --> Model Class Initialized
INFO - 2016-11-10 15:31:45 --> Model Class Initialized
INFO - 2016-11-10 15:31:45 --> Model Class Initialized
INFO - 2016-11-10 15:31:45 --> Model Class Initialized
INFO - 2016-11-10 15:31:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:31:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 15:31:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 15:31:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 15:31:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 15:31:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 15:31:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 15:31:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 15:31:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 15:31:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 15:31:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 15:31:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 15:31:45 --> Final output sent to browser
DEBUG - 2016-11-10 15:31:45 --> Total execution time: 0.4853
INFO - 2016-11-10 15:36:05 --> Config Class Initialized
INFO - 2016-11-10 15:36:05 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:36:05 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:36:05 --> Utf8 Class Initialized
INFO - 2016-11-10 15:36:05 --> URI Class Initialized
DEBUG - 2016-11-10 15:36:05 --> No URI present. Default controller set.
INFO - 2016-11-10 15:36:05 --> Router Class Initialized
INFO - 2016-11-10 15:36:05 --> Output Class Initialized
INFO - 2016-11-10 15:36:05 --> Security Class Initialized
DEBUG - 2016-11-10 15:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:36:05 --> Input Class Initialized
INFO - 2016-11-10 15:36:05 --> Language Class Initialized
INFO - 2016-11-10 15:36:05 --> Loader Class Initialized
INFO - 2016-11-10 15:36:05 --> Helper loaded: url_helper
INFO - 2016-11-10 15:36:05 --> Helper loaded: form_helper
INFO - 2016-11-10 15:36:05 --> Database Driver Class Initialized
INFO - 2016-11-10 15:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:36:05 --> Controller Class Initialized
INFO - 2016-11-10 15:36:05 --> Model Class Initialized
INFO - 2016-11-10 15:36:05 --> Model Class Initialized
INFO - 2016-11-10 15:36:05 --> Model Class Initialized
INFO - 2016-11-10 15:36:05 --> Model Class Initialized
INFO - 2016-11-10 15:36:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:36:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 15:36:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 15:36:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 15:36:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 15:36:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 15:36:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 15:36:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 15:36:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 15:36:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 15:36:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 15:36:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 15:36:05 --> Final output sent to browser
DEBUG - 2016-11-10 15:36:05 --> Total execution time: 0.4815
INFO - 2016-11-10 15:36:42 --> Config Class Initialized
INFO - 2016-11-10 15:36:42 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:36:42 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:36:42 --> Utf8 Class Initialized
INFO - 2016-11-10 15:36:42 --> URI Class Initialized
DEBUG - 2016-11-10 15:36:42 --> No URI present. Default controller set.
INFO - 2016-11-10 15:36:42 --> Router Class Initialized
INFO - 2016-11-10 15:36:42 --> Output Class Initialized
INFO - 2016-11-10 15:36:42 --> Security Class Initialized
DEBUG - 2016-11-10 15:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:36:43 --> Input Class Initialized
INFO - 2016-11-10 15:36:43 --> Language Class Initialized
INFO - 2016-11-10 15:36:43 --> Loader Class Initialized
INFO - 2016-11-10 15:36:43 --> Helper loaded: url_helper
INFO - 2016-11-10 15:36:43 --> Helper loaded: form_helper
INFO - 2016-11-10 15:36:43 --> Database Driver Class Initialized
INFO - 2016-11-10 15:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:36:43 --> Controller Class Initialized
INFO - 2016-11-10 15:36:43 --> Model Class Initialized
INFO - 2016-11-10 15:36:43 --> Model Class Initialized
INFO - 2016-11-10 15:36:43 --> Model Class Initialized
INFO - 2016-11-10 15:36:43 --> Model Class Initialized
INFO - 2016-11-10 15:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 15:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 15:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 15:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 15:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 15:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 15:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 15:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 15:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 15:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 15:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 15:36:43 --> Final output sent to browser
DEBUG - 2016-11-10 15:36:43 --> Total execution time: 0.4903
INFO - 2016-11-10 15:37:24 --> Config Class Initialized
INFO - 2016-11-10 15:37:24 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:37:24 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:37:24 --> Utf8 Class Initialized
INFO - 2016-11-10 15:37:24 --> URI Class Initialized
DEBUG - 2016-11-10 15:37:24 --> No URI present. Default controller set.
INFO - 2016-11-10 15:37:24 --> Router Class Initialized
INFO - 2016-11-10 15:37:24 --> Output Class Initialized
INFO - 2016-11-10 15:37:24 --> Security Class Initialized
DEBUG - 2016-11-10 15:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:37:24 --> Input Class Initialized
INFO - 2016-11-10 15:37:24 --> Language Class Initialized
INFO - 2016-11-10 15:37:24 --> Loader Class Initialized
INFO - 2016-11-10 15:37:24 --> Helper loaded: url_helper
INFO - 2016-11-10 15:37:24 --> Helper loaded: form_helper
INFO - 2016-11-10 15:37:24 --> Database Driver Class Initialized
INFO - 2016-11-10 15:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:37:24 --> Controller Class Initialized
INFO - 2016-11-10 15:37:24 --> Model Class Initialized
INFO - 2016-11-10 15:37:24 --> Model Class Initialized
INFO - 2016-11-10 15:37:24 --> Model Class Initialized
INFO - 2016-11-10 15:37:24 --> Model Class Initialized
INFO - 2016-11-10 15:37:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:37:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 15:37:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 15:37:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 15:37:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 15:37:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 15:37:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 15:37:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 15:37:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 15:37:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 15:37:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 15:37:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 15:37:24 --> Final output sent to browser
DEBUG - 2016-11-10 15:37:24 --> Total execution time: 0.4936
INFO - 2016-11-10 15:37:54 --> Config Class Initialized
INFO - 2016-11-10 15:37:54 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:37:54 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:37:54 --> Utf8 Class Initialized
INFO - 2016-11-10 15:37:54 --> URI Class Initialized
INFO - 2016-11-10 15:37:54 --> Router Class Initialized
INFO - 2016-11-10 15:37:54 --> Output Class Initialized
INFO - 2016-11-10 15:37:54 --> Security Class Initialized
DEBUG - 2016-11-10 15:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:37:54 --> Input Class Initialized
INFO - 2016-11-10 15:37:54 --> Language Class Initialized
INFO - 2016-11-10 15:37:55 --> Loader Class Initialized
INFO - 2016-11-10 15:37:55 --> Helper loaded: url_helper
INFO - 2016-11-10 15:37:55 --> Helper loaded: form_helper
INFO - 2016-11-10 15:37:55 --> Database Driver Class Initialized
INFO - 2016-11-10 15:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:37:55 --> Controller Class Initialized
INFO - 2016-11-10 15:37:55 --> Model Class Initialized
INFO - 2016-11-10 15:37:55 --> Form Validation Class Initialized
INFO - 2016-11-10 15:37:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-10 15:37:55 --> Final output sent to browser
DEBUG - 2016-11-10 15:37:55 --> Total execution time: 0.3552
INFO - 2016-11-10 15:37:57 --> Config Class Initialized
INFO - 2016-11-10 15:37:57 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:37:57 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:37:57 --> Utf8 Class Initialized
INFO - 2016-11-10 15:37:57 --> URI Class Initialized
DEBUG - 2016-11-10 15:37:57 --> No URI present. Default controller set.
INFO - 2016-11-10 15:37:57 --> Router Class Initialized
INFO - 2016-11-10 15:37:57 --> Output Class Initialized
INFO - 2016-11-10 15:37:57 --> Security Class Initialized
DEBUG - 2016-11-10 15:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:37:57 --> Input Class Initialized
INFO - 2016-11-10 15:37:57 --> Language Class Initialized
INFO - 2016-11-10 15:37:57 --> Loader Class Initialized
INFO - 2016-11-10 15:37:57 --> Helper loaded: url_helper
INFO - 2016-11-10 15:37:57 --> Helper loaded: form_helper
INFO - 2016-11-10 15:37:57 --> Database Driver Class Initialized
INFO - 2016-11-10 15:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:37:57 --> Controller Class Initialized
INFO - 2016-11-10 15:37:57 --> Model Class Initialized
INFO - 2016-11-10 15:37:57 --> Model Class Initialized
INFO - 2016-11-10 15:37:57 --> Model Class Initialized
INFO - 2016-11-10 15:37:57 --> Model Class Initialized
INFO - 2016-11-10 15:37:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:37:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 15:37:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 15:37:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 15:37:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 15:37:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 15:37:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 15:37:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 15:37:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 15:37:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 15:37:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 15:37:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 15:37:57 --> Final output sent to browser
DEBUG - 2016-11-10 15:37:57 --> Total execution time: 0.4859
INFO - 2016-11-10 15:38:39 --> Config Class Initialized
INFO - 2016-11-10 15:38:39 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:38:39 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:38:39 --> Utf8 Class Initialized
INFO - 2016-11-10 15:38:39 --> URI Class Initialized
DEBUG - 2016-11-10 15:38:39 --> No URI present. Default controller set.
INFO - 2016-11-10 15:38:39 --> Router Class Initialized
INFO - 2016-11-10 15:38:39 --> Output Class Initialized
INFO - 2016-11-10 15:38:39 --> Security Class Initialized
DEBUG - 2016-11-10 15:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:38:39 --> Input Class Initialized
INFO - 2016-11-10 15:38:39 --> Language Class Initialized
INFO - 2016-11-10 15:38:39 --> Loader Class Initialized
INFO - 2016-11-10 15:38:39 --> Helper loaded: url_helper
INFO - 2016-11-10 15:38:39 --> Helper loaded: form_helper
INFO - 2016-11-10 15:38:39 --> Database Driver Class Initialized
INFO - 2016-11-10 15:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:38:39 --> Controller Class Initialized
INFO - 2016-11-10 15:38:39 --> Model Class Initialized
INFO - 2016-11-10 15:38:39 --> Model Class Initialized
INFO - 2016-11-10 15:38:39 --> Model Class Initialized
INFO - 2016-11-10 15:38:39 --> Model Class Initialized
INFO - 2016-11-10 15:38:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:38:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 15:38:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 15:38:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 15:38:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 15:38:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 15:38:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 15:38:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 15:38:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 15:38:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 15:38:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 15:38:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 15:38:39 --> Final output sent to browser
DEBUG - 2016-11-10 15:38:39 --> Total execution time: 0.4983
INFO - 2016-11-10 15:43:02 --> Config Class Initialized
INFO - 2016-11-10 15:43:02 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:43:02 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:43:02 --> Utf8 Class Initialized
INFO - 2016-11-10 15:43:02 --> URI Class Initialized
DEBUG - 2016-11-10 15:43:02 --> No URI present. Default controller set.
INFO - 2016-11-10 15:43:02 --> Router Class Initialized
INFO - 2016-11-10 15:43:02 --> Output Class Initialized
INFO - 2016-11-10 15:43:02 --> Security Class Initialized
DEBUG - 2016-11-10 15:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:43:02 --> Input Class Initialized
INFO - 2016-11-10 15:43:02 --> Language Class Initialized
INFO - 2016-11-10 15:43:02 --> Loader Class Initialized
INFO - 2016-11-10 15:43:02 --> Helper loaded: url_helper
INFO - 2016-11-10 15:43:02 --> Helper loaded: form_helper
INFO - 2016-11-10 15:43:02 --> Database Driver Class Initialized
INFO - 2016-11-10 15:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:43:02 --> Controller Class Initialized
INFO - 2016-11-10 15:43:02 --> Model Class Initialized
INFO - 2016-11-10 15:43:02 --> Model Class Initialized
INFO - 2016-11-10 15:43:02 --> Model Class Initialized
INFO - 2016-11-10 15:43:02 --> Model Class Initialized
INFO - 2016-11-10 15:43:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:43:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 15:43:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 15:43:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 15:43:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 15:43:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 15:43:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 15:43:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 15:43:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 15:43:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 15:43:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 15:43:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 15:43:03 --> Final output sent to browser
DEBUG - 2016-11-10 15:43:03 --> Total execution time: 0.4813
INFO - 2016-11-10 15:43:37 --> Config Class Initialized
INFO - 2016-11-10 15:43:37 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:43:37 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:43:37 --> Utf8 Class Initialized
INFO - 2016-11-10 15:43:37 --> URI Class Initialized
INFO - 2016-11-10 15:43:37 --> Router Class Initialized
INFO - 2016-11-10 15:43:37 --> Output Class Initialized
INFO - 2016-11-10 15:43:37 --> Security Class Initialized
DEBUG - 2016-11-10 15:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:43:37 --> Input Class Initialized
INFO - 2016-11-10 15:43:37 --> Language Class Initialized
INFO - 2016-11-10 15:43:38 --> Loader Class Initialized
INFO - 2016-11-10 15:43:38 --> Helper loaded: url_helper
INFO - 2016-11-10 15:43:38 --> Helper loaded: form_helper
INFO - 2016-11-10 15:43:38 --> Database Driver Class Initialized
INFO - 2016-11-10 15:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:43:38 --> Controller Class Initialized
INFO - 2016-11-10 15:43:38 --> Model Class Initialized
INFO - 2016-11-10 15:43:38 --> Model Class Initialized
INFO - 2016-11-10 15:43:38 --> Model Class Initialized
INFO - 2016-11-10 15:43:38 --> Model Class Initialized
DEBUG - 2016-11-10 15:43:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 15:43:38 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 134
ERROR - 2016-11-10 15:43:38 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 134
INFO - 2016-11-10 15:43:38 --> Config Class Initialized
INFO - 2016-11-10 15:43:38 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:43:38 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:43:38 --> Utf8 Class Initialized
INFO - 2016-11-10 15:43:38 --> URI Class Initialized
DEBUG - 2016-11-10 15:43:38 --> No URI present. Default controller set.
INFO - 2016-11-10 15:43:38 --> Router Class Initialized
INFO - 2016-11-10 15:43:38 --> Output Class Initialized
INFO - 2016-11-10 15:43:38 --> Security Class Initialized
DEBUG - 2016-11-10 15:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:43:38 --> Input Class Initialized
INFO - 2016-11-10 15:43:38 --> Language Class Initialized
INFO - 2016-11-10 15:43:38 --> Loader Class Initialized
INFO - 2016-11-10 15:43:38 --> Helper loaded: url_helper
INFO - 2016-11-10 15:43:38 --> Helper loaded: form_helper
INFO - 2016-11-10 15:43:38 --> Database Driver Class Initialized
INFO - 2016-11-10 15:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:43:38 --> Controller Class Initialized
INFO - 2016-11-10 15:43:38 --> Model Class Initialized
INFO - 2016-11-10 15:43:38 --> Model Class Initialized
INFO - 2016-11-10 15:43:38 --> Model Class Initialized
INFO - 2016-11-10 15:43:38 --> Model Class Initialized
INFO - 2016-11-10 15:43:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:43:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 15:43:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 15:43:38 --> Final output sent to browser
DEBUG - 2016-11-10 15:43:38 --> Total execution time: 0.3497
INFO - 2016-11-10 15:43:52 --> Config Class Initialized
INFO - 2016-11-10 15:43:52 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:43:52 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:43:52 --> Utf8 Class Initialized
INFO - 2016-11-10 15:43:52 --> URI Class Initialized
INFO - 2016-11-10 15:43:52 --> Router Class Initialized
INFO - 2016-11-10 15:43:52 --> Output Class Initialized
INFO - 2016-11-10 15:43:52 --> Security Class Initialized
DEBUG - 2016-11-10 15:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:43:52 --> Input Class Initialized
INFO - 2016-11-10 15:43:52 --> Language Class Initialized
INFO - 2016-11-10 15:43:52 --> Loader Class Initialized
INFO - 2016-11-10 15:43:52 --> Helper loaded: url_helper
INFO - 2016-11-10 15:43:52 --> Helper loaded: form_helper
INFO - 2016-11-10 15:43:52 --> Database Driver Class Initialized
INFO - 2016-11-10 15:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:43:52 --> Controller Class Initialized
INFO - 2016-11-10 15:43:52 --> Model Class Initialized
INFO - 2016-11-10 15:43:52 --> Model Class Initialized
INFO - 2016-11-10 15:43:52 --> Model Class Initialized
INFO - 2016-11-10 15:43:52 --> Model Class Initialized
DEBUG - 2016-11-10 15:43:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 15:43:52 --> Model Class Initialized
INFO - 2016-11-10 15:43:52 --> Final output sent to browser
DEBUG - 2016-11-10 15:43:52 --> Total execution time: 0.4092
INFO - 2016-11-10 15:43:52 --> Config Class Initialized
INFO - 2016-11-10 15:43:52 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:43:53 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:43:53 --> Utf8 Class Initialized
INFO - 2016-11-10 15:43:53 --> URI Class Initialized
DEBUG - 2016-11-10 15:43:53 --> No URI present. Default controller set.
INFO - 2016-11-10 15:43:53 --> Router Class Initialized
INFO - 2016-11-10 15:43:53 --> Output Class Initialized
INFO - 2016-11-10 15:43:53 --> Security Class Initialized
DEBUG - 2016-11-10 15:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:43:53 --> Input Class Initialized
INFO - 2016-11-10 15:43:53 --> Language Class Initialized
INFO - 2016-11-10 15:43:53 --> Loader Class Initialized
INFO - 2016-11-10 15:43:53 --> Helper loaded: url_helper
INFO - 2016-11-10 15:43:53 --> Helper loaded: form_helper
INFO - 2016-11-10 15:43:53 --> Database Driver Class Initialized
INFO - 2016-11-10 15:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:43:53 --> Controller Class Initialized
INFO - 2016-11-10 15:43:53 --> Model Class Initialized
INFO - 2016-11-10 15:43:53 --> Model Class Initialized
INFO - 2016-11-10 15:43:53 --> Model Class Initialized
INFO - 2016-11-10 15:43:53 --> Model Class Initialized
INFO - 2016-11-10 15:43:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:43:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 15:43:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 15:43:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 15:43:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 15:43:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 15:43:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 15:43:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 15:43:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 15:43:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 15:43:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 15:43:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 15:43:53 --> Final output sent to browser
DEBUG - 2016-11-10 15:43:53 --> Total execution time: 0.4929
INFO - 2016-11-10 15:45:02 --> Config Class Initialized
INFO - 2016-11-10 15:45:02 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:45:02 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:45:02 --> Utf8 Class Initialized
INFO - 2016-11-10 15:45:02 --> URI Class Initialized
DEBUG - 2016-11-10 15:45:02 --> No URI present. Default controller set.
INFO - 2016-11-10 15:45:02 --> Router Class Initialized
INFO - 2016-11-10 15:45:02 --> Output Class Initialized
INFO - 2016-11-10 15:45:02 --> Security Class Initialized
DEBUG - 2016-11-10 15:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:45:02 --> Input Class Initialized
INFO - 2016-11-10 15:45:02 --> Language Class Initialized
INFO - 2016-11-10 15:45:02 --> Loader Class Initialized
INFO - 2016-11-10 15:45:02 --> Helper loaded: url_helper
INFO - 2016-11-10 15:45:02 --> Helper loaded: form_helper
INFO - 2016-11-10 15:45:02 --> Database Driver Class Initialized
INFO - 2016-11-10 15:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:45:02 --> Controller Class Initialized
INFO - 2016-11-10 15:45:02 --> Model Class Initialized
INFO - 2016-11-10 15:45:02 --> Model Class Initialized
INFO - 2016-11-10 15:45:02 --> Model Class Initialized
INFO - 2016-11-10 15:45:02 --> Model Class Initialized
INFO - 2016-11-10 15:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 15:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 15:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 15:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 15:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 15:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 15:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 15:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 15:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 15:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 15:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 15:45:03 --> Final output sent to browser
DEBUG - 2016-11-10 15:45:03 --> Total execution time: 0.5208
INFO - 2016-11-10 15:47:18 --> Config Class Initialized
INFO - 2016-11-10 15:47:18 --> Hooks Class Initialized
DEBUG - 2016-11-10 15:47:18 --> UTF-8 Support Enabled
INFO - 2016-11-10 15:47:18 --> Utf8 Class Initialized
INFO - 2016-11-10 15:47:18 --> URI Class Initialized
DEBUG - 2016-11-10 15:47:18 --> No URI present. Default controller set.
INFO - 2016-11-10 15:47:18 --> Router Class Initialized
INFO - 2016-11-10 15:47:18 --> Output Class Initialized
INFO - 2016-11-10 15:47:18 --> Security Class Initialized
DEBUG - 2016-11-10 15:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 15:47:18 --> Input Class Initialized
INFO - 2016-11-10 15:47:18 --> Language Class Initialized
INFO - 2016-11-10 15:47:18 --> Loader Class Initialized
INFO - 2016-11-10 15:47:18 --> Helper loaded: url_helper
INFO - 2016-11-10 15:47:18 --> Helper loaded: form_helper
INFO - 2016-11-10 15:47:18 --> Database Driver Class Initialized
INFO - 2016-11-10 15:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 15:47:18 --> Controller Class Initialized
INFO - 2016-11-10 15:47:18 --> Model Class Initialized
INFO - 2016-11-10 15:47:19 --> Model Class Initialized
INFO - 2016-11-10 15:47:19 --> Model Class Initialized
INFO - 2016-11-10 15:47:19 --> Model Class Initialized
INFO - 2016-11-10 15:47:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 15:47:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 15:47:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 15:47:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 15:47:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 15:47:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 15:47:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 15:47:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 15:47:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 15:47:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 15:47:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 15:47:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 15:47:19 --> Final output sent to browser
DEBUG - 2016-11-10 15:47:19 --> Total execution time: 0.4814
INFO - 2016-11-10 16:05:48 --> Config Class Initialized
INFO - 2016-11-10 16:05:48 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:05:48 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:05:48 --> Utf8 Class Initialized
INFO - 2016-11-10 16:05:48 --> URI Class Initialized
DEBUG - 2016-11-10 16:05:48 --> No URI present. Default controller set.
INFO - 2016-11-10 16:05:48 --> Router Class Initialized
INFO - 2016-11-10 16:05:48 --> Output Class Initialized
INFO - 2016-11-10 16:05:48 --> Security Class Initialized
DEBUG - 2016-11-10 16:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:05:48 --> Input Class Initialized
INFO - 2016-11-10 16:05:48 --> Language Class Initialized
INFO - 2016-11-10 16:05:48 --> Loader Class Initialized
INFO - 2016-11-10 16:05:48 --> Helper loaded: url_helper
INFO - 2016-11-10 16:05:48 --> Helper loaded: form_helper
INFO - 2016-11-10 16:05:48 --> Database Driver Class Initialized
INFO - 2016-11-10 16:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:05:48 --> Controller Class Initialized
INFO - 2016-11-10 16:05:48 --> Model Class Initialized
INFO - 2016-11-10 16:05:48 --> Model Class Initialized
INFO - 2016-11-10 16:05:48 --> Model Class Initialized
INFO - 2016-11-10 16:05:48 --> Model Class Initialized
INFO - 2016-11-10 16:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 16:05:48 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\LMS\app\controllers\Auth.php 82
INFO - 2016-11-10 16:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:05:48 --> Final output sent to browser
DEBUG - 2016-11-10 16:05:48 --> Total execution time: 0.5824
INFO - 2016-11-10 16:06:54 --> Config Class Initialized
INFO - 2016-11-10 16:06:54 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:06:54 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:06:54 --> Utf8 Class Initialized
INFO - 2016-11-10 16:06:54 --> URI Class Initialized
DEBUG - 2016-11-10 16:06:54 --> No URI present. Default controller set.
INFO - 2016-11-10 16:06:54 --> Router Class Initialized
INFO - 2016-11-10 16:06:54 --> Output Class Initialized
INFO - 2016-11-10 16:06:54 --> Security Class Initialized
DEBUG - 2016-11-10 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:06:54 --> Input Class Initialized
INFO - 2016-11-10 16:06:54 --> Language Class Initialized
ERROR - 2016-11-10 16:06:54 --> Severity: Parsing Error --> syntax error, unexpected '$subordinate' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Auth.php 41
INFO - 2016-11-10 16:07:42 --> Config Class Initialized
INFO - 2016-11-10 16:07:42 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:07:42 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:07:42 --> Utf8 Class Initialized
INFO - 2016-11-10 16:07:42 --> URI Class Initialized
DEBUG - 2016-11-10 16:07:42 --> No URI present. Default controller set.
INFO - 2016-11-10 16:07:42 --> Router Class Initialized
INFO - 2016-11-10 16:07:42 --> Output Class Initialized
INFO - 2016-11-10 16:07:42 --> Security Class Initialized
DEBUG - 2016-11-10 16:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:07:42 --> Input Class Initialized
INFO - 2016-11-10 16:07:42 --> Language Class Initialized
INFO - 2016-11-10 16:07:42 --> Loader Class Initialized
INFO - 2016-11-10 16:07:42 --> Helper loaded: url_helper
INFO - 2016-11-10 16:07:42 --> Helper loaded: form_helper
INFO - 2016-11-10 16:07:42 --> Database Driver Class Initialized
INFO - 2016-11-10 16:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:07:42 --> Controller Class Initialized
INFO - 2016-11-10 16:07:42 --> Model Class Initialized
INFO - 2016-11-10 16:07:42 --> Model Class Initialized
INFO - 2016-11-10 16:07:42 --> Model Class Initialized
INFO - 2016-11-10 16:07:42 --> Model Class Initialized
INFO - 2016-11-10 16:07:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:07:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:07:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:07:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:07:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:07:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:07:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:07:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:07:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:07:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:07:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:07:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:07:42 --> Final output sent to browser
DEBUG - 2016-11-10 16:07:43 --> Total execution time: 0.4995
INFO - 2016-11-10 16:08:54 --> Config Class Initialized
INFO - 2016-11-10 16:08:54 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:08:54 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:08:54 --> Utf8 Class Initialized
INFO - 2016-11-10 16:08:54 --> URI Class Initialized
DEBUG - 2016-11-10 16:08:54 --> No URI present. Default controller set.
INFO - 2016-11-10 16:08:54 --> Router Class Initialized
INFO - 2016-11-10 16:08:54 --> Output Class Initialized
INFO - 2016-11-10 16:08:54 --> Security Class Initialized
DEBUG - 2016-11-10 16:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:08:54 --> Input Class Initialized
INFO - 2016-11-10 16:08:54 --> Language Class Initialized
INFO - 2016-11-10 16:08:54 --> Loader Class Initialized
INFO - 2016-11-10 16:08:54 --> Helper loaded: url_helper
INFO - 2016-11-10 16:08:54 --> Helper loaded: form_helper
INFO - 2016-11-10 16:08:54 --> Database Driver Class Initialized
INFO - 2016-11-10 16:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:08:54 --> Controller Class Initialized
INFO - 2016-11-10 16:08:54 --> Model Class Initialized
INFO - 2016-11-10 16:08:54 --> Model Class Initialized
INFO - 2016-11-10 16:08:54 --> Model Class Initialized
INFO - 2016-11-10 16:08:55 --> Model Class Initialized
INFO - 2016-11-10 16:08:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:08:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:08:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:08:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:08:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:08:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:08:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:08:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:08:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:08:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:08:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:08:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:08:55 --> Final output sent to browser
DEBUG - 2016-11-10 16:08:55 --> Total execution time: 0.5705
INFO - 2016-11-10 16:09:59 --> Config Class Initialized
INFO - 2016-11-10 16:09:59 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:09:59 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:09:59 --> Utf8 Class Initialized
INFO - 2016-11-10 16:09:59 --> URI Class Initialized
DEBUG - 2016-11-10 16:09:59 --> No URI present. Default controller set.
INFO - 2016-11-10 16:09:59 --> Router Class Initialized
INFO - 2016-11-10 16:09:59 --> Output Class Initialized
INFO - 2016-11-10 16:09:59 --> Security Class Initialized
DEBUG - 2016-11-10 16:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:09:59 --> Input Class Initialized
INFO - 2016-11-10 16:09:59 --> Language Class Initialized
INFO - 2016-11-10 16:09:59 --> Loader Class Initialized
INFO - 2016-11-10 16:09:59 --> Helper loaded: url_helper
INFO - 2016-11-10 16:09:59 --> Helper loaded: form_helper
INFO - 2016-11-10 16:09:59 --> Database Driver Class Initialized
INFO - 2016-11-10 16:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:09:59 --> Controller Class Initialized
INFO - 2016-11-10 16:09:59 --> Model Class Initialized
INFO - 2016-11-10 16:09:59 --> Model Class Initialized
INFO - 2016-11-10 16:09:59 --> Model Class Initialized
INFO - 2016-11-10 16:09:59 --> Model Class Initialized
INFO - 2016-11-10 16:09:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:09:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:09:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:09:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:09:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:09:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:09:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:09:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:09:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:09:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:09:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:09:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:09:59 --> Final output sent to browser
DEBUG - 2016-11-10 16:09:59 --> Total execution time: 0.5037
INFO - 2016-11-10 16:10:04 --> Config Class Initialized
INFO - 2016-11-10 16:10:04 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:10:04 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:10:04 --> Utf8 Class Initialized
INFO - 2016-11-10 16:10:04 --> URI Class Initialized
INFO - 2016-11-10 16:10:04 --> Router Class Initialized
INFO - 2016-11-10 16:10:04 --> Output Class Initialized
INFO - 2016-11-10 16:10:04 --> Security Class Initialized
DEBUG - 2016-11-10 16:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:10:04 --> Input Class Initialized
INFO - 2016-11-10 16:10:04 --> Language Class Initialized
INFO - 2016-11-10 16:10:04 --> Loader Class Initialized
INFO - 2016-11-10 16:10:04 --> Helper loaded: url_helper
INFO - 2016-11-10 16:10:04 --> Helper loaded: form_helper
INFO - 2016-11-10 16:10:04 --> Database Driver Class Initialized
INFO - 2016-11-10 16:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:10:04 --> Controller Class Initialized
INFO - 2016-11-10 16:10:04 --> Model Class Initialized
INFO - 2016-11-10 16:10:04 --> Model Class Initialized
INFO - 2016-11-10 16:10:05 --> Model Class Initialized
INFO - 2016-11-10 16:10:05 --> Model Class Initialized
DEBUG - 2016-11-10 16:10:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 16:10:05 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
ERROR - 2016-11-10 16:10:05 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
INFO - 2016-11-10 16:10:05 --> Config Class Initialized
INFO - 2016-11-10 16:10:05 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:10:05 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:10:05 --> Utf8 Class Initialized
INFO - 2016-11-10 16:10:05 --> URI Class Initialized
DEBUG - 2016-11-10 16:10:05 --> No URI present. Default controller set.
INFO - 2016-11-10 16:10:05 --> Router Class Initialized
INFO - 2016-11-10 16:10:05 --> Output Class Initialized
INFO - 2016-11-10 16:10:05 --> Security Class Initialized
DEBUG - 2016-11-10 16:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:10:05 --> Input Class Initialized
INFO - 2016-11-10 16:10:05 --> Language Class Initialized
INFO - 2016-11-10 16:10:05 --> Loader Class Initialized
INFO - 2016-11-10 16:10:05 --> Helper loaded: url_helper
INFO - 2016-11-10 16:10:05 --> Helper loaded: form_helper
INFO - 2016-11-10 16:10:05 --> Database Driver Class Initialized
INFO - 2016-11-10 16:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:10:05 --> Controller Class Initialized
INFO - 2016-11-10 16:10:05 --> Model Class Initialized
INFO - 2016-11-10 16:10:05 --> Model Class Initialized
INFO - 2016-11-10 16:10:05 --> Model Class Initialized
INFO - 2016-11-10 16:10:05 --> Model Class Initialized
INFO - 2016-11-10 16:10:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:10:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 16:10:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:10:05 --> Final output sent to browser
DEBUG - 2016-11-10 16:10:05 --> Total execution time: 0.3579
INFO - 2016-11-10 16:10:15 --> Config Class Initialized
INFO - 2016-11-10 16:10:15 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:10:15 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:10:15 --> Utf8 Class Initialized
INFO - 2016-11-10 16:10:15 --> URI Class Initialized
INFO - 2016-11-10 16:10:15 --> Router Class Initialized
INFO - 2016-11-10 16:10:15 --> Output Class Initialized
INFO - 2016-11-10 16:10:15 --> Security Class Initialized
DEBUG - 2016-11-10 16:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:10:15 --> Input Class Initialized
INFO - 2016-11-10 16:10:15 --> Language Class Initialized
INFO - 2016-11-10 16:10:15 --> Loader Class Initialized
INFO - 2016-11-10 16:10:15 --> Helper loaded: url_helper
INFO - 2016-11-10 16:10:15 --> Helper loaded: form_helper
INFO - 2016-11-10 16:10:15 --> Database Driver Class Initialized
INFO - 2016-11-10 16:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:10:15 --> Controller Class Initialized
INFO - 2016-11-10 16:10:15 --> Model Class Initialized
INFO - 2016-11-10 16:10:15 --> Model Class Initialized
INFO - 2016-11-10 16:10:15 --> Model Class Initialized
INFO - 2016-11-10 16:10:15 --> Model Class Initialized
DEBUG - 2016-11-10 16:10:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 16:10:15 --> Model Class Initialized
INFO - 2016-11-10 16:10:15 --> Final output sent to browser
DEBUG - 2016-11-10 16:10:16 --> Total execution time: 0.3414
INFO - 2016-11-10 16:10:16 --> Config Class Initialized
INFO - 2016-11-10 16:10:16 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:10:16 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:10:16 --> Utf8 Class Initialized
INFO - 2016-11-10 16:10:16 --> URI Class Initialized
DEBUG - 2016-11-10 16:10:16 --> No URI present. Default controller set.
INFO - 2016-11-10 16:10:16 --> Router Class Initialized
INFO - 2016-11-10 16:10:16 --> Output Class Initialized
INFO - 2016-11-10 16:10:16 --> Security Class Initialized
DEBUG - 2016-11-10 16:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:10:16 --> Input Class Initialized
INFO - 2016-11-10 16:10:16 --> Language Class Initialized
INFO - 2016-11-10 16:10:16 --> Loader Class Initialized
INFO - 2016-11-10 16:10:16 --> Helper loaded: url_helper
INFO - 2016-11-10 16:10:16 --> Helper loaded: form_helper
INFO - 2016-11-10 16:10:16 --> Database Driver Class Initialized
INFO - 2016-11-10 16:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:10:16 --> Controller Class Initialized
INFO - 2016-11-10 16:10:16 --> Model Class Initialized
INFO - 2016-11-10 16:10:16 --> Model Class Initialized
INFO - 2016-11-10 16:10:16 --> Model Class Initialized
INFO - 2016-11-10 16:10:16 --> Model Class Initialized
INFO - 2016-11-10 16:10:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:10:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:10:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:10:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:10:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:10:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:10:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:10:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:10:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:10:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:10:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:10:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:10:16 --> Final output sent to browser
DEBUG - 2016-11-10 16:10:16 --> Total execution time: 0.4902
INFO - 2016-11-10 16:11:03 --> Config Class Initialized
INFO - 2016-11-10 16:11:03 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:11:03 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:11:03 --> Utf8 Class Initialized
INFO - 2016-11-10 16:11:03 --> URI Class Initialized
DEBUG - 2016-11-10 16:11:03 --> No URI present. Default controller set.
INFO - 2016-11-10 16:11:03 --> Router Class Initialized
INFO - 2016-11-10 16:11:03 --> Output Class Initialized
INFO - 2016-11-10 16:11:03 --> Security Class Initialized
DEBUG - 2016-11-10 16:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:11:03 --> Input Class Initialized
INFO - 2016-11-10 16:11:03 --> Language Class Initialized
INFO - 2016-11-10 16:11:03 --> Loader Class Initialized
INFO - 2016-11-10 16:11:03 --> Helper loaded: url_helper
INFO - 2016-11-10 16:11:03 --> Helper loaded: form_helper
INFO - 2016-11-10 16:11:03 --> Database Driver Class Initialized
INFO - 2016-11-10 16:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:11:03 --> Controller Class Initialized
INFO - 2016-11-10 16:11:03 --> Model Class Initialized
INFO - 2016-11-10 16:11:03 --> Model Class Initialized
INFO - 2016-11-10 16:11:03 --> Model Class Initialized
INFO - 2016-11-10 16:11:03 --> Model Class Initialized
INFO - 2016-11-10 16:11:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:11:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:11:46 --> Config Class Initialized
INFO - 2016-11-10 16:11:46 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:11:46 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:11:46 --> Utf8 Class Initialized
INFO - 2016-11-10 16:11:46 --> URI Class Initialized
DEBUG - 2016-11-10 16:11:46 --> No URI present. Default controller set.
INFO - 2016-11-10 16:11:46 --> Router Class Initialized
INFO - 2016-11-10 16:11:46 --> Output Class Initialized
INFO - 2016-11-10 16:11:46 --> Security Class Initialized
DEBUG - 2016-11-10 16:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:11:46 --> Input Class Initialized
INFO - 2016-11-10 16:11:46 --> Language Class Initialized
INFO - 2016-11-10 16:11:46 --> Loader Class Initialized
INFO - 2016-11-10 16:11:46 --> Helper loaded: url_helper
INFO - 2016-11-10 16:11:46 --> Helper loaded: form_helper
INFO - 2016-11-10 16:11:46 --> Database Driver Class Initialized
INFO - 2016-11-10 16:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:11:46 --> Controller Class Initialized
INFO - 2016-11-10 16:11:46 --> Model Class Initialized
INFO - 2016-11-10 16:11:46 --> Model Class Initialized
INFO - 2016-11-10 16:11:46 --> Model Class Initialized
INFO - 2016-11-10 16:11:46 --> Model Class Initialized
INFO - 2016-11-10 16:11:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:11:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:11:47 --> Config Class Initialized
INFO - 2016-11-10 16:11:47 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:11:47 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:11:47 --> Utf8 Class Initialized
INFO - 2016-11-10 16:11:47 --> URI Class Initialized
DEBUG - 2016-11-10 16:11:47 --> No URI present. Default controller set.
INFO - 2016-11-10 16:11:47 --> Router Class Initialized
INFO - 2016-11-10 16:11:47 --> Output Class Initialized
INFO - 2016-11-10 16:11:47 --> Security Class Initialized
DEBUG - 2016-11-10 16:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:11:47 --> Input Class Initialized
INFO - 2016-11-10 16:11:47 --> Language Class Initialized
INFO - 2016-11-10 16:11:47 --> Loader Class Initialized
INFO - 2016-11-10 16:11:47 --> Helper loaded: url_helper
INFO - 2016-11-10 16:11:47 --> Helper loaded: form_helper
INFO - 2016-11-10 16:11:47 --> Database Driver Class Initialized
INFO - 2016-11-10 16:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:11:47 --> Controller Class Initialized
INFO - 2016-11-10 16:11:47 --> Model Class Initialized
INFO - 2016-11-10 16:11:47 --> Model Class Initialized
INFO - 2016-11-10 16:11:47 --> Model Class Initialized
INFO - 2016-11-10 16:11:47 --> Model Class Initialized
INFO - 2016-11-10 16:11:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:11:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:11:48 --> Config Class Initialized
INFO - 2016-11-10 16:11:48 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:11:48 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:11:48 --> Utf8 Class Initialized
INFO - 2016-11-10 16:11:48 --> URI Class Initialized
DEBUG - 2016-11-10 16:11:48 --> No URI present. Default controller set.
INFO - 2016-11-10 16:11:48 --> Router Class Initialized
INFO - 2016-11-10 16:11:48 --> Output Class Initialized
INFO - 2016-11-10 16:11:48 --> Security Class Initialized
DEBUG - 2016-11-10 16:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:11:48 --> Input Class Initialized
INFO - 2016-11-10 16:11:48 --> Language Class Initialized
INFO - 2016-11-10 16:11:48 --> Loader Class Initialized
INFO - 2016-11-10 16:11:48 --> Helper loaded: url_helper
INFO - 2016-11-10 16:11:48 --> Helper loaded: form_helper
INFO - 2016-11-10 16:11:48 --> Database Driver Class Initialized
INFO - 2016-11-10 16:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:11:48 --> Controller Class Initialized
INFO - 2016-11-10 16:11:48 --> Model Class Initialized
INFO - 2016-11-10 16:11:48 --> Model Class Initialized
INFO - 2016-11-10 16:11:48 --> Model Class Initialized
INFO - 2016-11-10 16:11:48 --> Model Class Initialized
INFO - 2016-11-10 16:11:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:11:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:11:49 --> Config Class Initialized
INFO - 2016-11-10 16:11:49 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:11:49 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:11:49 --> Utf8 Class Initialized
INFO - 2016-11-10 16:11:49 --> URI Class Initialized
DEBUG - 2016-11-10 16:11:49 --> No URI present. Default controller set.
INFO - 2016-11-10 16:11:49 --> Router Class Initialized
INFO - 2016-11-10 16:11:49 --> Output Class Initialized
INFO - 2016-11-10 16:11:49 --> Security Class Initialized
DEBUG - 2016-11-10 16:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:11:49 --> Input Class Initialized
INFO - 2016-11-10 16:11:49 --> Language Class Initialized
INFO - 2016-11-10 16:11:49 --> Loader Class Initialized
INFO - 2016-11-10 16:11:49 --> Helper loaded: url_helper
INFO - 2016-11-10 16:11:49 --> Helper loaded: form_helper
INFO - 2016-11-10 16:11:49 --> Config Class Initialized
INFO - 2016-11-10 16:11:49 --> Database Driver Class Initialized
INFO - 2016-11-10 16:11:49 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:11:49 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:11:49 --> Utf8 Class Initialized
INFO - 2016-11-10 16:11:49 --> Controller Class Initialized
INFO - 2016-11-10 16:11:49 --> URI Class Initialized
INFO - 2016-11-10 16:11:49 --> Model Class Initialized
DEBUG - 2016-11-10 16:11:49 --> No URI present. Default controller set.
INFO - 2016-11-10 16:11:49 --> Model Class Initialized
INFO - 2016-11-10 16:11:49 --> Router Class Initialized
INFO - 2016-11-10 16:11:49 --> Model Class Initialized
INFO - 2016-11-10 16:11:49 --> Output Class Initialized
INFO - 2016-11-10 16:11:49 --> Model Class Initialized
INFO - 2016-11-10 16:11:49 --> Config Class Initialized
INFO - 2016-11-10 16:11:49 --> Security Class Initialized
INFO - 2016-11-10 16:11:49 --> Hooks Class Initialized
INFO - 2016-11-10 16:11:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
DEBUG - 2016-11-10 16:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-10 16:11:49 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:11:49 --> Utf8 Class Initialized
INFO - 2016-11-10 16:11:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:11:49 --> Input Class Initialized
INFO - 2016-11-10 16:11:49 --> Language Class Initialized
INFO - 2016-11-10 16:11:49 --> URI Class Initialized
INFO - 2016-11-10 16:11:49 --> Loader Class Initialized
DEBUG - 2016-11-10 16:11:49 --> No URI present. Default controller set.
INFO - 2016-11-10 16:11:49 --> Helper loaded: url_helper
INFO - 2016-11-10 16:11:49 --> Router Class Initialized
INFO - 2016-11-10 16:11:49 --> Helper loaded: form_helper
INFO - 2016-11-10 16:11:49 --> Output Class Initialized
INFO - 2016-11-10 16:11:49 --> Database Driver Class Initialized
INFO - 2016-11-10 16:11:49 --> Security Class Initialized
INFO - 2016-11-10 16:11:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-10 16:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:11:49 --> Controller Class Initialized
INFO - 2016-11-10 16:11:49 --> Input Class Initialized
INFO - 2016-11-10 16:11:49 --> Model Class Initialized
INFO - 2016-11-10 16:11:50 --> Language Class Initialized
INFO - 2016-11-10 16:11:50 --> Model Class Initialized
INFO - 2016-11-10 16:11:50 --> Loader Class Initialized
INFO - 2016-11-10 16:11:50 --> Model Class Initialized
INFO - 2016-11-10 16:11:50 --> Helper loaded: url_helper
INFO - 2016-11-10 16:11:50 --> Model Class Initialized
INFO - 2016-11-10 16:11:50 --> Helper loaded: form_helper
INFO - 2016-11-10 16:11:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:11:50 --> Database Driver Class Initialized
INFO - 2016-11-10 16:11:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:11:50 --> Controller Class Initialized
INFO - 2016-11-10 16:11:50 --> Model Class Initialized
INFO - 2016-11-10 16:11:50 --> Model Class Initialized
INFO - 2016-11-10 16:11:50 --> Model Class Initialized
INFO - 2016-11-10 16:11:50 --> Model Class Initialized
INFO - 2016-11-10 16:11:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:11:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:12:04 --> Config Class Initialized
INFO - 2016-11-10 16:12:04 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:12:04 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:12:04 --> Utf8 Class Initialized
INFO - 2016-11-10 16:12:04 --> URI Class Initialized
DEBUG - 2016-11-10 16:12:04 --> No URI present. Default controller set.
INFO - 2016-11-10 16:12:04 --> Router Class Initialized
INFO - 2016-11-10 16:12:04 --> Output Class Initialized
INFO - 2016-11-10 16:12:04 --> Security Class Initialized
DEBUG - 2016-11-10 16:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:12:04 --> Input Class Initialized
INFO - 2016-11-10 16:12:04 --> Language Class Initialized
INFO - 2016-11-10 16:12:04 --> Loader Class Initialized
INFO - 2016-11-10 16:12:04 --> Helper loaded: url_helper
INFO - 2016-11-10 16:12:04 --> Helper loaded: form_helper
INFO - 2016-11-10 16:12:04 --> Database Driver Class Initialized
INFO - 2016-11-10 16:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:12:04 --> Controller Class Initialized
INFO - 2016-11-10 16:12:04 --> Model Class Initialized
INFO - 2016-11-10 16:12:04 --> Model Class Initialized
INFO - 2016-11-10 16:12:04 --> Model Class Initialized
INFO - 2016-11-10 16:12:04 --> Model Class Initialized
INFO - 2016-11-10 16:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:12:04 --> Final output sent to browser
DEBUG - 2016-11-10 16:12:04 --> Total execution time: 0.5427
INFO - 2016-11-10 16:13:02 --> Config Class Initialized
INFO - 2016-11-10 16:13:02 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:13:02 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:13:02 --> Utf8 Class Initialized
INFO - 2016-11-10 16:13:02 --> URI Class Initialized
DEBUG - 2016-11-10 16:13:02 --> No URI present. Default controller set.
INFO - 2016-11-10 16:13:02 --> Router Class Initialized
INFO - 2016-11-10 16:13:02 --> Output Class Initialized
INFO - 2016-11-10 16:13:02 --> Security Class Initialized
DEBUG - 2016-11-10 16:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:13:03 --> Input Class Initialized
INFO - 2016-11-10 16:13:03 --> Language Class Initialized
INFO - 2016-11-10 16:13:03 --> Loader Class Initialized
INFO - 2016-11-10 16:13:03 --> Helper loaded: url_helper
INFO - 2016-11-10 16:13:03 --> Helper loaded: form_helper
INFO - 2016-11-10 16:13:03 --> Database Driver Class Initialized
INFO - 2016-11-10 16:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:13:03 --> Controller Class Initialized
INFO - 2016-11-10 16:13:03 --> Model Class Initialized
INFO - 2016-11-10 16:13:03 --> Model Class Initialized
INFO - 2016-11-10 16:13:03 --> Model Class Initialized
INFO - 2016-11-10 16:13:03 --> Model Class Initialized
INFO - 2016-11-10 16:13:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:13:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:13:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:13:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:13:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:13:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:13:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:13:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:13:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:13:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:13:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:13:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:13:03 --> Final output sent to browser
DEBUG - 2016-11-10 16:13:03 --> Total execution time: 0.5083
INFO - 2016-11-10 16:13:36 --> Config Class Initialized
INFO - 2016-11-10 16:13:36 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:13:36 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:13:36 --> Utf8 Class Initialized
INFO - 2016-11-10 16:13:36 --> URI Class Initialized
DEBUG - 2016-11-10 16:13:36 --> No URI present. Default controller set.
INFO - 2016-11-10 16:13:36 --> Router Class Initialized
INFO - 2016-11-10 16:13:36 --> Output Class Initialized
INFO - 2016-11-10 16:13:36 --> Security Class Initialized
DEBUG - 2016-11-10 16:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:13:36 --> Input Class Initialized
INFO - 2016-11-10 16:13:36 --> Language Class Initialized
INFO - 2016-11-10 16:13:36 --> Loader Class Initialized
INFO - 2016-11-10 16:13:36 --> Helper loaded: url_helper
INFO - 2016-11-10 16:13:36 --> Helper loaded: form_helper
INFO - 2016-11-10 16:13:36 --> Database Driver Class Initialized
INFO - 2016-11-10 16:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:13:36 --> Controller Class Initialized
INFO - 2016-11-10 16:13:36 --> Model Class Initialized
INFO - 2016-11-10 16:13:36 --> Model Class Initialized
INFO - 2016-11-10 16:13:36 --> Model Class Initialized
INFO - 2016-11-10 16:13:36 --> Model Class Initialized
INFO - 2016-11-10 16:13:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:13:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:13:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:13:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:13:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:13:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:13:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:13:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:13:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:13:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:13:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:13:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:13:36 --> Final output sent to browser
DEBUG - 2016-11-10 16:13:36 --> Total execution time: 0.4983
INFO - 2016-11-10 16:14:12 --> Config Class Initialized
INFO - 2016-11-10 16:14:12 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:14:12 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:14:12 --> Utf8 Class Initialized
INFO - 2016-11-10 16:14:12 --> URI Class Initialized
DEBUG - 2016-11-10 16:14:12 --> No URI present. Default controller set.
INFO - 2016-11-10 16:14:12 --> Router Class Initialized
INFO - 2016-11-10 16:14:12 --> Output Class Initialized
INFO - 2016-11-10 16:14:12 --> Security Class Initialized
DEBUG - 2016-11-10 16:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:14:12 --> Input Class Initialized
INFO - 2016-11-10 16:14:12 --> Language Class Initialized
INFO - 2016-11-10 16:14:12 --> Loader Class Initialized
INFO - 2016-11-10 16:14:12 --> Helper loaded: url_helper
INFO - 2016-11-10 16:14:12 --> Helper loaded: form_helper
INFO - 2016-11-10 16:14:12 --> Database Driver Class Initialized
INFO - 2016-11-10 16:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:14:12 --> Controller Class Initialized
INFO - 2016-11-10 16:14:12 --> Model Class Initialized
INFO - 2016-11-10 16:14:12 --> Model Class Initialized
INFO - 2016-11-10 16:14:12 --> Model Class Initialized
INFO - 2016-11-10 16:14:12 --> Model Class Initialized
INFO - 2016-11-10 16:14:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:14:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:14:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:14:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:14:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:14:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:14:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:14:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:14:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:14:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:14:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:14:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:14:12 --> Final output sent to browser
DEBUG - 2016-11-10 16:14:12 --> Total execution time: 0.5024
INFO - 2016-11-10 16:14:16 --> Config Class Initialized
INFO - 2016-11-10 16:14:16 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:14:16 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:14:16 --> Utf8 Class Initialized
INFO - 2016-11-10 16:14:16 --> URI Class Initialized
DEBUG - 2016-11-10 16:14:16 --> No URI present. Default controller set.
INFO - 2016-11-10 16:14:16 --> Router Class Initialized
INFO - 2016-11-10 16:14:16 --> Output Class Initialized
INFO - 2016-11-10 16:14:16 --> Security Class Initialized
DEBUG - 2016-11-10 16:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:14:16 --> Input Class Initialized
INFO - 2016-11-10 16:14:16 --> Language Class Initialized
INFO - 2016-11-10 16:14:16 --> Loader Class Initialized
INFO - 2016-11-10 16:14:16 --> Helper loaded: url_helper
INFO - 2016-11-10 16:14:16 --> Helper loaded: form_helper
INFO - 2016-11-10 16:14:16 --> Database Driver Class Initialized
INFO - 2016-11-10 16:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:14:16 --> Controller Class Initialized
INFO - 2016-11-10 16:14:16 --> Model Class Initialized
INFO - 2016-11-10 16:14:16 --> Model Class Initialized
INFO - 2016-11-10 16:14:16 --> Model Class Initialized
INFO - 2016-11-10 16:14:16 --> Model Class Initialized
INFO - 2016-11-10 16:14:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:14:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:14:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:14:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:14:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:14:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:14:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:14:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:14:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:14:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:14:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:14:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:14:16 --> Final output sent to browser
DEBUG - 2016-11-10 16:14:16 --> Total execution time: 0.5331
INFO - 2016-11-10 16:14:22 --> Config Class Initialized
INFO - 2016-11-10 16:14:22 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:14:22 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:14:22 --> Utf8 Class Initialized
INFO - 2016-11-10 16:14:22 --> URI Class Initialized
DEBUG - 2016-11-10 16:14:22 --> No URI present. Default controller set.
INFO - 2016-11-10 16:14:22 --> Router Class Initialized
INFO - 2016-11-10 16:14:22 --> Output Class Initialized
INFO - 2016-11-10 16:14:22 --> Security Class Initialized
DEBUG - 2016-11-10 16:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:14:22 --> Input Class Initialized
INFO - 2016-11-10 16:14:22 --> Language Class Initialized
INFO - 2016-11-10 16:14:22 --> Loader Class Initialized
INFO - 2016-11-10 16:14:22 --> Helper loaded: url_helper
INFO - 2016-11-10 16:14:22 --> Helper loaded: form_helper
INFO - 2016-11-10 16:14:22 --> Database Driver Class Initialized
INFO - 2016-11-10 16:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:14:22 --> Controller Class Initialized
INFO - 2016-11-10 16:14:22 --> Model Class Initialized
INFO - 2016-11-10 16:14:23 --> Model Class Initialized
INFO - 2016-11-10 16:14:23 --> Model Class Initialized
INFO - 2016-11-10 16:14:23 --> Model Class Initialized
INFO - 2016-11-10 16:14:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:14:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:14:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:14:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:14:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:14:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:14:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:14:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:14:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:14:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:14:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:14:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:14:23 --> Final output sent to browser
DEBUG - 2016-11-10 16:14:23 --> Total execution time: 0.5295
INFO - 2016-11-10 16:18:30 --> Config Class Initialized
INFO - 2016-11-10 16:18:30 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:18:30 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:18:30 --> Utf8 Class Initialized
INFO - 2016-11-10 16:18:30 --> URI Class Initialized
DEBUG - 2016-11-10 16:18:30 --> No URI present. Default controller set.
INFO - 2016-11-10 16:18:30 --> Router Class Initialized
INFO - 2016-11-10 16:18:30 --> Output Class Initialized
INFO - 2016-11-10 16:18:30 --> Security Class Initialized
DEBUG - 2016-11-10 16:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:18:30 --> Input Class Initialized
INFO - 2016-11-10 16:18:30 --> Language Class Initialized
INFO - 2016-11-10 16:18:30 --> Loader Class Initialized
INFO - 2016-11-10 16:18:30 --> Helper loaded: url_helper
INFO - 2016-11-10 16:18:30 --> Helper loaded: form_helper
INFO - 2016-11-10 16:18:30 --> Database Driver Class Initialized
INFO - 2016-11-10 16:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:18:30 --> Controller Class Initialized
INFO - 2016-11-10 16:18:31 --> Model Class Initialized
INFO - 2016-11-10 16:18:31 --> Model Class Initialized
INFO - 2016-11-10 16:18:31 --> Model Class Initialized
INFO - 2016-11-10 16:18:31 --> Model Class Initialized
INFO - 2016-11-10 16:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:18:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:18:31 --> Final output sent to browser
DEBUG - 2016-11-10 16:18:31 --> Total execution time: 0.6145
INFO - 2016-11-10 16:18:36 --> Config Class Initialized
INFO - 2016-11-10 16:18:36 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:18:36 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:18:36 --> Utf8 Class Initialized
INFO - 2016-11-10 16:18:36 --> URI Class Initialized
DEBUG - 2016-11-10 16:18:36 --> No URI present. Default controller set.
INFO - 2016-11-10 16:18:36 --> Router Class Initialized
INFO - 2016-11-10 16:18:36 --> Output Class Initialized
INFO - 2016-11-10 16:18:36 --> Security Class Initialized
DEBUG - 2016-11-10 16:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:18:36 --> Input Class Initialized
INFO - 2016-11-10 16:18:36 --> Language Class Initialized
INFO - 2016-11-10 16:18:36 --> Loader Class Initialized
INFO - 2016-11-10 16:18:36 --> Helper loaded: url_helper
INFO - 2016-11-10 16:18:36 --> Helper loaded: form_helper
INFO - 2016-11-10 16:18:36 --> Database Driver Class Initialized
INFO - 2016-11-10 16:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:18:36 --> Controller Class Initialized
INFO - 2016-11-10 16:18:36 --> Model Class Initialized
INFO - 2016-11-10 16:18:36 --> Model Class Initialized
INFO - 2016-11-10 16:18:36 --> Model Class Initialized
INFO - 2016-11-10 16:18:36 --> Model Class Initialized
INFO - 2016-11-10 16:18:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:18:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:18:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:18:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:18:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:18:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:18:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:18:37 --> Final output sent to browser
DEBUG - 2016-11-10 16:18:37 --> Total execution time: 0.6742
INFO - 2016-11-10 16:18:54 --> Config Class Initialized
INFO - 2016-11-10 16:18:54 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:18:54 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:18:54 --> Utf8 Class Initialized
INFO - 2016-11-10 16:18:54 --> URI Class Initialized
DEBUG - 2016-11-10 16:18:54 --> No URI present. Default controller set.
INFO - 2016-11-10 16:18:54 --> Router Class Initialized
INFO - 2016-11-10 16:18:54 --> Output Class Initialized
INFO - 2016-11-10 16:18:54 --> Security Class Initialized
DEBUG - 2016-11-10 16:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:18:54 --> Input Class Initialized
INFO - 2016-11-10 16:18:54 --> Language Class Initialized
INFO - 2016-11-10 16:18:54 --> Loader Class Initialized
INFO - 2016-11-10 16:18:54 --> Helper loaded: url_helper
INFO - 2016-11-10 16:18:54 --> Helper loaded: form_helper
INFO - 2016-11-10 16:18:54 --> Database Driver Class Initialized
INFO - 2016-11-10 16:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:18:54 --> Controller Class Initialized
INFO - 2016-11-10 16:18:54 --> Model Class Initialized
INFO - 2016-11-10 16:18:54 --> Model Class Initialized
INFO - 2016-11-10 16:18:54 --> Model Class Initialized
INFO - 2016-11-10 16:18:54 --> Model Class Initialized
INFO - 2016-11-10 16:18:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:18:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:18:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:18:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:18:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:18:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:18:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:18:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:18:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:18:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:18:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:18:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:18:55 --> Final output sent to browser
DEBUG - 2016-11-10 16:18:55 --> Total execution time: 0.7522
INFO - 2016-11-10 16:19:39 --> Config Class Initialized
INFO - 2016-11-10 16:19:39 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:19:39 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:19:39 --> Utf8 Class Initialized
INFO - 2016-11-10 16:19:39 --> URI Class Initialized
DEBUG - 2016-11-10 16:19:39 --> No URI present. Default controller set.
INFO - 2016-11-10 16:19:39 --> Router Class Initialized
INFO - 2016-11-10 16:19:39 --> Output Class Initialized
INFO - 2016-11-10 16:19:39 --> Security Class Initialized
DEBUG - 2016-11-10 16:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:19:39 --> Input Class Initialized
INFO - 2016-11-10 16:19:39 --> Language Class Initialized
INFO - 2016-11-10 16:19:39 --> Loader Class Initialized
INFO - 2016-11-10 16:19:39 --> Helper loaded: url_helper
INFO - 2016-11-10 16:19:39 --> Helper loaded: form_helper
INFO - 2016-11-10 16:19:39 --> Database Driver Class Initialized
INFO - 2016-11-10 16:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:19:39 --> Controller Class Initialized
INFO - 2016-11-10 16:19:39 --> Model Class Initialized
INFO - 2016-11-10 16:19:39 --> Model Class Initialized
INFO - 2016-11-10 16:19:39 --> Model Class Initialized
INFO - 2016-11-10 16:19:39 --> Model Class Initialized
INFO - 2016-11-10 16:19:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:19:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:19:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:19:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:19:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:19:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:19:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:19:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:19:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:19:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:19:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:19:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:19:39 --> Final output sent to browser
DEBUG - 2016-11-10 16:19:39 --> Total execution time: 0.5071
INFO - 2016-11-10 16:19:45 --> Config Class Initialized
INFO - 2016-11-10 16:19:45 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:19:45 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:19:45 --> Utf8 Class Initialized
INFO - 2016-11-10 16:19:45 --> URI Class Initialized
INFO - 2016-11-10 16:19:45 --> Router Class Initialized
INFO - 2016-11-10 16:19:45 --> Output Class Initialized
INFO - 2016-11-10 16:19:45 --> Security Class Initialized
DEBUG - 2016-11-10 16:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:19:45 --> Input Class Initialized
INFO - 2016-11-10 16:19:45 --> Language Class Initialized
INFO - 2016-11-10 16:19:45 --> Loader Class Initialized
INFO - 2016-11-10 16:19:45 --> Helper loaded: url_helper
INFO - 2016-11-10 16:19:45 --> Helper loaded: form_helper
INFO - 2016-11-10 16:19:45 --> Database Driver Class Initialized
INFO - 2016-11-10 16:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:19:45 --> Controller Class Initialized
INFO - 2016-11-10 16:19:45 --> Model Class Initialized
INFO - 2016-11-10 16:19:45 --> Model Class Initialized
INFO - 2016-11-10 16:19:45 --> Model Class Initialized
INFO - 2016-11-10 16:19:45 --> Model Class Initialized
DEBUG - 2016-11-10 16:19:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 16:19:45 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 143
ERROR - 2016-11-10 16:19:45 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 143
INFO - 2016-11-10 16:19:45 --> Config Class Initialized
INFO - 2016-11-10 16:19:45 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:19:45 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:19:45 --> Utf8 Class Initialized
INFO - 2016-11-10 16:19:45 --> URI Class Initialized
DEBUG - 2016-11-10 16:19:45 --> No URI present. Default controller set.
INFO - 2016-11-10 16:19:45 --> Router Class Initialized
INFO - 2016-11-10 16:19:45 --> Output Class Initialized
INFO - 2016-11-10 16:19:45 --> Security Class Initialized
DEBUG - 2016-11-10 16:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:19:45 --> Input Class Initialized
INFO - 2016-11-10 16:19:45 --> Language Class Initialized
INFO - 2016-11-10 16:19:45 --> Loader Class Initialized
INFO - 2016-11-10 16:19:45 --> Helper loaded: url_helper
INFO - 2016-11-10 16:19:45 --> Helper loaded: form_helper
INFO - 2016-11-10 16:19:45 --> Database Driver Class Initialized
INFO - 2016-11-10 16:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:19:45 --> Controller Class Initialized
INFO - 2016-11-10 16:19:45 --> Model Class Initialized
INFO - 2016-11-10 16:19:45 --> Model Class Initialized
INFO - 2016-11-10 16:19:45 --> Model Class Initialized
INFO - 2016-11-10 16:19:45 --> Model Class Initialized
INFO - 2016-11-10 16:19:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:19:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 16:19:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:19:45 --> Final output sent to browser
DEBUG - 2016-11-10 16:19:45 --> Total execution time: 0.3760
INFO - 2016-11-10 16:19:55 --> Config Class Initialized
INFO - 2016-11-10 16:19:55 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:19:55 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:19:55 --> Utf8 Class Initialized
INFO - 2016-11-10 16:19:55 --> URI Class Initialized
INFO - 2016-11-10 16:19:55 --> Router Class Initialized
INFO - 2016-11-10 16:19:55 --> Output Class Initialized
INFO - 2016-11-10 16:19:55 --> Security Class Initialized
DEBUG - 2016-11-10 16:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:19:55 --> Input Class Initialized
INFO - 2016-11-10 16:19:55 --> Language Class Initialized
INFO - 2016-11-10 16:19:56 --> Loader Class Initialized
INFO - 2016-11-10 16:19:56 --> Helper loaded: url_helper
INFO - 2016-11-10 16:19:56 --> Helper loaded: form_helper
INFO - 2016-11-10 16:19:56 --> Database Driver Class Initialized
INFO - 2016-11-10 16:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:19:56 --> Controller Class Initialized
INFO - 2016-11-10 16:19:56 --> Model Class Initialized
INFO - 2016-11-10 16:19:56 --> Model Class Initialized
INFO - 2016-11-10 16:19:56 --> Model Class Initialized
INFO - 2016-11-10 16:19:56 --> Model Class Initialized
DEBUG - 2016-11-10 16:19:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 16:19:56 --> Model Class Initialized
INFO - 2016-11-10 16:19:56 --> Final output sent to browser
DEBUG - 2016-11-10 16:19:56 --> Total execution time: 0.3651
INFO - 2016-11-10 16:19:56 --> Config Class Initialized
INFO - 2016-11-10 16:19:56 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:19:56 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:19:56 --> Utf8 Class Initialized
INFO - 2016-11-10 16:19:56 --> URI Class Initialized
DEBUG - 2016-11-10 16:19:56 --> No URI present. Default controller set.
INFO - 2016-11-10 16:19:56 --> Router Class Initialized
INFO - 2016-11-10 16:19:56 --> Output Class Initialized
INFO - 2016-11-10 16:19:56 --> Security Class Initialized
DEBUG - 2016-11-10 16:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:19:56 --> Input Class Initialized
INFO - 2016-11-10 16:19:56 --> Language Class Initialized
INFO - 2016-11-10 16:19:56 --> Loader Class Initialized
INFO - 2016-11-10 16:19:56 --> Helper loaded: url_helper
INFO - 2016-11-10 16:19:56 --> Helper loaded: form_helper
INFO - 2016-11-10 16:19:56 --> Database Driver Class Initialized
INFO - 2016-11-10 16:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:19:56 --> Controller Class Initialized
INFO - 2016-11-10 16:19:56 --> Model Class Initialized
INFO - 2016-11-10 16:19:56 --> Model Class Initialized
INFO - 2016-11-10 16:19:56 --> Model Class Initialized
INFO - 2016-11-10 16:19:56 --> Model Class Initialized
INFO - 2016-11-10 16:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:19:56 --> Final output sent to browser
DEBUG - 2016-11-10 16:19:56 --> Total execution time: 0.5334
INFO - 2016-11-10 16:20:32 --> Config Class Initialized
INFO - 2016-11-10 16:20:32 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:20:32 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:20:32 --> Utf8 Class Initialized
INFO - 2016-11-10 16:20:32 --> URI Class Initialized
INFO - 2016-11-10 16:20:32 --> Router Class Initialized
INFO - 2016-11-10 16:20:32 --> Output Class Initialized
INFO - 2016-11-10 16:20:32 --> Security Class Initialized
DEBUG - 2016-11-10 16:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:20:32 --> Input Class Initialized
INFO - 2016-11-10 16:20:32 --> Language Class Initialized
INFO - 2016-11-10 16:20:32 --> Loader Class Initialized
INFO - 2016-11-10 16:20:32 --> Helper loaded: url_helper
INFO - 2016-11-10 16:20:32 --> Helper loaded: form_helper
INFO - 2016-11-10 16:20:32 --> Database Driver Class Initialized
INFO - 2016-11-10 16:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:20:32 --> Controller Class Initialized
INFO - 2016-11-10 16:20:32 --> Model Class Initialized
INFO - 2016-11-10 16:20:32 --> Model Class Initialized
INFO - 2016-11-10 16:20:32 --> Model Class Initialized
INFO - 2016-11-10 16:20:32 --> Model Class Initialized
DEBUG - 2016-11-10 16:20:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 16:20:32 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 143
ERROR - 2016-11-10 16:20:32 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 143
INFO - 2016-11-10 16:20:32 --> Config Class Initialized
INFO - 2016-11-10 16:20:32 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:20:32 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:20:33 --> Utf8 Class Initialized
INFO - 2016-11-10 16:20:33 --> URI Class Initialized
DEBUG - 2016-11-10 16:20:33 --> No URI present. Default controller set.
INFO - 2016-11-10 16:20:33 --> Router Class Initialized
INFO - 2016-11-10 16:20:33 --> Output Class Initialized
INFO - 2016-11-10 16:20:33 --> Security Class Initialized
DEBUG - 2016-11-10 16:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:20:33 --> Input Class Initialized
INFO - 2016-11-10 16:20:33 --> Language Class Initialized
INFO - 2016-11-10 16:20:33 --> Loader Class Initialized
INFO - 2016-11-10 16:20:33 --> Helper loaded: url_helper
INFO - 2016-11-10 16:20:33 --> Helper loaded: form_helper
INFO - 2016-11-10 16:20:33 --> Database Driver Class Initialized
INFO - 2016-11-10 16:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:20:33 --> Controller Class Initialized
INFO - 2016-11-10 16:20:33 --> Model Class Initialized
INFO - 2016-11-10 16:20:33 --> Model Class Initialized
INFO - 2016-11-10 16:20:33 --> Model Class Initialized
INFO - 2016-11-10 16:20:33 --> Model Class Initialized
INFO - 2016-11-10 16:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 16:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:20:33 --> Final output sent to browser
DEBUG - 2016-11-10 16:20:33 --> Total execution time: 0.3861
INFO - 2016-11-10 16:20:52 --> Config Class Initialized
INFO - 2016-11-10 16:20:52 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:20:52 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:20:52 --> Utf8 Class Initialized
INFO - 2016-11-10 16:20:52 --> URI Class Initialized
INFO - 2016-11-10 16:20:52 --> Router Class Initialized
INFO - 2016-11-10 16:20:52 --> Output Class Initialized
INFO - 2016-11-10 16:20:52 --> Security Class Initialized
DEBUG - 2016-11-10 16:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:20:52 --> Input Class Initialized
INFO - 2016-11-10 16:20:52 --> Language Class Initialized
INFO - 2016-11-10 16:20:52 --> Loader Class Initialized
INFO - 2016-11-10 16:20:52 --> Helper loaded: url_helper
INFO - 2016-11-10 16:20:52 --> Helper loaded: form_helper
INFO - 2016-11-10 16:20:52 --> Database Driver Class Initialized
INFO - 2016-11-10 16:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:20:52 --> Controller Class Initialized
INFO - 2016-11-10 16:20:52 --> Model Class Initialized
INFO - 2016-11-10 16:20:52 --> Model Class Initialized
INFO - 2016-11-10 16:20:52 --> Model Class Initialized
INFO - 2016-11-10 16:20:52 --> Model Class Initialized
DEBUG - 2016-11-10 16:20:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 16:20:52 --> Model Class Initialized
INFO - 2016-11-10 16:20:52 --> Final output sent to browser
DEBUG - 2016-11-10 16:20:52 --> Total execution time: 0.4165
INFO - 2016-11-10 16:20:52 --> Config Class Initialized
INFO - 2016-11-10 16:20:52 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:20:52 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:20:52 --> Utf8 Class Initialized
INFO - 2016-11-10 16:20:52 --> URI Class Initialized
DEBUG - 2016-11-10 16:20:52 --> No URI present. Default controller set.
INFO - 2016-11-10 16:20:53 --> Router Class Initialized
INFO - 2016-11-10 16:20:53 --> Output Class Initialized
INFO - 2016-11-10 16:20:53 --> Security Class Initialized
DEBUG - 2016-11-10 16:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:20:53 --> Input Class Initialized
INFO - 2016-11-10 16:20:53 --> Language Class Initialized
INFO - 2016-11-10 16:20:53 --> Loader Class Initialized
INFO - 2016-11-10 16:20:53 --> Helper loaded: url_helper
INFO - 2016-11-10 16:20:53 --> Helper loaded: form_helper
INFO - 2016-11-10 16:20:53 --> Database Driver Class Initialized
INFO - 2016-11-10 16:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:20:53 --> Controller Class Initialized
INFO - 2016-11-10 16:20:53 --> Model Class Initialized
INFO - 2016-11-10 16:20:53 --> Model Class Initialized
INFO - 2016-11-10 16:20:53 --> Model Class Initialized
INFO - 2016-11-10 16:20:53 --> Model Class Initialized
INFO - 2016-11-10 16:20:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:20:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:20:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:20:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:20:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:20:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:20:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:20:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:20:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:20:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:20:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:20:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:20:53 --> Final output sent to browser
DEBUG - 2016-11-10 16:20:53 --> Total execution time: 0.5168
INFO - 2016-11-10 16:21:40 --> Config Class Initialized
INFO - 2016-11-10 16:21:40 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:21:40 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:21:40 --> Utf8 Class Initialized
INFO - 2016-11-10 16:21:40 --> URI Class Initialized
INFO - 2016-11-10 16:21:40 --> Router Class Initialized
INFO - 2016-11-10 16:21:40 --> Output Class Initialized
INFO - 2016-11-10 16:21:40 --> Security Class Initialized
DEBUG - 2016-11-10 16:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:21:40 --> Input Class Initialized
INFO - 2016-11-10 16:21:40 --> Language Class Initialized
INFO - 2016-11-10 16:21:40 --> Loader Class Initialized
INFO - 2016-11-10 16:21:40 --> Helper loaded: url_helper
INFO - 2016-11-10 16:21:40 --> Helper loaded: form_helper
INFO - 2016-11-10 16:21:40 --> Database Driver Class Initialized
INFO - 2016-11-10 16:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:21:40 --> Controller Class Initialized
INFO - 2016-11-10 16:21:40 --> Model Class Initialized
INFO - 2016-11-10 16:21:40 --> Model Class Initialized
INFO - 2016-11-10 16:21:40 --> Model Class Initialized
INFO - 2016-11-10 16:21:40 --> Model Class Initialized
DEBUG - 2016-11-10 16:21:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 16:21:40 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 143
ERROR - 2016-11-10 16:21:40 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 143
INFO - 2016-11-10 16:21:40 --> Config Class Initialized
INFO - 2016-11-10 16:21:40 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:21:40 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:21:40 --> Utf8 Class Initialized
INFO - 2016-11-10 16:21:40 --> URI Class Initialized
DEBUG - 2016-11-10 16:21:40 --> No URI present. Default controller set.
INFO - 2016-11-10 16:21:40 --> Router Class Initialized
INFO - 2016-11-10 16:21:40 --> Output Class Initialized
INFO - 2016-11-10 16:21:40 --> Security Class Initialized
DEBUG - 2016-11-10 16:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:21:40 --> Input Class Initialized
INFO - 2016-11-10 16:21:40 --> Language Class Initialized
INFO - 2016-11-10 16:21:40 --> Loader Class Initialized
INFO - 2016-11-10 16:21:40 --> Helper loaded: url_helper
INFO - 2016-11-10 16:21:40 --> Helper loaded: form_helper
INFO - 2016-11-10 16:21:40 --> Database Driver Class Initialized
INFO - 2016-11-10 16:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:21:40 --> Controller Class Initialized
INFO - 2016-11-10 16:21:40 --> Model Class Initialized
INFO - 2016-11-10 16:21:40 --> Model Class Initialized
INFO - 2016-11-10 16:21:40 --> Model Class Initialized
INFO - 2016-11-10 16:21:40 --> Model Class Initialized
INFO - 2016-11-10 16:21:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:21:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 16:21:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:21:40 --> Final output sent to browser
DEBUG - 2016-11-10 16:21:40 --> Total execution time: 0.3811
INFO - 2016-11-10 16:22:33 --> Config Class Initialized
INFO - 2016-11-10 16:22:33 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:22:33 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:22:33 --> Utf8 Class Initialized
INFO - 2016-11-10 16:22:33 --> URI Class Initialized
INFO - 2016-11-10 16:22:33 --> Router Class Initialized
INFO - 2016-11-10 16:22:33 --> Output Class Initialized
INFO - 2016-11-10 16:22:33 --> Security Class Initialized
DEBUG - 2016-11-10 16:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:22:33 --> Input Class Initialized
INFO - 2016-11-10 16:22:33 --> Language Class Initialized
INFO - 2016-11-10 16:22:33 --> Loader Class Initialized
INFO - 2016-11-10 16:22:33 --> Helper loaded: url_helper
INFO - 2016-11-10 16:22:33 --> Helper loaded: form_helper
INFO - 2016-11-10 16:22:33 --> Database Driver Class Initialized
INFO - 2016-11-10 16:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:22:33 --> Controller Class Initialized
INFO - 2016-11-10 16:22:33 --> Model Class Initialized
INFO - 2016-11-10 16:22:33 --> Model Class Initialized
INFO - 2016-11-10 16:22:33 --> Model Class Initialized
INFO - 2016-11-10 16:22:33 --> Model Class Initialized
DEBUG - 2016-11-10 16:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 16:22:33 --> Model Class Initialized
INFO - 2016-11-10 16:22:33 --> Final output sent to browser
DEBUG - 2016-11-10 16:22:33 --> Total execution time: 0.3923
INFO - 2016-11-10 16:22:33 --> Config Class Initialized
INFO - 2016-11-10 16:22:33 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:22:33 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:22:33 --> Utf8 Class Initialized
INFO - 2016-11-10 16:22:33 --> URI Class Initialized
DEBUG - 2016-11-10 16:22:33 --> No URI present. Default controller set.
INFO - 2016-11-10 16:22:33 --> Router Class Initialized
INFO - 2016-11-10 16:22:33 --> Output Class Initialized
INFO - 2016-11-10 16:22:33 --> Security Class Initialized
DEBUG - 2016-11-10 16:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:22:33 --> Input Class Initialized
INFO - 2016-11-10 16:22:33 --> Language Class Initialized
INFO - 2016-11-10 16:22:33 --> Loader Class Initialized
INFO - 2016-11-10 16:22:33 --> Helper loaded: url_helper
INFO - 2016-11-10 16:22:33 --> Helper loaded: form_helper
INFO - 2016-11-10 16:22:33 --> Database Driver Class Initialized
INFO - 2016-11-10 16:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:22:33 --> Controller Class Initialized
INFO - 2016-11-10 16:22:33 --> Model Class Initialized
INFO - 2016-11-10 16:22:33 --> Model Class Initialized
INFO - 2016-11-10 16:22:33 --> Model Class Initialized
INFO - 2016-11-10 16:22:33 --> Model Class Initialized
INFO - 2016-11-10 16:22:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:22:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:22:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:22:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:22:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:22:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:22:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:22:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:22:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:22:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:22:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:22:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:22:34 --> Final output sent to browser
DEBUG - 2016-11-10 16:22:34 --> Total execution time: 0.5634
INFO - 2016-11-10 16:22:58 --> Config Class Initialized
INFO - 2016-11-10 16:22:59 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:22:59 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:22:59 --> Utf8 Class Initialized
INFO - 2016-11-10 16:22:59 --> URI Class Initialized
INFO - 2016-11-10 16:22:59 --> Router Class Initialized
INFO - 2016-11-10 16:22:59 --> Output Class Initialized
INFO - 2016-11-10 16:22:59 --> Security Class Initialized
DEBUG - 2016-11-10 16:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:22:59 --> Input Class Initialized
INFO - 2016-11-10 16:22:59 --> Language Class Initialized
INFO - 2016-11-10 16:22:59 --> Loader Class Initialized
INFO - 2016-11-10 16:22:59 --> Helper loaded: url_helper
INFO - 2016-11-10 16:22:59 --> Helper loaded: form_helper
INFO - 2016-11-10 16:22:59 --> Database Driver Class Initialized
INFO - 2016-11-10 16:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:22:59 --> Controller Class Initialized
INFO - 2016-11-10 16:22:59 --> Model Class Initialized
INFO - 2016-11-10 16:22:59 --> Model Class Initialized
INFO - 2016-11-10 16:22:59 --> Model Class Initialized
INFO - 2016-11-10 16:22:59 --> Model Class Initialized
DEBUG - 2016-11-10 16:22:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 16:22:59 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 143
ERROR - 2016-11-10 16:22:59 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 143
INFO - 2016-11-10 16:22:59 --> Config Class Initialized
INFO - 2016-11-10 16:22:59 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:22:59 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:22:59 --> Utf8 Class Initialized
INFO - 2016-11-10 16:22:59 --> URI Class Initialized
DEBUG - 2016-11-10 16:22:59 --> No URI present. Default controller set.
INFO - 2016-11-10 16:22:59 --> Router Class Initialized
INFO - 2016-11-10 16:22:59 --> Output Class Initialized
INFO - 2016-11-10 16:22:59 --> Security Class Initialized
DEBUG - 2016-11-10 16:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:22:59 --> Input Class Initialized
INFO - 2016-11-10 16:22:59 --> Language Class Initialized
INFO - 2016-11-10 16:22:59 --> Loader Class Initialized
INFO - 2016-11-10 16:22:59 --> Helper loaded: url_helper
INFO - 2016-11-10 16:22:59 --> Helper loaded: form_helper
INFO - 2016-11-10 16:22:59 --> Database Driver Class Initialized
INFO - 2016-11-10 16:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:22:59 --> Controller Class Initialized
INFO - 2016-11-10 16:22:59 --> Model Class Initialized
INFO - 2016-11-10 16:22:59 --> Model Class Initialized
INFO - 2016-11-10 16:22:59 --> Model Class Initialized
INFO - 2016-11-10 16:22:59 --> Model Class Initialized
INFO - 2016-11-10 16:22:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:22:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 16:22:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:22:59 --> Final output sent to browser
DEBUG - 2016-11-10 16:22:59 --> Total execution time: 0.3878
INFO - 2016-11-10 16:23:24 --> Config Class Initialized
INFO - 2016-11-10 16:23:24 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:23:24 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:23:24 --> Utf8 Class Initialized
INFO - 2016-11-10 16:23:24 --> URI Class Initialized
INFO - 2016-11-10 16:23:24 --> Router Class Initialized
INFO - 2016-11-10 16:23:24 --> Output Class Initialized
INFO - 2016-11-10 16:23:24 --> Security Class Initialized
DEBUG - 2016-11-10 16:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:23:24 --> Input Class Initialized
INFO - 2016-11-10 16:23:24 --> Language Class Initialized
INFO - 2016-11-10 16:23:24 --> Loader Class Initialized
INFO - 2016-11-10 16:23:24 --> Helper loaded: url_helper
INFO - 2016-11-10 16:23:24 --> Helper loaded: form_helper
INFO - 2016-11-10 16:23:24 --> Database Driver Class Initialized
INFO - 2016-11-10 16:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:23:24 --> Controller Class Initialized
INFO - 2016-11-10 16:23:24 --> Model Class Initialized
INFO - 2016-11-10 16:23:24 --> Model Class Initialized
INFO - 2016-11-10 16:23:24 --> Model Class Initialized
INFO - 2016-11-10 16:23:24 --> Model Class Initialized
DEBUG - 2016-11-10 16:23:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 16:23:24 --> Model Class Initialized
INFO - 2016-11-10 16:23:24 --> Final output sent to browser
DEBUG - 2016-11-10 16:23:24 --> Total execution time: 0.4167
INFO - 2016-11-10 16:23:25 --> Config Class Initialized
INFO - 2016-11-10 16:23:25 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:23:25 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:23:25 --> Utf8 Class Initialized
INFO - 2016-11-10 16:23:25 --> URI Class Initialized
DEBUG - 2016-11-10 16:23:25 --> No URI present. Default controller set.
INFO - 2016-11-10 16:23:25 --> Router Class Initialized
INFO - 2016-11-10 16:23:25 --> Output Class Initialized
INFO - 2016-11-10 16:23:25 --> Security Class Initialized
DEBUG - 2016-11-10 16:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:23:25 --> Input Class Initialized
INFO - 2016-11-10 16:23:25 --> Language Class Initialized
INFO - 2016-11-10 16:23:25 --> Loader Class Initialized
INFO - 2016-11-10 16:23:25 --> Helper loaded: url_helper
INFO - 2016-11-10 16:23:25 --> Helper loaded: form_helper
INFO - 2016-11-10 16:23:25 --> Database Driver Class Initialized
INFO - 2016-11-10 16:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:23:25 --> Controller Class Initialized
INFO - 2016-11-10 16:23:25 --> Model Class Initialized
INFO - 2016-11-10 16:23:25 --> Model Class Initialized
INFO - 2016-11-10 16:23:25 --> Model Class Initialized
INFO - 2016-11-10 16:23:25 --> Model Class Initialized
INFO - 2016-11-10 16:23:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:23:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:23:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:23:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:23:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:23:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:23:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:23:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:23:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:23:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:23:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:23:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:23:25 --> Final output sent to browser
DEBUG - 2016-11-10 16:23:25 --> Total execution time: 0.5638
INFO - 2016-11-10 16:29:07 --> Config Class Initialized
INFO - 2016-11-10 16:29:07 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:29:07 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:29:07 --> Utf8 Class Initialized
INFO - 2016-11-10 16:29:07 --> URI Class Initialized
DEBUG - 2016-11-10 16:29:07 --> No URI present. Default controller set.
INFO - 2016-11-10 16:29:07 --> Router Class Initialized
INFO - 2016-11-10 16:29:07 --> Output Class Initialized
INFO - 2016-11-10 16:29:07 --> Security Class Initialized
DEBUG - 2016-11-10 16:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:29:08 --> Input Class Initialized
INFO - 2016-11-10 16:29:08 --> Language Class Initialized
INFO - 2016-11-10 16:29:08 --> Loader Class Initialized
INFO - 2016-11-10 16:29:08 --> Helper loaded: url_helper
INFO - 2016-11-10 16:29:08 --> Helper loaded: form_helper
INFO - 2016-11-10 16:29:08 --> Database Driver Class Initialized
INFO - 2016-11-10 16:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:29:08 --> Controller Class Initialized
INFO - 2016-11-10 16:29:08 --> Model Class Initialized
INFO - 2016-11-10 16:29:08 --> Model Class Initialized
INFO - 2016-11-10 16:29:08 --> Model Class Initialized
INFO - 2016-11-10 16:29:08 --> Model Class Initialized
INFO - 2016-11-10 16:29:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:29:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 16:29:08 --> Severity: Notice --> Undefined variable: queryLeaveRecord C:\xampp\htdocs\LMS\app\controllers\Auth.php 73
INFO - 2016-11-10 16:29:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:29:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:29:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:29:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:29:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:29:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
ERROR - 2016-11-10 16:29:08 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 14
INFO - 2016-11-10 16:31:05 --> Config Class Initialized
INFO - 2016-11-10 16:31:05 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:31:05 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:31:05 --> Utf8 Class Initialized
INFO - 2016-11-10 16:31:05 --> URI Class Initialized
DEBUG - 2016-11-10 16:31:05 --> No URI present. Default controller set.
INFO - 2016-11-10 16:31:05 --> Router Class Initialized
INFO - 2016-11-10 16:31:05 --> Output Class Initialized
INFO - 2016-11-10 16:31:05 --> Security Class Initialized
DEBUG - 2016-11-10 16:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:31:05 --> Input Class Initialized
INFO - 2016-11-10 16:31:05 --> Language Class Initialized
INFO - 2016-11-10 16:31:05 --> Loader Class Initialized
INFO - 2016-11-10 16:31:05 --> Helper loaded: url_helper
INFO - 2016-11-10 16:31:05 --> Helper loaded: form_helper
INFO - 2016-11-10 16:31:05 --> Database Driver Class Initialized
INFO - 2016-11-10 16:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:31:05 --> Controller Class Initialized
INFO - 2016-11-10 16:31:05 --> Model Class Initialized
INFO - 2016-11-10 16:31:05 --> Model Class Initialized
INFO - 2016-11-10 16:31:05 --> Model Class Initialized
INFO - 2016-11-10 16:31:05 --> Model Class Initialized
INFO - 2016-11-10 16:31:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:31:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 16:31:05 --> Severity: Notice --> Undefined variable: queryLeaveRecord C:\xampp\htdocs\LMS\app\controllers\Auth.php 73
ERROR - 2016-11-10 16:31:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\LMS\sys\database\DB_query_builder.php 669
ERROR - 2016-11-10 16:31:05 --> Query error: Unknown column 'em.idEmployee' in 'where clause' - Invalid query: SELECT `em`.`surname`, `lt`.`name`, `lv`.`numberOfLeaves`, `lv`.`description`
FROM `leaveRecord` `lv`
LEFT JOIN `employee` as `em` ON `em`.`id` = `lv`.`idEmployee`
LEFT JOIN `leaveType` as `lt` ON `lt`.`id` = `lv`.`idLeaveType`
WHERE `em`.`idEmployee` = `Array`
INFO - 2016-11-10 16:31:05 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 16:33:11 --> Config Class Initialized
INFO - 2016-11-10 16:33:11 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:33:11 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:33:11 --> Utf8 Class Initialized
INFO - 2016-11-10 16:33:11 --> URI Class Initialized
DEBUG - 2016-11-10 16:33:11 --> No URI present. Default controller set.
INFO - 2016-11-10 16:33:11 --> Router Class Initialized
INFO - 2016-11-10 16:33:11 --> Output Class Initialized
INFO - 2016-11-10 16:33:11 --> Security Class Initialized
DEBUG - 2016-11-10 16:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:33:11 --> Input Class Initialized
INFO - 2016-11-10 16:33:11 --> Language Class Initialized
INFO - 2016-11-10 16:33:11 --> Loader Class Initialized
INFO - 2016-11-10 16:33:11 --> Helper loaded: url_helper
INFO - 2016-11-10 16:33:11 --> Helper loaded: form_helper
INFO - 2016-11-10 16:33:11 --> Database Driver Class Initialized
INFO - 2016-11-10 16:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:33:11 --> Controller Class Initialized
INFO - 2016-11-10 16:33:11 --> Model Class Initialized
INFO - 2016-11-10 16:33:11 --> Model Class Initialized
INFO - 2016-11-10 16:33:11 --> Model Class Initialized
INFO - 2016-11-10 16:33:11 --> Model Class Initialized
INFO - 2016-11-10 16:33:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:33:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 16:33:11 --> Severity: Notice --> Undefined variable: queryLeaveRecord C:\xampp\htdocs\LMS\app\controllers\Auth.php 73
INFO - 2016-11-10 16:33:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:33:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:33:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:33:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:33:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:33:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
ERROR - 2016-11-10 16:33:11 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 14
INFO - 2016-11-10 16:34:26 --> Config Class Initialized
INFO - 2016-11-10 16:34:26 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:34:26 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:34:26 --> Utf8 Class Initialized
INFO - 2016-11-10 16:34:26 --> URI Class Initialized
DEBUG - 2016-11-10 16:34:26 --> No URI present. Default controller set.
INFO - 2016-11-10 16:34:26 --> Router Class Initialized
INFO - 2016-11-10 16:34:26 --> Output Class Initialized
INFO - 2016-11-10 16:34:26 --> Security Class Initialized
DEBUG - 2016-11-10 16:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:34:26 --> Input Class Initialized
INFO - 2016-11-10 16:34:26 --> Language Class Initialized
INFO - 2016-11-10 16:34:26 --> Loader Class Initialized
INFO - 2016-11-10 16:34:26 --> Helper loaded: url_helper
INFO - 2016-11-10 16:34:26 --> Helper loaded: form_helper
INFO - 2016-11-10 16:34:26 --> Database Driver Class Initialized
INFO - 2016-11-10 16:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:34:26 --> Controller Class Initialized
INFO - 2016-11-10 16:34:26 --> Model Class Initialized
INFO - 2016-11-10 16:34:26 --> Model Class Initialized
INFO - 2016-11-10 16:34:26 --> Model Class Initialized
INFO - 2016-11-10 16:34:26 --> Model Class Initialized
INFO - 2016-11-10 16:34:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:34:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:34:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:34:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:34:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:34:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:34:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:34:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
ERROR - 2016-11-10 16:34:26 --> Severity: Notice --> Undefined variable: all_leave_records_data C:\xampp\htdocs\LMS\app\views\dashboard.php 123
ERROR - 2016-11-10 16:34:26 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 14
INFO - 2016-11-10 16:35:01 --> Config Class Initialized
INFO - 2016-11-10 16:35:01 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:35:01 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:35:01 --> Utf8 Class Initialized
INFO - 2016-11-10 16:35:01 --> URI Class Initialized
DEBUG - 2016-11-10 16:35:01 --> No URI present. Default controller set.
INFO - 2016-11-10 16:35:01 --> Router Class Initialized
INFO - 2016-11-10 16:35:01 --> Output Class Initialized
INFO - 2016-11-10 16:35:01 --> Security Class Initialized
DEBUG - 2016-11-10 16:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:35:01 --> Input Class Initialized
INFO - 2016-11-10 16:35:01 --> Language Class Initialized
INFO - 2016-11-10 16:35:01 --> Loader Class Initialized
INFO - 2016-11-10 16:35:01 --> Helper loaded: url_helper
INFO - 2016-11-10 16:35:01 --> Helper loaded: form_helper
INFO - 2016-11-10 16:35:01 --> Database Driver Class Initialized
INFO - 2016-11-10 16:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:35:01 --> Controller Class Initialized
INFO - 2016-11-10 16:35:01 --> Model Class Initialized
INFO - 2016-11-10 16:35:01 --> Model Class Initialized
INFO - 2016-11-10 16:35:02 --> Model Class Initialized
INFO - 2016-11-10 16:35:02 --> Model Class Initialized
INFO - 2016-11-10 16:35:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:35:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 16:35:02 --> Query error: Unknown column 'em.idEmployee' in 'where clause' - Invalid query: SELECT `em`.`surname`, `lt`.`name`, `lv`.`numberOfLeaves`, `lv`.`description`
FROM `leaveRecord` `lv`
LEFT JOIN `employee` as `em` ON `em`.`id` = `lv`.`idEmployee`
LEFT JOIN `leaveType` as `lt` ON `lt`.`id` = `lv`.`idLeaveType`
WHERE `em`.`idEmployee` = 5
INFO - 2016-11-10 16:35:02 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 16:35:23 --> Config Class Initialized
INFO - 2016-11-10 16:35:24 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:35:24 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:35:24 --> Utf8 Class Initialized
INFO - 2016-11-10 16:35:24 --> URI Class Initialized
DEBUG - 2016-11-10 16:35:24 --> No URI present. Default controller set.
INFO - 2016-11-10 16:35:24 --> Router Class Initialized
INFO - 2016-11-10 16:35:24 --> Output Class Initialized
INFO - 2016-11-10 16:35:24 --> Security Class Initialized
DEBUG - 2016-11-10 16:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:35:24 --> Input Class Initialized
INFO - 2016-11-10 16:35:24 --> Language Class Initialized
INFO - 2016-11-10 16:35:24 --> Loader Class Initialized
INFO - 2016-11-10 16:35:24 --> Helper loaded: url_helper
INFO - 2016-11-10 16:35:24 --> Helper loaded: form_helper
INFO - 2016-11-10 16:35:24 --> Database Driver Class Initialized
INFO - 2016-11-10 16:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:35:24 --> Controller Class Initialized
INFO - 2016-11-10 16:35:24 --> Model Class Initialized
INFO - 2016-11-10 16:35:24 --> Model Class Initialized
INFO - 2016-11-10 16:35:24 --> Model Class Initialized
INFO - 2016-11-10 16:35:24 --> Model Class Initialized
INFO - 2016-11-10 16:35:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:35:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:35:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:35:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:35:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:35:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:35:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:35:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:35:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:35:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:35:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:35:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:35:24 --> Final output sent to browser
DEBUG - 2016-11-10 16:35:24 --> Total execution time: 0.6104
INFO - 2016-11-10 16:38:52 --> Config Class Initialized
INFO - 2016-11-10 16:38:52 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:38:52 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:38:52 --> Utf8 Class Initialized
INFO - 2016-11-10 16:38:52 --> URI Class Initialized
INFO - 2016-11-10 16:38:52 --> Router Class Initialized
INFO - 2016-11-10 16:38:52 --> Output Class Initialized
INFO - 2016-11-10 16:38:52 --> Security Class Initialized
DEBUG - 2016-11-10 16:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:38:52 --> Input Class Initialized
INFO - 2016-11-10 16:38:52 --> Language Class Initialized
INFO - 2016-11-10 16:38:52 --> Loader Class Initialized
INFO - 2016-11-10 16:38:52 --> Helper loaded: url_helper
INFO - 2016-11-10 16:38:52 --> Helper loaded: form_helper
INFO - 2016-11-10 16:38:52 --> Database Driver Class Initialized
INFO - 2016-11-10 16:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:38:52 --> Controller Class Initialized
INFO - 2016-11-10 16:38:52 --> Model Class Initialized
INFO - 2016-11-10 16:38:52 --> Model Class Initialized
INFO - 2016-11-10 16:38:53 --> Model Class Initialized
INFO - 2016-11-10 16:38:53 --> Model Class Initialized
DEBUG - 2016-11-10 16:38:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 16:38:53 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 143
ERROR - 2016-11-10 16:38:53 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 143
INFO - 2016-11-10 16:38:53 --> Config Class Initialized
INFO - 2016-11-10 16:38:53 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:38:53 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:38:53 --> Utf8 Class Initialized
INFO - 2016-11-10 16:38:53 --> URI Class Initialized
DEBUG - 2016-11-10 16:38:53 --> No URI present. Default controller set.
INFO - 2016-11-10 16:38:53 --> Router Class Initialized
INFO - 2016-11-10 16:38:53 --> Output Class Initialized
INFO - 2016-11-10 16:38:53 --> Security Class Initialized
DEBUG - 2016-11-10 16:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:38:53 --> Input Class Initialized
INFO - 2016-11-10 16:38:53 --> Language Class Initialized
INFO - 2016-11-10 16:38:53 --> Loader Class Initialized
INFO - 2016-11-10 16:38:53 --> Helper loaded: url_helper
INFO - 2016-11-10 16:38:53 --> Helper loaded: form_helper
INFO - 2016-11-10 16:38:53 --> Database Driver Class Initialized
INFO - 2016-11-10 16:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:38:53 --> Controller Class Initialized
INFO - 2016-11-10 16:38:53 --> Model Class Initialized
INFO - 2016-11-10 16:38:53 --> Model Class Initialized
INFO - 2016-11-10 16:38:53 --> Model Class Initialized
INFO - 2016-11-10 16:38:53 --> Model Class Initialized
INFO - 2016-11-10 16:38:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:38:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 16:38:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:38:53 --> Final output sent to browser
DEBUG - 2016-11-10 16:38:53 --> Total execution time: 0.4009
INFO - 2016-11-10 16:39:02 --> Config Class Initialized
INFO - 2016-11-10 16:39:02 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:39:02 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:39:02 --> Utf8 Class Initialized
INFO - 2016-11-10 16:39:02 --> URI Class Initialized
INFO - 2016-11-10 16:39:02 --> Router Class Initialized
INFO - 2016-11-10 16:39:02 --> Output Class Initialized
INFO - 2016-11-10 16:39:02 --> Security Class Initialized
DEBUG - 2016-11-10 16:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:39:02 --> Input Class Initialized
INFO - 2016-11-10 16:39:02 --> Language Class Initialized
INFO - 2016-11-10 16:39:02 --> Loader Class Initialized
INFO - 2016-11-10 16:39:02 --> Helper loaded: url_helper
INFO - 2016-11-10 16:39:02 --> Helper loaded: form_helper
INFO - 2016-11-10 16:39:02 --> Database Driver Class Initialized
INFO - 2016-11-10 16:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:39:02 --> Controller Class Initialized
INFO - 2016-11-10 16:39:02 --> Model Class Initialized
INFO - 2016-11-10 16:39:02 --> Model Class Initialized
INFO - 2016-11-10 16:39:02 --> Model Class Initialized
INFO - 2016-11-10 16:39:02 --> Model Class Initialized
DEBUG - 2016-11-10 16:39:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 16:39:02 --> Model Class Initialized
INFO - 2016-11-10 16:39:02 --> Final output sent to browser
DEBUG - 2016-11-10 16:39:02 --> Total execution time: 0.3770
INFO - 2016-11-10 16:39:02 --> Config Class Initialized
INFO - 2016-11-10 16:39:02 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:39:02 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:39:02 --> Utf8 Class Initialized
INFO - 2016-11-10 16:39:02 --> URI Class Initialized
DEBUG - 2016-11-10 16:39:02 --> No URI present. Default controller set.
INFO - 2016-11-10 16:39:02 --> Router Class Initialized
INFO - 2016-11-10 16:39:02 --> Output Class Initialized
INFO - 2016-11-10 16:39:02 --> Security Class Initialized
DEBUG - 2016-11-10 16:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:39:02 --> Input Class Initialized
INFO - 2016-11-10 16:39:02 --> Language Class Initialized
INFO - 2016-11-10 16:39:02 --> Loader Class Initialized
INFO - 2016-11-10 16:39:02 --> Helper loaded: url_helper
INFO - 2016-11-10 16:39:02 --> Helper loaded: form_helper
INFO - 2016-11-10 16:39:02 --> Database Driver Class Initialized
INFO - 2016-11-10 16:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:39:02 --> Controller Class Initialized
INFO - 2016-11-10 16:39:02 --> Model Class Initialized
INFO - 2016-11-10 16:39:02 --> Model Class Initialized
INFO - 2016-11-10 16:39:02 --> Model Class Initialized
INFO - 2016-11-10 16:39:02 --> Model Class Initialized
INFO - 2016-11-10 16:39:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:39:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:39:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:39:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:39:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:39:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:39:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:39:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:39:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:39:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:39:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:39:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:39:03 --> Final output sent to browser
DEBUG - 2016-11-10 16:39:03 --> Total execution time: 0.5437
INFO - 2016-11-10 16:41:19 --> Config Class Initialized
INFO - 2016-11-10 16:41:19 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:41:19 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:41:19 --> Utf8 Class Initialized
INFO - 2016-11-10 16:41:19 --> URI Class Initialized
DEBUG - 2016-11-10 16:41:19 --> No URI present. Default controller set.
INFO - 2016-11-10 16:41:19 --> Router Class Initialized
INFO - 2016-11-10 16:41:19 --> Output Class Initialized
INFO - 2016-11-10 16:41:19 --> Security Class Initialized
DEBUG - 2016-11-10 16:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:41:19 --> Input Class Initialized
INFO - 2016-11-10 16:41:19 --> Language Class Initialized
INFO - 2016-11-10 16:41:19 --> Loader Class Initialized
INFO - 2016-11-10 16:41:19 --> Helper loaded: url_helper
INFO - 2016-11-10 16:41:19 --> Helper loaded: form_helper
INFO - 2016-11-10 16:41:20 --> Database Driver Class Initialized
INFO - 2016-11-10 16:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:41:20 --> Controller Class Initialized
INFO - 2016-11-10 16:41:20 --> Model Class Initialized
INFO - 2016-11-10 16:41:20 --> Model Class Initialized
INFO - 2016-11-10 16:41:20 --> Model Class Initialized
INFO - 2016-11-10 16:41:20 --> Model Class Initialized
INFO - 2016-11-10 16:41:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:41:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:41:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:41:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:41:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:41:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:41:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:41:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:41:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:41:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:41:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:41:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:41:20 --> Final output sent to browser
DEBUG - 2016-11-10 16:41:20 --> Total execution time: 0.6066
INFO - 2016-11-10 16:42:05 --> Config Class Initialized
INFO - 2016-11-10 16:42:05 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:42:05 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:42:05 --> Utf8 Class Initialized
INFO - 2016-11-10 16:42:05 --> URI Class Initialized
DEBUG - 2016-11-10 16:42:05 --> No URI present. Default controller set.
INFO - 2016-11-10 16:42:05 --> Router Class Initialized
INFO - 2016-11-10 16:42:05 --> Output Class Initialized
INFO - 2016-11-10 16:42:05 --> Security Class Initialized
DEBUG - 2016-11-10 16:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:42:05 --> Input Class Initialized
INFO - 2016-11-10 16:42:05 --> Language Class Initialized
INFO - 2016-11-10 16:42:05 --> Loader Class Initialized
INFO - 2016-11-10 16:42:05 --> Helper loaded: url_helper
INFO - 2016-11-10 16:42:05 --> Helper loaded: form_helper
INFO - 2016-11-10 16:42:05 --> Database Driver Class Initialized
INFO - 2016-11-10 16:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:42:05 --> Controller Class Initialized
INFO - 2016-11-10 16:42:05 --> Model Class Initialized
INFO - 2016-11-10 16:42:05 --> Model Class Initialized
INFO - 2016-11-10 16:42:05 --> Model Class Initialized
INFO - 2016-11-10 16:42:05 --> Model Class Initialized
INFO - 2016-11-10 16:42:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:42:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:42:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:42:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:42:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:42:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:42:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:42:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:42:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:42:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:42:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:42:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:42:05 --> Final output sent to browser
DEBUG - 2016-11-10 16:42:05 --> Total execution time: 0.6070
INFO - 2016-11-10 16:42:37 --> Config Class Initialized
INFO - 2016-11-10 16:42:37 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:42:37 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:42:37 --> Utf8 Class Initialized
INFO - 2016-11-10 16:42:37 --> URI Class Initialized
DEBUG - 2016-11-10 16:42:37 --> No URI present. Default controller set.
INFO - 2016-11-10 16:42:37 --> Router Class Initialized
INFO - 2016-11-10 16:42:37 --> Output Class Initialized
INFO - 2016-11-10 16:42:37 --> Security Class Initialized
DEBUG - 2016-11-10 16:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:42:37 --> Input Class Initialized
INFO - 2016-11-10 16:42:37 --> Language Class Initialized
INFO - 2016-11-10 16:42:37 --> Loader Class Initialized
INFO - 2016-11-10 16:42:37 --> Helper loaded: url_helper
INFO - 2016-11-10 16:42:37 --> Helper loaded: form_helper
INFO - 2016-11-10 16:42:37 --> Database Driver Class Initialized
INFO - 2016-11-10 16:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:42:37 --> Controller Class Initialized
INFO - 2016-11-10 16:42:37 --> Model Class Initialized
INFO - 2016-11-10 16:42:37 --> Model Class Initialized
INFO - 2016-11-10 16:42:37 --> Model Class Initialized
INFO - 2016-11-10 16:42:37 --> Model Class Initialized
INFO - 2016-11-10 16:42:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:42:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 16:42:37 --> Severity: Notice --> Undefined variable: queryLeaveRecord C:\xampp\htdocs\LMS\app\controllers\Auth.php 85
INFO - 2016-11-10 16:42:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:42:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:42:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:42:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:42:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:42:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
ERROR - 2016-11-10 16:42:37 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 14
INFO - 2016-11-10 16:44:42 --> Config Class Initialized
INFO - 2016-11-10 16:44:42 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:44:42 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:44:42 --> Utf8 Class Initialized
INFO - 2016-11-10 16:44:42 --> URI Class Initialized
DEBUG - 2016-11-10 16:44:42 --> No URI present. Default controller set.
INFO - 2016-11-10 16:44:42 --> Router Class Initialized
INFO - 2016-11-10 16:44:42 --> Output Class Initialized
INFO - 2016-11-10 16:44:42 --> Security Class Initialized
DEBUG - 2016-11-10 16:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:44:42 --> Input Class Initialized
INFO - 2016-11-10 16:44:42 --> Language Class Initialized
INFO - 2016-11-10 16:44:42 --> Loader Class Initialized
INFO - 2016-11-10 16:44:42 --> Helper loaded: url_helper
INFO - 2016-11-10 16:44:42 --> Helper loaded: form_helper
INFO - 2016-11-10 16:44:42 --> Database Driver Class Initialized
INFO - 2016-11-10 16:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:44:42 --> Controller Class Initialized
INFO - 2016-11-10 16:44:42 --> Model Class Initialized
INFO - 2016-11-10 16:44:42 --> Model Class Initialized
INFO - 2016-11-10 16:44:42 --> Model Class Initialized
INFO - 2016-11-10 16:44:42 --> Model Class Initialized
INFO - 2016-11-10 16:44:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:44:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:44:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:44:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:44:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:44:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:44:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:44:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
ERROR - 2016-11-10 16:44:43 --> Severity: Notice --> Undefined variable: all_leave_records_data C:\xampp\htdocs\LMS\app\views\dashboard.php 123
ERROR - 2016-11-10 16:44:43 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 14
INFO - 2016-11-10 16:45:08 --> Config Class Initialized
INFO - 2016-11-10 16:45:08 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:45:08 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:45:08 --> Utf8 Class Initialized
INFO - 2016-11-10 16:45:08 --> URI Class Initialized
DEBUG - 2016-11-10 16:45:08 --> No URI present. Default controller set.
INFO - 2016-11-10 16:45:08 --> Router Class Initialized
INFO - 2016-11-10 16:45:08 --> Output Class Initialized
INFO - 2016-11-10 16:45:08 --> Security Class Initialized
DEBUG - 2016-11-10 16:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:45:08 --> Input Class Initialized
INFO - 2016-11-10 16:45:08 --> Language Class Initialized
INFO - 2016-11-10 16:45:08 --> Loader Class Initialized
INFO - 2016-11-10 16:45:08 --> Helper loaded: url_helper
INFO - 2016-11-10 16:45:08 --> Helper loaded: form_helper
INFO - 2016-11-10 16:45:08 --> Database Driver Class Initialized
INFO - 2016-11-10 16:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:45:08 --> Controller Class Initialized
INFO - 2016-11-10 16:45:08 --> Model Class Initialized
INFO - 2016-11-10 16:45:08 --> Model Class Initialized
INFO - 2016-11-10 16:45:08 --> Model Class Initialized
INFO - 2016-11-10 16:45:08 --> Model Class Initialized
INFO - 2016-11-10 16:45:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:45:09 --> Final output sent to browser
DEBUG - 2016-11-10 16:45:09 --> Total execution time: 0.5718
INFO - 2016-11-10 16:48:22 --> Config Class Initialized
INFO - 2016-11-10 16:48:22 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:48:22 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:48:22 --> Utf8 Class Initialized
INFO - 2016-11-10 16:48:22 --> URI Class Initialized
DEBUG - 2016-11-10 16:48:22 --> No URI present. Default controller set.
INFO - 2016-11-10 16:48:22 --> Router Class Initialized
INFO - 2016-11-10 16:48:22 --> Output Class Initialized
INFO - 2016-11-10 16:48:22 --> Security Class Initialized
DEBUG - 2016-11-10 16:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:48:22 --> Input Class Initialized
INFO - 2016-11-10 16:48:22 --> Language Class Initialized
INFO - 2016-11-10 16:48:22 --> Loader Class Initialized
INFO - 2016-11-10 16:48:22 --> Helper loaded: url_helper
INFO - 2016-11-10 16:48:22 --> Helper loaded: form_helper
INFO - 2016-11-10 16:48:22 --> Database Driver Class Initialized
INFO - 2016-11-10 16:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:48:22 --> Controller Class Initialized
INFO - 2016-11-10 16:48:22 --> Model Class Initialized
INFO - 2016-11-10 16:48:22 --> Model Class Initialized
INFO - 2016-11-10 16:48:22 --> Model Class Initialized
INFO - 2016-11-10 16:48:22 --> Model Class Initialized
INFO - 2016-11-10 16:48:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:48:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:48:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:48:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:48:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:48:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:48:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:48:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:48:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:48:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:48:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:48:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:48:23 --> Final output sent to browser
DEBUG - 2016-11-10 16:48:23 --> Total execution time: 0.5865
INFO - 2016-11-10 16:48:43 --> Config Class Initialized
INFO - 2016-11-10 16:48:43 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:48:43 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:48:43 --> Utf8 Class Initialized
INFO - 2016-11-10 16:48:43 --> URI Class Initialized
INFO - 2016-11-10 16:48:43 --> Router Class Initialized
INFO - 2016-11-10 16:48:43 --> Output Class Initialized
INFO - 2016-11-10 16:48:43 --> Security Class Initialized
DEBUG - 2016-11-10 16:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:48:43 --> Input Class Initialized
INFO - 2016-11-10 16:48:43 --> Language Class Initialized
INFO - 2016-11-10 16:48:43 --> Loader Class Initialized
INFO - 2016-11-10 16:48:43 --> Helper loaded: url_helper
INFO - 2016-11-10 16:48:43 --> Helper loaded: form_helper
INFO - 2016-11-10 16:48:43 --> Database Driver Class Initialized
INFO - 2016-11-10 16:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:48:44 --> Controller Class Initialized
INFO - 2016-11-10 16:48:44 --> Model Class Initialized
INFO - 2016-11-10 16:48:44 --> Model Class Initialized
INFO - 2016-11-10 16:48:44 --> Model Class Initialized
INFO - 2016-11-10 16:48:44 --> Model Class Initialized
DEBUG - 2016-11-10 16:48:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 16:48:44 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 143
ERROR - 2016-11-10 16:48:44 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 143
INFO - 2016-11-10 16:48:44 --> Config Class Initialized
INFO - 2016-11-10 16:48:44 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:48:44 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:48:44 --> Utf8 Class Initialized
INFO - 2016-11-10 16:48:44 --> URI Class Initialized
DEBUG - 2016-11-10 16:48:44 --> No URI present. Default controller set.
INFO - 2016-11-10 16:48:44 --> Router Class Initialized
INFO - 2016-11-10 16:48:44 --> Output Class Initialized
INFO - 2016-11-10 16:48:44 --> Security Class Initialized
DEBUG - 2016-11-10 16:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:48:44 --> Input Class Initialized
INFO - 2016-11-10 16:48:44 --> Language Class Initialized
INFO - 2016-11-10 16:48:44 --> Loader Class Initialized
INFO - 2016-11-10 16:48:44 --> Helper loaded: url_helper
INFO - 2016-11-10 16:48:44 --> Helper loaded: form_helper
INFO - 2016-11-10 16:48:44 --> Database Driver Class Initialized
INFO - 2016-11-10 16:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:48:44 --> Controller Class Initialized
INFO - 2016-11-10 16:48:44 --> Model Class Initialized
INFO - 2016-11-10 16:48:44 --> Model Class Initialized
INFO - 2016-11-10 16:48:44 --> Model Class Initialized
INFO - 2016-11-10 16:48:44 --> Model Class Initialized
INFO - 2016-11-10 16:48:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:48:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 16:48:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:48:44 --> Final output sent to browser
DEBUG - 2016-11-10 16:48:44 --> Total execution time: 0.4124
INFO - 2016-11-10 16:48:57 --> Config Class Initialized
INFO - 2016-11-10 16:48:57 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:48:57 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:48:57 --> Utf8 Class Initialized
INFO - 2016-11-10 16:48:57 --> URI Class Initialized
INFO - 2016-11-10 16:48:57 --> Router Class Initialized
INFO - 2016-11-10 16:48:57 --> Output Class Initialized
INFO - 2016-11-10 16:48:57 --> Security Class Initialized
DEBUG - 2016-11-10 16:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:48:57 --> Input Class Initialized
INFO - 2016-11-10 16:48:57 --> Language Class Initialized
INFO - 2016-11-10 16:48:57 --> Loader Class Initialized
INFO - 2016-11-10 16:48:57 --> Helper loaded: url_helper
INFO - 2016-11-10 16:48:57 --> Helper loaded: form_helper
INFO - 2016-11-10 16:48:57 --> Database Driver Class Initialized
INFO - 2016-11-10 16:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:48:57 --> Controller Class Initialized
INFO - 2016-11-10 16:48:57 --> Model Class Initialized
INFO - 2016-11-10 16:48:57 --> Model Class Initialized
INFO - 2016-11-10 16:48:57 --> Model Class Initialized
INFO - 2016-11-10 16:48:57 --> Model Class Initialized
DEBUG - 2016-11-10 16:48:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 16:48:57 --> Model Class Initialized
INFO - 2016-11-10 16:48:57 --> Final output sent to browser
DEBUG - 2016-11-10 16:48:57 --> Total execution time: 0.3539
INFO - 2016-11-10 16:48:57 --> Config Class Initialized
INFO - 2016-11-10 16:48:57 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:48:57 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:48:57 --> Utf8 Class Initialized
INFO - 2016-11-10 16:48:57 --> URI Class Initialized
DEBUG - 2016-11-10 16:48:57 --> No URI present. Default controller set.
INFO - 2016-11-10 16:48:57 --> Router Class Initialized
INFO - 2016-11-10 16:48:57 --> Output Class Initialized
INFO - 2016-11-10 16:48:57 --> Security Class Initialized
DEBUG - 2016-11-10 16:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:48:57 --> Input Class Initialized
INFO - 2016-11-10 16:48:57 --> Language Class Initialized
INFO - 2016-11-10 16:48:57 --> Loader Class Initialized
INFO - 2016-11-10 16:48:57 --> Helper loaded: url_helper
INFO - 2016-11-10 16:48:57 --> Helper loaded: form_helper
INFO - 2016-11-10 16:48:57 --> Database Driver Class Initialized
INFO - 2016-11-10 16:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:48:58 --> Controller Class Initialized
INFO - 2016-11-10 16:48:58 --> Model Class Initialized
INFO - 2016-11-10 16:48:58 --> Model Class Initialized
INFO - 2016-11-10 16:48:58 --> Model Class Initialized
INFO - 2016-11-10 16:48:58 --> Model Class Initialized
INFO - 2016-11-10 16:48:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:48:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:48:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:48:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:48:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:48:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:48:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:48:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:48:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:48:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:48:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:48:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:48:58 --> Final output sent to browser
DEBUG - 2016-11-10 16:48:58 --> Total execution time: 0.5676
INFO - 2016-11-10 16:51:15 --> Config Class Initialized
INFO - 2016-11-10 16:51:15 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:51:15 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:51:15 --> Utf8 Class Initialized
INFO - 2016-11-10 16:51:15 --> URI Class Initialized
DEBUG - 2016-11-10 16:51:15 --> No URI present. Default controller set.
INFO - 2016-11-10 16:51:15 --> Router Class Initialized
INFO - 2016-11-10 16:51:15 --> Output Class Initialized
INFO - 2016-11-10 16:51:15 --> Security Class Initialized
DEBUG - 2016-11-10 16:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:51:15 --> Input Class Initialized
INFO - 2016-11-10 16:51:15 --> Language Class Initialized
INFO - 2016-11-10 16:51:15 --> Loader Class Initialized
INFO - 2016-11-10 16:51:15 --> Helper loaded: url_helper
INFO - 2016-11-10 16:51:15 --> Helper loaded: form_helper
INFO - 2016-11-10 16:51:15 --> Database Driver Class Initialized
INFO - 2016-11-10 16:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:51:15 --> Controller Class Initialized
INFO - 2016-11-10 16:51:15 --> Model Class Initialized
INFO - 2016-11-10 16:51:16 --> Model Class Initialized
INFO - 2016-11-10 16:51:16 --> Model Class Initialized
INFO - 2016-11-10 16:51:16 --> Model Class Initialized
INFO - 2016-11-10 16:51:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:51:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 16:51:16 --> Severity: Error --> Call to undefined method Leave_record_m::all_leave_record() C:\xampp\htdocs\LMS\app\controllers\Auth.php 66
INFO - 2016-11-10 16:52:27 --> Config Class Initialized
INFO - 2016-11-10 16:52:27 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:52:27 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:52:27 --> Utf8 Class Initialized
INFO - 2016-11-10 16:52:27 --> URI Class Initialized
DEBUG - 2016-11-10 16:52:27 --> No URI present. Default controller set.
INFO - 2016-11-10 16:52:27 --> Router Class Initialized
INFO - 2016-11-10 16:52:27 --> Output Class Initialized
INFO - 2016-11-10 16:52:27 --> Security Class Initialized
DEBUG - 2016-11-10 16:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:52:27 --> Input Class Initialized
INFO - 2016-11-10 16:52:27 --> Language Class Initialized
INFO - 2016-11-10 16:52:27 --> Loader Class Initialized
INFO - 2016-11-10 16:52:27 --> Helper loaded: url_helper
INFO - 2016-11-10 16:52:27 --> Helper loaded: form_helper
INFO - 2016-11-10 16:52:27 --> Database Driver Class Initialized
INFO - 2016-11-10 16:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:52:27 --> Controller Class Initialized
INFO - 2016-11-10 16:52:27 --> Model Class Initialized
INFO - 2016-11-10 16:52:27 --> Model Class Initialized
INFO - 2016-11-10 16:52:27 --> Model Class Initialized
INFO - 2016-11-10 16:52:27 --> Model Class Initialized
INFO - 2016-11-10 16:52:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:52:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 16:52:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\LMS\sys\database\DB_query_builder.php 669
ERROR - 2016-11-10 16:52:27 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `em`.`surname`, `lt`.`name`, `lv`.`numberOfLeaves`, `lv`.`description`
FROM `leaveRecord` `lv`
LEFT JOIN `employee` as `em` ON `em`.`id` = `lv`.`idEmployee`
LEFT JOIN `leaveType` as `lt` ON `lt`.`id` = `lv`.`idLeaveType`
WHERE `em`.`idRole` = `Array`
INFO - 2016-11-10 16:52:27 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 16:53:20 --> Config Class Initialized
INFO - 2016-11-10 16:53:20 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:53:20 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:53:20 --> Utf8 Class Initialized
INFO - 2016-11-10 16:53:20 --> URI Class Initialized
INFO - 2016-11-10 16:53:20 --> Router Class Initialized
INFO - 2016-11-10 16:53:20 --> Output Class Initialized
INFO - 2016-11-10 16:53:20 --> Security Class Initialized
DEBUG - 2016-11-10 16:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:53:20 --> Input Class Initialized
INFO - 2016-11-10 16:53:20 --> Language Class Initialized
INFO - 2016-11-10 16:53:20 --> Loader Class Initialized
INFO - 2016-11-10 16:53:20 --> Helper loaded: url_helper
INFO - 2016-11-10 16:53:20 --> Helper loaded: form_helper
INFO - 2016-11-10 16:53:20 --> Database Driver Class Initialized
INFO - 2016-11-10 16:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:53:20 --> Controller Class Initialized
INFO - 2016-11-10 16:53:20 --> Model Class Initialized
INFO - 2016-11-10 16:53:20 --> Model Class Initialized
INFO - 2016-11-10 16:53:20 --> Model Class Initialized
INFO - 2016-11-10 16:53:20 --> Model Class Initialized
DEBUG - 2016-11-10 16:53:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 16:53:20 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 140
ERROR - 2016-11-10 16:53:20 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 140
INFO - 2016-11-10 16:53:20 --> Config Class Initialized
INFO - 2016-11-10 16:53:20 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:53:20 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:53:20 --> Utf8 Class Initialized
INFO - 2016-11-10 16:53:20 --> URI Class Initialized
DEBUG - 2016-11-10 16:53:20 --> No URI present. Default controller set.
INFO - 2016-11-10 16:53:20 --> Router Class Initialized
INFO - 2016-11-10 16:53:20 --> Output Class Initialized
INFO - 2016-11-10 16:53:20 --> Security Class Initialized
DEBUG - 2016-11-10 16:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:53:20 --> Input Class Initialized
INFO - 2016-11-10 16:53:20 --> Language Class Initialized
INFO - 2016-11-10 16:53:20 --> Loader Class Initialized
INFO - 2016-11-10 16:53:20 --> Helper loaded: url_helper
INFO - 2016-11-10 16:53:21 --> Helper loaded: form_helper
INFO - 2016-11-10 16:53:21 --> Database Driver Class Initialized
INFO - 2016-11-10 16:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:53:21 --> Controller Class Initialized
INFO - 2016-11-10 16:53:21 --> Model Class Initialized
INFO - 2016-11-10 16:53:21 --> Model Class Initialized
INFO - 2016-11-10 16:53:21 --> Model Class Initialized
INFO - 2016-11-10 16:53:21 --> Model Class Initialized
INFO - 2016-11-10 16:53:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:53:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 16:53:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:53:21 --> Final output sent to browser
DEBUG - 2016-11-10 16:53:21 --> Total execution time: 0.4188
INFO - 2016-11-10 16:53:34 --> Config Class Initialized
INFO - 2016-11-10 16:53:34 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:53:34 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:53:34 --> Utf8 Class Initialized
INFO - 2016-11-10 16:53:34 --> URI Class Initialized
INFO - 2016-11-10 16:53:34 --> Router Class Initialized
INFO - 2016-11-10 16:53:34 --> Output Class Initialized
INFO - 2016-11-10 16:53:34 --> Security Class Initialized
DEBUG - 2016-11-10 16:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:53:34 --> Input Class Initialized
INFO - 2016-11-10 16:53:34 --> Language Class Initialized
INFO - 2016-11-10 16:53:34 --> Loader Class Initialized
INFO - 2016-11-10 16:53:34 --> Helper loaded: url_helper
INFO - 2016-11-10 16:53:34 --> Helper loaded: form_helper
INFO - 2016-11-10 16:53:34 --> Database Driver Class Initialized
INFO - 2016-11-10 16:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:53:34 --> Controller Class Initialized
INFO - 2016-11-10 16:53:34 --> Model Class Initialized
INFO - 2016-11-10 16:53:34 --> Model Class Initialized
INFO - 2016-11-10 16:53:34 --> Model Class Initialized
INFO - 2016-11-10 16:53:34 --> Model Class Initialized
DEBUG - 2016-11-10 16:53:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 16:53:34 --> Model Class Initialized
INFO - 2016-11-10 16:53:34 --> Final output sent to browser
DEBUG - 2016-11-10 16:53:34 --> Total execution time: 0.3645
INFO - 2016-11-10 16:53:38 --> Config Class Initialized
INFO - 2016-11-10 16:53:38 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:53:38 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:53:38 --> Utf8 Class Initialized
INFO - 2016-11-10 16:53:38 --> URI Class Initialized
INFO - 2016-11-10 16:53:38 --> Router Class Initialized
INFO - 2016-11-10 16:53:38 --> Output Class Initialized
INFO - 2016-11-10 16:53:38 --> Security Class Initialized
DEBUG - 2016-11-10 16:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:53:38 --> Input Class Initialized
INFO - 2016-11-10 16:53:38 --> Language Class Initialized
INFO - 2016-11-10 16:53:38 --> Loader Class Initialized
INFO - 2016-11-10 16:53:38 --> Helper loaded: url_helper
INFO - 2016-11-10 16:53:38 --> Helper loaded: form_helper
INFO - 2016-11-10 16:53:38 --> Database Driver Class Initialized
INFO - 2016-11-10 16:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:53:38 --> Controller Class Initialized
INFO - 2016-11-10 16:53:38 --> Model Class Initialized
INFO - 2016-11-10 16:53:38 --> Model Class Initialized
INFO - 2016-11-10 16:53:38 --> Model Class Initialized
INFO - 2016-11-10 16:53:38 --> Model Class Initialized
DEBUG - 2016-11-10 16:53:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 16:53:38 --> Model Class Initialized
INFO - 2016-11-10 16:53:38 --> Final output sent to browser
DEBUG - 2016-11-10 16:53:38 --> Total execution time: 0.3561
INFO - 2016-11-10 16:53:39 --> Config Class Initialized
INFO - 2016-11-10 16:53:39 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:53:39 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:53:39 --> Utf8 Class Initialized
INFO - 2016-11-10 16:53:39 --> URI Class Initialized
DEBUG - 2016-11-10 16:53:39 --> No URI present. Default controller set.
INFO - 2016-11-10 16:53:39 --> Router Class Initialized
INFO - 2016-11-10 16:53:39 --> Output Class Initialized
INFO - 2016-11-10 16:53:39 --> Security Class Initialized
DEBUG - 2016-11-10 16:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:53:39 --> Input Class Initialized
INFO - 2016-11-10 16:53:39 --> Language Class Initialized
INFO - 2016-11-10 16:53:39 --> Loader Class Initialized
INFO - 2016-11-10 16:53:39 --> Helper loaded: url_helper
INFO - 2016-11-10 16:53:39 --> Helper loaded: form_helper
INFO - 2016-11-10 16:53:39 --> Database Driver Class Initialized
INFO - 2016-11-10 16:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:53:39 --> Controller Class Initialized
INFO - 2016-11-10 16:53:39 --> Model Class Initialized
INFO - 2016-11-10 16:53:39 --> Model Class Initialized
INFO - 2016-11-10 16:53:39 --> Model Class Initialized
INFO - 2016-11-10 16:53:39 --> Model Class Initialized
INFO - 2016-11-10 16:53:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:53:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 16:53:39 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\LMS\sys\database\DB_query_builder.php 669
ERROR - 2016-11-10 16:53:39 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `em`.`surname`, `lt`.`name`, `lv`.`numberOfLeaves`, `lv`.`description`
FROM `leaveRecord` `lv`
LEFT JOIN `employee` as `em` ON `em`.`id` = `lv`.`idEmployee`
LEFT JOIN `leaveType` as `lt` ON `lt`.`id` = `lv`.`idLeaveType`
WHERE `em`.`idRole` = `Array`
INFO - 2016-11-10 16:53:39 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 16:54:02 --> Config Class Initialized
INFO - 2016-11-10 16:54:02 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:54:02 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:54:02 --> Utf8 Class Initialized
INFO - 2016-11-10 16:54:02 --> URI Class Initialized
DEBUG - 2016-11-10 16:54:02 --> No URI present. Default controller set.
INFO - 2016-11-10 16:54:02 --> Router Class Initialized
INFO - 2016-11-10 16:54:02 --> Output Class Initialized
INFO - 2016-11-10 16:54:02 --> Security Class Initialized
DEBUG - 2016-11-10 16:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:54:02 --> Input Class Initialized
INFO - 2016-11-10 16:54:02 --> Language Class Initialized
INFO - 2016-11-10 16:54:02 --> Loader Class Initialized
INFO - 2016-11-10 16:54:02 --> Helper loaded: url_helper
INFO - 2016-11-10 16:54:02 --> Helper loaded: form_helper
INFO - 2016-11-10 16:54:02 --> Database Driver Class Initialized
INFO - 2016-11-10 16:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:54:02 --> Controller Class Initialized
INFO - 2016-11-10 16:54:02 --> Model Class Initialized
INFO - 2016-11-10 16:54:02 --> Model Class Initialized
INFO - 2016-11-10 16:54:02 --> Model Class Initialized
INFO - 2016-11-10 16:54:02 --> Model Class Initialized
INFO - 2016-11-10 16:54:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:54:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 16:54:02 --> Severity: Error --> Call to undefined method Leave_record_m::all_leave_record() C:\xampp\htdocs\LMS\app\controllers\Auth.php 66
INFO - 2016-11-10 16:54:18 --> Config Class Initialized
INFO - 2016-11-10 16:54:18 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:54:18 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:54:18 --> Utf8 Class Initialized
INFO - 2016-11-10 16:54:18 --> URI Class Initialized
DEBUG - 2016-11-10 16:54:18 --> No URI present. Default controller set.
INFO - 2016-11-10 16:54:18 --> Router Class Initialized
INFO - 2016-11-10 16:54:18 --> Output Class Initialized
INFO - 2016-11-10 16:54:18 --> Security Class Initialized
DEBUG - 2016-11-10 16:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:54:18 --> Input Class Initialized
INFO - 2016-11-10 16:54:18 --> Language Class Initialized
INFO - 2016-11-10 16:54:18 --> Loader Class Initialized
INFO - 2016-11-10 16:54:18 --> Helper loaded: url_helper
INFO - 2016-11-10 16:54:18 --> Helper loaded: form_helper
INFO - 2016-11-10 16:54:18 --> Database Driver Class Initialized
INFO - 2016-11-10 16:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:54:18 --> Controller Class Initialized
INFO - 2016-11-10 16:54:18 --> Model Class Initialized
INFO - 2016-11-10 16:54:18 --> Model Class Initialized
INFO - 2016-11-10 16:54:18 --> Model Class Initialized
INFO - 2016-11-10 16:54:18 --> Model Class Initialized
INFO - 2016-11-10 16:54:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:54:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 16:54:18 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\LMS\sys\database\DB_query_builder.php 669
ERROR - 2016-11-10 16:54:18 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `em`.`surname`, `lt`.`name`, `lv`.`numberOfLeaves`, `lv`.`description`
FROM `leaveRecord` `lv`
LEFT JOIN `employee` as `em` ON `em`.`id` = `lv`.`idEmployee`
LEFT JOIN `leaveType` as `lt` ON `lt`.`id` = `lv`.`idLeaveType`
WHERE `em`.`idRole` = `Array`
INFO - 2016-11-10 16:54:18 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 16:54:30 --> Config Class Initialized
INFO - 2016-11-10 16:54:30 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:54:30 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:54:31 --> Utf8 Class Initialized
INFO - 2016-11-10 16:54:31 --> URI Class Initialized
DEBUG - 2016-11-10 16:54:31 --> No URI present. Default controller set.
INFO - 2016-11-10 16:54:31 --> Router Class Initialized
INFO - 2016-11-10 16:54:31 --> Output Class Initialized
INFO - 2016-11-10 16:54:31 --> Security Class Initialized
DEBUG - 2016-11-10 16:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:54:31 --> Input Class Initialized
INFO - 2016-11-10 16:54:31 --> Language Class Initialized
INFO - 2016-11-10 16:54:31 --> Loader Class Initialized
INFO - 2016-11-10 16:54:31 --> Helper loaded: url_helper
INFO - 2016-11-10 16:54:31 --> Helper loaded: form_helper
INFO - 2016-11-10 16:54:31 --> Database Driver Class Initialized
INFO - 2016-11-10 16:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:54:31 --> Controller Class Initialized
INFO - 2016-11-10 16:54:31 --> Model Class Initialized
INFO - 2016-11-10 16:54:31 --> Model Class Initialized
INFO - 2016-11-10 16:54:31 --> Model Class Initialized
INFO - 2016-11-10 16:54:31 --> Model Class Initialized
INFO - 2016-11-10 16:54:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:54:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 16:54:31 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\LMS\sys\database\DB_query_builder.php 669
ERROR - 2016-11-10 16:54:31 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `em`.`surname`, `lt`.`name`, `lv`.`numberOfLeaves`, `lv`.`description`
FROM `leaveRecord` `lv`
LEFT JOIN `employee` as `em` ON `em`.`id` = `lv`.`idEmployee`
LEFT JOIN `leaveType` as `lt` ON `lt`.`id` = `lv`.`idLeaveType`
WHERE `em`.`idRole` = `Array`
INFO - 2016-11-10 16:54:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 16:54:32 --> Config Class Initialized
INFO - 2016-11-10 16:54:32 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:54:32 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:54:32 --> Utf8 Class Initialized
INFO - 2016-11-10 16:54:32 --> URI Class Initialized
DEBUG - 2016-11-10 16:54:32 --> No URI present. Default controller set.
INFO - 2016-11-10 16:54:32 --> Router Class Initialized
INFO - 2016-11-10 16:54:32 --> Output Class Initialized
INFO - 2016-11-10 16:54:32 --> Security Class Initialized
DEBUG - 2016-11-10 16:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:54:32 --> Input Class Initialized
INFO - 2016-11-10 16:54:32 --> Language Class Initialized
INFO - 2016-11-10 16:54:32 --> Loader Class Initialized
INFO - 2016-11-10 16:54:32 --> Helper loaded: url_helper
INFO - 2016-11-10 16:54:32 --> Helper loaded: form_helper
INFO - 2016-11-10 16:54:32 --> Database Driver Class Initialized
INFO - 2016-11-10 16:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:54:32 --> Controller Class Initialized
INFO - 2016-11-10 16:54:32 --> Model Class Initialized
INFO - 2016-11-10 16:54:32 --> Model Class Initialized
INFO - 2016-11-10 16:54:32 --> Model Class Initialized
INFO - 2016-11-10 16:54:32 --> Model Class Initialized
INFO - 2016-11-10 16:54:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:54:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 16:54:33 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\LMS\sys\database\DB_query_builder.php 669
ERROR - 2016-11-10 16:54:33 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `em`.`surname`, `lt`.`name`, `lv`.`numberOfLeaves`, `lv`.`description`
FROM `leaveRecord` `lv`
LEFT JOIN `employee` as `em` ON `em`.`id` = `lv`.`idEmployee`
LEFT JOIN `leaveType` as `lt` ON `lt`.`id` = `lv`.`idLeaveType`
WHERE `em`.`idRole` = `Array`
INFO - 2016-11-10 16:54:33 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 16:55:12 --> Config Class Initialized
INFO - 2016-11-10 16:55:12 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:55:12 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:55:12 --> Utf8 Class Initialized
INFO - 2016-11-10 16:55:12 --> URI Class Initialized
DEBUG - 2016-11-10 16:55:12 --> No URI present. Default controller set.
INFO - 2016-11-10 16:55:12 --> Router Class Initialized
INFO - 2016-11-10 16:55:12 --> Output Class Initialized
INFO - 2016-11-10 16:55:12 --> Security Class Initialized
DEBUG - 2016-11-10 16:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:55:12 --> Input Class Initialized
INFO - 2016-11-10 16:55:12 --> Language Class Initialized
INFO - 2016-11-10 16:55:12 --> Loader Class Initialized
INFO - 2016-11-10 16:55:12 --> Helper loaded: url_helper
INFO - 2016-11-10 16:55:12 --> Helper loaded: form_helper
INFO - 2016-11-10 16:55:12 --> Database Driver Class Initialized
INFO - 2016-11-10 16:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:55:12 --> Controller Class Initialized
INFO - 2016-11-10 16:55:12 --> Model Class Initialized
INFO - 2016-11-10 16:55:12 --> Model Class Initialized
INFO - 2016-11-10 16:55:12 --> Model Class Initialized
INFO - 2016-11-10 16:55:12 --> Model Class Initialized
INFO - 2016-11-10 16:55:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:55:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:55:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:55:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:55:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:55:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:55:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:55:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:55:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:55:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:55:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:55:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:55:12 --> Final output sent to browser
DEBUG - 2016-11-10 16:55:12 --> Total execution time: 0.5708
INFO - 2016-11-10 16:57:01 --> Config Class Initialized
INFO - 2016-11-10 16:57:01 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:57:01 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:57:01 --> Utf8 Class Initialized
INFO - 2016-11-10 16:57:01 --> URI Class Initialized
DEBUG - 2016-11-10 16:57:01 --> No URI present. Default controller set.
INFO - 2016-11-10 16:57:01 --> Router Class Initialized
INFO - 2016-11-10 16:57:01 --> Output Class Initialized
INFO - 2016-11-10 16:57:01 --> Security Class Initialized
DEBUG - 2016-11-10 16:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:57:01 --> Input Class Initialized
INFO - 2016-11-10 16:57:01 --> Language Class Initialized
INFO - 2016-11-10 16:57:01 --> Loader Class Initialized
INFO - 2016-11-10 16:57:01 --> Helper loaded: url_helper
INFO - 2016-11-10 16:57:01 --> Helper loaded: form_helper
INFO - 2016-11-10 16:57:01 --> Database Driver Class Initialized
INFO - 2016-11-10 16:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:57:01 --> Controller Class Initialized
INFO - 2016-11-10 16:57:01 --> Model Class Initialized
INFO - 2016-11-10 16:57:01 --> Model Class Initialized
INFO - 2016-11-10 16:57:01 --> Model Class Initialized
INFO - 2016-11-10 16:57:01 --> Model Class Initialized
INFO - 2016-11-10 16:57:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:57:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:57:02 --> Final output sent to browser
DEBUG - 2016-11-10 16:57:02 --> Total execution time: 0.5757
INFO - 2016-11-10 16:58:30 --> Config Class Initialized
INFO - 2016-11-10 16:58:30 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:58:30 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:58:30 --> Utf8 Class Initialized
INFO - 2016-11-10 16:58:30 --> URI Class Initialized
DEBUG - 2016-11-10 16:58:30 --> No URI present. Default controller set.
INFO - 2016-11-10 16:58:30 --> Router Class Initialized
INFO - 2016-11-10 16:58:30 --> Output Class Initialized
INFO - 2016-11-10 16:58:30 --> Security Class Initialized
DEBUG - 2016-11-10 16:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:58:30 --> Input Class Initialized
INFO - 2016-11-10 16:58:30 --> Language Class Initialized
INFO - 2016-11-10 16:58:30 --> Loader Class Initialized
INFO - 2016-11-10 16:58:30 --> Helper loaded: url_helper
INFO - 2016-11-10 16:58:30 --> Helper loaded: form_helper
INFO - 2016-11-10 16:58:30 --> Database Driver Class Initialized
INFO - 2016-11-10 16:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:58:30 --> Controller Class Initialized
INFO - 2016-11-10 16:58:30 --> Model Class Initialized
INFO - 2016-11-10 16:58:30 --> Model Class Initialized
INFO - 2016-11-10 16:58:30 --> Model Class Initialized
INFO - 2016-11-10 16:58:30 --> Model Class Initialized
INFO - 2016-11-10 16:58:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:58:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:58:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:58:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:58:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:58:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:58:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:58:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:58:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:58:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:58:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:58:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:58:31 --> Final output sent to browser
DEBUG - 2016-11-10 16:58:31 --> Total execution time: 0.5580
INFO - 2016-11-10 16:58:44 --> Config Class Initialized
INFO - 2016-11-10 16:58:44 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:58:44 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:58:44 --> Utf8 Class Initialized
INFO - 2016-11-10 16:58:44 --> URI Class Initialized
INFO - 2016-11-10 16:58:45 --> Router Class Initialized
INFO - 2016-11-10 16:58:45 --> Output Class Initialized
INFO - 2016-11-10 16:58:45 --> Security Class Initialized
DEBUG - 2016-11-10 16:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:58:45 --> Input Class Initialized
INFO - 2016-11-10 16:58:45 --> Language Class Initialized
INFO - 2016-11-10 16:58:45 --> Loader Class Initialized
INFO - 2016-11-10 16:58:45 --> Helper loaded: url_helper
INFO - 2016-11-10 16:58:45 --> Helper loaded: form_helper
INFO - 2016-11-10 16:58:45 --> Database Driver Class Initialized
INFO - 2016-11-10 16:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:58:45 --> Controller Class Initialized
INFO - 2016-11-10 16:58:45 --> Model Class Initialized
INFO - 2016-11-10 16:58:45 --> Form Validation Class Initialized
INFO - 2016-11-10 16:58:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-10 16:58:45 --> Final output sent to browser
DEBUG - 2016-11-10 16:58:45 --> Total execution time: 0.3515
INFO - 2016-11-10 16:58:46 --> Config Class Initialized
INFO - 2016-11-10 16:58:46 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:58:46 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:58:46 --> Utf8 Class Initialized
INFO - 2016-11-10 16:58:46 --> URI Class Initialized
DEBUG - 2016-11-10 16:58:46 --> No URI present. Default controller set.
INFO - 2016-11-10 16:58:46 --> Router Class Initialized
INFO - 2016-11-10 16:58:46 --> Output Class Initialized
INFO - 2016-11-10 16:58:46 --> Security Class Initialized
DEBUG - 2016-11-10 16:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:58:46 --> Input Class Initialized
INFO - 2016-11-10 16:58:46 --> Language Class Initialized
INFO - 2016-11-10 16:58:46 --> Loader Class Initialized
INFO - 2016-11-10 16:58:46 --> Helper loaded: url_helper
INFO - 2016-11-10 16:58:46 --> Helper loaded: form_helper
INFO - 2016-11-10 16:58:46 --> Database Driver Class Initialized
INFO - 2016-11-10 16:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:58:46 --> Controller Class Initialized
INFO - 2016-11-10 16:58:46 --> Model Class Initialized
INFO - 2016-11-10 16:58:46 --> Model Class Initialized
INFO - 2016-11-10 16:58:46 --> Model Class Initialized
INFO - 2016-11-10 16:58:46 --> Model Class Initialized
INFO - 2016-11-10 16:58:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:58:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:58:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:58:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:58:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:58:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:58:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:58:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:58:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:58:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:58:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:58:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:58:46 --> Final output sent to browser
DEBUG - 2016-11-10 16:58:46 --> Total execution time: 0.6229
INFO - 2016-11-10 16:58:54 --> Config Class Initialized
INFO - 2016-11-10 16:58:54 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:58:54 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:58:54 --> Utf8 Class Initialized
INFO - 2016-11-10 16:58:54 --> URI Class Initialized
INFO - 2016-11-10 16:58:54 --> Router Class Initialized
INFO - 2016-11-10 16:58:54 --> Output Class Initialized
INFO - 2016-11-10 16:58:54 --> Security Class Initialized
DEBUG - 2016-11-10 16:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:58:54 --> Input Class Initialized
INFO - 2016-11-10 16:58:54 --> Language Class Initialized
INFO - 2016-11-10 16:58:54 --> Loader Class Initialized
INFO - 2016-11-10 16:58:54 --> Helper loaded: url_helper
INFO - 2016-11-10 16:58:54 --> Helper loaded: form_helper
INFO - 2016-11-10 16:58:54 --> Database Driver Class Initialized
INFO - 2016-11-10 16:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:58:54 --> Controller Class Initialized
INFO - 2016-11-10 16:58:54 --> Model Class Initialized
INFO - 2016-11-10 16:58:54 --> Form Validation Class Initialized
INFO - 2016-11-10 16:58:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-10 16:58:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:58:54 --> Final output sent to browser
DEBUG - 2016-11-10 16:58:54 --> Total execution time: 0.4906
INFO - 2016-11-10 16:58:56 --> Config Class Initialized
INFO - 2016-11-10 16:58:56 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:58:56 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:58:56 --> Utf8 Class Initialized
INFO - 2016-11-10 16:58:56 --> URI Class Initialized
DEBUG - 2016-11-10 16:58:56 --> No URI present. Default controller set.
INFO - 2016-11-10 16:58:56 --> Router Class Initialized
INFO - 2016-11-10 16:58:56 --> Output Class Initialized
INFO - 2016-11-10 16:58:56 --> Security Class Initialized
DEBUG - 2016-11-10 16:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:58:56 --> Input Class Initialized
INFO - 2016-11-10 16:58:56 --> Language Class Initialized
INFO - 2016-11-10 16:58:56 --> Loader Class Initialized
INFO - 2016-11-10 16:58:56 --> Helper loaded: url_helper
INFO - 2016-11-10 16:58:56 --> Helper loaded: form_helper
INFO - 2016-11-10 16:58:56 --> Database Driver Class Initialized
INFO - 2016-11-10 16:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:58:56 --> Controller Class Initialized
INFO - 2016-11-10 16:58:56 --> Model Class Initialized
INFO - 2016-11-10 16:58:56 --> Model Class Initialized
INFO - 2016-11-10 16:58:56 --> Model Class Initialized
INFO - 2016-11-10 16:58:56 --> Model Class Initialized
INFO - 2016-11-10 16:58:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:58:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:58:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:58:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:58:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:58:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:58:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:58:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:58:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:58:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:58:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:58:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:58:56 --> Final output sent to browser
DEBUG - 2016-11-10 16:58:56 --> Total execution time: 0.6801
INFO - 2016-11-10 16:59:55 --> Config Class Initialized
INFO - 2016-11-10 16:59:55 --> Hooks Class Initialized
DEBUG - 2016-11-10 16:59:55 --> UTF-8 Support Enabled
INFO - 2016-11-10 16:59:55 --> Utf8 Class Initialized
INFO - 2016-11-10 16:59:55 --> URI Class Initialized
DEBUG - 2016-11-10 16:59:55 --> No URI present. Default controller set.
INFO - 2016-11-10 16:59:55 --> Router Class Initialized
INFO - 2016-11-10 16:59:55 --> Output Class Initialized
INFO - 2016-11-10 16:59:55 --> Security Class Initialized
DEBUG - 2016-11-10 16:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 16:59:55 --> Input Class Initialized
INFO - 2016-11-10 16:59:55 --> Language Class Initialized
INFO - 2016-11-10 16:59:55 --> Loader Class Initialized
INFO - 2016-11-10 16:59:55 --> Helper loaded: url_helper
INFO - 2016-11-10 16:59:55 --> Helper loaded: form_helper
INFO - 2016-11-10 16:59:55 --> Database Driver Class Initialized
INFO - 2016-11-10 16:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 16:59:55 --> Controller Class Initialized
INFO - 2016-11-10 16:59:55 --> Model Class Initialized
INFO - 2016-11-10 16:59:55 --> Model Class Initialized
INFO - 2016-11-10 16:59:55 --> Model Class Initialized
INFO - 2016-11-10 16:59:55 --> Model Class Initialized
INFO - 2016-11-10 16:59:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 16:59:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 16:59:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 16:59:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 16:59:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 16:59:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 16:59:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 16:59:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 16:59:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 16:59:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 16:59:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 16:59:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 16:59:56 --> Final output sent to browser
DEBUG - 2016-11-10 16:59:56 --> Total execution time: 0.6249
INFO - 2016-11-10 17:04:34 --> Config Class Initialized
INFO - 2016-11-10 17:04:34 --> Hooks Class Initialized
DEBUG - 2016-11-10 17:04:34 --> UTF-8 Support Enabled
INFO - 2016-11-10 17:04:34 --> Utf8 Class Initialized
INFO - 2016-11-10 17:04:34 --> URI Class Initialized
INFO - 2016-11-10 17:04:35 --> Router Class Initialized
INFO - 2016-11-10 17:04:35 --> Output Class Initialized
INFO - 2016-11-10 17:04:35 --> Security Class Initialized
DEBUG - 2016-11-10 17:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 17:04:35 --> Input Class Initialized
INFO - 2016-11-10 17:04:35 --> Language Class Initialized
INFO - 2016-11-10 17:04:35 --> Loader Class Initialized
INFO - 2016-11-10 17:04:35 --> Helper loaded: url_helper
INFO - 2016-11-10 17:04:35 --> Helper loaded: form_helper
INFO - 2016-11-10 17:04:35 --> Database Driver Class Initialized
INFO - 2016-11-10 17:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 17:04:35 --> Controller Class Initialized
INFO - 2016-11-10 17:04:35 --> Model Class Initialized
INFO - 2016-11-10 17:04:35 --> Model Class Initialized
INFO - 2016-11-10 17:04:35 --> Model Class Initialized
INFO - 2016-11-10 17:04:35 --> Model Class Initialized
DEBUG - 2016-11-10 17:04:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 17:04:35 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 140
ERROR - 2016-11-10 17:04:35 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 140
INFO - 2016-11-10 17:04:35 --> Config Class Initialized
INFO - 2016-11-10 17:04:35 --> Hooks Class Initialized
DEBUG - 2016-11-10 17:04:35 --> UTF-8 Support Enabled
INFO - 2016-11-10 17:04:35 --> Utf8 Class Initialized
INFO - 2016-11-10 17:04:35 --> URI Class Initialized
DEBUG - 2016-11-10 17:04:35 --> No URI present. Default controller set.
INFO - 2016-11-10 17:04:35 --> Router Class Initialized
INFO - 2016-11-10 17:04:35 --> Output Class Initialized
INFO - 2016-11-10 17:04:35 --> Security Class Initialized
DEBUG - 2016-11-10 17:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 17:04:35 --> Input Class Initialized
INFO - 2016-11-10 17:04:35 --> Language Class Initialized
INFO - 2016-11-10 17:04:35 --> Loader Class Initialized
INFO - 2016-11-10 17:04:35 --> Helper loaded: url_helper
INFO - 2016-11-10 17:04:35 --> Helper loaded: form_helper
INFO - 2016-11-10 17:04:35 --> Database Driver Class Initialized
INFO - 2016-11-10 17:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 17:04:35 --> Controller Class Initialized
INFO - 2016-11-10 17:04:35 --> Model Class Initialized
INFO - 2016-11-10 17:04:35 --> Model Class Initialized
INFO - 2016-11-10 17:04:35 --> Model Class Initialized
INFO - 2016-11-10 17:04:35 --> Model Class Initialized
INFO - 2016-11-10 17:04:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 17:04:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 17:04:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 17:04:35 --> Final output sent to browser
DEBUG - 2016-11-10 17:04:35 --> Total execution time: 0.4333
INFO - 2016-11-10 17:04:46 --> Config Class Initialized
INFO - 2016-11-10 17:04:46 --> Hooks Class Initialized
DEBUG - 2016-11-10 17:04:46 --> UTF-8 Support Enabled
INFO - 2016-11-10 17:04:46 --> Utf8 Class Initialized
INFO - 2016-11-10 17:04:46 --> URI Class Initialized
INFO - 2016-11-10 17:04:46 --> Router Class Initialized
INFO - 2016-11-10 17:04:46 --> Output Class Initialized
INFO - 2016-11-10 17:04:46 --> Security Class Initialized
DEBUG - 2016-11-10 17:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 17:04:46 --> Input Class Initialized
INFO - 2016-11-10 17:04:46 --> Language Class Initialized
INFO - 2016-11-10 17:04:46 --> Loader Class Initialized
INFO - 2016-11-10 17:04:46 --> Helper loaded: url_helper
INFO - 2016-11-10 17:04:46 --> Helper loaded: form_helper
INFO - 2016-11-10 17:04:46 --> Database Driver Class Initialized
INFO - 2016-11-10 17:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 17:04:46 --> Controller Class Initialized
INFO - 2016-11-10 17:04:46 --> Model Class Initialized
INFO - 2016-11-10 17:04:46 --> Model Class Initialized
INFO - 2016-11-10 17:04:47 --> Model Class Initialized
INFO - 2016-11-10 17:04:47 --> Model Class Initialized
DEBUG - 2016-11-10 17:04:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 17:04:47 --> Model Class Initialized
INFO - 2016-11-10 17:04:47 --> Final output sent to browser
DEBUG - 2016-11-10 17:04:47 --> Total execution time: 0.3920
INFO - 2016-11-10 17:04:47 --> Config Class Initialized
INFO - 2016-11-10 17:04:47 --> Hooks Class Initialized
DEBUG - 2016-11-10 17:04:47 --> UTF-8 Support Enabled
INFO - 2016-11-10 17:04:47 --> Utf8 Class Initialized
INFO - 2016-11-10 17:04:47 --> URI Class Initialized
DEBUG - 2016-11-10 17:04:47 --> No URI present. Default controller set.
INFO - 2016-11-10 17:04:47 --> Router Class Initialized
INFO - 2016-11-10 17:04:47 --> Output Class Initialized
INFO - 2016-11-10 17:04:47 --> Security Class Initialized
DEBUG - 2016-11-10 17:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 17:04:47 --> Input Class Initialized
INFO - 2016-11-10 17:04:47 --> Language Class Initialized
INFO - 2016-11-10 17:04:47 --> Loader Class Initialized
INFO - 2016-11-10 17:04:47 --> Helper loaded: url_helper
INFO - 2016-11-10 17:04:47 --> Helper loaded: form_helper
INFO - 2016-11-10 17:04:47 --> Database Driver Class Initialized
INFO - 2016-11-10 17:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 17:04:47 --> Controller Class Initialized
INFO - 2016-11-10 17:04:47 --> Model Class Initialized
INFO - 2016-11-10 17:04:47 --> Model Class Initialized
INFO - 2016-11-10 17:04:47 --> Model Class Initialized
INFO - 2016-11-10 17:04:47 --> Model Class Initialized
INFO - 2016-11-10 17:04:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 17:04:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 17:04:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 17:04:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 17:04:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 17:04:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 17:04:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 17:04:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 17:04:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 17:04:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 17:04:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 17:04:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 17:04:47 --> Final output sent to browser
DEBUG - 2016-11-10 17:04:47 --> Total execution time: 0.6092
INFO - 2016-11-10 17:08:19 --> Config Class Initialized
INFO - 2016-11-10 17:08:19 --> Hooks Class Initialized
DEBUG - 2016-11-10 17:08:19 --> UTF-8 Support Enabled
INFO - 2016-11-10 17:08:19 --> Utf8 Class Initialized
INFO - 2016-11-10 17:08:19 --> URI Class Initialized
DEBUG - 2016-11-10 17:08:19 --> No URI present. Default controller set.
INFO - 2016-11-10 17:08:19 --> Router Class Initialized
INFO - 2016-11-10 17:08:19 --> Output Class Initialized
INFO - 2016-11-10 17:08:19 --> Security Class Initialized
DEBUG - 2016-11-10 17:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 17:08:19 --> Input Class Initialized
INFO - 2016-11-10 17:08:19 --> Language Class Initialized
INFO - 2016-11-10 17:08:19 --> Loader Class Initialized
INFO - 2016-11-10 17:08:19 --> Helper loaded: url_helper
INFO - 2016-11-10 17:08:19 --> Helper loaded: form_helper
INFO - 2016-11-10 17:08:19 --> Database Driver Class Initialized
INFO - 2016-11-10 17:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 17:08:19 --> Controller Class Initialized
INFO - 2016-11-10 17:08:19 --> Model Class Initialized
INFO - 2016-11-10 17:08:19 --> Model Class Initialized
INFO - 2016-11-10 17:08:19 --> Model Class Initialized
INFO - 2016-11-10 17:08:19 --> Model Class Initialized
INFO - 2016-11-10 17:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 17:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 17:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 17:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 17:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 17:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 17:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 17:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 17:08:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 17:08:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 17:08:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 17:08:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 17:08:20 --> Final output sent to browser
DEBUG - 2016-11-10 17:08:20 --> Total execution time: 0.6448
INFO - 2016-11-10 17:08:34 --> Config Class Initialized
INFO - 2016-11-10 17:08:34 --> Hooks Class Initialized
DEBUG - 2016-11-10 17:08:34 --> UTF-8 Support Enabled
INFO - 2016-11-10 17:08:34 --> Utf8 Class Initialized
INFO - 2016-11-10 17:08:34 --> URI Class Initialized
INFO - 2016-11-10 17:08:34 --> Router Class Initialized
INFO - 2016-11-10 17:08:34 --> Output Class Initialized
INFO - 2016-11-10 17:08:34 --> Security Class Initialized
DEBUG - 2016-11-10 17:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 17:08:34 --> Input Class Initialized
INFO - 2016-11-10 17:08:34 --> Language Class Initialized
INFO - 2016-11-10 17:08:34 --> Loader Class Initialized
INFO - 2016-11-10 17:08:34 --> Helper loaded: url_helper
INFO - 2016-11-10 17:08:34 --> Helper loaded: form_helper
INFO - 2016-11-10 17:08:34 --> Database Driver Class Initialized
INFO - 2016-11-10 17:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 17:08:34 --> Controller Class Initialized
INFO - 2016-11-10 17:08:34 --> Model Class Initialized
INFO - 2016-11-10 17:08:34 --> Form Validation Class Initialized
INFO - 2016-11-10 17:08:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-10 17:08:34 --> Final output sent to browser
DEBUG - 2016-11-10 17:08:34 --> Total execution time: 0.3579
INFO - 2016-11-10 17:08:35 --> Config Class Initialized
INFO - 2016-11-10 17:08:35 --> Hooks Class Initialized
DEBUG - 2016-11-10 17:08:35 --> UTF-8 Support Enabled
INFO - 2016-11-10 17:08:35 --> Utf8 Class Initialized
INFO - 2016-11-10 17:08:35 --> URI Class Initialized
DEBUG - 2016-11-10 17:08:35 --> No URI present. Default controller set.
INFO - 2016-11-10 17:08:35 --> Router Class Initialized
INFO - 2016-11-10 17:08:35 --> Output Class Initialized
INFO - 2016-11-10 17:08:35 --> Security Class Initialized
DEBUG - 2016-11-10 17:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 17:08:35 --> Input Class Initialized
INFO - 2016-11-10 17:08:35 --> Language Class Initialized
INFO - 2016-11-10 17:08:35 --> Loader Class Initialized
INFO - 2016-11-10 17:08:35 --> Helper loaded: url_helper
INFO - 2016-11-10 17:08:35 --> Helper loaded: form_helper
INFO - 2016-11-10 17:08:35 --> Database Driver Class Initialized
INFO - 2016-11-10 17:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 17:08:36 --> Controller Class Initialized
INFO - 2016-11-10 17:08:36 --> Model Class Initialized
INFO - 2016-11-10 17:08:36 --> Model Class Initialized
INFO - 2016-11-10 17:08:36 --> Model Class Initialized
INFO - 2016-11-10 17:08:36 --> Model Class Initialized
INFO - 2016-11-10 17:08:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 17:08:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 17:08:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 17:08:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 17:08:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 17:08:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 17:08:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 17:08:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 17:08:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 17:08:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 17:08:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 17:08:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 17:08:36 --> Final output sent to browser
DEBUG - 2016-11-10 17:08:36 --> Total execution time: 0.6993
INFO - 2016-11-10 17:12:39 --> Config Class Initialized
INFO - 2016-11-10 17:12:39 --> Hooks Class Initialized
DEBUG - 2016-11-10 17:12:39 --> UTF-8 Support Enabled
INFO - 2016-11-10 17:12:39 --> Utf8 Class Initialized
INFO - 2016-11-10 17:12:39 --> URI Class Initialized
DEBUG - 2016-11-10 17:12:39 --> No URI present. Default controller set.
INFO - 2016-11-10 17:12:39 --> Router Class Initialized
INFO - 2016-11-10 17:12:39 --> Output Class Initialized
INFO - 2016-11-10 17:12:39 --> Security Class Initialized
DEBUG - 2016-11-10 17:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 17:12:39 --> Input Class Initialized
INFO - 2016-11-10 17:12:39 --> Language Class Initialized
INFO - 2016-11-10 17:12:39 --> Loader Class Initialized
INFO - 2016-11-10 17:12:39 --> Helper loaded: url_helper
INFO - 2016-11-10 17:12:39 --> Helper loaded: form_helper
INFO - 2016-11-10 17:12:39 --> Database Driver Class Initialized
INFO - 2016-11-10 17:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 17:12:39 --> Controller Class Initialized
INFO - 2016-11-10 17:12:39 --> Model Class Initialized
INFO - 2016-11-10 17:12:39 --> Model Class Initialized
INFO - 2016-11-10 17:12:39 --> Model Class Initialized
INFO - 2016-11-10 17:12:40 --> Model Class Initialized
INFO - 2016-11-10 17:12:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 17:12:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 17:12:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 17:12:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 17:12:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 17:12:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 17:12:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 17:12:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 17:12:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 17:12:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 17:12:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 17:12:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 17:12:40 --> Final output sent to browser
DEBUG - 2016-11-10 17:12:40 --> Total execution time: 0.6050
INFO - 2016-11-10 17:13:35 --> Config Class Initialized
INFO - 2016-11-10 17:13:35 --> Hooks Class Initialized
DEBUG - 2016-11-10 17:13:35 --> UTF-8 Support Enabled
INFO - 2016-11-10 17:13:35 --> Utf8 Class Initialized
INFO - 2016-11-10 17:13:35 --> URI Class Initialized
DEBUG - 2016-11-10 17:13:35 --> No URI present. Default controller set.
INFO - 2016-11-10 17:13:35 --> Router Class Initialized
INFO - 2016-11-10 17:13:36 --> Output Class Initialized
INFO - 2016-11-10 17:13:36 --> Security Class Initialized
DEBUG - 2016-11-10 17:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 17:13:36 --> Input Class Initialized
INFO - 2016-11-10 17:13:36 --> Language Class Initialized
INFO - 2016-11-10 17:13:36 --> Loader Class Initialized
INFO - 2016-11-10 17:13:36 --> Helper loaded: url_helper
INFO - 2016-11-10 17:13:36 --> Helper loaded: form_helper
INFO - 2016-11-10 17:13:36 --> Database Driver Class Initialized
INFO - 2016-11-10 17:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 17:13:36 --> Controller Class Initialized
INFO - 2016-11-10 17:13:36 --> Model Class Initialized
INFO - 2016-11-10 17:13:36 --> Model Class Initialized
INFO - 2016-11-10 17:13:36 --> Model Class Initialized
INFO - 2016-11-10 17:13:36 --> Model Class Initialized
INFO - 2016-11-10 17:13:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 17:13:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 17:13:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 17:13:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 17:13:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 17:13:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 17:13:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 17:13:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 17:13:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 17:13:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 17:13:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 17:13:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 17:13:36 --> Final output sent to browser
DEBUG - 2016-11-10 17:13:36 --> Total execution time: 0.6386
INFO - 2016-11-10 17:56:20 --> Config Class Initialized
INFO - 2016-11-10 17:56:20 --> Hooks Class Initialized
DEBUG - 2016-11-10 17:56:20 --> UTF-8 Support Enabled
INFO - 2016-11-10 17:56:20 --> Utf8 Class Initialized
INFO - 2016-11-10 17:56:20 --> URI Class Initialized
DEBUG - 2016-11-10 17:56:20 --> No URI present. Default controller set.
INFO - 2016-11-10 17:56:20 --> Router Class Initialized
INFO - 2016-11-10 17:56:20 --> Output Class Initialized
INFO - 2016-11-10 17:56:20 --> Security Class Initialized
DEBUG - 2016-11-10 17:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 17:56:20 --> Input Class Initialized
INFO - 2016-11-10 17:56:20 --> Language Class Initialized
INFO - 2016-11-10 17:56:20 --> Loader Class Initialized
INFO - 2016-11-10 17:56:20 --> Helper loaded: url_helper
INFO - 2016-11-10 17:56:20 --> Helper loaded: form_helper
INFO - 2016-11-10 17:56:20 --> Database Driver Class Initialized
INFO - 2016-11-10 17:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 17:56:20 --> Controller Class Initialized
INFO - 2016-11-10 17:56:20 --> Model Class Initialized
INFO - 2016-11-10 17:56:20 --> Model Class Initialized
INFO - 2016-11-10 17:56:20 --> Model Class Initialized
INFO - 2016-11-10 17:56:21 --> Model Class Initialized
INFO - 2016-11-10 17:56:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 17:56:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 17:56:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 17:56:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 17:56:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 17:56:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 17:56:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 17:56:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 17:56:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 17:56:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 17:56:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 17:56:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 17:56:21 --> Final output sent to browser
DEBUG - 2016-11-10 17:56:21 --> Total execution time: 0.9079
INFO - 2016-11-10 17:57:39 --> Config Class Initialized
INFO - 2016-11-10 17:57:39 --> Hooks Class Initialized
DEBUG - 2016-11-10 17:57:39 --> UTF-8 Support Enabled
INFO - 2016-11-10 17:57:39 --> Utf8 Class Initialized
INFO - 2016-11-10 17:57:39 --> URI Class Initialized
DEBUG - 2016-11-10 17:57:39 --> No URI present. Default controller set.
INFO - 2016-11-10 17:57:39 --> Router Class Initialized
INFO - 2016-11-10 17:57:39 --> Output Class Initialized
INFO - 2016-11-10 17:57:39 --> Security Class Initialized
DEBUG - 2016-11-10 17:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 17:57:39 --> Input Class Initialized
INFO - 2016-11-10 17:57:39 --> Language Class Initialized
INFO - 2016-11-10 17:57:39 --> Loader Class Initialized
INFO - 2016-11-10 17:57:39 --> Helper loaded: url_helper
INFO - 2016-11-10 17:57:39 --> Helper loaded: form_helper
INFO - 2016-11-10 17:57:39 --> Database Driver Class Initialized
INFO - 2016-11-10 17:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 17:57:39 --> Controller Class Initialized
INFO - 2016-11-10 17:57:39 --> Model Class Initialized
INFO - 2016-11-10 17:57:39 --> Model Class Initialized
INFO - 2016-11-10 17:57:40 --> Model Class Initialized
INFO - 2016-11-10 17:57:40 --> Model Class Initialized
INFO - 2016-11-10 17:57:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 17:57:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 17:57:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 17:57:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 17:57:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 17:57:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 17:57:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 17:57:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 17:57:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 17:57:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 17:57:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 17:57:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 17:57:40 --> Final output sent to browser
DEBUG - 2016-11-10 17:57:40 --> Total execution time: 0.6328
INFO - 2016-11-10 17:59:58 --> Config Class Initialized
INFO - 2016-11-10 17:59:58 --> Hooks Class Initialized
DEBUG - 2016-11-10 17:59:58 --> UTF-8 Support Enabled
INFO - 2016-11-10 17:59:58 --> Utf8 Class Initialized
INFO - 2016-11-10 17:59:58 --> URI Class Initialized
DEBUG - 2016-11-10 17:59:58 --> No URI present. Default controller set.
INFO - 2016-11-10 17:59:58 --> Router Class Initialized
INFO - 2016-11-10 17:59:58 --> Output Class Initialized
INFO - 2016-11-10 17:59:58 --> Security Class Initialized
DEBUG - 2016-11-10 17:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 17:59:58 --> Input Class Initialized
INFO - 2016-11-10 17:59:58 --> Language Class Initialized
INFO - 2016-11-10 17:59:58 --> Loader Class Initialized
INFO - 2016-11-10 17:59:58 --> Helper loaded: url_helper
INFO - 2016-11-10 17:59:58 --> Helper loaded: form_helper
INFO - 2016-11-10 17:59:58 --> Database Driver Class Initialized
INFO - 2016-11-10 17:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 17:59:58 --> Controller Class Initialized
INFO - 2016-11-10 17:59:58 --> Model Class Initialized
INFO - 2016-11-10 17:59:58 --> Model Class Initialized
INFO - 2016-11-10 17:59:58 --> Model Class Initialized
INFO - 2016-11-10 17:59:58 --> Model Class Initialized
INFO - 2016-11-10 17:59:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 17:59:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 17:59:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 17:59:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 17:59:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 17:59:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 17:59:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 17:59:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 17:59:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 17:59:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 17:59:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 17:59:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 17:59:58 --> Final output sent to browser
DEBUG - 2016-11-10 17:59:58 --> Total execution time: 0.6265
INFO - 2016-11-10 18:01:14 --> Config Class Initialized
INFO - 2016-11-10 18:01:14 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:01:14 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:01:14 --> Utf8 Class Initialized
INFO - 2016-11-10 18:01:14 --> URI Class Initialized
DEBUG - 2016-11-10 18:01:14 --> No URI present. Default controller set.
INFO - 2016-11-10 18:01:14 --> Router Class Initialized
INFO - 2016-11-10 18:01:14 --> Output Class Initialized
INFO - 2016-11-10 18:01:14 --> Security Class Initialized
DEBUG - 2016-11-10 18:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:01:14 --> Input Class Initialized
INFO - 2016-11-10 18:01:14 --> Language Class Initialized
INFO - 2016-11-10 18:01:14 --> Loader Class Initialized
INFO - 2016-11-10 18:01:14 --> Helper loaded: url_helper
INFO - 2016-11-10 18:01:14 --> Helper loaded: form_helper
INFO - 2016-11-10 18:01:15 --> Database Driver Class Initialized
INFO - 2016-11-10 18:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:01:15 --> Controller Class Initialized
INFO - 2016-11-10 18:01:15 --> Model Class Initialized
INFO - 2016-11-10 18:01:15 --> Model Class Initialized
INFO - 2016-11-10 18:01:15 --> Model Class Initialized
INFO - 2016-11-10 18:01:15 --> Model Class Initialized
INFO - 2016-11-10 18:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 18:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 18:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 18:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 18:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 18:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 18:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 18:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 18:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:01:15 --> Final output sent to browser
DEBUG - 2016-11-10 18:01:15 --> Total execution time: 0.5826
INFO - 2016-11-10 18:01:42 --> Config Class Initialized
INFO - 2016-11-10 18:01:42 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:01:42 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:01:42 --> Utf8 Class Initialized
INFO - 2016-11-10 18:01:42 --> URI Class Initialized
DEBUG - 2016-11-10 18:01:42 --> No URI present. Default controller set.
INFO - 2016-11-10 18:01:42 --> Router Class Initialized
INFO - 2016-11-10 18:01:42 --> Output Class Initialized
INFO - 2016-11-10 18:01:42 --> Security Class Initialized
DEBUG - 2016-11-10 18:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:01:42 --> Input Class Initialized
INFO - 2016-11-10 18:01:42 --> Language Class Initialized
INFO - 2016-11-10 18:01:42 --> Loader Class Initialized
INFO - 2016-11-10 18:01:42 --> Helper loaded: url_helper
INFO - 2016-11-10 18:01:42 --> Helper loaded: form_helper
INFO - 2016-11-10 18:01:42 --> Database Driver Class Initialized
INFO - 2016-11-10 18:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:01:42 --> Controller Class Initialized
INFO - 2016-11-10 18:01:42 --> Model Class Initialized
INFO - 2016-11-10 18:01:42 --> Model Class Initialized
INFO - 2016-11-10 18:01:42 --> Model Class Initialized
INFO - 2016-11-10 18:01:42 --> Model Class Initialized
INFO - 2016-11-10 18:01:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:01:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:01:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:01:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 18:01:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 18:01:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 18:01:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 18:01:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 18:01:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 18:01:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 18:01:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 18:01:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:01:43 --> Final output sent to browser
DEBUG - 2016-11-10 18:01:43 --> Total execution time: 0.6122
INFO - 2016-11-10 18:02:33 --> Config Class Initialized
INFO - 2016-11-10 18:02:33 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:02:33 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:02:33 --> Utf8 Class Initialized
INFO - 2016-11-10 18:02:33 --> URI Class Initialized
DEBUG - 2016-11-10 18:02:33 --> No URI present. Default controller set.
INFO - 2016-11-10 18:02:33 --> Router Class Initialized
INFO - 2016-11-10 18:02:33 --> Output Class Initialized
INFO - 2016-11-10 18:02:33 --> Security Class Initialized
DEBUG - 2016-11-10 18:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:02:33 --> Input Class Initialized
INFO - 2016-11-10 18:02:33 --> Language Class Initialized
INFO - 2016-11-10 18:02:33 --> Loader Class Initialized
INFO - 2016-11-10 18:02:34 --> Helper loaded: url_helper
INFO - 2016-11-10 18:02:34 --> Helper loaded: form_helper
INFO - 2016-11-10 18:02:34 --> Database Driver Class Initialized
INFO - 2016-11-10 18:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:02:34 --> Controller Class Initialized
INFO - 2016-11-10 18:02:34 --> Model Class Initialized
INFO - 2016-11-10 18:02:34 --> Model Class Initialized
INFO - 2016-11-10 18:02:34 --> Model Class Initialized
INFO - 2016-11-10 18:02:34 --> Model Class Initialized
INFO - 2016-11-10 18:02:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:02:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:02:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:02:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 18:02:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 18:02:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 18:02:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 18:02:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 18:02:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 18:02:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 18:02:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 18:02:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:02:34 --> Final output sent to browser
DEBUG - 2016-11-10 18:02:34 --> Total execution time: 0.6237
INFO - 2016-11-10 18:03:35 --> Config Class Initialized
INFO - 2016-11-10 18:03:35 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:03:35 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:03:35 --> Utf8 Class Initialized
INFO - 2016-11-10 18:03:35 --> URI Class Initialized
DEBUG - 2016-11-10 18:03:35 --> No URI present. Default controller set.
INFO - 2016-11-10 18:03:35 --> Router Class Initialized
INFO - 2016-11-10 18:03:35 --> Output Class Initialized
INFO - 2016-11-10 18:03:35 --> Security Class Initialized
DEBUG - 2016-11-10 18:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:03:35 --> Input Class Initialized
INFO - 2016-11-10 18:03:35 --> Language Class Initialized
INFO - 2016-11-10 18:03:36 --> Loader Class Initialized
INFO - 2016-11-10 18:03:36 --> Helper loaded: url_helper
INFO - 2016-11-10 18:03:36 --> Helper loaded: form_helper
INFO - 2016-11-10 18:03:36 --> Database Driver Class Initialized
INFO - 2016-11-10 18:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:03:36 --> Controller Class Initialized
INFO - 2016-11-10 18:03:36 --> Model Class Initialized
INFO - 2016-11-10 18:03:36 --> Model Class Initialized
INFO - 2016-11-10 18:03:36 --> Model Class Initialized
INFO - 2016-11-10 18:03:36 --> Model Class Initialized
INFO - 2016-11-10 18:03:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:03:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:03:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:03:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 18:03:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 18:03:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 18:03:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 18:03:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 18:03:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 18:03:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 18:03:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 18:03:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:03:36 --> Final output sent to browser
DEBUG - 2016-11-10 18:03:36 --> Total execution time: 0.6206
INFO - 2016-11-10 18:19:55 --> Config Class Initialized
INFO - 2016-11-10 18:19:55 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:19:55 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:19:55 --> Utf8 Class Initialized
INFO - 2016-11-10 18:19:55 --> URI Class Initialized
DEBUG - 2016-11-10 18:19:55 --> No URI present. Default controller set.
INFO - 2016-11-10 18:19:55 --> Router Class Initialized
INFO - 2016-11-10 18:19:55 --> Output Class Initialized
INFO - 2016-11-10 18:19:55 --> Security Class Initialized
DEBUG - 2016-11-10 18:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:19:55 --> Input Class Initialized
INFO - 2016-11-10 18:19:55 --> Language Class Initialized
INFO - 2016-11-10 18:19:55 --> Loader Class Initialized
INFO - 2016-11-10 18:19:55 --> Helper loaded: url_helper
INFO - 2016-11-10 18:19:55 --> Helper loaded: form_helper
INFO - 2016-11-10 18:19:55 --> Database Driver Class Initialized
INFO - 2016-11-10 18:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:19:55 --> Controller Class Initialized
INFO - 2016-11-10 18:19:55 --> Model Class Initialized
INFO - 2016-11-10 18:19:55 --> Model Class Initialized
INFO - 2016-11-10 18:19:56 --> Model Class Initialized
INFO - 2016-11-10 18:19:56 --> Model Class Initialized
INFO - 2016-11-10 18:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 18:19:56 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 17
INFO - 2016-11-10 18:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 18:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 18:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 18:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 18:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 18:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 18:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 18:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 18:19:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:19:56 --> Final output sent to browser
DEBUG - 2016-11-10 18:19:56 --> Total execution time: 0.6620
INFO - 2016-11-10 18:20:37 --> Config Class Initialized
INFO - 2016-11-10 18:20:37 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:20:37 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:20:37 --> Utf8 Class Initialized
INFO - 2016-11-10 18:20:37 --> URI Class Initialized
DEBUG - 2016-11-10 18:20:37 --> No URI present. Default controller set.
INFO - 2016-11-10 18:20:37 --> Router Class Initialized
INFO - 2016-11-10 18:20:37 --> Output Class Initialized
INFO - 2016-11-10 18:20:37 --> Security Class Initialized
DEBUG - 2016-11-10 18:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:20:37 --> Input Class Initialized
INFO - 2016-11-10 18:20:37 --> Language Class Initialized
INFO - 2016-11-10 18:20:37 --> Loader Class Initialized
INFO - 2016-11-10 18:20:37 --> Helper loaded: url_helper
INFO - 2016-11-10 18:20:38 --> Helper loaded: form_helper
INFO - 2016-11-10 18:20:38 --> Database Driver Class Initialized
INFO - 2016-11-10 18:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:20:38 --> Controller Class Initialized
INFO - 2016-11-10 18:20:38 --> Model Class Initialized
INFO - 2016-11-10 18:20:38 --> Model Class Initialized
INFO - 2016-11-10 18:20:38 --> Model Class Initialized
INFO - 2016-11-10 18:20:38 --> Model Class Initialized
INFO - 2016-11-10 18:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 18:20:38 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\LMS\sys\database\DB_query_builder.php 669
ERROR - 2016-11-10 18:20:38 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `applicationData`
WHERE `idEmployee` = `Array`
INFO - 2016-11-10 18:20:38 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 18:27:12 --> Config Class Initialized
INFO - 2016-11-10 18:27:12 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:27:12 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:27:12 --> Utf8 Class Initialized
INFO - 2016-11-10 18:27:12 --> URI Class Initialized
DEBUG - 2016-11-10 18:27:12 --> No URI present. Default controller set.
INFO - 2016-11-10 18:27:12 --> Router Class Initialized
INFO - 2016-11-10 18:27:12 --> Output Class Initialized
INFO - 2016-11-10 18:27:12 --> Security Class Initialized
DEBUG - 2016-11-10 18:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:27:12 --> Input Class Initialized
INFO - 2016-11-10 18:27:12 --> Language Class Initialized
INFO - 2016-11-10 18:27:12 --> Loader Class Initialized
INFO - 2016-11-10 18:27:12 --> Helper loaded: url_helper
INFO - 2016-11-10 18:27:12 --> Helper loaded: form_helper
INFO - 2016-11-10 18:27:12 --> Database Driver Class Initialized
INFO - 2016-11-10 18:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:27:12 --> Controller Class Initialized
INFO - 2016-11-10 18:27:12 --> Model Class Initialized
INFO - 2016-11-10 18:27:12 --> Model Class Initialized
INFO - 2016-11-10 18:27:12 --> Model Class Initialized
INFO - 2016-11-10 18:27:12 --> Model Class Initialized
INFO - 2016-11-10 18:27:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:27:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:27:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:27:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 18:27:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 18:27:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 18:27:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 18:27:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 18:27:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 18:27:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 18:27:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 18:27:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:27:13 --> Final output sent to browser
DEBUG - 2016-11-10 18:27:13 --> Total execution time: 0.6679
INFO - 2016-11-10 18:29:24 --> Config Class Initialized
INFO - 2016-11-10 18:29:24 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:29:24 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:29:24 --> Utf8 Class Initialized
INFO - 2016-11-10 18:29:24 --> URI Class Initialized
DEBUG - 2016-11-10 18:29:24 --> No URI present. Default controller set.
INFO - 2016-11-10 18:29:24 --> Router Class Initialized
INFO - 2016-11-10 18:29:24 --> Output Class Initialized
INFO - 2016-11-10 18:29:24 --> Security Class Initialized
DEBUG - 2016-11-10 18:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:29:24 --> Input Class Initialized
INFO - 2016-11-10 18:29:24 --> Language Class Initialized
INFO - 2016-11-10 18:29:24 --> Loader Class Initialized
INFO - 2016-11-10 18:29:24 --> Helper loaded: url_helper
INFO - 2016-11-10 18:29:24 --> Helper loaded: form_helper
INFO - 2016-11-10 18:29:24 --> Database Driver Class Initialized
INFO - 2016-11-10 18:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:29:24 --> Controller Class Initialized
INFO - 2016-11-10 18:29:24 --> Model Class Initialized
INFO - 2016-11-10 18:29:24 --> Model Class Initialized
INFO - 2016-11-10 18:29:24 --> Model Class Initialized
INFO - 2016-11-10 18:29:24 --> Model Class Initialized
INFO - 2016-11-10 18:29:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:29:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:29:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:29:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 18:29:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 18:29:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 18:29:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 18:29:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 18:29:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 18:29:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 18:29:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 18:29:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:29:25 --> Final output sent to browser
DEBUG - 2016-11-10 18:29:25 --> Total execution time: 0.6018
INFO - 2016-11-10 18:29:46 --> Config Class Initialized
INFO - 2016-11-10 18:29:46 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:29:46 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:29:46 --> Utf8 Class Initialized
INFO - 2016-11-10 18:29:46 --> URI Class Initialized
DEBUG - 2016-11-10 18:29:46 --> No URI present. Default controller set.
INFO - 2016-11-10 18:29:46 --> Router Class Initialized
INFO - 2016-11-10 18:29:46 --> Output Class Initialized
INFO - 2016-11-10 18:29:46 --> Security Class Initialized
DEBUG - 2016-11-10 18:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:29:46 --> Input Class Initialized
INFO - 2016-11-10 18:29:46 --> Language Class Initialized
INFO - 2016-11-10 18:29:46 --> Loader Class Initialized
INFO - 2016-11-10 18:29:46 --> Helper loaded: url_helper
INFO - 2016-11-10 18:29:46 --> Helper loaded: form_helper
INFO - 2016-11-10 18:29:46 --> Database Driver Class Initialized
INFO - 2016-11-10 18:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:29:46 --> Controller Class Initialized
INFO - 2016-11-10 18:29:46 --> Model Class Initialized
INFO - 2016-11-10 18:29:46 --> Model Class Initialized
INFO - 2016-11-10 18:29:46 --> Model Class Initialized
INFO - 2016-11-10 18:29:46 --> Model Class Initialized
INFO - 2016-11-10 18:29:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:29:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:29:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:29:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 18:29:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 18:29:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 18:29:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 18:29:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 18:29:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 18:29:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 18:29:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 18:29:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:29:46 --> Final output sent to browser
DEBUG - 2016-11-10 18:29:46 --> Total execution time: 0.6253
INFO - 2016-11-10 18:31:43 --> Config Class Initialized
INFO - 2016-11-10 18:31:43 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:31:43 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:31:43 --> Utf8 Class Initialized
INFO - 2016-11-10 18:31:43 --> URI Class Initialized
DEBUG - 2016-11-10 18:31:43 --> No URI present. Default controller set.
INFO - 2016-11-10 18:31:43 --> Router Class Initialized
INFO - 2016-11-10 18:31:43 --> Output Class Initialized
INFO - 2016-11-10 18:31:43 --> Security Class Initialized
DEBUG - 2016-11-10 18:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:31:43 --> Input Class Initialized
INFO - 2016-11-10 18:31:43 --> Language Class Initialized
INFO - 2016-11-10 18:31:43 --> Loader Class Initialized
INFO - 2016-11-10 18:31:43 --> Helper loaded: url_helper
INFO - 2016-11-10 18:31:43 --> Helper loaded: form_helper
INFO - 2016-11-10 18:31:43 --> Database Driver Class Initialized
INFO - 2016-11-10 18:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:31:43 --> Controller Class Initialized
INFO - 2016-11-10 18:31:43 --> Model Class Initialized
INFO - 2016-11-10 18:31:43 --> Model Class Initialized
INFO - 2016-11-10 18:31:43 --> Model Class Initialized
INFO - 2016-11-10 18:31:43 --> Model Class Initialized
INFO - 2016-11-10 18:31:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:31:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:31:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:31:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 18:31:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 18:31:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 18:31:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 18:31:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 18:31:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 18:31:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 18:31:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 18:31:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:31:44 --> Final output sent to browser
DEBUG - 2016-11-10 18:31:44 --> Total execution time: 0.6323
INFO - 2016-11-10 18:33:28 --> Config Class Initialized
INFO - 2016-11-10 18:33:28 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:33:28 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:33:28 --> Utf8 Class Initialized
INFO - 2016-11-10 18:33:28 --> URI Class Initialized
DEBUG - 2016-11-10 18:33:28 --> No URI present. Default controller set.
INFO - 2016-11-10 18:33:28 --> Router Class Initialized
INFO - 2016-11-10 18:33:28 --> Output Class Initialized
INFO - 2016-11-10 18:33:28 --> Security Class Initialized
DEBUG - 2016-11-10 18:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:33:28 --> Input Class Initialized
INFO - 2016-11-10 18:33:28 --> Language Class Initialized
INFO - 2016-11-10 18:33:28 --> Loader Class Initialized
INFO - 2016-11-10 18:33:28 --> Helper loaded: url_helper
INFO - 2016-11-10 18:33:28 --> Helper loaded: form_helper
INFO - 2016-11-10 18:33:28 --> Database Driver Class Initialized
INFO - 2016-11-10 18:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:33:28 --> Controller Class Initialized
INFO - 2016-11-10 18:33:28 --> Model Class Initialized
INFO - 2016-11-10 18:33:28 --> Model Class Initialized
INFO - 2016-11-10 18:33:28 --> Model Class Initialized
INFO - 2016-11-10 18:33:28 --> Model Class Initialized
INFO - 2016-11-10 18:33:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:33:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:33:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:33:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 18:33:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 18:33:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 18:33:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 18:33:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 18:33:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 18:33:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 18:33:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 18:33:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:33:29 --> Final output sent to browser
DEBUG - 2016-11-10 18:33:29 --> Total execution time: 0.5996
INFO - 2016-11-10 18:35:00 --> Config Class Initialized
INFO - 2016-11-10 18:35:00 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:35:00 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:35:00 --> Utf8 Class Initialized
INFO - 2016-11-10 18:35:00 --> URI Class Initialized
DEBUG - 2016-11-10 18:35:00 --> No URI present. Default controller set.
INFO - 2016-11-10 18:35:00 --> Router Class Initialized
INFO - 2016-11-10 18:35:00 --> Output Class Initialized
INFO - 2016-11-10 18:35:00 --> Security Class Initialized
DEBUG - 2016-11-10 18:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:35:00 --> Input Class Initialized
INFO - 2016-11-10 18:35:00 --> Language Class Initialized
INFO - 2016-11-10 18:35:00 --> Loader Class Initialized
INFO - 2016-11-10 18:35:00 --> Helper loaded: url_helper
INFO - 2016-11-10 18:35:00 --> Helper loaded: form_helper
INFO - 2016-11-10 18:35:00 --> Database Driver Class Initialized
INFO - 2016-11-10 18:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:35:00 --> Controller Class Initialized
INFO - 2016-11-10 18:35:00 --> Model Class Initialized
INFO - 2016-11-10 18:35:00 --> Model Class Initialized
INFO - 2016-11-10 18:35:00 --> Model Class Initialized
INFO - 2016-11-10 18:35:00 --> Model Class Initialized
INFO - 2016-11-10 18:35:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:35:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:35:40 --> Config Class Initialized
INFO - 2016-11-10 18:35:40 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:35:40 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:35:40 --> Utf8 Class Initialized
INFO - 2016-11-10 18:35:40 --> URI Class Initialized
DEBUG - 2016-11-10 18:35:40 --> No URI present. Default controller set.
INFO - 2016-11-10 18:35:40 --> Router Class Initialized
INFO - 2016-11-10 18:35:40 --> Output Class Initialized
INFO - 2016-11-10 18:35:41 --> Security Class Initialized
DEBUG - 2016-11-10 18:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:35:41 --> Input Class Initialized
INFO - 2016-11-10 18:35:41 --> Language Class Initialized
INFO - 2016-11-10 18:35:41 --> Loader Class Initialized
INFO - 2016-11-10 18:35:41 --> Helper loaded: url_helper
INFO - 2016-11-10 18:35:41 --> Helper loaded: form_helper
INFO - 2016-11-10 18:35:41 --> Database Driver Class Initialized
INFO - 2016-11-10 18:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:35:41 --> Controller Class Initialized
INFO - 2016-11-10 18:35:41 --> Model Class Initialized
INFO - 2016-11-10 18:35:41 --> Model Class Initialized
INFO - 2016-11-10 18:35:41 --> Model Class Initialized
INFO - 2016-11-10 18:35:41 --> Model Class Initialized
INFO - 2016-11-10 18:35:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:35:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 18:35:41 --> Severity: Notice --> Undefined variable: queryApplicationData C:\xampp\htdocs\LMS\app\controllers\Auth.php 80
INFO - 2016-11-10 18:35:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:35:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
ERROR - 2016-11-10 18:35:41 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 14
INFO - 2016-11-10 18:36:16 --> Config Class Initialized
INFO - 2016-11-10 18:36:16 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:36:16 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:36:16 --> Utf8 Class Initialized
INFO - 2016-11-10 18:36:16 --> URI Class Initialized
DEBUG - 2016-11-10 18:36:16 --> No URI present. Default controller set.
INFO - 2016-11-10 18:36:16 --> Router Class Initialized
INFO - 2016-11-10 18:36:16 --> Output Class Initialized
INFO - 2016-11-10 18:36:16 --> Security Class Initialized
DEBUG - 2016-11-10 18:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:36:16 --> Input Class Initialized
INFO - 2016-11-10 18:36:16 --> Language Class Initialized
INFO - 2016-11-10 18:36:16 --> Loader Class Initialized
INFO - 2016-11-10 18:36:16 --> Helper loaded: url_helper
INFO - 2016-11-10 18:36:16 --> Helper loaded: form_helper
INFO - 2016-11-10 18:36:16 --> Database Driver Class Initialized
INFO - 2016-11-10 18:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:36:16 --> Controller Class Initialized
INFO - 2016-11-10 18:36:16 --> Model Class Initialized
INFO - 2016-11-10 18:36:16 --> Model Class Initialized
INFO - 2016-11-10 18:36:16 --> Model Class Initialized
INFO - 2016-11-10 18:36:16 --> Model Class Initialized
INFO - 2016-11-10 18:36:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:36:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:36:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:36:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 18:36:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 18:36:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 18:36:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 18:36:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 18:36:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 18:36:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 18:36:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 18:36:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:36:16 --> Final output sent to browser
DEBUG - 2016-11-10 18:36:16 --> Total execution time: 0.6199
INFO - 2016-11-10 18:36:35 --> Config Class Initialized
INFO - 2016-11-10 18:36:35 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:36:35 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:36:35 --> Utf8 Class Initialized
INFO - 2016-11-10 18:36:35 --> URI Class Initialized
INFO - 2016-11-10 18:36:35 --> Router Class Initialized
INFO - 2016-11-10 18:36:35 --> Output Class Initialized
INFO - 2016-11-10 18:36:35 --> Security Class Initialized
DEBUG - 2016-11-10 18:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:36:35 --> Input Class Initialized
INFO - 2016-11-10 18:36:35 --> Language Class Initialized
INFO - 2016-11-10 18:36:35 --> Loader Class Initialized
INFO - 2016-11-10 18:36:35 --> Helper loaded: url_helper
INFO - 2016-11-10 18:36:35 --> Helper loaded: form_helper
INFO - 2016-11-10 18:36:35 --> Database Driver Class Initialized
INFO - 2016-11-10 18:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:36:35 --> Controller Class Initialized
INFO - 2016-11-10 18:36:35 --> Model Class Initialized
INFO - 2016-11-10 18:36:35 --> Model Class Initialized
INFO - 2016-11-10 18:36:35 --> Model Class Initialized
INFO - 2016-11-10 18:36:35 --> Model Class Initialized
DEBUG - 2016-11-10 18:36:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 18:36:35 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
ERROR - 2016-11-10 18:36:35 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
INFO - 2016-11-10 18:36:35 --> Config Class Initialized
INFO - 2016-11-10 18:36:35 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:36:35 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:36:35 --> Utf8 Class Initialized
INFO - 2016-11-10 18:36:35 --> URI Class Initialized
DEBUG - 2016-11-10 18:36:35 --> No URI present. Default controller set.
INFO - 2016-11-10 18:36:35 --> Router Class Initialized
INFO - 2016-11-10 18:36:35 --> Output Class Initialized
INFO - 2016-11-10 18:36:35 --> Security Class Initialized
DEBUG - 2016-11-10 18:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:36:35 --> Input Class Initialized
INFO - 2016-11-10 18:36:35 --> Language Class Initialized
INFO - 2016-11-10 18:36:35 --> Loader Class Initialized
INFO - 2016-11-10 18:36:35 --> Helper loaded: url_helper
INFO - 2016-11-10 18:36:35 --> Helper loaded: form_helper
INFO - 2016-11-10 18:36:35 --> Database Driver Class Initialized
INFO - 2016-11-10 18:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:36:35 --> Controller Class Initialized
INFO - 2016-11-10 18:36:36 --> Model Class Initialized
INFO - 2016-11-10 18:36:36 --> Model Class Initialized
INFO - 2016-11-10 18:36:36 --> Model Class Initialized
INFO - 2016-11-10 18:36:36 --> Model Class Initialized
INFO - 2016-11-10 18:36:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:36:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 18:36:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:36:36 --> Final output sent to browser
DEBUG - 2016-11-10 18:36:36 --> Total execution time: 0.4414
INFO - 2016-11-10 18:37:04 --> Config Class Initialized
INFO - 2016-11-10 18:37:04 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:37:04 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:37:04 --> Utf8 Class Initialized
INFO - 2016-11-10 18:37:04 --> URI Class Initialized
INFO - 2016-11-10 18:37:04 --> Router Class Initialized
INFO - 2016-11-10 18:37:04 --> Output Class Initialized
INFO - 2016-11-10 18:37:04 --> Security Class Initialized
DEBUG - 2016-11-10 18:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:37:04 --> Input Class Initialized
INFO - 2016-11-10 18:37:04 --> Language Class Initialized
INFO - 2016-11-10 18:37:04 --> Loader Class Initialized
INFO - 2016-11-10 18:37:04 --> Helper loaded: url_helper
INFO - 2016-11-10 18:37:04 --> Helper loaded: form_helper
INFO - 2016-11-10 18:37:04 --> Database Driver Class Initialized
INFO - 2016-11-10 18:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:37:04 --> Controller Class Initialized
INFO - 2016-11-10 18:37:04 --> Model Class Initialized
INFO - 2016-11-10 18:37:04 --> Model Class Initialized
INFO - 2016-11-10 18:37:04 --> Model Class Initialized
INFO - 2016-11-10 18:37:04 --> Model Class Initialized
DEBUG - 2016-11-10 18:37:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 18:37:04 --> Model Class Initialized
INFO - 2016-11-10 18:37:04 --> Final output sent to browser
DEBUG - 2016-11-10 18:37:04 --> Total execution time: 0.4174
INFO - 2016-11-10 18:37:04 --> Config Class Initialized
INFO - 2016-11-10 18:37:04 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:37:04 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:37:04 --> Utf8 Class Initialized
INFO - 2016-11-10 18:37:04 --> URI Class Initialized
DEBUG - 2016-11-10 18:37:04 --> No URI present. Default controller set.
INFO - 2016-11-10 18:37:04 --> Router Class Initialized
INFO - 2016-11-10 18:37:04 --> Output Class Initialized
INFO - 2016-11-10 18:37:04 --> Security Class Initialized
DEBUG - 2016-11-10 18:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:37:05 --> Input Class Initialized
INFO - 2016-11-10 18:37:05 --> Language Class Initialized
INFO - 2016-11-10 18:37:05 --> Loader Class Initialized
INFO - 2016-11-10 18:37:05 --> Helper loaded: url_helper
INFO - 2016-11-10 18:37:05 --> Helper loaded: form_helper
INFO - 2016-11-10 18:37:05 --> Database Driver Class Initialized
INFO - 2016-11-10 18:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:37:05 --> Controller Class Initialized
INFO - 2016-11-10 18:37:05 --> Model Class Initialized
INFO - 2016-11-10 18:37:05 --> Model Class Initialized
INFO - 2016-11-10 18:37:05 --> Model Class Initialized
INFO - 2016-11-10 18:37:05 --> Model Class Initialized
INFO - 2016-11-10 18:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 18:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 18:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 18:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 18:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 18:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 18:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 18:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 18:37:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:37:05 --> Final output sent to browser
DEBUG - 2016-11-10 18:37:05 --> Total execution time: 0.6149
INFO - 2016-11-10 18:39:14 --> Config Class Initialized
INFO - 2016-11-10 18:39:14 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:39:14 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:39:14 --> Utf8 Class Initialized
INFO - 2016-11-10 18:39:14 --> URI Class Initialized
DEBUG - 2016-11-10 18:39:14 --> No URI present. Default controller set.
INFO - 2016-11-10 18:39:14 --> Router Class Initialized
INFO - 2016-11-10 18:39:14 --> Output Class Initialized
INFO - 2016-11-10 18:39:14 --> Security Class Initialized
DEBUG - 2016-11-10 18:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:39:14 --> Input Class Initialized
INFO - 2016-11-10 18:39:14 --> Language Class Initialized
INFO - 2016-11-10 18:39:14 --> Loader Class Initialized
INFO - 2016-11-10 18:39:14 --> Helper loaded: url_helper
INFO - 2016-11-10 18:39:14 --> Helper loaded: form_helper
INFO - 2016-11-10 18:39:15 --> Database Driver Class Initialized
INFO - 2016-11-10 18:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:39:15 --> Controller Class Initialized
INFO - 2016-11-10 18:39:15 --> Model Class Initialized
INFO - 2016-11-10 18:39:15 --> Model Class Initialized
INFO - 2016-11-10 18:39:15 --> Model Class Initialized
INFO - 2016-11-10 18:39:15 --> Model Class Initialized
INFO - 2016-11-10 18:39:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:39:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:39:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:39:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 18:39:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 18:39:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 18:39:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 18:39:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 18:39:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 18:39:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 18:39:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 18:39:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:39:15 --> Final output sent to browser
DEBUG - 2016-11-10 18:39:15 --> Total execution time: 0.6251
INFO - 2016-11-10 18:40:23 --> Config Class Initialized
INFO - 2016-11-10 18:40:23 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:40:23 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:40:23 --> Utf8 Class Initialized
INFO - 2016-11-10 18:40:23 --> URI Class Initialized
DEBUG - 2016-11-10 18:40:23 --> No URI present. Default controller set.
INFO - 2016-11-10 18:40:23 --> Router Class Initialized
INFO - 2016-11-10 18:40:23 --> Output Class Initialized
INFO - 2016-11-10 18:40:23 --> Security Class Initialized
DEBUG - 2016-11-10 18:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:40:23 --> Input Class Initialized
INFO - 2016-11-10 18:40:23 --> Language Class Initialized
INFO - 2016-11-10 18:40:23 --> Loader Class Initialized
INFO - 2016-11-10 18:40:23 --> Helper loaded: url_helper
INFO - 2016-11-10 18:40:23 --> Helper loaded: form_helper
INFO - 2016-11-10 18:40:23 --> Database Driver Class Initialized
INFO - 2016-11-10 18:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:40:23 --> Controller Class Initialized
INFO - 2016-11-10 18:40:23 --> Model Class Initialized
INFO - 2016-11-10 18:40:23 --> Model Class Initialized
INFO - 2016-11-10 18:40:23 --> Model Class Initialized
INFO - 2016-11-10 18:40:23 --> Model Class Initialized
INFO - 2016-11-10 18:40:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:40:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:40:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:40:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 18:40:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 18:40:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 18:40:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 18:40:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 18:40:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 18:40:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 18:40:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 18:40:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:40:24 --> Final output sent to browser
DEBUG - 2016-11-10 18:40:24 --> Total execution time: 0.6546
INFO - 2016-11-10 18:41:18 --> Config Class Initialized
INFO - 2016-11-10 18:41:18 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:41:18 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:41:18 --> Utf8 Class Initialized
INFO - 2016-11-10 18:41:18 --> URI Class Initialized
DEBUG - 2016-11-10 18:41:18 --> No URI present. Default controller set.
INFO - 2016-11-10 18:41:18 --> Router Class Initialized
INFO - 2016-11-10 18:41:18 --> Output Class Initialized
INFO - 2016-11-10 18:41:18 --> Security Class Initialized
DEBUG - 2016-11-10 18:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:41:18 --> Input Class Initialized
INFO - 2016-11-10 18:41:18 --> Language Class Initialized
INFO - 2016-11-10 18:41:18 --> Loader Class Initialized
INFO - 2016-11-10 18:41:18 --> Helper loaded: url_helper
INFO - 2016-11-10 18:41:18 --> Helper loaded: form_helper
INFO - 2016-11-10 18:41:18 --> Database Driver Class Initialized
INFO - 2016-11-10 18:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:41:18 --> Controller Class Initialized
INFO - 2016-11-10 18:41:18 --> Model Class Initialized
INFO - 2016-11-10 18:41:18 --> Model Class Initialized
INFO - 2016-11-10 18:41:18 --> Model Class Initialized
INFO - 2016-11-10 18:41:18 --> Model Class Initialized
INFO - 2016-11-10 18:41:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:41:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:41:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:41:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 18:41:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 18:41:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 18:41:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 18:41:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 18:41:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 18:41:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 18:41:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 18:41:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:41:18 --> Final output sent to browser
DEBUG - 2016-11-10 18:41:18 --> Total execution time: 0.6299
INFO - 2016-11-10 18:41:37 --> Config Class Initialized
INFO - 2016-11-10 18:41:37 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:41:37 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:41:37 --> Utf8 Class Initialized
INFO - 2016-11-10 18:41:37 --> URI Class Initialized
DEBUG - 2016-11-10 18:41:37 --> No URI present. Default controller set.
INFO - 2016-11-10 18:41:37 --> Router Class Initialized
INFO - 2016-11-10 18:41:37 --> Output Class Initialized
INFO - 2016-11-10 18:41:37 --> Security Class Initialized
DEBUG - 2016-11-10 18:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:41:37 --> Input Class Initialized
INFO - 2016-11-10 18:41:37 --> Language Class Initialized
INFO - 2016-11-10 18:41:37 --> Loader Class Initialized
INFO - 2016-11-10 18:41:37 --> Helper loaded: url_helper
INFO - 2016-11-10 18:41:37 --> Helper loaded: form_helper
INFO - 2016-11-10 18:41:37 --> Database Driver Class Initialized
INFO - 2016-11-10 18:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:41:38 --> Controller Class Initialized
INFO - 2016-11-10 18:41:38 --> Model Class Initialized
INFO - 2016-11-10 18:41:38 --> Model Class Initialized
INFO - 2016-11-10 18:41:38 --> Model Class Initialized
INFO - 2016-11-10 18:41:38 --> Model Class Initialized
INFO - 2016-11-10 18:41:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:41:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:41:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:41:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 18:41:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 18:41:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 18:41:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 18:41:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 18:41:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 18:41:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 18:41:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 18:41:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:41:38 --> Final output sent to browser
DEBUG - 2016-11-10 18:41:38 --> Total execution time: 0.6216
INFO - 2016-11-10 18:42:59 --> Config Class Initialized
INFO - 2016-11-10 18:42:59 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:42:59 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:42:59 --> Utf8 Class Initialized
INFO - 2016-11-10 18:42:59 --> URI Class Initialized
DEBUG - 2016-11-10 18:42:59 --> No URI present. Default controller set.
INFO - 2016-11-10 18:43:00 --> Router Class Initialized
INFO - 2016-11-10 18:43:00 --> Output Class Initialized
INFO - 2016-11-10 18:43:00 --> Security Class Initialized
DEBUG - 2016-11-10 18:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:43:00 --> Input Class Initialized
INFO - 2016-11-10 18:43:00 --> Language Class Initialized
INFO - 2016-11-10 18:43:00 --> Loader Class Initialized
INFO - 2016-11-10 18:43:00 --> Helper loaded: url_helper
INFO - 2016-11-10 18:43:00 --> Helper loaded: form_helper
INFO - 2016-11-10 18:43:00 --> Database Driver Class Initialized
INFO - 2016-11-10 18:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:43:00 --> Controller Class Initialized
INFO - 2016-11-10 18:43:00 --> Model Class Initialized
INFO - 2016-11-10 18:43:00 --> Model Class Initialized
INFO - 2016-11-10 18:43:00 --> Model Class Initialized
INFO - 2016-11-10 18:43:00 --> Model Class Initialized
INFO - 2016-11-10 18:43:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:43:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:43:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:43:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 18:43:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 18:43:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 18:43:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 18:43:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 18:43:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 18:43:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 18:43:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 18:43:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:43:00 --> Final output sent to browser
DEBUG - 2016-11-10 18:43:00 --> Total execution time: 0.6247
INFO - 2016-11-10 18:44:07 --> Config Class Initialized
INFO - 2016-11-10 18:44:07 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:44:07 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:44:07 --> Utf8 Class Initialized
INFO - 2016-11-10 18:44:07 --> URI Class Initialized
DEBUG - 2016-11-10 18:44:08 --> No URI present. Default controller set.
INFO - 2016-11-10 18:44:08 --> Router Class Initialized
INFO - 2016-11-10 18:44:08 --> Output Class Initialized
INFO - 2016-11-10 18:44:08 --> Security Class Initialized
DEBUG - 2016-11-10 18:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:44:08 --> Input Class Initialized
INFO - 2016-11-10 18:44:08 --> Language Class Initialized
INFO - 2016-11-10 18:44:08 --> Loader Class Initialized
INFO - 2016-11-10 18:44:08 --> Helper loaded: url_helper
INFO - 2016-11-10 18:44:08 --> Helper loaded: form_helper
INFO - 2016-11-10 18:44:08 --> Database Driver Class Initialized
INFO - 2016-11-10 18:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:44:08 --> Controller Class Initialized
INFO - 2016-11-10 18:44:08 --> Model Class Initialized
INFO - 2016-11-10 18:44:08 --> Model Class Initialized
INFO - 2016-11-10 18:44:08 --> Model Class Initialized
INFO - 2016-11-10 18:44:08 --> Model Class Initialized
INFO - 2016-11-10 18:44:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:44:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:44:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:44:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 18:44:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 18:44:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 18:44:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 18:44:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 18:44:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 18:44:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 18:44:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 18:44:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:44:08 --> Final output sent to browser
DEBUG - 2016-11-10 18:44:08 --> Total execution time: 0.7053
INFO - 2016-11-10 18:44:28 --> Config Class Initialized
INFO - 2016-11-10 18:44:29 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:44:29 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:44:29 --> Utf8 Class Initialized
INFO - 2016-11-10 18:44:29 --> URI Class Initialized
DEBUG - 2016-11-10 18:44:29 --> No URI present. Default controller set.
INFO - 2016-11-10 18:44:29 --> Router Class Initialized
INFO - 2016-11-10 18:44:29 --> Output Class Initialized
INFO - 2016-11-10 18:44:29 --> Security Class Initialized
DEBUG - 2016-11-10 18:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:44:29 --> Input Class Initialized
INFO - 2016-11-10 18:44:29 --> Language Class Initialized
INFO - 2016-11-10 18:44:29 --> Loader Class Initialized
INFO - 2016-11-10 18:44:29 --> Helper loaded: url_helper
INFO - 2016-11-10 18:44:29 --> Helper loaded: form_helper
INFO - 2016-11-10 18:44:29 --> Database Driver Class Initialized
INFO - 2016-11-10 18:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:44:29 --> Controller Class Initialized
INFO - 2016-11-10 18:44:29 --> Model Class Initialized
INFO - 2016-11-10 18:44:29 --> Model Class Initialized
INFO - 2016-11-10 18:44:29 --> Model Class Initialized
INFO - 2016-11-10 18:44:29 --> Model Class Initialized
INFO - 2016-11-10 18:44:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:44:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 18:44:29 --> Severity: Error --> Call to undefined method Leave_application_m::count_Leave_applied() C:\xampp\htdocs\LMS\app\controllers\Auth.php 70
INFO - 2016-11-10 18:45:08 --> Config Class Initialized
INFO - 2016-11-10 18:45:08 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:45:08 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:45:08 --> Utf8 Class Initialized
INFO - 2016-11-10 18:45:08 --> URI Class Initialized
DEBUG - 2016-11-10 18:45:08 --> No URI present. Default controller set.
INFO - 2016-11-10 18:45:08 --> Router Class Initialized
INFO - 2016-11-10 18:45:08 --> Output Class Initialized
INFO - 2016-11-10 18:45:08 --> Security Class Initialized
DEBUG - 2016-11-10 18:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:45:08 --> Input Class Initialized
INFO - 2016-11-10 18:45:08 --> Language Class Initialized
INFO - 2016-11-10 18:45:08 --> Loader Class Initialized
INFO - 2016-11-10 18:45:08 --> Helper loaded: url_helper
INFO - 2016-11-10 18:45:08 --> Helper loaded: form_helper
INFO - 2016-11-10 18:45:08 --> Database Driver Class Initialized
INFO - 2016-11-10 18:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:45:08 --> Controller Class Initialized
INFO - 2016-11-10 18:45:08 --> Model Class Initialized
INFO - 2016-11-10 18:45:08 --> Model Class Initialized
INFO - 2016-11-10 18:45:08 --> Model Class Initialized
INFO - 2016-11-10 18:45:08 --> Model Class Initialized
INFO - 2016-11-10 18:45:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:45:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:45:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:45:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 18:45:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 18:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 18:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 18:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 18:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 18:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 18:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 18:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:45:09 --> Final output sent to browser
DEBUG - 2016-11-10 18:45:09 --> Total execution time: 0.6800
INFO - 2016-11-10 18:45:51 --> Config Class Initialized
INFO - 2016-11-10 18:45:51 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:45:51 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:45:51 --> Utf8 Class Initialized
INFO - 2016-11-10 18:45:51 --> URI Class Initialized
INFO - 2016-11-10 18:45:51 --> Router Class Initialized
INFO - 2016-11-10 18:45:51 --> Output Class Initialized
INFO - 2016-11-10 18:45:51 --> Security Class Initialized
DEBUG - 2016-11-10 18:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:45:51 --> Input Class Initialized
INFO - 2016-11-10 18:45:51 --> Language Class Initialized
INFO - 2016-11-10 18:45:51 --> Loader Class Initialized
INFO - 2016-11-10 18:45:51 --> Helper loaded: url_helper
INFO - 2016-11-10 18:45:51 --> Helper loaded: form_helper
INFO - 2016-11-10 18:45:51 --> Database Driver Class Initialized
INFO - 2016-11-10 18:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:45:51 --> Controller Class Initialized
INFO - 2016-11-10 18:45:51 --> Model Class Initialized
INFO - 2016-11-10 18:45:51 --> Model Class Initialized
INFO - 2016-11-10 18:45:51 --> Model Class Initialized
INFO - 2016-11-10 18:45:51 --> Model Class Initialized
DEBUG - 2016-11-10 18:45:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 18:45:51 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
ERROR - 2016-11-10 18:45:51 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
INFO - 2016-11-10 18:45:52 --> Config Class Initialized
INFO - 2016-11-10 18:45:52 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:45:52 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:45:52 --> Utf8 Class Initialized
INFO - 2016-11-10 18:45:52 --> URI Class Initialized
DEBUG - 2016-11-10 18:45:52 --> No URI present. Default controller set.
INFO - 2016-11-10 18:45:52 --> Router Class Initialized
INFO - 2016-11-10 18:45:52 --> Output Class Initialized
INFO - 2016-11-10 18:45:52 --> Security Class Initialized
DEBUG - 2016-11-10 18:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:45:52 --> Input Class Initialized
INFO - 2016-11-10 18:45:52 --> Language Class Initialized
INFO - 2016-11-10 18:45:52 --> Loader Class Initialized
INFO - 2016-11-10 18:45:52 --> Helper loaded: url_helper
INFO - 2016-11-10 18:45:52 --> Helper loaded: form_helper
INFO - 2016-11-10 18:45:52 --> Database Driver Class Initialized
INFO - 2016-11-10 18:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:45:52 --> Controller Class Initialized
INFO - 2016-11-10 18:45:52 --> Model Class Initialized
INFO - 2016-11-10 18:45:52 --> Model Class Initialized
INFO - 2016-11-10 18:45:52 --> Model Class Initialized
INFO - 2016-11-10 18:45:52 --> Model Class Initialized
INFO - 2016-11-10 18:45:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:45:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 18:45:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:45:52 --> Final output sent to browser
DEBUG - 2016-11-10 18:45:52 --> Total execution time: 0.4524
INFO - 2016-11-10 18:46:02 --> Config Class Initialized
INFO - 2016-11-10 18:46:02 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:46:02 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:46:02 --> Utf8 Class Initialized
INFO - 2016-11-10 18:46:02 --> URI Class Initialized
INFO - 2016-11-10 18:46:02 --> Router Class Initialized
INFO - 2016-11-10 18:46:02 --> Output Class Initialized
INFO - 2016-11-10 18:46:02 --> Security Class Initialized
DEBUG - 2016-11-10 18:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:46:02 --> Input Class Initialized
INFO - 2016-11-10 18:46:02 --> Language Class Initialized
INFO - 2016-11-10 18:46:02 --> Loader Class Initialized
INFO - 2016-11-10 18:46:02 --> Helper loaded: url_helper
INFO - 2016-11-10 18:46:02 --> Helper loaded: form_helper
INFO - 2016-11-10 18:46:03 --> Database Driver Class Initialized
INFO - 2016-11-10 18:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:46:03 --> Controller Class Initialized
INFO - 2016-11-10 18:46:03 --> Model Class Initialized
INFO - 2016-11-10 18:46:03 --> Model Class Initialized
INFO - 2016-11-10 18:46:03 --> Model Class Initialized
INFO - 2016-11-10 18:46:03 --> Model Class Initialized
DEBUG - 2016-11-10 18:46:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 18:46:03 --> Model Class Initialized
INFO - 2016-11-10 18:46:03 --> Final output sent to browser
DEBUG - 2016-11-10 18:46:03 --> Total execution time: 0.4239
INFO - 2016-11-10 18:46:03 --> Config Class Initialized
INFO - 2016-11-10 18:46:03 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:46:03 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:46:03 --> Utf8 Class Initialized
INFO - 2016-11-10 18:46:03 --> URI Class Initialized
DEBUG - 2016-11-10 18:46:03 --> No URI present. Default controller set.
INFO - 2016-11-10 18:46:03 --> Router Class Initialized
INFO - 2016-11-10 18:46:03 --> Output Class Initialized
INFO - 2016-11-10 18:46:03 --> Security Class Initialized
DEBUG - 2016-11-10 18:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:46:03 --> Input Class Initialized
INFO - 2016-11-10 18:46:03 --> Language Class Initialized
INFO - 2016-11-10 18:46:03 --> Loader Class Initialized
INFO - 2016-11-10 18:46:03 --> Helper loaded: url_helper
INFO - 2016-11-10 18:46:03 --> Helper loaded: form_helper
INFO - 2016-11-10 18:46:03 --> Database Driver Class Initialized
INFO - 2016-11-10 18:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:46:03 --> Controller Class Initialized
INFO - 2016-11-10 18:46:03 --> Model Class Initialized
INFO - 2016-11-10 18:46:03 --> Model Class Initialized
INFO - 2016-11-10 18:46:03 --> Model Class Initialized
INFO - 2016-11-10 18:46:03 --> Model Class Initialized
INFO - 2016-11-10 18:46:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:46:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:46:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:46:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 18:46:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 18:46:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 18:46:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 18:46:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 18:46:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 18:46:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 18:46:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 18:46:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:46:03 --> Final output sent to browser
DEBUG - 2016-11-10 18:46:03 --> Total execution time: 0.6293
INFO - 2016-11-10 18:48:45 --> Config Class Initialized
INFO - 2016-11-10 18:48:45 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:48:45 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:48:45 --> Utf8 Class Initialized
INFO - 2016-11-10 18:48:45 --> URI Class Initialized
INFO - 2016-11-10 18:48:45 --> Router Class Initialized
INFO - 2016-11-10 18:48:45 --> Output Class Initialized
INFO - 2016-11-10 18:48:45 --> Security Class Initialized
DEBUG - 2016-11-10 18:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:48:45 --> Input Class Initialized
INFO - 2016-11-10 18:48:45 --> Language Class Initialized
INFO - 2016-11-10 18:48:45 --> Loader Class Initialized
INFO - 2016-11-10 18:48:45 --> Helper loaded: url_helper
INFO - 2016-11-10 18:48:45 --> Helper loaded: form_helper
INFO - 2016-11-10 18:48:45 --> Database Driver Class Initialized
INFO - 2016-11-10 18:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:48:45 --> Controller Class Initialized
INFO - 2016-11-10 18:48:45 --> Model Class Initialized
INFO - 2016-11-10 18:48:45 --> Model Class Initialized
INFO - 2016-11-10 18:48:45 --> Model Class Initialized
INFO - 2016-11-10 18:48:45 --> Model Class Initialized
DEBUG - 2016-11-10 18:48:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 18:48:45 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
ERROR - 2016-11-10 18:48:45 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
INFO - 2016-11-10 18:48:45 --> Config Class Initialized
INFO - 2016-11-10 18:48:45 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:48:45 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:48:45 --> Utf8 Class Initialized
INFO - 2016-11-10 18:48:45 --> URI Class Initialized
DEBUG - 2016-11-10 18:48:45 --> No URI present. Default controller set.
INFO - 2016-11-10 18:48:45 --> Router Class Initialized
INFO - 2016-11-10 18:48:45 --> Output Class Initialized
INFO - 2016-11-10 18:48:45 --> Security Class Initialized
DEBUG - 2016-11-10 18:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:48:45 --> Input Class Initialized
INFO - 2016-11-10 18:48:45 --> Language Class Initialized
INFO - 2016-11-10 18:48:45 --> Loader Class Initialized
INFO - 2016-11-10 18:48:45 --> Helper loaded: url_helper
INFO - 2016-11-10 18:48:45 --> Helper loaded: form_helper
INFO - 2016-11-10 18:48:45 --> Database Driver Class Initialized
INFO - 2016-11-10 18:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:48:45 --> Controller Class Initialized
INFO - 2016-11-10 18:48:45 --> Model Class Initialized
INFO - 2016-11-10 18:48:45 --> Model Class Initialized
INFO - 2016-11-10 18:48:45 --> Model Class Initialized
INFO - 2016-11-10 18:48:45 --> Model Class Initialized
INFO - 2016-11-10 18:48:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:48:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 18:48:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:48:46 --> Final output sent to browser
DEBUG - 2016-11-10 18:48:46 --> Total execution time: 0.4606
INFO - 2016-11-10 18:48:54 --> Config Class Initialized
INFO - 2016-11-10 18:48:54 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:48:54 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:48:54 --> Utf8 Class Initialized
INFO - 2016-11-10 18:48:54 --> URI Class Initialized
INFO - 2016-11-10 18:48:54 --> Router Class Initialized
INFO - 2016-11-10 18:48:54 --> Output Class Initialized
INFO - 2016-11-10 18:48:54 --> Security Class Initialized
DEBUG - 2016-11-10 18:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:48:54 --> Input Class Initialized
INFO - 2016-11-10 18:48:54 --> Language Class Initialized
INFO - 2016-11-10 18:48:54 --> Loader Class Initialized
INFO - 2016-11-10 18:48:54 --> Helper loaded: url_helper
INFO - 2016-11-10 18:48:54 --> Helper loaded: form_helper
INFO - 2016-11-10 18:48:54 --> Database Driver Class Initialized
INFO - 2016-11-10 18:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:48:54 --> Controller Class Initialized
INFO - 2016-11-10 18:48:54 --> Model Class Initialized
INFO - 2016-11-10 18:48:54 --> Model Class Initialized
INFO - 2016-11-10 18:48:54 --> Model Class Initialized
INFO - 2016-11-10 18:48:54 --> Model Class Initialized
DEBUG - 2016-11-10 18:48:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 18:48:54 --> Model Class Initialized
INFO - 2016-11-10 18:48:54 --> Final output sent to browser
DEBUG - 2016-11-10 18:48:55 --> Total execution time: 0.4330
INFO - 2016-11-10 18:48:55 --> Config Class Initialized
INFO - 2016-11-10 18:48:55 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:48:55 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:48:55 --> Utf8 Class Initialized
INFO - 2016-11-10 18:48:55 --> URI Class Initialized
DEBUG - 2016-11-10 18:48:55 --> No URI present. Default controller set.
INFO - 2016-11-10 18:48:55 --> Router Class Initialized
INFO - 2016-11-10 18:48:55 --> Output Class Initialized
INFO - 2016-11-10 18:48:55 --> Security Class Initialized
DEBUG - 2016-11-10 18:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:48:55 --> Input Class Initialized
INFO - 2016-11-10 18:48:55 --> Language Class Initialized
INFO - 2016-11-10 18:48:55 --> Loader Class Initialized
INFO - 2016-11-10 18:48:55 --> Helper loaded: url_helper
INFO - 2016-11-10 18:48:55 --> Helper loaded: form_helper
INFO - 2016-11-10 18:48:55 --> Database Driver Class Initialized
INFO - 2016-11-10 18:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:48:55 --> Controller Class Initialized
INFO - 2016-11-10 18:48:55 --> Model Class Initialized
INFO - 2016-11-10 18:48:55 --> Model Class Initialized
INFO - 2016-11-10 18:48:55 --> Model Class Initialized
INFO - 2016-11-10 18:48:55 --> Model Class Initialized
INFO - 2016-11-10 18:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 18:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 18:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 18:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 18:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 18:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 18:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 18:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 18:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:48:55 --> Final output sent to browser
DEBUG - 2016-11-10 18:48:55 --> Total execution time: 0.6398
INFO - 2016-11-10 18:51:07 --> Config Class Initialized
INFO - 2016-11-10 18:51:07 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:51:07 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:51:07 --> Utf8 Class Initialized
INFO - 2016-11-10 18:51:07 --> URI Class Initialized
INFO - 2016-11-10 18:51:07 --> Router Class Initialized
INFO - 2016-11-10 18:51:07 --> Output Class Initialized
INFO - 2016-11-10 18:51:07 --> Security Class Initialized
DEBUG - 2016-11-10 18:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:51:07 --> Input Class Initialized
INFO - 2016-11-10 18:51:07 --> Language Class Initialized
INFO - 2016-11-10 18:51:07 --> Loader Class Initialized
INFO - 2016-11-10 18:51:07 --> Helper loaded: url_helper
INFO - 2016-11-10 18:51:07 --> Helper loaded: form_helper
INFO - 2016-11-10 18:51:07 --> Database Driver Class Initialized
INFO - 2016-11-10 18:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:51:07 --> Controller Class Initialized
INFO - 2016-11-10 18:51:07 --> Model Class Initialized
INFO - 2016-11-10 18:51:07 --> Model Class Initialized
INFO - 2016-11-10 18:51:07 --> Model Class Initialized
INFO - 2016-11-10 18:51:07 --> Model Class Initialized
DEBUG - 2016-11-10 18:51:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 18:51:07 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
ERROR - 2016-11-10 18:51:07 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
INFO - 2016-11-10 18:51:07 --> Config Class Initialized
INFO - 2016-11-10 18:51:08 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:51:08 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:51:08 --> Utf8 Class Initialized
INFO - 2016-11-10 18:51:08 --> URI Class Initialized
DEBUG - 2016-11-10 18:51:08 --> No URI present. Default controller set.
INFO - 2016-11-10 18:51:08 --> Router Class Initialized
INFO - 2016-11-10 18:51:08 --> Output Class Initialized
INFO - 2016-11-10 18:51:08 --> Security Class Initialized
DEBUG - 2016-11-10 18:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:51:08 --> Input Class Initialized
INFO - 2016-11-10 18:51:08 --> Language Class Initialized
INFO - 2016-11-10 18:51:08 --> Loader Class Initialized
INFO - 2016-11-10 18:51:08 --> Helper loaded: url_helper
INFO - 2016-11-10 18:51:08 --> Helper loaded: form_helper
INFO - 2016-11-10 18:51:08 --> Database Driver Class Initialized
INFO - 2016-11-10 18:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:51:08 --> Controller Class Initialized
INFO - 2016-11-10 18:51:08 --> Model Class Initialized
INFO - 2016-11-10 18:51:08 --> Model Class Initialized
INFO - 2016-11-10 18:51:08 --> Model Class Initialized
INFO - 2016-11-10 18:51:08 --> Model Class Initialized
INFO - 2016-11-10 18:51:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:51:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 18:51:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:51:08 --> Final output sent to browser
DEBUG - 2016-11-10 18:51:08 --> Total execution time: 0.4707
INFO - 2016-11-10 18:51:16 --> Config Class Initialized
INFO - 2016-11-10 18:51:16 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:51:16 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:51:16 --> Utf8 Class Initialized
INFO - 2016-11-10 18:51:16 --> URI Class Initialized
INFO - 2016-11-10 18:51:16 --> Router Class Initialized
INFO - 2016-11-10 18:51:16 --> Output Class Initialized
INFO - 2016-11-10 18:51:16 --> Security Class Initialized
DEBUG - 2016-11-10 18:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:51:16 --> Input Class Initialized
INFO - 2016-11-10 18:51:16 --> Language Class Initialized
INFO - 2016-11-10 18:51:16 --> Loader Class Initialized
INFO - 2016-11-10 18:51:16 --> Helper loaded: url_helper
INFO - 2016-11-10 18:51:16 --> Helper loaded: form_helper
INFO - 2016-11-10 18:51:16 --> Database Driver Class Initialized
INFO - 2016-11-10 18:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:51:16 --> Controller Class Initialized
INFO - 2016-11-10 18:51:16 --> Model Class Initialized
INFO - 2016-11-10 18:51:16 --> Model Class Initialized
INFO - 2016-11-10 18:51:16 --> Model Class Initialized
INFO - 2016-11-10 18:51:16 --> Model Class Initialized
DEBUG - 2016-11-10 18:51:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 18:51:16 --> Model Class Initialized
INFO - 2016-11-10 18:51:16 --> Final output sent to browser
DEBUG - 2016-11-10 18:51:16 --> Total execution time: 0.4425
INFO - 2016-11-10 18:51:16 --> Config Class Initialized
INFO - 2016-11-10 18:51:16 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:51:16 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:51:17 --> Utf8 Class Initialized
INFO - 2016-11-10 18:51:17 --> URI Class Initialized
DEBUG - 2016-11-10 18:51:17 --> No URI present. Default controller set.
INFO - 2016-11-10 18:51:17 --> Router Class Initialized
INFO - 2016-11-10 18:51:17 --> Output Class Initialized
INFO - 2016-11-10 18:51:17 --> Security Class Initialized
DEBUG - 2016-11-10 18:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:51:17 --> Input Class Initialized
INFO - 2016-11-10 18:51:17 --> Language Class Initialized
INFO - 2016-11-10 18:51:17 --> Loader Class Initialized
INFO - 2016-11-10 18:51:17 --> Helper loaded: url_helper
INFO - 2016-11-10 18:51:17 --> Helper loaded: form_helper
INFO - 2016-11-10 18:51:17 --> Database Driver Class Initialized
INFO - 2016-11-10 18:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:51:17 --> Controller Class Initialized
INFO - 2016-11-10 18:51:17 --> Model Class Initialized
INFO - 2016-11-10 18:51:17 --> Model Class Initialized
INFO - 2016-11-10 18:51:17 --> Model Class Initialized
INFO - 2016-11-10 18:51:17 --> Model Class Initialized
INFO - 2016-11-10 18:51:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:51:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:51:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:51:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-10 18:51:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-10 18:51:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-10 18:51:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-10 18:51:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-10 18:51:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-10 18:51:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 18:51:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:51:17 --> Final output sent to browser
DEBUG - 2016-11-10 18:51:17 --> Total execution time: 0.7191
INFO - 2016-11-10 18:51:28 --> Config Class Initialized
INFO - 2016-11-10 18:51:28 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:51:28 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:51:28 --> Utf8 Class Initialized
INFO - 2016-11-10 18:51:28 --> URI Class Initialized
INFO - 2016-11-10 18:51:28 --> Router Class Initialized
INFO - 2016-11-10 18:51:28 --> Output Class Initialized
INFO - 2016-11-10 18:51:28 --> Security Class Initialized
DEBUG - 2016-11-10 18:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:51:28 --> Input Class Initialized
INFO - 2016-11-10 18:51:28 --> Language Class Initialized
INFO - 2016-11-10 18:51:28 --> Loader Class Initialized
INFO - 2016-11-10 18:51:28 --> Helper loaded: url_helper
INFO - 2016-11-10 18:51:28 --> Helper loaded: form_helper
INFO - 2016-11-10 18:51:28 --> Database Driver Class Initialized
INFO - 2016-11-10 18:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:51:28 --> Controller Class Initialized
INFO - 2016-11-10 18:51:28 --> Model Class Initialized
INFO - 2016-11-10 18:51:28 --> Model Class Initialized
INFO - 2016-11-10 18:51:28 --> Model Class Initialized
INFO - 2016-11-10 18:51:28 --> Model Class Initialized
DEBUG - 2016-11-10 18:51:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 18:51:28 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
ERROR - 2016-11-10 18:51:28 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
INFO - 2016-11-10 18:51:28 --> Config Class Initialized
INFO - 2016-11-10 18:51:28 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:51:28 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:51:28 --> Utf8 Class Initialized
INFO - 2016-11-10 18:51:28 --> URI Class Initialized
DEBUG - 2016-11-10 18:51:28 --> No URI present. Default controller set.
INFO - 2016-11-10 18:51:28 --> Router Class Initialized
INFO - 2016-11-10 18:51:28 --> Output Class Initialized
INFO - 2016-11-10 18:51:28 --> Security Class Initialized
DEBUG - 2016-11-10 18:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:51:28 --> Input Class Initialized
INFO - 2016-11-10 18:51:28 --> Language Class Initialized
INFO - 2016-11-10 18:51:28 --> Loader Class Initialized
INFO - 2016-11-10 18:51:28 --> Helper loaded: url_helper
INFO - 2016-11-10 18:51:28 --> Helper loaded: form_helper
INFO - 2016-11-10 18:51:28 --> Database Driver Class Initialized
INFO - 2016-11-10 18:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:51:28 --> Controller Class Initialized
INFO - 2016-11-10 18:51:28 --> Model Class Initialized
INFO - 2016-11-10 18:51:28 --> Model Class Initialized
INFO - 2016-11-10 18:51:28 --> Model Class Initialized
INFO - 2016-11-10 18:51:28 --> Model Class Initialized
INFO - 2016-11-10 18:51:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:51:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 18:51:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:51:29 --> Final output sent to browser
DEBUG - 2016-11-10 18:51:29 --> Total execution time: 0.4856
INFO - 2016-11-10 18:52:11 --> Config Class Initialized
INFO - 2016-11-10 18:52:11 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:52:11 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:52:11 --> Utf8 Class Initialized
INFO - 2016-11-10 18:52:11 --> URI Class Initialized
INFO - 2016-11-10 18:52:11 --> Router Class Initialized
INFO - 2016-11-10 18:52:11 --> Output Class Initialized
INFO - 2016-11-10 18:52:11 --> Security Class Initialized
DEBUG - 2016-11-10 18:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:52:11 --> Input Class Initialized
INFO - 2016-11-10 18:52:11 --> Language Class Initialized
INFO - 2016-11-10 18:52:11 --> Loader Class Initialized
INFO - 2016-11-10 18:52:11 --> Helper loaded: url_helper
INFO - 2016-11-10 18:52:11 --> Helper loaded: form_helper
INFO - 2016-11-10 18:52:11 --> Database Driver Class Initialized
INFO - 2016-11-10 18:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:52:11 --> Controller Class Initialized
INFO - 2016-11-10 18:52:11 --> Model Class Initialized
INFO - 2016-11-10 18:52:11 --> Model Class Initialized
INFO - 2016-11-10 18:52:11 --> Model Class Initialized
INFO - 2016-11-10 18:52:11 --> Model Class Initialized
DEBUG - 2016-11-10 18:52:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 18:52:11 --> Model Class Initialized
INFO - 2016-11-10 18:52:11 --> Final output sent to browser
DEBUG - 2016-11-10 18:52:11 --> Total execution time: 0.4325
INFO - 2016-11-10 18:52:11 --> Config Class Initialized
INFO - 2016-11-10 18:52:11 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:52:11 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:52:11 --> Utf8 Class Initialized
INFO - 2016-11-10 18:52:11 --> URI Class Initialized
DEBUG - 2016-11-10 18:52:11 --> No URI present. Default controller set.
INFO - 2016-11-10 18:52:11 --> Router Class Initialized
INFO - 2016-11-10 18:52:11 --> Output Class Initialized
INFO - 2016-11-10 18:52:11 --> Security Class Initialized
DEBUG - 2016-11-10 18:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:52:11 --> Input Class Initialized
INFO - 2016-11-10 18:52:11 --> Language Class Initialized
INFO - 2016-11-10 18:52:11 --> Loader Class Initialized
INFO - 2016-11-10 18:52:11 --> Helper loaded: url_helper
INFO - 2016-11-10 18:52:11 --> Helper loaded: form_helper
INFO - 2016-11-10 18:52:11 --> Database Driver Class Initialized
INFO - 2016-11-10 18:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:52:11 --> Controller Class Initialized
INFO - 2016-11-10 18:52:11 --> Model Class Initialized
INFO - 2016-11-10 18:52:11 --> Model Class Initialized
INFO - 2016-11-10 18:52:11 --> Model Class Initialized
INFO - 2016-11-10 18:52:12 --> Model Class Initialized
INFO - 2016-11-10 18:52:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:52:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:52:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:52:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 18:52:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 18:52:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 18:52:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 18:52:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 18:52:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 18:52:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 18:52:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 18:52:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:52:12 --> Final output sent to browser
DEBUG - 2016-11-10 18:52:12 --> Total execution time: 0.6489
INFO - 2016-11-10 18:55:04 --> Config Class Initialized
INFO - 2016-11-10 18:55:04 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:55:04 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:55:04 --> Utf8 Class Initialized
INFO - 2016-11-10 18:55:04 --> URI Class Initialized
DEBUG - 2016-11-10 18:55:04 --> No URI present. Default controller set.
INFO - 2016-11-10 18:55:04 --> Router Class Initialized
INFO - 2016-11-10 18:55:04 --> Output Class Initialized
INFO - 2016-11-10 18:55:04 --> Security Class Initialized
DEBUG - 2016-11-10 18:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:55:04 --> Input Class Initialized
INFO - 2016-11-10 18:55:04 --> Language Class Initialized
INFO - 2016-11-10 18:55:04 --> Loader Class Initialized
INFO - 2016-11-10 18:55:04 --> Helper loaded: url_helper
INFO - 2016-11-10 18:55:04 --> Helper loaded: form_helper
INFO - 2016-11-10 18:55:04 --> Database Driver Class Initialized
INFO - 2016-11-10 18:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:55:04 --> Controller Class Initialized
INFO - 2016-11-10 18:55:04 --> Model Class Initialized
INFO - 2016-11-10 18:55:04 --> Model Class Initialized
INFO - 2016-11-10 18:55:04 --> Model Class Initialized
INFO - 2016-11-10 18:55:04 --> Model Class Initialized
INFO - 2016-11-10 18:55:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:55:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:59:25 --> Config Class Initialized
INFO - 2016-11-10 18:59:25 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:59:25 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:59:25 --> Utf8 Class Initialized
INFO - 2016-11-10 18:59:25 --> URI Class Initialized
DEBUG - 2016-11-10 18:59:25 --> No URI present. Default controller set.
INFO - 2016-11-10 18:59:25 --> Router Class Initialized
INFO - 2016-11-10 18:59:25 --> Output Class Initialized
INFO - 2016-11-10 18:59:25 --> Security Class Initialized
DEBUG - 2016-11-10 18:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:59:26 --> Input Class Initialized
INFO - 2016-11-10 18:59:26 --> Language Class Initialized
INFO - 2016-11-10 18:59:26 --> Loader Class Initialized
INFO - 2016-11-10 18:59:26 --> Helper loaded: url_helper
INFO - 2016-11-10 18:59:26 --> Helper loaded: form_helper
INFO - 2016-11-10 18:59:26 --> Database Driver Class Initialized
INFO - 2016-11-10 18:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:59:26 --> Controller Class Initialized
INFO - 2016-11-10 18:59:26 --> Model Class Initialized
INFO - 2016-11-10 18:59:26 --> Model Class Initialized
INFO - 2016-11-10 18:59:26 --> Model Class Initialized
INFO - 2016-11-10 18:59:26 --> Model Class Initialized
INFO - 2016-11-10 18:59:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:59:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:59:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:59:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 18:59:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 18:59:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 18:59:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 18:59:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 18:59:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 18:59:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 18:59:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 18:59:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:59:26 --> Final output sent to browser
DEBUG - 2016-11-10 18:59:26 --> Total execution time: 0.6520
INFO - 2016-11-10 18:59:30 --> Config Class Initialized
INFO - 2016-11-10 18:59:30 --> Hooks Class Initialized
DEBUG - 2016-11-10 18:59:30 --> UTF-8 Support Enabled
INFO - 2016-11-10 18:59:30 --> Utf8 Class Initialized
INFO - 2016-11-10 18:59:30 --> URI Class Initialized
DEBUG - 2016-11-10 18:59:30 --> No URI present. Default controller set.
INFO - 2016-11-10 18:59:30 --> Router Class Initialized
INFO - 2016-11-10 18:59:30 --> Output Class Initialized
INFO - 2016-11-10 18:59:30 --> Security Class Initialized
DEBUG - 2016-11-10 18:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 18:59:30 --> Input Class Initialized
INFO - 2016-11-10 18:59:30 --> Language Class Initialized
INFO - 2016-11-10 18:59:30 --> Loader Class Initialized
INFO - 2016-11-10 18:59:30 --> Helper loaded: url_helper
INFO - 2016-11-10 18:59:30 --> Helper loaded: form_helper
INFO - 2016-11-10 18:59:30 --> Database Driver Class Initialized
INFO - 2016-11-10 18:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 18:59:31 --> Controller Class Initialized
INFO - 2016-11-10 18:59:31 --> Model Class Initialized
INFO - 2016-11-10 18:59:31 --> Model Class Initialized
INFO - 2016-11-10 18:59:31 --> Model Class Initialized
INFO - 2016-11-10 18:59:31 --> Model Class Initialized
INFO - 2016-11-10 18:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 18:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 18:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 18:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 18:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 18:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 18:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 18:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 18:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 18:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 18:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 18:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 18:59:31 --> Final output sent to browser
DEBUG - 2016-11-10 18:59:31 --> Total execution time: 0.6928
INFO - 2016-11-10 20:53:17 --> Config Class Initialized
INFO - 2016-11-10 20:53:17 --> Hooks Class Initialized
DEBUG - 2016-11-10 20:53:18 --> UTF-8 Support Enabled
INFO - 2016-11-10 20:53:18 --> Utf8 Class Initialized
INFO - 2016-11-10 20:53:18 --> URI Class Initialized
INFO - 2016-11-10 20:53:18 --> Router Class Initialized
INFO - 2016-11-10 20:53:18 --> Output Class Initialized
INFO - 2016-11-10 20:53:18 --> Security Class Initialized
DEBUG - 2016-11-10 20:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 20:53:18 --> Input Class Initialized
INFO - 2016-11-10 20:53:18 --> Language Class Initialized
INFO - 2016-11-10 20:53:19 --> Loader Class Initialized
INFO - 2016-11-10 20:53:19 --> Helper loaded: url_helper
INFO - 2016-11-10 20:53:19 --> Helper loaded: form_helper
INFO - 2016-11-10 20:53:19 --> Database Driver Class Initialized
INFO - 2016-11-10 20:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 20:53:19 --> Controller Class Initialized
INFO - 2016-11-10 20:53:19 --> Model Class Initialized
INFO - 2016-11-10 20:53:19 --> Model Class Initialized
INFO - 2016-11-10 20:53:19 --> Model Class Initialized
INFO - 2016-11-10 20:53:19 --> Model Class Initialized
DEBUG - 2016-11-10 20:53:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 20:53:19 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 141
ERROR - 2016-11-10 20:53:19 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 141
INFO - 2016-11-10 20:53:19 --> Config Class Initialized
INFO - 2016-11-10 20:53:19 --> Hooks Class Initialized
DEBUG - 2016-11-10 20:53:19 --> UTF-8 Support Enabled
INFO - 2016-11-10 20:53:19 --> Utf8 Class Initialized
INFO - 2016-11-10 20:53:19 --> URI Class Initialized
DEBUG - 2016-11-10 20:53:19 --> No URI present. Default controller set.
INFO - 2016-11-10 20:53:19 --> Router Class Initialized
INFO - 2016-11-10 20:53:20 --> Output Class Initialized
INFO - 2016-11-10 20:53:20 --> Security Class Initialized
DEBUG - 2016-11-10 20:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 20:53:20 --> Input Class Initialized
INFO - 2016-11-10 20:53:20 --> Language Class Initialized
INFO - 2016-11-10 20:53:20 --> Loader Class Initialized
INFO - 2016-11-10 20:53:20 --> Helper loaded: url_helper
INFO - 2016-11-10 20:53:20 --> Helper loaded: form_helper
INFO - 2016-11-10 20:53:20 --> Database Driver Class Initialized
INFO - 2016-11-10 20:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 20:53:20 --> Controller Class Initialized
INFO - 2016-11-10 20:53:20 --> Model Class Initialized
INFO - 2016-11-10 20:53:20 --> Model Class Initialized
INFO - 2016-11-10 20:53:20 --> Model Class Initialized
INFO - 2016-11-10 20:53:20 --> Model Class Initialized
INFO - 2016-11-10 20:53:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 20:53:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 20:53:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 20:53:20 --> Final output sent to browser
DEBUG - 2016-11-10 20:53:20 --> Total execution time: 0.6902
INFO - 2016-11-10 20:54:51 --> Config Class Initialized
INFO - 2016-11-10 20:54:51 --> Hooks Class Initialized
DEBUG - 2016-11-10 20:54:51 --> UTF-8 Support Enabled
INFO - 2016-11-10 20:54:51 --> Utf8 Class Initialized
INFO - 2016-11-10 20:54:51 --> URI Class Initialized
INFO - 2016-11-10 20:54:51 --> Router Class Initialized
INFO - 2016-11-10 20:54:51 --> Output Class Initialized
INFO - 2016-11-10 20:54:51 --> Security Class Initialized
DEBUG - 2016-11-10 20:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 20:54:52 --> Input Class Initialized
INFO - 2016-11-10 20:54:52 --> Language Class Initialized
INFO - 2016-11-10 20:54:52 --> Loader Class Initialized
INFO - 2016-11-10 20:54:52 --> Helper loaded: url_helper
INFO - 2016-11-10 20:54:52 --> Helper loaded: form_helper
INFO - 2016-11-10 20:54:52 --> Database Driver Class Initialized
INFO - 2016-11-10 20:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 20:54:52 --> Controller Class Initialized
INFO - 2016-11-10 20:54:52 --> Model Class Initialized
INFO - 2016-11-10 20:54:52 --> Model Class Initialized
INFO - 2016-11-10 20:54:52 --> Model Class Initialized
INFO - 2016-11-10 20:54:52 --> Model Class Initialized
DEBUG - 2016-11-10 20:54:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 20:54:52 --> Model Class Initialized
INFO - 2016-11-10 20:54:52 --> Final output sent to browser
DEBUG - 2016-11-10 20:54:52 --> Total execution time: 0.4499
INFO - 2016-11-10 20:54:52 --> Config Class Initialized
INFO - 2016-11-10 20:54:52 --> Hooks Class Initialized
DEBUG - 2016-11-10 20:54:52 --> UTF-8 Support Enabled
INFO - 2016-11-10 20:54:52 --> Utf8 Class Initialized
INFO - 2016-11-10 20:54:52 --> URI Class Initialized
DEBUG - 2016-11-10 20:54:52 --> No URI present. Default controller set.
INFO - 2016-11-10 20:54:52 --> Router Class Initialized
INFO - 2016-11-10 20:54:52 --> Output Class Initialized
INFO - 2016-11-10 20:54:52 --> Security Class Initialized
DEBUG - 2016-11-10 20:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 20:54:52 --> Input Class Initialized
INFO - 2016-11-10 20:54:52 --> Language Class Initialized
INFO - 2016-11-10 20:54:52 --> Loader Class Initialized
INFO - 2016-11-10 20:54:52 --> Helper loaded: url_helper
INFO - 2016-11-10 20:54:52 --> Helper loaded: form_helper
INFO - 2016-11-10 20:54:52 --> Database Driver Class Initialized
INFO - 2016-11-10 20:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 20:54:52 --> Controller Class Initialized
INFO - 2016-11-10 20:54:52 --> Model Class Initialized
INFO - 2016-11-10 20:54:52 --> Model Class Initialized
INFO - 2016-11-10 20:54:52 --> Model Class Initialized
INFO - 2016-11-10 20:54:52 --> Model Class Initialized
INFO - 2016-11-10 20:54:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 20:54:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 20:54:53 --> Query error: Unknown column 'name' in 'field list' - Invalid query: SELECT `id`, `name`
FROM `Component`
INFO - 2016-11-10 20:54:53 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 20:56:36 --> Config Class Initialized
INFO - 2016-11-10 20:56:36 --> Hooks Class Initialized
DEBUG - 2016-11-10 20:56:36 --> UTF-8 Support Enabled
INFO - 2016-11-10 20:56:36 --> Utf8 Class Initialized
INFO - 2016-11-10 20:56:36 --> URI Class Initialized
DEBUG - 2016-11-10 20:56:36 --> No URI present. Default controller set.
INFO - 2016-11-10 20:56:36 --> Router Class Initialized
INFO - 2016-11-10 20:56:36 --> Output Class Initialized
INFO - 2016-11-10 20:56:36 --> Security Class Initialized
DEBUG - 2016-11-10 20:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 20:56:36 --> Input Class Initialized
INFO - 2016-11-10 20:56:36 --> Language Class Initialized
INFO - 2016-11-10 20:56:36 --> Loader Class Initialized
INFO - 2016-11-10 20:56:36 --> Helper loaded: url_helper
INFO - 2016-11-10 20:56:36 --> Helper loaded: form_helper
INFO - 2016-11-10 20:56:36 --> Database Driver Class Initialized
INFO - 2016-11-10 20:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 20:56:36 --> Controller Class Initialized
INFO - 2016-11-10 20:56:36 --> Model Class Initialized
INFO - 2016-11-10 20:56:36 --> Model Class Initialized
INFO - 2016-11-10 20:56:36 --> Model Class Initialized
INFO - 2016-11-10 20:56:36 --> Model Class Initialized
INFO - 2016-11-10 20:56:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 20:56:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 20:56:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 20:56:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 20:56:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 20:56:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 20:56:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 20:56:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 20:56:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 20:56:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 20:56:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 20:56:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 20:56:36 --> Final output sent to browser
DEBUG - 2016-11-10 20:56:36 --> Total execution time: 0.9235
INFO - 2016-11-10 20:57:35 --> Config Class Initialized
INFO - 2016-11-10 20:57:35 --> Hooks Class Initialized
DEBUG - 2016-11-10 20:57:35 --> UTF-8 Support Enabled
INFO - 2016-11-10 20:57:35 --> Utf8 Class Initialized
INFO - 2016-11-10 20:57:35 --> URI Class Initialized
INFO - 2016-11-10 20:57:35 --> Router Class Initialized
INFO - 2016-11-10 20:57:35 --> Output Class Initialized
INFO - 2016-11-10 20:57:35 --> Security Class Initialized
DEBUG - 2016-11-10 20:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 20:57:35 --> Input Class Initialized
INFO - 2016-11-10 20:57:35 --> Language Class Initialized
INFO - 2016-11-10 20:57:35 --> Loader Class Initialized
INFO - 2016-11-10 20:57:35 --> Helper loaded: url_helper
INFO - 2016-11-10 20:57:35 --> Helper loaded: form_helper
INFO - 2016-11-10 20:57:35 --> Database Driver Class Initialized
INFO - 2016-11-10 20:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 20:57:35 --> Controller Class Initialized
INFO - 2016-11-10 20:57:35 --> Model Class Initialized
INFO - 2016-11-10 20:57:35 --> Model Class Initialized
INFO - 2016-11-10 20:57:35 --> Model Class Initialized
INFO - 2016-11-10 20:57:35 --> Model Class Initialized
DEBUG - 2016-11-10 20:57:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 20:57:35 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 141
ERROR - 2016-11-10 20:57:35 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 141
INFO - 2016-11-10 20:57:35 --> Config Class Initialized
INFO - 2016-11-10 20:57:35 --> Hooks Class Initialized
DEBUG - 2016-11-10 20:57:35 --> UTF-8 Support Enabled
INFO - 2016-11-10 20:57:35 --> Utf8 Class Initialized
INFO - 2016-11-10 20:57:36 --> URI Class Initialized
DEBUG - 2016-11-10 20:57:36 --> No URI present. Default controller set.
INFO - 2016-11-10 20:57:36 --> Router Class Initialized
INFO - 2016-11-10 20:57:36 --> Output Class Initialized
INFO - 2016-11-10 20:57:36 --> Security Class Initialized
DEBUG - 2016-11-10 20:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 20:57:36 --> Input Class Initialized
INFO - 2016-11-10 20:57:36 --> Language Class Initialized
INFO - 2016-11-10 20:57:36 --> Loader Class Initialized
INFO - 2016-11-10 20:57:36 --> Helper loaded: url_helper
INFO - 2016-11-10 20:57:36 --> Helper loaded: form_helper
INFO - 2016-11-10 20:57:36 --> Database Driver Class Initialized
INFO - 2016-11-10 20:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 20:57:36 --> Controller Class Initialized
INFO - 2016-11-10 20:57:36 --> Model Class Initialized
INFO - 2016-11-10 20:57:36 --> Model Class Initialized
INFO - 2016-11-10 20:57:36 --> Model Class Initialized
INFO - 2016-11-10 20:57:36 --> Model Class Initialized
INFO - 2016-11-10 20:57:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 20:57:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 20:57:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 20:57:36 --> Final output sent to browser
DEBUG - 2016-11-10 20:57:36 --> Total execution time: 0.4718
INFO - 2016-11-10 20:57:59 --> Config Class Initialized
INFO - 2016-11-10 20:57:59 --> Hooks Class Initialized
DEBUG - 2016-11-10 20:57:59 --> UTF-8 Support Enabled
INFO - 2016-11-10 20:57:59 --> Utf8 Class Initialized
INFO - 2016-11-10 20:57:59 --> URI Class Initialized
INFO - 2016-11-10 20:57:59 --> Router Class Initialized
INFO - 2016-11-10 20:57:59 --> Output Class Initialized
INFO - 2016-11-10 20:57:59 --> Security Class Initialized
DEBUG - 2016-11-10 20:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 20:57:59 --> Input Class Initialized
INFO - 2016-11-10 20:57:59 --> Language Class Initialized
INFO - 2016-11-10 20:57:59 --> Loader Class Initialized
INFO - 2016-11-10 20:57:59 --> Helper loaded: url_helper
INFO - 2016-11-10 20:57:59 --> Helper loaded: form_helper
INFO - 2016-11-10 20:57:59 --> Database Driver Class Initialized
INFO - 2016-11-10 20:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 20:57:59 --> Controller Class Initialized
INFO - 2016-11-10 20:57:59 --> Model Class Initialized
INFO - 2016-11-10 20:57:59 --> Model Class Initialized
INFO - 2016-11-10 20:57:59 --> Model Class Initialized
INFO - 2016-11-10 20:57:59 --> Model Class Initialized
DEBUG - 2016-11-10 20:57:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 20:58:00 --> Model Class Initialized
INFO - 2016-11-10 20:58:00 --> Final output sent to browser
DEBUG - 2016-11-10 20:58:00 --> Total execution time: 0.5804
INFO - 2016-11-10 20:58:00 --> Config Class Initialized
INFO - 2016-11-10 20:58:00 --> Hooks Class Initialized
DEBUG - 2016-11-10 20:58:00 --> UTF-8 Support Enabled
INFO - 2016-11-10 20:58:00 --> Utf8 Class Initialized
INFO - 2016-11-10 20:58:00 --> URI Class Initialized
DEBUG - 2016-11-10 20:58:00 --> No URI present. Default controller set.
INFO - 2016-11-10 20:58:00 --> Router Class Initialized
INFO - 2016-11-10 20:58:00 --> Output Class Initialized
INFO - 2016-11-10 20:58:00 --> Security Class Initialized
DEBUG - 2016-11-10 20:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 20:58:00 --> Input Class Initialized
INFO - 2016-11-10 20:58:00 --> Language Class Initialized
INFO - 2016-11-10 20:58:00 --> Loader Class Initialized
INFO - 2016-11-10 20:58:00 --> Helper loaded: url_helper
INFO - 2016-11-10 20:58:00 --> Helper loaded: form_helper
INFO - 2016-11-10 20:58:00 --> Database Driver Class Initialized
INFO - 2016-11-10 20:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 20:58:00 --> Controller Class Initialized
INFO - 2016-11-10 20:58:00 --> Model Class Initialized
INFO - 2016-11-10 20:58:00 --> Model Class Initialized
INFO - 2016-11-10 20:58:00 --> Model Class Initialized
INFO - 2016-11-10 20:58:00 --> Model Class Initialized
INFO - 2016-11-10 20:58:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 20:58:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 20:58:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 20:58:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 20:58:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 20:58:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 20:58:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 20:58:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 20:58:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 20:58:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 20:58:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 20:58:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 20:58:00 --> Final output sent to browser
DEBUG - 2016-11-10 20:58:00 --> Total execution time: 0.7357
INFO - 2016-11-10 21:05:01 --> Config Class Initialized
INFO - 2016-11-10 21:05:01 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:05:01 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:05:01 --> Utf8 Class Initialized
INFO - 2016-11-10 21:05:01 --> URI Class Initialized
DEBUG - 2016-11-10 21:05:01 --> No URI present. Default controller set.
INFO - 2016-11-10 21:05:01 --> Router Class Initialized
INFO - 2016-11-10 21:05:02 --> Output Class Initialized
INFO - 2016-11-10 21:05:02 --> Security Class Initialized
DEBUG - 2016-11-10 21:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:05:02 --> Input Class Initialized
INFO - 2016-11-10 21:05:02 --> Language Class Initialized
INFO - 2016-11-10 21:05:02 --> Loader Class Initialized
INFO - 2016-11-10 21:05:02 --> Helper loaded: url_helper
INFO - 2016-11-10 21:05:02 --> Helper loaded: form_helper
INFO - 2016-11-10 21:05:03 --> Database Driver Class Initialized
INFO - 2016-11-10 21:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:05:03 --> Controller Class Initialized
INFO - 2016-11-10 21:05:03 --> Model Class Initialized
INFO - 2016-11-10 21:05:03 --> Model Class Initialized
INFO - 2016-11-10 21:05:03 --> Model Class Initialized
INFO - 2016-11-10 21:05:03 --> Model Class Initialized
INFO - 2016-11-10 21:05:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:05:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 21:05:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:05:03 --> Final output sent to browser
DEBUG - 2016-11-10 21:05:04 --> Total execution time: 3.2021
INFO - 2016-11-10 21:05:14 --> Config Class Initialized
INFO - 2016-11-10 21:05:14 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:05:14 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:05:14 --> Utf8 Class Initialized
INFO - 2016-11-10 21:05:14 --> URI Class Initialized
INFO - 2016-11-10 21:05:14 --> Router Class Initialized
INFO - 2016-11-10 21:05:14 --> Output Class Initialized
INFO - 2016-11-10 21:05:14 --> Security Class Initialized
DEBUG - 2016-11-10 21:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:05:14 --> Input Class Initialized
INFO - 2016-11-10 21:05:15 --> Language Class Initialized
INFO - 2016-11-10 21:05:15 --> Loader Class Initialized
INFO - 2016-11-10 21:05:15 --> Helper loaded: url_helper
INFO - 2016-11-10 21:05:15 --> Helper loaded: form_helper
INFO - 2016-11-10 21:05:15 --> Database Driver Class Initialized
INFO - 2016-11-10 21:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:05:15 --> Controller Class Initialized
INFO - 2016-11-10 21:05:15 --> Model Class Initialized
INFO - 2016-11-10 21:05:15 --> Model Class Initialized
INFO - 2016-11-10 21:05:15 --> Model Class Initialized
INFO - 2016-11-10 21:05:15 --> Model Class Initialized
DEBUG - 2016-11-10 21:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 21:05:15 --> Model Class Initialized
INFO - 2016-11-10 21:05:15 --> Final output sent to browser
DEBUG - 2016-11-10 21:05:15 --> Total execution time: 0.6426
INFO - 2016-11-10 21:05:15 --> Config Class Initialized
INFO - 2016-11-10 21:05:15 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:05:15 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:05:15 --> Utf8 Class Initialized
INFO - 2016-11-10 21:05:15 --> URI Class Initialized
DEBUG - 2016-11-10 21:05:15 --> No URI present. Default controller set.
INFO - 2016-11-10 21:05:15 --> Router Class Initialized
INFO - 2016-11-10 21:05:15 --> Output Class Initialized
INFO - 2016-11-10 21:05:15 --> Security Class Initialized
DEBUG - 2016-11-10 21:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:05:15 --> Input Class Initialized
INFO - 2016-11-10 21:05:15 --> Language Class Initialized
INFO - 2016-11-10 21:05:15 --> Loader Class Initialized
INFO - 2016-11-10 21:05:15 --> Helper loaded: url_helper
INFO - 2016-11-10 21:05:15 --> Helper loaded: form_helper
INFO - 2016-11-10 21:05:16 --> Database Driver Class Initialized
INFO - 2016-11-10 21:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:05:16 --> Controller Class Initialized
INFO - 2016-11-10 21:05:16 --> Model Class Initialized
INFO - 2016-11-10 21:05:16 --> Model Class Initialized
INFO - 2016-11-10 21:05:16 --> Model Class Initialized
INFO - 2016-11-10 21:05:16 --> Model Class Initialized
INFO - 2016-11-10 21:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 21:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 21:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 21:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 21:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 21:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 21:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 21:05:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 21:05:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 21:05:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 21:05:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:05:17 --> Final output sent to browser
DEBUG - 2016-11-10 21:05:17 --> Total execution time: 1.5227
INFO - 2016-11-10 21:05:55 --> Config Class Initialized
INFO - 2016-11-10 21:05:56 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:05:56 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:05:56 --> Utf8 Class Initialized
INFO - 2016-11-10 21:05:56 --> URI Class Initialized
INFO - 2016-11-10 21:05:56 --> Router Class Initialized
INFO - 2016-11-10 21:05:56 --> Output Class Initialized
INFO - 2016-11-10 21:05:56 --> Security Class Initialized
DEBUG - 2016-11-10 21:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:05:56 --> Input Class Initialized
INFO - 2016-11-10 21:05:56 --> Language Class Initialized
INFO - 2016-11-10 21:05:56 --> Loader Class Initialized
INFO - 2016-11-10 21:05:56 --> Helper loaded: url_helper
INFO - 2016-11-10 21:05:56 --> Helper loaded: form_helper
INFO - 2016-11-10 21:05:56 --> Database Driver Class Initialized
INFO - 2016-11-10 21:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:05:56 --> Controller Class Initialized
INFO - 2016-11-10 21:05:56 --> Model Class Initialized
INFO - 2016-11-10 21:05:56 --> Model Class Initialized
INFO - 2016-11-10 21:05:56 --> Model Class Initialized
INFO - 2016-11-10 21:05:56 --> Model Class Initialized
DEBUG - 2016-11-10 21:05:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 21:05:57 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 141
ERROR - 2016-11-10 21:05:57 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 141
INFO - 2016-11-10 21:05:57 --> Config Class Initialized
INFO - 2016-11-10 21:05:57 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:05:57 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:05:57 --> Utf8 Class Initialized
INFO - 2016-11-10 21:05:57 --> URI Class Initialized
DEBUG - 2016-11-10 21:05:57 --> No URI present. Default controller set.
INFO - 2016-11-10 21:05:57 --> Router Class Initialized
INFO - 2016-11-10 21:05:57 --> Output Class Initialized
INFO - 2016-11-10 21:05:57 --> Security Class Initialized
DEBUG - 2016-11-10 21:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:05:57 --> Input Class Initialized
INFO - 2016-11-10 21:05:57 --> Language Class Initialized
INFO - 2016-11-10 21:05:57 --> Loader Class Initialized
INFO - 2016-11-10 21:05:57 --> Helper loaded: url_helper
INFO - 2016-11-10 21:05:57 --> Helper loaded: form_helper
INFO - 2016-11-10 21:05:57 --> Database Driver Class Initialized
INFO - 2016-11-10 21:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:05:57 --> Controller Class Initialized
INFO - 2016-11-10 21:05:57 --> Model Class Initialized
INFO - 2016-11-10 21:05:57 --> Model Class Initialized
INFO - 2016-11-10 21:05:57 --> Model Class Initialized
INFO - 2016-11-10 21:05:57 --> Model Class Initialized
INFO - 2016-11-10 21:05:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:05:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 21:05:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:05:57 --> Final output sent to browser
DEBUG - 2016-11-10 21:05:57 --> Total execution time: 0.8053
INFO - 2016-11-10 21:06:05 --> Config Class Initialized
INFO - 2016-11-10 21:06:05 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:06:05 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:06:05 --> Utf8 Class Initialized
INFO - 2016-11-10 21:06:05 --> URI Class Initialized
INFO - 2016-11-10 21:06:05 --> Router Class Initialized
INFO - 2016-11-10 21:06:05 --> Output Class Initialized
INFO - 2016-11-10 21:06:05 --> Security Class Initialized
DEBUG - 2016-11-10 21:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:06:05 --> Input Class Initialized
INFO - 2016-11-10 21:06:05 --> Language Class Initialized
INFO - 2016-11-10 21:06:05 --> Loader Class Initialized
INFO - 2016-11-10 21:06:05 --> Helper loaded: url_helper
INFO - 2016-11-10 21:06:05 --> Helper loaded: form_helper
INFO - 2016-11-10 21:06:05 --> Database Driver Class Initialized
INFO - 2016-11-10 21:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:06:05 --> Controller Class Initialized
INFO - 2016-11-10 21:06:05 --> Model Class Initialized
INFO - 2016-11-10 21:06:05 --> Model Class Initialized
INFO - 2016-11-10 21:06:05 --> Model Class Initialized
INFO - 2016-11-10 21:06:05 --> Model Class Initialized
DEBUG - 2016-11-10 21:06:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 21:06:05 --> Model Class Initialized
INFO - 2016-11-10 21:06:05 --> Final output sent to browser
DEBUG - 2016-11-10 21:06:05 --> Total execution time: 0.7545
INFO - 2016-11-10 21:06:05 --> Config Class Initialized
INFO - 2016-11-10 21:06:05 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:06:05 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:06:05 --> Utf8 Class Initialized
INFO - 2016-11-10 21:06:05 --> URI Class Initialized
DEBUG - 2016-11-10 21:06:05 --> No URI present. Default controller set.
INFO - 2016-11-10 21:06:05 --> Router Class Initialized
INFO - 2016-11-10 21:06:05 --> Output Class Initialized
INFO - 2016-11-10 21:06:05 --> Security Class Initialized
DEBUG - 2016-11-10 21:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:06:06 --> Input Class Initialized
INFO - 2016-11-10 21:06:06 --> Language Class Initialized
INFO - 2016-11-10 21:06:06 --> Loader Class Initialized
INFO - 2016-11-10 21:06:06 --> Helper loaded: url_helper
INFO - 2016-11-10 21:06:06 --> Helper loaded: form_helper
INFO - 2016-11-10 21:06:06 --> Database Driver Class Initialized
INFO - 2016-11-10 21:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:06:06 --> Controller Class Initialized
INFO - 2016-11-10 21:06:06 --> Model Class Initialized
INFO - 2016-11-10 21:06:06 --> Model Class Initialized
INFO - 2016-11-10 21:06:06 --> Model Class Initialized
INFO - 2016-11-10 21:06:06 --> Model Class Initialized
INFO - 2016-11-10 21:06:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:06:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 21:06:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 21:06:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-10 21:06:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-10 21:06:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-10 21:06:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-10 21:06:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-10 21:06:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-10 21:06:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 21:06:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:06:06 --> Final output sent to browser
DEBUG - 2016-11-10 21:06:06 --> Total execution time: 1.0119
INFO - 2016-11-10 21:08:54 --> Config Class Initialized
INFO - 2016-11-10 21:08:54 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:08:54 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:08:54 --> Utf8 Class Initialized
INFO - 2016-11-10 21:08:54 --> URI Class Initialized
DEBUG - 2016-11-10 21:08:54 --> No URI present. Default controller set.
INFO - 2016-11-10 21:08:54 --> Router Class Initialized
INFO - 2016-11-10 21:08:54 --> Output Class Initialized
INFO - 2016-11-10 21:08:54 --> Security Class Initialized
DEBUG - 2016-11-10 21:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:08:54 --> Input Class Initialized
INFO - 2016-11-10 21:08:54 --> Language Class Initialized
INFO - 2016-11-10 21:08:54 --> Loader Class Initialized
INFO - 2016-11-10 21:08:54 --> Helper loaded: url_helper
INFO - 2016-11-10 21:08:54 --> Helper loaded: form_helper
INFO - 2016-11-10 21:08:54 --> Database Driver Class Initialized
INFO - 2016-11-10 21:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:08:54 --> Controller Class Initialized
INFO - 2016-11-10 21:08:54 --> Model Class Initialized
INFO - 2016-11-10 21:08:54 --> Model Class Initialized
INFO - 2016-11-10 21:08:55 --> Model Class Initialized
INFO - 2016-11-10 21:08:55 --> Model Class Initialized
INFO - 2016-11-10 21:08:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:08:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 21:08:55 --> Query error: Unknown column 'ls.name' in 'field list' - Invalid query: SELECT `ap`.`startDate`, `ap`.`endDate`, `ap`.`applicationDate`, `ap`.`numberOfDays`, `lt`.`name`, `ls`.`name`, `em`.`surname`
FROM (`applicationData` `ap`, `applicationData`)
LEFT JOIN `employee` as `em` ON `em`.`id` = `ap`.`idEmployee`
LEFT JOIN `leaveType` as `lt` ON `lt`.`id` = `ap`.`idLeaveType`
LEFT JOIN `leaveStatus` as `ls` ON `ls`.`id` = `ap`.`idLeaveType`
WHERE `em`.`idRole` IN(2, 3)
INFO - 2016-11-10 21:08:55 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 21:09:31 --> Config Class Initialized
INFO - 2016-11-10 21:09:31 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:09:31 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:09:31 --> Utf8 Class Initialized
INFO - 2016-11-10 21:09:31 --> URI Class Initialized
DEBUG - 2016-11-10 21:09:31 --> No URI present. Default controller set.
INFO - 2016-11-10 21:09:31 --> Router Class Initialized
INFO - 2016-11-10 21:09:31 --> Output Class Initialized
INFO - 2016-11-10 21:09:31 --> Security Class Initialized
DEBUG - 2016-11-10 21:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:09:31 --> Input Class Initialized
INFO - 2016-11-10 21:09:32 --> Language Class Initialized
INFO - 2016-11-10 21:09:32 --> Loader Class Initialized
INFO - 2016-11-10 21:09:32 --> Helper loaded: url_helper
INFO - 2016-11-10 21:09:32 --> Helper loaded: form_helper
INFO - 2016-11-10 21:09:32 --> Database Driver Class Initialized
INFO - 2016-11-10 21:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:09:32 --> Controller Class Initialized
INFO - 2016-11-10 21:09:32 --> Model Class Initialized
INFO - 2016-11-10 21:09:32 --> Model Class Initialized
INFO - 2016-11-10 21:09:32 --> Model Class Initialized
INFO - 2016-11-10 21:09:32 --> Model Class Initialized
INFO - 2016-11-10 21:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 21:09:32 --> Query error: Unknown column 'lt.statusName' in 'field list' - Invalid query: SELECT `ap`.`startDate`, `ap`.`endDate`, `ap`.`applicationDate`, `ap`.`numberOfDays`, `lt`.`statusName`, `ls`.`name`, `em`.`surname`
FROM (`applicationData` `ap`, `applicationData`)
LEFT JOIN `employee` as `em` ON `em`.`id` = `ap`.`idEmployee`
LEFT JOIN `leaveType` as `lt` ON `lt`.`id` = `ap`.`idLeaveType`
LEFT JOIN `leaveStatus` as `ls` ON `ls`.`id` = `ap`.`idLeaveType`
WHERE `em`.`idRole` IN(2, 3)
INFO - 2016-11-10 21:09:32 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 21:09:59 --> Config Class Initialized
INFO - 2016-11-10 21:09:59 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:09:59 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:09:59 --> Utf8 Class Initialized
INFO - 2016-11-10 21:09:59 --> URI Class Initialized
DEBUG - 2016-11-10 21:09:59 --> No URI present. Default controller set.
INFO - 2016-11-10 21:09:59 --> Router Class Initialized
INFO - 2016-11-10 21:09:59 --> Output Class Initialized
INFO - 2016-11-10 21:09:59 --> Security Class Initialized
DEBUG - 2016-11-10 21:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:09:59 --> Input Class Initialized
INFO - 2016-11-10 21:09:59 --> Language Class Initialized
INFO - 2016-11-10 21:09:59 --> Loader Class Initialized
INFO - 2016-11-10 21:09:59 --> Helper loaded: url_helper
INFO - 2016-11-10 21:09:59 --> Helper loaded: form_helper
INFO - 2016-11-10 21:09:59 --> Database Driver Class Initialized
INFO - 2016-11-10 21:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:09:59 --> Controller Class Initialized
INFO - 2016-11-10 21:10:00 --> Model Class Initialized
INFO - 2016-11-10 21:10:00 --> Model Class Initialized
INFO - 2016-11-10 21:10:00 --> Model Class Initialized
INFO - 2016-11-10 21:10:00 --> Model Class Initialized
INFO - 2016-11-10 21:10:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:10:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 21:10:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 21:10:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-10 21:10:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-10 21:10:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-10 21:10:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-10 21:10:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-10 21:10:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-10 21:10:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 21:10:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:10:00 --> Final output sent to browser
DEBUG - 2016-11-10 21:10:00 --> Total execution time: 1.6102
INFO - 2016-11-10 21:11:45 --> Config Class Initialized
INFO - 2016-11-10 21:11:45 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:11:45 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:11:45 --> Utf8 Class Initialized
INFO - 2016-11-10 21:11:45 --> URI Class Initialized
DEBUG - 2016-11-10 21:11:46 --> No URI present. Default controller set.
INFO - 2016-11-10 21:11:46 --> Router Class Initialized
INFO - 2016-11-10 21:11:46 --> Output Class Initialized
INFO - 2016-11-10 21:11:46 --> Security Class Initialized
DEBUG - 2016-11-10 21:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:11:46 --> Input Class Initialized
INFO - 2016-11-10 21:11:46 --> Language Class Initialized
INFO - 2016-11-10 21:11:46 --> Loader Class Initialized
INFO - 2016-11-10 21:11:46 --> Helper loaded: url_helper
INFO - 2016-11-10 21:11:46 --> Helper loaded: form_helper
INFO - 2016-11-10 21:11:46 --> Database Driver Class Initialized
ERROR - 2016-11-10 21:11:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\LMS\sys\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2016-11-10 21:11:48 --> Unable to connect to the database
INFO - 2016-11-10 21:11:48 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 21:12:07 --> Config Class Initialized
INFO - 2016-11-10 21:12:08 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:12:08 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:12:08 --> Utf8 Class Initialized
INFO - 2016-11-10 21:12:08 --> URI Class Initialized
DEBUG - 2016-11-10 21:12:08 --> No URI present. Default controller set.
INFO - 2016-11-10 21:12:08 --> Router Class Initialized
INFO - 2016-11-10 21:12:08 --> Output Class Initialized
INFO - 2016-11-10 21:12:08 --> Security Class Initialized
DEBUG - 2016-11-10 21:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:12:08 --> Input Class Initialized
INFO - 2016-11-10 21:12:08 --> Language Class Initialized
INFO - 2016-11-10 21:12:08 --> Loader Class Initialized
INFO - 2016-11-10 21:12:08 --> Helper loaded: url_helper
INFO - 2016-11-10 21:12:08 --> Helper loaded: form_helper
INFO - 2016-11-10 21:12:08 --> Database Driver Class Initialized
INFO - 2016-11-10 21:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:12:08 --> Controller Class Initialized
INFO - 2016-11-10 21:12:08 --> Model Class Initialized
INFO - 2016-11-10 21:12:08 --> Model Class Initialized
INFO - 2016-11-10 21:12:08 --> Model Class Initialized
INFO - 2016-11-10 21:12:08 --> Model Class Initialized
INFO - 2016-11-10 21:12:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:12:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 21:12:08 --> Query error: Unknown column 'lt.name' in 'field list' - Invalid query: SELECT `em`.`surname`, `lt`.`name`, `lv`.`numberOfLeaves`, `lv`.`description`
FROM `leaveRecord` `lv`
LEFT JOIN `employee` as `em` ON `em`.`id` = `lv`.`idEmployee`
LEFT JOIN `leaveType` as `lt` ON `lt`.`id` = `lv`.`idLeaveType`
WHERE `em`.`idRole` IN(2, 3)
INFO - 2016-11-10 21:12:08 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 21:12:11 --> Config Class Initialized
INFO - 2016-11-10 21:12:11 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:12:11 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:12:11 --> Utf8 Class Initialized
INFO - 2016-11-10 21:12:11 --> URI Class Initialized
DEBUG - 2016-11-10 21:12:11 --> No URI present. Default controller set.
INFO - 2016-11-10 21:12:11 --> Router Class Initialized
INFO - 2016-11-10 21:12:11 --> Output Class Initialized
INFO - 2016-11-10 21:12:11 --> Security Class Initialized
DEBUG - 2016-11-10 21:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:12:11 --> Input Class Initialized
INFO - 2016-11-10 21:12:11 --> Language Class Initialized
INFO - 2016-11-10 21:12:11 --> Loader Class Initialized
INFO - 2016-11-10 21:12:11 --> Helper loaded: url_helper
INFO - 2016-11-10 21:12:11 --> Helper loaded: form_helper
INFO - 2016-11-10 21:12:11 --> Database Driver Class Initialized
INFO - 2016-11-10 21:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:12:11 --> Controller Class Initialized
INFO - 2016-11-10 21:12:11 --> Model Class Initialized
INFO - 2016-11-10 21:12:11 --> Model Class Initialized
INFO - 2016-11-10 21:12:11 --> Model Class Initialized
INFO - 2016-11-10 21:12:11 --> Model Class Initialized
INFO - 2016-11-10 21:12:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:12:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 21:12:11 --> Query error: Unknown column 'lt.name' in 'field list' - Invalid query: SELECT `em`.`surname`, `lt`.`name`, `lv`.`numberOfLeaves`, `lv`.`description`
FROM `leaveRecord` `lv`
LEFT JOIN `employee` as `em` ON `em`.`id` = `lv`.`idEmployee`
LEFT JOIN `leaveType` as `lt` ON `lt`.`id` = `lv`.`idLeaveType`
WHERE `em`.`idRole` IN(2, 3)
INFO - 2016-11-10 21:12:11 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 21:12:27 --> Config Class Initialized
INFO - 2016-11-10 21:12:27 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:12:27 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:12:27 --> Utf8 Class Initialized
INFO - 2016-11-10 21:12:27 --> URI Class Initialized
DEBUG - 2016-11-10 21:12:27 --> No URI present. Default controller set.
INFO - 2016-11-10 21:12:27 --> Router Class Initialized
INFO - 2016-11-10 21:12:27 --> Output Class Initialized
INFO - 2016-11-10 21:12:27 --> Security Class Initialized
DEBUG - 2016-11-10 21:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:12:27 --> Input Class Initialized
INFO - 2016-11-10 21:12:27 --> Language Class Initialized
INFO - 2016-11-10 21:12:27 --> Loader Class Initialized
INFO - 2016-11-10 21:12:27 --> Helper loaded: url_helper
INFO - 2016-11-10 21:12:27 --> Helper loaded: form_helper
INFO - 2016-11-10 21:12:27 --> Database Driver Class Initialized
INFO - 2016-11-10 21:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:12:27 --> Controller Class Initialized
INFO - 2016-11-10 21:12:27 --> Model Class Initialized
INFO - 2016-11-10 21:12:27 --> Model Class Initialized
INFO - 2016-11-10 21:12:27 --> Model Class Initialized
INFO - 2016-11-10 21:12:27 --> Model Class Initialized
INFO - 2016-11-10 21:12:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:12:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 21:12:27 --> Query error: Unknown column 'lt.name' in 'field list' - Invalid query: SELECT `em`.`surname`, `lt`.`name`, `lv`.`numberOfLeaves`, `lv`.`description`
FROM `leaveRecord` `lv`
LEFT JOIN `employee` as `em` ON `em`.`id` = `lv`.`idEmployee`
LEFT JOIN `leaveType` as `lt` ON `lt`.`id` = `lv`.`idLeaveType`
WHERE `em`.`idRole` IN(2, 3)
INFO - 2016-11-10 21:12:28 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 21:12:52 --> Config Class Initialized
INFO - 2016-11-10 21:12:52 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:12:52 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:12:52 --> Utf8 Class Initialized
INFO - 2016-11-10 21:12:52 --> URI Class Initialized
DEBUG - 2016-11-10 21:12:52 --> No URI present. Default controller set.
INFO - 2016-11-10 21:12:52 --> Router Class Initialized
INFO - 2016-11-10 21:12:52 --> Output Class Initialized
INFO - 2016-11-10 21:12:52 --> Security Class Initialized
DEBUG - 2016-11-10 21:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:12:52 --> Input Class Initialized
INFO - 2016-11-10 21:12:52 --> Language Class Initialized
INFO - 2016-11-10 21:12:52 --> Loader Class Initialized
INFO - 2016-11-10 21:12:52 --> Helper loaded: url_helper
INFO - 2016-11-10 21:12:52 --> Helper loaded: form_helper
INFO - 2016-11-10 21:12:52 --> Database Driver Class Initialized
INFO - 2016-11-10 21:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:12:52 --> Controller Class Initialized
INFO - 2016-11-10 21:12:52 --> Model Class Initialized
INFO - 2016-11-10 21:12:52 --> Model Class Initialized
INFO - 2016-11-10 21:12:52 --> Model Class Initialized
INFO - 2016-11-10 21:12:52 --> Model Class Initialized
INFO - 2016-11-10 21:12:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:12:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 21:12:52 --> Query error: Unknown column 'lt.name' in 'field list' - Invalid query: SELECT `em`.`surname`, `lt`.`name`, `lv`.`numberOfLeaves`, `lv`.`description`
FROM `leaveRecord` `lv`
LEFT JOIN `employee` as `em` ON `em`.`id` = `lv`.`idEmployee`
LEFT JOIN `leaveType` as `lt` ON `lt`.`id` = `lv`.`idLeaveType`
WHERE `em`.`idRole` IN(2, 3)
INFO - 2016-11-10 21:12:52 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 21:14:49 --> Config Class Initialized
INFO - 2016-11-10 21:14:49 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:14:49 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:14:49 --> Utf8 Class Initialized
INFO - 2016-11-10 21:14:49 --> URI Class Initialized
DEBUG - 2016-11-10 21:14:49 --> No URI present. Default controller set.
INFO - 2016-11-10 21:14:49 --> Router Class Initialized
INFO - 2016-11-10 21:14:49 --> Output Class Initialized
INFO - 2016-11-10 21:14:49 --> Security Class Initialized
DEBUG - 2016-11-10 21:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:14:49 --> Input Class Initialized
INFO - 2016-11-10 21:14:49 --> Language Class Initialized
INFO - 2016-11-10 21:14:49 --> Loader Class Initialized
INFO - 2016-11-10 21:14:49 --> Helper loaded: url_helper
INFO - 2016-11-10 21:14:50 --> Helper loaded: form_helper
INFO - 2016-11-10 21:14:50 --> Database Driver Class Initialized
INFO - 2016-11-10 21:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:14:50 --> Controller Class Initialized
INFO - 2016-11-10 21:14:50 --> Model Class Initialized
INFO - 2016-11-10 21:14:50 --> Model Class Initialized
INFO - 2016-11-10 21:14:50 --> Model Class Initialized
INFO - 2016-11-10 21:14:50 --> Model Class Initialized
INFO - 2016-11-10 21:14:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:14:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 21:14:50 --> Query error: Unknown column 'lt.name' in 'field list' - Invalid query: SELECT `em`.`surname`, `lt`.`name`, `lv`.`numberOfLeaves`, `lv`.`description`
FROM `leaveRecord` `lv`
LEFT JOIN `employee` as `em` ON `em`.`id` = `lv`.`idEmployee`
LEFT JOIN `leaveType` as `lt` ON `lt`.`id` = `lv`.`idLeaveType`
WHERE `em`.`idRole` IN(2, 3)
INFO - 2016-11-10 21:14:50 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 21:14:51 --> Config Class Initialized
INFO - 2016-11-10 21:14:51 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:14:51 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:14:51 --> Utf8 Class Initialized
INFO - 2016-11-10 21:14:52 --> URI Class Initialized
DEBUG - 2016-11-10 21:14:52 --> No URI present. Default controller set.
INFO - 2016-11-10 21:14:52 --> Router Class Initialized
INFO - 2016-11-10 21:14:52 --> Output Class Initialized
INFO - 2016-11-10 21:14:52 --> Security Class Initialized
DEBUG - 2016-11-10 21:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:14:52 --> Input Class Initialized
INFO - 2016-11-10 21:14:52 --> Language Class Initialized
INFO - 2016-11-10 21:14:52 --> Loader Class Initialized
INFO - 2016-11-10 21:14:52 --> Helper loaded: url_helper
INFO - 2016-11-10 21:14:52 --> Helper loaded: form_helper
INFO - 2016-11-10 21:14:52 --> Database Driver Class Initialized
INFO - 2016-11-10 21:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:14:52 --> Controller Class Initialized
INFO - 2016-11-10 21:14:52 --> Model Class Initialized
INFO - 2016-11-10 21:14:52 --> Model Class Initialized
INFO - 2016-11-10 21:14:52 --> Model Class Initialized
INFO - 2016-11-10 21:14:52 --> Model Class Initialized
INFO - 2016-11-10 21:14:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:14:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 21:14:52 --> Query error: Unknown column 'lt.name' in 'field list' - Invalid query: SELECT `em`.`surname`, `lt`.`name`, `lv`.`numberOfLeaves`, `lv`.`description`
FROM `leaveRecord` `lv`
LEFT JOIN `employee` as `em` ON `em`.`id` = `lv`.`idEmployee`
LEFT JOIN `leaveType` as `lt` ON `lt`.`id` = `lv`.`idLeaveType`
WHERE `em`.`idRole` IN(2, 3)
INFO - 2016-11-10 21:14:52 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 21:15:42 --> Config Class Initialized
INFO - 2016-11-10 21:15:42 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:15:42 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:15:42 --> Utf8 Class Initialized
INFO - 2016-11-10 21:15:42 --> URI Class Initialized
DEBUG - 2016-11-10 21:15:42 --> No URI present. Default controller set.
INFO - 2016-11-10 21:15:42 --> Router Class Initialized
INFO - 2016-11-10 21:15:42 --> Output Class Initialized
INFO - 2016-11-10 21:15:42 --> Security Class Initialized
DEBUG - 2016-11-10 21:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:15:42 --> Input Class Initialized
INFO - 2016-11-10 21:15:42 --> Language Class Initialized
INFO - 2016-11-10 21:15:42 --> Loader Class Initialized
INFO - 2016-11-10 21:15:42 --> Helper loaded: url_helper
INFO - 2016-11-10 21:15:42 --> Helper loaded: form_helper
INFO - 2016-11-10 21:15:42 --> Database Driver Class Initialized
INFO - 2016-11-10 21:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:15:42 --> Controller Class Initialized
INFO - 2016-11-10 21:15:42 --> Model Class Initialized
INFO - 2016-11-10 21:15:42 --> Model Class Initialized
INFO - 2016-11-10 21:15:42 --> Model Class Initialized
INFO - 2016-11-10 21:15:42 --> Model Class Initialized
INFO - 2016-11-10 21:15:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:15:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 21:15:42 --> Query error: Unknown column 'name' in 'field list' - Invalid query: SELECT `id`, `name`
FROM `leavetype`
INFO - 2016-11-10 21:15:42 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 21:16:39 --> Config Class Initialized
INFO - 2016-11-10 21:16:39 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:16:39 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:16:39 --> Utf8 Class Initialized
INFO - 2016-11-10 21:16:39 --> URI Class Initialized
DEBUG - 2016-11-10 21:16:39 --> No URI present. Default controller set.
INFO - 2016-11-10 21:16:39 --> Router Class Initialized
INFO - 2016-11-10 21:16:39 --> Output Class Initialized
INFO - 2016-11-10 21:16:39 --> Security Class Initialized
DEBUG - 2016-11-10 21:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:16:39 --> Input Class Initialized
INFO - 2016-11-10 21:16:39 --> Language Class Initialized
INFO - 2016-11-10 21:16:39 --> Loader Class Initialized
INFO - 2016-11-10 21:16:39 --> Helper loaded: url_helper
INFO - 2016-11-10 21:16:39 --> Helper loaded: form_helper
INFO - 2016-11-10 21:16:39 --> Database Driver Class Initialized
INFO - 2016-11-10 21:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:16:39 --> Controller Class Initialized
INFO - 2016-11-10 21:16:39 --> Model Class Initialized
INFO - 2016-11-10 21:16:39 --> Model Class Initialized
INFO - 2016-11-10 21:16:39 --> Model Class Initialized
INFO - 2016-11-10 21:16:39 --> Model Class Initialized
INFO - 2016-11-10 21:16:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:16:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 21:16:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 21:16:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-10 21:16:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-10 21:16:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
ERROR - 2016-11-10 21:16:39 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\admin\all_leave_type.php 37
ERROR - 2016-11-10 21:16:39 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\admin\all_leave_type.php 37
ERROR - 2016-11-10 21:16:39 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\admin\all_leave_type.php 37
INFO - 2016-11-10 21:16:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-10 21:16:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-10 21:16:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-10 21:16:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 21:16:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:16:39 --> Final output sent to browser
DEBUG - 2016-11-10 21:16:40 --> Total execution time: 0.9671
INFO - 2016-11-10 21:18:18 --> Config Class Initialized
INFO - 2016-11-10 21:18:19 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:18:19 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:18:19 --> Utf8 Class Initialized
INFO - 2016-11-10 21:18:19 --> URI Class Initialized
DEBUG - 2016-11-10 21:18:19 --> No URI present. Default controller set.
INFO - 2016-11-10 21:18:19 --> Router Class Initialized
INFO - 2016-11-10 21:18:19 --> Output Class Initialized
INFO - 2016-11-10 21:18:19 --> Security Class Initialized
DEBUG - 2016-11-10 21:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:18:19 --> Input Class Initialized
INFO - 2016-11-10 21:18:19 --> Language Class Initialized
INFO - 2016-11-10 21:18:19 --> Loader Class Initialized
INFO - 2016-11-10 21:18:19 --> Helper loaded: url_helper
INFO - 2016-11-10 21:18:19 --> Helper loaded: form_helper
INFO - 2016-11-10 21:18:19 --> Database Driver Class Initialized
INFO - 2016-11-10 21:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:18:19 --> Controller Class Initialized
INFO - 2016-11-10 21:18:19 --> Model Class Initialized
INFO - 2016-11-10 21:18:19 --> Model Class Initialized
INFO - 2016-11-10 21:18:19 --> Model Class Initialized
INFO - 2016-11-10 21:18:19 --> Model Class Initialized
INFO - 2016-11-10 21:18:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:18:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 21:18:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 21:18:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-10 21:18:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-10 21:18:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-10 21:18:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-10 21:18:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-10 21:18:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-10 21:18:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 21:18:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:18:19 --> Final output sent to browser
DEBUG - 2016-11-10 21:18:19 --> Total execution time: 1.0145
INFO - 2016-11-10 21:18:46 --> Config Class Initialized
INFO - 2016-11-10 21:18:46 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:18:46 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:18:46 --> Utf8 Class Initialized
INFO - 2016-11-10 21:18:46 --> URI Class Initialized
INFO - 2016-11-10 21:18:46 --> Router Class Initialized
INFO - 2016-11-10 21:18:46 --> Output Class Initialized
INFO - 2016-11-10 21:18:46 --> Security Class Initialized
DEBUG - 2016-11-10 21:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:18:46 --> Input Class Initialized
INFO - 2016-11-10 21:18:46 --> Language Class Initialized
INFO - 2016-11-10 21:18:46 --> Loader Class Initialized
INFO - 2016-11-10 21:18:46 --> Helper loaded: url_helper
INFO - 2016-11-10 21:18:46 --> Helper loaded: form_helper
INFO - 2016-11-10 21:18:46 --> Database Driver Class Initialized
INFO - 2016-11-10 21:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:18:46 --> Controller Class Initialized
INFO - 2016-11-10 21:18:46 --> Model Class Initialized
INFO - 2016-11-10 21:18:46 --> Model Class Initialized
INFO - 2016-11-10 21:18:46 --> Model Class Initialized
INFO - 2016-11-10 21:18:46 --> Model Class Initialized
DEBUG - 2016-11-10 21:18:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 21:18:46 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 141
ERROR - 2016-11-10 21:18:46 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 141
INFO - 2016-11-10 21:18:46 --> Config Class Initialized
INFO - 2016-11-10 21:18:46 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:18:46 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:18:46 --> Utf8 Class Initialized
INFO - 2016-11-10 21:18:46 --> URI Class Initialized
DEBUG - 2016-11-10 21:18:46 --> No URI present. Default controller set.
INFO - 2016-11-10 21:18:46 --> Router Class Initialized
INFO - 2016-11-10 21:18:46 --> Output Class Initialized
INFO - 2016-11-10 21:18:46 --> Security Class Initialized
DEBUG - 2016-11-10 21:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:18:46 --> Input Class Initialized
INFO - 2016-11-10 21:18:46 --> Language Class Initialized
INFO - 2016-11-10 21:18:46 --> Loader Class Initialized
INFO - 2016-11-10 21:18:46 --> Helper loaded: url_helper
INFO - 2016-11-10 21:18:46 --> Helper loaded: form_helper
INFO - 2016-11-10 21:18:46 --> Database Driver Class Initialized
INFO - 2016-11-10 21:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:18:47 --> Controller Class Initialized
INFO - 2016-11-10 21:18:47 --> Model Class Initialized
INFO - 2016-11-10 21:18:47 --> Model Class Initialized
INFO - 2016-11-10 21:18:47 --> Model Class Initialized
INFO - 2016-11-10 21:18:47 --> Model Class Initialized
INFO - 2016-11-10 21:18:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:18:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 21:18:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:18:47 --> Final output sent to browser
DEBUG - 2016-11-10 21:18:47 --> Total execution time: 0.7222
INFO - 2016-11-10 21:18:59 --> Config Class Initialized
INFO - 2016-11-10 21:18:59 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:18:59 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:18:59 --> Utf8 Class Initialized
INFO - 2016-11-10 21:18:59 --> URI Class Initialized
INFO - 2016-11-10 21:19:00 --> Router Class Initialized
INFO - 2016-11-10 21:19:00 --> Output Class Initialized
INFO - 2016-11-10 21:19:00 --> Security Class Initialized
DEBUG - 2016-11-10 21:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:19:00 --> Input Class Initialized
INFO - 2016-11-10 21:19:00 --> Language Class Initialized
INFO - 2016-11-10 21:19:00 --> Loader Class Initialized
INFO - 2016-11-10 21:19:00 --> Helper loaded: url_helper
INFO - 2016-11-10 21:19:00 --> Helper loaded: form_helper
INFO - 2016-11-10 21:19:00 --> Database Driver Class Initialized
INFO - 2016-11-10 21:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:19:00 --> Controller Class Initialized
INFO - 2016-11-10 21:19:00 --> Model Class Initialized
INFO - 2016-11-10 21:19:00 --> Model Class Initialized
INFO - 2016-11-10 21:19:00 --> Model Class Initialized
INFO - 2016-11-10 21:19:00 --> Model Class Initialized
DEBUG - 2016-11-10 21:19:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 21:19:00 --> Model Class Initialized
INFO - 2016-11-10 21:19:00 --> Final output sent to browser
DEBUG - 2016-11-10 21:19:00 --> Total execution time: 0.6541
INFO - 2016-11-10 21:19:00 --> Config Class Initialized
INFO - 2016-11-10 21:19:00 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:19:00 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:19:00 --> Utf8 Class Initialized
INFO - 2016-11-10 21:19:00 --> URI Class Initialized
DEBUG - 2016-11-10 21:19:00 --> No URI present. Default controller set.
INFO - 2016-11-10 21:19:00 --> Router Class Initialized
INFO - 2016-11-10 21:19:00 --> Output Class Initialized
INFO - 2016-11-10 21:19:00 --> Security Class Initialized
DEBUG - 2016-11-10 21:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:19:00 --> Input Class Initialized
INFO - 2016-11-10 21:19:00 --> Language Class Initialized
INFO - 2016-11-10 21:19:00 --> Loader Class Initialized
INFO - 2016-11-10 21:19:00 --> Helper loaded: url_helper
INFO - 2016-11-10 21:19:00 --> Helper loaded: form_helper
INFO - 2016-11-10 21:19:00 --> Database Driver Class Initialized
INFO - 2016-11-10 21:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:19:00 --> Controller Class Initialized
INFO - 2016-11-10 21:19:00 --> Model Class Initialized
INFO - 2016-11-10 21:19:01 --> Model Class Initialized
INFO - 2016-11-10 21:19:01 --> Model Class Initialized
INFO - 2016-11-10 21:19:01 --> Model Class Initialized
INFO - 2016-11-10 21:19:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:19:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 21:19:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
ERROR - 2016-11-10 21:19:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\employee\apply_leave.php 19
ERROR - 2016-11-10 21:19:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\employee\apply_leave.php 19
ERROR - 2016-11-10 21:19:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\employee\apply_leave.php 19
INFO - 2016-11-10 21:19:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 21:19:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 21:19:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-10 21:19:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 23
ERROR - 2016-11-10 21:19:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:19:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 23
ERROR - 2016-11-10 21:19:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:19:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 23
ERROR - 2016-11-10 21:19:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:19:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 23
ERROR - 2016-11-10 21:19:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:19:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 23
ERROR - 2016-11-10 21:19:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:19:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 23
ERROR - 2016-11-10 21:19:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:19:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 23
ERROR - 2016-11-10 21:19:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:19:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 23
ERROR - 2016-11-10 21:19:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
INFO - 2016-11-10 21:19:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
ERROR - 2016-11-10 21:19:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_records.php 37
ERROR - 2016-11-10 21:19:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_records.php 37
ERROR - 2016-11-10 21:19:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_records.php 37
INFO - 2016-11-10 21:19:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
ERROR - 2016-11-10 21:19:02 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 18
INFO - 2016-11-10 21:19:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 21:19:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 21:19:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 21:19:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:19:02 --> Final output sent to browser
DEBUG - 2016-11-10 21:19:02 --> Total execution time: 1.7853
INFO - 2016-11-10 21:19:33 --> Config Class Initialized
INFO - 2016-11-10 21:19:33 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:19:33 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:19:33 --> Utf8 Class Initialized
INFO - 2016-11-10 21:19:33 --> URI Class Initialized
DEBUG - 2016-11-10 21:19:33 --> No URI present. Default controller set.
INFO - 2016-11-10 21:19:33 --> Router Class Initialized
INFO - 2016-11-10 21:19:33 --> Output Class Initialized
INFO - 2016-11-10 21:19:33 --> Security Class Initialized
DEBUG - 2016-11-10 21:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:19:33 --> Input Class Initialized
INFO - 2016-11-10 21:19:33 --> Language Class Initialized
INFO - 2016-11-10 21:19:33 --> Loader Class Initialized
INFO - 2016-11-10 21:19:33 --> Helper loaded: url_helper
INFO - 2016-11-10 21:19:33 --> Helper loaded: form_helper
INFO - 2016-11-10 21:19:33 --> Database Driver Class Initialized
INFO - 2016-11-10 21:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:19:33 --> Controller Class Initialized
INFO - 2016-11-10 21:19:33 --> Model Class Initialized
INFO - 2016-11-10 21:19:33 --> Model Class Initialized
INFO - 2016-11-10 21:19:33 --> Model Class Initialized
INFO - 2016-11-10 21:19:33 --> Model Class Initialized
INFO - 2016-11-10 21:19:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:19:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 21:19:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
ERROR - 2016-11-10 21:19:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\employee\apply_leave.php 19
ERROR - 2016-11-10 21:19:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\employee\apply_leave.php 19
ERROR - 2016-11-10 21:19:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\employee\apply_leave.php 19
INFO - 2016-11-10 21:19:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 21:19:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 21:19:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-10 21:19:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 23
ERROR - 2016-11-10 21:19:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:19:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 23
ERROR - 2016-11-10 21:19:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:19:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 23
ERROR - 2016-11-10 21:19:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:19:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 23
ERROR - 2016-11-10 21:19:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:19:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 23
ERROR - 2016-11-10 21:19:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:19:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 23
ERROR - 2016-11-10 21:19:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:19:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 23
ERROR - 2016-11-10 21:19:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:19:34 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 23
ERROR - 2016-11-10 21:19:34 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
INFO - 2016-11-10 21:19:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 21:19:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
ERROR - 2016-11-10 21:19:34 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\add_leave_record_sidebar.php 18
INFO - 2016-11-10 21:19:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 21:19:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 21:19:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 21:19:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:19:34 --> Final output sent to browser
DEBUG - 2016-11-10 21:19:34 --> Total execution time: 1.0931
INFO - 2016-11-10 21:20:08 --> Config Class Initialized
INFO - 2016-11-10 21:20:08 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:20:08 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:20:08 --> Utf8 Class Initialized
INFO - 2016-11-10 21:20:08 --> URI Class Initialized
DEBUG - 2016-11-10 21:20:08 --> No URI present. Default controller set.
INFO - 2016-11-10 21:20:08 --> Router Class Initialized
INFO - 2016-11-10 21:20:08 --> Output Class Initialized
INFO - 2016-11-10 21:20:08 --> Security Class Initialized
DEBUG - 2016-11-10 21:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:20:08 --> Input Class Initialized
INFO - 2016-11-10 21:20:08 --> Language Class Initialized
INFO - 2016-11-10 21:20:08 --> Loader Class Initialized
INFO - 2016-11-10 21:20:08 --> Helper loaded: url_helper
INFO - 2016-11-10 21:20:09 --> Helper loaded: form_helper
INFO - 2016-11-10 21:20:09 --> Database Driver Class Initialized
INFO - 2016-11-10 21:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:20:09 --> Controller Class Initialized
INFO - 2016-11-10 21:20:09 --> Model Class Initialized
INFO - 2016-11-10 21:20:09 --> Model Class Initialized
INFO - 2016-11-10 21:20:09 --> Model Class Initialized
INFO - 2016-11-10 21:20:09 --> Model Class Initialized
INFO - 2016-11-10 21:20:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:20:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 21:20:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
ERROR - 2016-11-10 21:20:09 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\employee\apply_leave.php 19
ERROR - 2016-11-10 21:20:09 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\employee\apply_leave.php 19
ERROR - 2016-11-10 21:20:09 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\employee\apply_leave.php 19
INFO - 2016-11-10 21:20:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 21:20:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 21:20:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-10 21:20:09 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 23
ERROR - 2016-11-10 21:20:09 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:20:09 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 23
ERROR - 2016-11-10 21:20:09 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:20:09 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 23
ERROR - 2016-11-10 21:20:09 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:20:09 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 23
ERROR - 2016-11-10 21:20:09 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:20:09 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 23
ERROR - 2016-11-10 21:20:09 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:20:09 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 23
ERROR - 2016-11-10 21:20:09 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:20:09 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 23
ERROR - 2016-11-10 21:20:09 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:20:09 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 23
ERROR - 2016-11-10 21:20:09 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
INFO - 2016-11-10 21:20:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 21:20:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 21:20:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 21:20:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 21:20:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 21:20:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:20:09 --> Final output sent to browser
DEBUG - 2016-11-10 21:20:09 --> Total execution time: 1.2644
INFO - 2016-11-10 21:20:32 --> Config Class Initialized
INFO - 2016-11-10 21:20:32 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:20:32 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:20:32 --> Utf8 Class Initialized
INFO - 2016-11-10 21:20:32 --> URI Class Initialized
DEBUG - 2016-11-10 21:20:33 --> No URI present. Default controller set.
INFO - 2016-11-10 21:20:33 --> Router Class Initialized
INFO - 2016-11-10 21:20:33 --> Output Class Initialized
INFO - 2016-11-10 21:20:33 --> Security Class Initialized
DEBUG - 2016-11-10 21:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:20:33 --> Input Class Initialized
INFO - 2016-11-10 21:20:33 --> Language Class Initialized
INFO - 2016-11-10 21:20:33 --> Loader Class Initialized
INFO - 2016-11-10 21:20:33 --> Helper loaded: url_helper
INFO - 2016-11-10 21:20:33 --> Helper loaded: form_helper
INFO - 2016-11-10 21:20:33 --> Database Driver Class Initialized
INFO - 2016-11-10 21:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:20:33 --> Controller Class Initialized
INFO - 2016-11-10 21:20:33 --> Model Class Initialized
INFO - 2016-11-10 21:20:33 --> Model Class Initialized
INFO - 2016-11-10 21:20:33 --> Model Class Initialized
INFO - 2016-11-10 21:20:33 --> Model Class Initialized
INFO - 2016-11-10 21:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 21:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
ERROR - 2016-11-10 21:20:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\employee\apply_leave.php 19
ERROR - 2016-11-10 21:20:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\employee\apply_leave.php 19
ERROR - 2016-11-10 21:20:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\employee\apply_leave.php 19
INFO - 2016-11-10 21:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 21:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 21:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-10 21:20:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:20:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:20:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:20:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:20:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:20:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:20:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
ERROR - 2016-11-10 21:20:33 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
INFO - 2016-11-10 21:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 21:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 21:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 21:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 21:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 21:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:20:33 --> Final output sent to browser
DEBUG - 2016-11-10 21:20:33 --> Total execution time: 0.9462
INFO - 2016-11-10 21:21:01 --> Config Class Initialized
INFO - 2016-11-10 21:21:01 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:21:01 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:21:01 --> Utf8 Class Initialized
INFO - 2016-11-10 21:21:01 --> URI Class Initialized
DEBUG - 2016-11-10 21:21:01 --> No URI present. Default controller set.
INFO - 2016-11-10 21:21:01 --> Router Class Initialized
INFO - 2016-11-10 21:21:01 --> Output Class Initialized
INFO - 2016-11-10 21:21:01 --> Security Class Initialized
DEBUG - 2016-11-10 21:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:21:01 --> Input Class Initialized
INFO - 2016-11-10 21:21:01 --> Language Class Initialized
INFO - 2016-11-10 21:21:01 --> Loader Class Initialized
INFO - 2016-11-10 21:21:01 --> Helper loaded: url_helper
INFO - 2016-11-10 21:21:01 --> Helper loaded: form_helper
INFO - 2016-11-10 21:21:01 --> Database Driver Class Initialized
INFO - 2016-11-10 21:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:21:01 --> Controller Class Initialized
INFO - 2016-11-10 21:21:01 --> Model Class Initialized
INFO - 2016-11-10 21:21:01 --> Model Class Initialized
INFO - 2016-11-10 21:21:01 --> Model Class Initialized
INFO - 2016-11-10 21:21:01 --> Model Class Initialized
INFO - 2016-11-10 21:21:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:21:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 21:21:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
ERROR - 2016-11-10 21:21:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\employee\apply_leave.php 19
ERROR - 2016-11-10 21:21:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\employee\apply_leave.php 19
ERROR - 2016-11-10 21:21:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\employee\apply_leave.php 19
INFO - 2016-11-10 21:21:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 21:21:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 21:21:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 21:21:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 21:21:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 21:21:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 21:21:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 21:21:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 21:21:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:21:01 --> Final output sent to browser
DEBUG - 2016-11-10 21:21:02 --> Total execution time: 0.8300
INFO - 2016-11-10 21:22:02 --> Config Class Initialized
INFO - 2016-11-10 21:22:02 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:22:02 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:22:02 --> Utf8 Class Initialized
INFO - 2016-11-10 21:22:02 --> URI Class Initialized
DEBUG - 2016-11-10 21:22:02 --> No URI present. Default controller set.
INFO - 2016-11-10 21:22:02 --> Router Class Initialized
INFO - 2016-11-10 21:22:02 --> Output Class Initialized
INFO - 2016-11-10 21:22:02 --> Security Class Initialized
DEBUG - 2016-11-10 21:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:22:02 --> Input Class Initialized
INFO - 2016-11-10 21:22:02 --> Language Class Initialized
INFO - 2016-11-10 21:22:02 --> Loader Class Initialized
INFO - 2016-11-10 21:22:03 --> Helper loaded: url_helper
INFO - 2016-11-10 21:22:03 --> Helper loaded: form_helper
INFO - 2016-11-10 21:22:03 --> Database Driver Class Initialized
INFO - 2016-11-10 21:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:22:03 --> Controller Class Initialized
INFO - 2016-11-10 21:22:03 --> Model Class Initialized
INFO - 2016-11-10 21:22:03 --> Model Class Initialized
INFO - 2016-11-10 21:22:03 --> Model Class Initialized
INFO - 2016-11-10 21:22:03 --> Model Class Initialized
INFO - 2016-11-10 21:22:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:22:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 21:22:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 21:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 21:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 21:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 21:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 21:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 21:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 21:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 21:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 21:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:22:04 --> Final output sent to browser
DEBUG - 2016-11-10 21:22:04 --> Total execution time: 2.0406
INFO - 2016-11-10 21:23:23 --> Config Class Initialized
INFO - 2016-11-10 21:23:23 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:23:23 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:23:23 --> Utf8 Class Initialized
INFO - 2016-11-10 21:23:23 --> URI Class Initialized
DEBUG - 2016-11-10 21:23:23 --> No URI present. Default controller set.
INFO - 2016-11-10 21:23:23 --> Router Class Initialized
INFO - 2016-11-10 21:23:23 --> Output Class Initialized
INFO - 2016-11-10 21:23:24 --> Security Class Initialized
DEBUG - 2016-11-10 21:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:23:24 --> Input Class Initialized
INFO - 2016-11-10 21:23:24 --> Language Class Initialized
INFO - 2016-11-10 21:23:24 --> Loader Class Initialized
INFO - 2016-11-10 21:23:24 --> Helper loaded: url_helper
INFO - 2016-11-10 21:23:24 --> Helper loaded: form_helper
INFO - 2016-11-10 21:23:24 --> Database Driver Class Initialized
INFO - 2016-11-10 21:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:23:24 --> Controller Class Initialized
INFO - 2016-11-10 21:23:24 --> Model Class Initialized
INFO - 2016-11-10 21:23:24 --> Model Class Initialized
INFO - 2016-11-10 21:23:24 --> Model Class Initialized
INFO - 2016-11-10 21:23:24 --> Model Class Initialized
INFO - 2016-11-10 21:23:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:23:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 21:23:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 21:23:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 21:23:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 21:23:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 21:23:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 21:23:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 21:23:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 21:23:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 21:23:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 21:23:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:23:24 --> Final output sent to browser
DEBUG - 2016-11-10 21:23:24 --> Total execution time: 1.0645
INFO - 2016-11-10 21:26:28 --> Config Class Initialized
INFO - 2016-11-10 21:26:29 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:26:29 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:26:29 --> Utf8 Class Initialized
INFO - 2016-11-10 21:26:29 --> URI Class Initialized
DEBUG - 2016-11-10 21:26:29 --> No URI present. Default controller set.
INFO - 2016-11-10 21:26:29 --> Router Class Initialized
INFO - 2016-11-10 21:26:29 --> Output Class Initialized
INFO - 2016-11-10 21:26:29 --> Security Class Initialized
DEBUG - 2016-11-10 21:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:26:29 --> Input Class Initialized
INFO - 2016-11-10 21:26:29 --> Language Class Initialized
INFO - 2016-11-10 21:26:29 --> Loader Class Initialized
INFO - 2016-11-10 21:26:29 --> Helper loaded: url_helper
INFO - 2016-11-10 21:26:29 --> Helper loaded: form_helper
INFO - 2016-11-10 21:26:29 --> Database Driver Class Initialized
INFO - 2016-11-10 21:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:26:29 --> Controller Class Initialized
INFO - 2016-11-10 21:26:29 --> Model Class Initialized
INFO - 2016-11-10 21:26:29 --> Model Class Initialized
ERROR - 2016-11-10 21:26:30 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 11
INFO - 2016-11-10 21:26:42 --> Config Class Initialized
INFO - 2016-11-10 21:26:42 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:26:42 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:26:42 --> Utf8 Class Initialized
INFO - 2016-11-10 21:26:42 --> URI Class Initialized
DEBUG - 2016-11-10 21:26:42 --> No URI present. Default controller set.
INFO - 2016-11-10 21:26:42 --> Router Class Initialized
INFO - 2016-11-10 21:26:42 --> Output Class Initialized
INFO - 2016-11-10 21:26:43 --> Security Class Initialized
DEBUG - 2016-11-10 21:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:26:43 --> Input Class Initialized
INFO - 2016-11-10 21:26:43 --> Language Class Initialized
INFO - 2016-11-10 21:26:43 --> Loader Class Initialized
INFO - 2016-11-10 21:26:43 --> Helper loaded: url_helper
INFO - 2016-11-10 21:26:43 --> Helper loaded: form_helper
INFO - 2016-11-10 21:26:43 --> Database Driver Class Initialized
INFO - 2016-11-10 21:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:26:43 --> Controller Class Initialized
INFO - 2016-11-10 21:26:43 --> Model Class Initialized
INFO - 2016-11-10 21:26:43 --> Model Class Initialized
INFO - 2016-11-10 21:26:43 --> Model Class Initialized
INFO - 2016-11-10 21:26:43 --> Model Class Initialized
INFO - 2016-11-10 21:26:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:26:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 21:26:43 --> Query error: Not unique table/alias: 'applicationData' - Invalid query: SELECT *
FROM `applicationData`, `applicationData`
WHERE `idEmployee` = '19'
INFO - 2016-11-10 21:26:43 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 21:28:45 --> Config Class Initialized
INFO - 2016-11-10 21:28:45 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:28:45 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:28:46 --> Utf8 Class Initialized
INFO - 2016-11-10 21:28:46 --> URI Class Initialized
DEBUG - 2016-11-10 21:28:46 --> No URI present. Default controller set.
INFO - 2016-11-10 21:28:46 --> Router Class Initialized
INFO - 2016-11-10 21:28:46 --> Output Class Initialized
INFO - 2016-11-10 21:28:46 --> Security Class Initialized
DEBUG - 2016-11-10 21:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:28:46 --> Input Class Initialized
INFO - 2016-11-10 21:28:46 --> Language Class Initialized
INFO - 2016-11-10 21:28:46 --> Loader Class Initialized
INFO - 2016-11-10 21:28:46 --> Helper loaded: url_helper
INFO - 2016-11-10 21:28:46 --> Helper loaded: form_helper
INFO - 2016-11-10 21:28:46 --> Database Driver Class Initialized
INFO - 2016-11-10 21:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:28:46 --> Controller Class Initialized
INFO - 2016-11-10 21:28:46 --> Model Class Initialized
INFO - 2016-11-10 21:28:46 --> Model Class Initialized
INFO - 2016-11-10 21:28:46 --> Model Class Initialized
INFO - 2016-11-10 21:28:46 --> Model Class Initialized
INFO - 2016-11-10 21:28:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:28:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 21:29:09 --> Config Class Initialized
INFO - 2016-11-10 21:29:10 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:29:10 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:29:10 --> Utf8 Class Initialized
INFO - 2016-11-10 21:29:10 --> URI Class Initialized
DEBUG - 2016-11-10 21:29:10 --> No URI present. Default controller set.
INFO - 2016-11-10 21:29:10 --> Router Class Initialized
INFO - 2016-11-10 21:29:10 --> Output Class Initialized
INFO - 2016-11-10 21:29:10 --> Security Class Initialized
DEBUG - 2016-11-10 21:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:29:10 --> Input Class Initialized
INFO - 2016-11-10 21:29:10 --> Language Class Initialized
INFO - 2016-11-10 21:29:10 --> Loader Class Initialized
INFO - 2016-11-10 21:29:10 --> Helper loaded: url_helper
INFO - 2016-11-10 21:29:10 --> Helper loaded: form_helper
INFO - 2016-11-10 21:29:10 --> Database Driver Class Initialized
INFO - 2016-11-10 21:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:29:10 --> Controller Class Initialized
INFO - 2016-11-10 21:29:10 --> Model Class Initialized
INFO - 2016-11-10 21:29:10 --> Model Class Initialized
INFO - 2016-11-10 21:29:10 --> Model Class Initialized
INFO - 2016-11-10 21:29:10 --> Model Class Initialized
INFO - 2016-11-10 21:29:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:29:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-10 21:29:10 --> Query error: Not unique table/alias: 'applicationData' - Invalid query: SELECT *
FROM `applicationData`, `applicationData`
WHERE `idEmployee` = '19'
INFO - 2016-11-10 21:29:10 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-10 21:30:02 --> Config Class Initialized
INFO - 2016-11-10 21:30:02 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:30:02 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:30:02 --> Utf8 Class Initialized
INFO - 2016-11-10 21:30:02 --> URI Class Initialized
DEBUG - 2016-11-10 21:30:02 --> No URI present. Default controller set.
INFO - 2016-11-10 21:30:02 --> Router Class Initialized
INFO - 2016-11-10 21:30:02 --> Output Class Initialized
INFO - 2016-11-10 21:30:02 --> Security Class Initialized
DEBUG - 2016-11-10 21:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:30:02 --> Input Class Initialized
INFO - 2016-11-10 21:30:02 --> Language Class Initialized
INFO - 2016-11-10 21:30:02 --> Loader Class Initialized
INFO - 2016-11-10 21:30:02 --> Helper loaded: url_helper
INFO - 2016-11-10 21:30:02 --> Helper loaded: form_helper
INFO - 2016-11-10 21:30:02 --> Database Driver Class Initialized
INFO - 2016-11-10 21:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:30:02 --> Controller Class Initialized
INFO - 2016-11-10 21:30:02 --> Model Class Initialized
INFO - 2016-11-10 21:30:03 --> Model Class Initialized
INFO - 2016-11-10 21:30:03 --> Model Class Initialized
INFO - 2016-11-10 21:30:03 --> Model Class Initialized
INFO - 2016-11-10 21:30:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:30:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 21:30:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 21:30:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 21:30:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 21:30:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 21:30:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 21:30:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 21:30:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 21:30:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 21:30:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 21:30:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:30:03 --> Final output sent to browser
DEBUG - 2016-11-10 21:30:04 --> Total execution time: 1.5530
INFO - 2016-11-10 21:33:54 --> Config Class Initialized
INFO - 2016-11-10 21:33:55 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:33:55 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:33:55 --> Utf8 Class Initialized
INFO - 2016-11-10 21:33:55 --> URI Class Initialized
DEBUG - 2016-11-10 21:33:55 --> No URI present. Default controller set.
INFO - 2016-11-10 21:33:55 --> Router Class Initialized
INFO - 2016-11-10 21:33:55 --> Output Class Initialized
INFO - 2016-11-10 21:33:55 --> Security Class Initialized
DEBUG - 2016-11-10 21:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:33:55 --> Input Class Initialized
INFO - 2016-11-10 21:33:55 --> Language Class Initialized
INFO - 2016-11-10 21:33:55 --> Loader Class Initialized
INFO - 2016-11-10 21:33:55 --> Helper loaded: url_helper
INFO - 2016-11-10 21:33:55 --> Helper loaded: form_helper
INFO - 2016-11-10 21:33:55 --> Database Driver Class Initialized
INFO - 2016-11-10 21:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:33:56 --> Controller Class Initialized
INFO - 2016-11-10 21:33:56 --> Model Class Initialized
INFO - 2016-11-10 21:33:56 --> Model Class Initialized
INFO - 2016-11-10 21:33:56 --> Model Class Initialized
INFO - 2016-11-10 21:33:56 --> Model Class Initialized
INFO - 2016-11-10 21:33:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:33:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 21:33:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 21:33:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 21:33:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 21:33:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 21:33:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 21:33:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 21:33:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 21:33:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 21:33:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 21:33:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:33:56 --> Final output sent to browser
DEBUG - 2016-11-10 21:33:56 --> Total execution time: 1.5790
INFO - 2016-11-10 21:36:35 --> Config Class Initialized
INFO - 2016-11-10 21:36:35 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:36:35 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:36:35 --> Utf8 Class Initialized
INFO - 2016-11-10 21:36:35 --> URI Class Initialized
INFO - 2016-11-10 21:36:35 --> Router Class Initialized
INFO - 2016-11-10 21:36:35 --> Output Class Initialized
INFO - 2016-11-10 21:36:35 --> Security Class Initialized
DEBUG - 2016-11-10 21:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:36:35 --> Input Class Initialized
INFO - 2016-11-10 21:36:35 --> Language Class Initialized
INFO - 2016-11-10 21:36:35 --> Loader Class Initialized
INFO - 2016-11-10 21:36:35 --> Helper loaded: url_helper
INFO - 2016-11-10 21:36:35 --> Helper loaded: form_helper
INFO - 2016-11-10 21:36:35 --> Database Driver Class Initialized
INFO - 2016-11-10 21:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:36:35 --> Controller Class Initialized
INFO - 2016-11-10 21:36:35 --> Model Class Initialized
INFO - 2016-11-10 21:36:35 --> Model Class Initialized
INFO - 2016-11-10 21:36:35 --> Model Class Initialized
INFO - 2016-11-10 21:36:35 --> Model Class Initialized
DEBUG - 2016-11-10 21:36:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 21:36:35 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
ERROR - 2016-11-10 21:36:35 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
INFO - 2016-11-10 21:36:35 --> Config Class Initialized
INFO - 2016-11-10 21:36:35 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:36:35 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:36:35 --> Utf8 Class Initialized
INFO - 2016-11-10 21:36:35 --> URI Class Initialized
DEBUG - 2016-11-10 21:36:35 --> No URI present. Default controller set.
INFO - 2016-11-10 21:36:35 --> Router Class Initialized
INFO - 2016-11-10 21:36:35 --> Output Class Initialized
INFO - 2016-11-10 21:36:36 --> Security Class Initialized
DEBUG - 2016-11-10 21:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:36:36 --> Input Class Initialized
INFO - 2016-11-10 21:36:36 --> Language Class Initialized
INFO - 2016-11-10 21:36:36 --> Loader Class Initialized
INFO - 2016-11-10 21:36:36 --> Helper loaded: url_helper
INFO - 2016-11-10 21:36:36 --> Helper loaded: form_helper
INFO - 2016-11-10 21:36:36 --> Database Driver Class Initialized
INFO - 2016-11-10 21:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:36:36 --> Controller Class Initialized
INFO - 2016-11-10 21:36:36 --> Model Class Initialized
INFO - 2016-11-10 21:36:36 --> Model Class Initialized
INFO - 2016-11-10 21:36:36 --> Model Class Initialized
INFO - 2016-11-10 21:36:36 --> Model Class Initialized
INFO - 2016-11-10 21:36:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:36:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 21:36:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:36:36 --> Final output sent to browser
DEBUG - 2016-11-10 21:36:36 --> Total execution time: 0.6240
INFO - 2016-11-10 21:37:03 --> Config Class Initialized
INFO - 2016-11-10 21:37:03 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:37:03 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:37:03 --> Utf8 Class Initialized
INFO - 2016-11-10 21:37:03 --> URI Class Initialized
INFO - 2016-11-10 21:37:03 --> Router Class Initialized
INFO - 2016-11-10 21:37:03 --> Output Class Initialized
INFO - 2016-11-10 21:37:03 --> Security Class Initialized
DEBUG - 2016-11-10 21:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:37:03 --> Input Class Initialized
INFO - 2016-11-10 21:37:03 --> Language Class Initialized
INFO - 2016-11-10 21:37:03 --> Loader Class Initialized
INFO - 2016-11-10 21:37:03 --> Helper loaded: url_helper
INFO - 2016-11-10 21:37:03 --> Helper loaded: form_helper
INFO - 2016-11-10 21:37:03 --> Database Driver Class Initialized
INFO - 2016-11-10 21:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:37:03 --> Controller Class Initialized
INFO - 2016-11-10 21:37:03 --> Model Class Initialized
INFO - 2016-11-10 21:37:03 --> Model Class Initialized
INFO - 2016-11-10 21:37:03 --> Model Class Initialized
INFO - 2016-11-10 21:37:03 --> Model Class Initialized
DEBUG - 2016-11-10 21:37:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-10 21:37:03 --> Model Class Initialized
INFO - 2016-11-10 21:37:03 --> Final output sent to browser
DEBUG - 2016-11-10 21:37:03 --> Total execution time: 0.4719
INFO - 2016-11-10 21:37:03 --> Config Class Initialized
INFO - 2016-11-10 21:37:03 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:37:03 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:37:03 --> Utf8 Class Initialized
INFO - 2016-11-10 21:37:03 --> URI Class Initialized
DEBUG - 2016-11-10 21:37:03 --> No URI present. Default controller set.
INFO - 2016-11-10 21:37:03 --> Router Class Initialized
INFO - 2016-11-10 21:37:03 --> Output Class Initialized
INFO - 2016-11-10 21:37:03 --> Security Class Initialized
DEBUG - 2016-11-10 21:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:37:03 --> Input Class Initialized
INFO - 2016-11-10 21:37:03 --> Language Class Initialized
INFO - 2016-11-10 21:37:03 --> Loader Class Initialized
INFO - 2016-11-10 21:37:03 --> Helper loaded: url_helper
INFO - 2016-11-10 21:37:03 --> Helper loaded: form_helper
INFO - 2016-11-10 21:37:03 --> Database Driver Class Initialized
INFO - 2016-11-10 21:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:37:04 --> Controller Class Initialized
INFO - 2016-11-10 21:37:04 --> Model Class Initialized
INFO - 2016-11-10 21:37:04 --> Model Class Initialized
INFO - 2016-11-10 21:37:04 --> Model Class Initialized
INFO - 2016-11-10 21:37:04 --> Model Class Initialized
INFO - 2016-11-10 21:37:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:37:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 21:37:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 21:37:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 21:37:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 21:37:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 21:37:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 21:37:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 21:37:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 21:37:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 21:37:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 21:37:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:37:04 --> Final output sent to browser
DEBUG - 2016-11-10 21:37:04 --> Total execution time: 0.7257
INFO - 2016-11-10 21:38:38 --> Config Class Initialized
INFO - 2016-11-10 21:38:38 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:38:38 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:38:38 --> Utf8 Class Initialized
INFO - 2016-11-10 21:38:38 --> URI Class Initialized
INFO - 2016-11-10 21:38:38 --> Router Class Initialized
INFO - 2016-11-10 21:38:38 --> Output Class Initialized
INFO - 2016-11-10 21:38:38 --> Security Class Initialized
DEBUG - 2016-11-10 21:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:38:38 --> Input Class Initialized
INFO - 2016-11-10 21:38:38 --> Language Class Initialized
INFO - 2016-11-10 21:38:38 --> Loader Class Initialized
INFO - 2016-11-10 21:38:38 --> Helper loaded: url_helper
INFO - 2016-11-10 21:38:38 --> Helper loaded: form_helper
INFO - 2016-11-10 21:38:39 --> Database Driver Class Initialized
INFO - 2016-11-10 21:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:38:39 --> Controller Class Initialized
INFO - 2016-11-10 21:38:39 --> Config Class Initialized
INFO - 2016-11-10 21:38:39 --> Model Class Initialized
INFO - 2016-11-10 21:38:39 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:38:39 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:38:39 --> Utf8 Class Initialized
INFO - 2016-11-10 21:38:39 --> URI Class Initialized
INFO - 2016-11-10 21:38:39 --> Router Class Initialized
INFO - 2016-11-10 21:38:39 --> Form Validation Class Initialized
INFO - 2016-11-10 21:38:39 --> Output Class Initialized
INFO - 2016-11-10 21:38:39 --> Security Class Initialized
INFO - 2016-11-10 21:38:39 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-10 21:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:38:39 --> Final output sent to browser
INFO - 2016-11-10 21:38:39 --> Input Class Initialized
DEBUG - 2016-11-10 21:38:39 --> Total execution time: 0.7252
INFO - 2016-11-10 21:38:39 --> Language Class Initialized
INFO - 2016-11-10 21:38:39 --> Loader Class Initialized
INFO - 2016-11-10 21:38:39 --> Helper loaded: url_helper
INFO - 2016-11-10 21:38:39 --> Helper loaded: form_helper
INFO - 2016-11-10 21:38:39 --> Database Driver Class Initialized
INFO - 2016-11-10 21:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:38:39 --> Controller Class Initialized
INFO - 2016-11-10 21:38:39 --> Model Class Initialized
INFO - 2016-11-10 21:38:39 --> Form Validation Class Initialized
INFO - 2016-11-10 21:38:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-10 21:38:39 --> Final output sent to browser
DEBUG - 2016-11-10 21:38:39 --> Total execution time: 0.5109
INFO - 2016-11-10 21:38:40 --> Config Class Initialized
INFO - 2016-11-10 21:38:40 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:38:40 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:38:40 --> Utf8 Class Initialized
INFO - 2016-11-10 21:38:41 --> URI Class Initialized
INFO - 2016-11-10 21:38:41 --> Router Class Initialized
INFO - 2016-11-10 21:38:41 --> Output Class Initialized
INFO - 2016-11-10 21:38:41 --> Security Class Initialized
DEBUG - 2016-11-10 21:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:38:41 --> Input Class Initialized
INFO - 2016-11-10 21:38:41 --> Language Class Initialized
INFO - 2016-11-10 21:38:41 --> Loader Class Initialized
INFO - 2016-11-10 21:38:41 --> Helper loaded: url_helper
INFO - 2016-11-10 21:38:41 --> Helper loaded: form_helper
INFO - 2016-11-10 21:38:41 --> Database Driver Class Initialized
INFO - 2016-11-10 21:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:38:41 --> Controller Class Initialized
INFO - 2016-11-10 21:38:41 --> Model Class Initialized
INFO - 2016-11-10 21:38:41 --> Form Validation Class Initialized
INFO - 2016-11-10 21:38:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-10 21:38:41 --> Final output sent to browser
DEBUG - 2016-11-10 21:38:41 --> Total execution time: 0.4327
INFO - 2016-11-10 21:38:46 --> Config Class Initialized
INFO - 2016-11-10 21:38:46 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:38:46 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:38:46 --> Utf8 Class Initialized
INFO - 2016-11-10 21:38:46 --> URI Class Initialized
INFO - 2016-11-10 21:38:46 --> Router Class Initialized
INFO - 2016-11-10 21:38:46 --> Output Class Initialized
INFO - 2016-11-10 21:38:46 --> Security Class Initialized
DEBUG - 2016-11-10 21:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:38:46 --> Input Class Initialized
INFO - 2016-11-10 21:38:46 --> Language Class Initialized
INFO - 2016-11-10 21:38:46 --> Loader Class Initialized
INFO - 2016-11-10 21:38:46 --> Helper loaded: url_helper
INFO - 2016-11-10 21:38:46 --> Helper loaded: form_helper
INFO - 2016-11-10 21:38:46 --> Database Driver Class Initialized
INFO - 2016-11-10 21:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:38:46 --> Controller Class Initialized
INFO - 2016-11-10 21:38:46 --> Model Class Initialized
INFO - 2016-11-10 21:38:46 --> Form Validation Class Initialized
INFO - 2016-11-10 21:38:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-10 21:38:46 --> Final output sent to browser
DEBUG - 2016-11-10 21:38:46 --> Total execution time: 0.5904
INFO - 2016-11-10 21:38:51 --> Config Class Initialized
INFO - 2016-11-10 21:38:51 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:38:51 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:38:51 --> Utf8 Class Initialized
INFO - 2016-11-10 21:38:51 --> URI Class Initialized
INFO - 2016-11-10 21:38:51 --> Router Class Initialized
INFO - 2016-11-10 21:38:51 --> Output Class Initialized
INFO - 2016-11-10 21:38:51 --> Security Class Initialized
DEBUG - 2016-11-10 21:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:38:51 --> Input Class Initialized
INFO - 2016-11-10 21:38:51 --> Language Class Initialized
INFO - 2016-11-10 21:38:51 --> Loader Class Initialized
INFO - 2016-11-10 21:38:51 --> Helper loaded: url_helper
INFO - 2016-11-10 21:38:51 --> Helper loaded: form_helper
INFO - 2016-11-10 21:38:51 --> Database Driver Class Initialized
INFO - 2016-11-10 21:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:38:51 --> Controller Class Initialized
INFO - 2016-11-10 21:38:51 --> Model Class Initialized
INFO - 2016-11-10 21:38:51 --> Form Validation Class Initialized
INFO - 2016-11-10 21:38:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-10 21:38:51 --> Final output sent to browser
DEBUG - 2016-11-10 21:38:51 --> Total execution time: 0.5954
INFO - 2016-11-10 21:39:04 --> Config Class Initialized
INFO - 2016-11-10 21:39:04 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:39:04 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:39:04 --> Utf8 Class Initialized
INFO - 2016-11-10 21:39:04 --> URI Class Initialized
INFO - 2016-11-10 21:39:04 --> Router Class Initialized
INFO - 2016-11-10 21:39:04 --> Output Class Initialized
INFO - 2016-11-10 21:39:04 --> Security Class Initialized
DEBUG - 2016-11-10 21:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:39:04 --> Input Class Initialized
INFO - 2016-11-10 21:39:04 --> Language Class Initialized
INFO - 2016-11-10 21:39:04 --> Loader Class Initialized
INFO - 2016-11-10 21:39:04 --> Helper loaded: url_helper
INFO - 2016-11-10 21:39:04 --> Helper loaded: form_helper
INFO - 2016-11-10 21:39:04 --> Database Driver Class Initialized
INFO - 2016-11-10 21:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:39:04 --> Controller Class Initialized
INFO - 2016-11-10 21:39:04 --> Model Class Initialized
INFO - 2016-11-10 21:39:04 --> Form Validation Class Initialized
INFO - 2016-11-10 21:39:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-10 21:39:04 --> Final output sent to browser
DEBUG - 2016-11-10 21:39:04 --> Total execution time: 0.4471
INFO - 2016-11-10 21:39:05 --> Config Class Initialized
INFO - 2016-11-10 21:39:05 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:39:05 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:39:05 --> Utf8 Class Initialized
INFO - 2016-11-10 21:39:05 --> URI Class Initialized
INFO - 2016-11-10 21:39:05 --> Router Class Initialized
INFO - 2016-11-10 21:39:05 --> Output Class Initialized
INFO - 2016-11-10 21:39:05 --> Security Class Initialized
DEBUG - 2016-11-10 21:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:39:05 --> Input Class Initialized
INFO - 2016-11-10 21:39:05 --> Language Class Initialized
INFO - 2016-11-10 21:39:05 --> Loader Class Initialized
INFO - 2016-11-10 21:39:05 --> Helper loaded: url_helper
INFO - 2016-11-10 21:39:05 --> Helper loaded: form_helper
INFO - 2016-11-10 21:39:05 --> Database Driver Class Initialized
INFO - 2016-11-10 21:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:39:06 --> Controller Class Initialized
INFO - 2016-11-10 21:39:06 --> Model Class Initialized
INFO - 2016-11-10 21:39:06 --> Form Validation Class Initialized
INFO - 2016-11-10 21:39:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-10 21:39:06 --> Final output sent to browser
DEBUG - 2016-11-10 21:39:06 --> Total execution time: 0.4310
INFO - 2016-11-10 21:39:06 --> Config Class Initialized
INFO - 2016-11-10 21:39:06 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:39:06 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:39:06 --> Utf8 Class Initialized
INFO - 2016-11-10 21:39:06 --> URI Class Initialized
INFO - 2016-11-10 21:39:06 --> Router Class Initialized
INFO - 2016-11-10 21:39:06 --> Output Class Initialized
INFO - 2016-11-10 21:39:06 --> Security Class Initialized
DEBUG - 2016-11-10 21:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:39:06 --> Input Class Initialized
INFO - 2016-11-10 21:39:06 --> Language Class Initialized
INFO - 2016-11-10 21:39:06 --> Loader Class Initialized
INFO - 2016-11-10 21:39:06 --> Config Class Initialized
INFO - 2016-11-10 21:39:06 --> Helper loaded: url_helper
INFO - 2016-11-10 21:39:06 --> Hooks Class Initialized
INFO - 2016-11-10 21:39:06 --> Helper loaded: form_helper
DEBUG - 2016-11-10 21:39:06 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:39:06 --> Database Driver Class Initialized
INFO - 2016-11-10 21:39:06 --> Utf8 Class Initialized
INFO - 2016-11-10 21:39:06 --> URI Class Initialized
INFO - 2016-11-10 21:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:39:06 --> Router Class Initialized
INFO - 2016-11-10 21:39:06 --> Controller Class Initialized
INFO - 2016-11-10 21:39:06 --> Model Class Initialized
INFO - 2016-11-10 21:39:06 --> Output Class Initialized
INFO - 2016-11-10 21:39:06 --> Form Validation Class Initialized
INFO - 2016-11-10 21:39:06 --> Security Class Initialized
INFO - 2016-11-10 21:39:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-10 21:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:39:06 --> Final output sent to browser
INFO - 2016-11-10 21:39:06 --> Input Class Initialized
DEBUG - 2016-11-10 21:39:06 --> Total execution time: 0.4864
INFO - 2016-11-10 21:39:06 --> Language Class Initialized
INFO - 2016-11-10 21:39:06 --> Loader Class Initialized
INFO - 2016-11-10 21:39:06 --> Helper loaded: url_helper
INFO - 2016-11-10 21:39:06 --> Helper loaded: form_helper
INFO - 2016-11-10 21:39:06 --> Database Driver Class Initialized
INFO - 2016-11-10 21:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:39:06 --> Controller Class Initialized
INFO - 2016-11-10 21:39:06 --> Model Class Initialized
INFO - 2016-11-10 21:39:06 --> Form Validation Class Initialized
INFO - 2016-11-10 21:39:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-10 21:39:06 --> Final output sent to browser
DEBUG - 2016-11-10 21:39:06 --> Total execution time: 0.5491
INFO - 2016-11-10 21:39:11 --> Config Class Initialized
INFO - 2016-11-10 21:39:11 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:39:11 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:39:11 --> Utf8 Class Initialized
INFO - 2016-11-10 21:39:11 --> URI Class Initialized
DEBUG - 2016-11-10 21:39:11 --> No URI present. Default controller set.
INFO - 2016-11-10 21:39:11 --> Router Class Initialized
INFO - 2016-11-10 21:39:11 --> Output Class Initialized
INFO - 2016-11-10 21:39:11 --> Security Class Initialized
DEBUG - 2016-11-10 21:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:39:11 --> Input Class Initialized
INFO - 2016-11-10 21:39:11 --> Language Class Initialized
INFO - 2016-11-10 21:39:11 --> Loader Class Initialized
INFO - 2016-11-10 21:39:11 --> Helper loaded: url_helper
INFO - 2016-11-10 21:39:11 --> Helper loaded: form_helper
INFO - 2016-11-10 21:39:11 --> Database Driver Class Initialized
INFO - 2016-11-10 21:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:39:11 --> Controller Class Initialized
INFO - 2016-11-10 21:39:11 --> Model Class Initialized
INFO - 2016-11-10 21:39:11 --> Model Class Initialized
INFO - 2016-11-10 21:39:11 --> Model Class Initialized
INFO - 2016-11-10 21:39:11 --> Model Class Initialized
INFO - 2016-11-10 21:39:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:39:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 21:39:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 21:39:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 21:39:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 21:39:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 21:39:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 21:39:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 21:39:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 21:39:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 21:39:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 21:39:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:39:12 --> Final output sent to browser
DEBUG - 2016-11-10 21:39:12 --> Total execution time: 0.7155
INFO - 2016-11-10 21:41:54 --> Config Class Initialized
INFO - 2016-11-10 21:41:54 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:41:54 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:41:54 --> Utf8 Class Initialized
INFO - 2016-11-10 21:41:54 --> URI Class Initialized
DEBUG - 2016-11-10 21:41:54 --> No URI present. Default controller set.
INFO - 2016-11-10 21:41:54 --> Router Class Initialized
INFO - 2016-11-10 21:41:54 --> Output Class Initialized
INFO - 2016-11-10 21:41:54 --> Security Class Initialized
DEBUG - 2016-11-10 21:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:41:54 --> Input Class Initialized
INFO - 2016-11-10 21:41:54 --> Language Class Initialized
INFO - 2016-11-10 21:41:54 --> Loader Class Initialized
INFO - 2016-11-10 21:41:54 --> Helper loaded: url_helper
INFO - 2016-11-10 21:41:54 --> Helper loaded: form_helper
INFO - 2016-11-10 21:41:54 --> Database Driver Class Initialized
INFO - 2016-11-10 21:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:41:54 --> Controller Class Initialized
INFO - 2016-11-10 21:41:54 --> Model Class Initialized
INFO - 2016-11-10 21:41:54 --> Model Class Initialized
INFO - 2016-11-10 21:41:54 --> Model Class Initialized
INFO - 2016-11-10 21:41:54 --> Model Class Initialized
INFO - 2016-11-10 21:41:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:41:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 21:41:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 21:41:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 21:41:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 21:41:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 21:41:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 21:41:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 21:41:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 21:41:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 21:41:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 21:41:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:41:54 --> Final output sent to browser
DEBUG - 2016-11-10 21:41:54 --> Total execution time: 0.7078
INFO - 2016-11-10 21:42:04 --> Config Class Initialized
INFO - 2016-11-10 21:42:04 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:42:04 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:42:04 --> Utf8 Class Initialized
INFO - 2016-11-10 21:42:05 --> URI Class Initialized
INFO - 2016-11-10 21:42:05 --> Router Class Initialized
INFO - 2016-11-10 21:42:05 --> Output Class Initialized
INFO - 2016-11-10 21:42:05 --> Security Class Initialized
DEBUG - 2016-11-10 21:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:42:05 --> Input Class Initialized
INFO - 2016-11-10 21:42:05 --> Language Class Initialized
INFO - 2016-11-10 21:42:05 --> Loader Class Initialized
INFO - 2016-11-10 21:42:05 --> Helper loaded: url_helper
INFO - 2016-11-10 21:42:05 --> Helper loaded: form_helper
INFO - 2016-11-10 21:42:05 --> Database Driver Class Initialized
INFO - 2016-11-10 21:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:42:05 --> Controller Class Initialized
INFO - 2016-11-10 21:42:05 --> Model Class Initialized
INFO - 2016-11-10 21:42:05 --> Form Validation Class Initialized
INFO - 2016-11-10 21:42:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-10 21:42:05 --> Final output sent to browser
DEBUG - 2016-11-10 21:42:05 --> Total execution time: 0.4455
INFO - 2016-11-10 21:42:07 --> Config Class Initialized
INFO - 2016-11-10 21:42:07 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:42:07 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:42:07 --> Utf8 Class Initialized
INFO - 2016-11-10 21:42:07 --> URI Class Initialized
DEBUG - 2016-11-10 21:42:07 --> No URI present. Default controller set.
INFO - 2016-11-10 21:42:07 --> Router Class Initialized
INFO - 2016-11-10 21:42:07 --> Output Class Initialized
INFO - 2016-11-10 21:42:07 --> Security Class Initialized
DEBUG - 2016-11-10 21:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:42:07 --> Input Class Initialized
INFO - 2016-11-10 21:42:07 --> Language Class Initialized
INFO - 2016-11-10 21:42:07 --> Loader Class Initialized
INFO - 2016-11-10 21:42:07 --> Helper loaded: url_helper
INFO - 2016-11-10 21:42:07 --> Helper loaded: form_helper
INFO - 2016-11-10 21:42:07 --> Database Driver Class Initialized
INFO - 2016-11-10 21:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:42:07 --> Controller Class Initialized
INFO - 2016-11-10 21:42:07 --> Model Class Initialized
INFO - 2016-11-10 21:42:07 --> Model Class Initialized
INFO - 2016-11-10 21:42:07 --> Model Class Initialized
INFO - 2016-11-10 21:42:07 --> Model Class Initialized
INFO - 2016-11-10 21:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-10 21:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-10 21:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-10 21:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-10 21:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-10 21:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-10 21:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-10 21:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-10 21:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-10 21:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-10 21:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:42:07 --> Final output sent to browser
DEBUG - 2016-11-10 21:42:07 --> Total execution time: 0.7949
INFO - 2016-11-10 21:42:16 --> Config Class Initialized
INFO - 2016-11-10 21:42:16 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:42:16 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:42:16 --> Utf8 Class Initialized
INFO - 2016-11-10 21:42:16 --> URI Class Initialized
INFO - 2016-11-10 21:42:16 --> Router Class Initialized
INFO - 2016-11-10 21:42:16 --> Output Class Initialized
INFO - 2016-11-10 21:42:16 --> Security Class Initialized
DEBUG - 2016-11-10 21:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:42:16 --> Input Class Initialized
INFO - 2016-11-10 21:42:16 --> Language Class Initialized
INFO - 2016-11-10 21:42:16 --> Loader Class Initialized
INFO - 2016-11-10 21:42:16 --> Helper loaded: url_helper
INFO - 2016-11-10 21:42:16 --> Helper loaded: form_helper
INFO - 2016-11-10 21:42:16 --> Database Driver Class Initialized
INFO - 2016-11-10 21:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:42:16 --> Controller Class Initialized
INFO - 2016-11-10 21:42:17 --> Model Class Initialized
INFO - 2016-11-10 21:42:17 --> Model Class Initialized
INFO - 2016-11-10 21:42:17 --> Model Class Initialized
INFO - 2016-11-10 21:42:17 --> Model Class Initialized
DEBUG - 2016-11-10 21:42:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 21:42:17 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
ERROR - 2016-11-10 21:42:17 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
INFO - 2016-11-10 21:42:17 --> Config Class Initialized
INFO - 2016-11-10 21:42:17 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:42:17 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:42:17 --> Utf8 Class Initialized
INFO - 2016-11-10 21:42:17 --> URI Class Initialized
DEBUG - 2016-11-10 21:42:17 --> No URI present. Default controller set.
INFO - 2016-11-10 21:42:17 --> Router Class Initialized
INFO - 2016-11-10 21:42:17 --> Output Class Initialized
INFO - 2016-11-10 21:42:17 --> Security Class Initialized
DEBUG - 2016-11-10 21:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:42:17 --> Input Class Initialized
INFO - 2016-11-10 21:42:17 --> Language Class Initialized
INFO - 2016-11-10 21:42:17 --> Loader Class Initialized
INFO - 2016-11-10 21:42:17 --> Helper loaded: url_helper
INFO - 2016-11-10 21:42:17 --> Helper loaded: form_helper
INFO - 2016-11-10 21:42:17 --> Database Driver Class Initialized
INFO - 2016-11-10 21:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:42:17 --> Controller Class Initialized
INFO - 2016-11-10 21:42:17 --> Model Class Initialized
INFO - 2016-11-10 21:42:17 --> Model Class Initialized
INFO - 2016-11-10 21:42:17 --> Model Class Initialized
INFO - 2016-11-10 21:42:17 --> Model Class Initialized
INFO - 2016-11-10 21:42:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:42:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 21:42:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:42:17 --> Final output sent to browser
DEBUG - 2016-11-10 21:42:17 --> Total execution time: 0.5195
INFO - 2016-11-10 21:42:46 --> Config Class Initialized
INFO - 2016-11-10 21:42:46 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:42:46 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:42:46 --> Utf8 Class Initialized
INFO - 2016-11-10 21:42:46 --> URI Class Initialized
DEBUG - 2016-11-10 21:42:46 --> No URI present. Default controller set.
INFO - 2016-11-10 21:42:46 --> Router Class Initialized
INFO - 2016-11-10 21:42:46 --> Output Class Initialized
INFO - 2016-11-10 21:42:46 --> Security Class Initialized
DEBUG - 2016-11-10 21:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:42:46 --> Input Class Initialized
INFO - 2016-11-10 21:42:46 --> Language Class Initialized
INFO - 2016-11-10 21:42:46 --> Loader Class Initialized
INFO - 2016-11-10 21:42:46 --> Helper loaded: url_helper
INFO - 2016-11-10 21:42:46 --> Helper loaded: form_helper
INFO - 2016-11-10 21:42:46 --> Database Driver Class Initialized
INFO - 2016-11-10 21:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:42:46 --> Controller Class Initialized
INFO - 2016-11-10 21:42:46 --> Model Class Initialized
INFO - 2016-11-10 21:42:46 --> Model Class Initialized
INFO - 2016-11-10 21:42:46 --> Model Class Initialized
INFO - 2016-11-10 21:42:46 --> Model Class Initialized
INFO - 2016-11-10 21:42:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:42:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 21:42:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:42:46 --> Final output sent to browser
DEBUG - 2016-11-10 21:42:46 --> Total execution time: 0.5473
INFO - 2016-11-10 21:43:58 --> Config Class Initialized
INFO - 2016-11-10 21:43:58 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:43:58 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:43:58 --> Utf8 Class Initialized
INFO - 2016-11-10 21:43:58 --> URI Class Initialized
DEBUG - 2016-11-10 21:43:58 --> No URI present. Default controller set.
INFO - 2016-11-10 21:43:58 --> Router Class Initialized
INFO - 2016-11-10 21:43:58 --> Output Class Initialized
INFO - 2016-11-10 21:43:58 --> Security Class Initialized
DEBUG - 2016-11-10 21:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:43:58 --> Input Class Initialized
INFO - 2016-11-10 21:43:58 --> Language Class Initialized
INFO - 2016-11-10 21:43:58 --> Loader Class Initialized
INFO - 2016-11-10 21:43:58 --> Helper loaded: url_helper
INFO - 2016-11-10 21:43:58 --> Helper loaded: form_helper
INFO - 2016-11-10 21:43:58 --> Database Driver Class Initialized
INFO - 2016-11-10 21:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:43:58 --> Controller Class Initialized
INFO - 2016-11-10 21:43:58 --> Model Class Initialized
INFO - 2016-11-10 21:43:58 --> Model Class Initialized
INFO - 2016-11-10 21:43:58 --> Model Class Initialized
INFO - 2016-11-10 21:43:59 --> Model Class Initialized
INFO - 2016-11-10 21:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 21:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:43:59 --> Final output sent to browser
DEBUG - 2016-11-10 21:43:59 --> Total execution time: 0.6127
INFO - 2016-11-10 21:45:21 --> Config Class Initialized
INFO - 2016-11-10 21:45:21 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:45:21 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:45:21 --> Utf8 Class Initialized
INFO - 2016-11-10 21:45:21 --> URI Class Initialized
DEBUG - 2016-11-10 21:45:21 --> No URI present. Default controller set.
INFO - 2016-11-10 21:45:21 --> Router Class Initialized
INFO - 2016-11-10 21:45:21 --> Output Class Initialized
INFO - 2016-11-10 21:45:21 --> Security Class Initialized
DEBUG - 2016-11-10 21:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:45:22 --> Input Class Initialized
INFO - 2016-11-10 21:45:22 --> Language Class Initialized
INFO - 2016-11-10 21:45:22 --> Loader Class Initialized
INFO - 2016-11-10 21:45:22 --> Helper loaded: url_helper
INFO - 2016-11-10 21:45:22 --> Helper loaded: form_helper
INFO - 2016-11-10 21:45:22 --> Database Driver Class Initialized
INFO - 2016-11-10 21:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:45:22 --> Controller Class Initialized
INFO - 2016-11-10 21:45:22 --> Model Class Initialized
INFO - 2016-11-10 21:45:22 --> Model Class Initialized
INFO - 2016-11-10 21:45:22 --> Model Class Initialized
INFO - 2016-11-10 21:45:22 --> Model Class Initialized
INFO - 2016-11-10 21:45:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:45:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 21:45:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:45:22 --> Final output sent to browser
DEBUG - 2016-11-10 21:45:22 --> Total execution time: 0.6664
INFO - 2016-11-10 21:46:03 --> Config Class Initialized
INFO - 2016-11-10 21:46:03 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:46:03 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:46:03 --> Utf8 Class Initialized
INFO - 2016-11-10 21:46:03 --> URI Class Initialized
INFO - 2016-11-10 21:46:03 --> Router Class Initialized
INFO - 2016-11-10 21:46:03 --> Output Class Initialized
INFO - 2016-11-10 21:46:03 --> Security Class Initialized
DEBUG - 2016-11-10 21:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:46:03 --> Input Class Initialized
INFO - 2016-11-10 21:46:03 --> Language Class Initialized
INFO - 2016-11-10 21:46:03 --> Loader Class Initialized
INFO - 2016-11-10 21:46:03 --> Helper loaded: url_helper
INFO - 2016-11-10 21:46:03 --> Helper loaded: form_helper
INFO - 2016-11-10 21:46:03 --> Database Driver Class Initialized
INFO - 2016-11-10 21:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:46:04 --> Controller Class Initialized
INFO - 2016-11-10 21:46:04 --> Model Class Initialized
INFO - 2016-11-10 21:46:04 --> Model Class Initialized
INFO - 2016-11-10 21:46:04 --> Model Class Initialized
INFO - 2016-11-10 21:46:04 --> Model Class Initialized
DEBUG - 2016-11-10 21:46:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-10 21:46:04 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
ERROR - 2016-11-10 21:46:04 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 142
INFO - 2016-11-10 21:46:04 --> Config Class Initialized
INFO - 2016-11-10 21:46:04 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:46:04 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:46:04 --> Utf8 Class Initialized
INFO - 2016-11-10 21:46:04 --> URI Class Initialized
DEBUG - 2016-11-10 21:46:04 --> No URI present. Default controller set.
INFO - 2016-11-10 21:46:04 --> Router Class Initialized
INFO - 2016-11-10 21:46:04 --> Output Class Initialized
INFO - 2016-11-10 21:46:04 --> Security Class Initialized
DEBUG - 2016-11-10 21:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:46:04 --> Input Class Initialized
INFO - 2016-11-10 21:46:04 --> Language Class Initialized
INFO - 2016-11-10 21:46:04 --> Loader Class Initialized
INFO - 2016-11-10 21:46:04 --> Helper loaded: url_helper
INFO - 2016-11-10 21:46:04 --> Helper loaded: form_helper
INFO - 2016-11-10 21:46:04 --> Database Driver Class Initialized
INFO - 2016-11-10 21:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:46:04 --> Controller Class Initialized
INFO - 2016-11-10 21:46:04 --> Model Class Initialized
INFO - 2016-11-10 21:46:04 --> Model Class Initialized
INFO - 2016-11-10 21:46:04 --> Model Class Initialized
INFO - 2016-11-10 21:46:04 --> Model Class Initialized
INFO - 2016-11-10 21:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-10 21:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-10 21:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-10 21:46:04 --> Final output sent to browser
DEBUG - 2016-11-10 21:46:04 --> Total execution time: 0.5222
