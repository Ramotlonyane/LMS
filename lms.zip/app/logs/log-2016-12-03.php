<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-03 00:00:50 --> Config Class Initialized
INFO - 2016-12-03 00:00:50 --> Hooks Class Initialized
DEBUG - 2016-12-03 00:00:50 --> UTF-8 Support Enabled
INFO - 2016-12-03 00:00:50 --> Utf8 Class Initialized
INFO - 2016-12-03 00:00:50 --> URI Class Initialized
INFO - 2016-12-03 00:00:50 --> Router Class Initialized
INFO - 2016-12-03 00:00:50 --> Output Class Initialized
INFO - 2016-12-03 00:00:50 --> Security Class Initialized
DEBUG - 2016-12-03 00:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 00:00:50 --> Input Class Initialized
INFO - 2016-12-03 00:00:50 --> Language Class Initialized
INFO - 2016-12-03 00:00:50 --> Loader Class Initialized
INFO - 2016-12-03 00:00:50 --> Helper loaded: url_helper
INFO - 2016-12-03 00:00:50 --> Helper loaded: form_helper
INFO - 2016-12-03 00:00:50 --> Database Driver Class Initialized
INFO - 2016-12-03 00:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 00:00:50 --> Controller Class Initialized
INFO - 2016-12-03 00:00:50 --> Model Class Initialized
INFO - 2016-12-03 00:00:50 --> Form Validation Class Initialized
INFO - 2016-12-03 00:00:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 00:00:50 --> Pagination Class Initialized
INFO - 2016-12-03 00:00:50 --> Helper loaded: app_helper
INFO - 2016-12-03 00:00:50 --> Email Class Initialized
INFO - 2016-12-03 00:00:50 --> Final output sent to browser
DEBUG - 2016-12-03 00:00:50 --> Total execution time: 0.2599
INFO - 2016-12-03 00:01:31 --> Config Class Initialized
INFO - 2016-12-03 00:01:31 --> Hooks Class Initialized
DEBUG - 2016-12-03 00:01:31 --> UTF-8 Support Enabled
INFO - 2016-12-03 00:01:31 --> Utf8 Class Initialized
INFO - 2016-12-03 00:01:31 --> URI Class Initialized
INFO - 2016-12-03 00:01:31 --> Router Class Initialized
INFO - 2016-12-03 00:01:31 --> Output Class Initialized
INFO - 2016-12-03 00:01:31 --> Security Class Initialized
DEBUG - 2016-12-03 00:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 00:01:31 --> Input Class Initialized
INFO - 2016-12-03 00:01:31 --> Language Class Initialized
INFO - 2016-12-03 00:01:31 --> Loader Class Initialized
INFO - 2016-12-03 00:01:31 --> Helper loaded: url_helper
INFO - 2016-12-03 00:01:31 --> Helper loaded: form_helper
INFO - 2016-12-03 00:01:31 --> Database Driver Class Initialized
INFO - 2016-12-03 00:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 00:01:31 --> Controller Class Initialized
INFO - 2016-12-03 00:01:31 --> Model Class Initialized
INFO - 2016-12-03 00:01:31 --> Form Validation Class Initialized
INFO - 2016-12-03 00:01:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 00:01:31 --> Pagination Class Initialized
INFO - 2016-12-03 00:01:31 --> Helper loaded: app_helper
INFO - 2016-12-03 00:01:31 --> Email Class Initialized
INFO - 2016-12-03 00:01:31 --> Final output sent to browser
DEBUG - 2016-12-03 00:01:31 --> Total execution time: 0.3105
INFO - 2016-12-03 00:02:08 --> Config Class Initialized
INFO - 2016-12-03 00:02:08 --> Hooks Class Initialized
DEBUG - 2016-12-03 00:02:08 --> UTF-8 Support Enabled
INFO - 2016-12-03 00:02:08 --> Utf8 Class Initialized
INFO - 2016-12-03 00:02:08 --> URI Class Initialized
DEBUG - 2016-12-03 00:02:08 --> No URI present. Default controller set.
INFO - 2016-12-03 00:02:08 --> Router Class Initialized
INFO - 2016-12-03 00:02:08 --> Output Class Initialized
INFO - 2016-12-03 00:02:08 --> Security Class Initialized
DEBUG - 2016-12-03 00:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 00:02:08 --> Input Class Initialized
INFO - 2016-12-03 00:02:08 --> Language Class Initialized
INFO - 2016-12-03 00:02:09 --> Loader Class Initialized
INFO - 2016-12-03 00:02:09 --> Helper loaded: url_helper
INFO - 2016-12-03 00:02:09 --> Helper loaded: form_helper
INFO - 2016-12-03 00:02:09 --> Database Driver Class Initialized
INFO - 2016-12-03 00:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 00:02:09 --> Controller Class Initialized
INFO - 2016-12-03 00:02:09 --> Model Class Initialized
INFO - 2016-12-03 00:02:09 --> Model Class Initialized
INFO - 2016-12-03 00:02:09 --> Model Class Initialized
INFO - 2016-12-03 00:02:09 --> Model Class Initialized
INFO - 2016-12-03 00:02:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 00:02:09 --> Pagination Class Initialized
INFO - 2016-12-03 00:02:09 --> Helper loaded: app_helper
INFO - 2016-12-03 00:02:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 00:02:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-03 00:02:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-03 00:02:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-03 00:02:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-03 00:02:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-03 00:02:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-03 00:02:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-03 00:02:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 00:02:09 --> Final output sent to browser
DEBUG - 2016-12-03 00:02:09 --> Total execution time: 0.3618
INFO - 2016-12-03 00:03:41 --> Config Class Initialized
INFO - 2016-12-03 00:03:41 --> Hooks Class Initialized
DEBUG - 2016-12-03 00:03:41 --> UTF-8 Support Enabled
INFO - 2016-12-03 00:03:41 --> Utf8 Class Initialized
INFO - 2016-12-03 00:03:41 --> URI Class Initialized
DEBUG - 2016-12-03 00:03:41 --> No URI present. Default controller set.
INFO - 2016-12-03 00:03:41 --> Router Class Initialized
INFO - 2016-12-03 00:03:41 --> Output Class Initialized
INFO - 2016-12-03 00:03:41 --> Security Class Initialized
DEBUG - 2016-12-03 00:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 00:03:41 --> Input Class Initialized
INFO - 2016-12-03 00:03:41 --> Language Class Initialized
INFO - 2016-12-03 00:03:41 --> Loader Class Initialized
INFO - 2016-12-03 00:03:41 --> Helper loaded: url_helper
INFO - 2016-12-03 00:03:41 --> Helper loaded: form_helper
INFO - 2016-12-03 00:03:41 --> Database Driver Class Initialized
INFO - 2016-12-03 00:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 00:03:41 --> Controller Class Initialized
INFO - 2016-12-03 00:03:41 --> Model Class Initialized
INFO - 2016-12-03 00:03:41 --> Model Class Initialized
INFO - 2016-12-03 00:03:41 --> Model Class Initialized
INFO - 2016-12-03 00:03:41 --> Model Class Initialized
INFO - 2016-12-03 00:03:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 00:03:41 --> Pagination Class Initialized
INFO - 2016-12-03 00:03:41 --> Helper loaded: app_helper
INFO - 2016-12-03 00:03:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 00:03:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-03 00:03:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-03 00:03:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-03 00:03:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-03 00:03:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-03 00:03:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-03 00:03:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-03 00:03:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 00:03:42 --> Final output sent to browser
DEBUG - 2016-12-03 00:03:42 --> Total execution time: 0.3686
INFO - 2016-12-03 00:04:23 --> Config Class Initialized
INFO - 2016-12-03 00:04:23 --> Hooks Class Initialized
DEBUG - 2016-12-03 00:04:23 --> UTF-8 Support Enabled
INFO - 2016-12-03 00:04:23 --> Utf8 Class Initialized
INFO - 2016-12-03 00:04:23 --> URI Class Initialized
DEBUG - 2016-12-03 00:04:23 --> No URI present. Default controller set.
INFO - 2016-12-03 00:04:23 --> Router Class Initialized
INFO - 2016-12-03 00:04:23 --> Output Class Initialized
INFO - 2016-12-03 00:04:23 --> Security Class Initialized
DEBUG - 2016-12-03 00:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 00:04:23 --> Input Class Initialized
INFO - 2016-12-03 00:04:23 --> Language Class Initialized
INFO - 2016-12-03 00:04:23 --> Loader Class Initialized
INFO - 2016-12-03 00:04:23 --> Helper loaded: url_helper
INFO - 2016-12-03 00:04:23 --> Helper loaded: form_helper
INFO - 2016-12-03 00:04:23 --> Database Driver Class Initialized
INFO - 2016-12-03 00:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 00:04:23 --> Controller Class Initialized
INFO - 2016-12-03 00:04:23 --> Model Class Initialized
INFO - 2016-12-03 00:04:23 --> Model Class Initialized
INFO - 2016-12-03 00:04:23 --> Model Class Initialized
INFO - 2016-12-03 00:04:23 --> Model Class Initialized
INFO - 2016-12-03 00:04:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 00:04:23 --> Pagination Class Initialized
INFO - 2016-12-03 00:04:23 --> Helper loaded: app_helper
INFO - 2016-12-03 00:04:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 00:04:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-03 00:04:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-03 00:04:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-03 00:04:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-03 00:04:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-03 00:04:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-03 00:04:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-03 00:04:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 00:04:24 --> Final output sent to browser
DEBUG - 2016-12-03 00:04:24 --> Total execution time: 0.3873
INFO - 2016-12-03 00:05:00 --> Config Class Initialized
INFO - 2016-12-03 00:05:00 --> Hooks Class Initialized
DEBUG - 2016-12-03 00:05:00 --> UTF-8 Support Enabled
INFO - 2016-12-03 00:05:00 --> Utf8 Class Initialized
INFO - 2016-12-03 00:05:00 --> URI Class Initialized
INFO - 2016-12-03 00:05:00 --> Router Class Initialized
INFO - 2016-12-03 00:05:00 --> Output Class Initialized
INFO - 2016-12-03 00:05:00 --> Security Class Initialized
DEBUG - 2016-12-03 00:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 00:05:00 --> Input Class Initialized
INFO - 2016-12-03 00:05:00 --> Language Class Initialized
INFO - 2016-12-03 00:05:00 --> Loader Class Initialized
INFO - 2016-12-03 00:05:00 --> Helper loaded: url_helper
INFO - 2016-12-03 00:05:00 --> Helper loaded: form_helper
INFO - 2016-12-03 00:05:00 --> Database Driver Class Initialized
INFO - 2016-12-03 00:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 00:05:00 --> Controller Class Initialized
INFO - 2016-12-03 00:05:01 --> Model Class Initialized
INFO - 2016-12-03 00:05:01 --> Model Class Initialized
INFO - 2016-12-03 00:05:01 --> Model Class Initialized
INFO - 2016-12-03 00:05:01 --> Model Class Initialized
INFO - 2016-12-03 00:05:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 00:05:01 --> Pagination Class Initialized
INFO - 2016-12-03 00:05:01 --> Helper loaded: app_helper
DEBUG - 2016-12-03 00:05:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-12-03 00:05:01 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-12-03 00:05:01 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-12-03 00:05:01 --> Config Class Initialized
INFO - 2016-12-03 00:05:01 --> Hooks Class Initialized
DEBUG - 2016-12-03 00:05:01 --> UTF-8 Support Enabled
INFO - 2016-12-03 00:05:01 --> Utf8 Class Initialized
INFO - 2016-12-03 00:05:01 --> URI Class Initialized
DEBUG - 2016-12-03 00:05:01 --> No URI present. Default controller set.
INFO - 2016-12-03 00:05:01 --> Router Class Initialized
INFO - 2016-12-03 00:05:01 --> Output Class Initialized
INFO - 2016-12-03 00:05:01 --> Security Class Initialized
DEBUG - 2016-12-03 00:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 00:05:01 --> Input Class Initialized
INFO - 2016-12-03 00:05:01 --> Language Class Initialized
INFO - 2016-12-03 00:05:01 --> Loader Class Initialized
INFO - 2016-12-03 00:05:01 --> Helper loaded: url_helper
INFO - 2016-12-03 00:05:01 --> Helper loaded: form_helper
INFO - 2016-12-03 00:05:01 --> Database Driver Class Initialized
INFO - 2016-12-03 00:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 00:05:01 --> Controller Class Initialized
INFO - 2016-12-03 00:05:01 --> Model Class Initialized
INFO - 2016-12-03 00:05:01 --> Model Class Initialized
INFO - 2016-12-03 00:05:01 --> Model Class Initialized
INFO - 2016-12-03 00:05:01 --> Model Class Initialized
INFO - 2016-12-03 00:05:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 00:05:01 --> Pagination Class Initialized
INFO - 2016-12-03 00:05:01 --> Helper loaded: app_helper
INFO - 2016-12-03 00:05:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 00:05:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-03 00:05:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 00:05:01 --> Final output sent to browser
DEBUG - 2016-12-03 00:05:01 --> Total execution time: 0.3187
INFO - 2016-12-03 00:05:11 --> Config Class Initialized
INFO - 2016-12-03 00:05:11 --> Hooks Class Initialized
DEBUG - 2016-12-03 00:05:11 --> UTF-8 Support Enabled
INFO - 2016-12-03 00:05:11 --> Utf8 Class Initialized
INFO - 2016-12-03 00:05:11 --> URI Class Initialized
INFO - 2016-12-03 00:05:11 --> Router Class Initialized
INFO - 2016-12-03 00:05:11 --> Output Class Initialized
INFO - 2016-12-03 00:05:11 --> Security Class Initialized
DEBUG - 2016-12-03 00:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 00:05:11 --> Input Class Initialized
INFO - 2016-12-03 00:05:11 --> Language Class Initialized
INFO - 2016-12-03 00:05:11 --> Loader Class Initialized
INFO - 2016-12-03 00:05:11 --> Helper loaded: url_helper
INFO - 2016-12-03 00:05:11 --> Helper loaded: form_helper
INFO - 2016-12-03 00:05:11 --> Database Driver Class Initialized
INFO - 2016-12-03 00:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 00:05:11 --> Controller Class Initialized
INFO - 2016-12-03 00:05:11 --> Model Class Initialized
INFO - 2016-12-03 00:05:11 --> Model Class Initialized
INFO - 2016-12-03 00:05:11 --> Model Class Initialized
INFO - 2016-12-03 00:05:11 --> Model Class Initialized
INFO - 2016-12-03 00:05:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 00:05:11 --> Pagination Class Initialized
INFO - 2016-12-03 00:05:11 --> Helper loaded: app_helper
DEBUG - 2016-12-03 00:05:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 00:05:11 --> Model Class Initialized
INFO - 2016-12-03 00:05:11 --> Final output sent to browser
DEBUG - 2016-12-03 00:05:11 --> Total execution time: 0.2791
INFO - 2016-12-03 00:05:11 --> Config Class Initialized
INFO - 2016-12-03 00:05:11 --> Hooks Class Initialized
DEBUG - 2016-12-03 00:05:11 --> UTF-8 Support Enabled
INFO - 2016-12-03 00:05:11 --> Utf8 Class Initialized
INFO - 2016-12-03 00:05:11 --> URI Class Initialized
DEBUG - 2016-12-03 00:05:11 --> No URI present. Default controller set.
INFO - 2016-12-03 00:05:11 --> Router Class Initialized
INFO - 2016-12-03 00:05:11 --> Output Class Initialized
INFO - 2016-12-03 00:05:11 --> Security Class Initialized
DEBUG - 2016-12-03 00:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 00:05:11 --> Input Class Initialized
INFO - 2016-12-03 00:05:11 --> Language Class Initialized
INFO - 2016-12-03 00:05:11 --> Loader Class Initialized
INFO - 2016-12-03 00:05:11 --> Helper loaded: url_helper
INFO - 2016-12-03 00:05:11 --> Helper loaded: form_helper
INFO - 2016-12-03 00:05:11 --> Database Driver Class Initialized
INFO - 2016-12-03 00:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 00:05:11 --> Controller Class Initialized
INFO - 2016-12-03 00:05:11 --> Model Class Initialized
INFO - 2016-12-03 00:05:11 --> Model Class Initialized
INFO - 2016-12-03 00:05:11 --> Model Class Initialized
INFO - 2016-12-03 00:05:11 --> Model Class Initialized
INFO - 2016-12-03 00:05:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 00:05:11 --> Pagination Class Initialized
INFO - 2016-12-03 00:05:11 --> Helper loaded: app_helper
INFO - 2016-12-03 00:05:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 00:05:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-03 00:05:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-03 00:05:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-12-03 00:05:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-12-03 00:05:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-12-03 00:05:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-03 00:05:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 00:05:11 --> Final output sent to browser
DEBUG - 2016-12-03 00:05:11 --> Total execution time: 0.4788
INFO - 2016-12-03 00:05:27 --> Config Class Initialized
INFO - 2016-12-03 00:05:27 --> Hooks Class Initialized
DEBUG - 2016-12-03 00:05:27 --> UTF-8 Support Enabled
INFO - 2016-12-03 00:05:27 --> Utf8 Class Initialized
INFO - 2016-12-03 00:05:27 --> URI Class Initialized
INFO - 2016-12-03 00:05:27 --> Router Class Initialized
INFO - 2016-12-03 00:05:27 --> Output Class Initialized
INFO - 2016-12-03 00:05:27 --> Security Class Initialized
DEBUG - 2016-12-03 00:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 00:05:27 --> Input Class Initialized
INFO - 2016-12-03 00:05:27 --> Language Class Initialized
INFO - 2016-12-03 00:05:27 --> Loader Class Initialized
INFO - 2016-12-03 00:05:27 --> Helper loaded: url_helper
INFO - 2016-12-03 00:05:27 --> Helper loaded: form_helper
INFO - 2016-12-03 00:05:27 --> Database Driver Class Initialized
INFO - 2016-12-03 00:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 00:05:27 --> Controller Class Initialized
INFO - 2016-12-03 00:05:27 --> Model Class Initialized
INFO - 2016-12-03 00:05:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 00:05:27 --> Pagination Class Initialized
INFO - 2016-12-03 00:05:27 --> Helper loaded: app_helper
INFO - 2016-12-03 00:05:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-12-03 00:05:27 --> Final output sent to browser
DEBUG - 2016-12-03 00:05:27 --> Total execution time: 0.2051
INFO - 2016-12-03 00:05:38 --> Config Class Initialized
INFO - 2016-12-03 00:05:38 --> Hooks Class Initialized
DEBUG - 2016-12-03 00:05:38 --> UTF-8 Support Enabled
INFO - 2016-12-03 00:05:38 --> Utf8 Class Initialized
INFO - 2016-12-03 00:05:38 --> URI Class Initialized
INFO - 2016-12-03 00:05:38 --> Router Class Initialized
INFO - 2016-12-03 00:05:38 --> Output Class Initialized
INFO - 2016-12-03 00:05:38 --> Security Class Initialized
DEBUG - 2016-12-03 00:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 00:05:38 --> Input Class Initialized
INFO - 2016-12-03 00:05:38 --> Language Class Initialized
INFO - 2016-12-03 00:05:38 --> Loader Class Initialized
INFO - 2016-12-03 00:05:38 --> Helper loaded: url_helper
INFO - 2016-12-03 00:05:38 --> Helper loaded: form_helper
INFO - 2016-12-03 00:05:38 --> Database Driver Class Initialized
INFO - 2016-12-03 00:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 00:05:38 --> Controller Class Initialized
INFO - 2016-12-03 00:05:38 --> Model Class Initialized
INFO - 2016-12-03 00:05:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 00:05:38 --> Pagination Class Initialized
INFO - 2016-12-03 00:05:38 --> Helper loaded: app_helper
INFO - 2016-12-03 00:05:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-12-03 00:05:38 --> Final output sent to browser
DEBUG - 2016-12-03 00:05:38 --> Total execution time: 0.2064
INFO - 2016-12-03 00:06:36 --> Config Class Initialized
INFO - 2016-12-03 00:06:36 --> Hooks Class Initialized
DEBUG - 2016-12-03 00:06:36 --> UTF-8 Support Enabled
INFO - 2016-12-03 00:06:36 --> Utf8 Class Initialized
INFO - 2016-12-03 00:06:36 --> URI Class Initialized
INFO - 2016-12-03 00:06:36 --> Router Class Initialized
INFO - 2016-12-03 00:06:36 --> Output Class Initialized
INFO - 2016-12-03 00:06:36 --> Security Class Initialized
DEBUG - 2016-12-03 00:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 00:06:36 --> Input Class Initialized
INFO - 2016-12-03 00:06:36 --> Language Class Initialized
INFO - 2016-12-03 00:06:36 --> Loader Class Initialized
INFO - 2016-12-03 00:06:36 --> Helper loaded: url_helper
INFO - 2016-12-03 00:06:36 --> Helper loaded: form_helper
INFO - 2016-12-03 00:06:36 --> Database Driver Class Initialized
INFO - 2016-12-03 00:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 00:06:36 --> Controller Class Initialized
INFO - 2016-12-03 00:06:37 --> Model Class Initialized
INFO - 2016-12-03 00:06:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 00:06:37 --> Pagination Class Initialized
INFO - 2016-12-03 00:06:37 --> Helper loaded: app_helper
INFO - 2016-12-03 00:06:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-12-03 00:06:37 --> Final output sent to browser
DEBUG - 2016-12-03 00:06:37 --> Total execution time: 0.2264
INFO - 2016-12-03 00:06:40 --> Config Class Initialized
INFO - 2016-12-03 00:06:40 --> Hooks Class Initialized
DEBUG - 2016-12-03 00:06:40 --> UTF-8 Support Enabled
INFO - 2016-12-03 00:06:40 --> Utf8 Class Initialized
INFO - 2016-12-03 00:06:40 --> URI Class Initialized
INFO - 2016-12-03 00:06:40 --> Router Class Initialized
INFO - 2016-12-03 00:06:40 --> Output Class Initialized
INFO - 2016-12-03 00:06:40 --> Security Class Initialized
DEBUG - 2016-12-03 00:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 00:06:40 --> Input Class Initialized
INFO - 2016-12-03 00:06:40 --> Language Class Initialized
INFO - 2016-12-03 00:06:40 --> Loader Class Initialized
INFO - 2016-12-03 00:06:40 --> Helper loaded: url_helper
INFO - 2016-12-03 00:06:40 --> Helper loaded: form_helper
INFO - 2016-12-03 00:06:40 --> Database Driver Class Initialized
INFO - 2016-12-03 00:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 00:06:40 --> Controller Class Initialized
INFO - 2016-12-03 00:06:40 --> Model Class Initialized
INFO - 2016-12-03 00:06:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 00:06:40 --> Pagination Class Initialized
INFO - 2016-12-03 00:06:40 --> Helper loaded: app_helper
INFO - 2016-12-03 00:06:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-12-03 00:06:40 --> Final output sent to browser
DEBUG - 2016-12-03 00:06:40 --> Total execution time: 0.2117
INFO - 2016-12-03 00:06:46 --> Config Class Initialized
INFO - 2016-12-03 00:06:46 --> Hooks Class Initialized
DEBUG - 2016-12-03 00:06:46 --> UTF-8 Support Enabled
INFO - 2016-12-03 00:06:46 --> Utf8 Class Initialized
INFO - 2016-12-03 00:06:46 --> URI Class Initialized
INFO - 2016-12-03 00:06:46 --> Router Class Initialized
INFO - 2016-12-03 00:06:46 --> Output Class Initialized
INFO - 2016-12-03 00:06:46 --> Security Class Initialized
DEBUG - 2016-12-03 00:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 00:06:46 --> Input Class Initialized
INFO - 2016-12-03 00:06:46 --> Language Class Initialized
INFO - 2016-12-03 00:06:46 --> Loader Class Initialized
INFO - 2016-12-03 00:06:46 --> Helper loaded: url_helper
INFO - 2016-12-03 00:06:46 --> Helper loaded: form_helper
INFO - 2016-12-03 00:06:46 --> Database Driver Class Initialized
INFO - 2016-12-03 00:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 00:06:46 --> Controller Class Initialized
INFO - 2016-12-03 00:06:46 --> Model Class Initialized
INFO - 2016-12-03 00:06:46 --> Model Class Initialized
INFO - 2016-12-03 00:06:46 --> Model Class Initialized
INFO - 2016-12-03 00:06:46 --> Model Class Initialized
INFO - 2016-12-03 00:06:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 00:06:46 --> Pagination Class Initialized
INFO - 2016-12-03 00:06:46 --> Helper loaded: app_helper
DEBUG - 2016-12-03 00:06:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-12-03 00:06:46 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-12-03 00:06:46 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-12-03 00:06:46 --> Config Class Initialized
INFO - 2016-12-03 00:06:46 --> Hooks Class Initialized
DEBUG - 2016-12-03 00:06:46 --> UTF-8 Support Enabled
INFO - 2016-12-03 00:06:46 --> Utf8 Class Initialized
INFO - 2016-12-03 00:06:46 --> URI Class Initialized
DEBUG - 2016-12-03 00:06:46 --> No URI present. Default controller set.
INFO - 2016-12-03 00:06:46 --> Router Class Initialized
INFO - 2016-12-03 00:06:46 --> Output Class Initialized
INFO - 2016-12-03 00:06:46 --> Security Class Initialized
DEBUG - 2016-12-03 00:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 00:06:46 --> Input Class Initialized
INFO - 2016-12-03 00:06:46 --> Language Class Initialized
INFO - 2016-12-03 00:06:46 --> Loader Class Initialized
INFO - 2016-12-03 00:06:46 --> Helper loaded: url_helper
INFO - 2016-12-03 00:06:46 --> Helper loaded: form_helper
INFO - 2016-12-03 00:06:46 --> Database Driver Class Initialized
INFO - 2016-12-03 00:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 00:06:47 --> Controller Class Initialized
INFO - 2016-12-03 00:06:47 --> Model Class Initialized
INFO - 2016-12-03 00:06:47 --> Model Class Initialized
INFO - 2016-12-03 00:06:47 --> Model Class Initialized
INFO - 2016-12-03 00:06:47 --> Model Class Initialized
INFO - 2016-12-03 00:06:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 00:06:47 --> Pagination Class Initialized
INFO - 2016-12-03 00:06:47 --> Helper loaded: app_helper
INFO - 2016-12-03 00:06:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 00:06:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-03 00:06:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 00:06:47 --> Final output sent to browser
DEBUG - 2016-12-03 00:06:47 --> Total execution time: 0.2955
INFO - 2016-12-03 00:07:01 --> Config Class Initialized
INFO - 2016-12-03 00:07:01 --> Hooks Class Initialized
DEBUG - 2016-12-03 00:07:01 --> UTF-8 Support Enabled
INFO - 2016-12-03 00:07:01 --> Utf8 Class Initialized
INFO - 2016-12-03 00:07:01 --> URI Class Initialized
INFO - 2016-12-03 00:07:01 --> Router Class Initialized
INFO - 2016-12-03 00:07:01 --> Output Class Initialized
INFO - 2016-12-03 00:07:01 --> Security Class Initialized
DEBUG - 2016-12-03 00:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 00:07:01 --> Input Class Initialized
INFO - 2016-12-03 00:07:01 --> Language Class Initialized
INFO - 2016-12-03 00:07:01 --> Loader Class Initialized
INFO - 2016-12-03 00:07:01 --> Helper loaded: url_helper
INFO - 2016-12-03 00:07:01 --> Helper loaded: form_helper
INFO - 2016-12-03 00:07:01 --> Database Driver Class Initialized
INFO - 2016-12-03 00:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 00:07:01 --> Controller Class Initialized
INFO - 2016-12-03 00:07:01 --> Model Class Initialized
INFO - 2016-12-03 00:07:01 --> Model Class Initialized
INFO - 2016-12-03 00:07:01 --> Model Class Initialized
INFO - 2016-12-03 00:07:01 --> Model Class Initialized
INFO - 2016-12-03 00:07:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 00:07:01 --> Pagination Class Initialized
INFO - 2016-12-03 00:07:01 --> Helper loaded: app_helper
DEBUG - 2016-12-03 00:07:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 00:07:01 --> Model Class Initialized
INFO - 2016-12-03 00:07:01 --> Final output sent to browser
DEBUG - 2016-12-03 00:07:01 --> Total execution time: 0.2290
INFO - 2016-12-03 00:07:01 --> Config Class Initialized
INFO - 2016-12-03 00:07:01 --> Hooks Class Initialized
DEBUG - 2016-12-03 00:07:01 --> UTF-8 Support Enabled
INFO - 2016-12-03 00:07:01 --> Utf8 Class Initialized
INFO - 2016-12-03 00:07:01 --> URI Class Initialized
DEBUG - 2016-12-03 00:07:01 --> No URI present. Default controller set.
INFO - 2016-12-03 00:07:01 --> Router Class Initialized
INFO - 2016-12-03 00:07:01 --> Output Class Initialized
INFO - 2016-12-03 00:07:01 --> Security Class Initialized
DEBUG - 2016-12-03 00:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 00:07:01 --> Input Class Initialized
INFO - 2016-12-03 00:07:01 --> Language Class Initialized
INFO - 2016-12-03 00:07:01 --> Loader Class Initialized
INFO - 2016-12-03 00:07:01 --> Helper loaded: url_helper
INFO - 2016-12-03 00:07:01 --> Helper loaded: form_helper
INFO - 2016-12-03 00:07:01 --> Database Driver Class Initialized
INFO - 2016-12-03 00:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 00:07:01 --> Controller Class Initialized
INFO - 2016-12-03 00:07:01 --> Model Class Initialized
INFO - 2016-12-03 00:07:01 --> Model Class Initialized
INFO - 2016-12-03 00:07:01 --> Model Class Initialized
INFO - 2016-12-03 00:07:01 --> Model Class Initialized
INFO - 2016-12-03 00:07:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 00:07:01 --> Pagination Class Initialized
INFO - 2016-12-03 00:07:01 --> Helper loaded: app_helper
INFO - 2016-12-03 00:07:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 00:07:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-03 00:07:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-03 00:07:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-12-03 00:07:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-12-03 00:07:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-12-03 00:07:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-12-03 00:07:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-12-03 00:07:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-12-03 00:07:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-03 00:07:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 00:07:01 --> Final output sent to browser
DEBUG - 2016-12-03 00:07:01 --> Total execution time: 0.4351
INFO - 2016-12-03 00:07:47 --> Config Class Initialized
INFO - 2016-12-03 00:07:47 --> Hooks Class Initialized
DEBUG - 2016-12-03 00:07:47 --> UTF-8 Support Enabled
INFO - 2016-12-03 00:07:47 --> Utf8 Class Initialized
INFO - 2016-12-03 00:07:47 --> URI Class Initialized
DEBUG - 2016-12-03 00:07:47 --> No URI present. Default controller set.
INFO - 2016-12-03 00:07:47 --> Router Class Initialized
INFO - 2016-12-03 00:07:47 --> Output Class Initialized
INFO - 2016-12-03 00:07:47 --> Security Class Initialized
DEBUG - 2016-12-03 00:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 00:07:47 --> Input Class Initialized
INFO - 2016-12-03 00:07:47 --> Language Class Initialized
INFO - 2016-12-03 00:07:47 --> Loader Class Initialized
INFO - 2016-12-03 00:07:47 --> Helper loaded: url_helper
INFO - 2016-12-03 00:07:47 --> Helper loaded: form_helper
INFO - 2016-12-03 00:07:47 --> Database Driver Class Initialized
INFO - 2016-12-03 00:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 00:07:47 --> Controller Class Initialized
INFO - 2016-12-03 00:07:47 --> Model Class Initialized
INFO - 2016-12-03 00:07:47 --> Model Class Initialized
INFO - 2016-12-03 00:07:47 --> Model Class Initialized
INFO - 2016-12-03 00:07:47 --> Model Class Initialized
INFO - 2016-12-03 00:07:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 00:07:47 --> Pagination Class Initialized
INFO - 2016-12-03 00:07:47 --> Helper loaded: app_helper
INFO - 2016-12-03 00:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 00:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-03 00:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-03 00:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-12-03 00:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-12-03 00:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-12-03 00:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-12-03 00:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-12-03 00:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-12-03 00:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-03 00:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 00:07:47 --> Final output sent to browser
DEBUG - 2016-12-03 00:07:47 --> Total execution time: 0.4349
INFO - 2016-12-03 00:08:09 --> Config Class Initialized
INFO - 2016-12-03 00:08:09 --> Hooks Class Initialized
DEBUG - 2016-12-03 00:08:09 --> UTF-8 Support Enabled
INFO - 2016-12-03 00:08:09 --> Utf8 Class Initialized
INFO - 2016-12-03 00:08:09 --> URI Class Initialized
INFO - 2016-12-03 00:08:09 --> Router Class Initialized
INFO - 2016-12-03 00:08:09 --> Output Class Initialized
INFO - 2016-12-03 00:08:09 --> Security Class Initialized
DEBUG - 2016-12-03 00:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 00:08:09 --> Input Class Initialized
INFO - 2016-12-03 00:08:09 --> Language Class Initialized
INFO - 2016-12-03 00:08:09 --> Loader Class Initialized
INFO - 2016-12-03 00:08:09 --> Helper loaded: url_helper
INFO - 2016-12-03 00:08:09 --> Helper loaded: form_helper
INFO - 2016-12-03 00:08:09 --> Database Driver Class Initialized
INFO - 2016-12-03 00:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 00:08:09 --> Controller Class Initialized
INFO - 2016-12-03 00:08:09 --> Model Class Initialized
INFO - 2016-12-03 00:08:09 --> Model Class Initialized
INFO - 2016-12-03 00:08:09 --> Model Class Initialized
INFO - 2016-12-03 00:08:09 --> Model Class Initialized
INFO - 2016-12-03 00:08:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 00:08:10 --> Pagination Class Initialized
INFO - 2016-12-03 00:08:10 --> Helper loaded: app_helper
DEBUG - 2016-12-03 00:08:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-12-03 00:08:10 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-12-03 00:08:10 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-12-03 00:08:10 --> Config Class Initialized
INFO - 2016-12-03 00:08:10 --> Hooks Class Initialized
DEBUG - 2016-12-03 00:08:10 --> UTF-8 Support Enabled
INFO - 2016-12-03 00:08:10 --> Utf8 Class Initialized
INFO - 2016-12-03 00:08:10 --> URI Class Initialized
DEBUG - 2016-12-03 00:08:10 --> No URI present. Default controller set.
INFO - 2016-12-03 00:08:10 --> Router Class Initialized
INFO - 2016-12-03 00:08:10 --> Output Class Initialized
INFO - 2016-12-03 00:08:10 --> Security Class Initialized
DEBUG - 2016-12-03 00:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 00:08:10 --> Input Class Initialized
INFO - 2016-12-03 00:08:10 --> Language Class Initialized
INFO - 2016-12-03 00:08:10 --> Loader Class Initialized
INFO - 2016-12-03 00:08:10 --> Helper loaded: url_helper
INFO - 2016-12-03 00:08:10 --> Helper loaded: form_helper
INFO - 2016-12-03 00:08:10 --> Database Driver Class Initialized
INFO - 2016-12-03 00:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 00:08:10 --> Controller Class Initialized
INFO - 2016-12-03 00:08:10 --> Model Class Initialized
INFO - 2016-12-03 00:08:10 --> Model Class Initialized
INFO - 2016-12-03 00:08:10 --> Model Class Initialized
INFO - 2016-12-03 00:08:10 --> Model Class Initialized
INFO - 2016-12-03 00:08:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 00:08:10 --> Pagination Class Initialized
INFO - 2016-12-03 00:08:10 --> Helper loaded: app_helper
INFO - 2016-12-03 00:08:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 00:08:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-03 00:08:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 00:08:10 --> Final output sent to browser
DEBUG - 2016-12-03 00:08:10 --> Total execution time: 0.2932
INFO - 2016-12-03 00:11:43 --> Config Class Initialized
INFO - 2016-12-03 00:11:43 --> Hooks Class Initialized
DEBUG - 2016-12-03 00:11:43 --> UTF-8 Support Enabled
INFO - 2016-12-03 00:11:43 --> Utf8 Class Initialized
INFO - 2016-12-03 00:11:43 --> URI Class Initialized
DEBUG - 2016-12-03 00:11:43 --> No URI present. Default controller set.
INFO - 2016-12-03 00:11:43 --> Router Class Initialized
INFO - 2016-12-03 00:11:43 --> Output Class Initialized
INFO - 2016-12-03 00:11:43 --> Security Class Initialized
DEBUG - 2016-12-03 00:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 00:11:43 --> Input Class Initialized
INFO - 2016-12-03 00:11:43 --> Language Class Initialized
INFO - 2016-12-03 00:11:43 --> Loader Class Initialized
INFO - 2016-12-03 00:11:43 --> Helper loaded: url_helper
INFO - 2016-12-03 00:11:43 --> Helper loaded: form_helper
INFO - 2016-12-03 00:11:43 --> Database Driver Class Initialized
INFO - 2016-12-03 00:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 00:11:43 --> Controller Class Initialized
INFO - 2016-12-03 00:11:43 --> Model Class Initialized
INFO - 2016-12-03 00:11:43 --> Model Class Initialized
INFO - 2016-12-03 00:11:43 --> Model Class Initialized
INFO - 2016-12-03 00:11:43 --> Model Class Initialized
INFO - 2016-12-03 00:11:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 00:11:43 --> Pagination Class Initialized
INFO - 2016-12-03 00:11:43 --> Helper loaded: app_helper
INFO - 2016-12-03 00:11:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 00:11:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-03 00:11:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 00:11:43 --> Final output sent to browser
DEBUG - 2016-12-03 00:11:43 --> Total execution time: 0.3219
INFO - 2016-12-03 00:11:50 --> Config Class Initialized
INFO - 2016-12-03 00:11:50 --> Hooks Class Initialized
DEBUG - 2016-12-03 00:11:50 --> UTF-8 Support Enabled
INFO - 2016-12-03 00:11:50 --> Utf8 Class Initialized
INFO - 2016-12-03 00:11:50 --> URI Class Initialized
DEBUG - 2016-12-03 00:11:50 --> No URI present. Default controller set.
INFO - 2016-12-03 00:11:50 --> Router Class Initialized
INFO - 2016-12-03 00:11:51 --> Output Class Initialized
INFO - 2016-12-03 00:11:51 --> Security Class Initialized
DEBUG - 2016-12-03 00:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 00:11:51 --> Input Class Initialized
INFO - 2016-12-03 00:11:51 --> Language Class Initialized
INFO - 2016-12-03 00:11:51 --> Loader Class Initialized
INFO - 2016-12-03 00:11:51 --> Helper loaded: url_helper
INFO - 2016-12-03 00:11:51 --> Helper loaded: form_helper
INFO - 2016-12-03 00:11:51 --> Database Driver Class Initialized
INFO - 2016-12-03 00:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 00:11:51 --> Controller Class Initialized
INFO - 2016-12-03 00:11:51 --> Model Class Initialized
INFO - 2016-12-03 00:11:51 --> Model Class Initialized
INFO - 2016-12-03 00:11:51 --> Model Class Initialized
INFO - 2016-12-03 00:11:51 --> Model Class Initialized
INFO - 2016-12-03 00:11:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 00:11:51 --> Pagination Class Initialized
INFO - 2016-12-03 00:11:51 --> Helper loaded: app_helper
INFO - 2016-12-03 00:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 00:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-03 00:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 00:11:51 --> Final output sent to browser
DEBUG - 2016-12-03 00:11:51 --> Total execution time: 0.3243
INFO - 2016-12-03 13:42:51 --> Config Class Initialized
INFO - 2016-12-03 13:42:51 --> Hooks Class Initialized
DEBUG - 2016-12-03 13:42:51 --> UTF-8 Support Enabled
INFO - 2016-12-03 13:42:51 --> Utf8 Class Initialized
INFO - 2016-12-03 13:42:51 --> Config Class Initialized
INFO - 2016-12-03 13:42:51 --> Hooks Class Initialized
DEBUG - 2016-12-03 13:42:51 --> UTF-8 Support Enabled
INFO - 2016-12-03 13:42:51 --> URI Class Initialized
INFO - 2016-12-03 13:42:51 --> Utf8 Class Initialized
INFO - 2016-12-03 13:42:51 --> URI Class Initialized
DEBUG - 2016-12-03 13:42:51 --> No URI present. Default controller set.
DEBUG - 2016-12-03 13:42:51 --> No URI present. Default controller set.
INFO - 2016-12-03 13:42:51 --> Router Class Initialized
INFO - 2016-12-03 13:42:51 --> Router Class Initialized
INFO - 2016-12-03 13:42:51 --> Output Class Initialized
INFO - 2016-12-03 13:42:51 --> Output Class Initialized
INFO - 2016-12-03 13:42:52 --> Security Class Initialized
INFO - 2016-12-03 13:42:52 --> Security Class Initialized
DEBUG - 2016-12-03 13:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-12-03 13:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 13:42:52 --> Input Class Initialized
INFO - 2016-12-03 13:42:52 --> Input Class Initialized
INFO - 2016-12-03 13:42:52 --> Language Class Initialized
INFO - 2016-12-03 13:42:52 --> Language Class Initialized
INFO - 2016-12-03 13:42:52 --> Loader Class Initialized
INFO - 2016-12-03 13:42:52 --> Loader Class Initialized
INFO - 2016-12-03 13:42:52 --> Helper loaded: url_helper
INFO - 2016-12-03 13:42:52 --> Helper loaded: url_helper
INFO - 2016-12-03 13:42:52 --> Helper loaded: form_helper
INFO - 2016-12-03 13:42:52 --> Helper loaded: form_helper
INFO - 2016-12-03 13:42:52 --> Database Driver Class Initialized
INFO - 2016-12-03 13:42:52 --> Database Driver Class Initialized
INFO - 2016-12-03 13:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 13:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 13:42:53 --> Controller Class Initialized
INFO - 2016-12-03 13:42:53 --> Controller Class Initialized
INFO - 2016-12-03 13:42:53 --> Model Class Initialized
INFO - 2016-12-03 13:42:53 --> Model Class Initialized
INFO - 2016-12-03 13:42:53 --> Model Class Initialized
INFO - 2016-12-03 13:42:53 --> Model Class Initialized
INFO - 2016-12-03 13:42:53 --> Model Class Initialized
INFO - 2016-12-03 13:42:53 --> Model Class Initialized
INFO - 2016-12-03 13:42:53 --> Model Class Initialized
INFO - 2016-12-03 13:42:53 --> Model Class Initialized
INFO - 2016-12-03 13:42:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 13:42:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 13:42:54 --> Pagination Class Initialized
INFO - 2016-12-03 13:42:54 --> Pagination Class Initialized
INFO - 2016-12-03 13:42:54 --> Helper loaded: app_helper
INFO - 2016-12-03 13:42:54 --> Helper loaded: app_helper
INFO - 2016-12-03 13:42:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 13:42:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 13:42:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-03 13:42:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-03 13:42:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 13:42:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 13:42:54 --> Final output sent to browser
INFO - 2016-12-03 13:42:54 --> Final output sent to browser
DEBUG - 2016-12-03 13:42:54 --> Total execution time: 3.7304
DEBUG - 2016-12-03 13:42:54 --> Total execution time: 3.0799
INFO - 2016-12-03 13:43:08 --> Config Class Initialized
INFO - 2016-12-03 13:43:08 --> Hooks Class Initialized
DEBUG - 2016-12-03 13:43:08 --> UTF-8 Support Enabled
INFO - 2016-12-03 13:43:08 --> Utf8 Class Initialized
INFO - 2016-12-03 13:43:08 --> URI Class Initialized
INFO - 2016-12-03 13:43:08 --> Router Class Initialized
INFO - 2016-12-03 13:43:08 --> Output Class Initialized
INFO - 2016-12-03 13:43:08 --> Security Class Initialized
DEBUG - 2016-12-03 13:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 13:43:08 --> Input Class Initialized
INFO - 2016-12-03 13:43:08 --> Language Class Initialized
INFO - 2016-12-03 13:43:08 --> Loader Class Initialized
INFO - 2016-12-03 13:43:08 --> Helper loaded: url_helper
INFO - 2016-12-03 13:43:08 --> Helper loaded: form_helper
INFO - 2016-12-03 13:43:08 --> Database Driver Class Initialized
INFO - 2016-12-03 13:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 13:43:08 --> Controller Class Initialized
INFO - 2016-12-03 13:43:08 --> Model Class Initialized
INFO - 2016-12-03 13:43:08 --> Model Class Initialized
INFO - 2016-12-03 13:43:08 --> Model Class Initialized
INFO - 2016-12-03 13:43:08 --> Model Class Initialized
INFO - 2016-12-03 13:43:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 13:43:08 --> Pagination Class Initialized
INFO - 2016-12-03 13:43:08 --> Helper loaded: app_helper
DEBUG - 2016-12-03 13:43:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 13:43:08 --> Model Class Initialized
INFO - 2016-12-03 13:43:08 --> Final output sent to browser
DEBUG - 2016-12-03 13:43:08 --> Total execution time: 0.4369
INFO - 2016-12-03 13:43:08 --> Config Class Initialized
INFO - 2016-12-03 13:43:08 --> Hooks Class Initialized
DEBUG - 2016-12-03 13:43:08 --> UTF-8 Support Enabled
INFO - 2016-12-03 13:43:08 --> Utf8 Class Initialized
INFO - 2016-12-03 13:43:08 --> URI Class Initialized
DEBUG - 2016-12-03 13:43:08 --> No URI present. Default controller set.
INFO - 2016-12-03 13:43:08 --> Router Class Initialized
INFO - 2016-12-03 13:43:08 --> Output Class Initialized
INFO - 2016-12-03 13:43:08 --> Security Class Initialized
DEBUG - 2016-12-03 13:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 13:43:08 --> Input Class Initialized
INFO - 2016-12-03 13:43:08 --> Language Class Initialized
INFO - 2016-12-03 13:43:08 --> Loader Class Initialized
INFO - 2016-12-03 13:43:08 --> Helper loaded: url_helper
INFO - 2016-12-03 13:43:08 --> Helper loaded: form_helper
INFO - 2016-12-03 13:43:08 --> Database Driver Class Initialized
INFO - 2016-12-03 13:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 13:43:08 --> Controller Class Initialized
INFO - 2016-12-03 13:43:08 --> Model Class Initialized
INFO - 2016-12-03 13:43:08 --> Model Class Initialized
INFO - 2016-12-03 13:43:08 --> Model Class Initialized
INFO - 2016-12-03 13:43:08 --> Model Class Initialized
INFO - 2016-12-03 13:43:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 13:43:08 --> Pagination Class Initialized
INFO - 2016-12-03 13:43:08 --> Helper loaded: app_helper
INFO - 2016-12-03 13:43:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 13:43:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-03 13:43:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-03 13:43:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-03 13:43:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-03 13:43:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-03 13:43:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-03 13:43:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 13:43:09 --> Final output sent to browser
DEBUG - 2016-12-03 13:43:09 --> Total execution time: 0.9735
INFO - 2016-12-03 13:44:01 --> Config Class Initialized
INFO - 2016-12-03 13:44:01 --> Hooks Class Initialized
DEBUG - 2016-12-03 13:44:01 --> UTF-8 Support Enabled
INFO - 2016-12-03 13:44:01 --> Utf8 Class Initialized
INFO - 2016-12-03 13:44:01 --> URI Class Initialized
DEBUG - 2016-12-03 13:44:01 --> No URI present. Default controller set.
INFO - 2016-12-03 13:44:01 --> Router Class Initialized
INFO - 2016-12-03 13:44:01 --> Output Class Initialized
INFO - 2016-12-03 13:44:01 --> Security Class Initialized
DEBUG - 2016-12-03 13:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 13:44:01 --> Input Class Initialized
INFO - 2016-12-03 13:44:01 --> Language Class Initialized
INFO - 2016-12-03 13:44:01 --> Loader Class Initialized
INFO - 2016-12-03 13:44:01 --> Helper loaded: url_helper
INFO - 2016-12-03 13:44:01 --> Helper loaded: form_helper
INFO - 2016-12-03 13:44:01 --> Database Driver Class Initialized
INFO - 2016-12-03 13:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 13:44:01 --> Controller Class Initialized
INFO - 2016-12-03 13:44:01 --> Model Class Initialized
INFO - 2016-12-03 13:44:01 --> Model Class Initialized
INFO - 2016-12-03 13:44:01 --> Model Class Initialized
INFO - 2016-12-03 13:44:01 --> Model Class Initialized
INFO - 2016-12-03 13:44:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 13:44:01 --> Pagination Class Initialized
INFO - 2016-12-03 13:44:01 --> Helper loaded: app_helper
INFO - 2016-12-03 13:44:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 13:44:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-03 13:44:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-03 13:44:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-03 13:44:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-03 13:44:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-03 13:44:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-03 13:44:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 13:44:01 --> Final output sent to browser
DEBUG - 2016-12-03 13:44:01 --> Total execution time: 0.3611
INFO - 2016-12-03 15:32:54 --> Config Class Initialized
INFO - 2016-12-03 15:32:54 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:32:55 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:32:55 --> Utf8 Class Initialized
INFO - 2016-12-03 15:32:55 --> URI Class Initialized
DEBUG - 2016-12-03 15:32:55 --> No URI present. Default controller set.
INFO - 2016-12-03 15:32:55 --> Router Class Initialized
INFO - 2016-12-03 15:32:55 --> Output Class Initialized
INFO - 2016-12-03 15:32:56 --> Security Class Initialized
DEBUG - 2016-12-03 15:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:32:56 --> Input Class Initialized
INFO - 2016-12-03 15:32:56 --> Language Class Initialized
INFO - 2016-12-03 15:32:56 --> Loader Class Initialized
INFO - 2016-12-03 15:32:56 --> Helper loaded: url_helper
INFO - 2016-12-03 15:32:56 --> Helper loaded: form_helper
INFO - 2016-12-03 15:32:57 --> Database Driver Class Initialized
INFO - 2016-12-03 15:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:32:58 --> Controller Class Initialized
INFO - 2016-12-03 15:32:58 --> Model Class Initialized
INFO - 2016-12-03 15:32:58 --> Model Class Initialized
INFO - 2016-12-03 15:32:58 --> Model Class Initialized
INFO - 2016-12-03 15:32:58 --> Model Class Initialized
INFO - 2016-12-03 15:32:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 15:32:59 --> Pagination Class Initialized
INFO - 2016-12-03 15:32:59 --> Helper loaded: app_helper
INFO - 2016-12-03 15:32:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 15:32:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-03 15:32:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-03 15:32:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-03 15:33:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-03 15:33:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-03 15:33:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-03 15:33:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 15:33:00 --> Final output sent to browser
DEBUG - 2016-12-03 15:33:00 --> Total execution time: 5.8881
INFO - 2016-12-03 15:46:03 --> Config Class Initialized
INFO - 2016-12-03 15:46:03 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:46:03 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:46:03 --> Utf8 Class Initialized
INFO - 2016-12-03 15:46:03 --> URI Class Initialized
DEBUG - 2016-12-03 15:46:03 --> No URI present. Default controller set.
INFO - 2016-12-03 15:46:03 --> Router Class Initialized
INFO - 2016-12-03 15:46:03 --> Output Class Initialized
INFO - 2016-12-03 15:46:03 --> Security Class Initialized
DEBUG - 2016-12-03 15:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:46:03 --> Input Class Initialized
INFO - 2016-12-03 15:46:03 --> Language Class Initialized
INFO - 2016-12-03 15:46:03 --> Loader Class Initialized
INFO - 2016-12-03 15:46:03 --> Helper loaded: url_helper
INFO - 2016-12-03 15:46:03 --> Helper loaded: form_helper
INFO - 2016-12-03 15:46:04 --> Database Driver Class Initialized
INFO - 2016-12-03 15:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:46:04 --> Controller Class Initialized
INFO - 2016-12-03 15:46:04 --> Model Class Initialized
INFO - 2016-12-03 15:46:04 --> Model Class Initialized
INFO - 2016-12-03 15:46:04 --> Model Class Initialized
INFO - 2016-12-03 15:46:04 --> Model Class Initialized
INFO - 2016-12-03 15:46:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 15:46:04 --> Pagination Class Initialized
INFO - 2016-12-03 15:46:04 --> Helper loaded: app_helper
INFO - 2016-12-03 15:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 15:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-03 15:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-03 15:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-03 15:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-03 15:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-03 15:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-03 15:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 15:46:04 --> Final output sent to browser
DEBUG - 2016-12-03 15:46:04 --> Total execution time: 0.4424
INFO - 2016-12-03 15:46:05 --> Config Class Initialized
INFO - 2016-12-03 15:46:05 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:46:05 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:46:05 --> Utf8 Class Initialized
INFO - 2016-12-03 15:46:05 --> URI Class Initialized
INFO - 2016-12-03 15:46:05 --> Router Class Initialized
INFO - 2016-12-03 15:46:05 --> Output Class Initialized
INFO - 2016-12-03 15:46:05 --> Security Class Initialized
DEBUG - 2016-12-03 15:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:46:05 --> Input Class Initialized
INFO - 2016-12-03 15:46:05 --> Language Class Initialized
INFO - 2016-12-03 15:46:05 --> Loader Class Initialized
INFO - 2016-12-03 15:46:05 --> Helper loaded: url_helper
INFO - 2016-12-03 15:46:05 --> Helper loaded: form_helper
INFO - 2016-12-03 15:46:05 --> Database Driver Class Initialized
INFO - 2016-12-03 15:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:46:05 --> Controller Class Initialized
INFO - 2016-12-03 15:46:06 --> Model Class Initialized
INFO - 2016-12-03 15:46:06 --> Model Class Initialized
INFO - 2016-12-03 15:46:06 --> Model Class Initialized
INFO - 2016-12-03 15:46:06 --> Model Class Initialized
INFO - 2016-12-03 15:46:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 15:46:06 --> Pagination Class Initialized
INFO - 2016-12-03 15:46:06 --> Helper loaded: app_helper
DEBUG - 2016-12-03 15:46:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-12-03 15:46:06 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-12-03 15:46:06 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-12-03 15:46:06 --> Config Class Initialized
INFO - 2016-12-03 15:46:06 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:46:06 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:46:06 --> Utf8 Class Initialized
INFO - 2016-12-03 15:46:06 --> URI Class Initialized
DEBUG - 2016-12-03 15:46:06 --> No URI present. Default controller set.
INFO - 2016-12-03 15:46:06 --> Router Class Initialized
INFO - 2016-12-03 15:46:06 --> Output Class Initialized
INFO - 2016-12-03 15:46:06 --> Security Class Initialized
DEBUG - 2016-12-03 15:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:46:06 --> Input Class Initialized
INFO - 2016-12-03 15:46:06 --> Language Class Initialized
INFO - 2016-12-03 15:46:06 --> Loader Class Initialized
INFO - 2016-12-03 15:46:06 --> Helper loaded: url_helper
INFO - 2016-12-03 15:46:06 --> Helper loaded: form_helper
INFO - 2016-12-03 15:46:06 --> Database Driver Class Initialized
INFO - 2016-12-03 15:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:46:06 --> Controller Class Initialized
INFO - 2016-12-03 15:46:06 --> Model Class Initialized
INFO - 2016-12-03 15:46:06 --> Model Class Initialized
INFO - 2016-12-03 15:46:06 --> Model Class Initialized
INFO - 2016-12-03 15:46:06 --> Model Class Initialized
INFO - 2016-12-03 15:46:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 15:46:06 --> Pagination Class Initialized
INFO - 2016-12-03 15:46:06 --> Helper loaded: app_helper
INFO - 2016-12-03 15:46:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 15:46:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-03 15:46:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 15:46:06 --> Final output sent to browser
DEBUG - 2016-12-03 15:46:06 --> Total execution time: 0.3124
INFO - 2016-12-03 15:46:14 --> Config Class Initialized
INFO - 2016-12-03 15:46:14 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:46:14 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:46:14 --> Utf8 Class Initialized
INFO - 2016-12-03 15:46:14 --> URI Class Initialized
INFO - 2016-12-03 15:46:15 --> Router Class Initialized
INFO - 2016-12-03 15:46:15 --> Output Class Initialized
INFO - 2016-12-03 15:46:15 --> Security Class Initialized
DEBUG - 2016-12-03 15:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:46:15 --> Input Class Initialized
INFO - 2016-12-03 15:46:15 --> Language Class Initialized
INFO - 2016-12-03 15:46:15 --> Loader Class Initialized
INFO - 2016-12-03 15:46:15 --> Helper loaded: url_helper
INFO - 2016-12-03 15:46:15 --> Helper loaded: form_helper
INFO - 2016-12-03 15:46:15 --> Database Driver Class Initialized
INFO - 2016-12-03 15:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:46:15 --> Controller Class Initialized
INFO - 2016-12-03 15:46:15 --> Model Class Initialized
INFO - 2016-12-03 15:46:15 --> Model Class Initialized
INFO - 2016-12-03 15:46:15 --> Model Class Initialized
INFO - 2016-12-03 15:46:15 --> Model Class Initialized
INFO - 2016-12-03 15:46:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 15:46:15 --> Pagination Class Initialized
INFO - 2016-12-03 15:46:15 --> Helper loaded: app_helper
DEBUG - 2016-12-03 15:46:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 15:46:15 --> Model Class Initialized
INFO - 2016-12-03 15:46:15 --> Final output sent to browser
DEBUG - 2016-12-03 15:46:15 --> Total execution time: 0.2316
INFO - 2016-12-03 15:46:15 --> Config Class Initialized
INFO - 2016-12-03 15:46:15 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:46:15 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:46:15 --> Utf8 Class Initialized
INFO - 2016-12-03 15:46:15 --> URI Class Initialized
DEBUG - 2016-12-03 15:46:15 --> No URI present. Default controller set.
INFO - 2016-12-03 15:46:15 --> Router Class Initialized
INFO - 2016-12-03 15:46:15 --> Output Class Initialized
INFO - 2016-12-03 15:46:15 --> Security Class Initialized
DEBUG - 2016-12-03 15:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:46:15 --> Input Class Initialized
INFO - 2016-12-03 15:46:15 --> Language Class Initialized
INFO - 2016-12-03 15:46:15 --> Loader Class Initialized
INFO - 2016-12-03 15:46:15 --> Helper loaded: url_helper
INFO - 2016-12-03 15:46:15 --> Helper loaded: form_helper
INFO - 2016-12-03 15:46:15 --> Database Driver Class Initialized
INFO - 2016-12-03 15:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:46:15 --> Controller Class Initialized
INFO - 2016-12-03 15:46:15 --> Model Class Initialized
INFO - 2016-12-03 15:46:15 --> Model Class Initialized
INFO - 2016-12-03 15:46:15 --> Model Class Initialized
INFO - 2016-12-03 15:46:15 --> Model Class Initialized
INFO - 2016-12-03 15:46:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 15:46:15 --> Pagination Class Initialized
INFO - 2016-12-03 15:46:15 --> Helper loaded: app_helper
INFO - 2016-12-03 15:46:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 15:46:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-03 15:46:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-03 15:46:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-12-03 15:46:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-12-03 15:46:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-12-03 15:46:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-12-03 15:46:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-12-03 15:46:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-12-03 15:46:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-03 15:46:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 15:46:15 --> Final output sent to browser
DEBUG - 2016-12-03 15:46:15 --> Total execution time: 0.3585
INFO - 2016-12-03 15:55:56 --> Config Class Initialized
INFO - 2016-12-03 15:55:56 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:55:56 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:55:56 --> Utf8 Class Initialized
INFO - 2016-12-03 15:55:56 --> URI Class Initialized
DEBUG - 2016-12-03 15:55:56 --> No URI present. Default controller set.
INFO - 2016-12-03 15:55:56 --> Router Class Initialized
INFO - 2016-12-03 15:55:56 --> Output Class Initialized
INFO - 2016-12-03 15:55:56 --> Security Class Initialized
DEBUG - 2016-12-03 15:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:55:56 --> Input Class Initialized
INFO - 2016-12-03 15:55:56 --> Language Class Initialized
INFO - 2016-12-03 15:55:56 --> Loader Class Initialized
INFO - 2016-12-03 15:55:56 --> Helper loaded: url_helper
INFO - 2016-12-03 15:55:56 --> Helper loaded: form_helper
INFO - 2016-12-03 15:55:56 --> Database Driver Class Initialized
INFO - 2016-12-03 15:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:55:56 --> Controller Class Initialized
INFO - 2016-12-03 15:55:56 --> Model Class Initialized
INFO - 2016-12-03 15:55:56 --> Model Class Initialized
INFO - 2016-12-03 15:55:56 --> Model Class Initialized
INFO - 2016-12-03 15:55:56 --> Model Class Initialized
INFO - 2016-12-03 15:55:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 15:55:56 --> Pagination Class Initialized
INFO - 2016-12-03 15:55:56 --> Helper loaded: app_helper
INFO - 2016-12-03 15:55:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 15:55:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-03 15:55:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-03 15:55:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-12-03 15:55:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-12-03 15:55:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-12-03 15:55:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-12-03 15:55:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-12-03 15:55:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-12-03 15:55:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-03 15:55:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 15:55:56 --> Final output sent to browser
DEBUG - 2016-12-03 15:55:56 --> Total execution time: 0.3696
INFO - 2016-12-03 15:56:38 --> Config Class Initialized
INFO - 2016-12-03 15:56:38 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:56:38 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:56:38 --> Utf8 Class Initialized
INFO - 2016-12-03 15:56:38 --> URI Class Initialized
DEBUG - 2016-12-03 15:56:38 --> No URI present. Default controller set.
INFO - 2016-12-03 15:56:38 --> Router Class Initialized
INFO - 2016-12-03 15:56:38 --> Output Class Initialized
INFO - 2016-12-03 15:56:38 --> Security Class Initialized
DEBUG - 2016-12-03 15:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:56:38 --> Input Class Initialized
INFO - 2016-12-03 15:56:38 --> Language Class Initialized
INFO - 2016-12-03 15:56:38 --> Loader Class Initialized
INFO - 2016-12-03 15:56:38 --> Helper loaded: url_helper
INFO - 2016-12-03 15:56:38 --> Helper loaded: form_helper
INFO - 2016-12-03 15:56:38 --> Database Driver Class Initialized
INFO - 2016-12-03 15:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:56:38 --> Controller Class Initialized
INFO - 2016-12-03 15:56:38 --> Model Class Initialized
INFO - 2016-12-03 15:56:38 --> Model Class Initialized
INFO - 2016-12-03 15:56:38 --> Model Class Initialized
INFO - 2016-12-03 15:56:38 --> Model Class Initialized
INFO - 2016-12-03 15:56:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 15:56:38 --> Pagination Class Initialized
INFO - 2016-12-03 15:56:38 --> Helper loaded: app_helper
INFO - 2016-12-03 15:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 15:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-03 15:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-03 15:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-12-03 15:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-12-03 15:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-12-03 15:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-12-03 15:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-12-03 15:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-12-03 15:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-03 15:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 15:56:38 --> Final output sent to browser
DEBUG - 2016-12-03 15:56:38 --> Total execution time: 0.3756
INFO - 2016-12-03 16:01:54 --> Config Class Initialized
INFO - 2016-12-03 16:01:54 --> Hooks Class Initialized
DEBUG - 2016-12-03 16:01:54 --> UTF-8 Support Enabled
INFO - 2016-12-03 16:01:54 --> Utf8 Class Initialized
INFO - 2016-12-03 16:01:54 --> URI Class Initialized
DEBUG - 2016-12-03 16:01:54 --> No URI present. Default controller set.
INFO - 2016-12-03 16:01:54 --> Router Class Initialized
INFO - 2016-12-03 16:01:54 --> Output Class Initialized
INFO - 2016-12-03 16:01:54 --> Security Class Initialized
DEBUG - 2016-12-03 16:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 16:01:54 --> Input Class Initialized
INFO - 2016-12-03 16:01:54 --> Language Class Initialized
INFO - 2016-12-03 16:01:54 --> Loader Class Initialized
INFO - 2016-12-03 16:01:54 --> Helper loaded: url_helper
INFO - 2016-12-03 16:01:54 --> Helper loaded: form_helper
INFO - 2016-12-03 16:01:54 --> Database Driver Class Initialized
INFO - 2016-12-03 16:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 16:01:54 --> Controller Class Initialized
INFO - 2016-12-03 16:01:54 --> Model Class Initialized
INFO - 2016-12-03 16:01:54 --> Model Class Initialized
INFO - 2016-12-03 16:01:54 --> Model Class Initialized
INFO - 2016-12-03 16:01:54 --> Model Class Initialized
INFO - 2016-12-03 16:01:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 16:01:54 --> Pagination Class Initialized
INFO - 2016-12-03 16:01:54 --> Helper loaded: app_helper
INFO - 2016-12-03 16:01:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 16:01:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-03 16:01:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-03 16:01:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-12-03 16:01:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-12-03 16:01:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-12-03 16:01:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-12-03 16:01:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-12-03 16:01:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-12-03 16:01:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-03 16:01:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 16:01:54 --> Final output sent to browser
DEBUG - 2016-12-03 16:01:54 --> Total execution time: 0.3851
INFO - 2016-12-03 16:01:55 --> Config Class Initialized
INFO - 2016-12-03 16:01:55 --> Hooks Class Initialized
DEBUG - 2016-12-03 16:01:55 --> UTF-8 Support Enabled
INFO - 2016-12-03 16:01:55 --> Utf8 Class Initialized
INFO - 2016-12-03 16:01:55 --> URI Class Initialized
INFO - 2016-12-03 16:01:55 --> Router Class Initialized
INFO - 2016-12-03 16:01:55 --> Output Class Initialized
INFO - 2016-12-03 16:01:55 --> Security Class Initialized
DEBUG - 2016-12-03 16:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 16:01:55 --> Input Class Initialized
INFO - 2016-12-03 16:01:55 --> Language Class Initialized
INFO - 2016-12-03 16:01:55 --> Loader Class Initialized
INFO - 2016-12-03 16:01:55 --> Helper loaded: url_helper
INFO - 2016-12-03 16:01:55 --> Helper loaded: form_helper
INFO - 2016-12-03 16:01:55 --> Database Driver Class Initialized
INFO - 2016-12-03 16:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 16:01:56 --> Controller Class Initialized
INFO - 2016-12-03 16:01:56 --> Model Class Initialized
INFO - 2016-12-03 16:01:56 --> Model Class Initialized
INFO - 2016-12-03 16:01:56 --> Model Class Initialized
INFO - 2016-12-03 16:01:56 --> Model Class Initialized
INFO - 2016-12-03 16:01:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 16:01:56 --> Pagination Class Initialized
INFO - 2016-12-03 16:01:56 --> Helper loaded: app_helper
DEBUG - 2016-12-03 16:01:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-12-03 16:01:56 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-12-03 16:01:56 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-12-03 16:01:56 --> Config Class Initialized
INFO - 2016-12-03 16:01:56 --> Hooks Class Initialized
DEBUG - 2016-12-03 16:01:56 --> UTF-8 Support Enabled
INFO - 2016-12-03 16:01:56 --> Utf8 Class Initialized
INFO - 2016-12-03 16:01:56 --> URI Class Initialized
DEBUG - 2016-12-03 16:01:56 --> No URI present. Default controller set.
INFO - 2016-12-03 16:01:56 --> Router Class Initialized
INFO - 2016-12-03 16:01:56 --> Output Class Initialized
INFO - 2016-12-03 16:01:56 --> Security Class Initialized
DEBUG - 2016-12-03 16:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 16:01:56 --> Input Class Initialized
INFO - 2016-12-03 16:01:56 --> Language Class Initialized
INFO - 2016-12-03 16:01:56 --> Loader Class Initialized
INFO - 2016-12-03 16:01:56 --> Helper loaded: url_helper
INFO - 2016-12-03 16:01:56 --> Helper loaded: form_helper
INFO - 2016-12-03 16:01:56 --> Database Driver Class Initialized
INFO - 2016-12-03 16:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 16:01:56 --> Controller Class Initialized
INFO - 2016-12-03 16:01:56 --> Model Class Initialized
INFO - 2016-12-03 16:01:56 --> Model Class Initialized
INFO - 2016-12-03 16:01:56 --> Model Class Initialized
INFO - 2016-12-03 16:01:56 --> Model Class Initialized
INFO - 2016-12-03 16:01:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 16:01:56 --> Pagination Class Initialized
INFO - 2016-12-03 16:01:56 --> Helper loaded: app_helper
INFO - 2016-12-03 16:01:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 16:01:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-03 16:01:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 16:01:56 --> Final output sent to browser
DEBUG - 2016-12-03 16:01:56 --> Total execution time: 0.3104
INFO - 2016-12-03 16:07:35 --> Config Class Initialized
INFO - 2016-12-03 16:07:35 --> Hooks Class Initialized
DEBUG - 2016-12-03 16:07:35 --> UTF-8 Support Enabled
INFO - 2016-12-03 16:07:35 --> Utf8 Class Initialized
INFO - 2016-12-03 16:07:35 --> URI Class Initialized
DEBUG - 2016-12-03 16:07:35 --> No URI present. Default controller set.
INFO - 2016-12-03 16:07:35 --> Router Class Initialized
INFO - 2016-12-03 16:07:35 --> Output Class Initialized
INFO - 2016-12-03 16:07:35 --> Security Class Initialized
DEBUG - 2016-12-03 16:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 16:07:35 --> Input Class Initialized
INFO - 2016-12-03 16:07:35 --> Language Class Initialized
INFO - 2016-12-03 16:07:35 --> Loader Class Initialized
INFO - 2016-12-03 16:07:35 --> Helper loaded: url_helper
INFO - 2016-12-03 16:07:35 --> Helper loaded: form_helper
INFO - 2016-12-03 16:07:35 --> Database Driver Class Initialized
INFO - 2016-12-03 16:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 16:07:35 --> Controller Class Initialized
INFO - 2016-12-03 16:07:35 --> Model Class Initialized
INFO - 2016-12-03 16:07:35 --> Model Class Initialized
INFO - 2016-12-03 16:07:35 --> Model Class Initialized
INFO - 2016-12-03 16:07:35 --> Model Class Initialized
INFO - 2016-12-03 16:07:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 16:07:35 --> Pagination Class Initialized
INFO - 2016-12-03 16:07:35 --> Helper loaded: app_helper
INFO - 2016-12-03 16:07:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 16:07:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-03 16:07:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 16:07:35 --> Final output sent to browser
DEBUG - 2016-12-03 16:07:35 --> Total execution time: 0.3339
INFO - 2016-12-03 16:07:44 --> Config Class Initialized
INFO - 2016-12-03 16:07:44 --> Hooks Class Initialized
DEBUG - 2016-12-03 16:07:44 --> UTF-8 Support Enabled
INFO - 2016-12-03 16:07:44 --> Utf8 Class Initialized
INFO - 2016-12-03 16:07:44 --> URI Class Initialized
INFO - 2016-12-03 16:07:44 --> Router Class Initialized
INFO - 2016-12-03 16:07:44 --> Output Class Initialized
INFO - 2016-12-03 16:07:44 --> Security Class Initialized
DEBUG - 2016-12-03 16:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 16:07:44 --> Input Class Initialized
INFO - 2016-12-03 16:07:44 --> Language Class Initialized
INFO - 2016-12-03 16:07:44 --> Loader Class Initialized
INFO - 2016-12-03 16:07:44 --> Helper loaded: url_helper
INFO - 2016-12-03 16:07:44 --> Helper loaded: form_helper
INFO - 2016-12-03 16:07:44 --> Database Driver Class Initialized
INFO - 2016-12-03 16:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 16:07:44 --> Controller Class Initialized
INFO - 2016-12-03 16:07:44 --> Model Class Initialized
INFO - 2016-12-03 16:07:44 --> Model Class Initialized
INFO - 2016-12-03 16:07:44 --> Model Class Initialized
INFO - 2016-12-03 16:07:44 --> Model Class Initialized
INFO - 2016-12-03 16:07:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 16:07:44 --> Pagination Class Initialized
INFO - 2016-12-03 16:07:44 --> Helper loaded: app_helper
DEBUG - 2016-12-03 16:07:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 16:07:44 --> Model Class Initialized
INFO - 2016-12-03 16:07:44 --> Final output sent to browser
DEBUG - 2016-12-03 16:07:44 --> Total execution time: 0.2430
INFO - 2016-12-03 16:07:44 --> Config Class Initialized
INFO - 2016-12-03 16:07:44 --> Hooks Class Initialized
DEBUG - 2016-12-03 16:07:44 --> UTF-8 Support Enabled
INFO - 2016-12-03 16:07:44 --> Utf8 Class Initialized
INFO - 2016-12-03 16:07:44 --> URI Class Initialized
DEBUG - 2016-12-03 16:07:44 --> No URI present. Default controller set.
INFO - 2016-12-03 16:07:44 --> Router Class Initialized
INFO - 2016-12-03 16:07:44 --> Output Class Initialized
INFO - 2016-12-03 16:07:44 --> Security Class Initialized
DEBUG - 2016-12-03 16:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 16:07:44 --> Input Class Initialized
INFO - 2016-12-03 16:07:44 --> Language Class Initialized
INFO - 2016-12-03 16:07:44 --> Loader Class Initialized
INFO - 2016-12-03 16:07:44 --> Helper loaded: url_helper
INFO - 2016-12-03 16:07:44 --> Helper loaded: form_helper
INFO - 2016-12-03 16:07:44 --> Database Driver Class Initialized
INFO - 2016-12-03 16:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 16:07:44 --> Controller Class Initialized
INFO - 2016-12-03 16:07:44 --> Model Class Initialized
INFO - 2016-12-03 16:07:44 --> Model Class Initialized
INFO - 2016-12-03 16:07:44 --> Model Class Initialized
INFO - 2016-12-03 16:07:44 --> Model Class Initialized
INFO - 2016-12-03 16:07:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 16:07:44 --> Pagination Class Initialized
INFO - 2016-12-03 16:07:44 --> Helper loaded: app_helper
INFO - 2016-12-03 16:07:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 16:07:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-03 16:07:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-03 16:07:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-03 16:07:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-03 16:07:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-03 16:07:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-03 16:07:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-03 16:07:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 16:07:45 --> Final output sent to browser
DEBUG - 2016-12-03 16:07:45 --> Total execution time: 0.3407
INFO - 2016-12-03 16:15:15 --> Config Class Initialized
INFO - 2016-12-03 16:15:15 --> Hooks Class Initialized
DEBUG - 2016-12-03 16:15:15 --> UTF-8 Support Enabled
INFO - 2016-12-03 16:15:15 --> Utf8 Class Initialized
INFO - 2016-12-03 16:15:15 --> URI Class Initialized
DEBUG - 2016-12-03 16:15:15 --> No URI present. Default controller set.
INFO - 2016-12-03 16:15:15 --> Router Class Initialized
INFO - 2016-12-03 16:15:15 --> Output Class Initialized
INFO - 2016-12-03 16:15:15 --> Security Class Initialized
DEBUG - 2016-12-03 16:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 16:15:15 --> Input Class Initialized
INFO - 2016-12-03 16:15:15 --> Language Class Initialized
INFO - 2016-12-03 16:15:15 --> Loader Class Initialized
INFO - 2016-12-03 16:15:15 --> Helper loaded: url_helper
INFO - 2016-12-03 16:15:15 --> Helper loaded: form_helper
INFO - 2016-12-03 16:15:15 --> Database Driver Class Initialized
INFO - 2016-12-03 16:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 16:15:16 --> Controller Class Initialized
INFO - 2016-12-03 16:15:16 --> Model Class Initialized
INFO - 2016-12-03 16:15:16 --> Model Class Initialized
INFO - 2016-12-03 16:15:16 --> Model Class Initialized
INFO - 2016-12-03 16:15:16 --> Model Class Initialized
INFO - 2016-12-03 16:15:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 16:15:16 --> Pagination Class Initialized
INFO - 2016-12-03 16:15:16 --> Helper loaded: app_helper
INFO - 2016-12-03 16:15:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 16:15:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-03 16:15:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-03 16:15:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-03 16:15:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-03 16:15:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-03 16:15:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-03 16:15:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-03 16:15:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 16:15:16 --> Final output sent to browser
DEBUG - 2016-12-03 16:15:16 --> Total execution time: 0.3861
INFO - 2016-12-03 16:15:59 --> Config Class Initialized
INFO - 2016-12-03 16:15:59 --> Hooks Class Initialized
DEBUG - 2016-12-03 16:15:59 --> UTF-8 Support Enabled
INFO - 2016-12-03 16:15:59 --> Utf8 Class Initialized
INFO - 2016-12-03 16:15:59 --> URI Class Initialized
DEBUG - 2016-12-03 16:15:59 --> No URI present. Default controller set.
INFO - 2016-12-03 16:15:59 --> Router Class Initialized
INFO - 2016-12-03 16:15:59 --> Output Class Initialized
INFO - 2016-12-03 16:15:59 --> Security Class Initialized
DEBUG - 2016-12-03 16:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 16:15:59 --> Input Class Initialized
INFO - 2016-12-03 16:16:00 --> Language Class Initialized
INFO - 2016-12-03 16:16:00 --> Loader Class Initialized
INFO - 2016-12-03 16:16:00 --> Helper loaded: url_helper
INFO - 2016-12-03 16:16:00 --> Helper loaded: form_helper
INFO - 2016-12-03 16:16:00 --> Database Driver Class Initialized
INFO - 2016-12-03 16:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 16:16:00 --> Controller Class Initialized
INFO - 2016-12-03 16:16:00 --> Model Class Initialized
INFO - 2016-12-03 16:16:00 --> Model Class Initialized
INFO - 2016-12-03 16:16:00 --> Model Class Initialized
INFO - 2016-12-03 16:16:00 --> Model Class Initialized
INFO - 2016-12-03 16:16:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 16:16:00 --> Pagination Class Initialized
INFO - 2016-12-03 16:16:00 --> Helper loaded: app_helper
INFO - 2016-12-03 16:16:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 16:16:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-03 16:16:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-03 16:16:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-03 16:16:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-03 16:16:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-03 16:16:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-03 16:16:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-03 16:16:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 16:16:00 --> Final output sent to browser
DEBUG - 2016-12-03 16:16:00 --> Total execution time: 0.3991
INFO - 2016-12-03 16:31:21 --> Config Class Initialized
INFO - 2016-12-03 16:31:21 --> Hooks Class Initialized
DEBUG - 2016-12-03 16:31:21 --> UTF-8 Support Enabled
INFO - 2016-12-03 16:31:21 --> Utf8 Class Initialized
INFO - 2016-12-03 16:31:21 --> URI Class Initialized
INFO - 2016-12-03 16:31:21 --> Router Class Initialized
INFO - 2016-12-03 16:31:21 --> Output Class Initialized
INFO - 2016-12-03 16:31:21 --> Security Class Initialized
DEBUG - 2016-12-03 16:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 16:31:21 --> Input Class Initialized
INFO - 2016-12-03 16:31:21 --> Language Class Initialized
INFO - 2016-12-03 16:31:21 --> Loader Class Initialized
INFO - 2016-12-03 16:31:21 --> Helper loaded: url_helper
INFO - 2016-12-03 16:31:21 --> Helper loaded: form_helper
INFO - 2016-12-03 16:31:21 --> Database Driver Class Initialized
INFO - 2016-12-03 16:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 16:31:21 --> Controller Class Initialized
INFO - 2016-12-03 16:31:21 --> Model Class Initialized
INFO - 2016-12-03 16:31:21 --> Form Validation Class Initialized
INFO - 2016-12-03 16:31:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 16:31:21 --> Pagination Class Initialized
INFO - 2016-12-03 16:31:21 --> Helper loaded: app_helper
INFO - 2016-12-03 16:31:21 --> Email Class Initialized
INFO - 2016-12-03 16:31:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-03 15:31:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-03 15:31:22 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-03 15:31:22 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-03 15:31:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-03 15:31:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-03 15:31:26 --> Final output sent to browser
DEBUG - 2016-12-03 15:31:26 --> Total execution time: 4.7114
INFO - 2016-12-03 16:32:09 --> Config Class Initialized
INFO - 2016-12-03 16:32:09 --> Hooks Class Initialized
DEBUG - 2016-12-03 16:32:09 --> UTF-8 Support Enabled
INFO - 2016-12-03 16:32:09 --> Utf8 Class Initialized
INFO - 2016-12-03 16:32:09 --> URI Class Initialized
INFO - 2016-12-03 16:32:09 --> Router Class Initialized
INFO - 2016-12-03 16:32:09 --> Output Class Initialized
INFO - 2016-12-03 16:32:09 --> Security Class Initialized
DEBUG - 2016-12-03 16:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 16:32:09 --> Input Class Initialized
INFO - 2016-12-03 16:32:09 --> Language Class Initialized
INFO - 2016-12-03 16:32:09 --> Loader Class Initialized
INFO - 2016-12-03 16:32:09 --> Helper loaded: url_helper
INFO - 2016-12-03 16:32:09 --> Helper loaded: form_helper
INFO - 2016-12-03 16:32:09 --> Database Driver Class Initialized
INFO - 2016-12-03 16:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 16:32:09 --> Controller Class Initialized
INFO - 2016-12-03 16:32:09 --> Model Class Initialized
INFO - 2016-12-03 16:32:09 --> Form Validation Class Initialized
INFO - 2016-12-03 16:32:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 16:32:09 --> Pagination Class Initialized
INFO - 2016-12-03 16:32:09 --> Helper loaded: app_helper
INFO - 2016-12-03 16:32:09 --> Email Class Initialized
INFO - 2016-12-03 16:32:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 16:32:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-03 16:32:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 16:32:09 --> Final output sent to browser
DEBUG - 2016-12-03 16:32:09 --> Total execution time: 0.3090
INFO - 2016-12-03 16:32:20 --> Config Class Initialized
INFO - 2016-12-03 16:32:20 --> Hooks Class Initialized
DEBUG - 2016-12-03 16:32:20 --> UTF-8 Support Enabled
INFO - 2016-12-03 16:32:21 --> Utf8 Class Initialized
INFO - 2016-12-03 16:32:21 --> URI Class Initialized
INFO - 2016-12-03 16:32:21 --> Router Class Initialized
INFO - 2016-12-03 16:32:21 --> Output Class Initialized
INFO - 2016-12-03 16:32:21 --> Security Class Initialized
DEBUG - 2016-12-03 16:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 16:32:21 --> Input Class Initialized
INFO - 2016-12-03 16:32:21 --> Language Class Initialized
INFO - 2016-12-03 16:32:21 --> Loader Class Initialized
INFO - 2016-12-03 16:32:21 --> Helper loaded: url_helper
INFO - 2016-12-03 16:32:21 --> Helper loaded: form_helper
INFO - 2016-12-03 16:32:21 --> Database Driver Class Initialized
INFO - 2016-12-03 16:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 16:32:21 --> Controller Class Initialized
INFO - 2016-12-03 16:32:21 --> Model Class Initialized
INFO - 2016-12-03 16:32:21 --> Form Validation Class Initialized
INFO - 2016-12-03 16:32:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 16:32:21 --> Pagination Class Initialized
INFO - 2016-12-03 16:32:21 --> Helper loaded: app_helper
INFO - 2016-12-03 16:32:21 --> Email Class Initialized
INFO - 2016-12-03 16:32:21 --> Final output sent to browser
DEBUG - 2016-12-03 16:32:21 --> Total execution time: 0.2417
INFO - 2016-12-03 16:32:33 --> Config Class Initialized
INFO - 2016-12-03 16:32:33 --> Hooks Class Initialized
DEBUG - 2016-12-03 16:32:33 --> UTF-8 Support Enabled
INFO - 2016-12-03 16:32:33 --> Utf8 Class Initialized
INFO - 2016-12-03 16:32:33 --> URI Class Initialized
INFO - 2016-12-03 16:32:33 --> Router Class Initialized
INFO - 2016-12-03 16:32:33 --> Output Class Initialized
INFO - 2016-12-03 16:32:34 --> Security Class Initialized
DEBUG - 2016-12-03 16:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 16:32:34 --> Input Class Initialized
INFO - 2016-12-03 16:32:34 --> Language Class Initialized
INFO - 2016-12-03 16:32:34 --> Loader Class Initialized
INFO - 2016-12-03 16:32:34 --> Helper loaded: url_helper
INFO - 2016-12-03 16:32:34 --> Helper loaded: form_helper
INFO - 2016-12-03 16:32:34 --> Database Driver Class Initialized
INFO - 2016-12-03 16:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 16:32:34 --> Controller Class Initialized
INFO - 2016-12-03 16:32:34 --> Model Class Initialized
INFO - 2016-12-03 16:32:34 --> Form Validation Class Initialized
INFO - 2016-12-03 16:32:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 16:32:34 --> Pagination Class Initialized
INFO - 2016-12-03 16:32:34 --> Helper loaded: app_helper
INFO - 2016-12-03 16:32:34 --> Email Class Initialized
INFO - 2016-12-03 16:32:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 16:32:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-03 16:32:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 16:32:34 --> Final output sent to browser
DEBUG - 2016-12-03 16:32:34 --> Total execution time: 0.3042
INFO - 2016-12-03 16:33:16 --> Config Class Initialized
INFO - 2016-12-03 16:33:16 --> Hooks Class Initialized
DEBUG - 2016-12-03 16:33:16 --> UTF-8 Support Enabled
INFO - 2016-12-03 16:33:16 --> Utf8 Class Initialized
INFO - 2016-12-03 16:33:16 --> URI Class Initialized
INFO - 2016-12-03 16:33:16 --> Router Class Initialized
INFO - 2016-12-03 16:33:16 --> Output Class Initialized
INFO - 2016-12-03 16:33:16 --> Security Class Initialized
DEBUG - 2016-12-03 16:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 16:33:16 --> Input Class Initialized
INFO - 2016-12-03 16:33:16 --> Language Class Initialized
INFO - 2016-12-03 16:33:16 --> Loader Class Initialized
INFO - 2016-12-03 16:33:16 --> Helper loaded: url_helper
INFO - 2016-12-03 16:33:16 --> Helper loaded: form_helper
INFO - 2016-12-03 16:33:17 --> Database Driver Class Initialized
INFO - 2016-12-03 16:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 16:33:17 --> Controller Class Initialized
INFO - 2016-12-03 16:33:17 --> Model Class Initialized
INFO - 2016-12-03 16:33:17 --> Form Validation Class Initialized
INFO - 2016-12-03 16:33:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 16:33:17 --> Pagination Class Initialized
INFO - 2016-12-03 16:33:17 --> Helper loaded: app_helper
INFO - 2016-12-03 16:33:17 --> Email Class Initialized
INFO - 2016-12-03 16:33:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 16:33:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-03 16:33:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 16:33:17 --> Final output sent to browser
DEBUG - 2016-12-03 16:33:17 --> Total execution time: 0.3264
INFO - 2016-12-03 16:35:51 --> Config Class Initialized
INFO - 2016-12-03 16:35:51 --> Hooks Class Initialized
DEBUG - 2016-12-03 16:35:51 --> UTF-8 Support Enabled
INFO - 2016-12-03 16:35:51 --> Utf8 Class Initialized
INFO - 2016-12-03 16:35:51 --> URI Class Initialized
INFO - 2016-12-03 16:35:51 --> Router Class Initialized
INFO - 2016-12-03 16:35:51 --> Output Class Initialized
INFO - 2016-12-03 16:35:51 --> Security Class Initialized
DEBUG - 2016-12-03 16:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 16:35:51 --> Input Class Initialized
INFO - 2016-12-03 16:35:51 --> Language Class Initialized
INFO - 2016-12-03 16:35:51 --> Loader Class Initialized
INFO - 2016-12-03 16:35:51 --> Helper loaded: url_helper
INFO - 2016-12-03 16:35:51 --> Helper loaded: form_helper
INFO - 2016-12-03 16:35:52 --> Database Driver Class Initialized
INFO - 2016-12-03 16:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 16:35:52 --> Controller Class Initialized
INFO - 2016-12-03 16:35:52 --> Model Class Initialized
INFO - 2016-12-03 16:35:52 --> Form Validation Class Initialized
INFO - 2016-12-03 16:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 16:35:52 --> Pagination Class Initialized
INFO - 2016-12-03 16:35:52 --> Helper loaded: app_helper
INFO - 2016-12-03 16:35:52 --> Email Class Initialized
INFO - 2016-12-03 16:35:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 16:35:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-03 16:35:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 16:35:52 --> Final output sent to browser
DEBUG - 2016-12-03 16:35:52 --> Total execution time: 0.3204
INFO - 2016-12-03 16:36:13 --> Config Class Initialized
INFO - 2016-12-03 16:36:13 --> Hooks Class Initialized
DEBUG - 2016-12-03 16:36:13 --> UTF-8 Support Enabled
INFO - 2016-12-03 16:36:13 --> Utf8 Class Initialized
INFO - 2016-12-03 16:36:13 --> URI Class Initialized
INFO - 2016-12-03 16:36:13 --> Router Class Initialized
INFO - 2016-12-03 16:36:14 --> Output Class Initialized
INFO - 2016-12-03 16:36:14 --> Security Class Initialized
DEBUG - 2016-12-03 16:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 16:36:14 --> Input Class Initialized
INFO - 2016-12-03 16:36:14 --> Language Class Initialized
INFO - 2016-12-03 16:36:14 --> Loader Class Initialized
INFO - 2016-12-03 16:36:14 --> Helper loaded: url_helper
INFO - 2016-12-03 16:36:14 --> Helper loaded: form_helper
INFO - 2016-12-03 16:36:14 --> Database Driver Class Initialized
INFO - 2016-12-03 16:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 16:36:14 --> Controller Class Initialized
INFO - 2016-12-03 16:36:14 --> Model Class Initialized
INFO - 2016-12-03 16:36:14 --> Form Validation Class Initialized
INFO - 2016-12-03 16:36:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 16:36:14 --> Pagination Class Initialized
INFO - 2016-12-03 16:36:14 --> Helper loaded: app_helper
INFO - 2016-12-03 16:36:14 --> Email Class Initialized
INFO - 2016-12-03 16:36:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 16:36:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-03 16:36:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 16:36:14 --> Final output sent to browser
DEBUG - 2016-12-03 16:36:14 --> Total execution time: 0.2949
INFO - 2016-12-03 16:40:52 --> Config Class Initialized
INFO - 2016-12-03 16:40:52 --> Hooks Class Initialized
DEBUG - 2016-12-03 16:40:52 --> UTF-8 Support Enabled
INFO - 2016-12-03 16:40:52 --> Utf8 Class Initialized
INFO - 2016-12-03 16:40:52 --> URI Class Initialized
DEBUG - 2016-12-03 16:40:52 --> No URI present. Default controller set.
INFO - 2016-12-03 16:40:52 --> Router Class Initialized
INFO - 2016-12-03 16:40:52 --> Output Class Initialized
INFO - 2016-12-03 16:40:52 --> Security Class Initialized
DEBUG - 2016-12-03 16:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 16:40:52 --> Input Class Initialized
INFO - 2016-12-03 16:40:52 --> Language Class Initialized
INFO - 2016-12-03 16:40:52 --> Loader Class Initialized
INFO - 2016-12-03 16:40:52 --> Helper loaded: url_helper
INFO - 2016-12-03 16:40:52 --> Helper loaded: form_helper
INFO - 2016-12-03 16:40:52 --> Database Driver Class Initialized
INFO - 2016-12-03 16:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 16:40:52 --> Controller Class Initialized
INFO - 2016-12-03 16:40:52 --> Model Class Initialized
INFO - 2016-12-03 16:40:52 --> Model Class Initialized
INFO - 2016-12-03 16:40:52 --> Model Class Initialized
INFO - 2016-12-03 16:40:52 --> Model Class Initialized
INFO - 2016-12-03 16:40:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 16:40:52 --> Pagination Class Initialized
INFO - 2016-12-03 16:40:52 --> Helper loaded: app_helper
INFO - 2016-12-03 16:40:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 16:40:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-03 16:40:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-03 16:40:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-03 16:40:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-03 16:40:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-03 16:40:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-03 16:40:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-03 16:40:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 16:40:52 --> Final output sent to browser
DEBUG - 2016-12-03 16:40:52 --> Total execution time: 0.4180
INFO - 2016-12-03 16:50:33 --> Config Class Initialized
INFO - 2016-12-03 16:50:33 --> Hooks Class Initialized
DEBUG - 2016-12-03 16:50:33 --> UTF-8 Support Enabled
INFO - 2016-12-03 16:50:33 --> Utf8 Class Initialized
INFO - 2016-12-03 16:50:33 --> URI Class Initialized
INFO - 2016-12-03 16:50:33 --> Router Class Initialized
INFO - 2016-12-03 16:50:33 --> Output Class Initialized
INFO - 2016-12-03 16:50:33 --> Security Class Initialized
DEBUG - 2016-12-03 16:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 16:50:33 --> Input Class Initialized
INFO - 2016-12-03 16:50:33 --> Language Class Initialized
INFO - 2016-12-03 16:50:33 --> Loader Class Initialized
INFO - 2016-12-03 16:50:33 --> Helper loaded: url_helper
INFO - 2016-12-03 16:50:33 --> Helper loaded: form_helper
INFO - 2016-12-03 16:50:33 --> Database Driver Class Initialized
INFO - 2016-12-03 16:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 16:50:33 --> Controller Class Initialized
INFO - 2016-12-03 16:50:33 --> Model Class Initialized
INFO - 2016-12-03 16:50:33 --> Model Class Initialized
INFO - 2016-12-03 16:50:33 --> Model Class Initialized
INFO - 2016-12-03 16:50:33 --> Model Class Initialized
INFO - 2016-12-03 16:50:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 16:50:33 --> Pagination Class Initialized
INFO - 2016-12-03 16:50:33 --> Helper loaded: app_helper
DEBUG - 2016-12-03 16:50:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-12-03 16:50:33 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-12-03 16:50:33 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-12-03 16:50:33 --> Config Class Initialized
INFO - 2016-12-03 16:50:33 --> Hooks Class Initialized
DEBUG - 2016-12-03 16:50:33 --> UTF-8 Support Enabled
INFO - 2016-12-03 16:50:33 --> Utf8 Class Initialized
INFO - 2016-12-03 16:50:33 --> URI Class Initialized
DEBUG - 2016-12-03 16:50:33 --> No URI present. Default controller set.
INFO - 2016-12-03 16:50:33 --> Router Class Initialized
INFO - 2016-12-03 16:50:33 --> Output Class Initialized
INFO - 2016-12-03 16:50:33 --> Security Class Initialized
DEBUG - 2016-12-03 16:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 16:50:33 --> Input Class Initialized
INFO - 2016-12-03 16:50:33 --> Language Class Initialized
INFO - 2016-12-03 16:50:33 --> Loader Class Initialized
INFO - 2016-12-03 16:50:33 --> Helper loaded: url_helper
INFO - 2016-12-03 16:50:33 --> Helper loaded: form_helper
INFO - 2016-12-03 16:50:33 --> Database Driver Class Initialized
INFO - 2016-12-03 16:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 16:50:33 --> Controller Class Initialized
INFO - 2016-12-03 16:50:33 --> Model Class Initialized
INFO - 2016-12-03 16:50:33 --> Model Class Initialized
INFO - 2016-12-03 16:50:33 --> Model Class Initialized
INFO - 2016-12-03 16:50:33 --> Model Class Initialized
INFO - 2016-12-03 16:50:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 16:50:33 --> Pagination Class Initialized
INFO - 2016-12-03 16:50:33 --> Helper loaded: app_helper
INFO - 2016-12-03 16:50:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 16:50:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-03 16:50:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 16:50:33 --> Final output sent to browser
DEBUG - 2016-12-03 16:50:33 --> Total execution time: 0.2930
INFO - 2016-12-03 16:51:51 --> Config Class Initialized
INFO - 2016-12-03 16:51:51 --> Hooks Class Initialized
DEBUG - 2016-12-03 16:51:51 --> UTF-8 Support Enabled
INFO - 2016-12-03 16:51:51 --> Utf8 Class Initialized
INFO - 2016-12-03 16:51:51 --> URI Class Initialized
DEBUG - 2016-12-03 16:51:51 --> No URI present. Default controller set.
INFO - 2016-12-03 16:51:51 --> Router Class Initialized
INFO - 2016-12-03 16:51:51 --> Output Class Initialized
INFO - 2016-12-03 16:51:51 --> Security Class Initialized
DEBUG - 2016-12-03 16:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 16:51:51 --> Input Class Initialized
INFO - 2016-12-03 16:51:51 --> Language Class Initialized
INFO - 2016-12-03 16:51:51 --> Loader Class Initialized
INFO - 2016-12-03 16:51:51 --> Helper loaded: url_helper
INFO - 2016-12-03 16:51:51 --> Helper loaded: form_helper
INFO - 2016-12-03 16:51:51 --> Database Driver Class Initialized
INFO - 2016-12-03 16:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 16:51:51 --> Controller Class Initialized
INFO - 2016-12-03 16:51:51 --> Model Class Initialized
INFO - 2016-12-03 16:51:51 --> Model Class Initialized
INFO - 2016-12-03 16:51:51 --> Model Class Initialized
INFO - 2016-12-03 16:51:51 --> Model Class Initialized
INFO - 2016-12-03 16:51:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 16:51:51 --> Pagination Class Initialized
INFO - 2016-12-03 16:51:51 --> Helper loaded: app_helper
INFO - 2016-12-03 16:51:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 16:51:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-03 16:51:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 16:51:51 --> Final output sent to browser
DEBUG - 2016-12-03 16:51:51 --> Total execution time: 0.3108
INFO - 2016-12-03 16:54:15 --> Config Class Initialized
INFO - 2016-12-03 16:54:15 --> Hooks Class Initialized
DEBUG - 2016-12-03 16:54:15 --> UTF-8 Support Enabled
INFO - 2016-12-03 16:54:15 --> Utf8 Class Initialized
INFO - 2016-12-03 16:54:15 --> URI Class Initialized
DEBUG - 2016-12-03 16:54:15 --> No URI present. Default controller set.
INFO - 2016-12-03 16:54:15 --> Router Class Initialized
INFO - 2016-12-03 16:54:15 --> Output Class Initialized
INFO - 2016-12-03 16:54:15 --> Security Class Initialized
DEBUG - 2016-12-03 16:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 16:54:15 --> Input Class Initialized
INFO - 2016-12-03 16:54:15 --> Language Class Initialized
INFO - 2016-12-03 16:54:16 --> Loader Class Initialized
INFO - 2016-12-03 16:54:16 --> Helper loaded: url_helper
INFO - 2016-12-03 16:54:16 --> Helper loaded: form_helper
INFO - 2016-12-03 16:54:16 --> Database Driver Class Initialized
INFO - 2016-12-03 16:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 16:54:16 --> Controller Class Initialized
INFO - 2016-12-03 16:54:16 --> Model Class Initialized
INFO - 2016-12-03 16:54:16 --> Model Class Initialized
INFO - 2016-12-03 16:54:16 --> Model Class Initialized
INFO - 2016-12-03 16:54:16 --> Model Class Initialized
INFO - 2016-12-03 16:54:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 16:54:16 --> Pagination Class Initialized
INFO - 2016-12-03 16:54:16 --> Helper loaded: app_helper
INFO - 2016-12-03 16:54:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 16:54:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-03 16:54:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 16:54:16 --> Final output sent to browser
DEBUG - 2016-12-03 16:54:16 --> Total execution time: 0.3066
INFO - 2016-12-03 16:54:18 --> Config Class Initialized
INFO - 2016-12-03 16:54:18 --> Hooks Class Initialized
DEBUG - 2016-12-03 16:54:19 --> UTF-8 Support Enabled
INFO - 2016-12-03 16:54:19 --> Utf8 Class Initialized
INFO - 2016-12-03 16:54:19 --> URI Class Initialized
DEBUG - 2016-12-03 16:54:19 --> No URI present. Default controller set.
INFO - 2016-12-03 16:54:19 --> Router Class Initialized
INFO - 2016-12-03 16:54:19 --> Output Class Initialized
INFO - 2016-12-03 16:54:19 --> Security Class Initialized
DEBUG - 2016-12-03 16:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 16:54:19 --> Input Class Initialized
INFO - 2016-12-03 16:54:19 --> Language Class Initialized
INFO - 2016-12-03 16:54:19 --> Loader Class Initialized
INFO - 2016-12-03 16:54:19 --> Helper loaded: url_helper
INFO - 2016-12-03 16:54:19 --> Helper loaded: form_helper
INFO - 2016-12-03 16:54:19 --> Database Driver Class Initialized
INFO - 2016-12-03 16:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 16:54:19 --> Controller Class Initialized
INFO - 2016-12-03 16:54:19 --> Model Class Initialized
INFO - 2016-12-03 16:54:19 --> Model Class Initialized
INFO - 2016-12-03 16:54:19 --> Model Class Initialized
INFO - 2016-12-03 16:54:19 --> Model Class Initialized
INFO - 2016-12-03 16:54:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 16:54:19 --> Pagination Class Initialized
INFO - 2016-12-03 16:54:19 --> Helper loaded: app_helper
INFO - 2016-12-03 16:54:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 16:54:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-03 16:54:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 16:54:19 --> Final output sent to browser
DEBUG - 2016-12-03 16:54:19 --> Total execution time: 0.2973
INFO - 2016-12-03 16:55:25 --> Config Class Initialized
INFO - 2016-12-03 16:55:25 --> Hooks Class Initialized
DEBUG - 2016-12-03 16:55:25 --> UTF-8 Support Enabled
INFO - 2016-12-03 16:55:25 --> Utf8 Class Initialized
INFO - 2016-12-03 16:55:25 --> URI Class Initialized
DEBUG - 2016-12-03 16:55:25 --> No URI present. Default controller set.
INFO - 2016-12-03 16:55:25 --> Router Class Initialized
INFO - 2016-12-03 16:55:25 --> Output Class Initialized
INFO - 2016-12-03 16:55:25 --> Security Class Initialized
DEBUG - 2016-12-03 16:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 16:55:25 --> Input Class Initialized
INFO - 2016-12-03 16:55:25 --> Language Class Initialized
INFO - 2016-12-03 16:55:25 --> Loader Class Initialized
INFO - 2016-12-03 16:55:25 --> Helper loaded: url_helper
INFO - 2016-12-03 16:55:25 --> Helper loaded: form_helper
INFO - 2016-12-03 16:55:25 --> Database Driver Class Initialized
INFO - 2016-12-03 16:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 16:55:25 --> Controller Class Initialized
INFO - 2016-12-03 16:55:25 --> Model Class Initialized
INFO - 2016-12-03 16:55:25 --> Model Class Initialized
INFO - 2016-12-03 16:55:25 --> Model Class Initialized
INFO - 2016-12-03 16:55:25 --> Model Class Initialized
INFO - 2016-12-03 16:55:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 16:55:25 --> Pagination Class Initialized
INFO - 2016-12-03 16:55:25 --> Helper loaded: app_helper
INFO - 2016-12-03 16:55:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 16:55:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-03 16:55:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 16:55:25 --> Final output sent to browser
DEBUG - 2016-12-03 16:55:25 --> Total execution time: 0.3190
INFO - 2016-12-03 18:11:15 --> Config Class Initialized
INFO - 2016-12-03 18:11:15 --> Hooks Class Initialized
DEBUG - 2016-12-03 18:11:15 --> UTF-8 Support Enabled
INFO - 2016-12-03 18:11:15 --> Utf8 Class Initialized
INFO - 2016-12-03 18:11:15 --> URI Class Initialized
DEBUG - 2016-12-03 18:11:15 --> No URI present. Default controller set.
INFO - 2016-12-03 18:11:15 --> Router Class Initialized
INFO - 2016-12-03 18:11:15 --> Output Class Initialized
INFO - 2016-12-03 18:11:15 --> Security Class Initialized
DEBUG - 2016-12-03 18:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 18:11:15 --> Input Class Initialized
INFO - 2016-12-03 18:11:15 --> Language Class Initialized
INFO - 2016-12-03 18:11:15 --> Loader Class Initialized
INFO - 2016-12-03 18:11:15 --> Helper loaded: url_helper
INFO - 2016-12-03 18:11:16 --> Helper loaded: form_helper
INFO - 2016-12-03 18:11:16 --> Database Driver Class Initialized
INFO - 2016-12-03 18:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 18:11:16 --> Controller Class Initialized
INFO - 2016-12-03 18:11:16 --> Model Class Initialized
INFO - 2016-12-03 18:11:16 --> Model Class Initialized
INFO - 2016-12-03 18:11:16 --> Model Class Initialized
INFO - 2016-12-03 18:11:16 --> Model Class Initialized
INFO - 2016-12-03 18:11:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 18:11:16 --> Pagination Class Initialized
INFO - 2016-12-03 18:11:16 --> Helper loaded: app_helper
INFO - 2016-12-03 18:11:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 18:11:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-03 18:11:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 18:11:16 --> Final output sent to browser
DEBUG - 2016-12-03 18:11:16 --> Total execution time: 1.7958
INFO - 2016-12-03 18:11:38 --> Config Class Initialized
INFO - 2016-12-03 18:11:38 --> Hooks Class Initialized
DEBUG - 2016-12-03 18:11:38 --> UTF-8 Support Enabled
INFO - 2016-12-03 18:11:38 --> Utf8 Class Initialized
INFO - 2016-12-03 18:11:38 --> URI Class Initialized
INFO - 2016-12-03 18:11:38 --> Router Class Initialized
INFO - 2016-12-03 18:11:38 --> Output Class Initialized
INFO - 2016-12-03 18:11:38 --> Security Class Initialized
DEBUG - 2016-12-03 18:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 18:11:38 --> Input Class Initialized
INFO - 2016-12-03 18:11:38 --> Language Class Initialized
INFO - 2016-12-03 18:11:38 --> Loader Class Initialized
INFO - 2016-12-03 18:11:38 --> Helper loaded: url_helper
INFO - 2016-12-03 18:11:38 --> Helper loaded: form_helper
INFO - 2016-12-03 18:11:38 --> Database Driver Class Initialized
INFO - 2016-12-03 18:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 18:11:39 --> Controller Class Initialized
INFO - 2016-12-03 18:11:39 --> Model Class Initialized
INFO - 2016-12-03 18:11:39 --> Model Class Initialized
INFO - 2016-12-03 18:11:39 --> Model Class Initialized
INFO - 2016-12-03 18:11:39 --> Model Class Initialized
INFO - 2016-12-03 18:11:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 18:11:39 --> Pagination Class Initialized
INFO - 2016-12-03 18:11:39 --> Helper loaded: app_helper
DEBUG - 2016-12-03 18:11:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 18:11:39 --> Model Class Initialized
INFO - 2016-12-03 18:11:39 --> Final output sent to browser
DEBUG - 2016-12-03 18:11:39 --> Total execution time: 0.3517
INFO - 2016-12-03 18:11:39 --> Config Class Initialized
INFO - 2016-12-03 18:11:39 --> Hooks Class Initialized
DEBUG - 2016-12-03 18:11:39 --> UTF-8 Support Enabled
INFO - 2016-12-03 18:11:39 --> Utf8 Class Initialized
INFO - 2016-12-03 18:11:39 --> URI Class Initialized
DEBUG - 2016-12-03 18:11:39 --> No URI present. Default controller set.
INFO - 2016-12-03 18:11:39 --> Router Class Initialized
INFO - 2016-12-03 18:11:39 --> Output Class Initialized
INFO - 2016-12-03 18:11:39 --> Security Class Initialized
DEBUG - 2016-12-03 18:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 18:11:39 --> Input Class Initialized
INFO - 2016-12-03 18:11:39 --> Language Class Initialized
INFO - 2016-12-03 18:11:39 --> Loader Class Initialized
INFO - 2016-12-03 18:11:39 --> Helper loaded: url_helper
INFO - 2016-12-03 18:11:39 --> Helper loaded: form_helper
INFO - 2016-12-03 18:11:39 --> Database Driver Class Initialized
INFO - 2016-12-03 18:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 18:11:39 --> Controller Class Initialized
INFO - 2016-12-03 18:11:39 --> Model Class Initialized
INFO - 2016-12-03 18:11:39 --> Model Class Initialized
INFO - 2016-12-03 18:11:39 --> Model Class Initialized
INFO - 2016-12-03 18:11:39 --> Model Class Initialized
INFO - 2016-12-03 18:11:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 18:11:39 --> Pagination Class Initialized
INFO - 2016-12-03 18:11:39 --> Helper loaded: app_helper
INFO - 2016-12-03 18:11:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 18:11:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-03 18:11:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-03 18:11:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-03 18:11:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-03 18:11:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-03 18:11:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-03 18:11:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-03 18:11:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 18:11:39 --> Final output sent to browser
DEBUG - 2016-12-03 18:11:39 --> Total execution time: 0.6937
INFO - 2016-12-03 18:12:01 --> Config Class Initialized
INFO - 2016-12-03 18:12:01 --> Hooks Class Initialized
DEBUG - 2016-12-03 18:12:01 --> UTF-8 Support Enabled
INFO - 2016-12-03 18:12:01 --> Utf8 Class Initialized
INFO - 2016-12-03 18:12:01 --> URI Class Initialized
INFO - 2016-12-03 18:12:01 --> Router Class Initialized
INFO - 2016-12-03 18:12:01 --> Output Class Initialized
INFO - 2016-12-03 18:12:01 --> Security Class Initialized
DEBUG - 2016-12-03 18:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 18:12:01 --> Input Class Initialized
INFO - 2016-12-03 18:12:01 --> Language Class Initialized
INFO - 2016-12-03 18:12:01 --> Loader Class Initialized
INFO - 2016-12-03 18:12:01 --> Helper loaded: url_helper
INFO - 2016-12-03 18:12:01 --> Helper loaded: form_helper
INFO - 2016-12-03 18:12:01 --> Database Driver Class Initialized
INFO - 2016-12-03 18:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 18:12:01 --> Controller Class Initialized
INFO - 2016-12-03 18:12:01 --> Model Class Initialized
INFO - 2016-12-03 18:12:01 --> Form Validation Class Initialized
INFO - 2016-12-03 18:12:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 18:12:01 --> Pagination Class Initialized
INFO - 2016-12-03 18:12:01 --> Helper loaded: app_helper
INFO - 2016-12-03 18:12:01 --> Email Class Initialized
INFO - 2016-12-03 18:12:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-03 18:12:01 --> Final output sent to browser
DEBUG - 2016-12-03 18:12:01 --> Total execution time: 0.5134
INFO - 2016-12-03 18:12:10 --> Config Class Initialized
INFO - 2016-12-03 18:12:10 --> Hooks Class Initialized
DEBUG - 2016-12-03 18:12:10 --> UTF-8 Support Enabled
INFO - 2016-12-03 18:12:10 --> Utf8 Class Initialized
INFO - 2016-12-03 18:12:10 --> URI Class Initialized
INFO - 2016-12-03 18:12:10 --> Router Class Initialized
INFO - 2016-12-03 18:12:10 --> Output Class Initialized
INFO - 2016-12-03 18:12:10 --> Security Class Initialized
DEBUG - 2016-12-03 18:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 18:12:10 --> Input Class Initialized
INFO - 2016-12-03 18:12:10 --> Language Class Initialized
INFO - 2016-12-03 18:12:10 --> Loader Class Initialized
INFO - 2016-12-03 18:12:10 --> Helper loaded: url_helper
INFO - 2016-12-03 18:12:10 --> Helper loaded: form_helper
INFO - 2016-12-03 18:12:10 --> Database Driver Class Initialized
INFO - 2016-12-03 18:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 18:12:10 --> Controller Class Initialized
INFO - 2016-12-03 18:12:10 --> Model Class Initialized
INFO - 2016-12-03 18:12:10 --> Form Validation Class Initialized
INFO - 2016-12-03 18:12:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 18:12:10 --> Pagination Class Initialized
INFO - 2016-12-03 18:12:10 --> Helper loaded: app_helper
INFO - 2016-12-03 18:12:10 --> Email Class Initialized
INFO - 2016-12-03 18:12:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-03 17:12:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-03 17:12:11 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-03 17:12:11 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-03 17:12:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-03 17:12:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-03 17:12:16 --> Final output sent to browser
DEBUG - 2016-12-03 17:12:16 --> Total execution time: 5.8903
INFO - 2016-12-03 18:12:37 --> Config Class Initialized
INFO - 2016-12-03 18:12:37 --> Hooks Class Initialized
DEBUG - 2016-12-03 18:12:37 --> UTF-8 Support Enabled
INFO - 2016-12-03 18:12:37 --> Utf8 Class Initialized
INFO - 2016-12-03 18:12:37 --> URI Class Initialized
INFO - 2016-12-03 18:12:37 --> Router Class Initialized
INFO - 2016-12-03 18:12:37 --> Output Class Initialized
INFO - 2016-12-03 18:12:37 --> Security Class Initialized
DEBUG - 2016-12-03 18:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 18:12:37 --> Input Class Initialized
INFO - 2016-12-03 18:12:37 --> Language Class Initialized
INFO - 2016-12-03 18:12:37 --> Loader Class Initialized
INFO - 2016-12-03 18:12:37 --> Helper loaded: url_helper
INFO - 2016-12-03 18:12:37 --> Helper loaded: form_helper
INFO - 2016-12-03 18:12:37 --> Database Driver Class Initialized
INFO - 2016-12-03 18:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 18:12:37 --> Controller Class Initialized
INFO - 2016-12-03 18:12:37 --> Model Class Initialized
INFO - 2016-12-03 18:12:37 --> Form Validation Class Initialized
INFO - 2016-12-03 18:12:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 18:12:37 --> Pagination Class Initialized
INFO - 2016-12-03 18:12:37 --> Helper loaded: app_helper
INFO - 2016-12-03 18:12:37 --> Email Class Initialized
INFO - 2016-12-03 18:12:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 18:12:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-03 18:12:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 18:12:38 --> Final output sent to browser
DEBUG - 2016-12-03 18:12:38 --> Total execution time: 0.4241
INFO - 2016-12-03 18:12:47 --> Config Class Initialized
INFO - 2016-12-03 18:12:47 --> Hooks Class Initialized
DEBUG - 2016-12-03 18:12:47 --> UTF-8 Support Enabled
INFO - 2016-12-03 18:12:47 --> Utf8 Class Initialized
INFO - 2016-12-03 18:12:47 --> URI Class Initialized
INFO - 2016-12-03 18:12:47 --> Router Class Initialized
INFO - 2016-12-03 18:12:47 --> Output Class Initialized
INFO - 2016-12-03 18:12:47 --> Security Class Initialized
DEBUG - 2016-12-03 18:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 18:12:47 --> Input Class Initialized
INFO - 2016-12-03 18:12:47 --> Language Class Initialized
INFO - 2016-12-03 18:12:47 --> Loader Class Initialized
INFO - 2016-12-03 18:12:47 --> Helper loaded: url_helper
INFO - 2016-12-03 18:12:47 --> Helper loaded: form_helper
INFO - 2016-12-03 18:12:47 --> Database Driver Class Initialized
INFO - 2016-12-03 18:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 18:12:47 --> Controller Class Initialized
INFO - 2016-12-03 18:12:47 --> Model Class Initialized
INFO - 2016-12-03 18:12:47 --> Form Validation Class Initialized
INFO - 2016-12-03 18:12:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 18:12:47 --> Pagination Class Initialized
INFO - 2016-12-03 18:12:47 --> Helper loaded: app_helper
INFO - 2016-12-03 18:12:47 --> Email Class Initialized
INFO - 2016-12-03 18:12:47 --> Final output sent to browser
DEBUG - 2016-12-03 18:12:47 --> Total execution time: 0.2626
INFO - 2016-12-03 18:12:57 --> Config Class Initialized
INFO - 2016-12-03 18:12:57 --> Hooks Class Initialized
DEBUG - 2016-12-03 18:12:57 --> UTF-8 Support Enabled
INFO - 2016-12-03 18:12:57 --> Utf8 Class Initialized
INFO - 2016-12-03 18:12:57 --> URI Class Initialized
DEBUG - 2016-12-03 18:12:57 --> No URI present. Default controller set.
INFO - 2016-12-03 18:12:57 --> Router Class Initialized
INFO - 2016-12-03 18:12:57 --> Output Class Initialized
INFO - 2016-12-03 18:12:57 --> Security Class Initialized
DEBUG - 2016-12-03 18:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 18:12:57 --> Input Class Initialized
INFO - 2016-12-03 18:12:57 --> Language Class Initialized
INFO - 2016-12-03 18:12:57 --> Loader Class Initialized
INFO - 2016-12-03 18:12:57 --> Helper loaded: url_helper
INFO - 2016-12-03 18:12:57 --> Helper loaded: form_helper
INFO - 2016-12-03 18:12:57 --> Database Driver Class Initialized
INFO - 2016-12-03 18:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 18:12:57 --> Controller Class Initialized
INFO - 2016-12-03 18:12:58 --> Model Class Initialized
INFO - 2016-12-03 18:12:58 --> Model Class Initialized
INFO - 2016-12-03 18:12:58 --> Model Class Initialized
INFO - 2016-12-03 18:12:58 --> Model Class Initialized
INFO - 2016-12-03 18:12:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 18:12:58 --> Pagination Class Initialized
INFO - 2016-12-03 18:12:58 --> Helper loaded: app_helper
INFO - 2016-12-03 18:12:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 18:12:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-03 18:12:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-03 18:12:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-03 18:12:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-03 18:12:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-03 18:12:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-03 18:12:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-03 18:12:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 18:12:58 --> Final output sent to browser
DEBUG - 2016-12-03 18:12:58 --> Total execution time: 0.3961
INFO - 2016-12-03 18:23:55 --> Config Class Initialized
INFO - 2016-12-03 18:23:55 --> Hooks Class Initialized
DEBUG - 2016-12-03 18:23:55 --> UTF-8 Support Enabled
INFO - 2016-12-03 18:23:55 --> Utf8 Class Initialized
INFO - 2016-12-03 18:23:55 --> URI Class Initialized
INFO - 2016-12-03 18:23:55 --> Router Class Initialized
INFO - 2016-12-03 18:23:55 --> Output Class Initialized
INFO - 2016-12-03 18:23:55 --> Security Class Initialized
DEBUG - 2016-12-03 18:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 18:23:55 --> Input Class Initialized
INFO - 2016-12-03 18:23:55 --> Language Class Initialized
INFO - 2016-12-03 18:23:55 --> Loader Class Initialized
INFO - 2016-12-03 18:23:55 --> Helper loaded: url_helper
INFO - 2016-12-03 18:23:55 --> Helper loaded: form_helper
INFO - 2016-12-03 18:23:55 --> Database Driver Class Initialized
INFO - 2016-12-03 18:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 18:23:55 --> Controller Class Initialized
INFO - 2016-12-03 18:23:55 --> Model Class Initialized
INFO - 2016-12-03 18:23:55 --> Form Validation Class Initialized
INFO - 2016-12-03 18:23:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 18:23:55 --> Pagination Class Initialized
INFO - 2016-12-03 18:23:55 --> Helper loaded: app_helper
INFO - 2016-12-03 18:23:55 --> Email Class Initialized
INFO - 2016-12-03 18:23:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 18:23:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-03 18:23:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 18:23:56 --> Final output sent to browser
DEBUG - 2016-12-03 18:23:56 --> Total execution time: 0.3999
INFO - 2016-12-03 18:56:38 --> Config Class Initialized
INFO - 2016-12-03 18:56:38 --> Hooks Class Initialized
DEBUG - 2016-12-03 18:56:38 --> UTF-8 Support Enabled
INFO - 2016-12-03 18:56:39 --> Utf8 Class Initialized
INFO - 2016-12-03 18:56:39 --> URI Class Initialized
DEBUG - 2016-12-03 18:56:39 --> No URI present. Default controller set.
INFO - 2016-12-03 18:56:39 --> Router Class Initialized
INFO - 2016-12-03 18:56:39 --> Output Class Initialized
INFO - 2016-12-03 18:56:39 --> Security Class Initialized
DEBUG - 2016-12-03 18:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 18:56:39 --> Input Class Initialized
INFO - 2016-12-03 18:56:39 --> Language Class Initialized
INFO - 2016-12-03 18:56:39 --> Loader Class Initialized
INFO - 2016-12-03 18:56:39 --> Helper loaded: url_helper
INFO - 2016-12-03 18:56:39 --> Helper loaded: form_helper
INFO - 2016-12-03 18:56:40 --> Database Driver Class Initialized
INFO - 2016-12-03 18:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 18:56:40 --> Controller Class Initialized
INFO - 2016-12-03 18:56:40 --> Model Class Initialized
INFO - 2016-12-03 18:56:40 --> Model Class Initialized
INFO - 2016-12-03 18:56:40 --> Model Class Initialized
INFO - 2016-12-03 18:56:40 --> Model Class Initialized
INFO - 2016-12-03 18:56:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 18:56:41 --> Pagination Class Initialized
INFO - 2016-12-03 18:56:41 --> Helper loaded: app_helper
INFO - 2016-12-03 18:56:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 18:56:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-03 18:56:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-03 18:56:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-03 18:56:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-03 18:56:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-03 18:56:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-03 18:56:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-03 18:56:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 18:56:41 --> Final output sent to browser
DEBUG - 2016-12-03 18:56:41 --> Total execution time: 3.1275
INFO - 2016-12-03 18:56:44 --> Config Class Initialized
INFO - 2016-12-03 18:56:44 --> Hooks Class Initialized
DEBUG - 2016-12-03 18:56:44 --> UTF-8 Support Enabled
INFO - 2016-12-03 18:56:44 --> Utf8 Class Initialized
INFO - 2016-12-03 18:56:44 --> URI Class Initialized
INFO - 2016-12-03 18:56:44 --> Router Class Initialized
INFO - 2016-12-03 18:56:44 --> Output Class Initialized
INFO - 2016-12-03 18:56:44 --> Security Class Initialized
DEBUG - 2016-12-03 18:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 18:56:44 --> Input Class Initialized
INFO - 2016-12-03 18:56:44 --> Language Class Initialized
INFO - 2016-12-03 18:56:44 --> Loader Class Initialized
INFO - 2016-12-03 18:56:44 --> Helper loaded: url_helper
INFO - 2016-12-03 18:56:44 --> Helper loaded: form_helper
INFO - 2016-12-03 18:56:44 --> Database Driver Class Initialized
INFO - 2016-12-03 18:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 18:56:44 --> Controller Class Initialized
INFO - 2016-12-03 18:56:44 --> Model Class Initialized
INFO - 2016-12-03 18:56:44 --> Model Class Initialized
INFO - 2016-12-03 18:56:44 --> Model Class Initialized
INFO - 2016-12-03 18:56:44 --> Model Class Initialized
INFO - 2016-12-03 18:56:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 18:56:44 --> Pagination Class Initialized
INFO - 2016-12-03 18:56:44 --> Helper loaded: app_helper
DEBUG - 2016-12-03 18:56:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-12-03 18:56:44 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-12-03 18:56:44 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-12-03 18:56:44 --> Config Class Initialized
INFO - 2016-12-03 18:56:44 --> Hooks Class Initialized
DEBUG - 2016-12-03 18:56:44 --> UTF-8 Support Enabled
INFO - 2016-12-03 18:56:44 --> Utf8 Class Initialized
INFO - 2016-12-03 18:56:44 --> URI Class Initialized
DEBUG - 2016-12-03 18:56:44 --> No URI present. Default controller set.
INFO - 2016-12-03 18:56:44 --> Router Class Initialized
INFO - 2016-12-03 18:56:44 --> Output Class Initialized
INFO - 2016-12-03 18:56:44 --> Security Class Initialized
DEBUG - 2016-12-03 18:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 18:56:45 --> Input Class Initialized
INFO - 2016-12-03 18:56:45 --> Language Class Initialized
INFO - 2016-12-03 18:56:45 --> Loader Class Initialized
INFO - 2016-12-03 18:56:45 --> Helper loaded: url_helper
INFO - 2016-12-03 18:56:45 --> Helper loaded: form_helper
INFO - 2016-12-03 18:56:45 --> Database Driver Class Initialized
INFO - 2016-12-03 18:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 18:56:45 --> Controller Class Initialized
INFO - 2016-12-03 18:56:45 --> Model Class Initialized
INFO - 2016-12-03 18:56:45 --> Model Class Initialized
INFO - 2016-12-03 18:56:45 --> Model Class Initialized
INFO - 2016-12-03 18:56:45 --> Model Class Initialized
INFO - 2016-12-03 18:56:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-03 18:56:45 --> Pagination Class Initialized
INFO - 2016-12-03 18:56:45 --> Helper loaded: app_helper
INFO - 2016-12-03 18:56:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-03 18:56:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-03 18:56:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-03 18:56:45 --> Final output sent to browser
DEBUG - 2016-12-03 18:56:45 --> Total execution time: 0.3640
