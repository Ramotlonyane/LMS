<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-18 00:50:13 --> Config Class Initialized
INFO - 2016-10-18 00:50:13 --> Hooks Class Initialized
DEBUG - 2016-10-18 00:50:13 --> UTF-8 Support Enabled
INFO - 2016-10-18 00:50:13 --> Utf8 Class Initialized
INFO - 2016-10-18 00:50:13 --> URI Class Initialized
DEBUG - 2016-10-18 00:50:13 --> No URI present. Default controller set.
INFO - 2016-10-18 00:50:13 --> Router Class Initialized
INFO - 2016-10-18 00:50:13 --> Output Class Initialized
INFO - 2016-10-18 00:50:13 --> Security Class Initialized
DEBUG - 2016-10-18 00:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 00:50:13 --> Input Class Initialized
INFO - 2016-10-18 00:50:13 --> Language Class Initialized
INFO - 2016-10-18 00:50:13 --> Loader Class Initialized
INFO - 2016-10-18 00:50:13 --> Helper loaded: url_helper
INFO - 2016-10-18 00:50:13 --> Helper loaded: form_helper
INFO - 2016-10-18 00:50:13 --> Database Driver Class Initialized
INFO - 2016-10-18 00:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 00:50:13 --> Controller Class Initialized
INFO - 2016-10-18 00:50:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-18 00:50:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-18 00:50:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-18 00:50:13 --> Final output sent to browser
DEBUG - 2016-10-18 00:50:13 --> Total execution time: 0.5525
INFO - 2016-10-18 00:50:18 --> Config Class Initialized
INFO - 2016-10-18 00:50:18 --> Hooks Class Initialized
DEBUG - 2016-10-18 00:50:18 --> UTF-8 Support Enabled
INFO - 2016-10-18 00:50:18 --> Utf8 Class Initialized
INFO - 2016-10-18 00:50:18 --> URI Class Initialized
DEBUG - 2016-10-18 00:50:18 --> No URI present. Default controller set.
INFO - 2016-10-18 00:50:18 --> Router Class Initialized
INFO - 2016-10-18 00:50:18 --> Output Class Initialized
INFO - 2016-10-18 00:50:18 --> Security Class Initialized
DEBUG - 2016-10-18 00:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 00:50:18 --> Input Class Initialized
INFO - 2016-10-18 00:50:18 --> Language Class Initialized
INFO - 2016-10-18 00:50:18 --> Loader Class Initialized
INFO - 2016-10-18 00:50:18 --> Helper loaded: url_helper
INFO - 2016-10-18 00:50:18 --> Helper loaded: form_helper
INFO - 2016-10-18 00:50:18 --> Database Driver Class Initialized
INFO - 2016-10-18 00:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 00:50:18 --> Controller Class Initialized
INFO - 2016-10-18 00:50:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-18 00:50:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-18 00:50:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-18 00:50:18 --> Final output sent to browser
DEBUG - 2016-10-18 00:50:18 --> Total execution time: 0.2248
INFO - 2016-10-18 00:50:20 --> Config Class Initialized
INFO - 2016-10-18 00:50:20 --> Hooks Class Initialized
DEBUG - 2016-10-18 00:50:20 --> UTF-8 Support Enabled
INFO - 2016-10-18 00:50:20 --> Utf8 Class Initialized
INFO - 2016-10-18 00:50:20 --> URI Class Initialized
DEBUG - 2016-10-18 00:50:20 --> No URI present. Default controller set.
INFO - 2016-10-18 00:50:20 --> Router Class Initialized
INFO - 2016-10-18 00:50:20 --> Output Class Initialized
INFO - 2016-10-18 00:50:20 --> Security Class Initialized
DEBUG - 2016-10-18 00:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 00:50:20 --> Input Class Initialized
INFO - 2016-10-18 00:50:20 --> Language Class Initialized
INFO - 2016-10-18 00:50:20 --> Loader Class Initialized
INFO - 2016-10-18 00:50:20 --> Helper loaded: url_helper
INFO - 2016-10-18 00:50:20 --> Helper loaded: form_helper
INFO - 2016-10-18 00:50:20 --> Database Driver Class Initialized
INFO - 2016-10-18 00:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 00:50:20 --> Controller Class Initialized
INFO - 2016-10-18 00:50:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-18 00:50:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-18 00:50:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-18 00:50:21 --> Final output sent to browser
DEBUG - 2016-10-18 00:50:21 --> Total execution time: 0.2444
INFO - 2016-10-18 00:54:29 --> Config Class Initialized
INFO - 2016-10-18 00:54:29 --> Hooks Class Initialized
DEBUG - 2016-10-18 00:54:29 --> UTF-8 Support Enabled
INFO - 2016-10-18 00:54:29 --> Utf8 Class Initialized
INFO - 2016-10-18 00:54:29 --> URI Class Initialized
DEBUG - 2016-10-18 00:54:29 --> No URI present. Default controller set.
INFO - 2016-10-18 00:54:29 --> Router Class Initialized
INFO - 2016-10-18 00:54:29 --> Output Class Initialized
INFO - 2016-10-18 00:54:29 --> Security Class Initialized
DEBUG - 2016-10-18 00:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 00:54:29 --> Input Class Initialized
INFO - 2016-10-18 00:54:29 --> Language Class Initialized
INFO - 2016-10-18 00:54:29 --> Loader Class Initialized
INFO - 2016-10-18 00:54:29 --> Helper loaded: url_helper
INFO - 2016-10-18 00:54:29 --> Helper loaded: form_helper
INFO - 2016-10-18 00:54:29 --> Database Driver Class Initialized
INFO - 2016-10-18 00:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 00:54:29 --> Controller Class Initialized
INFO - 2016-10-18 00:54:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-18 00:54:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-18 00:54:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-18 00:54:29 --> Final output sent to browser
DEBUG - 2016-10-18 00:54:29 --> Total execution time: 0.2423
INFO - 2016-10-18 00:55:09 --> Config Class Initialized
INFO - 2016-10-18 00:55:09 --> Hooks Class Initialized
DEBUG - 2016-10-18 00:55:09 --> UTF-8 Support Enabled
INFO - 2016-10-18 00:55:09 --> Utf8 Class Initialized
INFO - 2016-10-18 00:55:09 --> URI Class Initialized
INFO - 2016-10-18 00:55:09 --> Router Class Initialized
INFO - 2016-10-18 00:55:09 --> Output Class Initialized
INFO - 2016-10-18 00:55:09 --> Security Class Initialized
DEBUG - 2016-10-18 00:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 00:55:09 --> Input Class Initialized
INFO - 2016-10-18 00:55:09 --> Language Class Initialized
INFO - 2016-10-18 00:55:09 --> Loader Class Initialized
INFO - 2016-10-18 00:55:10 --> Helper loaded: url_helper
INFO - 2016-10-18 00:55:10 --> Helper loaded: form_helper
INFO - 2016-10-18 00:55:10 --> Database Driver Class Initialized
INFO - 2016-10-18 00:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 00:55:10 --> Controller Class Initialized
INFO - 2016-10-18 00:55:10 --> Model Class Initialized
INFO - 2016-10-18 00:55:10 --> Final output sent to browser
DEBUG - 2016-10-18 00:55:10 --> Total execution time: 0.9827
INFO - 2016-10-18 00:55:10 --> Config Class Initialized
INFO - 2016-10-18 00:55:10 --> Hooks Class Initialized
DEBUG - 2016-10-18 00:55:10 --> UTF-8 Support Enabled
INFO - 2016-10-18 00:55:10 --> Utf8 Class Initialized
INFO - 2016-10-18 00:55:11 --> URI Class Initialized
DEBUG - 2016-10-18 00:55:11 --> No URI present. Default controller set.
INFO - 2016-10-18 00:55:11 --> Router Class Initialized
INFO - 2016-10-18 00:55:11 --> Output Class Initialized
INFO - 2016-10-18 00:55:11 --> Security Class Initialized
DEBUG - 2016-10-18 00:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 00:55:11 --> Input Class Initialized
INFO - 2016-10-18 00:55:11 --> Language Class Initialized
INFO - 2016-10-18 00:55:11 --> Loader Class Initialized
INFO - 2016-10-18 00:55:11 --> Helper loaded: url_helper
INFO - 2016-10-18 00:55:11 --> Helper loaded: form_helper
INFO - 2016-10-18 00:55:11 --> Database Driver Class Initialized
INFO - 2016-10-18 00:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 00:55:11 --> Controller Class Initialized
INFO - 2016-10-18 00:55:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-18 00:55:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-18 00:55:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-18 00:55:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-18 00:55:11 --> Final output sent to browser
DEBUG - 2016-10-18 00:55:11 --> Total execution time: 0.3402
INFO - 2016-10-18 00:55:34 --> Config Class Initialized
INFO - 2016-10-18 00:55:34 --> Hooks Class Initialized
DEBUG - 2016-10-18 00:55:34 --> UTF-8 Support Enabled
INFO - 2016-10-18 00:55:34 --> Utf8 Class Initialized
INFO - 2016-10-18 00:55:34 --> URI Class Initialized
INFO - 2016-10-18 00:55:34 --> Router Class Initialized
INFO - 2016-10-18 00:55:34 --> Output Class Initialized
INFO - 2016-10-18 00:55:34 --> Security Class Initialized
DEBUG - 2016-10-18 00:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 00:55:34 --> Input Class Initialized
INFO - 2016-10-18 00:55:34 --> Language Class Initialized
INFO - 2016-10-18 00:55:34 --> Loader Class Initialized
INFO - 2016-10-18 00:55:34 --> Helper loaded: url_helper
INFO - 2016-10-18 00:55:34 --> Helper loaded: form_helper
INFO - 2016-10-18 00:55:34 --> Database Driver Class Initialized
INFO - 2016-10-18 00:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 00:55:34 --> Controller Class Initialized
ERROR - 2016-10-18 00:55:34 --> Severity: Notice --> Undefined variable: name C:\xampp\htdocs\LMS\app\controllers\Auth.php 92
ERROR - 2016-10-18 00:55:34 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 92
INFO - 2016-10-18 00:55:34 --> Config Class Initialized
INFO - 2016-10-18 00:55:34 --> Hooks Class Initialized
DEBUG - 2016-10-18 00:55:34 --> UTF-8 Support Enabled
INFO - 2016-10-18 00:55:34 --> Utf8 Class Initialized
INFO - 2016-10-18 00:55:34 --> URI Class Initialized
DEBUG - 2016-10-18 00:55:34 --> No URI present. Default controller set.
INFO - 2016-10-18 00:55:34 --> Router Class Initialized
INFO - 2016-10-18 00:55:34 --> Output Class Initialized
INFO - 2016-10-18 00:55:34 --> Security Class Initialized
DEBUG - 2016-10-18 00:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 00:55:34 --> Input Class Initialized
INFO - 2016-10-18 00:55:34 --> Language Class Initialized
INFO - 2016-10-18 00:55:34 --> Loader Class Initialized
INFO - 2016-10-18 00:55:34 --> Helper loaded: url_helper
INFO - 2016-10-18 00:55:34 --> Helper loaded: form_helper
INFO - 2016-10-18 00:55:34 --> Database Driver Class Initialized
INFO - 2016-10-18 00:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 00:55:34 --> Controller Class Initialized
INFO - 2016-10-18 00:55:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-18 00:55:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-18 00:55:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-18 00:55:34 --> Final output sent to browser
DEBUG - 2016-10-18 00:55:34 --> Total execution time: 0.4805
INFO - 2016-10-18 00:55:47 --> Config Class Initialized
INFO - 2016-10-18 00:55:47 --> Hooks Class Initialized
DEBUG - 2016-10-18 00:55:47 --> UTF-8 Support Enabled
INFO - 2016-10-18 00:55:47 --> Utf8 Class Initialized
INFO - 2016-10-18 00:55:47 --> URI Class Initialized
INFO - 2016-10-18 00:55:47 --> Router Class Initialized
INFO - 2016-10-18 00:55:47 --> Output Class Initialized
INFO - 2016-10-18 00:55:47 --> Security Class Initialized
DEBUG - 2016-10-18 00:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 00:55:47 --> Input Class Initialized
INFO - 2016-10-18 00:55:47 --> Language Class Initialized
INFO - 2016-10-18 00:55:47 --> Loader Class Initialized
INFO - 2016-10-18 00:55:47 --> Helper loaded: url_helper
INFO - 2016-10-18 00:55:47 --> Helper loaded: form_helper
INFO - 2016-10-18 00:55:47 --> Database Driver Class Initialized
INFO - 2016-10-18 00:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 00:55:48 --> Controller Class Initialized
INFO - 2016-10-18 00:55:48 --> Model Class Initialized
INFO - 2016-10-18 00:55:48 --> Final output sent to browser
DEBUG - 2016-10-18 00:55:48 --> Total execution time: 0.2322
INFO - 2016-10-18 00:55:48 --> Config Class Initialized
INFO - 2016-10-18 00:55:48 --> Hooks Class Initialized
DEBUG - 2016-10-18 00:55:48 --> UTF-8 Support Enabled
INFO - 2016-10-18 00:55:48 --> Utf8 Class Initialized
INFO - 2016-10-18 00:55:48 --> URI Class Initialized
DEBUG - 2016-10-18 00:55:48 --> No URI present. Default controller set.
INFO - 2016-10-18 00:55:48 --> Router Class Initialized
INFO - 2016-10-18 00:55:48 --> Output Class Initialized
INFO - 2016-10-18 00:55:48 --> Security Class Initialized
DEBUG - 2016-10-18 00:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 00:55:48 --> Input Class Initialized
INFO - 2016-10-18 00:55:48 --> Language Class Initialized
INFO - 2016-10-18 00:55:48 --> Loader Class Initialized
INFO - 2016-10-18 00:55:48 --> Helper loaded: url_helper
INFO - 2016-10-18 00:55:48 --> Helper loaded: form_helper
INFO - 2016-10-18 00:55:48 --> Database Driver Class Initialized
INFO - 2016-10-18 00:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 00:55:48 --> Controller Class Initialized
INFO - 2016-10-18 00:55:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-18 00:55:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-18 00:55:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-18 00:55:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-18 00:55:48 --> Final output sent to browser
DEBUG - 2016-10-18 00:55:48 --> Total execution time: 0.2632
INFO - 2016-10-18 00:56:03 --> Config Class Initialized
INFO - 2016-10-18 00:56:03 --> Hooks Class Initialized
DEBUG - 2016-10-18 00:56:03 --> UTF-8 Support Enabled
INFO - 2016-10-18 00:56:03 --> Utf8 Class Initialized
INFO - 2016-10-18 00:56:03 --> URI Class Initialized
INFO - 2016-10-18 00:56:03 --> Router Class Initialized
INFO - 2016-10-18 00:56:03 --> Output Class Initialized
INFO - 2016-10-18 00:56:03 --> Security Class Initialized
DEBUG - 2016-10-18 00:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 00:56:03 --> Input Class Initialized
INFO - 2016-10-18 00:56:03 --> Language Class Initialized
INFO - 2016-10-18 00:56:03 --> Loader Class Initialized
INFO - 2016-10-18 00:56:03 --> Helper loaded: url_helper
INFO - 2016-10-18 00:56:03 --> Helper loaded: form_helper
INFO - 2016-10-18 00:56:03 --> Database Driver Class Initialized
INFO - 2016-10-18 00:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 00:56:03 --> Controller Class Initialized
ERROR - 2016-10-18 00:56:03 --> Severity: Notice --> Undefined variable: name C:\xampp\htdocs\LMS\app\controllers\Auth.php 92
ERROR - 2016-10-18 00:56:03 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 92
INFO - 2016-10-18 00:56:03 --> Config Class Initialized
INFO - 2016-10-18 00:56:03 --> Hooks Class Initialized
DEBUG - 2016-10-18 00:56:03 --> UTF-8 Support Enabled
INFO - 2016-10-18 00:56:03 --> Utf8 Class Initialized
INFO - 2016-10-18 00:56:03 --> URI Class Initialized
DEBUG - 2016-10-18 00:56:03 --> No URI present. Default controller set.
INFO - 2016-10-18 00:56:03 --> Router Class Initialized
INFO - 2016-10-18 00:56:03 --> Output Class Initialized
INFO - 2016-10-18 00:56:03 --> Security Class Initialized
DEBUG - 2016-10-18 00:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 00:56:03 --> Input Class Initialized
INFO - 2016-10-18 00:56:03 --> Language Class Initialized
INFO - 2016-10-18 00:56:03 --> Loader Class Initialized
INFO - 2016-10-18 00:56:03 --> Helper loaded: url_helper
INFO - 2016-10-18 00:56:03 --> Helper loaded: form_helper
INFO - 2016-10-18 00:56:03 --> Database Driver Class Initialized
INFO - 2016-10-18 00:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 00:56:03 --> Controller Class Initialized
INFO - 2016-10-18 00:56:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-18 00:56:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-18 00:56:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-18 00:56:03 --> Final output sent to browser
DEBUG - 2016-10-18 00:56:03 --> Total execution time: 0.2628
INFO - 2016-10-18 00:56:11 --> Config Class Initialized
INFO - 2016-10-18 00:56:11 --> Hooks Class Initialized
DEBUG - 2016-10-18 00:56:11 --> UTF-8 Support Enabled
INFO - 2016-10-18 00:56:11 --> Utf8 Class Initialized
INFO - 2016-10-18 00:56:11 --> URI Class Initialized
INFO - 2016-10-18 00:56:11 --> Router Class Initialized
INFO - 2016-10-18 00:56:11 --> Output Class Initialized
INFO - 2016-10-18 00:56:11 --> Security Class Initialized
DEBUG - 2016-10-18 00:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 00:56:11 --> Input Class Initialized
INFO - 2016-10-18 00:56:11 --> Language Class Initialized
INFO - 2016-10-18 00:56:11 --> Loader Class Initialized
INFO - 2016-10-18 00:56:11 --> Helper loaded: url_helper
INFO - 2016-10-18 00:56:11 --> Helper loaded: form_helper
INFO - 2016-10-18 00:56:11 --> Database Driver Class Initialized
INFO - 2016-10-18 00:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 00:56:11 --> Controller Class Initialized
INFO - 2016-10-18 00:56:11 --> Model Class Initialized
INFO - 2016-10-18 00:56:11 --> Final output sent to browser
DEBUG - 2016-10-18 00:56:11 --> Total execution time: 0.2716
INFO - 2016-10-18 00:56:11 --> Config Class Initialized
INFO - 2016-10-18 00:56:11 --> Hooks Class Initialized
DEBUG - 2016-10-18 00:56:11 --> UTF-8 Support Enabled
INFO - 2016-10-18 00:56:11 --> Utf8 Class Initialized
INFO - 2016-10-18 00:56:11 --> URI Class Initialized
DEBUG - 2016-10-18 00:56:11 --> No URI present. Default controller set.
INFO - 2016-10-18 00:56:11 --> Router Class Initialized
INFO - 2016-10-18 00:56:11 --> Output Class Initialized
INFO - 2016-10-18 00:56:11 --> Security Class Initialized
DEBUG - 2016-10-18 00:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 00:56:11 --> Input Class Initialized
INFO - 2016-10-18 00:56:11 --> Language Class Initialized
INFO - 2016-10-18 00:56:11 --> Loader Class Initialized
INFO - 2016-10-18 00:56:11 --> Helper loaded: url_helper
INFO - 2016-10-18 00:56:11 --> Helper loaded: form_helper
INFO - 2016-10-18 00:56:11 --> Database Driver Class Initialized
INFO - 2016-10-18 00:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 00:56:11 --> Controller Class Initialized
INFO - 2016-10-18 00:56:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-18 00:56:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-18 00:56:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-18 00:56:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-18 00:56:11 --> Final output sent to browser
DEBUG - 2016-10-18 00:56:11 --> Total execution time: 0.3054
INFO - 2016-10-18 00:56:32 --> Config Class Initialized
INFO - 2016-10-18 00:56:32 --> Hooks Class Initialized
DEBUG - 2016-10-18 00:56:32 --> UTF-8 Support Enabled
INFO - 2016-10-18 00:56:32 --> Utf8 Class Initialized
INFO - 2016-10-18 00:56:32 --> URI Class Initialized
INFO - 2016-10-18 00:56:32 --> Router Class Initialized
INFO - 2016-10-18 00:56:32 --> Output Class Initialized
INFO - 2016-10-18 00:56:32 --> Security Class Initialized
DEBUG - 2016-10-18 00:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 00:56:32 --> Input Class Initialized
INFO - 2016-10-18 00:56:32 --> Language Class Initialized
INFO - 2016-10-18 00:56:32 --> Loader Class Initialized
INFO - 2016-10-18 00:56:32 --> Helper loaded: url_helper
INFO - 2016-10-18 00:56:32 --> Helper loaded: form_helper
INFO - 2016-10-18 00:56:32 --> Database Driver Class Initialized
INFO - 2016-10-18 00:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 00:56:32 --> Controller Class Initialized
ERROR - 2016-10-18 00:56:32 --> Severity: Notice --> Undefined variable: name C:\xampp\htdocs\LMS\app\controllers\Auth.php 92
ERROR - 2016-10-18 00:56:32 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 92
INFO - 2016-10-18 00:56:32 --> Config Class Initialized
INFO - 2016-10-18 00:56:32 --> Hooks Class Initialized
DEBUG - 2016-10-18 00:56:32 --> UTF-8 Support Enabled
INFO - 2016-10-18 00:56:32 --> Utf8 Class Initialized
INFO - 2016-10-18 00:56:32 --> URI Class Initialized
DEBUG - 2016-10-18 00:56:32 --> No URI present. Default controller set.
INFO - 2016-10-18 00:56:32 --> Router Class Initialized
INFO - 2016-10-18 00:56:32 --> Output Class Initialized
INFO - 2016-10-18 00:56:32 --> Security Class Initialized
DEBUG - 2016-10-18 00:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 00:56:32 --> Input Class Initialized
INFO - 2016-10-18 00:56:32 --> Language Class Initialized
INFO - 2016-10-18 00:56:32 --> Loader Class Initialized
INFO - 2016-10-18 00:56:32 --> Helper loaded: url_helper
INFO - 2016-10-18 00:56:32 --> Helper loaded: form_helper
INFO - 2016-10-18 00:56:32 --> Database Driver Class Initialized
INFO - 2016-10-18 00:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 00:56:32 --> Controller Class Initialized
INFO - 2016-10-18 00:56:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-18 00:56:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-18 00:56:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-18 00:56:32 --> Final output sent to browser
DEBUG - 2016-10-18 00:56:32 --> Total execution time: 0.2714
INFO - 2016-10-18 00:56:40 --> Config Class Initialized
INFO - 2016-10-18 00:56:40 --> Hooks Class Initialized
DEBUG - 2016-10-18 00:56:40 --> UTF-8 Support Enabled
INFO - 2016-10-18 00:56:40 --> Utf8 Class Initialized
INFO - 2016-10-18 00:56:40 --> URI Class Initialized
INFO - 2016-10-18 00:56:40 --> Router Class Initialized
INFO - 2016-10-18 00:56:40 --> Output Class Initialized
INFO - 2016-10-18 00:56:40 --> Security Class Initialized
DEBUG - 2016-10-18 00:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 00:56:40 --> Input Class Initialized
INFO - 2016-10-18 00:56:40 --> Language Class Initialized
INFO - 2016-10-18 00:56:40 --> Loader Class Initialized
INFO - 2016-10-18 00:56:40 --> Helper loaded: url_helper
INFO - 2016-10-18 00:56:40 --> Helper loaded: form_helper
INFO - 2016-10-18 00:56:40 --> Database Driver Class Initialized
INFO - 2016-10-18 00:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 00:56:40 --> Controller Class Initialized
INFO - 2016-10-18 00:56:40 --> Model Class Initialized
INFO - 2016-10-18 00:56:40 --> Final output sent to browser
DEBUG - 2016-10-18 00:56:40 --> Total execution time: 0.2680
INFO - 2016-10-18 00:56:40 --> Config Class Initialized
INFO - 2016-10-18 00:56:40 --> Hooks Class Initialized
DEBUG - 2016-10-18 00:56:40 --> UTF-8 Support Enabled
INFO - 2016-10-18 00:56:40 --> Utf8 Class Initialized
INFO - 2016-10-18 00:56:40 --> URI Class Initialized
DEBUG - 2016-10-18 00:56:40 --> No URI present. Default controller set.
INFO - 2016-10-18 00:56:40 --> Router Class Initialized
INFO - 2016-10-18 00:56:40 --> Output Class Initialized
INFO - 2016-10-18 00:56:40 --> Security Class Initialized
DEBUG - 2016-10-18 00:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 00:56:40 --> Input Class Initialized
INFO - 2016-10-18 00:56:40 --> Language Class Initialized
INFO - 2016-10-18 00:56:40 --> Loader Class Initialized
INFO - 2016-10-18 00:56:40 --> Helper loaded: url_helper
INFO - 2016-10-18 00:56:40 --> Helper loaded: form_helper
INFO - 2016-10-18 00:56:40 --> Database Driver Class Initialized
INFO - 2016-10-18 00:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 00:56:40 --> Controller Class Initialized
INFO - 2016-10-18 00:56:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-18 00:56:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-18 00:56:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-18 00:56:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-18 00:56:40 --> Final output sent to browser
DEBUG - 2016-10-18 00:56:40 --> Total execution time: 0.2758
INFO - 2016-10-18 00:56:45 --> Config Class Initialized
INFO - 2016-10-18 00:56:45 --> Hooks Class Initialized
DEBUG - 2016-10-18 00:56:45 --> UTF-8 Support Enabled
INFO - 2016-10-18 00:56:45 --> Utf8 Class Initialized
INFO - 2016-10-18 00:56:45 --> URI Class Initialized
INFO - 2016-10-18 00:56:45 --> Router Class Initialized
INFO - 2016-10-18 00:56:45 --> Output Class Initialized
INFO - 2016-10-18 00:56:45 --> Security Class Initialized
DEBUG - 2016-10-18 00:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 00:56:45 --> Input Class Initialized
INFO - 2016-10-18 00:56:45 --> Language Class Initialized
INFO - 2016-10-18 00:56:45 --> Loader Class Initialized
INFO - 2016-10-18 00:56:45 --> Helper loaded: url_helper
INFO - 2016-10-18 00:56:45 --> Helper loaded: form_helper
INFO - 2016-10-18 00:56:45 --> Database Driver Class Initialized
INFO - 2016-10-18 00:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 00:56:45 --> Controller Class Initialized
INFO - 2016-10-18 00:56:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-18 00:56:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-18 00:56:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\leave/home.php
INFO - 2016-10-18 00:56:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-18 00:56:45 --> Final output sent to browser
DEBUG - 2016-10-18 00:56:45 --> Total execution time: 0.2628
INFO - 2016-10-18 00:56:47 --> Config Class Initialized
INFO - 2016-10-18 00:56:47 --> Hooks Class Initialized
DEBUG - 2016-10-18 00:56:47 --> UTF-8 Support Enabled
INFO - 2016-10-18 00:56:47 --> Utf8 Class Initialized
INFO - 2016-10-18 00:56:47 --> URI Class Initialized
DEBUG - 2016-10-18 00:56:47 --> No URI present. Default controller set.
INFO - 2016-10-18 00:56:47 --> Router Class Initialized
INFO - 2016-10-18 00:56:47 --> Output Class Initialized
INFO - 2016-10-18 00:56:47 --> Security Class Initialized
DEBUG - 2016-10-18 00:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 00:56:47 --> Input Class Initialized
INFO - 2016-10-18 00:56:47 --> Language Class Initialized
INFO - 2016-10-18 00:56:47 --> Loader Class Initialized
INFO - 2016-10-18 00:56:47 --> Helper loaded: url_helper
INFO - 2016-10-18 00:56:47 --> Helper loaded: form_helper
INFO - 2016-10-18 00:56:47 --> Database Driver Class Initialized
INFO - 2016-10-18 00:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 00:56:47 --> Controller Class Initialized
INFO - 2016-10-18 00:56:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-18 00:56:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-18 00:56:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-18 00:56:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-18 00:56:47 --> Final output sent to browser
DEBUG - 2016-10-18 00:56:48 --> Total execution time: 0.3206
INFO - 2016-10-18 00:56:51 --> Config Class Initialized
INFO - 2016-10-18 00:56:51 --> Hooks Class Initialized
DEBUG - 2016-10-18 00:56:51 --> UTF-8 Support Enabled
INFO - 2016-10-18 00:56:51 --> Utf8 Class Initialized
INFO - 2016-10-18 00:56:51 --> URI Class Initialized
INFO - 2016-10-18 00:56:51 --> Router Class Initialized
INFO - 2016-10-18 00:56:51 --> Output Class Initialized
INFO - 2016-10-18 00:56:51 --> Security Class Initialized
DEBUG - 2016-10-18 00:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 00:56:51 --> Input Class Initialized
INFO - 2016-10-18 00:56:51 --> Language Class Initialized
INFO - 2016-10-18 00:56:51 --> Loader Class Initialized
INFO - 2016-10-18 00:56:51 --> Helper loaded: url_helper
INFO - 2016-10-18 00:56:51 --> Helper loaded: form_helper
INFO - 2016-10-18 00:56:52 --> Database Driver Class Initialized
INFO - 2016-10-18 00:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 00:56:52 --> Controller Class Initialized
INFO - 2016-10-18 00:56:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-18 00:56:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-18 00:56:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\leave/home.php
INFO - 2016-10-18 00:56:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-18 00:56:52 --> Final output sent to browser
DEBUG - 2016-10-18 00:56:52 --> Total execution time: 0.2987
INFO - 2016-10-18 00:56:53 --> Config Class Initialized
INFO - 2016-10-18 00:56:53 --> Hooks Class Initialized
DEBUG - 2016-10-18 00:56:53 --> UTF-8 Support Enabled
INFO - 2016-10-18 00:56:53 --> Utf8 Class Initialized
INFO - 2016-10-18 00:56:53 --> URI Class Initialized
DEBUG - 2016-10-18 00:56:53 --> No URI present. Default controller set.
INFO - 2016-10-18 00:56:53 --> Router Class Initialized
INFO - 2016-10-18 00:56:53 --> Output Class Initialized
INFO - 2016-10-18 00:56:53 --> Security Class Initialized
DEBUG - 2016-10-18 00:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 00:56:53 --> Input Class Initialized
INFO - 2016-10-18 00:56:53 --> Language Class Initialized
INFO - 2016-10-18 00:56:53 --> Loader Class Initialized
INFO - 2016-10-18 00:56:53 --> Helper loaded: url_helper
INFO - 2016-10-18 00:56:53 --> Helper loaded: form_helper
INFO - 2016-10-18 00:56:53 --> Database Driver Class Initialized
INFO - 2016-10-18 00:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 00:56:53 --> Controller Class Initialized
INFO - 2016-10-18 00:56:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-18 00:56:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-18 00:56:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-18 00:56:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-18 00:56:53 --> Final output sent to browser
DEBUG - 2016-10-18 00:56:53 --> Total execution time: 0.3154
INFO - 2016-10-18 00:59:30 --> Config Class Initialized
INFO - 2016-10-18 00:59:30 --> Hooks Class Initialized
DEBUG - 2016-10-18 00:59:30 --> UTF-8 Support Enabled
INFO - 2016-10-18 00:59:30 --> Utf8 Class Initialized
INFO - 2016-10-18 00:59:30 --> URI Class Initialized
DEBUG - 2016-10-18 00:59:30 --> No URI present. Default controller set.
INFO - 2016-10-18 00:59:30 --> Router Class Initialized
INFO - 2016-10-18 00:59:30 --> Output Class Initialized
INFO - 2016-10-18 00:59:30 --> Security Class Initialized
DEBUG - 2016-10-18 00:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 00:59:30 --> Input Class Initialized
INFO - 2016-10-18 00:59:30 --> Language Class Initialized
INFO - 2016-10-18 00:59:30 --> Loader Class Initialized
INFO - 2016-10-18 00:59:30 --> Helper loaded: url_helper
INFO - 2016-10-18 00:59:30 --> Helper loaded: form_helper
INFO - 2016-10-18 00:59:30 --> Database Driver Class Initialized
INFO - 2016-10-18 00:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 00:59:30 --> Controller Class Initialized
INFO - 2016-10-18 00:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-18 00:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-18 00:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-18 00:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-18 00:59:30 --> Final output sent to browser
DEBUG - 2016-10-18 00:59:30 --> Total execution time: 0.2851
INFO - 2016-10-18 01:04:47 --> Config Class Initialized
INFO - 2016-10-18 01:04:47 --> Hooks Class Initialized
DEBUG - 2016-10-18 01:04:47 --> UTF-8 Support Enabled
INFO - 2016-10-18 01:04:47 --> Utf8 Class Initialized
INFO - 2016-10-18 01:04:47 --> URI Class Initialized
DEBUG - 2016-10-18 01:04:47 --> No URI present. Default controller set.
INFO - 2016-10-18 01:04:47 --> Router Class Initialized
INFO - 2016-10-18 01:04:47 --> Output Class Initialized
INFO - 2016-10-18 01:04:47 --> Security Class Initialized
DEBUG - 2016-10-18 01:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 01:04:47 --> Input Class Initialized
INFO - 2016-10-18 01:04:47 --> Language Class Initialized
INFO - 2016-10-18 01:04:47 --> Loader Class Initialized
INFO - 2016-10-18 01:04:47 --> Helper loaded: url_helper
INFO - 2016-10-18 01:04:47 --> Helper loaded: form_helper
INFO - 2016-10-18 01:04:47 --> Database Driver Class Initialized
INFO - 2016-10-18 01:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 01:04:47 --> Controller Class Initialized
INFO - 2016-10-18 01:04:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-18 01:04:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-18 01:04:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-18 01:04:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-18 01:04:47 --> Final output sent to browser
DEBUG - 2016-10-18 01:04:47 --> Total execution time: 0.2366
INFO - 2016-10-18 01:07:34 --> Config Class Initialized
INFO - 2016-10-18 01:07:34 --> Hooks Class Initialized
DEBUG - 2016-10-18 01:07:34 --> UTF-8 Support Enabled
INFO - 2016-10-18 01:07:34 --> Utf8 Class Initialized
INFO - 2016-10-18 01:07:34 --> URI Class Initialized
DEBUG - 2016-10-18 01:07:34 --> No URI present. Default controller set.
INFO - 2016-10-18 01:07:34 --> Router Class Initialized
INFO - 2016-10-18 01:07:34 --> Output Class Initialized
INFO - 2016-10-18 01:07:34 --> Security Class Initialized
DEBUG - 2016-10-18 01:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 01:07:34 --> Input Class Initialized
INFO - 2016-10-18 01:07:34 --> Language Class Initialized
INFO - 2016-10-18 01:07:34 --> Loader Class Initialized
INFO - 2016-10-18 01:07:34 --> Helper loaded: url_helper
INFO - 2016-10-18 01:07:34 --> Helper loaded: form_helper
INFO - 2016-10-18 01:07:34 --> Database Driver Class Initialized
INFO - 2016-10-18 01:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 01:07:34 --> Controller Class Initialized
INFO - 2016-10-18 01:07:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-18 01:07:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-18 01:07:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-18 01:07:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-18 01:07:34 --> Final output sent to browser
DEBUG - 2016-10-18 01:07:34 --> Total execution time: 0.2595
INFO - 2016-10-18 01:09:04 --> Config Class Initialized
INFO - 2016-10-18 01:09:04 --> Hooks Class Initialized
DEBUG - 2016-10-18 01:09:04 --> UTF-8 Support Enabled
INFO - 2016-10-18 01:09:04 --> Utf8 Class Initialized
INFO - 2016-10-18 01:09:04 --> URI Class Initialized
DEBUG - 2016-10-18 01:09:04 --> No URI present. Default controller set.
INFO - 2016-10-18 01:09:04 --> Router Class Initialized
INFO - 2016-10-18 01:09:04 --> Output Class Initialized
INFO - 2016-10-18 01:09:04 --> Security Class Initialized
DEBUG - 2016-10-18 01:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 01:09:04 --> Input Class Initialized
INFO - 2016-10-18 01:09:04 --> Language Class Initialized
INFO - 2016-10-18 01:09:04 --> Loader Class Initialized
INFO - 2016-10-18 01:09:04 --> Helper loaded: url_helper
INFO - 2016-10-18 01:09:04 --> Helper loaded: form_helper
INFO - 2016-10-18 01:09:04 --> Database Driver Class Initialized
INFO - 2016-10-18 01:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 01:09:04 --> Controller Class Initialized
INFO - 2016-10-18 01:09:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-18 01:09:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-18 01:09:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-18 01:09:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-18 01:09:04 --> Final output sent to browser
DEBUG - 2016-10-18 01:09:04 --> Total execution time: 0.2540
INFO - 2016-10-18 01:09:46 --> Config Class Initialized
INFO - 2016-10-18 01:09:46 --> Hooks Class Initialized
DEBUG - 2016-10-18 01:09:46 --> UTF-8 Support Enabled
INFO - 2016-10-18 01:09:46 --> Utf8 Class Initialized
INFO - 2016-10-18 01:09:46 --> URI Class Initialized
DEBUG - 2016-10-18 01:09:46 --> No URI present. Default controller set.
INFO - 2016-10-18 01:09:46 --> Router Class Initialized
INFO - 2016-10-18 01:09:46 --> Output Class Initialized
INFO - 2016-10-18 01:09:46 --> Security Class Initialized
DEBUG - 2016-10-18 01:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 01:09:46 --> Input Class Initialized
INFO - 2016-10-18 01:09:46 --> Language Class Initialized
INFO - 2016-10-18 01:09:46 --> Loader Class Initialized
INFO - 2016-10-18 01:09:46 --> Helper loaded: url_helper
INFO - 2016-10-18 01:09:46 --> Helper loaded: form_helper
INFO - 2016-10-18 01:09:46 --> Database Driver Class Initialized
INFO - 2016-10-18 01:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 01:09:47 --> Controller Class Initialized
INFO - 2016-10-18 01:09:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-18 01:09:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-18 01:09:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-18 01:09:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-18 01:09:47 --> Final output sent to browser
DEBUG - 2016-10-18 01:09:47 --> Total execution time: 0.3121
INFO - 2016-10-18 01:11:21 --> Config Class Initialized
INFO - 2016-10-18 01:11:21 --> Hooks Class Initialized
DEBUG - 2016-10-18 01:11:21 --> UTF-8 Support Enabled
INFO - 2016-10-18 01:11:21 --> Utf8 Class Initialized
INFO - 2016-10-18 01:11:21 --> URI Class Initialized
DEBUG - 2016-10-18 01:11:21 --> No URI present. Default controller set.
INFO - 2016-10-18 01:11:21 --> Router Class Initialized
INFO - 2016-10-18 01:11:21 --> Output Class Initialized
INFO - 2016-10-18 01:11:21 --> Security Class Initialized
DEBUG - 2016-10-18 01:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 01:11:21 --> Input Class Initialized
INFO - 2016-10-18 01:11:21 --> Language Class Initialized
INFO - 2016-10-18 01:11:21 --> Loader Class Initialized
INFO - 2016-10-18 01:11:21 --> Helper loaded: url_helper
INFO - 2016-10-18 01:11:21 --> Helper loaded: form_helper
INFO - 2016-10-18 01:11:21 --> Database Driver Class Initialized
INFO - 2016-10-18 01:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 01:11:21 --> Controller Class Initialized
INFO - 2016-10-18 01:11:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-18 01:11:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-18 01:11:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-18 01:11:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-18 01:11:21 --> Final output sent to browser
DEBUG - 2016-10-18 01:11:21 --> Total execution time: 0.2479
INFO - 2016-10-18 01:13:24 --> Config Class Initialized
INFO - 2016-10-18 01:13:24 --> Hooks Class Initialized
DEBUG - 2016-10-18 01:13:24 --> UTF-8 Support Enabled
INFO - 2016-10-18 01:13:24 --> Utf8 Class Initialized
INFO - 2016-10-18 01:13:24 --> URI Class Initialized
DEBUG - 2016-10-18 01:13:24 --> No URI present. Default controller set.
INFO - 2016-10-18 01:13:24 --> Router Class Initialized
INFO - 2016-10-18 01:13:24 --> Output Class Initialized
INFO - 2016-10-18 01:13:24 --> Security Class Initialized
DEBUG - 2016-10-18 01:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 01:13:24 --> Input Class Initialized
INFO - 2016-10-18 01:13:24 --> Language Class Initialized
INFO - 2016-10-18 01:13:24 --> Loader Class Initialized
INFO - 2016-10-18 01:13:24 --> Helper loaded: url_helper
INFO - 2016-10-18 01:13:24 --> Helper loaded: form_helper
INFO - 2016-10-18 01:13:24 --> Database Driver Class Initialized
INFO - 2016-10-18 01:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 01:13:24 --> Controller Class Initialized
INFO - 2016-10-18 01:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-18 01:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-18 01:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-18 01:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-18 01:13:24 --> Final output sent to browser
DEBUG - 2016-10-18 01:13:24 --> Total execution time: 0.2691
INFO - 2016-10-18 01:18:25 --> Config Class Initialized
INFO - 2016-10-18 01:18:25 --> Hooks Class Initialized
DEBUG - 2016-10-18 01:18:25 --> UTF-8 Support Enabled
INFO - 2016-10-18 01:18:25 --> Utf8 Class Initialized
INFO - 2016-10-18 01:18:25 --> URI Class Initialized
DEBUG - 2016-10-18 01:18:25 --> No URI present. Default controller set.
INFO - 2016-10-18 01:18:25 --> Router Class Initialized
INFO - 2016-10-18 01:18:25 --> Output Class Initialized
INFO - 2016-10-18 01:18:25 --> Security Class Initialized
DEBUG - 2016-10-18 01:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 01:18:25 --> Input Class Initialized
INFO - 2016-10-18 01:18:25 --> Language Class Initialized
INFO - 2016-10-18 01:18:25 --> Loader Class Initialized
INFO - 2016-10-18 01:18:25 --> Helper loaded: url_helper
INFO - 2016-10-18 01:18:25 --> Helper loaded: form_helper
INFO - 2016-10-18 01:18:25 --> Database Driver Class Initialized
INFO - 2016-10-18 01:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 01:18:25 --> Controller Class Initialized
INFO - 2016-10-18 01:18:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-18 01:18:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-18 01:18:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-18 01:18:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-18 01:18:26 --> Final output sent to browser
DEBUG - 2016-10-18 01:18:26 --> Total execution time: 0.2549
INFO - 2016-10-18 01:18:52 --> Config Class Initialized
INFO - 2016-10-18 01:18:53 --> Hooks Class Initialized
DEBUG - 2016-10-18 01:18:53 --> UTF-8 Support Enabled
INFO - 2016-10-18 01:18:53 --> Utf8 Class Initialized
INFO - 2016-10-18 01:18:53 --> URI Class Initialized
DEBUG - 2016-10-18 01:18:53 --> No URI present. Default controller set.
INFO - 2016-10-18 01:18:53 --> Router Class Initialized
INFO - 2016-10-18 01:18:53 --> Output Class Initialized
INFO - 2016-10-18 01:18:53 --> Security Class Initialized
DEBUG - 2016-10-18 01:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 01:18:53 --> Input Class Initialized
INFO - 2016-10-18 01:18:53 --> Language Class Initialized
INFO - 2016-10-18 01:18:53 --> Loader Class Initialized
INFO - 2016-10-18 01:18:53 --> Helper loaded: url_helper
INFO - 2016-10-18 01:18:53 --> Helper loaded: form_helper
INFO - 2016-10-18 01:18:53 --> Database Driver Class Initialized
INFO - 2016-10-18 01:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 01:18:53 --> Controller Class Initialized
INFO - 2016-10-18 01:18:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-18 01:18:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-18 01:18:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-18 01:18:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-18 01:18:53 --> Final output sent to browser
DEBUG - 2016-10-18 01:18:53 --> Total execution time: 0.2275
INFO - 2016-10-18 01:20:03 --> Config Class Initialized
INFO - 2016-10-18 01:20:03 --> Hooks Class Initialized
DEBUG - 2016-10-18 01:20:03 --> UTF-8 Support Enabled
INFO - 2016-10-18 01:20:03 --> Utf8 Class Initialized
INFO - 2016-10-18 01:20:03 --> URI Class Initialized
INFO - 2016-10-18 01:20:03 --> Router Class Initialized
INFO - 2016-10-18 01:20:03 --> Output Class Initialized
INFO - 2016-10-18 01:20:03 --> Security Class Initialized
DEBUG - 2016-10-18 01:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 01:20:03 --> Input Class Initialized
INFO - 2016-10-18 01:20:03 --> Language Class Initialized
INFO - 2016-10-18 01:20:03 --> Loader Class Initialized
INFO - 2016-10-18 01:20:03 --> Helper loaded: url_helper
INFO - 2016-10-18 01:20:03 --> Helper loaded: form_helper
INFO - 2016-10-18 01:20:03 --> Database Driver Class Initialized
INFO - 2016-10-18 01:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 01:20:03 --> Controller Class Initialized
ERROR - 2016-10-18 01:20:03 --> Severity: Notice --> Undefined variable: name C:\xampp\htdocs\LMS\app\controllers\Auth.php 92
ERROR - 2016-10-18 01:20:03 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 92
INFO - 2016-10-18 01:20:03 --> Config Class Initialized
INFO - 2016-10-18 01:20:03 --> Hooks Class Initialized
DEBUG - 2016-10-18 01:20:03 --> UTF-8 Support Enabled
INFO - 2016-10-18 01:20:03 --> Utf8 Class Initialized
INFO - 2016-10-18 01:20:03 --> URI Class Initialized
DEBUG - 2016-10-18 01:20:03 --> No URI present. Default controller set.
INFO - 2016-10-18 01:20:03 --> Router Class Initialized
INFO - 2016-10-18 01:20:03 --> Output Class Initialized
INFO - 2016-10-18 01:20:03 --> Security Class Initialized
DEBUG - 2016-10-18 01:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 01:20:03 --> Input Class Initialized
INFO - 2016-10-18 01:20:03 --> Language Class Initialized
INFO - 2016-10-18 01:20:03 --> Loader Class Initialized
INFO - 2016-10-18 01:20:03 --> Helper loaded: url_helper
INFO - 2016-10-18 01:20:03 --> Helper loaded: form_helper
INFO - 2016-10-18 01:20:03 --> Database Driver Class Initialized
INFO - 2016-10-18 01:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 01:20:03 --> Controller Class Initialized
INFO - 2016-10-18 01:20:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-18 01:20:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-18 01:20:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-18 01:20:03 --> Final output sent to browser
DEBUG - 2016-10-18 01:20:03 --> Total execution time: 0.2186
INFO - 2016-10-18 09:49:29 --> Config Class Initialized
INFO - 2016-10-18 09:49:29 --> Hooks Class Initialized
DEBUG - 2016-10-18 09:49:29 --> UTF-8 Support Enabled
INFO - 2016-10-18 09:49:29 --> Utf8 Class Initialized
INFO - 2016-10-18 09:49:29 --> URI Class Initialized
DEBUG - 2016-10-18 09:49:29 --> No URI present. Default controller set.
INFO - 2016-10-18 09:49:29 --> Router Class Initialized
INFO - 2016-10-18 09:49:29 --> Output Class Initialized
INFO - 2016-10-18 09:49:29 --> Security Class Initialized
DEBUG - 2016-10-18 09:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 09:49:29 --> Input Class Initialized
INFO - 2016-10-18 09:49:29 --> Language Class Initialized
INFO - 2016-10-18 09:49:29 --> Loader Class Initialized
INFO - 2016-10-18 09:49:29 --> Helper loaded: url_helper
INFO - 2016-10-18 09:49:29 --> Helper loaded: form_helper
INFO - 2016-10-18 09:49:29 --> Database Driver Class Initialized
ERROR - 2016-10-18 09:49:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-18 09:49:29 --> Unable to connect to the database
INFO - 2016-10-18 09:49:29 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-18 09:50:40 --> Config Class Initialized
INFO - 2016-10-18 09:50:40 --> Hooks Class Initialized
DEBUG - 2016-10-18 09:50:40 --> UTF-8 Support Enabled
INFO - 2016-10-18 09:50:40 --> Utf8 Class Initialized
INFO - 2016-10-18 09:50:40 --> URI Class Initialized
DEBUG - 2016-10-18 09:50:40 --> No URI present. Default controller set.
INFO - 2016-10-18 09:50:40 --> Router Class Initialized
INFO - 2016-10-18 09:50:40 --> Output Class Initialized
INFO - 2016-10-18 09:50:40 --> Security Class Initialized
DEBUG - 2016-10-18 09:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 09:50:40 --> Input Class Initialized
INFO - 2016-10-18 09:50:40 --> Language Class Initialized
INFO - 2016-10-18 09:50:40 --> Loader Class Initialized
INFO - 2016-10-18 09:50:40 --> Helper loaded: url_helper
INFO - 2016-10-18 09:50:40 --> Helper loaded: form_helper
INFO - 2016-10-18 09:50:40 --> Database Driver Class Initialized
INFO - 2016-10-18 09:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 09:50:40 --> Controller Class Initialized
INFO - 2016-10-18 09:50:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 09:50:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 09:50:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 09:50:40 --> Final output sent to browser
DEBUG - 2016-10-18 09:50:40 --> Total execution time: 0.0109
INFO - 2016-10-18 09:50:51 --> Config Class Initialized
INFO - 2016-10-18 09:50:51 --> Hooks Class Initialized
DEBUG - 2016-10-18 09:50:51 --> UTF-8 Support Enabled
INFO - 2016-10-18 09:50:51 --> Utf8 Class Initialized
INFO - 2016-10-18 09:50:51 --> URI Class Initialized
INFO - 2016-10-18 09:50:51 --> Router Class Initialized
INFO - 2016-10-18 09:50:51 --> Output Class Initialized
INFO - 2016-10-18 09:50:51 --> Security Class Initialized
DEBUG - 2016-10-18 09:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 09:50:51 --> Input Class Initialized
INFO - 2016-10-18 09:50:51 --> Language Class Initialized
INFO - 2016-10-18 09:50:51 --> Loader Class Initialized
INFO - 2016-10-18 09:50:51 --> Helper loaded: url_helper
INFO - 2016-10-18 09:50:51 --> Helper loaded: form_helper
INFO - 2016-10-18 09:50:51 --> Database Driver Class Initialized
INFO - 2016-10-18 09:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 09:50:51 --> Controller Class Initialized
INFO - 2016-10-18 09:50:51 --> Model Class Initialized
INFO - 2016-10-18 09:50:51 --> Final output sent to browser
DEBUG - 2016-10-18 09:50:51 --> Total execution time: 0.0110
INFO - 2016-10-18 09:50:51 --> Config Class Initialized
INFO - 2016-10-18 09:50:51 --> Hooks Class Initialized
DEBUG - 2016-10-18 09:50:51 --> UTF-8 Support Enabled
INFO - 2016-10-18 09:50:51 --> Utf8 Class Initialized
INFO - 2016-10-18 09:50:51 --> URI Class Initialized
DEBUG - 2016-10-18 09:50:51 --> No URI present. Default controller set.
INFO - 2016-10-18 09:50:51 --> Router Class Initialized
INFO - 2016-10-18 09:50:51 --> Output Class Initialized
INFO - 2016-10-18 09:50:51 --> Security Class Initialized
DEBUG - 2016-10-18 09:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 09:50:51 --> Input Class Initialized
INFO - 2016-10-18 09:50:51 --> Language Class Initialized
INFO - 2016-10-18 09:50:51 --> Loader Class Initialized
INFO - 2016-10-18 09:50:51 --> Helper loaded: url_helper
INFO - 2016-10-18 09:50:51 --> Helper loaded: form_helper
INFO - 2016-10-18 09:50:51 --> Database Driver Class Initialized
INFO - 2016-10-18 09:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 09:50:51 --> Controller Class Initialized
INFO - 2016-10-18 09:50:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 09:50:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 09:50:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 09:50:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 09:50:51 --> Final output sent to browser
DEBUG - 2016-10-18 09:50:51 --> Total execution time: 0.0053
INFO - 2016-10-18 09:51:16 --> Config Class Initialized
INFO - 2016-10-18 09:51:16 --> Hooks Class Initialized
DEBUG - 2016-10-18 09:51:16 --> UTF-8 Support Enabled
INFO - 2016-10-18 09:51:16 --> Utf8 Class Initialized
INFO - 2016-10-18 09:51:16 --> URI Class Initialized
DEBUG - 2016-10-18 09:51:16 --> No URI present. Default controller set.
INFO - 2016-10-18 09:51:16 --> Router Class Initialized
INFO - 2016-10-18 09:51:16 --> Output Class Initialized
INFO - 2016-10-18 09:51:16 --> Security Class Initialized
DEBUG - 2016-10-18 09:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 09:51:16 --> Input Class Initialized
INFO - 2016-10-18 09:51:16 --> Language Class Initialized
INFO - 2016-10-18 09:51:16 --> Loader Class Initialized
INFO - 2016-10-18 09:51:16 --> Helper loaded: url_helper
INFO - 2016-10-18 09:51:16 --> Helper loaded: form_helper
INFO - 2016-10-18 09:51:16 --> Database Driver Class Initialized
INFO - 2016-10-18 09:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 09:51:16 --> Controller Class Initialized
INFO - 2016-10-18 09:51:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 09:51:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 09:51:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 09:51:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 09:51:16 --> Final output sent to browser
DEBUG - 2016-10-18 09:51:16 --> Total execution time: 0.0056
INFO - 2016-10-18 09:53:45 --> Config Class Initialized
INFO - 2016-10-18 09:53:45 --> Hooks Class Initialized
DEBUG - 2016-10-18 09:53:45 --> UTF-8 Support Enabled
INFO - 2016-10-18 09:53:45 --> Utf8 Class Initialized
INFO - 2016-10-18 09:53:45 --> URI Class Initialized
DEBUG - 2016-10-18 09:53:45 --> No URI present. Default controller set.
INFO - 2016-10-18 09:53:45 --> Router Class Initialized
INFO - 2016-10-18 09:53:45 --> Output Class Initialized
INFO - 2016-10-18 09:53:45 --> Security Class Initialized
DEBUG - 2016-10-18 09:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 09:53:45 --> Input Class Initialized
INFO - 2016-10-18 09:53:45 --> Language Class Initialized
INFO - 2016-10-18 09:53:45 --> Loader Class Initialized
INFO - 2016-10-18 09:53:45 --> Helper loaded: url_helper
INFO - 2016-10-18 09:53:45 --> Helper loaded: form_helper
INFO - 2016-10-18 09:53:45 --> Database Driver Class Initialized
INFO - 2016-10-18 09:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 09:53:45 --> Controller Class Initialized
INFO - 2016-10-18 09:53:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
ERROR - 2016-10-18 09:53:45 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php 20
INFO - 2016-10-18 09:53:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 09:53:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 09:53:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 09:53:45 --> Final output sent to browser
DEBUG - 2016-10-18 09:53:45 --> Total execution time: 0.0090
INFO - 2016-10-18 09:53:54 --> Config Class Initialized
INFO - 2016-10-18 09:53:54 --> Hooks Class Initialized
DEBUG - 2016-10-18 09:53:54 --> UTF-8 Support Enabled
INFO - 2016-10-18 09:53:54 --> Utf8 Class Initialized
INFO - 2016-10-18 09:53:54 --> URI Class Initialized
DEBUG - 2016-10-18 09:53:54 --> No URI present. Default controller set.
INFO - 2016-10-18 09:53:54 --> Router Class Initialized
INFO - 2016-10-18 09:53:54 --> Output Class Initialized
INFO - 2016-10-18 09:53:54 --> Security Class Initialized
DEBUG - 2016-10-18 09:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 09:53:54 --> Input Class Initialized
INFO - 2016-10-18 09:53:54 --> Language Class Initialized
INFO - 2016-10-18 09:53:54 --> Loader Class Initialized
INFO - 2016-10-18 09:53:54 --> Helper loaded: url_helper
INFO - 2016-10-18 09:53:54 --> Helper loaded: form_helper
INFO - 2016-10-18 09:53:54 --> Database Driver Class Initialized
INFO - 2016-10-18 09:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 09:53:54 --> Controller Class Initialized
INFO - 2016-10-18 09:53:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
ERROR - 2016-10-18 09:53:54 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php 20
INFO - 2016-10-18 09:53:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 09:53:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 09:53:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 09:53:54 --> Final output sent to browser
DEBUG - 2016-10-18 09:53:54 --> Total execution time: 0.0090
INFO - 2016-10-18 09:57:29 --> Config Class Initialized
INFO - 2016-10-18 09:57:29 --> Hooks Class Initialized
DEBUG - 2016-10-18 09:57:29 --> UTF-8 Support Enabled
INFO - 2016-10-18 09:57:29 --> Utf8 Class Initialized
INFO - 2016-10-18 09:57:29 --> URI Class Initialized
DEBUG - 2016-10-18 09:57:29 --> No URI present. Default controller set.
INFO - 2016-10-18 09:57:29 --> Router Class Initialized
INFO - 2016-10-18 09:57:29 --> Output Class Initialized
INFO - 2016-10-18 09:57:29 --> Security Class Initialized
DEBUG - 2016-10-18 09:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 09:57:29 --> Input Class Initialized
INFO - 2016-10-18 09:57:29 --> Language Class Initialized
INFO - 2016-10-18 09:57:29 --> Loader Class Initialized
INFO - 2016-10-18 09:57:29 --> Helper loaded: url_helper
INFO - 2016-10-18 09:57:29 --> Helper loaded: form_helper
INFO - 2016-10-18 09:57:29 --> Database Driver Class Initialized
INFO - 2016-10-18 09:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 09:57:29 --> Controller Class Initialized
INFO - 2016-10-18 09:57:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
ERROR - 2016-10-18 09:57:29 --> Severity: Notice --> Undefined variable: name /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php 20
INFO - 2016-10-18 09:57:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 09:57:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 09:57:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 09:57:29 --> Final output sent to browser
DEBUG - 2016-10-18 09:57:29 --> Total execution time: 0.0087
INFO - 2016-10-18 09:57:31 --> Config Class Initialized
INFO - 2016-10-18 09:57:31 --> Hooks Class Initialized
DEBUG - 2016-10-18 09:57:31 --> UTF-8 Support Enabled
INFO - 2016-10-18 09:57:31 --> Utf8 Class Initialized
INFO - 2016-10-18 09:57:31 --> URI Class Initialized
DEBUG - 2016-10-18 09:57:31 --> No URI present. Default controller set.
INFO - 2016-10-18 09:57:31 --> Router Class Initialized
INFO - 2016-10-18 09:57:31 --> Output Class Initialized
INFO - 2016-10-18 09:57:31 --> Security Class Initialized
DEBUG - 2016-10-18 09:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 09:57:31 --> Input Class Initialized
INFO - 2016-10-18 09:57:31 --> Language Class Initialized
INFO - 2016-10-18 09:57:31 --> Loader Class Initialized
INFO - 2016-10-18 09:57:31 --> Helper loaded: url_helper
INFO - 2016-10-18 09:57:31 --> Helper loaded: form_helper
INFO - 2016-10-18 09:57:31 --> Database Driver Class Initialized
INFO - 2016-10-18 09:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 09:57:31 --> Controller Class Initialized
INFO - 2016-10-18 09:57:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
ERROR - 2016-10-18 09:57:31 --> Severity: Notice --> Undefined variable: name /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php 20
INFO - 2016-10-18 09:57:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 09:57:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 09:57:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 09:57:31 --> Final output sent to browser
DEBUG - 2016-10-18 09:57:31 --> Total execution time: 0.0054
INFO - 2016-10-18 10:08:31 --> Config Class Initialized
INFO - 2016-10-18 10:08:31 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:08:31 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:08:31 --> Utf8 Class Initialized
INFO - 2016-10-18 10:08:31 --> URI Class Initialized
DEBUG - 2016-10-18 10:08:31 --> No URI present. Default controller set.
INFO - 2016-10-18 10:08:31 --> Router Class Initialized
INFO - 2016-10-18 10:08:31 --> Output Class Initialized
INFO - 2016-10-18 10:08:31 --> Security Class Initialized
DEBUG - 2016-10-18 10:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:08:31 --> Input Class Initialized
INFO - 2016-10-18 10:08:31 --> Language Class Initialized
INFO - 2016-10-18 10:08:31 --> Loader Class Initialized
INFO - 2016-10-18 10:08:31 --> Helper loaded: url_helper
INFO - 2016-10-18 10:08:31 --> Helper loaded: form_helper
INFO - 2016-10-18 10:08:31 --> Database Driver Class Initialized
INFO - 2016-10-18 10:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:08:31 --> Controller Class Initialized
INFO - 2016-10-18 10:08:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
ERROR - 2016-10-18 10:08:31 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php 20
INFO - 2016-10-18 10:08:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:08:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:08:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:08:31 --> Final output sent to browser
DEBUG - 2016-10-18 10:08:31 --> Total execution time: 0.0079
INFO - 2016-10-18 10:08:33 --> Config Class Initialized
INFO - 2016-10-18 10:08:33 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:08:33 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:08:33 --> Utf8 Class Initialized
INFO - 2016-10-18 10:08:33 --> URI Class Initialized
DEBUG - 2016-10-18 10:08:33 --> No URI present. Default controller set.
INFO - 2016-10-18 10:08:33 --> Router Class Initialized
INFO - 2016-10-18 10:08:33 --> Output Class Initialized
INFO - 2016-10-18 10:08:33 --> Security Class Initialized
DEBUG - 2016-10-18 10:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:08:33 --> Input Class Initialized
INFO - 2016-10-18 10:08:33 --> Language Class Initialized
INFO - 2016-10-18 10:08:33 --> Loader Class Initialized
INFO - 2016-10-18 10:08:33 --> Helper loaded: url_helper
INFO - 2016-10-18 10:08:33 --> Helper loaded: form_helper
INFO - 2016-10-18 10:08:33 --> Database Driver Class Initialized
INFO - 2016-10-18 10:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:08:33 --> Controller Class Initialized
INFO - 2016-10-18 10:08:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
ERROR - 2016-10-18 10:08:33 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php 20
INFO - 2016-10-18 10:08:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:08:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:08:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:08:33 --> Final output sent to browser
DEBUG - 2016-10-18 10:08:33 --> Total execution time: 0.0114
INFO - 2016-10-18 10:08:35 --> Config Class Initialized
INFO - 2016-10-18 10:08:35 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:08:35 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:08:35 --> Utf8 Class Initialized
INFO - 2016-10-18 10:08:35 --> URI Class Initialized
DEBUG - 2016-10-18 10:08:35 --> No URI present. Default controller set.
INFO - 2016-10-18 10:08:35 --> Router Class Initialized
INFO - 2016-10-18 10:08:35 --> Output Class Initialized
INFO - 2016-10-18 10:08:35 --> Security Class Initialized
DEBUG - 2016-10-18 10:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:08:35 --> Input Class Initialized
INFO - 2016-10-18 10:08:35 --> Language Class Initialized
INFO - 2016-10-18 10:08:35 --> Loader Class Initialized
INFO - 2016-10-18 10:08:35 --> Helper loaded: url_helper
INFO - 2016-10-18 10:08:35 --> Helper loaded: form_helper
INFO - 2016-10-18 10:08:35 --> Database Driver Class Initialized
INFO - 2016-10-18 10:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:08:35 --> Controller Class Initialized
INFO - 2016-10-18 10:08:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
ERROR - 2016-10-18 10:08:35 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php 20
INFO - 2016-10-18 10:08:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:08:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:08:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:08:35 --> Final output sent to browser
DEBUG - 2016-10-18 10:08:35 --> Total execution time: 0.0045
INFO - 2016-10-18 10:11:09 --> Config Class Initialized
INFO - 2016-10-18 10:11:09 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:11:09 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:11:09 --> Utf8 Class Initialized
INFO - 2016-10-18 10:11:09 --> URI Class Initialized
DEBUG - 2016-10-18 10:11:09 --> No URI present. Default controller set.
INFO - 2016-10-18 10:11:09 --> Router Class Initialized
INFO - 2016-10-18 10:11:09 --> Output Class Initialized
INFO - 2016-10-18 10:11:09 --> Security Class Initialized
DEBUG - 2016-10-18 10:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:11:09 --> Input Class Initialized
INFO - 2016-10-18 10:11:09 --> Language Class Initialized
INFO - 2016-10-18 10:11:09 --> Loader Class Initialized
INFO - 2016-10-18 10:11:09 --> Helper loaded: url_helper
INFO - 2016-10-18 10:11:09 --> Helper loaded: form_helper
INFO - 2016-10-18 10:11:09 --> Database Driver Class Initialized
INFO - 2016-10-18 10:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:11:09 --> Controller Class Initialized
INFO - 2016-10-18 10:11:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
ERROR - 2016-10-18 10:11:09 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php 20
INFO - 2016-10-18 10:11:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:11:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:11:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:11:09 --> Final output sent to browser
DEBUG - 2016-10-18 10:11:09 --> Total execution time: 0.0073
INFO - 2016-10-18 10:11:11 --> Config Class Initialized
INFO - 2016-10-18 10:11:11 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:11:11 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:11:11 --> Utf8 Class Initialized
INFO - 2016-10-18 10:11:11 --> URI Class Initialized
DEBUG - 2016-10-18 10:11:11 --> No URI present. Default controller set.
INFO - 2016-10-18 10:11:11 --> Router Class Initialized
INFO - 2016-10-18 10:11:11 --> Output Class Initialized
INFO - 2016-10-18 10:11:11 --> Security Class Initialized
DEBUG - 2016-10-18 10:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:11:11 --> Input Class Initialized
INFO - 2016-10-18 10:11:11 --> Language Class Initialized
INFO - 2016-10-18 10:11:11 --> Loader Class Initialized
INFO - 2016-10-18 10:11:11 --> Helper loaded: url_helper
INFO - 2016-10-18 10:11:11 --> Helper loaded: form_helper
INFO - 2016-10-18 10:11:11 --> Database Driver Class Initialized
INFO - 2016-10-18 10:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:11:11 --> Controller Class Initialized
INFO - 2016-10-18 10:11:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
ERROR - 2016-10-18 10:11:11 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php 20
INFO - 2016-10-18 10:11:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:11:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:11:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:11:11 --> Final output sent to browser
DEBUG - 2016-10-18 10:11:11 --> Total execution time: 0.0054
INFO - 2016-10-18 10:12:47 --> Config Class Initialized
INFO - 2016-10-18 10:12:47 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:12:47 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:12:47 --> Utf8 Class Initialized
INFO - 2016-10-18 10:12:47 --> URI Class Initialized
DEBUG - 2016-10-18 10:12:47 --> No URI present. Default controller set.
INFO - 2016-10-18 10:12:47 --> Router Class Initialized
INFO - 2016-10-18 10:12:47 --> Output Class Initialized
INFO - 2016-10-18 10:12:47 --> Security Class Initialized
DEBUG - 2016-10-18 10:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:12:47 --> Input Class Initialized
INFO - 2016-10-18 10:12:47 --> Language Class Initialized
INFO - 2016-10-18 10:12:47 --> Loader Class Initialized
INFO - 2016-10-18 10:12:47 --> Helper loaded: url_helper
INFO - 2016-10-18 10:12:47 --> Helper loaded: form_helper
INFO - 2016-10-18 10:12:47 --> Database Driver Class Initialized
INFO - 2016-10-18 10:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:12:47 --> Controller Class Initialized
INFO - 2016-10-18 10:12:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
ERROR - 2016-10-18 10:12:47 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php 20
INFO - 2016-10-18 10:12:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:12:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:12:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:12:47 --> Final output sent to browser
DEBUG - 2016-10-18 10:12:47 --> Total execution time: 0.0092
INFO - 2016-10-18 10:12:49 --> Config Class Initialized
INFO - 2016-10-18 10:12:49 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:12:49 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:12:49 --> Utf8 Class Initialized
INFO - 2016-10-18 10:12:49 --> URI Class Initialized
DEBUG - 2016-10-18 10:12:49 --> No URI present. Default controller set.
INFO - 2016-10-18 10:12:49 --> Router Class Initialized
INFO - 2016-10-18 10:12:49 --> Output Class Initialized
INFO - 2016-10-18 10:12:49 --> Security Class Initialized
DEBUG - 2016-10-18 10:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:12:49 --> Input Class Initialized
INFO - 2016-10-18 10:12:49 --> Language Class Initialized
INFO - 2016-10-18 10:12:49 --> Loader Class Initialized
INFO - 2016-10-18 10:12:49 --> Helper loaded: url_helper
INFO - 2016-10-18 10:12:49 --> Helper loaded: form_helper
INFO - 2016-10-18 10:12:49 --> Database Driver Class Initialized
INFO - 2016-10-18 10:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:12:49 --> Controller Class Initialized
INFO - 2016-10-18 10:12:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
ERROR - 2016-10-18 10:12:49 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php 20
INFO - 2016-10-18 10:12:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:12:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:12:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:12:49 --> Final output sent to browser
DEBUG - 2016-10-18 10:12:49 --> Total execution time: 0.0057
INFO - 2016-10-18 10:12:49 --> Config Class Initialized
INFO - 2016-10-18 10:12:49 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:12:49 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:12:49 --> Utf8 Class Initialized
INFO - 2016-10-18 10:12:49 --> URI Class Initialized
DEBUG - 2016-10-18 10:12:49 --> No URI present. Default controller set.
INFO - 2016-10-18 10:12:49 --> Router Class Initialized
INFO - 2016-10-18 10:12:49 --> Output Class Initialized
INFO - 2016-10-18 10:12:49 --> Security Class Initialized
DEBUG - 2016-10-18 10:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:12:49 --> Input Class Initialized
INFO - 2016-10-18 10:12:49 --> Language Class Initialized
INFO - 2016-10-18 10:12:49 --> Loader Class Initialized
INFO - 2016-10-18 10:12:49 --> Helper loaded: url_helper
INFO - 2016-10-18 10:12:49 --> Helper loaded: form_helper
INFO - 2016-10-18 10:12:49 --> Database Driver Class Initialized
INFO - 2016-10-18 10:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:12:49 --> Controller Class Initialized
INFO - 2016-10-18 10:12:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
ERROR - 2016-10-18 10:12:49 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php 20
INFO - 2016-10-18 10:12:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:12:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:12:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:12:49 --> Final output sent to browser
DEBUG - 2016-10-18 10:12:49 --> Total execution time: 0.0046
INFO - 2016-10-18 10:15:19 --> Config Class Initialized
INFO - 2016-10-18 10:15:19 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:15:19 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:15:19 --> Utf8 Class Initialized
INFO - 2016-10-18 10:15:19 --> URI Class Initialized
DEBUG - 2016-10-18 10:15:19 --> No URI present. Default controller set.
INFO - 2016-10-18 10:15:19 --> Router Class Initialized
INFO - 2016-10-18 10:15:19 --> Output Class Initialized
INFO - 2016-10-18 10:15:19 --> Security Class Initialized
DEBUG - 2016-10-18 10:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:15:19 --> Input Class Initialized
INFO - 2016-10-18 10:15:19 --> Language Class Initialized
INFO - 2016-10-18 10:15:19 --> Loader Class Initialized
INFO - 2016-10-18 10:15:19 --> Helper loaded: url_helper
INFO - 2016-10-18 10:15:19 --> Helper loaded: form_helper
INFO - 2016-10-18 10:15:19 --> Database Driver Class Initialized
INFO - 2016-10-18 10:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:15:19 --> Controller Class Initialized
INFO - 2016-10-18 10:15:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
ERROR - 2016-10-18 10:15:19 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php 20
INFO - 2016-10-18 10:15:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:15:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:15:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:15:19 --> Final output sent to browser
DEBUG - 2016-10-18 10:15:19 --> Total execution time: 0.0087
INFO - 2016-10-18 10:15:20 --> Config Class Initialized
INFO - 2016-10-18 10:15:20 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:15:20 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:15:20 --> Utf8 Class Initialized
INFO - 2016-10-18 10:15:20 --> URI Class Initialized
DEBUG - 2016-10-18 10:15:20 --> No URI present. Default controller set.
INFO - 2016-10-18 10:15:20 --> Router Class Initialized
INFO - 2016-10-18 10:15:20 --> Output Class Initialized
INFO - 2016-10-18 10:15:20 --> Security Class Initialized
DEBUG - 2016-10-18 10:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:15:20 --> Input Class Initialized
INFO - 2016-10-18 10:15:20 --> Language Class Initialized
INFO - 2016-10-18 10:15:20 --> Loader Class Initialized
INFO - 2016-10-18 10:15:20 --> Helper loaded: url_helper
INFO - 2016-10-18 10:15:20 --> Helper loaded: form_helper
INFO - 2016-10-18 10:15:20 --> Database Driver Class Initialized
INFO - 2016-10-18 10:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:15:20 --> Controller Class Initialized
INFO - 2016-10-18 10:15:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
ERROR - 2016-10-18 10:15:20 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php 20
INFO - 2016-10-18 10:15:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:15:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:15:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:15:20 --> Final output sent to browser
DEBUG - 2016-10-18 10:15:20 --> Total execution time: 0.0086
INFO - 2016-10-18 10:15:21 --> Config Class Initialized
INFO - 2016-10-18 10:15:21 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:15:21 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:15:21 --> Utf8 Class Initialized
INFO - 2016-10-18 10:15:21 --> URI Class Initialized
DEBUG - 2016-10-18 10:15:21 --> No URI present. Default controller set.
INFO - 2016-10-18 10:15:21 --> Router Class Initialized
INFO - 2016-10-18 10:15:21 --> Output Class Initialized
INFO - 2016-10-18 10:15:21 --> Security Class Initialized
DEBUG - 2016-10-18 10:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:15:21 --> Input Class Initialized
INFO - 2016-10-18 10:15:21 --> Language Class Initialized
INFO - 2016-10-18 10:15:21 --> Loader Class Initialized
INFO - 2016-10-18 10:15:21 --> Helper loaded: url_helper
INFO - 2016-10-18 10:15:21 --> Helper loaded: form_helper
INFO - 2016-10-18 10:15:21 --> Database Driver Class Initialized
INFO - 2016-10-18 10:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:15:21 --> Controller Class Initialized
INFO - 2016-10-18 10:15:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
ERROR - 2016-10-18 10:15:21 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php 20
INFO - 2016-10-18 10:15:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:15:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:15:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:15:21 --> Final output sent to browser
DEBUG - 2016-10-18 10:15:21 --> Total execution time: 0.0047
INFO - 2016-10-18 10:23:27 --> Config Class Initialized
INFO - 2016-10-18 10:23:27 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:23:27 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:23:27 --> Utf8 Class Initialized
INFO - 2016-10-18 10:23:27 --> URI Class Initialized
DEBUG - 2016-10-18 10:23:27 --> No URI present. Default controller set.
INFO - 2016-10-18 10:23:27 --> Router Class Initialized
INFO - 2016-10-18 10:23:27 --> Output Class Initialized
INFO - 2016-10-18 10:23:27 --> Security Class Initialized
DEBUG - 2016-10-18 10:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:23:27 --> Input Class Initialized
INFO - 2016-10-18 10:23:27 --> Language Class Initialized
INFO - 2016-10-18 10:23:27 --> Loader Class Initialized
INFO - 2016-10-18 10:23:27 --> Helper loaded: url_helper
INFO - 2016-10-18 10:23:27 --> Helper loaded: form_helper
INFO - 2016-10-18 10:23:27 --> Database Driver Class Initialized
INFO - 2016-10-18 10:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:23:27 --> Controller Class Initialized
INFO - 2016-10-18 10:23:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
ERROR - 2016-10-18 10:23:27 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php 20
INFO - 2016-10-18 10:23:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:23:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:23:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:23:27 --> Final output sent to browser
DEBUG - 2016-10-18 10:23:27 --> Total execution time: 0.0100
INFO - 2016-10-18 10:23:28 --> Config Class Initialized
INFO - 2016-10-18 10:23:28 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:23:28 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:23:28 --> Utf8 Class Initialized
INFO - 2016-10-18 10:23:28 --> URI Class Initialized
DEBUG - 2016-10-18 10:23:28 --> No URI present. Default controller set.
INFO - 2016-10-18 10:23:28 --> Router Class Initialized
INFO - 2016-10-18 10:23:28 --> Output Class Initialized
INFO - 2016-10-18 10:23:28 --> Security Class Initialized
DEBUG - 2016-10-18 10:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:23:28 --> Input Class Initialized
INFO - 2016-10-18 10:23:28 --> Language Class Initialized
INFO - 2016-10-18 10:23:28 --> Loader Class Initialized
INFO - 2016-10-18 10:23:28 --> Helper loaded: url_helper
INFO - 2016-10-18 10:23:28 --> Helper loaded: form_helper
INFO - 2016-10-18 10:23:28 --> Database Driver Class Initialized
INFO - 2016-10-18 10:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:23:28 --> Controller Class Initialized
INFO - 2016-10-18 10:23:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
ERROR - 2016-10-18 10:23:28 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php 20
INFO - 2016-10-18 10:23:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:23:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:23:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:23:28 --> Final output sent to browser
DEBUG - 2016-10-18 10:23:28 --> Total execution time: 0.0050
INFO - 2016-10-18 10:23:29 --> Config Class Initialized
INFO - 2016-10-18 10:23:29 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:23:29 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:23:29 --> Utf8 Class Initialized
INFO - 2016-10-18 10:23:29 --> URI Class Initialized
DEBUG - 2016-10-18 10:23:29 --> No URI present. Default controller set.
INFO - 2016-10-18 10:23:29 --> Router Class Initialized
INFO - 2016-10-18 10:23:29 --> Output Class Initialized
INFO - 2016-10-18 10:23:29 --> Security Class Initialized
DEBUG - 2016-10-18 10:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:23:29 --> Input Class Initialized
INFO - 2016-10-18 10:23:29 --> Language Class Initialized
INFO - 2016-10-18 10:23:29 --> Loader Class Initialized
INFO - 2016-10-18 10:23:29 --> Helper loaded: url_helper
INFO - 2016-10-18 10:23:29 --> Helper loaded: form_helper
INFO - 2016-10-18 10:23:29 --> Database Driver Class Initialized
INFO - 2016-10-18 10:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:23:29 --> Controller Class Initialized
INFO - 2016-10-18 10:23:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
ERROR - 2016-10-18 10:23:29 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php 20
INFO - 2016-10-18 10:23:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:23:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:23:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:23:29 --> Final output sent to browser
DEBUG - 2016-10-18 10:23:29 --> Total execution time: 0.0051
INFO - 2016-10-18 10:23:29 --> Config Class Initialized
INFO - 2016-10-18 10:23:29 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:23:29 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:23:29 --> Utf8 Class Initialized
INFO - 2016-10-18 10:23:29 --> URI Class Initialized
DEBUG - 2016-10-18 10:23:29 --> No URI present. Default controller set.
INFO - 2016-10-18 10:23:29 --> Router Class Initialized
INFO - 2016-10-18 10:23:29 --> Output Class Initialized
INFO - 2016-10-18 10:23:29 --> Security Class Initialized
DEBUG - 2016-10-18 10:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:23:29 --> Input Class Initialized
INFO - 2016-10-18 10:23:29 --> Language Class Initialized
INFO - 2016-10-18 10:23:29 --> Loader Class Initialized
INFO - 2016-10-18 10:23:29 --> Helper loaded: url_helper
INFO - 2016-10-18 10:23:29 --> Helper loaded: form_helper
INFO - 2016-10-18 10:23:29 --> Database Driver Class Initialized
INFO - 2016-10-18 10:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:23:29 --> Controller Class Initialized
INFO - 2016-10-18 10:23:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
ERROR - 2016-10-18 10:23:29 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php 20
INFO - 2016-10-18 10:23:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:23:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:23:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:23:29 --> Final output sent to browser
DEBUG - 2016-10-18 10:23:29 --> Total execution time: 0.0057
INFO - 2016-10-18 10:24:19 --> Config Class Initialized
INFO - 2016-10-18 10:24:19 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:24:19 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:24:19 --> Utf8 Class Initialized
INFO - 2016-10-18 10:24:19 --> URI Class Initialized
DEBUG - 2016-10-18 10:24:19 --> No URI present. Default controller set.
INFO - 2016-10-18 10:24:19 --> Router Class Initialized
INFO - 2016-10-18 10:24:19 --> Output Class Initialized
INFO - 2016-10-18 10:24:19 --> Security Class Initialized
DEBUG - 2016-10-18 10:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:24:19 --> Input Class Initialized
INFO - 2016-10-18 10:24:19 --> Language Class Initialized
INFO - 2016-10-18 10:24:19 --> Loader Class Initialized
INFO - 2016-10-18 10:24:19 --> Helper loaded: url_helper
INFO - 2016-10-18 10:24:19 --> Helper loaded: form_helper
INFO - 2016-10-18 10:24:19 --> Database Driver Class Initialized
INFO - 2016-10-18 10:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:24:19 --> Controller Class Initialized
INFO - 2016-10-18 10:24:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 10:24:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:24:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:24:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:24:19 --> Final output sent to browser
DEBUG - 2016-10-18 10:24:19 --> Total execution time: 0.0061
INFO - 2016-10-18 10:24:22 --> Config Class Initialized
INFO - 2016-10-18 10:24:22 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:24:22 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:24:22 --> Utf8 Class Initialized
INFO - 2016-10-18 10:24:22 --> URI Class Initialized
DEBUG - 2016-10-18 10:24:22 --> No URI present. Default controller set.
INFO - 2016-10-18 10:24:22 --> Router Class Initialized
INFO - 2016-10-18 10:24:22 --> Output Class Initialized
INFO - 2016-10-18 10:24:22 --> Security Class Initialized
DEBUG - 2016-10-18 10:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:24:22 --> Input Class Initialized
INFO - 2016-10-18 10:24:22 --> Language Class Initialized
INFO - 2016-10-18 10:24:22 --> Loader Class Initialized
INFO - 2016-10-18 10:24:22 --> Helper loaded: url_helper
INFO - 2016-10-18 10:24:22 --> Helper loaded: form_helper
INFO - 2016-10-18 10:24:22 --> Database Driver Class Initialized
INFO - 2016-10-18 10:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:24:22 --> Controller Class Initialized
INFO - 2016-10-18 10:24:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 10:24:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:24:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:24:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:24:22 --> Final output sent to browser
DEBUG - 2016-10-18 10:24:22 --> Total execution time: 0.0045
INFO - 2016-10-18 10:25:48 --> Config Class Initialized
INFO - 2016-10-18 10:25:48 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:25:48 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:25:48 --> Utf8 Class Initialized
INFO - 2016-10-18 10:25:48 --> URI Class Initialized
DEBUG - 2016-10-18 10:25:48 --> No URI present. Default controller set.
INFO - 2016-10-18 10:25:48 --> Router Class Initialized
INFO - 2016-10-18 10:25:48 --> Output Class Initialized
INFO - 2016-10-18 10:25:48 --> Security Class Initialized
DEBUG - 2016-10-18 10:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:25:48 --> Input Class Initialized
INFO - 2016-10-18 10:25:48 --> Language Class Initialized
INFO - 2016-10-18 10:25:48 --> Loader Class Initialized
INFO - 2016-10-18 10:25:48 --> Helper loaded: url_helper
INFO - 2016-10-18 10:25:48 --> Helper loaded: form_helper
INFO - 2016-10-18 10:25:48 --> Database Driver Class Initialized
INFO - 2016-10-18 10:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:25:48 --> Controller Class Initialized
INFO - 2016-10-18 10:25:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
ERROR - 2016-10-18 10:25:48 --> Severity: Notice --> Undefined variable: userName /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php 20
INFO - 2016-10-18 10:25:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:25:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:25:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:25:48 --> Final output sent to browser
DEBUG - 2016-10-18 10:25:48 --> Total execution time: 0.0060
INFO - 2016-10-18 10:25:55 --> Config Class Initialized
INFO - 2016-10-18 10:25:55 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:25:55 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:25:55 --> Utf8 Class Initialized
INFO - 2016-10-18 10:25:55 --> URI Class Initialized
DEBUG - 2016-10-18 10:25:55 --> No URI present. Default controller set.
INFO - 2016-10-18 10:25:55 --> Router Class Initialized
INFO - 2016-10-18 10:25:55 --> Output Class Initialized
INFO - 2016-10-18 10:25:55 --> Security Class Initialized
DEBUG - 2016-10-18 10:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:25:55 --> Input Class Initialized
INFO - 2016-10-18 10:25:55 --> Language Class Initialized
INFO - 2016-10-18 10:25:55 --> Loader Class Initialized
INFO - 2016-10-18 10:25:55 --> Helper loaded: url_helper
INFO - 2016-10-18 10:25:55 --> Helper loaded: form_helper
INFO - 2016-10-18 10:25:55 --> Database Driver Class Initialized
INFO - 2016-10-18 10:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:25:55 --> Controller Class Initialized
INFO - 2016-10-18 10:25:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 10:25:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:25:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:25:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:25:55 --> Final output sent to browser
DEBUG - 2016-10-18 10:25:55 --> Total execution time: 0.0051
INFO - 2016-10-18 10:26:29 --> Config Class Initialized
INFO - 2016-10-18 10:26:29 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:26:29 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:26:29 --> Utf8 Class Initialized
INFO - 2016-10-18 10:26:29 --> URI Class Initialized
DEBUG - 2016-10-18 10:26:29 --> No URI present. Default controller set.
INFO - 2016-10-18 10:26:29 --> Router Class Initialized
INFO - 2016-10-18 10:26:29 --> Output Class Initialized
INFO - 2016-10-18 10:26:29 --> Security Class Initialized
DEBUG - 2016-10-18 10:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:26:29 --> Input Class Initialized
INFO - 2016-10-18 10:26:29 --> Language Class Initialized
INFO - 2016-10-18 10:26:29 --> Loader Class Initialized
INFO - 2016-10-18 10:26:29 --> Helper loaded: url_helper
INFO - 2016-10-18 10:26:29 --> Helper loaded: form_helper
INFO - 2016-10-18 10:26:29 --> Database Driver Class Initialized
INFO - 2016-10-18 10:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:26:29 --> Controller Class Initialized
INFO - 2016-10-18 10:26:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 10:26:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:26:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:26:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:26:29 --> Final output sent to browser
DEBUG - 2016-10-18 10:26:29 --> Total execution time: 0.0054
INFO - 2016-10-18 10:27:36 --> Config Class Initialized
INFO - 2016-10-18 10:27:36 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:27:36 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:27:36 --> Utf8 Class Initialized
INFO - 2016-10-18 10:27:36 --> URI Class Initialized
DEBUG - 2016-10-18 10:27:36 --> No URI present. Default controller set.
INFO - 2016-10-18 10:27:36 --> Router Class Initialized
INFO - 2016-10-18 10:27:36 --> Output Class Initialized
INFO - 2016-10-18 10:27:36 --> Security Class Initialized
DEBUG - 2016-10-18 10:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:27:36 --> Input Class Initialized
INFO - 2016-10-18 10:27:36 --> Language Class Initialized
INFO - 2016-10-18 10:27:36 --> Loader Class Initialized
INFO - 2016-10-18 10:27:36 --> Helper loaded: url_helper
INFO - 2016-10-18 10:27:36 --> Helper loaded: form_helper
INFO - 2016-10-18 10:27:36 --> Database Driver Class Initialized
INFO - 2016-10-18 10:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:27:36 --> Controller Class Initialized
INFO - 2016-10-18 10:27:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 10:27:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:27:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:27:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:27:36 --> Final output sent to browser
DEBUG - 2016-10-18 10:27:36 --> Total execution time: 0.0073
INFO - 2016-10-18 10:27:37 --> Config Class Initialized
INFO - 2016-10-18 10:27:37 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:27:37 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:27:37 --> Utf8 Class Initialized
INFO - 2016-10-18 10:27:37 --> URI Class Initialized
DEBUG - 2016-10-18 10:27:37 --> No URI present. Default controller set.
INFO - 2016-10-18 10:27:37 --> Router Class Initialized
INFO - 2016-10-18 10:27:37 --> Output Class Initialized
INFO - 2016-10-18 10:27:37 --> Security Class Initialized
DEBUG - 2016-10-18 10:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:27:37 --> Input Class Initialized
INFO - 2016-10-18 10:27:37 --> Language Class Initialized
INFO - 2016-10-18 10:27:37 --> Loader Class Initialized
INFO - 2016-10-18 10:27:37 --> Helper loaded: url_helper
INFO - 2016-10-18 10:27:37 --> Helper loaded: form_helper
INFO - 2016-10-18 10:27:37 --> Database Driver Class Initialized
INFO - 2016-10-18 10:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:27:37 --> Controller Class Initialized
INFO - 2016-10-18 10:27:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 10:27:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:27:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:27:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:27:37 --> Final output sent to browser
DEBUG - 2016-10-18 10:27:37 --> Total execution time: 0.0051
INFO - 2016-10-18 10:27:54 --> Config Class Initialized
INFO - 2016-10-18 10:27:54 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:27:54 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:27:54 --> Utf8 Class Initialized
INFO - 2016-10-18 10:27:54 --> URI Class Initialized
INFO - 2016-10-18 10:27:54 --> Router Class Initialized
INFO - 2016-10-18 10:27:54 --> Output Class Initialized
INFO - 2016-10-18 10:27:54 --> Security Class Initialized
DEBUG - 2016-10-18 10:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:27:54 --> Input Class Initialized
INFO - 2016-10-18 10:27:54 --> Language Class Initialized
INFO - 2016-10-18 10:27:54 --> Loader Class Initialized
INFO - 2016-10-18 10:27:54 --> Helper loaded: url_helper
INFO - 2016-10-18 10:27:54 --> Helper loaded: form_helper
INFO - 2016-10-18 10:27:54 --> Database Driver Class Initialized
INFO - 2016-10-18 10:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:27:54 --> Controller Class Initialized
ERROR - 2016-10-18 10:27:54 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 99
ERROR - 2016-10-18 10:27:54 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 99
INFO - 2016-10-18 10:27:54 --> Config Class Initialized
INFO - 2016-10-18 10:27:54 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:27:54 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:27:54 --> Utf8 Class Initialized
INFO - 2016-10-18 10:27:54 --> URI Class Initialized
DEBUG - 2016-10-18 10:27:54 --> No URI present. Default controller set.
INFO - 2016-10-18 10:27:54 --> Router Class Initialized
INFO - 2016-10-18 10:27:54 --> Output Class Initialized
INFO - 2016-10-18 10:27:54 --> Security Class Initialized
DEBUG - 2016-10-18 10:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:27:54 --> Input Class Initialized
INFO - 2016-10-18 10:27:54 --> Language Class Initialized
INFO - 2016-10-18 10:27:54 --> Loader Class Initialized
INFO - 2016-10-18 10:27:54 --> Helper loaded: url_helper
INFO - 2016-10-18 10:27:54 --> Helper loaded: form_helper
INFO - 2016-10-18 10:27:54 --> Database Driver Class Initialized
INFO - 2016-10-18 10:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:27:54 --> Controller Class Initialized
INFO - 2016-10-18 10:27:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 10:27:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 10:27:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:27:54 --> Final output sent to browser
DEBUG - 2016-10-18 10:27:54 --> Total execution time: 0.0042
INFO - 2016-10-18 10:28:00 --> Config Class Initialized
INFO - 2016-10-18 10:28:00 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:28:00 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:28:00 --> Utf8 Class Initialized
INFO - 2016-10-18 10:28:00 --> URI Class Initialized
INFO - 2016-10-18 10:28:00 --> Router Class Initialized
INFO - 2016-10-18 10:28:00 --> Output Class Initialized
INFO - 2016-10-18 10:28:00 --> Security Class Initialized
DEBUG - 2016-10-18 10:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:28:00 --> Input Class Initialized
INFO - 2016-10-18 10:28:00 --> Language Class Initialized
INFO - 2016-10-18 10:28:00 --> Loader Class Initialized
INFO - 2016-10-18 10:28:00 --> Helper loaded: url_helper
INFO - 2016-10-18 10:28:00 --> Helper loaded: form_helper
INFO - 2016-10-18 10:28:00 --> Database Driver Class Initialized
INFO - 2016-10-18 10:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:28:00 --> Controller Class Initialized
INFO - 2016-10-18 10:28:00 --> Model Class Initialized
INFO - 2016-10-18 10:28:00 --> Final output sent to browser
DEBUG - 2016-10-18 10:28:00 --> Total execution time: 0.0057
INFO - 2016-10-18 10:28:00 --> Config Class Initialized
INFO - 2016-10-18 10:28:00 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:28:00 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:28:00 --> Utf8 Class Initialized
INFO - 2016-10-18 10:28:00 --> URI Class Initialized
DEBUG - 2016-10-18 10:28:00 --> No URI present. Default controller set.
INFO - 2016-10-18 10:28:00 --> Router Class Initialized
INFO - 2016-10-18 10:28:00 --> Output Class Initialized
INFO - 2016-10-18 10:28:00 --> Security Class Initialized
DEBUG - 2016-10-18 10:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:28:00 --> Input Class Initialized
INFO - 2016-10-18 10:28:00 --> Language Class Initialized
INFO - 2016-10-18 10:28:00 --> Loader Class Initialized
INFO - 2016-10-18 10:28:00 --> Helper loaded: url_helper
INFO - 2016-10-18 10:28:00 --> Helper loaded: form_helper
INFO - 2016-10-18 10:28:00 --> Database Driver Class Initialized
INFO - 2016-10-18 10:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:28:00 --> Controller Class Initialized
INFO - 2016-10-18 10:28:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 10:28:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:28:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:28:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:28:00 --> Final output sent to browser
DEBUG - 2016-10-18 10:28:00 --> Total execution time: 0.0042
INFO - 2016-10-18 10:28:50 --> Config Class Initialized
INFO - 2016-10-18 10:28:50 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:28:50 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:28:50 --> Utf8 Class Initialized
INFO - 2016-10-18 10:28:50 --> URI Class Initialized
DEBUG - 2016-10-18 10:28:50 --> No URI present. Default controller set.
INFO - 2016-10-18 10:28:50 --> Router Class Initialized
INFO - 2016-10-18 10:28:50 --> Output Class Initialized
INFO - 2016-10-18 10:28:50 --> Security Class Initialized
DEBUG - 2016-10-18 10:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:28:50 --> Input Class Initialized
INFO - 2016-10-18 10:28:50 --> Language Class Initialized
INFO - 2016-10-18 10:28:50 --> Loader Class Initialized
INFO - 2016-10-18 10:28:50 --> Helper loaded: url_helper
INFO - 2016-10-18 10:28:50 --> Helper loaded: form_helper
INFO - 2016-10-18 10:28:50 --> Database Driver Class Initialized
INFO - 2016-10-18 10:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:28:50 --> Controller Class Initialized
INFO - 2016-10-18 10:28:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 10:28:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:28:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:28:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:28:50 --> Final output sent to browser
DEBUG - 2016-10-18 10:28:50 --> Total execution time: 0.0081
INFO - 2016-10-18 10:29:03 --> Config Class Initialized
INFO - 2016-10-18 10:29:03 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:29:03 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:29:03 --> Utf8 Class Initialized
INFO - 2016-10-18 10:29:03 --> URI Class Initialized
DEBUG - 2016-10-18 10:29:03 --> No URI present. Default controller set.
INFO - 2016-10-18 10:29:03 --> Router Class Initialized
INFO - 2016-10-18 10:29:03 --> Output Class Initialized
INFO - 2016-10-18 10:29:03 --> Security Class Initialized
DEBUG - 2016-10-18 10:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:29:03 --> Input Class Initialized
INFO - 2016-10-18 10:29:03 --> Language Class Initialized
INFO - 2016-10-18 10:29:03 --> Loader Class Initialized
INFO - 2016-10-18 10:29:03 --> Helper loaded: url_helper
INFO - 2016-10-18 10:29:03 --> Helper loaded: form_helper
INFO - 2016-10-18 10:29:03 --> Database Driver Class Initialized
INFO - 2016-10-18 10:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:29:03 --> Controller Class Initialized
INFO - 2016-10-18 10:29:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 10:29:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:29:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:29:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:29:03 --> Final output sent to browser
DEBUG - 2016-10-18 10:29:03 --> Total execution time: 0.0055
INFO - 2016-10-18 10:29:30 --> Config Class Initialized
INFO - 2016-10-18 10:29:30 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:29:30 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:29:30 --> Utf8 Class Initialized
INFO - 2016-10-18 10:29:30 --> URI Class Initialized
INFO - 2016-10-18 10:29:30 --> Router Class Initialized
INFO - 2016-10-18 10:29:30 --> Output Class Initialized
INFO - 2016-10-18 10:29:30 --> Security Class Initialized
DEBUG - 2016-10-18 10:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:29:30 --> Input Class Initialized
INFO - 2016-10-18 10:29:30 --> Language Class Initialized
INFO - 2016-10-18 10:29:30 --> Loader Class Initialized
INFO - 2016-10-18 10:29:30 --> Helper loaded: url_helper
INFO - 2016-10-18 10:29:30 --> Helper loaded: form_helper
INFO - 2016-10-18 10:29:30 --> Database Driver Class Initialized
INFO - 2016-10-18 10:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:29:30 --> Controller Class Initialized
ERROR - 2016-10-18 10:29:30 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 99
ERROR - 2016-10-18 10:29:30 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 99
INFO - 2016-10-18 10:29:30 --> Config Class Initialized
INFO - 2016-10-18 10:29:30 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:29:30 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:29:30 --> Utf8 Class Initialized
INFO - 2016-10-18 10:29:30 --> URI Class Initialized
DEBUG - 2016-10-18 10:29:30 --> No URI present. Default controller set.
INFO - 2016-10-18 10:29:30 --> Router Class Initialized
INFO - 2016-10-18 10:29:30 --> Output Class Initialized
INFO - 2016-10-18 10:29:30 --> Security Class Initialized
DEBUG - 2016-10-18 10:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:29:30 --> Input Class Initialized
INFO - 2016-10-18 10:29:30 --> Language Class Initialized
INFO - 2016-10-18 10:29:30 --> Loader Class Initialized
INFO - 2016-10-18 10:29:30 --> Helper loaded: url_helper
INFO - 2016-10-18 10:29:30 --> Helper loaded: form_helper
INFO - 2016-10-18 10:29:30 --> Database Driver Class Initialized
INFO - 2016-10-18 10:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:29:30 --> Controller Class Initialized
INFO - 2016-10-18 10:29:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 10:29:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 10:29:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:29:30 --> Final output sent to browser
DEBUG - 2016-10-18 10:29:30 --> Total execution time: 0.0039
INFO - 2016-10-18 10:29:41 --> Config Class Initialized
INFO - 2016-10-18 10:29:41 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:29:41 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:29:41 --> Utf8 Class Initialized
INFO - 2016-10-18 10:29:41 --> URI Class Initialized
INFO - 2016-10-18 10:29:41 --> Router Class Initialized
INFO - 2016-10-18 10:29:41 --> Output Class Initialized
INFO - 2016-10-18 10:29:41 --> Security Class Initialized
DEBUG - 2016-10-18 10:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:29:41 --> Input Class Initialized
INFO - 2016-10-18 10:29:41 --> Language Class Initialized
INFO - 2016-10-18 10:29:41 --> Loader Class Initialized
INFO - 2016-10-18 10:29:41 --> Helper loaded: url_helper
INFO - 2016-10-18 10:29:41 --> Helper loaded: form_helper
INFO - 2016-10-18 10:29:41 --> Database Driver Class Initialized
INFO - 2016-10-18 10:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:29:41 --> Controller Class Initialized
INFO - 2016-10-18 10:29:41 --> Model Class Initialized
INFO - 2016-10-18 10:29:41 --> Final output sent to browser
DEBUG - 2016-10-18 10:29:41 --> Total execution time: 0.0086
INFO - 2016-10-18 10:29:41 --> Config Class Initialized
INFO - 2016-10-18 10:29:41 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:29:41 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:29:41 --> Utf8 Class Initialized
INFO - 2016-10-18 10:29:41 --> URI Class Initialized
DEBUG - 2016-10-18 10:29:41 --> No URI present. Default controller set.
INFO - 2016-10-18 10:29:41 --> Router Class Initialized
INFO - 2016-10-18 10:29:41 --> Output Class Initialized
INFO - 2016-10-18 10:29:41 --> Security Class Initialized
DEBUG - 2016-10-18 10:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:29:41 --> Input Class Initialized
INFO - 2016-10-18 10:29:41 --> Language Class Initialized
INFO - 2016-10-18 10:29:41 --> Loader Class Initialized
INFO - 2016-10-18 10:29:41 --> Helper loaded: url_helper
INFO - 2016-10-18 10:29:41 --> Helper loaded: form_helper
INFO - 2016-10-18 10:29:41 --> Database Driver Class Initialized
INFO - 2016-10-18 10:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:29:41 --> Controller Class Initialized
INFO - 2016-10-18 10:29:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 10:29:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:29:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:29:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:29:41 --> Final output sent to browser
DEBUG - 2016-10-18 10:29:41 --> Total execution time: 0.0052
INFO - 2016-10-18 10:30:46 --> Config Class Initialized
INFO - 2016-10-18 10:30:46 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:30:46 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:30:46 --> Utf8 Class Initialized
INFO - 2016-10-18 10:30:46 --> URI Class Initialized
DEBUG - 2016-10-18 10:30:46 --> No URI present. Default controller set.
INFO - 2016-10-18 10:30:46 --> Router Class Initialized
INFO - 2016-10-18 10:30:46 --> Output Class Initialized
INFO - 2016-10-18 10:30:46 --> Security Class Initialized
DEBUG - 2016-10-18 10:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:30:46 --> Input Class Initialized
INFO - 2016-10-18 10:30:46 --> Language Class Initialized
INFO - 2016-10-18 10:30:46 --> Loader Class Initialized
INFO - 2016-10-18 10:30:46 --> Helper loaded: url_helper
INFO - 2016-10-18 10:30:46 --> Helper loaded: form_helper
INFO - 2016-10-18 10:30:46 --> Database Driver Class Initialized
INFO - 2016-10-18 10:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:30:46 --> Controller Class Initialized
INFO - 2016-10-18 10:30:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 10:30:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:30:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:30:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:30:46 --> Final output sent to browser
DEBUG - 2016-10-18 10:30:46 --> Total execution time: 0.0058
INFO - 2016-10-18 10:31:02 --> Config Class Initialized
INFO - 2016-10-18 10:31:02 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:31:02 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:31:02 --> Utf8 Class Initialized
INFO - 2016-10-18 10:31:02 --> URI Class Initialized
DEBUG - 2016-10-18 10:31:02 --> No URI present. Default controller set.
INFO - 2016-10-18 10:31:02 --> Router Class Initialized
INFO - 2016-10-18 10:31:02 --> Output Class Initialized
INFO - 2016-10-18 10:31:02 --> Security Class Initialized
DEBUG - 2016-10-18 10:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:31:02 --> Input Class Initialized
INFO - 2016-10-18 10:31:02 --> Language Class Initialized
INFO - 2016-10-18 10:31:02 --> Loader Class Initialized
INFO - 2016-10-18 10:31:02 --> Helper loaded: url_helper
INFO - 2016-10-18 10:31:02 --> Helper loaded: form_helper
INFO - 2016-10-18 10:31:02 --> Database Driver Class Initialized
INFO - 2016-10-18 10:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:31:02 --> Controller Class Initialized
INFO - 2016-10-18 10:31:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 10:31:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:31:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:31:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:31:02 --> Final output sent to browser
DEBUG - 2016-10-18 10:31:02 --> Total execution time: 0.0048
INFO - 2016-10-18 10:31:24 --> Config Class Initialized
INFO - 2016-10-18 10:31:24 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:31:24 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:31:24 --> Utf8 Class Initialized
INFO - 2016-10-18 10:31:24 --> URI Class Initialized
INFO - 2016-10-18 10:31:24 --> Router Class Initialized
INFO - 2016-10-18 10:31:24 --> Output Class Initialized
INFO - 2016-10-18 10:31:24 --> Security Class Initialized
DEBUG - 2016-10-18 10:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:31:24 --> Input Class Initialized
INFO - 2016-10-18 10:31:24 --> Language Class Initialized
INFO - 2016-10-18 10:31:24 --> Loader Class Initialized
INFO - 2016-10-18 10:31:24 --> Helper loaded: url_helper
INFO - 2016-10-18 10:31:24 --> Helper loaded: form_helper
INFO - 2016-10-18 10:31:24 --> Database Driver Class Initialized
INFO - 2016-10-18 10:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:31:24 --> Controller Class Initialized
ERROR - 2016-10-18 10:31:24 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 99
ERROR - 2016-10-18 10:31:24 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 99
INFO - 2016-10-18 10:31:24 --> Config Class Initialized
INFO - 2016-10-18 10:31:24 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:31:24 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:31:24 --> Utf8 Class Initialized
INFO - 2016-10-18 10:31:24 --> URI Class Initialized
DEBUG - 2016-10-18 10:31:24 --> No URI present. Default controller set.
INFO - 2016-10-18 10:31:24 --> Router Class Initialized
INFO - 2016-10-18 10:31:24 --> Output Class Initialized
INFO - 2016-10-18 10:31:24 --> Security Class Initialized
DEBUG - 2016-10-18 10:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:31:24 --> Input Class Initialized
INFO - 2016-10-18 10:31:24 --> Language Class Initialized
INFO - 2016-10-18 10:31:24 --> Loader Class Initialized
INFO - 2016-10-18 10:31:24 --> Helper loaded: url_helper
INFO - 2016-10-18 10:31:24 --> Helper loaded: form_helper
INFO - 2016-10-18 10:31:24 --> Database Driver Class Initialized
INFO - 2016-10-18 10:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:31:24 --> Controller Class Initialized
INFO - 2016-10-18 10:31:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 10:31:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 10:31:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:31:24 --> Final output sent to browser
DEBUG - 2016-10-18 10:31:24 --> Total execution time: 0.0052
INFO - 2016-10-18 10:46:19 --> Config Class Initialized
INFO - 2016-10-18 10:46:19 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:46:19 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:46:19 --> Utf8 Class Initialized
INFO - 2016-10-18 10:46:19 --> URI Class Initialized
DEBUG - 2016-10-18 10:46:19 --> No URI present. Default controller set.
INFO - 2016-10-18 10:46:19 --> Router Class Initialized
INFO - 2016-10-18 10:46:19 --> Output Class Initialized
INFO - 2016-10-18 10:46:19 --> Security Class Initialized
DEBUG - 2016-10-18 10:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:46:19 --> Input Class Initialized
INFO - 2016-10-18 10:46:19 --> Language Class Initialized
INFO - 2016-10-18 10:46:19 --> Loader Class Initialized
INFO - 2016-10-18 10:46:19 --> Helper loaded: url_helper
INFO - 2016-10-18 10:46:19 --> Helper loaded: form_helper
INFO - 2016-10-18 10:46:19 --> Database Driver Class Initialized
INFO - 2016-10-18 10:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:46:19 --> Controller Class Initialized
INFO - 2016-10-18 10:46:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 10:46:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 10:46:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:46:19 --> Final output sent to browser
DEBUG - 2016-10-18 10:46:19 --> Total execution time: 0.0200
INFO - 2016-10-18 10:46:30 --> Config Class Initialized
INFO - 2016-10-18 10:46:30 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:46:30 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:46:30 --> Utf8 Class Initialized
INFO - 2016-10-18 10:46:30 --> URI Class Initialized
INFO - 2016-10-18 10:46:30 --> Router Class Initialized
INFO - 2016-10-18 10:46:30 --> Output Class Initialized
INFO - 2016-10-18 10:46:30 --> Security Class Initialized
DEBUG - 2016-10-18 10:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:46:30 --> Input Class Initialized
INFO - 2016-10-18 10:46:30 --> Language Class Initialized
INFO - 2016-10-18 10:46:30 --> Loader Class Initialized
INFO - 2016-10-18 10:46:30 --> Helper loaded: url_helper
INFO - 2016-10-18 10:46:30 --> Helper loaded: form_helper
INFO - 2016-10-18 10:46:30 --> Database Driver Class Initialized
INFO - 2016-10-18 10:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:46:30 --> Controller Class Initialized
INFO - 2016-10-18 10:46:30 --> Model Class Initialized
INFO - 2016-10-18 10:46:30 --> Final output sent to browser
DEBUG - 2016-10-18 10:46:30 --> Total execution time: 0.0077
INFO - 2016-10-18 10:46:30 --> Config Class Initialized
INFO - 2016-10-18 10:46:30 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:46:30 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:46:30 --> Utf8 Class Initialized
INFO - 2016-10-18 10:46:30 --> URI Class Initialized
DEBUG - 2016-10-18 10:46:30 --> No URI present. Default controller set.
INFO - 2016-10-18 10:46:30 --> Router Class Initialized
INFO - 2016-10-18 10:46:30 --> Output Class Initialized
INFO - 2016-10-18 10:46:30 --> Security Class Initialized
DEBUG - 2016-10-18 10:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:46:30 --> Input Class Initialized
INFO - 2016-10-18 10:46:30 --> Language Class Initialized
INFO - 2016-10-18 10:46:30 --> Loader Class Initialized
INFO - 2016-10-18 10:46:30 --> Helper loaded: url_helper
INFO - 2016-10-18 10:46:30 --> Helper loaded: form_helper
INFO - 2016-10-18 10:46:30 --> Database Driver Class Initialized
INFO - 2016-10-18 10:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:46:30 --> Controller Class Initialized
INFO - 2016-10-18 10:46:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 10:46:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:46:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:46:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:46:30 --> Final output sent to browser
DEBUG - 2016-10-18 10:46:30 --> Total execution time: 0.0047
INFO - 2016-10-18 10:56:32 --> Config Class Initialized
INFO - 2016-10-18 10:56:32 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:56:32 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:56:32 --> Utf8 Class Initialized
INFO - 2016-10-18 10:56:32 --> URI Class Initialized
DEBUG - 2016-10-18 10:56:32 --> No URI present. Default controller set.
INFO - 2016-10-18 10:56:32 --> Router Class Initialized
INFO - 2016-10-18 10:56:32 --> Output Class Initialized
INFO - 2016-10-18 10:56:32 --> Security Class Initialized
DEBUG - 2016-10-18 10:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:56:32 --> Input Class Initialized
INFO - 2016-10-18 10:56:32 --> Language Class Initialized
INFO - 2016-10-18 10:56:32 --> Loader Class Initialized
INFO - 2016-10-18 10:56:32 --> Helper loaded: url_helper
INFO - 2016-10-18 10:56:32 --> Helper loaded: form_helper
INFO - 2016-10-18 10:56:32 --> Database Driver Class Initialized
INFO - 2016-10-18 10:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:56:32 --> Controller Class Initialized
INFO - 2016-10-18 10:56:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 10:56:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:56:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:56:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:56:32 --> Final output sent to browser
DEBUG - 2016-10-18 10:56:32 --> Total execution time: 0.0089
INFO - 2016-10-18 10:56:59 --> Config Class Initialized
INFO - 2016-10-18 10:56:59 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:56:59 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:56:59 --> Utf8 Class Initialized
INFO - 2016-10-18 10:56:59 --> URI Class Initialized
DEBUG - 2016-10-18 10:56:59 --> No URI present. Default controller set.
INFO - 2016-10-18 10:56:59 --> Router Class Initialized
INFO - 2016-10-18 10:56:59 --> Output Class Initialized
INFO - 2016-10-18 10:56:59 --> Security Class Initialized
DEBUG - 2016-10-18 10:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:56:59 --> Input Class Initialized
INFO - 2016-10-18 10:56:59 --> Language Class Initialized
INFO - 2016-10-18 10:56:59 --> Loader Class Initialized
INFO - 2016-10-18 10:56:59 --> Helper loaded: url_helper
INFO - 2016-10-18 10:56:59 --> Helper loaded: form_helper
INFO - 2016-10-18 10:56:59 --> Database Driver Class Initialized
INFO - 2016-10-18 10:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:56:59 --> Controller Class Initialized
INFO - 2016-10-18 10:56:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 10:56:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:56:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:56:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:56:59 --> Final output sent to browser
DEBUG - 2016-10-18 10:56:59 --> Total execution time: 0.0131
INFO - 2016-10-18 10:57:01 --> Config Class Initialized
INFO - 2016-10-18 10:57:01 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:57:01 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:57:01 --> Utf8 Class Initialized
INFO - 2016-10-18 10:57:01 --> URI Class Initialized
DEBUG - 2016-10-18 10:57:01 --> No URI present. Default controller set.
INFO - 2016-10-18 10:57:01 --> Router Class Initialized
INFO - 2016-10-18 10:57:01 --> Output Class Initialized
INFO - 2016-10-18 10:57:01 --> Security Class Initialized
DEBUG - 2016-10-18 10:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:57:01 --> Input Class Initialized
INFO - 2016-10-18 10:57:01 --> Language Class Initialized
INFO - 2016-10-18 10:57:01 --> Loader Class Initialized
INFO - 2016-10-18 10:57:01 --> Helper loaded: url_helper
INFO - 2016-10-18 10:57:01 --> Helper loaded: form_helper
INFO - 2016-10-18 10:57:01 --> Database Driver Class Initialized
INFO - 2016-10-18 10:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:57:01 --> Controller Class Initialized
INFO - 2016-10-18 10:57:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 10:57:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:57:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:57:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:57:01 --> Final output sent to browser
DEBUG - 2016-10-18 10:57:01 --> Total execution time: 0.0054
INFO - 2016-10-18 10:58:54 --> Config Class Initialized
INFO - 2016-10-18 10:58:54 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:58:54 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:58:54 --> Utf8 Class Initialized
INFO - 2016-10-18 10:58:54 --> URI Class Initialized
DEBUG - 2016-10-18 10:58:54 --> No URI present. Default controller set.
INFO - 2016-10-18 10:58:54 --> Router Class Initialized
INFO - 2016-10-18 10:58:54 --> Output Class Initialized
INFO - 2016-10-18 10:58:54 --> Security Class Initialized
DEBUG - 2016-10-18 10:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:58:54 --> Input Class Initialized
INFO - 2016-10-18 10:58:54 --> Language Class Initialized
INFO - 2016-10-18 10:58:54 --> Loader Class Initialized
INFO - 2016-10-18 10:58:54 --> Helper loaded: url_helper
INFO - 2016-10-18 10:58:54 --> Helper loaded: form_helper
INFO - 2016-10-18 10:58:54 --> Database Driver Class Initialized
INFO - 2016-10-18 10:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:58:54 --> Controller Class Initialized
INFO - 2016-10-18 10:58:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 10:58:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:58:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:58:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:58:54 --> Final output sent to browser
DEBUG - 2016-10-18 10:58:54 --> Total execution time: 0.0058
INFO - 2016-10-18 10:58:56 --> Config Class Initialized
INFO - 2016-10-18 10:58:56 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:58:56 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:58:56 --> Utf8 Class Initialized
INFO - 2016-10-18 10:58:56 --> URI Class Initialized
DEBUG - 2016-10-18 10:58:56 --> No URI present. Default controller set.
INFO - 2016-10-18 10:58:56 --> Router Class Initialized
INFO - 2016-10-18 10:58:56 --> Output Class Initialized
INFO - 2016-10-18 10:58:56 --> Security Class Initialized
DEBUG - 2016-10-18 10:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:58:56 --> Input Class Initialized
INFO - 2016-10-18 10:58:56 --> Language Class Initialized
INFO - 2016-10-18 10:58:56 --> Loader Class Initialized
INFO - 2016-10-18 10:58:56 --> Helper loaded: url_helper
INFO - 2016-10-18 10:58:56 --> Helper loaded: form_helper
INFO - 2016-10-18 10:58:56 --> Database Driver Class Initialized
INFO - 2016-10-18 10:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:58:56 --> Controller Class Initialized
INFO - 2016-10-18 10:58:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 10:58:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:58:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:58:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:58:56 --> Final output sent to browser
DEBUG - 2016-10-18 10:58:56 --> Total execution time: 0.0049
INFO - 2016-10-18 10:59:25 --> Config Class Initialized
INFO - 2016-10-18 10:59:25 --> Hooks Class Initialized
DEBUG - 2016-10-18 10:59:25 --> UTF-8 Support Enabled
INFO - 2016-10-18 10:59:25 --> Utf8 Class Initialized
INFO - 2016-10-18 10:59:25 --> URI Class Initialized
DEBUG - 2016-10-18 10:59:25 --> No URI present. Default controller set.
INFO - 2016-10-18 10:59:25 --> Router Class Initialized
INFO - 2016-10-18 10:59:25 --> Output Class Initialized
INFO - 2016-10-18 10:59:25 --> Security Class Initialized
DEBUG - 2016-10-18 10:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 10:59:25 --> Input Class Initialized
INFO - 2016-10-18 10:59:25 --> Language Class Initialized
INFO - 2016-10-18 10:59:25 --> Loader Class Initialized
INFO - 2016-10-18 10:59:25 --> Helper loaded: url_helper
INFO - 2016-10-18 10:59:25 --> Helper loaded: form_helper
INFO - 2016-10-18 10:59:25 --> Database Driver Class Initialized
INFO - 2016-10-18 10:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 10:59:25 --> Controller Class Initialized
INFO - 2016-10-18 10:59:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 10:59:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 10:59:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 10:59:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 10:59:25 --> Final output sent to browser
DEBUG - 2016-10-18 10:59:25 --> Total execution time: 0.0053
INFO - 2016-10-18 11:00:15 --> Config Class Initialized
INFO - 2016-10-18 11:00:15 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:00:15 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:00:15 --> Utf8 Class Initialized
INFO - 2016-10-18 11:00:15 --> URI Class Initialized
DEBUG - 2016-10-18 11:00:15 --> No URI present. Default controller set.
INFO - 2016-10-18 11:00:15 --> Router Class Initialized
INFO - 2016-10-18 11:00:15 --> Output Class Initialized
INFO - 2016-10-18 11:00:15 --> Security Class Initialized
DEBUG - 2016-10-18 11:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:00:15 --> Input Class Initialized
INFO - 2016-10-18 11:00:15 --> Language Class Initialized
INFO - 2016-10-18 11:00:15 --> Loader Class Initialized
INFO - 2016-10-18 11:00:15 --> Helper loaded: url_helper
INFO - 2016-10-18 11:00:15 --> Helper loaded: form_helper
INFO - 2016-10-18 11:00:15 --> Database Driver Class Initialized
INFO - 2016-10-18 11:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:00:15 --> Controller Class Initialized
INFO - 2016-10-18 11:00:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:00:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:00:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:00:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:00:15 --> Final output sent to browser
DEBUG - 2016-10-18 11:00:15 --> Total execution time: 0.0059
INFO - 2016-10-18 11:00:29 --> Config Class Initialized
INFO - 2016-10-18 11:00:29 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:00:29 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:00:29 --> Utf8 Class Initialized
INFO - 2016-10-18 11:00:29 --> URI Class Initialized
DEBUG - 2016-10-18 11:00:29 --> No URI present. Default controller set.
INFO - 2016-10-18 11:00:29 --> Router Class Initialized
INFO - 2016-10-18 11:00:29 --> Output Class Initialized
INFO - 2016-10-18 11:00:29 --> Security Class Initialized
DEBUG - 2016-10-18 11:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:00:29 --> Input Class Initialized
INFO - 2016-10-18 11:00:29 --> Language Class Initialized
INFO - 2016-10-18 11:00:29 --> Loader Class Initialized
INFO - 2016-10-18 11:00:29 --> Helper loaded: url_helper
INFO - 2016-10-18 11:00:29 --> Helper loaded: form_helper
INFO - 2016-10-18 11:00:29 --> Database Driver Class Initialized
INFO - 2016-10-18 11:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:00:29 --> Controller Class Initialized
INFO - 2016-10-18 11:00:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:00:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:00:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:00:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:00:29 --> Final output sent to browser
DEBUG - 2016-10-18 11:00:29 --> Total execution time: 0.0090
INFO - 2016-10-18 11:01:45 --> Config Class Initialized
INFO - 2016-10-18 11:01:45 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:01:45 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:01:45 --> Utf8 Class Initialized
INFO - 2016-10-18 11:01:45 --> URI Class Initialized
DEBUG - 2016-10-18 11:01:45 --> No URI present. Default controller set.
INFO - 2016-10-18 11:01:45 --> Router Class Initialized
INFO - 2016-10-18 11:01:45 --> Output Class Initialized
INFO - 2016-10-18 11:01:45 --> Security Class Initialized
DEBUG - 2016-10-18 11:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:01:45 --> Input Class Initialized
INFO - 2016-10-18 11:01:45 --> Language Class Initialized
INFO - 2016-10-18 11:01:45 --> Loader Class Initialized
INFO - 2016-10-18 11:01:45 --> Helper loaded: url_helper
INFO - 2016-10-18 11:01:45 --> Helper loaded: form_helper
INFO - 2016-10-18 11:01:45 --> Database Driver Class Initialized
INFO - 2016-10-18 11:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:01:45 --> Controller Class Initialized
INFO - 2016-10-18 11:01:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:01:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:01:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:01:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:01:45 --> Final output sent to browser
DEBUG - 2016-10-18 11:01:45 --> Total execution time: 0.0065
INFO - 2016-10-18 11:02:27 --> Config Class Initialized
INFO - 2016-10-18 11:02:27 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:02:27 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:02:27 --> Utf8 Class Initialized
INFO - 2016-10-18 11:02:27 --> URI Class Initialized
DEBUG - 2016-10-18 11:02:27 --> No URI present. Default controller set.
INFO - 2016-10-18 11:02:27 --> Router Class Initialized
INFO - 2016-10-18 11:02:27 --> Output Class Initialized
INFO - 2016-10-18 11:02:27 --> Security Class Initialized
DEBUG - 2016-10-18 11:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:02:27 --> Input Class Initialized
INFO - 2016-10-18 11:02:27 --> Language Class Initialized
INFO - 2016-10-18 11:02:27 --> Loader Class Initialized
INFO - 2016-10-18 11:02:27 --> Helper loaded: url_helper
INFO - 2016-10-18 11:02:27 --> Helper loaded: form_helper
INFO - 2016-10-18 11:02:27 --> Database Driver Class Initialized
INFO - 2016-10-18 11:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:02:27 --> Controller Class Initialized
INFO - 2016-10-18 11:02:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:02:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:02:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:02:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:02:27 --> Final output sent to browser
DEBUG - 2016-10-18 11:02:27 --> Total execution time: 0.0088
INFO - 2016-10-18 11:27:15 --> Config Class Initialized
INFO - 2016-10-18 11:27:15 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:27:15 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:27:15 --> Utf8 Class Initialized
INFO - 2016-10-18 11:27:15 --> URI Class Initialized
DEBUG - 2016-10-18 11:27:15 --> No URI present. Default controller set.
INFO - 2016-10-18 11:27:15 --> Router Class Initialized
INFO - 2016-10-18 11:27:15 --> Output Class Initialized
INFO - 2016-10-18 11:27:15 --> Security Class Initialized
DEBUG - 2016-10-18 11:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:27:15 --> Input Class Initialized
INFO - 2016-10-18 11:27:15 --> Language Class Initialized
INFO - 2016-10-18 11:27:15 --> Loader Class Initialized
INFO - 2016-10-18 11:27:15 --> Helper loaded: url_helper
INFO - 2016-10-18 11:27:15 --> Helper loaded: form_helper
INFO - 2016-10-18 11:27:15 --> Database Driver Class Initialized
INFO - 2016-10-18 11:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:27:15 --> Controller Class Initialized
INFO - 2016-10-18 11:27:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:27:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:27:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:27:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:27:15 --> Final output sent to browser
DEBUG - 2016-10-18 11:27:15 --> Total execution time: 0.0236
INFO - 2016-10-18 11:27:51 --> Config Class Initialized
INFO - 2016-10-18 11:27:51 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:27:51 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:27:51 --> Utf8 Class Initialized
INFO - 2016-10-18 11:27:51 --> URI Class Initialized
DEBUG - 2016-10-18 11:27:51 --> No URI present. Default controller set.
INFO - 2016-10-18 11:27:51 --> Router Class Initialized
INFO - 2016-10-18 11:27:51 --> Output Class Initialized
INFO - 2016-10-18 11:27:51 --> Security Class Initialized
DEBUG - 2016-10-18 11:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:27:51 --> Input Class Initialized
INFO - 2016-10-18 11:27:51 --> Language Class Initialized
INFO - 2016-10-18 11:27:51 --> Loader Class Initialized
INFO - 2016-10-18 11:27:51 --> Helper loaded: url_helper
INFO - 2016-10-18 11:27:51 --> Helper loaded: form_helper
INFO - 2016-10-18 11:27:51 --> Database Driver Class Initialized
INFO - 2016-10-18 11:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:27:51 --> Controller Class Initialized
INFO - 2016-10-18 11:27:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:27:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:27:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:27:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:27:51 --> Final output sent to browser
DEBUG - 2016-10-18 11:27:51 --> Total execution time: 0.0076
INFO - 2016-10-18 11:27:54 --> Config Class Initialized
INFO - 2016-10-18 11:27:54 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:27:54 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:27:54 --> Utf8 Class Initialized
INFO - 2016-10-18 11:27:54 --> URI Class Initialized
DEBUG - 2016-10-18 11:27:54 --> No URI present. Default controller set.
INFO - 2016-10-18 11:27:54 --> Router Class Initialized
INFO - 2016-10-18 11:27:54 --> Output Class Initialized
INFO - 2016-10-18 11:27:54 --> Security Class Initialized
DEBUG - 2016-10-18 11:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:27:54 --> Input Class Initialized
INFO - 2016-10-18 11:27:54 --> Language Class Initialized
INFO - 2016-10-18 11:27:54 --> Loader Class Initialized
INFO - 2016-10-18 11:27:54 --> Helper loaded: url_helper
INFO - 2016-10-18 11:27:54 --> Helper loaded: form_helper
INFO - 2016-10-18 11:27:54 --> Database Driver Class Initialized
INFO - 2016-10-18 11:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:27:54 --> Controller Class Initialized
INFO - 2016-10-18 11:27:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:27:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:27:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:27:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:27:54 --> Final output sent to browser
DEBUG - 2016-10-18 11:27:54 --> Total execution time: 0.0074
INFO - 2016-10-18 11:28:51 --> Config Class Initialized
INFO - 2016-10-18 11:28:51 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:28:51 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:28:51 --> Utf8 Class Initialized
INFO - 2016-10-18 11:28:51 --> URI Class Initialized
DEBUG - 2016-10-18 11:28:51 --> No URI present. Default controller set.
INFO - 2016-10-18 11:28:51 --> Router Class Initialized
INFO - 2016-10-18 11:28:51 --> Output Class Initialized
INFO - 2016-10-18 11:28:51 --> Security Class Initialized
DEBUG - 2016-10-18 11:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:28:51 --> Input Class Initialized
INFO - 2016-10-18 11:28:51 --> Language Class Initialized
INFO - 2016-10-18 11:28:51 --> Loader Class Initialized
INFO - 2016-10-18 11:28:51 --> Helper loaded: url_helper
INFO - 2016-10-18 11:28:51 --> Helper loaded: form_helper
INFO - 2016-10-18 11:28:51 --> Database Driver Class Initialized
INFO - 2016-10-18 11:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:28:51 --> Controller Class Initialized
INFO - 2016-10-18 11:28:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:28:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:28:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:28:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:28:51 --> Final output sent to browser
DEBUG - 2016-10-18 11:28:51 --> Total execution time: 0.0062
INFO - 2016-10-18 11:29:34 --> Config Class Initialized
INFO - 2016-10-18 11:29:34 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:29:34 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:29:34 --> Utf8 Class Initialized
INFO - 2016-10-18 11:29:34 --> URI Class Initialized
DEBUG - 2016-10-18 11:29:34 --> No URI present. Default controller set.
INFO - 2016-10-18 11:29:34 --> Router Class Initialized
INFO - 2016-10-18 11:29:34 --> Output Class Initialized
INFO - 2016-10-18 11:29:34 --> Security Class Initialized
DEBUG - 2016-10-18 11:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:29:34 --> Input Class Initialized
INFO - 2016-10-18 11:29:34 --> Language Class Initialized
INFO - 2016-10-18 11:29:34 --> Loader Class Initialized
INFO - 2016-10-18 11:29:34 --> Helper loaded: url_helper
INFO - 2016-10-18 11:29:34 --> Helper loaded: form_helper
INFO - 2016-10-18 11:29:34 --> Database Driver Class Initialized
INFO - 2016-10-18 11:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:29:34 --> Controller Class Initialized
INFO - 2016-10-18 11:29:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:29:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:29:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:29:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:29:34 --> Final output sent to browser
DEBUG - 2016-10-18 11:29:34 --> Total execution time: 0.0084
INFO - 2016-10-18 11:29:45 --> Config Class Initialized
INFO - 2016-10-18 11:29:45 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:29:45 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:29:45 --> Utf8 Class Initialized
INFO - 2016-10-18 11:29:45 --> URI Class Initialized
DEBUG - 2016-10-18 11:29:45 --> No URI present. Default controller set.
INFO - 2016-10-18 11:29:45 --> Router Class Initialized
INFO - 2016-10-18 11:29:45 --> Output Class Initialized
INFO - 2016-10-18 11:29:45 --> Security Class Initialized
DEBUG - 2016-10-18 11:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:29:45 --> Input Class Initialized
INFO - 2016-10-18 11:29:45 --> Language Class Initialized
INFO - 2016-10-18 11:29:45 --> Loader Class Initialized
INFO - 2016-10-18 11:29:45 --> Helper loaded: url_helper
INFO - 2016-10-18 11:29:45 --> Helper loaded: form_helper
INFO - 2016-10-18 11:29:45 --> Database Driver Class Initialized
INFO - 2016-10-18 11:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:29:45 --> Controller Class Initialized
INFO - 2016-10-18 11:29:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:29:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:29:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:29:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:29:45 --> Final output sent to browser
DEBUG - 2016-10-18 11:29:45 --> Total execution time: 0.0080
INFO - 2016-10-18 11:30:09 --> Config Class Initialized
INFO - 2016-10-18 11:30:09 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:30:09 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:30:09 --> Utf8 Class Initialized
INFO - 2016-10-18 11:30:09 --> URI Class Initialized
DEBUG - 2016-10-18 11:30:09 --> No URI present. Default controller set.
INFO - 2016-10-18 11:30:09 --> Router Class Initialized
INFO - 2016-10-18 11:30:09 --> Output Class Initialized
INFO - 2016-10-18 11:30:09 --> Security Class Initialized
DEBUG - 2016-10-18 11:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:30:09 --> Input Class Initialized
INFO - 2016-10-18 11:30:09 --> Language Class Initialized
INFO - 2016-10-18 11:30:09 --> Loader Class Initialized
INFO - 2016-10-18 11:30:09 --> Helper loaded: url_helper
INFO - 2016-10-18 11:30:09 --> Helper loaded: form_helper
INFO - 2016-10-18 11:30:09 --> Database Driver Class Initialized
INFO - 2016-10-18 11:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:30:09 --> Controller Class Initialized
INFO - 2016-10-18 11:30:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:30:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:30:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:30:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:30:09 --> Final output sent to browser
DEBUG - 2016-10-18 11:30:09 --> Total execution time: 0.0052
INFO - 2016-10-18 11:30:49 --> Config Class Initialized
INFO - 2016-10-18 11:30:49 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:30:49 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:30:49 --> Utf8 Class Initialized
INFO - 2016-10-18 11:30:49 --> URI Class Initialized
DEBUG - 2016-10-18 11:30:49 --> No URI present. Default controller set.
INFO - 2016-10-18 11:30:49 --> Router Class Initialized
INFO - 2016-10-18 11:30:49 --> Output Class Initialized
INFO - 2016-10-18 11:30:49 --> Security Class Initialized
DEBUG - 2016-10-18 11:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:30:49 --> Input Class Initialized
INFO - 2016-10-18 11:30:49 --> Language Class Initialized
INFO - 2016-10-18 11:30:49 --> Loader Class Initialized
INFO - 2016-10-18 11:30:49 --> Helper loaded: url_helper
INFO - 2016-10-18 11:30:49 --> Helper loaded: form_helper
INFO - 2016-10-18 11:30:49 --> Database Driver Class Initialized
INFO - 2016-10-18 11:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:30:49 --> Controller Class Initialized
INFO - 2016-10-18 11:30:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:30:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:30:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:30:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:30:49 --> Final output sent to browser
DEBUG - 2016-10-18 11:30:49 --> Total execution time: 0.0051
INFO - 2016-10-18 11:31:37 --> Config Class Initialized
INFO - 2016-10-18 11:31:37 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:31:37 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:31:37 --> Utf8 Class Initialized
INFO - 2016-10-18 11:31:37 --> URI Class Initialized
DEBUG - 2016-10-18 11:31:37 --> No URI present. Default controller set.
INFO - 2016-10-18 11:31:37 --> Router Class Initialized
INFO - 2016-10-18 11:31:37 --> Output Class Initialized
INFO - 2016-10-18 11:31:37 --> Security Class Initialized
DEBUG - 2016-10-18 11:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:31:37 --> Input Class Initialized
INFO - 2016-10-18 11:31:37 --> Language Class Initialized
INFO - 2016-10-18 11:31:37 --> Loader Class Initialized
INFO - 2016-10-18 11:31:37 --> Helper loaded: url_helper
INFO - 2016-10-18 11:31:37 --> Helper loaded: form_helper
INFO - 2016-10-18 11:31:37 --> Database Driver Class Initialized
INFO - 2016-10-18 11:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:31:37 --> Controller Class Initialized
INFO - 2016-10-18 11:31:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:31:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:31:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:31:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:31:37 --> Final output sent to browser
DEBUG - 2016-10-18 11:31:37 --> Total execution time: 0.0075
INFO - 2016-10-18 11:32:22 --> Config Class Initialized
INFO - 2016-10-18 11:32:22 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:32:22 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:32:22 --> Utf8 Class Initialized
INFO - 2016-10-18 11:32:22 --> URI Class Initialized
DEBUG - 2016-10-18 11:32:22 --> No URI present. Default controller set.
INFO - 2016-10-18 11:32:22 --> Router Class Initialized
INFO - 2016-10-18 11:32:22 --> Output Class Initialized
INFO - 2016-10-18 11:32:22 --> Security Class Initialized
DEBUG - 2016-10-18 11:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:32:22 --> Input Class Initialized
INFO - 2016-10-18 11:32:22 --> Language Class Initialized
INFO - 2016-10-18 11:32:22 --> Loader Class Initialized
INFO - 2016-10-18 11:32:22 --> Helper loaded: url_helper
INFO - 2016-10-18 11:32:22 --> Helper loaded: form_helper
INFO - 2016-10-18 11:32:22 --> Database Driver Class Initialized
INFO - 2016-10-18 11:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:32:22 --> Controller Class Initialized
INFO - 2016-10-18 11:32:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:32:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:32:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:32:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:32:22 --> Final output sent to browser
DEBUG - 2016-10-18 11:32:22 --> Total execution time: 0.0067
INFO - 2016-10-18 11:34:01 --> Config Class Initialized
INFO - 2016-10-18 11:34:01 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:34:01 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:34:01 --> Utf8 Class Initialized
INFO - 2016-10-18 11:34:01 --> URI Class Initialized
DEBUG - 2016-10-18 11:34:01 --> No URI present. Default controller set.
INFO - 2016-10-18 11:34:01 --> Router Class Initialized
INFO - 2016-10-18 11:34:01 --> Output Class Initialized
INFO - 2016-10-18 11:34:01 --> Security Class Initialized
DEBUG - 2016-10-18 11:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:34:01 --> Input Class Initialized
INFO - 2016-10-18 11:34:01 --> Language Class Initialized
INFO - 2016-10-18 11:34:01 --> Loader Class Initialized
INFO - 2016-10-18 11:34:01 --> Helper loaded: url_helper
INFO - 2016-10-18 11:34:01 --> Helper loaded: form_helper
INFO - 2016-10-18 11:34:01 --> Database Driver Class Initialized
INFO - 2016-10-18 11:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:34:01 --> Controller Class Initialized
INFO - 2016-10-18 11:34:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:34:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:34:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:34:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:34:01 --> Final output sent to browser
DEBUG - 2016-10-18 11:34:01 --> Total execution time: 0.0080
INFO - 2016-10-18 11:34:03 --> Config Class Initialized
INFO - 2016-10-18 11:34:03 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:34:03 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:34:03 --> Utf8 Class Initialized
INFO - 2016-10-18 11:34:03 --> URI Class Initialized
DEBUG - 2016-10-18 11:34:03 --> No URI present. Default controller set.
INFO - 2016-10-18 11:34:03 --> Router Class Initialized
INFO - 2016-10-18 11:34:03 --> Output Class Initialized
INFO - 2016-10-18 11:34:03 --> Security Class Initialized
DEBUG - 2016-10-18 11:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:34:03 --> Input Class Initialized
INFO - 2016-10-18 11:34:03 --> Language Class Initialized
INFO - 2016-10-18 11:34:03 --> Loader Class Initialized
INFO - 2016-10-18 11:34:03 --> Helper loaded: url_helper
INFO - 2016-10-18 11:34:03 --> Helper loaded: form_helper
INFO - 2016-10-18 11:34:03 --> Database Driver Class Initialized
INFO - 2016-10-18 11:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:34:03 --> Controller Class Initialized
INFO - 2016-10-18 11:34:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:34:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:34:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:34:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:34:03 --> Final output sent to browser
DEBUG - 2016-10-18 11:34:03 --> Total execution time: 0.0054
INFO - 2016-10-18 11:34:33 --> Config Class Initialized
INFO - 2016-10-18 11:34:33 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:34:33 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:34:33 --> Utf8 Class Initialized
INFO - 2016-10-18 11:34:33 --> URI Class Initialized
DEBUG - 2016-10-18 11:34:33 --> No URI present. Default controller set.
INFO - 2016-10-18 11:34:33 --> Router Class Initialized
INFO - 2016-10-18 11:34:33 --> Output Class Initialized
INFO - 2016-10-18 11:34:33 --> Security Class Initialized
DEBUG - 2016-10-18 11:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:34:33 --> Input Class Initialized
INFO - 2016-10-18 11:34:33 --> Language Class Initialized
INFO - 2016-10-18 11:34:33 --> Loader Class Initialized
INFO - 2016-10-18 11:34:33 --> Helper loaded: url_helper
INFO - 2016-10-18 11:34:33 --> Helper loaded: form_helper
INFO - 2016-10-18 11:34:33 --> Database Driver Class Initialized
INFO - 2016-10-18 11:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:34:33 --> Controller Class Initialized
INFO - 2016-10-18 11:34:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:34:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:34:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:34:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:34:33 --> Final output sent to browser
DEBUG - 2016-10-18 11:34:33 --> Total execution time: 0.0059
INFO - 2016-10-18 11:35:31 --> Config Class Initialized
INFO - 2016-10-18 11:35:31 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:35:31 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:35:31 --> Utf8 Class Initialized
INFO - 2016-10-18 11:35:31 --> URI Class Initialized
DEBUG - 2016-10-18 11:35:31 --> No URI present. Default controller set.
INFO - 2016-10-18 11:35:31 --> Router Class Initialized
INFO - 2016-10-18 11:35:31 --> Output Class Initialized
INFO - 2016-10-18 11:35:31 --> Security Class Initialized
DEBUG - 2016-10-18 11:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:35:31 --> Input Class Initialized
INFO - 2016-10-18 11:35:31 --> Language Class Initialized
INFO - 2016-10-18 11:35:31 --> Loader Class Initialized
INFO - 2016-10-18 11:35:31 --> Helper loaded: url_helper
INFO - 2016-10-18 11:35:31 --> Helper loaded: form_helper
INFO - 2016-10-18 11:35:31 --> Database Driver Class Initialized
INFO - 2016-10-18 11:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:35:31 --> Controller Class Initialized
INFO - 2016-10-18 11:35:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:35:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:35:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:35:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:35:31 --> Final output sent to browser
DEBUG - 2016-10-18 11:35:31 --> Total execution time: 0.0071
INFO - 2016-10-18 11:35:44 --> Config Class Initialized
INFO - 2016-10-18 11:35:44 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:35:44 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:35:44 --> Utf8 Class Initialized
INFO - 2016-10-18 11:35:44 --> URI Class Initialized
DEBUG - 2016-10-18 11:35:44 --> No URI present. Default controller set.
INFO - 2016-10-18 11:35:44 --> Router Class Initialized
INFO - 2016-10-18 11:35:44 --> Output Class Initialized
INFO - 2016-10-18 11:35:44 --> Security Class Initialized
DEBUG - 2016-10-18 11:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:35:44 --> Input Class Initialized
INFO - 2016-10-18 11:35:44 --> Language Class Initialized
INFO - 2016-10-18 11:35:44 --> Loader Class Initialized
INFO - 2016-10-18 11:35:44 --> Helper loaded: url_helper
INFO - 2016-10-18 11:35:44 --> Helper loaded: form_helper
INFO - 2016-10-18 11:35:44 --> Database Driver Class Initialized
INFO - 2016-10-18 11:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:35:44 --> Controller Class Initialized
INFO - 2016-10-18 11:35:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:35:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:35:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:35:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:35:44 --> Final output sent to browser
DEBUG - 2016-10-18 11:35:44 --> Total execution time: 0.0051
INFO - 2016-10-18 11:37:16 --> Config Class Initialized
INFO - 2016-10-18 11:37:16 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:37:16 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:37:16 --> Utf8 Class Initialized
INFO - 2016-10-18 11:37:16 --> URI Class Initialized
DEBUG - 2016-10-18 11:37:16 --> No URI present. Default controller set.
INFO - 2016-10-18 11:37:16 --> Router Class Initialized
INFO - 2016-10-18 11:37:16 --> Output Class Initialized
INFO - 2016-10-18 11:37:16 --> Security Class Initialized
DEBUG - 2016-10-18 11:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:37:16 --> Input Class Initialized
INFO - 2016-10-18 11:37:16 --> Language Class Initialized
INFO - 2016-10-18 11:37:16 --> Loader Class Initialized
INFO - 2016-10-18 11:37:16 --> Helper loaded: url_helper
INFO - 2016-10-18 11:37:16 --> Helper loaded: form_helper
INFO - 2016-10-18 11:37:16 --> Database Driver Class Initialized
INFO - 2016-10-18 11:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:37:16 --> Controller Class Initialized
INFO - 2016-10-18 11:37:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:37:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:37:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:37:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:37:16 --> Final output sent to browser
DEBUG - 2016-10-18 11:37:16 --> Total execution time: 0.0065
INFO - 2016-10-18 11:38:08 --> Config Class Initialized
INFO - 2016-10-18 11:38:08 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:38:08 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:38:08 --> Utf8 Class Initialized
INFO - 2016-10-18 11:38:08 --> URI Class Initialized
DEBUG - 2016-10-18 11:38:08 --> No URI present. Default controller set.
INFO - 2016-10-18 11:38:08 --> Router Class Initialized
INFO - 2016-10-18 11:38:08 --> Output Class Initialized
INFO - 2016-10-18 11:38:08 --> Security Class Initialized
DEBUG - 2016-10-18 11:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:38:08 --> Input Class Initialized
INFO - 2016-10-18 11:38:08 --> Language Class Initialized
INFO - 2016-10-18 11:38:08 --> Loader Class Initialized
INFO - 2016-10-18 11:38:08 --> Helper loaded: url_helper
INFO - 2016-10-18 11:38:08 --> Helper loaded: form_helper
INFO - 2016-10-18 11:38:08 --> Database Driver Class Initialized
INFO - 2016-10-18 11:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:38:08 --> Controller Class Initialized
INFO - 2016-10-18 11:38:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:38:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:38:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:38:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:38:08 --> Final output sent to browser
DEBUG - 2016-10-18 11:38:08 --> Total execution time: 0.0084
INFO - 2016-10-18 11:38:11 --> Config Class Initialized
INFO - 2016-10-18 11:38:11 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:38:11 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:38:11 --> Utf8 Class Initialized
INFO - 2016-10-18 11:38:11 --> URI Class Initialized
DEBUG - 2016-10-18 11:38:11 --> No URI present. Default controller set.
INFO - 2016-10-18 11:38:11 --> Router Class Initialized
INFO - 2016-10-18 11:38:11 --> Output Class Initialized
INFO - 2016-10-18 11:38:11 --> Security Class Initialized
DEBUG - 2016-10-18 11:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:38:11 --> Input Class Initialized
INFO - 2016-10-18 11:38:11 --> Language Class Initialized
INFO - 2016-10-18 11:38:11 --> Loader Class Initialized
INFO - 2016-10-18 11:38:11 --> Helper loaded: url_helper
INFO - 2016-10-18 11:38:11 --> Helper loaded: form_helper
INFO - 2016-10-18 11:38:11 --> Database Driver Class Initialized
INFO - 2016-10-18 11:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:38:11 --> Controller Class Initialized
INFO - 2016-10-18 11:38:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:38:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:38:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:38:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:38:11 --> Final output sent to browser
DEBUG - 2016-10-18 11:38:11 --> Total execution time: 0.0064
INFO - 2016-10-18 11:39:24 --> Config Class Initialized
INFO - 2016-10-18 11:39:24 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:39:24 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:39:24 --> Utf8 Class Initialized
INFO - 2016-10-18 11:39:24 --> URI Class Initialized
DEBUG - 2016-10-18 11:39:24 --> No URI present. Default controller set.
INFO - 2016-10-18 11:39:24 --> Router Class Initialized
INFO - 2016-10-18 11:39:24 --> Output Class Initialized
INFO - 2016-10-18 11:39:24 --> Security Class Initialized
DEBUG - 2016-10-18 11:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:39:24 --> Input Class Initialized
INFO - 2016-10-18 11:39:24 --> Language Class Initialized
INFO - 2016-10-18 11:39:24 --> Loader Class Initialized
INFO - 2016-10-18 11:39:24 --> Helper loaded: url_helper
INFO - 2016-10-18 11:39:24 --> Helper loaded: form_helper
INFO - 2016-10-18 11:39:24 --> Database Driver Class Initialized
INFO - 2016-10-18 11:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:39:24 --> Controller Class Initialized
INFO - 2016-10-18 11:39:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:39:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:39:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:39:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:39:24 --> Final output sent to browser
DEBUG - 2016-10-18 11:39:24 --> Total execution time: 0.0054
INFO - 2016-10-18 11:39:38 --> Config Class Initialized
INFO - 2016-10-18 11:39:38 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:39:38 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:39:38 --> Utf8 Class Initialized
INFO - 2016-10-18 11:39:38 --> URI Class Initialized
DEBUG - 2016-10-18 11:39:38 --> No URI present. Default controller set.
INFO - 2016-10-18 11:39:38 --> Router Class Initialized
INFO - 2016-10-18 11:39:38 --> Output Class Initialized
INFO - 2016-10-18 11:39:38 --> Security Class Initialized
DEBUG - 2016-10-18 11:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:39:38 --> Input Class Initialized
INFO - 2016-10-18 11:39:38 --> Language Class Initialized
INFO - 2016-10-18 11:39:38 --> Loader Class Initialized
INFO - 2016-10-18 11:39:38 --> Helper loaded: url_helper
INFO - 2016-10-18 11:39:38 --> Helper loaded: form_helper
INFO - 2016-10-18 11:39:38 --> Database Driver Class Initialized
INFO - 2016-10-18 11:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:39:38 --> Controller Class Initialized
INFO - 2016-10-18 11:39:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:39:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:39:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:39:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:39:38 --> Final output sent to browser
DEBUG - 2016-10-18 11:39:38 --> Total execution time: 0.0056
INFO - 2016-10-18 11:42:00 --> Config Class Initialized
INFO - 2016-10-18 11:42:00 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:42:00 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:42:00 --> Utf8 Class Initialized
INFO - 2016-10-18 11:42:00 --> URI Class Initialized
DEBUG - 2016-10-18 11:42:00 --> No URI present. Default controller set.
INFO - 2016-10-18 11:42:00 --> Router Class Initialized
INFO - 2016-10-18 11:42:00 --> Output Class Initialized
INFO - 2016-10-18 11:42:00 --> Security Class Initialized
DEBUG - 2016-10-18 11:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:42:00 --> Input Class Initialized
INFO - 2016-10-18 11:42:00 --> Language Class Initialized
INFO - 2016-10-18 11:42:00 --> Loader Class Initialized
INFO - 2016-10-18 11:42:00 --> Helper loaded: url_helper
INFO - 2016-10-18 11:42:00 --> Helper loaded: form_helper
INFO - 2016-10-18 11:42:00 --> Database Driver Class Initialized
INFO - 2016-10-18 11:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:42:00 --> Controller Class Initialized
INFO - 2016-10-18 11:42:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:42:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:42:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:42:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:42:00 --> Final output sent to browser
DEBUG - 2016-10-18 11:42:00 --> Total execution time: 0.0060
INFO - 2016-10-18 11:42:27 --> Config Class Initialized
INFO - 2016-10-18 11:42:27 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:42:27 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:42:27 --> Utf8 Class Initialized
INFO - 2016-10-18 11:42:27 --> URI Class Initialized
DEBUG - 2016-10-18 11:42:27 --> No URI present. Default controller set.
INFO - 2016-10-18 11:42:27 --> Router Class Initialized
INFO - 2016-10-18 11:42:27 --> Output Class Initialized
INFO - 2016-10-18 11:42:27 --> Security Class Initialized
DEBUG - 2016-10-18 11:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:42:27 --> Input Class Initialized
INFO - 2016-10-18 11:42:27 --> Language Class Initialized
INFO - 2016-10-18 11:42:27 --> Loader Class Initialized
INFO - 2016-10-18 11:42:27 --> Helper loaded: url_helper
INFO - 2016-10-18 11:42:27 --> Helper loaded: form_helper
INFO - 2016-10-18 11:42:27 --> Database Driver Class Initialized
INFO - 2016-10-18 11:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:42:27 --> Controller Class Initialized
INFO - 2016-10-18 11:42:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:42:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:42:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:42:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:42:27 --> Final output sent to browser
DEBUG - 2016-10-18 11:42:27 --> Total execution time: 0.0085
INFO - 2016-10-18 11:42:28 --> Config Class Initialized
INFO - 2016-10-18 11:42:28 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:42:28 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:42:28 --> Utf8 Class Initialized
INFO - 2016-10-18 11:42:28 --> URI Class Initialized
DEBUG - 2016-10-18 11:42:28 --> No URI present. Default controller set.
INFO - 2016-10-18 11:42:28 --> Router Class Initialized
INFO - 2016-10-18 11:42:28 --> Output Class Initialized
INFO - 2016-10-18 11:42:28 --> Security Class Initialized
DEBUG - 2016-10-18 11:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:42:28 --> Input Class Initialized
INFO - 2016-10-18 11:42:28 --> Language Class Initialized
INFO - 2016-10-18 11:42:28 --> Loader Class Initialized
INFO - 2016-10-18 11:42:28 --> Helper loaded: url_helper
INFO - 2016-10-18 11:42:28 --> Helper loaded: form_helper
INFO - 2016-10-18 11:42:28 --> Database Driver Class Initialized
INFO - 2016-10-18 11:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:42:28 --> Controller Class Initialized
INFO - 2016-10-18 11:42:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:42:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:42:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:42:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:42:28 --> Final output sent to browser
DEBUG - 2016-10-18 11:42:28 --> Total execution time: 0.0046
INFO - 2016-10-18 11:42:29 --> Config Class Initialized
INFO - 2016-10-18 11:42:29 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:42:29 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:42:29 --> Utf8 Class Initialized
INFO - 2016-10-18 11:42:29 --> URI Class Initialized
DEBUG - 2016-10-18 11:42:29 --> No URI present. Default controller set.
INFO - 2016-10-18 11:42:29 --> Router Class Initialized
INFO - 2016-10-18 11:42:29 --> Output Class Initialized
INFO - 2016-10-18 11:42:29 --> Security Class Initialized
DEBUG - 2016-10-18 11:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:42:29 --> Input Class Initialized
INFO - 2016-10-18 11:42:29 --> Language Class Initialized
INFO - 2016-10-18 11:42:29 --> Loader Class Initialized
INFO - 2016-10-18 11:42:29 --> Helper loaded: url_helper
INFO - 2016-10-18 11:42:29 --> Helper loaded: form_helper
INFO - 2016-10-18 11:42:29 --> Database Driver Class Initialized
INFO - 2016-10-18 11:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:42:29 --> Controller Class Initialized
INFO - 2016-10-18 11:42:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:42:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:42:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:42:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:42:29 --> Final output sent to browser
DEBUG - 2016-10-18 11:42:29 --> Total execution time: 0.0048
INFO - 2016-10-18 11:42:37 --> Config Class Initialized
INFO - 2016-10-18 11:42:37 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:42:37 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:42:37 --> Utf8 Class Initialized
INFO - 2016-10-18 11:42:37 --> URI Class Initialized
DEBUG - 2016-10-18 11:42:37 --> No URI present. Default controller set.
INFO - 2016-10-18 11:42:37 --> Router Class Initialized
INFO - 2016-10-18 11:42:37 --> Output Class Initialized
INFO - 2016-10-18 11:42:37 --> Security Class Initialized
DEBUG - 2016-10-18 11:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:42:37 --> Input Class Initialized
INFO - 2016-10-18 11:42:37 --> Language Class Initialized
INFO - 2016-10-18 11:42:37 --> Loader Class Initialized
INFO - 2016-10-18 11:42:37 --> Helper loaded: url_helper
INFO - 2016-10-18 11:42:37 --> Helper loaded: form_helper
INFO - 2016-10-18 11:42:37 --> Database Driver Class Initialized
INFO - 2016-10-18 11:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:42:37 --> Controller Class Initialized
INFO - 2016-10-18 11:42:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:42:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:42:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:42:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:42:37 --> Final output sent to browser
DEBUG - 2016-10-18 11:42:37 --> Total execution time: 0.0050
INFO - 2016-10-18 11:42:58 --> Config Class Initialized
INFO - 2016-10-18 11:42:58 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:42:58 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:42:58 --> Utf8 Class Initialized
INFO - 2016-10-18 11:42:58 --> URI Class Initialized
DEBUG - 2016-10-18 11:42:58 --> No URI present. Default controller set.
INFO - 2016-10-18 11:42:58 --> Router Class Initialized
INFO - 2016-10-18 11:42:58 --> Output Class Initialized
INFO - 2016-10-18 11:42:58 --> Security Class Initialized
DEBUG - 2016-10-18 11:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:42:58 --> Input Class Initialized
INFO - 2016-10-18 11:42:58 --> Language Class Initialized
INFO - 2016-10-18 11:42:58 --> Loader Class Initialized
INFO - 2016-10-18 11:42:58 --> Helper loaded: url_helper
INFO - 2016-10-18 11:42:58 --> Helper loaded: form_helper
INFO - 2016-10-18 11:42:58 --> Database Driver Class Initialized
INFO - 2016-10-18 11:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:42:58 --> Controller Class Initialized
INFO - 2016-10-18 11:42:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:42:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:42:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:42:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:42:58 --> Final output sent to browser
DEBUG - 2016-10-18 11:42:58 --> Total execution time: 0.0045
INFO - 2016-10-18 11:43:04 --> Config Class Initialized
INFO - 2016-10-18 11:43:04 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:43:04 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:43:04 --> Utf8 Class Initialized
INFO - 2016-10-18 11:43:04 --> URI Class Initialized
DEBUG - 2016-10-18 11:43:04 --> No URI present. Default controller set.
INFO - 2016-10-18 11:43:04 --> Router Class Initialized
INFO - 2016-10-18 11:43:04 --> Output Class Initialized
INFO - 2016-10-18 11:43:04 --> Security Class Initialized
DEBUG - 2016-10-18 11:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:43:04 --> Input Class Initialized
INFO - 2016-10-18 11:43:04 --> Language Class Initialized
INFO - 2016-10-18 11:43:04 --> Loader Class Initialized
INFO - 2016-10-18 11:43:04 --> Helper loaded: url_helper
INFO - 2016-10-18 11:43:04 --> Helper loaded: form_helper
INFO - 2016-10-18 11:43:04 --> Database Driver Class Initialized
INFO - 2016-10-18 11:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:43:04 --> Controller Class Initialized
INFO - 2016-10-18 11:43:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:43:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:43:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:43:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:43:04 --> Final output sent to browser
DEBUG - 2016-10-18 11:43:04 --> Total execution time: 0.0074
INFO - 2016-10-18 11:43:23 --> Config Class Initialized
INFO - 2016-10-18 11:43:23 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:43:23 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:43:23 --> Utf8 Class Initialized
INFO - 2016-10-18 11:43:23 --> URI Class Initialized
DEBUG - 2016-10-18 11:43:23 --> No URI present. Default controller set.
INFO - 2016-10-18 11:43:23 --> Router Class Initialized
INFO - 2016-10-18 11:43:23 --> Output Class Initialized
INFO - 2016-10-18 11:43:23 --> Security Class Initialized
DEBUG - 2016-10-18 11:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:43:23 --> Input Class Initialized
INFO - 2016-10-18 11:43:23 --> Language Class Initialized
INFO - 2016-10-18 11:43:23 --> Loader Class Initialized
INFO - 2016-10-18 11:43:23 --> Helper loaded: url_helper
INFO - 2016-10-18 11:43:23 --> Helper loaded: form_helper
INFO - 2016-10-18 11:43:23 --> Database Driver Class Initialized
INFO - 2016-10-18 11:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:43:23 --> Controller Class Initialized
INFO - 2016-10-18 11:43:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:43:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:43:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:43:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:43:23 --> Final output sent to browser
DEBUG - 2016-10-18 11:43:23 --> Total execution time: 0.0050
INFO - 2016-10-18 11:47:13 --> Config Class Initialized
INFO - 2016-10-18 11:47:13 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:47:13 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:47:13 --> Utf8 Class Initialized
INFO - 2016-10-18 11:47:13 --> URI Class Initialized
DEBUG - 2016-10-18 11:47:13 --> No URI present. Default controller set.
INFO - 2016-10-18 11:47:13 --> Router Class Initialized
INFO - 2016-10-18 11:47:13 --> Output Class Initialized
INFO - 2016-10-18 11:47:13 --> Security Class Initialized
DEBUG - 2016-10-18 11:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:47:13 --> Input Class Initialized
INFO - 2016-10-18 11:47:13 --> Language Class Initialized
INFO - 2016-10-18 11:47:13 --> Loader Class Initialized
INFO - 2016-10-18 11:47:13 --> Helper loaded: url_helper
INFO - 2016-10-18 11:47:13 --> Helper loaded: form_helper
INFO - 2016-10-18 11:47:13 --> Database Driver Class Initialized
INFO - 2016-10-18 11:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:47:13 --> Controller Class Initialized
INFO - 2016-10-18 11:47:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:47:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:47:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:47:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:47:13 --> Final output sent to browser
DEBUG - 2016-10-18 11:47:13 --> Total execution time: 0.0058
INFO - 2016-10-18 11:47:28 --> Config Class Initialized
INFO - 2016-10-18 11:47:28 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:47:28 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:47:28 --> Utf8 Class Initialized
INFO - 2016-10-18 11:47:28 --> URI Class Initialized
DEBUG - 2016-10-18 11:47:28 --> No URI present. Default controller set.
INFO - 2016-10-18 11:47:28 --> Router Class Initialized
INFO - 2016-10-18 11:47:28 --> Output Class Initialized
INFO - 2016-10-18 11:47:28 --> Security Class Initialized
DEBUG - 2016-10-18 11:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:47:28 --> Input Class Initialized
INFO - 2016-10-18 11:47:28 --> Language Class Initialized
INFO - 2016-10-18 11:47:28 --> Loader Class Initialized
INFO - 2016-10-18 11:47:28 --> Helper loaded: url_helper
INFO - 2016-10-18 11:47:28 --> Helper loaded: form_helper
INFO - 2016-10-18 11:47:28 --> Database Driver Class Initialized
INFO - 2016-10-18 11:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:47:28 --> Controller Class Initialized
INFO - 2016-10-18 11:47:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:47:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:47:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:47:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:47:28 --> Final output sent to browser
DEBUG - 2016-10-18 11:47:28 --> Total execution time: 0.0050
INFO - 2016-10-18 11:48:39 --> Config Class Initialized
INFO - 2016-10-18 11:48:39 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:48:39 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:48:39 --> Utf8 Class Initialized
INFO - 2016-10-18 11:48:39 --> URI Class Initialized
DEBUG - 2016-10-18 11:48:39 --> No URI present. Default controller set.
INFO - 2016-10-18 11:48:39 --> Router Class Initialized
INFO - 2016-10-18 11:48:39 --> Output Class Initialized
INFO - 2016-10-18 11:48:39 --> Security Class Initialized
DEBUG - 2016-10-18 11:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:48:39 --> Input Class Initialized
INFO - 2016-10-18 11:48:39 --> Language Class Initialized
INFO - 2016-10-18 11:48:39 --> Loader Class Initialized
INFO - 2016-10-18 11:48:39 --> Helper loaded: url_helper
INFO - 2016-10-18 11:48:39 --> Helper loaded: form_helper
INFO - 2016-10-18 11:48:39 --> Database Driver Class Initialized
INFO - 2016-10-18 11:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:48:39 --> Controller Class Initialized
INFO - 2016-10-18 11:48:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:48:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:48:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:48:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:48:39 --> Final output sent to browser
DEBUG - 2016-10-18 11:48:39 --> Total execution time: 0.1945
INFO - 2016-10-18 11:49:08 --> Config Class Initialized
INFO - 2016-10-18 11:49:08 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:49:08 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:49:08 --> Utf8 Class Initialized
INFO - 2016-10-18 11:49:08 --> URI Class Initialized
DEBUG - 2016-10-18 11:49:08 --> No URI present. Default controller set.
INFO - 2016-10-18 11:49:08 --> Router Class Initialized
INFO - 2016-10-18 11:49:08 --> Output Class Initialized
INFO - 2016-10-18 11:49:08 --> Security Class Initialized
DEBUG - 2016-10-18 11:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:49:08 --> Input Class Initialized
INFO - 2016-10-18 11:49:08 --> Language Class Initialized
INFO - 2016-10-18 11:49:08 --> Loader Class Initialized
INFO - 2016-10-18 11:49:08 --> Helper loaded: url_helper
INFO - 2016-10-18 11:49:08 --> Helper loaded: form_helper
INFO - 2016-10-18 11:49:08 --> Database Driver Class Initialized
INFO - 2016-10-18 11:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:49:08 --> Controller Class Initialized
INFO - 2016-10-18 11:49:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:49:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:49:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:49:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:49:08 --> Final output sent to browser
DEBUG - 2016-10-18 11:49:08 --> Total execution time: 0.0057
INFO - 2016-10-18 11:50:14 --> Config Class Initialized
INFO - 2016-10-18 11:50:14 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:50:14 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:50:14 --> Utf8 Class Initialized
INFO - 2016-10-18 11:50:14 --> URI Class Initialized
DEBUG - 2016-10-18 11:50:14 --> No URI present. Default controller set.
INFO - 2016-10-18 11:50:14 --> Router Class Initialized
INFO - 2016-10-18 11:50:14 --> Output Class Initialized
INFO - 2016-10-18 11:50:14 --> Security Class Initialized
DEBUG - 2016-10-18 11:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:50:14 --> Input Class Initialized
INFO - 2016-10-18 11:50:14 --> Language Class Initialized
INFO - 2016-10-18 11:50:14 --> Loader Class Initialized
INFO - 2016-10-18 11:50:14 --> Helper loaded: url_helper
INFO - 2016-10-18 11:50:14 --> Helper loaded: form_helper
INFO - 2016-10-18 11:50:14 --> Database Driver Class Initialized
INFO - 2016-10-18 11:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:50:14 --> Controller Class Initialized
INFO - 2016-10-18 11:50:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:50:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:50:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:50:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:50:14 --> Final output sent to browser
DEBUG - 2016-10-18 11:50:14 --> Total execution time: 0.0231
INFO - 2016-10-18 11:50:38 --> Config Class Initialized
INFO - 2016-10-18 11:50:38 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:50:38 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:50:38 --> Utf8 Class Initialized
INFO - 2016-10-18 11:50:38 --> URI Class Initialized
DEBUG - 2016-10-18 11:50:38 --> No URI present. Default controller set.
INFO - 2016-10-18 11:50:38 --> Router Class Initialized
INFO - 2016-10-18 11:50:38 --> Output Class Initialized
INFO - 2016-10-18 11:50:38 --> Security Class Initialized
DEBUG - 2016-10-18 11:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:50:38 --> Input Class Initialized
INFO - 2016-10-18 11:50:38 --> Language Class Initialized
INFO - 2016-10-18 11:50:38 --> Loader Class Initialized
INFO - 2016-10-18 11:50:38 --> Helper loaded: url_helper
INFO - 2016-10-18 11:50:38 --> Helper loaded: form_helper
INFO - 2016-10-18 11:50:38 --> Database Driver Class Initialized
INFO - 2016-10-18 11:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:50:38 --> Controller Class Initialized
INFO - 2016-10-18 11:50:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:50:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:50:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:50:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:50:38 --> Final output sent to browser
DEBUG - 2016-10-18 11:50:38 --> Total execution time: 0.0085
INFO - 2016-10-18 11:50:43 --> Config Class Initialized
INFO - 2016-10-18 11:50:43 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:50:43 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:50:43 --> Utf8 Class Initialized
INFO - 2016-10-18 11:50:43 --> URI Class Initialized
INFO - 2016-10-18 11:50:43 --> Router Class Initialized
INFO - 2016-10-18 11:50:43 --> Output Class Initialized
INFO - 2016-10-18 11:50:43 --> Security Class Initialized
DEBUG - 2016-10-18 11:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:50:43 --> Input Class Initialized
INFO - 2016-10-18 11:50:43 --> Language Class Initialized
INFO - 2016-10-18 11:50:43 --> Loader Class Initialized
INFO - 2016-10-18 11:50:43 --> Helper loaded: url_helper
INFO - 2016-10-18 11:50:43 --> Helper loaded: form_helper
INFO - 2016-10-18 11:50:43 --> Database Driver Class Initialized
INFO - 2016-10-18 11:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:50:43 --> Controller Class Initialized
ERROR - 2016-10-18 11:50:43 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 121
ERROR - 2016-10-18 11:50:43 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 121
INFO - 2016-10-18 11:50:43 --> Config Class Initialized
INFO - 2016-10-18 11:50:43 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:50:43 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:50:43 --> Utf8 Class Initialized
INFO - 2016-10-18 11:50:43 --> URI Class Initialized
DEBUG - 2016-10-18 11:50:43 --> No URI present. Default controller set.
INFO - 2016-10-18 11:50:43 --> Router Class Initialized
INFO - 2016-10-18 11:50:43 --> Output Class Initialized
INFO - 2016-10-18 11:50:43 --> Security Class Initialized
DEBUG - 2016-10-18 11:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:50:43 --> Input Class Initialized
INFO - 2016-10-18 11:50:43 --> Language Class Initialized
INFO - 2016-10-18 11:50:43 --> Loader Class Initialized
INFO - 2016-10-18 11:50:43 --> Helper loaded: url_helper
INFO - 2016-10-18 11:50:43 --> Helper loaded: form_helper
INFO - 2016-10-18 11:50:43 --> Database Driver Class Initialized
INFO - 2016-10-18 11:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:50:43 --> Controller Class Initialized
INFO - 2016-10-18 11:50:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:50:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 11:50:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:50:43 --> Final output sent to browser
DEBUG - 2016-10-18 11:50:43 --> Total execution time: 0.0045
INFO - 2016-10-18 11:50:49 --> Config Class Initialized
INFO - 2016-10-18 11:50:49 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:50:49 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:50:49 --> Utf8 Class Initialized
INFO - 2016-10-18 11:50:49 --> URI Class Initialized
INFO - 2016-10-18 11:50:49 --> Router Class Initialized
INFO - 2016-10-18 11:50:49 --> Output Class Initialized
INFO - 2016-10-18 11:50:49 --> Security Class Initialized
DEBUG - 2016-10-18 11:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:50:49 --> Input Class Initialized
INFO - 2016-10-18 11:50:49 --> Language Class Initialized
INFO - 2016-10-18 11:50:49 --> Loader Class Initialized
INFO - 2016-10-18 11:50:49 --> Helper loaded: url_helper
INFO - 2016-10-18 11:50:49 --> Helper loaded: form_helper
INFO - 2016-10-18 11:50:49 --> Database Driver Class Initialized
INFO - 2016-10-18 11:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:50:49 --> Controller Class Initialized
INFO - 2016-10-18 11:50:49 --> Model Class Initialized
INFO - 2016-10-18 11:50:49 --> Final output sent to browser
DEBUG - 2016-10-18 11:50:49 --> Total execution time: 0.0054
INFO - 2016-10-18 11:50:50 --> Config Class Initialized
INFO - 2016-10-18 11:50:50 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:50:50 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:50:50 --> Utf8 Class Initialized
INFO - 2016-10-18 11:50:50 --> URI Class Initialized
DEBUG - 2016-10-18 11:50:50 --> No URI present. Default controller set.
INFO - 2016-10-18 11:50:50 --> Router Class Initialized
INFO - 2016-10-18 11:50:50 --> Output Class Initialized
INFO - 2016-10-18 11:50:50 --> Security Class Initialized
DEBUG - 2016-10-18 11:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:50:50 --> Input Class Initialized
INFO - 2016-10-18 11:50:50 --> Language Class Initialized
INFO - 2016-10-18 11:50:50 --> Loader Class Initialized
INFO - 2016-10-18 11:50:50 --> Helper loaded: url_helper
INFO - 2016-10-18 11:50:50 --> Helper loaded: form_helper
INFO - 2016-10-18 11:50:50 --> Database Driver Class Initialized
INFO - 2016-10-18 11:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:50:50 --> Controller Class Initialized
INFO - 2016-10-18 11:50:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:50:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:50:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:50:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:50:50 --> Final output sent to browser
DEBUG - 2016-10-18 11:50:50 --> Total execution time: 0.0041
INFO - 2016-10-18 11:52:12 --> Config Class Initialized
INFO - 2016-10-18 11:52:12 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:52:12 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:52:12 --> Utf8 Class Initialized
INFO - 2016-10-18 11:52:12 --> URI Class Initialized
DEBUG - 2016-10-18 11:52:12 --> No URI present. Default controller set.
INFO - 2016-10-18 11:52:12 --> Router Class Initialized
INFO - 2016-10-18 11:52:12 --> Output Class Initialized
INFO - 2016-10-18 11:52:12 --> Security Class Initialized
DEBUG - 2016-10-18 11:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:52:12 --> Input Class Initialized
INFO - 2016-10-18 11:52:12 --> Language Class Initialized
INFO - 2016-10-18 11:52:12 --> Loader Class Initialized
INFO - 2016-10-18 11:52:12 --> Helper loaded: url_helper
INFO - 2016-10-18 11:52:12 --> Helper loaded: form_helper
INFO - 2016-10-18 11:52:12 --> Database Driver Class Initialized
INFO - 2016-10-18 11:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:52:13 --> Controller Class Initialized
INFO - 2016-10-18 11:52:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:52:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:52:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:52:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:52:13 --> Final output sent to browser
DEBUG - 2016-10-18 11:52:13 --> Total execution time: 0.0088
INFO - 2016-10-18 11:52:14 --> Config Class Initialized
INFO - 2016-10-18 11:52:14 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:52:14 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:52:14 --> Utf8 Class Initialized
INFO - 2016-10-18 11:52:14 --> URI Class Initialized
DEBUG - 2016-10-18 11:52:14 --> No URI present. Default controller set.
INFO - 2016-10-18 11:52:14 --> Router Class Initialized
INFO - 2016-10-18 11:52:14 --> Output Class Initialized
INFO - 2016-10-18 11:52:14 --> Security Class Initialized
DEBUG - 2016-10-18 11:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:52:14 --> Input Class Initialized
INFO - 2016-10-18 11:52:14 --> Language Class Initialized
INFO - 2016-10-18 11:52:14 --> Loader Class Initialized
INFO - 2016-10-18 11:52:14 --> Helper loaded: url_helper
INFO - 2016-10-18 11:52:14 --> Helper loaded: form_helper
INFO - 2016-10-18 11:52:14 --> Database Driver Class Initialized
INFO - 2016-10-18 11:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:52:14 --> Controller Class Initialized
INFO - 2016-10-18 11:52:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:52:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:52:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:52:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:52:14 --> Final output sent to browser
DEBUG - 2016-10-18 11:52:14 --> Total execution time: 0.0072
INFO - 2016-10-18 11:52:41 --> Config Class Initialized
INFO - 2016-10-18 11:52:41 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:52:41 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:52:41 --> Utf8 Class Initialized
INFO - 2016-10-18 11:52:41 --> URI Class Initialized
DEBUG - 2016-10-18 11:52:41 --> No URI present. Default controller set.
INFO - 2016-10-18 11:52:41 --> Router Class Initialized
INFO - 2016-10-18 11:52:41 --> Output Class Initialized
INFO - 2016-10-18 11:52:41 --> Security Class Initialized
DEBUG - 2016-10-18 11:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:52:41 --> Input Class Initialized
INFO - 2016-10-18 11:52:41 --> Language Class Initialized
INFO - 2016-10-18 11:52:41 --> Loader Class Initialized
INFO - 2016-10-18 11:52:41 --> Helper loaded: url_helper
INFO - 2016-10-18 11:52:41 --> Helper loaded: form_helper
INFO - 2016-10-18 11:52:41 --> Database Driver Class Initialized
INFO - 2016-10-18 11:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:52:41 --> Controller Class Initialized
INFO - 2016-10-18 11:52:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:52:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:52:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:52:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:52:41 --> Final output sent to browser
DEBUG - 2016-10-18 11:52:41 --> Total execution time: 0.0055
INFO - 2016-10-18 11:54:59 --> Config Class Initialized
INFO - 2016-10-18 11:54:59 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:54:59 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:54:59 --> Utf8 Class Initialized
INFO - 2016-10-18 11:54:59 --> URI Class Initialized
DEBUG - 2016-10-18 11:54:59 --> No URI present. Default controller set.
INFO - 2016-10-18 11:54:59 --> Router Class Initialized
INFO - 2016-10-18 11:54:59 --> Output Class Initialized
INFO - 2016-10-18 11:54:59 --> Security Class Initialized
DEBUG - 2016-10-18 11:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:54:59 --> Input Class Initialized
INFO - 2016-10-18 11:54:59 --> Language Class Initialized
INFO - 2016-10-18 11:54:59 --> Loader Class Initialized
INFO - 2016-10-18 11:54:59 --> Helper loaded: url_helper
INFO - 2016-10-18 11:54:59 --> Helper loaded: form_helper
INFO - 2016-10-18 11:54:59 --> Database Driver Class Initialized
INFO - 2016-10-18 11:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:54:59 --> Controller Class Initialized
INFO - 2016-10-18 11:54:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:54:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:54:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:54:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:54:59 --> Final output sent to browser
DEBUG - 2016-10-18 11:54:59 --> Total execution time: 0.0054
INFO - 2016-10-18 11:55:01 --> Config Class Initialized
INFO - 2016-10-18 11:55:01 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:55:01 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:55:01 --> Utf8 Class Initialized
INFO - 2016-10-18 11:55:01 --> URI Class Initialized
DEBUG - 2016-10-18 11:55:01 --> No URI present. Default controller set.
INFO - 2016-10-18 11:55:01 --> Router Class Initialized
INFO - 2016-10-18 11:55:01 --> Output Class Initialized
INFO - 2016-10-18 11:55:01 --> Security Class Initialized
DEBUG - 2016-10-18 11:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:55:01 --> Input Class Initialized
INFO - 2016-10-18 11:55:01 --> Language Class Initialized
INFO - 2016-10-18 11:55:01 --> Loader Class Initialized
INFO - 2016-10-18 11:55:01 --> Helper loaded: url_helper
INFO - 2016-10-18 11:55:01 --> Helper loaded: form_helper
INFO - 2016-10-18 11:55:01 --> Database Driver Class Initialized
INFO - 2016-10-18 11:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:55:01 --> Controller Class Initialized
INFO - 2016-10-18 11:55:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:55:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:55:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:55:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:55:01 --> Final output sent to browser
DEBUG - 2016-10-18 11:55:01 --> Total execution time: 0.0050
INFO - 2016-10-18 11:55:15 --> Config Class Initialized
INFO - 2016-10-18 11:55:15 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:55:15 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:55:15 --> Utf8 Class Initialized
INFO - 2016-10-18 11:55:15 --> URI Class Initialized
DEBUG - 2016-10-18 11:55:15 --> No URI present. Default controller set.
INFO - 2016-10-18 11:55:15 --> Router Class Initialized
INFO - 2016-10-18 11:55:15 --> Output Class Initialized
INFO - 2016-10-18 11:55:15 --> Security Class Initialized
DEBUG - 2016-10-18 11:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:55:15 --> Input Class Initialized
INFO - 2016-10-18 11:55:15 --> Language Class Initialized
INFO - 2016-10-18 11:55:15 --> Loader Class Initialized
INFO - 2016-10-18 11:55:15 --> Helper loaded: url_helper
INFO - 2016-10-18 11:55:15 --> Helper loaded: form_helper
INFO - 2016-10-18 11:55:15 --> Database Driver Class Initialized
INFO - 2016-10-18 11:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:55:15 --> Controller Class Initialized
INFO - 2016-10-18 11:55:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:55:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:55:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:55:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:55:15 --> Final output sent to browser
DEBUG - 2016-10-18 11:55:15 --> Total execution time: 0.0060
INFO - 2016-10-18 11:55:16 --> Config Class Initialized
INFO - 2016-10-18 11:55:16 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:55:16 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:55:16 --> Utf8 Class Initialized
INFO - 2016-10-18 11:55:16 --> URI Class Initialized
DEBUG - 2016-10-18 11:55:16 --> No URI present. Default controller set.
INFO - 2016-10-18 11:55:16 --> Router Class Initialized
INFO - 2016-10-18 11:55:16 --> Output Class Initialized
INFO - 2016-10-18 11:55:16 --> Security Class Initialized
DEBUG - 2016-10-18 11:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:55:16 --> Input Class Initialized
INFO - 2016-10-18 11:55:16 --> Language Class Initialized
INFO - 2016-10-18 11:55:16 --> Loader Class Initialized
INFO - 2016-10-18 11:55:16 --> Helper loaded: url_helper
INFO - 2016-10-18 11:55:16 --> Helper loaded: form_helper
INFO - 2016-10-18 11:55:16 --> Database Driver Class Initialized
INFO - 2016-10-18 11:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:55:16 --> Controller Class Initialized
INFO - 2016-10-18 11:55:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:55:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:55:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:55:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:55:16 --> Final output sent to browser
DEBUG - 2016-10-18 11:55:16 --> Total execution time: 0.0054
INFO - 2016-10-18 11:56:15 --> Config Class Initialized
INFO - 2016-10-18 11:56:15 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:56:15 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:56:15 --> Utf8 Class Initialized
INFO - 2016-10-18 11:56:15 --> URI Class Initialized
DEBUG - 2016-10-18 11:56:15 --> No URI present. Default controller set.
INFO - 2016-10-18 11:56:15 --> Router Class Initialized
INFO - 2016-10-18 11:56:15 --> Output Class Initialized
INFO - 2016-10-18 11:56:15 --> Security Class Initialized
DEBUG - 2016-10-18 11:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:56:15 --> Input Class Initialized
INFO - 2016-10-18 11:56:15 --> Language Class Initialized
INFO - 2016-10-18 11:56:15 --> Loader Class Initialized
INFO - 2016-10-18 11:56:15 --> Helper loaded: url_helper
INFO - 2016-10-18 11:56:15 --> Helper loaded: form_helper
INFO - 2016-10-18 11:56:15 --> Database Driver Class Initialized
INFO - 2016-10-18 11:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:56:15 --> Controller Class Initialized
INFO - 2016-10-18 11:56:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:56:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:56:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:56:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:56:15 --> Final output sent to browser
DEBUG - 2016-10-18 11:56:15 --> Total execution time: 0.0067
INFO - 2016-10-18 11:56:28 --> Config Class Initialized
INFO - 2016-10-18 11:56:28 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:56:28 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:56:28 --> Utf8 Class Initialized
INFO - 2016-10-18 11:56:28 --> URI Class Initialized
DEBUG - 2016-10-18 11:56:28 --> No URI present. Default controller set.
INFO - 2016-10-18 11:56:28 --> Router Class Initialized
INFO - 2016-10-18 11:56:28 --> Output Class Initialized
INFO - 2016-10-18 11:56:28 --> Security Class Initialized
DEBUG - 2016-10-18 11:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:56:28 --> Input Class Initialized
INFO - 2016-10-18 11:56:28 --> Language Class Initialized
INFO - 2016-10-18 11:56:28 --> Loader Class Initialized
INFO - 2016-10-18 11:56:28 --> Helper loaded: url_helper
INFO - 2016-10-18 11:56:28 --> Helper loaded: form_helper
INFO - 2016-10-18 11:56:28 --> Database Driver Class Initialized
INFO - 2016-10-18 11:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:56:28 --> Controller Class Initialized
INFO - 2016-10-18 11:56:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:56:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 11:56:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 11:56:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:56:28 --> Final output sent to browser
DEBUG - 2016-10-18 11:56:28 --> Total execution time: 0.0059
INFO - 2016-10-18 11:56:54 --> Config Class Initialized
INFO - 2016-10-18 11:56:54 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:56:54 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:56:54 --> Utf8 Class Initialized
INFO - 2016-10-18 11:56:54 --> URI Class Initialized
INFO - 2016-10-18 11:56:54 --> Router Class Initialized
INFO - 2016-10-18 11:56:54 --> Output Class Initialized
INFO - 2016-10-18 11:56:54 --> Security Class Initialized
DEBUG - 2016-10-18 11:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:56:54 --> Input Class Initialized
INFO - 2016-10-18 11:56:54 --> Language Class Initialized
INFO - 2016-10-18 11:56:54 --> Loader Class Initialized
INFO - 2016-10-18 11:56:54 --> Helper loaded: url_helper
INFO - 2016-10-18 11:56:54 --> Helper loaded: form_helper
INFO - 2016-10-18 11:56:54 --> Database Driver Class Initialized
INFO - 2016-10-18 11:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:56:54 --> Controller Class Initialized
ERROR - 2016-10-18 11:56:54 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 121
ERROR - 2016-10-18 11:56:54 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 121
INFO - 2016-10-18 11:56:54 --> Config Class Initialized
INFO - 2016-10-18 11:56:54 --> Hooks Class Initialized
DEBUG - 2016-10-18 11:56:54 --> UTF-8 Support Enabled
INFO - 2016-10-18 11:56:54 --> Utf8 Class Initialized
INFO - 2016-10-18 11:56:54 --> URI Class Initialized
DEBUG - 2016-10-18 11:56:54 --> No URI present. Default controller set.
INFO - 2016-10-18 11:56:54 --> Router Class Initialized
INFO - 2016-10-18 11:56:54 --> Output Class Initialized
INFO - 2016-10-18 11:56:54 --> Security Class Initialized
DEBUG - 2016-10-18 11:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 11:56:54 --> Input Class Initialized
INFO - 2016-10-18 11:56:54 --> Language Class Initialized
INFO - 2016-10-18 11:56:54 --> Loader Class Initialized
INFO - 2016-10-18 11:56:54 --> Helper loaded: url_helper
INFO - 2016-10-18 11:56:54 --> Helper loaded: form_helper
INFO - 2016-10-18 11:56:54 --> Database Driver Class Initialized
INFO - 2016-10-18 11:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 11:56:54 --> Controller Class Initialized
INFO - 2016-10-18 11:56:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 11:56:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 11:56:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 11:56:54 --> Final output sent to browser
DEBUG - 2016-10-18 11:56:54 --> Total execution time: 0.0039
INFO - 2016-10-18 12:17:52 --> Config Class Initialized
INFO - 2016-10-18 12:17:52 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:17:52 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:17:52 --> Utf8 Class Initialized
INFO - 2016-10-18 12:17:52 --> URI Class Initialized
DEBUG - 2016-10-18 12:17:52 --> No URI present. Default controller set.
INFO - 2016-10-18 12:17:52 --> Router Class Initialized
INFO - 2016-10-18 12:17:52 --> Output Class Initialized
INFO - 2016-10-18 12:17:52 --> Security Class Initialized
DEBUG - 2016-10-18 12:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:17:52 --> Input Class Initialized
INFO - 2016-10-18 12:17:52 --> Language Class Initialized
INFO - 2016-10-18 12:17:52 --> Loader Class Initialized
INFO - 2016-10-18 12:17:52 --> Helper loaded: url_helper
INFO - 2016-10-18 12:17:52 --> Helper loaded: form_helper
INFO - 2016-10-18 12:17:52 --> Database Driver Class Initialized
INFO - 2016-10-18 12:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:17:52 --> Controller Class Initialized
INFO - 2016-10-18 12:17:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:17:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 12:17:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:17:52 --> Final output sent to browser
DEBUG - 2016-10-18 12:17:52 --> Total execution time: 0.0081
INFO - 2016-10-18 12:34:42 --> Config Class Initialized
INFO - 2016-10-18 12:34:42 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:34:42 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:34:42 --> Utf8 Class Initialized
INFO - 2016-10-18 12:34:42 --> URI Class Initialized
DEBUG - 2016-10-18 12:34:42 --> No URI present. Default controller set.
INFO - 2016-10-18 12:34:42 --> Router Class Initialized
INFO - 2016-10-18 12:34:42 --> Output Class Initialized
INFO - 2016-10-18 12:34:42 --> Security Class Initialized
DEBUG - 2016-10-18 12:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:34:42 --> Input Class Initialized
INFO - 2016-10-18 12:34:42 --> Language Class Initialized
INFO - 2016-10-18 12:34:42 --> Loader Class Initialized
INFO - 2016-10-18 12:34:42 --> Helper loaded: url_helper
INFO - 2016-10-18 12:34:42 --> Helper loaded: form_helper
INFO - 2016-10-18 12:34:42 --> Database Driver Class Initialized
INFO - 2016-10-18 12:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:34:42 --> Controller Class Initialized
INFO - 2016-10-18 12:34:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:34:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 12:34:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:34:42 --> Final output sent to browser
DEBUG - 2016-10-18 12:34:42 --> Total execution time: 0.1175
INFO - 2016-10-18 12:34:48 --> Config Class Initialized
INFO - 2016-10-18 12:34:48 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:34:48 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:34:48 --> Utf8 Class Initialized
INFO - 2016-10-18 12:34:48 --> URI Class Initialized
INFO - 2016-10-18 12:34:48 --> Router Class Initialized
INFO - 2016-10-18 12:34:48 --> Output Class Initialized
INFO - 2016-10-18 12:34:48 --> Security Class Initialized
DEBUG - 2016-10-18 12:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:34:48 --> Input Class Initialized
INFO - 2016-10-18 12:34:48 --> Language Class Initialized
INFO - 2016-10-18 12:34:48 --> Loader Class Initialized
INFO - 2016-10-18 12:34:48 --> Helper loaded: url_helper
INFO - 2016-10-18 12:34:48 --> Helper loaded: form_helper
INFO - 2016-10-18 12:34:48 --> Database Driver Class Initialized
INFO - 2016-10-18 12:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:34:48 --> Controller Class Initialized
INFO - 2016-10-18 12:34:48 --> Model Class Initialized
INFO - 2016-10-18 12:34:48 --> Final output sent to browser
DEBUG - 2016-10-18 12:34:48 --> Total execution time: 0.0077
INFO - 2016-10-18 12:34:48 --> Config Class Initialized
INFO - 2016-10-18 12:34:48 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:34:48 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:34:48 --> Utf8 Class Initialized
INFO - 2016-10-18 12:34:48 --> URI Class Initialized
DEBUG - 2016-10-18 12:34:48 --> No URI present. Default controller set.
INFO - 2016-10-18 12:34:48 --> Router Class Initialized
INFO - 2016-10-18 12:34:48 --> Output Class Initialized
INFO - 2016-10-18 12:34:48 --> Security Class Initialized
DEBUG - 2016-10-18 12:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:34:48 --> Input Class Initialized
INFO - 2016-10-18 12:34:48 --> Language Class Initialized
INFO - 2016-10-18 12:34:48 --> Loader Class Initialized
INFO - 2016-10-18 12:34:48 --> Helper loaded: url_helper
INFO - 2016-10-18 12:34:48 --> Helper loaded: form_helper
INFO - 2016-10-18 12:34:48 --> Database Driver Class Initialized
INFO - 2016-10-18 12:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:34:48 --> Controller Class Initialized
INFO - 2016-10-18 12:34:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:34:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:34:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:34:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:34:48 --> Final output sent to browser
DEBUG - 2016-10-18 12:34:48 --> Total execution time: 0.0044
INFO - 2016-10-18 12:34:54 --> Config Class Initialized
INFO - 2016-10-18 12:34:54 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:34:54 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:34:54 --> Utf8 Class Initialized
INFO - 2016-10-18 12:34:54 --> URI Class Initialized
DEBUG - 2016-10-18 12:34:54 --> No URI present. Default controller set.
INFO - 2016-10-18 12:34:54 --> Router Class Initialized
INFO - 2016-10-18 12:34:54 --> Output Class Initialized
INFO - 2016-10-18 12:34:54 --> Security Class Initialized
DEBUG - 2016-10-18 12:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:34:54 --> Input Class Initialized
INFO - 2016-10-18 12:34:54 --> Language Class Initialized
INFO - 2016-10-18 12:34:54 --> Loader Class Initialized
INFO - 2016-10-18 12:34:54 --> Helper loaded: url_helper
INFO - 2016-10-18 12:34:54 --> Helper loaded: form_helper
INFO - 2016-10-18 12:34:54 --> Database Driver Class Initialized
INFO - 2016-10-18 12:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:34:54 --> Controller Class Initialized
INFO - 2016-10-18 12:34:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:34:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:34:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:34:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:34:54 --> Final output sent to browser
DEBUG - 2016-10-18 12:34:54 --> Total execution time: 0.0077
INFO - 2016-10-18 12:34:58 --> Config Class Initialized
INFO - 2016-10-18 12:34:58 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:34:58 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:34:58 --> Utf8 Class Initialized
INFO - 2016-10-18 12:34:58 --> URI Class Initialized
INFO - 2016-10-18 12:34:58 --> Router Class Initialized
INFO - 2016-10-18 12:34:58 --> Output Class Initialized
INFO - 2016-10-18 12:34:58 --> Security Class Initialized
DEBUG - 2016-10-18 12:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:34:58 --> Input Class Initialized
INFO - 2016-10-18 12:34:58 --> Language Class Initialized
INFO - 2016-10-18 12:34:58 --> Loader Class Initialized
INFO - 2016-10-18 12:34:58 --> Helper loaded: url_helper
INFO - 2016-10-18 12:34:58 --> Helper loaded: form_helper
INFO - 2016-10-18 12:34:58 --> Database Driver Class Initialized
INFO - 2016-10-18 12:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:34:58 --> Controller Class Initialized
INFO - 2016-10-18 12:34:58 --> Form Validation Class Initialized
INFO - 2016-10-18 12:34:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 12:34:58 --> Final output sent to browser
DEBUG - 2016-10-18 12:34:58 --> Total execution time: 0.0451
INFO - 2016-10-18 12:35:12 --> Config Class Initialized
INFO - 2016-10-18 12:35:12 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:35:12 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:35:12 --> Utf8 Class Initialized
INFO - 2016-10-18 12:35:12 --> URI Class Initialized
INFO - 2016-10-18 12:35:12 --> Router Class Initialized
INFO - 2016-10-18 12:35:12 --> Output Class Initialized
INFO - 2016-10-18 12:35:12 --> Security Class Initialized
DEBUG - 2016-10-18 12:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:35:12 --> Input Class Initialized
INFO - 2016-10-18 12:35:12 --> Language Class Initialized
INFO - 2016-10-18 12:35:12 --> Loader Class Initialized
INFO - 2016-10-18 12:35:12 --> Helper loaded: url_helper
INFO - 2016-10-18 12:35:12 --> Helper loaded: form_helper
INFO - 2016-10-18 12:35:12 --> Database Driver Class Initialized
INFO - 2016-10-18 12:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:35:12 --> Controller Class Initialized
INFO - 2016-10-18 12:35:12 --> Form Validation Class Initialized
INFO - 2016-10-18 12:35:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 12:35:12 --> Final output sent to browser
DEBUG - 2016-10-18 12:35:12 --> Total execution time: 0.0050
INFO - 2016-10-18 12:35:47 --> Config Class Initialized
INFO - 2016-10-18 12:35:47 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:35:47 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:35:47 --> Utf8 Class Initialized
INFO - 2016-10-18 12:35:47 --> URI Class Initialized
DEBUG - 2016-10-18 12:35:47 --> No URI present. Default controller set.
INFO - 2016-10-18 12:35:47 --> Router Class Initialized
INFO - 2016-10-18 12:35:47 --> Output Class Initialized
INFO - 2016-10-18 12:35:47 --> Security Class Initialized
DEBUG - 2016-10-18 12:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:35:47 --> Input Class Initialized
INFO - 2016-10-18 12:35:47 --> Language Class Initialized
INFO - 2016-10-18 12:35:47 --> Loader Class Initialized
INFO - 2016-10-18 12:35:47 --> Helper loaded: url_helper
INFO - 2016-10-18 12:35:47 --> Helper loaded: form_helper
INFO - 2016-10-18 12:35:47 --> Database Driver Class Initialized
INFO - 2016-10-18 12:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:35:47 --> Controller Class Initialized
INFO - 2016-10-18 12:35:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:35:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:35:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:35:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:35:47 --> Final output sent to browser
DEBUG - 2016-10-18 12:35:47 --> Total execution time: 0.0087
INFO - 2016-10-18 12:36:00 --> Config Class Initialized
INFO - 2016-10-18 12:36:00 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:36:00 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:36:00 --> Utf8 Class Initialized
INFO - 2016-10-18 12:36:00 --> URI Class Initialized
DEBUG - 2016-10-18 12:36:00 --> No URI present. Default controller set.
INFO - 2016-10-18 12:36:00 --> Router Class Initialized
INFO - 2016-10-18 12:36:00 --> Output Class Initialized
INFO - 2016-10-18 12:36:00 --> Security Class Initialized
DEBUG - 2016-10-18 12:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:36:00 --> Input Class Initialized
INFO - 2016-10-18 12:36:00 --> Language Class Initialized
INFO - 2016-10-18 12:36:00 --> Loader Class Initialized
INFO - 2016-10-18 12:36:00 --> Helper loaded: url_helper
INFO - 2016-10-18 12:36:00 --> Helper loaded: form_helper
INFO - 2016-10-18 12:36:00 --> Database Driver Class Initialized
INFO - 2016-10-18 12:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:36:00 --> Controller Class Initialized
INFO - 2016-10-18 12:36:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:36:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:36:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:36:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:36:00 --> Final output sent to browser
DEBUG - 2016-10-18 12:36:00 --> Total execution time: 0.0052
INFO - 2016-10-18 12:36:17 --> Config Class Initialized
INFO - 2016-10-18 12:36:17 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:36:17 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:36:17 --> Utf8 Class Initialized
INFO - 2016-10-18 12:36:17 --> URI Class Initialized
INFO - 2016-10-18 12:36:17 --> Router Class Initialized
INFO - 2016-10-18 12:36:17 --> Output Class Initialized
INFO - 2016-10-18 12:36:17 --> Security Class Initialized
DEBUG - 2016-10-18 12:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:36:17 --> Input Class Initialized
INFO - 2016-10-18 12:36:17 --> Language Class Initialized
INFO - 2016-10-18 12:36:17 --> Loader Class Initialized
INFO - 2016-10-18 12:36:17 --> Helper loaded: url_helper
INFO - 2016-10-18 12:36:17 --> Helper loaded: form_helper
INFO - 2016-10-18 12:36:17 --> Database Driver Class Initialized
INFO - 2016-10-18 12:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:36:17 --> Controller Class Initialized
INFO - 2016-10-18 12:36:17 --> Form Validation Class Initialized
INFO - 2016-10-18 12:36:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 12:36:17 --> Final output sent to browser
DEBUG - 2016-10-18 12:36:17 --> Total execution time: 0.0054
INFO - 2016-10-18 12:36:23 --> Config Class Initialized
INFO - 2016-10-18 12:36:23 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:36:23 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:36:23 --> Utf8 Class Initialized
INFO - 2016-10-18 12:36:23 --> URI Class Initialized
INFO - 2016-10-18 12:36:23 --> Router Class Initialized
INFO - 2016-10-18 12:36:23 --> Output Class Initialized
INFO - 2016-10-18 12:36:23 --> Security Class Initialized
DEBUG - 2016-10-18 12:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:36:23 --> Input Class Initialized
INFO - 2016-10-18 12:36:23 --> Language Class Initialized
INFO - 2016-10-18 12:36:23 --> Loader Class Initialized
INFO - 2016-10-18 12:36:23 --> Helper loaded: url_helper
INFO - 2016-10-18 12:36:23 --> Helper loaded: form_helper
INFO - 2016-10-18 12:36:23 --> Database Driver Class Initialized
INFO - 2016-10-18 12:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:36:23 --> Controller Class Initialized
INFO - 2016-10-18 12:36:23 --> Form Validation Class Initialized
INFO - 2016-10-18 12:36:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 12:36:23 --> Final output sent to browser
DEBUG - 2016-10-18 12:36:23 --> Total execution time: 0.0054
INFO - 2016-10-18 12:36:37 --> Config Class Initialized
INFO - 2016-10-18 12:36:37 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:36:37 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:36:37 --> Utf8 Class Initialized
INFO - 2016-10-18 12:36:37 --> URI Class Initialized
INFO - 2016-10-18 12:36:37 --> Router Class Initialized
INFO - 2016-10-18 12:36:37 --> Output Class Initialized
INFO - 2016-10-18 12:36:37 --> Security Class Initialized
DEBUG - 2016-10-18 12:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:36:37 --> Input Class Initialized
INFO - 2016-10-18 12:36:37 --> Language Class Initialized
INFO - 2016-10-18 12:36:37 --> Loader Class Initialized
INFO - 2016-10-18 12:36:37 --> Helper loaded: url_helper
INFO - 2016-10-18 12:36:37 --> Helper loaded: form_helper
INFO - 2016-10-18 12:36:37 --> Database Driver Class Initialized
INFO - 2016-10-18 12:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:36:37 --> Controller Class Initialized
INFO - 2016-10-18 12:36:37 --> Form Validation Class Initialized
INFO - 2016-10-18 12:36:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 12:36:37 --> Final output sent to browser
DEBUG - 2016-10-18 12:36:37 --> Total execution time: 0.0052
INFO - 2016-10-18 12:36:40 --> Config Class Initialized
INFO - 2016-10-18 12:36:40 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:36:40 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:36:40 --> Utf8 Class Initialized
INFO - 2016-10-18 12:36:40 --> URI Class Initialized
INFO - 2016-10-18 12:36:40 --> Router Class Initialized
INFO - 2016-10-18 12:36:40 --> Output Class Initialized
INFO - 2016-10-18 12:36:40 --> Security Class Initialized
DEBUG - 2016-10-18 12:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:36:40 --> Input Class Initialized
INFO - 2016-10-18 12:36:40 --> Language Class Initialized
INFO - 2016-10-18 12:36:40 --> Loader Class Initialized
INFO - 2016-10-18 12:36:40 --> Helper loaded: url_helper
INFO - 2016-10-18 12:36:40 --> Helper loaded: form_helper
INFO - 2016-10-18 12:36:40 --> Database Driver Class Initialized
INFO - 2016-10-18 12:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:36:40 --> Controller Class Initialized
INFO - 2016-10-18 12:36:40 --> Form Validation Class Initialized
INFO - 2016-10-18 12:36:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 12:36:40 --> Final output sent to browser
DEBUG - 2016-10-18 12:36:40 --> Total execution time: 0.0053
INFO - 2016-10-18 12:36:53 --> Config Class Initialized
INFO - 2016-10-18 12:36:53 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:36:53 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:36:53 --> Utf8 Class Initialized
INFO - 2016-10-18 12:36:53 --> URI Class Initialized
INFO - 2016-10-18 12:36:53 --> Router Class Initialized
INFO - 2016-10-18 12:36:53 --> Output Class Initialized
INFO - 2016-10-18 12:36:53 --> Security Class Initialized
DEBUG - 2016-10-18 12:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:36:53 --> Input Class Initialized
INFO - 2016-10-18 12:36:53 --> Language Class Initialized
INFO - 2016-10-18 12:36:53 --> Loader Class Initialized
INFO - 2016-10-18 12:36:53 --> Helper loaded: url_helper
INFO - 2016-10-18 12:36:53 --> Helper loaded: form_helper
INFO - 2016-10-18 12:36:53 --> Database Driver Class Initialized
INFO - 2016-10-18 12:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:36:53 --> Controller Class Initialized
INFO - 2016-10-18 12:36:53 --> Form Validation Class Initialized
INFO - 2016-10-18 12:36:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 12:36:53 --> Final output sent to browser
DEBUG - 2016-10-18 12:36:53 --> Total execution time: 0.0056
INFO - 2016-10-18 12:37:03 --> Config Class Initialized
INFO - 2016-10-18 12:37:03 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:37:03 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:37:03 --> Utf8 Class Initialized
INFO - 2016-10-18 12:37:03 --> URI Class Initialized
DEBUG - 2016-10-18 12:37:03 --> No URI present. Default controller set.
INFO - 2016-10-18 12:37:03 --> Router Class Initialized
INFO - 2016-10-18 12:37:03 --> Output Class Initialized
INFO - 2016-10-18 12:37:03 --> Security Class Initialized
DEBUG - 2016-10-18 12:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:37:03 --> Input Class Initialized
INFO - 2016-10-18 12:37:03 --> Language Class Initialized
INFO - 2016-10-18 12:37:03 --> Loader Class Initialized
INFO - 2016-10-18 12:37:03 --> Helper loaded: url_helper
INFO - 2016-10-18 12:37:03 --> Helper loaded: form_helper
INFO - 2016-10-18 12:37:03 --> Database Driver Class Initialized
INFO - 2016-10-18 12:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:37:03 --> Controller Class Initialized
INFO - 2016-10-18 12:37:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:37:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:37:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:37:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:37:03 --> Final output sent to browser
DEBUG - 2016-10-18 12:37:03 --> Total execution time: 0.0122
INFO - 2016-10-18 12:37:45 --> Config Class Initialized
INFO - 2016-10-18 12:37:45 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:37:45 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:37:45 --> Utf8 Class Initialized
INFO - 2016-10-18 12:37:45 --> URI Class Initialized
DEBUG - 2016-10-18 12:37:45 --> No URI present. Default controller set.
INFO - 2016-10-18 12:37:45 --> Router Class Initialized
INFO - 2016-10-18 12:37:45 --> Output Class Initialized
INFO - 2016-10-18 12:37:45 --> Security Class Initialized
DEBUG - 2016-10-18 12:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:37:45 --> Input Class Initialized
INFO - 2016-10-18 12:37:45 --> Language Class Initialized
INFO - 2016-10-18 12:37:45 --> Loader Class Initialized
INFO - 2016-10-18 12:37:45 --> Helper loaded: url_helper
INFO - 2016-10-18 12:37:45 --> Helper loaded: form_helper
INFO - 2016-10-18 12:37:45 --> Database Driver Class Initialized
INFO - 2016-10-18 12:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:37:45 --> Controller Class Initialized
INFO - 2016-10-18 12:37:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:37:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:37:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:37:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:37:45 --> Final output sent to browser
DEBUG - 2016-10-18 12:37:45 --> Total execution time: 0.0085
INFO - 2016-10-18 12:37:47 --> Config Class Initialized
INFO - 2016-10-18 12:37:47 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:37:47 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:37:47 --> Utf8 Class Initialized
INFO - 2016-10-18 12:37:47 --> URI Class Initialized
INFO - 2016-10-18 12:37:47 --> Router Class Initialized
INFO - 2016-10-18 12:37:47 --> Output Class Initialized
INFO - 2016-10-18 12:37:47 --> Security Class Initialized
DEBUG - 2016-10-18 12:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:37:47 --> Input Class Initialized
INFO - 2016-10-18 12:37:47 --> Language Class Initialized
INFO - 2016-10-18 12:37:47 --> Loader Class Initialized
INFO - 2016-10-18 12:37:47 --> Helper loaded: url_helper
INFO - 2016-10-18 12:37:47 --> Helper loaded: form_helper
INFO - 2016-10-18 12:37:47 --> Database Driver Class Initialized
INFO - 2016-10-18 12:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:37:47 --> Controller Class Initialized
INFO - 2016-10-18 12:37:47 --> Form Validation Class Initialized
INFO - 2016-10-18 12:37:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 12:37:47 --> Final output sent to browser
DEBUG - 2016-10-18 12:37:47 --> Total execution time: 0.0162
INFO - 2016-10-18 12:39:01 --> Config Class Initialized
INFO - 2016-10-18 12:39:01 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:39:01 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:39:01 --> Utf8 Class Initialized
INFO - 2016-10-18 12:39:01 --> URI Class Initialized
DEBUG - 2016-10-18 12:39:01 --> No URI present. Default controller set.
INFO - 2016-10-18 12:39:01 --> Router Class Initialized
INFO - 2016-10-18 12:39:01 --> Output Class Initialized
INFO - 2016-10-18 12:39:01 --> Security Class Initialized
DEBUG - 2016-10-18 12:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:39:01 --> Input Class Initialized
INFO - 2016-10-18 12:39:01 --> Language Class Initialized
INFO - 2016-10-18 12:39:01 --> Loader Class Initialized
INFO - 2016-10-18 12:39:01 --> Helper loaded: url_helper
INFO - 2016-10-18 12:39:01 --> Helper loaded: form_helper
INFO - 2016-10-18 12:39:01 --> Database Driver Class Initialized
INFO - 2016-10-18 12:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:39:01 --> Controller Class Initialized
INFO - 2016-10-18 12:39:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:39:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:39:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:39:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:39:01 --> Final output sent to browser
DEBUG - 2016-10-18 12:39:01 --> Total execution time: 0.0052
INFO - 2016-10-18 12:39:04 --> Config Class Initialized
INFO - 2016-10-18 12:39:04 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:39:04 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:39:04 --> Utf8 Class Initialized
INFO - 2016-10-18 12:39:04 --> URI Class Initialized
INFO - 2016-10-18 12:39:04 --> Router Class Initialized
INFO - 2016-10-18 12:39:04 --> Output Class Initialized
INFO - 2016-10-18 12:39:04 --> Security Class Initialized
DEBUG - 2016-10-18 12:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:39:04 --> Input Class Initialized
INFO - 2016-10-18 12:39:04 --> Language Class Initialized
INFO - 2016-10-18 12:39:04 --> Loader Class Initialized
INFO - 2016-10-18 12:39:04 --> Helper loaded: url_helper
INFO - 2016-10-18 12:39:04 --> Helper loaded: form_helper
INFO - 2016-10-18 12:39:04 --> Database Driver Class Initialized
INFO - 2016-10-18 12:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:39:04 --> Controller Class Initialized
INFO - 2016-10-18 12:39:04 --> Form Validation Class Initialized
INFO - 2016-10-18 12:39:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 12:39:04 --> Final output sent to browser
DEBUG - 2016-10-18 12:39:04 --> Total execution time: 0.0075
INFO - 2016-10-18 12:39:08 --> Config Class Initialized
INFO - 2016-10-18 12:39:08 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:39:08 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:39:08 --> Utf8 Class Initialized
INFO - 2016-10-18 12:39:08 --> URI Class Initialized
DEBUG - 2016-10-18 12:39:08 --> No URI present. Default controller set.
INFO - 2016-10-18 12:39:08 --> Router Class Initialized
INFO - 2016-10-18 12:39:08 --> Output Class Initialized
INFO - 2016-10-18 12:39:08 --> Security Class Initialized
DEBUG - 2016-10-18 12:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:39:08 --> Input Class Initialized
INFO - 2016-10-18 12:39:08 --> Language Class Initialized
INFO - 2016-10-18 12:39:08 --> Loader Class Initialized
INFO - 2016-10-18 12:39:08 --> Helper loaded: url_helper
INFO - 2016-10-18 12:39:08 --> Helper loaded: form_helper
INFO - 2016-10-18 12:39:08 --> Database Driver Class Initialized
INFO - 2016-10-18 12:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:39:08 --> Controller Class Initialized
INFO - 2016-10-18 12:39:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:39:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:39:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:39:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:39:08 --> Final output sent to browser
DEBUG - 2016-10-18 12:39:08 --> Total execution time: 0.0046
INFO - 2016-10-18 12:39:12 --> Config Class Initialized
INFO - 2016-10-18 12:39:12 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:39:12 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:39:12 --> Utf8 Class Initialized
INFO - 2016-10-18 12:39:12 --> URI Class Initialized
INFO - 2016-10-18 12:39:12 --> Router Class Initialized
INFO - 2016-10-18 12:39:12 --> Output Class Initialized
INFO - 2016-10-18 12:39:12 --> Security Class Initialized
DEBUG - 2016-10-18 12:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:39:12 --> Input Class Initialized
INFO - 2016-10-18 12:39:12 --> Language Class Initialized
INFO - 2016-10-18 12:39:12 --> Loader Class Initialized
INFO - 2016-10-18 12:39:12 --> Helper loaded: url_helper
INFO - 2016-10-18 12:39:12 --> Helper loaded: form_helper
INFO - 2016-10-18 12:39:12 --> Database Driver Class Initialized
INFO - 2016-10-18 12:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:39:12 --> Controller Class Initialized
INFO - 2016-10-18 12:39:12 --> Form Validation Class Initialized
INFO - 2016-10-18 12:39:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 12:39:12 --> Final output sent to browser
DEBUG - 2016-10-18 12:39:12 --> Total execution time: 0.0044
INFO - 2016-10-18 12:39:13 --> Config Class Initialized
INFO - 2016-10-18 12:39:13 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:39:13 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:39:13 --> Utf8 Class Initialized
INFO - 2016-10-18 12:39:13 --> URI Class Initialized
INFO - 2016-10-18 12:39:13 --> Router Class Initialized
INFO - 2016-10-18 12:39:13 --> Output Class Initialized
INFO - 2016-10-18 12:39:13 --> Security Class Initialized
DEBUG - 2016-10-18 12:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:39:13 --> Input Class Initialized
INFO - 2016-10-18 12:39:13 --> Language Class Initialized
INFO - 2016-10-18 12:39:13 --> Loader Class Initialized
INFO - 2016-10-18 12:39:13 --> Helper loaded: url_helper
INFO - 2016-10-18 12:39:13 --> Helper loaded: form_helper
INFO - 2016-10-18 12:39:13 --> Database Driver Class Initialized
INFO - 2016-10-18 12:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:39:13 --> Controller Class Initialized
INFO - 2016-10-18 12:39:13 --> Form Validation Class Initialized
INFO - 2016-10-18 12:39:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 12:39:13 --> Final output sent to browser
DEBUG - 2016-10-18 12:39:13 --> Total execution time: 0.0044
INFO - 2016-10-18 12:39:23 --> Config Class Initialized
INFO - 2016-10-18 12:39:23 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:39:23 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:39:23 --> Utf8 Class Initialized
INFO - 2016-10-18 12:39:23 --> URI Class Initialized
INFO - 2016-10-18 12:39:23 --> Router Class Initialized
INFO - 2016-10-18 12:39:23 --> Output Class Initialized
INFO - 2016-10-18 12:39:23 --> Security Class Initialized
DEBUG - 2016-10-18 12:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:39:23 --> Input Class Initialized
INFO - 2016-10-18 12:39:23 --> Language Class Initialized
INFO - 2016-10-18 12:39:23 --> Loader Class Initialized
INFO - 2016-10-18 12:39:23 --> Helper loaded: url_helper
INFO - 2016-10-18 12:39:23 --> Helper loaded: form_helper
INFO - 2016-10-18 12:39:23 --> Database Driver Class Initialized
INFO - 2016-10-18 12:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:39:23 --> Controller Class Initialized
INFO - 2016-10-18 12:39:23 --> Form Validation Class Initialized
INFO - 2016-10-18 12:39:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 12:39:23 --> Final output sent to browser
DEBUG - 2016-10-18 12:39:23 --> Total execution time: 0.0083
INFO - 2016-10-18 12:39:29 --> Config Class Initialized
INFO - 2016-10-18 12:39:29 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:39:29 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:39:29 --> Utf8 Class Initialized
INFO - 2016-10-18 12:39:29 --> URI Class Initialized
DEBUG - 2016-10-18 12:39:29 --> No URI present. Default controller set.
INFO - 2016-10-18 12:39:29 --> Router Class Initialized
INFO - 2016-10-18 12:39:29 --> Output Class Initialized
INFO - 2016-10-18 12:39:29 --> Security Class Initialized
DEBUG - 2016-10-18 12:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:39:29 --> Input Class Initialized
INFO - 2016-10-18 12:39:29 --> Language Class Initialized
INFO - 2016-10-18 12:39:29 --> Loader Class Initialized
INFO - 2016-10-18 12:39:29 --> Helper loaded: url_helper
INFO - 2016-10-18 12:39:29 --> Helper loaded: form_helper
INFO - 2016-10-18 12:39:29 --> Database Driver Class Initialized
INFO - 2016-10-18 12:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:39:29 --> Controller Class Initialized
INFO - 2016-10-18 12:39:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:39:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:39:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:39:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:39:29 --> Final output sent to browser
DEBUG - 2016-10-18 12:39:29 --> Total execution time: 0.0053
INFO - 2016-10-18 12:40:22 --> Config Class Initialized
INFO - 2016-10-18 12:40:22 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:40:22 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:40:22 --> Utf8 Class Initialized
INFO - 2016-10-18 12:40:22 --> URI Class Initialized
DEBUG - 2016-10-18 12:40:22 --> No URI present. Default controller set.
INFO - 2016-10-18 12:40:22 --> Router Class Initialized
INFO - 2016-10-18 12:40:22 --> Output Class Initialized
INFO - 2016-10-18 12:40:22 --> Security Class Initialized
DEBUG - 2016-10-18 12:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:40:22 --> Input Class Initialized
INFO - 2016-10-18 12:40:22 --> Language Class Initialized
INFO - 2016-10-18 12:40:22 --> Loader Class Initialized
INFO - 2016-10-18 12:40:22 --> Helper loaded: url_helper
INFO - 2016-10-18 12:40:22 --> Helper loaded: form_helper
INFO - 2016-10-18 12:40:22 --> Database Driver Class Initialized
INFO - 2016-10-18 12:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:40:22 --> Controller Class Initialized
INFO - 2016-10-18 12:40:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:40:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:40:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:40:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:40:22 --> Final output sent to browser
DEBUG - 2016-10-18 12:40:22 --> Total execution time: 0.0052
INFO - 2016-10-18 12:40:30 --> Config Class Initialized
INFO - 2016-10-18 12:40:30 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:40:30 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:40:30 --> Utf8 Class Initialized
INFO - 2016-10-18 12:40:30 --> URI Class Initialized
INFO - 2016-10-18 12:40:30 --> Router Class Initialized
INFO - 2016-10-18 12:40:30 --> Output Class Initialized
INFO - 2016-10-18 12:40:30 --> Security Class Initialized
DEBUG - 2016-10-18 12:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:40:30 --> Input Class Initialized
INFO - 2016-10-18 12:40:30 --> Language Class Initialized
INFO - 2016-10-18 12:40:30 --> Loader Class Initialized
INFO - 2016-10-18 12:40:30 --> Helper loaded: url_helper
INFO - 2016-10-18 12:40:30 --> Helper loaded: form_helper
INFO - 2016-10-18 12:40:30 --> Database Driver Class Initialized
INFO - 2016-10-18 12:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:40:30 --> Controller Class Initialized
INFO - 2016-10-18 12:40:30 --> Form Validation Class Initialized
INFO - 2016-10-18 12:40:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 12:40:30 --> Final output sent to browser
DEBUG - 2016-10-18 12:40:30 --> Total execution time: 0.0056
INFO - 2016-10-18 12:40:32 --> Config Class Initialized
INFO - 2016-10-18 12:40:32 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:40:32 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:40:32 --> Utf8 Class Initialized
INFO - 2016-10-18 12:40:32 --> URI Class Initialized
DEBUG - 2016-10-18 12:40:32 --> No URI present. Default controller set.
INFO - 2016-10-18 12:40:32 --> Router Class Initialized
INFO - 2016-10-18 12:40:32 --> Output Class Initialized
INFO - 2016-10-18 12:40:32 --> Security Class Initialized
DEBUG - 2016-10-18 12:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:40:32 --> Input Class Initialized
INFO - 2016-10-18 12:40:32 --> Language Class Initialized
INFO - 2016-10-18 12:40:32 --> Loader Class Initialized
INFO - 2016-10-18 12:40:32 --> Helper loaded: url_helper
INFO - 2016-10-18 12:40:32 --> Helper loaded: form_helper
INFO - 2016-10-18 12:40:32 --> Database Driver Class Initialized
INFO - 2016-10-18 12:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:40:32 --> Controller Class Initialized
INFO - 2016-10-18 12:40:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:40:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:40:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:40:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:40:32 --> Final output sent to browser
DEBUG - 2016-10-18 12:40:32 --> Total execution time: 0.0047
INFO - 2016-10-18 12:40:48 --> Config Class Initialized
INFO - 2016-10-18 12:40:48 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:40:48 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:40:48 --> Utf8 Class Initialized
INFO - 2016-10-18 12:40:48 --> URI Class Initialized
DEBUG - 2016-10-18 12:40:48 --> No URI present. Default controller set.
INFO - 2016-10-18 12:40:48 --> Router Class Initialized
INFO - 2016-10-18 12:40:48 --> Output Class Initialized
INFO - 2016-10-18 12:40:48 --> Security Class Initialized
DEBUG - 2016-10-18 12:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:40:48 --> Input Class Initialized
INFO - 2016-10-18 12:40:48 --> Language Class Initialized
INFO - 2016-10-18 12:40:48 --> Loader Class Initialized
INFO - 2016-10-18 12:40:48 --> Helper loaded: url_helper
INFO - 2016-10-18 12:40:48 --> Helper loaded: form_helper
INFO - 2016-10-18 12:40:48 --> Database Driver Class Initialized
INFO - 2016-10-18 12:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:40:48 --> Controller Class Initialized
INFO - 2016-10-18 12:40:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:40:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:40:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:40:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:40:48 --> Final output sent to browser
DEBUG - 2016-10-18 12:40:48 --> Total execution time: 0.0057
INFO - 2016-10-18 12:41:13 --> Config Class Initialized
INFO - 2016-10-18 12:41:13 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:41:13 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:41:13 --> Utf8 Class Initialized
INFO - 2016-10-18 12:41:13 --> URI Class Initialized
DEBUG - 2016-10-18 12:41:13 --> No URI present. Default controller set.
INFO - 2016-10-18 12:41:13 --> Router Class Initialized
INFO - 2016-10-18 12:41:13 --> Output Class Initialized
INFO - 2016-10-18 12:41:13 --> Security Class Initialized
DEBUG - 2016-10-18 12:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:41:13 --> Input Class Initialized
INFO - 2016-10-18 12:41:13 --> Language Class Initialized
INFO - 2016-10-18 12:41:13 --> Loader Class Initialized
INFO - 2016-10-18 12:41:13 --> Helper loaded: url_helper
INFO - 2016-10-18 12:41:13 --> Helper loaded: form_helper
INFO - 2016-10-18 12:41:13 --> Database Driver Class Initialized
INFO - 2016-10-18 12:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:41:13 --> Controller Class Initialized
INFO - 2016-10-18 12:41:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:41:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:41:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:41:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:41:13 --> Final output sent to browser
DEBUG - 2016-10-18 12:41:13 --> Total execution time: 0.0048
INFO - 2016-10-18 12:43:25 --> Config Class Initialized
INFO - 2016-10-18 12:43:25 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:43:25 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:43:25 --> Utf8 Class Initialized
INFO - 2016-10-18 12:43:25 --> URI Class Initialized
DEBUG - 2016-10-18 12:43:25 --> No URI present. Default controller set.
INFO - 2016-10-18 12:43:25 --> Router Class Initialized
INFO - 2016-10-18 12:43:25 --> Output Class Initialized
INFO - 2016-10-18 12:43:25 --> Security Class Initialized
DEBUG - 2016-10-18 12:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:43:25 --> Input Class Initialized
INFO - 2016-10-18 12:43:25 --> Language Class Initialized
INFO - 2016-10-18 12:43:25 --> Loader Class Initialized
INFO - 2016-10-18 12:43:25 --> Helper loaded: url_helper
INFO - 2016-10-18 12:43:25 --> Helper loaded: form_helper
INFO - 2016-10-18 12:43:25 --> Database Driver Class Initialized
INFO - 2016-10-18 12:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:43:25 --> Controller Class Initialized
INFO - 2016-10-18 12:43:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:43:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:43:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:43:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:43:25 --> Final output sent to browser
DEBUG - 2016-10-18 12:43:25 --> Total execution time: 0.0075
INFO - 2016-10-18 12:43:27 --> Config Class Initialized
INFO - 2016-10-18 12:43:27 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:43:27 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:43:27 --> Utf8 Class Initialized
INFO - 2016-10-18 12:43:27 --> URI Class Initialized
INFO - 2016-10-18 12:43:27 --> Router Class Initialized
INFO - 2016-10-18 12:43:27 --> Output Class Initialized
INFO - 2016-10-18 12:43:27 --> Security Class Initialized
DEBUG - 2016-10-18 12:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:43:27 --> Input Class Initialized
INFO - 2016-10-18 12:43:27 --> Language Class Initialized
INFO - 2016-10-18 12:43:27 --> Loader Class Initialized
INFO - 2016-10-18 12:43:27 --> Helper loaded: url_helper
INFO - 2016-10-18 12:43:27 --> Helper loaded: form_helper
INFO - 2016-10-18 12:43:27 --> Database Driver Class Initialized
INFO - 2016-10-18 12:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:43:27 --> Controller Class Initialized
INFO - 2016-10-18 12:43:27 --> Form Validation Class Initialized
INFO - 2016-10-18 12:43:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 12:43:27 --> Final output sent to browser
DEBUG - 2016-10-18 12:43:27 --> Total execution time: 0.0048
INFO - 2016-10-18 12:43:29 --> Config Class Initialized
INFO - 2016-10-18 12:43:29 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:43:29 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:43:29 --> Utf8 Class Initialized
INFO - 2016-10-18 12:43:29 --> URI Class Initialized
DEBUG - 2016-10-18 12:43:29 --> No URI present. Default controller set.
INFO - 2016-10-18 12:43:29 --> Router Class Initialized
INFO - 2016-10-18 12:43:29 --> Output Class Initialized
INFO - 2016-10-18 12:43:29 --> Security Class Initialized
DEBUG - 2016-10-18 12:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:43:29 --> Input Class Initialized
INFO - 2016-10-18 12:43:29 --> Language Class Initialized
INFO - 2016-10-18 12:43:29 --> Loader Class Initialized
INFO - 2016-10-18 12:43:29 --> Helper loaded: url_helper
INFO - 2016-10-18 12:43:29 --> Helper loaded: form_helper
INFO - 2016-10-18 12:43:29 --> Database Driver Class Initialized
INFO - 2016-10-18 12:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:43:29 --> Controller Class Initialized
INFO - 2016-10-18 12:43:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:43:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:43:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:43:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:43:29 --> Final output sent to browser
DEBUG - 2016-10-18 12:43:29 --> Total execution time: 0.0047
INFO - 2016-10-18 12:43:36 --> Config Class Initialized
INFO - 2016-10-18 12:43:36 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:43:36 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:43:36 --> Utf8 Class Initialized
INFO - 2016-10-18 12:43:36 --> URI Class Initialized
INFO - 2016-10-18 12:43:36 --> Router Class Initialized
INFO - 2016-10-18 12:43:36 --> Output Class Initialized
INFO - 2016-10-18 12:43:36 --> Security Class Initialized
DEBUG - 2016-10-18 12:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:43:36 --> Input Class Initialized
INFO - 2016-10-18 12:43:36 --> Language Class Initialized
INFO - 2016-10-18 12:43:36 --> Loader Class Initialized
INFO - 2016-10-18 12:43:36 --> Helper loaded: url_helper
INFO - 2016-10-18 12:43:36 --> Helper loaded: form_helper
INFO - 2016-10-18 12:43:36 --> Database Driver Class Initialized
INFO - 2016-10-18 12:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:43:36 --> Controller Class Initialized
INFO - 2016-10-18 12:43:36 --> Form Validation Class Initialized
INFO - 2016-10-18 12:43:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 12:43:36 --> Final output sent to browser
DEBUG - 2016-10-18 12:43:36 --> Total execution time: 0.0077
INFO - 2016-10-18 12:43:49 --> Config Class Initialized
INFO - 2016-10-18 12:43:49 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:43:49 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:43:49 --> Utf8 Class Initialized
INFO - 2016-10-18 12:43:49 --> URI Class Initialized
DEBUG - 2016-10-18 12:43:49 --> No URI present. Default controller set.
INFO - 2016-10-18 12:43:49 --> Router Class Initialized
INFO - 2016-10-18 12:43:49 --> Output Class Initialized
INFO - 2016-10-18 12:43:49 --> Security Class Initialized
DEBUG - 2016-10-18 12:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:43:49 --> Input Class Initialized
INFO - 2016-10-18 12:43:49 --> Language Class Initialized
INFO - 2016-10-18 12:43:49 --> Loader Class Initialized
INFO - 2016-10-18 12:43:49 --> Helper loaded: url_helper
INFO - 2016-10-18 12:43:49 --> Helper loaded: form_helper
INFO - 2016-10-18 12:43:49 --> Database Driver Class Initialized
INFO - 2016-10-18 12:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:43:49 --> Controller Class Initialized
INFO - 2016-10-18 12:43:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:43:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:43:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:43:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:43:49 --> Final output sent to browser
DEBUG - 2016-10-18 12:43:49 --> Total execution time: 0.0049
INFO - 2016-10-18 12:43:58 --> Config Class Initialized
INFO - 2016-10-18 12:43:58 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:43:58 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:43:58 --> Utf8 Class Initialized
INFO - 2016-10-18 12:43:58 --> URI Class Initialized
INFO - 2016-10-18 12:43:58 --> Router Class Initialized
INFO - 2016-10-18 12:43:58 --> Output Class Initialized
INFO - 2016-10-18 12:43:58 --> Security Class Initialized
DEBUG - 2016-10-18 12:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:43:58 --> Input Class Initialized
INFO - 2016-10-18 12:43:58 --> Language Class Initialized
INFO - 2016-10-18 12:43:58 --> Loader Class Initialized
INFO - 2016-10-18 12:43:58 --> Helper loaded: url_helper
INFO - 2016-10-18 12:43:58 --> Helper loaded: form_helper
INFO - 2016-10-18 12:43:58 --> Database Driver Class Initialized
INFO - 2016-10-18 12:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:43:58 --> Controller Class Initialized
ERROR - 2016-10-18 12:43:58 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 121
ERROR - 2016-10-18 12:43:58 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 121
INFO - 2016-10-18 12:43:58 --> Config Class Initialized
INFO - 2016-10-18 12:43:58 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:43:58 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:43:58 --> Utf8 Class Initialized
INFO - 2016-10-18 12:43:58 --> URI Class Initialized
DEBUG - 2016-10-18 12:43:58 --> No URI present. Default controller set.
INFO - 2016-10-18 12:43:58 --> Router Class Initialized
INFO - 2016-10-18 12:43:58 --> Output Class Initialized
INFO - 2016-10-18 12:43:58 --> Security Class Initialized
DEBUG - 2016-10-18 12:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:43:58 --> Input Class Initialized
INFO - 2016-10-18 12:43:58 --> Language Class Initialized
INFO - 2016-10-18 12:43:58 --> Loader Class Initialized
INFO - 2016-10-18 12:43:58 --> Helper loaded: url_helper
INFO - 2016-10-18 12:43:58 --> Helper loaded: form_helper
INFO - 2016-10-18 12:43:58 --> Database Driver Class Initialized
INFO - 2016-10-18 12:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:43:58 --> Controller Class Initialized
INFO - 2016-10-18 12:43:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:43:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 12:43:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:43:58 --> Final output sent to browser
DEBUG - 2016-10-18 12:43:58 --> Total execution time: 0.0039
INFO - 2016-10-18 12:46:49 --> Config Class Initialized
INFO - 2016-10-18 12:46:49 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:46:49 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:46:49 --> Utf8 Class Initialized
INFO - 2016-10-18 12:46:49 --> URI Class Initialized
INFO - 2016-10-18 12:46:49 --> Router Class Initialized
INFO - 2016-10-18 12:46:49 --> Output Class Initialized
INFO - 2016-10-18 12:46:49 --> Security Class Initialized
DEBUG - 2016-10-18 12:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:46:49 --> Input Class Initialized
INFO - 2016-10-18 12:46:49 --> Language Class Initialized
INFO - 2016-10-18 12:46:49 --> Loader Class Initialized
INFO - 2016-10-18 12:46:49 --> Helper loaded: url_helper
INFO - 2016-10-18 12:46:49 --> Helper loaded: form_helper
INFO - 2016-10-18 12:46:49 --> Database Driver Class Initialized
INFO - 2016-10-18 12:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:46:49 --> Controller Class Initialized
INFO - 2016-10-18 12:46:49 --> Model Class Initialized
INFO - 2016-10-18 12:46:49 --> Final output sent to browser
DEBUG - 2016-10-18 12:46:49 --> Total execution time: 0.0082
INFO - 2016-10-18 12:46:50 --> Config Class Initialized
INFO - 2016-10-18 12:46:50 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:46:50 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:46:50 --> Utf8 Class Initialized
INFO - 2016-10-18 12:46:50 --> URI Class Initialized
DEBUG - 2016-10-18 12:46:50 --> No URI present. Default controller set.
INFO - 2016-10-18 12:46:50 --> Router Class Initialized
INFO - 2016-10-18 12:46:50 --> Output Class Initialized
INFO - 2016-10-18 12:46:50 --> Security Class Initialized
DEBUG - 2016-10-18 12:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:46:50 --> Input Class Initialized
INFO - 2016-10-18 12:46:50 --> Language Class Initialized
INFO - 2016-10-18 12:46:50 --> Loader Class Initialized
INFO - 2016-10-18 12:46:50 --> Helper loaded: url_helper
INFO - 2016-10-18 12:46:50 --> Helper loaded: form_helper
INFO - 2016-10-18 12:46:50 --> Database Driver Class Initialized
INFO - 2016-10-18 12:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:46:50 --> Controller Class Initialized
INFO - 2016-10-18 12:46:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:46:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:46:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:46:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:46:50 --> Final output sent to browser
DEBUG - 2016-10-18 12:46:50 --> Total execution time: 0.0040
INFO - 2016-10-18 12:47:02 --> Config Class Initialized
INFO - 2016-10-18 12:47:02 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:47:02 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:47:02 --> Utf8 Class Initialized
INFO - 2016-10-18 12:47:02 --> URI Class Initialized
INFO - 2016-10-18 12:47:02 --> Router Class Initialized
INFO - 2016-10-18 12:47:02 --> Output Class Initialized
INFO - 2016-10-18 12:47:02 --> Security Class Initialized
DEBUG - 2016-10-18 12:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:47:02 --> Input Class Initialized
INFO - 2016-10-18 12:47:02 --> Language Class Initialized
INFO - 2016-10-18 12:47:02 --> Loader Class Initialized
INFO - 2016-10-18 12:47:02 --> Helper loaded: url_helper
INFO - 2016-10-18 12:47:02 --> Helper loaded: form_helper
INFO - 2016-10-18 12:47:02 --> Database Driver Class Initialized
INFO - 2016-10-18 12:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:47:02 --> Controller Class Initialized
INFO - 2016-10-18 12:47:02 --> Form Validation Class Initialized
INFO - 2016-10-18 12:47:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 12:47:02 --> Final output sent to browser
DEBUG - 2016-10-18 12:47:02 --> Total execution time: 0.0048
INFO - 2016-10-18 12:47:19 --> Config Class Initialized
INFO - 2016-10-18 12:47:19 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:47:19 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:47:19 --> Utf8 Class Initialized
INFO - 2016-10-18 12:47:19 --> URI Class Initialized
INFO - 2016-10-18 12:47:19 --> Router Class Initialized
INFO - 2016-10-18 12:47:19 --> Output Class Initialized
INFO - 2016-10-18 12:47:19 --> Security Class Initialized
DEBUG - 2016-10-18 12:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:47:19 --> Input Class Initialized
INFO - 2016-10-18 12:47:19 --> Language Class Initialized
INFO - 2016-10-18 12:47:19 --> Loader Class Initialized
INFO - 2016-10-18 12:47:19 --> Helper loaded: url_helper
INFO - 2016-10-18 12:47:19 --> Helper loaded: form_helper
INFO - 2016-10-18 12:47:19 --> Database Driver Class Initialized
INFO - 2016-10-18 12:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:47:19 --> Controller Class Initialized
ERROR - 2016-10-18 12:47:19 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 121
ERROR - 2016-10-18 12:47:19 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 121
INFO - 2016-10-18 12:47:19 --> Config Class Initialized
INFO - 2016-10-18 12:47:19 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:47:19 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:47:19 --> Utf8 Class Initialized
INFO - 2016-10-18 12:47:19 --> URI Class Initialized
DEBUG - 2016-10-18 12:47:19 --> No URI present. Default controller set.
INFO - 2016-10-18 12:47:19 --> Router Class Initialized
INFO - 2016-10-18 12:47:19 --> Output Class Initialized
INFO - 2016-10-18 12:47:19 --> Security Class Initialized
DEBUG - 2016-10-18 12:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:47:19 --> Input Class Initialized
INFO - 2016-10-18 12:47:19 --> Language Class Initialized
INFO - 2016-10-18 12:47:19 --> Loader Class Initialized
INFO - 2016-10-18 12:47:19 --> Helper loaded: url_helper
INFO - 2016-10-18 12:47:19 --> Helper loaded: form_helper
INFO - 2016-10-18 12:47:19 --> Database Driver Class Initialized
INFO - 2016-10-18 12:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:47:19 --> Controller Class Initialized
INFO - 2016-10-18 12:47:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:47:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 12:47:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:47:19 --> Final output sent to browser
DEBUG - 2016-10-18 12:47:19 --> Total execution time: 0.0040
INFO - 2016-10-18 12:47:41 --> Config Class Initialized
INFO - 2016-10-18 12:47:41 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:47:41 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:47:41 --> Utf8 Class Initialized
INFO - 2016-10-18 12:47:41 --> URI Class Initialized
INFO - 2016-10-18 12:47:41 --> Router Class Initialized
INFO - 2016-10-18 12:47:41 --> Output Class Initialized
INFO - 2016-10-18 12:47:41 --> Security Class Initialized
DEBUG - 2016-10-18 12:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:47:41 --> Input Class Initialized
INFO - 2016-10-18 12:47:41 --> Language Class Initialized
INFO - 2016-10-18 12:47:41 --> Loader Class Initialized
INFO - 2016-10-18 12:47:41 --> Helper loaded: url_helper
INFO - 2016-10-18 12:47:41 --> Helper loaded: form_helper
INFO - 2016-10-18 12:47:41 --> Database Driver Class Initialized
INFO - 2016-10-18 12:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:47:41 --> Controller Class Initialized
INFO - 2016-10-18 12:47:41 --> Model Class Initialized
INFO - 2016-10-18 12:47:41 --> Final output sent to browser
DEBUG - 2016-10-18 12:47:41 --> Total execution time: 0.0054
INFO - 2016-10-18 12:47:42 --> Config Class Initialized
INFO - 2016-10-18 12:47:42 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:47:42 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:47:42 --> Utf8 Class Initialized
INFO - 2016-10-18 12:47:42 --> URI Class Initialized
DEBUG - 2016-10-18 12:47:42 --> No URI present. Default controller set.
INFO - 2016-10-18 12:47:42 --> Router Class Initialized
INFO - 2016-10-18 12:47:42 --> Output Class Initialized
INFO - 2016-10-18 12:47:42 --> Security Class Initialized
DEBUG - 2016-10-18 12:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:47:42 --> Input Class Initialized
INFO - 2016-10-18 12:47:42 --> Language Class Initialized
INFO - 2016-10-18 12:47:42 --> Loader Class Initialized
INFO - 2016-10-18 12:47:42 --> Helper loaded: url_helper
INFO - 2016-10-18 12:47:42 --> Helper loaded: form_helper
INFO - 2016-10-18 12:47:42 --> Database Driver Class Initialized
INFO - 2016-10-18 12:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:47:42 --> Controller Class Initialized
INFO - 2016-10-18 12:47:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:47:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:47:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:47:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:47:42 --> Final output sent to browser
DEBUG - 2016-10-18 12:47:42 --> Total execution time: 0.0042
INFO - 2016-10-18 12:48:20 --> Config Class Initialized
INFO - 2016-10-18 12:48:20 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:48:20 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:48:20 --> Utf8 Class Initialized
INFO - 2016-10-18 12:48:20 --> URI Class Initialized
INFO - 2016-10-18 12:48:20 --> Router Class Initialized
INFO - 2016-10-18 12:48:20 --> Output Class Initialized
INFO - 2016-10-18 12:48:20 --> Security Class Initialized
DEBUG - 2016-10-18 12:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:48:20 --> Input Class Initialized
INFO - 2016-10-18 12:48:20 --> Language Class Initialized
INFO - 2016-10-18 12:48:20 --> Loader Class Initialized
INFO - 2016-10-18 12:48:20 --> Helper loaded: url_helper
INFO - 2016-10-18 12:48:20 --> Helper loaded: form_helper
INFO - 2016-10-18 12:48:20 --> Database Driver Class Initialized
INFO - 2016-10-18 12:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:48:20 --> Controller Class Initialized
INFO - 2016-10-18 12:48:20 --> Form Validation Class Initialized
INFO - 2016-10-18 12:48:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 12:48:20 --> Final output sent to browser
DEBUG - 2016-10-18 12:48:20 --> Total execution time: 0.0099
INFO - 2016-10-18 12:48:22 --> Config Class Initialized
INFO - 2016-10-18 12:48:22 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:48:22 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:48:22 --> Utf8 Class Initialized
INFO - 2016-10-18 12:48:22 --> URI Class Initialized
DEBUG - 2016-10-18 12:48:22 --> No URI present. Default controller set.
INFO - 2016-10-18 12:48:22 --> Router Class Initialized
INFO - 2016-10-18 12:48:22 --> Output Class Initialized
INFO - 2016-10-18 12:48:22 --> Security Class Initialized
DEBUG - 2016-10-18 12:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:48:22 --> Input Class Initialized
INFO - 2016-10-18 12:48:22 --> Language Class Initialized
INFO - 2016-10-18 12:48:22 --> Loader Class Initialized
INFO - 2016-10-18 12:48:22 --> Helper loaded: url_helper
INFO - 2016-10-18 12:48:22 --> Helper loaded: form_helper
INFO - 2016-10-18 12:48:22 --> Database Driver Class Initialized
INFO - 2016-10-18 12:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:48:22 --> Controller Class Initialized
INFO - 2016-10-18 12:48:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:48:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:48:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:48:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:48:22 --> Final output sent to browser
DEBUG - 2016-10-18 12:48:22 --> Total execution time: 0.0048
INFO - 2016-10-18 12:48:32 --> Config Class Initialized
INFO - 2016-10-18 12:48:32 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:48:32 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:48:32 --> Utf8 Class Initialized
INFO - 2016-10-18 12:48:32 --> URI Class Initialized
INFO - 2016-10-18 12:48:32 --> Router Class Initialized
INFO - 2016-10-18 12:48:32 --> Output Class Initialized
INFO - 2016-10-18 12:48:32 --> Security Class Initialized
DEBUG - 2016-10-18 12:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:48:32 --> Input Class Initialized
INFO - 2016-10-18 12:48:32 --> Language Class Initialized
INFO - 2016-10-18 12:48:32 --> Loader Class Initialized
INFO - 2016-10-18 12:48:32 --> Helper loaded: url_helper
INFO - 2016-10-18 12:48:32 --> Helper loaded: form_helper
INFO - 2016-10-18 12:48:32 --> Database Driver Class Initialized
INFO - 2016-10-18 12:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:48:32 --> Controller Class Initialized
INFO - 2016-10-18 12:48:32 --> Form Validation Class Initialized
INFO - 2016-10-18 12:48:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 12:48:32 --> Final output sent to browser
DEBUG - 2016-10-18 12:48:32 --> Total execution time: 0.0076
INFO - 2016-10-18 12:48:33 --> Config Class Initialized
INFO - 2016-10-18 12:48:33 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:48:33 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:48:33 --> Utf8 Class Initialized
INFO - 2016-10-18 12:48:33 --> URI Class Initialized
DEBUG - 2016-10-18 12:48:33 --> No URI present. Default controller set.
INFO - 2016-10-18 12:48:33 --> Router Class Initialized
INFO - 2016-10-18 12:48:33 --> Output Class Initialized
INFO - 2016-10-18 12:48:33 --> Security Class Initialized
DEBUG - 2016-10-18 12:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:48:33 --> Input Class Initialized
INFO - 2016-10-18 12:48:33 --> Language Class Initialized
INFO - 2016-10-18 12:48:33 --> Loader Class Initialized
INFO - 2016-10-18 12:48:33 --> Helper loaded: url_helper
INFO - 2016-10-18 12:48:33 --> Helper loaded: form_helper
INFO - 2016-10-18 12:48:33 --> Database Driver Class Initialized
INFO - 2016-10-18 12:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:48:33 --> Controller Class Initialized
INFO - 2016-10-18 12:48:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:48:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:48:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:48:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:48:33 --> Final output sent to browser
DEBUG - 2016-10-18 12:48:33 --> Total execution time: 0.0046
INFO - 2016-10-18 12:49:04 --> Config Class Initialized
INFO - 2016-10-18 12:49:04 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:49:04 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:49:04 --> Utf8 Class Initialized
INFO - 2016-10-18 12:49:04 --> URI Class Initialized
DEBUG - 2016-10-18 12:49:04 --> No URI present. Default controller set.
INFO - 2016-10-18 12:49:04 --> Router Class Initialized
INFO - 2016-10-18 12:49:04 --> Output Class Initialized
INFO - 2016-10-18 12:49:04 --> Security Class Initialized
DEBUG - 2016-10-18 12:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:49:04 --> Input Class Initialized
INFO - 2016-10-18 12:49:04 --> Language Class Initialized
INFO - 2016-10-18 12:49:04 --> Loader Class Initialized
INFO - 2016-10-18 12:49:04 --> Helper loaded: url_helper
INFO - 2016-10-18 12:49:04 --> Helper loaded: form_helper
INFO - 2016-10-18 12:49:04 --> Database Driver Class Initialized
INFO - 2016-10-18 12:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:49:04 --> Controller Class Initialized
INFO - 2016-10-18 12:49:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:49:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:49:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:49:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:49:04 --> Final output sent to browser
DEBUG - 2016-10-18 12:49:04 --> Total execution time: 0.0060
INFO - 2016-10-18 12:49:07 --> Config Class Initialized
INFO - 2016-10-18 12:49:07 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:49:07 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:49:07 --> Utf8 Class Initialized
INFO - 2016-10-18 12:49:07 --> URI Class Initialized
DEBUG - 2016-10-18 12:49:07 --> No URI present. Default controller set.
INFO - 2016-10-18 12:49:07 --> Router Class Initialized
INFO - 2016-10-18 12:49:07 --> Output Class Initialized
INFO - 2016-10-18 12:49:07 --> Security Class Initialized
DEBUG - 2016-10-18 12:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:49:07 --> Input Class Initialized
INFO - 2016-10-18 12:49:07 --> Language Class Initialized
INFO - 2016-10-18 12:49:07 --> Loader Class Initialized
INFO - 2016-10-18 12:49:07 --> Helper loaded: url_helper
INFO - 2016-10-18 12:49:07 --> Helper loaded: form_helper
INFO - 2016-10-18 12:49:07 --> Database Driver Class Initialized
INFO - 2016-10-18 12:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:49:07 --> Controller Class Initialized
INFO - 2016-10-18 12:49:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:49:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:49:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:49:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:49:07 --> Final output sent to browser
DEBUG - 2016-10-18 12:49:07 --> Total execution time: 0.0047
INFO - 2016-10-18 12:50:00 --> Config Class Initialized
INFO - 2016-10-18 12:50:00 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:50:00 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:50:00 --> Utf8 Class Initialized
INFO - 2016-10-18 12:50:00 --> URI Class Initialized
DEBUG - 2016-10-18 12:50:00 --> No URI present. Default controller set.
INFO - 2016-10-18 12:50:00 --> Router Class Initialized
INFO - 2016-10-18 12:50:00 --> Output Class Initialized
INFO - 2016-10-18 12:50:00 --> Security Class Initialized
DEBUG - 2016-10-18 12:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:50:00 --> Input Class Initialized
INFO - 2016-10-18 12:50:00 --> Language Class Initialized
INFO - 2016-10-18 12:50:00 --> Loader Class Initialized
INFO - 2016-10-18 12:50:00 --> Helper loaded: url_helper
INFO - 2016-10-18 12:50:00 --> Helper loaded: form_helper
INFO - 2016-10-18 12:50:00 --> Database Driver Class Initialized
INFO - 2016-10-18 12:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:50:00 --> Controller Class Initialized
INFO - 2016-10-18 12:50:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:50:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:50:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:50:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:50:00 --> Final output sent to browser
DEBUG - 2016-10-18 12:50:00 --> Total execution time: 0.0084
INFO - 2016-10-18 12:50:33 --> Config Class Initialized
INFO - 2016-10-18 12:50:33 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:50:33 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:50:33 --> Utf8 Class Initialized
INFO - 2016-10-18 12:50:33 --> URI Class Initialized
DEBUG - 2016-10-18 12:50:33 --> No URI present. Default controller set.
INFO - 2016-10-18 12:50:33 --> Router Class Initialized
INFO - 2016-10-18 12:50:33 --> Output Class Initialized
INFO - 2016-10-18 12:50:33 --> Security Class Initialized
DEBUG - 2016-10-18 12:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:50:33 --> Input Class Initialized
INFO - 2016-10-18 12:50:33 --> Language Class Initialized
INFO - 2016-10-18 12:50:33 --> Loader Class Initialized
INFO - 2016-10-18 12:50:33 --> Helper loaded: url_helper
INFO - 2016-10-18 12:50:33 --> Helper loaded: form_helper
INFO - 2016-10-18 12:50:33 --> Database Driver Class Initialized
INFO - 2016-10-18 12:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:50:33 --> Controller Class Initialized
INFO - 2016-10-18 12:50:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:50:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:50:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:50:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:50:33 --> Final output sent to browser
DEBUG - 2016-10-18 12:50:33 --> Total execution time: 0.0078
INFO - 2016-10-18 12:50:50 --> Config Class Initialized
INFO - 2016-10-18 12:50:50 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:50:50 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:50:50 --> Utf8 Class Initialized
INFO - 2016-10-18 12:50:50 --> URI Class Initialized
DEBUG - 2016-10-18 12:50:50 --> No URI present. Default controller set.
INFO - 2016-10-18 12:50:50 --> Router Class Initialized
INFO - 2016-10-18 12:50:50 --> Output Class Initialized
INFO - 2016-10-18 12:50:50 --> Security Class Initialized
DEBUG - 2016-10-18 12:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:50:50 --> Input Class Initialized
INFO - 2016-10-18 12:50:50 --> Language Class Initialized
INFO - 2016-10-18 12:50:50 --> Loader Class Initialized
INFO - 2016-10-18 12:50:50 --> Helper loaded: url_helper
INFO - 2016-10-18 12:50:50 --> Helper loaded: form_helper
INFO - 2016-10-18 12:50:50 --> Database Driver Class Initialized
INFO - 2016-10-18 12:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:50:50 --> Controller Class Initialized
INFO - 2016-10-18 12:50:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:50:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:50:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:50:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:50:50 --> Final output sent to browser
DEBUG - 2016-10-18 12:50:50 --> Total execution time: 0.0083
INFO - 2016-10-18 12:51:02 --> Config Class Initialized
INFO - 2016-10-18 12:51:02 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:51:02 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:51:02 --> Utf8 Class Initialized
INFO - 2016-10-18 12:51:02 --> URI Class Initialized
DEBUG - 2016-10-18 12:51:02 --> No URI present. Default controller set.
INFO - 2016-10-18 12:51:02 --> Router Class Initialized
INFO - 2016-10-18 12:51:02 --> Output Class Initialized
INFO - 2016-10-18 12:51:02 --> Security Class Initialized
DEBUG - 2016-10-18 12:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:51:02 --> Input Class Initialized
INFO - 2016-10-18 12:51:02 --> Language Class Initialized
INFO - 2016-10-18 12:51:02 --> Loader Class Initialized
INFO - 2016-10-18 12:51:02 --> Helper loaded: url_helper
INFO - 2016-10-18 12:51:02 --> Helper loaded: form_helper
INFO - 2016-10-18 12:51:02 --> Database Driver Class Initialized
INFO - 2016-10-18 12:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:51:02 --> Controller Class Initialized
INFO - 2016-10-18 12:51:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:51:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:51:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:51:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:51:02 --> Final output sent to browser
DEBUG - 2016-10-18 12:51:02 --> Total execution time: 0.0078
INFO - 2016-10-18 12:51:24 --> Config Class Initialized
INFO - 2016-10-18 12:51:24 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:51:24 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:51:24 --> Utf8 Class Initialized
INFO - 2016-10-18 12:51:24 --> URI Class Initialized
DEBUG - 2016-10-18 12:51:24 --> No URI present. Default controller set.
INFO - 2016-10-18 12:51:24 --> Router Class Initialized
INFO - 2016-10-18 12:51:24 --> Output Class Initialized
INFO - 2016-10-18 12:51:24 --> Security Class Initialized
DEBUG - 2016-10-18 12:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:51:24 --> Input Class Initialized
INFO - 2016-10-18 12:51:24 --> Language Class Initialized
INFO - 2016-10-18 12:51:24 --> Loader Class Initialized
INFO - 2016-10-18 12:51:24 --> Helper loaded: url_helper
INFO - 2016-10-18 12:51:24 --> Helper loaded: form_helper
INFO - 2016-10-18 12:51:24 --> Database Driver Class Initialized
INFO - 2016-10-18 12:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:51:24 --> Controller Class Initialized
INFO - 2016-10-18 12:51:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:51:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:51:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:51:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:51:24 --> Final output sent to browser
DEBUG - 2016-10-18 12:51:24 --> Total execution time: 0.0049
INFO - 2016-10-18 12:51:42 --> Config Class Initialized
INFO - 2016-10-18 12:51:42 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:51:42 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:51:42 --> Utf8 Class Initialized
INFO - 2016-10-18 12:51:42 --> URI Class Initialized
DEBUG - 2016-10-18 12:51:42 --> No URI present. Default controller set.
INFO - 2016-10-18 12:51:42 --> Router Class Initialized
INFO - 2016-10-18 12:51:42 --> Output Class Initialized
INFO - 2016-10-18 12:51:42 --> Security Class Initialized
DEBUG - 2016-10-18 12:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:51:42 --> Input Class Initialized
INFO - 2016-10-18 12:51:42 --> Language Class Initialized
INFO - 2016-10-18 12:51:42 --> Loader Class Initialized
INFO - 2016-10-18 12:51:42 --> Helper loaded: url_helper
INFO - 2016-10-18 12:51:42 --> Helper loaded: form_helper
INFO - 2016-10-18 12:51:42 --> Database Driver Class Initialized
INFO - 2016-10-18 12:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:51:42 --> Controller Class Initialized
INFO - 2016-10-18 12:51:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:51:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:51:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:51:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:51:42 --> Final output sent to browser
DEBUG - 2016-10-18 12:51:42 --> Total execution time: 0.0050
INFO - 2016-10-18 12:51:49 --> Config Class Initialized
INFO - 2016-10-18 12:51:49 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:51:49 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:51:49 --> Utf8 Class Initialized
INFO - 2016-10-18 12:51:49 --> URI Class Initialized
INFO - 2016-10-18 12:51:49 --> Router Class Initialized
INFO - 2016-10-18 12:51:49 --> Output Class Initialized
INFO - 2016-10-18 12:51:49 --> Security Class Initialized
DEBUG - 2016-10-18 12:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:51:49 --> Input Class Initialized
INFO - 2016-10-18 12:51:49 --> Language Class Initialized
INFO - 2016-10-18 12:51:49 --> Loader Class Initialized
INFO - 2016-10-18 12:51:49 --> Helper loaded: url_helper
INFO - 2016-10-18 12:51:49 --> Helper loaded: form_helper
INFO - 2016-10-18 12:51:49 --> Database Driver Class Initialized
INFO - 2016-10-18 12:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:51:49 --> Controller Class Initialized
INFO - 2016-10-18 12:51:49 --> Form Validation Class Initialized
INFO - 2016-10-18 12:51:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 12:51:49 --> Final output sent to browser
DEBUG - 2016-10-18 12:51:49 --> Total execution time: 0.0061
INFO - 2016-10-18 12:51:53 --> Config Class Initialized
INFO - 2016-10-18 12:51:53 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:51:53 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:51:53 --> Utf8 Class Initialized
INFO - 2016-10-18 12:51:53 --> URI Class Initialized
DEBUG - 2016-10-18 12:51:53 --> No URI present. Default controller set.
INFO - 2016-10-18 12:51:53 --> Router Class Initialized
INFO - 2016-10-18 12:51:53 --> Output Class Initialized
INFO - 2016-10-18 12:51:53 --> Security Class Initialized
DEBUG - 2016-10-18 12:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:51:53 --> Input Class Initialized
INFO - 2016-10-18 12:51:53 --> Language Class Initialized
INFO - 2016-10-18 12:51:53 --> Loader Class Initialized
INFO - 2016-10-18 12:51:53 --> Helper loaded: url_helper
INFO - 2016-10-18 12:51:53 --> Helper loaded: form_helper
INFO - 2016-10-18 12:51:53 --> Database Driver Class Initialized
INFO - 2016-10-18 12:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:51:53 --> Controller Class Initialized
INFO - 2016-10-18 12:51:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:51:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:51:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:51:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:51:53 --> Final output sent to browser
DEBUG - 2016-10-18 12:51:53 --> Total execution time: 0.0050
INFO - 2016-10-18 12:52:05 --> Config Class Initialized
INFO - 2016-10-18 12:52:05 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:52:05 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:52:05 --> Utf8 Class Initialized
INFO - 2016-10-18 12:52:05 --> URI Class Initialized
INFO - 2016-10-18 12:52:05 --> Router Class Initialized
INFO - 2016-10-18 12:52:05 --> Output Class Initialized
INFO - 2016-10-18 12:52:05 --> Security Class Initialized
DEBUG - 2016-10-18 12:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:52:05 --> Input Class Initialized
INFO - 2016-10-18 12:52:05 --> Language Class Initialized
INFO - 2016-10-18 12:52:05 --> Loader Class Initialized
INFO - 2016-10-18 12:52:05 --> Helper loaded: url_helper
INFO - 2016-10-18 12:52:05 --> Helper loaded: form_helper
INFO - 2016-10-18 12:52:05 --> Database Driver Class Initialized
INFO - 2016-10-18 12:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:52:05 --> Controller Class Initialized
INFO - 2016-10-18 12:52:05 --> Form Validation Class Initialized
INFO - 2016-10-18 12:52:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 12:52:05 --> Final output sent to browser
DEBUG - 2016-10-18 12:52:05 --> Total execution time: 0.0079
INFO - 2016-10-18 12:52:09 --> Config Class Initialized
INFO - 2016-10-18 12:52:09 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:52:09 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:52:09 --> Utf8 Class Initialized
INFO - 2016-10-18 12:52:09 --> URI Class Initialized
DEBUG - 2016-10-18 12:52:09 --> No URI present. Default controller set.
INFO - 2016-10-18 12:52:09 --> Router Class Initialized
INFO - 2016-10-18 12:52:09 --> Output Class Initialized
INFO - 2016-10-18 12:52:09 --> Security Class Initialized
DEBUG - 2016-10-18 12:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:52:09 --> Input Class Initialized
INFO - 2016-10-18 12:52:09 --> Language Class Initialized
INFO - 2016-10-18 12:52:09 --> Loader Class Initialized
INFO - 2016-10-18 12:52:09 --> Helper loaded: url_helper
INFO - 2016-10-18 12:52:09 --> Helper loaded: form_helper
INFO - 2016-10-18 12:52:09 --> Database Driver Class Initialized
INFO - 2016-10-18 12:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:52:09 --> Controller Class Initialized
INFO - 2016-10-18 12:52:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:52:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:52:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:52:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:52:09 --> Final output sent to browser
DEBUG - 2016-10-18 12:52:09 --> Total execution time: 0.0057
INFO - 2016-10-18 12:52:41 --> Config Class Initialized
INFO - 2016-10-18 12:52:41 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:52:41 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:52:41 --> Utf8 Class Initialized
INFO - 2016-10-18 12:52:41 --> URI Class Initialized
INFO - 2016-10-18 12:52:41 --> Router Class Initialized
INFO - 2016-10-18 12:52:41 --> Output Class Initialized
INFO - 2016-10-18 12:52:41 --> Security Class Initialized
DEBUG - 2016-10-18 12:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:52:41 --> Input Class Initialized
INFO - 2016-10-18 12:52:41 --> Language Class Initialized
INFO - 2016-10-18 12:52:41 --> Loader Class Initialized
INFO - 2016-10-18 12:52:41 --> Helper loaded: url_helper
INFO - 2016-10-18 12:52:41 --> Helper loaded: form_helper
INFO - 2016-10-18 12:52:41 --> Database Driver Class Initialized
INFO - 2016-10-18 12:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:52:41 --> Controller Class Initialized
INFO - 2016-10-18 12:52:41 --> Form Validation Class Initialized
INFO - 2016-10-18 12:52:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 12:52:41 --> Final output sent to browser
DEBUG - 2016-10-18 12:52:41 --> Total execution time: 0.0078
INFO - 2016-10-18 12:52:42 --> Config Class Initialized
INFO - 2016-10-18 12:52:42 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:52:42 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:52:42 --> Utf8 Class Initialized
INFO - 2016-10-18 12:52:42 --> URI Class Initialized
DEBUG - 2016-10-18 12:52:42 --> No URI present. Default controller set.
INFO - 2016-10-18 12:52:42 --> Router Class Initialized
INFO - 2016-10-18 12:52:42 --> Output Class Initialized
INFO - 2016-10-18 12:52:42 --> Security Class Initialized
DEBUG - 2016-10-18 12:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:52:42 --> Input Class Initialized
INFO - 2016-10-18 12:52:42 --> Language Class Initialized
INFO - 2016-10-18 12:52:42 --> Loader Class Initialized
INFO - 2016-10-18 12:52:42 --> Helper loaded: url_helper
INFO - 2016-10-18 12:52:42 --> Helper loaded: form_helper
INFO - 2016-10-18 12:52:42 --> Database Driver Class Initialized
INFO - 2016-10-18 12:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:52:42 --> Controller Class Initialized
INFO - 2016-10-18 12:52:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:52:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:52:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:52:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:52:42 --> Final output sent to browser
DEBUG - 2016-10-18 12:52:42 --> Total execution time: 0.0055
INFO - 2016-10-18 12:52:49 --> Config Class Initialized
INFO - 2016-10-18 12:52:49 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:52:49 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:52:49 --> Utf8 Class Initialized
INFO - 2016-10-18 12:52:49 --> URI Class Initialized
DEBUG - 2016-10-18 12:52:49 --> No URI present. Default controller set.
INFO - 2016-10-18 12:52:49 --> Router Class Initialized
INFO - 2016-10-18 12:52:49 --> Output Class Initialized
INFO - 2016-10-18 12:52:49 --> Security Class Initialized
DEBUG - 2016-10-18 12:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:52:49 --> Input Class Initialized
INFO - 2016-10-18 12:52:49 --> Language Class Initialized
INFO - 2016-10-18 12:52:49 --> Loader Class Initialized
INFO - 2016-10-18 12:52:49 --> Helper loaded: url_helper
INFO - 2016-10-18 12:52:49 --> Helper loaded: form_helper
INFO - 2016-10-18 12:52:49 --> Database Driver Class Initialized
INFO - 2016-10-18 12:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:52:49 --> Controller Class Initialized
INFO - 2016-10-18 12:52:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:52:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 12:52:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 12:52:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:52:49 --> Final output sent to browser
DEBUG - 2016-10-18 12:52:49 --> Total execution time: 0.0050
INFO - 2016-10-18 12:53:01 --> Config Class Initialized
INFO - 2016-10-18 12:53:01 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:53:01 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:53:01 --> Utf8 Class Initialized
INFO - 2016-10-18 12:53:01 --> URI Class Initialized
INFO - 2016-10-18 12:53:01 --> Router Class Initialized
INFO - 2016-10-18 12:53:01 --> Output Class Initialized
INFO - 2016-10-18 12:53:01 --> Security Class Initialized
DEBUG - 2016-10-18 12:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:53:01 --> Input Class Initialized
INFO - 2016-10-18 12:53:01 --> Language Class Initialized
INFO - 2016-10-18 12:53:01 --> Loader Class Initialized
INFO - 2016-10-18 12:53:01 --> Helper loaded: url_helper
INFO - 2016-10-18 12:53:01 --> Helper loaded: form_helper
INFO - 2016-10-18 12:53:01 --> Database Driver Class Initialized
INFO - 2016-10-18 12:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:53:01 --> Controller Class Initialized
ERROR - 2016-10-18 12:53:01 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 121
ERROR - 2016-10-18 12:53:01 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 121
INFO - 2016-10-18 12:53:01 --> Config Class Initialized
INFO - 2016-10-18 12:53:01 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:53:01 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:53:01 --> Utf8 Class Initialized
INFO - 2016-10-18 12:53:01 --> URI Class Initialized
DEBUG - 2016-10-18 12:53:01 --> No URI present. Default controller set.
INFO - 2016-10-18 12:53:01 --> Router Class Initialized
INFO - 2016-10-18 12:53:01 --> Output Class Initialized
INFO - 2016-10-18 12:53:01 --> Security Class Initialized
DEBUG - 2016-10-18 12:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:53:01 --> Input Class Initialized
INFO - 2016-10-18 12:53:01 --> Language Class Initialized
INFO - 2016-10-18 12:53:01 --> Loader Class Initialized
INFO - 2016-10-18 12:53:01 --> Helper loaded: url_helper
INFO - 2016-10-18 12:53:01 --> Helper loaded: form_helper
INFO - 2016-10-18 12:53:01 --> Database Driver Class Initialized
INFO - 2016-10-18 12:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:53:01 --> Controller Class Initialized
INFO - 2016-10-18 12:53:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:53:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 12:53:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:53:01 --> Final output sent to browser
DEBUG - 2016-10-18 12:53:01 --> Total execution time: 0.0044
INFO - 2016-10-18 12:56:24 --> Config Class Initialized
INFO - 2016-10-18 12:56:24 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:56:24 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:56:24 --> Utf8 Class Initialized
INFO - 2016-10-18 12:56:24 --> URI Class Initialized
DEBUG - 2016-10-18 12:56:24 --> No URI present. Default controller set.
INFO - 2016-10-18 12:56:24 --> Router Class Initialized
INFO - 2016-10-18 12:56:24 --> Output Class Initialized
INFO - 2016-10-18 12:56:24 --> Security Class Initialized
DEBUG - 2016-10-18 12:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:56:24 --> Input Class Initialized
INFO - 2016-10-18 12:56:24 --> Language Class Initialized
INFO - 2016-10-18 12:56:24 --> Loader Class Initialized
INFO - 2016-10-18 12:56:24 --> Helper loaded: url_helper
INFO - 2016-10-18 12:56:24 --> Helper loaded: form_helper
INFO - 2016-10-18 12:56:24 --> Database Driver Class Initialized
INFO - 2016-10-18 12:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:56:24 --> Controller Class Initialized
INFO - 2016-10-18 12:56:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 12:56:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 12:56:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 12:56:24 --> Final output sent to browser
DEBUG - 2016-10-18 12:56:24 --> Total execution time: 0.0050
INFO - 2016-10-18 12:56:55 --> Config Class Initialized
INFO - 2016-10-18 12:56:55 --> Hooks Class Initialized
DEBUG - 2016-10-18 12:56:55 --> UTF-8 Support Enabled
INFO - 2016-10-18 12:56:55 --> Utf8 Class Initialized
INFO - 2016-10-18 12:56:55 --> URI Class Initialized
INFO - 2016-10-18 12:56:55 --> Router Class Initialized
INFO - 2016-10-18 12:56:55 --> Output Class Initialized
INFO - 2016-10-18 12:56:55 --> Security Class Initialized
DEBUG - 2016-10-18 12:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 12:56:55 --> Input Class Initialized
INFO - 2016-10-18 12:56:55 --> Language Class Initialized
INFO - 2016-10-18 12:56:55 --> Loader Class Initialized
INFO - 2016-10-18 12:56:55 --> Helper loaded: url_helper
INFO - 2016-10-18 12:56:55 --> Helper loaded: form_helper
INFO - 2016-10-18 12:56:55 --> Database Driver Class Initialized
INFO - 2016-10-18 12:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 12:56:55 --> Controller Class Initialized
INFO - 2016-10-18 12:56:55 --> Model Class Initialized
INFO - 2016-10-18 12:56:55 --> Final output sent to browser
DEBUG - 2016-10-18 12:56:55 --> Total execution time: 0.0057
INFO - 2016-10-18 13:08:44 --> Config Class Initialized
INFO - 2016-10-18 13:08:44 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:08:44 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:08:44 --> Utf8 Class Initialized
INFO - 2016-10-18 13:08:44 --> URI Class Initialized
DEBUG - 2016-10-18 13:08:44 --> No URI present. Default controller set.
INFO - 2016-10-18 13:08:44 --> Router Class Initialized
INFO - 2016-10-18 13:08:44 --> Output Class Initialized
INFO - 2016-10-18 13:08:44 --> Security Class Initialized
DEBUG - 2016-10-18 13:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:08:44 --> Input Class Initialized
INFO - 2016-10-18 13:08:44 --> Language Class Initialized
INFO - 2016-10-18 13:08:44 --> Loader Class Initialized
INFO - 2016-10-18 13:08:44 --> Helper loaded: url_helper
INFO - 2016-10-18 13:08:44 --> Helper loaded: form_helper
INFO - 2016-10-18 13:08:44 --> Database Driver Class Initialized
INFO - 2016-10-18 13:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:08:44 --> Controller Class Initialized
INFO - 2016-10-18 13:08:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:08:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:08:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:08:44 --> Final output sent to browser
DEBUG - 2016-10-18 13:08:44 --> Total execution time: 0.0081
INFO - 2016-10-18 13:08:58 --> Config Class Initialized
INFO - 2016-10-18 13:08:58 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:08:58 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:08:58 --> Utf8 Class Initialized
INFO - 2016-10-18 13:08:58 --> URI Class Initialized
DEBUG - 2016-10-18 13:08:58 --> No URI present. Default controller set.
INFO - 2016-10-18 13:08:58 --> Router Class Initialized
INFO - 2016-10-18 13:08:58 --> Output Class Initialized
INFO - 2016-10-18 13:08:58 --> Security Class Initialized
DEBUG - 2016-10-18 13:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:08:58 --> Input Class Initialized
INFO - 2016-10-18 13:08:58 --> Language Class Initialized
INFO - 2016-10-18 13:08:58 --> Loader Class Initialized
INFO - 2016-10-18 13:08:58 --> Helper loaded: url_helper
INFO - 2016-10-18 13:08:58 --> Helper loaded: form_helper
INFO - 2016-10-18 13:08:58 --> Database Driver Class Initialized
INFO - 2016-10-18 13:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:08:58 --> Controller Class Initialized
INFO - 2016-10-18 13:08:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:08:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:08:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:08:58 --> Final output sent to browser
DEBUG - 2016-10-18 13:08:58 --> Total execution time: 0.0052
INFO - 2016-10-18 13:09:24 --> Config Class Initialized
INFO - 2016-10-18 13:09:24 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:09:24 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:09:24 --> Utf8 Class Initialized
INFO - 2016-10-18 13:09:24 --> URI Class Initialized
DEBUG - 2016-10-18 13:09:24 --> No URI present. Default controller set.
INFO - 2016-10-18 13:09:24 --> Router Class Initialized
INFO - 2016-10-18 13:09:24 --> Output Class Initialized
INFO - 2016-10-18 13:09:24 --> Security Class Initialized
DEBUG - 2016-10-18 13:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:09:24 --> Input Class Initialized
INFO - 2016-10-18 13:09:24 --> Language Class Initialized
INFO - 2016-10-18 13:09:24 --> Loader Class Initialized
INFO - 2016-10-18 13:09:24 --> Helper loaded: url_helper
INFO - 2016-10-18 13:09:24 --> Helper loaded: form_helper
INFO - 2016-10-18 13:09:24 --> Database Driver Class Initialized
INFO - 2016-10-18 13:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:09:24 --> Controller Class Initialized
INFO - 2016-10-18 13:09:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:09:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:09:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:09:24 --> Final output sent to browser
DEBUG - 2016-10-18 13:09:24 --> Total execution time: 0.0052
INFO - 2016-10-18 13:09:35 --> Config Class Initialized
INFO - 2016-10-18 13:09:35 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:09:35 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:09:35 --> Utf8 Class Initialized
INFO - 2016-10-18 13:09:35 --> URI Class Initialized
DEBUG - 2016-10-18 13:09:35 --> No URI present. Default controller set.
INFO - 2016-10-18 13:09:35 --> Router Class Initialized
INFO - 2016-10-18 13:09:35 --> Output Class Initialized
INFO - 2016-10-18 13:09:35 --> Security Class Initialized
DEBUG - 2016-10-18 13:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:09:35 --> Input Class Initialized
INFO - 2016-10-18 13:09:35 --> Language Class Initialized
INFO - 2016-10-18 13:09:35 --> Loader Class Initialized
INFO - 2016-10-18 13:09:35 --> Helper loaded: url_helper
INFO - 2016-10-18 13:09:35 --> Helper loaded: form_helper
INFO - 2016-10-18 13:09:35 --> Database Driver Class Initialized
INFO - 2016-10-18 13:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:09:35 --> Controller Class Initialized
INFO - 2016-10-18 13:09:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:09:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:09:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:09:35 --> Final output sent to browser
DEBUG - 2016-10-18 13:09:35 --> Total execution time: 0.0077
INFO - 2016-10-18 13:17:38 --> Config Class Initialized
INFO - 2016-10-18 13:17:38 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:17:38 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:17:38 --> Utf8 Class Initialized
INFO - 2016-10-18 13:17:38 --> URI Class Initialized
DEBUG - 2016-10-18 13:17:38 --> No URI present. Default controller set.
INFO - 2016-10-18 13:17:38 --> Router Class Initialized
INFO - 2016-10-18 13:17:38 --> Output Class Initialized
INFO - 2016-10-18 13:17:38 --> Security Class Initialized
DEBUG - 2016-10-18 13:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:17:38 --> Input Class Initialized
INFO - 2016-10-18 13:17:38 --> Language Class Initialized
INFO - 2016-10-18 13:17:38 --> Loader Class Initialized
INFO - 2016-10-18 13:17:38 --> Helper loaded: url_helper
INFO - 2016-10-18 13:17:38 --> Helper loaded: form_helper
INFO - 2016-10-18 13:17:38 --> Database Driver Class Initialized
INFO - 2016-10-18 13:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:17:38 --> Controller Class Initialized
INFO - 2016-10-18 13:17:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:17:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:17:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:17:38 --> Final output sent to browser
DEBUG - 2016-10-18 13:17:38 --> Total execution time: 0.0088
INFO - 2016-10-18 13:18:24 --> Config Class Initialized
INFO - 2016-10-18 13:18:24 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:18:24 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:18:24 --> Utf8 Class Initialized
INFO - 2016-10-18 13:18:24 --> URI Class Initialized
DEBUG - 2016-10-18 13:18:24 --> No URI present. Default controller set.
INFO - 2016-10-18 13:18:24 --> Router Class Initialized
INFO - 2016-10-18 13:18:24 --> Output Class Initialized
INFO - 2016-10-18 13:18:24 --> Security Class Initialized
DEBUG - 2016-10-18 13:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:18:24 --> Input Class Initialized
INFO - 2016-10-18 13:18:24 --> Language Class Initialized
INFO - 2016-10-18 13:18:24 --> Loader Class Initialized
INFO - 2016-10-18 13:18:24 --> Helper loaded: url_helper
INFO - 2016-10-18 13:18:24 --> Helper loaded: form_helper
INFO - 2016-10-18 13:18:24 --> Database Driver Class Initialized
INFO - 2016-10-18 13:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:18:24 --> Controller Class Initialized
INFO - 2016-10-18 13:18:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:18:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:18:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:18:24 --> Final output sent to browser
DEBUG - 2016-10-18 13:18:24 --> Total execution time: 0.0076
INFO - 2016-10-18 13:18:52 --> Config Class Initialized
INFO - 2016-10-18 13:18:52 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:18:52 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:18:52 --> Utf8 Class Initialized
INFO - 2016-10-18 13:18:52 --> URI Class Initialized
DEBUG - 2016-10-18 13:18:52 --> No URI present. Default controller set.
INFO - 2016-10-18 13:18:52 --> Router Class Initialized
INFO - 2016-10-18 13:18:52 --> Output Class Initialized
INFO - 2016-10-18 13:18:52 --> Security Class Initialized
DEBUG - 2016-10-18 13:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:18:52 --> Input Class Initialized
INFO - 2016-10-18 13:18:52 --> Language Class Initialized
INFO - 2016-10-18 13:18:52 --> Loader Class Initialized
INFO - 2016-10-18 13:18:52 --> Helper loaded: url_helper
INFO - 2016-10-18 13:18:52 --> Helper loaded: form_helper
INFO - 2016-10-18 13:18:52 --> Database Driver Class Initialized
INFO - 2016-10-18 13:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:18:52 --> Controller Class Initialized
INFO - 2016-10-18 13:18:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:18:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:18:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:18:52 --> Final output sent to browser
DEBUG - 2016-10-18 13:18:52 --> Total execution time: 0.0061
INFO - 2016-10-18 13:19:25 --> Config Class Initialized
INFO - 2016-10-18 13:19:25 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:19:25 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:19:25 --> Utf8 Class Initialized
INFO - 2016-10-18 13:19:25 --> URI Class Initialized
DEBUG - 2016-10-18 13:19:25 --> No URI present. Default controller set.
INFO - 2016-10-18 13:19:25 --> Router Class Initialized
INFO - 2016-10-18 13:19:25 --> Output Class Initialized
INFO - 2016-10-18 13:19:25 --> Security Class Initialized
DEBUG - 2016-10-18 13:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:19:25 --> Input Class Initialized
INFO - 2016-10-18 13:19:25 --> Language Class Initialized
INFO - 2016-10-18 13:19:25 --> Loader Class Initialized
INFO - 2016-10-18 13:19:25 --> Helper loaded: url_helper
INFO - 2016-10-18 13:19:25 --> Helper loaded: form_helper
INFO - 2016-10-18 13:19:25 --> Database Driver Class Initialized
INFO - 2016-10-18 13:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:19:25 --> Controller Class Initialized
INFO - 2016-10-18 13:19:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:19:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:19:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:19:25 --> Final output sent to browser
DEBUG - 2016-10-18 13:19:25 --> Total execution time: 0.0078
INFO - 2016-10-18 13:19:32 --> Config Class Initialized
INFO - 2016-10-18 13:19:32 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:19:32 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:19:32 --> Utf8 Class Initialized
INFO - 2016-10-18 13:19:32 --> URI Class Initialized
INFO - 2016-10-18 13:19:32 --> Router Class Initialized
INFO - 2016-10-18 13:19:32 --> Output Class Initialized
INFO - 2016-10-18 13:19:32 --> Security Class Initialized
DEBUG - 2016-10-18 13:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:19:32 --> Input Class Initialized
INFO - 2016-10-18 13:19:32 --> Language Class Initialized
INFO - 2016-10-18 13:19:32 --> Loader Class Initialized
INFO - 2016-10-18 13:19:32 --> Helper loaded: url_helper
INFO - 2016-10-18 13:19:32 --> Helper loaded: form_helper
INFO - 2016-10-18 13:19:32 --> Database Driver Class Initialized
INFO - 2016-10-18 13:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:19:32 --> Controller Class Initialized
INFO - 2016-10-18 13:19:32 --> Model Class Initialized
INFO - 2016-10-18 13:19:32 --> Final output sent to browser
DEBUG - 2016-10-18 13:19:32 --> Total execution time: 0.0058
INFO - 2016-10-18 13:19:32 --> Config Class Initialized
INFO - 2016-10-18 13:19:32 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:19:32 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:19:32 --> Utf8 Class Initialized
INFO - 2016-10-18 13:19:32 --> URI Class Initialized
DEBUG - 2016-10-18 13:19:32 --> No URI present. Default controller set.
INFO - 2016-10-18 13:19:32 --> Router Class Initialized
INFO - 2016-10-18 13:19:32 --> Output Class Initialized
INFO - 2016-10-18 13:19:32 --> Security Class Initialized
DEBUG - 2016-10-18 13:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:19:32 --> Input Class Initialized
INFO - 2016-10-18 13:19:32 --> Language Class Initialized
INFO - 2016-10-18 13:19:32 --> Loader Class Initialized
INFO - 2016-10-18 13:19:32 --> Helper loaded: url_helper
INFO - 2016-10-18 13:19:32 --> Helper loaded: form_helper
INFO - 2016-10-18 13:19:32 --> Database Driver Class Initialized
INFO - 2016-10-18 13:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:19:32 --> Controller Class Initialized
INFO - 2016-10-18 13:19:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:19:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:19:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:19:32 --> Final output sent to browser
DEBUG - 2016-10-18 13:19:32 --> Total execution time: 0.0043
INFO - 2016-10-18 13:19:40 --> Config Class Initialized
INFO - 2016-10-18 13:19:40 --> Hooks Class Initialized
INFO - 2016-10-18 13:19:40 --> Config Class Initialized
INFO - 2016-10-18 13:19:40 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:19:40 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:19:40 --> Utf8 Class Initialized
DEBUG - 2016-10-18 13:19:40 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:19:40 --> Utf8 Class Initialized
INFO - 2016-10-18 13:19:40 --> URI Class Initialized
INFO - 2016-10-18 13:19:40 --> URI Class Initialized
DEBUG - 2016-10-18 13:19:40 --> No URI present. Default controller set.
INFO - 2016-10-18 13:19:40 --> Router Class Initialized
INFO - 2016-10-18 13:19:40 --> Router Class Initialized
INFO - 2016-10-18 13:19:40 --> Output Class Initialized
INFO - 2016-10-18 13:19:40 --> Output Class Initialized
INFO - 2016-10-18 13:19:40 --> Security Class Initialized
INFO - 2016-10-18 13:19:40 --> Security Class Initialized
DEBUG - 2016-10-18 13:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:19:40 --> Input Class Initialized
DEBUG - 2016-10-18 13:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:19:40 --> Input Class Initialized
INFO - 2016-10-18 13:19:40 --> Language Class Initialized
INFO - 2016-10-18 13:19:40 --> Language Class Initialized
INFO - 2016-10-18 13:19:40 --> Loader Class Initialized
INFO - 2016-10-18 13:19:40 --> Loader Class Initialized
INFO - 2016-10-18 13:19:40 --> Helper loaded: url_helper
INFO - 2016-10-18 13:19:40 --> Helper loaded: form_helper
INFO - 2016-10-18 13:19:40 --> Helper loaded: url_helper
INFO - 2016-10-18 13:19:40 --> Helper loaded: form_helper
INFO - 2016-10-18 13:19:40 --> Database Driver Class Initialized
INFO - 2016-10-18 13:19:40 --> Database Driver Class Initialized
INFO - 2016-10-18 13:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:19:40 --> Controller Class Initialized
INFO - 2016-10-18 13:19:40 --> Model Class Initialized
INFO - 2016-10-18 13:19:40 --> Final output sent to browser
DEBUG - 2016-10-18 13:19:40 --> Total execution time: 0.1040
INFO - 2016-10-18 13:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:19:40 --> Controller Class Initialized
INFO - 2016-10-18 13:19:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:19:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:19:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:19:40 --> Final output sent to browser
DEBUG - 2016-10-18 13:19:40 --> Total execution time: 0.1060
INFO - 2016-10-18 13:19:44 --> Config Class Initialized
INFO - 2016-10-18 13:19:44 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:19:44 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:19:44 --> Utf8 Class Initialized
INFO - 2016-10-18 13:19:44 --> URI Class Initialized
INFO - 2016-10-18 13:19:44 --> Router Class Initialized
INFO - 2016-10-18 13:19:44 --> Output Class Initialized
INFO - 2016-10-18 13:19:44 --> Security Class Initialized
DEBUG - 2016-10-18 13:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:19:44 --> Input Class Initialized
INFO - 2016-10-18 13:19:44 --> Language Class Initialized
INFO - 2016-10-18 13:19:44 --> Loader Class Initialized
INFO - 2016-10-18 13:19:44 --> Helper loaded: url_helper
INFO - 2016-10-18 13:19:44 --> Helper loaded: form_helper
INFO - 2016-10-18 13:19:44 --> Database Driver Class Initialized
INFO - 2016-10-18 13:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:19:44 --> Controller Class Initialized
INFO - 2016-10-18 13:19:44 --> Model Class Initialized
INFO - 2016-10-18 13:19:44 --> Final output sent to browser
DEBUG - 2016-10-18 13:19:44 --> Total execution time: 0.0053
INFO - 2016-10-18 13:19:44 --> Config Class Initialized
INFO - 2016-10-18 13:19:44 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:19:44 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:19:44 --> Utf8 Class Initialized
INFO - 2016-10-18 13:19:44 --> URI Class Initialized
DEBUG - 2016-10-18 13:19:44 --> No URI present. Default controller set.
INFO - 2016-10-18 13:19:44 --> Router Class Initialized
INFO - 2016-10-18 13:19:44 --> Output Class Initialized
INFO - 2016-10-18 13:19:44 --> Security Class Initialized
DEBUG - 2016-10-18 13:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:19:44 --> Input Class Initialized
INFO - 2016-10-18 13:19:44 --> Language Class Initialized
INFO - 2016-10-18 13:19:44 --> Loader Class Initialized
INFO - 2016-10-18 13:19:44 --> Helper loaded: url_helper
INFO - 2016-10-18 13:19:44 --> Helper loaded: form_helper
INFO - 2016-10-18 13:19:44 --> Database Driver Class Initialized
INFO - 2016-10-18 13:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:19:44 --> Controller Class Initialized
INFO - 2016-10-18 13:19:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:19:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:19:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:19:44 --> Final output sent to browser
DEBUG - 2016-10-18 13:19:44 --> Total execution time: 0.0051
INFO - 2016-10-18 13:19:51 --> Config Class Initialized
INFO - 2016-10-18 13:19:51 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:19:51 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:19:51 --> Utf8 Class Initialized
INFO - 2016-10-18 13:19:51 --> URI Class Initialized
INFO - 2016-10-18 13:19:51 --> Router Class Initialized
INFO - 2016-10-18 13:19:51 --> Output Class Initialized
INFO - 2016-10-18 13:19:51 --> Security Class Initialized
DEBUG - 2016-10-18 13:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:19:51 --> Input Class Initialized
INFO - 2016-10-18 13:19:51 --> Language Class Initialized
INFO - 2016-10-18 13:19:51 --> Loader Class Initialized
INFO - 2016-10-18 13:19:51 --> Helper loaded: url_helper
INFO - 2016-10-18 13:19:51 --> Helper loaded: form_helper
INFO - 2016-10-18 13:19:51 --> Database Driver Class Initialized
INFO - 2016-10-18 13:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:19:51 --> Controller Class Initialized
INFO - 2016-10-18 13:19:51 --> Model Class Initialized
INFO - 2016-10-18 13:19:51 --> Final output sent to browser
DEBUG - 2016-10-18 13:19:51 --> Total execution time: 0.0084
INFO - 2016-10-18 13:19:51 --> Config Class Initialized
INFO - 2016-10-18 13:19:51 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:19:51 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:19:51 --> Utf8 Class Initialized
INFO - 2016-10-18 13:19:51 --> URI Class Initialized
DEBUG - 2016-10-18 13:19:51 --> No URI present. Default controller set.
INFO - 2016-10-18 13:19:51 --> Router Class Initialized
INFO - 2016-10-18 13:19:51 --> Output Class Initialized
INFO - 2016-10-18 13:19:51 --> Security Class Initialized
DEBUG - 2016-10-18 13:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:19:51 --> Input Class Initialized
INFO - 2016-10-18 13:19:51 --> Language Class Initialized
INFO - 2016-10-18 13:19:51 --> Loader Class Initialized
INFO - 2016-10-18 13:19:51 --> Helper loaded: url_helper
INFO - 2016-10-18 13:19:51 --> Helper loaded: form_helper
INFO - 2016-10-18 13:19:51 --> Database Driver Class Initialized
INFO - 2016-10-18 13:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:19:51 --> Controller Class Initialized
INFO - 2016-10-18 13:19:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:19:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 13:19:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 13:19:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:19:51 --> Final output sent to browser
DEBUG - 2016-10-18 13:19:51 --> Total execution time: 0.0049
INFO - 2016-10-18 13:19:53 --> Config Class Initialized
INFO - 2016-10-18 13:19:53 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:19:53 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:19:53 --> Utf8 Class Initialized
INFO - 2016-10-18 13:19:53 --> URI Class Initialized
INFO - 2016-10-18 13:19:53 --> Router Class Initialized
INFO - 2016-10-18 13:19:53 --> Output Class Initialized
INFO - 2016-10-18 13:19:53 --> Security Class Initialized
DEBUG - 2016-10-18 13:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:19:53 --> Input Class Initialized
INFO - 2016-10-18 13:19:53 --> Language Class Initialized
INFO - 2016-10-18 13:19:53 --> Loader Class Initialized
INFO - 2016-10-18 13:19:53 --> Helper loaded: url_helper
INFO - 2016-10-18 13:19:53 --> Helper loaded: form_helper
INFO - 2016-10-18 13:19:53 --> Database Driver Class Initialized
INFO - 2016-10-18 13:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:19:53 --> Controller Class Initialized
ERROR - 2016-10-18 13:19:53 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 121
ERROR - 2016-10-18 13:19:53 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 121
INFO - 2016-10-18 13:19:53 --> Config Class Initialized
INFO - 2016-10-18 13:19:53 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:19:53 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:19:53 --> Utf8 Class Initialized
INFO - 2016-10-18 13:19:53 --> URI Class Initialized
DEBUG - 2016-10-18 13:19:53 --> No URI present. Default controller set.
INFO - 2016-10-18 13:19:53 --> Router Class Initialized
INFO - 2016-10-18 13:19:53 --> Output Class Initialized
INFO - 2016-10-18 13:19:53 --> Security Class Initialized
DEBUG - 2016-10-18 13:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:19:53 --> Input Class Initialized
INFO - 2016-10-18 13:19:53 --> Language Class Initialized
INFO - 2016-10-18 13:19:53 --> Loader Class Initialized
INFO - 2016-10-18 13:19:53 --> Helper loaded: url_helper
INFO - 2016-10-18 13:19:53 --> Helper loaded: form_helper
INFO - 2016-10-18 13:19:53 --> Database Driver Class Initialized
INFO - 2016-10-18 13:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:19:53 --> Controller Class Initialized
INFO - 2016-10-18 13:19:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:19:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:19:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:19:53 --> Final output sent to browser
DEBUG - 2016-10-18 13:19:53 --> Total execution time: 0.0042
INFO - 2016-10-18 13:20:09 --> Config Class Initialized
INFO - 2016-10-18 13:20:09 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:20:09 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:20:09 --> Utf8 Class Initialized
INFO - 2016-10-18 13:20:09 --> URI Class Initialized
INFO - 2016-10-18 13:20:09 --> Router Class Initialized
INFO - 2016-10-18 13:20:09 --> Output Class Initialized
INFO - 2016-10-18 13:20:09 --> Security Class Initialized
DEBUG - 2016-10-18 13:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:20:09 --> Input Class Initialized
INFO - 2016-10-18 13:20:09 --> Language Class Initialized
INFO - 2016-10-18 13:20:09 --> Loader Class Initialized
INFO - 2016-10-18 13:20:09 --> Helper loaded: url_helper
INFO - 2016-10-18 13:20:09 --> Helper loaded: form_helper
INFO - 2016-10-18 13:20:09 --> Database Driver Class Initialized
INFO - 2016-10-18 13:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:20:09 --> Controller Class Initialized
INFO - 2016-10-18 13:20:09 --> Model Class Initialized
INFO - 2016-10-18 13:20:09 --> Final output sent to browser
DEBUG - 2016-10-18 13:20:09 --> Total execution time: 0.0085
INFO - 2016-10-18 13:20:09 --> Config Class Initialized
INFO - 2016-10-18 13:20:09 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:20:09 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:20:09 --> Utf8 Class Initialized
INFO - 2016-10-18 13:20:09 --> URI Class Initialized
DEBUG - 2016-10-18 13:20:09 --> No URI present. Default controller set.
INFO - 2016-10-18 13:20:09 --> Router Class Initialized
INFO - 2016-10-18 13:20:09 --> Output Class Initialized
INFO - 2016-10-18 13:20:09 --> Security Class Initialized
DEBUG - 2016-10-18 13:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:20:09 --> Input Class Initialized
INFO - 2016-10-18 13:20:09 --> Language Class Initialized
INFO - 2016-10-18 13:20:09 --> Loader Class Initialized
INFO - 2016-10-18 13:20:09 --> Helper loaded: url_helper
INFO - 2016-10-18 13:20:09 --> Helper loaded: form_helper
INFO - 2016-10-18 13:20:09 --> Database Driver Class Initialized
INFO - 2016-10-18 13:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:20:09 --> Controller Class Initialized
INFO - 2016-10-18 13:20:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:20:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:20:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:20:09 --> Final output sent to browser
DEBUG - 2016-10-18 13:20:09 --> Total execution time: 0.0044
INFO - 2016-10-18 13:20:14 --> Config Class Initialized
INFO - 2016-10-18 13:20:14 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:20:14 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:20:14 --> Utf8 Class Initialized
INFO - 2016-10-18 13:20:14 --> URI Class Initialized
INFO - 2016-10-18 13:20:14 --> Router Class Initialized
INFO - 2016-10-18 13:20:14 --> Output Class Initialized
INFO - 2016-10-18 13:20:14 --> Security Class Initialized
DEBUG - 2016-10-18 13:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:20:14 --> Input Class Initialized
INFO - 2016-10-18 13:20:14 --> Language Class Initialized
INFO - 2016-10-18 13:20:14 --> Loader Class Initialized
INFO - 2016-10-18 13:20:14 --> Helper loaded: url_helper
INFO - 2016-10-18 13:20:14 --> Helper loaded: form_helper
INFO - 2016-10-18 13:20:14 --> Database Driver Class Initialized
INFO - 2016-10-18 13:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:20:14 --> Controller Class Initialized
INFO - 2016-10-18 13:20:14 --> Model Class Initialized
INFO - 2016-10-18 13:20:14 --> Final output sent to browser
DEBUG - 2016-10-18 13:20:14 --> Total execution time: 0.0052
INFO - 2016-10-18 13:20:14 --> Config Class Initialized
INFO - 2016-10-18 13:20:14 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:20:14 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:20:14 --> Utf8 Class Initialized
INFO - 2016-10-18 13:20:14 --> URI Class Initialized
DEBUG - 2016-10-18 13:20:14 --> No URI present. Default controller set.
INFO - 2016-10-18 13:20:14 --> Router Class Initialized
INFO - 2016-10-18 13:20:14 --> Output Class Initialized
INFO - 2016-10-18 13:20:14 --> Security Class Initialized
DEBUG - 2016-10-18 13:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:20:14 --> Input Class Initialized
INFO - 2016-10-18 13:20:14 --> Language Class Initialized
INFO - 2016-10-18 13:20:14 --> Loader Class Initialized
INFO - 2016-10-18 13:20:14 --> Helper loaded: url_helper
INFO - 2016-10-18 13:20:14 --> Helper loaded: form_helper
INFO - 2016-10-18 13:20:14 --> Database Driver Class Initialized
INFO - 2016-10-18 13:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:20:14 --> Controller Class Initialized
INFO - 2016-10-18 13:20:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:20:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:20:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:20:14 --> Final output sent to browser
DEBUG - 2016-10-18 13:20:14 --> Total execution time: 0.0074
INFO - 2016-10-18 13:20:28 --> Config Class Initialized
INFO - 2016-10-18 13:20:28 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:20:28 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:20:28 --> Utf8 Class Initialized
INFO - 2016-10-18 13:20:28 --> URI Class Initialized
DEBUG - 2016-10-18 13:20:28 --> No URI present. Default controller set.
INFO - 2016-10-18 13:20:28 --> Router Class Initialized
INFO - 2016-10-18 13:20:28 --> Output Class Initialized
INFO - 2016-10-18 13:20:28 --> Security Class Initialized
DEBUG - 2016-10-18 13:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:20:28 --> Input Class Initialized
INFO - 2016-10-18 13:20:28 --> Language Class Initialized
INFO - 2016-10-18 13:20:28 --> Loader Class Initialized
INFO - 2016-10-18 13:20:28 --> Helper loaded: url_helper
INFO - 2016-10-18 13:20:28 --> Helper loaded: form_helper
INFO - 2016-10-18 13:20:28 --> Database Driver Class Initialized
INFO - 2016-10-18 13:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:20:28 --> Controller Class Initialized
INFO - 2016-10-18 13:20:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:20:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:20:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:20:28 --> Final output sent to browser
DEBUG - 2016-10-18 13:20:28 --> Total execution time: 0.0073
INFO - 2016-10-18 13:20:42 --> Config Class Initialized
INFO - 2016-10-18 13:20:42 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:20:42 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:20:42 --> Utf8 Class Initialized
INFO - 2016-10-18 13:20:42 --> URI Class Initialized
DEBUG - 2016-10-18 13:20:42 --> No URI present. Default controller set.
INFO - 2016-10-18 13:20:42 --> Router Class Initialized
INFO - 2016-10-18 13:20:42 --> Output Class Initialized
INFO - 2016-10-18 13:20:42 --> Security Class Initialized
DEBUG - 2016-10-18 13:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:20:42 --> Input Class Initialized
INFO - 2016-10-18 13:20:42 --> Language Class Initialized
INFO - 2016-10-18 13:20:42 --> Loader Class Initialized
INFO - 2016-10-18 13:20:42 --> Helper loaded: url_helper
INFO - 2016-10-18 13:20:42 --> Helper loaded: form_helper
INFO - 2016-10-18 13:20:42 --> Database Driver Class Initialized
INFO - 2016-10-18 13:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:20:42 --> Controller Class Initialized
INFO - 2016-10-18 13:20:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:20:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:20:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:20:42 --> Final output sent to browser
DEBUG - 2016-10-18 13:20:42 --> Total execution time: 0.0083
INFO - 2016-10-18 13:21:01 --> Config Class Initialized
INFO - 2016-10-18 13:21:01 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:21:01 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:21:01 --> Utf8 Class Initialized
INFO - 2016-10-18 13:21:01 --> URI Class Initialized
DEBUG - 2016-10-18 13:21:01 --> No URI present. Default controller set.
INFO - 2016-10-18 13:21:01 --> Router Class Initialized
INFO - 2016-10-18 13:21:01 --> Output Class Initialized
INFO - 2016-10-18 13:21:01 --> Security Class Initialized
DEBUG - 2016-10-18 13:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:21:01 --> Input Class Initialized
INFO - 2016-10-18 13:21:01 --> Language Class Initialized
INFO - 2016-10-18 13:21:01 --> Loader Class Initialized
INFO - 2016-10-18 13:21:01 --> Helper loaded: url_helper
INFO - 2016-10-18 13:21:01 --> Helper loaded: form_helper
INFO - 2016-10-18 13:21:01 --> Database Driver Class Initialized
INFO - 2016-10-18 13:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:21:01 --> Controller Class Initialized
INFO - 2016-10-18 13:21:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:21:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:21:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:21:01 --> Final output sent to browser
DEBUG - 2016-10-18 13:21:01 --> Total execution time: 0.0083
INFO - 2016-10-18 13:21:16 --> Config Class Initialized
INFO - 2016-10-18 13:21:16 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:21:16 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:21:16 --> Utf8 Class Initialized
INFO - 2016-10-18 13:21:16 --> URI Class Initialized
DEBUG - 2016-10-18 13:21:16 --> No URI present. Default controller set.
INFO - 2016-10-18 13:21:16 --> Router Class Initialized
INFO - 2016-10-18 13:21:16 --> Output Class Initialized
INFO - 2016-10-18 13:21:16 --> Security Class Initialized
DEBUG - 2016-10-18 13:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:21:16 --> Input Class Initialized
INFO - 2016-10-18 13:21:16 --> Language Class Initialized
INFO - 2016-10-18 13:21:16 --> Loader Class Initialized
INFO - 2016-10-18 13:21:16 --> Helper loaded: url_helper
INFO - 2016-10-18 13:21:16 --> Helper loaded: form_helper
INFO - 2016-10-18 13:21:16 --> Database Driver Class Initialized
INFO - 2016-10-18 13:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:21:16 --> Controller Class Initialized
INFO - 2016-10-18 13:21:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:21:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:21:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:21:16 --> Final output sent to browser
DEBUG - 2016-10-18 13:21:16 --> Total execution time: 0.0053
INFO - 2016-10-18 13:21:28 --> Config Class Initialized
INFO - 2016-10-18 13:21:28 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:21:28 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:21:28 --> Utf8 Class Initialized
INFO - 2016-10-18 13:21:28 --> URI Class Initialized
DEBUG - 2016-10-18 13:21:28 --> No URI present. Default controller set.
INFO - 2016-10-18 13:21:28 --> Router Class Initialized
INFO - 2016-10-18 13:21:28 --> Output Class Initialized
INFO - 2016-10-18 13:21:28 --> Security Class Initialized
DEBUG - 2016-10-18 13:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:21:28 --> Input Class Initialized
INFO - 2016-10-18 13:21:28 --> Language Class Initialized
INFO - 2016-10-18 13:21:28 --> Loader Class Initialized
INFO - 2016-10-18 13:21:28 --> Helper loaded: url_helper
INFO - 2016-10-18 13:21:28 --> Helper loaded: form_helper
INFO - 2016-10-18 13:21:28 --> Database Driver Class Initialized
INFO - 2016-10-18 13:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:21:28 --> Controller Class Initialized
INFO - 2016-10-18 13:21:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:21:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:21:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:21:28 --> Final output sent to browser
DEBUG - 2016-10-18 13:21:28 --> Total execution time: 0.0054
INFO - 2016-10-18 13:21:33 --> Config Class Initialized
INFO - 2016-10-18 13:21:33 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:21:33 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:21:33 --> Utf8 Class Initialized
INFO - 2016-10-18 13:21:33 --> URI Class Initialized
INFO - 2016-10-18 13:21:33 --> Router Class Initialized
INFO - 2016-10-18 13:21:33 --> Output Class Initialized
INFO - 2016-10-18 13:21:33 --> Security Class Initialized
DEBUG - 2016-10-18 13:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:21:33 --> Input Class Initialized
INFO - 2016-10-18 13:21:33 --> Language Class Initialized
INFO - 2016-10-18 13:21:33 --> Loader Class Initialized
INFO - 2016-10-18 13:21:33 --> Helper loaded: url_helper
INFO - 2016-10-18 13:21:33 --> Helper loaded: form_helper
INFO - 2016-10-18 13:21:33 --> Database Driver Class Initialized
INFO - 2016-10-18 13:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:21:33 --> Controller Class Initialized
INFO - 2016-10-18 13:21:33 --> Model Class Initialized
INFO - 2016-10-18 13:21:33 --> Final output sent to browser
DEBUG - 2016-10-18 13:21:33 --> Total execution time: 0.0081
INFO - 2016-10-18 13:21:34 --> Config Class Initialized
INFO - 2016-10-18 13:21:34 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:21:34 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:21:34 --> Utf8 Class Initialized
INFO - 2016-10-18 13:21:34 --> URI Class Initialized
DEBUG - 2016-10-18 13:21:34 --> No URI present. Default controller set.
INFO - 2016-10-18 13:21:34 --> Router Class Initialized
INFO - 2016-10-18 13:21:34 --> Output Class Initialized
INFO - 2016-10-18 13:21:34 --> Security Class Initialized
DEBUG - 2016-10-18 13:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:21:34 --> Input Class Initialized
INFO - 2016-10-18 13:21:34 --> Language Class Initialized
INFO - 2016-10-18 13:21:34 --> Loader Class Initialized
INFO - 2016-10-18 13:21:34 --> Helper loaded: url_helper
INFO - 2016-10-18 13:21:34 --> Helper loaded: form_helper
INFO - 2016-10-18 13:21:34 --> Database Driver Class Initialized
INFO - 2016-10-18 13:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:21:34 --> Controller Class Initialized
INFO - 2016-10-18 13:21:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:21:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:21:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:21:34 --> Final output sent to browser
DEBUG - 2016-10-18 13:21:34 --> Total execution time: 0.0042
INFO - 2016-10-18 13:21:43 --> Config Class Initialized
INFO - 2016-10-18 13:21:43 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:21:43 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:21:43 --> Utf8 Class Initialized
INFO - 2016-10-18 13:21:43 --> URI Class Initialized
INFO - 2016-10-18 13:21:43 --> Router Class Initialized
INFO - 2016-10-18 13:21:43 --> Output Class Initialized
INFO - 2016-10-18 13:21:43 --> Security Class Initialized
DEBUG - 2016-10-18 13:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:21:43 --> Input Class Initialized
INFO - 2016-10-18 13:21:43 --> Language Class Initialized
INFO - 2016-10-18 13:21:43 --> Loader Class Initialized
INFO - 2016-10-18 13:21:43 --> Helper loaded: url_helper
INFO - 2016-10-18 13:21:43 --> Helper loaded: form_helper
INFO - 2016-10-18 13:21:43 --> Database Driver Class Initialized
INFO - 2016-10-18 13:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:21:43 --> Controller Class Initialized
INFO - 2016-10-18 13:21:43 --> Model Class Initialized
INFO - 2016-10-18 13:21:43 --> Final output sent to browser
DEBUG - 2016-10-18 13:21:43 --> Total execution time: 0.0083
INFO - 2016-10-18 13:21:43 --> Config Class Initialized
INFO - 2016-10-18 13:21:43 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:21:43 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:21:43 --> Utf8 Class Initialized
INFO - 2016-10-18 13:21:43 --> URI Class Initialized
DEBUG - 2016-10-18 13:21:43 --> No URI present. Default controller set.
INFO - 2016-10-18 13:21:43 --> Router Class Initialized
INFO - 2016-10-18 13:21:43 --> Output Class Initialized
INFO - 2016-10-18 13:21:43 --> Security Class Initialized
DEBUG - 2016-10-18 13:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:21:43 --> Input Class Initialized
INFO - 2016-10-18 13:21:43 --> Language Class Initialized
INFO - 2016-10-18 13:21:43 --> Loader Class Initialized
INFO - 2016-10-18 13:21:43 --> Helper loaded: url_helper
INFO - 2016-10-18 13:21:43 --> Helper loaded: form_helper
INFO - 2016-10-18 13:21:43 --> Database Driver Class Initialized
INFO - 2016-10-18 13:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:21:43 --> Controller Class Initialized
INFO - 2016-10-18 13:21:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:21:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:21:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:21:43 --> Final output sent to browser
DEBUG - 2016-10-18 13:21:43 --> Total execution time: 0.0043
INFO - 2016-10-18 13:21:52 --> Config Class Initialized
INFO - 2016-10-18 13:21:52 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:21:52 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:21:52 --> Utf8 Class Initialized
INFO - 2016-10-18 13:21:52 --> URI Class Initialized
INFO - 2016-10-18 13:21:52 --> Router Class Initialized
INFO - 2016-10-18 13:21:52 --> Output Class Initialized
INFO - 2016-10-18 13:21:52 --> Security Class Initialized
DEBUG - 2016-10-18 13:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:21:52 --> Input Class Initialized
INFO - 2016-10-18 13:21:52 --> Language Class Initialized
INFO - 2016-10-18 13:21:52 --> Loader Class Initialized
INFO - 2016-10-18 13:21:52 --> Helper loaded: url_helper
INFO - 2016-10-18 13:21:52 --> Helper loaded: form_helper
INFO - 2016-10-18 13:21:52 --> Database Driver Class Initialized
INFO - 2016-10-18 13:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:21:52 --> Controller Class Initialized
INFO - 2016-10-18 13:21:52 --> Model Class Initialized
INFO - 2016-10-18 13:21:52 --> Final output sent to browser
DEBUG - 2016-10-18 13:21:52 --> Total execution time: 0.0101
INFO - 2016-10-18 13:21:52 --> Config Class Initialized
INFO - 2016-10-18 13:21:52 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:21:52 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:21:52 --> Utf8 Class Initialized
INFO - 2016-10-18 13:21:52 --> URI Class Initialized
DEBUG - 2016-10-18 13:21:52 --> No URI present. Default controller set.
INFO - 2016-10-18 13:21:52 --> Router Class Initialized
INFO - 2016-10-18 13:21:52 --> Output Class Initialized
INFO - 2016-10-18 13:21:52 --> Security Class Initialized
DEBUG - 2016-10-18 13:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:21:52 --> Input Class Initialized
INFO - 2016-10-18 13:21:52 --> Language Class Initialized
INFO - 2016-10-18 13:21:52 --> Loader Class Initialized
INFO - 2016-10-18 13:21:52 --> Helper loaded: url_helper
INFO - 2016-10-18 13:21:52 --> Helper loaded: form_helper
INFO - 2016-10-18 13:21:52 --> Database Driver Class Initialized
INFO - 2016-10-18 13:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:21:52 --> Controller Class Initialized
INFO - 2016-10-18 13:21:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:21:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:21:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:21:52 --> Final output sent to browser
DEBUG - 2016-10-18 13:21:52 --> Total execution time: 0.0042
INFO - 2016-10-18 13:22:49 --> Config Class Initialized
INFO - 2016-10-18 13:22:49 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:22:49 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:22:49 --> Utf8 Class Initialized
INFO - 2016-10-18 13:22:49 --> URI Class Initialized
DEBUG - 2016-10-18 13:22:49 --> No URI present. Default controller set.
INFO - 2016-10-18 13:22:49 --> Router Class Initialized
INFO - 2016-10-18 13:22:49 --> Output Class Initialized
INFO - 2016-10-18 13:22:49 --> Security Class Initialized
DEBUG - 2016-10-18 13:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:22:49 --> Input Class Initialized
INFO - 2016-10-18 13:22:49 --> Language Class Initialized
INFO - 2016-10-18 13:22:49 --> Loader Class Initialized
INFO - 2016-10-18 13:22:49 --> Helper loaded: url_helper
INFO - 2016-10-18 13:22:49 --> Helper loaded: form_helper
INFO - 2016-10-18 13:22:49 --> Database Driver Class Initialized
INFO - 2016-10-18 13:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:22:49 --> Controller Class Initialized
INFO - 2016-10-18 13:22:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:22:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:22:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:22:49 --> Final output sent to browser
DEBUG - 2016-10-18 13:22:49 --> Total execution time: 0.0048
INFO - 2016-10-18 13:22:54 --> Config Class Initialized
INFO - 2016-10-18 13:22:54 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:22:54 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:22:54 --> Utf8 Class Initialized
INFO - 2016-10-18 13:22:54 --> URI Class Initialized
INFO - 2016-10-18 13:22:54 --> Router Class Initialized
INFO - 2016-10-18 13:22:54 --> Output Class Initialized
INFO - 2016-10-18 13:22:54 --> Security Class Initialized
DEBUG - 2016-10-18 13:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:22:54 --> Input Class Initialized
INFO - 2016-10-18 13:22:54 --> Language Class Initialized
INFO - 2016-10-18 13:22:54 --> Loader Class Initialized
INFO - 2016-10-18 13:22:54 --> Helper loaded: url_helper
INFO - 2016-10-18 13:22:54 --> Helper loaded: form_helper
INFO - 2016-10-18 13:22:54 --> Database Driver Class Initialized
INFO - 2016-10-18 13:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:22:54 --> Controller Class Initialized
INFO - 2016-10-18 13:22:54 --> Model Class Initialized
INFO - 2016-10-18 13:22:54 --> Final output sent to browser
DEBUG - 2016-10-18 13:22:54 --> Total execution time: 0.0057
INFO - 2016-10-18 13:22:58 --> Config Class Initialized
INFO - 2016-10-18 13:22:58 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:22:58 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:22:58 --> Utf8 Class Initialized
INFO - 2016-10-18 13:22:58 --> URI Class Initialized
DEBUG - 2016-10-18 13:22:58 --> No URI present. Default controller set.
INFO - 2016-10-18 13:22:58 --> Router Class Initialized
INFO - 2016-10-18 13:22:58 --> Output Class Initialized
INFO - 2016-10-18 13:22:58 --> Security Class Initialized
DEBUG - 2016-10-18 13:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:22:58 --> Input Class Initialized
INFO - 2016-10-18 13:22:58 --> Language Class Initialized
INFO - 2016-10-18 13:22:58 --> Loader Class Initialized
INFO - 2016-10-18 13:22:58 --> Helper loaded: url_helper
INFO - 2016-10-18 13:22:58 --> Helper loaded: form_helper
INFO - 2016-10-18 13:22:58 --> Database Driver Class Initialized
INFO - 2016-10-18 13:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:22:58 --> Controller Class Initialized
INFO - 2016-10-18 13:22:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:22:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:22:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:22:58 --> Final output sent to browser
DEBUG - 2016-10-18 13:22:58 --> Total execution time: 0.0047
INFO - 2016-10-18 13:23:22 --> Config Class Initialized
INFO - 2016-10-18 13:23:22 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:23:22 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:23:22 --> Utf8 Class Initialized
INFO - 2016-10-18 13:23:22 --> URI Class Initialized
DEBUG - 2016-10-18 13:23:22 --> No URI present. Default controller set.
INFO - 2016-10-18 13:23:22 --> Router Class Initialized
INFO - 2016-10-18 13:23:22 --> Output Class Initialized
INFO - 2016-10-18 13:23:22 --> Security Class Initialized
DEBUG - 2016-10-18 13:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:23:22 --> Input Class Initialized
INFO - 2016-10-18 13:23:22 --> Language Class Initialized
INFO - 2016-10-18 13:23:22 --> Loader Class Initialized
INFO - 2016-10-18 13:23:22 --> Helper loaded: url_helper
INFO - 2016-10-18 13:23:22 --> Helper loaded: form_helper
INFO - 2016-10-18 13:23:22 --> Database Driver Class Initialized
INFO - 2016-10-18 13:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:23:22 --> Controller Class Initialized
INFO - 2016-10-18 13:23:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:23:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:23:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:23:22 --> Final output sent to browser
DEBUG - 2016-10-18 13:23:22 --> Total execution time: 0.0048
INFO - 2016-10-18 13:23:29 --> Config Class Initialized
INFO - 2016-10-18 13:23:29 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:23:29 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:23:29 --> Utf8 Class Initialized
INFO - 2016-10-18 13:23:29 --> URI Class Initialized
INFO - 2016-10-18 13:23:29 --> Router Class Initialized
INFO - 2016-10-18 13:23:29 --> Output Class Initialized
INFO - 2016-10-18 13:23:29 --> Security Class Initialized
DEBUG - 2016-10-18 13:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:23:29 --> Input Class Initialized
INFO - 2016-10-18 13:23:29 --> Language Class Initialized
INFO - 2016-10-18 13:23:29 --> Loader Class Initialized
INFO - 2016-10-18 13:23:29 --> Helper loaded: url_helper
INFO - 2016-10-18 13:23:29 --> Helper loaded: form_helper
INFO - 2016-10-18 13:23:29 --> Database Driver Class Initialized
INFO - 2016-10-18 13:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:23:29 --> Controller Class Initialized
INFO - 2016-10-18 13:23:29 --> Model Class Initialized
INFO - 2016-10-18 13:23:29 --> Final output sent to browser
DEBUG - 2016-10-18 13:23:29 --> Total execution time: 0.0063
INFO - 2016-10-18 13:23:29 --> Config Class Initialized
INFO - 2016-10-18 13:23:29 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:23:29 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:23:29 --> Utf8 Class Initialized
INFO - 2016-10-18 13:23:29 --> URI Class Initialized
DEBUG - 2016-10-18 13:23:29 --> No URI present. Default controller set.
INFO - 2016-10-18 13:23:29 --> Router Class Initialized
INFO - 2016-10-18 13:23:29 --> Output Class Initialized
INFO - 2016-10-18 13:23:29 --> Security Class Initialized
DEBUG - 2016-10-18 13:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:23:29 --> Input Class Initialized
INFO - 2016-10-18 13:23:29 --> Language Class Initialized
INFO - 2016-10-18 13:23:29 --> Loader Class Initialized
INFO - 2016-10-18 13:23:29 --> Helper loaded: url_helper
INFO - 2016-10-18 13:23:29 --> Helper loaded: form_helper
INFO - 2016-10-18 13:23:29 --> Database Driver Class Initialized
INFO - 2016-10-18 13:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:23:29 --> Controller Class Initialized
INFO - 2016-10-18 13:23:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:23:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 13:23:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 13:23:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:23:29 --> Final output sent to browser
DEBUG - 2016-10-18 13:23:29 --> Total execution time: 0.0049
INFO - 2016-10-18 13:23:32 --> Config Class Initialized
INFO - 2016-10-18 13:23:32 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:23:32 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:23:32 --> Utf8 Class Initialized
INFO - 2016-10-18 13:23:32 --> URI Class Initialized
DEBUG - 2016-10-18 13:23:32 --> No URI present. Default controller set.
INFO - 2016-10-18 13:23:32 --> Router Class Initialized
INFO - 2016-10-18 13:23:32 --> Output Class Initialized
INFO - 2016-10-18 13:23:32 --> Security Class Initialized
DEBUG - 2016-10-18 13:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:23:32 --> Input Class Initialized
INFO - 2016-10-18 13:23:32 --> Language Class Initialized
INFO - 2016-10-18 13:23:32 --> Loader Class Initialized
INFO - 2016-10-18 13:23:32 --> Helper loaded: url_helper
INFO - 2016-10-18 13:23:32 --> Helper loaded: form_helper
INFO - 2016-10-18 13:23:32 --> Database Driver Class Initialized
INFO - 2016-10-18 13:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:23:32 --> Controller Class Initialized
INFO - 2016-10-18 13:23:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:23:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 13:23:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 13:23:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:23:32 --> Final output sent to browser
DEBUG - 2016-10-18 13:23:32 --> Total execution time: 0.0047
INFO - 2016-10-18 13:23:35 --> Config Class Initialized
INFO - 2016-10-18 13:23:35 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:23:35 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:23:35 --> Utf8 Class Initialized
INFO - 2016-10-18 13:23:35 --> URI Class Initialized
INFO - 2016-10-18 13:23:35 --> Router Class Initialized
INFO - 2016-10-18 13:23:35 --> Output Class Initialized
INFO - 2016-10-18 13:23:35 --> Security Class Initialized
DEBUG - 2016-10-18 13:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:23:35 --> Input Class Initialized
INFO - 2016-10-18 13:23:35 --> Language Class Initialized
INFO - 2016-10-18 13:23:35 --> Loader Class Initialized
INFO - 2016-10-18 13:23:35 --> Helper loaded: url_helper
INFO - 2016-10-18 13:23:35 --> Helper loaded: form_helper
INFO - 2016-10-18 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-18 13:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:23:35 --> Controller Class Initialized
INFO - 2016-10-18 13:23:35 --> Form Validation Class Initialized
INFO - 2016-10-18 13:23:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 13:23:35 --> Final output sent to browser
DEBUG - 2016-10-18 13:23:35 --> Total execution time: 0.0283
INFO - 2016-10-18 13:23:38 --> Config Class Initialized
INFO - 2016-10-18 13:23:38 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:23:38 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:23:38 --> Utf8 Class Initialized
INFO - 2016-10-18 13:23:38 --> URI Class Initialized
INFO - 2016-10-18 13:23:38 --> Router Class Initialized
INFO - 2016-10-18 13:23:38 --> Output Class Initialized
INFO - 2016-10-18 13:23:38 --> Security Class Initialized
DEBUG - 2016-10-18 13:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:23:38 --> Input Class Initialized
INFO - 2016-10-18 13:23:38 --> Language Class Initialized
INFO - 2016-10-18 13:23:38 --> Loader Class Initialized
INFO - 2016-10-18 13:23:38 --> Helper loaded: url_helper
INFO - 2016-10-18 13:23:38 --> Helper loaded: form_helper
INFO - 2016-10-18 13:23:38 --> Database Driver Class Initialized
INFO - 2016-10-18 13:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:23:38 --> Controller Class Initialized
INFO - 2016-10-18 13:23:38 --> Form Validation Class Initialized
INFO - 2016-10-18 13:23:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 13:23:38 --> Final output sent to browser
DEBUG - 2016-10-18 13:23:38 --> Total execution time: 0.0047
INFO - 2016-10-18 13:23:40 --> Config Class Initialized
INFO - 2016-10-18 13:23:40 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:23:40 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:23:40 --> Utf8 Class Initialized
INFO - 2016-10-18 13:23:40 --> URI Class Initialized
INFO - 2016-10-18 13:23:40 --> Router Class Initialized
INFO - 2016-10-18 13:23:40 --> Output Class Initialized
INFO - 2016-10-18 13:23:40 --> Security Class Initialized
DEBUG - 2016-10-18 13:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:23:40 --> Input Class Initialized
INFO - 2016-10-18 13:23:40 --> Language Class Initialized
INFO - 2016-10-18 13:23:40 --> Loader Class Initialized
INFO - 2016-10-18 13:23:40 --> Helper loaded: url_helper
INFO - 2016-10-18 13:23:40 --> Helper loaded: form_helper
INFO - 2016-10-18 13:23:40 --> Database Driver Class Initialized
INFO - 2016-10-18 13:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:23:40 --> Controller Class Initialized
ERROR - 2016-10-18 13:23:40 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 121
ERROR - 2016-10-18 13:23:40 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 121
INFO - 2016-10-18 13:23:40 --> Config Class Initialized
INFO - 2016-10-18 13:23:40 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:23:40 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:23:40 --> Utf8 Class Initialized
INFO - 2016-10-18 13:23:40 --> URI Class Initialized
DEBUG - 2016-10-18 13:23:40 --> No URI present. Default controller set.
INFO - 2016-10-18 13:23:40 --> Router Class Initialized
INFO - 2016-10-18 13:23:40 --> Output Class Initialized
INFO - 2016-10-18 13:23:40 --> Security Class Initialized
DEBUG - 2016-10-18 13:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:23:40 --> Input Class Initialized
INFO - 2016-10-18 13:23:40 --> Language Class Initialized
INFO - 2016-10-18 13:23:40 --> Loader Class Initialized
INFO - 2016-10-18 13:23:40 --> Helper loaded: url_helper
INFO - 2016-10-18 13:23:40 --> Helper loaded: form_helper
INFO - 2016-10-18 13:23:40 --> Database Driver Class Initialized
INFO - 2016-10-18 13:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:23:40 --> Controller Class Initialized
INFO - 2016-10-18 13:23:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:23:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:23:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:23:40 --> Final output sent to browser
DEBUG - 2016-10-18 13:23:40 --> Total execution time: 0.0039
INFO - 2016-10-18 13:30:05 --> Config Class Initialized
INFO - 2016-10-18 13:30:05 --> Hooks Class Initialized
DEBUG - 2016-10-18 13:30:05 --> UTF-8 Support Enabled
INFO - 2016-10-18 13:30:05 --> Utf8 Class Initialized
INFO - 2016-10-18 13:30:05 --> URI Class Initialized
DEBUG - 2016-10-18 13:30:05 --> No URI present. Default controller set.
INFO - 2016-10-18 13:30:05 --> Router Class Initialized
INFO - 2016-10-18 13:30:05 --> Output Class Initialized
INFO - 2016-10-18 13:30:05 --> Security Class Initialized
DEBUG - 2016-10-18 13:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 13:30:05 --> Input Class Initialized
INFO - 2016-10-18 13:30:05 --> Language Class Initialized
INFO - 2016-10-18 13:30:05 --> Loader Class Initialized
INFO - 2016-10-18 13:30:05 --> Helper loaded: url_helper
INFO - 2016-10-18 13:30:05 --> Helper loaded: form_helper
INFO - 2016-10-18 13:30:05 --> Database Driver Class Initialized
INFO - 2016-10-18 13:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 13:30:05 --> Controller Class Initialized
INFO - 2016-10-18 13:30:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 13:30:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 13:30:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 13:30:05 --> Final output sent to browser
DEBUG - 2016-10-18 13:30:05 --> Total execution time: 0.0052
INFO - 2016-10-18 14:50:55 --> Config Class Initialized
INFO - 2016-10-18 14:50:55 --> Hooks Class Initialized
DEBUG - 2016-10-18 14:50:55 --> UTF-8 Support Enabled
INFO - 2016-10-18 14:50:55 --> Utf8 Class Initialized
INFO - 2016-10-18 14:50:55 --> URI Class Initialized
DEBUG - 2016-10-18 14:50:55 --> No URI present. Default controller set.
INFO - 2016-10-18 14:50:55 --> Router Class Initialized
INFO - 2016-10-18 14:50:55 --> Output Class Initialized
INFO - 2016-10-18 14:50:55 --> Security Class Initialized
DEBUG - 2016-10-18 14:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 14:50:55 --> Input Class Initialized
INFO - 2016-10-18 14:50:55 --> Language Class Initialized
INFO - 2016-10-18 14:50:55 --> Loader Class Initialized
INFO - 2016-10-18 14:50:55 --> Helper loaded: url_helper
INFO - 2016-10-18 14:50:55 --> Helper loaded: form_helper
INFO - 2016-10-18 14:50:55 --> Database Driver Class Initialized
INFO - 2016-10-18 14:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 14:50:55 --> Controller Class Initialized
INFO - 2016-10-18 14:50:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 14:50:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 14:50:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 14:50:55 --> Final output sent to browser
DEBUG - 2016-10-18 14:50:55 --> Total execution time: 0.0301
INFO - 2016-10-18 14:54:32 --> Config Class Initialized
INFO - 2016-10-18 14:54:32 --> Hooks Class Initialized
DEBUG - 2016-10-18 14:54:32 --> UTF-8 Support Enabled
INFO - 2016-10-18 14:54:32 --> Utf8 Class Initialized
INFO - 2016-10-18 14:54:32 --> URI Class Initialized
DEBUG - 2016-10-18 14:54:32 --> No URI present. Default controller set.
INFO - 2016-10-18 14:54:32 --> Router Class Initialized
INFO - 2016-10-18 14:54:32 --> Output Class Initialized
INFO - 2016-10-18 14:54:32 --> Security Class Initialized
DEBUG - 2016-10-18 14:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 14:54:32 --> Input Class Initialized
INFO - 2016-10-18 14:54:32 --> Language Class Initialized
INFO - 2016-10-18 14:54:32 --> Loader Class Initialized
INFO - 2016-10-18 14:54:32 --> Helper loaded: url_helper
INFO - 2016-10-18 14:54:32 --> Helper loaded: form_helper
INFO - 2016-10-18 14:54:32 --> Database Driver Class Initialized
INFO - 2016-10-18 14:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 14:54:32 --> Controller Class Initialized
INFO - 2016-10-18 14:54:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 14:54:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 14:54:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 14:54:32 --> Final output sent to browser
DEBUG - 2016-10-18 14:54:32 --> Total execution time: 0.0057
INFO - 2016-10-18 15:04:43 --> Config Class Initialized
INFO - 2016-10-18 15:04:43 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:04:43 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:04:43 --> Utf8 Class Initialized
INFO - 2016-10-18 15:04:43 --> URI Class Initialized
DEBUG - 2016-10-18 15:04:43 --> No URI present. Default controller set.
INFO - 2016-10-18 15:04:43 --> Router Class Initialized
INFO - 2016-10-18 15:04:43 --> Output Class Initialized
INFO - 2016-10-18 15:04:43 --> Security Class Initialized
DEBUG - 2016-10-18 15:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:04:43 --> Input Class Initialized
INFO - 2016-10-18 15:04:43 --> Language Class Initialized
INFO - 2016-10-18 15:04:43 --> Loader Class Initialized
INFO - 2016-10-18 15:04:43 --> Helper loaded: url_helper
INFO - 2016-10-18 15:04:43 --> Helper loaded: form_helper
INFO - 2016-10-18 15:04:43 --> Database Driver Class Initialized
INFO - 2016-10-18 15:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:04:43 --> Controller Class Initialized
INFO - 2016-10-18 15:04:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
ERROR - 2016-10-18 15:04:43 --> Severity: Notice --> Undefined variable: nameErr /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php 26
INFO - 2016-10-18 15:04:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:04:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:04:43 --> Final output sent to browser
DEBUG - 2016-10-18 15:04:43 --> Total execution time: 0.0070
INFO - 2016-10-18 15:05:48 --> Config Class Initialized
INFO - 2016-10-18 15:05:48 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:05:48 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:05:48 --> Utf8 Class Initialized
INFO - 2016-10-18 15:05:48 --> URI Class Initialized
DEBUG - 2016-10-18 15:05:48 --> No URI present. Default controller set.
INFO - 2016-10-18 15:05:48 --> Router Class Initialized
INFO - 2016-10-18 15:05:48 --> Output Class Initialized
INFO - 2016-10-18 15:05:48 --> Security Class Initialized
DEBUG - 2016-10-18 15:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:05:48 --> Input Class Initialized
INFO - 2016-10-18 15:05:48 --> Language Class Initialized
INFO - 2016-10-18 15:05:48 --> Loader Class Initialized
INFO - 2016-10-18 15:05:48 --> Helper loaded: url_helper
INFO - 2016-10-18 15:05:48 --> Helper loaded: form_helper
INFO - 2016-10-18 15:05:48 --> Database Driver Class Initialized
INFO - 2016-10-18 15:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:05:48 --> Controller Class Initialized
INFO - 2016-10-18 15:05:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
ERROR - 2016-10-18 15:05:48 --> Severity: Notice --> Undefined variable: nameErr /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php 26
INFO - 2016-10-18 15:05:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:05:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:05:48 --> Final output sent to browser
DEBUG - 2016-10-18 15:05:48 --> Total execution time: 0.0056
INFO - 2016-10-18 15:06:10 --> Config Class Initialized
INFO - 2016-10-18 15:06:10 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:06:10 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:06:10 --> Utf8 Class Initialized
INFO - 2016-10-18 15:06:10 --> URI Class Initialized
DEBUG - 2016-10-18 15:06:10 --> No URI present. Default controller set.
INFO - 2016-10-18 15:06:10 --> Router Class Initialized
INFO - 2016-10-18 15:06:10 --> Output Class Initialized
INFO - 2016-10-18 15:06:10 --> Security Class Initialized
DEBUG - 2016-10-18 15:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:06:10 --> Input Class Initialized
INFO - 2016-10-18 15:06:10 --> Language Class Initialized
INFO - 2016-10-18 15:06:10 --> Loader Class Initialized
INFO - 2016-10-18 15:06:10 --> Helper loaded: url_helper
INFO - 2016-10-18 15:06:10 --> Helper loaded: form_helper
INFO - 2016-10-18 15:06:10 --> Database Driver Class Initialized
INFO - 2016-10-18 15:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:06:10 --> Controller Class Initialized
INFO - 2016-10-18 15:06:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:06:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:06:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:06:10 --> Final output sent to browser
DEBUG - 2016-10-18 15:06:10 --> Total execution time: 0.0069
INFO - 2016-10-18 15:12:25 --> Config Class Initialized
INFO - 2016-10-18 15:12:25 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:12:25 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:12:25 --> Utf8 Class Initialized
INFO - 2016-10-18 15:12:25 --> URI Class Initialized
DEBUG - 2016-10-18 15:12:25 --> No URI present. Default controller set.
INFO - 2016-10-18 15:12:25 --> Router Class Initialized
INFO - 2016-10-18 15:12:25 --> Output Class Initialized
INFO - 2016-10-18 15:12:25 --> Security Class Initialized
DEBUG - 2016-10-18 15:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:12:25 --> Input Class Initialized
INFO - 2016-10-18 15:12:25 --> Language Class Initialized
INFO - 2016-10-18 15:12:25 --> Loader Class Initialized
INFO - 2016-10-18 15:12:25 --> Helper loaded: url_helper
INFO - 2016-10-18 15:12:25 --> Helper loaded: form_helper
INFO - 2016-10-18 15:12:25 --> Database Driver Class Initialized
INFO - 2016-10-18 15:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:12:25 --> Controller Class Initialized
INFO - 2016-10-18 15:12:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:12:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:12:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:12:25 --> Final output sent to browser
DEBUG - 2016-10-18 15:12:25 --> Total execution time: 0.0055
INFO - 2016-10-18 15:12:57 --> Config Class Initialized
INFO - 2016-10-18 15:12:57 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:12:57 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:12:57 --> Utf8 Class Initialized
INFO - 2016-10-18 15:12:57 --> URI Class Initialized
DEBUG - 2016-10-18 15:12:57 --> No URI present. Default controller set.
INFO - 2016-10-18 15:12:57 --> Router Class Initialized
INFO - 2016-10-18 15:12:57 --> Output Class Initialized
INFO - 2016-10-18 15:12:57 --> Security Class Initialized
DEBUG - 2016-10-18 15:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:12:57 --> Input Class Initialized
INFO - 2016-10-18 15:12:57 --> Language Class Initialized
INFO - 2016-10-18 15:12:57 --> Loader Class Initialized
INFO - 2016-10-18 15:12:57 --> Helper loaded: url_helper
INFO - 2016-10-18 15:12:57 --> Helper loaded: form_helper
INFO - 2016-10-18 15:12:57 --> Database Driver Class Initialized
INFO - 2016-10-18 15:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:12:57 --> Controller Class Initialized
INFO - 2016-10-18 15:12:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:12:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:12:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:12:57 --> Final output sent to browser
DEBUG - 2016-10-18 15:12:57 --> Total execution time: 0.0055
INFO - 2016-10-18 15:14:11 --> Config Class Initialized
INFO - 2016-10-18 15:14:11 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:14:11 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:14:11 --> Utf8 Class Initialized
INFO - 2016-10-18 15:14:11 --> URI Class Initialized
DEBUG - 2016-10-18 15:14:11 --> No URI present. Default controller set.
INFO - 2016-10-18 15:14:11 --> Router Class Initialized
INFO - 2016-10-18 15:14:11 --> Output Class Initialized
INFO - 2016-10-18 15:14:11 --> Security Class Initialized
DEBUG - 2016-10-18 15:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:14:11 --> Input Class Initialized
INFO - 2016-10-18 15:14:11 --> Language Class Initialized
INFO - 2016-10-18 15:14:11 --> Loader Class Initialized
INFO - 2016-10-18 15:14:11 --> Helper loaded: url_helper
INFO - 2016-10-18 15:14:11 --> Helper loaded: form_helper
INFO - 2016-10-18 15:14:11 --> Database Driver Class Initialized
INFO - 2016-10-18 15:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:14:11 --> Controller Class Initialized
INFO - 2016-10-18 15:14:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:14:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:14:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:14:11 --> Final output sent to browser
DEBUG - 2016-10-18 15:14:11 --> Total execution time: 0.0074
INFO - 2016-10-18 15:14:13 --> Config Class Initialized
INFO - 2016-10-18 15:14:13 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:14:13 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:14:13 --> Utf8 Class Initialized
INFO - 2016-10-18 15:14:13 --> URI Class Initialized
DEBUG - 2016-10-18 15:14:13 --> No URI present. Default controller set.
INFO - 2016-10-18 15:14:13 --> Router Class Initialized
INFO - 2016-10-18 15:14:13 --> Output Class Initialized
INFO - 2016-10-18 15:14:13 --> Security Class Initialized
DEBUG - 2016-10-18 15:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:14:13 --> Input Class Initialized
INFO - 2016-10-18 15:14:13 --> Language Class Initialized
INFO - 2016-10-18 15:14:13 --> Loader Class Initialized
INFO - 2016-10-18 15:14:13 --> Helper loaded: url_helper
INFO - 2016-10-18 15:14:13 --> Helper loaded: form_helper
INFO - 2016-10-18 15:14:13 --> Database Driver Class Initialized
INFO - 2016-10-18 15:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:14:13 --> Controller Class Initialized
INFO - 2016-10-18 15:14:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:14:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:14:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:14:13 --> Final output sent to browser
DEBUG - 2016-10-18 15:14:13 --> Total execution time: 0.0067
INFO - 2016-10-18 15:15:08 --> Config Class Initialized
INFO - 2016-10-18 15:15:08 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:15:08 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:15:08 --> Utf8 Class Initialized
INFO - 2016-10-18 15:15:08 --> URI Class Initialized
DEBUG - 2016-10-18 15:15:08 --> No URI present. Default controller set.
INFO - 2016-10-18 15:15:08 --> Router Class Initialized
INFO - 2016-10-18 15:15:08 --> Output Class Initialized
INFO - 2016-10-18 15:15:08 --> Security Class Initialized
DEBUG - 2016-10-18 15:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:15:08 --> Input Class Initialized
INFO - 2016-10-18 15:15:08 --> Language Class Initialized
INFO - 2016-10-18 15:15:08 --> Loader Class Initialized
INFO - 2016-10-18 15:15:08 --> Helper loaded: url_helper
INFO - 2016-10-18 15:15:08 --> Helper loaded: form_helper
INFO - 2016-10-18 15:15:08 --> Database Driver Class Initialized
INFO - 2016-10-18 15:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:15:08 --> Controller Class Initialized
INFO - 2016-10-18 15:15:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:15:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:15:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:15:08 --> Final output sent to browser
DEBUG - 2016-10-18 15:15:08 --> Total execution time: 0.0058
INFO - 2016-10-18 15:15:26 --> Config Class Initialized
INFO - 2016-10-18 15:15:26 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:15:26 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:15:26 --> Utf8 Class Initialized
INFO - 2016-10-18 15:15:26 --> URI Class Initialized
DEBUG - 2016-10-18 15:15:26 --> No URI present. Default controller set.
INFO - 2016-10-18 15:15:26 --> Router Class Initialized
INFO - 2016-10-18 15:15:26 --> Output Class Initialized
INFO - 2016-10-18 15:15:26 --> Security Class Initialized
DEBUG - 2016-10-18 15:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:15:26 --> Input Class Initialized
INFO - 2016-10-18 15:15:26 --> Language Class Initialized
INFO - 2016-10-18 15:15:26 --> Loader Class Initialized
INFO - 2016-10-18 15:15:26 --> Helper loaded: url_helper
INFO - 2016-10-18 15:15:26 --> Helper loaded: form_helper
INFO - 2016-10-18 15:15:26 --> Database Driver Class Initialized
INFO - 2016-10-18 15:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:15:26 --> Controller Class Initialized
INFO - 2016-10-18 15:15:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:15:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:15:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:15:26 --> Final output sent to browser
DEBUG - 2016-10-18 15:15:26 --> Total execution time: 0.0054
INFO - 2016-10-18 15:16:14 --> Config Class Initialized
INFO - 2016-10-18 15:16:14 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:16:14 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:16:14 --> Utf8 Class Initialized
INFO - 2016-10-18 15:16:14 --> URI Class Initialized
DEBUG - 2016-10-18 15:16:14 --> No URI present. Default controller set.
INFO - 2016-10-18 15:16:14 --> Router Class Initialized
INFO - 2016-10-18 15:16:14 --> Output Class Initialized
INFO - 2016-10-18 15:16:14 --> Security Class Initialized
DEBUG - 2016-10-18 15:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:16:14 --> Input Class Initialized
INFO - 2016-10-18 15:16:14 --> Language Class Initialized
INFO - 2016-10-18 15:16:14 --> Loader Class Initialized
INFO - 2016-10-18 15:16:14 --> Helper loaded: url_helper
INFO - 2016-10-18 15:16:14 --> Helper loaded: form_helper
INFO - 2016-10-18 15:16:14 --> Database Driver Class Initialized
INFO - 2016-10-18 15:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:16:14 --> Controller Class Initialized
INFO - 2016-10-18 15:16:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:16:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:16:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:16:14 --> Final output sent to browser
DEBUG - 2016-10-18 15:16:14 --> Total execution time: 0.0098
INFO - 2016-10-18 15:16:26 --> Config Class Initialized
INFO - 2016-10-18 15:16:26 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:16:26 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:16:26 --> Utf8 Class Initialized
INFO - 2016-10-18 15:16:26 --> URI Class Initialized
DEBUG - 2016-10-18 15:16:26 --> No URI present. Default controller set.
INFO - 2016-10-18 15:16:26 --> Router Class Initialized
INFO - 2016-10-18 15:16:26 --> Output Class Initialized
INFO - 2016-10-18 15:16:26 --> Security Class Initialized
DEBUG - 2016-10-18 15:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:16:26 --> Input Class Initialized
INFO - 2016-10-18 15:16:26 --> Language Class Initialized
INFO - 2016-10-18 15:16:26 --> Loader Class Initialized
INFO - 2016-10-18 15:16:26 --> Helper loaded: url_helper
INFO - 2016-10-18 15:16:26 --> Helper loaded: form_helper
INFO - 2016-10-18 15:16:26 --> Database Driver Class Initialized
INFO - 2016-10-18 15:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:16:26 --> Controller Class Initialized
INFO - 2016-10-18 15:16:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:16:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:16:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:16:26 --> Final output sent to browser
DEBUG - 2016-10-18 15:16:26 --> Total execution time: 0.0053
INFO - 2016-10-18 15:16:48 --> Config Class Initialized
INFO - 2016-10-18 15:16:48 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:16:48 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:16:48 --> Utf8 Class Initialized
INFO - 2016-10-18 15:16:48 --> URI Class Initialized
DEBUG - 2016-10-18 15:16:48 --> No URI present. Default controller set.
INFO - 2016-10-18 15:16:48 --> Router Class Initialized
INFO - 2016-10-18 15:16:48 --> Output Class Initialized
INFO - 2016-10-18 15:16:48 --> Security Class Initialized
DEBUG - 2016-10-18 15:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:16:48 --> Input Class Initialized
INFO - 2016-10-18 15:16:48 --> Language Class Initialized
INFO - 2016-10-18 15:16:48 --> Loader Class Initialized
INFO - 2016-10-18 15:16:48 --> Helper loaded: url_helper
INFO - 2016-10-18 15:16:48 --> Helper loaded: form_helper
INFO - 2016-10-18 15:16:48 --> Database Driver Class Initialized
INFO - 2016-10-18 15:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:16:48 --> Controller Class Initialized
INFO - 2016-10-18 15:16:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:16:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:16:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:16:48 --> Final output sent to browser
DEBUG - 2016-10-18 15:16:48 --> Total execution time: 0.0053
INFO - 2016-10-18 15:17:15 --> Config Class Initialized
INFO - 2016-10-18 15:17:15 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:17:15 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:17:15 --> Utf8 Class Initialized
INFO - 2016-10-18 15:17:15 --> URI Class Initialized
DEBUG - 2016-10-18 15:17:15 --> No URI present. Default controller set.
INFO - 2016-10-18 15:17:15 --> Router Class Initialized
INFO - 2016-10-18 15:17:15 --> Output Class Initialized
INFO - 2016-10-18 15:17:15 --> Security Class Initialized
DEBUG - 2016-10-18 15:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:17:15 --> Input Class Initialized
INFO - 2016-10-18 15:17:15 --> Language Class Initialized
INFO - 2016-10-18 15:17:15 --> Loader Class Initialized
INFO - 2016-10-18 15:17:15 --> Helper loaded: url_helper
INFO - 2016-10-18 15:17:15 --> Helper loaded: form_helper
INFO - 2016-10-18 15:17:15 --> Database Driver Class Initialized
INFO - 2016-10-18 15:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:17:15 --> Controller Class Initialized
INFO - 2016-10-18 15:17:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:17:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:17:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:17:15 --> Final output sent to browser
DEBUG - 2016-10-18 15:17:15 --> Total execution time: 0.0052
INFO - 2016-10-18 15:18:22 --> Config Class Initialized
INFO - 2016-10-18 15:18:22 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:18:22 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:18:22 --> Utf8 Class Initialized
INFO - 2016-10-18 15:18:22 --> URI Class Initialized
DEBUG - 2016-10-18 15:18:22 --> No URI present. Default controller set.
INFO - 2016-10-18 15:18:22 --> Router Class Initialized
INFO - 2016-10-18 15:18:22 --> Output Class Initialized
INFO - 2016-10-18 15:18:22 --> Security Class Initialized
DEBUG - 2016-10-18 15:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:18:22 --> Input Class Initialized
INFO - 2016-10-18 15:18:22 --> Language Class Initialized
INFO - 2016-10-18 15:18:22 --> Loader Class Initialized
INFO - 2016-10-18 15:18:22 --> Helper loaded: url_helper
INFO - 2016-10-18 15:18:22 --> Helper loaded: form_helper
INFO - 2016-10-18 15:18:22 --> Database Driver Class Initialized
INFO - 2016-10-18 15:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:18:22 --> Controller Class Initialized
INFO - 2016-10-18 15:18:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:18:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:18:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:18:22 --> Final output sent to browser
DEBUG - 2016-10-18 15:18:22 --> Total execution time: 0.0056
INFO - 2016-10-18 15:18:53 --> Config Class Initialized
INFO - 2016-10-18 15:18:53 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:18:53 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:18:53 --> Utf8 Class Initialized
INFO - 2016-10-18 15:18:53 --> URI Class Initialized
DEBUG - 2016-10-18 15:18:53 --> No URI present. Default controller set.
INFO - 2016-10-18 15:18:53 --> Router Class Initialized
INFO - 2016-10-18 15:18:53 --> Output Class Initialized
INFO - 2016-10-18 15:18:53 --> Security Class Initialized
DEBUG - 2016-10-18 15:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:18:53 --> Input Class Initialized
INFO - 2016-10-18 15:18:53 --> Language Class Initialized
INFO - 2016-10-18 15:18:53 --> Loader Class Initialized
INFO - 2016-10-18 15:18:53 --> Helper loaded: url_helper
INFO - 2016-10-18 15:18:53 --> Helper loaded: form_helper
INFO - 2016-10-18 15:18:53 --> Database Driver Class Initialized
INFO - 2016-10-18 15:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:18:53 --> Controller Class Initialized
INFO - 2016-10-18 15:18:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:18:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:18:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:18:53 --> Final output sent to browser
DEBUG - 2016-10-18 15:18:53 --> Total execution time: 0.0051
INFO - 2016-10-18 15:19:07 --> Config Class Initialized
INFO - 2016-10-18 15:19:07 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:19:07 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:19:07 --> Utf8 Class Initialized
INFO - 2016-10-18 15:19:07 --> URI Class Initialized
INFO - 2016-10-18 15:19:07 --> Router Class Initialized
INFO - 2016-10-18 15:19:07 --> Output Class Initialized
INFO - 2016-10-18 15:19:07 --> Security Class Initialized
DEBUG - 2016-10-18 15:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:19:07 --> Input Class Initialized
INFO - 2016-10-18 15:19:07 --> Language Class Initialized
INFO - 2016-10-18 15:19:07 --> Loader Class Initialized
INFO - 2016-10-18 15:19:07 --> Helper loaded: url_helper
INFO - 2016-10-18 15:19:07 --> Helper loaded: form_helper
INFO - 2016-10-18 15:19:07 --> Database Driver Class Initialized
INFO - 2016-10-18 15:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:19:07 --> Controller Class Initialized
INFO - 2016-10-18 15:19:07 --> Model Class Initialized
INFO - 2016-10-18 15:19:07 --> Final output sent to browser
DEBUG - 2016-10-18 15:19:07 --> Total execution time: 0.0472
INFO - 2016-10-18 15:20:07 --> Config Class Initialized
INFO - 2016-10-18 15:20:07 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:20:07 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:20:07 --> Utf8 Class Initialized
INFO - 2016-10-18 15:20:07 --> URI Class Initialized
DEBUG - 2016-10-18 15:20:07 --> No URI present. Default controller set.
INFO - 2016-10-18 15:20:07 --> Router Class Initialized
INFO - 2016-10-18 15:20:07 --> Output Class Initialized
INFO - 2016-10-18 15:20:07 --> Security Class Initialized
DEBUG - 2016-10-18 15:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:20:07 --> Input Class Initialized
INFO - 2016-10-18 15:20:07 --> Language Class Initialized
INFO - 2016-10-18 15:20:07 --> Loader Class Initialized
INFO - 2016-10-18 15:20:07 --> Helper loaded: url_helper
INFO - 2016-10-18 15:20:07 --> Helper loaded: form_helper
INFO - 2016-10-18 15:20:07 --> Database Driver Class Initialized
INFO - 2016-10-18 15:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:20:07 --> Controller Class Initialized
INFO - 2016-10-18 15:20:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:20:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:20:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:20:07 --> Final output sent to browser
DEBUG - 2016-10-18 15:20:07 --> Total execution time: 0.0063
INFO - 2016-10-18 15:20:09 --> Config Class Initialized
INFO - 2016-10-18 15:20:09 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:20:09 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:20:09 --> Utf8 Class Initialized
INFO - 2016-10-18 15:20:09 --> URI Class Initialized
DEBUG - 2016-10-18 15:20:09 --> No URI present. Default controller set.
INFO - 2016-10-18 15:20:09 --> Router Class Initialized
INFO - 2016-10-18 15:20:09 --> Output Class Initialized
INFO - 2016-10-18 15:20:09 --> Security Class Initialized
DEBUG - 2016-10-18 15:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:20:09 --> Input Class Initialized
INFO - 2016-10-18 15:20:09 --> Language Class Initialized
INFO - 2016-10-18 15:20:09 --> Loader Class Initialized
INFO - 2016-10-18 15:20:09 --> Helper loaded: url_helper
INFO - 2016-10-18 15:20:09 --> Helper loaded: form_helper
INFO - 2016-10-18 15:20:09 --> Database Driver Class Initialized
INFO - 2016-10-18 15:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:20:09 --> Controller Class Initialized
INFO - 2016-10-18 15:20:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:20:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:20:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:20:09 --> Final output sent to browser
DEBUG - 2016-10-18 15:20:09 --> Total execution time: 0.0086
INFO - 2016-10-18 15:20:21 --> Config Class Initialized
INFO - 2016-10-18 15:20:21 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:20:21 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:20:21 --> Utf8 Class Initialized
INFO - 2016-10-18 15:20:21 --> URI Class Initialized
INFO - 2016-10-18 15:20:21 --> Router Class Initialized
INFO - 2016-10-18 15:20:21 --> Output Class Initialized
INFO - 2016-10-18 15:20:21 --> Security Class Initialized
DEBUG - 2016-10-18 15:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:20:21 --> Input Class Initialized
INFO - 2016-10-18 15:20:21 --> Language Class Initialized
INFO - 2016-10-18 15:20:21 --> Loader Class Initialized
INFO - 2016-10-18 15:20:21 --> Helper loaded: url_helper
INFO - 2016-10-18 15:20:21 --> Helper loaded: form_helper
INFO - 2016-10-18 15:20:21 --> Database Driver Class Initialized
INFO - 2016-10-18 15:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:20:21 --> Controller Class Initialized
INFO - 2016-10-18 15:20:21 --> Model Class Initialized
INFO - 2016-10-18 15:20:21 --> Final output sent to browser
DEBUG - 2016-10-18 15:20:21 --> Total execution time: 0.0064
INFO - 2016-10-18 15:20:33 --> Config Class Initialized
INFO - 2016-10-18 15:20:33 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:20:33 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:20:33 --> Utf8 Class Initialized
INFO - 2016-10-18 15:20:33 --> URI Class Initialized
DEBUG - 2016-10-18 15:20:33 --> No URI present. Default controller set.
INFO - 2016-10-18 15:20:33 --> Router Class Initialized
INFO - 2016-10-18 15:20:33 --> Output Class Initialized
INFO - 2016-10-18 15:20:33 --> Security Class Initialized
DEBUG - 2016-10-18 15:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:20:33 --> Input Class Initialized
INFO - 2016-10-18 15:20:33 --> Language Class Initialized
INFO - 2016-10-18 15:20:33 --> Loader Class Initialized
INFO - 2016-10-18 15:20:33 --> Helper loaded: url_helper
INFO - 2016-10-18 15:20:33 --> Helper loaded: form_helper
INFO - 2016-10-18 15:20:33 --> Database Driver Class Initialized
INFO - 2016-10-18 15:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:20:33 --> Controller Class Initialized
INFO - 2016-10-18 15:20:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:20:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:20:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:20:33 --> Final output sent to browser
DEBUG - 2016-10-18 15:20:33 --> Total execution time: 0.0056
INFO - 2016-10-18 15:21:05 --> Config Class Initialized
INFO - 2016-10-18 15:21:05 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:21:05 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:21:05 --> Utf8 Class Initialized
INFO - 2016-10-18 15:21:05 --> URI Class Initialized
DEBUG - 2016-10-18 15:21:05 --> No URI present. Default controller set.
INFO - 2016-10-18 15:21:05 --> Router Class Initialized
INFO - 2016-10-18 15:21:05 --> Output Class Initialized
INFO - 2016-10-18 15:21:05 --> Security Class Initialized
DEBUG - 2016-10-18 15:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:21:05 --> Input Class Initialized
INFO - 2016-10-18 15:21:05 --> Language Class Initialized
INFO - 2016-10-18 15:21:05 --> Loader Class Initialized
INFO - 2016-10-18 15:21:05 --> Helper loaded: url_helper
INFO - 2016-10-18 15:21:05 --> Helper loaded: form_helper
INFO - 2016-10-18 15:21:05 --> Database Driver Class Initialized
INFO - 2016-10-18 15:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:21:05 --> Controller Class Initialized
INFO - 2016-10-18 15:21:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:21:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:21:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:21:05 --> Final output sent to browser
DEBUG - 2016-10-18 15:21:05 --> Total execution time: 0.0066
INFO - 2016-10-18 15:21:19 --> Config Class Initialized
INFO - 2016-10-18 15:21:19 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:21:19 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:21:19 --> Utf8 Class Initialized
INFO - 2016-10-18 15:21:19 --> URI Class Initialized
DEBUG - 2016-10-18 15:21:19 --> No URI present. Default controller set.
INFO - 2016-10-18 15:21:19 --> Router Class Initialized
INFO - 2016-10-18 15:21:19 --> Output Class Initialized
INFO - 2016-10-18 15:21:19 --> Security Class Initialized
DEBUG - 2016-10-18 15:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:21:19 --> Input Class Initialized
INFO - 2016-10-18 15:21:19 --> Language Class Initialized
INFO - 2016-10-18 15:21:19 --> Loader Class Initialized
INFO - 2016-10-18 15:21:19 --> Helper loaded: url_helper
INFO - 2016-10-18 15:21:19 --> Helper loaded: form_helper
INFO - 2016-10-18 15:21:19 --> Database Driver Class Initialized
INFO - 2016-10-18 15:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:21:19 --> Controller Class Initialized
INFO - 2016-10-18 15:21:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:21:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:21:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:21:19 --> Final output sent to browser
DEBUG - 2016-10-18 15:21:19 --> Total execution time: 0.0088
INFO - 2016-10-18 15:21:27 --> Config Class Initialized
INFO - 2016-10-18 15:21:27 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:21:27 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:21:27 --> Utf8 Class Initialized
INFO - 2016-10-18 15:21:27 --> URI Class Initialized
INFO - 2016-10-18 15:21:27 --> Router Class Initialized
INFO - 2016-10-18 15:21:27 --> Output Class Initialized
INFO - 2016-10-18 15:21:27 --> Security Class Initialized
DEBUG - 2016-10-18 15:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:21:27 --> Input Class Initialized
INFO - 2016-10-18 15:21:27 --> Language Class Initialized
INFO - 2016-10-18 15:21:27 --> Loader Class Initialized
INFO - 2016-10-18 15:21:27 --> Helper loaded: url_helper
INFO - 2016-10-18 15:21:27 --> Helper loaded: form_helper
INFO - 2016-10-18 15:21:27 --> Database Driver Class Initialized
INFO - 2016-10-18 15:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:21:27 --> Controller Class Initialized
INFO - 2016-10-18 15:21:27 --> Model Class Initialized
INFO - 2016-10-18 15:21:27 --> Final output sent to browser
DEBUG - 2016-10-18 15:21:27 --> Total execution time: 0.0104
INFO - 2016-10-18 15:22:01 --> Config Class Initialized
INFO - 2016-10-18 15:22:01 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:22:01 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:22:01 --> Utf8 Class Initialized
INFO - 2016-10-18 15:22:01 --> URI Class Initialized
DEBUG - 2016-10-18 15:22:01 --> No URI present. Default controller set.
INFO - 2016-10-18 15:22:01 --> Router Class Initialized
INFO - 2016-10-18 15:22:01 --> Output Class Initialized
INFO - 2016-10-18 15:22:01 --> Security Class Initialized
DEBUG - 2016-10-18 15:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:22:01 --> Input Class Initialized
INFO - 2016-10-18 15:22:01 --> Language Class Initialized
INFO - 2016-10-18 15:22:01 --> Loader Class Initialized
INFO - 2016-10-18 15:22:01 --> Helper loaded: url_helper
INFO - 2016-10-18 15:22:01 --> Helper loaded: form_helper
INFO - 2016-10-18 15:22:01 --> Database Driver Class Initialized
INFO - 2016-10-18 15:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:22:01 --> Controller Class Initialized
INFO - 2016-10-18 15:22:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:22:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:22:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:22:01 --> Final output sent to browser
DEBUG - 2016-10-18 15:22:01 --> Total execution time: 0.0053
INFO - 2016-10-18 15:22:17 --> Config Class Initialized
INFO - 2016-10-18 15:22:17 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:22:17 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:22:17 --> Utf8 Class Initialized
INFO - 2016-10-18 15:22:17 --> URI Class Initialized
DEBUG - 2016-10-18 15:22:17 --> No URI present. Default controller set.
INFO - 2016-10-18 15:22:17 --> Router Class Initialized
INFO - 2016-10-18 15:22:17 --> Output Class Initialized
INFO - 2016-10-18 15:22:17 --> Security Class Initialized
DEBUG - 2016-10-18 15:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:22:17 --> Input Class Initialized
INFO - 2016-10-18 15:22:17 --> Language Class Initialized
INFO - 2016-10-18 15:22:17 --> Loader Class Initialized
INFO - 2016-10-18 15:22:17 --> Helper loaded: url_helper
INFO - 2016-10-18 15:22:17 --> Helper loaded: form_helper
INFO - 2016-10-18 15:22:17 --> Database Driver Class Initialized
INFO - 2016-10-18 15:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:22:17 --> Controller Class Initialized
INFO - 2016-10-18 15:22:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:22:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:22:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:22:17 --> Final output sent to browser
DEBUG - 2016-10-18 15:22:17 --> Total execution time: 0.0072
INFO - 2016-10-18 15:22:19 --> Config Class Initialized
INFO - 2016-10-18 15:22:19 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:22:19 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:22:19 --> Utf8 Class Initialized
INFO - 2016-10-18 15:22:19 --> URI Class Initialized
DEBUG - 2016-10-18 15:22:19 --> No URI present. Default controller set.
INFO - 2016-10-18 15:22:19 --> Router Class Initialized
INFO - 2016-10-18 15:22:19 --> Output Class Initialized
INFO - 2016-10-18 15:22:19 --> Security Class Initialized
DEBUG - 2016-10-18 15:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:22:19 --> Input Class Initialized
INFO - 2016-10-18 15:22:19 --> Language Class Initialized
INFO - 2016-10-18 15:22:19 --> Loader Class Initialized
INFO - 2016-10-18 15:22:19 --> Helper loaded: url_helper
INFO - 2016-10-18 15:22:19 --> Helper loaded: form_helper
INFO - 2016-10-18 15:22:19 --> Database Driver Class Initialized
INFO - 2016-10-18 15:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:22:19 --> Controller Class Initialized
INFO - 2016-10-18 15:22:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:22:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:22:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:22:19 --> Final output sent to browser
DEBUG - 2016-10-18 15:22:19 --> Total execution time: 0.0079
INFO - 2016-10-18 15:22:23 --> Config Class Initialized
INFO - 2016-10-18 15:22:23 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:22:23 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:22:23 --> Utf8 Class Initialized
INFO - 2016-10-18 15:22:23 --> URI Class Initialized
INFO - 2016-10-18 15:22:23 --> Router Class Initialized
INFO - 2016-10-18 15:22:23 --> Output Class Initialized
INFO - 2016-10-18 15:22:23 --> Security Class Initialized
DEBUG - 2016-10-18 15:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:22:23 --> Input Class Initialized
INFO - 2016-10-18 15:22:23 --> Language Class Initialized
INFO - 2016-10-18 15:22:23 --> Loader Class Initialized
INFO - 2016-10-18 15:22:23 --> Helper loaded: url_helper
INFO - 2016-10-18 15:22:23 --> Helper loaded: form_helper
INFO - 2016-10-18 15:22:23 --> Database Driver Class Initialized
INFO - 2016-10-18 15:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:22:23 --> Controller Class Initialized
INFO - 2016-10-18 15:22:23 --> Model Class Initialized
INFO - 2016-10-18 15:22:23 --> Final output sent to browser
DEBUG - 2016-10-18 15:22:23 --> Total execution time: 0.0063
INFO - 2016-10-18 15:22:49 --> Config Class Initialized
INFO - 2016-10-18 15:22:49 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:22:49 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:22:49 --> Utf8 Class Initialized
INFO - 2016-10-18 15:22:49 --> URI Class Initialized
DEBUG - 2016-10-18 15:22:49 --> No URI present. Default controller set.
INFO - 2016-10-18 15:22:49 --> Router Class Initialized
INFO - 2016-10-18 15:22:49 --> Output Class Initialized
INFO - 2016-10-18 15:22:49 --> Security Class Initialized
DEBUG - 2016-10-18 15:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:22:49 --> Input Class Initialized
INFO - 2016-10-18 15:22:49 --> Language Class Initialized
INFO - 2016-10-18 15:22:49 --> Loader Class Initialized
INFO - 2016-10-18 15:22:49 --> Helper loaded: url_helper
INFO - 2016-10-18 15:22:49 --> Helper loaded: form_helper
INFO - 2016-10-18 15:22:49 --> Database Driver Class Initialized
INFO - 2016-10-18 15:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:22:49 --> Controller Class Initialized
INFO - 2016-10-18 15:22:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:22:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:22:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:22:49 --> Final output sent to browser
DEBUG - 2016-10-18 15:22:49 --> Total execution time: 0.0050
INFO - 2016-10-18 15:22:53 --> Config Class Initialized
INFO - 2016-10-18 15:22:53 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:22:53 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:22:53 --> Utf8 Class Initialized
INFO - 2016-10-18 15:22:53 --> URI Class Initialized
INFO - 2016-10-18 15:22:53 --> Router Class Initialized
INFO - 2016-10-18 15:22:53 --> Output Class Initialized
INFO - 2016-10-18 15:22:53 --> Security Class Initialized
DEBUG - 2016-10-18 15:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:22:53 --> Input Class Initialized
INFO - 2016-10-18 15:22:53 --> Language Class Initialized
INFO - 2016-10-18 15:22:53 --> Loader Class Initialized
INFO - 2016-10-18 15:22:53 --> Helper loaded: url_helper
INFO - 2016-10-18 15:22:53 --> Helper loaded: form_helper
INFO - 2016-10-18 15:22:53 --> Database Driver Class Initialized
INFO - 2016-10-18 15:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:22:53 --> Controller Class Initialized
INFO - 2016-10-18 15:22:53 --> Model Class Initialized
INFO - 2016-10-18 15:22:53 --> Final output sent to browser
DEBUG - 2016-10-18 15:22:53 --> Total execution time: 0.0064
INFO - 2016-10-18 15:23:16 --> Config Class Initialized
INFO - 2016-10-18 15:23:16 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:23:16 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:23:16 --> Utf8 Class Initialized
INFO - 2016-10-18 15:23:16 --> URI Class Initialized
DEBUG - 2016-10-18 15:23:16 --> No URI present. Default controller set.
INFO - 2016-10-18 15:23:16 --> Router Class Initialized
INFO - 2016-10-18 15:23:16 --> Output Class Initialized
INFO - 2016-10-18 15:23:16 --> Security Class Initialized
DEBUG - 2016-10-18 15:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:23:16 --> Input Class Initialized
INFO - 2016-10-18 15:23:16 --> Language Class Initialized
INFO - 2016-10-18 15:23:16 --> Loader Class Initialized
INFO - 2016-10-18 15:23:16 --> Helper loaded: url_helper
INFO - 2016-10-18 15:23:16 --> Helper loaded: form_helper
INFO - 2016-10-18 15:23:16 --> Database Driver Class Initialized
INFO - 2016-10-18 15:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:23:16 --> Controller Class Initialized
INFO - 2016-10-18 15:23:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:23:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:23:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:23:16 --> Final output sent to browser
DEBUG - 2016-10-18 15:23:16 --> Total execution time: 0.0052
INFO - 2016-10-18 15:23:20 --> Config Class Initialized
INFO - 2016-10-18 15:23:20 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:23:20 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:23:20 --> Utf8 Class Initialized
INFO - 2016-10-18 15:23:20 --> URI Class Initialized
INFO - 2016-10-18 15:23:20 --> Router Class Initialized
INFO - 2016-10-18 15:23:20 --> Output Class Initialized
INFO - 2016-10-18 15:23:20 --> Security Class Initialized
DEBUG - 2016-10-18 15:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:23:20 --> Input Class Initialized
INFO - 2016-10-18 15:23:20 --> Language Class Initialized
INFO - 2016-10-18 15:23:20 --> Loader Class Initialized
INFO - 2016-10-18 15:23:20 --> Helper loaded: url_helper
INFO - 2016-10-18 15:23:20 --> Helper loaded: form_helper
INFO - 2016-10-18 15:23:20 --> Database Driver Class Initialized
INFO - 2016-10-18 15:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:23:20 --> Controller Class Initialized
INFO - 2016-10-18 15:23:20 --> Model Class Initialized
INFO - 2016-10-18 15:23:20 --> Final output sent to browser
DEBUG - 2016-10-18 15:23:20 --> Total execution time: 0.0062
INFO - 2016-10-18 15:24:33 --> Config Class Initialized
INFO - 2016-10-18 15:24:33 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:24:33 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:24:33 --> Utf8 Class Initialized
INFO - 2016-10-18 15:24:33 --> URI Class Initialized
INFO - 2016-10-18 15:24:33 --> Router Class Initialized
INFO - 2016-10-18 15:24:33 --> Output Class Initialized
INFO - 2016-10-18 15:24:33 --> Security Class Initialized
DEBUG - 2016-10-18 15:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:24:33 --> Input Class Initialized
INFO - 2016-10-18 15:24:33 --> Language Class Initialized
INFO - 2016-10-18 15:24:33 --> Loader Class Initialized
INFO - 2016-10-18 15:24:33 --> Helper loaded: url_helper
INFO - 2016-10-18 15:24:33 --> Helper loaded: form_helper
INFO - 2016-10-18 15:24:33 --> Database Driver Class Initialized
INFO - 2016-10-18 15:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:24:33 --> Controller Class Initialized
INFO - 2016-10-18 15:24:33 --> Model Class Initialized
INFO - 2016-10-18 15:24:33 --> Final output sent to browser
DEBUG - 2016-10-18 15:24:33 --> Total execution time: 0.0122
INFO - 2016-10-18 15:24:46 --> Config Class Initialized
INFO - 2016-10-18 15:24:46 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:24:46 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:24:46 --> Utf8 Class Initialized
INFO - 2016-10-18 15:24:46 --> URI Class Initialized
DEBUG - 2016-10-18 15:24:46 --> No URI present. Default controller set.
INFO - 2016-10-18 15:24:46 --> Router Class Initialized
INFO - 2016-10-18 15:24:46 --> Output Class Initialized
INFO - 2016-10-18 15:24:46 --> Security Class Initialized
DEBUG - 2016-10-18 15:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:24:46 --> Input Class Initialized
INFO - 2016-10-18 15:24:46 --> Language Class Initialized
INFO - 2016-10-18 15:24:46 --> Loader Class Initialized
INFO - 2016-10-18 15:24:46 --> Helper loaded: url_helper
INFO - 2016-10-18 15:24:46 --> Helper loaded: form_helper
INFO - 2016-10-18 15:24:46 --> Database Driver Class Initialized
INFO - 2016-10-18 15:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:24:46 --> Controller Class Initialized
INFO - 2016-10-18 15:24:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:24:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:24:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:24:46 --> Final output sent to browser
DEBUG - 2016-10-18 15:24:46 --> Total execution time: 0.0052
INFO - 2016-10-18 15:24:52 --> Config Class Initialized
INFO - 2016-10-18 15:24:52 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:24:52 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:24:52 --> Utf8 Class Initialized
INFO - 2016-10-18 15:24:52 --> URI Class Initialized
INFO - 2016-10-18 15:24:52 --> Router Class Initialized
INFO - 2016-10-18 15:24:52 --> Output Class Initialized
INFO - 2016-10-18 15:24:52 --> Security Class Initialized
DEBUG - 2016-10-18 15:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:24:52 --> Input Class Initialized
INFO - 2016-10-18 15:24:52 --> Language Class Initialized
INFO - 2016-10-18 15:24:52 --> Loader Class Initialized
INFO - 2016-10-18 15:24:52 --> Helper loaded: url_helper
INFO - 2016-10-18 15:24:52 --> Helper loaded: form_helper
INFO - 2016-10-18 15:24:52 --> Database Driver Class Initialized
INFO - 2016-10-18 15:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:24:52 --> Controller Class Initialized
INFO - 2016-10-18 15:24:52 --> Model Class Initialized
INFO - 2016-10-18 15:24:52 --> Final output sent to browser
DEBUG - 2016-10-18 15:24:52 --> Total execution time: 0.0067
INFO - 2016-10-18 15:25:07 --> Config Class Initialized
INFO - 2016-10-18 15:25:07 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:25:07 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:25:07 --> Utf8 Class Initialized
INFO - 2016-10-18 15:25:07 --> URI Class Initialized
DEBUG - 2016-10-18 15:25:07 --> No URI present. Default controller set.
INFO - 2016-10-18 15:25:07 --> Router Class Initialized
INFO - 2016-10-18 15:25:07 --> Output Class Initialized
INFO - 2016-10-18 15:25:07 --> Security Class Initialized
DEBUG - 2016-10-18 15:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:25:07 --> Input Class Initialized
INFO - 2016-10-18 15:25:07 --> Language Class Initialized
INFO - 2016-10-18 15:25:07 --> Loader Class Initialized
INFO - 2016-10-18 15:25:07 --> Helper loaded: url_helper
INFO - 2016-10-18 15:25:07 --> Helper loaded: form_helper
INFO - 2016-10-18 15:25:07 --> Database Driver Class Initialized
INFO - 2016-10-18 15:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:25:07 --> Controller Class Initialized
INFO - 2016-10-18 15:25:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:25:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:25:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:25:07 --> Final output sent to browser
DEBUG - 2016-10-18 15:25:07 --> Total execution time: 0.0085
INFO - 2016-10-18 15:25:46 --> Config Class Initialized
INFO - 2016-10-18 15:25:46 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:25:46 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:25:46 --> Utf8 Class Initialized
INFO - 2016-10-18 15:25:46 --> URI Class Initialized
DEBUG - 2016-10-18 15:25:46 --> No URI present. Default controller set.
INFO - 2016-10-18 15:25:46 --> Router Class Initialized
INFO - 2016-10-18 15:25:46 --> Output Class Initialized
INFO - 2016-10-18 15:25:46 --> Security Class Initialized
DEBUG - 2016-10-18 15:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:25:46 --> Input Class Initialized
INFO - 2016-10-18 15:25:46 --> Language Class Initialized
INFO - 2016-10-18 15:25:46 --> Loader Class Initialized
INFO - 2016-10-18 15:25:46 --> Helper loaded: url_helper
INFO - 2016-10-18 15:25:46 --> Helper loaded: form_helper
INFO - 2016-10-18 15:25:46 --> Database Driver Class Initialized
INFO - 2016-10-18 15:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:25:46 --> Controller Class Initialized
INFO - 2016-10-18 15:25:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:25:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:25:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:25:46 --> Final output sent to browser
DEBUG - 2016-10-18 15:25:46 --> Total execution time: 0.0057
INFO - 2016-10-18 15:25:55 --> Config Class Initialized
INFO - 2016-10-18 15:25:55 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:25:55 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:25:55 --> Utf8 Class Initialized
INFO - 2016-10-18 15:25:55 --> URI Class Initialized
INFO - 2016-10-18 15:25:55 --> Router Class Initialized
INFO - 2016-10-18 15:25:55 --> Output Class Initialized
INFO - 2016-10-18 15:25:55 --> Security Class Initialized
DEBUG - 2016-10-18 15:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:25:55 --> Input Class Initialized
INFO - 2016-10-18 15:25:55 --> Language Class Initialized
INFO - 2016-10-18 15:25:55 --> Loader Class Initialized
INFO - 2016-10-18 15:25:55 --> Helper loaded: url_helper
INFO - 2016-10-18 15:25:55 --> Helper loaded: form_helper
INFO - 2016-10-18 15:25:55 --> Database Driver Class Initialized
INFO - 2016-10-18 15:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:25:55 --> Controller Class Initialized
INFO - 2016-10-18 15:25:55 --> Model Class Initialized
INFO - 2016-10-18 15:25:55 --> Final output sent to browser
DEBUG - 2016-10-18 15:25:55 --> Total execution time: 0.0083
INFO - 2016-10-18 15:26:00 --> Config Class Initialized
INFO - 2016-10-18 15:26:00 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:26:00 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:26:00 --> Utf8 Class Initialized
INFO - 2016-10-18 15:26:00 --> URI Class Initialized
DEBUG - 2016-10-18 15:26:00 --> No URI present. Default controller set.
INFO - 2016-10-18 15:26:00 --> Router Class Initialized
INFO - 2016-10-18 15:26:00 --> Output Class Initialized
INFO - 2016-10-18 15:26:00 --> Security Class Initialized
DEBUG - 2016-10-18 15:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:26:00 --> Input Class Initialized
INFO - 2016-10-18 15:26:00 --> Language Class Initialized
INFO - 2016-10-18 15:26:00 --> Loader Class Initialized
INFO - 2016-10-18 15:26:00 --> Helper loaded: url_helper
INFO - 2016-10-18 15:26:00 --> Helper loaded: form_helper
INFO - 2016-10-18 15:26:00 --> Database Driver Class Initialized
INFO - 2016-10-18 15:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:26:00 --> Controller Class Initialized
INFO - 2016-10-18 15:26:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:26:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:26:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:26:00 --> Final output sent to browser
DEBUG - 2016-10-18 15:26:00 --> Total execution time: 0.0051
INFO - 2016-10-18 15:26:22 --> Config Class Initialized
INFO - 2016-10-18 15:26:22 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:26:22 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:26:22 --> Utf8 Class Initialized
INFO - 2016-10-18 15:26:22 --> URI Class Initialized
DEBUG - 2016-10-18 15:26:22 --> No URI present. Default controller set.
INFO - 2016-10-18 15:26:22 --> Router Class Initialized
INFO - 2016-10-18 15:26:22 --> Output Class Initialized
INFO - 2016-10-18 15:26:22 --> Security Class Initialized
DEBUG - 2016-10-18 15:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:26:22 --> Input Class Initialized
INFO - 2016-10-18 15:26:22 --> Language Class Initialized
INFO - 2016-10-18 15:26:22 --> Loader Class Initialized
INFO - 2016-10-18 15:26:22 --> Helper loaded: url_helper
INFO - 2016-10-18 15:26:22 --> Helper loaded: form_helper
INFO - 2016-10-18 15:26:22 --> Database Driver Class Initialized
INFO - 2016-10-18 15:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:26:22 --> Controller Class Initialized
INFO - 2016-10-18 15:26:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:26:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:26:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:26:22 --> Final output sent to browser
DEBUG - 2016-10-18 15:26:22 --> Total execution time: 0.0054
INFO - 2016-10-18 15:26:26 --> Config Class Initialized
INFO - 2016-10-18 15:26:26 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:26:26 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:26:26 --> Utf8 Class Initialized
INFO - 2016-10-18 15:26:26 --> URI Class Initialized
INFO - 2016-10-18 15:26:26 --> Router Class Initialized
INFO - 2016-10-18 15:26:26 --> Output Class Initialized
INFO - 2016-10-18 15:26:26 --> Security Class Initialized
DEBUG - 2016-10-18 15:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:26:26 --> Input Class Initialized
INFO - 2016-10-18 15:26:26 --> Language Class Initialized
INFO - 2016-10-18 15:26:26 --> Loader Class Initialized
INFO - 2016-10-18 15:26:26 --> Helper loaded: url_helper
INFO - 2016-10-18 15:26:26 --> Helper loaded: form_helper
INFO - 2016-10-18 15:26:26 --> Database Driver Class Initialized
INFO - 2016-10-18 15:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:26:26 --> Controller Class Initialized
INFO - 2016-10-18 15:26:26 --> Model Class Initialized
INFO - 2016-10-18 15:26:26 --> Final output sent to browser
DEBUG - 2016-10-18 15:26:26 --> Total execution time: 0.0066
INFO - 2016-10-18 15:26:31 --> Config Class Initialized
INFO - 2016-10-18 15:26:31 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:26:31 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:26:31 --> Utf8 Class Initialized
INFO - 2016-10-18 15:26:31 --> URI Class Initialized
DEBUG - 2016-10-18 15:26:31 --> No URI present. Default controller set.
INFO - 2016-10-18 15:26:31 --> Router Class Initialized
INFO - 2016-10-18 15:26:31 --> Output Class Initialized
INFO - 2016-10-18 15:26:31 --> Security Class Initialized
DEBUG - 2016-10-18 15:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:26:31 --> Input Class Initialized
INFO - 2016-10-18 15:26:31 --> Language Class Initialized
INFO - 2016-10-18 15:26:31 --> Loader Class Initialized
INFO - 2016-10-18 15:26:31 --> Helper loaded: url_helper
INFO - 2016-10-18 15:26:31 --> Helper loaded: form_helper
INFO - 2016-10-18 15:26:31 --> Database Driver Class Initialized
INFO - 2016-10-18 15:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:26:31 --> Controller Class Initialized
INFO - 2016-10-18 15:26:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:26:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:26:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:26:31 --> Final output sent to browser
DEBUG - 2016-10-18 15:26:31 --> Total execution time: 0.0061
INFO - 2016-10-18 15:29:07 --> Config Class Initialized
INFO - 2016-10-18 15:29:07 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:29:07 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:29:07 --> Utf8 Class Initialized
INFO - 2016-10-18 15:29:07 --> URI Class Initialized
DEBUG - 2016-10-18 15:29:07 --> No URI present. Default controller set.
INFO - 2016-10-18 15:29:07 --> Router Class Initialized
INFO - 2016-10-18 15:29:07 --> Output Class Initialized
INFO - 2016-10-18 15:29:07 --> Security Class Initialized
DEBUG - 2016-10-18 15:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:29:07 --> Input Class Initialized
INFO - 2016-10-18 15:29:07 --> Language Class Initialized
INFO - 2016-10-18 15:29:07 --> Loader Class Initialized
INFO - 2016-10-18 15:29:07 --> Helper loaded: url_helper
INFO - 2016-10-18 15:29:07 --> Helper loaded: form_helper
INFO - 2016-10-18 15:29:07 --> Database Driver Class Initialized
INFO - 2016-10-18 15:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:29:07 --> Controller Class Initialized
INFO - 2016-10-18 15:29:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:29:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:29:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:29:07 --> Final output sent to browser
DEBUG - 2016-10-18 15:29:07 --> Total execution time: 0.0059
INFO - 2016-10-18 15:29:18 --> Config Class Initialized
INFO - 2016-10-18 15:29:18 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:29:18 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:29:18 --> Utf8 Class Initialized
INFO - 2016-10-18 15:29:18 --> URI Class Initialized
INFO - 2016-10-18 15:29:18 --> Router Class Initialized
INFO - 2016-10-18 15:29:18 --> Output Class Initialized
INFO - 2016-10-18 15:29:18 --> Security Class Initialized
DEBUG - 2016-10-18 15:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:29:18 --> Input Class Initialized
INFO - 2016-10-18 15:29:18 --> Language Class Initialized
INFO - 2016-10-18 15:29:18 --> Loader Class Initialized
INFO - 2016-10-18 15:29:18 --> Helper loaded: url_helper
INFO - 2016-10-18 15:29:18 --> Helper loaded: form_helper
INFO - 2016-10-18 15:29:18 --> Database Driver Class Initialized
INFO - 2016-10-18 15:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:29:18 --> Controller Class Initialized
INFO - 2016-10-18 15:29:18 --> Model Class Initialized
INFO - 2016-10-18 15:29:18 --> Final output sent to browser
DEBUG - 2016-10-18 15:29:18 --> Total execution time: 0.0090
INFO - 2016-10-18 15:29:18 --> Config Class Initialized
INFO - 2016-10-18 15:29:18 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:29:18 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:29:18 --> Utf8 Class Initialized
INFO - 2016-10-18 15:29:18 --> URI Class Initialized
DEBUG - 2016-10-18 15:29:18 --> No URI present. Default controller set.
INFO - 2016-10-18 15:29:18 --> Router Class Initialized
INFO - 2016-10-18 15:29:18 --> Output Class Initialized
INFO - 2016-10-18 15:29:18 --> Security Class Initialized
DEBUG - 2016-10-18 15:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:29:18 --> Input Class Initialized
INFO - 2016-10-18 15:29:18 --> Language Class Initialized
INFO - 2016-10-18 15:29:18 --> Loader Class Initialized
INFO - 2016-10-18 15:29:18 --> Helper loaded: url_helper
INFO - 2016-10-18 15:29:18 --> Helper loaded: form_helper
INFO - 2016-10-18 15:29:18 --> Database Driver Class Initialized
INFO - 2016-10-18 15:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:29:18 --> Controller Class Initialized
INFO - 2016-10-18 15:29:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:29:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:29:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:29:18 --> Final output sent to browser
DEBUG - 2016-10-18 15:29:18 --> Total execution time: 0.0043
INFO - 2016-10-18 15:29:22 --> Config Class Initialized
INFO - 2016-10-18 15:29:22 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:29:22 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:29:22 --> Utf8 Class Initialized
INFO - 2016-10-18 15:29:22 --> URI Class Initialized
INFO - 2016-10-18 15:29:22 --> Router Class Initialized
INFO - 2016-10-18 15:29:22 --> Output Class Initialized
INFO - 2016-10-18 15:29:22 --> Security Class Initialized
DEBUG - 2016-10-18 15:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:29:22 --> Input Class Initialized
INFO - 2016-10-18 15:29:22 --> Language Class Initialized
INFO - 2016-10-18 15:29:22 --> Loader Class Initialized
INFO - 2016-10-18 15:29:22 --> Helper loaded: url_helper
INFO - 2016-10-18 15:29:22 --> Helper loaded: form_helper
INFO - 2016-10-18 15:29:22 --> Database Driver Class Initialized
INFO - 2016-10-18 15:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:29:22 --> Controller Class Initialized
INFO - 2016-10-18 15:29:22 --> Model Class Initialized
INFO - 2016-10-18 15:29:22 --> Final output sent to browser
DEBUG - 2016-10-18 15:29:22 --> Total execution time: 0.0060
INFO - 2016-10-18 15:29:22 --> Config Class Initialized
INFO - 2016-10-18 15:29:22 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:29:22 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:29:22 --> Utf8 Class Initialized
INFO - 2016-10-18 15:29:22 --> URI Class Initialized
DEBUG - 2016-10-18 15:29:22 --> No URI present. Default controller set.
INFO - 2016-10-18 15:29:22 --> Router Class Initialized
INFO - 2016-10-18 15:29:22 --> Output Class Initialized
INFO - 2016-10-18 15:29:22 --> Security Class Initialized
DEBUG - 2016-10-18 15:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:29:22 --> Input Class Initialized
INFO - 2016-10-18 15:29:22 --> Language Class Initialized
INFO - 2016-10-18 15:29:22 --> Loader Class Initialized
INFO - 2016-10-18 15:29:22 --> Helper loaded: url_helper
INFO - 2016-10-18 15:29:22 --> Helper loaded: form_helper
INFO - 2016-10-18 15:29:22 --> Database Driver Class Initialized
INFO - 2016-10-18 15:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:29:22 --> Controller Class Initialized
INFO - 2016-10-18 15:29:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:29:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:29:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:29:22 --> Final output sent to browser
DEBUG - 2016-10-18 15:29:22 --> Total execution time: 0.0046
INFO - 2016-10-18 15:31:05 --> Config Class Initialized
INFO - 2016-10-18 15:31:05 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:31:05 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:31:05 --> Utf8 Class Initialized
INFO - 2016-10-18 15:31:05 --> URI Class Initialized
DEBUG - 2016-10-18 15:31:05 --> No URI present. Default controller set.
INFO - 2016-10-18 15:31:05 --> Router Class Initialized
INFO - 2016-10-18 15:31:05 --> Output Class Initialized
INFO - 2016-10-18 15:31:05 --> Security Class Initialized
DEBUG - 2016-10-18 15:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:31:05 --> Input Class Initialized
INFO - 2016-10-18 15:31:05 --> Language Class Initialized
INFO - 2016-10-18 15:31:05 --> Loader Class Initialized
INFO - 2016-10-18 15:31:05 --> Helper loaded: url_helper
INFO - 2016-10-18 15:31:05 --> Helper loaded: form_helper
INFO - 2016-10-18 15:31:05 --> Database Driver Class Initialized
INFO - 2016-10-18 15:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:31:05 --> Controller Class Initialized
INFO - 2016-10-18 15:31:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:31:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:31:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:31:05 --> Final output sent to browser
DEBUG - 2016-10-18 15:31:05 --> Total execution time: 0.0090
INFO - 2016-10-18 15:31:10 --> Config Class Initialized
INFO - 2016-10-18 15:31:10 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:31:10 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:31:10 --> Utf8 Class Initialized
INFO - 2016-10-18 15:31:10 --> URI Class Initialized
DEBUG - 2016-10-18 15:31:10 --> No URI present. Default controller set.
INFO - 2016-10-18 15:31:10 --> Router Class Initialized
INFO - 2016-10-18 15:31:10 --> Output Class Initialized
INFO - 2016-10-18 15:31:10 --> Security Class Initialized
DEBUG - 2016-10-18 15:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:31:10 --> Input Class Initialized
INFO - 2016-10-18 15:31:10 --> Language Class Initialized
INFO - 2016-10-18 15:31:10 --> Loader Class Initialized
INFO - 2016-10-18 15:31:10 --> Helper loaded: url_helper
INFO - 2016-10-18 15:31:10 --> Helper loaded: form_helper
INFO - 2016-10-18 15:31:10 --> Database Driver Class Initialized
INFO - 2016-10-18 15:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:31:10 --> Controller Class Initialized
INFO - 2016-10-18 15:31:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:31:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:31:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:31:10 --> Final output sent to browser
DEBUG - 2016-10-18 15:31:10 --> Total execution time: 0.0053
INFO - 2016-10-18 15:31:22 --> Config Class Initialized
INFO - 2016-10-18 15:31:22 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:31:22 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:31:22 --> Utf8 Class Initialized
INFO - 2016-10-18 15:31:22 --> URI Class Initialized
DEBUG - 2016-10-18 15:31:22 --> No URI present. Default controller set.
INFO - 2016-10-18 15:31:22 --> Router Class Initialized
INFO - 2016-10-18 15:31:22 --> Output Class Initialized
INFO - 2016-10-18 15:31:22 --> Security Class Initialized
DEBUG - 2016-10-18 15:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:31:22 --> Input Class Initialized
INFO - 2016-10-18 15:31:22 --> Language Class Initialized
INFO - 2016-10-18 15:31:22 --> Loader Class Initialized
INFO - 2016-10-18 15:31:22 --> Helper loaded: url_helper
INFO - 2016-10-18 15:31:22 --> Helper loaded: form_helper
INFO - 2016-10-18 15:31:22 --> Database Driver Class Initialized
INFO - 2016-10-18 15:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:31:22 --> Controller Class Initialized
INFO - 2016-10-18 15:31:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:31:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:31:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:31:22 --> Final output sent to browser
DEBUG - 2016-10-18 15:31:22 --> Total execution time: 0.0074
INFO - 2016-10-18 15:31:26 --> Config Class Initialized
INFO - 2016-10-18 15:31:26 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:31:26 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:31:26 --> Utf8 Class Initialized
INFO - 2016-10-18 15:31:26 --> URI Class Initialized
DEBUG - 2016-10-18 15:31:26 --> No URI present. Default controller set.
INFO - 2016-10-18 15:31:26 --> Router Class Initialized
INFO - 2016-10-18 15:31:26 --> Output Class Initialized
INFO - 2016-10-18 15:31:26 --> Security Class Initialized
DEBUG - 2016-10-18 15:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:31:26 --> Input Class Initialized
INFO - 2016-10-18 15:31:26 --> Language Class Initialized
INFO - 2016-10-18 15:31:26 --> Loader Class Initialized
INFO - 2016-10-18 15:31:26 --> Helper loaded: url_helper
INFO - 2016-10-18 15:31:26 --> Helper loaded: form_helper
INFO - 2016-10-18 15:31:26 --> Database Driver Class Initialized
INFO - 2016-10-18 15:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:31:26 --> Controller Class Initialized
INFO - 2016-10-18 15:31:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:31:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:31:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:31:26 --> Final output sent to browser
DEBUG - 2016-10-18 15:31:26 --> Total execution time: 0.0051
INFO - 2016-10-18 15:31:48 --> Config Class Initialized
INFO - 2016-10-18 15:31:48 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:31:48 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:31:48 --> Utf8 Class Initialized
INFO - 2016-10-18 15:31:48 --> URI Class Initialized
DEBUG - 2016-10-18 15:31:48 --> No URI present. Default controller set.
INFO - 2016-10-18 15:31:48 --> Router Class Initialized
INFO - 2016-10-18 15:31:48 --> Output Class Initialized
INFO - 2016-10-18 15:31:48 --> Security Class Initialized
DEBUG - 2016-10-18 15:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:31:48 --> Input Class Initialized
INFO - 2016-10-18 15:31:48 --> Language Class Initialized
INFO - 2016-10-18 15:31:48 --> Loader Class Initialized
INFO - 2016-10-18 15:31:48 --> Helper loaded: url_helper
INFO - 2016-10-18 15:31:48 --> Helper loaded: form_helper
INFO - 2016-10-18 15:31:48 --> Database Driver Class Initialized
INFO - 2016-10-18 15:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:31:48 --> Controller Class Initialized
INFO - 2016-10-18 15:31:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:31:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:31:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:31:48 --> Final output sent to browser
DEBUG - 2016-10-18 15:31:48 --> Total execution time: 0.0059
INFO - 2016-10-18 15:31:50 --> Config Class Initialized
INFO - 2016-10-18 15:31:50 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:31:50 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:31:50 --> Utf8 Class Initialized
INFO - 2016-10-18 15:31:50 --> URI Class Initialized
DEBUG - 2016-10-18 15:31:50 --> No URI present. Default controller set.
INFO - 2016-10-18 15:31:50 --> Router Class Initialized
INFO - 2016-10-18 15:31:50 --> Output Class Initialized
INFO - 2016-10-18 15:31:50 --> Security Class Initialized
DEBUG - 2016-10-18 15:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:31:50 --> Input Class Initialized
INFO - 2016-10-18 15:31:50 --> Language Class Initialized
INFO - 2016-10-18 15:31:50 --> Loader Class Initialized
INFO - 2016-10-18 15:31:50 --> Helper loaded: url_helper
INFO - 2016-10-18 15:31:50 --> Helper loaded: form_helper
INFO - 2016-10-18 15:31:50 --> Database Driver Class Initialized
INFO - 2016-10-18 15:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:31:50 --> Controller Class Initialized
INFO - 2016-10-18 15:31:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:31:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:31:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:31:50 --> Final output sent to browser
DEBUG - 2016-10-18 15:31:50 --> Total execution time: 0.0048
INFO - 2016-10-18 15:32:13 --> Config Class Initialized
INFO - 2016-10-18 15:32:13 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:32:13 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:32:13 --> Utf8 Class Initialized
INFO - 2016-10-18 15:32:13 --> URI Class Initialized
DEBUG - 2016-10-18 15:32:13 --> No URI present. Default controller set.
INFO - 2016-10-18 15:32:13 --> Router Class Initialized
INFO - 2016-10-18 15:32:13 --> Output Class Initialized
INFO - 2016-10-18 15:32:13 --> Security Class Initialized
DEBUG - 2016-10-18 15:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:32:13 --> Input Class Initialized
INFO - 2016-10-18 15:32:13 --> Language Class Initialized
INFO - 2016-10-18 15:32:13 --> Loader Class Initialized
INFO - 2016-10-18 15:32:13 --> Helper loaded: url_helper
INFO - 2016-10-18 15:32:13 --> Helper loaded: form_helper
INFO - 2016-10-18 15:32:13 --> Database Driver Class Initialized
INFO - 2016-10-18 15:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:32:13 --> Controller Class Initialized
INFO - 2016-10-18 15:32:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:32:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:32:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:32:13 --> Final output sent to browser
DEBUG - 2016-10-18 15:32:13 --> Total execution time: 0.0055
INFO - 2016-10-18 15:32:17 --> Config Class Initialized
INFO - 2016-10-18 15:32:17 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:32:17 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:32:17 --> Utf8 Class Initialized
INFO - 2016-10-18 15:32:17 --> URI Class Initialized
DEBUG - 2016-10-18 15:32:17 --> No URI present. Default controller set.
INFO - 2016-10-18 15:32:17 --> Router Class Initialized
INFO - 2016-10-18 15:32:17 --> Output Class Initialized
INFO - 2016-10-18 15:32:17 --> Security Class Initialized
DEBUG - 2016-10-18 15:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:32:17 --> Input Class Initialized
INFO - 2016-10-18 15:32:17 --> Language Class Initialized
INFO - 2016-10-18 15:32:17 --> Loader Class Initialized
INFO - 2016-10-18 15:32:17 --> Helper loaded: url_helper
INFO - 2016-10-18 15:32:17 --> Helper loaded: form_helper
INFO - 2016-10-18 15:32:17 --> Database Driver Class Initialized
INFO - 2016-10-18 15:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:32:17 --> Controller Class Initialized
INFO - 2016-10-18 15:32:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:32:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:32:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:32:17 --> Final output sent to browser
DEBUG - 2016-10-18 15:32:17 --> Total execution time: 0.0046
INFO - 2016-10-18 15:32:25 --> Config Class Initialized
INFO - 2016-10-18 15:32:25 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:32:25 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:32:25 --> Utf8 Class Initialized
INFO - 2016-10-18 15:32:25 --> URI Class Initialized
INFO - 2016-10-18 15:32:25 --> Router Class Initialized
INFO - 2016-10-18 15:32:25 --> Output Class Initialized
INFO - 2016-10-18 15:32:25 --> Security Class Initialized
DEBUG - 2016-10-18 15:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:32:25 --> Input Class Initialized
INFO - 2016-10-18 15:32:25 --> Language Class Initialized
INFO - 2016-10-18 15:32:25 --> Loader Class Initialized
INFO - 2016-10-18 15:32:25 --> Helper loaded: url_helper
INFO - 2016-10-18 15:32:25 --> Helper loaded: form_helper
INFO - 2016-10-18 15:32:25 --> Database Driver Class Initialized
INFO - 2016-10-18 15:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:32:25 --> Controller Class Initialized
INFO - 2016-10-18 15:32:25 --> Model Class Initialized
INFO - 2016-10-18 15:32:25 --> Final output sent to browser
DEBUG - 2016-10-18 15:32:25 --> Total execution time: 0.0066
INFO - 2016-10-18 15:32:36 --> Config Class Initialized
INFO - 2016-10-18 15:32:36 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:32:36 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:32:36 --> Utf8 Class Initialized
INFO - 2016-10-18 15:32:36 --> URI Class Initialized
INFO - 2016-10-18 15:32:36 --> Router Class Initialized
INFO - 2016-10-18 15:32:36 --> Output Class Initialized
INFO - 2016-10-18 15:32:36 --> Security Class Initialized
DEBUG - 2016-10-18 15:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:32:36 --> Input Class Initialized
INFO - 2016-10-18 15:32:36 --> Language Class Initialized
INFO - 2016-10-18 15:32:36 --> Loader Class Initialized
INFO - 2016-10-18 15:32:36 --> Helper loaded: url_helper
INFO - 2016-10-18 15:32:36 --> Helper loaded: form_helper
INFO - 2016-10-18 15:32:36 --> Database Driver Class Initialized
INFO - 2016-10-18 15:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:32:36 --> Controller Class Initialized
INFO - 2016-10-18 15:32:36 --> Model Class Initialized
INFO - 2016-10-18 15:32:36 --> Final output sent to browser
DEBUG - 2016-10-18 15:32:36 --> Total execution time: 0.0080
INFO - 2016-10-18 15:32:41 --> Config Class Initialized
INFO - 2016-10-18 15:32:41 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:32:41 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:32:41 --> Utf8 Class Initialized
INFO - 2016-10-18 15:32:41 --> URI Class Initialized
INFO - 2016-10-18 15:32:41 --> Router Class Initialized
INFO - 2016-10-18 15:32:41 --> Output Class Initialized
INFO - 2016-10-18 15:32:41 --> Security Class Initialized
DEBUG - 2016-10-18 15:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:32:41 --> Input Class Initialized
INFO - 2016-10-18 15:32:41 --> Language Class Initialized
INFO - 2016-10-18 15:32:41 --> Loader Class Initialized
INFO - 2016-10-18 15:32:41 --> Helper loaded: url_helper
INFO - 2016-10-18 15:32:41 --> Helper loaded: form_helper
INFO - 2016-10-18 15:32:41 --> Database Driver Class Initialized
INFO - 2016-10-18 15:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:32:41 --> Controller Class Initialized
INFO - 2016-10-18 15:32:41 --> Model Class Initialized
INFO - 2016-10-18 15:32:41 --> Final output sent to browser
DEBUG - 2016-10-18 15:32:41 --> Total execution time: 0.0090
INFO - 2016-10-18 15:32:55 --> Config Class Initialized
INFO - 2016-10-18 15:32:55 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:32:55 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:32:55 --> Utf8 Class Initialized
INFO - 2016-10-18 15:32:55 --> URI Class Initialized
DEBUG - 2016-10-18 15:32:55 --> No URI present. Default controller set.
INFO - 2016-10-18 15:32:55 --> Router Class Initialized
INFO - 2016-10-18 15:32:55 --> Output Class Initialized
INFO - 2016-10-18 15:32:55 --> Security Class Initialized
DEBUG - 2016-10-18 15:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:32:55 --> Input Class Initialized
INFO - 2016-10-18 15:32:55 --> Language Class Initialized
INFO - 2016-10-18 15:32:55 --> Loader Class Initialized
INFO - 2016-10-18 15:32:55 --> Helper loaded: url_helper
INFO - 2016-10-18 15:32:55 --> Helper loaded: form_helper
INFO - 2016-10-18 15:32:55 --> Database Driver Class Initialized
INFO - 2016-10-18 15:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:32:55 --> Controller Class Initialized
INFO - 2016-10-18 15:32:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:32:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:32:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:32:55 --> Final output sent to browser
DEBUG - 2016-10-18 15:32:55 --> Total execution time: 0.0074
INFO - 2016-10-18 15:32:58 --> Config Class Initialized
INFO - 2016-10-18 15:32:58 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:32:58 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:32:58 --> Utf8 Class Initialized
INFO - 2016-10-18 15:32:58 --> URI Class Initialized
DEBUG - 2016-10-18 15:32:58 --> No URI present. Default controller set.
INFO - 2016-10-18 15:32:58 --> Router Class Initialized
INFO - 2016-10-18 15:32:58 --> Output Class Initialized
INFO - 2016-10-18 15:32:58 --> Security Class Initialized
DEBUG - 2016-10-18 15:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:32:58 --> Input Class Initialized
INFO - 2016-10-18 15:32:58 --> Language Class Initialized
INFO - 2016-10-18 15:32:58 --> Loader Class Initialized
INFO - 2016-10-18 15:32:58 --> Helper loaded: url_helper
INFO - 2016-10-18 15:32:58 --> Helper loaded: form_helper
INFO - 2016-10-18 15:32:58 --> Database Driver Class Initialized
INFO - 2016-10-18 15:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:32:58 --> Controller Class Initialized
INFO - 2016-10-18 15:32:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:32:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:32:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:32:58 --> Final output sent to browser
DEBUG - 2016-10-18 15:32:58 --> Total execution time: 0.0049
INFO - 2016-10-18 15:33:01 --> Config Class Initialized
INFO - 2016-10-18 15:33:01 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:33:01 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:33:01 --> Utf8 Class Initialized
INFO - 2016-10-18 15:33:01 --> URI Class Initialized
DEBUG - 2016-10-18 15:33:01 --> No URI present. Default controller set.
INFO - 2016-10-18 15:33:01 --> Router Class Initialized
INFO - 2016-10-18 15:33:01 --> Output Class Initialized
INFO - 2016-10-18 15:33:01 --> Security Class Initialized
DEBUG - 2016-10-18 15:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:33:01 --> Input Class Initialized
INFO - 2016-10-18 15:33:01 --> Language Class Initialized
INFO - 2016-10-18 15:33:01 --> Loader Class Initialized
INFO - 2016-10-18 15:33:01 --> Helper loaded: url_helper
INFO - 2016-10-18 15:33:01 --> Helper loaded: form_helper
INFO - 2016-10-18 15:33:01 --> Database Driver Class Initialized
INFO - 2016-10-18 15:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:33:01 --> Controller Class Initialized
INFO - 2016-10-18 15:33:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:33:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:33:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:33:01 --> Final output sent to browser
DEBUG - 2016-10-18 15:33:01 --> Total execution time: 0.0045
INFO - 2016-10-18 15:33:07 --> Config Class Initialized
INFO - 2016-10-18 15:33:07 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:33:07 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:33:07 --> Utf8 Class Initialized
INFO - 2016-10-18 15:33:07 --> URI Class Initialized
DEBUG - 2016-10-18 15:33:07 --> No URI present. Default controller set.
INFO - 2016-10-18 15:33:07 --> Router Class Initialized
INFO - 2016-10-18 15:33:07 --> Output Class Initialized
INFO - 2016-10-18 15:33:07 --> Security Class Initialized
DEBUG - 2016-10-18 15:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:33:07 --> Input Class Initialized
INFO - 2016-10-18 15:33:07 --> Language Class Initialized
INFO - 2016-10-18 15:33:07 --> Loader Class Initialized
INFO - 2016-10-18 15:33:07 --> Helper loaded: url_helper
INFO - 2016-10-18 15:33:07 --> Helper loaded: form_helper
INFO - 2016-10-18 15:33:07 --> Database Driver Class Initialized
INFO - 2016-10-18 15:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:33:07 --> Controller Class Initialized
INFO - 2016-10-18 15:33:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:33:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:33:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:33:07 --> Final output sent to browser
DEBUG - 2016-10-18 15:33:07 --> Total execution time: 0.0055
INFO - 2016-10-18 15:33:10 --> Config Class Initialized
INFO - 2016-10-18 15:33:10 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:33:10 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:33:10 --> Utf8 Class Initialized
INFO - 2016-10-18 15:33:10 --> URI Class Initialized
DEBUG - 2016-10-18 15:33:10 --> No URI present. Default controller set.
INFO - 2016-10-18 15:33:10 --> Router Class Initialized
INFO - 2016-10-18 15:33:10 --> Output Class Initialized
INFO - 2016-10-18 15:33:10 --> Security Class Initialized
DEBUG - 2016-10-18 15:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:33:10 --> Input Class Initialized
INFO - 2016-10-18 15:33:10 --> Language Class Initialized
INFO - 2016-10-18 15:33:10 --> Loader Class Initialized
INFO - 2016-10-18 15:33:10 --> Helper loaded: url_helper
INFO - 2016-10-18 15:33:10 --> Helper loaded: form_helper
INFO - 2016-10-18 15:33:10 --> Database Driver Class Initialized
INFO - 2016-10-18 15:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:33:10 --> Controller Class Initialized
INFO - 2016-10-18 15:33:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:33:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:33:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:33:10 --> Final output sent to browser
DEBUG - 2016-10-18 15:33:10 --> Total execution time: 0.0048
INFO - 2016-10-18 15:33:16 --> Config Class Initialized
INFO - 2016-10-18 15:33:16 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:33:16 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:33:16 --> Utf8 Class Initialized
INFO - 2016-10-18 15:33:16 --> URI Class Initialized
INFO - 2016-10-18 15:33:16 --> Router Class Initialized
INFO - 2016-10-18 15:33:16 --> Output Class Initialized
INFO - 2016-10-18 15:33:16 --> Security Class Initialized
DEBUG - 2016-10-18 15:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:33:16 --> Input Class Initialized
INFO - 2016-10-18 15:33:16 --> Language Class Initialized
INFO - 2016-10-18 15:33:16 --> Loader Class Initialized
INFO - 2016-10-18 15:33:16 --> Helper loaded: url_helper
INFO - 2016-10-18 15:33:16 --> Helper loaded: form_helper
INFO - 2016-10-18 15:33:16 --> Database Driver Class Initialized
INFO - 2016-10-18 15:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:33:16 --> Controller Class Initialized
INFO - 2016-10-18 15:33:16 --> Model Class Initialized
INFO - 2016-10-18 15:33:16 --> Final output sent to browser
DEBUG - 2016-10-18 15:33:16 --> Total execution time: 0.0068
INFO - 2016-10-18 15:33:16 --> Config Class Initialized
INFO - 2016-10-18 15:33:16 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:33:16 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:33:16 --> Utf8 Class Initialized
INFO - 2016-10-18 15:33:16 --> URI Class Initialized
DEBUG - 2016-10-18 15:33:16 --> No URI present. Default controller set.
INFO - 2016-10-18 15:33:16 --> Router Class Initialized
INFO - 2016-10-18 15:33:16 --> Output Class Initialized
INFO - 2016-10-18 15:33:16 --> Security Class Initialized
DEBUG - 2016-10-18 15:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:33:16 --> Input Class Initialized
INFO - 2016-10-18 15:33:16 --> Language Class Initialized
INFO - 2016-10-18 15:33:16 --> Loader Class Initialized
INFO - 2016-10-18 15:33:16 --> Helper loaded: url_helper
INFO - 2016-10-18 15:33:16 --> Helper loaded: form_helper
INFO - 2016-10-18 15:33:16 --> Database Driver Class Initialized
INFO - 2016-10-18 15:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:33:16 --> Controller Class Initialized
INFO - 2016-10-18 15:33:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:33:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:33:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:33:16 --> Final output sent to browser
DEBUG - 2016-10-18 15:33:16 --> Total execution time: 0.0043
INFO - 2016-10-18 15:33:40 --> Config Class Initialized
INFO - 2016-10-18 15:33:40 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:33:40 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:33:40 --> Utf8 Class Initialized
INFO - 2016-10-18 15:33:40 --> URI Class Initialized
DEBUG - 2016-10-18 15:33:40 --> No URI present. Default controller set.
INFO - 2016-10-18 15:33:40 --> Router Class Initialized
INFO - 2016-10-18 15:33:40 --> Output Class Initialized
INFO - 2016-10-18 15:33:40 --> Security Class Initialized
DEBUG - 2016-10-18 15:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:33:40 --> Input Class Initialized
INFO - 2016-10-18 15:33:40 --> Language Class Initialized
INFO - 2016-10-18 15:33:40 --> Loader Class Initialized
INFO - 2016-10-18 15:33:40 --> Helper loaded: url_helper
INFO - 2016-10-18 15:33:40 --> Helper loaded: form_helper
INFO - 2016-10-18 15:33:40 --> Database Driver Class Initialized
INFO - 2016-10-18 15:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:33:40 --> Controller Class Initialized
INFO - 2016-10-18 15:33:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:33:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:33:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:33:40 --> Final output sent to browser
DEBUG - 2016-10-18 15:33:40 --> Total execution time: 0.0077
INFO - 2016-10-18 15:33:51 --> Config Class Initialized
INFO - 2016-10-18 15:33:51 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:33:51 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:33:51 --> Utf8 Class Initialized
INFO - 2016-10-18 15:33:51 --> URI Class Initialized
DEBUG - 2016-10-18 15:33:51 --> No URI present. Default controller set.
INFO - 2016-10-18 15:33:51 --> Router Class Initialized
INFO - 2016-10-18 15:33:51 --> Output Class Initialized
INFO - 2016-10-18 15:33:51 --> Security Class Initialized
DEBUG - 2016-10-18 15:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:33:51 --> Input Class Initialized
INFO - 2016-10-18 15:33:51 --> Language Class Initialized
INFO - 2016-10-18 15:33:51 --> Loader Class Initialized
INFO - 2016-10-18 15:33:51 --> Helper loaded: url_helper
INFO - 2016-10-18 15:33:51 --> Helper loaded: form_helper
INFO - 2016-10-18 15:33:51 --> Database Driver Class Initialized
INFO - 2016-10-18 15:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:33:51 --> Controller Class Initialized
INFO - 2016-10-18 15:33:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:33:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:33:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:33:51 --> Final output sent to browser
DEBUG - 2016-10-18 15:33:51 --> Total execution time: 0.0050
INFO - 2016-10-18 15:34:03 --> Config Class Initialized
INFO - 2016-10-18 15:34:03 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:34:03 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:34:03 --> Utf8 Class Initialized
INFO - 2016-10-18 15:34:03 --> URI Class Initialized
DEBUG - 2016-10-18 15:34:03 --> No URI present. Default controller set.
INFO - 2016-10-18 15:34:03 --> Router Class Initialized
INFO - 2016-10-18 15:34:03 --> Output Class Initialized
INFO - 2016-10-18 15:34:03 --> Security Class Initialized
DEBUG - 2016-10-18 15:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:34:03 --> Input Class Initialized
INFO - 2016-10-18 15:34:03 --> Language Class Initialized
INFO - 2016-10-18 15:34:03 --> Loader Class Initialized
INFO - 2016-10-18 15:34:03 --> Helper loaded: url_helper
INFO - 2016-10-18 15:34:03 --> Helper loaded: form_helper
INFO - 2016-10-18 15:34:03 --> Database Driver Class Initialized
INFO - 2016-10-18 15:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:34:03 --> Controller Class Initialized
INFO - 2016-10-18 15:34:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:34:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:34:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:34:03 --> Final output sent to browser
DEBUG - 2016-10-18 15:34:03 --> Total execution time: 0.0051
INFO - 2016-10-18 15:34:04 --> Config Class Initialized
INFO - 2016-10-18 15:34:04 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:34:04 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:34:04 --> Utf8 Class Initialized
INFO - 2016-10-18 15:34:04 --> URI Class Initialized
DEBUG - 2016-10-18 15:34:04 --> No URI present. Default controller set.
INFO - 2016-10-18 15:34:04 --> Router Class Initialized
INFO - 2016-10-18 15:34:04 --> Output Class Initialized
INFO - 2016-10-18 15:34:04 --> Security Class Initialized
DEBUG - 2016-10-18 15:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:34:04 --> Input Class Initialized
INFO - 2016-10-18 15:34:04 --> Language Class Initialized
INFO - 2016-10-18 15:34:04 --> Loader Class Initialized
INFO - 2016-10-18 15:34:04 --> Helper loaded: url_helper
INFO - 2016-10-18 15:34:04 --> Helper loaded: form_helper
INFO - 2016-10-18 15:34:04 --> Database Driver Class Initialized
INFO - 2016-10-18 15:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:34:04 --> Controller Class Initialized
INFO - 2016-10-18 15:34:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:34:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:34:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:34:04 --> Final output sent to browser
DEBUG - 2016-10-18 15:34:04 --> Total execution time: 0.0049
INFO - 2016-10-18 15:34:26 --> Config Class Initialized
INFO - 2016-10-18 15:34:26 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:34:26 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:34:26 --> Utf8 Class Initialized
INFO - 2016-10-18 15:34:26 --> URI Class Initialized
DEBUG - 2016-10-18 15:34:26 --> No URI present. Default controller set.
INFO - 2016-10-18 15:34:26 --> Router Class Initialized
INFO - 2016-10-18 15:34:26 --> Output Class Initialized
INFO - 2016-10-18 15:34:26 --> Security Class Initialized
DEBUG - 2016-10-18 15:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:34:26 --> Input Class Initialized
INFO - 2016-10-18 15:34:26 --> Language Class Initialized
INFO - 2016-10-18 15:34:26 --> Loader Class Initialized
INFO - 2016-10-18 15:34:26 --> Helper loaded: url_helper
INFO - 2016-10-18 15:34:26 --> Helper loaded: form_helper
INFO - 2016-10-18 15:34:26 --> Database Driver Class Initialized
INFO - 2016-10-18 15:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:34:26 --> Controller Class Initialized
INFO - 2016-10-18 15:34:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:34:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:34:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:34:26 --> Final output sent to browser
DEBUG - 2016-10-18 15:34:26 --> Total execution time: 0.0057
INFO - 2016-10-18 15:34:30 --> Config Class Initialized
INFO - 2016-10-18 15:34:30 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:34:30 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:34:30 --> Utf8 Class Initialized
INFO - 2016-10-18 15:34:30 --> URI Class Initialized
DEBUG - 2016-10-18 15:34:30 --> No URI present. Default controller set.
INFO - 2016-10-18 15:34:30 --> Router Class Initialized
INFO - 2016-10-18 15:34:30 --> Output Class Initialized
INFO - 2016-10-18 15:34:30 --> Security Class Initialized
DEBUG - 2016-10-18 15:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:34:30 --> Input Class Initialized
INFO - 2016-10-18 15:34:30 --> Language Class Initialized
INFO - 2016-10-18 15:34:30 --> Loader Class Initialized
INFO - 2016-10-18 15:34:30 --> Helper loaded: url_helper
INFO - 2016-10-18 15:34:30 --> Helper loaded: form_helper
INFO - 2016-10-18 15:34:30 --> Database Driver Class Initialized
INFO - 2016-10-18 15:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:34:30 --> Controller Class Initialized
INFO - 2016-10-18 15:34:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:34:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:34:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:34:30 --> Final output sent to browser
DEBUG - 2016-10-18 15:34:30 --> Total execution time: 0.0049
INFO - 2016-10-18 15:34:35 --> Config Class Initialized
INFO - 2016-10-18 15:34:35 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:34:35 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:34:35 --> Utf8 Class Initialized
INFO - 2016-10-18 15:34:35 --> URI Class Initialized
INFO - 2016-10-18 15:34:35 --> Router Class Initialized
INFO - 2016-10-18 15:34:35 --> Output Class Initialized
INFO - 2016-10-18 15:34:35 --> Security Class Initialized
DEBUG - 2016-10-18 15:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:34:35 --> Input Class Initialized
INFO - 2016-10-18 15:34:35 --> Language Class Initialized
INFO - 2016-10-18 15:34:35 --> Loader Class Initialized
INFO - 2016-10-18 15:34:35 --> Helper loaded: url_helper
INFO - 2016-10-18 15:34:35 --> Helper loaded: form_helper
INFO - 2016-10-18 15:34:35 --> Database Driver Class Initialized
INFO - 2016-10-18 15:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:34:35 --> Controller Class Initialized
INFO - 2016-10-18 15:34:35 --> Model Class Initialized
INFO - 2016-10-18 15:34:35 --> Final output sent to browser
DEBUG - 2016-10-18 15:34:35 --> Total execution time: 0.0063
INFO - 2016-10-18 15:34:43 --> Config Class Initialized
INFO - 2016-10-18 15:34:43 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:34:43 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:34:43 --> Utf8 Class Initialized
INFO - 2016-10-18 15:34:43 --> URI Class Initialized
DEBUG - 2016-10-18 15:34:43 --> No URI present. Default controller set.
INFO - 2016-10-18 15:34:43 --> Router Class Initialized
INFO - 2016-10-18 15:34:43 --> Output Class Initialized
INFO - 2016-10-18 15:34:43 --> Security Class Initialized
DEBUG - 2016-10-18 15:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:34:43 --> Input Class Initialized
INFO - 2016-10-18 15:34:43 --> Language Class Initialized
INFO - 2016-10-18 15:34:43 --> Loader Class Initialized
INFO - 2016-10-18 15:34:43 --> Helper loaded: url_helper
INFO - 2016-10-18 15:34:43 --> Helper loaded: form_helper
INFO - 2016-10-18 15:34:43 --> Database Driver Class Initialized
INFO - 2016-10-18 15:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:34:43 --> Controller Class Initialized
INFO - 2016-10-18 15:34:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:34:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:34:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:34:43 --> Final output sent to browser
DEBUG - 2016-10-18 15:34:43 --> Total execution time: 0.0078
INFO - 2016-10-18 15:34:46 --> Config Class Initialized
INFO - 2016-10-18 15:34:46 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:34:46 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:34:46 --> Utf8 Class Initialized
INFO - 2016-10-18 15:34:46 --> URI Class Initialized
DEBUG - 2016-10-18 15:34:46 --> No URI present. Default controller set.
INFO - 2016-10-18 15:34:46 --> Router Class Initialized
INFO - 2016-10-18 15:34:46 --> Output Class Initialized
INFO - 2016-10-18 15:34:46 --> Security Class Initialized
DEBUG - 2016-10-18 15:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:34:46 --> Input Class Initialized
INFO - 2016-10-18 15:34:46 --> Language Class Initialized
INFO - 2016-10-18 15:34:46 --> Loader Class Initialized
INFO - 2016-10-18 15:34:46 --> Helper loaded: url_helper
INFO - 2016-10-18 15:34:46 --> Helper loaded: form_helper
INFO - 2016-10-18 15:34:46 --> Database Driver Class Initialized
INFO - 2016-10-18 15:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:34:46 --> Controller Class Initialized
INFO - 2016-10-18 15:34:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:34:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:34:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:34:46 --> Final output sent to browser
DEBUG - 2016-10-18 15:34:46 --> Total execution time: 0.0045
INFO - 2016-10-18 15:35:11 --> Config Class Initialized
INFO - 2016-10-18 15:35:11 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:35:11 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:35:11 --> Utf8 Class Initialized
INFO - 2016-10-18 15:35:11 --> URI Class Initialized
DEBUG - 2016-10-18 15:35:11 --> No URI present. Default controller set.
INFO - 2016-10-18 15:35:11 --> Router Class Initialized
INFO - 2016-10-18 15:35:11 --> Output Class Initialized
INFO - 2016-10-18 15:35:11 --> Security Class Initialized
DEBUG - 2016-10-18 15:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:35:11 --> Input Class Initialized
INFO - 2016-10-18 15:35:11 --> Language Class Initialized
INFO - 2016-10-18 15:35:11 --> Loader Class Initialized
INFO - 2016-10-18 15:35:11 --> Helper loaded: url_helper
INFO - 2016-10-18 15:35:11 --> Helper loaded: form_helper
INFO - 2016-10-18 15:35:11 --> Database Driver Class Initialized
INFO - 2016-10-18 15:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:35:11 --> Controller Class Initialized
INFO - 2016-10-18 15:35:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:35:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:35:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:35:11 --> Final output sent to browser
DEBUG - 2016-10-18 15:35:11 --> Total execution time: 0.0057
INFO - 2016-10-18 15:35:13 --> Config Class Initialized
INFO - 2016-10-18 15:35:13 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:35:13 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:35:13 --> Utf8 Class Initialized
INFO - 2016-10-18 15:35:13 --> URI Class Initialized
DEBUG - 2016-10-18 15:35:13 --> No URI present. Default controller set.
INFO - 2016-10-18 15:35:13 --> Router Class Initialized
INFO - 2016-10-18 15:35:13 --> Output Class Initialized
INFO - 2016-10-18 15:35:13 --> Security Class Initialized
DEBUG - 2016-10-18 15:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:35:13 --> Input Class Initialized
INFO - 2016-10-18 15:35:13 --> Language Class Initialized
INFO - 2016-10-18 15:35:13 --> Loader Class Initialized
INFO - 2016-10-18 15:35:13 --> Helper loaded: url_helper
INFO - 2016-10-18 15:35:13 --> Helper loaded: form_helper
INFO - 2016-10-18 15:35:13 --> Database Driver Class Initialized
INFO - 2016-10-18 15:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:35:13 --> Controller Class Initialized
INFO - 2016-10-18 15:35:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:35:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:35:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:35:13 --> Final output sent to browser
DEBUG - 2016-10-18 15:35:13 --> Total execution time: 0.0045
INFO - 2016-10-18 15:35:31 --> Config Class Initialized
INFO - 2016-10-18 15:35:31 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:35:31 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:35:31 --> Utf8 Class Initialized
INFO - 2016-10-18 15:35:31 --> URI Class Initialized
DEBUG - 2016-10-18 15:35:31 --> No URI present. Default controller set.
INFO - 2016-10-18 15:35:31 --> Router Class Initialized
INFO - 2016-10-18 15:35:31 --> Output Class Initialized
INFO - 2016-10-18 15:35:31 --> Security Class Initialized
DEBUG - 2016-10-18 15:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:35:31 --> Input Class Initialized
INFO - 2016-10-18 15:35:31 --> Language Class Initialized
INFO - 2016-10-18 15:35:31 --> Loader Class Initialized
INFO - 2016-10-18 15:35:31 --> Helper loaded: url_helper
INFO - 2016-10-18 15:35:31 --> Helper loaded: form_helper
INFO - 2016-10-18 15:35:31 --> Database Driver Class Initialized
INFO - 2016-10-18 15:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:35:31 --> Controller Class Initialized
INFO - 2016-10-18 15:35:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:35:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:35:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:35:31 --> Final output sent to browser
DEBUG - 2016-10-18 15:35:31 --> Total execution time: 0.0054
INFO - 2016-10-18 15:35:37 --> Config Class Initialized
INFO - 2016-10-18 15:35:37 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:35:37 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:35:37 --> Utf8 Class Initialized
INFO - 2016-10-18 15:35:37 --> URI Class Initialized
INFO - 2016-10-18 15:35:37 --> Router Class Initialized
INFO - 2016-10-18 15:35:37 --> Output Class Initialized
INFO - 2016-10-18 15:35:37 --> Security Class Initialized
DEBUG - 2016-10-18 15:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:35:37 --> Input Class Initialized
INFO - 2016-10-18 15:35:37 --> Language Class Initialized
INFO - 2016-10-18 15:35:37 --> Loader Class Initialized
INFO - 2016-10-18 15:35:37 --> Helper loaded: url_helper
INFO - 2016-10-18 15:35:37 --> Helper loaded: form_helper
INFO - 2016-10-18 15:35:37 --> Database Driver Class Initialized
INFO - 2016-10-18 15:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:35:37 --> Controller Class Initialized
INFO - 2016-10-18 15:35:37 --> Model Class Initialized
INFO - 2016-10-18 15:35:37 --> Final output sent to browser
DEBUG - 2016-10-18 15:35:37 --> Total execution time: 0.0087
INFO - 2016-10-18 15:36:30 --> Config Class Initialized
INFO - 2016-10-18 15:36:30 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:36:30 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:36:30 --> Utf8 Class Initialized
INFO - 2016-10-18 15:36:30 --> URI Class Initialized
DEBUG - 2016-10-18 15:36:30 --> No URI present. Default controller set.
INFO - 2016-10-18 15:36:30 --> Router Class Initialized
INFO - 2016-10-18 15:36:30 --> Output Class Initialized
INFO - 2016-10-18 15:36:30 --> Security Class Initialized
DEBUG - 2016-10-18 15:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:36:30 --> Input Class Initialized
INFO - 2016-10-18 15:36:30 --> Language Class Initialized
INFO - 2016-10-18 15:36:30 --> Loader Class Initialized
INFO - 2016-10-18 15:36:30 --> Helper loaded: url_helper
INFO - 2016-10-18 15:36:30 --> Helper loaded: form_helper
INFO - 2016-10-18 15:36:30 --> Database Driver Class Initialized
INFO - 2016-10-18 15:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:36:30 --> Controller Class Initialized
INFO - 2016-10-18 15:36:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:36:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:36:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:36:30 --> Final output sent to browser
DEBUG - 2016-10-18 15:36:30 --> Total execution time: 0.0054
INFO - 2016-10-18 15:36:35 --> Config Class Initialized
INFO - 2016-10-18 15:36:35 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:36:35 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:36:35 --> Utf8 Class Initialized
INFO - 2016-10-18 15:36:35 --> URI Class Initialized
INFO - 2016-10-18 15:36:35 --> Router Class Initialized
INFO - 2016-10-18 15:36:35 --> Output Class Initialized
INFO - 2016-10-18 15:36:35 --> Security Class Initialized
DEBUG - 2016-10-18 15:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:36:35 --> Input Class Initialized
INFO - 2016-10-18 15:36:35 --> Language Class Initialized
INFO - 2016-10-18 15:36:35 --> Loader Class Initialized
INFO - 2016-10-18 15:36:35 --> Helper loaded: url_helper
INFO - 2016-10-18 15:36:35 --> Helper loaded: form_helper
INFO - 2016-10-18 15:36:35 --> Database Driver Class Initialized
INFO - 2016-10-18 15:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:36:35 --> Controller Class Initialized
INFO - 2016-10-18 15:36:35 --> Model Class Initialized
INFO - 2016-10-18 15:36:35 --> Final output sent to browser
DEBUG - 2016-10-18 15:36:35 --> Total execution time: 0.0057
INFO - 2016-10-18 15:36:54 --> Config Class Initialized
INFO - 2016-10-18 15:36:54 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:36:54 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:36:54 --> Utf8 Class Initialized
INFO - 2016-10-18 15:36:54 --> URI Class Initialized
DEBUG - 2016-10-18 15:36:54 --> No URI present. Default controller set.
INFO - 2016-10-18 15:36:54 --> Router Class Initialized
INFO - 2016-10-18 15:36:54 --> Output Class Initialized
INFO - 2016-10-18 15:36:54 --> Security Class Initialized
DEBUG - 2016-10-18 15:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:36:54 --> Input Class Initialized
INFO - 2016-10-18 15:36:54 --> Language Class Initialized
INFO - 2016-10-18 15:36:54 --> Loader Class Initialized
INFO - 2016-10-18 15:36:54 --> Helper loaded: url_helper
INFO - 2016-10-18 15:36:54 --> Helper loaded: form_helper
INFO - 2016-10-18 15:36:54 --> Database Driver Class Initialized
INFO - 2016-10-18 15:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:36:54 --> Controller Class Initialized
INFO - 2016-10-18 15:36:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:36:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:36:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:36:54 --> Final output sent to browser
DEBUG - 2016-10-18 15:36:54 --> Total execution time: 0.0051
INFO - 2016-10-18 15:40:40 --> Config Class Initialized
INFO - 2016-10-18 15:40:40 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:40:40 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:40:40 --> Utf8 Class Initialized
INFO - 2016-10-18 15:40:40 --> URI Class Initialized
DEBUG - 2016-10-18 15:40:40 --> No URI present. Default controller set.
INFO - 2016-10-18 15:40:40 --> Router Class Initialized
INFO - 2016-10-18 15:40:40 --> Output Class Initialized
INFO - 2016-10-18 15:40:40 --> Security Class Initialized
DEBUG - 2016-10-18 15:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:40:40 --> Input Class Initialized
INFO - 2016-10-18 15:40:40 --> Language Class Initialized
INFO - 2016-10-18 15:40:40 --> Loader Class Initialized
INFO - 2016-10-18 15:40:40 --> Helper loaded: url_helper
INFO - 2016-10-18 15:40:40 --> Helper loaded: form_helper
INFO - 2016-10-18 15:40:40 --> Database Driver Class Initialized
INFO - 2016-10-18 15:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:40:40 --> Controller Class Initialized
INFO - 2016-10-18 15:40:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:40:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:40:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:40:40 --> Final output sent to browser
DEBUG - 2016-10-18 15:40:40 --> Total execution time: 0.0085
INFO - 2016-10-18 15:47:22 --> Config Class Initialized
INFO - 2016-10-18 15:47:22 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:47:22 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:47:22 --> Utf8 Class Initialized
INFO - 2016-10-18 15:47:22 --> URI Class Initialized
DEBUG - 2016-10-18 15:47:22 --> No URI present. Default controller set.
INFO - 2016-10-18 15:47:22 --> Router Class Initialized
INFO - 2016-10-18 15:47:22 --> Output Class Initialized
INFO - 2016-10-18 15:47:22 --> Security Class Initialized
DEBUG - 2016-10-18 15:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:47:22 --> Input Class Initialized
INFO - 2016-10-18 15:47:22 --> Language Class Initialized
INFO - 2016-10-18 15:47:22 --> Loader Class Initialized
INFO - 2016-10-18 15:47:22 --> Helper loaded: url_helper
INFO - 2016-10-18 15:47:22 --> Helper loaded: form_helper
INFO - 2016-10-18 15:47:22 --> Database Driver Class Initialized
INFO - 2016-10-18 15:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:47:22 --> Controller Class Initialized
INFO - 2016-10-18 15:47:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:47:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 15:47:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:47:22 --> Final output sent to browser
DEBUG - 2016-10-18 15:47:22 --> Total execution time: 0.0054
INFO - 2016-10-18 15:47:30 --> Config Class Initialized
INFO - 2016-10-18 15:47:30 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:47:30 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:47:30 --> Utf8 Class Initialized
INFO - 2016-10-18 15:47:30 --> URI Class Initialized
INFO - 2016-10-18 15:47:30 --> Router Class Initialized
INFO - 2016-10-18 15:47:30 --> Output Class Initialized
INFO - 2016-10-18 15:47:30 --> Security Class Initialized
DEBUG - 2016-10-18 15:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:47:30 --> Input Class Initialized
INFO - 2016-10-18 15:47:30 --> Language Class Initialized
INFO - 2016-10-18 15:47:30 --> Loader Class Initialized
INFO - 2016-10-18 15:47:30 --> Helper loaded: url_helper
INFO - 2016-10-18 15:47:30 --> Helper loaded: form_helper
INFO - 2016-10-18 15:47:30 --> Database Driver Class Initialized
INFO - 2016-10-18 15:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:47:30 --> Controller Class Initialized
INFO - 2016-10-18 15:47:30 --> Model Class Initialized
INFO - 2016-10-18 15:47:30 --> Final output sent to browser
DEBUG - 2016-10-18 15:47:30 --> Total execution time: 0.0106
INFO - 2016-10-18 15:47:45 --> Config Class Initialized
INFO - 2016-10-18 15:47:45 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:47:45 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:47:45 --> Utf8 Class Initialized
INFO - 2016-10-18 15:47:45 --> URI Class Initialized
INFO - 2016-10-18 15:47:45 --> Router Class Initialized
INFO - 2016-10-18 15:47:45 --> Output Class Initialized
INFO - 2016-10-18 15:47:45 --> Security Class Initialized
DEBUG - 2016-10-18 15:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:47:45 --> Input Class Initialized
INFO - 2016-10-18 15:47:45 --> Language Class Initialized
INFO - 2016-10-18 15:47:45 --> Loader Class Initialized
INFO - 2016-10-18 15:47:45 --> Helper loaded: url_helper
INFO - 2016-10-18 15:47:45 --> Helper loaded: form_helper
INFO - 2016-10-18 15:47:45 --> Database Driver Class Initialized
INFO - 2016-10-18 15:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:47:45 --> Controller Class Initialized
INFO - 2016-10-18 15:47:45 --> Model Class Initialized
INFO - 2016-10-18 15:47:45 --> Final output sent to browser
DEBUG - 2016-10-18 15:47:45 --> Total execution time: 0.0065
INFO - 2016-10-18 15:47:45 --> Config Class Initialized
INFO - 2016-10-18 15:47:45 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:47:45 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:47:45 --> Utf8 Class Initialized
INFO - 2016-10-18 15:47:45 --> URI Class Initialized
DEBUG - 2016-10-18 15:47:45 --> No URI present. Default controller set.
INFO - 2016-10-18 15:47:45 --> Router Class Initialized
INFO - 2016-10-18 15:47:45 --> Output Class Initialized
INFO - 2016-10-18 15:47:45 --> Security Class Initialized
DEBUG - 2016-10-18 15:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:47:45 --> Input Class Initialized
INFO - 2016-10-18 15:47:45 --> Language Class Initialized
INFO - 2016-10-18 15:47:45 --> Loader Class Initialized
INFO - 2016-10-18 15:47:45 --> Helper loaded: url_helper
INFO - 2016-10-18 15:47:45 --> Helper loaded: form_helper
INFO - 2016-10-18 15:47:45 --> Database Driver Class Initialized
INFO - 2016-10-18 15:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:47:45 --> Controller Class Initialized
INFO - 2016-10-18 15:47:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:47:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 15:47:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 15:47:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:47:45 --> Final output sent to browser
DEBUG - 2016-10-18 15:47:45 --> Total execution time: 0.0043
INFO - 2016-10-18 15:47:47 --> Config Class Initialized
INFO - 2016-10-18 15:47:47 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:47:47 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:47:47 --> Utf8 Class Initialized
INFO - 2016-10-18 15:47:47 --> URI Class Initialized
DEBUG - 2016-10-18 15:47:47 --> No URI present. Default controller set.
INFO - 2016-10-18 15:47:47 --> Router Class Initialized
INFO - 2016-10-18 15:47:47 --> Output Class Initialized
INFO - 2016-10-18 15:47:47 --> Security Class Initialized
DEBUG - 2016-10-18 15:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:47:47 --> Input Class Initialized
INFO - 2016-10-18 15:47:47 --> Language Class Initialized
INFO - 2016-10-18 15:47:47 --> Loader Class Initialized
INFO - 2016-10-18 15:47:47 --> Helper loaded: url_helper
INFO - 2016-10-18 15:47:47 --> Helper loaded: form_helper
INFO - 2016-10-18 15:47:47 --> Database Driver Class Initialized
INFO - 2016-10-18 15:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:47:47 --> Controller Class Initialized
INFO - 2016-10-18 15:47:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:47:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 15:47:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 15:47:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:47:47 --> Final output sent to browser
DEBUG - 2016-10-18 15:47:47 --> Total execution time: 0.0046
INFO - 2016-10-18 15:47:54 --> Config Class Initialized
INFO - 2016-10-18 15:47:54 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:47:54 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:47:54 --> Utf8 Class Initialized
INFO - 2016-10-18 15:47:54 --> URI Class Initialized
INFO - 2016-10-18 15:47:54 --> Router Class Initialized
INFO - 2016-10-18 15:47:54 --> Output Class Initialized
INFO - 2016-10-18 15:47:54 --> Security Class Initialized
DEBUG - 2016-10-18 15:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:47:54 --> Input Class Initialized
INFO - 2016-10-18 15:47:54 --> Language Class Initialized
INFO - 2016-10-18 15:47:54 --> Loader Class Initialized
INFO - 2016-10-18 15:47:54 --> Helper loaded: url_helper
INFO - 2016-10-18 15:47:54 --> Helper loaded: form_helper
INFO - 2016-10-18 15:47:54 --> Database Driver Class Initialized
INFO - 2016-10-18 15:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:47:54 --> Controller Class Initialized
INFO - 2016-10-18 15:47:54 --> Form Validation Class Initialized
INFO - 2016-10-18 15:47:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 15:47:54 --> Final output sent to browser
DEBUG - 2016-10-18 15:47:54 --> Total execution time: 0.0386
INFO - 2016-10-18 15:50:11 --> Config Class Initialized
INFO - 2016-10-18 15:50:11 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:50:11 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:50:11 --> Utf8 Class Initialized
INFO - 2016-10-18 15:50:11 --> URI Class Initialized
INFO - 2016-10-18 15:50:11 --> Router Class Initialized
INFO - 2016-10-18 15:50:11 --> Output Class Initialized
INFO - 2016-10-18 15:50:11 --> Security Class Initialized
DEBUG - 2016-10-18 15:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:50:11 --> Input Class Initialized
INFO - 2016-10-18 15:50:11 --> Language Class Initialized
INFO - 2016-10-18 15:50:11 --> Loader Class Initialized
INFO - 2016-10-18 15:50:11 --> Helper loaded: url_helper
INFO - 2016-10-18 15:50:11 --> Helper loaded: form_helper
INFO - 2016-10-18 15:50:11 --> Database Driver Class Initialized
INFO - 2016-10-18 15:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:50:11 --> Controller Class Initialized
INFO - 2016-10-18 15:50:11 --> Form Validation Class Initialized
INFO - 2016-10-18 15:50:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 15:50:11 --> Final output sent to browser
DEBUG - 2016-10-18 15:50:11 --> Total execution time: 0.0097
INFO - 2016-10-18 15:50:12 --> Config Class Initialized
INFO - 2016-10-18 15:50:12 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:50:12 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:50:12 --> Utf8 Class Initialized
INFO - 2016-10-18 15:50:12 --> URI Class Initialized
INFO - 2016-10-18 15:50:12 --> Router Class Initialized
INFO - 2016-10-18 15:50:12 --> Output Class Initialized
INFO - 2016-10-18 15:50:12 --> Security Class Initialized
DEBUG - 2016-10-18 15:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:50:12 --> Input Class Initialized
INFO - 2016-10-18 15:50:12 --> Language Class Initialized
INFO - 2016-10-18 15:50:12 --> Loader Class Initialized
INFO - 2016-10-18 15:50:12 --> Helper loaded: url_helper
INFO - 2016-10-18 15:50:12 --> Helper loaded: form_helper
INFO - 2016-10-18 15:50:12 --> Database Driver Class Initialized
INFO - 2016-10-18 15:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:50:12 --> Controller Class Initialized
INFO - 2016-10-18 15:50:12 --> Form Validation Class Initialized
INFO - 2016-10-18 15:50:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 15:50:12 --> Final output sent to browser
DEBUG - 2016-10-18 15:50:12 --> Total execution time: 0.0085
INFO - 2016-10-18 15:53:54 --> Config Class Initialized
INFO - 2016-10-18 15:53:54 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:53:54 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:53:54 --> Utf8 Class Initialized
INFO - 2016-10-18 15:53:54 --> URI Class Initialized
DEBUG - 2016-10-18 15:53:54 --> No URI present. Default controller set.
INFO - 2016-10-18 15:53:54 --> Router Class Initialized
INFO - 2016-10-18 15:53:54 --> Output Class Initialized
INFO - 2016-10-18 15:53:54 --> Security Class Initialized
DEBUG - 2016-10-18 15:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:53:54 --> Input Class Initialized
INFO - 2016-10-18 15:53:54 --> Language Class Initialized
INFO - 2016-10-18 15:53:54 --> Loader Class Initialized
INFO - 2016-10-18 15:53:54 --> Helper loaded: url_helper
INFO - 2016-10-18 15:53:54 --> Helper loaded: form_helper
INFO - 2016-10-18 15:53:54 --> Database Driver Class Initialized
INFO - 2016-10-18 15:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:53:54 --> Controller Class Initialized
INFO - 2016-10-18 15:53:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:53:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 15:53:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 15:53:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:53:54 --> Final output sent to browser
DEBUG - 2016-10-18 15:53:54 --> Total execution time: 0.0054
INFO - 2016-10-18 15:54:26 --> Config Class Initialized
INFO - 2016-10-18 15:54:26 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:54:26 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:54:26 --> Utf8 Class Initialized
INFO - 2016-10-18 15:54:26 --> URI Class Initialized
DEBUG - 2016-10-18 15:54:26 --> No URI present. Default controller set.
INFO - 2016-10-18 15:54:26 --> Router Class Initialized
INFO - 2016-10-18 15:54:26 --> Output Class Initialized
INFO - 2016-10-18 15:54:26 --> Security Class Initialized
DEBUG - 2016-10-18 15:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:54:26 --> Input Class Initialized
INFO - 2016-10-18 15:54:26 --> Language Class Initialized
INFO - 2016-10-18 15:54:26 --> Loader Class Initialized
INFO - 2016-10-18 15:54:26 --> Helper loaded: url_helper
INFO - 2016-10-18 15:54:26 --> Helper loaded: form_helper
INFO - 2016-10-18 15:54:26 --> Database Driver Class Initialized
INFO - 2016-10-18 15:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:54:26 --> Controller Class Initialized
INFO - 2016-10-18 15:54:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:54:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 15:54:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 15:54:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:54:26 --> Final output sent to browser
DEBUG - 2016-10-18 15:54:26 --> Total execution time: 0.0056
INFO - 2016-10-18 15:56:20 --> Config Class Initialized
INFO - 2016-10-18 15:56:20 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:56:20 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:56:20 --> Utf8 Class Initialized
INFO - 2016-10-18 15:56:20 --> URI Class Initialized
DEBUG - 2016-10-18 15:56:20 --> No URI present. Default controller set.
INFO - 2016-10-18 15:56:20 --> Router Class Initialized
INFO - 2016-10-18 15:56:20 --> Output Class Initialized
INFO - 2016-10-18 15:56:20 --> Security Class Initialized
DEBUG - 2016-10-18 15:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:56:20 --> Input Class Initialized
INFO - 2016-10-18 15:56:20 --> Language Class Initialized
INFO - 2016-10-18 15:56:20 --> Loader Class Initialized
INFO - 2016-10-18 15:56:20 --> Helper loaded: url_helper
INFO - 2016-10-18 15:56:20 --> Helper loaded: form_helper
INFO - 2016-10-18 15:56:20 --> Database Driver Class Initialized
INFO - 2016-10-18 15:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:56:20 --> Controller Class Initialized
INFO - 2016-10-18 15:56:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:56:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 15:56:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 15:56:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:56:20 --> Final output sent to browser
DEBUG - 2016-10-18 15:56:20 --> Total execution time: 0.0083
INFO - 2016-10-18 15:57:16 --> Config Class Initialized
INFO - 2016-10-18 15:57:16 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:57:16 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:57:16 --> Utf8 Class Initialized
INFO - 2016-10-18 15:57:16 --> URI Class Initialized
DEBUG - 2016-10-18 15:57:16 --> No URI present. Default controller set.
INFO - 2016-10-18 15:57:16 --> Router Class Initialized
INFO - 2016-10-18 15:57:16 --> Output Class Initialized
INFO - 2016-10-18 15:57:16 --> Security Class Initialized
DEBUG - 2016-10-18 15:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:57:16 --> Input Class Initialized
INFO - 2016-10-18 15:57:16 --> Language Class Initialized
INFO - 2016-10-18 15:57:16 --> Loader Class Initialized
INFO - 2016-10-18 15:57:16 --> Helper loaded: url_helper
INFO - 2016-10-18 15:57:16 --> Helper loaded: form_helper
INFO - 2016-10-18 15:57:16 --> Database Driver Class Initialized
INFO - 2016-10-18 15:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:57:16 --> Controller Class Initialized
INFO - 2016-10-18 15:57:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:57:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 15:57:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 15:57:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:57:16 --> Final output sent to browser
DEBUG - 2016-10-18 15:57:16 --> Total execution time: 0.0081
INFO - 2016-10-18 15:57:40 --> Config Class Initialized
INFO - 2016-10-18 15:57:40 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:57:40 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:57:40 --> Utf8 Class Initialized
INFO - 2016-10-18 15:57:40 --> URI Class Initialized
DEBUG - 2016-10-18 15:57:40 --> No URI present. Default controller set.
INFO - 2016-10-18 15:57:40 --> Router Class Initialized
INFO - 2016-10-18 15:57:40 --> Output Class Initialized
INFO - 2016-10-18 15:57:40 --> Security Class Initialized
DEBUG - 2016-10-18 15:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:57:40 --> Input Class Initialized
INFO - 2016-10-18 15:57:40 --> Language Class Initialized
INFO - 2016-10-18 15:57:40 --> Loader Class Initialized
INFO - 2016-10-18 15:57:40 --> Helper loaded: url_helper
INFO - 2016-10-18 15:57:40 --> Helper loaded: form_helper
INFO - 2016-10-18 15:57:40 --> Database Driver Class Initialized
INFO - 2016-10-18 15:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:57:40 --> Controller Class Initialized
INFO - 2016-10-18 15:57:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:57:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 15:57:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 15:57:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:57:40 --> Final output sent to browser
DEBUG - 2016-10-18 15:57:40 --> Total execution time: 0.0055
INFO - 2016-10-18 15:58:46 --> Config Class Initialized
INFO - 2016-10-18 15:58:46 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:58:46 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:58:46 --> Utf8 Class Initialized
INFO - 2016-10-18 15:58:46 --> URI Class Initialized
DEBUG - 2016-10-18 15:58:46 --> No URI present. Default controller set.
INFO - 2016-10-18 15:58:46 --> Router Class Initialized
INFO - 2016-10-18 15:58:46 --> Output Class Initialized
INFO - 2016-10-18 15:58:46 --> Security Class Initialized
DEBUG - 2016-10-18 15:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:58:46 --> Input Class Initialized
INFO - 2016-10-18 15:58:46 --> Language Class Initialized
INFO - 2016-10-18 15:58:46 --> Loader Class Initialized
INFO - 2016-10-18 15:58:46 --> Helper loaded: url_helper
INFO - 2016-10-18 15:58:46 --> Helper loaded: form_helper
INFO - 2016-10-18 15:58:46 --> Database Driver Class Initialized
INFO - 2016-10-18 15:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:58:46 --> Controller Class Initialized
INFO - 2016-10-18 15:58:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:58:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 15:58:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 15:58:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:58:46 --> Final output sent to browser
DEBUG - 2016-10-18 15:58:46 --> Total execution time: 0.0056
INFO - 2016-10-18 15:59:11 --> Config Class Initialized
INFO - 2016-10-18 15:59:11 --> Hooks Class Initialized
DEBUG - 2016-10-18 15:59:11 --> UTF-8 Support Enabled
INFO - 2016-10-18 15:59:11 --> Utf8 Class Initialized
INFO - 2016-10-18 15:59:11 --> URI Class Initialized
DEBUG - 2016-10-18 15:59:11 --> No URI present. Default controller set.
INFO - 2016-10-18 15:59:11 --> Router Class Initialized
INFO - 2016-10-18 15:59:11 --> Output Class Initialized
INFO - 2016-10-18 15:59:11 --> Security Class Initialized
DEBUG - 2016-10-18 15:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 15:59:11 --> Input Class Initialized
INFO - 2016-10-18 15:59:11 --> Language Class Initialized
INFO - 2016-10-18 15:59:11 --> Loader Class Initialized
INFO - 2016-10-18 15:59:11 --> Helper loaded: url_helper
INFO - 2016-10-18 15:59:11 --> Helper loaded: form_helper
INFO - 2016-10-18 15:59:11 --> Database Driver Class Initialized
INFO - 2016-10-18 15:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 15:59:11 --> Controller Class Initialized
INFO - 2016-10-18 15:59:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 15:59:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 15:59:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 15:59:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 15:59:11 --> Final output sent to browser
DEBUG - 2016-10-18 15:59:11 --> Total execution time: 0.0053
INFO - 2016-10-18 16:01:23 --> Config Class Initialized
INFO - 2016-10-18 16:01:23 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:01:23 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:01:23 --> Utf8 Class Initialized
INFO - 2016-10-18 16:01:23 --> URI Class Initialized
DEBUG - 2016-10-18 16:01:23 --> No URI present. Default controller set.
INFO - 2016-10-18 16:01:23 --> Router Class Initialized
INFO - 2016-10-18 16:01:23 --> Output Class Initialized
INFO - 2016-10-18 16:01:23 --> Security Class Initialized
DEBUG - 2016-10-18 16:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:01:23 --> Input Class Initialized
INFO - 2016-10-18 16:01:23 --> Language Class Initialized
INFO - 2016-10-18 16:01:23 --> Loader Class Initialized
INFO - 2016-10-18 16:01:23 --> Helper loaded: url_helper
INFO - 2016-10-18 16:01:23 --> Helper loaded: form_helper
INFO - 2016-10-18 16:01:23 --> Database Driver Class Initialized
INFO - 2016-10-18 16:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:01:23 --> Controller Class Initialized
INFO - 2016-10-18 16:01:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:01:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:01:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:01:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:01:23 --> Final output sent to browser
DEBUG - 2016-10-18 16:01:23 --> Total execution time: 0.0057
INFO - 2016-10-18 16:03:12 --> Config Class Initialized
INFO - 2016-10-18 16:03:12 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:03:12 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:03:12 --> Utf8 Class Initialized
INFO - 2016-10-18 16:03:12 --> URI Class Initialized
DEBUG - 2016-10-18 16:03:12 --> No URI present. Default controller set.
INFO - 2016-10-18 16:03:12 --> Router Class Initialized
INFO - 2016-10-18 16:03:12 --> Output Class Initialized
INFO - 2016-10-18 16:03:12 --> Security Class Initialized
DEBUG - 2016-10-18 16:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:03:12 --> Input Class Initialized
INFO - 2016-10-18 16:03:12 --> Language Class Initialized
INFO - 2016-10-18 16:03:12 --> Loader Class Initialized
INFO - 2016-10-18 16:03:12 --> Helper loaded: url_helper
INFO - 2016-10-18 16:03:12 --> Helper loaded: form_helper
INFO - 2016-10-18 16:03:12 --> Database Driver Class Initialized
INFO - 2016-10-18 16:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:03:12 --> Controller Class Initialized
INFO - 2016-10-18 16:03:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:03:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:03:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:03:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:03:12 --> Final output sent to browser
DEBUG - 2016-10-18 16:03:12 --> Total execution time: 0.0083
INFO - 2016-10-18 16:03:17 --> Config Class Initialized
INFO - 2016-10-18 16:03:17 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:03:17 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:03:17 --> Utf8 Class Initialized
INFO - 2016-10-18 16:03:17 --> URI Class Initialized
DEBUG - 2016-10-18 16:03:17 --> No URI present. Default controller set.
INFO - 2016-10-18 16:03:17 --> Router Class Initialized
INFO - 2016-10-18 16:03:17 --> Output Class Initialized
INFO - 2016-10-18 16:03:17 --> Security Class Initialized
DEBUG - 2016-10-18 16:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:03:17 --> Input Class Initialized
INFO - 2016-10-18 16:03:17 --> Language Class Initialized
INFO - 2016-10-18 16:03:17 --> Loader Class Initialized
INFO - 2016-10-18 16:03:17 --> Helper loaded: url_helper
INFO - 2016-10-18 16:03:17 --> Helper loaded: form_helper
INFO - 2016-10-18 16:03:17 --> Database Driver Class Initialized
INFO - 2016-10-18 16:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:03:17 --> Controller Class Initialized
INFO - 2016-10-18 16:03:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:03:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:03:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:03:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:03:17 --> Final output sent to browser
DEBUG - 2016-10-18 16:03:17 --> Total execution time: 0.0077
INFO - 2016-10-18 16:03:40 --> Config Class Initialized
INFO - 2016-10-18 16:03:40 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:03:40 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:03:40 --> Utf8 Class Initialized
INFO - 2016-10-18 16:03:40 --> URI Class Initialized
DEBUG - 2016-10-18 16:03:40 --> No URI present. Default controller set.
INFO - 2016-10-18 16:03:40 --> Router Class Initialized
INFO - 2016-10-18 16:03:40 --> Output Class Initialized
INFO - 2016-10-18 16:03:40 --> Security Class Initialized
DEBUG - 2016-10-18 16:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:03:40 --> Input Class Initialized
INFO - 2016-10-18 16:03:40 --> Language Class Initialized
INFO - 2016-10-18 16:03:40 --> Loader Class Initialized
INFO - 2016-10-18 16:03:40 --> Helper loaded: url_helper
INFO - 2016-10-18 16:03:40 --> Helper loaded: form_helper
INFO - 2016-10-18 16:03:40 --> Database Driver Class Initialized
INFO - 2016-10-18 16:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:03:40 --> Controller Class Initialized
INFO - 2016-10-18 16:03:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:03:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:03:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:03:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:03:40 --> Final output sent to browser
DEBUG - 2016-10-18 16:03:40 --> Total execution time: 0.0051
INFO - 2016-10-18 16:04:52 --> Config Class Initialized
INFO - 2016-10-18 16:04:52 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:04:52 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:04:52 --> Utf8 Class Initialized
INFO - 2016-10-18 16:04:52 --> URI Class Initialized
DEBUG - 2016-10-18 16:04:52 --> No URI present. Default controller set.
INFO - 2016-10-18 16:04:52 --> Router Class Initialized
INFO - 2016-10-18 16:04:52 --> Output Class Initialized
INFO - 2016-10-18 16:04:52 --> Security Class Initialized
DEBUG - 2016-10-18 16:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:04:52 --> Input Class Initialized
INFO - 2016-10-18 16:04:52 --> Language Class Initialized
INFO - 2016-10-18 16:04:52 --> Loader Class Initialized
INFO - 2016-10-18 16:04:52 --> Helper loaded: url_helper
INFO - 2016-10-18 16:04:52 --> Helper loaded: form_helper
INFO - 2016-10-18 16:04:52 --> Database Driver Class Initialized
INFO - 2016-10-18 16:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:04:52 --> Controller Class Initialized
INFO - 2016-10-18 16:04:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:04:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:04:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:04:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:04:52 --> Final output sent to browser
DEBUG - 2016-10-18 16:04:52 --> Total execution time: 0.0051
INFO - 2016-10-18 16:07:31 --> Config Class Initialized
INFO - 2016-10-18 16:07:31 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:07:31 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:07:31 --> Utf8 Class Initialized
INFO - 2016-10-18 16:07:31 --> URI Class Initialized
DEBUG - 2016-10-18 16:07:31 --> No URI present. Default controller set.
INFO - 2016-10-18 16:07:31 --> Router Class Initialized
INFO - 2016-10-18 16:07:31 --> Output Class Initialized
INFO - 2016-10-18 16:07:31 --> Security Class Initialized
DEBUG - 2016-10-18 16:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:07:31 --> Input Class Initialized
INFO - 2016-10-18 16:07:31 --> Language Class Initialized
INFO - 2016-10-18 16:07:31 --> Loader Class Initialized
INFO - 2016-10-18 16:07:31 --> Helper loaded: url_helper
INFO - 2016-10-18 16:07:31 --> Helper loaded: form_helper
INFO - 2016-10-18 16:07:31 --> Database Driver Class Initialized
INFO - 2016-10-18 16:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:07:31 --> Controller Class Initialized
INFO - 2016-10-18 16:07:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:07:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:07:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:07:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:07:31 --> Final output sent to browser
DEBUG - 2016-10-18 16:07:31 --> Total execution time: 0.0057
INFO - 2016-10-18 16:08:37 --> Config Class Initialized
INFO - 2016-10-18 16:08:37 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:08:37 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:08:37 --> Utf8 Class Initialized
INFO - 2016-10-18 16:08:37 --> URI Class Initialized
DEBUG - 2016-10-18 16:08:37 --> No URI present. Default controller set.
INFO - 2016-10-18 16:08:37 --> Router Class Initialized
INFO - 2016-10-18 16:08:37 --> Output Class Initialized
INFO - 2016-10-18 16:08:37 --> Security Class Initialized
DEBUG - 2016-10-18 16:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:08:37 --> Input Class Initialized
INFO - 2016-10-18 16:08:37 --> Language Class Initialized
INFO - 2016-10-18 16:08:37 --> Loader Class Initialized
INFO - 2016-10-18 16:08:37 --> Helper loaded: url_helper
INFO - 2016-10-18 16:08:37 --> Helper loaded: form_helper
INFO - 2016-10-18 16:08:37 --> Database Driver Class Initialized
INFO - 2016-10-18 16:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:08:37 --> Controller Class Initialized
INFO - 2016-10-18 16:08:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:08:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:08:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:08:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:08:37 --> Final output sent to browser
DEBUG - 2016-10-18 16:08:37 --> Total execution time: 0.0054
INFO - 2016-10-18 16:08:53 --> Config Class Initialized
INFO - 2016-10-18 16:08:53 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:08:53 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:08:53 --> Utf8 Class Initialized
INFO - 2016-10-18 16:08:53 --> URI Class Initialized
DEBUG - 2016-10-18 16:08:53 --> No URI present. Default controller set.
INFO - 2016-10-18 16:08:53 --> Router Class Initialized
INFO - 2016-10-18 16:08:53 --> Output Class Initialized
INFO - 2016-10-18 16:08:53 --> Security Class Initialized
DEBUG - 2016-10-18 16:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:08:53 --> Input Class Initialized
INFO - 2016-10-18 16:08:53 --> Language Class Initialized
INFO - 2016-10-18 16:08:53 --> Loader Class Initialized
INFO - 2016-10-18 16:08:53 --> Helper loaded: url_helper
INFO - 2016-10-18 16:08:53 --> Helper loaded: form_helper
INFO - 2016-10-18 16:08:53 --> Database Driver Class Initialized
INFO - 2016-10-18 16:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:08:53 --> Controller Class Initialized
INFO - 2016-10-18 16:08:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:08:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:08:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:08:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:08:53 --> Final output sent to browser
DEBUG - 2016-10-18 16:08:53 --> Total execution time: 0.0057
INFO - 2016-10-18 16:09:45 --> Config Class Initialized
INFO - 2016-10-18 16:09:45 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:09:45 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:09:45 --> Utf8 Class Initialized
INFO - 2016-10-18 16:09:45 --> URI Class Initialized
DEBUG - 2016-10-18 16:09:45 --> No URI present. Default controller set.
INFO - 2016-10-18 16:09:45 --> Router Class Initialized
INFO - 2016-10-18 16:09:45 --> Output Class Initialized
INFO - 2016-10-18 16:09:45 --> Security Class Initialized
DEBUG - 2016-10-18 16:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:09:45 --> Input Class Initialized
INFO - 2016-10-18 16:09:45 --> Language Class Initialized
INFO - 2016-10-18 16:09:45 --> Loader Class Initialized
INFO - 2016-10-18 16:09:45 --> Helper loaded: url_helper
INFO - 2016-10-18 16:09:45 --> Helper loaded: form_helper
INFO - 2016-10-18 16:09:45 --> Database Driver Class Initialized
INFO - 2016-10-18 16:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:09:45 --> Controller Class Initialized
INFO - 2016-10-18 16:09:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:09:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:09:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:09:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:09:45 --> Final output sent to browser
DEBUG - 2016-10-18 16:09:45 --> Total execution time: 0.0057
INFO - 2016-10-18 16:09:46 --> Config Class Initialized
INFO - 2016-10-18 16:09:46 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:09:46 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:09:46 --> Utf8 Class Initialized
INFO - 2016-10-18 16:09:46 --> URI Class Initialized
DEBUG - 2016-10-18 16:09:46 --> No URI present. Default controller set.
INFO - 2016-10-18 16:09:46 --> Router Class Initialized
INFO - 2016-10-18 16:09:46 --> Output Class Initialized
INFO - 2016-10-18 16:09:46 --> Security Class Initialized
DEBUG - 2016-10-18 16:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:09:46 --> Input Class Initialized
INFO - 2016-10-18 16:09:46 --> Language Class Initialized
INFO - 2016-10-18 16:09:46 --> Loader Class Initialized
INFO - 2016-10-18 16:09:46 --> Helper loaded: url_helper
INFO - 2016-10-18 16:09:46 --> Helper loaded: form_helper
INFO - 2016-10-18 16:09:46 --> Database Driver Class Initialized
INFO - 2016-10-18 16:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:09:46 --> Controller Class Initialized
INFO - 2016-10-18 16:09:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:09:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:09:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:09:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:09:46 --> Final output sent to browser
DEBUG - 2016-10-18 16:09:46 --> Total execution time: 0.0054
INFO - 2016-10-18 16:10:50 --> Config Class Initialized
INFO - 2016-10-18 16:10:50 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:10:50 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:10:50 --> Utf8 Class Initialized
INFO - 2016-10-18 16:10:50 --> URI Class Initialized
DEBUG - 2016-10-18 16:10:50 --> No URI present. Default controller set.
INFO - 2016-10-18 16:10:50 --> Router Class Initialized
INFO - 2016-10-18 16:10:50 --> Output Class Initialized
INFO - 2016-10-18 16:10:50 --> Security Class Initialized
DEBUG - 2016-10-18 16:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:10:50 --> Input Class Initialized
INFO - 2016-10-18 16:10:50 --> Language Class Initialized
INFO - 2016-10-18 16:10:50 --> Loader Class Initialized
INFO - 2016-10-18 16:10:50 --> Helper loaded: url_helper
INFO - 2016-10-18 16:10:50 --> Helper loaded: form_helper
INFO - 2016-10-18 16:10:50 --> Database Driver Class Initialized
INFO - 2016-10-18 16:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:10:50 --> Controller Class Initialized
INFO - 2016-10-18 16:10:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:10:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:10:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:10:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:10:50 --> Final output sent to browser
DEBUG - 2016-10-18 16:10:50 --> Total execution time: 0.0052
INFO - 2016-10-18 16:11:21 --> Config Class Initialized
INFO - 2016-10-18 16:11:21 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:11:21 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:11:21 --> Utf8 Class Initialized
INFO - 2016-10-18 16:11:21 --> URI Class Initialized
DEBUG - 2016-10-18 16:11:21 --> No URI present. Default controller set.
INFO - 2016-10-18 16:11:21 --> Router Class Initialized
INFO - 2016-10-18 16:11:21 --> Output Class Initialized
INFO - 2016-10-18 16:11:21 --> Security Class Initialized
DEBUG - 2016-10-18 16:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:11:21 --> Input Class Initialized
INFO - 2016-10-18 16:11:21 --> Language Class Initialized
INFO - 2016-10-18 16:11:21 --> Loader Class Initialized
INFO - 2016-10-18 16:11:21 --> Helper loaded: url_helper
INFO - 2016-10-18 16:11:21 --> Helper loaded: form_helper
INFO - 2016-10-18 16:11:21 --> Database Driver Class Initialized
INFO - 2016-10-18 16:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:11:21 --> Controller Class Initialized
INFO - 2016-10-18 16:11:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:11:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:11:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:11:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:11:21 --> Final output sent to browser
DEBUG - 2016-10-18 16:11:21 --> Total execution time: 0.0055
INFO - 2016-10-18 16:11:43 --> Config Class Initialized
INFO - 2016-10-18 16:11:43 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:11:43 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:11:43 --> Utf8 Class Initialized
INFO - 2016-10-18 16:11:43 --> URI Class Initialized
DEBUG - 2016-10-18 16:11:43 --> No URI present. Default controller set.
INFO - 2016-10-18 16:11:43 --> Router Class Initialized
INFO - 2016-10-18 16:11:43 --> Output Class Initialized
INFO - 2016-10-18 16:11:43 --> Security Class Initialized
DEBUG - 2016-10-18 16:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:11:43 --> Input Class Initialized
INFO - 2016-10-18 16:11:43 --> Language Class Initialized
INFO - 2016-10-18 16:11:43 --> Loader Class Initialized
INFO - 2016-10-18 16:11:43 --> Helper loaded: url_helper
INFO - 2016-10-18 16:11:43 --> Helper loaded: form_helper
INFO - 2016-10-18 16:11:43 --> Database Driver Class Initialized
INFO - 2016-10-18 16:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:11:44 --> Controller Class Initialized
INFO - 2016-10-18 16:11:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:11:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:11:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:11:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:11:44 --> Final output sent to browser
DEBUG - 2016-10-18 16:11:44 --> Total execution time: 0.0052
INFO - 2016-10-18 16:12:00 --> Config Class Initialized
INFO - 2016-10-18 16:12:00 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:12:00 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:12:00 --> Utf8 Class Initialized
INFO - 2016-10-18 16:12:00 --> URI Class Initialized
DEBUG - 2016-10-18 16:12:00 --> No URI present. Default controller set.
INFO - 2016-10-18 16:12:00 --> Router Class Initialized
INFO - 2016-10-18 16:12:00 --> Output Class Initialized
INFO - 2016-10-18 16:12:00 --> Security Class Initialized
DEBUG - 2016-10-18 16:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:12:00 --> Input Class Initialized
INFO - 2016-10-18 16:12:00 --> Language Class Initialized
INFO - 2016-10-18 16:12:00 --> Loader Class Initialized
INFO - 2016-10-18 16:12:00 --> Helper loaded: url_helper
INFO - 2016-10-18 16:12:00 --> Helper loaded: form_helper
INFO - 2016-10-18 16:12:00 --> Database Driver Class Initialized
INFO - 2016-10-18 16:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:12:00 --> Controller Class Initialized
INFO - 2016-10-18 16:12:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:12:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:12:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:12:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:12:00 --> Final output sent to browser
DEBUG - 2016-10-18 16:12:00 --> Total execution time: 0.0046
INFO - 2016-10-18 16:12:40 --> Config Class Initialized
INFO - 2016-10-18 16:12:40 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:12:40 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:12:40 --> Utf8 Class Initialized
INFO - 2016-10-18 16:12:40 --> URI Class Initialized
DEBUG - 2016-10-18 16:12:40 --> No URI present. Default controller set.
INFO - 2016-10-18 16:12:40 --> Router Class Initialized
INFO - 2016-10-18 16:12:40 --> Output Class Initialized
INFO - 2016-10-18 16:12:40 --> Security Class Initialized
DEBUG - 2016-10-18 16:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:12:40 --> Input Class Initialized
INFO - 2016-10-18 16:12:40 --> Language Class Initialized
INFO - 2016-10-18 16:12:40 --> Loader Class Initialized
INFO - 2016-10-18 16:12:40 --> Helper loaded: url_helper
INFO - 2016-10-18 16:12:40 --> Helper loaded: form_helper
INFO - 2016-10-18 16:12:40 --> Database Driver Class Initialized
INFO - 2016-10-18 16:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:12:40 --> Controller Class Initialized
INFO - 2016-10-18 16:12:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:12:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:12:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:12:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:12:40 --> Final output sent to browser
DEBUG - 2016-10-18 16:12:40 --> Total execution time: 0.0057
INFO - 2016-10-18 16:12:44 --> Config Class Initialized
INFO - 2016-10-18 16:12:44 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:12:44 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:12:44 --> Utf8 Class Initialized
INFO - 2016-10-18 16:12:44 --> URI Class Initialized
DEBUG - 2016-10-18 16:12:44 --> No URI present. Default controller set.
INFO - 2016-10-18 16:12:44 --> Router Class Initialized
INFO - 2016-10-18 16:12:44 --> Output Class Initialized
INFO - 2016-10-18 16:12:44 --> Security Class Initialized
DEBUG - 2016-10-18 16:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:12:44 --> Input Class Initialized
INFO - 2016-10-18 16:12:44 --> Language Class Initialized
INFO - 2016-10-18 16:12:44 --> Loader Class Initialized
INFO - 2016-10-18 16:12:44 --> Helper loaded: url_helper
INFO - 2016-10-18 16:12:44 --> Helper loaded: form_helper
INFO - 2016-10-18 16:12:44 --> Database Driver Class Initialized
INFO - 2016-10-18 16:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:12:44 --> Controller Class Initialized
INFO - 2016-10-18 16:12:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:12:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:12:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:12:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:12:44 --> Final output sent to browser
DEBUG - 2016-10-18 16:12:44 --> Total execution time: 0.0053
INFO - 2016-10-18 16:13:02 --> Config Class Initialized
INFO - 2016-10-18 16:13:02 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:13:02 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:13:02 --> Utf8 Class Initialized
INFO - 2016-10-18 16:13:02 --> URI Class Initialized
DEBUG - 2016-10-18 16:13:02 --> No URI present. Default controller set.
INFO - 2016-10-18 16:13:02 --> Router Class Initialized
INFO - 2016-10-18 16:13:02 --> Output Class Initialized
INFO - 2016-10-18 16:13:02 --> Security Class Initialized
DEBUG - 2016-10-18 16:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:13:02 --> Input Class Initialized
INFO - 2016-10-18 16:13:02 --> Language Class Initialized
INFO - 2016-10-18 16:13:02 --> Loader Class Initialized
INFO - 2016-10-18 16:13:02 --> Helper loaded: url_helper
INFO - 2016-10-18 16:13:02 --> Helper loaded: form_helper
INFO - 2016-10-18 16:13:02 --> Database Driver Class Initialized
INFO - 2016-10-18 16:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:13:02 --> Controller Class Initialized
INFO - 2016-10-18 16:13:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:13:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:13:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:13:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:13:02 --> Final output sent to browser
DEBUG - 2016-10-18 16:13:02 --> Total execution time: 0.0050
INFO - 2016-10-18 16:14:34 --> Config Class Initialized
INFO - 2016-10-18 16:14:34 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:14:34 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:14:34 --> Utf8 Class Initialized
INFO - 2016-10-18 16:14:34 --> URI Class Initialized
DEBUG - 2016-10-18 16:14:34 --> No URI present. Default controller set.
INFO - 2016-10-18 16:14:34 --> Router Class Initialized
INFO - 2016-10-18 16:14:34 --> Output Class Initialized
INFO - 2016-10-18 16:14:34 --> Security Class Initialized
DEBUG - 2016-10-18 16:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:14:34 --> Input Class Initialized
INFO - 2016-10-18 16:14:34 --> Language Class Initialized
INFO - 2016-10-18 16:14:34 --> Loader Class Initialized
INFO - 2016-10-18 16:14:34 --> Helper loaded: url_helper
INFO - 2016-10-18 16:14:34 --> Helper loaded: form_helper
INFO - 2016-10-18 16:14:34 --> Database Driver Class Initialized
INFO - 2016-10-18 16:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:14:34 --> Controller Class Initialized
INFO - 2016-10-18 16:14:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:14:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:14:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:14:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:14:34 --> Final output sent to browser
DEBUG - 2016-10-18 16:14:34 --> Total execution time: 0.0048
INFO - 2016-10-18 16:15:06 --> Config Class Initialized
INFO - 2016-10-18 16:15:06 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:15:06 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:15:06 --> Utf8 Class Initialized
INFO - 2016-10-18 16:15:06 --> URI Class Initialized
DEBUG - 2016-10-18 16:15:06 --> No URI present. Default controller set.
INFO - 2016-10-18 16:15:06 --> Router Class Initialized
INFO - 2016-10-18 16:15:06 --> Output Class Initialized
INFO - 2016-10-18 16:15:06 --> Security Class Initialized
DEBUG - 2016-10-18 16:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:15:06 --> Input Class Initialized
INFO - 2016-10-18 16:15:06 --> Language Class Initialized
INFO - 2016-10-18 16:15:06 --> Loader Class Initialized
INFO - 2016-10-18 16:15:06 --> Helper loaded: url_helper
INFO - 2016-10-18 16:15:06 --> Helper loaded: form_helper
INFO - 2016-10-18 16:15:06 --> Database Driver Class Initialized
INFO - 2016-10-18 16:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:15:06 --> Controller Class Initialized
INFO - 2016-10-18 16:15:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:15:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:15:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:15:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:15:06 --> Final output sent to browser
DEBUG - 2016-10-18 16:15:06 --> Total execution time: 0.0046
INFO - 2016-10-18 16:15:33 --> Config Class Initialized
INFO - 2016-10-18 16:15:33 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:15:33 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:15:33 --> Utf8 Class Initialized
INFO - 2016-10-18 16:15:33 --> URI Class Initialized
DEBUG - 2016-10-18 16:15:33 --> No URI present. Default controller set.
INFO - 2016-10-18 16:15:33 --> Router Class Initialized
INFO - 2016-10-18 16:15:33 --> Output Class Initialized
INFO - 2016-10-18 16:15:33 --> Security Class Initialized
DEBUG - 2016-10-18 16:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:15:33 --> Input Class Initialized
INFO - 2016-10-18 16:15:33 --> Language Class Initialized
INFO - 2016-10-18 16:15:33 --> Loader Class Initialized
INFO - 2016-10-18 16:15:33 --> Helper loaded: url_helper
INFO - 2016-10-18 16:15:33 --> Helper loaded: form_helper
INFO - 2016-10-18 16:15:33 --> Database Driver Class Initialized
INFO - 2016-10-18 16:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:15:33 --> Controller Class Initialized
INFO - 2016-10-18 16:15:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:15:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:15:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:15:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:15:33 --> Final output sent to browser
DEBUG - 2016-10-18 16:15:33 --> Total execution time: 0.0077
INFO - 2016-10-18 16:17:12 --> Config Class Initialized
INFO - 2016-10-18 16:17:12 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:17:12 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:17:12 --> Utf8 Class Initialized
INFO - 2016-10-18 16:17:12 --> URI Class Initialized
DEBUG - 2016-10-18 16:17:12 --> No URI present. Default controller set.
INFO - 2016-10-18 16:17:12 --> Router Class Initialized
INFO - 2016-10-18 16:17:12 --> Output Class Initialized
INFO - 2016-10-18 16:17:12 --> Security Class Initialized
DEBUG - 2016-10-18 16:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:17:12 --> Input Class Initialized
INFO - 2016-10-18 16:17:12 --> Language Class Initialized
INFO - 2016-10-18 16:17:12 --> Loader Class Initialized
INFO - 2016-10-18 16:17:12 --> Helper loaded: url_helper
INFO - 2016-10-18 16:17:12 --> Helper loaded: form_helper
INFO - 2016-10-18 16:17:12 --> Database Driver Class Initialized
INFO - 2016-10-18 16:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:17:12 --> Controller Class Initialized
INFO - 2016-10-18 16:17:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:17:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:17:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:17:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:17:12 --> Final output sent to browser
DEBUG - 2016-10-18 16:17:12 --> Total execution time: 0.0062
INFO - 2016-10-18 16:18:10 --> Config Class Initialized
INFO - 2016-10-18 16:18:10 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:18:10 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:18:10 --> Utf8 Class Initialized
INFO - 2016-10-18 16:18:10 --> URI Class Initialized
INFO - 2016-10-18 16:18:10 --> Router Class Initialized
INFO - 2016-10-18 16:18:10 --> Output Class Initialized
INFO - 2016-10-18 16:18:10 --> Security Class Initialized
DEBUG - 2016-10-18 16:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:18:10 --> Input Class Initialized
INFO - 2016-10-18 16:18:10 --> Language Class Initialized
INFO - 2016-10-18 16:18:10 --> Loader Class Initialized
INFO - 2016-10-18 16:18:10 --> Helper loaded: url_helper
INFO - 2016-10-18 16:18:10 --> Helper loaded: form_helper
INFO - 2016-10-18 16:18:10 --> Database Driver Class Initialized
INFO - 2016-10-18 16:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:18:10 --> Controller Class Initialized
INFO - 2016-10-18 16:18:10 --> Form Validation Class Initialized
INFO - 2016-10-18 16:18:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 16:18:10 --> Final output sent to browser
DEBUG - 2016-10-18 16:18:10 --> Total execution time: 0.0060
INFO - 2016-10-18 16:18:17 --> Config Class Initialized
INFO - 2016-10-18 16:18:17 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:18:17 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:18:17 --> Utf8 Class Initialized
INFO - 2016-10-18 16:18:17 --> URI Class Initialized
DEBUG - 2016-10-18 16:18:17 --> No URI present. Default controller set.
INFO - 2016-10-18 16:18:17 --> Router Class Initialized
INFO - 2016-10-18 16:18:17 --> Output Class Initialized
INFO - 2016-10-18 16:18:17 --> Security Class Initialized
DEBUG - 2016-10-18 16:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:18:17 --> Input Class Initialized
INFO - 2016-10-18 16:18:17 --> Language Class Initialized
INFO - 2016-10-18 16:18:17 --> Loader Class Initialized
INFO - 2016-10-18 16:18:17 --> Helper loaded: url_helper
INFO - 2016-10-18 16:18:17 --> Helper loaded: form_helper
INFO - 2016-10-18 16:18:17 --> Database Driver Class Initialized
INFO - 2016-10-18 16:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:18:17 --> Controller Class Initialized
INFO - 2016-10-18 16:18:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:18:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:18:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:18:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:18:17 --> Final output sent to browser
DEBUG - 2016-10-18 16:18:17 --> Total execution time: 0.0056
INFO - 2016-10-18 16:19:55 --> Config Class Initialized
INFO - 2016-10-18 16:19:55 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:19:55 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:19:55 --> Utf8 Class Initialized
INFO - 2016-10-18 16:19:55 --> URI Class Initialized
DEBUG - 2016-10-18 16:19:55 --> No URI present. Default controller set.
INFO - 2016-10-18 16:19:55 --> Router Class Initialized
INFO - 2016-10-18 16:19:55 --> Output Class Initialized
INFO - 2016-10-18 16:19:55 --> Security Class Initialized
DEBUG - 2016-10-18 16:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:19:55 --> Input Class Initialized
INFO - 2016-10-18 16:19:55 --> Language Class Initialized
INFO - 2016-10-18 16:19:55 --> Loader Class Initialized
INFO - 2016-10-18 16:19:55 --> Helper loaded: url_helper
INFO - 2016-10-18 16:19:55 --> Helper loaded: form_helper
INFO - 2016-10-18 16:19:55 --> Database Driver Class Initialized
INFO - 2016-10-18 16:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:19:55 --> Controller Class Initialized
INFO - 2016-10-18 16:19:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:19:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:19:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:19:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:19:55 --> Final output sent to browser
DEBUG - 2016-10-18 16:19:55 --> Total execution time: 0.0049
INFO - 2016-10-18 16:21:09 --> Config Class Initialized
INFO - 2016-10-18 16:21:09 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:21:09 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:21:09 --> Utf8 Class Initialized
INFO - 2016-10-18 16:21:09 --> URI Class Initialized
DEBUG - 2016-10-18 16:21:09 --> No URI present. Default controller set.
INFO - 2016-10-18 16:21:09 --> Router Class Initialized
INFO - 2016-10-18 16:21:09 --> Output Class Initialized
INFO - 2016-10-18 16:21:09 --> Security Class Initialized
DEBUG - 2016-10-18 16:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:21:09 --> Input Class Initialized
INFO - 2016-10-18 16:21:09 --> Language Class Initialized
INFO - 2016-10-18 16:21:09 --> Loader Class Initialized
INFO - 2016-10-18 16:21:09 --> Helper loaded: url_helper
INFO - 2016-10-18 16:21:09 --> Helper loaded: form_helper
INFO - 2016-10-18 16:21:09 --> Database Driver Class Initialized
INFO - 2016-10-18 16:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:21:09 --> Controller Class Initialized
INFO - 2016-10-18 16:21:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:21:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:21:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:21:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:21:09 --> Final output sent to browser
DEBUG - 2016-10-18 16:21:09 --> Total execution time: 0.0080
INFO - 2016-10-18 16:21:34 --> Config Class Initialized
INFO - 2016-10-18 16:21:34 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:21:34 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:21:34 --> Utf8 Class Initialized
INFO - 2016-10-18 16:21:34 --> URI Class Initialized
DEBUG - 2016-10-18 16:21:34 --> No URI present. Default controller set.
INFO - 2016-10-18 16:21:34 --> Router Class Initialized
INFO - 2016-10-18 16:21:34 --> Output Class Initialized
INFO - 2016-10-18 16:21:34 --> Security Class Initialized
DEBUG - 2016-10-18 16:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:21:34 --> Input Class Initialized
INFO - 2016-10-18 16:21:34 --> Language Class Initialized
INFO - 2016-10-18 16:21:34 --> Loader Class Initialized
INFO - 2016-10-18 16:21:34 --> Helper loaded: url_helper
INFO - 2016-10-18 16:21:34 --> Helper loaded: form_helper
INFO - 2016-10-18 16:21:34 --> Database Driver Class Initialized
INFO - 2016-10-18 16:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:21:34 --> Controller Class Initialized
INFO - 2016-10-18 16:21:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:21:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:21:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:21:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:21:34 --> Final output sent to browser
DEBUG - 2016-10-18 16:21:34 --> Total execution time: 0.0056
INFO - 2016-10-18 16:22:07 --> Config Class Initialized
INFO - 2016-10-18 16:22:07 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:22:07 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:22:07 --> Utf8 Class Initialized
INFO - 2016-10-18 16:22:07 --> URI Class Initialized
INFO - 2016-10-18 16:22:07 --> Router Class Initialized
INFO - 2016-10-18 16:22:07 --> Output Class Initialized
INFO - 2016-10-18 16:22:07 --> Security Class Initialized
DEBUG - 2016-10-18 16:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:22:07 --> Input Class Initialized
INFO - 2016-10-18 16:22:07 --> Language Class Initialized
INFO - 2016-10-18 16:22:07 --> Loader Class Initialized
INFO - 2016-10-18 16:22:07 --> Helper loaded: url_helper
INFO - 2016-10-18 16:22:07 --> Helper loaded: form_helper
INFO - 2016-10-18 16:22:07 --> Database Driver Class Initialized
INFO - 2016-10-18 16:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:22:07 --> Controller Class Initialized
INFO - 2016-10-18 16:22:07 --> Form Validation Class Initialized
INFO - 2016-10-18 16:22:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 16:22:07 --> Final output sent to browser
DEBUG - 2016-10-18 16:22:07 --> Total execution time: 0.0063
INFO - 2016-10-18 16:22:10 --> Config Class Initialized
INFO - 2016-10-18 16:22:10 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:22:10 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:22:10 --> Utf8 Class Initialized
INFO - 2016-10-18 16:22:10 --> URI Class Initialized
DEBUG - 2016-10-18 16:22:10 --> No URI present. Default controller set.
INFO - 2016-10-18 16:22:10 --> Router Class Initialized
INFO - 2016-10-18 16:22:10 --> Output Class Initialized
INFO - 2016-10-18 16:22:10 --> Security Class Initialized
DEBUG - 2016-10-18 16:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:22:10 --> Input Class Initialized
INFO - 2016-10-18 16:22:10 --> Language Class Initialized
INFO - 2016-10-18 16:22:10 --> Loader Class Initialized
INFO - 2016-10-18 16:22:10 --> Helper loaded: url_helper
INFO - 2016-10-18 16:22:10 --> Helper loaded: form_helper
INFO - 2016-10-18 16:22:10 --> Database Driver Class Initialized
INFO - 2016-10-18 16:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:22:10 --> Controller Class Initialized
INFO - 2016-10-18 16:22:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:22:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:22:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:22:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:22:10 --> Final output sent to browser
DEBUG - 2016-10-18 16:22:10 --> Total execution time: 0.0049
INFO - 2016-10-18 16:23:04 --> Config Class Initialized
INFO - 2016-10-18 16:23:04 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:23:04 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:23:04 --> Utf8 Class Initialized
INFO - 2016-10-18 16:23:04 --> URI Class Initialized
DEBUG - 2016-10-18 16:23:04 --> No URI present. Default controller set.
INFO - 2016-10-18 16:23:04 --> Router Class Initialized
INFO - 2016-10-18 16:23:04 --> Output Class Initialized
INFO - 2016-10-18 16:23:04 --> Security Class Initialized
DEBUG - 2016-10-18 16:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:23:04 --> Input Class Initialized
INFO - 2016-10-18 16:23:04 --> Language Class Initialized
INFO - 2016-10-18 16:23:04 --> Loader Class Initialized
INFO - 2016-10-18 16:23:04 --> Helper loaded: url_helper
INFO - 2016-10-18 16:23:04 --> Helper loaded: form_helper
INFO - 2016-10-18 16:23:04 --> Database Driver Class Initialized
INFO - 2016-10-18 16:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:23:04 --> Controller Class Initialized
INFO - 2016-10-18 16:23:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:23:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:23:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:23:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:23:04 --> Final output sent to browser
DEBUG - 2016-10-18 16:23:04 --> Total execution time: 0.0083
INFO - 2016-10-18 16:25:31 --> Config Class Initialized
INFO - 2016-10-18 16:25:31 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:25:31 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:25:31 --> Utf8 Class Initialized
INFO - 2016-10-18 16:25:31 --> URI Class Initialized
DEBUG - 2016-10-18 16:25:31 --> No URI present. Default controller set.
INFO - 2016-10-18 16:25:31 --> Router Class Initialized
INFO - 2016-10-18 16:25:31 --> Output Class Initialized
INFO - 2016-10-18 16:25:31 --> Security Class Initialized
DEBUG - 2016-10-18 16:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:25:31 --> Input Class Initialized
INFO - 2016-10-18 16:25:31 --> Language Class Initialized
INFO - 2016-10-18 16:25:31 --> Loader Class Initialized
INFO - 2016-10-18 16:25:31 --> Helper loaded: url_helper
INFO - 2016-10-18 16:25:31 --> Helper loaded: form_helper
INFO - 2016-10-18 16:25:31 --> Database Driver Class Initialized
INFO - 2016-10-18 16:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:25:31 --> Controller Class Initialized
INFO - 2016-10-18 16:25:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:25:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:25:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:25:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:25:31 --> Final output sent to browser
DEBUG - 2016-10-18 16:25:31 --> Total execution time: 0.0085
INFO - 2016-10-18 16:25:34 --> Config Class Initialized
INFO - 2016-10-18 16:25:34 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:25:34 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:25:34 --> Utf8 Class Initialized
INFO - 2016-10-18 16:25:34 --> URI Class Initialized
DEBUG - 2016-10-18 16:25:34 --> No URI present. Default controller set.
INFO - 2016-10-18 16:25:34 --> Router Class Initialized
INFO - 2016-10-18 16:25:34 --> Output Class Initialized
INFO - 2016-10-18 16:25:34 --> Security Class Initialized
DEBUG - 2016-10-18 16:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:25:34 --> Input Class Initialized
INFO - 2016-10-18 16:25:34 --> Language Class Initialized
INFO - 2016-10-18 16:25:34 --> Loader Class Initialized
INFO - 2016-10-18 16:25:34 --> Helper loaded: url_helper
INFO - 2016-10-18 16:25:34 --> Helper loaded: form_helper
INFO - 2016-10-18 16:25:34 --> Database Driver Class Initialized
INFO - 2016-10-18 16:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:25:34 --> Controller Class Initialized
INFO - 2016-10-18 16:25:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:25:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:25:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:25:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:25:34 --> Final output sent to browser
DEBUG - 2016-10-18 16:25:34 --> Total execution time: 0.0054
INFO - 2016-10-18 16:25:58 --> Config Class Initialized
INFO - 2016-10-18 16:25:58 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:25:58 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:25:58 --> Utf8 Class Initialized
INFO - 2016-10-18 16:25:58 --> URI Class Initialized
DEBUG - 2016-10-18 16:25:58 --> No URI present. Default controller set.
INFO - 2016-10-18 16:25:58 --> Router Class Initialized
INFO - 2016-10-18 16:25:58 --> Output Class Initialized
INFO - 2016-10-18 16:25:58 --> Security Class Initialized
DEBUG - 2016-10-18 16:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:25:58 --> Input Class Initialized
INFO - 2016-10-18 16:25:58 --> Language Class Initialized
INFO - 2016-10-18 16:25:58 --> Loader Class Initialized
INFO - 2016-10-18 16:25:58 --> Helper loaded: url_helper
INFO - 2016-10-18 16:25:58 --> Helper loaded: form_helper
INFO - 2016-10-18 16:25:58 --> Database Driver Class Initialized
INFO - 2016-10-18 16:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:25:58 --> Controller Class Initialized
INFO - 2016-10-18 16:25:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:25:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:25:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:25:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:25:58 --> Final output sent to browser
DEBUG - 2016-10-18 16:25:58 --> Total execution time: 0.0054
INFO - 2016-10-18 16:26:33 --> Config Class Initialized
INFO - 2016-10-18 16:26:33 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:26:33 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:26:33 --> Utf8 Class Initialized
INFO - 2016-10-18 16:26:33 --> URI Class Initialized
DEBUG - 2016-10-18 16:26:33 --> No URI present. Default controller set.
INFO - 2016-10-18 16:26:33 --> Router Class Initialized
INFO - 2016-10-18 16:26:33 --> Output Class Initialized
INFO - 2016-10-18 16:26:33 --> Security Class Initialized
DEBUG - 2016-10-18 16:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:26:33 --> Input Class Initialized
INFO - 2016-10-18 16:26:33 --> Language Class Initialized
INFO - 2016-10-18 16:26:33 --> Loader Class Initialized
INFO - 2016-10-18 16:26:33 --> Helper loaded: url_helper
INFO - 2016-10-18 16:26:33 --> Helper loaded: form_helper
INFO - 2016-10-18 16:26:33 --> Database Driver Class Initialized
INFO - 2016-10-18 16:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:26:33 --> Controller Class Initialized
INFO - 2016-10-18 16:26:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:26:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:26:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:26:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:26:33 --> Final output sent to browser
DEBUG - 2016-10-18 16:26:33 --> Total execution time: 0.0075
INFO - 2016-10-18 16:26:47 --> Config Class Initialized
INFO - 2016-10-18 16:26:47 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:26:47 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:26:47 --> Utf8 Class Initialized
INFO - 2016-10-18 16:26:47 --> URI Class Initialized
DEBUG - 2016-10-18 16:26:47 --> No URI present. Default controller set.
INFO - 2016-10-18 16:26:47 --> Router Class Initialized
INFO - 2016-10-18 16:26:47 --> Output Class Initialized
INFO - 2016-10-18 16:26:47 --> Security Class Initialized
DEBUG - 2016-10-18 16:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:26:47 --> Input Class Initialized
INFO - 2016-10-18 16:26:47 --> Language Class Initialized
INFO - 2016-10-18 16:26:47 --> Loader Class Initialized
INFO - 2016-10-18 16:26:47 --> Helper loaded: url_helper
INFO - 2016-10-18 16:26:47 --> Helper loaded: form_helper
INFO - 2016-10-18 16:26:47 --> Database Driver Class Initialized
INFO - 2016-10-18 16:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:26:47 --> Controller Class Initialized
INFO - 2016-10-18 16:26:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:26:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:26:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:26:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:26:47 --> Final output sent to browser
DEBUG - 2016-10-18 16:26:47 --> Total execution time: 0.0073
INFO - 2016-10-18 16:26:54 --> Config Class Initialized
INFO - 2016-10-18 16:26:54 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:26:54 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:26:54 --> Utf8 Class Initialized
INFO - 2016-10-18 16:26:54 --> URI Class Initialized
DEBUG - 2016-10-18 16:26:54 --> No URI present. Default controller set.
INFO - 2016-10-18 16:26:54 --> Router Class Initialized
INFO - 2016-10-18 16:26:54 --> Output Class Initialized
INFO - 2016-10-18 16:26:54 --> Security Class Initialized
DEBUG - 2016-10-18 16:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:26:54 --> Input Class Initialized
INFO - 2016-10-18 16:26:54 --> Language Class Initialized
INFO - 2016-10-18 16:26:54 --> Loader Class Initialized
INFO - 2016-10-18 16:26:54 --> Helper loaded: url_helper
INFO - 2016-10-18 16:26:54 --> Helper loaded: form_helper
INFO - 2016-10-18 16:26:54 --> Database Driver Class Initialized
INFO - 2016-10-18 16:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:26:54 --> Controller Class Initialized
INFO - 2016-10-18 16:26:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:26:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:26:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:26:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:26:54 --> Final output sent to browser
DEBUG - 2016-10-18 16:26:54 --> Total execution time: 0.0049
INFO - 2016-10-18 16:27:38 --> Config Class Initialized
INFO - 2016-10-18 16:27:38 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:27:38 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:27:38 --> Utf8 Class Initialized
INFO - 2016-10-18 16:27:38 --> URI Class Initialized
DEBUG - 2016-10-18 16:27:38 --> No URI present. Default controller set.
INFO - 2016-10-18 16:27:38 --> Router Class Initialized
INFO - 2016-10-18 16:27:38 --> Output Class Initialized
INFO - 2016-10-18 16:27:38 --> Security Class Initialized
DEBUG - 2016-10-18 16:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:27:38 --> Input Class Initialized
INFO - 2016-10-18 16:27:38 --> Language Class Initialized
INFO - 2016-10-18 16:27:38 --> Loader Class Initialized
INFO - 2016-10-18 16:27:38 --> Helper loaded: url_helper
INFO - 2016-10-18 16:27:38 --> Helper loaded: form_helper
INFO - 2016-10-18 16:27:38 --> Database Driver Class Initialized
INFO - 2016-10-18 16:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:27:38 --> Controller Class Initialized
INFO - 2016-10-18 16:27:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:27:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:27:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:27:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:27:38 --> Final output sent to browser
DEBUG - 2016-10-18 16:27:38 --> Total execution time: 0.0053
INFO - 2016-10-18 16:28:14 --> Config Class Initialized
INFO - 2016-10-18 16:28:14 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:28:14 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:28:14 --> Utf8 Class Initialized
INFO - 2016-10-18 16:28:14 --> URI Class Initialized
DEBUG - 2016-10-18 16:28:14 --> No URI present. Default controller set.
INFO - 2016-10-18 16:28:14 --> Router Class Initialized
INFO - 2016-10-18 16:28:14 --> Output Class Initialized
INFO - 2016-10-18 16:28:14 --> Security Class Initialized
DEBUG - 2016-10-18 16:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:28:14 --> Input Class Initialized
INFO - 2016-10-18 16:28:14 --> Language Class Initialized
INFO - 2016-10-18 16:28:14 --> Loader Class Initialized
INFO - 2016-10-18 16:28:14 --> Helper loaded: url_helper
INFO - 2016-10-18 16:28:14 --> Helper loaded: form_helper
INFO - 2016-10-18 16:28:14 --> Database Driver Class Initialized
INFO - 2016-10-18 16:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:28:14 --> Controller Class Initialized
INFO - 2016-10-18 16:28:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:28:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:28:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:28:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:28:14 --> Final output sent to browser
DEBUG - 2016-10-18 16:28:14 --> Total execution time: 0.0052
INFO - 2016-10-18 16:28:24 --> Config Class Initialized
INFO - 2016-10-18 16:28:24 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:28:24 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:28:24 --> Utf8 Class Initialized
INFO - 2016-10-18 16:28:24 --> URI Class Initialized
DEBUG - 2016-10-18 16:28:24 --> No URI present. Default controller set.
INFO - 2016-10-18 16:28:24 --> Router Class Initialized
INFO - 2016-10-18 16:28:24 --> Output Class Initialized
INFO - 2016-10-18 16:28:24 --> Security Class Initialized
DEBUG - 2016-10-18 16:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:28:24 --> Input Class Initialized
INFO - 2016-10-18 16:28:24 --> Language Class Initialized
INFO - 2016-10-18 16:28:24 --> Loader Class Initialized
INFO - 2016-10-18 16:28:24 --> Helper loaded: url_helper
INFO - 2016-10-18 16:28:24 --> Helper loaded: form_helper
INFO - 2016-10-18 16:28:24 --> Database Driver Class Initialized
INFO - 2016-10-18 16:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:28:24 --> Controller Class Initialized
INFO - 2016-10-18 16:28:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:28:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:28:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:28:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:28:24 --> Final output sent to browser
DEBUG - 2016-10-18 16:28:24 --> Total execution time: 0.0073
INFO - 2016-10-18 16:29:10 --> Config Class Initialized
INFO - 2016-10-18 16:29:10 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:29:10 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:29:10 --> Utf8 Class Initialized
INFO - 2016-10-18 16:29:10 --> URI Class Initialized
DEBUG - 2016-10-18 16:29:10 --> No URI present. Default controller set.
INFO - 2016-10-18 16:29:10 --> Router Class Initialized
INFO - 2016-10-18 16:29:10 --> Output Class Initialized
INFO - 2016-10-18 16:29:10 --> Security Class Initialized
DEBUG - 2016-10-18 16:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:29:10 --> Input Class Initialized
INFO - 2016-10-18 16:29:10 --> Language Class Initialized
INFO - 2016-10-18 16:29:10 --> Loader Class Initialized
INFO - 2016-10-18 16:29:10 --> Helper loaded: url_helper
INFO - 2016-10-18 16:29:10 --> Helper loaded: form_helper
INFO - 2016-10-18 16:29:10 --> Database Driver Class Initialized
INFO - 2016-10-18 16:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:29:10 --> Controller Class Initialized
INFO - 2016-10-18 16:29:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:29:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:29:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:29:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:29:10 --> Final output sent to browser
DEBUG - 2016-10-18 16:29:10 --> Total execution time: 0.0053
INFO - 2016-10-18 16:29:14 --> Config Class Initialized
INFO - 2016-10-18 16:29:14 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:29:14 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:29:14 --> Utf8 Class Initialized
INFO - 2016-10-18 16:29:14 --> URI Class Initialized
DEBUG - 2016-10-18 16:29:14 --> No URI present. Default controller set.
INFO - 2016-10-18 16:29:14 --> Router Class Initialized
INFO - 2016-10-18 16:29:14 --> Output Class Initialized
INFO - 2016-10-18 16:29:14 --> Security Class Initialized
DEBUG - 2016-10-18 16:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:29:14 --> Input Class Initialized
INFO - 2016-10-18 16:29:14 --> Language Class Initialized
INFO - 2016-10-18 16:29:14 --> Loader Class Initialized
INFO - 2016-10-18 16:29:14 --> Helper loaded: url_helper
INFO - 2016-10-18 16:29:14 --> Helper loaded: form_helper
INFO - 2016-10-18 16:29:14 --> Database Driver Class Initialized
INFO - 2016-10-18 16:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:29:14 --> Controller Class Initialized
INFO - 2016-10-18 16:29:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:29:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:29:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:29:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:29:14 --> Final output sent to browser
DEBUG - 2016-10-18 16:29:14 --> Total execution time: 0.0052
INFO - 2016-10-18 16:29:59 --> Config Class Initialized
INFO - 2016-10-18 16:29:59 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:29:59 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:29:59 --> Utf8 Class Initialized
INFO - 2016-10-18 16:29:59 --> URI Class Initialized
DEBUG - 2016-10-18 16:29:59 --> No URI present. Default controller set.
INFO - 2016-10-18 16:29:59 --> Router Class Initialized
INFO - 2016-10-18 16:29:59 --> Output Class Initialized
INFO - 2016-10-18 16:29:59 --> Security Class Initialized
DEBUG - 2016-10-18 16:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:29:59 --> Input Class Initialized
INFO - 2016-10-18 16:29:59 --> Language Class Initialized
INFO - 2016-10-18 16:29:59 --> Loader Class Initialized
INFO - 2016-10-18 16:29:59 --> Helper loaded: url_helper
INFO - 2016-10-18 16:29:59 --> Helper loaded: form_helper
INFO - 2016-10-18 16:29:59 --> Database Driver Class Initialized
INFO - 2016-10-18 16:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:29:59 --> Controller Class Initialized
INFO - 2016-10-18 16:29:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:29:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:29:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:29:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:29:59 --> Final output sent to browser
DEBUG - 2016-10-18 16:29:59 --> Total execution time: 0.0075
INFO - 2016-10-18 16:32:28 --> Config Class Initialized
INFO - 2016-10-18 16:32:28 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:32:28 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:32:28 --> Utf8 Class Initialized
INFO - 2016-10-18 16:32:28 --> URI Class Initialized
DEBUG - 2016-10-18 16:32:28 --> No URI present. Default controller set.
INFO - 2016-10-18 16:32:28 --> Router Class Initialized
INFO - 2016-10-18 16:32:28 --> Output Class Initialized
INFO - 2016-10-18 16:32:28 --> Security Class Initialized
DEBUG - 2016-10-18 16:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:32:28 --> Input Class Initialized
INFO - 2016-10-18 16:32:28 --> Language Class Initialized
INFO - 2016-10-18 16:32:28 --> Loader Class Initialized
INFO - 2016-10-18 16:32:28 --> Helper loaded: url_helper
INFO - 2016-10-18 16:32:28 --> Helper loaded: form_helper
INFO - 2016-10-18 16:32:28 --> Database Driver Class Initialized
INFO - 2016-10-18 16:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:32:28 --> Controller Class Initialized
INFO - 2016-10-18 16:32:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:32:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:32:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:32:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:32:28 --> Final output sent to browser
DEBUG - 2016-10-18 16:32:28 --> Total execution time: 0.0055
INFO - 2016-10-18 16:32:51 --> Config Class Initialized
INFO - 2016-10-18 16:32:51 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:32:51 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:32:51 --> Utf8 Class Initialized
INFO - 2016-10-18 16:32:51 --> URI Class Initialized
INFO - 2016-10-18 16:32:51 --> Router Class Initialized
INFO - 2016-10-18 16:32:51 --> Output Class Initialized
INFO - 2016-10-18 16:32:51 --> Security Class Initialized
DEBUG - 2016-10-18 16:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:32:51 --> Input Class Initialized
INFO - 2016-10-18 16:32:51 --> Language Class Initialized
INFO - 2016-10-18 16:32:51 --> Loader Class Initialized
INFO - 2016-10-18 16:32:51 --> Helper loaded: url_helper
INFO - 2016-10-18 16:32:51 --> Helper loaded: form_helper
INFO - 2016-10-18 16:32:51 --> Database Driver Class Initialized
INFO - 2016-10-18 16:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:32:51 --> Controller Class Initialized
INFO - 2016-10-18 16:32:51 --> Form Validation Class Initialized
INFO - 2016-10-18 16:32:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 16:32:51 --> Final output sent to browser
DEBUG - 2016-10-18 16:32:51 --> Total execution time: 0.0065
INFO - 2016-10-18 16:39:49 --> Config Class Initialized
INFO - 2016-10-18 16:39:49 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:39:49 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:39:49 --> Utf8 Class Initialized
INFO - 2016-10-18 16:39:49 --> URI Class Initialized
DEBUG - 2016-10-18 16:39:49 --> No URI present. Default controller set.
INFO - 2016-10-18 16:39:49 --> Router Class Initialized
INFO - 2016-10-18 16:39:49 --> Output Class Initialized
INFO - 2016-10-18 16:39:49 --> Security Class Initialized
DEBUG - 2016-10-18 16:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:39:49 --> Input Class Initialized
INFO - 2016-10-18 16:39:49 --> Language Class Initialized
INFO - 2016-10-18 16:39:49 --> Loader Class Initialized
INFO - 2016-10-18 16:39:49 --> Helper loaded: url_helper
INFO - 2016-10-18 16:39:49 --> Helper loaded: form_helper
INFO - 2016-10-18 16:39:49 --> Database Driver Class Initialized
INFO - 2016-10-18 16:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:39:49 --> Controller Class Initialized
INFO - 2016-10-18 16:39:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:39:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:39:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:39:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:39:49 --> Final output sent to browser
DEBUG - 2016-10-18 16:39:49 --> Total execution time: 0.0062
INFO - 2016-10-18 16:39:51 --> Config Class Initialized
INFO - 2016-10-18 16:39:51 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:39:51 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:39:51 --> Utf8 Class Initialized
INFO - 2016-10-18 16:39:51 --> URI Class Initialized
INFO - 2016-10-18 16:39:51 --> Router Class Initialized
INFO - 2016-10-18 16:39:51 --> Output Class Initialized
INFO - 2016-10-18 16:39:51 --> Security Class Initialized
DEBUG - 2016-10-18 16:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:39:51 --> Input Class Initialized
INFO - 2016-10-18 16:39:51 --> Language Class Initialized
INFO - 2016-10-18 16:39:51 --> Loader Class Initialized
INFO - 2016-10-18 16:39:51 --> Helper loaded: url_helper
INFO - 2016-10-18 16:39:51 --> Helper loaded: form_helper
INFO - 2016-10-18 16:39:51 --> Database Driver Class Initialized
INFO - 2016-10-18 16:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:39:51 --> Controller Class Initialized
INFO - 2016-10-18 16:39:51 --> Form Validation Class Initialized
INFO - 2016-10-18 16:39:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 16:39:51 --> Final output sent to browser
DEBUG - 2016-10-18 16:39:51 --> Total execution time: 0.0065
INFO - 2016-10-18 16:40:18 --> Config Class Initialized
INFO - 2016-10-18 16:40:18 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:40:18 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:40:18 --> Utf8 Class Initialized
INFO - 2016-10-18 16:40:18 --> URI Class Initialized
DEBUG - 2016-10-18 16:40:18 --> No URI present. Default controller set.
INFO - 2016-10-18 16:40:18 --> Router Class Initialized
INFO - 2016-10-18 16:40:18 --> Output Class Initialized
INFO - 2016-10-18 16:40:18 --> Security Class Initialized
DEBUG - 2016-10-18 16:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:40:18 --> Input Class Initialized
INFO - 2016-10-18 16:40:18 --> Language Class Initialized
INFO - 2016-10-18 16:40:18 --> Loader Class Initialized
INFO - 2016-10-18 16:40:18 --> Helper loaded: url_helper
INFO - 2016-10-18 16:40:18 --> Helper loaded: form_helper
INFO - 2016-10-18 16:40:18 --> Database Driver Class Initialized
INFO - 2016-10-18 16:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:40:18 --> Controller Class Initialized
INFO - 2016-10-18 16:40:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:40:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:40:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:40:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:40:18 --> Final output sent to browser
DEBUG - 2016-10-18 16:40:18 --> Total execution time: 0.0089
INFO - 2016-10-18 16:40:20 --> Config Class Initialized
INFO - 2016-10-18 16:40:20 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:40:20 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:40:20 --> Utf8 Class Initialized
INFO - 2016-10-18 16:40:20 --> URI Class Initialized
INFO - 2016-10-18 16:40:20 --> Router Class Initialized
INFO - 2016-10-18 16:40:20 --> Output Class Initialized
INFO - 2016-10-18 16:40:20 --> Security Class Initialized
DEBUG - 2016-10-18 16:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:40:20 --> Input Class Initialized
INFO - 2016-10-18 16:40:20 --> Language Class Initialized
INFO - 2016-10-18 16:40:20 --> Loader Class Initialized
INFO - 2016-10-18 16:40:20 --> Helper loaded: url_helper
INFO - 2016-10-18 16:40:20 --> Helper loaded: form_helper
INFO - 2016-10-18 16:40:20 --> Database Driver Class Initialized
INFO - 2016-10-18 16:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:40:20 --> Controller Class Initialized
INFO - 2016-10-18 16:40:20 --> Form Validation Class Initialized
INFO - 2016-10-18 16:40:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 16:40:20 --> Final output sent to browser
DEBUG - 2016-10-18 16:40:20 --> Total execution time: 0.0098
INFO - 2016-10-18 16:40:23 --> Config Class Initialized
INFO - 2016-10-18 16:40:23 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:40:23 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:40:23 --> Utf8 Class Initialized
INFO - 2016-10-18 16:40:23 --> URI Class Initialized
DEBUG - 2016-10-18 16:40:23 --> No URI present. Default controller set.
INFO - 2016-10-18 16:40:23 --> Router Class Initialized
INFO - 2016-10-18 16:40:23 --> Output Class Initialized
INFO - 2016-10-18 16:40:23 --> Security Class Initialized
DEBUG - 2016-10-18 16:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:40:23 --> Input Class Initialized
INFO - 2016-10-18 16:40:23 --> Language Class Initialized
INFO - 2016-10-18 16:40:23 --> Loader Class Initialized
INFO - 2016-10-18 16:40:23 --> Helper loaded: url_helper
INFO - 2016-10-18 16:40:23 --> Helper loaded: form_helper
INFO - 2016-10-18 16:40:23 --> Database Driver Class Initialized
INFO - 2016-10-18 16:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:40:23 --> Controller Class Initialized
INFO - 2016-10-18 16:40:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:40:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:40:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:40:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:40:23 --> Final output sent to browser
DEBUG - 2016-10-18 16:40:23 --> Total execution time: 0.0055
INFO - 2016-10-18 16:40:39 --> Config Class Initialized
INFO - 2016-10-18 16:40:39 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:40:39 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:40:39 --> Utf8 Class Initialized
INFO - 2016-10-18 16:40:39 --> URI Class Initialized
INFO - 2016-10-18 16:40:39 --> Router Class Initialized
INFO - 2016-10-18 16:40:39 --> Output Class Initialized
INFO - 2016-10-18 16:40:39 --> Security Class Initialized
DEBUG - 2016-10-18 16:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:40:39 --> Input Class Initialized
INFO - 2016-10-18 16:40:39 --> Language Class Initialized
INFO - 2016-10-18 16:40:39 --> Loader Class Initialized
INFO - 2016-10-18 16:40:39 --> Helper loaded: url_helper
INFO - 2016-10-18 16:40:39 --> Helper loaded: form_helper
INFO - 2016-10-18 16:40:39 --> Database Driver Class Initialized
INFO - 2016-10-18 16:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:40:39 --> Controller Class Initialized
INFO - 2016-10-18 16:40:39 --> Form Validation Class Initialized
INFO - 2016-10-18 16:40:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 16:40:39 --> Final output sent to browser
DEBUG - 2016-10-18 16:40:39 --> Total execution time: 0.0093
INFO - 2016-10-18 16:40:42 --> Config Class Initialized
INFO - 2016-10-18 16:40:42 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:40:42 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:40:42 --> Utf8 Class Initialized
INFO - 2016-10-18 16:40:42 --> URI Class Initialized
DEBUG - 2016-10-18 16:40:42 --> No URI present. Default controller set.
INFO - 2016-10-18 16:40:42 --> Router Class Initialized
INFO - 2016-10-18 16:40:42 --> Output Class Initialized
INFO - 2016-10-18 16:40:42 --> Security Class Initialized
DEBUG - 2016-10-18 16:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:40:42 --> Input Class Initialized
INFO - 2016-10-18 16:40:42 --> Language Class Initialized
INFO - 2016-10-18 16:40:42 --> Loader Class Initialized
INFO - 2016-10-18 16:40:42 --> Helper loaded: url_helper
INFO - 2016-10-18 16:40:42 --> Helper loaded: form_helper
INFO - 2016-10-18 16:40:42 --> Database Driver Class Initialized
INFO - 2016-10-18 16:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:40:42 --> Controller Class Initialized
INFO - 2016-10-18 16:40:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:40:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:40:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:40:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:40:42 --> Final output sent to browser
DEBUG - 2016-10-18 16:40:42 --> Total execution time: 0.0049
INFO - 2016-10-18 16:41:00 --> Config Class Initialized
INFO - 2016-10-18 16:41:00 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:41:00 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:41:00 --> Utf8 Class Initialized
INFO - 2016-10-18 16:41:00 --> URI Class Initialized
DEBUG - 2016-10-18 16:41:00 --> No URI present. Default controller set.
INFO - 2016-10-18 16:41:00 --> Router Class Initialized
INFO - 2016-10-18 16:41:00 --> Output Class Initialized
INFO - 2016-10-18 16:41:00 --> Security Class Initialized
DEBUG - 2016-10-18 16:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:41:00 --> Input Class Initialized
INFO - 2016-10-18 16:41:00 --> Language Class Initialized
INFO - 2016-10-18 16:41:00 --> Loader Class Initialized
INFO - 2016-10-18 16:41:00 --> Helper loaded: url_helper
INFO - 2016-10-18 16:41:00 --> Helper loaded: form_helper
INFO - 2016-10-18 16:41:00 --> Database Driver Class Initialized
INFO - 2016-10-18 16:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:41:00 --> Controller Class Initialized
INFO - 2016-10-18 16:41:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:41:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:41:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:41:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:41:00 --> Final output sent to browser
DEBUG - 2016-10-18 16:41:00 --> Total execution time: 0.0054
INFO - 2016-10-18 16:41:15 --> Config Class Initialized
INFO - 2016-10-18 16:41:15 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:41:15 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:41:15 --> Utf8 Class Initialized
INFO - 2016-10-18 16:41:15 --> URI Class Initialized
INFO - 2016-10-18 16:41:15 --> Router Class Initialized
INFO - 2016-10-18 16:41:15 --> Output Class Initialized
INFO - 2016-10-18 16:41:15 --> Security Class Initialized
DEBUG - 2016-10-18 16:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:41:15 --> Input Class Initialized
INFO - 2016-10-18 16:41:15 --> Language Class Initialized
INFO - 2016-10-18 16:41:15 --> Loader Class Initialized
INFO - 2016-10-18 16:41:15 --> Helper loaded: url_helper
INFO - 2016-10-18 16:41:15 --> Helper loaded: form_helper
INFO - 2016-10-18 16:41:15 --> Database Driver Class Initialized
INFO - 2016-10-18 16:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:41:15 --> Controller Class Initialized
INFO - 2016-10-18 16:41:15 --> Form Validation Class Initialized
INFO - 2016-10-18 16:41:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 16:41:15 --> Final output sent to browser
DEBUG - 2016-10-18 16:41:15 --> Total execution time: 0.0098
INFO - 2016-10-18 16:41:28 --> Config Class Initialized
INFO - 2016-10-18 16:41:28 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:41:28 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:41:28 --> Utf8 Class Initialized
INFO - 2016-10-18 16:41:28 --> URI Class Initialized
INFO - 2016-10-18 16:41:28 --> Router Class Initialized
INFO - 2016-10-18 16:41:28 --> Output Class Initialized
INFO - 2016-10-18 16:41:28 --> Security Class Initialized
DEBUG - 2016-10-18 16:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:41:28 --> Input Class Initialized
INFO - 2016-10-18 16:41:28 --> Language Class Initialized
INFO - 2016-10-18 16:41:28 --> Loader Class Initialized
INFO - 2016-10-18 16:41:28 --> Helper loaded: url_helper
INFO - 2016-10-18 16:41:28 --> Helper loaded: form_helper
INFO - 2016-10-18 16:41:28 --> Database Driver Class Initialized
INFO - 2016-10-18 16:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:41:28 --> Controller Class Initialized
INFO - 2016-10-18 16:41:28 --> Form Validation Class Initialized
INFO - 2016-10-18 16:41:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 16:41:28 --> Final output sent to browser
DEBUG - 2016-10-18 16:41:28 --> Total execution time: 0.0066
INFO - 2016-10-18 16:41:32 --> Config Class Initialized
INFO - 2016-10-18 16:41:32 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:41:32 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:41:32 --> Utf8 Class Initialized
INFO - 2016-10-18 16:41:32 --> URI Class Initialized
INFO - 2016-10-18 16:41:32 --> Router Class Initialized
INFO - 2016-10-18 16:41:32 --> Output Class Initialized
INFO - 2016-10-18 16:41:32 --> Security Class Initialized
DEBUG - 2016-10-18 16:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:41:32 --> Input Class Initialized
INFO - 2016-10-18 16:41:32 --> Language Class Initialized
INFO - 2016-10-18 16:41:32 --> Loader Class Initialized
INFO - 2016-10-18 16:41:32 --> Helper loaded: url_helper
INFO - 2016-10-18 16:41:32 --> Helper loaded: form_helper
INFO - 2016-10-18 16:41:32 --> Database Driver Class Initialized
INFO - 2016-10-18 16:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:41:32 --> Controller Class Initialized
INFO - 2016-10-18 16:41:32 --> Form Validation Class Initialized
INFO - 2016-10-18 16:41:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 16:41:32 --> Final output sent to browser
DEBUG - 2016-10-18 16:41:32 --> Total execution time: 0.0060
INFO - 2016-10-18 16:41:38 --> Config Class Initialized
INFO - 2016-10-18 16:41:38 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:41:38 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:41:38 --> Utf8 Class Initialized
INFO - 2016-10-18 16:41:38 --> URI Class Initialized
INFO - 2016-10-18 16:41:38 --> Router Class Initialized
INFO - 2016-10-18 16:41:38 --> Output Class Initialized
INFO - 2016-10-18 16:41:38 --> Security Class Initialized
DEBUG - 2016-10-18 16:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:41:38 --> Input Class Initialized
INFO - 2016-10-18 16:41:38 --> Language Class Initialized
INFO - 2016-10-18 16:41:38 --> Loader Class Initialized
INFO - 2016-10-18 16:41:38 --> Helper loaded: url_helper
INFO - 2016-10-18 16:41:38 --> Helper loaded: form_helper
INFO - 2016-10-18 16:41:38 --> Database Driver Class Initialized
INFO - 2016-10-18 16:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:41:38 --> Controller Class Initialized
INFO - 2016-10-18 16:41:38 --> Form Validation Class Initialized
INFO - 2016-10-18 16:41:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 16:41:38 --> Final output sent to browser
DEBUG - 2016-10-18 16:41:38 --> Total execution time: 0.0062
INFO - 2016-10-18 16:41:49 --> Config Class Initialized
INFO - 2016-10-18 16:41:49 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:41:49 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:41:49 --> Utf8 Class Initialized
INFO - 2016-10-18 16:41:49 --> URI Class Initialized
DEBUG - 2016-10-18 16:41:49 --> No URI present. Default controller set.
INFO - 2016-10-18 16:41:49 --> Router Class Initialized
INFO - 2016-10-18 16:41:49 --> Output Class Initialized
INFO - 2016-10-18 16:41:49 --> Security Class Initialized
DEBUG - 2016-10-18 16:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:41:49 --> Input Class Initialized
INFO - 2016-10-18 16:41:49 --> Language Class Initialized
INFO - 2016-10-18 16:41:49 --> Loader Class Initialized
INFO - 2016-10-18 16:41:49 --> Helper loaded: url_helper
INFO - 2016-10-18 16:41:49 --> Helper loaded: form_helper
INFO - 2016-10-18 16:41:49 --> Database Driver Class Initialized
INFO - 2016-10-18 16:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:41:49 --> Controller Class Initialized
INFO - 2016-10-18 16:41:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:41:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:41:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:41:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:41:49 --> Final output sent to browser
DEBUG - 2016-10-18 16:41:49 --> Total execution time: 0.0056
INFO - 2016-10-18 16:42:00 --> Config Class Initialized
INFO - 2016-10-18 16:42:00 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:42:00 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:42:00 --> Utf8 Class Initialized
INFO - 2016-10-18 16:42:00 --> URI Class Initialized
INFO - 2016-10-18 16:42:00 --> Router Class Initialized
INFO - 2016-10-18 16:42:00 --> Output Class Initialized
INFO - 2016-10-18 16:42:00 --> Security Class Initialized
DEBUG - 2016-10-18 16:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:42:00 --> Input Class Initialized
INFO - 2016-10-18 16:42:00 --> Language Class Initialized
INFO - 2016-10-18 16:42:00 --> Loader Class Initialized
INFO - 2016-10-18 16:42:00 --> Helper loaded: url_helper
INFO - 2016-10-18 16:42:00 --> Helper loaded: form_helper
INFO - 2016-10-18 16:42:00 --> Database Driver Class Initialized
INFO - 2016-10-18 16:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:42:00 --> Controller Class Initialized
INFO - 2016-10-18 16:42:00 --> Form Validation Class Initialized
INFO - 2016-10-18 16:42:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 16:42:00 --> Final output sent to browser
DEBUG - 2016-10-18 16:42:00 --> Total execution time: 0.0088
INFO - 2016-10-18 16:42:02 --> Config Class Initialized
INFO - 2016-10-18 16:42:02 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:42:02 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:42:02 --> Utf8 Class Initialized
INFO - 2016-10-18 16:42:02 --> URI Class Initialized
INFO - 2016-10-18 16:42:02 --> Router Class Initialized
INFO - 2016-10-18 16:42:02 --> Output Class Initialized
INFO - 2016-10-18 16:42:02 --> Security Class Initialized
DEBUG - 2016-10-18 16:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:42:02 --> Input Class Initialized
INFO - 2016-10-18 16:42:02 --> Language Class Initialized
INFO - 2016-10-18 16:42:02 --> Loader Class Initialized
INFO - 2016-10-18 16:42:02 --> Helper loaded: url_helper
INFO - 2016-10-18 16:42:02 --> Helper loaded: form_helper
INFO - 2016-10-18 16:42:02 --> Database Driver Class Initialized
INFO - 2016-10-18 16:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:42:02 --> Controller Class Initialized
INFO - 2016-10-18 16:42:02 --> Form Validation Class Initialized
INFO - 2016-10-18 16:42:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 16:42:02 --> Final output sent to browser
DEBUG - 2016-10-18 16:42:02 --> Total execution time: 0.0070
INFO - 2016-10-18 16:42:23 --> Config Class Initialized
INFO - 2016-10-18 16:42:23 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:42:23 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:42:23 --> Utf8 Class Initialized
INFO - 2016-10-18 16:42:23 --> URI Class Initialized
INFO - 2016-10-18 16:42:23 --> Router Class Initialized
INFO - 2016-10-18 16:42:23 --> Output Class Initialized
INFO - 2016-10-18 16:42:23 --> Security Class Initialized
DEBUG - 2016-10-18 16:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:42:23 --> Input Class Initialized
INFO - 2016-10-18 16:42:23 --> Language Class Initialized
INFO - 2016-10-18 16:42:23 --> Loader Class Initialized
INFO - 2016-10-18 16:42:23 --> Helper loaded: url_helper
INFO - 2016-10-18 16:42:23 --> Helper loaded: form_helper
INFO - 2016-10-18 16:42:23 --> Database Driver Class Initialized
INFO - 2016-10-18 16:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:42:23 --> Controller Class Initialized
INFO - 2016-10-18 16:42:23 --> Form Validation Class Initialized
INFO - 2016-10-18 16:42:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 16:42:23 --> Final output sent to browser
DEBUG - 2016-10-18 16:42:23 --> Total execution time: 0.0096
INFO - 2016-10-18 16:42:29 --> Config Class Initialized
INFO - 2016-10-18 16:42:29 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:42:29 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:42:29 --> Utf8 Class Initialized
INFO - 2016-10-18 16:42:29 --> URI Class Initialized
DEBUG - 2016-10-18 16:42:29 --> No URI present. Default controller set.
INFO - 2016-10-18 16:42:29 --> Router Class Initialized
INFO - 2016-10-18 16:42:29 --> Output Class Initialized
INFO - 2016-10-18 16:42:29 --> Security Class Initialized
DEBUG - 2016-10-18 16:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:42:29 --> Input Class Initialized
INFO - 2016-10-18 16:42:29 --> Language Class Initialized
INFO - 2016-10-18 16:42:29 --> Loader Class Initialized
INFO - 2016-10-18 16:42:29 --> Helper loaded: url_helper
INFO - 2016-10-18 16:42:29 --> Helper loaded: form_helper
INFO - 2016-10-18 16:42:29 --> Database Driver Class Initialized
INFO - 2016-10-18 16:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:42:29 --> Controller Class Initialized
INFO - 2016-10-18 16:42:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:42:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:42:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:42:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:42:29 --> Final output sent to browser
DEBUG - 2016-10-18 16:42:29 --> Total execution time: 0.0076
INFO - 2016-10-18 16:42:57 --> Config Class Initialized
INFO - 2016-10-18 16:42:57 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:42:57 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:42:57 --> Utf8 Class Initialized
INFO - 2016-10-18 16:42:57 --> URI Class Initialized
INFO - 2016-10-18 16:42:57 --> Router Class Initialized
INFO - 2016-10-18 16:42:57 --> Output Class Initialized
INFO - 2016-10-18 16:42:57 --> Security Class Initialized
DEBUG - 2016-10-18 16:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:42:57 --> Input Class Initialized
INFO - 2016-10-18 16:42:57 --> Language Class Initialized
INFO - 2016-10-18 16:42:57 --> Loader Class Initialized
INFO - 2016-10-18 16:42:57 --> Helper loaded: url_helper
INFO - 2016-10-18 16:42:57 --> Helper loaded: form_helper
INFO - 2016-10-18 16:42:57 --> Database Driver Class Initialized
INFO - 2016-10-18 16:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:42:57 --> Controller Class Initialized
INFO - 2016-10-18 16:42:57 --> Form Validation Class Initialized
INFO - 2016-10-18 16:42:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 16:42:57 --> Final output sent to browser
DEBUG - 2016-10-18 16:42:57 --> Total execution time: 0.0069
INFO - 2016-10-18 16:43:05 --> Config Class Initialized
INFO - 2016-10-18 16:43:05 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:43:05 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:43:05 --> Utf8 Class Initialized
INFO - 2016-10-18 16:43:05 --> URI Class Initialized
DEBUG - 2016-10-18 16:43:05 --> No URI present. Default controller set.
INFO - 2016-10-18 16:43:05 --> Router Class Initialized
INFO - 2016-10-18 16:43:05 --> Output Class Initialized
INFO - 2016-10-18 16:43:05 --> Security Class Initialized
DEBUG - 2016-10-18 16:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:43:05 --> Input Class Initialized
INFO - 2016-10-18 16:43:05 --> Language Class Initialized
INFO - 2016-10-18 16:43:05 --> Loader Class Initialized
INFO - 2016-10-18 16:43:05 --> Helper loaded: url_helper
INFO - 2016-10-18 16:43:05 --> Helper loaded: form_helper
INFO - 2016-10-18 16:43:05 --> Database Driver Class Initialized
INFO - 2016-10-18 16:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:43:05 --> Controller Class Initialized
INFO - 2016-10-18 16:43:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:43:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:43:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:43:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:43:05 --> Final output sent to browser
DEBUG - 2016-10-18 16:43:05 --> Total execution time: 0.0080
INFO - 2016-10-18 16:45:59 --> Config Class Initialized
INFO - 2016-10-18 16:45:59 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:45:59 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:45:59 --> Utf8 Class Initialized
INFO - 2016-10-18 16:45:59 --> URI Class Initialized
DEBUG - 2016-10-18 16:45:59 --> No URI present. Default controller set.
INFO - 2016-10-18 16:45:59 --> Router Class Initialized
INFO - 2016-10-18 16:45:59 --> Output Class Initialized
INFO - 2016-10-18 16:45:59 --> Security Class Initialized
DEBUG - 2016-10-18 16:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:45:59 --> Input Class Initialized
INFO - 2016-10-18 16:45:59 --> Language Class Initialized
INFO - 2016-10-18 16:45:59 --> Loader Class Initialized
INFO - 2016-10-18 16:45:59 --> Helper loaded: url_helper
INFO - 2016-10-18 16:45:59 --> Helper loaded: form_helper
INFO - 2016-10-18 16:45:59 --> Database Driver Class Initialized
INFO - 2016-10-18 16:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:45:59 --> Controller Class Initialized
INFO - 2016-10-18 16:45:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:45:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:45:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:45:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:45:59 --> Final output sent to browser
DEBUG - 2016-10-18 16:45:59 --> Total execution time: 0.0088
INFO - 2016-10-18 16:46:25 --> Config Class Initialized
INFO - 2016-10-18 16:46:25 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:46:25 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:46:25 --> Utf8 Class Initialized
INFO - 2016-10-18 16:46:25 --> URI Class Initialized
DEBUG - 2016-10-18 16:46:25 --> No URI present. Default controller set.
INFO - 2016-10-18 16:46:25 --> Router Class Initialized
INFO - 2016-10-18 16:46:25 --> Output Class Initialized
INFO - 2016-10-18 16:46:25 --> Security Class Initialized
DEBUG - 2016-10-18 16:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:46:25 --> Input Class Initialized
INFO - 2016-10-18 16:46:25 --> Language Class Initialized
INFO - 2016-10-18 16:46:25 --> Loader Class Initialized
INFO - 2016-10-18 16:46:25 --> Helper loaded: url_helper
INFO - 2016-10-18 16:46:25 --> Helper loaded: form_helper
INFO - 2016-10-18 16:46:25 --> Database Driver Class Initialized
INFO - 2016-10-18 16:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:46:25 --> Controller Class Initialized
INFO - 2016-10-18 16:46:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:46:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:46:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:46:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:46:25 --> Final output sent to browser
DEBUG - 2016-10-18 16:46:25 --> Total execution time: 0.0078
INFO - 2016-10-18 16:47:58 --> Config Class Initialized
INFO - 2016-10-18 16:47:58 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:47:58 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:47:58 --> Utf8 Class Initialized
INFO - 2016-10-18 16:47:58 --> URI Class Initialized
DEBUG - 2016-10-18 16:47:58 --> No URI present. Default controller set.
INFO - 2016-10-18 16:47:58 --> Router Class Initialized
INFO - 2016-10-18 16:47:58 --> Output Class Initialized
INFO - 2016-10-18 16:47:58 --> Security Class Initialized
DEBUG - 2016-10-18 16:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:47:58 --> Input Class Initialized
INFO - 2016-10-18 16:47:58 --> Language Class Initialized
INFO - 2016-10-18 16:47:58 --> Loader Class Initialized
INFO - 2016-10-18 16:47:58 --> Helper loaded: url_helper
INFO - 2016-10-18 16:47:58 --> Helper loaded: form_helper
INFO - 2016-10-18 16:47:58 --> Database Driver Class Initialized
INFO - 2016-10-18 16:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:47:58 --> Controller Class Initialized
INFO - 2016-10-18 16:47:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:47:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:47:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:47:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:47:58 --> Final output sent to browser
DEBUG - 2016-10-18 16:47:58 --> Total execution time: 0.0552
INFO - 2016-10-18 16:48:07 --> Config Class Initialized
INFO - 2016-10-18 16:48:07 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:48:07 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:48:07 --> Utf8 Class Initialized
INFO - 2016-10-18 16:48:07 --> URI Class Initialized
DEBUG - 2016-10-18 16:48:07 --> No URI present. Default controller set.
INFO - 2016-10-18 16:48:07 --> Router Class Initialized
INFO - 2016-10-18 16:48:07 --> Output Class Initialized
INFO - 2016-10-18 16:48:07 --> Security Class Initialized
DEBUG - 2016-10-18 16:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:48:07 --> Input Class Initialized
INFO - 2016-10-18 16:48:07 --> Language Class Initialized
INFO - 2016-10-18 16:48:07 --> Loader Class Initialized
INFO - 2016-10-18 16:48:07 --> Helper loaded: url_helper
INFO - 2016-10-18 16:48:07 --> Helper loaded: form_helper
INFO - 2016-10-18 16:48:07 --> Database Driver Class Initialized
INFO - 2016-10-18 16:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:48:07 --> Controller Class Initialized
INFO - 2016-10-18 16:48:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:48:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:48:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:48:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:48:07 --> Final output sent to browser
DEBUG - 2016-10-18 16:48:07 --> Total execution time: 0.0071
INFO - 2016-10-18 16:48:16 --> Config Class Initialized
INFO - 2016-10-18 16:48:16 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:48:16 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:48:16 --> Utf8 Class Initialized
INFO - 2016-10-18 16:48:16 --> URI Class Initialized
DEBUG - 2016-10-18 16:48:16 --> No URI present. Default controller set.
INFO - 2016-10-18 16:48:16 --> Router Class Initialized
INFO - 2016-10-18 16:48:16 --> Output Class Initialized
INFO - 2016-10-18 16:48:16 --> Security Class Initialized
DEBUG - 2016-10-18 16:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:48:16 --> Input Class Initialized
INFO - 2016-10-18 16:48:16 --> Language Class Initialized
INFO - 2016-10-18 16:48:16 --> Loader Class Initialized
INFO - 2016-10-18 16:48:16 --> Helper loaded: url_helper
INFO - 2016-10-18 16:48:16 --> Helper loaded: form_helper
INFO - 2016-10-18 16:48:16 --> Database Driver Class Initialized
INFO - 2016-10-18 16:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:48:16 --> Controller Class Initialized
INFO - 2016-10-18 16:48:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:48:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:48:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:48:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:48:16 --> Final output sent to browser
DEBUG - 2016-10-18 16:48:16 --> Total execution time: 0.0058
INFO - 2016-10-18 16:48:31 --> Config Class Initialized
INFO - 2016-10-18 16:48:31 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:48:31 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:48:31 --> Utf8 Class Initialized
INFO - 2016-10-18 16:48:31 --> URI Class Initialized
DEBUG - 2016-10-18 16:48:31 --> No URI present. Default controller set.
INFO - 2016-10-18 16:48:31 --> Router Class Initialized
INFO - 2016-10-18 16:48:31 --> Output Class Initialized
INFO - 2016-10-18 16:48:31 --> Security Class Initialized
DEBUG - 2016-10-18 16:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:48:31 --> Input Class Initialized
INFO - 2016-10-18 16:48:31 --> Language Class Initialized
INFO - 2016-10-18 16:48:31 --> Loader Class Initialized
INFO - 2016-10-18 16:48:31 --> Helper loaded: url_helper
INFO - 2016-10-18 16:48:31 --> Helper loaded: form_helper
INFO - 2016-10-18 16:48:31 --> Database Driver Class Initialized
INFO - 2016-10-18 16:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:48:31 --> Controller Class Initialized
INFO - 2016-10-18 16:48:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:48:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:48:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:48:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:48:31 --> Final output sent to browser
DEBUG - 2016-10-18 16:48:31 --> Total execution time: 0.0047
INFO - 2016-10-18 16:48:40 --> Config Class Initialized
INFO - 2016-10-18 16:48:40 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:48:40 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:48:40 --> Utf8 Class Initialized
INFO - 2016-10-18 16:48:40 --> URI Class Initialized
DEBUG - 2016-10-18 16:48:40 --> No URI present. Default controller set.
INFO - 2016-10-18 16:48:40 --> Router Class Initialized
INFO - 2016-10-18 16:48:40 --> Output Class Initialized
INFO - 2016-10-18 16:48:40 --> Security Class Initialized
DEBUG - 2016-10-18 16:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:48:40 --> Input Class Initialized
INFO - 2016-10-18 16:48:40 --> Language Class Initialized
INFO - 2016-10-18 16:48:40 --> Loader Class Initialized
INFO - 2016-10-18 16:48:40 --> Helper loaded: url_helper
INFO - 2016-10-18 16:48:40 --> Helper loaded: form_helper
INFO - 2016-10-18 16:48:40 --> Database Driver Class Initialized
INFO - 2016-10-18 16:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:48:40 --> Controller Class Initialized
INFO - 2016-10-18 16:48:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:48:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:48:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:48:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:48:40 --> Final output sent to browser
DEBUG - 2016-10-18 16:48:40 --> Total execution time: 0.0077
INFO - 2016-10-18 16:48:50 --> Config Class Initialized
INFO - 2016-10-18 16:48:50 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:48:50 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:48:50 --> Utf8 Class Initialized
INFO - 2016-10-18 16:48:50 --> URI Class Initialized
DEBUG - 2016-10-18 16:48:50 --> No URI present. Default controller set.
INFO - 2016-10-18 16:48:50 --> Router Class Initialized
INFO - 2016-10-18 16:48:50 --> Output Class Initialized
INFO - 2016-10-18 16:48:50 --> Security Class Initialized
DEBUG - 2016-10-18 16:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:48:50 --> Input Class Initialized
INFO - 2016-10-18 16:48:50 --> Language Class Initialized
INFO - 2016-10-18 16:48:50 --> Loader Class Initialized
INFO - 2016-10-18 16:48:50 --> Helper loaded: url_helper
INFO - 2016-10-18 16:48:50 --> Helper loaded: form_helper
INFO - 2016-10-18 16:48:50 --> Database Driver Class Initialized
INFO - 2016-10-18 16:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:48:50 --> Controller Class Initialized
INFO - 2016-10-18 16:48:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:48:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:48:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:48:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:48:50 --> Final output sent to browser
DEBUG - 2016-10-18 16:48:50 --> Total execution time: 0.0053
INFO - 2016-10-18 16:49:38 --> Config Class Initialized
INFO - 2016-10-18 16:49:38 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:49:38 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:49:38 --> Utf8 Class Initialized
INFO - 2016-10-18 16:49:38 --> URI Class Initialized
DEBUG - 2016-10-18 16:49:38 --> No URI present. Default controller set.
INFO - 2016-10-18 16:49:38 --> Router Class Initialized
INFO - 2016-10-18 16:49:38 --> Output Class Initialized
INFO - 2016-10-18 16:49:38 --> Security Class Initialized
DEBUG - 2016-10-18 16:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:49:38 --> Input Class Initialized
INFO - 2016-10-18 16:49:38 --> Language Class Initialized
INFO - 2016-10-18 16:49:38 --> Loader Class Initialized
INFO - 2016-10-18 16:49:38 --> Helper loaded: url_helper
INFO - 2016-10-18 16:49:38 --> Helper loaded: form_helper
INFO - 2016-10-18 16:49:38 --> Database Driver Class Initialized
INFO - 2016-10-18 16:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:49:38 --> Controller Class Initialized
INFO - 2016-10-18 16:49:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:49:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:49:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:49:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:49:38 --> Final output sent to browser
DEBUG - 2016-10-18 16:49:38 --> Total execution time: 0.0084
INFO - 2016-10-18 16:49:41 --> Config Class Initialized
INFO - 2016-10-18 16:49:41 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:49:41 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:49:41 --> Utf8 Class Initialized
INFO - 2016-10-18 16:49:41 --> URI Class Initialized
INFO - 2016-10-18 16:49:41 --> Router Class Initialized
INFO - 2016-10-18 16:49:41 --> Output Class Initialized
INFO - 2016-10-18 16:49:41 --> Security Class Initialized
DEBUG - 2016-10-18 16:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:49:41 --> Input Class Initialized
INFO - 2016-10-18 16:49:41 --> Language Class Initialized
INFO - 2016-10-18 16:49:41 --> Loader Class Initialized
INFO - 2016-10-18 16:49:41 --> Helper loaded: url_helper
INFO - 2016-10-18 16:49:41 --> Helper loaded: form_helper
INFO - 2016-10-18 16:49:41 --> Database Driver Class Initialized
INFO - 2016-10-18 16:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:49:41 --> Controller Class Initialized
INFO - 2016-10-18 16:49:41 --> Form Validation Class Initialized
INFO - 2016-10-18 16:49:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 16:49:41 --> Final output sent to browser
DEBUG - 2016-10-18 16:49:41 --> Total execution time: 0.0066
INFO - 2016-10-18 16:50:52 --> Config Class Initialized
INFO - 2016-10-18 16:50:52 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:50:52 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:50:52 --> Utf8 Class Initialized
INFO - 2016-10-18 16:50:52 --> URI Class Initialized
DEBUG - 2016-10-18 16:50:52 --> No URI present. Default controller set.
INFO - 2016-10-18 16:50:52 --> Router Class Initialized
INFO - 2016-10-18 16:50:52 --> Output Class Initialized
INFO - 2016-10-18 16:50:52 --> Security Class Initialized
DEBUG - 2016-10-18 16:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:50:52 --> Input Class Initialized
INFO - 2016-10-18 16:50:52 --> Language Class Initialized
INFO - 2016-10-18 16:50:52 --> Loader Class Initialized
INFO - 2016-10-18 16:50:52 --> Helper loaded: url_helper
INFO - 2016-10-18 16:50:52 --> Helper loaded: form_helper
INFO - 2016-10-18 16:50:52 --> Database Driver Class Initialized
INFO - 2016-10-18 16:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:50:52 --> Controller Class Initialized
INFO - 2016-10-18 16:50:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:50:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:50:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:50:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:50:52 --> Final output sent to browser
DEBUG - 2016-10-18 16:50:52 --> Total execution time: 0.0049
INFO - 2016-10-18 16:51:07 --> Config Class Initialized
INFO - 2016-10-18 16:51:07 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:51:07 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:51:07 --> Utf8 Class Initialized
INFO - 2016-10-18 16:51:07 --> URI Class Initialized
INFO - 2016-10-18 16:51:07 --> Router Class Initialized
INFO - 2016-10-18 16:51:07 --> Output Class Initialized
INFO - 2016-10-18 16:51:07 --> Security Class Initialized
DEBUG - 2016-10-18 16:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:51:07 --> Input Class Initialized
INFO - 2016-10-18 16:51:07 --> Language Class Initialized
INFO - 2016-10-18 16:51:07 --> Loader Class Initialized
INFO - 2016-10-18 16:51:07 --> Helper loaded: url_helper
INFO - 2016-10-18 16:51:07 --> Helper loaded: form_helper
INFO - 2016-10-18 16:51:07 --> Database Driver Class Initialized
INFO - 2016-10-18 16:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:51:07 --> Controller Class Initialized
INFO - 2016-10-18 16:51:07 --> Form Validation Class Initialized
INFO - 2016-10-18 16:51:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 16:51:07 --> Final output sent to browser
DEBUG - 2016-10-18 16:51:07 --> Total execution time: 0.0063
INFO - 2016-10-18 16:51:10 --> Config Class Initialized
INFO - 2016-10-18 16:51:10 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:51:10 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:51:10 --> Utf8 Class Initialized
INFO - 2016-10-18 16:51:10 --> URI Class Initialized
DEBUG - 2016-10-18 16:51:10 --> No URI present. Default controller set.
INFO - 2016-10-18 16:51:10 --> Router Class Initialized
INFO - 2016-10-18 16:51:10 --> Output Class Initialized
INFO - 2016-10-18 16:51:10 --> Security Class Initialized
DEBUG - 2016-10-18 16:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:51:10 --> Input Class Initialized
INFO - 2016-10-18 16:51:10 --> Language Class Initialized
INFO - 2016-10-18 16:51:10 --> Loader Class Initialized
INFO - 2016-10-18 16:51:10 --> Helper loaded: url_helper
INFO - 2016-10-18 16:51:10 --> Helper loaded: form_helper
INFO - 2016-10-18 16:51:10 --> Database Driver Class Initialized
INFO - 2016-10-18 16:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:51:10 --> Controller Class Initialized
INFO - 2016-10-18 16:51:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:51:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:51:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:51:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:51:10 --> Final output sent to browser
DEBUG - 2016-10-18 16:51:10 --> Total execution time: 0.0050
INFO - 2016-10-18 16:51:12 --> Config Class Initialized
INFO - 2016-10-18 16:51:12 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:51:12 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:51:12 --> Utf8 Class Initialized
INFO - 2016-10-18 16:51:12 --> URI Class Initialized
INFO - 2016-10-18 16:51:12 --> Router Class Initialized
INFO - 2016-10-18 16:51:12 --> Output Class Initialized
INFO - 2016-10-18 16:51:12 --> Security Class Initialized
DEBUG - 2016-10-18 16:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:51:12 --> Input Class Initialized
INFO - 2016-10-18 16:51:12 --> Language Class Initialized
INFO - 2016-10-18 16:51:12 --> Loader Class Initialized
INFO - 2016-10-18 16:51:12 --> Helper loaded: url_helper
INFO - 2016-10-18 16:51:12 --> Helper loaded: form_helper
INFO - 2016-10-18 16:51:12 --> Database Driver Class Initialized
INFO - 2016-10-18 16:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:51:12 --> Controller Class Initialized
INFO - 2016-10-18 16:51:12 --> Form Validation Class Initialized
INFO - 2016-10-18 16:51:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 16:51:12 --> Final output sent to browser
DEBUG - 2016-10-18 16:51:12 --> Total execution time: 0.0059
INFO - 2016-10-18 16:51:14 --> Config Class Initialized
INFO - 2016-10-18 16:51:14 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:51:14 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:51:14 --> Utf8 Class Initialized
INFO - 2016-10-18 16:51:14 --> URI Class Initialized
DEBUG - 2016-10-18 16:51:14 --> No URI present. Default controller set.
INFO - 2016-10-18 16:51:14 --> Router Class Initialized
INFO - 2016-10-18 16:51:14 --> Output Class Initialized
INFO - 2016-10-18 16:51:14 --> Security Class Initialized
DEBUG - 2016-10-18 16:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:51:14 --> Input Class Initialized
INFO - 2016-10-18 16:51:14 --> Language Class Initialized
INFO - 2016-10-18 16:51:14 --> Loader Class Initialized
INFO - 2016-10-18 16:51:14 --> Helper loaded: url_helper
INFO - 2016-10-18 16:51:14 --> Helper loaded: form_helper
INFO - 2016-10-18 16:51:14 --> Database Driver Class Initialized
INFO - 2016-10-18 16:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:51:14 --> Controller Class Initialized
INFO - 2016-10-18 16:51:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:51:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:51:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:51:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:51:14 --> Final output sent to browser
DEBUG - 2016-10-18 16:51:14 --> Total execution time: 0.0054
INFO - 2016-10-18 16:51:36 --> Config Class Initialized
INFO - 2016-10-18 16:51:36 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:51:36 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:51:36 --> Utf8 Class Initialized
INFO - 2016-10-18 16:51:36 --> URI Class Initialized
INFO - 2016-10-18 16:51:36 --> Router Class Initialized
INFO - 2016-10-18 16:51:36 --> Output Class Initialized
INFO - 2016-10-18 16:51:36 --> Security Class Initialized
DEBUG - 2016-10-18 16:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:51:36 --> Input Class Initialized
INFO - 2016-10-18 16:51:36 --> Language Class Initialized
INFO - 2016-10-18 16:51:36 --> Loader Class Initialized
INFO - 2016-10-18 16:51:36 --> Helper loaded: url_helper
INFO - 2016-10-18 16:51:36 --> Helper loaded: form_helper
INFO - 2016-10-18 16:51:36 --> Database Driver Class Initialized
INFO - 2016-10-18 16:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:51:36 --> Controller Class Initialized
INFO - 2016-10-18 16:51:36 --> Form Validation Class Initialized
INFO - 2016-10-18 16:51:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 16:51:36 --> Final output sent to browser
DEBUG - 2016-10-18 16:51:36 --> Total execution time: 0.0089
INFO - 2016-10-18 16:51:37 --> Config Class Initialized
INFO - 2016-10-18 16:51:37 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:51:37 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:51:37 --> Utf8 Class Initialized
INFO - 2016-10-18 16:51:37 --> URI Class Initialized
DEBUG - 2016-10-18 16:51:37 --> No URI present. Default controller set.
INFO - 2016-10-18 16:51:37 --> Router Class Initialized
INFO - 2016-10-18 16:51:37 --> Output Class Initialized
INFO - 2016-10-18 16:51:37 --> Security Class Initialized
DEBUG - 2016-10-18 16:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:51:37 --> Input Class Initialized
INFO - 2016-10-18 16:51:37 --> Language Class Initialized
INFO - 2016-10-18 16:51:37 --> Loader Class Initialized
INFO - 2016-10-18 16:51:37 --> Helper loaded: url_helper
INFO - 2016-10-18 16:51:37 --> Helper loaded: form_helper
INFO - 2016-10-18 16:51:37 --> Database Driver Class Initialized
INFO - 2016-10-18 16:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:51:37 --> Controller Class Initialized
INFO - 2016-10-18 16:51:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:51:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:51:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:51:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:51:37 --> Final output sent to browser
DEBUG - 2016-10-18 16:51:37 --> Total execution time: 0.0050
INFO - 2016-10-18 16:52:05 --> Config Class Initialized
INFO - 2016-10-18 16:52:05 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:52:05 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:52:05 --> Utf8 Class Initialized
INFO - 2016-10-18 16:52:05 --> URI Class Initialized
INFO - 2016-10-18 16:52:05 --> Router Class Initialized
INFO - 2016-10-18 16:52:05 --> Output Class Initialized
INFO - 2016-10-18 16:52:05 --> Security Class Initialized
DEBUG - 2016-10-18 16:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:52:05 --> Input Class Initialized
INFO - 2016-10-18 16:52:05 --> Language Class Initialized
INFO - 2016-10-18 16:52:05 --> Loader Class Initialized
INFO - 2016-10-18 16:52:05 --> Helper loaded: url_helper
INFO - 2016-10-18 16:52:05 --> Helper loaded: form_helper
INFO - 2016-10-18 16:52:05 --> Database Driver Class Initialized
INFO - 2016-10-18 16:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:52:05 --> Controller Class Initialized
INFO - 2016-10-18 16:52:05 --> Form Validation Class Initialized
INFO - 2016-10-18 16:52:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 16:52:05 --> Final output sent to browser
DEBUG - 2016-10-18 16:52:05 --> Total execution time: 0.0061
INFO - 2016-10-18 16:52:11 --> Config Class Initialized
INFO - 2016-10-18 16:52:11 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:52:11 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:52:11 --> Utf8 Class Initialized
INFO - 2016-10-18 16:52:11 --> URI Class Initialized
DEBUG - 2016-10-18 16:52:11 --> No URI present. Default controller set.
INFO - 2016-10-18 16:52:11 --> Router Class Initialized
INFO - 2016-10-18 16:52:11 --> Output Class Initialized
INFO - 2016-10-18 16:52:11 --> Security Class Initialized
DEBUG - 2016-10-18 16:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:52:11 --> Input Class Initialized
INFO - 2016-10-18 16:52:11 --> Language Class Initialized
INFO - 2016-10-18 16:52:11 --> Loader Class Initialized
INFO - 2016-10-18 16:52:11 --> Helper loaded: url_helper
INFO - 2016-10-18 16:52:11 --> Helper loaded: form_helper
INFO - 2016-10-18 16:52:11 --> Database Driver Class Initialized
INFO - 2016-10-18 16:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:52:11 --> Controller Class Initialized
INFO - 2016-10-18 16:52:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:52:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:52:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:52:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:52:11 --> Final output sent to browser
DEBUG - 2016-10-18 16:52:11 --> Total execution time: 0.0049
INFO - 2016-10-18 16:52:19 --> Config Class Initialized
INFO - 2016-10-18 16:52:19 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:52:19 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:52:19 --> Utf8 Class Initialized
INFO - 2016-10-18 16:52:19 --> URI Class Initialized
DEBUG - 2016-10-18 16:52:19 --> No URI present. Default controller set.
INFO - 2016-10-18 16:52:19 --> Router Class Initialized
INFO - 2016-10-18 16:52:19 --> Output Class Initialized
INFO - 2016-10-18 16:52:19 --> Security Class Initialized
DEBUG - 2016-10-18 16:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:52:19 --> Input Class Initialized
INFO - 2016-10-18 16:52:19 --> Language Class Initialized
INFO - 2016-10-18 16:52:19 --> Loader Class Initialized
INFO - 2016-10-18 16:52:19 --> Helper loaded: url_helper
INFO - 2016-10-18 16:52:19 --> Helper loaded: form_helper
INFO - 2016-10-18 16:52:19 --> Database Driver Class Initialized
INFO - 2016-10-18 16:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:52:19 --> Controller Class Initialized
INFO - 2016-10-18 16:52:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:52:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:52:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:52:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:52:19 --> Final output sent to browser
DEBUG - 2016-10-18 16:52:19 --> Total execution time: 0.0083
INFO - 2016-10-18 16:57:04 --> Config Class Initialized
INFO - 2016-10-18 16:57:04 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:57:04 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:57:04 --> Utf8 Class Initialized
INFO - 2016-10-18 16:57:04 --> URI Class Initialized
DEBUG - 2016-10-18 16:57:04 --> No URI present. Default controller set.
INFO - 2016-10-18 16:57:04 --> Router Class Initialized
INFO - 2016-10-18 16:57:04 --> Output Class Initialized
INFO - 2016-10-18 16:57:04 --> Security Class Initialized
DEBUG - 2016-10-18 16:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:57:04 --> Input Class Initialized
INFO - 2016-10-18 16:57:04 --> Language Class Initialized
INFO - 2016-10-18 16:57:04 --> Loader Class Initialized
INFO - 2016-10-18 16:57:04 --> Helper loaded: url_helper
INFO - 2016-10-18 16:57:04 --> Helper loaded: form_helper
INFO - 2016-10-18 16:57:04 --> Database Driver Class Initialized
INFO - 2016-10-18 16:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:57:04 --> Controller Class Initialized
INFO - 2016-10-18 16:57:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:57:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:57:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:57:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:57:04 --> Final output sent to browser
DEBUG - 2016-10-18 16:57:04 --> Total execution time: 0.0083
INFO - 2016-10-18 16:58:52 --> Config Class Initialized
INFO - 2016-10-18 16:58:52 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:58:52 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:58:52 --> Utf8 Class Initialized
INFO - 2016-10-18 16:58:52 --> URI Class Initialized
DEBUG - 2016-10-18 16:58:52 --> No URI present. Default controller set.
INFO - 2016-10-18 16:58:52 --> Router Class Initialized
INFO - 2016-10-18 16:58:52 --> Output Class Initialized
INFO - 2016-10-18 16:58:52 --> Security Class Initialized
DEBUG - 2016-10-18 16:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:58:52 --> Input Class Initialized
INFO - 2016-10-18 16:58:52 --> Language Class Initialized
INFO - 2016-10-18 16:58:52 --> Loader Class Initialized
INFO - 2016-10-18 16:58:52 --> Helper loaded: url_helper
INFO - 2016-10-18 16:58:52 --> Helper loaded: form_helper
INFO - 2016-10-18 16:58:52 --> Database Driver Class Initialized
INFO - 2016-10-18 16:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 16:58:52 --> Controller Class Initialized
INFO - 2016-10-18 16:58:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 16:58:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 16:58:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 16:58:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 16:58:52 --> Final output sent to browser
DEBUG - 2016-10-18 16:58:52 --> Total execution time: 0.0081
INFO - 2016-10-18 17:00:20 --> Config Class Initialized
INFO - 2016-10-18 17:00:20 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:00:20 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:00:20 --> Utf8 Class Initialized
INFO - 2016-10-18 17:00:20 --> URI Class Initialized
DEBUG - 2016-10-18 17:00:20 --> No URI present. Default controller set.
INFO - 2016-10-18 17:00:20 --> Router Class Initialized
INFO - 2016-10-18 17:00:20 --> Output Class Initialized
INFO - 2016-10-18 17:00:20 --> Security Class Initialized
DEBUG - 2016-10-18 17:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:00:20 --> Input Class Initialized
INFO - 2016-10-18 17:00:20 --> Language Class Initialized
INFO - 2016-10-18 17:00:20 --> Loader Class Initialized
INFO - 2016-10-18 17:00:20 --> Helper loaded: url_helper
INFO - 2016-10-18 17:00:20 --> Helper loaded: form_helper
INFO - 2016-10-18 17:00:20 --> Database Driver Class Initialized
INFO - 2016-10-18 17:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:00:20 --> Controller Class Initialized
INFO - 2016-10-18 17:00:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:00:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:00:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:00:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:00:20 --> Final output sent to browser
DEBUG - 2016-10-18 17:00:20 --> Total execution time: 0.0085
INFO - 2016-10-18 17:01:12 --> Config Class Initialized
INFO - 2016-10-18 17:01:12 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:01:12 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:01:12 --> Utf8 Class Initialized
INFO - 2016-10-18 17:01:12 --> URI Class Initialized
DEBUG - 2016-10-18 17:01:12 --> No URI present. Default controller set.
INFO - 2016-10-18 17:01:12 --> Router Class Initialized
INFO - 2016-10-18 17:01:12 --> Output Class Initialized
INFO - 2016-10-18 17:01:12 --> Security Class Initialized
DEBUG - 2016-10-18 17:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:01:12 --> Input Class Initialized
INFO - 2016-10-18 17:01:12 --> Language Class Initialized
INFO - 2016-10-18 17:01:12 --> Loader Class Initialized
INFO - 2016-10-18 17:01:12 --> Helper loaded: url_helper
INFO - 2016-10-18 17:01:12 --> Helper loaded: form_helper
INFO - 2016-10-18 17:01:12 --> Database Driver Class Initialized
INFO - 2016-10-18 17:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:01:12 --> Controller Class Initialized
INFO - 2016-10-18 17:01:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:01:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:01:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:01:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:01:12 --> Final output sent to browser
DEBUG - 2016-10-18 17:01:12 --> Total execution time: 0.0074
INFO - 2016-10-18 17:02:20 --> Config Class Initialized
INFO - 2016-10-18 17:02:20 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:02:20 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:02:20 --> Utf8 Class Initialized
INFO - 2016-10-18 17:02:20 --> URI Class Initialized
DEBUG - 2016-10-18 17:02:20 --> No URI present. Default controller set.
INFO - 2016-10-18 17:02:20 --> Router Class Initialized
INFO - 2016-10-18 17:02:20 --> Output Class Initialized
INFO - 2016-10-18 17:02:20 --> Security Class Initialized
DEBUG - 2016-10-18 17:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:02:20 --> Input Class Initialized
INFO - 2016-10-18 17:02:20 --> Language Class Initialized
INFO - 2016-10-18 17:02:20 --> Loader Class Initialized
INFO - 2016-10-18 17:02:20 --> Helper loaded: url_helper
INFO - 2016-10-18 17:02:20 --> Helper loaded: form_helper
INFO - 2016-10-18 17:02:20 --> Database Driver Class Initialized
INFO - 2016-10-18 17:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:02:20 --> Controller Class Initialized
INFO - 2016-10-18 17:02:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:02:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:02:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:02:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:02:20 --> Final output sent to browser
DEBUG - 2016-10-18 17:02:20 --> Total execution time: 0.0057
INFO - 2016-10-18 17:03:46 --> Config Class Initialized
INFO - 2016-10-18 17:03:46 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:03:46 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:03:46 --> Utf8 Class Initialized
INFO - 2016-10-18 17:03:46 --> URI Class Initialized
DEBUG - 2016-10-18 17:03:46 --> No URI present. Default controller set.
INFO - 2016-10-18 17:03:46 --> Router Class Initialized
INFO - 2016-10-18 17:03:46 --> Output Class Initialized
INFO - 2016-10-18 17:03:46 --> Security Class Initialized
DEBUG - 2016-10-18 17:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:03:46 --> Input Class Initialized
INFO - 2016-10-18 17:03:46 --> Language Class Initialized
INFO - 2016-10-18 17:03:46 --> Loader Class Initialized
INFO - 2016-10-18 17:03:46 --> Helper loaded: url_helper
INFO - 2016-10-18 17:03:46 --> Helper loaded: form_helper
INFO - 2016-10-18 17:03:46 --> Database Driver Class Initialized
INFO - 2016-10-18 17:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:03:46 --> Controller Class Initialized
INFO - 2016-10-18 17:03:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:03:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:03:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:03:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:03:46 --> Final output sent to browser
DEBUG - 2016-10-18 17:03:46 --> Total execution time: 0.0057
INFO - 2016-10-18 17:04:24 --> Config Class Initialized
INFO - 2016-10-18 17:04:24 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:04:24 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:04:24 --> Utf8 Class Initialized
INFO - 2016-10-18 17:04:24 --> URI Class Initialized
DEBUG - 2016-10-18 17:04:24 --> No URI present. Default controller set.
INFO - 2016-10-18 17:04:24 --> Router Class Initialized
INFO - 2016-10-18 17:04:24 --> Output Class Initialized
INFO - 2016-10-18 17:04:24 --> Security Class Initialized
DEBUG - 2016-10-18 17:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:04:24 --> Input Class Initialized
INFO - 2016-10-18 17:04:24 --> Language Class Initialized
INFO - 2016-10-18 17:04:24 --> Loader Class Initialized
INFO - 2016-10-18 17:04:24 --> Helper loaded: url_helper
INFO - 2016-10-18 17:04:24 --> Helper loaded: form_helper
INFO - 2016-10-18 17:04:24 --> Database Driver Class Initialized
INFO - 2016-10-18 17:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:04:24 --> Controller Class Initialized
INFO - 2016-10-18 17:04:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:04:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:04:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:04:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:04:24 --> Final output sent to browser
DEBUG - 2016-10-18 17:04:24 --> Total execution time: 0.0088
INFO - 2016-10-18 17:05:05 --> Config Class Initialized
INFO - 2016-10-18 17:05:05 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:05:05 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:05:05 --> Utf8 Class Initialized
INFO - 2016-10-18 17:05:05 --> URI Class Initialized
DEBUG - 2016-10-18 17:05:05 --> No URI present. Default controller set.
INFO - 2016-10-18 17:05:05 --> Router Class Initialized
INFO - 2016-10-18 17:05:05 --> Output Class Initialized
INFO - 2016-10-18 17:05:05 --> Security Class Initialized
DEBUG - 2016-10-18 17:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:05:05 --> Input Class Initialized
INFO - 2016-10-18 17:05:05 --> Language Class Initialized
INFO - 2016-10-18 17:05:05 --> Loader Class Initialized
INFO - 2016-10-18 17:05:05 --> Helper loaded: url_helper
INFO - 2016-10-18 17:05:05 --> Helper loaded: form_helper
INFO - 2016-10-18 17:05:05 --> Database Driver Class Initialized
INFO - 2016-10-18 17:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:05:05 --> Controller Class Initialized
INFO - 2016-10-18 17:05:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:05:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:05:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:05:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:05:05 --> Final output sent to browser
DEBUG - 2016-10-18 17:05:05 --> Total execution time: 0.0056
INFO - 2016-10-18 17:05:53 --> Config Class Initialized
INFO - 2016-10-18 17:05:53 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:05:53 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:05:53 --> Utf8 Class Initialized
INFO - 2016-10-18 17:05:53 --> URI Class Initialized
DEBUG - 2016-10-18 17:05:53 --> No URI present. Default controller set.
INFO - 2016-10-18 17:05:53 --> Router Class Initialized
INFO - 2016-10-18 17:05:53 --> Output Class Initialized
INFO - 2016-10-18 17:05:53 --> Security Class Initialized
DEBUG - 2016-10-18 17:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:05:53 --> Input Class Initialized
INFO - 2016-10-18 17:05:53 --> Language Class Initialized
INFO - 2016-10-18 17:05:53 --> Loader Class Initialized
INFO - 2016-10-18 17:05:53 --> Helper loaded: url_helper
INFO - 2016-10-18 17:05:53 --> Helper loaded: form_helper
INFO - 2016-10-18 17:05:53 --> Database Driver Class Initialized
INFO - 2016-10-18 17:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:05:53 --> Controller Class Initialized
INFO - 2016-10-18 17:05:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:05:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:05:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:05:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:05:53 --> Final output sent to browser
DEBUG - 2016-10-18 17:05:53 --> Total execution time: 0.0066
INFO - 2016-10-18 17:06:18 --> Config Class Initialized
INFO - 2016-10-18 17:06:18 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:06:18 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:06:18 --> Utf8 Class Initialized
INFO - 2016-10-18 17:06:18 --> URI Class Initialized
DEBUG - 2016-10-18 17:06:18 --> No URI present. Default controller set.
INFO - 2016-10-18 17:06:18 --> Router Class Initialized
INFO - 2016-10-18 17:06:18 --> Output Class Initialized
INFO - 2016-10-18 17:06:18 --> Security Class Initialized
DEBUG - 2016-10-18 17:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:06:18 --> Input Class Initialized
INFO - 2016-10-18 17:06:18 --> Language Class Initialized
INFO - 2016-10-18 17:06:18 --> Loader Class Initialized
INFO - 2016-10-18 17:06:18 --> Helper loaded: url_helper
INFO - 2016-10-18 17:06:18 --> Helper loaded: form_helper
INFO - 2016-10-18 17:06:18 --> Database Driver Class Initialized
INFO - 2016-10-18 17:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:06:18 --> Controller Class Initialized
INFO - 2016-10-18 17:06:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:06:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:06:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:06:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:06:18 --> Final output sent to browser
DEBUG - 2016-10-18 17:06:18 --> Total execution time: 0.0056
INFO - 2016-10-18 17:06:38 --> Config Class Initialized
INFO - 2016-10-18 17:06:38 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:06:38 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:06:38 --> Utf8 Class Initialized
INFO - 2016-10-18 17:06:38 --> URI Class Initialized
DEBUG - 2016-10-18 17:06:38 --> No URI present. Default controller set.
INFO - 2016-10-18 17:06:38 --> Router Class Initialized
INFO - 2016-10-18 17:06:38 --> Output Class Initialized
INFO - 2016-10-18 17:06:38 --> Security Class Initialized
DEBUG - 2016-10-18 17:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:06:38 --> Input Class Initialized
INFO - 2016-10-18 17:06:38 --> Language Class Initialized
INFO - 2016-10-18 17:06:38 --> Loader Class Initialized
INFO - 2016-10-18 17:06:38 --> Helper loaded: url_helper
INFO - 2016-10-18 17:06:38 --> Helper loaded: form_helper
INFO - 2016-10-18 17:06:38 --> Database Driver Class Initialized
INFO - 2016-10-18 17:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:06:38 --> Controller Class Initialized
INFO - 2016-10-18 17:06:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:06:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:06:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:06:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:06:38 --> Final output sent to browser
DEBUG - 2016-10-18 17:06:38 --> Total execution time: 0.0053
INFO - 2016-10-18 17:06:56 --> Config Class Initialized
INFO - 2016-10-18 17:06:56 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:06:56 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:06:56 --> Utf8 Class Initialized
INFO - 2016-10-18 17:06:56 --> URI Class Initialized
DEBUG - 2016-10-18 17:06:56 --> No URI present. Default controller set.
INFO - 2016-10-18 17:06:56 --> Router Class Initialized
INFO - 2016-10-18 17:06:56 --> Output Class Initialized
INFO - 2016-10-18 17:06:56 --> Security Class Initialized
DEBUG - 2016-10-18 17:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:06:56 --> Input Class Initialized
INFO - 2016-10-18 17:06:56 --> Language Class Initialized
INFO - 2016-10-18 17:06:56 --> Loader Class Initialized
INFO - 2016-10-18 17:06:56 --> Helper loaded: url_helper
INFO - 2016-10-18 17:06:56 --> Helper loaded: form_helper
INFO - 2016-10-18 17:06:56 --> Database Driver Class Initialized
INFO - 2016-10-18 17:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:06:56 --> Controller Class Initialized
INFO - 2016-10-18 17:06:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:06:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:06:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:06:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:06:56 --> Final output sent to browser
DEBUG - 2016-10-18 17:06:56 --> Total execution time: 0.0051
INFO - 2016-10-18 17:07:29 --> Config Class Initialized
INFO - 2016-10-18 17:07:29 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:07:29 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:07:29 --> Utf8 Class Initialized
INFO - 2016-10-18 17:07:29 --> URI Class Initialized
DEBUG - 2016-10-18 17:07:29 --> No URI present. Default controller set.
INFO - 2016-10-18 17:07:29 --> Router Class Initialized
INFO - 2016-10-18 17:07:29 --> Output Class Initialized
INFO - 2016-10-18 17:07:29 --> Security Class Initialized
DEBUG - 2016-10-18 17:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:07:29 --> Input Class Initialized
INFO - 2016-10-18 17:07:29 --> Language Class Initialized
INFO - 2016-10-18 17:07:29 --> Loader Class Initialized
INFO - 2016-10-18 17:07:29 --> Helper loaded: url_helper
INFO - 2016-10-18 17:07:29 --> Helper loaded: form_helper
INFO - 2016-10-18 17:07:29 --> Database Driver Class Initialized
INFO - 2016-10-18 17:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:07:29 --> Controller Class Initialized
INFO - 2016-10-18 17:07:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:07:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:07:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:07:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:07:29 --> Final output sent to browser
DEBUG - 2016-10-18 17:07:29 --> Total execution time: 0.0091
INFO - 2016-10-18 17:07:56 --> Config Class Initialized
INFO - 2016-10-18 17:07:56 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:07:56 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:07:56 --> Utf8 Class Initialized
INFO - 2016-10-18 17:07:56 --> URI Class Initialized
DEBUG - 2016-10-18 17:07:56 --> No URI present. Default controller set.
INFO - 2016-10-18 17:07:56 --> Router Class Initialized
INFO - 2016-10-18 17:07:56 --> Output Class Initialized
INFO - 2016-10-18 17:07:56 --> Security Class Initialized
DEBUG - 2016-10-18 17:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:07:56 --> Input Class Initialized
INFO - 2016-10-18 17:07:56 --> Language Class Initialized
INFO - 2016-10-18 17:07:56 --> Loader Class Initialized
INFO - 2016-10-18 17:07:56 --> Helper loaded: url_helper
INFO - 2016-10-18 17:07:56 --> Helper loaded: form_helper
INFO - 2016-10-18 17:07:56 --> Database Driver Class Initialized
INFO - 2016-10-18 17:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:07:56 --> Controller Class Initialized
INFO - 2016-10-18 17:07:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:07:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:07:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:07:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:07:56 --> Final output sent to browser
DEBUG - 2016-10-18 17:07:56 --> Total execution time: 0.0054
INFO - 2016-10-18 17:08:21 --> Config Class Initialized
INFO - 2016-10-18 17:08:21 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:08:21 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:08:21 --> Utf8 Class Initialized
INFO - 2016-10-18 17:08:21 --> URI Class Initialized
DEBUG - 2016-10-18 17:08:21 --> No URI present. Default controller set.
INFO - 2016-10-18 17:08:21 --> Router Class Initialized
INFO - 2016-10-18 17:08:21 --> Output Class Initialized
INFO - 2016-10-18 17:08:21 --> Security Class Initialized
DEBUG - 2016-10-18 17:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:08:21 --> Input Class Initialized
INFO - 2016-10-18 17:08:21 --> Language Class Initialized
INFO - 2016-10-18 17:08:21 --> Loader Class Initialized
INFO - 2016-10-18 17:08:21 --> Helper loaded: url_helper
INFO - 2016-10-18 17:08:21 --> Helper loaded: form_helper
INFO - 2016-10-18 17:08:21 --> Database Driver Class Initialized
INFO - 2016-10-18 17:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:08:21 --> Controller Class Initialized
INFO - 2016-10-18 17:08:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:08:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:08:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:08:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:08:21 --> Final output sent to browser
DEBUG - 2016-10-18 17:08:21 --> Total execution time: 0.0057
INFO - 2016-10-18 17:08:32 --> Config Class Initialized
INFO - 2016-10-18 17:08:32 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:08:32 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:08:32 --> Utf8 Class Initialized
INFO - 2016-10-18 17:08:32 --> URI Class Initialized
INFO - 2016-10-18 17:08:32 --> Router Class Initialized
INFO - 2016-10-18 17:08:32 --> Output Class Initialized
INFO - 2016-10-18 17:08:32 --> Security Class Initialized
DEBUG - 2016-10-18 17:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:08:32 --> Input Class Initialized
INFO - 2016-10-18 17:08:32 --> Language Class Initialized
INFO - 2016-10-18 17:08:32 --> Loader Class Initialized
INFO - 2016-10-18 17:08:32 --> Helper loaded: url_helper
INFO - 2016-10-18 17:08:32 --> Helper loaded: form_helper
INFO - 2016-10-18 17:08:32 --> Database Driver Class Initialized
INFO - 2016-10-18 17:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:08:32 --> Controller Class Initialized
INFO - 2016-10-18 17:08:32 --> Form Validation Class Initialized
INFO - 2016-10-18 17:08:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 17:08:32 --> Final output sent to browser
DEBUG - 2016-10-18 17:08:32 --> Total execution time: 0.0064
INFO - 2016-10-18 17:08:36 --> Config Class Initialized
INFO - 2016-10-18 17:08:36 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:08:36 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:08:36 --> Utf8 Class Initialized
INFO - 2016-10-18 17:08:36 --> URI Class Initialized
DEBUG - 2016-10-18 17:08:36 --> No URI present. Default controller set.
INFO - 2016-10-18 17:08:36 --> Router Class Initialized
INFO - 2016-10-18 17:08:36 --> Output Class Initialized
INFO - 2016-10-18 17:08:36 --> Security Class Initialized
DEBUG - 2016-10-18 17:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:08:36 --> Input Class Initialized
INFO - 2016-10-18 17:08:36 --> Language Class Initialized
INFO - 2016-10-18 17:08:36 --> Loader Class Initialized
INFO - 2016-10-18 17:08:36 --> Helper loaded: url_helper
INFO - 2016-10-18 17:08:36 --> Helper loaded: form_helper
INFO - 2016-10-18 17:08:36 --> Database Driver Class Initialized
INFO - 2016-10-18 17:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:08:36 --> Controller Class Initialized
INFO - 2016-10-18 17:08:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:08:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:08:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:08:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:08:36 --> Final output sent to browser
DEBUG - 2016-10-18 17:08:36 --> Total execution time: 0.0053
INFO - 2016-10-18 17:10:15 --> Config Class Initialized
INFO - 2016-10-18 17:10:15 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:10:15 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:10:15 --> Utf8 Class Initialized
INFO - 2016-10-18 17:10:15 --> URI Class Initialized
DEBUG - 2016-10-18 17:10:15 --> No URI present. Default controller set.
INFO - 2016-10-18 17:10:15 --> Router Class Initialized
INFO - 2016-10-18 17:10:15 --> Output Class Initialized
INFO - 2016-10-18 17:10:15 --> Security Class Initialized
DEBUG - 2016-10-18 17:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:10:15 --> Input Class Initialized
INFO - 2016-10-18 17:10:15 --> Language Class Initialized
INFO - 2016-10-18 17:10:15 --> Loader Class Initialized
INFO - 2016-10-18 17:10:15 --> Helper loaded: url_helper
INFO - 2016-10-18 17:10:15 --> Helper loaded: form_helper
INFO - 2016-10-18 17:10:15 --> Database Driver Class Initialized
INFO - 2016-10-18 17:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:10:15 --> Controller Class Initialized
INFO - 2016-10-18 17:10:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:10:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:10:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:10:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:10:15 --> Final output sent to browser
DEBUG - 2016-10-18 17:10:15 --> Total execution time: 0.0058
INFO - 2016-10-18 17:11:00 --> Config Class Initialized
INFO - 2016-10-18 17:11:00 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:11:00 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:11:00 --> Utf8 Class Initialized
INFO - 2016-10-18 17:11:00 --> URI Class Initialized
DEBUG - 2016-10-18 17:11:00 --> No URI present. Default controller set.
INFO - 2016-10-18 17:11:00 --> Router Class Initialized
INFO - 2016-10-18 17:11:00 --> Output Class Initialized
INFO - 2016-10-18 17:11:00 --> Security Class Initialized
DEBUG - 2016-10-18 17:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:11:00 --> Input Class Initialized
INFO - 2016-10-18 17:11:00 --> Language Class Initialized
INFO - 2016-10-18 17:11:00 --> Loader Class Initialized
INFO - 2016-10-18 17:11:00 --> Helper loaded: url_helper
INFO - 2016-10-18 17:11:00 --> Helper loaded: form_helper
INFO - 2016-10-18 17:11:00 --> Database Driver Class Initialized
INFO - 2016-10-18 17:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:11:00 --> Controller Class Initialized
INFO - 2016-10-18 17:11:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:11:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:11:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:11:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:11:00 --> Final output sent to browser
DEBUG - 2016-10-18 17:11:00 --> Total execution time: 0.0055
INFO - 2016-10-18 17:13:15 --> Config Class Initialized
INFO - 2016-10-18 17:13:15 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:13:15 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:13:15 --> Utf8 Class Initialized
INFO - 2016-10-18 17:13:15 --> URI Class Initialized
DEBUG - 2016-10-18 17:13:15 --> No URI present. Default controller set.
INFO - 2016-10-18 17:13:15 --> Router Class Initialized
INFO - 2016-10-18 17:13:15 --> Output Class Initialized
INFO - 2016-10-18 17:13:15 --> Security Class Initialized
DEBUG - 2016-10-18 17:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:13:15 --> Input Class Initialized
INFO - 2016-10-18 17:13:15 --> Language Class Initialized
INFO - 2016-10-18 17:13:15 --> Loader Class Initialized
INFO - 2016-10-18 17:13:15 --> Helper loaded: url_helper
INFO - 2016-10-18 17:13:15 --> Helper loaded: form_helper
INFO - 2016-10-18 17:13:15 --> Database Driver Class Initialized
INFO - 2016-10-18 17:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:13:15 --> Controller Class Initialized
INFO - 2016-10-18 17:13:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:13:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:13:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:13:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:13:15 --> Final output sent to browser
DEBUG - 2016-10-18 17:13:15 --> Total execution time: 0.0086
INFO - 2016-10-18 17:14:11 --> Config Class Initialized
INFO - 2016-10-18 17:14:11 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:14:11 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:14:11 --> Utf8 Class Initialized
INFO - 2016-10-18 17:14:11 --> URI Class Initialized
DEBUG - 2016-10-18 17:14:11 --> No URI present. Default controller set.
INFO - 2016-10-18 17:14:11 --> Router Class Initialized
INFO - 2016-10-18 17:14:11 --> Output Class Initialized
INFO - 2016-10-18 17:14:11 --> Security Class Initialized
DEBUG - 2016-10-18 17:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:14:11 --> Input Class Initialized
INFO - 2016-10-18 17:14:11 --> Language Class Initialized
INFO - 2016-10-18 17:14:11 --> Loader Class Initialized
INFO - 2016-10-18 17:14:11 --> Helper loaded: url_helper
INFO - 2016-10-18 17:14:11 --> Helper loaded: form_helper
INFO - 2016-10-18 17:14:11 --> Database Driver Class Initialized
INFO - 2016-10-18 17:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:14:11 --> Controller Class Initialized
INFO - 2016-10-18 17:14:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:14:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:14:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:14:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:14:11 --> Final output sent to browser
DEBUG - 2016-10-18 17:14:11 --> Total execution time: 0.0065
INFO - 2016-10-18 17:14:52 --> Config Class Initialized
INFO - 2016-10-18 17:14:52 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:14:52 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:14:52 --> Utf8 Class Initialized
INFO - 2016-10-18 17:14:52 --> URI Class Initialized
DEBUG - 2016-10-18 17:14:52 --> No URI present. Default controller set.
INFO - 2016-10-18 17:14:52 --> Router Class Initialized
INFO - 2016-10-18 17:14:52 --> Output Class Initialized
INFO - 2016-10-18 17:14:52 --> Security Class Initialized
DEBUG - 2016-10-18 17:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:14:52 --> Input Class Initialized
INFO - 2016-10-18 17:14:52 --> Language Class Initialized
INFO - 2016-10-18 17:14:52 --> Loader Class Initialized
INFO - 2016-10-18 17:14:52 --> Helper loaded: url_helper
INFO - 2016-10-18 17:14:52 --> Helper loaded: form_helper
INFO - 2016-10-18 17:14:52 --> Database Driver Class Initialized
INFO - 2016-10-18 17:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:14:52 --> Controller Class Initialized
INFO - 2016-10-18 17:14:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:14:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:14:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:14:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:14:52 --> Final output sent to browser
DEBUG - 2016-10-18 17:14:52 --> Total execution time: 0.0056
INFO - 2016-10-18 17:15:08 --> Config Class Initialized
INFO - 2016-10-18 17:15:08 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:15:08 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:15:08 --> Utf8 Class Initialized
INFO - 2016-10-18 17:15:08 --> URI Class Initialized
DEBUG - 2016-10-18 17:15:08 --> No URI present. Default controller set.
INFO - 2016-10-18 17:15:08 --> Router Class Initialized
INFO - 2016-10-18 17:15:08 --> Output Class Initialized
INFO - 2016-10-18 17:15:08 --> Security Class Initialized
DEBUG - 2016-10-18 17:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:15:08 --> Input Class Initialized
INFO - 2016-10-18 17:15:08 --> Language Class Initialized
INFO - 2016-10-18 17:15:08 --> Loader Class Initialized
INFO - 2016-10-18 17:15:08 --> Helper loaded: url_helper
INFO - 2016-10-18 17:15:08 --> Helper loaded: form_helper
INFO - 2016-10-18 17:15:08 --> Database Driver Class Initialized
INFO - 2016-10-18 17:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:15:08 --> Controller Class Initialized
INFO - 2016-10-18 17:15:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:15:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:15:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:15:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:15:08 --> Final output sent to browser
DEBUG - 2016-10-18 17:15:08 --> Total execution time: 0.0089
INFO - 2016-10-18 17:15:35 --> Config Class Initialized
INFO - 2016-10-18 17:15:35 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:15:35 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:15:35 --> Utf8 Class Initialized
INFO - 2016-10-18 17:15:35 --> URI Class Initialized
DEBUG - 2016-10-18 17:15:35 --> No URI present. Default controller set.
INFO - 2016-10-18 17:15:35 --> Router Class Initialized
INFO - 2016-10-18 17:15:35 --> Output Class Initialized
INFO - 2016-10-18 17:15:35 --> Security Class Initialized
DEBUG - 2016-10-18 17:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:15:35 --> Input Class Initialized
INFO - 2016-10-18 17:15:35 --> Language Class Initialized
INFO - 2016-10-18 17:15:35 --> Loader Class Initialized
INFO - 2016-10-18 17:15:35 --> Helper loaded: url_helper
INFO - 2016-10-18 17:15:35 --> Helper loaded: form_helper
INFO - 2016-10-18 17:15:35 --> Database Driver Class Initialized
INFO - 2016-10-18 17:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:15:35 --> Controller Class Initialized
INFO - 2016-10-18 17:15:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:15:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:15:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:15:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:15:35 --> Final output sent to browser
DEBUG - 2016-10-18 17:15:35 --> Total execution time: 0.0052
INFO - 2016-10-18 17:16:05 --> Config Class Initialized
INFO - 2016-10-18 17:16:05 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:16:05 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:16:05 --> Utf8 Class Initialized
INFO - 2016-10-18 17:16:05 --> URI Class Initialized
DEBUG - 2016-10-18 17:16:05 --> No URI present. Default controller set.
INFO - 2016-10-18 17:16:05 --> Router Class Initialized
INFO - 2016-10-18 17:16:05 --> Output Class Initialized
INFO - 2016-10-18 17:16:05 --> Security Class Initialized
DEBUG - 2016-10-18 17:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:16:05 --> Input Class Initialized
INFO - 2016-10-18 17:16:05 --> Language Class Initialized
INFO - 2016-10-18 17:16:05 --> Loader Class Initialized
INFO - 2016-10-18 17:16:05 --> Helper loaded: url_helper
INFO - 2016-10-18 17:16:05 --> Helper loaded: form_helper
INFO - 2016-10-18 17:16:05 --> Database Driver Class Initialized
INFO - 2016-10-18 17:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:16:05 --> Controller Class Initialized
INFO - 2016-10-18 17:16:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:16:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:16:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:16:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:16:05 --> Final output sent to browser
DEBUG - 2016-10-18 17:16:05 --> Total execution time: 0.0051
INFO - 2016-10-18 17:16:38 --> Config Class Initialized
INFO - 2016-10-18 17:16:38 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:16:38 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:16:38 --> Utf8 Class Initialized
INFO - 2016-10-18 17:16:38 --> URI Class Initialized
DEBUG - 2016-10-18 17:16:38 --> No URI present. Default controller set.
INFO - 2016-10-18 17:16:38 --> Router Class Initialized
INFO - 2016-10-18 17:16:38 --> Output Class Initialized
INFO - 2016-10-18 17:16:38 --> Security Class Initialized
DEBUG - 2016-10-18 17:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:16:38 --> Input Class Initialized
INFO - 2016-10-18 17:16:38 --> Language Class Initialized
INFO - 2016-10-18 17:16:38 --> Loader Class Initialized
INFO - 2016-10-18 17:16:38 --> Helper loaded: url_helper
INFO - 2016-10-18 17:16:38 --> Helper loaded: form_helper
INFO - 2016-10-18 17:16:38 --> Database Driver Class Initialized
INFO - 2016-10-18 17:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:16:38 --> Controller Class Initialized
INFO - 2016-10-18 17:16:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:16:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:16:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:16:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:16:38 --> Final output sent to browser
DEBUG - 2016-10-18 17:16:38 --> Total execution time: 0.0052
INFO - 2016-10-18 17:16:58 --> Config Class Initialized
INFO - 2016-10-18 17:16:58 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:16:58 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:16:58 --> Utf8 Class Initialized
INFO - 2016-10-18 17:16:58 --> URI Class Initialized
DEBUG - 2016-10-18 17:16:58 --> No URI present. Default controller set.
INFO - 2016-10-18 17:16:58 --> Router Class Initialized
INFO - 2016-10-18 17:16:58 --> Output Class Initialized
INFO - 2016-10-18 17:16:58 --> Security Class Initialized
DEBUG - 2016-10-18 17:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:16:58 --> Input Class Initialized
INFO - 2016-10-18 17:16:58 --> Language Class Initialized
INFO - 2016-10-18 17:16:58 --> Loader Class Initialized
INFO - 2016-10-18 17:16:58 --> Helper loaded: url_helper
INFO - 2016-10-18 17:16:58 --> Helper loaded: form_helper
INFO - 2016-10-18 17:16:58 --> Database Driver Class Initialized
INFO - 2016-10-18 17:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:16:58 --> Controller Class Initialized
INFO - 2016-10-18 17:16:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:16:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:16:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:16:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:16:58 --> Final output sent to browser
DEBUG - 2016-10-18 17:16:58 --> Total execution time: 0.0088
INFO - 2016-10-18 17:17:45 --> Config Class Initialized
INFO - 2016-10-18 17:17:45 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:17:45 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:17:45 --> Utf8 Class Initialized
INFO - 2016-10-18 17:17:45 --> URI Class Initialized
DEBUG - 2016-10-18 17:17:45 --> No URI present. Default controller set.
INFO - 2016-10-18 17:17:45 --> Router Class Initialized
INFO - 2016-10-18 17:17:45 --> Output Class Initialized
INFO - 2016-10-18 17:17:45 --> Security Class Initialized
DEBUG - 2016-10-18 17:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:17:45 --> Input Class Initialized
INFO - 2016-10-18 17:17:45 --> Language Class Initialized
INFO - 2016-10-18 17:17:45 --> Loader Class Initialized
INFO - 2016-10-18 17:17:45 --> Helper loaded: url_helper
INFO - 2016-10-18 17:17:45 --> Helper loaded: form_helper
INFO - 2016-10-18 17:17:45 --> Database Driver Class Initialized
INFO - 2016-10-18 17:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:17:45 --> Controller Class Initialized
INFO - 2016-10-18 17:17:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:17:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:17:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:17:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:17:45 --> Final output sent to browser
DEBUG - 2016-10-18 17:17:45 --> Total execution time: 0.0053
INFO - 2016-10-18 17:17:52 --> Config Class Initialized
INFO - 2016-10-18 17:17:52 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:17:52 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:17:52 --> Utf8 Class Initialized
INFO - 2016-10-18 17:17:52 --> URI Class Initialized
INFO - 2016-10-18 17:17:52 --> Router Class Initialized
INFO - 2016-10-18 17:17:52 --> Output Class Initialized
INFO - 2016-10-18 17:17:52 --> Security Class Initialized
DEBUG - 2016-10-18 17:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:17:52 --> Input Class Initialized
INFO - 2016-10-18 17:17:52 --> Language Class Initialized
INFO - 2016-10-18 17:17:52 --> Loader Class Initialized
INFO - 2016-10-18 17:17:52 --> Helper loaded: url_helper
INFO - 2016-10-18 17:17:52 --> Helper loaded: form_helper
INFO - 2016-10-18 17:17:52 --> Database Driver Class Initialized
INFO - 2016-10-18 17:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:17:52 --> Controller Class Initialized
INFO - 2016-10-18 17:17:52 --> Form Validation Class Initialized
INFO - 2016-10-18 17:17:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 17:17:52 --> Final output sent to browser
DEBUG - 2016-10-18 17:17:52 --> Total execution time: 0.0059
INFO - 2016-10-18 17:17:57 --> Config Class Initialized
INFO - 2016-10-18 17:17:57 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:17:57 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:17:57 --> Utf8 Class Initialized
INFO - 2016-10-18 17:17:57 --> URI Class Initialized
DEBUG - 2016-10-18 17:17:57 --> No URI present. Default controller set.
INFO - 2016-10-18 17:17:57 --> Router Class Initialized
INFO - 2016-10-18 17:17:57 --> Output Class Initialized
INFO - 2016-10-18 17:17:57 --> Security Class Initialized
DEBUG - 2016-10-18 17:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:17:57 --> Input Class Initialized
INFO - 2016-10-18 17:17:57 --> Language Class Initialized
INFO - 2016-10-18 17:17:57 --> Loader Class Initialized
INFO - 2016-10-18 17:17:57 --> Helper loaded: url_helper
INFO - 2016-10-18 17:17:57 --> Helper loaded: form_helper
INFO - 2016-10-18 17:17:57 --> Database Driver Class Initialized
INFO - 2016-10-18 17:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:17:57 --> Controller Class Initialized
INFO - 2016-10-18 17:17:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:17:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:17:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:17:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:17:57 --> Final output sent to browser
DEBUG - 2016-10-18 17:17:57 --> Total execution time: 0.0049
INFO - 2016-10-18 17:18:00 --> Config Class Initialized
INFO - 2016-10-18 17:18:00 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:18:00 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:18:00 --> Utf8 Class Initialized
INFO - 2016-10-18 17:18:00 --> URI Class Initialized
INFO - 2016-10-18 17:18:00 --> Router Class Initialized
INFO - 2016-10-18 17:18:00 --> Output Class Initialized
INFO - 2016-10-18 17:18:00 --> Security Class Initialized
DEBUG - 2016-10-18 17:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:18:00 --> Input Class Initialized
INFO - 2016-10-18 17:18:00 --> Language Class Initialized
INFO - 2016-10-18 17:18:00 --> Loader Class Initialized
INFO - 2016-10-18 17:18:00 --> Helper loaded: url_helper
INFO - 2016-10-18 17:18:00 --> Helper loaded: form_helper
INFO - 2016-10-18 17:18:00 --> Database Driver Class Initialized
INFO - 2016-10-18 17:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:18:00 --> Controller Class Initialized
INFO - 2016-10-18 17:18:00 --> Form Validation Class Initialized
INFO - 2016-10-18 17:18:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 17:18:00 --> Final output sent to browser
DEBUG - 2016-10-18 17:18:00 --> Total execution time: 0.0092
INFO - 2016-10-18 17:18:10 --> Config Class Initialized
INFO - 2016-10-18 17:18:10 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:18:10 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:18:10 --> Utf8 Class Initialized
INFO - 2016-10-18 17:18:10 --> URI Class Initialized
DEBUG - 2016-10-18 17:18:10 --> No URI present. Default controller set.
INFO - 2016-10-18 17:18:10 --> Router Class Initialized
INFO - 2016-10-18 17:18:10 --> Output Class Initialized
INFO - 2016-10-18 17:18:10 --> Security Class Initialized
DEBUG - 2016-10-18 17:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:18:10 --> Input Class Initialized
INFO - 2016-10-18 17:18:10 --> Language Class Initialized
INFO - 2016-10-18 17:18:10 --> Loader Class Initialized
INFO - 2016-10-18 17:18:10 --> Helper loaded: url_helper
INFO - 2016-10-18 17:18:10 --> Helper loaded: form_helper
INFO - 2016-10-18 17:18:10 --> Database Driver Class Initialized
INFO - 2016-10-18 17:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:18:10 --> Controller Class Initialized
INFO - 2016-10-18 17:18:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:18:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:18:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:18:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:18:10 --> Final output sent to browser
DEBUG - 2016-10-18 17:18:10 --> Total execution time: 0.0079
INFO - 2016-10-18 17:21:06 --> Config Class Initialized
INFO - 2016-10-18 17:21:06 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:21:06 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:21:06 --> Utf8 Class Initialized
INFO - 2016-10-18 17:21:06 --> URI Class Initialized
DEBUG - 2016-10-18 17:21:06 --> No URI present. Default controller set.
INFO - 2016-10-18 17:21:06 --> Router Class Initialized
INFO - 2016-10-18 17:21:06 --> Output Class Initialized
INFO - 2016-10-18 17:21:06 --> Security Class Initialized
DEBUG - 2016-10-18 17:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:21:06 --> Input Class Initialized
INFO - 2016-10-18 17:21:06 --> Language Class Initialized
INFO - 2016-10-18 17:21:06 --> Loader Class Initialized
INFO - 2016-10-18 17:21:06 --> Helper loaded: url_helper
INFO - 2016-10-18 17:21:06 --> Helper loaded: form_helper
INFO - 2016-10-18 17:21:06 --> Database Driver Class Initialized
INFO - 2016-10-18 17:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:21:06 --> Controller Class Initialized
INFO - 2016-10-18 17:21:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:21:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:21:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:21:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:21:06 --> Final output sent to browser
DEBUG - 2016-10-18 17:21:06 --> Total execution time: 0.0055
INFO - 2016-10-18 17:21:21 --> Config Class Initialized
INFO - 2016-10-18 17:21:21 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:21:21 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:21:21 --> Utf8 Class Initialized
INFO - 2016-10-18 17:21:21 --> URI Class Initialized
DEBUG - 2016-10-18 17:21:21 --> No URI present. Default controller set.
INFO - 2016-10-18 17:21:21 --> Router Class Initialized
INFO - 2016-10-18 17:21:21 --> Output Class Initialized
INFO - 2016-10-18 17:21:21 --> Security Class Initialized
DEBUG - 2016-10-18 17:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:21:21 --> Input Class Initialized
INFO - 2016-10-18 17:21:21 --> Language Class Initialized
INFO - 2016-10-18 17:21:21 --> Loader Class Initialized
INFO - 2016-10-18 17:21:21 --> Helper loaded: url_helper
INFO - 2016-10-18 17:21:21 --> Helper loaded: form_helper
INFO - 2016-10-18 17:21:21 --> Database Driver Class Initialized
INFO - 2016-10-18 17:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:21:21 --> Controller Class Initialized
INFO - 2016-10-18 17:21:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:21:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:21:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:21:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:21:21 --> Final output sent to browser
DEBUG - 2016-10-18 17:21:21 --> Total execution time: 0.0083
INFO - 2016-10-18 17:21:34 --> Config Class Initialized
INFO - 2016-10-18 17:21:34 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:21:34 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:21:34 --> Utf8 Class Initialized
INFO - 2016-10-18 17:21:34 --> URI Class Initialized
DEBUG - 2016-10-18 17:21:34 --> No URI present. Default controller set.
INFO - 2016-10-18 17:21:34 --> Router Class Initialized
INFO - 2016-10-18 17:21:34 --> Output Class Initialized
INFO - 2016-10-18 17:21:34 --> Security Class Initialized
DEBUG - 2016-10-18 17:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:21:34 --> Input Class Initialized
INFO - 2016-10-18 17:21:34 --> Language Class Initialized
INFO - 2016-10-18 17:21:34 --> Loader Class Initialized
INFO - 2016-10-18 17:21:34 --> Helper loaded: url_helper
INFO - 2016-10-18 17:21:34 --> Helper loaded: form_helper
INFO - 2016-10-18 17:21:34 --> Database Driver Class Initialized
INFO - 2016-10-18 17:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:21:34 --> Controller Class Initialized
INFO - 2016-10-18 17:21:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:21:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:21:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:21:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:21:34 --> Final output sent to browser
DEBUG - 2016-10-18 17:21:34 --> Total execution time: 0.0075
INFO - 2016-10-18 17:22:09 --> Config Class Initialized
INFO - 2016-10-18 17:22:09 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:22:09 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:22:09 --> Utf8 Class Initialized
INFO - 2016-10-18 17:22:09 --> URI Class Initialized
DEBUG - 2016-10-18 17:22:09 --> No URI present. Default controller set.
INFO - 2016-10-18 17:22:09 --> Router Class Initialized
INFO - 2016-10-18 17:22:09 --> Output Class Initialized
INFO - 2016-10-18 17:22:09 --> Security Class Initialized
DEBUG - 2016-10-18 17:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:22:09 --> Input Class Initialized
INFO - 2016-10-18 17:22:09 --> Language Class Initialized
INFO - 2016-10-18 17:22:09 --> Loader Class Initialized
INFO - 2016-10-18 17:22:09 --> Helper loaded: url_helper
INFO - 2016-10-18 17:22:09 --> Helper loaded: form_helper
INFO - 2016-10-18 17:22:09 --> Database Driver Class Initialized
INFO - 2016-10-18 17:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:22:09 --> Controller Class Initialized
INFO - 2016-10-18 17:22:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:22:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:22:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:22:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:22:09 --> Final output sent to browser
DEBUG - 2016-10-18 17:22:09 --> Total execution time: 0.0076
INFO - 2016-10-18 17:23:24 --> Config Class Initialized
INFO - 2016-10-18 17:23:24 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:23:24 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:23:24 --> Utf8 Class Initialized
INFO - 2016-10-18 17:23:24 --> URI Class Initialized
DEBUG - 2016-10-18 17:23:24 --> No URI present. Default controller set.
INFO - 2016-10-18 17:23:24 --> Router Class Initialized
INFO - 2016-10-18 17:23:24 --> Output Class Initialized
INFO - 2016-10-18 17:23:24 --> Security Class Initialized
DEBUG - 2016-10-18 17:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:23:24 --> Input Class Initialized
INFO - 2016-10-18 17:23:24 --> Language Class Initialized
INFO - 2016-10-18 17:23:24 --> Loader Class Initialized
INFO - 2016-10-18 17:23:24 --> Helper loaded: url_helper
INFO - 2016-10-18 17:23:24 --> Helper loaded: form_helper
INFO - 2016-10-18 17:23:24 --> Database Driver Class Initialized
INFO - 2016-10-18 17:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:23:24 --> Controller Class Initialized
INFO - 2016-10-18 17:23:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:23:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:23:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:23:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:23:24 --> Final output sent to browser
DEBUG - 2016-10-18 17:23:24 --> Total execution time: 0.0062
INFO - 2016-10-18 17:23:41 --> Config Class Initialized
INFO - 2016-10-18 17:23:41 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:23:41 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:23:41 --> Utf8 Class Initialized
INFO - 2016-10-18 17:23:41 --> URI Class Initialized
DEBUG - 2016-10-18 17:23:41 --> No URI present. Default controller set.
INFO - 2016-10-18 17:23:41 --> Router Class Initialized
INFO - 2016-10-18 17:23:41 --> Output Class Initialized
INFO - 2016-10-18 17:23:41 --> Security Class Initialized
DEBUG - 2016-10-18 17:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:23:41 --> Input Class Initialized
INFO - 2016-10-18 17:23:41 --> Language Class Initialized
INFO - 2016-10-18 17:23:41 --> Loader Class Initialized
INFO - 2016-10-18 17:23:41 --> Helper loaded: url_helper
INFO - 2016-10-18 17:23:41 --> Helper loaded: form_helper
INFO - 2016-10-18 17:23:41 --> Database Driver Class Initialized
INFO - 2016-10-18 17:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:23:41 --> Controller Class Initialized
INFO - 2016-10-18 17:23:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:23:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:23:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:23:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:23:41 --> Final output sent to browser
DEBUG - 2016-10-18 17:23:41 --> Total execution time: 0.0076
INFO - 2016-10-18 17:24:01 --> Config Class Initialized
INFO - 2016-10-18 17:24:01 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:24:01 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:24:01 --> Utf8 Class Initialized
INFO - 2016-10-18 17:24:01 --> URI Class Initialized
DEBUG - 2016-10-18 17:24:01 --> No URI present. Default controller set.
INFO - 2016-10-18 17:24:01 --> Router Class Initialized
INFO - 2016-10-18 17:24:01 --> Output Class Initialized
INFO - 2016-10-18 17:24:01 --> Security Class Initialized
DEBUG - 2016-10-18 17:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:24:01 --> Input Class Initialized
INFO - 2016-10-18 17:24:01 --> Language Class Initialized
INFO - 2016-10-18 17:24:01 --> Loader Class Initialized
INFO - 2016-10-18 17:24:01 --> Helper loaded: url_helper
INFO - 2016-10-18 17:24:01 --> Helper loaded: form_helper
INFO - 2016-10-18 17:24:01 --> Database Driver Class Initialized
INFO - 2016-10-18 17:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:24:01 --> Controller Class Initialized
INFO - 2016-10-18 17:24:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:24:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:24:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:24:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:24:01 --> Final output sent to browser
DEBUG - 2016-10-18 17:24:01 --> Total execution time: 0.0049
INFO - 2016-10-18 17:25:37 --> Config Class Initialized
INFO - 2016-10-18 17:25:37 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:25:37 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:25:37 --> Utf8 Class Initialized
INFO - 2016-10-18 17:25:37 --> URI Class Initialized
DEBUG - 2016-10-18 17:25:37 --> No URI present. Default controller set.
INFO - 2016-10-18 17:25:37 --> Router Class Initialized
INFO - 2016-10-18 17:25:37 --> Output Class Initialized
INFO - 2016-10-18 17:25:37 --> Security Class Initialized
DEBUG - 2016-10-18 17:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:25:37 --> Input Class Initialized
INFO - 2016-10-18 17:25:37 --> Language Class Initialized
INFO - 2016-10-18 17:25:37 --> Loader Class Initialized
INFO - 2016-10-18 17:25:37 --> Helper loaded: url_helper
INFO - 2016-10-18 17:25:37 --> Helper loaded: form_helper
INFO - 2016-10-18 17:25:37 --> Database Driver Class Initialized
INFO - 2016-10-18 17:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:25:37 --> Controller Class Initialized
INFO - 2016-10-18 17:25:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:25:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:25:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:25:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:25:37 --> Final output sent to browser
DEBUG - 2016-10-18 17:25:37 --> Total execution time: 0.0083
INFO - 2016-10-18 17:26:37 --> Config Class Initialized
INFO - 2016-10-18 17:26:37 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:26:37 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:26:37 --> Utf8 Class Initialized
INFO - 2016-10-18 17:26:37 --> URI Class Initialized
DEBUG - 2016-10-18 17:26:37 --> No URI present. Default controller set.
INFO - 2016-10-18 17:26:37 --> Router Class Initialized
INFO - 2016-10-18 17:26:37 --> Output Class Initialized
INFO - 2016-10-18 17:26:37 --> Security Class Initialized
DEBUG - 2016-10-18 17:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:26:37 --> Input Class Initialized
INFO - 2016-10-18 17:26:37 --> Language Class Initialized
INFO - 2016-10-18 17:26:37 --> Loader Class Initialized
INFO - 2016-10-18 17:26:37 --> Helper loaded: url_helper
INFO - 2016-10-18 17:26:37 --> Helper loaded: form_helper
INFO - 2016-10-18 17:26:37 --> Database Driver Class Initialized
INFO - 2016-10-18 17:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:26:37 --> Controller Class Initialized
INFO - 2016-10-18 17:26:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:26:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:26:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:26:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:26:37 --> Final output sent to browser
DEBUG - 2016-10-18 17:26:37 --> Total execution time: 0.0057
INFO - 2016-10-18 17:26:44 --> Config Class Initialized
INFO - 2016-10-18 17:26:44 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:26:44 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:26:44 --> Utf8 Class Initialized
INFO - 2016-10-18 17:26:44 --> URI Class Initialized
DEBUG - 2016-10-18 17:26:44 --> No URI present. Default controller set.
INFO - 2016-10-18 17:26:44 --> Router Class Initialized
INFO - 2016-10-18 17:26:44 --> Output Class Initialized
INFO - 2016-10-18 17:26:44 --> Security Class Initialized
DEBUG - 2016-10-18 17:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:26:44 --> Input Class Initialized
INFO - 2016-10-18 17:26:44 --> Language Class Initialized
INFO - 2016-10-18 17:26:44 --> Loader Class Initialized
INFO - 2016-10-18 17:26:44 --> Helper loaded: url_helper
INFO - 2016-10-18 17:26:44 --> Helper loaded: form_helper
INFO - 2016-10-18 17:26:44 --> Database Driver Class Initialized
INFO - 2016-10-18 17:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:26:44 --> Controller Class Initialized
INFO - 2016-10-18 17:26:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:26:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:26:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:26:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:26:44 --> Final output sent to browser
DEBUG - 2016-10-18 17:26:44 --> Total execution time: 0.0052
INFO - 2016-10-18 17:27:11 --> Config Class Initialized
INFO - 2016-10-18 17:27:11 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:27:11 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:27:11 --> Utf8 Class Initialized
INFO - 2016-10-18 17:27:11 --> URI Class Initialized
DEBUG - 2016-10-18 17:27:11 --> No URI present. Default controller set.
INFO - 2016-10-18 17:27:11 --> Router Class Initialized
INFO - 2016-10-18 17:27:11 --> Output Class Initialized
INFO - 2016-10-18 17:27:11 --> Security Class Initialized
DEBUG - 2016-10-18 17:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:27:11 --> Input Class Initialized
INFO - 2016-10-18 17:27:11 --> Language Class Initialized
INFO - 2016-10-18 17:27:11 --> Loader Class Initialized
INFO - 2016-10-18 17:27:11 --> Helper loaded: url_helper
INFO - 2016-10-18 17:27:11 --> Helper loaded: form_helper
INFO - 2016-10-18 17:27:11 --> Database Driver Class Initialized
INFO - 2016-10-18 17:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:27:11 --> Controller Class Initialized
INFO - 2016-10-18 17:27:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:27:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:27:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:27:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:27:11 --> Final output sent to browser
DEBUG - 2016-10-18 17:27:11 --> Total execution time: 0.0052
INFO - 2016-10-18 17:28:05 --> Config Class Initialized
INFO - 2016-10-18 17:28:05 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:28:05 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:28:05 --> Utf8 Class Initialized
INFO - 2016-10-18 17:28:05 --> URI Class Initialized
DEBUG - 2016-10-18 17:28:05 --> No URI present. Default controller set.
INFO - 2016-10-18 17:28:05 --> Router Class Initialized
INFO - 2016-10-18 17:28:05 --> Output Class Initialized
INFO - 2016-10-18 17:28:05 --> Security Class Initialized
DEBUG - 2016-10-18 17:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:28:05 --> Input Class Initialized
INFO - 2016-10-18 17:28:05 --> Language Class Initialized
INFO - 2016-10-18 17:28:05 --> Loader Class Initialized
INFO - 2016-10-18 17:28:05 --> Helper loaded: url_helper
INFO - 2016-10-18 17:28:05 --> Helper loaded: form_helper
INFO - 2016-10-18 17:28:05 --> Database Driver Class Initialized
INFO - 2016-10-18 17:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:28:05 --> Controller Class Initialized
INFO - 2016-10-18 17:28:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:28:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:28:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:28:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:28:05 --> Final output sent to browser
DEBUG - 2016-10-18 17:28:05 --> Total execution time: 0.0078
INFO - 2016-10-18 17:29:20 --> Config Class Initialized
INFO - 2016-10-18 17:29:20 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:29:20 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:29:20 --> Utf8 Class Initialized
INFO - 2016-10-18 17:29:20 --> URI Class Initialized
DEBUG - 2016-10-18 17:29:20 --> No URI present. Default controller set.
INFO - 2016-10-18 17:29:20 --> Router Class Initialized
INFO - 2016-10-18 17:29:20 --> Output Class Initialized
INFO - 2016-10-18 17:29:20 --> Security Class Initialized
DEBUG - 2016-10-18 17:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:29:20 --> Input Class Initialized
INFO - 2016-10-18 17:29:20 --> Language Class Initialized
INFO - 2016-10-18 17:29:20 --> Loader Class Initialized
INFO - 2016-10-18 17:29:20 --> Helper loaded: url_helper
INFO - 2016-10-18 17:29:20 --> Helper loaded: form_helper
INFO - 2016-10-18 17:29:20 --> Database Driver Class Initialized
INFO - 2016-10-18 17:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:29:20 --> Controller Class Initialized
INFO - 2016-10-18 17:29:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:29:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:29:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:29:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:29:20 --> Final output sent to browser
DEBUG - 2016-10-18 17:29:20 --> Total execution time: 0.0056
INFO - 2016-10-18 17:29:59 --> Config Class Initialized
INFO - 2016-10-18 17:29:59 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:29:59 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:29:59 --> Utf8 Class Initialized
INFO - 2016-10-18 17:29:59 --> URI Class Initialized
DEBUG - 2016-10-18 17:29:59 --> No URI present. Default controller set.
INFO - 2016-10-18 17:29:59 --> Router Class Initialized
INFO - 2016-10-18 17:29:59 --> Output Class Initialized
INFO - 2016-10-18 17:29:59 --> Security Class Initialized
DEBUG - 2016-10-18 17:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:29:59 --> Input Class Initialized
INFO - 2016-10-18 17:29:59 --> Language Class Initialized
INFO - 2016-10-18 17:29:59 --> Loader Class Initialized
INFO - 2016-10-18 17:29:59 --> Helper loaded: url_helper
INFO - 2016-10-18 17:29:59 --> Helper loaded: form_helper
INFO - 2016-10-18 17:29:59 --> Database Driver Class Initialized
INFO - 2016-10-18 17:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:29:59 --> Controller Class Initialized
INFO - 2016-10-18 17:29:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:29:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:29:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:29:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:29:59 --> Final output sent to browser
DEBUG - 2016-10-18 17:29:59 --> Total execution time: 0.0052
INFO - 2016-10-18 17:30:02 --> Config Class Initialized
INFO - 2016-10-18 17:30:02 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:30:02 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:30:02 --> Utf8 Class Initialized
INFO - 2016-10-18 17:30:02 --> URI Class Initialized
INFO - 2016-10-18 17:30:02 --> Router Class Initialized
INFO - 2016-10-18 17:30:02 --> Output Class Initialized
INFO - 2016-10-18 17:30:02 --> Security Class Initialized
DEBUG - 2016-10-18 17:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:30:02 --> Input Class Initialized
INFO - 2016-10-18 17:30:02 --> Language Class Initialized
INFO - 2016-10-18 17:30:02 --> Loader Class Initialized
INFO - 2016-10-18 17:30:02 --> Helper loaded: url_helper
INFO - 2016-10-18 17:30:02 --> Helper loaded: form_helper
INFO - 2016-10-18 17:30:02 --> Database Driver Class Initialized
INFO - 2016-10-18 17:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:30:02 --> Controller Class Initialized
INFO - 2016-10-18 17:30:02 --> Form Validation Class Initialized
INFO - 2016-10-18 17:30:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 17:30:02 --> Final output sent to browser
DEBUG - 2016-10-18 17:30:02 --> Total execution time: 0.0060
INFO - 2016-10-18 17:30:11 --> Config Class Initialized
INFO - 2016-10-18 17:30:11 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:30:11 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:30:11 --> Utf8 Class Initialized
INFO - 2016-10-18 17:30:11 --> URI Class Initialized
DEBUG - 2016-10-18 17:30:11 --> No URI present. Default controller set.
INFO - 2016-10-18 17:30:11 --> Router Class Initialized
INFO - 2016-10-18 17:30:11 --> Output Class Initialized
INFO - 2016-10-18 17:30:11 --> Security Class Initialized
DEBUG - 2016-10-18 17:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:30:11 --> Input Class Initialized
INFO - 2016-10-18 17:30:11 --> Language Class Initialized
INFO - 2016-10-18 17:30:11 --> Loader Class Initialized
INFO - 2016-10-18 17:30:11 --> Helper loaded: url_helper
INFO - 2016-10-18 17:30:11 --> Helper loaded: form_helper
INFO - 2016-10-18 17:30:11 --> Database Driver Class Initialized
INFO - 2016-10-18 17:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:30:11 --> Controller Class Initialized
INFO - 2016-10-18 17:30:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:30:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:30:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:30:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:30:11 --> Final output sent to browser
DEBUG - 2016-10-18 17:30:11 --> Total execution time: 0.0079
INFO - 2016-10-18 17:30:14 --> Config Class Initialized
INFO - 2016-10-18 17:30:14 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:30:14 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:30:14 --> Utf8 Class Initialized
INFO - 2016-10-18 17:30:14 --> URI Class Initialized
INFO - 2016-10-18 17:30:14 --> Router Class Initialized
INFO - 2016-10-18 17:30:14 --> Output Class Initialized
INFO - 2016-10-18 17:30:14 --> Security Class Initialized
DEBUG - 2016-10-18 17:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:30:14 --> Input Class Initialized
INFO - 2016-10-18 17:30:14 --> Language Class Initialized
INFO - 2016-10-18 17:30:14 --> Loader Class Initialized
INFO - 2016-10-18 17:30:14 --> Helper loaded: url_helper
INFO - 2016-10-18 17:30:14 --> Helper loaded: form_helper
INFO - 2016-10-18 17:30:14 --> Database Driver Class Initialized
INFO - 2016-10-18 17:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:30:14 --> Controller Class Initialized
INFO - 2016-10-18 17:30:14 --> Form Validation Class Initialized
INFO - 2016-10-18 17:30:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 17:30:14 --> Final output sent to browser
DEBUG - 2016-10-18 17:30:14 --> Total execution time: 0.0066
INFO - 2016-10-18 17:31:12 --> Config Class Initialized
INFO - 2016-10-18 17:31:12 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:31:12 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:31:12 --> Utf8 Class Initialized
INFO - 2016-10-18 17:31:12 --> URI Class Initialized
DEBUG - 2016-10-18 17:31:12 --> No URI present. Default controller set.
INFO - 2016-10-18 17:31:12 --> Router Class Initialized
INFO - 2016-10-18 17:31:12 --> Output Class Initialized
INFO - 2016-10-18 17:31:12 --> Security Class Initialized
DEBUG - 2016-10-18 17:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:31:12 --> Input Class Initialized
INFO - 2016-10-18 17:31:12 --> Language Class Initialized
INFO - 2016-10-18 17:31:12 --> Loader Class Initialized
INFO - 2016-10-18 17:31:12 --> Helper loaded: url_helper
INFO - 2016-10-18 17:31:12 --> Helper loaded: form_helper
INFO - 2016-10-18 17:31:12 --> Database Driver Class Initialized
INFO - 2016-10-18 17:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:31:12 --> Controller Class Initialized
INFO - 2016-10-18 17:31:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:31:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:31:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:31:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:31:12 --> Final output sent to browser
DEBUG - 2016-10-18 17:31:12 --> Total execution time: 0.0056
INFO - 2016-10-18 17:31:16 --> Config Class Initialized
INFO - 2016-10-18 17:31:16 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:31:16 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:31:16 --> Utf8 Class Initialized
INFO - 2016-10-18 17:31:16 --> URI Class Initialized
INFO - 2016-10-18 17:31:16 --> Router Class Initialized
INFO - 2016-10-18 17:31:16 --> Output Class Initialized
INFO - 2016-10-18 17:31:16 --> Security Class Initialized
DEBUG - 2016-10-18 17:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:31:16 --> Input Class Initialized
INFO - 2016-10-18 17:31:16 --> Language Class Initialized
INFO - 2016-10-18 17:31:16 --> Loader Class Initialized
INFO - 2016-10-18 17:31:16 --> Helper loaded: url_helper
INFO - 2016-10-18 17:31:16 --> Helper loaded: form_helper
INFO - 2016-10-18 17:31:16 --> Database Driver Class Initialized
INFO - 2016-10-18 17:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:31:16 --> Controller Class Initialized
INFO - 2016-10-18 17:31:16 --> Form Validation Class Initialized
INFO - 2016-10-18 17:31:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 17:31:16 --> Final output sent to browser
DEBUG - 2016-10-18 17:31:16 --> Total execution time: 0.0064
INFO - 2016-10-18 17:31:27 --> Config Class Initialized
INFO - 2016-10-18 17:31:27 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:31:27 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:31:27 --> Utf8 Class Initialized
INFO - 2016-10-18 17:31:27 --> URI Class Initialized
DEBUG - 2016-10-18 17:31:27 --> No URI present. Default controller set.
INFO - 2016-10-18 17:31:27 --> Router Class Initialized
INFO - 2016-10-18 17:31:27 --> Output Class Initialized
INFO - 2016-10-18 17:31:27 --> Security Class Initialized
DEBUG - 2016-10-18 17:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:31:27 --> Input Class Initialized
INFO - 2016-10-18 17:31:27 --> Language Class Initialized
INFO - 2016-10-18 17:31:27 --> Loader Class Initialized
INFO - 2016-10-18 17:31:27 --> Helper loaded: url_helper
INFO - 2016-10-18 17:31:27 --> Helper loaded: form_helper
INFO - 2016-10-18 17:31:27 --> Database Driver Class Initialized
INFO - 2016-10-18 17:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:31:27 --> Controller Class Initialized
INFO - 2016-10-18 17:31:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:31:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:31:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:31:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:31:27 --> Final output sent to browser
DEBUG - 2016-10-18 17:31:27 --> Total execution time: 0.0056
INFO - 2016-10-18 17:32:43 --> Config Class Initialized
INFO - 2016-10-18 17:32:43 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:32:43 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:32:43 --> Utf8 Class Initialized
INFO - 2016-10-18 17:32:43 --> URI Class Initialized
DEBUG - 2016-10-18 17:32:43 --> No URI present. Default controller set.
INFO - 2016-10-18 17:32:43 --> Router Class Initialized
INFO - 2016-10-18 17:32:43 --> Output Class Initialized
INFO - 2016-10-18 17:32:43 --> Security Class Initialized
DEBUG - 2016-10-18 17:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:32:43 --> Input Class Initialized
INFO - 2016-10-18 17:32:43 --> Language Class Initialized
INFO - 2016-10-18 17:32:43 --> Loader Class Initialized
INFO - 2016-10-18 17:32:43 --> Helper loaded: url_helper
INFO - 2016-10-18 17:32:43 --> Helper loaded: form_helper
INFO - 2016-10-18 17:32:43 --> Database Driver Class Initialized
INFO - 2016-10-18 17:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:32:43 --> Controller Class Initialized
INFO - 2016-10-18 17:32:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:32:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:32:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:32:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:32:43 --> Final output sent to browser
DEBUG - 2016-10-18 17:32:43 --> Total execution time: 0.0058
INFO - 2016-10-18 17:33:23 --> Config Class Initialized
INFO - 2016-10-18 17:33:23 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:33:23 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:33:23 --> Utf8 Class Initialized
INFO - 2016-10-18 17:33:23 --> URI Class Initialized
DEBUG - 2016-10-18 17:33:23 --> No URI present. Default controller set.
INFO - 2016-10-18 17:33:23 --> Router Class Initialized
INFO - 2016-10-18 17:33:23 --> Output Class Initialized
INFO - 2016-10-18 17:33:23 --> Security Class Initialized
DEBUG - 2016-10-18 17:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:33:23 --> Input Class Initialized
INFO - 2016-10-18 17:33:23 --> Language Class Initialized
INFO - 2016-10-18 17:33:23 --> Loader Class Initialized
INFO - 2016-10-18 17:33:23 --> Helper loaded: url_helper
INFO - 2016-10-18 17:33:23 --> Helper loaded: form_helper
INFO - 2016-10-18 17:33:23 --> Database Driver Class Initialized
INFO - 2016-10-18 17:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:33:23 --> Controller Class Initialized
INFO - 2016-10-18 17:33:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:33:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:33:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:33:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:33:23 --> Final output sent to browser
DEBUG - 2016-10-18 17:33:23 --> Total execution time: 0.0127
INFO - 2016-10-18 17:33:37 --> Config Class Initialized
INFO - 2016-10-18 17:33:37 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:33:37 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:33:37 --> Utf8 Class Initialized
INFO - 2016-10-18 17:33:37 --> URI Class Initialized
DEBUG - 2016-10-18 17:33:37 --> No URI present. Default controller set.
INFO - 2016-10-18 17:33:37 --> Router Class Initialized
INFO - 2016-10-18 17:33:37 --> Output Class Initialized
INFO - 2016-10-18 17:33:37 --> Security Class Initialized
DEBUG - 2016-10-18 17:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:33:37 --> Input Class Initialized
INFO - 2016-10-18 17:33:37 --> Language Class Initialized
INFO - 2016-10-18 17:33:37 --> Loader Class Initialized
INFO - 2016-10-18 17:33:37 --> Helper loaded: url_helper
INFO - 2016-10-18 17:33:37 --> Helper loaded: form_helper
INFO - 2016-10-18 17:33:37 --> Database Driver Class Initialized
INFO - 2016-10-18 17:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:33:37 --> Controller Class Initialized
INFO - 2016-10-18 17:33:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:33:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:33:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:33:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:33:37 --> Final output sent to browser
DEBUG - 2016-10-18 17:33:37 --> Total execution time: 0.0059
INFO - 2016-10-18 17:34:34 --> Config Class Initialized
INFO - 2016-10-18 17:34:34 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:34:34 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:34:34 --> Utf8 Class Initialized
INFO - 2016-10-18 17:34:34 --> URI Class Initialized
DEBUG - 2016-10-18 17:34:34 --> No URI present. Default controller set.
INFO - 2016-10-18 17:34:34 --> Router Class Initialized
INFO - 2016-10-18 17:34:34 --> Output Class Initialized
INFO - 2016-10-18 17:34:34 --> Security Class Initialized
DEBUG - 2016-10-18 17:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:34:34 --> Input Class Initialized
INFO - 2016-10-18 17:34:34 --> Language Class Initialized
INFO - 2016-10-18 17:34:34 --> Loader Class Initialized
INFO - 2016-10-18 17:34:34 --> Helper loaded: url_helper
INFO - 2016-10-18 17:34:34 --> Helper loaded: form_helper
INFO - 2016-10-18 17:34:34 --> Database Driver Class Initialized
INFO - 2016-10-18 17:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:34:34 --> Controller Class Initialized
INFO - 2016-10-18 17:34:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:34:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:34:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:34:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:34:34 --> Final output sent to browser
DEBUG - 2016-10-18 17:34:34 --> Total execution time: 0.0052
INFO - 2016-10-18 17:34:38 --> Config Class Initialized
INFO - 2016-10-18 17:34:38 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:34:38 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:34:38 --> Utf8 Class Initialized
INFO - 2016-10-18 17:34:38 --> URI Class Initialized
INFO - 2016-10-18 17:34:38 --> Router Class Initialized
INFO - 2016-10-18 17:34:38 --> Output Class Initialized
INFO - 2016-10-18 17:34:38 --> Security Class Initialized
DEBUG - 2016-10-18 17:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:34:38 --> Input Class Initialized
INFO - 2016-10-18 17:34:38 --> Language Class Initialized
INFO - 2016-10-18 17:34:38 --> Loader Class Initialized
INFO - 2016-10-18 17:34:38 --> Helper loaded: url_helper
INFO - 2016-10-18 17:34:38 --> Helper loaded: form_helper
INFO - 2016-10-18 17:34:38 --> Database Driver Class Initialized
INFO - 2016-10-18 17:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:34:38 --> Controller Class Initialized
INFO - 2016-10-18 17:34:38 --> Form Validation Class Initialized
INFO - 2016-10-18 17:34:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 17:34:38 --> Final output sent to browser
DEBUG - 2016-10-18 17:34:38 --> Total execution time: 0.0125
INFO - 2016-10-18 17:34:41 --> Config Class Initialized
INFO - 2016-10-18 17:34:41 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:34:41 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:34:41 --> Utf8 Class Initialized
INFO - 2016-10-18 17:34:41 --> URI Class Initialized
DEBUG - 2016-10-18 17:34:41 --> No URI present. Default controller set.
INFO - 2016-10-18 17:34:41 --> Router Class Initialized
INFO - 2016-10-18 17:34:41 --> Output Class Initialized
INFO - 2016-10-18 17:34:41 --> Security Class Initialized
DEBUG - 2016-10-18 17:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:34:41 --> Input Class Initialized
INFO - 2016-10-18 17:34:41 --> Language Class Initialized
INFO - 2016-10-18 17:34:41 --> Loader Class Initialized
INFO - 2016-10-18 17:34:41 --> Helper loaded: url_helper
INFO - 2016-10-18 17:34:41 --> Helper loaded: form_helper
INFO - 2016-10-18 17:34:41 --> Database Driver Class Initialized
INFO - 2016-10-18 17:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:34:41 --> Controller Class Initialized
INFO - 2016-10-18 17:34:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:34:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:34:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:34:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:34:41 --> Final output sent to browser
DEBUG - 2016-10-18 17:34:41 --> Total execution time: 0.0052
INFO - 2016-10-18 17:36:02 --> Config Class Initialized
INFO - 2016-10-18 17:36:02 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:36:02 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:36:02 --> Utf8 Class Initialized
INFO - 2016-10-18 17:36:02 --> URI Class Initialized
DEBUG - 2016-10-18 17:36:02 --> No URI present. Default controller set.
INFO - 2016-10-18 17:36:02 --> Router Class Initialized
INFO - 2016-10-18 17:36:02 --> Output Class Initialized
INFO - 2016-10-18 17:36:02 --> Security Class Initialized
DEBUG - 2016-10-18 17:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:36:02 --> Input Class Initialized
INFO - 2016-10-18 17:36:02 --> Language Class Initialized
INFO - 2016-10-18 17:36:02 --> Loader Class Initialized
INFO - 2016-10-18 17:36:02 --> Helper loaded: url_helper
INFO - 2016-10-18 17:36:02 --> Helper loaded: form_helper
INFO - 2016-10-18 17:36:02 --> Database Driver Class Initialized
INFO - 2016-10-18 17:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:36:02 --> Controller Class Initialized
INFO - 2016-10-18 17:36:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:36:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:36:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:36:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:36:02 --> Final output sent to browser
DEBUG - 2016-10-18 17:36:02 --> Total execution time: 0.0086
INFO - 2016-10-18 17:36:06 --> Config Class Initialized
INFO - 2016-10-18 17:36:06 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:36:06 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:36:06 --> Utf8 Class Initialized
INFO - 2016-10-18 17:36:06 --> URI Class Initialized
INFO - 2016-10-18 17:36:06 --> Router Class Initialized
INFO - 2016-10-18 17:36:06 --> Output Class Initialized
INFO - 2016-10-18 17:36:06 --> Security Class Initialized
DEBUG - 2016-10-18 17:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:36:06 --> Input Class Initialized
INFO - 2016-10-18 17:36:06 --> Language Class Initialized
INFO - 2016-10-18 17:36:06 --> Loader Class Initialized
INFO - 2016-10-18 17:36:06 --> Helper loaded: url_helper
INFO - 2016-10-18 17:36:06 --> Helper loaded: form_helper
INFO - 2016-10-18 17:36:06 --> Database Driver Class Initialized
INFO - 2016-10-18 17:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:36:06 --> Controller Class Initialized
INFO - 2016-10-18 17:36:06 --> Form Validation Class Initialized
INFO - 2016-10-18 17:36:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 17:36:06 --> Final output sent to browser
DEBUG - 2016-10-18 17:36:06 --> Total execution time: 0.0060
INFO - 2016-10-18 17:36:34 --> Config Class Initialized
INFO - 2016-10-18 17:36:34 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:36:34 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:36:34 --> Utf8 Class Initialized
INFO - 2016-10-18 17:36:34 --> URI Class Initialized
DEBUG - 2016-10-18 17:36:34 --> No URI present. Default controller set.
INFO - 2016-10-18 17:36:34 --> Router Class Initialized
INFO - 2016-10-18 17:36:34 --> Output Class Initialized
INFO - 2016-10-18 17:36:34 --> Security Class Initialized
DEBUG - 2016-10-18 17:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:36:34 --> Input Class Initialized
INFO - 2016-10-18 17:36:34 --> Language Class Initialized
INFO - 2016-10-18 17:36:34 --> Loader Class Initialized
INFO - 2016-10-18 17:36:34 --> Helper loaded: url_helper
INFO - 2016-10-18 17:36:34 --> Helper loaded: form_helper
INFO - 2016-10-18 17:36:34 --> Database Driver Class Initialized
INFO - 2016-10-18 17:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:36:34 --> Controller Class Initialized
INFO - 2016-10-18 17:36:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:36:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:36:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:36:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:36:34 --> Final output sent to browser
DEBUG - 2016-10-18 17:36:34 --> Total execution time: 0.0081
INFO - 2016-10-18 17:38:22 --> Config Class Initialized
INFO - 2016-10-18 17:38:22 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:38:22 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:38:22 --> Utf8 Class Initialized
INFO - 2016-10-18 17:38:22 --> URI Class Initialized
DEBUG - 2016-10-18 17:38:22 --> No URI present. Default controller set.
INFO - 2016-10-18 17:38:22 --> Router Class Initialized
INFO - 2016-10-18 17:38:22 --> Output Class Initialized
INFO - 2016-10-18 17:38:22 --> Security Class Initialized
DEBUG - 2016-10-18 17:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:38:22 --> Input Class Initialized
INFO - 2016-10-18 17:38:22 --> Language Class Initialized
INFO - 2016-10-18 17:38:22 --> Loader Class Initialized
INFO - 2016-10-18 17:38:22 --> Helper loaded: url_helper
INFO - 2016-10-18 17:38:22 --> Helper loaded: form_helper
INFO - 2016-10-18 17:38:22 --> Database Driver Class Initialized
INFO - 2016-10-18 17:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:38:22 --> Controller Class Initialized
INFO - 2016-10-18 17:38:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:38:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:38:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:38:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:38:22 --> Final output sent to browser
DEBUG - 2016-10-18 17:38:22 --> Total execution time: 0.0065
INFO - 2016-10-18 17:38:58 --> Config Class Initialized
INFO - 2016-10-18 17:38:58 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:38:58 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:38:58 --> Utf8 Class Initialized
INFO - 2016-10-18 17:38:58 --> URI Class Initialized
DEBUG - 2016-10-18 17:38:58 --> No URI present. Default controller set.
INFO - 2016-10-18 17:38:58 --> Router Class Initialized
INFO - 2016-10-18 17:38:58 --> Output Class Initialized
INFO - 2016-10-18 17:38:58 --> Security Class Initialized
DEBUG - 2016-10-18 17:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:38:58 --> Input Class Initialized
INFO - 2016-10-18 17:38:58 --> Language Class Initialized
INFO - 2016-10-18 17:38:58 --> Loader Class Initialized
INFO - 2016-10-18 17:38:58 --> Helper loaded: url_helper
INFO - 2016-10-18 17:38:58 --> Helper loaded: form_helper
INFO - 2016-10-18 17:38:58 --> Database Driver Class Initialized
INFO - 2016-10-18 17:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:38:58 --> Controller Class Initialized
INFO - 2016-10-18 17:38:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:38:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:38:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:38:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:38:58 --> Final output sent to browser
DEBUG - 2016-10-18 17:38:58 --> Total execution time: 0.0105
INFO - 2016-10-18 17:39:54 --> Config Class Initialized
INFO - 2016-10-18 17:39:54 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:39:54 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:39:54 --> Utf8 Class Initialized
INFO - 2016-10-18 17:39:54 --> URI Class Initialized
DEBUG - 2016-10-18 17:39:54 --> No URI present. Default controller set.
INFO - 2016-10-18 17:39:54 --> Router Class Initialized
INFO - 2016-10-18 17:39:54 --> Output Class Initialized
INFO - 2016-10-18 17:39:54 --> Security Class Initialized
DEBUG - 2016-10-18 17:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:39:54 --> Input Class Initialized
INFO - 2016-10-18 17:39:54 --> Language Class Initialized
INFO - 2016-10-18 17:39:54 --> Loader Class Initialized
INFO - 2016-10-18 17:39:54 --> Helper loaded: url_helper
INFO - 2016-10-18 17:39:54 --> Helper loaded: form_helper
INFO - 2016-10-18 17:39:54 --> Database Driver Class Initialized
INFO - 2016-10-18 17:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:39:54 --> Controller Class Initialized
INFO - 2016-10-18 17:39:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:39:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:39:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:39:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:39:54 --> Final output sent to browser
DEBUG - 2016-10-18 17:39:54 --> Total execution time: 0.0049
INFO - 2016-10-18 17:40:26 --> Config Class Initialized
INFO - 2016-10-18 17:40:26 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:40:26 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:40:26 --> Utf8 Class Initialized
INFO - 2016-10-18 17:40:26 --> URI Class Initialized
DEBUG - 2016-10-18 17:40:26 --> No URI present. Default controller set.
INFO - 2016-10-18 17:40:26 --> Router Class Initialized
INFO - 2016-10-18 17:40:26 --> Output Class Initialized
INFO - 2016-10-18 17:40:26 --> Security Class Initialized
DEBUG - 2016-10-18 17:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:40:26 --> Input Class Initialized
INFO - 2016-10-18 17:40:26 --> Language Class Initialized
INFO - 2016-10-18 17:40:26 --> Loader Class Initialized
INFO - 2016-10-18 17:40:26 --> Helper loaded: url_helper
INFO - 2016-10-18 17:40:26 --> Helper loaded: form_helper
INFO - 2016-10-18 17:40:26 --> Database Driver Class Initialized
INFO - 2016-10-18 17:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:40:26 --> Controller Class Initialized
INFO - 2016-10-18 17:40:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:40:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:40:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:40:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:40:26 --> Final output sent to browser
DEBUG - 2016-10-18 17:40:26 --> Total execution time: 0.0097
INFO - 2016-10-18 17:40:38 --> Config Class Initialized
INFO - 2016-10-18 17:40:38 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:40:38 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:40:38 --> Utf8 Class Initialized
INFO - 2016-10-18 17:40:38 --> URI Class Initialized
DEBUG - 2016-10-18 17:40:38 --> No URI present. Default controller set.
INFO - 2016-10-18 17:40:38 --> Router Class Initialized
INFO - 2016-10-18 17:40:38 --> Output Class Initialized
INFO - 2016-10-18 17:40:38 --> Security Class Initialized
DEBUG - 2016-10-18 17:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:40:38 --> Input Class Initialized
INFO - 2016-10-18 17:40:38 --> Language Class Initialized
INFO - 2016-10-18 17:40:38 --> Loader Class Initialized
INFO - 2016-10-18 17:40:38 --> Helper loaded: url_helper
INFO - 2016-10-18 17:40:38 --> Helper loaded: form_helper
INFO - 2016-10-18 17:40:38 --> Database Driver Class Initialized
INFO - 2016-10-18 17:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:40:38 --> Controller Class Initialized
INFO - 2016-10-18 17:40:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:40:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:40:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:40:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:40:38 --> Final output sent to browser
DEBUG - 2016-10-18 17:40:38 --> Total execution time: 0.0058
INFO - 2016-10-18 17:40:56 --> Config Class Initialized
INFO - 2016-10-18 17:40:56 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:40:56 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:40:56 --> Utf8 Class Initialized
INFO - 2016-10-18 17:40:56 --> URI Class Initialized
INFO - 2016-10-18 17:40:56 --> Router Class Initialized
INFO - 2016-10-18 17:40:56 --> Output Class Initialized
INFO - 2016-10-18 17:40:56 --> Security Class Initialized
DEBUG - 2016-10-18 17:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:40:56 --> Input Class Initialized
INFO - 2016-10-18 17:40:56 --> Language Class Initialized
INFO - 2016-10-18 17:40:56 --> Loader Class Initialized
INFO - 2016-10-18 17:40:56 --> Helper loaded: url_helper
INFO - 2016-10-18 17:40:56 --> Helper loaded: form_helper
INFO - 2016-10-18 17:40:56 --> Database Driver Class Initialized
INFO - 2016-10-18 17:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:40:56 --> Controller Class Initialized
INFO - 2016-10-18 17:40:56 --> Form Validation Class Initialized
INFO - 2016-10-18 17:40:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 17:40:56 --> Final output sent to browser
DEBUG - 2016-10-18 17:40:56 --> Total execution time: 0.0061
INFO - 2016-10-18 17:40:58 --> Config Class Initialized
INFO - 2016-10-18 17:40:58 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:40:58 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:40:58 --> Utf8 Class Initialized
INFO - 2016-10-18 17:40:58 --> URI Class Initialized
DEBUG - 2016-10-18 17:40:58 --> No URI present. Default controller set.
INFO - 2016-10-18 17:40:58 --> Router Class Initialized
INFO - 2016-10-18 17:40:58 --> Output Class Initialized
INFO - 2016-10-18 17:40:58 --> Security Class Initialized
DEBUG - 2016-10-18 17:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:40:58 --> Input Class Initialized
INFO - 2016-10-18 17:40:58 --> Language Class Initialized
INFO - 2016-10-18 17:40:58 --> Loader Class Initialized
INFO - 2016-10-18 17:40:58 --> Helper loaded: url_helper
INFO - 2016-10-18 17:40:58 --> Helper loaded: form_helper
INFO - 2016-10-18 17:40:58 --> Database Driver Class Initialized
INFO - 2016-10-18 17:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:40:58 --> Controller Class Initialized
INFO - 2016-10-18 17:40:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:40:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:40:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:40:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:40:58 --> Final output sent to browser
DEBUG - 2016-10-18 17:40:58 --> Total execution time: 0.0049
INFO - 2016-10-18 17:42:08 --> Config Class Initialized
INFO - 2016-10-18 17:42:08 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:42:08 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:42:08 --> Utf8 Class Initialized
INFO - 2016-10-18 17:42:08 --> URI Class Initialized
INFO - 2016-10-18 17:42:08 --> Router Class Initialized
INFO - 2016-10-18 17:42:08 --> Output Class Initialized
INFO - 2016-10-18 17:42:08 --> Security Class Initialized
DEBUG - 2016-10-18 17:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:42:08 --> Input Class Initialized
INFO - 2016-10-18 17:42:08 --> Language Class Initialized
INFO - 2016-10-18 17:42:08 --> Loader Class Initialized
INFO - 2016-10-18 17:42:08 --> Helper loaded: url_helper
INFO - 2016-10-18 17:42:08 --> Helper loaded: form_helper
INFO - 2016-10-18 17:42:08 --> Database Driver Class Initialized
INFO - 2016-10-18 17:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:42:08 --> Controller Class Initialized
INFO - 2016-10-18 17:42:08 --> Form Validation Class Initialized
INFO - 2016-10-18 17:42:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 17:42:08 --> Final output sent to browser
DEBUG - 2016-10-18 17:42:08 --> Total execution time: 0.0092
INFO - 2016-10-18 17:42:25 --> Config Class Initialized
INFO - 2016-10-18 17:42:25 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:42:25 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:42:25 --> Utf8 Class Initialized
INFO - 2016-10-18 17:42:25 --> URI Class Initialized
INFO - 2016-10-18 17:42:25 --> Router Class Initialized
INFO - 2016-10-18 17:42:25 --> Output Class Initialized
INFO - 2016-10-18 17:42:25 --> Security Class Initialized
DEBUG - 2016-10-18 17:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:42:25 --> Input Class Initialized
INFO - 2016-10-18 17:42:25 --> Language Class Initialized
INFO - 2016-10-18 17:42:25 --> Loader Class Initialized
INFO - 2016-10-18 17:42:25 --> Helper loaded: url_helper
INFO - 2016-10-18 17:42:25 --> Helper loaded: form_helper
INFO - 2016-10-18 17:42:25 --> Database Driver Class Initialized
INFO - 2016-10-18 17:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:42:25 --> Controller Class Initialized
INFO - 2016-10-18 17:42:25 --> Form Validation Class Initialized
INFO - 2016-10-18 17:42:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 17:42:25 --> Final output sent to browser
DEBUG - 2016-10-18 17:42:25 --> Total execution time: 0.0100
INFO - 2016-10-18 17:50:10 --> Config Class Initialized
INFO - 2016-10-18 17:50:10 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:50:10 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:50:10 --> Utf8 Class Initialized
INFO - 2016-10-18 17:50:10 --> URI Class Initialized
INFO - 2016-10-18 17:50:10 --> Router Class Initialized
INFO - 2016-10-18 17:50:10 --> Output Class Initialized
INFO - 2016-10-18 17:50:10 --> Security Class Initialized
DEBUG - 2016-10-18 17:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:50:10 --> Input Class Initialized
INFO - 2016-10-18 17:50:10 --> Language Class Initialized
INFO - 2016-10-18 17:50:10 --> Loader Class Initialized
INFO - 2016-10-18 17:50:10 --> Helper loaded: url_helper
INFO - 2016-10-18 17:50:10 --> Helper loaded: form_helper
INFO - 2016-10-18 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-18 17:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:50:10 --> Controller Class Initialized
ERROR - 2016-10-18 17:50:10 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 121
ERROR - 2016-10-18 17:50:10 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 121
INFO - 2016-10-18 17:50:10 --> Config Class Initialized
INFO - 2016-10-18 17:50:10 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:50:10 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:50:10 --> Utf8 Class Initialized
INFO - 2016-10-18 17:50:10 --> URI Class Initialized
DEBUG - 2016-10-18 17:50:10 --> No URI present. Default controller set.
INFO - 2016-10-18 17:50:10 --> Router Class Initialized
INFO - 2016-10-18 17:50:10 --> Output Class Initialized
INFO - 2016-10-18 17:50:10 --> Security Class Initialized
DEBUG - 2016-10-18 17:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:50:10 --> Input Class Initialized
INFO - 2016-10-18 17:50:10 --> Language Class Initialized
INFO - 2016-10-18 17:50:10 --> Loader Class Initialized
INFO - 2016-10-18 17:50:10 --> Helper loaded: url_helper
INFO - 2016-10-18 17:50:10 --> Helper loaded: form_helper
INFO - 2016-10-18 17:50:10 --> Database Driver Class Initialized
INFO - 2016-10-18 17:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:50:10 --> Controller Class Initialized
INFO - 2016-10-18 17:50:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:50:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 17:50:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:50:10 --> Final output sent to browser
DEBUG - 2016-10-18 17:50:10 --> Total execution time: 0.0049
INFO - 2016-10-18 17:50:56 --> Config Class Initialized
INFO - 2016-10-18 17:50:56 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:50:56 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:50:56 --> Utf8 Class Initialized
INFO - 2016-10-18 17:50:56 --> URI Class Initialized
INFO - 2016-10-18 17:50:56 --> Router Class Initialized
INFO - 2016-10-18 17:50:56 --> Output Class Initialized
INFO - 2016-10-18 17:50:56 --> Security Class Initialized
DEBUG - 2016-10-18 17:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:50:56 --> Input Class Initialized
INFO - 2016-10-18 17:50:56 --> Language Class Initialized
INFO - 2016-10-18 17:50:56 --> Loader Class Initialized
INFO - 2016-10-18 17:50:56 --> Helper loaded: url_helper
INFO - 2016-10-18 17:50:56 --> Helper loaded: form_helper
INFO - 2016-10-18 17:50:56 --> Database Driver Class Initialized
INFO - 2016-10-18 17:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:50:56 --> Controller Class Initialized
INFO - 2016-10-18 17:50:56 --> Model Class Initialized
INFO - 2016-10-18 17:50:56 --> Final output sent to browser
DEBUG - 2016-10-18 17:50:56 --> Total execution time: 0.0101
INFO - 2016-10-18 17:50:56 --> Config Class Initialized
INFO - 2016-10-18 17:50:56 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:50:56 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:50:56 --> Utf8 Class Initialized
INFO - 2016-10-18 17:50:56 --> URI Class Initialized
DEBUG - 2016-10-18 17:50:56 --> No URI present. Default controller set.
INFO - 2016-10-18 17:50:56 --> Router Class Initialized
INFO - 2016-10-18 17:50:56 --> Output Class Initialized
INFO - 2016-10-18 17:50:56 --> Security Class Initialized
DEBUG - 2016-10-18 17:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:50:56 --> Input Class Initialized
INFO - 2016-10-18 17:50:56 --> Language Class Initialized
INFO - 2016-10-18 17:50:56 --> Loader Class Initialized
INFO - 2016-10-18 17:50:56 --> Helper loaded: url_helper
INFO - 2016-10-18 17:50:56 --> Helper loaded: form_helper
INFO - 2016-10-18 17:50:56 --> Database Driver Class Initialized
INFO - 2016-10-18 17:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:50:56 --> Controller Class Initialized
INFO - 2016-10-18 17:50:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:50:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:50:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:50:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:50:56 --> Final output sent to browser
DEBUG - 2016-10-18 17:50:56 --> Total execution time: 0.0049
INFO - 2016-10-18 17:51:11 --> Config Class Initialized
INFO - 2016-10-18 17:51:11 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:51:11 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:51:11 --> Utf8 Class Initialized
INFO - 2016-10-18 17:51:11 --> URI Class Initialized
INFO - 2016-10-18 17:51:11 --> Router Class Initialized
INFO - 2016-10-18 17:51:11 --> Output Class Initialized
INFO - 2016-10-18 17:51:11 --> Security Class Initialized
DEBUG - 2016-10-18 17:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:51:11 --> Input Class Initialized
INFO - 2016-10-18 17:51:11 --> Language Class Initialized
INFO - 2016-10-18 17:51:11 --> Loader Class Initialized
INFO - 2016-10-18 17:51:11 --> Helper loaded: url_helper
INFO - 2016-10-18 17:51:11 --> Helper loaded: form_helper
INFO - 2016-10-18 17:51:11 --> Database Driver Class Initialized
INFO - 2016-10-18 17:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:51:11 --> Controller Class Initialized
INFO - 2016-10-18 17:51:11 --> Form Validation Class Initialized
INFO - 2016-10-18 17:51:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 17:51:11 --> Final output sent to browser
DEBUG - 2016-10-18 17:51:11 --> Total execution time: 0.0086
INFO - 2016-10-18 17:51:14 --> Config Class Initialized
INFO - 2016-10-18 17:51:14 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:51:14 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:51:14 --> Utf8 Class Initialized
INFO - 2016-10-18 17:51:14 --> URI Class Initialized
DEBUG - 2016-10-18 17:51:14 --> No URI present. Default controller set.
INFO - 2016-10-18 17:51:14 --> Router Class Initialized
INFO - 2016-10-18 17:51:14 --> Output Class Initialized
INFO - 2016-10-18 17:51:14 --> Security Class Initialized
DEBUG - 2016-10-18 17:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:51:14 --> Input Class Initialized
INFO - 2016-10-18 17:51:14 --> Language Class Initialized
INFO - 2016-10-18 17:51:14 --> Loader Class Initialized
INFO - 2016-10-18 17:51:14 --> Helper loaded: url_helper
INFO - 2016-10-18 17:51:14 --> Helper loaded: form_helper
INFO - 2016-10-18 17:51:14 --> Database Driver Class Initialized
INFO - 2016-10-18 17:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:51:14 --> Controller Class Initialized
INFO - 2016-10-18 17:51:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:51:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:51:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:51:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:51:14 --> Final output sent to browser
DEBUG - 2016-10-18 17:51:14 --> Total execution time: 0.0053
INFO - 2016-10-18 17:52:04 --> Config Class Initialized
INFO - 2016-10-18 17:52:04 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:52:04 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:52:04 --> Utf8 Class Initialized
INFO - 2016-10-18 17:52:04 --> URI Class Initialized
INFO - 2016-10-18 17:52:04 --> Router Class Initialized
INFO - 2016-10-18 17:52:04 --> Output Class Initialized
INFO - 2016-10-18 17:52:04 --> Security Class Initialized
DEBUG - 2016-10-18 17:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:52:04 --> Input Class Initialized
INFO - 2016-10-18 17:52:04 --> Language Class Initialized
INFO - 2016-10-18 17:52:04 --> Loader Class Initialized
INFO - 2016-10-18 17:52:04 --> Helper loaded: url_helper
INFO - 2016-10-18 17:52:04 --> Helper loaded: form_helper
INFO - 2016-10-18 17:52:04 --> Database Driver Class Initialized
INFO - 2016-10-18 17:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:52:04 --> Controller Class Initialized
INFO - 2016-10-18 17:52:04 --> Form Validation Class Initialized
INFO - 2016-10-18 17:52:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 17:52:04 --> Final output sent to browser
DEBUG - 2016-10-18 17:52:04 --> Total execution time: 0.0062
INFO - 2016-10-18 17:52:07 --> Config Class Initialized
INFO - 2016-10-18 17:52:07 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:52:07 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:52:07 --> Utf8 Class Initialized
INFO - 2016-10-18 17:52:07 --> URI Class Initialized
DEBUG - 2016-10-18 17:52:07 --> No URI present. Default controller set.
INFO - 2016-10-18 17:52:07 --> Router Class Initialized
INFO - 2016-10-18 17:52:07 --> Output Class Initialized
INFO - 2016-10-18 17:52:07 --> Security Class Initialized
DEBUG - 2016-10-18 17:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:52:07 --> Input Class Initialized
INFO - 2016-10-18 17:52:07 --> Language Class Initialized
INFO - 2016-10-18 17:52:07 --> Loader Class Initialized
INFO - 2016-10-18 17:52:07 --> Helper loaded: url_helper
INFO - 2016-10-18 17:52:07 --> Helper loaded: form_helper
INFO - 2016-10-18 17:52:07 --> Database Driver Class Initialized
INFO - 2016-10-18 17:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:52:07 --> Controller Class Initialized
INFO - 2016-10-18 17:52:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:52:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:52:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:52:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:52:07 --> Final output sent to browser
DEBUG - 2016-10-18 17:52:07 --> Total execution time: 0.0048
INFO - 2016-10-18 17:53:37 --> Config Class Initialized
INFO - 2016-10-18 17:53:37 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:53:37 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:53:37 --> Utf8 Class Initialized
INFO - 2016-10-18 17:53:37 --> URI Class Initialized
DEBUG - 2016-10-18 17:53:37 --> No URI present. Default controller set.
INFO - 2016-10-18 17:53:37 --> Router Class Initialized
INFO - 2016-10-18 17:53:37 --> Output Class Initialized
INFO - 2016-10-18 17:53:37 --> Security Class Initialized
DEBUG - 2016-10-18 17:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:53:37 --> Input Class Initialized
INFO - 2016-10-18 17:53:37 --> Language Class Initialized
INFO - 2016-10-18 17:53:37 --> Loader Class Initialized
INFO - 2016-10-18 17:53:37 --> Helper loaded: url_helper
INFO - 2016-10-18 17:53:37 --> Helper loaded: form_helper
INFO - 2016-10-18 17:53:37 --> Database Driver Class Initialized
INFO - 2016-10-18 17:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:53:37 --> Controller Class Initialized
INFO - 2016-10-18 17:53:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:53:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:53:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:53:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:53:37 --> Final output sent to browser
DEBUG - 2016-10-18 17:53:37 --> Total execution time: 0.0054
INFO - 2016-10-18 17:53:58 --> Config Class Initialized
INFO - 2016-10-18 17:53:58 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:53:58 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:53:58 --> Utf8 Class Initialized
INFO - 2016-10-18 17:53:58 --> URI Class Initialized
DEBUG - 2016-10-18 17:53:58 --> No URI present. Default controller set.
INFO - 2016-10-18 17:53:58 --> Router Class Initialized
INFO - 2016-10-18 17:53:58 --> Output Class Initialized
INFO - 2016-10-18 17:53:58 --> Security Class Initialized
DEBUG - 2016-10-18 17:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:53:58 --> Input Class Initialized
INFO - 2016-10-18 17:53:58 --> Language Class Initialized
INFO - 2016-10-18 17:53:58 --> Loader Class Initialized
INFO - 2016-10-18 17:53:58 --> Helper loaded: url_helper
INFO - 2016-10-18 17:53:58 --> Helper loaded: form_helper
INFO - 2016-10-18 17:53:58 --> Database Driver Class Initialized
INFO - 2016-10-18 17:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:53:58 --> Controller Class Initialized
INFO - 2016-10-18 17:53:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:53:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:53:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:53:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:53:58 --> Final output sent to browser
DEBUG - 2016-10-18 17:53:58 --> Total execution time: 0.0055
INFO - 2016-10-18 17:54:14 --> Config Class Initialized
INFO - 2016-10-18 17:54:14 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:54:14 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:54:14 --> Utf8 Class Initialized
INFO - 2016-10-18 17:54:14 --> URI Class Initialized
DEBUG - 2016-10-18 17:54:14 --> No URI present. Default controller set.
INFO - 2016-10-18 17:54:14 --> Router Class Initialized
INFO - 2016-10-18 17:54:14 --> Output Class Initialized
INFO - 2016-10-18 17:54:14 --> Security Class Initialized
DEBUG - 2016-10-18 17:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:54:14 --> Input Class Initialized
INFO - 2016-10-18 17:54:14 --> Language Class Initialized
INFO - 2016-10-18 17:54:14 --> Loader Class Initialized
INFO - 2016-10-18 17:54:14 --> Helper loaded: url_helper
INFO - 2016-10-18 17:54:14 --> Helper loaded: form_helper
INFO - 2016-10-18 17:54:14 --> Database Driver Class Initialized
INFO - 2016-10-18 17:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:54:14 --> Controller Class Initialized
INFO - 2016-10-18 17:54:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:54:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:54:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:54:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:54:14 --> Final output sent to browser
DEBUG - 2016-10-18 17:54:14 --> Total execution time: 0.0049
INFO - 2016-10-18 17:54:40 --> Config Class Initialized
INFO - 2016-10-18 17:54:40 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:54:40 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:54:40 --> Utf8 Class Initialized
INFO - 2016-10-18 17:54:40 --> URI Class Initialized
INFO - 2016-10-18 17:54:40 --> Router Class Initialized
INFO - 2016-10-18 17:54:40 --> Output Class Initialized
INFO - 2016-10-18 17:54:40 --> Security Class Initialized
DEBUG - 2016-10-18 17:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:54:40 --> Input Class Initialized
INFO - 2016-10-18 17:54:40 --> Language Class Initialized
INFO - 2016-10-18 17:54:40 --> Loader Class Initialized
INFO - 2016-10-18 17:54:40 --> Helper loaded: url_helper
INFO - 2016-10-18 17:54:40 --> Helper loaded: form_helper
INFO - 2016-10-18 17:54:40 --> Database Driver Class Initialized
INFO - 2016-10-18 17:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:54:40 --> Controller Class Initialized
INFO - 2016-10-18 17:54:40 --> Form Validation Class Initialized
INFO - 2016-10-18 17:54:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 17:54:40 --> Final output sent to browser
DEBUG - 2016-10-18 17:54:40 --> Total execution time: 0.0076
INFO - 2016-10-18 17:54:42 --> Config Class Initialized
INFO - 2016-10-18 17:54:42 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:54:42 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:54:42 --> Utf8 Class Initialized
INFO - 2016-10-18 17:54:42 --> URI Class Initialized
DEBUG - 2016-10-18 17:54:42 --> No URI present. Default controller set.
INFO - 2016-10-18 17:54:42 --> Router Class Initialized
INFO - 2016-10-18 17:54:42 --> Output Class Initialized
INFO - 2016-10-18 17:54:42 --> Security Class Initialized
DEBUG - 2016-10-18 17:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:54:42 --> Input Class Initialized
INFO - 2016-10-18 17:54:42 --> Language Class Initialized
INFO - 2016-10-18 17:54:42 --> Loader Class Initialized
INFO - 2016-10-18 17:54:42 --> Helper loaded: url_helper
INFO - 2016-10-18 17:54:42 --> Helper loaded: form_helper
INFO - 2016-10-18 17:54:42 --> Database Driver Class Initialized
INFO - 2016-10-18 17:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:54:42 --> Controller Class Initialized
INFO - 2016-10-18 17:54:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:54:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:54:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:54:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:54:42 --> Final output sent to browser
DEBUG - 2016-10-18 17:54:42 --> Total execution time: 0.0049
INFO - 2016-10-18 17:55:56 --> Config Class Initialized
INFO - 2016-10-18 17:55:56 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:55:56 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:55:56 --> Utf8 Class Initialized
INFO - 2016-10-18 17:55:56 --> URI Class Initialized
DEBUG - 2016-10-18 17:55:56 --> No URI present. Default controller set.
INFO - 2016-10-18 17:55:56 --> Router Class Initialized
INFO - 2016-10-18 17:55:56 --> Output Class Initialized
INFO - 2016-10-18 17:55:56 --> Security Class Initialized
DEBUG - 2016-10-18 17:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:55:56 --> Input Class Initialized
INFO - 2016-10-18 17:55:56 --> Language Class Initialized
INFO - 2016-10-18 17:55:56 --> Loader Class Initialized
INFO - 2016-10-18 17:55:56 --> Helper loaded: url_helper
INFO - 2016-10-18 17:55:56 --> Helper loaded: form_helper
INFO - 2016-10-18 17:55:56 --> Database Driver Class Initialized
INFO - 2016-10-18 17:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:55:56 --> Controller Class Initialized
INFO - 2016-10-18 17:55:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:55:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:55:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:55:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:55:56 --> Final output sent to browser
DEBUG - 2016-10-18 17:55:56 --> Total execution time: 0.0052
INFO - 2016-10-18 17:56:45 --> Config Class Initialized
INFO - 2016-10-18 17:56:45 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:56:45 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:56:45 --> Utf8 Class Initialized
INFO - 2016-10-18 17:56:45 --> URI Class Initialized
DEBUG - 2016-10-18 17:56:45 --> No URI present. Default controller set.
INFO - 2016-10-18 17:56:45 --> Router Class Initialized
INFO - 2016-10-18 17:56:45 --> Output Class Initialized
INFO - 2016-10-18 17:56:45 --> Security Class Initialized
DEBUG - 2016-10-18 17:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:56:45 --> Input Class Initialized
INFO - 2016-10-18 17:56:45 --> Language Class Initialized
INFO - 2016-10-18 17:56:45 --> Loader Class Initialized
INFO - 2016-10-18 17:56:45 --> Helper loaded: url_helper
INFO - 2016-10-18 17:56:45 --> Helper loaded: form_helper
INFO - 2016-10-18 17:56:45 --> Database Driver Class Initialized
INFO - 2016-10-18 17:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:56:45 --> Controller Class Initialized
INFO - 2016-10-18 17:56:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:56:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:56:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:56:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:56:45 --> Final output sent to browser
DEBUG - 2016-10-18 17:56:45 --> Total execution time: 0.0053
INFO - 2016-10-18 17:58:06 --> Config Class Initialized
INFO - 2016-10-18 17:58:06 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:58:06 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:58:06 --> Utf8 Class Initialized
INFO - 2016-10-18 17:58:06 --> URI Class Initialized
DEBUG - 2016-10-18 17:58:06 --> No URI present. Default controller set.
INFO - 2016-10-18 17:58:06 --> Router Class Initialized
INFO - 2016-10-18 17:58:06 --> Output Class Initialized
INFO - 2016-10-18 17:58:06 --> Security Class Initialized
DEBUG - 2016-10-18 17:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:58:06 --> Input Class Initialized
INFO - 2016-10-18 17:58:06 --> Language Class Initialized
INFO - 2016-10-18 17:58:06 --> Loader Class Initialized
INFO - 2016-10-18 17:58:06 --> Helper loaded: url_helper
INFO - 2016-10-18 17:58:06 --> Helper loaded: form_helper
INFO - 2016-10-18 17:58:06 --> Database Driver Class Initialized
INFO - 2016-10-18 17:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 17:58:06 --> Controller Class Initialized
INFO - 2016-10-18 17:58:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 17:58:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 17:58:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 17:58:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 17:58:06 --> Final output sent to browser
DEBUG - 2016-10-18 17:58:06 --> Total execution time: 0.0078
INFO - 2016-10-18 18:00:52 --> Config Class Initialized
INFO - 2016-10-18 18:00:52 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:00:52 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:00:52 --> Utf8 Class Initialized
INFO - 2016-10-18 18:00:52 --> URI Class Initialized
DEBUG - 2016-10-18 18:00:52 --> No URI present. Default controller set.
INFO - 2016-10-18 18:00:52 --> Router Class Initialized
INFO - 2016-10-18 18:00:52 --> Output Class Initialized
INFO - 2016-10-18 18:00:52 --> Security Class Initialized
DEBUG - 2016-10-18 18:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:00:52 --> Input Class Initialized
INFO - 2016-10-18 18:00:52 --> Language Class Initialized
INFO - 2016-10-18 18:00:52 --> Loader Class Initialized
INFO - 2016-10-18 18:00:52 --> Helper loaded: url_helper
INFO - 2016-10-18 18:00:52 --> Helper loaded: form_helper
INFO - 2016-10-18 18:00:52 --> Database Driver Class Initialized
INFO - 2016-10-18 18:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:00:52 --> Controller Class Initialized
INFO - 2016-10-18 18:00:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:00:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:00:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:00:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:00:52 --> Final output sent to browser
DEBUG - 2016-10-18 18:00:52 --> Total execution time: 0.0059
INFO - 2016-10-18 18:01:20 --> Config Class Initialized
INFO - 2016-10-18 18:01:20 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:01:20 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:01:20 --> Utf8 Class Initialized
INFO - 2016-10-18 18:01:20 --> URI Class Initialized
DEBUG - 2016-10-18 18:01:20 --> No URI present. Default controller set.
INFO - 2016-10-18 18:01:20 --> Router Class Initialized
INFO - 2016-10-18 18:01:20 --> Output Class Initialized
INFO - 2016-10-18 18:01:20 --> Security Class Initialized
DEBUG - 2016-10-18 18:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:01:20 --> Input Class Initialized
INFO - 2016-10-18 18:01:20 --> Language Class Initialized
INFO - 2016-10-18 18:01:20 --> Loader Class Initialized
INFO - 2016-10-18 18:01:20 --> Helper loaded: url_helper
INFO - 2016-10-18 18:01:20 --> Helper loaded: form_helper
INFO - 2016-10-18 18:01:20 --> Database Driver Class Initialized
INFO - 2016-10-18 18:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:01:20 --> Controller Class Initialized
INFO - 2016-10-18 18:01:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:01:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:01:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:01:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:01:20 --> Final output sent to browser
DEBUG - 2016-10-18 18:01:20 --> Total execution time: 0.0056
INFO - 2016-10-18 18:01:52 --> Config Class Initialized
INFO - 2016-10-18 18:01:52 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:01:52 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:01:52 --> Utf8 Class Initialized
INFO - 2016-10-18 18:01:52 --> URI Class Initialized
DEBUG - 2016-10-18 18:01:52 --> No URI present. Default controller set.
INFO - 2016-10-18 18:01:52 --> Router Class Initialized
INFO - 2016-10-18 18:01:52 --> Output Class Initialized
INFO - 2016-10-18 18:01:52 --> Security Class Initialized
DEBUG - 2016-10-18 18:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:01:52 --> Input Class Initialized
INFO - 2016-10-18 18:01:52 --> Language Class Initialized
INFO - 2016-10-18 18:01:52 --> Loader Class Initialized
INFO - 2016-10-18 18:01:52 --> Helper loaded: url_helper
INFO - 2016-10-18 18:01:52 --> Helper loaded: form_helper
INFO - 2016-10-18 18:01:52 --> Database Driver Class Initialized
INFO - 2016-10-18 18:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:01:52 --> Controller Class Initialized
INFO - 2016-10-18 18:01:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:01:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:01:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:01:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:01:52 --> Final output sent to browser
DEBUG - 2016-10-18 18:01:52 --> Total execution time: 0.0051
INFO - 2016-10-18 18:02:24 --> Config Class Initialized
INFO - 2016-10-18 18:02:24 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:02:24 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:02:24 --> Utf8 Class Initialized
INFO - 2016-10-18 18:02:24 --> URI Class Initialized
DEBUG - 2016-10-18 18:02:24 --> No URI present. Default controller set.
INFO - 2016-10-18 18:02:24 --> Router Class Initialized
INFO - 2016-10-18 18:02:24 --> Output Class Initialized
INFO - 2016-10-18 18:02:24 --> Security Class Initialized
DEBUG - 2016-10-18 18:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:02:24 --> Input Class Initialized
INFO - 2016-10-18 18:02:24 --> Language Class Initialized
INFO - 2016-10-18 18:02:24 --> Loader Class Initialized
INFO - 2016-10-18 18:02:24 --> Helper loaded: url_helper
INFO - 2016-10-18 18:02:24 --> Helper loaded: form_helper
INFO - 2016-10-18 18:02:24 --> Database Driver Class Initialized
INFO - 2016-10-18 18:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:02:24 --> Controller Class Initialized
INFO - 2016-10-18 18:02:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:02:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:02:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:02:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:02:24 --> Final output sent to browser
DEBUG - 2016-10-18 18:02:24 --> Total execution time: 0.0051
INFO - 2016-10-18 18:02:56 --> Config Class Initialized
INFO - 2016-10-18 18:02:56 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:02:56 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:02:56 --> Utf8 Class Initialized
INFO - 2016-10-18 18:02:56 --> URI Class Initialized
DEBUG - 2016-10-18 18:02:56 --> No URI present. Default controller set.
INFO - 2016-10-18 18:02:56 --> Router Class Initialized
INFO - 2016-10-18 18:02:56 --> Output Class Initialized
INFO - 2016-10-18 18:02:56 --> Security Class Initialized
DEBUG - 2016-10-18 18:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:02:56 --> Input Class Initialized
INFO - 2016-10-18 18:02:56 --> Language Class Initialized
INFO - 2016-10-18 18:02:56 --> Loader Class Initialized
INFO - 2016-10-18 18:02:56 --> Helper loaded: url_helper
INFO - 2016-10-18 18:02:56 --> Helper loaded: form_helper
INFO - 2016-10-18 18:02:56 --> Database Driver Class Initialized
INFO - 2016-10-18 18:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:02:56 --> Controller Class Initialized
INFO - 2016-10-18 18:02:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:02:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:02:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:02:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:02:56 --> Final output sent to browser
DEBUG - 2016-10-18 18:02:56 --> Total execution time: 0.0056
INFO - 2016-10-18 18:03:55 --> Config Class Initialized
INFO - 2016-10-18 18:03:55 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:03:55 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:03:55 --> Utf8 Class Initialized
INFO - 2016-10-18 18:03:55 --> URI Class Initialized
DEBUG - 2016-10-18 18:03:55 --> No URI present. Default controller set.
INFO - 2016-10-18 18:03:55 --> Router Class Initialized
INFO - 2016-10-18 18:03:55 --> Output Class Initialized
INFO - 2016-10-18 18:03:55 --> Security Class Initialized
DEBUG - 2016-10-18 18:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:03:55 --> Input Class Initialized
INFO - 2016-10-18 18:03:55 --> Language Class Initialized
INFO - 2016-10-18 18:03:55 --> Loader Class Initialized
INFO - 2016-10-18 18:03:55 --> Helper loaded: url_helper
INFO - 2016-10-18 18:03:55 --> Helper loaded: form_helper
INFO - 2016-10-18 18:03:55 --> Database Driver Class Initialized
INFO - 2016-10-18 18:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:03:55 --> Controller Class Initialized
INFO - 2016-10-18 18:03:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:03:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:03:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:03:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:03:55 --> Final output sent to browser
DEBUG - 2016-10-18 18:03:55 --> Total execution time: 0.0087
INFO - 2016-10-18 18:04:29 --> Config Class Initialized
INFO - 2016-10-18 18:04:29 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:04:29 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:04:29 --> Utf8 Class Initialized
INFO - 2016-10-18 18:04:29 --> URI Class Initialized
DEBUG - 2016-10-18 18:04:29 --> No URI present. Default controller set.
INFO - 2016-10-18 18:04:29 --> Router Class Initialized
INFO - 2016-10-18 18:04:29 --> Output Class Initialized
INFO - 2016-10-18 18:04:29 --> Security Class Initialized
DEBUG - 2016-10-18 18:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:04:29 --> Input Class Initialized
INFO - 2016-10-18 18:04:29 --> Language Class Initialized
INFO - 2016-10-18 18:04:29 --> Loader Class Initialized
INFO - 2016-10-18 18:04:29 --> Helper loaded: url_helper
INFO - 2016-10-18 18:04:29 --> Helper loaded: form_helper
INFO - 2016-10-18 18:04:29 --> Database Driver Class Initialized
INFO - 2016-10-18 18:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:04:29 --> Controller Class Initialized
INFO - 2016-10-18 18:04:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:04:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:04:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:04:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:04:29 --> Final output sent to browser
DEBUG - 2016-10-18 18:04:29 --> Total execution time: 0.0085
INFO - 2016-10-18 18:04:44 --> Config Class Initialized
INFO - 2016-10-18 18:04:44 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:04:44 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:04:44 --> Utf8 Class Initialized
INFO - 2016-10-18 18:04:44 --> URI Class Initialized
DEBUG - 2016-10-18 18:04:44 --> No URI present. Default controller set.
INFO - 2016-10-18 18:04:44 --> Router Class Initialized
INFO - 2016-10-18 18:04:44 --> Output Class Initialized
INFO - 2016-10-18 18:04:44 --> Security Class Initialized
DEBUG - 2016-10-18 18:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:04:44 --> Input Class Initialized
INFO - 2016-10-18 18:04:44 --> Language Class Initialized
INFO - 2016-10-18 18:04:44 --> Loader Class Initialized
INFO - 2016-10-18 18:04:44 --> Helper loaded: url_helper
INFO - 2016-10-18 18:04:44 --> Helper loaded: form_helper
INFO - 2016-10-18 18:04:44 --> Database Driver Class Initialized
INFO - 2016-10-18 18:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:04:44 --> Controller Class Initialized
INFO - 2016-10-18 18:04:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:04:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:04:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:04:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:04:44 --> Final output sent to browser
DEBUG - 2016-10-18 18:04:44 --> Total execution time: 0.0056
INFO - 2016-10-18 18:05:00 --> Config Class Initialized
INFO - 2016-10-18 18:05:00 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:05:00 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:05:00 --> Utf8 Class Initialized
INFO - 2016-10-18 18:05:00 --> URI Class Initialized
DEBUG - 2016-10-18 18:05:00 --> No URI present. Default controller set.
INFO - 2016-10-18 18:05:00 --> Router Class Initialized
INFO - 2016-10-18 18:05:00 --> Output Class Initialized
INFO - 2016-10-18 18:05:00 --> Security Class Initialized
DEBUG - 2016-10-18 18:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:05:00 --> Input Class Initialized
INFO - 2016-10-18 18:05:00 --> Language Class Initialized
INFO - 2016-10-18 18:05:00 --> Loader Class Initialized
INFO - 2016-10-18 18:05:00 --> Helper loaded: url_helper
INFO - 2016-10-18 18:05:00 --> Helper loaded: form_helper
INFO - 2016-10-18 18:05:00 --> Database Driver Class Initialized
INFO - 2016-10-18 18:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:05:00 --> Controller Class Initialized
INFO - 2016-10-18 18:05:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:05:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:05:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:05:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:05:00 --> Final output sent to browser
DEBUG - 2016-10-18 18:05:00 --> Total execution time: 0.0052
INFO - 2016-10-18 18:05:29 --> Config Class Initialized
INFO - 2016-10-18 18:05:29 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:05:29 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:05:29 --> Utf8 Class Initialized
INFO - 2016-10-18 18:05:29 --> URI Class Initialized
DEBUG - 2016-10-18 18:05:29 --> No URI present. Default controller set.
INFO - 2016-10-18 18:05:29 --> Router Class Initialized
INFO - 2016-10-18 18:05:29 --> Output Class Initialized
INFO - 2016-10-18 18:05:29 --> Security Class Initialized
DEBUG - 2016-10-18 18:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:05:29 --> Input Class Initialized
INFO - 2016-10-18 18:05:29 --> Language Class Initialized
INFO - 2016-10-18 18:05:29 --> Loader Class Initialized
INFO - 2016-10-18 18:05:29 --> Helper loaded: url_helper
INFO - 2016-10-18 18:05:29 --> Helper loaded: form_helper
INFO - 2016-10-18 18:05:29 --> Database Driver Class Initialized
INFO - 2016-10-18 18:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:05:29 --> Controller Class Initialized
INFO - 2016-10-18 18:05:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:05:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:05:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:05:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:05:29 --> Final output sent to browser
DEBUG - 2016-10-18 18:05:29 --> Total execution time: 0.0060
INFO - 2016-10-18 18:05:40 --> Config Class Initialized
INFO - 2016-10-18 18:05:40 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:05:40 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:05:41 --> Utf8 Class Initialized
INFO - 2016-10-18 18:05:41 --> URI Class Initialized
DEBUG - 2016-10-18 18:05:41 --> No URI present. Default controller set.
INFO - 2016-10-18 18:05:41 --> Router Class Initialized
INFO - 2016-10-18 18:05:41 --> Output Class Initialized
INFO - 2016-10-18 18:05:41 --> Security Class Initialized
DEBUG - 2016-10-18 18:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:05:41 --> Input Class Initialized
INFO - 2016-10-18 18:05:41 --> Language Class Initialized
INFO - 2016-10-18 18:05:41 --> Loader Class Initialized
INFO - 2016-10-18 18:05:41 --> Helper loaded: url_helper
INFO - 2016-10-18 18:05:41 --> Helper loaded: form_helper
INFO - 2016-10-18 18:05:41 --> Database Driver Class Initialized
INFO - 2016-10-18 18:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:05:41 --> Controller Class Initialized
INFO - 2016-10-18 18:05:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:05:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:05:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:05:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:05:41 --> Final output sent to browser
DEBUG - 2016-10-18 18:05:41 --> Total execution time: 0.0095
INFO - 2016-10-18 18:06:43 --> Config Class Initialized
INFO - 2016-10-18 18:06:43 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:06:43 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:06:43 --> Utf8 Class Initialized
INFO - 2016-10-18 18:06:43 --> URI Class Initialized
DEBUG - 2016-10-18 18:06:43 --> No URI present. Default controller set.
INFO - 2016-10-18 18:06:43 --> Router Class Initialized
INFO - 2016-10-18 18:06:43 --> Output Class Initialized
INFO - 2016-10-18 18:06:43 --> Security Class Initialized
DEBUG - 2016-10-18 18:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:06:43 --> Input Class Initialized
INFO - 2016-10-18 18:06:43 --> Language Class Initialized
INFO - 2016-10-18 18:06:43 --> Loader Class Initialized
INFO - 2016-10-18 18:06:43 --> Helper loaded: url_helper
INFO - 2016-10-18 18:06:43 --> Helper loaded: form_helper
INFO - 2016-10-18 18:06:43 --> Database Driver Class Initialized
INFO - 2016-10-18 18:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:06:43 --> Controller Class Initialized
INFO - 2016-10-18 18:06:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:06:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:06:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:06:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:06:43 --> Final output sent to browser
DEBUG - 2016-10-18 18:06:43 --> Total execution time: 0.0057
INFO - 2016-10-18 18:07:51 --> Config Class Initialized
INFO - 2016-10-18 18:07:51 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:07:51 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:07:51 --> Utf8 Class Initialized
INFO - 2016-10-18 18:07:51 --> URI Class Initialized
DEBUG - 2016-10-18 18:07:51 --> No URI present. Default controller set.
INFO - 2016-10-18 18:07:51 --> Router Class Initialized
INFO - 2016-10-18 18:07:51 --> Output Class Initialized
INFO - 2016-10-18 18:07:51 --> Security Class Initialized
DEBUG - 2016-10-18 18:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:07:51 --> Input Class Initialized
INFO - 2016-10-18 18:07:51 --> Language Class Initialized
INFO - 2016-10-18 18:07:51 --> Loader Class Initialized
INFO - 2016-10-18 18:07:51 --> Helper loaded: url_helper
INFO - 2016-10-18 18:07:51 --> Helper loaded: form_helper
INFO - 2016-10-18 18:07:51 --> Database Driver Class Initialized
INFO - 2016-10-18 18:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:07:51 --> Controller Class Initialized
INFO - 2016-10-18 18:07:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:07:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:07:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:07:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:07:51 --> Final output sent to browser
DEBUG - 2016-10-18 18:07:51 --> Total execution time: 0.0063
INFO - 2016-10-18 18:08:08 --> Config Class Initialized
INFO - 2016-10-18 18:08:08 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:08:08 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:08:08 --> Utf8 Class Initialized
INFO - 2016-10-18 18:08:08 --> URI Class Initialized
DEBUG - 2016-10-18 18:08:08 --> No URI present. Default controller set.
INFO - 2016-10-18 18:08:08 --> Router Class Initialized
INFO - 2016-10-18 18:08:08 --> Output Class Initialized
INFO - 2016-10-18 18:08:08 --> Security Class Initialized
DEBUG - 2016-10-18 18:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:08:08 --> Input Class Initialized
INFO - 2016-10-18 18:08:08 --> Language Class Initialized
INFO - 2016-10-18 18:08:08 --> Loader Class Initialized
INFO - 2016-10-18 18:08:08 --> Helper loaded: url_helper
INFO - 2016-10-18 18:08:08 --> Helper loaded: form_helper
INFO - 2016-10-18 18:08:08 --> Database Driver Class Initialized
INFO - 2016-10-18 18:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:08:08 --> Controller Class Initialized
INFO - 2016-10-18 18:08:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:08:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:08:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:08:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:08:08 --> Final output sent to browser
DEBUG - 2016-10-18 18:08:08 --> Total execution time: 0.0049
INFO - 2016-10-18 18:08:54 --> Config Class Initialized
INFO - 2016-10-18 18:08:54 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:08:54 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:08:54 --> Utf8 Class Initialized
INFO - 2016-10-18 18:08:54 --> URI Class Initialized
DEBUG - 2016-10-18 18:08:54 --> No URI present. Default controller set.
INFO - 2016-10-18 18:08:54 --> Router Class Initialized
INFO - 2016-10-18 18:08:54 --> Output Class Initialized
INFO - 2016-10-18 18:08:54 --> Security Class Initialized
DEBUG - 2016-10-18 18:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:08:54 --> Input Class Initialized
INFO - 2016-10-18 18:08:54 --> Language Class Initialized
INFO - 2016-10-18 18:08:54 --> Loader Class Initialized
INFO - 2016-10-18 18:08:54 --> Helper loaded: url_helper
INFO - 2016-10-18 18:08:54 --> Helper loaded: form_helper
INFO - 2016-10-18 18:08:54 --> Database Driver Class Initialized
INFO - 2016-10-18 18:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:08:54 --> Controller Class Initialized
INFO - 2016-10-18 18:08:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:08:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:08:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:08:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:08:54 --> Final output sent to browser
DEBUG - 2016-10-18 18:08:54 --> Total execution time: 0.0050
INFO - 2016-10-18 18:09:19 --> Config Class Initialized
INFO - 2016-10-18 18:09:19 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:09:19 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:09:19 --> Utf8 Class Initialized
INFO - 2016-10-18 18:09:19 --> URI Class Initialized
DEBUG - 2016-10-18 18:09:19 --> No URI present. Default controller set.
INFO - 2016-10-18 18:09:19 --> Router Class Initialized
INFO - 2016-10-18 18:09:19 --> Output Class Initialized
INFO - 2016-10-18 18:09:19 --> Security Class Initialized
DEBUG - 2016-10-18 18:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:09:19 --> Input Class Initialized
INFO - 2016-10-18 18:09:19 --> Language Class Initialized
INFO - 2016-10-18 18:09:19 --> Loader Class Initialized
INFO - 2016-10-18 18:09:19 --> Helper loaded: url_helper
INFO - 2016-10-18 18:09:19 --> Helper loaded: form_helper
INFO - 2016-10-18 18:09:19 --> Database Driver Class Initialized
INFO - 2016-10-18 18:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:09:19 --> Controller Class Initialized
INFO - 2016-10-18 18:09:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:09:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:09:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:09:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:09:19 --> Final output sent to browser
DEBUG - 2016-10-18 18:09:19 --> Total execution time: 0.0049
INFO - 2016-10-18 18:12:38 --> Config Class Initialized
INFO - 2016-10-18 18:12:38 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:12:38 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:12:38 --> Utf8 Class Initialized
INFO - 2016-10-18 18:12:38 --> URI Class Initialized
DEBUG - 2016-10-18 18:12:38 --> No URI present. Default controller set.
INFO - 2016-10-18 18:12:38 --> Router Class Initialized
INFO - 2016-10-18 18:12:38 --> Output Class Initialized
INFO - 2016-10-18 18:12:38 --> Security Class Initialized
DEBUG - 2016-10-18 18:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:12:38 --> Input Class Initialized
INFO - 2016-10-18 18:12:38 --> Language Class Initialized
INFO - 2016-10-18 18:12:38 --> Loader Class Initialized
INFO - 2016-10-18 18:12:38 --> Helper loaded: url_helper
INFO - 2016-10-18 18:12:38 --> Helper loaded: form_helper
INFO - 2016-10-18 18:12:38 --> Database Driver Class Initialized
INFO - 2016-10-18 18:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:12:38 --> Controller Class Initialized
INFO - 2016-10-18 18:12:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:12:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:12:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:12:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:12:38 --> Final output sent to browser
DEBUG - 2016-10-18 18:12:38 --> Total execution time: 0.0060
INFO - 2016-10-18 18:15:45 --> Config Class Initialized
INFO - 2016-10-18 18:15:45 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:15:45 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:15:45 --> Utf8 Class Initialized
INFO - 2016-10-18 18:15:45 --> URI Class Initialized
DEBUG - 2016-10-18 18:15:45 --> No URI present. Default controller set.
INFO - 2016-10-18 18:15:45 --> Router Class Initialized
INFO - 2016-10-18 18:15:45 --> Output Class Initialized
INFO - 2016-10-18 18:15:45 --> Security Class Initialized
DEBUG - 2016-10-18 18:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:15:45 --> Input Class Initialized
INFO - 2016-10-18 18:15:45 --> Language Class Initialized
INFO - 2016-10-18 18:15:45 --> Loader Class Initialized
INFO - 2016-10-18 18:15:45 --> Helper loaded: url_helper
INFO - 2016-10-18 18:15:45 --> Helper loaded: form_helper
INFO - 2016-10-18 18:15:45 --> Database Driver Class Initialized
INFO - 2016-10-18 18:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:15:45 --> Controller Class Initialized
INFO - 2016-10-18 18:15:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:15:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:15:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:15:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:15:45 --> Final output sent to browser
DEBUG - 2016-10-18 18:15:45 --> Total execution time: 0.0059
INFO - 2016-10-18 18:17:20 --> Config Class Initialized
INFO - 2016-10-18 18:17:20 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:17:20 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:17:20 --> Utf8 Class Initialized
INFO - 2016-10-18 18:17:20 --> URI Class Initialized
DEBUG - 2016-10-18 18:17:20 --> No URI present. Default controller set.
INFO - 2016-10-18 18:17:20 --> Router Class Initialized
INFO - 2016-10-18 18:17:20 --> Output Class Initialized
INFO - 2016-10-18 18:17:20 --> Security Class Initialized
DEBUG - 2016-10-18 18:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:17:20 --> Input Class Initialized
INFO - 2016-10-18 18:17:20 --> Language Class Initialized
INFO - 2016-10-18 18:17:20 --> Loader Class Initialized
INFO - 2016-10-18 18:17:20 --> Helper loaded: url_helper
INFO - 2016-10-18 18:17:20 --> Helper loaded: form_helper
INFO - 2016-10-18 18:17:20 --> Database Driver Class Initialized
INFO - 2016-10-18 18:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:17:20 --> Controller Class Initialized
INFO - 2016-10-18 18:17:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:17:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:17:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:17:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:17:20 --> Final output sent to browser
DEBUG - 2016-10-18 18:17:20 --> Total execution time: 0.0054
INFO - 2016-10-18 18:17:40 --> Config Class Initialized
INFO - 2016-10-18 18:17:40 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:17:40 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:17:40 --> Utf8 Class Initialized
INFO - 2016-10-18 18:17:40 --> URI Class Initialized
DEBUG - 2016-10-18 18:17:40 --> No URI present. Default controller set.
INFO - 2016-10-18 18:17:40 --> Router Class Initialized
INFO - 2016-10-18 18:17:40 --> Output Class Initialized
INFO - 2016-10-18 18:17:40 --> Security Class Initialized
DEBUG - 2016-10-18 18:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:17:40 --> Input Class Initialized
INFO - 2016-10-18 18:17:40 --> Language Class Initialized
INFO - 2016-10-18 18:17:40 --> Loader Class Initialized
INFO - 2016-10-18 18:17:40 --> Helper loaded: url_helper
INFO - 2016-10-18 18:17:40 --> Helper loaded: form_helper
INFO - 2016-10-18 18:17:40 --> Database Driver Class Initialized
INFO - 2016-10-18 18:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:17:40 --> Controller Class Initialized
INFO - 2016-10-18 18:17:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:17:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:17:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:17:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:17:40 --> Final output sent to browser
DEBUG - 2016-10-18 18:17:40 --> Total execution time: 0.0056
INFO - 2016-10-18 18:18:00 --> Config Class Initialized
INFO - 2016-10-18 18:18:00 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:18:00 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:18:00 --> Utf8 Class Initialized
INFO - 2016-10-18 18:18:00 --> URI Class Initialized
DEBUG - 2016-10-18 18:18:00 --> No URI present. Default controller set.
INFO - 2016-10-18 18:18:00 --> Router Class Initialized
INFO - 2016-10-18 18:18:00 --> Output Class Initialized
INFO - 2016-10-18 18:18:00 --> Security Class Initialized
DEBUG - 2016-10-18 18:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:18:00 --> Input Class Initialized
INFO - 2016-10-18 18:18:00 --> Language Class Initialized
INFO - 2016-10-18 18:18:00 --> Loader Class Initialized
INFO - 2016-10-18 18:18:00 --> Helper loaded: url_helper
INFO - 2016-10-18 18:18:00 --> Helper loaded: form_helper
INFO - 2016-10-18 18:18:00 --> Database Driver Class Initialized
INFO - 2016-10-18 18:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:18:00 --> Controller Class Initialized
INFO - 2016-10-18 18:18:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:18:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:18:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:18:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:18:00 --> Final output sent to browser
DEBUG - 2016-10-18 18:18:00 --> Total execution time: 0.0059
INFO - 2016-10-18 18:18:16 --> Config Class Initialized
INFO - 2016-10-18 18:18:16 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:18:16 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:18:16 --> Utf8 Class Initialized
INFO - 2016-10-18 18:18:16 --> URI Class Initialized
DEBUG - 2016-10-18 18:18:16 --> No URI present. Default controller set.
INFO - 2016-10-18 18:18:16 --> Router Class Initialized
INFO - 2016-10-18 18:18:16 --> Output Class Initialized
INFO - 2016-10-18 18:18:16 --> Security Class Initialized
DEBUG - 2016-10-18 18:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:18:16 --> Input Class Initialized
INFO - 2016-10-18 18:18:16 --> Language Class Initialized
INFO - 2016-10-18 18:18:16 --> Loader Class Initialized
INFO - 2016-10-18 18:18:16 --> Helper loaded: url_helper
INFO - 2016-10-18 18:18:16 --> Helper loaded: form_helper
INFO - 2016-10-18 18:18:16 --> Database Driver Class Initialized
INFO - 2016-10-18 18:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:18:16 --> Controller Class Initialized
INFO - 2016-10-18 18:18:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:18:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:18:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:18:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:18:16 --> Final output sent to browser
DEBUG - 2016-10-18 18:18:16 --> Total execution time: 0.0050
INFO - 2016-10-18 18:18:50 --> Config Class Initialized
INFO - 2016-10-18 18:18:50 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:18:50 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:18:50 --> Utf8 Class Initialized
INFO - 2016-10-18 18:18:50 --> URI Class Initialized
DEBUG - 2016-10-18 18:18:50 --> No URI present. Default controller set.
INFO - 2016-10-18 18:18:50 --> Router Class Initialized
INFO - 2016-10-18 18:18:50 --> Output Class Initialized
INFO - 2016-10-18 18:18:50 --> Security Class Initialized
DEBUG - 2016-10-18 18:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:18:50 --> Input Class Initialized
INFO - 2016-10-18 18:18:50 --> Language Class Initialized
INFO - 2016-10-18 18:18:50 --> Loader Class Initialized
INFO - 2016-10-18 18:18:50 --> Helper loaded: url_helper
INFO - 2016-10-18 18:18:50 --> Helper loaded: form_helper
INFO - 2016-10-18 18:18:50 --> Database Driver Class Initialized
INFO - 2016-10-18 18:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:18:50 --> Controller Class Initialized
INFO - 2016-10-18 18:18:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:18:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:18:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:18:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:18:50 --> Final output sent to browser
DEBUG - 2016-10-18 18:18:50 --> Total execution time: 0.0060
INFO - 2016-10-18 18:19:00 --> Config Class Initialized
INFO - 2016-10-18 18:19:00 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:19:00 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:19:00 --> Utf8 Class Initialized
INFO - 2016-10-18 18:19:00 --> URI Class Initialized
DEBUG - 2016-10-18 18:19:00 --> No URI present. Default controller set.
INFO - 2016-10-18 18:19:00 --> Router Class Initialized
INFO - 2016-10-18 18:19:00 --> Output Class Initialized
INFO - 2016-10-18 18:19:00 --> Security Class Initialized
DEBUG - 2016-10-18 18:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:19:00 --> Input Class Initialized
INFO - 2016-10-18 18:19:00 --> Language Class Initialized
INFO - 2016-10-18 18:19:00 --> Loader Class Initialized
INFO - 2016-10-18 18:19:00 --> Helper loaded: url_helper
INFO - 2016-10-18 18:19:00 --> Helper loaded: form_helper
INFO - 2016-10-18 18:19:00 --> Database Driver Class Initialized
INFO - 2016-10-18 18:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:19:00 --> Controller Class Initialized
INFO - 2016-10-18 18:19:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:19:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:19:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:19:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:19:00 --> Final output sent to browser
DEBUG - 2016-10-18 18:19:00 --> Total execution time: 0.0055
INFO - 2016-10-18 18:20:16 --> Config Class Initialized
INFO - 2016-10-18 18:20:16 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:20:16 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:20:16 --> Utf8 Class Initialized
INFO - 2016-10-18 18:20:16 --> URI Class Initialized
DEBUG - 2016-10-18 18:20:16 --> No URI present. Default controller set.
INFO - 2016-10-18 18:20:16 --> Router Class Initialized
INFO - 2016-10-18 18:20:16 --> Output Class Initialized
INFO - 2016-10-18 18:20:16 --> Security Class Initialized
DEBUG - 2016-10-18 18:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:20:16 --> Input Class Initialized
INFO - 2016-10-18 18:20:16 --> Language Class Initialized
INFO - 2016-10-18 18:20:16 --> Loader Class Initialized
INFO - 2016-10-18 18:20:16 --> Helper loaded: url_helper
INFO - 2016-10-18 18:20:16 --> Helper loaded: form_helper
INFO - 2016-10-18 18:20:16 --> Database Driver Class Initialized
INFO - 2016-10-18 18:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:20:16 --> Controller Class Initialized
INFO - 2016-10-18 18:20:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:20:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:20:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:20:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:20:16 --> Final output sent to browser
DEBUG - 2016-10-18 18:20:16 --> Total execution time: 0.0081
INFO - 2016-10-18 18:21:04 --> Config Class Initialized
INFO - 2016-10-18 18:21:04 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:21:04 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:21:04 --> Utf8 Class Initialized
INFO - 2016-10-18 18:21:04 --> URI Class Initialized
DEBUG - 2016-10-18 18:21:04 --> No URI present. Default controller set.
INFO - 2016-10-18 18:21:04 --> Router Class Initialized
INFO - 2016-10-18 18:21:04 --> Output Class Initialized
INFO - 2016-10-18 18:21:04 --> Security Class Initialized
DEBUG - 2016-10-18 18:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:21:04 --> Input Class Initialized
INFO - 2016-10-18 18:21:04 --> Language Class Initialized
INFO - 2016-10-18 18:21:04 --> Loader Class Initialized
INFO - 2016-10-18 18:21:04 --> Helper loaded: url_helper
INFO - 2016-10-18 18:21:04 --> Helper loaded: form_helper
INFO - 2016-10-18 18:21:04 --> Database Driver Class Initialized
INFO - 2016-10-18 18:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:21:04 --> Controller Class Initialized
INFO - 2016-10-18 18:21:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:21:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:21:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:21:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:21:04 --> Final output sent to browser
DEBUG - 2016-10-18 18:21:04 --> Total execution time: 0.0084
INFO - 2016-10-18 18:22:28 --> Config Class Initialized
INFO - 2016-10-18 18:22:28 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:22:28 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:22:28 --> Utf8 Class Initialized
INFO - 2016-10-18 18:22:28 --> URI Class Initialized
DEBUG - 2016-10-18 18:22:28 --> No URI present. Default controller set.
INFO - 2016-10-18 18:22:28 --> Router Class Initialized
INFO - 2016-10-18 18:22:28 --> Output Class Initialized
INFO - 2016-10-18 18:22:28 --> Security Class Initialized
DEBUG - 2016-10-18 18:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:22:28 --> Input Class Initialized
INFO - 2016-10-18 18:22:28 --> Language Class Initialized
INFO - 2016-10-18 18:22:28 --> Loader Class Initialized
INFO - 2016-10-18 18:22:28 --> Helper loaded: url_helper
INFO - 2016-10-18 18:22:28 --> Helper loaded: form_helper
INFO - 2016-10-18 18:22:28 --> Database Driver Class Initialized
INFO - 2016-10-18 18:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:22:28 --> Controller Class Initialized
INFO - 2016-10-18 18:22:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:22:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:22:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:22:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:22:28 --> Final output sent to browser
DEBUG - 2016-10-18 18:22:28 --> Total execution time: 0.0058
INFO - 2016-10-18 18:22:33 --> Config Class Initialized
INFO - 2016-10-18 18:22:33 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:22:33 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:22:33 --> Utf8 Class Initialized
INFO - 2016-10-18 18:22:33 --> URI Class Initialized
INFO - 2016-10-18 18:22:33 --> Router Class Initialized
INFO - 2016-10-18 18:22:33 --> Output Class Initialized
INFO - 2016-10-18 18:22:33 --> Security Class Initialized
DEBUG - 2016-10-18 18:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:22:33 --> Input Class Initialized
INFO - 2016-10-18 18:22:33 --> Language Class Initialized
INFO - 2016-10-18 18:22:33 --> Loader Class Initialized
INFO - 2016-10-18 18:22:33 --> Helper loaded: url_helper
INFO - 2016-10-18 18:22:33 --> Helper loaded: form_helper
INFO - 2016-10-18 18:22:33 --> Database Driver Class Initialized
INFO - 2016-10-18 18:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:22:33 --> Controller Class Initialized
INFO - 2016-10-18 18:22:33 --> Form Validation Class Initialized
INFO - 2016-10-18 18:22:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:22:33 --> Final output sent to browser
DEBUG - 2016-10-18 18:22:33 --> Total execution time: 0.0090
INFO - 2016-10-18 18:22:41 --> Config Class Initialized
INFO - 2016-10-18 18:22:41 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:22:41 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:22:41 --> Utf8 Class Initialized
INFO - 2016-10-18 18:22:41 --> URI Class Initialized
DEBUG - 2016-10-18 18:22:41 --> No URI present. Default controller set.
INFO - 2016-10-18 18:22:41 --> Router Class Initialized
INFO - 2016-10-18 18:22:41 --> Output Class Initialized
INFO - 2016-10-18 18:22:41 --> Security Class Initialized
DEBUG - 2016-10-18 18:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:22:41 --> Input Class Initialized
INFO - 2016-10-18 18:22:41 --> Language Class Initialized
INFO - 2016-10-18 18:22:41 --> Loader Class Initialized
INFO - 2016-10-18 18:22:41 --> Helper loaded: url_helper
INFO - 2016-10-18 18:22:41 --> Helper loaded: form_helper
INFO - 2016-10-18 18:22:41 --> Database Driver Class Initialized
INFO - 2016-10-18 18:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:22:41 --> Controller Class Initialized
INFO - 2016-10-18 18:22:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:22:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:22:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:22:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:22:41 --> Final output sent to browser
DEBUG - 2016-10-18 18:22:41 --> Total execution time: 0.0052
INFO - 2016-10-18 18:22:44 --> Config Class Initialized
INFO - 2016-10-18 18:22:44 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:22:44 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:22:44 --> Utf8 Class Initialized
INFO - 2016-10-18 18:22:44 --> URI Class Initialized
INFO - 2016-10-18 18:22:44 --> Router Class Initialized
INFO - 2016-10-18 18:22:44 --> Output Class Initialized
INFO - 2016-10-18 18:22:44 --> Security Class Initialized
DEBUG - 2016-10-18 18:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:22:44 --> Input Class Initialized
INFO - 2016-10-18 18:22:44 --> Language Class Initialized
INFO - 2016-10-18 18:22:44 --> Loader Class Initialized
INFO - 2016-10-18 18:22:44 --> Helper loaded: url_helper
INFO - 2016-10-18 18:22:44 --> Helper loaded: form_helper
INFO - 2016-10-18 18:22:44 --> Database Driver Class Initialized
INFO - 2016-10-18 18:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:22:44 --> Controller Class Initialized
INFO - 2016-10-18 18:22:44 --> Form Validation Class Initialized
INFO - 2016-10-18 18:22:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:22:44 --> Final output sent to browser
DEBUG - 2016-10-18 18:22:44 --> Total execution time: 0.0066
INFO - 2016-10-18 18:22:46 --> Config Class Initialized
INFO - 2016-10-18 18:22:46 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:22:46 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:22:46 --> Utf8 Class Initialized
INFO - 2016-10-18 18:22:46 --> URI Class Initialized
DEBUG - 2016-10-18 18:22:46 --> No URI present. Default controller set.
INFO - 2016-10-18 18:22:46 --> Router Class Initialized
INFO - 2016-10-18 18:22:46 --> Output Class Initialized
INFO - 2016-10-18 18:22:46 --> Security Class Initialized
DEBUG - 2016-10-18 18:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:22:46 --> Input Class Initialized
INFO - 2016-10-18 18:22:46 --> Language Class Initialized
INFO - 2016-10-18 18:22:46 --> Loader Class Initialized
INFO - 2016-10-18 18:22:46 --> Helper loaded: url_helper
INFO - 2016-10-18 18:22:46 --> Helper loaded: form_helper
INFO - 2016-10-18 18:22:46 --> Database Driver Class Initialized
INFO - 2016-10-18 18:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:22:46 --> Controller Class Initialized
INFO - 2016-10-18 18:22:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:22:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:22:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:22:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:22:46 --> Final output sent to browser
DEBUG - 2016-10-18 18:22:46 --> Total execution time: 0.0050
INFO - 2016-10-18 18:23:00 --> Config Class Initialized
INFO - 2016-10-18 18:23:00 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:23:00 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:23:00 --> Utf8 Class Initialized
INFO - 2016-10-18 18:23:00 --> URI Class Initialized
DEBUG - 2016-10-18 18:23:00 --> No URI present. Default controller set.
INFO - 2016-10-18 18:23:00 --> Router Class Initialized
INFO - 2016-10-18 18:23:00 --> Output Class Initialized
INFO - 2016-10-18 18:23:00 --> Security Class Initialized
DEBUG - 2016-10-18 18:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:23:00 --> Input Class Initialized
INFO - 2016-10-18 18:23:00 --> Language Class Initialized
INFO - 2016-10-18 18:23:00 --> Loader Class Initialized
INFO - 2016-10-18 18:23:00 --> Helper loaded: url_helper
INFO - 2016-10-18 18:23:00 --> Helper loaded: form_helper
INFO - 2016-10-18 18:23:00 --> Database Driver Class Initialized
INFO - 2016-10-18 18:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:23:00 --> Controller Class Initialized
INFO - 2016-10-18 18:23:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:23:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:23:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:23:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:23:00 --> Final output sent to browser
DEBUG - 2016-10-18 18:23:00 --> Total execution time: 0.0055
INFO - 2016-10-18 18:23:06 --> Config Class Initialized
INFO - 2016-10-18 18:23:06 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:23:06 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:23:06 --> Utf8 Class Initialized
INFO - 2016-10-18 18:23:06 --> URI Class Initialized
INFO - 2016-10-18 18:23:06 --> Router Class Initialized
INFO - 2016-10-18 18:23:06 --> Output Class Initialized
INFO - 2016-10-18 18:23:06 --> Security Class Initialized
DEBUG - 2016-10-18 18:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:23:06 --> Input Class Initialized
INFO - 2016-10-18 18:23:06 --> Language Class Initialized
INFO - 2016-10-18 18:23:06 --> Loader Class Initialized
INFO - 2016-10-18 18:23:06 --> Helper loaded: url_helper
INFO - 2016-10-18 18:23:06 --> Helper loaded: form_helper
INFO - 2016-10-18 18:23:06 --> Database Driver Class Initialized
INFO - 2016-10-18 18:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:23:06 --> Controller Class Initialized
INFO - 2016-10-18 18:23:06 --> Form Validation Class Initialized
INFO - 2016-10-18 18:23:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:23:06 --> Final output sent to browser
DEBUG - 2016-10-18 18:23:06 --> Total execution time: 0.0062
INFO - 2016-10-18 18:23:56 --> Config Class Initialized
INFO - 2016-10-18 18:23:56 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:23:56 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:23:56 --> Utf8 Class Initialized
INFO - 2016-10-18 18:23:56 --> URI Class Initialized
DEBUG - 2016-10-18 18:23:56 --> No URI present. Default controller set.
INFO - 2016-10-18 18:23:56 --> Router Class Initialized
INFO - 2016-10-18 18:23:56 --> Output Class Initialized
INFO - 2016-10-18 18:23:56 --> Security Class Initialized
DEBUG - 2016-10-18 18:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:23:56 --> Input Class Initialized
INFO - 2016-10-18 18:23:56 --> Language Class Initialized
INFO - 2016-10-18 18:23:56 --> Loader Class Initialized
INFO - 2016-10-18 18:23:56 --> Helper loaded: url_helper
INFO - 2016-10-18 18:23:56 --> Helper loaded: form_helper
INFO - 2016-10-18 18:23:56 --> Database Driver Class Initialized
INFO - 2016-10-18 18:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:23:56 --> Controller Class Initialized
INFO - 2016-10-18 18:23:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:23:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:23:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:23:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:23:56 --> Final output sent to browser
DEBUG - 2016-10-18 18:23:56 --> Total execution time: 0.0052
INFO - 2016-10-18 18:24:00 --> Config Class Initialized
INFO - 2016-10-18 18:24:00 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:24:00 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:24:00 --> Utf8 Class Initialized
INFO - 2016-10-18 18:24:00 --> URI Class Initialized
INFO - 2016-10-18 18:24:00 --> Router Class Initialized
INFO - 2016-10-18 18:24:00 --> Output Class Initialized
INFO - 2016-10-18 18:24:00 --> Security Class Initialized
DEBUG - 2016-10-18 18:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:24:00 --> Input Class Initialized
INFO - 2016-10-18 18:24:00 --> Language Class Initialized
INFO - 2016-10-18 18:24:00 --> Loader Class Initialized
INFO - 2016-10-18 18:24:00 --> Helper loaded: url_helper
INFO - 2016-10-18 18:24:00 --> Helper loaded: form_helper
INFO - 2016-10-18 18:24:00 --> Database Driver Class Initialized
INFO - 2016-10-18 18:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:24:00 --> Controller Class Initialized
INFO - 2016-10-18 18:24:00 --> Form Validation Class Initialized
INFO - 2016-10-18 18:24:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:24:00 --> Final output sent to browser
DEBUG - 2016-10-18 18:24:00 --> Total execution time: 0.0062
INFO - 2016-10-18 18:24:16 --> Config Class Initialized
INFO - 2016-10-18 18:24:16 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:24:16 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:24:16 --> Utf8 Class Initialized
INFO - 2016-10-18 18:24:16 --> URI Class Initialized
DEBUG - 2016-10-18 18:24:16 --> No URI present. Default controller set.
INFO - 2016-10-18 18:24:16 --> Router Class Initialized
INFO - 2016-10-18 18:24:16 --> Output Class Initialized
INFO - 2016-10-18 18:24:16 --> Security Class Initialized
DEBUG - 2016-10-18 18:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:24:16 --> Input Class Initialized
INFO - 2016-10-18 18:24:16 --> Language Class Initialized
INFO - 2016-10-18 18:24:16 --> Loader Class Initialized
INFO - 2016-10-18 18:24:16 --> Helper loaded: url_helper
INFO - 2016-10-18 18:24:16 --> Helper loaded: form_helper
INFO - 2016-10-18 18:24:16 --> Database Driver Class Initialized
INFO - 2016-10-18 18:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:24:16 --> Controller Class Initialized
INFO - 2016-10-18 18:24:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:24:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:24:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:24:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:24:16 --> Final output sent to browser
DEBUG - 2016-10-18 18:24:16 --> Total execution time: 0.0053
INFO - 2016-10-18 18:24:22 --> Config Class Initialized
INFO - 2016-10-18 18:24:22 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:24:22 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:24:22 --> Utf8 Class Initialized
INFO - 2016-10-18 18:24:22 --> URI Class Initialized
INFO - 2016-10-18 18:24:22 --> Router Class Initialized
INFO - 2016-10-18 18:24:22 --> Output Class Initialized
INFO - 2016-10-18 18:24:22 --> Security Class Initialized
DEBUG - 2016-10-18 18:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:24:22 --> Input Class Initialized
INFO - 2016-10-18 18:24:22 --> Language Class Initialized
INFO - 2016-10-18 18:24:22 --> Loader Class Initialized
INFO - 2016-10-18 18:24:22 --> Helper loaded: url_helper
INFO - 2016-10-18 18:24:22 --> Helper loaded: form_helper
INFO - 2016-10-18 18:24:22 --> Database Driver Class Initialized
INFO - 2016-10-18 18:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:24:22 --> Controller Class Initialized
INFO - 2016-10-18 18:24:22 --> Form Validation Class Initialized
INFO - 2016-10-18 18:24:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:24:22 --> Final output sent to browser
DEBUG - 2016-10-18 18:24:22 --> Total execution time: 0.0094
INFO - 2016-10-18 18:24:26 --> Config Class Initialized
INFO - 2016-10-18 18:24:26 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:24:26 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:24:26 --> Utf8 Class Initialized
INFO - 2016-10-18 18:24:26 --> URI Class Initialized
DEBUG - 2016-10-18 18:24:26 --> No URI present. Default controller set.
INFO - 2016-10-18 18:24:26 --> Router Class Initialized
INFO - 2016-10-18 18:24:26 --> Output Class Initialized
INFO - 2016-10-18 18:24:26 --> Security Class Initialized
DEBUG - 2016-10-18 18:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:24:26 --> Input Class Initialized
INFO - 2016-10-18 18:24:26 --> Language Class Initialized
INFO - 2016-10-18 18:24:26 --> Loader Class Initialized
INFO - 2016-10-18 18:24:26 --> Helper loaded: url_helper
INFO - 2016-10-18 18:24:26 --> Helper loaded: form_helper
INFO - 2016-10-18 18:24:26 --> Database Driver Class Initialized
INFO - 2016-10-18 18:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:24:26 --> Controller Class Initialized
INFO - 2016-10-18 18:24:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:24:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:24:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:24:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:24:26 --> Final output sent to browser
DEBUG - 2016-10-18 18:24:26 --> Total execution time: 0.0052
INFO - 2016-10-18 18:24:34 --> Config Class Initialized
INFO - 2016-10-18 18:24:34 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:24:34 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:24:34 --> Utf8 Class Initialized
INFO - 2016-10-18 18:24:34 --> URI Class Initialized
DEBUG - 2016-10-18 18:24:34 --> No URI present. Default controller set.
INFO - 2016-10-18 18:24:34 --> Router Class Initialized
INFO - 2016-10-18 18:24:34 --> Output Class Initialized
INFO - 2016-10-18 18:24:34 --> Security Class Initialized
DEBUG - 2016-10-18 18:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:24:34 --> Input Class Initialized
INFO - 2016-10-18 18:24:34 --> Language Class Initialized
INFO - 2016-10-18 18:24:34 --> Loader Class Initialized
INFO - 2016-10-18 18:24:34 --> Helper loaded: url_helper
INFO - 2016-10-18 18:24:34 --> Helper loaded: form_helper
INFO - 2016-10-18 18:24:34 --> Database Driver Class Initialized
INFO - 2016-10-18 18:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:24:34 --> Controller Class Initialized
INFO - 2016-10-18 18:24:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:24:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:24:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:24:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:24:34 --> Final output sent to browser
DEBUG - 2016-10-18 18:24:34 --> Total execution time: 0.0053
INFO - 2016-10-18 18:24:36 --> Config Class Initialized
INFO - 2016-10-18 18:24:36 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:24:36 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:24:36 --> Utf8 Class Initialized
INFO - 2016-10-18 18:24:36 --> URI Class Initialized
INFO - 2016-10-18 18:24:36 --> Router Class Initialized
INFO - 2016-10-18 18:24:36 --> Output Class Initialized
INFO - 2016-10-18 18:24:36 --> Security Class Initialized
DEBUG - 2016-10-18 18:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:24:36 --> Input Class Initialized
INFO - 2016-10-18 18:24:36 --> Language Class Initialized
INFO - 2016-10-18 18:24:36 --> Loader Class Initialized
INFO - 2016-10-18 18:24:36 --> Helper loaded: url_helper
INFO - 2016-10-18 18:24:36 --> Helper loaded: form_helper
INFO - 2016-10-18 18:24:36 --> Database Driver Class Initialized
INFO - 2016-10-18 18:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:24:36 --> Controller Class Initialized
INFO - 2016-10-18 18:24:36 --> Form Validation Class Initialized
INFO - 2016-10-18 18:24:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:24:36 --> Final output sent to browser
DEBUG - 2016-10-18 18:24:36 --> Total execution time: 0.0096
INFO - 2016-10-18 18:24:39 --> Config Class Initialized
INFO - 2016-10-18 18:24:39 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:24:39 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:24:39 --> Utf8 Class Initialized
INFO - 2016-10-18 18:24:39 --> URI Class Initialized
DEBUG - 2016-10-18 18:24:39 --> No URI present. Default controller set.
INFO - 2016-10-18 18:24:39 --> Router Class Initialized
INFO - 2016-10-18 18:24:39 --> Output Class Initialized
INFO - 2016-10-18 18:24:39 --> Security Class Initialized
DEBUG - 2016-10-18 18:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:24:39 --> Input Class Initialized
INFO - 2016-10-18 18:24:39 --> Language Class Initialized
INFO - 2016-10-18 18:24:39 --> Loader Class Initialized
INFO - 2016-10-18 18:24:39 --> Helper loaded: url_helper
INFO - 2016-10-18 18:24:39 --> Helper loaded: form_helper
INFO - 2016-10-18 18:24:39 --> Database Driver Class Initialized
INFO - 2016-10-18 18:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:24:39 --> Controller Class Initialized
INFO - 2016-10-18 18:24:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:24:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:24:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:24:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:24:39 --> Final output sent to browser
DEBUG - 2016-10-18 18:24:39 --> Total execution time: 0.0051
INFO - 2016-10-18 18:25:58 --> Config Class Initialized
INFO - 2016-10-18 18:25:58 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:25:58 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:25:58 --> Utf8 Class Initialized
INFO - 2016-10-18 18:25:58 --> URI Class Initialized
DEBUG - 2016-10-18 18:25:58 --> No URI present. Default controller set.
INFO - 2016-10-18 18:25:58 --> Router Class Initialized
INFO - 2016-10-18 18:25:58 --> Output Class Initialized
INFO - 2016-10-18 18:25:58 --> Security Class Initialized
DEBUG - 2016-10-18 18:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:25:58 --> Input Class Initialized
INFO - 2016-10-18 18:25:58 --> Language Class Initialized
INFO - 2016-10-18 18:25:58 --> Loader Class Initialized
INFO - 2016-10-18 18:25:58 --> Helper loaded: url_helper
INFO - 2016-10-18 18:25:58 --> Helper loaded: form_helper
INFO - 2016-10-18 18:25:58 --> Database Driver Class Initialized
INFO - 2016-10-18 18:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:25:58 --> Controller Class Initialized
INFO - 2016-10-18 18:25:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:25:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:25:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:25:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:25:58 --> Final output sent to browser
DEBUG - 2016-10-18 18:25:58 --> Total execution time: 0.0055
INFO - 2016-10-18 18:26:02 --> Config Class Initialized
INFO - 2016-10-18 18:26:02 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:26:02 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:26:02 --> Utf8 Class Initialized
INFO - 2016-10-18 18:26:02 --> URI Class Initialized
INFO - 2016-10-18 18:26:02 --> Router Class Initialized
INFO - 2016-10-18 18:26:02 --> Output Class Initialized
INFO - 2016-10-18 18:26:02 --> Security Class Initialized
DEBUG - 2016-10-18 18:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:26:02 --> Input Class Initialized
INFO - 2016-10-18 18:26:02 --> Language Class Initialized
INFO - 2016-10-18 18:26:02 --> Loader Class Initialized
INFO - 2016-10-18 18:26:02 --> Helper loaded: url_helper
INFO - 2016-10-18 18:26:02 --> Helper loaded: form_helper
INFO - 2016-10-18 18:26:02 --> Database Driver Class Initialized
INFO - 2016-10-18 18:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:26:02 --> Controller Class Initialized
INFO - 2016-10-18 18:26:02 --> Form Validation Class Initialized
INFO - 2016-10-18 18:26:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:26:02 --> Final output sent to browser
DEBUG - 2016-10-18 18:26:02 --> Total execution time: 0.0073
INFO - 2016-10-18 18:26:13 --> Config Class Initialized
INFO - 2016-10-18 18:26:13 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:26:13 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:26:13 --> Utf8 Class Initialized
INFO - 2016-10-18 18:26:13 --> URI Class Initialized
INFO - 2016-10-18 18:26:13 --> Router Class Initialized
INFO - 2016-10-18 18:26:13 --> Output Class Initialized
INFO - 2016-10-18 18:26:13 --> Security Class Initialized
DEBUG - 2016-10-18 18:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:26:13 --> Input Class Initialized
INFO - 2016-10-18 18:26:13 --> Language Class Initialized
INFO - 2016-10-18 18:26:13 --> Loader Class Initialized
INFO - 2016-10-18 18:26:13 --> Helper loaded: url_helper
INFO - 2016-10-18 18:26:13 --> Helper loaded: form_helper
INFO - 2016-10-18 18:26:13 --> Database Driver Class Initialized
INFO - 2016-10-18 18:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:26:13 --> Controller Class Initialized
INFO - 2016-10-18 18:26:13 --> Form Validation Class Initialized
INFO - 2016-10-18 18:26:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:26:13 --> Final output sent to browser
DEBUG - 2016-10-18 18:26:13 --> Total execution time: 0.0062
INFO - 2016-10-18 18:26:16 --> Config Class Initialized
INFO - 2016-10-18 18:26:16 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:26:16 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:26:16 --> Utf8 Class Initialized
INFO - 2016-10-18 18:26:16 --> URI Class Initialized
DEBUG - 2016-10-18 18:26:16 --> No URI present. Default controller set.
INFO - 2016-10-18 18:26:16 --> Router Class Initialized
INFO - 2016-10-18 18:26:16 --> Output Class Initialized
INFO - 2016-10-18 18:26:16 --> Security Class Initialized
DEBUG - 2016-10-18 18:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:26:16 --> Input Class Initialized
INFO - 2016-10-18 18:26:16 --> Language Class Initialized
INFO - 2016-10-18 18:26:16 --> Loader Class Initialized
INFO - 2016-10-18 18:26:16 --> Helper loaded: url_helper
INFO - 2016-10-18 18:26:16 --> Helper loaded: form_helper
INFO - 2016-10-18 18:26:16 --> Database Driver Class Initialized
INFO - 2016-10-18 18:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:26:16 --> Controller Class Initialized
INFO - 2016-10-18 18:26:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:26:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:26:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:26:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:26:16 --> Final output sent to browser
DEBUG - 2016-10-18 18:26:16 --> Total execution time: 0.0049
INFO - 2016-10-18 18:26:19 --> Config Class Initialized
INFO - 2016-10-18 18:26:19 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:26:19 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:26:19 --> Utf8 Class Initialized
INFO - 2016-10-18 18:26:19 --> URI Class Initialized
INFO - 2016-10-18 18:26:19 --> Router Class Initialized
INFO - 2016-10-18 18:26:19 --> Output Class Initialized
INFO - 2016-10-18 18:26:19 --> Security Class Initialized
DEBUG - 2016-10-18 18:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:26:19 --> Input Class Initialized
INFO - 2016-10-18 18:26:19 --> Language Class Initialized
INFO - 2016-10-18 18:26:19 --> Loader Class Initialized
INFO - 2016-10-18 18:26:19 --> Helper loaded: url_helper
INFO - 2016-10-18 18:26:19 --> Helper loaded: form_helper
INFO - 2016-10-18 18:26:19 --> Database Driver Class Initialized
INFO - 2016-10-18 18:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:26:19 --> Controller Class Initialized
INFO - 2016-10-18 18:26:19 --> Form Validation Class Initialized
INFO - 2016-10-18 18:26:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:26:19 --> Final output sent to browser
DEBUG - 2016-10-18 18:26:19 --> Total execution time: 0.0078
INFO - 2016-10-18 18:26:24 --> Config Class Initialized
INFO - 2016-10-18 18:26:24 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:26:24 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:26:24 --> Utf8 Class Initialized
INFO - 2016-10-18 18:26:24 --> URI Class Initialized
DEBUG - 2016-10-18 18:26:24 --> No URI present. Default controller set.
INFO - 2016-10-18 18:26:24 --> Router Class Initialized
INFO - 2016-10-18 18:26:24 --> Output Class Initialized
INFO - 2016-10-18 18:26:24 --> Security Class Initialized
DEBUG - 2016-10-18 18:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:26:24 --> Input Class Initialized
INFO - 2016-10-18 18:26:24 --> Language Class Initialized
INFO - 2016-10-18 18:26:24 --> Loader Class Initialized
INFO - 2016-10-18 18:26:24 --> Helper loaded: url_helper
INFO - 2016-10-18 18:26:24 --> Helper loaded: form_helper
INFO - 2016-10-18 18:26:24 --> Database Driver Class Initialized
INFO - 2016-10-18 18:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:26:24 --> Controller Class Initialized
INFO - 2016-10-18 18:26:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:26:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:26:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:26:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:26:24 --> Final output sent to browser
DEBUG - 2016-10-18 18:26:24 --> Total execution time: 0.0057
INFO - 2016-10-18 18:29:09 --> Config Class Initialized
INFO - 2016-10-18 18:29:09 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:29:09 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:29:09 --> Utf8 Class Initialized
INFO - 2016-10-18 18:29:09 --> URI Class Initialized
DEBUG - 2016-10-18 18:29:09 --> No URI present. Default controller set.
INFO - 2016-10-18 18:29:09 --> Router Class Initialized
INFO - 2016-10-18 18:29:09 --> Output Class Initialized
INFO - 2016-10-18 18:29:09 --> Security Class Initialized
DEBUG - 2016-10-18 18:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:29:09 --> Input Class Initialized
INFO - 2016-10-18 18:29:09 --> Language Class Initialized
INFO - 2016-10-18 18:29:09 --> Loader Class Initialized
INFO - 2016-10-18 18:29:09 --> Helper loaded: url_helper
INFO - 2016-10-18 18:29:09 --> Helper loaded: form_helper
INFO - 2016-10-18 18:29:09 --> Database Driver Class Initialized
INFO - 2016-10-18 18:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:29:09 --> Controller Class Initialized
INFO - 2016-10-18 18:29:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:29:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:29:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:29:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:29:09 --> Final output sent to browser
DEBUG - 2016-10-18 18:29:09 --> Total execution time: 0.0055
INFO - 2016-10-18 18:29:12 --> Config Class Initialized
INFO - 2016-10-18 18:29:12 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:29:12 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:29:12 --> Utf8 Class Initialized
INFO - 2016-10-18 18:29:12 --> URI Class Initialized
INFO - 2016-10-18 18:29:12 --> Router Class Initialized
INFO - 2016-10-18 18:29:12 --> Output Class Initialized
INFO - 2016-10-18 18:29:12 --> Security Class Initialized
DEBUG - 2016-10-18 18:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:29:12 --> Input Class Initialized
INFO - 2016-10-18 18:29:12 --> Language Class Initialized
INFO - 2016-10-18 18:29:12 --> Loader Class Initialized
INFO - 2016-10-18 18:29:12 --> Helper loaded: url_helper
INFO - 2016-10-18 18:29:12 --> Helper loaded: form_helper
INFO - 2016-10-18 18:29:12 --> Database Driver Class Initialized
INFO - 2016-10-18 18:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:29:12 --> Controller Class Initialized
INFO - 2016-10-18 18:29:12 --> Form Validation Class Initialized
INFO - 2016-10-18 18:29:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:29:12 --> Final output sent to browser
DEBUG - 2016-10-18 18:29:12 --> Total execution time: 0.0061
INFO - 2016-10-18 18:29:17 --> Config Class Initialized
INFO - 2016-10-18 18:29:17 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:29:17 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:29:17 --> Utf8 Class Initialized
INFO - 2016-10-18 18:29:17 --> URI Class Initialized
INFO - 2016-10-18 18:29:17 --> Router Class Initialized
INFO - 2016-10-18 18:29:17 --> Output Class Initialized
INFO - 2016-10-18 18:29:17 --> Security Class Initialized
DEBUG - 2016-10-18 18:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:29:17 --> Input Class Initialized
INFO - 2016-10-18 18:29:17 --> Language Class Initialized
INFO - 2016-10-18 18:29:17 --> Loader Class Initialized
INFO - 2016-10-18 18:29:17 --> Helper loaded: url_helper
INFO - 2016-10-18 18:29:17 --> Helper loaded: form_helper
INFO - 2016-10-18 18:29:17 --> Database Driver Class Initialized
INFO - 2016-10-18 18:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:29:17 --> Controller Class Initialized
INFO - 2016-10-18 18:29:17 --> Form Validation Class Initialized
INFO - 2016-10-18 18:29:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:29:17 --> Final output sent to browser
DEBUG - 2016-10-18 18:29:17 --> Total execution time: 0.0064
INFO - 2016-10-18 18:29:21 --> Config Class Initialized
INFO - 2016-10-18 18:29:21 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:29:21 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:29:21 --> Utf8 Class Initialized
INFO - 2016-10-18 18:29:21 --> URI Class Initialized
INFO - 2016-10-18 18:29:21 --> Router Class Initialized
INFO - 2016-10-18 18:29:21 --> Output Class Initialized
INFO - 2016-10-18 18:29:21 --> Security Class Initialized
DEBUG - 2016-10-18 18:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:29:21 --> Input Class Initialized
INFO - 2016-10-18 18:29:21 --> Language Class Initialized
INFO - 2016-10-18 18:29:21 --> Loader Class Initialized
INFO - 2016-10-18 18:29:21 --> Helper loaded: url_helper
INFO - 2016-10-18 18:29:21 --> Helper loaded: form_helper
INFO - 2016-10-18 18:29:21 --> Database Driver Class Initialized
INFO - 2016-10-18 18:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:29:21 --> Controller Class Initialized
INFO - 2016-10-18 18:29:21 --> Form Validation Class Initialized
INFO - 2016-10-18 18:29:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:29:21 --> Final output sent to browser
DEBUG - 2016-10-18 18:29:21 --> Total execution time: 0.0062
INFO - 2016-10-18 18:29:24 --> Config Class Initialized
INFO - 2016-10-18 18:29:24 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:29:24 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:29:24 --> Utf8 Class Initialized
INFO - 2016-10-18 18:29:24 --> URI Class Initialized
INFO - 2016-10-18 18:29:24 --> Router Class Initialized
INFO - 2016-10-18 18:29:24 --> Output Class Initialized
INFO - 2016-10-18 18:29:24 --> Security Class Initialized
DEBUG - 2016-10-18 18:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:29:24 --> Input Class Initialized
INFO - 2016-10-18 18:29:24 --> Language Class Initialized
INFO - 2016-10-18 18:29:24 --> Loader Class Initialized
INFO - 2016-10-18 18:29:24 --> Helper loaded: url_helper
INFO - 2016-10-18 18:29:24 --> Helper loaded: form_helper
INFO - 2016-10-18 18:29:24 --> Database Driver Class Initialized
INFO - 2016-10-18 18:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:29:24 --> Controller Class Initialized
INFO - 2016-10-18 18:29:24 --> Form Validation Class Initialized
INFO - 2016-10-18 18:29:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:29:24 --> Final output sent to browser
DEBUG - 2016-10-18 18:29:24 --> Total execution time: 0.0057
INFO - 2016-10-18 18:29:28 --> Config Class Initialized
INFO - 2016-10-18 18:29:28 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:29:28 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:29:28 --> Utf8 Class Initialized
INFO - 2016-10-18 18:29:28 --> URI Class Initialized
INFO - 2016-10-18 18:29:28 --> Router Class Initialized
INFO - 2016-10-18 18:29:28 --> Output Class Initialized
INFO - 2016-10-18 18:29:28 --> Security Class Initialized
DEBUG - 2016-10-18 18:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:29:28 --> Input Class Initialized
INFO - 2016-10-18 18:29:28 --> Language Class Initialized
INFO - 2016-10-18 18:29:28 --> Loader Class Initialized
INFO - 2016-10-18 18:29:28 --> Helper loaded: url_helper
INFO - 2016-10-18 18:29:28 --> Helper loaded: form_helper
INFO - 2016-10-18 18:29:28 --> Database Driver Class Initialized
INFO - 2016-10-18 18:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:29:28 --> Controller Class Initialized
INFO - 2016-10-18 18:29:28 --> Form Validation Class Initialized
INFO - 2016-10-18 18:29:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:29:28 --> Final output sent to browser
DEBUG - 2016-10-18 18:29:28 --> Total execution time: 0.0061
INFO - 2016-10-18 18:29:51 --> Config Class Initialized
INFO - 2016-10-18 18:29:51 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:29:51 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:29:51 --> Utf8 Class Initialized
INFO - 2016-10-18 18:29:51 --> URI Class Initialized
DEBUG - 2016-10-18 18:29:51 --> No URI present. Default controller set.
INFO - 2016-10-18 18:29:51 --> Router Class Initialized
INFO - 2016-10-18 18:29:51 --> Output Class Initialized
INFO - 2016-10-18 18:29:51 --> Security Class Initialized
DEBUG - 2016-10-18 18:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:29:51 --> Input Class Initialized
INFO - 2016-10-18 18:29:51 --> Language Class Initialized
INFO - 2016-10-18 18:29:51 --> Loader Class Initialized
INFO - 2016-10-18 18:29:51 --> Helper loaded: url_helper
INFO - 2016-10-18 18:29:51 --> Helper loaded: form_helper
INFO - 2016-10-18 18:29:51 --> Database Driver Class Initialized
INFO - 2016-10-18 18:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:29:51 --> Controller Class Initialized
INFO - 2016-10-18 18:29:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:29:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:29:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:29:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:29:51 --> Final output sent to browser
DEBUG - 2016-10-18 18:29:51 --> Total execution time: 0.0057
INFO - 2016-10-18 18:29:53 --> Config Class Initialized
INFO - 2016-10-18 18:29:53 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:29:53 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:29:53 --> Utf8 Class Initialized
INFO - 2016-10-18 18:29:53 --> URI Class Initialized
INFO - 2016-10-18 18:29:53 --> Router Class Initialized
INFO - 2016-10-18 18:29:53 --> Output Class Initialized
INFO - 2016-10-18 18:29:53 --> Security Class Initialized
DEBUG - 2016-10-18 18:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:29:53 --> Input Class Initialized
INFO - 2016-10-18 18:29:53 --> Language Class Initialized
INFO - 2016-10-18 18:29:53 --> Loader Class Initialized
INFO - 2016-10-18 18:29:53 --> Helper loaded: url_helper
INFO - 2016-10-18 18:29:53 --> Helper loaded: form_helper
INFO - 2016-10-18 18:29:53 --> Database Driver Class Initialized
INFO - 2016-10-18 18:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:29:53 --> Controller Class Initialized
INFO - 2016-10-18 18:29:53 --> Form Validation Class Initialized
INFO - 2016-10-18 18:29:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:29:53 --> Final output sent to browser
DEBUG - 2016-10-18 18:29:53 --> Total execution time: 0.0059
INFO - 2016-10-18 18:29:54 --> Config Class Initialized
INFO - 2016-10-18 18:29:54 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:29:54 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:29:54 --> Utf8 Class Initialized
INFO - 2016-10-18 18:29:54 --> URI Class Initialized
INFO - 2016-10-18 18:29:54 --> Router Class Initialized
INFO - 2016-10-18 18:29:54 --> Output Class Initialized
INFO - 2016-10-18 18:29:54 --> Security Class Initialized
DEBUG - 2016-10-18 18:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:29:54 --> Input Class Initialized
INFO - 2016-10-18 18:29:54 --> Language Class Initialized
INFO - 2016-10-18 18:29:54 --> Loader Class Initialized
INFO - 2016-10-18 18:29:54 --> Helper loaded: url_helper
INFO - 2016-10-18 18:29:54 --> Helper loaded: form_helper
INFO - 2016-10-18 18:29:54 --> Database Driver Class Initialized
INFO - 2016-10-18 18:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:29:54 --> Controller Class Initialized
INFO - 2016-10-18 18:29:54 --> Form Validation Class Initialized
INFO - 2016-10-18 18:29:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:29:54 --> Final output sent to browser
DEBUG - 2016-10-18 18:29:54 --> Total execution time: 0.0058
INFO - 2016-10-18 18:29:59 --> Config Class Initialized
INFO - 2016-10-18 18:29:59 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:29:59 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:29:59 --> Utf8 Class Initialized
INFO - 2016-10-18 18:29:59 --> URI Class Initialized
INFO - 2016-10-18 18:29:59 --> Router Class Initialized
INFO - 2016-10-18 18:29:59 --> Output Class Initialized
INFO - 2016-10-18 18:29:59 --> Security Class Initialized
DEBUG - 2016-10-18 18:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:29:59 --> Input Class Initialized
INFO - 2016-10-18 18:29:59 --> Language Class Initialized
INFO - 2016-10-18 18:29:59 --> Loader Class Initialized
INFO - 2016-10-18 18:29:59 --> Helper loaded: url_helper
INFO - 2016-10-18 18:29:59 --> Helper loaded: form_helper
INFO - 2016-10-18 18:29:59 --> Database Driver Class Initialized
INFO - 2016-10-18 18:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:29:59 --> Controller Class Initialized
ERROR - 2016-10-18 18:29:59 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 121
ERROR - 2016-10-18 18:29:59 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 121
INFO - 2016-10-18 18:29:59 --> Config Class Initialized
INFO - 2016-10-18 18:29:59 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:29:59 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:29:59 --> Utf8 Class Initialized
INFO - 2016-10-18 18:29:59 --> URI Class Initialized
DEBUG - 2016-10-18 18:29:59 --> No URI present. Default controller set.
INFO - 2016-10-18 18:29:59 --> Router Class Initialized
INFO - 2016-10-18 18:29:59 --> Output Class Initialized
INFO - 2016-10-18 18:29:59 --> Security Class Initialized
DEBUG - 2016-10-18 18:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:29:59 --> Input Class Initialized
INFO - 2016-10-18 18:29:59 --> Language Class Initialized
INFO - 2016-10-18 18:29:59 --> Loader Class Initialized
INFO - 2016-10-18 18:29:59 --> Helper loaded: url_helper
INFO - 2016-10-18 18:29:59 --> Helper loaded: form_helper
INFO - 2016-10-18 18:29:59 --> Database Driver Class Initialized
INFO - 2016-10-18 18:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:29:59 --> Controller Class Initialized
INFO - 2016-10-18 18:29:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:29:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 18:29:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:29:59 --> Final output sent to browser
DEBUG - 2016-10-18 18:29:59 --> Total execution time: 0.0049
INFO - 2016-10-18 18:30:07 --> Config Class Initialized
INFO - 2016-10-18 18:30:07 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:30:07 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:30:07 --> Utf8 Class Initialized
INFO - 2016-10-18 18:30:07 --> URI Class Initialized
INFO - 2016-10-18 18:30:07 --> Router Class Initialized
INFO - 2016-10-18 18:30:07 --> Output Class Initialized
INFO - 2016-10-18 18:30:07 --> Security Class Initialized
DEBUG - 2016-10-18 18:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:30:07 --> Input Class Initialized
INFO - 2016-10-18 18:30:07 --> Language Class Initialized
INFO - 2016-10-18 18:30:07 --> Loader Class Initialized
INFO - 2016-10-18 18:30:07 --> Helper loaded: url_helper
INFO - 2016-10-18 18:30:07 --> Helper loaded: form_helper
INFO - 2016-10-18 18:30:07 --> Database Driver Class Initialized
INFO - 2016-10-18 18:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:30:07 --> Controller Class Initialized
INFO - 2016-10-18 18:30:07 --> Model Class Initialized
INFO - 2016-10-18 18:30:07 --> Final output sent to browser
DEBUG - 2016-10-18 18:30:07 --> Total execution time: 0.0093
INFO - 2016-10-18 18:30:07 --> Config Class Initialized
INFO - 2016-10-18 18:30:07 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:30:07 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:30:07 --> Utf8 Class Initialized
INFO - 2016-10-18 18:30:07 --> URI Class Initialized
DEBUG - 2016-10-18 18:30:07 --> No URI present. Default controller set.
INFO - 2016-10-18 18:30:07 --> Router Class Initialized
INFO - 2016-10-18 18:30:07 --> Output Class Initialized
INFO - 2016-10-18 18:30:07 --> Security Class Initialized
DEBUG - 2016-10-18 18:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:30:07 --> Input Class Initialized
INFO - 2016-10-18 18:30:07 --> Language Class Initialized
INFO - 2016-10-18 18:30:07 --> Loader Class Initialized
INFO - 2016-10-18 18:30:07 --> Helper loaded: url_helper
INFO - 2016-10-18 18:30:07 --> Helper loaded: form_helper
INFO - 2016-10-18 18:30:07 --> Database Driver Class Initialized
INFO - 2016-10-18 18:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:30:07 --> Controller Class Initialized
INFO - 2016-10-18 18:30:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:30:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:30:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:30:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:30:07 --> Final output sent to browser
DEBUG - 2016-10-18 18:30:07 --> Total execution time: 0.0047
INFO - 2016-10-18 18:30:10 --> Config Class Initialized
INFO - 2016-10-18 18:30:10 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:30:10 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:30:10 --> Utf8 Class Initialized
INFO - 2016-10-18 18:30:10 --> URI Class Initialized
INFO - 2016-10-18 18:30:10 --> Router Class Initialized
INFO - 2016-10-18 18:30:10 --> Output Class Initialized
INFO - 2016-10-18 18:30:10 --> Security Class Initialized
DEBUG - 2016-10-18 18:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:30:10 --> Input Class Initialized
INFO - 2016-10-18 18:30:10 --> Language Class Initialized
INFO - 2016-10-18 18:30:10 --> Loader Class Initialized
INFO - 2016-10-18 18:30:10 --> Helper loaded: url_helper
INFO - 2016-10-18 18:30:10 --> Helper loaded: form_helper
INFO - 2016-10-18 18:30:10 --> Database Driver Class Initialized
INFO - 2016-10-18 18:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:30:10 --> Controller Class Initialized
INFO - 2016-10-18 18:30:10 --> Form Validation Class Initialized
INFO - 2016-10-18 18:30:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:30:10 --> Final output sent to browser
DEBUG - 2016-10-18 18:30:10 --> Total execution time: 0.0059
INFO - 2016-10-18 18:30:59 --> Config Class Initialized
INFO - 2016-10-18 18:30:59 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:30:59 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:30:59 --> Utf8 Class Initialized
INFO - 2016-10-18 18:30:59 --> URI Class Initialized
DEBUG - 2016-10-18 18:30:59 --> No URI present. Default controller set.
INFO - 2016-10-18 18:30:59 --> Router Class Initialized
INFO - 2016-10-18 18:30:59 --> Output Class Initialized
INFO - 2016-10-18 18:30:59 --> Security Class Initialized
DEBUG - 2016-10-18 18:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:30:59 --> Input Class Initialized
INFO - 2016-10-18 18:30:59 --> Language Class Initialized
INFO - 2016-10-18 18:30:59 --> Loader Class Initialized
INFO - 2016-10-18 18:30:59 --> Helper loaded: url_helper
INFO - 2016-10-18 18:30:59 --> Helper loaded: form_helper
INFO - 2016-10-18 18:30:59 --> Database Driver Class Initialized
INFO - 2016-10-18 18:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:30:59 --> Controller Class Initialized
INFO - 2016-10-18 18:30:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:30:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:30:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:30:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:30:59 --> Final output sent to browser
DEBUG - 2016-10-18 18:30:59 --> Total execution time: 0.0081
INFO - 2016-10-18 18:31:01 --> Config Class Initialized
INFO - 2016-10-18 18:31:01 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:31:01 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:31:01 --> Utf8 Class Initialized
INFO - 2016-10-18 18:31:01 --> URI Class Initialized
INFO - 2016-10-18 18:31:01 --> Router Class Initialized
INFO - 2016-10-18 18:31:01 --> Output Class Initialized
INFO - 2016-10-18 18:31:01 --> Security Class Initialized
DEBUG - 2016-10-18 18:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:31:01 --> Input Class Initialized
INFO - 2016-10-18 18:31:01 --> Language Class Initialized
INFO - 2016-10-18 18:31:01 --> Loader Class Initialized
INFO - 2016-10-18 18:31:01 --> Helper loaded: url_helper
INFO - 2016-10-18 18:31:01 --> Helper loaded: form_helper
INFO - 2016-10-18 18:31:01 --> Database Driver Class Initialized
INFO - 2016-10-18 18:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:31:01 --> Controller Class Initialized
INFO - 2016-10-18 18:31:01 --> Form Validation Class Initialized
INFO - 2016-10-18 18:31:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:31:01 --> Final output sent to browser
DEBUG - 2016-10-18 18:31:01 --> Total execution time: 0.0061
INFO - 2016-10-18 18:31:06 --> Config Class Initialized
INFO - 2016-10-18 18:31:06 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:31:06 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:31:06 --> Utf8 Class Initialized
INFO - 2016-10-18 18:31:06 --> URI Class Initialized
DEBUG - 2016-10-18 18:31:06 --> No URI present. Default controller set.
INFO - 2016-10-18 18:31:06 --> Router Class Initialized
INFO - 2016-10-18 18:31:06 --> Output Class Initialized
INFO - 2016-10-18 18:31:06 --> Security Class Initialized
DEBUG - 2016-10-18 18:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:31:06 --> Input Class Initialized
INFO - 2016-10-18 18:31:06 --> Language Class Initialized
INFO - 2016-10-18 18:31:06 --> Loader Class Initialized
INFO - 2016-10-18 18:31:06 --> Helper loaded: url_helper
INFO - 2016-10-18 18:31:06 --> Helper loaded: form_helper
INFO - 2016-10-18 18:31:06 --> Database Driver Class Initialized
INFO - 2016-10-18 18:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:31:06 --> Controller Class Initialized
INFO - 2016-10-18 18:31:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:31:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:31:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:31:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:31:06 --> Final output sent to browser
DEBUG - 2016-10-18 18:31:06 --> Total execution time: 0.0051
INFO - 2016-10-18 18:31:07 --> Config Class Initialized
INFO - 2016-10-18 18:31:07 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:31:07 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:31:07 --> Utf8 Class Initialized
INFO - 2016-10-18 18:31:07 --> URI Class Initialized
DEBUG - 2016-10-18 18:31:07 --> No URI present. Default controller set.
INFO - 2016-10-18 18:31:07 --> Router Class Initialized
INFO - 2016-10-18 18:31:07 --> Output Class Initialized
INFO - 2016-10-18 18:31:07 --> Security Class Initialized
DEBUG - 2016-10-18 18:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:31:07 --> Input Class Initialized
INFO - 2016-10-18 18:31:07 --> Language Class Initialized
INFO - 2016-10-18 18:31:07 --> Loader Class Initialized
INFO - 2016-10-18 18:31:07 --> Helper loaded: url_helper
INFO - 2016-10-18 18:31:07 --> Helper loaded: form_helper
INFO - 2016-10-18 18:31:07 --> Database Driver Class Initialized
INFO - 2016-10-18 18:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:31:07 --> Controller Class Initialized
INFO - 2016-10-18 18:31:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:31:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:31:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:31:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:31:07 --> Final output sent to browser
DEBUG - 2016-10-18 18:31:07 --> Total execution time: 0.0077
INFO - 2016-10-18 18:31:09 --> Config Class Initialized
INFO - 2016-10-18 18:31:09 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:31:09 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:31:09 --> Utf8 Class Initialized
INFO - 2016-10-18 18:31:09 --> URI Class Initialized
INFO - 2016-10-18 18:31:09 --> Router Class Initialized
INFO - 2016-10-18 18:31:09 --> Output Class Initialized
INFO - 2016-10-18 18:31:09 --> Security Class Initialized
DEBUG - 2016-10-18 18:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:31:09 --> Input Class Initialized
INFO - 2016-10-18 18:31:09 --> Language Class Initialized
INFO - 2016-10-18 18:31:09 --> Loader Class Initialized
INFO - 2016-10-18 18:31:09 --> Helper loaded: url_helper
INFO - 2016-10-18 18:31:09 --> Helper loaded: form_helper
INFO - 2016-10-18 18:31:09 --> Database Driver Class Initialized
INFO - 2016-10-18 18:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:31:09 --> Controller Class Initialized
INFO - 2016-10-18 18:31:09 --> Form Validation Class Initialized
INFO - 2016-10-18 18:31:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:31:09 --> Final output sent to browser
DEBUG - 2016-10-18 18:31:09 --> Total execution time: 0.0061
INFO - 2016-10-18 18:31:19 --> Config Class Initialized
INFO - 2016-10-18 18:31:19 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:31:19 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:31:19 --> Utf8 Class Initialized
INFO - 2016-10-18 18:31:19 --> URI Class Initialized
DEBUG - 2016-10-18 18:31:19 --> No URI present. Default controller set.
INFO - 2016-10-18 18:31:19 --> Router Class Initialized
INFO - 2016-10-18 18:31:19 --> Output Class Initialized
INFO - 2016-10-18 18:31:19 --> Security Class Initialized
DEBUG - 2016-10-18 18:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:31:19 --> Input Class Initialized
INFO - 2016-10-18 18:31:19 --> Language Class Initialized
INFO - 2016-10-18 18:31:19 --> Loader Class Initialized
INFO - 2016-10-18 18:31:19 --> Helper loaded: url_helper
INFO - 2016-10-18 18:31:19 --> Helper loaded: form_helper
INFO - 2016-10-18 18:31:19 --> Database Driver Class Initialized
INFO - 2016-10-18 18:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:31:19 --> Controller Class Initialized
INFO - 2016-10-18 18:31:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:31:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:31:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:31:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:31:19 --> Final output sent to browser
DEBUG - 2016-10-18 18:31:19 --> Total execution time: 0.0048
INFO - 2016-10-18 18:31:21 --> Config Class Initialized
INFO - 2016-10-18 18:31:21 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:31:21 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:31:21 --> Utf8 Class Initialized
INFO - 2016-10-18 18:31:21 --> URI Class Initialized
INFO - 2016-10-18 18:31:21 --> Router Class Initialized
INFO - 2016-10-18 18:31:21 --> Output Class Initialized
INFO - 2016-10-18 18:31:21 --> Security Class Initialized
DEBUG - 2016-10-18 18:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:31:21 --> Input Class Initialized
INFO - 2016-10-18 18:31:21 --> Language Class Initialized
INFO - 2016-10-18 18:31:21 --> Loader Class Initialized
INFO - 2016-10-18 18:31:21 --> Helper loaded: url_helper
INFO - 2016-10-18 18:31:21 --> Helper loaded: form_helper
INFO - 2016-10-18 18:31:21 --> Database Driver Class Initialized
INFO - 2016-10-18 18:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:31:21 --> Controller Class Initialized
INFO - 2016-10-18 18:31:21 --> Form Validation Class Initialized
INFO - 2016-10-18 18:31:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:31:21 --> Final output sent to browser
DEBUG - 2016-10-18 18:31:21 --> Total execution time: 0.0093
INFO - 2016-10-18 18:31:59 --> Config Class Initialized
INFO - 2016-10-18 18:31:59 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:31:59 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:31:59 --> Utf8 Class Initialized
INFO - 2016-10-18 18:31:59 --> URI Class Initialized
DEBUG - 2016-10-18 18:31:59 --> No URI present. Default controller set.
INFO - 2016-10-18 18:31:59 --> Router Class Initialized
INFO - 2016-10-18 18:31:59 --> Output Class Initialized
INFO - 2016-10-18 18:31:59 --> Security Class Initialized
DEBUG - 2016-10-18 18:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:31:59 --> Input Class Initialized
INFO - 2016-10-18 18:31:59 --> Language Class Initialized
INFO - 2016-10-18 18:31:59 --> Loader Class Initialized
INFO - 2016-10-18 18:31:59 --> Helper loaded: url_helper
INFO - 2016-10-18 18:31:59 --> Helper loaded: form_helper
INFO - 2016-10-18 18:31:59 --> Database Driver Class Initialized
INFO - 2016-10-18 18:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:31:59 --> Controller Class Initialized
INFO - 2016-10-18 18:31:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:31:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:31:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:31:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:31:59 --> Final output sent to browser
DEBUG - 2016-10-18 18:31:59 --> Total execution time: 0.0052
INFO - 2016-10-18 18:32:03 --> Config Class Initialized
INFO - 2016-10-18 18:32:03 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:32:03 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:32:03 --> Utf8 Class Initialized
INFO - 2016-10-18 18:32:03 --> URI Class Initialized
INFO - 2016-10-18 18:32:03 --> Router Class Initialized
INFO - 2016-10-18 18:32:03 --> Output Class Initialized
INFO - 2016-10-18 18:32:03 --> Security Class Initialized
DEBUG - 2016-10-18 18:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:32:03 --> Input Class Initialized
INFO - 2016-10-18 18:32:03 --> Language Class Initialized
INFO - 2016-10-18 18:32:03 --> Loader Class Initialized
INFO - 2016-10-18 18:32:03 --> Helper loaded: url_helper
INFO - 2016-10-18 18:32:03 --> Helper loaded: form_helper
INFO - 2016-10-18 18:32:03 --> Database Driver Class Initialized
INFO - 2016-10-18 18:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:32:03 --> Controller Class Initialized
INFO - 2016-10-18 18:32:03 --> Form Validation Class Initialized
INFO - 2016-10-18 18:32:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:32:03 --> Final output sent to browser
DEBUG - 2016-10-18 18:32:03 --> Total execution time: 0.0062
INFO - 2016-10-18 18:32:34 --> Config Class Initialized
INFO - 2016-10-18 18:32:34 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:32:34 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:32:34 --> Utf8 Class Initialized
INFO - 2016-10-18 18:32:34 --> URI Class Initialized
DEBUG - 2016-10-18 18:32:34 --> No URI present. Default controller set.
INFO - 2016-10-18 18:32:34 --> Router Class Initialized
INFO - 2016-10-18 18:32:34 --> Output Class Initialized
INFO - 2016-10-18 18:32:34 --> Security Class Initialized
DEBUG - 2016-10-18 18:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:32:34 --> Input Class Initialized
INFO - 2016-10-18 18:32:34 --> Language Class Initialized
INFO - 2016-10-18 18:32:34 --> Loader Class Initialized
INFO - 2016-10-18 18:32:34 --> Helper loaded: url_helper
INFO - 2016-10-18 18:32:34 --> Helper loaded: form_helper
INFO - 2016-10-18 18:32:34 --> Database Driver Class Initialized
INFO - 2016-10-18 18:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:32:34 --> Controller Class Initialized
INFO - 2016-10-18 18:32:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:32:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:32:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:32:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:32:34 --> Final output sent to browser
DEBUG - 2016-10-18 18:32:34 --> Total execution time: 0.0050
INFO - 2016-10-18 18:32:37 --> Config Class Initialized
INFO - 2016-10-18 18:32:37 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:32:37 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:32:37 --> Utf8 Class Initialized
INFO - 2016-10-18 18:32:37 --> URI Class Initialized
INFO - 2016-10-18 18:32:37 --> Router Class Initialized
INFO - 2016-10-18 18:32:37 --> Output Class Initialized
INFO - 2016-10-18 18:32:37 --> Security Class Initialized
DEBUG - 2016-10-18 18:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:32:37 --> Input Class Initialized
INFO - 2016-10-18 18:32:37 --> Language Class Initialized
INFO - 2016-10-18 18:32:37 --> Loader Class Initialized
INFO - 2016-10-18 18:32:37 --> Helper loaded: url_helper
INFO - 2016-10-18 18:32:37 --> Helper loaded: form_helper
INFO - 2016-10-18 18:32:37 --> Database Driver Class Initialized
INFO - 2016-10-18 18:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:32:37 --> Controller Class Initialized
INFO - 2016-10-18 18:32:37 --> Form Validation Class Initialized
INFO - 2016-10-18 18:32:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:32:37 --> Final output sent to browser
DEBUG - 2016-10-18 18:32:37 --> Total execution time: 0.0069
INFO - 2016-10-18 18:32:58 --> Config Class Initialized
INFO - 2016-10-18 18:32:58 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:32:58 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:32:58 --> Utf8 Class Initialized
INFO - 2016-10-18 18:32:58 --> URI Class Initialized
DEBUG - 2016-10-18 18:32:58 --> No URI present. Default controller set.
INFO - 2016-10-18 18:32:58 --> Router Class Initialized
INFO - 2016-10-18 18:32:58 --> Output Class Initialized
INFO - 2016-10-18 18:32:58 --> Security Class Initialized
DEBUG - 2016-10-18 18:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:32:58 --> Input Class Initialized
INFO - 2016-10-18 18:32:58 --> Language Class Initialized
INFO - 2016-10-18 18:32:58 --> Loader Class Initialized
INFO - 2016-10-18 18:32:58 --> Helper loaded: url_helper
INFO - 2016-10-18 18:32:58 --> Helper loaded: form_helper
INFO - 2016-10-18 18:32:58 --> Database Driver Class Initialized
INFO - 2016-10-18 18:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:32:58 --> Controller Class Initialized
INFO - 2016-10-18 18:32:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:32:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:32:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:32:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:32:58 --> Final output sent to browser
DEBUG - 2016-10-18 18:32:58 --> Total execution time: 0.0048
INFO - 2016-10-18 18:33:00 --> Config Class Initialized
INFO - 2016-10-18 18:33:00 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:33:00 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:33:00 --> Utf8 Class Initialized
INFO - 2016-10-18 18:33:00 --> URI Class Initialized
INFO - 2016-10-18 18:33:00 --> Router Class Initialized
INFO - 2016-10-18 18:33:00 --> Output Class Initialized
INFO - 2016-10-18 18:33:00 --> Security Class Initialized
DEBUG - 2016-10-18 18:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:33:00 --> Input Class Initialized
INFO - 2016-10-18 18:33:00 --> Language Class Initialized
INFO - 2016-10-18 18:33:00 --> Loader Class Initialized
INFO - 2016-10-18 18:33:00 --> Helper loaded: url_helper
INFO - 2016-10-18 18:33:00 --> Helper loaded: form_helper
INFO - 2016-10-18 18:33:00 --> Database Driver Class Initialized
INFO - 2016-10-18 18:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:33:00 --> Controller Class Initialized
INFO - 2016-10-18 18:33:00 --> Form Validation Class Initialized
INFO - 2016-10-18 18:33:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:33:00 --> Final output sent to browser
DEBUG - 2016-10-18 18:33:00 --> Total execution time: 0.0059
INFO - 2016-10-18 18:33:13 --> Config Class Initialized
INFO - 2016-10-18 18:33:13 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:33:13 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:33:13 --> Utf8 Class Initialized
INFO - 2016-10-18 18:33:13 --> URI Class Initialized
DEBUG - 2016-10-18 18:33:13 --> No URI present. Default controller set.
INFO - 2016-10-18 18:33:13 --> Router Class Initialized
INFO - 2016-10-18 18:33:13 --> Output Class Initialized
INFO - 2016-10-18 18:33:13 --> Security Class Initialized
DEBUG - 2016-10-18 18:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:33:13 --> Input Class Initialized
INFO - 2016-10-18 18:33:13 --> Language Class Initialized
INFO - 2016-10-18 18:33:13 --> Loader Class Initialized
INFO - 2016-10-18 18:33:13 --> Helper loaded: url_helper
INFO - 2016-10-18 18:33:13 --> Helper loaded: form_helper
INFO - 2016-10-18 18:33:13 --> Database Driver Class Initialized
INFO - 2016-10-18 18:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:33:13 --> Controller Class Initialized
INFO - 2016-10-18 18:33:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:33:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:33:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:33:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:33:13 --> Final output sent to browser
DEBUG - 2016-10-18 18:33:13 --> Total execution time: 0.0081
INFO - 2016-10-18 18:33:15 --> Config Class Initialized
INFO - 2016-10-18 18:33:15 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:33:15 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:33:15 --> Utf8 Class Initialized
INFO - 2016-10-18 18:33:15 --> URI Class Initialized
INFO - 2016-10-18 18:33:15 --> Router Class Initialized
INFO - 2016-10-18 18:33:15 --> Output Class Initialized
INFO - 2016-10-18 18:33:15 --> Security Class Initialized
DEBUG - 2016-10-18 18:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:33:15 --> Input Class Initialized
INFO - 2016-10-18 18:33:15 --> Language Class Initialized
INFO - 2016-10-18 18:33:15 --> Loader Class Initialized
INFO - 2016-10-18 18:33:15 --> Helper loaded: url_helper
INFO - 2016-10-18 18:33:15 --> Helper loaded: form_helper
INFO - 2016-10-18 18:33:15 --> Database Driver Class Initialized
INFO - 2016-10-18 18:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:33:15 --> Controller Class Initialized
INFO - 2016-10-18 18:33:15 --> Form Validation Class Initialized
INFO - 2016-10-18 18:33:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:33:15 --> Final output sent to browser
DEBUG - 2016-10-18 18:33:15 --> Total execution time: 0.0058
INFO - 2016-10-18 18:33:24 --> Config Class Initialized
INFO - 2016-10-18 18:33:24 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:33:24 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:33:24 --> Utf8 Class Initialized
INFO - 2016-10-18 18:33:24 --> URI Class Initialized
DEBUG - 2016-10-18 18:33:24 --> No URI present. Default controller set.
INFO - 2016-10-18 18:33:24 --> Router Class Initialized
INFO - 2016-10-18 18:33:24 --> Output Class Initialized
INFO - 2016-10-18 18:33:24 --> Security Class Initialized
DEBUG - 2016-10-18 18:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:33:24 --> Input Class Initialized
INFO - 2016-10-18 18:33:24 --> Language Class Initialized
INFO - 2016-10-18 18:33:24 --> Loader Class Initialized
INFO - 2016-10-18 18:33:24 --> Helper loaded: url_helper
INFO - 2016-10-18 18:33:24 --> Helper loaded: form_helper
INFO - 2016-10-18 18:33:24 --> Database Driver Class Initialized
INFO - 2016-10-18 18:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:33:24 --> Controller Class Initialized
INFO - 2016-10-18 18:33:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:33:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:33:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:33:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:33:24 --> Final output sent to browser
DEBUG - 2016-10-18 18:33:24 --> Total execution time: 0.0077
INFO - 2016-10-18 18:34:16 --> Config Class Initialized
INFO - 2016-10-18 18:34:16 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:34:16 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:34:16 --> Utf8 Class Initialized
INFO - 2016-10-18 18:34:16 --> URI Class Initialized
DEBUG - 2016-10-18 18:34:16 --> No URI present. Default controller set.
INFO - 2016-10-18 18:34:16 --> Router Class Initialized
INFO - 2016-10-18 18:34:16 --> Output Class Initialized
INFO - 2016-10-18 18:34:16 --> Security Class Initialized
DEBUG - 2016-10-18 18:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:34:16 --> Input Class Initialized
INFO - 2016-10-18 18:34:16 --> Language Class Initialized
INFO - 2016-10-18 18:34:16 --> Loader Class Initialized
INFO - 2016-10-18 18:34:16 --> Helper loaded: url_helper
INFO - 2016-10-18 18:34:16 --> Helper loaded: form_helper
INFO - 2016-10-18 18:34:16 --> Database Driver Class Initialized
INFO - 2016-10-18 18:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:34:16 --> Controller Class Initialized
INFO - 2016-10-18 18:34:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:34:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:34:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:34:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:34:16 --> Final output sent to browser
DEBUG - 2016-10-18 18:34:16 --> Total execution time: 0.0054
INFO - 2016-10-18 18:34:19 --> Config Class Initialized
INFO - 2016-10-18 18:34:19 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:34:19 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:34:19 --> Utf8 Class Initialized
INFO - 2016-10-18 18:34:19 --> URI Class Initialized
INFO - 2016-10-18 18:34:19 --> Router Class Initialized
INFO - 2016-10-18 18:34:19 --> Output Class Initialized
INFO - 2016-10-18 18:34:19 --> Security Class Initialized
DEBUG - 2016-10-18 18:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:34:19 --> Input Class Initialized
INFO - 2016-10-18 18:34:19 --> Language Class Initialized
INFO - 2016-10-18 18:34:19 --> Loader Class Initialized
INFO - 2016-10-18 18:34:19 --> Helper loaded: url_helper
INFO - 2016-10-18 18:34:19 --> Helper loaded: form_helper
INFO - 2016-10-18 18:34:19 --> Database Driver Class Initialized
INFO - 2016-10-18 18:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:34:19 --> Controller Class Initialized
INFO - 2016-10-18 18:34:19 --> Form Validation Class Initialized
INFO - 2016-10-18 18:34:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:34:19 --> Final output sent to browser
DEBUG - 2016-10-18 18:34:19 --> Total execution time: 0.0095
INFO - 2016-10-18 18:35:05 --> Config Class Initialized
INFO - 2016-10-18 18:35:05 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:35:05 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:35:05 --> Utf8 Class Initialized
INFO - 2016-10-18 18:35:05 --> URI Class Initialized
DEBUG - 2016-10-18 18:35:05 --> No URI present. Default controller set.
INFO - 2016-10-18 18:35:05 --> Router Class Initialized
INFO - 2016-10-18 18:35:05 --> Output Class Initialized
INFO - 2016-10-18 18:35:05 --> Security Class Initialized
DEBUG - 2016-10-18 18:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:35:05 --> Input Class Initialized
INFO - 2016-10-18 18:35:05 --> Language Class Initialized
INFO - 2016-10-18 18:35:05 --> Loader Class Initialized
INFO - 2016-10-18 18:35:05 --> Helper loaded: url_helper
INFO - 2016-10-18 18:35:05 --> Helper loaded: form_helper
INFO - 2016-10-18 18:35:05 --> Database Driver Class Initialized
INFO - 2016-10-18 18:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:35:05 --> Controller Class Initialized
INFO - 2016-10-18 18:35:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:35:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:35:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:35:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:35:05 --> Final output sent to browser
DEBUG - 2016-10-18 18:35:05 --> Total execution time: 0.0084
INFO - 2016-10-18 18:35:07 --> Config Class Initialized
INFO - 2016-10-18 18:35:07 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:35:07 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:35:07 --> Utf8 Class Initialized
INFO - 2016-10-18 18:35:07 --> URI Class Initialized
INFO - 2016-10-18 18:35:07 --> Router Class Initialized
INFO - 2016-10-18 18:35:07 --> Output Class Initialized
INFO - 2016-10-18 18:35:07 --> Security Class Initialized
DEBUG - 2016-10-18 18:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:35:07 --> Input Class Initialized
INFO - 2016-10-18 18:35:07 --> Language Class Initialized
INFO - 2016-10-18 18:35:07 --> Loader Class Initialized
INFO - 2016-10-18 18:35:07 --> Helper loaded: url_helper
INFO - 2016-10-18 18:35:07 --> Helper loaded: form_helper
INFO - 2016-10-18 18:35:07 --> Database Driver Class Initialized
INFO - 2016-10-18 18:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:35:07 --> Controller Class Initialized
INFO - 2016-10-18 18:35:07 --> Form Validation Class Initialized
INFO - 2016-10-18 18:35:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:35:07 --> Final output sent to browser
DEBUG - 2016-10-18 18:35:07 --> Total execution time: 0.0081
INFO - 2016-10-18 18:35:12 --> Config Class Initialized
INFO - 2016-10-18 18:35:12 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:35:12 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:35:12 --> Utf8 Class Initialized
INFO - 2016-10-18 18:35:12 --> URI Class Initialized
INFO - 2016-10-18 18:35:12 --> Router Class Initialized
INFO - 2016-10-18 18:35:12 --> Output Class Initialized
INFO - 2016-10-18 18:35:12 --> Security Class Initialized
DEBUG - 2016-10-18 18:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:35:12 --> Input Class Initialized
INFO - 2016-10-18 18:35:12 --> Language Class Initialized
INFO - 2016-10-18 18:35:12 --> Loader Class Initialized
INFO - 2016-10-18 18:35:12 --> Helper loaded: url_helper
INFO - 2016-10-18 18:35:12 --> Helper loaded: form_helper
INFO - 2016-10-18 18:35:12 --> Database Driver Class Initialized
INFO - 2016-10-18 18:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:35:12 --> Controller Class Initialized
INFO - 2016-10-18 18:35:12 --> Form Validation Class Initialized
INFO - 2016-10-18 18:35:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:35:12 --> Final output sent to browser
DEBUG - 2016-10-18 18:35:12 --> Total execution time: 0.0060
INFO - 2016-10-18 18:35:22 --> Config Class Initialized
INFO - 2016-10-18 18:35:22 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:35:22 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:35:22 --> Utf8 Class Initialized
INFO - 2016-10-18 18:35:22 --> URI Class Initialized
INFO - 2016-10-18 18:35:22 --> Router Class Initialized
INFO - 2016-10-18 18:35:22 --> Output Class Initialized
INFO - 2016-10-18 18:35:22 --> Security Class Initialized
DEBUG - 2016-10-18 18:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:35:22 --> Input Class Initialized
INFO - 2016-10-18 18:35:22 --> Language Class Initialized
INFO - 2016-10-18 18:35:22 --> Loader Class Initialized
INFO - 2016-10-18 18:35:22 --> Helper loaded: url_helper
INFO - 2016-10-18 18:35:22 --> Helper loaded: form_helper
INFO - 2016-10-18 18:35:22 --> Database Driver Class Initialized
INFO - 2016-10-18 18:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:35:22 --> Controller Class Initialized
INFO - 2016-10-18 18:35:22 --> Form Validation Class Initialized
INFO - 2016-10-18 18:35:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:35:22 --> Final output sent to browser
DEBUG - 2016-10-18 18:35:22 --> Total execution time: 0.0063
INFO - 2016-10-18 18:36:48 --> Config Class Initialized
INFO - 2016-10-18 18:36:48 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:36:48 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:36:48 --> Utf8 Class Initialized
INFO - 2016-10-18 18:36:48 --> URI Class Initialized
DEBUG - 2016-10-18 18:36:48 --> No URI present. Default controller set.
INFO - 2016-10-18 18:36:48 --> Router Class Initialized
INFO - 2016-10-18 18:36:48 --> Output Class Initialized
INFO - 2016-10-18 18:36:48 --> Security Class Initialized
DEBUG - 2016-10-18 18:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:36:48 --> Input Class Initialized
INFO - 2016-10-18 18:36:48 --> Language Class Initialized
INFO - 2016-10-18 18:36:48 --> Loader Class Initialized
INFO - 2016-10-18 18:36:48 --> Helper loaded: url_helper
INFO - 2016-10-18 18:36:48 --> Helper loaded: form_helper
INFO - 2016-10-18 18:36:48 --> Database Driver Class Initialized
INFO - 2016-10-18 18:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:36:48 --> Controller Class Initialized
INFO - 2016-10-18 18:36:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:36:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:36:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:36:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:36:48 --> Final output sent to browser
DEBUG - 2016-10-18 18:36:48 --> Total execution time: 0.0090
INFO - 2016-10-18 18:36:55 --> Config Class Initialized
INFO - 2016-10-18 18:36:55 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:36:55 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:36:55 --> Utf8 Class Initialized
INFO - 2016-10-18 18:36:55 --> URI Class Initialized
INFO - 2016-10-18 18:36:55 --> Router Class Initialized
INFO - 2016-10-18 18:36:55 --> Output Class Initialized
INFO - 2016-10-18 18:36:55 --> Security Class Initialized
DEBUG - 2016-10-18 18:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:36:55 --> Input Class Initialized
INFO - 2016-10-18 18:36:55 --> Language Class Initialized
INFO - 2016-10-18 18:36:55 --> Loader Class Initialized
INFO - 2016-10-18 18:36:55 --> Helper loaded: url_helper
INFO - 2016-10-18 18:36:55 --> Helper loaded: form_helper
INFO - 2016-10-18 18:36:55 --> Database Driver Class Initialized
INFO - 2016-10-18 18:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:36:55 --> Controller Class Initialized
INFO - 2016-10-18 18:36:55 --> Form Validation Class Initialized
INFO - 2016-10-18 18:36:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:36:55 --> Final output sent to browser
DEBUG - 2016-10-18 18:36:55 --> Total execution time: 0.0062
INFO - 2016-10-18 18:36:58 --> Config Class Initialized
INFO - 2016-10-18 18:36:58 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:36:58 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:36:58 --> Utf8 Class Initialized
INFO - 2016-10-18 18:36:58 --> URI Class Initialized
DEBUG - 2016-10-18 18:36:58 --> No URI present. Default controller set.
INFO - 2016-10-18 18:36:58 --> Router Class Initialized
INFO - 2016-10-18 18:36:58 --> Output Class Initialized
INFO - 2016-10-18 18:36:58 --> Security Class Initialized
DEBUG - 2016-10-18 18:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:36:58 --> Input Class Initialized
INFO - 2016-10-18 18:36:58 --> Language Class Initialized
INFO - 2016-10-18 18:36:58 --> Loader Class Initialized
INFO - 2016-10-18 18:36:58 --> Helper loaded: url_helper
INFO - 2016-10-18 18:36:58 --> Helper loaded: form_helper
INFO - 2016-10-18 18:36:58 --> Database Driver Class Initialized
INFO - 2016-10-18 18:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:36:58 --> Controller Class Initialized
INFO - 2016-10-18 18:36:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:36:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:36:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:36:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:36:58 --> Final output sent to browser
DEBUG - 2016-10-18 18:36:58 --> Total execution time: 0.0051
INFO - 2016-10-18 18:37:11 --> Config Class Initialized
INFO - 2016-10-18 18:37:11 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:37:11 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:37:11 --> Utf8 Class Initialized
INFO - 2016-10-18 18:37:11 --> URI Class Initialized
DEBUG - 2016-10-18 18:37:11 --> No URI present. Default controller set.
INFO - 2016-10-18 18:37:11 --> Router Class Initialized
INFO - 2016-10-18 18:37:11 --> Output Class Initialized
INFO - 2016-10-18 18:37:11 --> Security Class Initialized
DEBUG - 2016-10-18 18:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:37:11 --> Input Class Initialized
INFO - 2016-10-18 18:37:11 --> Language Class Initialized
INFO - 2016-10-18 18:37:11 --> Loader Class Initialized
INFO - 2016-10-18 18:37:11 --> Helper loaded: url_helper
INFO - 2016-10-18 18:37:11 --> Helper loaded: form_helper
INFO - 2016-10-18 18:37:11 --> Database Driver Class Initialized
INFO - 2016-10-18 18:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:37:11 --> Controller Class Initialized
INFO - 2016-10-18 18:37:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:37:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:37:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:37:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:37:11 --> Final output sent to browser
DEBUG - 2016-10-18 18:37:11 --> Total execution time: 0.0079
INFO - 2016-10-18 18:37:14 --> Config Class Initialized
INFO - 2016-10-18 18:37:14 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:37:14 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:37:14 --> Utf8 Class Initialized
INFO - 2016-10-18 18:37:14 --> URI Class Initialized
INFO - 2016-10-18 18:37:14 --> Router Class Initialized
INFO - 2016-10-18 18:37:14 --> Output Class Initialized
INFO - 2016-10-18 18:37:14 --> Security Class Initialized
DEBUG - 2016-10-18 18:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:37:14 --> Input Class Initialized
INFO - 2016-10-18 18:37:14 --> Language Class Initialized
INFO - 2016-10-18 18:37:14 --> Loader Class Initialized
INFO - 2016-10-18 18:37:14 --> Helper loaded: url_helper
INFO - 2016-10-18 18:37:14 --> Helper loaded: form_helper
INFO - 2016-10-18 18:37:14 --> Database Driver Class Initialized
INFO - 2016-10-18 18:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:37:14 --> Controller Class Initialized
INFO - 2016-10-18 18:37:14 --> Form Validation Class Initialized
INFO - 2016-10-18 18:37:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-18 18:37:14 --> Final output sent to browser
DEBUG - 2016-10-18 18:37:14 --> Total execution time: 0.0063
INFO - 2016-10-18 18:37:40 --> Config Class Initialized
INFO - 2016-10-18 18:37:40 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:37:40 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:37:40 --> Utf8 Class Initialized
INFO - 2016-10-18 18:37:40 --> URI Class Initialized
INFO - 2016-10-18 18:37:40 --> Router Class Initialized
INFO - 2016-10-18 18:37:40 --> Output Class Initialized
INFO - 2016-10-18 18:37:40 --> Security Class Initialized
DEBUG - 2016-10-18 18:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:37:40 --> Input Class Initialized
INFO - 2016-10-18 18:37:40 --> Language Class Initialized
INFO - 2016-10-18 18:37:40 --> Loader Class Initialized
INFO - 2016-10-18 18:37:40 --> Helper loaded: url_helper
INFO - 2016-10-18 18:37:40 --> Helper loaded: form_helper
INFO - 2016-10-18 18:37:40 --> Database Driver Class Initialized
INFO - 2016-10-18 18:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:37:40 --> Controller Class Initialized
ERROR - 2016-10-18 18:37:40 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 121
ERROR - 2016-10-18 18:37:40 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 121
INFO - 2016-10-18 18:37:40 --> Config Class Initialized
INFO - 2016-10-18 18:37:40 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:37:40 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:37:40 --> Utf8 Class Initialized
INFO - 2016-10-18 18:37:40 --> URI Class Initialized
DEBUG - 2016-10-18 18:37:40 --> No URI present. Default controller set.
INFO - 2016-10-18 18:37:40 --> Router Class Initialized
INFO - 2016-10-18 18:37:40 --> Output Class Initialized
INFO - 2016-10-18 18:37:40 --> Security Class Initialized
DEBUG - 2016-10-18 18:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:37:40 --> Input Class Initialized
INFO - 2016-10-18 18:37:40 --> Language Class Initialized
INFO - 2016-10-18 18:37:40 --> Loader Class Initialized
INFO - 2016-10-18 18:37:40 --> Helper loaded: url_helper
INFO - 2016-10-18 18:37:40 --> Helper loaded: form_helper
INFO - 2016-10-18 18:37:40 --> Database Driver Class Initialized
INFO - 2016-10-18 18:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:37:40 --> Controller Class Initialized
INFO - 2016-10-18 18:37:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:37:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 18:37:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:37:40 --> Final output sent to browser
DEBUG - 2016-10-18 18:37:40 --> Total execution time: 0.0048
INFO - 2016-10-18 18:37:59 --> Config Class Initialized
INFO - 2016-10-18 18:37:59 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:37:59 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:37:59 --> Utf8 Class Initialized
INFO - 2016-10-18 18:37:59 --> URI Class Initialized
INFO - 2016-10-18 18:37:59 --> Router Class Initialized
INFO - 2016-10-18 18:37:59 --> Output Class Initialized
INFO - 2016-10-18 18:37:59 --> Security Class Initialized
DEBUG - 2016-10-18 18:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:37:59 --> Input Class Initialized
INFO - 2016-10-18 18:37:59 --> Language Class Initialized
INFO - 2016-10-18 18:37:59 --> Loader Class Initialized
INFO - 2016-10-18 18:37:59 --> Helper loaded: url_helper
INFO - 2016-10-18 18:37:59 --> Helper loaded: form_helper
INFO - 2016-10-18 18:37:59 --> Database Driver Class Initialized
INFO - 2016-10-18 18:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:37:59 --> Controller Class Initialized
INFO - 2016-10-18 18:37:59 --> Model Class Initialized
INFO - 2016-10-18 18:37:59 --> Final output sent to browser
DEBUG - 2016-10-18 18:37:59 --> Total execution time: 0.0066
INFO - 2016-10-18 18:38:03 --> Config Class Initialized
INFO - 2016-10-18 18:38:03 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:38:03 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:38:03 --> Utf8 Class Initialized
INFO - 2016-10-18 18:38:03 --> URI Class Initialized
INFO - 2016-10-18 18:38:03 --> Router Class Initialized
INFO - 2016-10-18 18:38:03 --> Output Class Initialized
INFO - 2016-10-18 18:38:03 --> Security Class Initialized
DEBUG - 2016-10-18 18:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:38:03 --> Input Class Initialized
INFO - 2016-10-18 18:38:03 --> Language Class Initialized
INFO - 2016-10-18 18:38:03 --> Loader Class Initialized
INFO - 2016-10-18 18:38:03 --> Helper loaded: url_helper
INFO - 2016-10-18 18:38:03 --> Helper loaded: form_helper
INFO - 2016-10-18 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-18 18:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:38:03 --> Controller Class Initialized
INFO - 2016-10-18 18:38:03 --> Model Class Initialized
INFO - 2016-10-18 18:38:03 --> Final output sent to browser
DEBUG - 2016-10-18 18:38:03 --> Total execution time: 0.0056
INFO - 2016-10-18 18:38:03 --> Config Class Initialized
INFO - 2016-10-18 18:38:03 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:38:03 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:38:03 --> Utf8 Class Initialized
INFO - 2016-10-18 18:38:03 --> URI Class Initialized
DEBUG - 2016-10-18 18:38:03 --> No URI present. Default controller set.
INFO - 2016-10-18 18:38:03 --> Router Class Initialized
INFO - 2016-10-18 18:38:03 --> Output Class Initialized
INFO - 2016-10-18 18:38:03 --> Security Class Initialized
DEBUG - 2016-10-18 18:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:38:03 --> Input Class Initialized
INFO - 2016-10-18 18:38:03 --> Language Class Initialized
INFO - 2016-10-18 18:38:03 --> Loader Class Initialized
INFO - 2016-10-18 18:38:03 --> Helper loaded: url_helper
INFO - 2016-10-18 18:38:03 --> Helper loaded: form_helper
INFO - 2016-10-18 18:38:03 --> Database Driver Class Initialized
INFO - 2016-10-18 18:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:38:03 --> Controller Class Initialized
INFO - 2016-10-18 18:38:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:38:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-18 18:38:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-18 18:38:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:38:03 --> Final output sent to browser
DEBUG - 2016-10-18 18:38:03 --> Total execution time: 0.0045
INFO - 2016-10-18 18:38:08 --> Config Class Initialized
INFO - 2016-10-18 18:38:08 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:38:08 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:38:08 --> Utf8 Class Initialized
INFO - 2016-10-18 18:38:08 --> URI Class Initialized
INFO - 2016-10-18 18:38:08 --> Router Class Initialized
INFO - 2016-10-18 18:38:08 --> Output Class Initialized
INFO - 2016-10-18 18:38:08 --> Security Class Initialized
DEBUG - 2016-10-18 18:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:38:08 --> Input Class Initialized
INFO - 2016-10-18 18:38:08 --> Language Class Initialized
INFO - 2016-10-18 18:38:08 --> Loader Class Initialized
INFO - 2016-10-18 18:38:08 --> Helper loaded: url_helper
INFO - 2016-10-18 18:38:08 --> Helper loaded: form_helper
INFO - 2016-10-18 18:38:08 --> Database Driver Class Initialized
INFO - 2016-10-18 18:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:38:08 --> Controller Class Initialized
ERROR - 2016-10-18 18:38:08 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 121
ERROR - 2016-10-18 18:38:08 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 121
INFO - 2016-10-18 18:38:08 --> Config Class Initialized
INFO - 2016-10-18 18:38:08 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:38:08 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:38:08 --> Utf8 Class Initialized
INFO - 2016-10-18 18:38:08 --> URI Class Initialized
DEBUG - 2016-10-18 18:38:08 --> No URI present. Default controller set.
INFO - 2016-10-18 18:38:08 --> Router Class Initialized
INFO - 2016-10-18 18:38:08 --> Output Class Initialized
INFO - 2016-10-18 18:38:08 --> Security Class Initialized
DEBUG - 2016-10-18 18:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:38:08 --> Input Class Initialized
INFO - 2016-10-18 18:38:08 --> Language Class Initialized
INFO - 2016-10-18 18:38:08 --> Loader Class Initialized
INFO - 2016-10-18 18:38:08 --> Helper loaded: url_helper
INFO - 2016-10-18 18:38:08 --> Helper loaded: form_helper
INFO - 2016-10-18 18:38:08 --> Database Driver Class Initialized
INFO - 2016-10-18 18:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:38:08 --> Controller Class Initialized
INFO - 2016-10-18 18:38:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-18 18:38:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-18 18:38:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-18 18:38:08 --> Final output sent to browser
DEBUG - 2016-10-18 18:38:08 --> Total execution time: 0.0042
