<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-26 00:00:21 --> Config Class Initialized
INFO - 2016-11-26 00:00:21 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:00:21 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:00:21 --> Utf8 Class Initialized
INFO - 2016-11-26 00:00:21 --> URI Class Initialized
DEBUG - 2016-11-26 00:00:21 --> No URI present. Default controller set.
INFO - 2016-11-26 00:00:21 --> Router Class Initialized
INFO - 2016-11-26 00:00:21 --> Output Class Initialized
INFO - 2016-11-26 00:00:21 --> Security Class Initialized
DEBUG - 2016-11-26 00:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:00:21 --> Input Class Initialized
INFO - 2016-11-26 00:00:21 --> Language Class Initialized
INFO - 2016-11-26 00:00:21 --> Loader Class Initialized
INFO - 2016-11-26 00:00:21 --> Helper loaded: url_helper
INFO - 2016-11-26 00:00:21 --> Helper loaded: form_helper
INFO - 2016-11-26 00:00:21 --> Database Driver Class Initialized
INFO - 2016-11-26 00:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:00:21 --> Controller Class Initialized
INFO - 2016-11-26 00:00:21 --> Model Class Initialized
INFO - 2016-11-26 00:00:21 --> Model Class Initialized
INFO - 2016-11-26 00:00:21 --> Model Class Initialized
INFO - 2016-11-26 00:00:21 --> Model Class Initialized
INFO - 2016-11-26 00:00:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:00:21 --> Pagination Class Initialized
INFO - 2016-11-26 00:00:21 --> Helper loaded: app_helper
INFO - 2016-11-26 00:00:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 00:00:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 00:00:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 00:00:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 00:00:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 00:00:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 00:00:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 00:00:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 00:00:21 --> Final output sent to browser
DEBUG - 2016-11-26 00:00:21 --> Total execution time: 0.3568
INFO - 2016-11-26 00:00:33 --> Config Class Initialized
INFO - 2016-11-26 00:00:33 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:00:33 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:00:33 --> Utf8 Class Initialized
INFO - 2016-11-26 00:00:33 --> URI Class Initialized
INFO - 2016-11-26 00:00:33 --> Router Class Initialized
INFO - 2016-11-26 00:00:33 --> Output Class Initialized
INFO - 2016-11-26 00:00:33 --> Security Class Initialized
DEBUG - 2016-11-26 00:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:00:33 --> Input Class Initialized
INFO - 2016-11-26 00:00:33 --> Language Class Initialized
INFO - 2016-11-26 00:00:33 --> Loader Class Initialized
INFO - 2016-11-26 00:00:33 --> Helper loaded: url_helper
INFO - 2016-11-26 00:00:33 --> Helper loaded: form_helper
INFO - 2016-11-26 00:00:33 --> Database Driver Class Initialized
INFO - 2016-11-26 00:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:00:33 --> Controller Class Initialized
INFO - 2016-11-26 00:00:33 --> Model Class Initialized
INFO - 2016-11-26 00:00:33 --> Form Validation Class Initialized
INFO - 2016-11-26 00:00:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-26 00:00:33 --> Final output sent to browser
DEBUG - 2016-11-26 00:00:33 --> Total execution time: 0.1902
INFO - 2016-11-26 00:04:18 --> Config Class Initialized
INFO - 2016-11-26 00:04:18 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:04:18 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:04:18 --> Utf8 Class Initialized
INFO - 2016-11-26 00:04:18 --> URI Class Initialized
INFO - 2016-11-26 00:04:18 --> Router Class Initialized
INFO - 2016-11-26 00:04:18 --> Output Class Initialized
INFO - 2016-11-26 00:04:18 --> Security Class Initialized
DEBUG - 2016-11-26 00:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:04:18 --> Input Class Initialized
INFO - 2016-11-26 00:04:18 --> Language Class Initialized
INFO - 2016-11-26 00:04:18 --> Loader Class Initialized
INFO - 2016-11-26 00:04:18 --> Helper loaded: url_helper
INFO - 2016-11-26 00:04:18 --> Helper loaded: form_helper
INFO - 2016-11-26 00:04:18 --> Database Driver Class Initialized
INFO - 2016-11-26 00:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:04:18 --> Controller Class Initialized
INFO - 2016-11-26 00:04:18 --> Model Class Initialized
ERROR - 2016-11-26 00:04:18 --> Severity: Error --> Call to undefined function ajax_pagination() C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 106
INFO - 2016-11-26 00:04:27 --> Config Class Initialized
INFO - 2016-11-26 00:04:27 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:04:27 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:04:27 --> Utf8 Class Initialized
INFO - 2016-11-26 00:04:27 --> URI Class Initialized
DEBUG - 2016-11-26 00:04:27 --> No URI present. Default controller set.
INFO - 2016-11-26 00:04:27 --> Router Class Initialized
INFO - 2016-11-26 00:04:27 --> Output Class Initialized
INFO - 2016-11-26 00:04:27 --> Security Class Initialized
DEBUG - 2016-11-26 00:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:04:27 --> Input Class Initialized
INFO - 2016-11-26 00:04:27 --> Language Class Initialized
INFO - 2016-11-26 00:04:27 --> Loader Class Initialized
INFO - 2016-11-26 00:04:27 --> Helper loaded: url_helper
INFO - 2016-11-26 00:04:27 --> Helper loaded: form_helper
INFO - 2016-11-26 00:04:27 --> Database Driver Class Initialized
INFO - 2016-11-26 00:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:04:27 --> Controller Class Initialized
INFO - 2016-11-26 00:04:27 --> Model Class Initialized
INFO - 2016-11-26 00:04:27 --> Model Class Initialized
INFO - 2016-11-26 00:04:27 --> Model Class Initialized
INFO - 2016-11-26 00:04:27 --> Model Class Initialized
INFO - 2016-11-26 00:04:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:04:27 --> Pagination Class Initialized
INFO - 2016-11-26 00:04:27 --> Helper loaded: app_helper
INFO - 2016-11-26 00:04:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 00:04:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 00:04:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 00:04:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 00:04:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 00:04:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 00:04:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 00:04:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 00:04:27 --> Final output sent to browser
DEBUG - 2016-11-26 00:04:27 --> Total execution time: 0.3535
INFO - 2016-11-26 00:04:59 --> Config Class Initialized
INFO - 2016-11-26 00:04:59 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:04:59 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:04:59 --> Utf8 Class Initialized
INFO - 2016-11-26 00:04:59 --> URI Class Initialized
DEBUG - 2016-11-26 00:04:59 --> No URI present. Default controller set.
INFO - 2016-11-26 00:04:59 --> Router Class Initialized
INFO - 2016-11-26 00:04:59 --> Output Class Initialized
INFO - 2016-11-26 00:04:59 --> Security Class Initialized
DEBUG - 2016-11-26 00:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:04:59 --> Input Class Initialized
INFO - 2016-11-26 00:04:59 --> Language Class Initialized
INFO - 2016-11-26 00:04:59 --> Loader Class Initialized
INFO - 2016-11-26 00:04:59 --> Helper loaded: url_helper
INFO - 2016-11-26 00:04:59 --> Helper loaded: form_helper
INFO - 2016-11-26 00:04:59 --> Database Driver Class Initialized
INFO - 2016-11-26 00:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:04:59 --> Controller Class Initialized
INFO - 2016-11-26 00:04:59 --> Model Class Initialized
INFO - 2016-11-26 00:04:59 --> Model Class Initialized
INFO - 2016-11-26 00:04:59 --> Model Class Initialized
INFO - 2016-11-26 00:04:59 --> Model Class Initialized
INFO - 2016-11-26 00:04:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:04:59 --> Pagination Class Initialized
INFO - 2016-11-26 00:04:59 --> Helper loaded: app_helper
INFO - 2016-11-26 00:04:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 00:04:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 00:04:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 00:04:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 00:04:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 00:04:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 00:04:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 00:04:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 00:04:59 --> Final output sent to browser
DEBUG - 2016-11-26 00:04:59 --> Total execution time: 0.3627
INFO - 2016-11-26 00:07:12 --> Config Class Initialized
INFO - 2016-11-26 00:07:12 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:07:12 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:07:12 --> Utf8 Class Initialized
INFO - 2016-11-26 00:07:12 --> URI Class Initialized
INFO - 2016-11-26 00:07:12 --> Router Class Initialized
INFO - 2016-11-26 00:07:12 --> Output Class Initialized
INFO - 2016-11-26 00:07:12 --> Security Class Initialized
DEBUG - 2016-11-26 00:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:07:12 --> Input Class Initialized
INFO - 2016-11-26 00:07:13 --> Language Class Initialized
INFO - 2016-11-26 00:07:13 --> Loader Class Initialized
INFO - 2016-11-26 00:07:13 --> Helper loaded: url_helper
INFO - 2016-11-26 00:07:13 --> Helper loaded: form_helper
INFO - 2016-11-26 00:07:13 --> Database Driver Class Initialized
INFO - 2016-11-26 00:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:07:13 --> Controller Class Initialized
INFO - 2016-11-26 00:07:13 --> Model Class Initialized
INFO - 2016-11-26 00:07:13 --> Model Class Initialized
INFO - 2016-11-26 00:07:13 --> Model Class Initialized
INFO - 2016-11-26 00:07:13 --> Model Class Initialized
INFO - 2016-11-26 00:07:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:07:13 --> Pagination Class Initialized
INFO - 2016-11-26 00:07:13 --> Helper loaded: app_helper
DEBUG - 2016-11-26 00:07:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-26 00:07:13 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-26 00:07:13 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-26 00:07:13 --> Config Class Initialized
INFO - 2016-11-26 00:07:13 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:07:13 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:07:13 --> Utf8 Class Initialized
INFO - 2016-11-26 00:07:13 --> URI Class Initialized
DEBUG - 2016-11-26 00:07:13 --> No URI present. Default controller set.
INFO - 2016-11-26 00:07:13 --> Router Class Initialized
INFO - 2016-11-26 00:07:13 --> Output Class Initialized
INFO - 2016-11-26 00:07:13 --> Security Class Initialized
DEBUG - 2016-11-26 00:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:07:13 --> Input Class Initialized
INFO - 2016-11-26 00:07:13 --> Language Class Initialized
INFO - 2016-11-26 00:07:13 --> Loader Class Initialized
INFO - 2016-11-26 00:07:13 --> Helper loaded: url_helper
INFO - 2016-11-26 00:07:13 --> Helper loaded: form_helper
INFO - 2016-11-26 00:07:13 --> Database Driver Class Initialized
INFO - 2016-11-26 00:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:07:13 --> Controller Class Initialized
INFO - 2016-11-26 00:07:13 --> Model Class Initialized
INFO - 2016-11-26 00:07:13 --> Model Class Initialized
INFO - 2016-11-26 00:07:13 --> Model Class Initialized
INFO - 2016-11-26 00:07:13 --> Model Class Initialized
INFO - 2016-11-26 00:07:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:07:13 --> Pagination Class Initialized
INFO - 2016-11-26 00:07:13 --> Helper loaded: app_helper
INFO - 2016-11-26 00:07:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 00:07:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-26 00:07:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 00:07:13 --> Final output sent to browser
DEBUG - 2016-11-26 00:07:13 --> Total execution time: 0.2612
INFO - 2016-11-26 00:07:27 --> Config Class Initialized
INFO - 2016-11-26 00:07:27 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:07:27 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:07:27 --> Utf8 Class Initialized
INFO - 2016-11-26 00:07:27 --> URI Class Initialized
INFO - 2016-11-26 00:07:27 --> Router Class Initialized
INFO - 2016-11-26 00:07:27 --> Output Class Initialized
INFO - 2016-11-26 00:07:27 --> Security Class Initialized
DEBUG - 2016-11-26 00:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:07:27 --> Input Class Initialized
INFO - 2016-11-26 00:07:27 --> Language Class Initialized
INFO - 2016-11-26 00:07:27 --> Loader Class Initialized
INFO - 2016-11-26 00:07:27 --> Helper loaded: url_helper
INFO - 2016-11-26 00:07:27 --> Helper loaded: form_helper
INFO - 2016-11-26 00:07:27 --> Database Driver Class Initialized
INFO - 2016-11-26 00:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:07:27 --> Controller Class Initialized
INFO - 2016-11-26 00:07:27 --> Model Class Initialized
INFO - 2016-11-26 00:07:27 --> Model Class Initialized
INFO - 2016-11-26 00:07:28 --> Model Class Initialized
INFO - 2016-11-26 00:07:28 --> Model Class Initialized
INFO - 2016-11-26 00:07:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:07:28 --> Pagination Class Initialized
INFO - 2016-11-26 00:07:28 --> Helper loaded: app_helper
DEBUG - 2016-11-26 00:07:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-26 00:07:28 --> Model Class Initialized
INFO - 2016-11-26 00:07:28 --> Final output sent to browser
DEBUG - 2016-11-26 00:07:28 --> Total execution time: 0.2213
INFO - 2016-11-26 00:07:28 --> Config Class Initialized
INFO - 2016-11-26 00:07:28 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:07:28 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:07:28 --> Utf8 Class Initialized
INFO - 2016-11-26 00:07:28 --> URI Class Initialized
DEBUG - 2016-11-26 00:07:28 --> No URI present. Default controller set.
INFO - 2016-11-26 00:07:28 --> Router Class Initialized
INFO - 2016-11-26 00:07:28 --> Output Class Initialized
INFO - 2016-11-26 00:07:28 --> Security Class Initialized
DEBUG - 2016-11-26 00:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:07:28 --> Input Class Initialized
INFO - 2016-11-26 00:07:28 --> Language Class Initialized
INFO - 2016-11-26 00:07:28 --> Loader Class Initialized
INFO - 2016-11-26 00:07:28 --> Helper loaded: url_helper
INFO - 2016-11-26 00:07:28 --> Helper loaded: form_helper
INFO - 2016-11-26 00:07:28 --> Database Driver Class Initialized
INFO - 2016-11-26 00:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:07:28 --> Controller Class Initialized
INFO - 2016-11-26 00:07:28 --> Model Class Initialized
INFO - 2016-11-26 00:07:28 --> Model Class Initialized
INFO - 2016-11-26 00:07:28 --> Model Class Initialized
INFO - 2016-11-26 00:07:28 --> Model Class Initialized
INFO - 2016-11-26 00:07:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:07:28 --> Pagination Class Initialized
INFO - 2016-11-26 00:07:28 --> Helper loaded: app_helper
INFO - 2016-11-26 00:07:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 00:07:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 00:07:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 00:07:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-26 00:07:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-26 00:07:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-26 00:07:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-26 00:07:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 00:07:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 00:07:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 00:07:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 00:07:28 --> Final output sent to browser
DEBUG - 2016-11-26 00:07:28 --> Total execution time: 0.3405
INFO - 2016-11-26 00:07:49 --> Config Class Initialized
INFO - 2016-11-26 00:07:49 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:07:49 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:07:49 --> Utf8 Class Initialized
INFO - 2016-11-26 00:07:49 --> URI Class Initialized
INFO - 2016-11-26 00:07:49 --> Router Class Initialized
INFO - 2016-11-26 00:07:49 --> Output Class Initialized
INFO - 2016-11-26 00:07:49 --> Security Class Initialized
DEBUG - 2016-11-26 00:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:07:49 --> Input Class Initialized
INFO - 2016-11-26 00:07:49 --> Language Class Initialized
INFO - 2016-11-26 00:07:49 --> Loader Class Initialized
INFO - 2016-11-26 00:07:49 --> Helper loaded: url_helper
INFO - 2016-11-26 00:07:49 --> Helper loaded: form_helper
INFO - 2016-11-26 00:07:49 --> Database Driver Class Initialized
INFO - 2016-11-26 00:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:07:49 --> Controller Class Initialized
INFO - 2016-11-26 00:07:49 --> Model Class Initialized
INFO - 2016-11-26 00:07:49 --> Model Class Initialized
INFO - 2016-11-26 00:07:49 --> Model Class Initialized
INFO - 2016-11-26 00:07:49 --> Model Class Initialized
INFO - 2016-11-26 00:07:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:07:49 --> Pagination Class Initialized
INFO - 2016-11-26 00:07:49 --> Helper loaded: app_helper
DEBUG - 2016-11-26 00:07:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-26 00:07:50 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-26 00:07:50 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-26 00:07:50 --> Config Class Initialized
INFO - 2016-11-26 00:07:50 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:07:50 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:07:50 --> Utf8 Class Initialized
INFO - 2016-11-26 00:07:50 --> URI Class Initialized
DEBUG - 2016-11-26 00:07:50 --> No URI present. Default controller set.
INFO - 2016-11-26 00:07:50 --> Router Class Initialized
INFO - 2016-11-26 00:07:50 --> Output Class Initialized
INFO - 2016-11-26 00:07:50 --> Security Class Initialized
DEBUG - 2016-11-26 00:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:07:50 --> Input Class Initialized
INFO - 2016-11-26 00:07:50 --> Language Class Initialized
INFO - 2016-11-26 00:07:50 --> Loader Class Initialized
INFO - 2016-11-26 00:07:50 --> Helper loaded: url_helper
INFO - 2016-11-26 00:07:50 --> Helper loaded: form_helper
INFO - 2016-11-26 00:07:50 --> Database Driver Class Initialized
INFO - 2016-11-26 00:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:07:50 --> Controller Class Initialized
INFO - 2016-11-26 00:07:50 --> Model Class Initialized
INFO - 2016-11-26 00:07:50 --> Model Class Initialized
INFO - 2016-11-26 00:07:50 --> Model Class Initialized
INFO - 2016-11-26 00:07:50 --> Model Class Initialized
INFO - 2016-11-26 00:07:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:07:50 --> Pagination Class Initialized
INFO - 2016-11-26 00:07:50 --> Helper loaded: app_helper
INFO - 2016-11-26 00:07:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 00:07:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-26 00:07:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 00:07:50 --> Final output sent to browser
DEBUG - 2016-11-26 00:07:50 --> Total execution time: 0.3034
INFO - 2016-11-26 00:08:03 --> Config Class Initialized
INFO - 2016-11-26 00:08:03 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:08:03 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:08:03 --> Utf8 Class Initialized
INFO - 2016-11-26 00:08:03 --> URI Class Initialized
INFO - 2016-11-26 00:08:03 --> Router Class Initialized
INFO - 2016-11-26 00:08:03 --> Output Class Initialized
INFO - 2016-11-26 00:08:03 --> Security Class Initialized
DEBUG - 2016-11-26 00:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:08:03 --> Input Class Initialized
INFO - 2016-11-26 00:08:03 --> Language Class Initialized
INFO - 2016-11-26 00:08:03 --> Loader Class Initialized
INFO - 2016-11-26 00:08:03 --> Helper loaded: url_helper
INFO - 2016-11-26 00:08:03 --> Helper loaded: form_helper
INFO - 2016-11-26 00:08:03 --> Database Driver Class Initialized
INFO - 2016-11-26 00:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:08:03 --> Controller Class Initialized
INFO - 2016-11-26 00:08:03 --> Model Class Initialized
INFO - 2016-11-26 00:08:03 --> Model Class Initialized
INFO - 2016-11-26 00:08:03 --> Model Class Initialized
INFO - 2016-11-26 00:08:03 --> Model Class Initialized
INFO - 2016-11-26 00:08:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:08:03 --> Pagination Class Initialized
INFO - 2016-11-26 00:08:03 --> Helper loaded: app_helper
DEBUG - 2016-11-26 00:08:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-26 00:08:03 --> Model Class Initialized
INFO - 2016-11-26 00:08:03 --> Final output sent to browser
DEBUG - 2016-11-26 00:08:03 --> Total execution time: 0.2909
INFO - 2016-11-26 00:08:03 --> Config Class Initialized
INFO - 2016-11-26 00:08:03 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:08:03 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:08:03 --> Utf8 Class Initialized
INFO - 2016-11-26 00:08:03 --> URI Class Initialized
DEBUG - 2016-11-26 00:08:03 --> No URI present. Default controller set.
INFO - 2016-11-26 00:08:03 --> Router Class Initialized
INFO - 2016-11-26 00:08:03 --> Output Class Initialized
INFO - 2016-11-26 00:08:03 --> Security Class Initialized
DEBUG - 2016-11-26 00:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:08:03 --> Input Class Initialized
INFO - 2016-11-26 00:08:03 --> Language Class Initialized
INFO - 2016-11-26 00:08:03 --> Loader Class Initialized
INFO - 2016-11-26 00:08:04 --> Helper loaded: url_helper
INFO - 2016-11-26 00:08:04 --> Helper loaded: form_helper
INFO - 2016-11-26 00:08:04 --> Database Driver Class Initialized
INFO - 2016-11-26 00:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:08:04 --> Controller Class Initialized
INFO - 2016-11-26 00:08:04 --> Model Class Initialized
INFO - 2016-11-26 00:08:04 --> Model Class Initialized
INFO - 2016-11-26 00:08:04 --> Model Class Initialized
INFO - 2016-11-26 00:08:04 --> Model Class Initialized
INFO - 2016-11-26 00:08:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:08:04 --> Pagination Class Initialized
INFO - 2016-11-26 00:08:04 --> Helper loaded: app_helper
INFO - 2016-11-26 00:08:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 00:08:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 00:08:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 00:08:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 00:08:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 00:08:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 00:08:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 00:08:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 00:08:04 --> Final output sent to browser
DEBUG - 2016-11-26 00:08:04 --> Total execution time: 0.3573
INFO - 2016-11-26 00:10:47 --> Config Class Initialized
INFO - 2016-11-26 00:10:47 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:10:47 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:10:47 --> Utf8 Class Initialized
INFO - 2016-11-26 00:10:47 --> URI Class Initialized
DEBUG - 2016-11-26 00:10:47 --> No URI present. Default controller set.
INFO - 2016-11-26 00:10:47 --> Router Class Initialized
INFO - 2016-11-26 00:10:47 --> Output Class Initialized
INFO - 2016-11-26 00:10:47 --> Security Class Initialized
DEBUG - 2016-11-26 00:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:10:47 --> Input Class Initialized
INFO - 2016-11-26 00:10:47 --> Language Class Initialized
INFO - 2016-11-26 00:10:47 --> Loader Class Initialized
INFO - 2016-11-26 00:10:47 --> Helper loaded: url_helper
INFO - 2016-11-26 00:10:47 --> Helper loaded: form_helper
INFO - 2016-11-26 00:10:47 --> Database Driver Class Initialized
INFO - 2016-11-26 00:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:10:47 --> Controller Class Initialized
INFO - 2016-11-26 00:10:47 --> Model Class Initialized
INFO - 2016-11-26 00:10:47 --> Model Class Initialized
INFO - 2016-11-26 00:10:47 --> Model Class Initialized
INFO - 2016-11-26 00:10:47 --> Model Class Initialized
INFO - 2016-11-26 00:10:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:10:47 --> Pagination Class Initialized
INFO - 2016-11-26 00:10:47 --> Helper loaded: app_helper
INFO - 2016-11-26 00:10:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 00:10:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 00:10:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 00:10:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 00:10:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 00:10:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 00:10:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 00:10:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 00:10:47 --> Final output sent to browser
DEBUG - 2016-11-26 00:10:47 --> Total execution time: 0.3719
INFO - 2016-11-26 00:10:53 --> Config Class Initialized
INFO - 2016-11-26 00:10:53 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:10:53 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:10:53 --> Utf8 Class Initialized
INFO - 2016-11-26 00:10:53 --> URI Class Initialized
DEBUG - 2016-11-26 00:10:53 --> No URI present. Default controller set.
INFO - 2016-11-26 00:10:53 --> Router Class Initialized
INFO - 2016-11-26 00:10:53 --> Output Class Initialized
INFO - 2016-11-26 00:10:53 --> Security Class Initialized
DEBUG - 2016-11-26 00:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:10:53 --> Input Class Initialized
INFO - 2016-11-26 00:10:53 --> Language Class Initialized
INFO - 2016-11-26 00:10:53 --> Loader Class Initialized
INFO - 2016-11-26 00:10:53 --> Helper loaded: url_helper
INFO - 2016-11-26 00:10:53 --> Helper loaded: form_helper
INFO - 2016-11-26 00:10:53 --> Config Class Initialized
INFO - 2016-11-26 00:10:53 --> Database Driver Class Initialized
INFO - 2016-11-26 00:10:53 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:10:53 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:10:53 --> Utf8 Class Initialized
INFO - 2016-11-26 00:10:53 --> Controller Class Initialized
INFO - 2016-11-26 00:10:53 --> URI Class Initialized
INFO - 2016-11-26 00:10:53 --> Model Class Initialized
DEBUG - 2016-11-26 00:10:53 --> No URI present. Default controller set.
INFO - 2016-11-26 00:10:53 --> Model Class Initialized
INFO - 2016-11-26 00:10:53 --> Router Class Initialized
INFO - 2016-11-26 00:10:53 --> Model Class Initialized
INFO - 2016-11-26 00:10:53 --> Output Class Initialized
INFO - 2016-11-26 00:10:53 --> Model Class Initialized
INFO - 2016-11-26 00:10:53 --> Security Class Initialized
INFO - 2016-11-26 00:10:53 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2016-11-26 00:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:10:53 --> Pagination Class Initialized
INFO - 2016-11-26 00:10:53 --> Input Class Initialized
INFO - 2016-11-26 00:10:53 --> Helper loaded: app_helper
INFO - 2016-11-26 00:10:53 --> Config Class Initialized
INFO - 2016-11-26 00:10:53 --> Language Class Initialized
INFO - 2016-11-26 00:10:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 00:10:53 --> Hooks Class Initialized
INFO - 2016-11-26 00:10:53 --> Loader Class Initialized
INFO - 2016-11-26 00:10:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
DEBUG - 2016-11-26 00:10:53 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:10:53 --> Helper loaded: url_helper
INFO - 2016-11-26 00:10:53 --> Utf8 Class Initialized
INFO - 2016-11-26 00:10:53 --> URI Class Initialized
INFO - 2016-11-26 00:10:53 --> Helper loaded: form_helper
INFO - 2016-11-26 00:10:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
DEBUG - 2016-11-26 00:10:53 --> No URI present. Default controller set.
INFO - 2016-11-26 00:10:53 --> Database Driver Class Initialized
INFO - 2016-11-26 00:10:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 00:10:53 --> Router Class Initialized
INFO - 2016-11-26 00:10:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 00:10:53 --> Output Class Initialized
INFO - 2016-11-26 00:10:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 00:10:53 --> Security Class Initialized
INFO - 2016-11-26 00:10:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 00:10:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
DEBUG - 2016-11-26 00:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:10:53 --> Final output sent to browser
INFO - 2016-11-26 00:10:53 --> Input Class Initialized
DEBUG - 2016-11-26 00:10:53 --> Total execution time: 0.5634
INFO - 2016-11-26 00:10:53 --> Language Class Initialized
INFO - 2016-11-26 00:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:10:53 --> Loader Class Initialized
INFO - 2016-11-26 00:10:53 --> Controller Class Initialized
INFO - 2016-11-26 00:10:53 --> Model Class Initialized
INFO - 2016-11-26 00:10:53 --> Helper loaded: url_helper
INFO - 2016-11-26 00:10:53 --> Model Class Initialized
INFO - 2016-11-26 00:10:53 --> Helper loaded: form_helper
INFO - 2016-11-26 00:10:53 --> Model Class Initialized
INFO - 2016-11-26 00:10:53 --> Database Driver Class Initialized
INFO - 2016-11-26 00:10:53 --> Model Class Initialized
INFO - 2016-11-26 00:10:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:10:53 --> Pagination Class Initialized
INFO - 2016-11-26 00:10:53 --> Config Class Initialized
INFO - 2016-11-26 00:10:53 --> Hooks Class Initialized
INFO - 2016-11-26 00:10:53 --> Helper loaded: app_helper
INFO - 2016-11-26 00:10:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
DEBUG - 2016-11-26 00:10:53 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:10:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 00:10:53 --> Utf8 Class Initialized
INFO - 2016-11-26 00:10:53 --> URI Class Initialized
DEBUG - 2016-11-26 00:10:53 --> No URI present. Default controller set.
INFO - 2016-11-26 00:10:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 00:10:53 --> Router Class Initialized
INFO - 2016-11-26 00:10:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 00:10:53 --> Output Class Initialized
INFO - 2016-11-26 00:10:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 00:10:53 --> Security Class Initialized
INFO - 2016-11-26 00:10:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 00:10:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
DEBUG - 2016-11-26 00:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:10:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 00:10:54 --> Input Class Initialized
INFO - 2016-11-26 00:10:54 --> Final output sent to browser
INFO - 2016-11-26 00:10:54 --> Language Class Initialized
DEBUG - 2016-11-26 00:10:54 --> Total execution time: 0.7274
INFO - 2016-11-26 00:10:54 --> Loader Class Initialized
INFO - 2016-11-26 00:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:10:54 --> Helper loaded: url_helper
INFO - 2016-11-26 00:10:54 --> Controller Class Initialized
INFO - 2016-11-26 00:10:54 --> Model Class Initialized
INFO - 2016-11-26 00:10:54 --> Helper loaded: form_helper
INFO - 2016-11-26 00:10:54 --> Model Class Initialized
INFO - 2016-11-26 00:10:54 --> Database Driver Class Initialized
INFO - 2016-11-26 00:10:54 --> Model Class Initialized
INFO - 2016-11-26 00:10:54 --> Model Class Initialized
INFO - 2016-11-26 00:10:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:10:54 --> Pagination Class Initialized
INFO - 2016-11-26 00:10:54 --> Helper loaded: app_helper
INFO - 2016-11-26 00:10:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 00:10:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 00:10:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 00:10:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 00:10:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 00:10:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 00:10:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 00:10:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 00:10:54 --> Final output sent to browser
DEBUG - 2016-11-26 00:10:54 --> Total execution time: 0.7736
INFO - 2016-11-26 00:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:10:54 --> Controller Class Initialized
INFO - 2016-11-26 00:10:54 --> Model Class Initialized
INFO - 2016-11-26 00:10:54 --> Model Class Initialized
INFO - 2016-11-26 00:10:54 --> Model Class Initialized
INFO - 2016-11-26 00:10:54 --> Model Class Initialized
INFO - 2016-11-26 00:10:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:10:54 --> Pagination Class Initialized
INFO - 2016-11-26 00:10:54 --> Helper loaded: app_helper
INFO - 2016-11-26 00:10:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 00:10:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 00:10:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 00:10:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 00:10:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 00:10:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 00:10:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 00:10:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 00:10:54 --> Final output sent to browser
DEBUG - 2016-11-26 00:10:54 --> Total execution time: 0.6632
INFO - 2016-11-26 00:11:00 --> Config Class Initialized
INFO - 2016-11-26 00:11:00 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:11:00 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:11:00 --> Utf8 Class Initialized
INFO - 2016-11-26 00:11:00 --> URI Class Initialized
DEBUG - 2016-11-26 00:11:00 --> No URI present. Default controller set.
INFO - 2016-11-26 00:11:00 --> Router Class Initialized
INFO - 2016-11-26 00:11:00 --> Output Class Initialized
INFO - 2016-11-26 00:11:00 --> Security Class Initialized
DEBUG - 2016-11-26 00:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:11:00 --> Input Class Initialized
INFO - 2016-11-26 00:11:00 --> Language Class Initialized
INFO - 2016-11-26 00:11:00 --> Loader Class Initialized
INFO - 2016-11-26 00:11:00 --> Helper loaded: url_helper
INFO - 2016-11-26 00:11:01 --> Helper loaded: form_helper
INFO - 2016-11-26 00:11:01 --> Database Driver Class Initialized
INFO - 2016-11-26 00:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:11:01 --> Controller Class Initialized
INFO - 2016-11-26 00:11:01 --> Model Class Initialized
INFO - 2016-11-26 00:11:01 --> Model Class Initialized
INFO - 2016-11-26 00:11:01 --> Model Class Initialized
INFO - 2016-11-26 00:11:01 --> Model Class Initialized
INFO - 2016-11-26 00:11:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:11:01 --> Pagination Class Initialized
INFO - 2016-11-26 00:11:01 --> Helper loaded: app_helper
INFO - 2016-11-26 00:11:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 00:11:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 00:11:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 00:11:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 00:11:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 00:11:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 00:11:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 00:11:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 00:11:01 --> Final output sent to browser
DEBUG - 2016-11-26 00:11:01 --> Total execution time: 0.3885
INFO - 2016-11-26 00:13:12 --> Config Class Initialized
INFO - 2016-11-26 00:13:12 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:13:12 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:13:12 --> Utf8 Class Initialized
INFO - 2016-11-26 00:13:12 --> URI Class Initialized
DEBUG - 2016-11-26 00:13:12 --> No URI present. Default controller set.
INFO - 2016-11-26 00:13:12 --> Router Class Initialized
INFO - 2016-11-26 00:13:12 --> Output Class Initialized
INFO - 2016-11-26 00:13:12 --> Security Class Initialized
DEBUG - 2016-11-26 00:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:13:12 --> Input Class Initialized
INFO - 2016-11-26 00:13:12 --> Language Class Initialized
INFO - 2016-11-26 00:13:12 --> Loader Class Initialized
INFO - 2016-11-26 00:13:12 --> Helper loaded: url_helper
INFO - 2016-11-26 00:13:12 --> Helper loaded: form_helper
INFO - 2016-11-26 00:13:12 --> Database Driver Class Initialized
INFO - 2016-11-26 00:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:13:12 --> Controller Class Initialized
INFO - 2016-11-26 00:13:12 --> Model Class Initialized
INFO - 2016-11-26 00:13:12 --> Model Class Initialized
INFO - 2016-11-26 00:13:12 --> Model Class Initialized
INFO - 2016-11-26 00:13:12 --> Model Class Initialized
INFO - 2016-11-26 00:13:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:13:12 --> Pagination Class Initialized
INFO - 2016-11-26 00:13:12 --> Helper loaded: app_helper
INFO - 2016-11-26 00:13:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 00:13:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 00:13:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 00:13:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 00:13:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 00:13:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 00:13:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 00:13:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 00:13:12 --> Final output sent to browser
DEBUG - 2016-11-26 00:13:12 --> Total execution time: 0.3998
INFO - 2016-11-26 00:15:03 --> Config Class Initialized
INFO - 2016-11-26 00:15:03 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:15:03 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:15:03 --> Utf8 Class Initialized
INFO - 2016-11-26 00:15:03 --> URI Class Initialized
DEBUG - 2016-11-26 00:15:03 --> No URI present. Default controller set.
INFO - 2016-11-26 00:15:03 --> Router Class Initialized
INFO - 2016-11-26 00:15:03 --> Output Class Initialized
INFO - 2016-11-26 00:15:03 --> Security Class Initialized
DEBUG - 2016-11-26 00:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:15:03 --> Input Class Initialized
INFO - 2016-11-26 00:15:03 --> Language Class Initialized
INFO - 2016-11-26 00:15:03 --> Loader Class Initialized
INFO - 2016-11-26 00:15:03 --> Helper loaded: url_helper
INFO - 2016-11-26 00:15:03 --> Helper loaded: form_helper
INFO - 2016-11-26 00:15:03 --> Database Driver Class Initialized
INFO - 2016-11-26 00:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:15:04 --> Controller Class Initialized
INFO - 2016-11-26 00:15:04 --> Model Class Initialized
INFO - 2016-11-26 00:15:04 --> Model Class Initialized
INFO - 2016-11-26 00:15:04 --> Model Class Initialized
INFO - 2016-11-26 00:15:04 --> Model Class Initialized
INFO - 2016-11-26 00:15:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:15:04 --> Pagination Class Initialized
INFO - 2016-11-26 00:15:04 --> Helper loaded: app_helper
INFO - 2016-11-26 00:15:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 00:15:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 00:15:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 00:15:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 00:15:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 00:15:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 00:15:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 00:15:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 00:15:04 --> Final output sent to browser
DEBUG - 2016-11-26 00:15:04 --> Total execution time: 0.4294
INFO - 2016-11-26 00:17:02 --> Config Class Initialized
INFO - 2016-11-26 00:17:02 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:17:02 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:17:02 --> Utf8 Class Initialized
INFO - 2016-11-26 00:17:02 --> URI Class Initialized
DEBUG - 2016-11-26 00:17:02 --> No URI present. Default controller set.
INFO - 2016-11-26 00:17:02 --> Router Class Initialized
INFO - 2016-11-26 00:17:02 --> Output Class Initialized
INFO - 2016-11-26 00:17:02 --> Security Class Initialized
DEBUG - 2016-11-26 00:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:17:02 --> Input Class Initialized
INFO - 2016-11-26 00:17:02 --> Language Class Initialized
INFO - 2016-11-26 00:17:02 --> Loader Class Initialized
INFO - 2016-11-26 00:17:02 --> Helper loaded: url_helper
INFO - 2016-11-26 00:17:02 --> Helper loaded: form_helper
INFO - 2016-11-26 00:17:02 --> Database Driver Class Initialized
INFO - 2016-11-26 00:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:17:02 --> Controller Class Initialized
INFO - 2016-11-26 00:17:02 --> Model Class Initialized
INFO - 2016-11-26 00:17:02 --> Model Class Initialized
INFO - 2016-11-26 00:17:02 --> Model Class Initialized
INFO - 2016-11-26 00:17:02 --> Model Class Initialized
INFO - 2016-11-26 00:17:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:17:02 --> Pagination Class Initialized
INFO - 2016-11-26 00:17:02 --> Helper loaded: app_helper
INFO - 2016-11-26 00:17:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 00:17:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 00:17:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 00:17:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 00:17:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 00:17:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 00:17:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 00:17:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 00:17:02 --> Final output sent to browser
DEBUG - 2016-11-26 00:17:02 --> Total execution time: 0.3848
INFO - 2016-11-26 00:17:41 --> Config Class Initialized
INFO - 2016-11-26 00:17:41 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:17:41 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:17:41 --> Utf8 Class Initialized
INFO - 2016-11-26 00:17:41 --> URI Class Initialized
DEBUG - 2016-11-26 00:17:41 --> No URI present. Default controller set.
INFO - 2016-11-26 00:17:41 --> Router Class Initialized
INFO - 2016-11-26 00:17:41 --> Output Class Initialized
INFO - 2016-11-26 00:17:41 --> Security Class Initialized
DEBUG - 2016-11-26 00:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:17:41 --> Input Class Initialized
INFO - 2016-11-26 00:17:41 --> Language Class Initialized
INFO - 2016-11-26 00:17:41 --> Loader Class Initialized
INFO - 2016-11-26 00:17:41 --> Helper loaded: url_helper
INFO - 2016-11-26 00:17:41 --> Helper loaded: form_helper
INFO - 2016-11-26 00:17:41 --> Database Driver Class Initialized
INFO - 2016-11-26 00:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:17:41 --> Controller Class Initialized
INFO - 2016-11-26 00:17:41 --> Model Class Initialized
INFO - 2016-11-26 00:17:41 --> Model Class Initialized
INFO - 2016-11-26 00:17:41 --> Model Class Initialized
INFO - 2016-11-26 00:17:41 --> Model Class Initialized
INFO - 2016-11-26 00:17:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:17:41 --> Pagination Class Initialized
INFO - 2016-11-26 00:17:41 --> Helper loaded: app_helper
INFO - 2016-11-26 00:17:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 00:17:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 00:17:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 00:17:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 00:17:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 00:17:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 00:17:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 00:17:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 00:17:41 --> Final output sent to browser
DEBUG - 2016-11-26 00:17:41 --> Total execution time: 0.4240
INFO - 2016-11-26 00:19:47 --> Config Class Initialized
INFO - 2016-11-26 00:19:47 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:19:47 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:19:47 --> Utf8 Class Initialized
INFO - 2016-11-26 00:19:47 --> URI Class Initialized
INFO - 2016-11-26 00:19:47 --> Router Class Initialized
INFO - 2016-11-26 00:19:47 --> Output Class Initialized
INFO - 2016-11-26 00:19:47 --> Security Class Initialized
DEBUG - 2016-11-26 00:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:19:47 --> Input Class Initialized
INFO - 2016-11-26 00:19:47 --> Language Class Initialized
INFO - 2016-11-26 00:19:47 --> Loader Class Initialized
INFO - 2016-11-26 00:19:47 --> Helper loaded: url_helper
INFO - 2016-11-26 00:19:47 --> Helper loaded: form_helper
INFO - 2016-11-26 00:19:47 --> Database Driver Class Initialized
INFO - 2016-11-26 00:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:19:47 --> Controller Class Initialized
INFO - 2016-11-26 00:19:47 --> Model Class Initialized
INFO - 2016-11-26 00:19:47 --> Form Validation Class Initialized
INFO - 2016-11-26 00:19:47 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-26 00:19:47 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\hrm\add_leave_record_sidebar.php 31
INFO - 2016-11-26 00:19:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 00:19:47 --> Final output sent to browser
DEBUG - 2016-11-26 00:19:47 --> Total execution time: 0.3437
INFO - 2016-11-26 00:19:54 --> Config Class Initialized
INFO - 2016-11-26 00:19:54 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:19:54 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:19:54 --> Utf8 Class Initialized
INFO - 2016-11-26 00:19:54 --> URI Class Initialized
DEBUG - 2016-11-26 00:19:54 --> No URI present. Default controller set.
INFO - 2016-11-26 00:19:54 --> Router Class Initialized
INFO - 2016-11-26 00:19:54 --> Output Class Initialized
INFO - 2016-11-26 00:19:54 --> Security Class Initialized
DEBUG - 2016-11-26 00:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:19:54 --> Input Class Initialized
INFO - 2016-11-26 00:19:54 --> Language Class Initialized
INFO - 2016-11-26 00:19:54 --> Loader Class Initialized
INFO - 2016-11-26 00:19:54 --> Helper loaded: url_helper
INFO - 2016-11-26 00:19:55 --> Helper loaded: form_helper
INFO - 2016-11-26 00:19:55 --> Database Driver Class Initialized
INFO - 2016-11-26 00:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:19:55 --> Controller Class Initialized
INFO - 2016-11-26 00:19:55 --> Model Class Initialized
INFO - 2016-11-26 00:19:55 --> Model Class Initialized
INFO - 2016-11-26 00:19:55 --> Model Class Initialized
INFO - 2016-11-26 00:19:55 --> Model Class Initialized
INFO - 2016-11-26 00:19:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:19:55 --> Pagination Class Initialized
INFO - 2016-11-26 00:19:55 --> Helper loaded: app_helper
INFO - 2016-11-26 00:19:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 00:19:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 00:19:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 00:19:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 00:19:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 00:19:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 00:19:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 00:19:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 00:19:55 --> Final output sent to browser
DEBUG - 2016-11-26 00:19:55 --> Total execution time: 0.4195
INFO - 2016-11-26 00:33:58 --> Config Class Initialized
INFO - 2016-11-26 00:33:58 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:33:58 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:33:58 --> Utf8 Class Initialized
INFO - 2016-11-26 00:33:58 --> URI Class Initialized
INFO - 2016-11-26 00:33:58 --> Router Class Initialized
INFO - 2016-11-26 00:33:58 --> Output Class Initialized
INFO - 2016-11-26 00:33:58 --> Security Class Initialized
DEBUG - 2016-11-26 00:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:33:58 --> Input Class Initialized
INFO - 2016-11-26 00:33:58 --> Language Class Initialized
INFO - 2016-11-26 00:33:58 --> Loader Class Initialized
INFO - 2016-11-26 00:33:58 --> Helper loaded: url_helper
INFO - 2016-11-26 00:33:58 --> Helper loaded: form_helper
INFO - 2016-11-26 00:33:58 --> Database Driver Class Initialized
INFO - 2016-11-26 00:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:33:58 --> Controller Class Initialized
INFO - 2016-11-26 00:33:58 --> Model Class Initialized
INFO - 2016-11-26 00:33:58 --> Form Validation Class Initialized
INFO - 2016-11-26 00:33:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-26 00:33:58 --> Final output sent to browser
DEBUG - 2016-11-26 00:33:58 --> Total execution time: 0.2184
INFO - 2016-11-26 00:35:14 --> Config Class Initialized
INFO - 2016-11-26 00:35:14 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:35:14 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:35:14 --> Utf8 Class Initialized
INFO - 2016-11-26 00:35:14 --> URI Class Initialized
INFO - 2016-11-26 00:35:14 --> Router Class Initialized
INFO - 2016-11-26 00:35:14 --> Output Class Initialized
INFO - 2016-11-26 00:35:14 --> Security Class Initialized
DEBUG - 2016-11-26 00:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:35:14 --> Input Class Initialized
INFO - 2016-11-26 00:35:14 --> Language Class Initialized
INFO - 2016-11-26 00:35:14 --> Loader Class Initialized
INFO - 2016-11-26 00:35:14 --> Helper loaded: url_helper
INFO - 2016-11-26 00:35:14 --> Helper loaded: form_helper
INFO - 2016-11-26 00:35:14 --> Database Driver Class Initialized
INFO - 2016-11-26 00:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:35:14 --> Controller Class Initialized
INFO - 2016-11-26 00:35:14 --> Model Class Initialized
ERROR - 2016-11-26 00:35:15 --> Severity: Error --> Call to undefined function ajax_pagination() C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 106
INFO - 2016-11-26 00:36:44 --> Config Class Initialized
INFO - 2016-11-26 00:36:44 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:36:44 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:36:44 --> Utf8 Class Initialized
INFO - 2016-11-26 00:36:44 --> URI Class Initialized
DEBUG - 2016-11-26 00:36:44 --> No URI present. Default controller set.
INFO - 2016-11-26 00:36:44 --> Router Class Initialized
INFO - 2016-11-26 00:36:44 --> Output Class Initialized
INFO - 2016-11-26 00:36:44 --> Security Class Initialized
DEBUG - 2016-11-26 00:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:36:44 --> Input Class Initialized
INFO - 2016-11-26 00:36:44 --> Language Class Initialized
INFO - 2016-11-26 00:36:44 --> Loader Class Initialized
INFO - 2016-11-26 00:36:44 --> Helper loaded: url_helper
INFO - 2016-11-26 00:36:44 --> Helper loaded: form_helper
INFO - 2016-11-26 00:36:44 --> Database Driver Class Initialized
INFO - 2016-11-26 00:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:36:44 --> Controller Class Initialized
INFO - 2016-11-26 00:36:44 --> Model Class Initialized
INFO - 2016-11-26 00:36:44 --> Model Class Initialized
INFO - 2016-11-26 00:36:44 --> Model Class Initialized
INFO - 2016-11-26 00:36:44 --> Model Class Initialized
INFO - 2016-11-26 00:36:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:36:44 --> Pagination Class Initialized
INFO - 2016-11-26 00:36:44 --> Helper loaded: app_helper
INFO - 2016-11-26 00:36:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 00:36:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 00:36:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 00:36:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 00:36:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 00:36:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 00:36:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 00:36:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 00:36:44 --> Final output sent to browser
DEBUG - 2016-11-26 00:36:44 --> Total execution time: 0.4025
INFO - 2016-11-26 00:36:54 --> Config Class Initialized
INFO - 2016-11-26 00:36:54 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:36:54 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:36:54 --> Utf8 Class Initialized
INFO - 2016-11-26 00:36:54 --> URI Class Initialized
INFO - 2016-11-26 00:36:54 --> Router Class Initialized
INFO - 2016-11-26 00:36:54 --> Output Class Initialized
INFO - 2016-11-26 00:36:54 --> Security Class Initialized
DEBUG - 2016-11-26 00:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:36:54 --> Input Class Initialized
INFO - 2016-11-26 00:36:54 --> Language Class Initialized
INFO - 2016-11-26 00:36:54 --> Loader Class Initialized
INFO - 2016-11-26 00:36:54 --> Helper loaded: url_helper
INFO - 2016-11-26 00:36:54 --> Helper loaded: form_helper
INFO - 2016-11-26 00:36:54 --> Database Driver Class Initialized
INFO - 2016-11-26 00:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:36:54 --> Controller Class Initialized
INFO - 2016-11-26 00:36:54 --> Model Class Initialized
ERROR - 2016-11-26 00:36:55 --> Severity: Error --> Call to undefined function ajax_pagination() C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 106
INFO - 2016-11-26 00:39:04 --> Config Class Initialized
INFO - 2016-11-26 00:39:04 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:39:04 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:39:04 --> Utf8 Class Initialized
INFO - 2016-11-26 00:39:04 --> URI Class Initialized
DEBUG - 2016-11-26 00:39:04 --> No URI present. Default controller set.
INFO - 2016-11-26 00:39:04 --> Router Class Initialized
INFO - 2016-11-26 00:39:04 --> Output Class Initialized
INFO - 2016-11-26 00:39:04 --> Security Class Initialized
DEBUG - 2016-11-26 00:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:39:05 --> Input Class Initialized
INFO - 2016-11-26 00:39:05 --> Language Class Initialized
INFO - 2016-11-26 00:39:05 --> Loader Class Initialized
INFO - 2016-11-26 00:39:05 --> Helper loaded: url_helper
INFO - 2016-11-26 00:39:05 --> Helper loaded: form_helper
INFO - 2016-11-26 00:39:05 --> Database Driver Class Initialized
INFO - 2016-11-26 00:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:39:05 --> Controller Class Initialized
INFO - 2016-11-26 00:39:05 --> Model Class Initialized
INFO - 2016-11-26 00:39:05 --> Model Class Initialized
INFO - 2016-11-26 00:39:05 --> Model Class Initialized
INFO - 2016-11-26 00:39:05 --> Model Class Initialized
INFO - 2016-11-26 00:39:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:39:05 --> Pagination Class Initialized
INFO - 2016-11-26 00:39:05 --> Helper loaded: app_helper
INFO - 2016-11-26 00:39:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 00:39:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 00:39:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 00:39:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 00:39:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 00:39:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 00:39:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 00:39:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 00:39:05 --> Final output sent to browser
DEBUG - 2016-11-26 00:39:05 --> Total execution time: 0.3989
INFO - 2016-11-26 00:39:09 --> Config Class Initialized
INFO - 2016-11-26 00:39:09 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:39:09 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:39:09 --> Utf8 Class Initialized
INFO - 2016-11-26 00:39:09 --> URI Class Initialized
INFO - 2016-11-26 00:39:10 --> Router Class Initialized
INFO - 2016-11-26 00:39:10 --> Output Class Initialized
INFO - 2016-11-26 00:39:10 --> Security Class Initialized
DEBUG - 2016-11-26 00:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:39:10 --> Input Class Initialized
INFO - 2016-11-26 00:39:10 --> Language Class Initialized
INFO - 2016-11-26 00:39:10 --> Loader Class Initialized
INFO - 2016-11-26 00:39:10 --> Helper loaded: url_helper
INFO - 2016-11-26 00:39:10 --> Helper loaded: form_helper
INFO - 2016-11-26 00:39:10 --> Database Driver Class Initialized
INFO - 2016-11-26 00:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:39:10 --> Controller Class Initialized
INFO - 2016-11-26 00:39:10 --> Model Class Initialized
ERROR - 2016-11-26 00:39:10 --> Severity: Error --> Call to undefined function ajax_pagination() C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 106
INFO - 2016-11-26 00:39:59 --> Config Class Initialized
INFO - 2016-11-26 00:39:59 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:39:59 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:39:59 --> Utf8 Class Initialized
INFO - 2016-11-26 00:39:59 --> URI Class Initialized
DEBUG - 2016-11-26 00:39:59 --> No URI present. Default controller set.
INFO - 2016-11-26 00:39:59 --> Router Class Initialized
INFO - 2016-11-26 00:39:59 --> Output Class Initialized
INFO - 2016-11-26 00:39:59 --> Security Class Initialized
DEBUG - 2016-11-26 00:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:39:59 --> Input Class Initialized
INFO - 2016-11-26 00:39:59 --> Language Class Initialized
INFO - 2016-11-26 00:39:59 --> Loader Class Initialized
INFO - 2016-11-26 00:39:59 --> Helper loaded: url_helper
INFO - 2016-11-26 00:39:59 --> Helper loaded: form_helper
INFO - 2016-11-26 00:39:59 --> Database Driver Class Initialized
INFO - 2016-11-26 00:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:39:59 --> Controller Class Initialized
INFO - 2016-11-26 00:39:59 --> Model Class Initialized
INFO - 2016-11-26 00:39:59 --> Model Class Initialized
INFO - 2016-11-26 00:39:59 --> Model Class Initialized
INFO - 2016-11-26 00:39:59 --> Model Class Initialized
INFO - 2016-11-26 00:39:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:39:59 --> Pagination Class Initialized
INFO - 2016-11-26 00:39:59 --> Helper loaded: app_helper
INFO - 2016-11-26 00:39:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 00:39:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 00:40:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 00:40:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 00:40:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 00:40:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 00:40:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 00:40:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 00:40:00 --> Final output sent to browser
DEBUG - 2016-11-26 00:40:00 --> Total execution time: 0.4583
INFO - 2016-11-26 00:50:02 --> Config Class Initialized
INFO - 2016-11-26 00:50:02 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:50:02 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:50:02 --> Utf8 Class Initialized
INFO - 2016-11-26 00:50:02 --> URI Class Initialized
INFO - 2016-11-26 00:50:02 --> Router Class Initialized
INFO - 2016-11-26 00:50:02 --> Output Class Initialized
INFO - 2016-11-26 00:50:02 --> Security Class Initialized
DEBUG - 2016-11-26 00:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:50:02 --> Input Class Initialized
INFO - 2016-11-26 00:50:02 --> Language Class Initialized
INFO - 2016-11-26 00:50:02 --> Loader Class Initialized
INFO - 2016-11-26 00:50:02 --> Helper loaded: url_helper
INFO - 2016-11-26 00:50:02 --> Helper loaded: form_helper
INFO - 2016-11-26 00:50:02 --> Database Driver Class Initialized
INFO - 2016-11-26 00:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:50:02 --> Controller Class Initialized
INFO - 2016-11-26 00:50:02 --> Model Class Initialized
INFO - 2016-11-26 00:50:02 --> Model Class Initialized
INFO - 2016-11-26 00:50:02 --> Model Class Initialized
INFO - 2016-11-26 00:50:02 --> Model Class Initialized
INFO - 2016-11-26 00:50:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:50:02 --> Pagination Class Initialized
INFO - 2016-11-26 00:50:02 --> Helper loaded: app_helper
DEBUG - 2016-11-26 00:50:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-26 00:50:02 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-26 00:50:02 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-26 00:50:02 --> Config Class Initialized
INFO - 2016-11-26 00:50:02 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:50:02 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:50:02 --> Utf8 Class Initialized
INFO - 2016-11-26 00:50:02 --> URI Class Initialized
DEBUG - 2016-11-26 00:50:02 --> No URI present. Default controller set.
INFO - 2016-11-26 00:50:02 --> Router Class Initialized
INFO - 2016-11-26 00:50:02 --> Output Class Initialized
INFO - 2016-11-26 00:50:02 --> Security Class Initialized
DEBUG - 2016-11-26 00:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:50:02 --> Input Class Initialized
INFO - 2016-11-26 00:50:02 --> Language Class Initialized
INFO - 2016-11-26 00:50:02 --> Loader Class Initialized
INFO - 2016-11-26 00:50:02 --> Helper loaded: url_helper
INFO - 2016-11-26 00:50:02 --> Helper loaded: form_helper
INFO - 2016-11-26 00:50:02 --> Database Driver Class Initialized
INFO - 2016-11-26 00:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:50:02 --> Controller Class Initialized
INFO - 2016-11-26 00:50:02 --> Model Class Initialized
INFO - 2016-11-26 00:50:02 --> Model Class Initialized
INFO - 2016-11-26 00:50:02 --> Model Class Initialized
INFO - 2016-11-26 00:50:02 --> Model Class Initialized
INFO - 2016-11-26 00:50:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:50:02 --> Pagination Class Initialized
INFO - 2016-11-26 00:50:02 --> Helper loaded: app_helper
INFO - 2016-11-26 00:50:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 00:50:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-26 00:50:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 00:50:02 --> Final output sent to browser
DEBUG - 2016-11-26 00:50:02 --> Total execution time: 0.3245
INFO - 2016-11-26 00:50:29 --> Config Class Initialized
INFO - 2016-11-26 00:50:29 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:50:29 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:50:29 --> Utf8 Class Initialized
INFO - 2016-11-26 00:50:29 --> URI Class Initialized
INFO - 2016-11-26 00:50:29 --> Router Class Initialized
INFO - 2016-11-26 00:50:29 --> Output Class Initialized
INFO - 2016-11-26 00:50:29 --> Security Class Initialized
DEBUG - 2016-11-26 00:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:50:29 --> Input Class Initialized
INFO - 2016-11-26 00:50:29 --> Language Class Initialized
INFO - 2016-11-26 00:50:29 --> Loader Class Initialized
INFO - 2016-11-26 00:50:29 --> Helper loaded: url_helper
INFO - 2016-11-26 00:50:29 --> Helper loaded: form_helper
INFO - 2016-11-26 00:50:29 --> Database Driver Class Initialized
INFO - 2016-11-26 00:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:50:29 --> Controller Class Initialized
INFO - 2016-11-26 00:50:29 --> Model Class Initialized
INFO - 2016-11-26 00:50:29 --> Model Class Initialized
INFO - 2016-11-26 00:50:29 --> Model Class Initialized
INFO - 2016-11-26 00:50:29 --> Model Class Initialized
INFO - 2016-11-26 00:50:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:50:29 --> Pagination Class Initialized
INFO - 2016-11-26 00:50:29 --> Helper loaded: app_helper
DEBUG - 2016-11-26 00:50:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-26 00:50:29 --> Model Class Initialized
INFO - 2016-11-26 00:50:29 --> Final output sent to browser
DEBUG - 2016-11-26 00:50:29 --> Total execution time: 0.2504
INFO - 2016-11-26 00:50:29 --> Config Class Initialized
INFO - 2016-11-26 00:50:29 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:50:29 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:50:29 --> Utf8 Class Initialized
INFO - 2016-11-26 00:50:29 --> URI Class Initialized
DEBUG - 2016-11-26 00:50:29 --> No URI present. Default controller set.
INFO - 2016-11-26 00:50:29 --> Router Class Initialized
INFO - 2016-11-26 00:50:29 --> Output Class Initialized
INFO - 2016-11-26 00:50:29 --> Security Class Initialized
DEBUG - 2016-11-26 00:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:50:29 --> Input Class Initialized
INFO - 2016-11-26 00:50:29 --> Language Class Initialized
INFO - 2016-11-26 00:50:29 --> Loader Class Initialized
INFO - 2016-11-26 00:50:29 --> Helper loaded: url_helper
INFO - 2016-11-26 00:50:29 --> Helper loaded: form_helper
INFO - 2016-11-26 00:50:29 --> Database Driver Class Initialized
INFO - 2016-11-26 00:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:50:29 --> Controller Class Initialized
INFO - 2016-11-26 00:50:30 --> Model Class Initialized
INFO - 2016-11-26 00:50:30 --> Model Class Initialized
INFO - 2016-11-26 00:50:30 --> Model Class Initialized
INFO - 2016-11-26 00:50:30 --> Model Class Initialized
INFO - 2016-11-26 00:50:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:50:30 --> Pagination Class Initialized
INFO - 2016-11-26 00:50:30 --> Helper loaded: app_helper
INFO - 2016-11-26 00:50:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 00:50:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 00:50:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 00:50:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-26 00:50:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-26 00:50:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-26 00:50:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-26 00:50:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 00:50:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 00:50:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 00:50:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 00:50:30 --> Final output sent to browser
DEBUG - 2016-11-26 00:50:30 --> Total execution time: 0.3684
INFO - 2016-11-26 00:51:54 --> Config Class Initialized
INFO - 2016-11-26 00:51:54 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:51:54 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:51:54 --> Utf8 Class Initialized
INFO - 2016-11-26 00:51:54 --> URI Class Initialized
DEBUG - 2016-11-26 00:51:54 --> No URI present. Default controller set.
INFO - 2016-11-26 00:51:54 --> Router Class Initialized
INFO - 2016-11-26 00:51:54 --> Output Class Initialized
INFO - 2016-11-26 00:51:54 --> Security Class Initialized
DEBUG - 2016-11-26 00:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:51:54 --> Input Class Initialized
INFO - 2016-11-26 00:51:54 --> Language Class Initialized
INFO - 2016-11-26 00:51:54 --> Loader Class Initialized
INFO - 2016-11-26 00:51:54 --> Helper loaded: url_helper
INFO - 2016-11-26 00:51:54 --> Helper loaded: form_helper
INFO - 2016-11-26 00:51:54 --> Database Driver Class Initialized
INFO - 2016-11-26 00:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:51:54 --> Controller Class Initialized
INFO - 2016-11-26 00:51:54 --> Model Class Initialized
INFO - 2016-11-26 00:51:54 --> Model Class Initialized
INFO - 2016-11-26 00:51:54 --> Model Class Initialized
INFO - 2016-11-26 00:51:54 --> Model Class Initialized
INFO - 2016-11-26 00:51:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:51:54 --> Pagination Class Initialized
INFO - 2016-11-26 00:51:54 --> Helper loaded: app_helper
INFO - 2016-11-26 00:51:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 00:51:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 00:51:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 00:51:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-26 00:51:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-26 00:51:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-26 00:51:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-26 00:51:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 00:51:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 00:51:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 00:51:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 00:51:54 --> Final output sent to browser
DEBUG - 2016-11-26 00:51:54 --> Total execution time: 0.4736
INFO - 2016-11-26 00:52:01 --> Config Class Initialized
INFO - 2016-11-26 00:52:01 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:52:01 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:52:01 --> Utf8 Class Initialized
INFO - 2016-11-26 00:52:01 --> URI Class Initialized
DEBUG - 2016-11-26 00:52:01 --> No URI present. Default controller set.
INFO - 2016-11-26 00:52:01 --> Router Class Initialized
INFO - 2016-11-26 00:52:01 --> Output Class Initialized
INFO - 2016-11-26 00:52:01 --> Security Class Initialized
DEBUG - 2016-11-26 00:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:52:01 --> Input Class Initialized
INFO - 2016-11-26 00:52:01 --> Language Class Initialized
INFO - 2016-11-26 00:52:01 --> Loader Class Initialized
INFO - 2016-11-26 00:52:01 --> Helper loaded: url_helper
INFO - 2016-11-26 00:52:01 --> Helper loaded: form_helper
INFO - 2016-11-26 00:52:01 --> Database Driver Class Initialized
INFO - 2016-11-26 00:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:52:01 --> Controller Class Initialized
INFO - 2016-11-26 00:52:01 --> Model Class Initialized
INFO - 2016-11-26 00:52:01 --> Model Class Initialized
INFO - 2016-11-26 00:52:01 --> Model Class Initialized
INFO - 2016-11-26 00:52:01 --> Model Class Initialized
INFO - 2016-11-26 00:52:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:52:01 --> Pagination Class Initialized
INFO - 2016-11-26 00:52:01 --> Helper loaded: app_helper
INFO - 2016-11-26 00:52:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 00:52:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 00:52:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 00:52:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-26 00:52:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-26 00:52:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-26 00:52:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-26 00:52:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 00:52:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 00:52:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 00:52:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 00:52:02 --> Final output sent to browser
DEBUG - 2016-11-26 00:52:02 --> Total execution time: 0.4530
INFO - 2016-11-26 00:52:07 --> Config Class Initialized
INFO - 2016-11-26 00:52:07 --> Hooks Class Initialized
DEBUG - 2016-11-26 00:52:07 --> UTF-8 Support Enabled
INFO - 2016-11-26 00:52:07 --> Utf8 Class Initialized
INFO - 2016-11-26 00:52:07 --> URI Class Initialized
DEBUG - 2016-11-26 00:52:07 --> No URI present. Default controller set.
INFO - 2016-11-26 00:52:07 --> Router Class Initialized
INFO - 2016-11-26 00:52:07 --> Output Class Initialized
INFO - 2016-11-26 00:52:07 --> Security Class Initialized
DEBUG - 2016-11-26 00:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 00:52:07 --> Input Class Initialized
INFO - 2016-11-26 00:52:07 --> Language Class Initialized
INFO - 2016-11-26 00:52:07 --> Loader Class Initialized
INFO - 2016-11-26 00:52:07 --> Helper loaded: url_helper
INFO - 2016-11-26 00:52:07 --> Helper loaded: form_helper
INFO - 2016-11-26 00:52:07 --> Database Driver Class Initialized
INFO - 2016-11-26 00:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 00:52:07 --> Controller Class Initialized
INFO - 2016-11-26 00:52:07 --> Model Class Initialized
INFO - 2016-11-26 00:52:07 --> Model Class Initialized
INFO - 2016-11-26 00:52:07 --> Model Class Initialized
INFO - 2016-11-26 00:52:07 --> Model Class Initialized
INFO - 2016-11-26 00:52:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 00:52:07 --> Pagination Class Initialized
INFO - 2016-11-26 00:52:07 --> Helper loaded: app_helper
INFO - 2016-11-26 00:52:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 00:52:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 00:52:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 00:52:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-26 00:52:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-26 00:52:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-26 00:52:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-26 00:52:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 00:52:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 00:52:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 00:52:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 00:52:08 --> Final output sent to browser
DEBUG - 2016-11-26 00:52:08 --> Total execution time: 0.3856
INFO - 2016-11-26 01:00:22 --> Config Class Initialized
INFO - 2016-11-26 01:00:22 --> Hooks Class Initialized
DEBUG - 2016-11-26 01:00:22 --> UTF-8 Support Enabled
INFO - 2016-11-26 01:00:22 --> Utf8 Class Initialized
INFO - 2016-11-26 01:00:22 --> URI Class Initialized
INFO - 2016-11-26 01:00:22 --> Router Class Initialized
INFO - 2016-11-26 01:00:22 --> Output Class Initialized
INFO - 2016-11-26 01:00:22 --> Security Class Initialized
DEBUG - 2016-11-26 01:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 01:00:22 --> Input Class Initialized
INFO - 2016-11-26 01:00:22 --> Language Class Initialized
INFO - 2016-11-26 01:00:22 --> Loader Class Initialized
INFO - 2016-11-26 01:00:22 --> Helper loaded: url_helper
INFO - 2016-11-26 01:00:22 --> Helper loaded: form_helper
INFO - 2016-11-26 01:00:22 --> Database Driver Class Initialized
INFO - 2016-11-26 01:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 01:00:22 --> Controller Class Initialized
INFO - 2016-11-26 01:00:22 --> Model Class Initialized
INFO - 2016-11-26 01:00:22 --> Model Class Initialized
INFO - 2016-11-26 01:00:22 --> Model Class Initialized
INFO - 2016-11-26 01:00:22 --> Model Class Initialized
INFO - 2016-11-26 01:00:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 01:00:22 --> Pagination Class Initialized
INFO - 2016-11-26 01:00:22 --> Helper loaded: app_helper
DEBUG - 2016-11-26 01:00:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-26 01:00:22 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-26 01:00:22 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-26 01:00:22 --> Config Class Initialized
INFO - 2016-11-26 01:00:22 --> Hooks Class Initialized
DEBUG - 2016-11-26 01:00:22 --> UTF-8 Support Enabled
INFO - 2016-11-26 01:00:22 --> Utf8 Class Initialized
INFO - 2016-11-26 01:00:22 --> URI Class Initialized
DEBUG - 2016-11-26 01:00:22 --> No URI present. Default controller set.
INFO - 2016-11-26 01:00:22 --> Router Class Initialized
INFO - 2016-11-26 01:00:22 --> Output Class Initialized
INFO - 2016-11-26 01:00:22 --> Security Class Initialized
DEBUG - 2016-11-26 01:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 01:00:22 --> Input Class Initialized
INFO - 2016-11-26 01:00:22 --> Language Class Initialized
INFO - 2016-11-26 01:00:22 --> Loader Class Initialized
INFO - 2016-11-26 01:00:22 --> Helper loaded: url_helper
INFO - 2016-11-26 01:00:22 --> Helper loaded: form_helper
INFO - 2016-11-26 01:00:22 --> Database Driver Class Initialized
INFO - 2016-11-26 01:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 01:00:22 --> Controller Class Initialized
INFO - 2016-11-26 01:00:22 --> Model Class Initialized
INFO - 2016-11-26 01:00:22 --> Model Class Initialized
INFO - 2016-11-26 01:00:22 --> Model Class Initialized
INFO - 2016-11-26 01:00:22 --> Model Class Initialized
INFO - 2016-11-26 01:00:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 01:00:22 --> Pagination Class Initialized
INFO - 2016-11-26 01:00:22 --> Helper loaded: app_helper
INFO - 2016-11-26 01:00:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 01:00:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-26 01:00:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 01:00:22 --> Final output sent to browser
DEBUG - 2016-11-26 01:00:22 --> Total execution time: 0.3074
INFO - 2016-11-26 10:27:59 --> Config Class Initialized
INFO - 2016-11-26 10:27:59 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:28:00 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:28:00 --> Utf8 Class Initialized
INFO - 2016-11-26 10:28:00 --> URI Class Initialized
DEBUG - 2016-11-26 10:28:00 --> No URI present. Default controller set.
INFO - 2016-11-26 10:28:00 --> Router Class Initialized
INFO - 2016-11-26 10:28:00 --> Output Class Initialized
INFO - 2016-11-26 10:28:00 --> Security Class Initialized
DEBUG - 2016-11-26 10:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:28:00 --> Input Class Initialized
INFO - 2016-11-26 10:28:01 --> Language Class Initialized
INFO - 2016-11-26 10:28:01 --> Loader Class Initialized
INFO - 2016-11-26 10:28:01 --> Helper loaded: url_helper
INFO - 2016-11-26 10:28:01 --> Helper loaded: form_helper
INFO - 2016-11-26 10:28:02 --> Database Driver Class Initialized
INFO - 2016-11-26 10:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:28:02 --> Controller Class Initialized
INFO - 2016-11-26 10:28:02 --> Model Class Initialized
INFO - 2016-11-26 10:28:03 --> Model Class Initialized
INFO - 2016-11-26 10:28:03 --> Model Class Initialized
INFO - 2016-11-26 10:28:03 --> Model Class Initialized
INFO - 2016-11-26 10:28:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 10:28:03 --> Pagination Class Initialized
INFO - 2016-11-26 10:28:03 --> Helper loaded: app_helper
INFO - 2016-11-26 10:28:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 10:28:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-26 10:28:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 10:28:04 --> Final output sent to browser
DEBUG - 2016-11-26 10:28:04 --> Total execution time: 4.4118
INFO - 2016-11-26 10:28:06 --> Config Class Initialized
INFO - 2016-11-26 10:28:06 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:28:06 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:28:06 --> Utf8 Class Initialized
INFO - 2016-11-26 10:28:06 --> URI Class Initialized
DEBUG - 2016-11-26 10:28:06 --> No URI present. Default controller set.
INFO - 2016-11-26 10:28:06 --> Router Class Initialized
INFO - 2016-11-26 10:28:06 --> Output Class Initialized
INFO - 2016-11-26 10:28:06 --> Security Class Initialized
DEBUG - 2016-11-26 10:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:28:06 --> Input Class Initialized
INFO - 2016-11-26 10:28:06 --> Language Class Initialized
INFO - 2016-11-26 10:28:06 --> Loader Class Initialized
INFO - 2016-11-26 10:28:06 --> Helper loaded: url_helper
INFO - 2016-11-26 10:28:06 --> Helper loaded: form_helper
INFO - 2016-11-26 10:28:06 --> Database Driver Class Initialized
INFO - 2016-11-26 10:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:28:06 --> Controller Class Initialized
INFO - 2016-11-26 10:28:06 --> Model Class Initialized
INFO - 2016-11-26 10:28:06 --> Model Class Initialized
INFO - 2016-11-26 10:28:06 --> Model Class Initialized
INFO - 2016-11-26 10:28:06 --> Model Class Initialized
INFO - 2016-11-26 10:28:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 10:28:06 --> Pagination Class Initialized
INFO - 2016-11-26 10:28:06 --> Helper loaded: app_helper
INFO - 2016-11-26 10:28:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 10:28:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-26 10:28:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 10:28:07 --> Final output sent to browser
DEBUG - 2016-11-26 10:28:07 --> Total execution time: 0.5449
INFO - 2016-11-26 10:28:19 --> Config Class Initialized
INFO - 2016-11-26 10:28:19 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:28:19 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:28:19 --> Utf8 Class Initialized
INFO - 2016-11-26 10:28:19 --> URI Class Initialized
INFO - 2016-11-26 10:28:19 --> Router Class Initialized
INFO - 2016-11-26 10:28:19 --> Output Class Initialized
INFO - 2016-11-26 10:28:19 --> Security Class Initialized
DEBUG - 2016-11-26 10:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:28:19 --> Input Class Initialized
INFO - 2016-11-26 10:28:19 --> Language Class Initialized
INFO - 2016-11-26 10:28:19 --> Loader Class Initialized
INFO - 2016-11-26 10:28:19 --> Helper loaded: url_helper
INFO - 2016-11-26 10:28:19 --> Helper loaded: form_helper
INFO - 2016-11-26 10:28:19 --> Database Driver Class Initialized
INFO - 2016-11-26 10:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:28:19 --> Controller Class Initialized
INFO - 2016-11-26 10:28:19 --> Model Class Initialized
INFO - 2016-11-26 10:28:19 --> Model Class Initialized
INFO - 2016-11-26 10:28:19 --> Model Class Initialized
INFO - 2016-11-26 10:28:19 --> Model Class Initialized
INFO - 2016-11-26 10:28:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 10:28:19 --> Pagination Class Initialized
INFO - 2016-11-26 10:28:19 --> Helper loaded: app_helper
DEBUG - 2016-11-26 10:28:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-26 10:28:19 --> Model Class Initialized
INFO - 2016-11-26 10:28:20 --> Final output sent to browser
DEBUG - 2016-11-26 10:28:20 --> Total execution time: 0.8534
INFO - 2016-11-26 10:28:20 --> Config Class Initialized
INFO - 2016-11-26 10:28:20 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:28:20 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:28:20 --> Utf8 Class Initialized
INFO - 2016-11-26 10:28:20 --> URI Class Initialized
DEBUG - 2016-11-26 10:28:20 --> No URI present. Default controller set.
INFO - 2016-11-26 10:28:20 --> Router Class Initialized
INFO - 2016-11-26 10:28:20 --> Output Class Initialized
INFO - 2016-11-26 10:28:20 --> Security Class Initialized
DEBUG - 2016-11-26 10:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:28:20 --> Input Class Initialized
INFO - 2016-11-26 10:28:20 --> Language Class Initialized
INFO - 2016-11-26 10:28:20 --> Loader Class Initialized
INFO - 2016-11-26 10:28:20 --> Helper loaded: url_helper
INFO - 2016-11-26 10:28:20 --> Helper loaded: form_helper
INFO - 2016-11-26 10:28:20 --> Database Driver Class Initialized
INFO - 2016-11-26 10:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:28:20 --> Controller Class Initialized
INFO - 2016-11-26 10:28:20 --> Model Class Initialized
INFO - 2016-11-26 10:28:20 --> Model Class Initialized
INFO - 2016-11-26 10:28:20 --> Model Class Initialized
INFO - 2016-11-26 10:28:20 --> Model Class Initialized
INFO - 2016-11-26 10:28:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 10:28:20 --> Pagination Class Initialized
INFO - 2016-11-26 10:28:20 --> Helper loaded: app_helper
INFO - 2016-11-26 10:28:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 10:28:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 10:28:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 10:28:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 10:28:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 10:28:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 10:28:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 10:28:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 10:28:22 --> Final output sent to browser
DEBUG - 2016-11-26 10:28:22 --> Total execution time: 1.6561
INFO - 2016-11-26 10:28:34 --> Config Class Initialized
INFO - 2016-11-26 10:28:34 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:28:34 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:28:34 --> Utf8 Class Initialized
INFO - 2016-11-26 10:28:34 --> URI Class Initialized
INFO - 2016-11-26 10:28:34 --> Router Class Initialized
INFO - 2016-11-26 10:28:34 --> Output Class Initialized
INFO - 2016-11-26 10:28:34 --> Security Class Initialized
DEBUG - 2016-11-26 10:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:28:34 --> Input Class Initialized
INFO - 2016-11-26 10:28:34 --> Language Class Initialized
INFO - 2016-11-26 10:28:34 --> Loader Class Initialized
INFO - 2016-11-26 10:28:34 --> Helper loaded: url_helper
INFO - 2016-11-26 10:28:34 --> Helper loaded: form_helper
INFO - 2016-11-26 10:28:34 --> Database Driver Class Initialized
INFO - 2016-11-26 10:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:28:34 --> Controller Class Initialized
INFO - 2016-11-26 10:28:34 --> Model Class Initialized
INFO - 2016-11-26 10:28:35 --> Form Validation Class Initialized
INFO - 2016-11-26 10:28:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-26 10:28:35 --> Final output sent to browser
DEBUG - 2016-11-26 10:28:35 --> Total execution time: 0.5306
INFO - 2016-11-26 10:31:02 --> Config Class Initialized
INFO - 2016-11-26 10:31:02 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:31:02 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:31:02 --> Utf8 Class Initialized
INFO - 2016-11-26 10:31:02 --> URI Class Initialized
DEBUG - 2016-11-26 10:31:02 --> No URI present. Default controller set.
INFO - 2016-11-26 10:31:02 --> Router Class Initialized
INFO - 2016-11-26 10:31:02 --> Output Class Initialized
INFO - 2016-11-26 10:31:02 --> Security Class Initialized
DEBUG - 2016-11-26 10:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:31:02 --> Input Class Initialized
INFO - 2016-11-26 10:31:02 --> Language Class Initialized
INFO - 2016-11-26 10:31:02 --> Loader Class Initialized
INFO - 2016-11-26 10:31:02 --> Helper loaded: url_helper
INFO - 2016-11-26 10:31:02 --> Helper loaded: form_helper
INFO - 2016-11-26 10:31:02 --> Database Driver Class Initialized
INFO - 2016-11-26 10:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:31:03 --> Controller Class Initialized
INFO - 2016-11-26 10:31:03 --> Model Class Initialized
INFO - 2016-11-26 10:31:03 --> Model Class Initialized
INFO - 2016-11-26 10:31:03 --> Model Class Initialized
INFO - 2016-11-26 10:31:03 --> Model Class Initialized
INFO - 2016-11-26 10:31:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 10:31:03 --> Pagination Class Initialized
INFO - 2016-11-26 10:31:03 --> Helper loaded: app_helper
INFO - 2016-11-26 10:31:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 10:31:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 10:31:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 10:31:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 10:31:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 10:31:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 10:31:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 10:31:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 10:31:03 --> Final output sent to browser
DEBUG - 2016-11-26 10:31:03 --> Total execution time: 0.4130
INFO - 2016-11-26 10:31:08 --> Config Class Initialized
INFO - 2016-11-26 10:31:08 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:31:08 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:31:08 --> Utf8 Class Initialized
INFO - 2016-11-26 10:31:08 --> URI Class Initialized
INFO - 2016-11-26 10:31:08 --> Router Class Initialized
INFO - 2016-11-26 10:31:08 --> Output Class Initialized
INFO - 2016-11-26 10:31:08 --> Security Class Initialized
DEBUG - 2016-11-26 10:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:31:08 --> Input Class Initialized
INFO - 2016-11-26 10:31:08 --> Language Class Initialized
INFO - 2016-11-26 10:31:08 --> Loader Class Initialized
INFO - 2016-11-26 10:31:08 --> Helper loaded: url_helper
INFO - 2016-11-26 10:31:08 --> Helper loaded: form_helper
INFO - 2016-11-26 10:31:08 --> Database Driver Class Initialized
INFO - 2016-11-26 10:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:31:08 --> Controller Class Initialized
INFO - 2016-11-26 10:31:08 --> Model Class Initialized
INFO - 2016-11-26 10:31:08 --> Model Class Initialized
INFO - 2016-11-26 10:31:08 --> Model Class Initialized
INFO - 2016-11-26 10:31:08 --> Model Class Initialized
INFO - 2016-11-26 10:31:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 10:31:08 --> Pagination Class Initialized
INFO - 2016-11-26 10:31:08 --> Helper loaded: app_helper
DEBUG - 2016-11-26 10:31:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-26 10:31:08 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-26 10:31:08 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-26 10:31:08 --> Config Class Initialized
INFO - 2016-11-26 10:31:08 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:31:08 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:31:08 --> Utf8 Class Initialized
INFO - 2016-11-26 10:31:08 --> URI Class Initialized
DEBUG - 2016-11-26 10:31:08 --> No URI present. Default controller set.
INFO - 2016-11-26 10:31:08 --> Router Class Initialized
INFO - 2016-11-26 10:31:08 --> Output Class Initialized
INFO - 2016-11-26 10:31:08 --> Security Class Initialized
DEBUG - 2016-11-26 10:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:31:08 --> Input Class Initialized
INFO - 2016-11-26 10:31:09 --> Language Class Initialized
INFO - 2016-11-26 10:31:09 --> Loader Class Initialized
INFO - 2016-11-26 10:31:09 --> Helper loaded: url_helper
INFO - 2016-11-26 10:31:09 --> Helper loaded: form_helper
INFO - 2016-11-26 10:31:09 --> Database Driver Class Initialized
INFO - 2016-11-26 10:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:31:09 --> Controller Class Initialized
INFO - 2016-11-26 10:31:09 --> Model Class Initialized
INFO - 2016-11-26 10:31:09 --> Model Class Initialized
INFO - 2016-11-26 10:31:09 --> Model Class Initialized
INFO - 2016-11-26 10:31:09 --> Model Class Initialized
INFO - 2016-11-26 10:31:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 10:31:09 --> Pagination Class Initialized
INFO - 2016-11-26 10:31:09 --> Helper loaded: app_helper
INFO - 2016-11-26 10:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 10:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-26 10:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 10:31:09 --> Final output sent to browser
DEBUG - 2016-11-26 10:31:09 --> Total execution time: 0.8370
INFO - 2016-11-26 10:31:17 --> Config Class Initialized
INFO - 2016-11-26 10:31:17 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:31:17 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:31:17 --> Utf8 Class Initialized
INFO - 2016-11-26 10:31:17 --> URI Class Initialized
INFO - 2016-11-26 10:31:17 --> Router Class Initialized
INFO - 2016-11-26 10:31:17 --> Output Class Initialized
INFO - 2016-11-26 10:31:17 --> Security Class Initialized
DEBUG - 2016-11-26 10:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:31:17 --> Input Class Initialized
INFO - 2016-11-26 10:31:17 --> Language Class Initialized
INFO - 2016-11-26 10:31:17 --> Loader Class Initialized
INFO - 2016-11-26 10:31:17 --> Helper loaded: url_helper
INFO - 2016-11-26 10:31:17 --> Helper loaded: form_helper
INFO - 2016-11-26 10:31:17 --> Database Driver Class Initialized
INFO - 2016-11-26 10:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:31:17 --> Controller Class Initialized
INFO - 2016-11-26 10:31:17 --> Model Class Initialized
INFO - 2016-11-26 10:31:17 --> Model Class Initialized
INFO - 2016-11-26 10:31:17 --> Model Class Initialized
INFO - 2016-11-26 10:31:17 --> Model Class Initialized
INFO - 2016-11-26 10:31:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 10:31:17 --> Pagination Class Initialized
INFO - 2016-11-26 10:31:17 --> Helper loaded: app_helper
DEBUG - 2016-11-26 10:31:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-26 10:31:17 --> Model Class Initialized
INFO - 2016-11-26 10:31:17 --> Final output sent to browser
DEBUG - 2016-11-26 10:31:17 --> Total execution time: 0.2678
INFO - 2016-11-26 10:31:17 --> Config Class Initialized
INFO - 2016-11-26 10:31:17 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:31:17 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:31:17 --> Utf8 Class Initialized
INFO - 2016-11-26 10:31:17 --> URI Class Initialized
DEBUG - 2016-11-26 10:31:17 --> No URI present. Default controller set.
INFO - 2016-11-26 10:31:17 --> Router Class Initialized
INFO - 2016-11-26 10:31:17 --> Output Class Initialized
INFO - 2016-11-26 10:31:17 --> Security Class Initialized
DEBUG - 2016-11-26 10:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:31:17 --> Input Class Initialized
INFO - 2016-11-26 10:31:17 --> Language Class Initialized
INFO - 2016-11-26 10:31:17 --> Loader Class Initialized
INFO - 2016-11-26 10:31:17 --> Helper loaded: url_helper
INFO - 2016-11-26 10:31:17 --> Helper loaded: form_helper
INFO - 2016-11-26 10:31:17 --> Database Driver Class Initialized
INFO - 2016-11-26 10:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:31:17 --> Controller Class Initialized
INFO - 2016-11-26 10:31:17 --> Model Class Initialized
INFO - 2016-11-26 10:31:17 --> Model Class Initialized
INFO - 2016-11-26 10:31:17 --> Model Class Initialized
INFO - 2016-11-26 10:31:17 --> Model Class Initialized
INFO - 2016-11-26 10:31:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 10:31:17 --> Pagination Class Initialized
INFO - 2016-11-26 10:31:17 --> Helper loaded: app_helper
INFO - 2016-11-26 10:31:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 10:31:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 10:31:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 10:31:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-26 10:31:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-26 10:31:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-26 10:31:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-26 10:31:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 10:31:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 10:31:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 10:31:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 10:31:18 --> Final output sent to browser
DEBUG - 2016-11-26 10:31:18 --> Total execution time: 0.7162
INFO - 2016-11-26 10:33:19 --> Config Class Initialized
INFO - 2016-11-26 10:33:19 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:33:19 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:33:19 --> Utf8 Class Initialized
INFO - 2016-11-26 10:33:19 --> URI Class Initialized
DEBUG - 2016-11-26 10:33:19 --> No URI present. Default controller set.
INFO - 2016-11-26 10:33:19 --> Router Class Initialized
INFO - 2016-11-26 10:33:20 --> Output Class Initialized
INFO - 2016-11-26 10:33:20 --> Security Class Initialized
DEBUG - 2016-11-26 10:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:33:20 --> Input Class Initialized
INFO - 2016-11-26 10:33:20 --> Language Class Initialized
INFO - 2016-11-26 10:33:20 --> Loader Class Initialized
INFO - 2016-11-26 10:33:20 --> Helper loaded: url_helper
INFO - 2016-11-26 10:33:20 --> Helper loaded: form_helper
INFO - 2016-11-26 10:33:20 --> Database Driver Class Initialized
INFO - 2016-11-26 10:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:33:20 --> Controller Class Initialized
INFO - 2016-11-26 10:33:20 --> Model Class Initialized
INFO - 2016-11-26 10:33:20 --> Model Class Initialized
INFO - 2016-11-26 10:33:20 --> Model Class Initialized
INFO - 2016-11-26 10:33:20 --> Model Class Initialized
INFO - 2016-11-26 10:33:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 10:33:20 --> Pagination Class Initialized
INFO - 2016-11-26 10:33:20 --> Helper loaded: app_helper
INFO - 2016-11-26 10:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 10:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 10:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 10:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-26 10:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-26 10:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-26 10:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-26 10:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 10:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 10:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 10:33:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 10:33:20 --> Final output sent to browser
DEBUG - 2016-11-26 10:33:20 --> Total execution time: 0.9006
INFO - 2016-11-26 10:38:47 --> Config Class Initialized
INFO - 2016-11-26 10:38:47 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:38:47 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:38:47 --> Utf8 Class Initialized
INFO - 2016-11-26 10:38:47 --> URI Class Initialized
DEBUG - 2016-11-26 10:38:47 --> No URI present. Default controller set.
INFO - 2016-11-26 10:38:47 --> Router Class Initialized
INFO - 2016-11-26 10:38:47 --> Output Class Initialized
INFO - 2016-11-26 10:38:47 --> Security Class Initialized
DEBUG - 2016-11-26 10:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:38:47 --> Input Class Initialized
INFO - 2016-11-26 10:38:47 --> Language Class Initialized
INFO - 2016-11-26 10:38:48 --> Loader Class Initialized
INFO - 2016-11-26 10:38:48 --> Helper loaded: url_helper
INFO - 2016-11-26 10:38:48 --> Helper loaded: form_helper
INFO - 2016-11-26 10:38:48 --> Database Driver Class Initialized
INFO - 2016-11-26 10:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:38:48 --> Controller Class Initialized
INFO - 2016-11-26 10:38:48 --> Model Class Initialized
INFO - 2016-11-26 10:38:48 --> Model Class Initialized
INFO - 2016-11-26 10:38:48 --> Model Class Initialized
INFO - 2016-11-26 10:38:48 --> Model Class Initialized
INFO - 2016-11-26 10:38:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 10:38:48 --> Pagination Class Initialized
INFO - 2016-11-26 10:38:48 --> Helper loaded: app_helper
INFO - 2016-11-26 10:38:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 10:38:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 10:38:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 10:38:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-26 10:38:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-26 10:38:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-26 10:38:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-26 10:38:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 10:38:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 10:38:48 --> Final output sent to browser
DEBUG - 2016-11-26 10:38:48 --> Total execution time: 0.3982
INFO - 2016-11-26 10:38:56 --> Config Class Initialized
INFO - 2016-11-26 10:38:56 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:38:56 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:38:56 --> Utf8 Class Initialized
INFO - 2016-11-26 10:38:56 --> URI Class Initialized
INFO - 2016-11-26 10:38:56 --> Router Class Initialized
INFO - 2016-11-26 10:38:56 --> Output Class Initialized
INFO - 2016-11-26 10:38:56 --> Security Class Initialized
DEBUG - 2016-11-26 10:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:38:56 --> Input Class Initialized
INFO - 2016-11-26 10:38:56 --> Language Class Initialized
INFO - 2016-11-26 10:38:56 --> Loader Class Initialized
INFO - 2016-11-26 10:38:56 --> Helper loaded: url_helper
INFO - 2016-11-26 10:38:56 --> Helper loaded: form_helper
INFO - 2016-11-26 10:38:56 --> Database Driver Class Initialized
INFO - 2016-11-26 10:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:38:57 --> Controller Class Initialized
INFO - 2016-11-26 10:38:57 --> Model Class Initialized
INFO - 2016-11-26 10:38:57 --> Model Class Initialized
INFO - 2016-11-26 10:38:57 --> Model Class Initialized
INFO - 2016-11-26 10:38:57 --> Model Class Initialized
INFO - 2016-11-26 10:38:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 10:38:57 --> Pagination Class Initialized
INFO - 2016-11-26 10:38:57 --> Helper loaded: app_helper
DEBUG - 2016-11-26 10:38:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-26 10:38:57 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-26 10:38:57 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-26 10:38:57 --> Config Class Initialized
INFO - 2016-11-26 10:38:57 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:38:57 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:38:57 --> Utf8 Class Initialized
INFO - 2016-11-26 10:38:57 --> URI Class Initialized
DEBUG - 2016-11-26 10:38:57 --> No URI present. Default controller set.
INFO - 2016-11-26 10:38:57 --> Router Class Initialized
INFO - 2016-11-26 10:38:57 --> Output Class Initialized
INFO - 2016-11-26 10:38:57 --> Security Class Initialized
DEBUG - 2016-11-26 10:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:38:57 --> Input Class Initialized
INFO - 2016-11-26 10:38:57 --> Language Class Initialized
INFO - 2016-11-26 10:38:57 --> Loader Class Initialized
INFO - 2016-11-26 10:38:57 --> Helper loaded: url_helper
INFO - 2016-11-26 10:38:57 --> Helper loaded: form_helper
INFO - 2016-11-26 10:38:57 --> Database Driver Class Initialized
INFO - 2016-11-26 10:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:38:57 --> Controller Class Initialized
INFO - 2016-11-26 10:38:57 --> Model Class Initialized
INFO - 2016-11-26 10:38:57 --> Model Class Initialized
INFO - 2016-11-26 10:38:57 --> Model Class Initialized
INFO - 2016-11-26 10:38:57 --> Model Class Initialized
INFO - 2016-11-26 10:38:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 10:38:57 --> Pagination Class Initialized
INFO - 2016-11-26 10:38:57 --> Helper loaded: app_helper
INFO - 2016-11-26 10:38:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 10:38:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-26 10:38:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 10:38:57 --> Final output sent to browser
DEBUG - 2016-11-26 10:38:57 --> Total execution time: 0.5312
INFO - 2016-11-26 10:39:03 --> Config Class Initialized
INFO - 2016-11-26 10:39:03 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:39:03 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:39:03 --> Utf8 Class Initialized
INFO - 2016-11-26 10:39:03 --> URI Class Initialized
INFO - 2016-11-26 10:39:03 --> Router Class Initialized
INFO - 2016-11-26 10:39:03 --> Output Class Initialized
INFO - 2016-11-26 10:39:03 --> Security Class Initialized
DEBUG - 2016-11-26 10:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:39:03 --> Input Class Initialized
INFO - 2016-11-26 10:39:03 --> Language Class Initialized
INFO - 2016-11-26 10:39:03 --> Loader Class Initialized
INFO - 2016-11-26 10:39:03 --> Helper loaded: url_helper
INFO - 2016-11-26 10:39:03 --> Helper loaded: form_helper
INFO - 2016-11-26 10:39:03 --> Database Driver Class Initialized
INFO - 2016-11-26 10:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:39:03 --> Controller Class Initialized
INFO - 2016-11-26 10:39:03 --> Model Class Initialized
INFO - 2016-11-26 10:39:03 --> Model Class Initialized
INFO - 2016-11-26 10:39:03 --> Model Class Initialized
INFO - 2016-11-26 10:39:03 --> Model Class Initialized
INFO - 2016-11-26 10:39:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 10:39:03 --> Pagination Class Initialized
INFO - 2016-11-26 10:39:03 --> Helper loaded: app_helper
DEBUG - 2016-11-26 10:39:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-26 10:39:03 --> Model Class Initialized
INFO - 2016-11-26 10:39:03 --> Final output sent to browser
DEBUG - 2016-11-26 10:39:03 --> Total execution time: 0.2891
INFO - 2016-11-26 10:39:03 --> Config Class Initialized
INFO - 2016-11-26 10:39:03 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:39:03 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:39:03 --> Utf8 Class Initialized
INFO - 2016-11-26 10:39:03 --> URI Class Initialized
DEBUG - 2016-11-26 10:39:03 --> No URI present. Default controller set.
INFO - 2016-11-26 10:39:03 --> Router Class Initialized
INFO - 2016-11-26 10:39:03 --> Output Class Initialized
INFO - 2016-11-26 10:39:03 --> Security Class Initialized
DEBUG - 2016-11-26 10:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:39:03 --> Input Class Initialized
INFO - 2016-11-26 10:39:03 --> Language Class Initialized
INFO - 2016-11-26 10:39:03 --> Loader Class Initialized
INFO - 2016-11-26 10:39:03 --> Helper loaded: url_helper
INFO - 2016-11-26 10:39:03 --> Helper loaded: form_helper
INFO - 2016-11-26 10:39:03 --> Database Driver Class Initialized
INFO - 2016-11-26 10:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:39:03 --> Controller Class Initialized
INFO - 2016-11-26 10:39:03 --> Model Class Initialized
INFO - 2016-11-26 10:39:03 --> Model Class Initialized
INFO - 2016-11-26 10:39:03 --> Model Class Initialized
INFO - 2016-11-26 10:39:03 --> Model Class Initialized
INFO - 2016-11-26 10:39:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 10:39:03 --> Pagination Class Initialized
INFO - 2016-11-26 10:39:03 --> Helper loaded: app_helper
INFO - 2016-11-26 10:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 10:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 10:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 10:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 10:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 10:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 10:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 10:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 10:39:03 --> Final output sent to browser
DEBUG - 2016-11-26 10:39:03 --> Total execution time: 0.3891
INFO - 2016-11-26 10:40:58 --> Config Class Initialized
INFO - 2016-11-26 10:40:58 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:40:58 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:40:58 --> Utf8 Class Initialized
INFO - 2016-11-26 10:40:58 --> URI Class Initialized
DEBUG - 2016-11-26 10:40:58 --> No URI present. Default controller set.
INFO - 2016-11-26 10:40:58 --> Router Class Initialized
INFO - 2016-11-26 10:40:58 --> Output Class Initialized
INFO - 2016-11-26 10:40:58 --> Security Class Initialized
DEBUG - 2016-11-26 10:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:40:58 --> Input Class Initialized
INFO - 2016-11-26 10:40:58 --> Language Class Initialized
INFO - 2016-11-26 10:40:58 --> Loader Class Initialized
INFO - 2016-11-26 10:40:58 --> Helper loaded: url_helper
INFO - 2016-11-26 10:40:58 --> Helper loaded: form_helper
INFO - 2016-11-26 10:40:58 --> Database Driver Class Initialized
INFO - 2016-11-26 10:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:40:58 --> Controller Class Initialized
INFO - 2016-11-26 10:40:58 --> Model Class Initialized
INFO - 2016-11-26 10:40:58 --> Model Class Initialized
INFO - 2016-11-26 10:40:58 --> Model Class Initialized
INFO - 2016-11-26 10:40:58 --> Model Class Initialized
INFO - 2016-11-26 10:40:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 10:40:58 --> Pagination Class Initialized
INFO - 2016-11-26 10:40:58 --> Helper loaded: app_helper
INFO - 2016-11-26 10:40:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 10:40:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 10:40:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 10:40:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 10:40:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 10:40:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 10:40:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 10:40:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 10:40:58 --> Final output sent to browser
DEBUG - 2016-11-26 10:40:58 --> Total execution time: 0.4182
INFO - 2016-11-26 10:41:02 --> Config Class Initialized
INFO - 2016-11-26 10:41:03 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:41:03 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:41:03 --> Utf8 Class Initialized
INFO - 2016-11-26 10:41:03 --> URI Class Initialized
INFO - 2016-11-26 10:41:03 --> Router Class Initialized
INFO - 2016-11-26 10:41:03 --> Output Class Initialized
INFO - 2016-11-26 10:41:03 --> Security Class Initialized
DEBUG - 2016-11-26 10:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:41:03 --> Input Class Initialized
INFO - 2016-11-26 10:41:03 --> Language Class Initialized
INFO - 2016-11-26 10:41:03 --> Loader Class Initialized
INFO - 2016-11-26 10:41:03 --> Helper loaded: url_helper
INFO - 2016-11-26 10:41:03 --> Helper loaded: form_helper
INFO - 2016-11-26 10:41:03 --> Database Driver Class Initialized
INFO - 2016-11-26 10:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:41:03 --> Controller Class Initialized
INFO - 2016-11-26 10:41:03 --> Model Class Initialized
INFO - 2016-11-26 10:41:03 --> Form Validation Class Initialized
INFO - 2016-11-26 10:41:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-26 10:41:03 --> Final output sent to browser
DEBUG - 2016-11-26 10:41:03 --> Total execution time: 0.2190
INFO - 2016-11-26 10:41:04 --> Config Class Initialized
INFO - 2016-11-26 10:41:04 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:41:04 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:41:04 --> Utf8 Class Initialized
INFO - 2016-11-26 10:41:04 --> URI Class Initialized
DEBUG - 2016-11-26 10:41:04 --> No URI present. Default controller set.
INFO - 2016-11-26 10:41:04 --> Router Class Initialized
INFO - 2016-11-26 10:41:04 --> Output Class Initialized
INFO - 2016-11-26 10:41:04 --> Security Class Initialized
DEBUG - 2016-11-26 10:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:41:04 --> Input Class Initialized
INFO - 2016-11-26 10:41:04 --> Language Class Initialized
INFO - 2016-11-26 10:41:04 --> Loader Class Initialized
INFO - 2016-11-26 10:41:04 --> Helper loaded: url_helper
INFO - 2016-11-26 10:41:04 --> Helper loaded: form_helper
INFO - 2016-11-26 10:41:04 --> Database Driver Class Initialized
INFO - 2016-11-26 10:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:41:04 --> Controller Class Initialized
INFO - 2016-11-26 10:41:04 --> Model Class Initialized
INFO - 2016-11-26 10:41:04 --> Model Class Initialized
INFO - 2016-11-26 10:41:04 --> Model Class Initialized
INFO - 2016-11-26 10:41:04 --> Model Class Initialized
INFO - 2016-11-26 10:41:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 10:41:04 --> Pagination Class Initialized
INFO - 2016-11-26 10:41:04 --> Helper loaded: app_helper
INFO - 2016-11-26 10:41:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 10:41:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 10:41:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 10:41:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 10:41:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 10:41:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 10:41:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 10:41:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 10:41:04 --> Final output sent to browser
DEBUG - 2016-11-26 10:41:04 --> Total execution time: 0.4465
INFO - 2016-11-26 10:43:54 --> Config Class Initialized
INFO - 2016-11-26 10:43:54 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:43:54 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:43:54 --> Utf8 Class Initialized
INFO - 2016-11-26 10:43:54 --> URI Class Initialized
DEBUG - 2016-11-26 10:43:54 --> No URI present. Default controller set.
INFO - 2016-11-26 10:43:54 --> Router Class Initialized
INFO - 2016-11-26 10:43:54 --> Output Class Initialized
INFO - 2016-11-26 10:43:54 --> Security Class Initialized
DEBUG - 2016-11-26 10:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:43:54 --> Input Class Initialized
INFO - 2016-11-26 10:43:55 --> Language Class Initialized
INFO - 2016-11-26 10:43:55 --> Loader Class Initialized
INFO - 2016-11-26 10:43:55 --> Helper loaded: url_helper
INFO - 2016-11-26 10:43:55 --> Helper loaded: form_helper
INFO - 2016-11-26 10:43:55 --> Database Driver Class Initialized
INFO - 2016-11-26 10:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:43:55 --> Controller Class Initialized
INFO - 2016-11-26 10:43:55 --> Model Class Initialized
INFO - 2016-11-26 10:43:55 --> Model Class Initialized
INFO - 2016-11-26 10:43:55 --> Model Class Initialized
INFO - 2016-11-26 10:43:55 --> Model Class Initialized
INFO - 2016-11-26 10:43:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 10:43:55 --> Pagination Class Initialized
INFO - 2016-11-26 10:43:55 --> Helper loaded: app_helper
INFO - 2016-11-26 10:43:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 10:43:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 10:43:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 10:43:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 10:43:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 10:43:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 10:43:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 10:43:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 10:43:55 --> Final output sent to browser
DEBUG - 2016-11-26 10:43:55 --> Total execution time: 0.3941
INFO - 2016-11-26 10:43:59 --> Config Class Initialized
INFO - 2016-11-26 10:43:59 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:43:59 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:43:59 --> Utf8 Class Initialized
INFO - 2016-11-26 10:43:59 --> URI Class Initialized
INFO - 2016-11-26 10:43:59 --> Router Class Initialized
INFO - 2016-11-26 10:43:59 --> Output Class Initialized
INFO - 2016-11-26 10:43:59 --> Security Class Initialized
DEBUG - 2016-11-26 10:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:43:59 --> Input Class Initialized
INFO - 2016-11-26 10:43:59 --> Language Class Initialized
INFO - 2016-11-26 10:43:59 --> Loader Class Initialized
INFO - 2016-11-26 10:43:59 --> Helper loaded: url_helper
INFO - 2016-11-26 10:43:59 --> Helper loaded: form_helper
INFO - 2016-11-26 10:43:59 --> Database Driver Class Initialized
INFO - 2016-11-26 10:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:44:00 --> Controller Class Initialized
INFO - 2016-11-26 10:44:00 --> Model Class Initialized
ERROR - 2016-11-26 10:44:00 --> Severity: Error --> Call to undefined function ajax_pagination() C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 108
INFO - 2016-11-26 10:46:04 --> Config Class Initialized
INFO - 2016-11-26 10:46:04 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:46:04 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:46:04 --> Utf8 Class Initialized
INFO - 2016-11-26 10:46:04 --> URI Class Initialized
DEBUG - 2016-11-26 10:46:04 --> No URI present. Default controller set.
INFO - 2016-11-26 10:46:04 --> Router Class Initialized
INFO - 2016-11-26 10:46:04 --> Output Class Initialized
INFO - 2016-11-26 10:46:04 --> Security Class Initialized
DEBUG - 2016-11-26 10:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:46:04 --> Input Class Initialized
INFO - 2016-11-26 10:46:04 --> Language Class Initialized
INFO - 2016-11-26 10:46:04 --> Loader Class Initialized
INFO - 2016-11-26 10:46:04 --> Helper loaded: url_helper
INFO - 2016-11-26 10:46:04 --> Helper loaded: form_helper
INFO - 2016-11-26 10:46:04 --> Database Driver Class Initialized
INFO - 2016-11-26 10:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:46:04 --> Controller Class Initialized
INFO - 2016-11-26 10:46:04 --> Model Class Initialized
INFO - 2016-11-26 10:46:04 --> Model Class Initialized
INFO - 2016-11-26 10:46:04 --> Model Class Initialized
INFO - 2016-11-26 10:46:04 --> Model Class Initialized
INFO - 2016-11-26 10:46:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 10:46:04 --> Pagination Class Initialized
INFO - 2016-11-26 10:46:04 --> Helper loaded: app_helper
INFO - 2016-11-26 10:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 10:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 10:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 10:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 10:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 10:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 10:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 10:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 10:46:04 --> Final output sent to browser
DEBUG - 2016-11-26 10:46:04 --> Total execution time: 0.4020
INFO - 2016-11-26 10:46:07 --> Config Class Initialized
INFO - 2016-11-26 10:46:07 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:46:07 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:46:07 --> Utf8 Class Initialized
INFO - 2016-11-26 10:46:07 --> URI Class Initialized
INFO - 2016-11-26 10:46:07 --> Router Class Initialized
INFO - 2016-11-26 10:46:08 --> Output Class Initialized
INFO - 2016-11-26 10:46:08 --> Security Class Initialized
DEBUG - 2016-11-26 10:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:46:08 --> Input Class Initialized
INFO - 2016-11-26 10:46:08 --> Language Class Initialized
INFO - 2016-11-26 10:46:08 --> Loader Class Initialized
INFO - 2016-11-26 10:46:08 --> Helper loaded: url_helper
INFO - 2016-11-26 10:46:08 --> Helper loaded: form_helper
INFO - 2016-11-26 10:46:08 --> Database Driver Class Initialized
INFO - 2016-11-26 10:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:46:08 --> Controller Class Initialized
INFO - 2016-11-26 10:46:08 --> Model Class Initialized
ERROR - 2016-11-26 10:46:08 --> Severity: Error --> Call to undefined function ajax_pagination() C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 108
INFO - 2016-11-26 10:49:26 --> Config Class Initialized
INFO - 2016-11-26 10:49:26 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:49:26 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:49:26 --> Utf8 Class Initialized
INFO - 2016-11-26 10:49:26 --> URI Class Initialized
DEBUG - 2016-11-26 10:49:26 --> No URI present. Default controller set.
INFO - 2016-11-26 10:49:26 --> Router Class Initialized
INFO - 2016-11-26 10:49:26 --> Output Class Initialized
INFO - 2016-11-26 10:49:26 --> Security Class Initialized
DEBUG - 2016-11-26 10:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:49:26 --> Input Class Initialized
INFO - 2016-11-26 10:49:26 --> Language Class Initialized
INFO - 2016-11-26 10:49:26 --> Loader Class Initialized
INFO - 2016-11-26 10:49:26 --> Helper loaded: url_helper
INFO - 2016-11-26 10:49:26 --> Helper loaded: form_helper
INFO - 2016-11-26 10:49:26 --> Database Driver Class Initialized
INFO - 2016-11-26 10:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:49:26 --> Controller Class Initialized
INFO - 2016-11-26 10:49:26 --> Model Class Initialized
INFO - 2016-11-26 10:49:26 --> Model Class Initialized
INFO - 2016-11-26 10:49:26 --> Model Class Initialized
INFO - 2016-11-26 10:49:26 --> Model Class Initialized
INFO - 2016-11-26 10:49:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 10:49:26 --> Pagination Class Initialized
INFO - 2016-11-26 10:49:26 --> Helper loaded: app_helper
INFO - 2016-11-26 10:49:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 10:49:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 10:49:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 10:49:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 10:49:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 10:49:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 10:49:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 10:49:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 10:49:26 --> Final output sent to browser
DEBUG - 2016-11-26 10:49:26 --> Total execution time: 0.4244
INFO - 2016-11-26 10:49:30 --> Config Class Initialized
INFO - 2016-11-26 10:49:30 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:49:30 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:49:30 --> Utf8 Class Initialized
INFO - 2016-11-26 10:49:30 --> URI Class Initialized
INFO - 2016-11-26 10:49:30 --> Router Class Initialized
INFO - 2016-11-26 10:49:30 --> Output Class Initialized
INFO - 2016-11-26 10:49:30 --> Security Class Initialized
DEBUG - 2016-11-26 10:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:49:30 --> Input Class Initialized
INFO - 2016-11-26 10:49:30 --> Language Class Initialized
INFO - 2016-11-26 10:49:30 --> Loader Class Initialized
INFO - 2016-11-26 10:49:30 --> Helper loaded: url_helper
INFO - 2016-11-26 10:49:30 --> Helper loaded: form_helper
INFO - 2016-11-26 10:49:30 --> Database Driver Class Initialized
INFO - 2016-11-26 10:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:49:30 --> Controller Class Initialized
INFO - 2016-11-26 10:49:30 --> Model Class Initialized
ERROR - 2016-11-26 10:49:30 --> Severity: Error --> Call to undefined function ajax_pagination() C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 108
INFO - 2016-11-26 10:49:34 --> Config Class Initialized
INFO - 2016-11-26 10:49:34 --> Hooks Class Initialized
DEBUG - 2016-11-26 10:49:34 --> UTF-8 Support Enabled
INFO - 2016-11-26 10:49:34 --> Utf8 Class Initialized
INFO - 2016-11-26 10:49:34 --> URI Class Initialized
DEBUG - 2016-11-26 10:49:34 --> No URI present. Default controller set.
INFO - 2016-11-26 10:49:34 --> Router Class Initialized
INFO - 2016-11-26 10:49:34 --> Output Class Initialized
INFO - 2016-11-26 10:49:34 --> Security Class Initialized
DEBUG - 2016-11-26 10:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 10:49:34 --> Input Class Initialized
INFO - 2016-11-26 10:49:34 --> Language Class Initialized
INFO - 2016-11-26 10:49:34 --> Loader Class Initialized
INFO - 2016-11-26 10:49:34 --> Helper loaded: url_helper
INFO - 2016-11-26 10:49:34 --> Helper loaded: form_helper
INFO - 2016-11-26 10:49:34 --> Database Driver Class Initialized
INFO - 2016-11-26 10:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 10:49:34 --> Controller Class Initialized
INFO - 2016-11-26 10:49:34 --> Model Class Initialized
INFO - 2016-11-26 10:49:34 --> Model Class Initialized
INFO - 2016-11-26 10:49:34 --> Model Class Initialized
INFO - 2016-11-26 10:49:34 --> Model Class Initialized
INFO - 2016-11-26 10:49:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 10:49:34 --> Pagination Class Initialized
INFO - 2016-11-26 10:49:34 --> Helper loaded: app_helper
INFO - 2016-11-26 10:49:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 10:49:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 10:49:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 10:49:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 10:49:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 10:49:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 10:49:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 10:49:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 10:49:34 --> Final output sent to browser
DEBUG - 2016-11-26 10:49:34 --> Total execution time: 0.4188
INFO - 2016-11-26 11:04:57 --> Config Class Initialized
INFO - 2016-11-26 11:04:57 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:04:57 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:04:57 --> Utf8 Class Initialized
INFO - 2016-11-26 11:04:57 --> URI Class Initialized
DEBUG - 2016-11-26 11:04:57 --> No URI present. Default controller set.
INFO - 2016-11-26 11:04:57 --> Router Class Initialized
INFO - 2016-11-26 11:04:57 --> Output Class Initialized
INFO - 2016-11-26 11:04:57 --> Security Class Initialized
DEBUG - 2016-11-26 11:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:04:57 --> Input Class Initialized
INFO - 2016-11-26 11:04:57 --> Language Class Initialized
INFO - 2016-11-26 11:04:57 --> Loader Class Initialized
INFO - 2016-11-26 11:04:57 --> Helper loaded: url_helper
INFO - 2016-11-26 11:04:57 --> Helper loaded: form_helper
INFO - 2016-11-26 11:04:57 --> Database Driver Class Initialized
INFO - 2016-11-26 11:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:04:57 --> Controller Class Initialized
INFO - 2016-11-26 11:04:57 --> Model Class Initialized
INFO - 2016-11-26 11:04:57 --> Model Class Initialized
INFO - 2016-11-26 11:04:57 --> Model Class Initialized
INFO - 2016-11-26 11:04:57 --> Model Class Initialized
INFO - 2016-11-26 11:04:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:04:57 --> Pagination Class Initialized
INFO - 2016-11-26 11:04:57 --> Helper loaded: app_helper
INFO - 2016-11-26 11:04:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:04:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:04:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:04:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:04:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:04:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:04:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:04:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:04:57 --> Final output sent to browser
DEBUG - 2016-11-26 11:04:57 --> Total execution time: 0.4139
INFO - 2016-11-26 11:05:01 --> Config Class Initialized
INFO - 2016-11-26 11:05:01 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:05:01 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:05:01 --> Utf8 Class Initialized
INFO - 2016-11-26 11:05:01 --> URI Class Initialized
INFO - 2016-11-26 11:05:01 --> Router Class Initialized
INFO - 2016-11-26 11:05:01 --> Output Class Initialized
INFO - 2016-11-26 11:05:01 --> Security Class Initialized
DEBUG - 2016-11-26 11:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:05:01 --> Input Class Initialized
INFO - 2016-11-26 11:05:01 --> Language Class Initialized
INFO - 2016-11-26 11:05:01 --> Loader Class Initialized
INFO - 2016-11-26 11:05:01 --> Helper loaded: url_helper
INFO - 2016-11-26 11:05:01 --> Helper loaded: form_helper
INFO - 2016-11-26 11:05:01 --> Database Driver Class Initialized
INFO - 2016-11-26 11:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:05:02 --> Controller Class Initialized
INFO - 2016-11-26 11:05:02 --> Model Class Initialized
ERROR - 2016-11-26 11:05:02 --> Severity: Error --> Call to undefined function ajax_pagination() C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 108
INFO - 2016-11-26 11:05:20 --> Config Class Initialized
INFO - 2016-11-26 11:05:20 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:05:20 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:05:20 --> Utf8 Class Initialized
INFO - 2016-11-26 11:05:20 --> URI Class Initialized
INFO - 2016-11-26 11:05:20 --> Router Class Initialized
INFO - 2016-11-26 11:05:20 --> Output Class Initialized
INFO - 2016-11-26 11:05:20 --> Security Class Initialized
DEBUG - 2016-11-26 11:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:05:20 --> Input Class Initialized
INFO - 2016-11-26 11:05:20 --> Language Class Initialized
INFO - 2016-11-26 11:05:20 --> Loader Class Initialized
INFO - 2016-11-26 11:05:20 --> Helper loaded: url_helper
INFO - 2016-11-26 11:05:20 --> Helper loaded: form_helper
INFO - 2016-11-26 11:05:20 --> Database Driver Class Initialized
INFO - 2016-11-26 11:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:05:20 --> Controller Class Initialized
INFO - 2016-11-26 11:05:20 --> Model Class Initialized
INFO - 2016-11-26 11:05:20 --> Form Validation Class Initialized
INFO - 2016-11-26 11:05:20 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-26 11:05:20 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\hrm\add_leave_record_sidebar.php 31
INFO - 2016-11-26 11:05:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:05:21 --> Final output sent to browser
DEBUG - 2016-11-26 11:05:21 --> Total execution time: 0.4955
INFO - 2016-11-26 11:05:34 --> Config Class Initialized
INFO - 2016-11-26 11:05:34 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:05:34 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:05:34 --> Utf8 Class Initialized
INFO - 2016-11-26 11:05:34 --> URI Class Initialized
INFO - 2016-11-26 11:05:34 --> Router Class Initialized
INFO - 2016-11-26 11:05:34 --> Output Class Initialized
INFO - 2016-11-26 11:05:34 --> Security Class Initialized
DEBUG - 2016-11-26 11:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:05:34 --> Input Class Initialized
INFO - 2016-11-26 11:05:34 --> Language Class Initialized
INFO - 2016-11-26 11:05:34 --> Loader Class Initialized
INFO - 2016-11-26 11:05:34 --> Helper loaded: url_helper
INFO - 2016-11-26 11:05:34 --> Helper loaded: form_helper
INFO - 2016-11-26 11:05:34 --> Database Driver Class Initialized
INFO - 2016-11-26 11:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:05:34 --> Controller Class Initialized
INFO - 2016-11-26 11:05:34 --> Model Class Initialized
INFO - 2016-11-26 11:05:34 --> Form Validation Class Initialized
INFO - 2016-11-26 11:05:34 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-26 11:05:34 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\hrm\add_leave_record_sidebar.php 31
INFO - 2016-11-26 11:05:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:05:34 --> Final output sent to browser
DEBUG - 2016-11-26 11:05:34 --> Total execution time: 0.3941
INFO - 2016-11-26 11:05:42 --> Config Class Initialized
INFO - 2016-11-26 11:05:42 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:05:42 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:05:42 --> Utf8 Class Initialized
INFO - 2016-11-26 11:05:42 --> URI Class Initialized
INFO - 2016-11-26 11:05:42 --> Router Class Initialized
INFO - 2016-11-26 11:05:42 --> Output Class Initialized
INFO - 2016-11-26 11:05:42 --> Security Class Initialized
DEBUG - 2016-11-26 11:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:05:42 --> Input Class Initialized
INFO - 2016-11-26 11:05:42 --> Language Class Initialized
INFO - 2016-11-26 11:05:42 --> Loader Class Initialized
INFO - 2016-11-26 11:05:42 --> Helper loaded: url_helper
INFO - 2016-11-26 11:05:42 --> Helper loaded: form_helper
INFO - 2016-11-26 11:05:42 --> Database Driver Class Initialized
INFO - 2016-11-26 11:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:05:42 --> Controller Class Initialized
INFO - 2016-11-26 11:05:42 --> Model Class Initialized
INFO - 2016-11-26 11:05:42 --> Form Validation Class Initialized
INFO - 2016-11-26 11:05:42 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-26 11:05:42 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\hrm\add_leave_record_sidebar.php 31
INFO - 2016-11-26 11:05:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:05:43 --> Final output sent to browser
DEBUG - 2016-11-26 11:05:43 --> Total execution time: 0.4861
INFO - 2016-11-26 11:05:53 --> Config Class Initialized
INFO - 2016-11-26 11:05:53 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:05:53 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:05:53 --> Utf8 Class Initialized
INFO - 2016-11-26 11:05:53 --> URI Class Initialized
INFO - 2016-11-26 11:05:53 --> Router Class Initialized
INFO - 2016-11-26 11:05:53 --> Output Class Initialized
INFO - 2016-11-26 11:05:53 --> Security Class Initialized
DEBUG - 2016-11-26 11:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:05:53 --> Input Class Initialized
INFO - 2016-11-26 11:05:53 --> Language Class Initialized
INFO - 2016-11-26 11:05:53 --> Loader Class Initialized
INFO - 2016-11-26 11:05:53 --> Helper loaded: url_helper
INFO - 2016-11-26 11:05:53 --> Helper loaded: form_helper
INFO - 2016-11-26 11:05:53 --> Database Driver Class Initialized
INFO - 2016-11-26 11:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:05:53 --> Controller Class Initialized
INFO - 2016-11-26 11:05:53 --> Model Class Initialized
INFO - 2016-11-26 11:05:53 --> Form Validation Class Initialized
INFO - 2016-11-26 11:05:53 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-26 11:05:54 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\hrm\add_leave_record_sidebar.php 31
INFO - 2016-11-26 11:05:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:05:54 --> Final output sent to browser
DEBUG - 2016-11-26 11:05:54 --> Total execution time: 0.3770
INFO - 2016-11-26 11:05:54 --> Config Class Initialized
INFO - 2016-11-26 11:05:54 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:05:54 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:05:54 --> Utf8 Class Initialized
INFO - 2016-11-26 11:05:54 --> URI Class Initialized
INFO - 2016-11-26 11:05:54 --> Router Class Initialized
INFO - 2016-11-26 11:05:54 --> Output Class Initialized
INFO - 2016-11-26 11:05:54 --> Security Class Initialized
DEBUG - 2016-11-26 11:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:05:54 --> Input Class Initialized
INFO - 2016-11-26 11:05:54 --> Language Class Initialized
INFO - 2016-11-26 11:05:54 --> Loader Class Initialized
INFO - 2016-11-26 11:05:54 --> Helper loaded: url_helper
INFO - 2016-11-26 11:05:54 --> Helper loaded: form_helper
INFO - 2016-11-26 11:05:54 --> Database Driver Class Initialized
INFO - 2016-11-26 11:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:05:54 --> Controller Class Initialized
INFO - 2016-11-26 11:05:54 --> Model Class Initialized
INFO - 2016-11-26 11:05:54 --> Form Validation Class Initialized
INFO - 2016-11-26 11:05:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-26 11:05:54 --> Final output sent to browser
DEBUG - 2016-11-26 11:05:54 --> Total execution time: 0.2252
INFO - 2016-11-26 11:06:05 --> Config Class Initialized
INFO - 2016-11-26 11:06:05 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:06:05 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:06:05 --> Utf8 Class Initialized
INFO - 2016-11-26 11:06:05 --> URI Class Initialized
INFO - 2016-11-26 11:06:05 --> Router Class Initialized
INFO - 2016-11-26 11:06:05 --> Output Class Initialized
INFO - 2016-11-26 11:06:05 --> Security Class Initialized
DEBUG - 2016-11-26 11:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:06:05 --> Input Class Initialized
INFO - 2016-11-26 11:06:05 --> Language Class Initialized
INFO - 2016-11-26 11:06:05 --> Loader Class Initialized
INFO - 2016-11-26 11:06:05 --> Helper loaded: url_helper
INFO - 2016-11-26 11:06:05 --> Helper loaded: form_helper
INFO - 2016-11-26 11:06:05 --> Database Driver Class Initialized
INFO - 2016-11-26 11:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:06:05 --> Controller Class Initialized
INFO - 2016-11-26 11:06:05 --> Model Class Initialized
INFO - 2016-11-26 11:06:05 --> Form Validation Class Initialized
INFO - 2016-11-26 11:06:05 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-26 11:06:05 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\hrm\add_leave_record_sidebar.php 31
INFO - 2016-11-26 11:06:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:06:05 --> Final output sent to browser
DEBUG - 2016-11-26 11:06:05 --> Total execution time: 0.4280
INFO - 2016-11-26 11:06:15 --> Config Class Initialized
INFO - 2016-11-26 11:06:15 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:06:15 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:06:15 --> Utf8 Class Initialized
INFO - 2016-11-26 11:06:15 --> URI Class Initialized
INFO - 2016-11-26 11:06:15 --> Router Class Initialized
INFO - 2016-11-26 11:06:15 --> Output Class Initialized
INFO - 2016-11-26 11:06:15 --> Security Class Initialized
DEBUG - 2016-11-26 11:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:06:15 --> Input Class Initialized
INFO - 2016-11-26 11:06:15 --> Language Class Initialized
INFO - 2016-11-26 11:06:15 --> Loader Class Initialized
INFO - 2016-11-26 11:06:15 --> Helper loaded: url_helper
INFO - 2016-11-26 11:06:15 --> Helper loaded: form_helper
INFO - 2016-11-26 11:06:15 --> Database Driver Class Initialized
INFO - 2016-11-26 11:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:06:15 --> Controller Class Initialized
INFO - 2016-11-26 11:06:15 --> Model Class Initialized
INFO - 2016-11-26 11:06:15 --> Form Validation Class Initialized
INFO - 2016-11-26 11:06:15 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-26 11:06:16 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\hrm\add_leave_record_sidebar.php 31
INFO - 2016-11-26 11:06:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:06:16 --> Final output sent to browser
DEBUG - 2016-11-26 11:06:16 --> Total execution time: 0.4217
INFO - 2016-11-26 11:06:19 --> Config Class Initialized
INFO - 2016-11-26 11:06:19 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:06:19 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:06:19 --> Utf8 Class Initialized
INFO - 2016-11-26 11:06:19 --> URI Class Initialized
DEBUG - 2016-11-26 11:06:19 --> No URI present. Default controller set.
INFO - 2016-11-26 11:06:19 --> Router Class Initialized
INFO - 2016-11-26 11:06:19 --> Output Class Initialized
INFO - 2016-11-26 11:06:19 --> Security Class Initialized
DEBUG - 2016-11-26 11:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:06:19 --> Input Class Initialized
INFO - 2016-11-26 11:06:19 --> Language Class Initialized
INFO - 2016-11-26 11:06:19 --> Loader Class Initialized
INFO - 2016-11-26 11:06:19 --> Helper loaded: url_helper
INFO - 2016-11-26 11:06:19 --> Helper loaded: form_helper
INFO - 2016-11-26 11:06:19 --> Database Driver Class Initialized
INFO - 2016-11-26 11:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:06:19 --> Controller Class Initialized
INFO - 2016-11-26 11:06:19 --> Model Class Initialized
INFO - 2016-11-26 11:06:19 --> Model Class Initialized
INFO - 2016-11-26 11:06:19 --> Model Class Initialized
INFO - 2016-11-26 11:06:19 --> Model Class Initialized
INFO - 2016-11-26 11:06:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:06:19 --> Pagination Class Initialized
INFO - 2016-11-26 11:06:19 --> Helper loaded: app_helper
INFO - 2016-11-26 11:06:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:06:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:06:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:06:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:06:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:06:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:06:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:06:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:06:19 --> Final output sent to browser
DEBUG - 2016-11-26 11:06:19 --> Total execution time: 0.4436
INFO - 2016-11-26 11:06:23 --> Config Class Initialized
INFO - 2016-11-26 11:06:23 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:06:23 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:06:23 --> Utf8 Class Initialized
INFO - 2016-11-26 11:06:23 --> URI Class Initialized
INFO - 2016-11-26 11:06:23 --> Router Class Initialized
INFO - 2016-11-26 11:06:23 --> Output Class Initialized
INFO - 2016-11-26 11:06:23 --> Security Class Initialized
DEBUG - 2016-11-26 11:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:06:23 --> Input Class Initialized
INFO - 2016-11-26 11:06:23 --> Language Class Initialized
INFO - 2016-11-26 11:06:23 --> Loader Class Initialized
INFO - 2016-11-26 11:06:23 --> Helper loaded: url_helper
INFO - 2016-11-26 11:06:23 --> Helper loaded: form_helper
INFO - 2016-11-26 11:06:23 --> Database Driver Class Initialized
INFO - 2016-11-26 11:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:06:23 --> Controller Class Initialized
INFO - 2016-11-26 11:06:23 --> Model Class Initialized
ERROR - 2016-11-26 11:06:23 --> Severity: Error --> Call to undefined function ajax_pagination() C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 125
INFO - 2016-11-26 11:09:02 --> Config Class Initialized
INFO - 2016-11-26 11:09:02 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:09:02 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:09:02 --> Utf8 Class Initialized
INFO - 2016-11-26 11:09:03 --> URI Class Initialized
DEBUG - 2016-11-26 11:09:03 --> No URI present. Default controller set.
INFO - 2016-11-26 11:09:03 --> Router Class Initialized
INFO - 2016-11-26 11:09:03 --> Output Class Initialized
INFO - 2016-11-26 11:09:03 --> Security Class Initialized
DEBUG - 2016-11-26 11:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:09:03 --> Input Class Initialized
INFO - 2016-11-26 11:09:03 --> Language Class Initialized
INFO - 2016-11-26 11:09:03 --> Loader Class Initialized
INFO - 2016-11-26 11:09:03 --> Helper loaded: url_helper
INFO - 2016-11-26 11:09:03 --> Helper loaded: form_helper
INFO - 2016-11-26 11:09:03 --> Database Driver Class Initialized
INFO - 2016-11-26 11:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:09:03 --> Controller Class Initialized
INFO - 2016-11-26 11:09:03 --> Model Class Initialized
INFO - 2016-11-26 11:09:03 --> Model Class Initialized
INFO - 2016-11-26 11:09:03 --> Model Class Initialized
INFO - 2016-11-26 11:09:03 --> Model Class Initialized
INFO - 2016-11-26 11:09:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:09:03 --> Pagination Class Initialized
INFO - 2016-11-26 11:09:03 --> Helper loaded: app_helper
INFO - 2016-11-26 11:09:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:09:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:09:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:09:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:09:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:09:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:09:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:09:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:09:03 --> Final output sent to browser
DEBUG - 2016-11-26 11:09:03 --> Total execution time: 0.4474
INFO - 2016-11-26 11:09:06 --> Config Class Initialized
INFO - 2016-11-26 11:09:06 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:09:06 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:09:06 --> Utf8 Class Initialized
INFO - 2016-11-26 11:09:06 --> URI Class Initialized
INFO - 2016-11-26 11:09:06 --> Router Class Initialized
INFO - 2016-11-26 11:09:06 --> Output Class Initialized
INFO - 2016-11-26 11:09:06 --> Security Class Initialized
DEBUG - 2016-11-26 11:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:09:06 --> Input Class Initialized
INFO - 2016-11-26 11:09:06 --> Language Class Initialized
INFO - 2016-11-26 11:09:06 --> Loader Class Initialized
INFO - 2016-11-26 11:09:06 --> Helper loaded: url_helper
INFO - 2016-11-26 11:09:06 --> Helper loaded: form_helper
INFO - 2016-11-26 11:09:06 --> Database Driver Class Initialized
INFO - 2016-11-26 11:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:09:06 --> Controller Class Initialized
INFO - 2016-11-26 11:09:06 --> Model Class Initialized
ERROR - 2016-11-26 11:09:06 --> Severity: Error --> Call to undefined function ajax_pagination() C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 125
INFO - 2016-11-26 11:09:08 --> Config Class Initialized
INFO - 2016-11-26 11:09:08 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:09:08 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:09:08 --> Utf8 Class Initialized
INFO - 2016-11-26 11:09:08 --> URI Class Initialized
INFO - 2016-11-26 11:09:08 --> Router Class Initialized
INFO - 2016-11-26 11:09:08 --> Output Class Initialized
INFO - 2016-11-26 11:09:08 --> Security Class Initialized
DEBUG - 2016-11-26 11:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:09:09 --> Input Class Initialized
INFO - 2016-11-26 11:09:09 --> Language Class Initialized
INFO - 2016-11-26 11:09:09 --> Loader Class Initialized
INFO - 2016-11-26 11:09:09 --> Helper loaded: url_helper
INFO - 2016-11-26 11:09:09 --> Helper loaded: form_helper
INFO - 2016-11-26 11:09:09 --> Database Driver Class Initialized
INFO - 2016-11-26 11:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:09:09 --> Controller Class Initialized
INFO - 2016-11-26 11:09:09 --> Model Class Initialized
ERROR - 2016-11-26 11:09:09 --> Severity: Error --> Call to undefined function ajax_pagination() C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 125
INFO - 2016-11-26 11:09:12 --> Config Class Initialized
INFO - 2016-11-26 11:09:12 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:09:12 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:09:12 --> Utf8 Class Initialized
INFO - 2016-11-26 11:09:12 --> URI Class Initialized
INFO - 2016-11-26 11:09:12 --> Router Class Initialized
INFO - 2016-11-26 11:09:12 --> Output Class Initialized
INFO - 2016-11-26 11:09:12 --> Security Class Initialized
DEBUG - 2016-11-26 11:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:09:12 --> Input Class Initialized
INFO - 2016-11-26 11:09:12 --> Language Class Initialized
INFO - 2016-11-26 11:09:12 --> Loader Class Initialized
INFO - 2016-11-26 11:09:12 --> Helper loaded: url_helper
INFO - 2016-11-26 11:09:12 --> Helper loaded: form_helper
INFO - 2016-11-26 11:09:12 --> Database Driver Class Initialized
INFO - 2016-11-26 11:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:09:12 --> Controller Class Initialized
INFO - 2016-11-26 11:09:12 --> Model Class Initialized
ERROR - 2016-11-26 11:09:12 --> Severity: Error --> Call to undefined function ajax_pagination() C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 108
INFO - 2016-11-26 11:09:17 --> Config Class Initialized
INFO - 2016-11-26 11:09:17 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:09:17 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:09:17 --> Utf8 Class Initialized
INFO - 2016-11-26 11:09:17 --> URI Class Initialized
DEBUG - 2016-11-26 11:09:17 --> No URI present. Default controller set.
INFO - 2016-11-26 11:09:17 --> Router Class Initialized
INFO - 2016-11-26 11:09:17 --> Output Class Initialized
INFO - 2016-11-26 11:09:17 --> Security Class Initialized
DEBUG - 2016-11-26 11:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:09:17 --> Input Class Initialized
INFO - 2016-11-26 11:09:17 --> Language Class Initialized
INFO - 2016-11-26 11:09:17 --> Loader Class Initialized
INFO - 2016-11-26 11:09:17 --> Helper loaded: url_helper
INFO - 2016-11-26 11:09:17 --> Helper loaded: form_helper
INFO - 2016-11-26 11:09:17 --> Database Driver Class Initialized
INFO - 2016-11-26 11:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:09:17 --> Controller Class Initialized
INFO - 2016-11-26 11:09:17 --> Model Class Initialized
INFO - 2016-11-26 11:09:17 --> Model Class Initialized
INFO - 2016-11-26 11:09:17 --> Model Class Initialized
INFO - 2016-11-26 11:09:17 --> Model Class Initialized
INFO - 2016-11-26 11:09:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:09:17 --> Pagination Class Initialized
INFO - 2016-11-26 11:09:17 --> Helper loaded: app_helper
INFO - 2016-11-26 11:09:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:09:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:09:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:09:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:09:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:09:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:09:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:09:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:09:17 --> Final output sent to browser
DEBUG - 2016-11-26 11:09:17 --> Total execution time: 0.4495
INFO - 2016-11-26 11:09:39 --> Config Class Initialized
INFO - 2016-11-26 11:09:39 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:09:39 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:09:39 --> Utf8 Class Initialized
INFO - 2016-11-26 11:09:39 --> URI Class Initialized
DEBUG - 2016-11-26 11:09:39 --> No URI present. Default controller set.
INFO - 2016-11-26 11:09:40 --> Router Class Initialized
INFO - 2016-11-26 11:09:40 --> Output Class Initialized
INFO - 2016-11-26 11:09:40 --> Security Class Initialized
DEBUG - 2016-11-26 11:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:09:40 --> Input Class Initialized
INFO - 2016-11-26 11:09:40 --> Language Class Initialized
INFO - 2016-11-26 11:09:40 --> Loader Class Initialized
INFO - 2016-11-26 11:09:40 --> Helper loaded: url_helper
INFO - 2016-11-26 11:09:40 --> Helper loaded: form_helper
INFO - 2016-11-26 11:09:40 --> Database Driver Class Initialized
INFO - 2016-11-26 11:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:09:40 --> Controller Class Initialized
INFO - 2016-11-26 11:09:40 --> Model Class Initialized
INFO - 2016-11-26 11:09:40 --> Model Class Initialized
INFO - 2016-11-26 11:09:40 --> Model Class Initialized
INFO - 2016-11-26 11:09:40 --> Model Class Initialized
INFO - 2016-11-26 11:09:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:09:40 --> Pagination Class Initialized
INFO - 2016-11-26 11:09:40 --> Helper loaded: app_helper
INFO - 2016-11-26 11:09:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:09:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:09:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:09:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:09:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:09:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:09:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:09:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:09:40 --> Final output sent to browser
DEBUG - 2016-11-26 11:09:40 --> Total execution time: 0.4502
INFO - 2016-11-26 11:15:10 --> Config Class Initialized
INFO - 2016-11-26 11:15:10 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:15:10 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:15:10 --> Utf8 Class Initialized
INFO - 2016-11-26 11:15:10 --> URI Class Initialized
DEBUG - 2016-11-26 11:15:10 --> No URI present. Default controller set.
INFO - 2016-11-26 11:15:10 --> Router Class Initialized
INFO - 2016-11-26 11:15:10 --> Output Class Initialized
INFO - 2016-11-26 11:15:10 --> Security Class Initialized
DEBUG - 2016-11-26 11:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:15:10 --> Input Class Initialized
INFO - 2016-11-26 11:15:10 --> Language Class Initialized
INFO - 2016-11-26 11:15:10 --> Loader Class Initialized
INFO - 2016-11-26 11:15:10 --> Helper loaded: url_helper
INFO - 2016-11-26 11:15:10 --> Helper loaded: form_helper
INFO - 2016-11-26 11:15:10 --> Database Driver Class Initialized
INFO - 2016-11-26 11:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:15:10 --> Controller Class Initialized
INFO - 2016-11-26 11:15:10 --> Model Class Initialized
INFO - 2016-11-26 11:15:10 --> Model Class Initialized
INFO - 2016-11-26 11:15:10 --> Model Class Initialized
INFO - 2016-11-26 11:15:10 --> Model Class Initialized
INFO - 2016-11-26 11:15:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:15:10 --> Pagination Class Initialized
INFO - 2016-11-26 11:15:10 --> Helper loaded: app_helper
INFO - 2016-11-26 11:15:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:15:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:15:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:15:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:15:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:15:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:15:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:15:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:15:10 --> Final output sent to browser
DEBUG - 2016-11-26 11:15:10 --> Total execution time: 0.4526
INFO - 2016-11-26 11:15:57 --> Config Class Initialized
INFO - 2016-11-26 11:15:57 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:15:57 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:15:57 --> Utf8 Class Initialized
INFO - 2016-11-26 11:15:57 --> URI Class Initialized
INFO - 2016-11-26 11:15:57 --> Router Class Initialized
INFO - 2016-11-26 11:15:57 --> Output Class Initialized
INFO - 2016-11-26 11:15:57 --> Security Class Initialized
DEBUG - 2016-11-26 11:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:15:57 --> Input Class Initialized
INFO - 2016-11-26 11:15:57 --> Language Class Initialized
INFO - 2016-11-26 11:15:57 --> Loader Class Initialized
INFO - 2016-11-26 11:15:57 --> Helper loaded: url_helper
INFO - 2016-11-26 11:15:57 --> Helper loaded: form_helper
INFO - 2016-11-26 11:15:57 --> Database Driver Class Initialized
INFO - 2016-11-26 11:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:15:57 --> Controller Class Initialized
INFO - 2016-11-26 11:15:57 --> Model Class Initialized
INFO - 2016-11-26 11:15:57 --> Form Validation Class Initialized
INFO - 2016-11-26 11:15:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-26 11:15:57 --> Final output sent to browser
DEBUG - 2016-11-26 11:15:57 --> Total execution time: 0.2397
INFO - 2016-11-26 11:18:28 --> Config Class Initialized
INFO - 2016-11-26 11:18:28 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:18:28 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:18:28 --> Utf8 Class Initialized
INFO - 2016-11-26 11:18:28 --> URI Class Initialized
DEBUG - 2016-11-26 11:18:28 --> No URI present. Default controller set.
INFO - 2016-11-26 11:18:28 --> Router Class Initialized
INFO - 2016-11-26 11:18:29 --> Output Class Initialized
INFO - 2016-11-26 11:18:29 --> Security Class Initialized
DEBUG - 2016-11-26 11:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:18:29 --> Input Class Initialized
INFO - 2016-11-26 11:18:29 --> Language Class Initialized
INFO - 2016-11-26 11:18:29 --> Loader Class Initialized
INFO - 2016-11-26 11:18:29 --> Helper loaded: url_helper
INFO - 2016-11-26 11:18:29 --> Helper loaded: form_helper
INFO - 2016-11-26 11:18:29 --> Database Driver Class Initialized
INFO - 2016-11-26 11:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:18:29 --> Controller Class Initialized
INFO - 2016-11-26 11:18:29 --> Model Class Initialized
INFO - 2016-11-26 11:18:29 --> Model Class Initialized
INFO - 2016-11-26 11:18:29 --> Model Class Initialized
INFO - 2016-11-26 11:18:29 --> Model Class Initialized
INFO - 2016-11-26 11:18:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:18:29 --> Pagination Class Initialized
INFO - 2016-11-26 11:18:29 --> Helper loaded: app_helper
INFO - 2016-11-26 11:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:18:29 --> Final output sent to browser
DEBUG - 2016-11-26 11:18:29 --> Total execution time: 0.4407
INFO - 2016-11-26 11:18:33 --> Config Class Initialized
INFO - 2016-11-26 11:18:33 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:18:33 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:18:33 --> Utf8 Class Initialized
INFO - 2016-11-26 11:18:33 --> URI Class Initialized
INFO - 2016-11-26 11:18:33 --> Router Class Initialized
INFO - 2016-11-26 11:18:33 --> Output Class Initialized
INFO - 2016-11-26 11:18:33 --> Security Class Initialized
DEBUG - 2016-11-26 11:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:18:33 --> Input Class Initialized
INFO - 2016-11-26 11:18:33 --> Language Class Initialized
INFO - 2016-11-26 11:18:33 --> Loader Class Initialized
INFO - 2016-11-26 11:18:33 --> Helper loaded: url_helper
INFO - 2016-11-26 11:18:33 --> Helper loaded: form_helper
INFO - 2016-11-26 11:18:33 --> Database Driver Class Initialized
INFO - 2016-11-26 11:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:18:33 --> Controller Class Initialized
INFO - 2016-11-26 11:18:33 --> Model Class Initialized
ERROR - 2016-11-26 11:18:33 --> Severity: Error --> Call to undefined function ajax_pagination() C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 125
INFO - 2016-11-26 11:18:42 --> Config Class Initialized
INFO - 2016-11-26 11:18:43 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:18:43 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:18:43 --> Utf8 Class Initialized
INFO - 2016-11-26 11:18:43 --> URI Class Initialized
INFO - 2016-11-26 11:18:43 --> Router Class Initialized
INFO - 2016-11-26 11:18:43 --> Output Class Initialized
INFO - 2016-11-26 11:18:43 --> Security Class Initialized
DEBUG - 2016-11-26 11:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:18:43 --> Input Class Initialized
INFO - 2016-11-26 11:18:43 --> Language Class Initialized
INFO - 2016-11-26 11:18:43 --> Loader Class Initialized
INFO - 2016-11-26 11:18:43 --> Helper loaded: url_helper
INFO - 2016-11-26 11:18:43 --> Helper loaded: form_helper
INFO - 2016-11-26 11:18:43 --> Database Driver Class Initialized
INFO - 2016-11-26 11:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:18:43 --> Controller Class Initialized
INFO - 2016-11-26 11:18:43 --> Model Class Initialized
ERROR - 2016-11-26 11:18:43 --> Severity: Error --> Call to undefined function ajax_pagination() C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 125
INFO - 2016-11-26 11:19:30 --> Config Class Initialized
INFO - 2016-11-26 11:19:30 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:19:30 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:19:30 --> Utf8 Class Initialized
INFO - 2016-11-26 11:19:30 --> URI Class Initialized
DEBUG - 2016-11-26 11:19:30 --> No URI present. Default controller set.
INFO - 2016-11-26 11:19:30 --> Router Class Initialized
INFO - 2016-11-26 11:19:30 --> Output Class Initialized
INFO - 2016-11-26 11:19:30 --> Security Class Initialized
DEBUG - 2016-11-26 11:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:19:30 --> Input Class Initialized
INFO - 2016-11-26 11:19:30 --> Language Class Initialized
INFO - 2016-11-26 11:19:30 --> Loader Class Initialized
INFO - 2016-11-26 11:19:30 --> Helper loaded: url_helper
INFO - 2016-11-26 11:19:30 --> Helper loaded: form_helper
INFO - 2016-11-26 11:19:31 --> Database Driver Class Initialized
INFO - 2016-11-26 11:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:19:31 --> Controller Class Initialized
INFO - 2016-11-26 11:19:31 --> Model Class Initialized
INFO - 2016-11-26 11:19:31 --> Model Class Initialized
INFO - 2016-11-26 11:19:31 --> Model Class Initialized
INFO - 2016-11-26 11:19:31 --> Model Class Initialized
INFO - 2016-11-26 11:19:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:19:31 --> Pagination Class Initialized
INFO - 2016-11-26 11:19:31 --> Helper loaded: app_helper
INFO - 2016-11-26 11:19:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:19:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:19:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:19:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:19:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:19:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:19:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:19:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:19:31 --> Final output sent to browser
DEBUG - 2016-11-26 11:19:31 --> Total execution time: 0.6266
INFO - 2016-11-26 11:20:07 --> Config Class Initialized
INFO - 2016-11-26 11:20:07 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:20:07 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:20:07 --> Utf8 Class Initialized
INFO - 2016-11-26 11:20:07 --> URI Class Initialized
DEBUG - 2016-11-26 11:20:07 --> No URI present. Default controller set.
INFO - 2016-11-26 11:20:07 --> Router Class Initialized
INFO - 2016-11-26 11:20:07 --> Output Class Initialized
INFO - 2016-11-26 11:20:07 --> Security Class Initialized
DEBUG - 2016-11-26 11:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:20:07 --> Input Class Initialized
INFO - 2016-11-26 11:20:07 --> Language Class Initialized
INFO - 2016-11-26 11:20:07 --> Loader Class Initialized
INFO - 2016-11-26 11:20:07 --> Helper loaded: url_helper
INFO - 2016-11-26 11:20:07 --> Helper loaded: form_helper
INFO - 2016-11-26 11:20:07 --> Database Driver Class Initialized
INFO - 2016-11-26 11:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:20:07 --> Controller Class Initialized
INFO - 2016-11-26 11:20:07 --> Model Class Initialized
INFO - 2016-11-26 11:20:07 --> Model Class Initialized
INFO - 2016-11-26 11:20:07 --> Model Class Initialized
INFO - 2016-11-26 11:20:07 --> Model Class Initialized
INFO - 2016-11-26 11:20:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:20:07 --> Pagination Class Initialized
INFO - 2016-11-26 11:20:07 --> Helper loaded: app_helper
INFO - 2016-11-26 11:20:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:20:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:20:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:20:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:20:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:20:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:20:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:20:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:20:07 --> Final output sent to browser
DEBUG - 2016-11-26 11:20:07 --> Total execution time: 0.4715
INFO - 2016-11-26 11:20:09 --> Config Class Initialized
INFO - 2016-11-26 11:20:09 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:20:09 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:20:09 --> Utf8 Class Initialized
INFO - 2016-11-26 11:20:09 --> URI Class Initialized
DEBUG - 2016-11-26 11:20:09 --> No URI present. Default controller set.
INFO - 2016-11-26 11:20:09 --> Router Class Initialized
INFO - 2016-11-26 11:20:09 --> Output Class Initialized
INFO - 2016-11-26 11:20:09 --> Security Class Initialized
DEBUG - 2016-11-26 11:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:20:09 --> Input Class Initialized
INFO - 2016-11-26 11:20:09 --> Language Class Initialized
INFO - 2016-11-26 11:20:09 --> Loader Class Initialized
INFO - 2016-11-26 11:20:09 --> Helper loaded: url_helper
INFO - 2016-11-26 11:20:09 --> Helper loaded: form_helper
INFO - 2016-11-26 11:20:09 --> Database Driver Class Initialized
INFO - 2016-11-26 11:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:20:09 --> Controller Class Initialized
INFO - 2016-11-26 11:20:09 --> Model Class Initialized
INFO - 2016-11-26 11:20:09 --> Model Class Initialized
INFO - 2016-11-26 11:20:09 --> Model Class Initialized
INFO - 2016-11-26 11:20:09 --> Model Class Initialized
INFO - 2016-11-26 11:20:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:20:09 --> Pagination Class Initialized
INFO - 2016-11-26 11:20:09 --> Helper loaded: app_helper
INFO - 2016-11-26 11:20:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:20:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:20:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:20:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:20:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:20:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:20:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:20:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:20:09 --> Final output sent to browser
DEBUG - 2016-11-26 11:20:09 --> Total execution time: 0.5209
INFO - 2016-11-26 11:20:17 --> Config Class Initialized
INFO - 2016-11-26 11:20:17 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:20:17 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:20:17 --> Utf8 Class Initialized
INFO - 2016-11-26 11:20:17 --> URI Class Initialized
DEBUG - 2016-11-26 11:20:17 --> No URI present. Default controller set.
INFO - 2016-11-26 11:20:17 --> Router Class Initialized
INFO - 2016-11-26 11:20:17 --> Output Class Initialized
INFO - 2016-11-26 11:20:17 --> Security Class Initialized
DEBUG - 2016-11-26 11:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:20:17 --> Input Class Initialized
INFO - 2016-11-26 11:20:17 --> Language Class Initialized
INFO - 2016-11-26 11:20:17 --> Loader Class Initialized
INFO - 2016-11-26 11:20:17 --> Helper loaded: url_helper
INFO - 2016-11-26 11:20:17 --> Helper loaded: form_helper
INFO - 2016-11-26 11:20:17 --> Database Driver Class Initialized
INFO - 2016-11-26 11:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:20:17 --> Controller Class Initialized
INFO - 2016-11-26 11:20:17 --> Model Class Initialized
INFO - 2016-11-26 11:20:17 --> Model Class Initialized
INFO - 2016-11-26 11:20:17 --> Model Class Initialized
INFO - 2016-11-26 11:20:17 --> Model Class Initialized
INFO - 2016-11-26 11:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:20:17 --> Pagination Class Initialized
INFO - 2016-11-26 11:20:17 --> Helper loaded: app_helper
INFO - 2016-11-26 11:20:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:20:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:20:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:20:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:20:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:20:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:20:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:20:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:20:18 --> Final output sent to browser
DEBUG - 2016-11-26 11:20:18 --> Total execution time: 0.5218
INFO - 2016-11-26 11:21:08 --> Config Class Initialized
INFO - 2016-11-26 11:21:08 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:21:08 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:21:08 --> Utf8 Class Initialized
INFO - 2016-11-26 11:21:08 --> URI Class Initialized
DEBUG - 2016-11-26 11:21:08 --> No URI present. Default controller set.
INFO - 2016-11-26 11:21:08 --> Router Class Initialized
INFO - 2016-11-26 11:21:09 --> Output Class Initialized
INFO - 2016-11-26 11:21:09 --> Security Class Initialized
DEBUG - 2016-11-26 11:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:21:09 --> Input Class Initialized
INFO - 2016-11-26 11:21:09 --> Language Class Initialized
INFO - 2016-11-26 11:21:09 --> Loader Class Initialized
INFO - 2016-11-26 11:21:09 --> Helper loaded: url_helper
INFO - 2016-11-26 11:21:09 --> Helper loaded: form_helper
INFO - 2016-11-26 11:21:09 --> Database Driver Class Initialized
INFO - 2016-11-26 11:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:21:09 --> Controller Class Initialized
INFO - 2016-11-26 11:21:09 --> Model Class Initialized
INFO - 2016-11-26 11:21:09 --> Model Class Initialized
INFO - 2016-11-26 11:21:09 --> Model Class Initialized
INFO - 2016-11-26 11:21:09 --> Model Class Initialized
INFO - 2016-11-26 11:21:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:21:09 --> Pagination Class Initialized
INFO - 2016-11-26 11:21:09 --> Helper loaded: app_helper
INFO - 2016-11-26 11:21:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:21:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:21:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:21:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:21:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:21:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:21:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:21:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:21:09 --> Final output sent to browser
DEBUG - 2016-11-26 11:21:09 --> Total execution time: 0.4975
INFO - 2016-11-26 11:21:38 --> Config Class Initialized
INFO - 2016-11-26 11:21:38 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:21:38 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:21:38 --> Utf8 Class Initialized
INFO - 2016-11-26 11:21:38 --> URI Class Initialized
DEBUG - 2016-11-26 11:21:38 --> No URI present. Default controller set.
INFO - 2016-11-26 11:21:38 --> Router Class Initialized
INFO - 2016-11-26 11:21:38 --> Output Class Initialized
INFO - 2016-11-26 11:21:38 --> Security Class Initialized
DEBUG - 2016-11-26 11:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:21:38 --> Input Class Initialized
INFO - 2016-11-26 11:21:38 --> Language Class Initialized
INFO - 2016-11-26 11:21:38 --> Loader Class Initialized
INFO - 2016-11-26 11:21:38 --> Helper loaded: url_helper
INFO - 2016-11-26 11:21:38 --> Helper loaded: form_helper
INFO - 2016-11-26 11:21:38 --> Database Driver Class Initialized
INFO - 2016-11-26 11:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:21:38 --> Controller Class Initialized
INFO - 2016-11-26 11:21:38 --> Model Class Initialized
INFO - 2016-11-26 11:21:38 --> Model Class Initialized
INFO - 2016-11-26 11:21:38 --> Model Class Initialized
INFO - 2016-11-26 11:21:38 --> Model Class Initialized
INFO - 2016-11-26 11:21:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:21:38 --> Pagination Class Initialized
INFO - 2016-11-26 11:21:38 --> Helper loaded: app_helper
INFO - 2016-11-26 11:21:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:21:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:21:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:21:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:21:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:21:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:21:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:21:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:21:38 --> Final output sent to browser
DEBUG - 2016-11-26 11:21:38 --> Total execution time: 0.4638
INFO - 2016-11-26 11:21:48 --> Config Class Initialized
INFO - 2016-11-26 11:21:48 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:21:48 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:21:48 --> Utf8 Class Initialized
INFO - 2016-11-26 11:21:48 --> URI Class Initialized
DEBUG - 2016-11-26 11:21:48 --> No URI present. Default controller set.
INFO - 2016-11-26 11:21:48 --> Router Class Initialized
INFO - 2016-11-26 11:21:48 --> Output Class Initialized
INFO - 2016-11-26 11:21:48 --> Security Class Initialized
INFO - 2016-11-26 11:21:48 --> Config Class Initialized
DEBUG - 2016-11-26 11:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:21:48 --> Hooks Class Initialized
INFO - 2016-11-26 11:21:48 --> Input Class Initialized
DEBUG - 2016-11-26 11:21:48 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:21:48 --> Language Class Initialized
INFO - 2016-11-26 11:21:48 --> Utf8 Class Initialized
INFO - 2016-11-26 11:21:48 --> URI Class Initialized
INFO - 2016-11-26 11:21:48 --> Loader Class Initialized
DEBUG - 2016-11-26 11:21:49 --> No URI present. Default controller set.
INFO - 2016-11-26 11:21:49 --> Config Class Initialized
INFO - 2016-11-26 11:21:49 --> Router Class Initialized
INFO - 2016-11-26 11:21:49 --> Helper loaded: url_helper
INFO - 2016-11-26 11:21:49 --> Hooks Class Initialized
INFO - 2016-11-26 11:21:49 --> Output Class Initialized
INFO - 2016-11-26 11:21:49 --> Helper loaded: form_helper
DEBUG - 2016-11-26 11:21:49 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:21:49 --> Database Driver Class Initialized
INFO - 2016-11-26 11:21:49 --> Security Class Initialized
INFO - 2016-11-26 11:21:49 --> Utf8 Class Initialized
INFO - 2016-11-26 11:21:49 --> URI Class Initialized
DEBUG - 2016-11-26 11:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:21:49 --> Input Class Initialized
DEBUG - 2016-11-26 11:21:49 --> No URI present. Default controller set.
INFO - 2016-11-26 11:21:49 --> Controller Class Initialized
INFO - 2016-11-26 11:21:49 --> Router Class Initialized
INFO - 2016-11-26 11:21:49 --> Language Class Initialized
INFO - 2016-11-26 11:21:49 --> Model Class Initialized
INFO - 2016-11-26 11:21:49 --> Loader Class Initialized
INFO - 2016-11-26 11:21:49 --> Output Class Initialized
INFO - 2016-11-26 11:21:49 --> Model Class Initialized
INFO - 2016-11-26 11:21:49 --> Helper loaded: url_helper
INFO - 2016-11-26 11:21:49 --> Security Class Initialized
INFO - 2016-11-26 11:21:49 --> Model Class Initialized
DEBUG - 2016-11-26 11:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:21:49 --> Helper loaded: form_helper
INFO - 2016-11-26 11:21:49 --> Model Class Initialized
INFO - 2016-11-26 11:21:49 --> Input Class Initialized
INFO - 2016-11-26 11:21:49 --> Database Driver Class Initialized
INFO - 2016-11-26 11:21:49 --> Language Class Initialized
INFO - 2016-11-26 11:21:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:21:49 --> Pagination Class Initialized
INFO - 2016-11-26 11:21:49 --> Loader Class Initialized
INFO - 2016-11-26 11:21:49 --> Helper loaded: app_helper
INFO - 2016-11-26 11:21:49 --> Helper loaded: url_helper
INFO - 2016-11-26 11:21:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:21:49 --> Helper loaded: form_helper
INFO - 2016-11-26 11:21:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:21:49 --> Database Driver Class Initialized
INFO - 2016-11-26 11:21:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:21:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:21:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:21:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:21:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:21:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:21:49 --> Final output sent to browser
DEBUG - 2016-11-26 11:21:49 --> Total execution time: 0.9272
INFO - 2016-11-26 11:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:21:49 --> Controller Class Initialized
INFO - 2016-11-26 11:21:49 --> Model Class Initialized
INFO - 2016-11-26 11:21:49 --> Model Class Initialized
INFO - 2016-11-26 11:21:49 --> Model Class Initialized
INFO - 2016-11-26 11:21:49 --> Model Class Initialized
INFO - 2016-11-26 11:21:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:21:49 --> Pagination Class Initialized
INFO - 2016-11-26 11:21:49 --> Helper loaded: app_helper
INFO - 2016-11-26 11:21:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:21:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:21:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:21:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:21:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:21:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:21:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:21:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:21:50 --> Final output sent to browser
DEBUG - 2016-11-26 11:21:50 --> Total execution time: 1.2230
INFO - 2016-11-26 11:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:21:50 --> Controller Class Initialized
INFO - 2016-11-26 11:21:50 --> Model Class Initialized
INFO - 2016-11-26 11:21:50 --> Model Class Initialized
INFO - 2016-11-26 11:21:50 --> Model Class Initialized
INFO - 2016-11-26 11:21:50 --> Model Class Initialized
INFO - 2016-11-26 11:21:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:21:50 --> Pagination Class Initialized
INFO - 2016-11-26 11:21:50 --> Helper loaded: app_helper
INFO - 2016-11-26 11:21:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:21:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:21:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:21:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:21:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:21:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:21:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:21:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:21:50 --> Final output sent to browser
DEBUG - 2016-11-26 11:21:50 --> Total execution time: 1.5751
INFO - 2016-11-26 11:21:55 --> Config Class Initialized
INFO - 2016-11-26 11:21:55 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:21:55 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:21:55 --> Utf8 Class Initialized
INFO - 2016-11-26 11:21:55 --> URI Class Initialized
DEBUG - 2016-11-26 11:21:55 --> No URI present. Default controller set.
INFO - 2016-11-26 11:21:55 --> Router Class Initialized
INFO - 2016-11-26 11:21:55 --> Output Class Initialized
INFO - 2016-11-26 11:21:55 --> Security Class Initialized
DEBUG - 2016-11-26 11:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:21:55 --> Input Class Initialized
INFO - 2016-11-26 11:21:55 --> Language Class Initialized
INFO - 2016-11-26 11:21:56 --> Loader Class Initialized
INFO - 2016-11-26 11:21:56 --> Helper loaded: url_helper
INFO - 2016-11-26 11:21:56 --> Helper loaded: form_helper
INFO - 2016-11-26 11:21:56 --> Database Driver Class Initialized
INFO - 2016-11-26 11:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:21:56 --> Controller Class Initialized
INFO - 2016-11-26 11:21:56 --> Model Class Initialized
INFO - 2016-11-26 11:21:56 --> Model Class Initialized
INFO - 2016-11-26 11:21:56 --> Model Class Initialized
INFO - 2016-11-26 11:21:56 --> Model Class Initialized
INFO - 2016-11-26 11:21:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:21:56 --> Pagination Class Initialized
INFO - 2016-11-26 11:21:56 --> Helper loaded: app_helper
INFO - 2016-11-26 11:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:21:56 --> Final output sent to browser
DEBUG - 2016-11-26 11:21:56 --> Total execution time: 0.5516
INFO - 2016-11-26 11:23:03 --> Config Class Initialized
INFO - 2016-11-26 11:23:03 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:23:03 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:23:03 --> Utf8 Class Initialized
INFO - 2016-11-26 11:23:03 --> URI Class Initialized
INFO - 2016-11-26 11:23:03 --> Router Class Initialized
INFO - 2016-11-26 11:23:03 --> Output Class Initialized
INFO - 2016-11-26 11:23:03 --> Security Class Initialized
DEBUG - 2016-11-26 11:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:23:03 --> Input Class Initialized
INFO - 2016-11-26 11:23:03 --> Language Class Initialized
INFO - 2016-11-26 11:23:03 --> Loader Class Initialized
INFO - 2016-11-26 11:23:03 --> Helper loaded: url_helper
INFO - 2016-11-26 11:23:03 --> Helper loaded: form_helper
INFO - 2016-11-26 11:23:03 --> Database Driver Class Initialized
INFO - 2016-11-26 11:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:23:03 --> Controller Class Initialized
INFO - 2016-11-26 11:23:03 --> Model Class Initialized
INFO - 2016-11-26 11:23:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:23:03 --> Pagination Class Initialized
INFO - 2016-11-26 11:23:03 --> Helper loaded: app_helper
INFO - 2016-11-26 11:23:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:23:03 --> Final output sent to browser
DEBUG - 2016-11-26 11:23:03 --> Total execution time: 0.2707
INFO - 2016-11-26 11:23:07 --> Config Class Initialized
INFO - 2016-11-26 11:23:07 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:23:07 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:23:07 --> Utf8 Class Initialized
INFO - 2016-11-26 11:23:07 --> URI Class Initialized
INFO - 2016-11-26 11:23:07 --> Router Class Initialized
INFO - 2016-11-26 11:23:07 --> Output Class Initialized
INFO - 2016-11-26 11:23:07 --> Security Class Initialized
DEBUG - 2016-11-26 11:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:23:07 --> Input Class Initialized
INFO - 2016-11-26 11:23:07 --> Language Class Initialized
INFO - 2016-11-26 11:23:07 --> Loader Class Initialized
INFO - 2016-11-26 11:23:07 --> Helper loaded: url_helper
INFO - 2016-11-26 11:23:07 --> Helper loaded: form_helper
INFO - 2016-11-26 11:23:07 --> Database Driver Class Initialized
INFO - 2016-11-26 11:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:23:07 --> Controller Class Initialized
INFO - 2016-11-26 11:23:07 --> Model Class Initialized
INFO - 2016-11-26 11:23:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:23:07 --> Pagination Class Initialized
INFO - 2016-11-26 11:23:07 --> Helper loaded: app_helper
INFO - 2016-11-26 11:23:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:23:07 --> Final output sent to browser
DEBUG - 2016-11-26 11:23:07 --> Total execution time: 0.2767
INFO - 2016-11-26 11:23:09 --> Config Class Initialized
INFO - 2016-11-26 11:23:09 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:23:09 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:23:09 --> Utf8 Class Initialized
INFO - 2016-11-26 11:23:09 --> URI Class Initialized
INFO - 2016-11-26 11:23:09 --> Router Class Initialized
INFO - 2016-11-26 11:23:09 --> Output Class Initialized
INFO - 2016-11-26 11:23:09 --> Security Class Initialized
DEBUG - 2016-11-26 11:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:23:09 --> Input Class Initialized
INFO - 2016-11-26 11:23:09 --> Language Class Initialized
INFO - 2016-11-26 11:23:09 --> Loader Class Initialized
INFO - 2016-11-26 11:23:09 --> Helper loaded: url_helper
INFO - 2016-11-26 11:23:09 --> Helper loaded: form_helper
INFO - 2016-11-26 11:23:09 --> Database Driver Class Initialized
INFO - 2016-11-26 11:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:23:09 --> Controller Class Initialized
INFO - 2016-11-26 11:23:09 --> Model Class Initialized
INFO - 2016-11-26 11:23:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:23:09 --> Pagination Class Initialized
INFO - 2016-11-26 11:23:09 --> Helper loaded: app_helper
INFO - 2016-11-26 11:23:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:23:09 --> Final output sent to browser
DEBUG - 2016-11-26 11:23:09 --> Total execution time: 0.2762
INFO - 2016-11-26 11:23:13 --> Config Class Initialized
INFO - 2016-11-26 11:23:13 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:23:13 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:23:13 --> Utf8 Class Initialized
INFO - 2016-11-26 11:23:13 --> URI Class Initialized
INFO - 2016-11-26 11:23:13 --> Router Class Initialized
INFO - 2016-11-26 11:23:13 --> Output Class Initialized
INFO - 2016-11-26 11:23:13 --> Security Class Initialized
DEBUG - 2016-11-26 11:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:23:13 --> Input Class Initialized
INFO - 2016-11-26 11:23:13 --> Language Class Initialized
INFO - 2016-11-26 11:23:13 --> Loader Class Initialized
INFO - 2016-11-26 11:23:13 --> Helper loaded: url_helper
INFO - 2016-11-26 11:23:13 --> Helper loaded: form_helper
INFO - 2016-11-26 11:23:13 --> Database Driver Class Initialized
INFO - 2016-11-26 11:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:23:13 --> Controller Class Initialized
INFO - 2016-11-26 11:23:13 --> Model Class Initialized
INFO - 2016-11-26 11:23:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:23:13 --> Pagination Class Initialized
INFO - 2016-11-26 11:23:13 --> Helper loaded: app_helper
INFO - 2016-11-26 11:23:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:23:13 --> Final output sent to browser
DEBUG - 2016-11-26 11:23:13 --> Total execution time: 0.2883
INFO - 2016-11-26 11:23:17 --> Config Class Initialized
INFO - 2016-11-26 11:23:17 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:23:17 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:23:17 --> Utf8 Class Initialized
INFO - 2016-11-26 11:23:17 --> URI Class Initialized
INFO - 2016-11-26 11:23:17 --> Router Class Initialized
INFO - 2016-11-26 11:23:17 --> Output Class Initialized
INFO - 2016-11-26 11:23:17 --> Security Class Initialized
DEBUG - 2016-11-26 11:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:23:17 --> Input Class Initialized
INFO - 2016-11-26 11:23:17 --> Language Class Initialized
INFO - 2016-11-26 11:23:17 --> Loader Class Initialized
INFO - 2016-11-26 11:23:17 --> Helper loaded: url_helper
INFO - 2016-11-26 11:23:17 --> Helper loaded: form_helper
INFO - 2016-11-26 11:23:17 --> Database Driver Class Initialized
INFO - 2016-11-26 11:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:23:17 --> Controller Class Initialized
INFO - 2016-11-26 11:23:17 --> Model Class Initialized
INFO - 2016-11-26 11:23:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:23:17 --> Pagination Class Initialized
INFO - 2016-11-26 11:23:17 --> Helper loaded: app_helper
INFO - 2016-11-26 11:23:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:23:18 --> Final output sent to browser
DEBUG - 2016-11-26 11:23:18 --> Total execution time: 0.3964
INFO - 2016-11-26 11:23:18 --> Config Class Initialized
INFO - 2016-11-26 11:23:18 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:23:18 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:23:18 --> Utf8 Class Initialized
INFO - 2016-11-26 11:23:18 --> URI Class Initialized
DEBUG - 2016-11-26 11:23:18 --> No URI present. Default controller set.
INFO - 2016-11-26 11:23:18 --> Router Class Initialized
INFO - 2016-11-26 11:23:18 --> Output Class Initialized
INFO - 2016-11-26 11:23:18 --> Security Class Initialized
DEBUG - 2016-11-26 11:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:23:18 --> Input Class Initialized
INFO - 2016-11-26 11:23:18 --> Language Class Initialized
INFO - 2016-11-26 11:23:18 --> Loader Class Initialized
INFO - 2016-11-26 11:23:18 --> Helper loaded: url_helper
INFO - 2016-11-26 11:23:18 --> Helper loaded: form_helper
INFO - 2016-11-26 11:23:18 --> Database Driver Class Initialized
INFO - 2016-11-26 11:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:23:18 --> Controller Class Initialized
INFO - 2016-11-26 11:23:18 --> Model Class Initialized
INFO - 2016-11-26 11:23:18 --> Model Class Initialized
INFO - 2016-11-26 11:23:18 --> Model Class Initialized
INFO - 2016-11-26 11:23:18 --> Model Class Initialized
INFO - 2016-11-26 11:23:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:23:18 --> Pagination Class Initialized
INFO - 2016-11-26 11:23:18 --> Helper loaded: app_helper
INFO - 2016-11-26 11:23:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:23:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:23:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:23:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:23:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:23:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:23:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:23:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:23:18 --> Final output sent to browser
DEBUG - 2016-11-26 11:23:18 --> Total execution time: 0.4516
INFO - 2016-11-26 11:24:34 --> Config Class Initialized
INFO - 2016-11-26 11:24:34 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:24:34 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:24:34 --> Utf8 Class Initialized
INFO - 2016-11-26 11:24:34 --> URI Class Initialized
INFO - 2016-11-26 11:24:34 --> Router Class Initialized
INFO - 2016-11-26 11:24:34 --> Output Class Initialized
INFO - 2016-11-26 11:24:34 --> Security Class Initialized
DEBUG - 2016-11-26 11:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:24:34 --> Input Class Initialized
INFO - 2016-11-26 11:24:34 --> Language Class Initialized
INFO - 2016-11-26 11:24:34 --> Loader Class Initialized
INFO - 2016-11-26 11:24:34 --> Helper loaded: url_helper
INFO - 2016-11-26 11:24:34 --> Helper loaded: form_helper
INFO - 2016-11-26 11:24:34 --> Database Driver Class Initialized
INFO - 2016-11-26 11:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:24:34 --> Controller Class Initialized
INFO - 2016-11-26 11:24:34 --> Model Class Initialized
INFO - 2016-11-26 11:24:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:24:34 --> Pagination Class Initialized
INFO - 2016-11-26 11:24:34 --> Helper loaded: app_helper
INFO - 2016-11-26 11:24:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:24:34 --> Final output sent to browser
DEBUG - 2016-11-26 11:24:34 --> Total execution time: 0.4986
INFO - 2016-11-26 11:24:38 --> Config Class Initialized
INFO - 2016-11-26 11:24:38 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:24:38 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:24:38 --> Utf8 Class Initialized
INFO - 2016-11-26 11:24:38 --> URI Class Initialized
INFO - 2016-11-26 11:24:38 --> Router Class Initialized
INFO - 2016-11-26 11:24:38 --> Output Class Initialized
INFO - 2016-11-26 11:24:38 --> Security Class Initialized
DEBUG - 2016-11-26 11:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:24:38 --> Input Class Initialized
INFO - 2016-11-26 11:24:38 --> Language Class Initialized
INFO - 2016-11-26 11:24:38 --> Loader Class Initialized
INFO - 2016-11-26 11:24:38 --> Helper loaded: url_helper
INFO - 2016-11-26 11:24:38 --> Helper loaded: form_helper
INFO - 2016-11-26 11:24:38 --> Database Driver Class Initialized
INFO - 2016-11-26 11:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:24:38 --> Controller Class Initialized
INFO - 2016-11-26 11:24:38 --> Model Class Initialized
INFO - 2016-11-26 11:24:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:24:38 --> Pagination Class Initialized
INFO - 2016-11-26 11:24:38 --> Helper loaded: app_helper
INFO - 2016-11-26 11:24:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:24:38 --> Final output sent to browser
DEBUG - 2016-11-26 11:24:38 --> Total execution time: 0.2775
INFO - 2016-11-26 11:24:40 --> Config Class Initialized
INFO - 2016-11-26 11:24:40 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:24:40 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:24:40 --> Utf8 Class Initialized
INFO - 2016-11-26 11:24:40 --> URI Class Initialized
DEBUG - 2016-11-26 11:24:40 --> No URI present. Default controller set.
INFO - 2016-11-26 11:24:40 --> Router Class Initialized
INFO - 2016-11-26 11:24:40 --> Output Class Initialized
INFO - 2016-11-26 11:24:40 --> Security Class Initialized
DEBUG - 2016-11-26 11:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:24:40 --> Input Class Initialized
INFO - 2016-11-26 11:24:40 --> Language Class Initialized
INFO - 2016-11-26 11:24:40 --> Loader Class Initialized
INFO - 2016-11-26 11:24:40 --> Helper loaded: url_helper
INFO - 2016-11-26 11:24:40 --> Helper loaded: form_helper
INFO - 2016-11-26 11:24:40 --> Database Driver Class Initialized
INFO - 2016-11-26 11:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:24:40 --> Controller Class Initialized
INFO - 2016-11-26 11:24:40 --> Model Class Initialized
INFO - 2016-11-26 11:24:40 --> Model Class Initialized
INFO - 2016-11-26 11:24:40 --> Model Class Initialized
INFO - 2016-11-26 11:24:40 --> Model Class Initialized
INFO - 2016-11-26 11:24:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:24:40 --> Pagination Class Initialized
INFO - 2016-11-26 11:24:40 --> Helper loaded: app_helper
INFO - 2016-11-26 11:24:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:24:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:24:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:24:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:24:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:24:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:24:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:24:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:24:40 --> Final output sent to browser
DEBUG - 2016-11-26 11:24:41 --> Total execution time: 0.5542
INFO - 2016-11-26 11:28:29 --> Config Class Initialized
INFO - 2016-11-26 11:28:29 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:28:29 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:28:29 --> Utf8 Class Initialized
INFO - 2016-11-26 11:28:29 --> URI Class Initialized
DEBUG - 2016-11-26 11:28:29 --> No URI present. Default controller set.
INFO - 2016-11-26 11:28:29 --> Router Class Initialized
INFO - 2016-11-26 11:28:29 --> Output Class Initialized
INFO - 2016-11-26 11:28:29 --> Security Class Initialized
DEBUG - 2016-11-26 11:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:28:29 --> Input Class Initialized
INFO - 2016-11-26 11:28:29 --> Language Class Initialized
INFO - 2016-11-26 11:28:29 --> Loader Class Initialized
INFO - 2016-11-26 11:28:29 --> Helper loaded: url_helper
INFO - 2016-11-26 11:28:29 --> Helper loaded: form_helper
INFO - 2016-11-26 11:28:29 --> Database Driver Class Initialized
INFO - 2016-11-26 11:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:28:29 --> Controller Class Initialized
INFO - 2016-11-26 11:28:29 --> Model Class Initialized
INFO - 2016-11-26 11:28:29 --> Model Class Initialized
INFO - 2016-11-26 11:28:29 --> Model Class Initialized
INFO - 2016-11-26 11:28:29 --> Model Class Initialized
INFO - 2016-11-26 11:28:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:28:29 --> Pagination Class Initialized
INFO - 2016-11-26 11:28:29 --> Helper loaded: app_helper
INFO - 2016-11-26 11:28:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:28:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:28:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:28:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:28:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:28:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:28:30 --> Final output sent to browser
DEBUG - 2016-11-26 11:28:30 --> Total execution time: 0.4433
INFO - 2016-11-26 11:28:35 --> Config Class Initialized
INFO - 2016-11-26 11:28:35 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:28:35 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:28:35 --> Utf8 Class Initialized
INFO - 2016-11-26 11:28:35 --> URI Class Initialized
DEBUG - 2016-11-26 11:28:35 --> No URI present. Default controller set.
INFO - 2016-11-26 11:28:35 --> Router Class Initialized
INFO - 2016-11-26 11:28:35 --> Output Class Initialized
INFO - 2016-11-26 11:28:35 --> Security Class Initialized
DEBUG - 2016-11-26 11:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:28:35 --> Input Class Initialized
INFO - 2016-11-26 11:28:36 --> Language Class Initialized
INFO - 2016-11-26 11:28:36 --> Loader Class Initialized
INFO - 2016-11-26 11:28:36 --> Helper loaded: url_helper
INFO - 2016-11-26 11:28:36 --> Helper loaded: form_helper
INFO - 2016-11-26 11:28:36 --> Database Driver Class Initialized
INFO - 2016-11-26 11:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:28:36 --> Controller Class Initialized
INFO - 2016-11-26 11:28:36 --> Model Class Initialized
INFO - 2016-11-26 11:28:36 --> Model Class Initialized
INFO - 2016-11-26 11:28:36 --> Model Class Initialized
INFO - 2016-11-26 11:28:36 --> Model Class Initialized
INFO - 2016-11-26 11:28:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:28:36 --> Pagination Class Initialized
INFO - 2016-11-26 11:28:36 --> Helper loaded: app_helper
INFO - 2016-11-26 11:28:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:28:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:28:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:28:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:28:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:28:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:28:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:28:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:28:36 --> Final output sent to browser
DEBUG - 2016-11-26 11:28:36 --> Total execution time: 0.6465
INFO - 2016-11-26 11:28:41 --> Config Class Initialized
INFO - 2016-11-26 11:28:41 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:28:41 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:28:41 --> Utf8 Class Initialized
INFO - 2016-11-26 11:28:41 --> URI Class Initialized
DEBUG - 2016-11-26 11:28:41 --> No URI present. Default controller set.
INFO - 2016-11-26 11:28:41 --> Router Class Initialized
INFO - 2016-11-26 11:28:41 --> Output Class Initialized
INFO - 2016-11-26 11:28:41 --> Security Class Initialized
DEBUG - 2016-11-26 11:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:28:41 --> Input Class Initialized
INFO - 2016-11-26 11:28:41 --> Language Class Initialized
INFO - 2016-11-26 11:28:41 --> Loader Class Initialized
INFO - 2016-11-26 11:28:41 --> Helper loaded: url_helper
INFO - 2016-11-26 11:28:41 --> Helper loaded: form_helper
INFO - 2016-11-26 11:28:41 --> Database Driver Class Initialized
INFO - 2016-11-26 11:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:28:41 --> Controller Class Initialized
INFO - 2016-11-26 11:28:41 --> Model Class Initialized
INFO - 2016-11-26 11:28:41 --> Model Class Initialized
INFO - 2016-11-26 11:28:41 --> Model Class Initialized
INFO - 2016-11-26 11:28:41 --> Model Class Initialized
INFO - 2016-11-26 11:28:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:28:41 --> Pagination Class Initialized
INFO - 2016-11-26 11:28:41 --> Helper loaded: app_helper
INFO - 2016-11-26 11:28:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:28:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:28:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:28:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:28:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:28:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:28:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:28:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:28:41 --> Final output sent to browser
DEBUG - 2016-11-26 11:28:41 --> Total execution time: 0.6566
INFO - 2016-11-26 11:28:45 --> Config Class Initialized
INFO - 2016-11-26 11:28:45 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:28:45 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:28:45 --> Utf8 Class Initialized
INFO - 2016-11-26 11:28:45 --> URI Class Initialized
INFO - 2016-11-26 11:28:45 --> Router Class Initialized
INFO - 2016-11-26 11:28:45 --> Output Class Initialized
INFO - 2016-11-26 11:28:45 --> Security Class Initialized
DEBUG - 2016-11-26 11:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:28:45 --> Input Class Initialized
INFO - 2016-11-26 11:28:45 --> Language Class Initialized
INFO - 2016-11-26 11:28:45 --> Loader Class Initialized
INFO - 2016-11-26 11:28:45 --> Helper loaded: url_helper
INFO - 2016-11-26 11:28:45 --> Helper loaded: form_helper
INFO - 2016-11-26 11:28:45 --> Database Driver Class Initialized
INFO - 2016-11-26 11:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:28:45 --> Controller Class Initialized
INFO - 2016-11-26 11:28:45 --> Model Class Initialized
INFO - 2016-11-26 11:28:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:28:45 --> Pagination Class Initialized
INFO - 2016-11-26 11:28:45 --> Helper loaded: app_helper
INFO - 2016-11-26 11:28:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:28:45 --> Final output sent to browser
DEBUG - 2016-11-26 11:28:45 --> Total execution time: 0.2793
INFO - 2016-11-26 11:28:47 --> Config Class Initialized
INFO - 2016-11-26 11:28:47 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:28:47 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:28:47 --> Utf8 Class Initialized
INFO - 2016-11-26 11:28:47 --> URI Class Initialized
INFO - 2016-11-26 11:28:47 --> Router Class Initialized
INFO - 2016-11-26 11:28:47 --> Output Class Initialized
INFO - 2016-11-26 11:28:47 --> Security Class Initialized
DEBUG - 2016-11-26 11:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:28:47 --> Input Class Initialized
INFO - 2016-11-26 11:28:47 --> Language Class Initialized
INFO - 2016-11-26 11:28:47 --> Loader Class Initialized
INFO - 2016-11-26 11:28:48 --> Helper loaded: url_helper
INFO - 2016-11-26 11:28:48 --> Helper loaded: form_helper
INFO - 2016-11-26 11:28:48 --> Database Driver Class Initialized
INFO - 2016-11-26 11:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:28:48 --> Controller Class Initialized
INFO - 2016-11-26 11:28:48 --> Model Class Initialized
INFO - 2016-11-26 11:28:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:28:48 --> Pagination Class Initialized
INFO - 2016-11-26 11:28:48 --> Helper loaded: app_helper
INFO - 2016-11-26 11:28:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:28:48 --> Final output sent to browser
DEBUG - 2016-11-26 11:28:48 --> Total execution time: 0.3483
INFO - 2016-11-26 11:28:50 --> Config Class Initialized
INFO - 2016-11-26 11:28:50 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:28:50 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:28:50 --> Utf8 Class Initialized
INFO - 2016-11-26 11:28:50 --> URI Class Initialized
INFO - 2016-11-26 11:28:50 --> Router Class Initialized
INFO - 2016-11-26 11:28:50 --> Output Class Initialized
INFO - 2016-11-26 11:28:50 --> Security Class Initialized
DEBUG - 2016-11-26 11:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:28:50 --> Input Class Initialized
INFO - 2016-11-26 11:28:50 --> Language Class Initialized
INFO - 2016-11-26 11:28:50 --> Loader Class Initialized
INFO - 2016-11-26 11:28:50 --> Helper loaded: url_helper
INFO - 2016-11-26 11:28:50 --> Helper loaded: form_helper
INFO - 2016-11-26 11:28:50 --> Database Driver Class Initialized
INFO - 2016-11-26 11:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:28:50 --> Controller Class Initialized
INFO - 2016-11-26 11:28:50 --> Model Class Initialized
INFO - 2016-11-26 11:28:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:28:50 --> Pagination Class Initialized
INFO - 2016-11-26 11:28:50 --> Helper loaded: app_helper
INFO - 2016-11-26 11:28:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:28:50 --> Final output sent to browser
DEBUG - 2016-11-26 11:28:50 --> Total execution time: 0.2831
INFO - 2016-11-26 11:28:52 --> Config Class Initialized
INFO - 2016-11-26 11:28:52 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:28:52 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:28:52 --> Utf8 Class Initialized
INFO - 2016-11-26 11:28:52 --> URI Class Initialized
INFO - 2016-11-26 11:28:52 --> Router Class Initialized
INFO - 2016-11-26 11:28:52 --> Output Class Initialized
INFO - 2016-11-26 11:28:52 --> Security Class Initialized
DEBUG - 2016-11-26 11:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:28:52 --> Input Class Initialized
INFO - 2016-11-26 11:28:52 --> Language Class Initialized
INFO - 2016-11-26 11:28:52 --> Loader Class Initialized
INFO - 2016-11-26 11:28:52 --> Helper loaded: url_helper
INFO - 2016-11-26 11:28:52 --> Helper loaded: form_helper
INFO - 2016-11-26 11:28:52 --> Database Driver Class Initialized
INFO - 2016-11-26 11:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:28:52 --> Controller Class Initialized
INFO - 2016-11-26 11:28:52 --> Model Class Initialized
INFO - 2016-11-26 11:28:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:28:52 --> Pagination Class Initialized
INFO - 2016-11-26 11:28:52 --> Helper loaded: app_helper
INFO - 2016-11-26 11:28:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:28:52 --> Final output sent to browser
DEBUG - 2016-11-26 11:28:52 --> Total execution time: 0.3321
INFO - 2016-11-26 11:28:55 --> Config Class Initialized
INFO - 2016-11-26 11:28:55 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:28:55 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:28:55 --> Utf8 Class Initialized
INFO - 2016-11-26 11:28:55 --> URI Class Initialized
INFO - 2016-11-26 11:28:55 --> Router Class Initialized
INFO - 2016-11-26 11:28:55 --> Output Class Initialized
INFO - 2016-11-26 11:28:55 --> Security Class Initialized
DEBUG - 2016-11-26 11:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:28:55 --> Input Class Initialized
INFO - 2016-11-26 11:28:55 --> Language Class Initialized
INFO - 2016-11-26 11:28:55 --> Loader Class Initialized
INFO - 2016-11-26 11:28:55 --> Helper loaded: url_helper
INFO - 2016-11-26 11:28:55 --> Helper loaded: form_helper
INFO - 2016-11-26 11:28:56 --> Database Driver Class Initialized
INFO - 2016-11-26 11:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:28:56 --> Controller Class Initialized
INFO - 2016-11-26 11:28:56 --> Model Class Initialized
INFO - 2016-11-26 11:28:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:28:56 --> Pagination Class Initialized
INFO - 2016-11-26 11:28:56 --> Helper loaded: app_helper
INFO - 2016-11-26 11:28:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:28:56 --> Final output sent to browser
DEBUG - 2016-11-26 11:28:56 --> Total execution time: 0.4338
INFO - 2016-11-26 11:28:56 --> Config Class Initialized
INFO - 2016-11-26 11:28:56 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:28:56 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:28:56 --> Utf8 Class Initialized
INFO - 2016-11-26 11:28:56 --> URI Class Initialized
DEBUG - 2016-11-26 11:28:56 --> No URI present. Default controller set.
INFO - 2016-11-26 11:28:56 --> Router Class Initialized
INFO - 2016-11-26 11:28:56 --> Output Class Initialized
INFO - 2016-11-26 11:28:56 --> Security Class Initialized
DEBUG - 2016-11-26 11:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:28:56 --> Input Class Initialized
INFO - 2016-11-26 11:28:56 --> Language Class Initialized
INFO - 2016-11-26 11:28:56 --> Loader Class Initialized
INFO - 2016-11-26 11:28:56 --> Helper loaded: url_helper
INFO - 2016-11-26 11:28:56 --> Helper loaded: form_helper
INFO - 2016-11-26 11:28:56 --> Database Driver Class Initialized
INFO - 2016-11-26 11:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:28:56 --> Controller Class Initialized
INFO - 2016-11-26 11:28:56 --> Model Class Initialized
INFO - 2016-11-26 11:28:56 --> Model Class Initialized
INFO - 2016-11-26 11:28:56 --> Model Class Initialized
INFO - 2016-11-26 11:28:56 --> Model Class Initialized
INFO - 2016-11-26 11:28:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:28:56 --> Pagination Class Initialized
INFO - 2016-11-26 11:28:56 --> Helper loaded: app_helper
INFO - 2016-11-26 11:28:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:28:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:28:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:28:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:28:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:28:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:28:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:28:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:28:57 --> Final output sent to browser
DEBUG - 2016-11-26 11:28:57 --> Total execution time: 0.6545
INFO - 2016-11-26 11:31:21 --> Config Class Initialized
INFO - 2016-11-26 11:31:21 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:31:21 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:31:21 --> Utf8 Class Initialized
INFO - 2016-11-26 11:31:21 --> URI Class Initialized
INFO - 2016-11-26 11:31:21 --> Router Class Initialized
INFO - 2016-11-26 11:31:21 --> Output Class Initialized
INFO - 2016-11-26 11:31:21 --> Security Class Initialized
DEBUG - 2016-11-26 11:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:31:21 --> Input Class Initialized
INFO - 2016-11-26 11:31:21 --> Language Class Initialized
ERROR - 2016-11-26 11:31:21 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 89
INFO - 2016-11-26 11:31:37 --> Config Class Initialized
INFO - 2016-11-26 11:31:37 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:31:37 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:31:37 --> Utf8 Class Initialized
INFO - 2016-11-26 11:31:37 --> URI Class Initialized
INFO - 2016-11-26 11:31:37 --> Router Class Initialized
INFO - 2016-11-26 11:31:37 --> Output Class Initialized
INFO - 2016-11-26 11:31:37 --> Security Class Initialized
DEBUG - 2016-11-26 11:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:31:37 --> Input Class Initialized
INFO - 2016-11-26 11:31:37 --> Language Class Initialized
INFO - 2016-11-26 11:31:37 --> Loader Class Initialized
INFO - 2016-11-26 11:31:37 --> Helper loaded: url_helper
INFO - 2016-11-26 11:31:37 --> Helper loaded: form_helper
INFO - 2016-11-26 11:31:37 --> Database Driver Class Initialized
INFO - 2016-11-26 11:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:31:37 --> Controller Class Initialized
INFO - 2016-11-26 11:31:37 --> Model Class Initialized
INFO - 2016-11-26 11:31:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:31:37 --> Pagination Class Initialized
INFO - 2016-11-26 11:31:37 --> Helper loaded: app_helper
INFO - 2016-11-26 11:31:37 --> Form Validation Class Initialized
INFO - 2016-11-26 11:31:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-26 11:31:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:31:37 --> Final output sent to browser
DEBUG - 2016-11-26 11:31:37 --> Total execution time: 0.4688
INFO - 2016-11-26 11:31:47 --> Config Class Initialized
INFO - 2016-11-26 11:31:47 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:31:47 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:31:47 --> Utf8 Class Initialized
INFO - 2016-11-26 11:31:47 --> URI Class Initialized
DEBUG - 2016-11-26 11:31:47 --> No URI present. Default controller set.
INFO - 2016-11-26 11:31:47 --> Router Class Initialized
INFO - 2016-11-26 11:31:47 --> Output Class Initialized
INFO - 2016-11-26 11:31:47 --> Security Class Initialized
DEBUG - 2016-11-26 11:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:31:47 --> Input Class Initialized
INFO - 2016-11-26 11:31:47 --> Language Class Initialized
INFO - 2016-11-26 11:31:47 --> Loader Class Initialized
INFO - 2016-11-26 11:31:47 --> Helper loaded: url_helper
INFO - 2016-11-26 11:31:47 --> Helper loaded: form_helper
INFO - 2016-11-26 11:31:47 --> Database Driver Class Initialized
INFO - 2016-11-26 11:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:31:47 --> Controller Class Initialized
INFO - 2016-11-26 11:31:47 --> Model Class Initialized
INFO - 2016-11-26 11:31:47 --> Model Class Initialized
INFO - 2016-11-26 11:31:47 --> Model Class Initialized
INFO - 2016-11-26 11:31:47 --> Model Class Initialized
INFO - 2016-11-26 11:31:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:31:47 --> Pagination Class Initialized
INFO - 2016-11-26 11:31:48 --> Helper loaded: app_helper
INFO - 2016-11-26 11:31:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:31:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:31:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:31:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:31:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:31:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:31:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:31:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:31:48 --> Final output sent to browser
DEBUG - 2016-11-26 11:31:48 --> Total execution time: 0.4990
INFO - 2016-11-26 11:31:56 --> Config Class Initialized
INFO - 2016-11-26 11:31:56 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:31:56 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:31:56 --> Utf8 Class Initialized
INFO - 2016-11-26 11:31:56 --> URI Class Initialized
INFO - 2016-11-26 11:31:56 --> Router Class Initialized
INFO - 2016-11-26 11:31:56 --> Output Class Initialized
INFO - 2016-11-26 11:31:56 --> Security Class Initialized
DEBUG - 2016-11-26 11:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:31:56 --> Input Class Initialized
INFO - 2016-11-26 11:31:56 --> Language Class Initialized
INFO - 2016-11-26 11:31:56 --> Loader Class Initialized
INFO - 2016-11-26 11:31:56 --> Helper loaded: url_helper
INFO - 2016-11-26 11:31:56 --> Helper loaded: form_helper
INFO - 2016-11-26 11:31:56 --> Database Driver Class Initialized
INFO - 2016-11-26 11:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:31:57 --> Controller Class Initialized
INFO - 2016-11-26 11:31:57 --> Model Class Initialized
INFO - 2016-11-26 11:31:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:31:57 --> Pagination Class Initialized
INFO - 2016-11-26 11:31:57 --> Helper loaded: app_helper
INFO - 2016-11-26 11:31:57 --> Form Validation Class Initialized
INFO - 2016-11-26 11:31:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-26 11:31:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:31:57 --> Final output sent to browser
DEBUG - 2016-11-26 11:31:57 --> Total execution time: 0.9654
INFO - 2016-11-26 11:32:54 --> Config Class Initialized
INFO - 2016-11-26 11:32:54 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:32:54 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:32:54 --> Utf8 Class Initialized
INFO - 2016-11-26 11:32:54 --> URI Class Initialized
DEBUG - 2016-11-26 11:32:54 --> No URI present. Default controller set.
INFO - 2016-11-26 11:32:54 --> Router Class Initialized
INFO - 2016-11-26 11:32:54 --> Output Class Initialized
INFO - 2016-11-26 11:32:54 --> Security Class Initialized
DEBUG - 2016-11-26 11:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:32:54 --> Input Class Initialized
INFO - 2016-11-26 11:32:54 --> Language Class Initialized
INFO - 2016-11-26 11:32:54 --> Loader Class Initialized
INFO - 2016-11-26 11:32:54 --> Helper loaded: url_helper
INFO - 2016-11-26 11:32:54 --> Helper loaded: form_helper
INFO - 2016-11-26 11:32:54 --> Database Driver Class Initialized
INFO - 2016-11-26 11:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:32:55 --> Controller Class Initialized
INFO - 2016-11-26 11:32:55 --> Model Class Initialized
INFO - 2016-11-26 11:32:55 --> Model Class Initialized
INFO - 2016-11-26 11:32:55 --> Model Class Initialized
INFO - 2016-11-26 11:32:55 --> Model Class Initialized
INFO - 2016-11-26 11:32:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:32:55 --> Pagination Class Initialized
INFO - 2016-11-26 11:32:55 --> Helper loaded: app_helper
INFO - 2016-11-26 11:32:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:32:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:32:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:32:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:32:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:32:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:32:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:32:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:32:55 --> Final output sent to browser
DEBUG - 2016-11-26 11:32:55 --> Total execution time: 0.5138
INFO - 2016-11-26 11:32:58 --> Config Class Initialized
INFO - 2016-11-26 11:32:58 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:32:58 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:32:58 --> Utf8 Class Initialized
INFO - 2016-11-26 11:32:58 --> URI Class Initialized
INFO - 2016-11-26 11:32:58 --> Router Class Initialized
INFO - 2016-11-26 11:32:58 --> Output Class Initialized
INFO - 2016-11-26 11:32:58 --> Security Class Initialized
DEBUG - 2016-11-26 11:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:32:58 --> Input Class Initialized
INFO - 2016-11-26 11:32:58 --> Language Class Initialized
INFO - 2016-11-26 11:32:58 --> Loader Class Initialized
INFO - 2016-11-26 11:32:58 --> Helper loaded: url_helper
INFO - 2016-11-26 11:32:58 --> Helper loaded: form_helper
INFO - 2016-11-26 11:32:58 --> Database Driver Class Initialized
INFO - 2016-11-26 11:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:32:58 --> Controller Class Initialized
INFO - 2016-11-26 11:32:58 --> Model Class Initialized
INFO - 2016-11-26 11:32:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:32:58 --> Pagination Class Initialized
INFO - 2016-11-26 11:32:58 --> Helper loaded: app_helper
INFO - 2016-11-26 11:32:58 --> Form Validation Class Initialized
INFO - 2016-11-26 11:32:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-26 11:32:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:32:58 --> Final output sent to browser
DEBUG - 2016-11-26 11:32:58 --> Total execution time: 0.4509
INFO - 2016-11-26 11:33:04 --> Config Class Initialized
INFO - 2016-11-26 11:33:04 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:33:04 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:33:04 --> Utf8 Class Initialized
INFO - 2016-11-26 11:33:04 --> URI Class Initialized
DEBUG - 2016-11-26 11:33:04 --> No URI present. Default controller set.
INFO - 2016-11-26 11:33:04 --> Router Class Initialized
INFO - 2016-11-26 11:33:04 --> Output Class Initialized
INFO - 2016-11-26 11:33:04 --> Security Class Initialized
DEBUG - 2016-11-26 11:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:33:04 --> Input Class Initialized
INFO - 2016-11-26 11:33:04 --> Language Class Initialized
INFO - 2016-11-26 11:33:04 --> Loader Class Initialized
INFO - 2016-11-26 11:33:04 --> Helper loaded: url_helper
INFO - 2016-11-26 11:33:04 --> Helper loaded: form_helper
INFO - 2016-11-26 11:33:04 --> Database Driver Class Initialized
INFO - 2016-11-26 11:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:33:04 --> Controller Class Initialized
INFO - 2016-11-26 11:33:04 --> Model Class Initialized
INFO - 2016-11-26 11:33:04 --> Model Class Initialized
INFO - 2016-11-26 11:33:04 --> Model Class Initialized
INFO - 2016-11-26 11:33:04 --> Model Class Initialized
INFO - 2016-11-26 11:33:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:33:04 --> Pagination Class Initialized
INFO - 2016-11-26 11:33:04 --> Helper loaded: app_helper
INFO - 2016-11-26 11:33:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:33:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:33:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:33:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:33:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:33:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:33:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:33:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:33:04 --> Final output sent to browser
DEBUG - 2016-11-26 11:33:04 --> Total execution time: 0.4799
INFO - 2016-11-26 11:33:21 --> Config Class Initialized
INFO - 2016-11-26 11:33:21 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:33:21 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:33:21 --> Utf8 Class Initialized
INFO - 2016-11-26 11:33:21 --> URI Class Initialized
DEBUG - 2016-11-26 11:33:21 --> No URI present. Default controller set.
INFO - 2016-11-26 11:33:21 --> Router Class Initialized
INFO - 2016-11-26 11:33:21 --> Output Class Initialized
INFO - 2016-11-26 11:33:21 --> Security Class Initialized
DEBUG - 2016-11-26 11:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:33:21 --> Input Class Initialized
INFO - 2016-11-26 11:33:21 --> Language Class Initialized
INFO - 2016-11-26 11:33:21 --> Loader Class Initialized
INFO - 2016-11-26 11:33:21 --> Helper loaded: url_helper
INFO - 2016-11-26 11:33:21 --> Helper loaded: form_helper
INFO - 2016-11-26 11:33:21 --> Database Driver Class Initialized
INFO - 2016-11-26 11:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:33:21 --> Controller Class Initialized
INFO - 2016-11-26 11:33:21 --> Model Class Initialized
INFO - 2016-11-26 11:33:21 --> Model Class Initialized
INFO - 2016-11-26 11:33:21 --> Model Class Initialized
INFO - 2016-11-26 11:33:21 --> Model Class Initialized
INFO - 2016-11-26 11:33:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:33:21 --> Pagination Class Initialized
INFO - 2016-11-26 11:33:21 --> Helper loaded: app_helper
INFO - 2016-11-26 11:33:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:33:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:33:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:33:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:33:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:33:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:33:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:33:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:33:21 --> Final output sent to browser
DEBUG - 2016-11-26 11:33:22 --> Total execution time: 0.4565
INFO - 2016-11-26 11:36:01 --> Config Class Initialized
INFO - 2016-11-26 11:36:01 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:36:01 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:36:01 --> Utf8 Class Initialized
INFO - 2016-11-26 11:36:01 --> URI Class Initialized
INFO - 2016-11-26 11:36:01 --> Router Class Initialized
INFO - 2016-11-26 11:36:01 --> Output Class Initialized
INFO - 2016-11-26 11:36:01 --> Security Class Initialized
DEBUG - 2016-11-26 11:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:36:01 --> Input Class Initialized
INFO - 2016-11-26 11:36:01 --> Language Class Initialized
INFO - 2016-11-26 11:36:01 --> Loader Class Initialized
INFO - 2016-11-26 11:36:01 --> Helper loaded: url_helper
INFO - 2016-11-26 11:36:01 --> Helper loaded: form_helper
INFO - 2016-11-26 11:36:01 --> Database Driver Class Initialized
INFO - 2016-11-26 11:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:36:01 --> Controller Class Initialized
INFO - 2016-11-26 11:36:01 --> Model Class Initialized
INFO - 2016-11-26 11:36:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:36:01 --> Pagination Class Initialized
INFO - 2016-11-26 11:36:01 --> Helper loaded: app_helper
INFO - 2016-11-26 11:36:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:36:01 --> Final output sent to browser
DEBUG - 2016-11-26 11:36:01 --> Total execution time: 0.3599
INFO - 2016-11-26 11:36:05 --> Config Class Initialized
INFO - 2016-11-26 11:36:05 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:36:05 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:36:05 --> Utf8 Class Initialized
INFO - 2016-11-26 11:36:05 --> URI Class Initialized
INFO - 2016-11-26 11:36:05 --> Router Class Initialized
INFO - 2016-11-26 11:36:05 --> Output Class Initialized
INFO - 2016-11-26 11:36:05 --> Security Class Initialized
DEBUG - 2016-11-26 11:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:36:05 --> Input Class Initialized
INFO - 2016-11-26 11:36:05 --> Language Class Initialized
INFO - 2016-11-26 11:36:05 --> Loader Class Initialized
INFO - 2016-11-26 11:36:05 --> Helper loaded: url_helper
INFO - 2016-11-26 11:36:05 --> Helper loaded: form_helper
INFO - 2016-11-26 11:36:06 --> Database Driver Class Initialized
INFO - 2016-11-26 11:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:36:06 --> Controller Class Initialized
INFO - 2016-11-26 11:36:06 --> Model Class Initialized
INFO - 2016-11-26 11:36:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:36:06 --> Pagination Class Initialized
INFO - 2016-11-26 11:36:06 --> Helper loaded: app_helper
INFO - 2016-11-26 11:36:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:36:06 --> Final output sent to browser
DEBUG - 2016-11-26 11:36:06 --> Total execution time: 0.3965
INFO - 2016-11-26 11:36:06 --> Config Class Initialized
INFO - 2016-11-26 11:36:06 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:36:06 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:36:06 --> Utf8 Class Initialized
INFO - 2016-11-26 11:36:06 --> URI Class Initialized
DEBUG - 2016-11-26 11:36:06 --> No URI present. Default controller set.
INFO - 2016-11-26 11:36:06 --> Router Class Initialized
INFO - 2016-11-26 11:36:06 --> Output Class Initialized
INFO - 2016-11-26 11:36:06 --> Security Class Initialized
DEBUG - 2016-11-26 11:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:36:06 --> Input Class Initialized
INFO - 2016-11-26 11:36:06 --> Language Class Initialized
INFO - 2016-11-26 11:36:06 --> Loader Class Initialized
INFO - 2016-11-26 11:36:06 --> Helper loaded: url_helper
INFO - 2016-11-26 11:36:06 --> Helper loaded: form_helper
INFO - 2016-11-26 11:36:06 --> Database Driver Class Initialized
INFO - 2016-11-26 11:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:36:06 --> Controller Class Initialized
INFO - 2016-11-26 11:36:06 --> Model Class Initialized
INFO - 2016-11-26 11:36:06 --> Model Class Initialized
INFO - 2016-11-26 11:36:06 --> Model Class Initialized
INFO - 2016-11-26 11:36:06 --> Model Class Initialized
INFO - 2016-11-26 11:36:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:36:06 --> Pagination Class Initialized
INFO - 2016-11-26 11:36:06 --> Helper loaded: app_helper
INFO - 2016-11-26 11:36:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:36:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:36:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:36:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:36:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:36:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:36:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:36:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:36:06 --> Final output sent to browser
DEBUG - 2016-11-26 11:36:06 --> Total execution time: 0.4759
INFO - 2016-11-26 11:39:14 --> Config Class Initialized
INFO - 2016-11-26 11:39:14 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:39:14 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:39:14 --> Utf8 Class Initialized
INFO - 2016-11-26 11:39:14 --> URI Class Initialized
DEBUG - 2016-11-26 11:39:14 --> No URI present. Default controller set.
INFO - 2016-11-26 11:39:14 --> Router Class Initialized
INFO - 2016-11-26 11:39:14 --> Output Class Initialized
INFO - 2016-11-26 11:39:14 --> Security Class Initialized
DEBUG - 2016-11-26 11:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:39:14 --> Input Class Initialized
INFO - 2016-11-26 11:39:14 --> Language Class Initialized
INFO - 2016-11-26 11:39:14 --> Loader Class Initialized
INFO - 2016-11-26 11:39:14 --> Helper loaded: url_helper
INFO - 2016-11-26 11:39:14 --> Helper loaded: form_helper
INFO - 2016-11-26 11:39:14 --> Database Driver Class Initialized
INFO - 2016-11-26 11:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:39:14 --> Controller Class Initialized
INFO - 2016-11-26 11:39:14 --> Model Class Initialized
INFO - 2016-11-26 11:39:14 --> Model Class Initialized
INFO - 2016-11-26 11:39:14 --> Model Class Initialized
INFO - 2016-11-26 11:39:14 --> Model Class Initialized
INFO - 2016-11-26 11:39:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:39:14 --> Pagination Class Initialized
INFO - 2016-11-26 11:39:14 --> Helper loaded: app_helper
INFO - 2016-11-26 11:39:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:39:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-26 11:39:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-26 11:39:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-26 11:39:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-26 11:39:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-26 11:39:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-26 11:39:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:39:14 --> Final output sent to browser
DEBUG - 2016-11-26 11:39:14 --> Total execution time: 0.4670
INFO - 2016-11-26 11:40:25 --> Config Class Initialized
INFO - 2016-11-26 11:40:25 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:40:25 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:40:25 --> Utf8 Class Initialized
INFO - 2016-11-26 11:40:25 --> URI Class Initialized
INFO - 2016-11-26 11:40:25 --> Router Class Initialized
INFO - 2016-11-26 11:40:25 --> Output Class Initialized
INFO - 2016-11-26 11:40:25 --> Security Class Initialized
DEBUG - 2016-11-26 11:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:40:25 --> Input Class Initialized
INFO - 2016-11-26 11:40:25 --> Language Class Initialized
INFO - 2016-11-26 11:40:25 --> Loader Class Initialized
INFO - 2016-11-26 11:40:25 --> Helper loaded: url_helper
INFO - 2016-11-26 11:40:25 --> Helper loaded: form_helper
INFO - 2016-11-26 11:40:25 --> Database Driver Class Initialized
INFO - 2016-11-26 11:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:40:26 --> Controller Class Initialized
INFO - 2016-11-26 11:40:26 --> Model Class Initialized
INFO - 2016-11-26 11:40:26 --> Model Class Initialized
INFO - 2016-11-26 11:40:26 --> Model Class Initialized
INFO - 2016-11-26 11:40:26 --> Model Class Initialized
INFO - 2016-11-26 11:40:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:40:26 --> Pagination Class Initialized
INFO - 2016-11-26 11:40:26 --> Helper loaded: app_helper
DEBUG - 2016-11-26 11:40:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-26 11:40:26 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-26 11:40:26 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-26 11:40:26 --> Config Class Initialized
INFO - 2016-11-26 11:40:26 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:40:26 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:40:26 --> Utf8 Class Initialized
INFO - 2016-11-26 11:40:26 --> URI Class Initialized
DEBUG - 2016-11-26 11:40:26 --> No URI present. Default controller set.
INFO - 2016-11-26 11:40:26 --> Router Class Initialized
INFO - 2016-11-26 11:40:26 --> Output Class Initialized
INFO - 2016-11-26 11:40:26 --> Security Class Initialized
DEBUG - 2016-11-26 11:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:40:26 --> Input Class Initialized
INFO - 2016-11-26 11:40:26 --> Language Class Initialized
INFO - 2016-11-26 11:40:26 --> Loader Class Initialized
INFO - 2016-11-26 11:40:26 --> Helper loaded: url_helper
INFO - 2016-11-26 11:40:26 --> Helper loaded: form_helper
INFO - 2016-11-26 11:40:26 --> Database Driver Class Initialized
INFO - 2016-11-26 11:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:40:26 --> Controller Class Initialized
INFO - 2016-11-26 11:40:26 --> Model Class Initialized
INFO - 2016-11-26 11:40:26 --> Model Class Initialized
INFO - 2016-11-26 11:40:26 --> Model Class Initialized
INFO - 2016-11-26 11:40:26 --> Model Class Initialized
INFO - 2016-11-26 11:40:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:40:26 --> Pagination Class Initialized
INFO - 2016-11-26 11:40:26 --> Helper loaded: app_helper
INFO - 2016-11-26 11:40:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:40:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-26 11:40:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:40:26 --> Final output sent to browser
DEBUG - 2016-11-26 11:40:26 --> Total execution time: 0.3735
INFO - 2016-11-26 11:40:31 --> Config Class Initialized
INFO - 2016-11-26 11:40:31 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:40:31 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:40:31 --> Utf8 Class Initialized
INFO - 2016-11-26 11:40:31 --> URI Class Initialized
DEBUG - 2016-11-26 11:40:31 --> No URI present. Default controller set.
INFO - 2016-11-26 11:40:31 --> Router Class Initialized
INFO - 2016-11-26 11:40:31 --> Output Class Initialized
INFO - 2016-11-26 11:40:31 --> Security Class Initialized
DEBUG - 2016-11-26 11:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:40:31 --> Input Class Initialized
INFO - 2016-11-26 11:40:31 --> Language Class Initialized
INFO - 2016-11-26 11:40:31 --> Loader Class Initialized
INFO - 2016-11-26 11:40:31 --> Helper loaded: url_helper
INFO - 2016-11-26 11:40:31 --> Helper loaded: form_helper
INFO - 2016-11-26 11:40:31 --> Database Driver Class Initialized
INFO - 2016-11-26 11:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:40:31 --> Controller Class Initialized
INFO - 2016-11-26 11:40:31 --> Model Class Initialized
INFO - 2016-11-26 11:40:31 --> Model Class Initialized
INFO - 2016-11-26 11:40:31 --> Model Class Initialized
INFO - 2016-11-26 11:40:31 --> Model Class Initialized
INFO - 2016-11-26 11:40:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:40:31 --> Pagination Class Initialized
INFO - 2016-11-26 11:40:31 --> Helper loaded: app_helper
INFO - 2016-11-26 11:40:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:40:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-26 11:40:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:40:31 --> Final output sent to browser
DEBUG - 2016-11-26 11:40:31 --> Total execution time: 0.3948
INFO - 2016-11-26 11:41:28 --> Config Class Initialized
INFO - 2016-11-26 11:41:28 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:41:28 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:41:28 --> Utf8 Class Initialized
INFO - 2016-11-26 11:41:28 --> URI Class Initialized
DEBUG - 2016-11-26 11:41:28 --> No URI present. Default controller set.
INFO - 2016-11-26 11:41:28 --> Router Class Initialized
INFO - 2016-11-26 11:41:28 --> Output Class Initialized
INFO - 2016-11-26 11:41:28 --> Security Class Initialized
DEBUG - 2016-11-26 11:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:41:28 --> Input Class Initialized
INFO - 2016-11-26 11:41:28 --> Language Class Initialized
INFO - 2016-11-26 11:41:28 --> Loader Class Initialized
INFO - 2016-11-26 11:41:28 --> Helper loaded: url_helper
INFO - 2016-11-26 11:41:28 --> Helper loaded: form_helper
INFO - 2016-11-26 11:41:28 --> Database Driver Class Initialized
INFO - 2016-11-26 11:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:41:28 --> Controller Class Initialized
INFO - 2016-11-26 11:41:28 --> Model Class Initialized
INFO - 2016-11-26 11:41:28 --> Model Class Initialized
INFO - 2016-11-26 11:41:28 --> Model Class Initialized
INFO - 2016-11-26 11:41:28 --> Model Class Initialized
INFO - 2016-11-26 11:41:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:41:28 --> Pagination Class Initialized
INFO - 2016-11-26 11:41:28 --> Helper loaded: app_helper
INFO - 2016-11-26 11:41:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:41:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-26 11:41:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:41:28 --> Final output sent to browser
DEBUG - 2016-11-26 11:41:28 --> Total execution time: 0.3944
INFO - 2016-11-26 11:41:33 --> Config Class Initialized
INFO - 2016-11-26 11:41:33 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:41:33 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:41:33 --> Utf8 Class Initialized
INFO - 2016-11-26 11:41:33 --> URI Class Initialized
DEBUG - 2016-11-26 11:41:33 --> No URI present. Default controller set.
INFO - 2016-11-26 11:41:33 --> Router Class Initialized
INFO - 2016-11-26 11:41:33 --> Output Class Initialized
INFO - 2016-11-26 11:41:33 --> Security Class Initialized
DEBUG - 2016-11-26 11:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:41:33 --> Input Class Initialized
INFO - 2016-11-26 11:41:33 --> Language Class Initialized
INFO - 2016-11-26 11:41:33 --> Loader Class Initialized
INFO - 2016-11-26 11:41:33 --> Helper loaded: url_helper
INFO - 2016-11-26 11:41:33 --> Helper loaded: form_helper
INFO - 2016-11-26 11:41:33 --> Database Driver Class Initialized
INFO - 2016-11-26 11:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:41:33 --> Controller Class Initialized
INFO - 2016-11-26 11:41:33 --> Model Class Initialized
INFO - 2016-11-26 11:41:33 --> Model Class Initialized
INFO - 2016-11-26 11:41:33 --> Model Class Initialized
INFO - 2016-11-26 11:41:33 --> Model Class Initialized
INFO - 2016-11-26 11:41:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:41:33 --> Pagination Class Initialized
INFO - 2016-11-26 11:41:33 --> Helper loaded: app_helper
INFO - 2016-11-26 11:41:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:41:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-26 11:41:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:41:33 --> Final output sent to browser
DEBUG - 2016-11-26 11:41:33 --> Total execution time: 0.4227
INFO - 2016-11-26 11:41:38 --> Config Class Initialized
INFO - 2016-11-26 11:41:38 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:41:38 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:41:38 --> Utf8 Class Initialized
INFO - 2016-11-26 11:41:38 --> URI Class Initialized
DEBUG - 2016-11-26 11:41:38 --> No URI present. Default controller set.
INFO - 2016-11-26 11:41:38 --> Router Class Initialized
INFO - 2016-11-26 11:41:38 --> Output Class Initialized
INFO - 2016-11-26 11:41:38 --> Security Class Initialized
DEBUG - 2016-11-26 11:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:41:38 --> Input Class Initialized
INFO - 2016-11-26 11:41:38 --> Language Class Initialized
INFO - 2016-11-26 11:41:38 --> Loader Class Initialized
INFO - 2016-11-26 11:41:38 --> Helper loaded: url_helper
INFO - 2016-11-26 11:41:38 --> Helper loaded: form_helper
INFO - 2016-11-26 11:41:38 --> Database Driver Class Initialized
INFO - 2016-11-26 11:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:41:38 --> Controller Class Initialized
INFO - 2016-11-26 11:41:38 --> Model Class Initialized
INFO - 2016-11-26 11:41:38 --> Model Class Initialized
INFO - 2016-11-26 11:41:38 --> Model Class Initialized
INFO - 2016-11-26 11:41:38 --> Model Class Initialized
INFO - 2016-11-26 11:41:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:41:38 --> Pagination Class Initialized
INFO - 2016-11-26 11:41:38 --> Helper loaded: app_helper
INFO - 2016-11-26 11:41:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:41:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-26 11:41:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:41:38 --> Final output sent to browser
DEBUG - 2016-11-26 11:41:38 --> Total execution time: 0.4280
INFO - 2016-11-26 11:41:47 --> Config Class Initialized
INFO - 2016-11-26 11:41:48 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:41:48 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:41:48 --> Utf8 Class Initialized
INFO - 2016-11-26 11:41:48 --> URI Class Initialized
DEBUG - 2016-11-26 11:41:48 --> No URI present. Default controller set.
INFO - 2016-11-26 11:41:48 --> Router Class Initialized
INFO - 2016-11-26 11:41:48 --> Output Class Initialized
INFO - 2016-11-26 11:41:48 --> Security Class Initialized
DEBUG - 2016-11-26 11:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:41:48 --> Input Class Initialized
INFO - 2016-11-26 11:41:48 --> Language Class Initialized
INFO - 2016-11-26 11:41:48 --> Loader Class Initialized
INFO - 2016-11-26 11:41:48 --> Helper loaded: url_helper
INFO - 2016-11-26 11:41:48 --> Helper loaded: form_helper
INFO - 2016-11-26 11:41:48 --> Database Driver Class Initialized
INFO - 2016-11-26 11:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:41:48 --> Controller Class Initialized
INFO - 2016-11-26 11:41:48 --> Model Class Initialized
INFO - 2016-11-26 11:41:48 --> Model Class Initialized
INFO - 2016-11-26 11:41:48 --> Model Class Initialized
INFO - 2016-11-26 11:41:48 --> Model Class Initialized
INFO - 2016-11-26 11:41:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:41:48 --> Pagination Class Initialized
INFO - 2016-11-26 11:41:48 --> Helper loaded: app_helper
INFO - 2016-11-26 11:41:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:41:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-26 11:41:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:41:48 --> Final output sent to browser
DEBUG - 2016-11-26 11:41:48 --> Total execution time: 0.3891
INFO - 2016-11-26 11:42:20 --> Config Class Initialized
INFO - 2016-11-26 11:42:20 --> Hooks Class Initialized
DEBUG - 2016-11-26 11:42:20 --> UTF-8 Support Enabled
INFO - 2016-11-26 11:42:20 --> Utf8 Class Initialized
INFO - 2016-11-26 11:42:20 --> URI Class Initialized
DEBUG - 2016-11-26 11:42:21 --> No URI present. Default controller set.
INFO - 2016-11-26 11:42:21 --> Router Class Initialized
INFO - 2016-11-26 11:42:21 --> Output Class Initialized
INFO - 2016-11-26 11:42:21 --> Security Class Initialized
DEBUG - 2016-11-26 11:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-26 11:42:21 --> Input Class Initialized
INFO - 2016-11-26 11:42:21 --> Language Class Initialized
INFO - 2016-11-26 11:42:21 --> Loader Class Initialized
INFO - 2016-11-26 11:42:21 --> Helper loaded: url_helper
INFO - 2016-11-26 11:42:21 --> Helper loaded: form_helper
INFO - 2016-11-26 11:42:21 --> Database Driver Class Initialized
INFO - 2016-11-26 11:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-26 11:42:21 --> Controller Class Initialized
INFO - 2016-11-26 11:42:21 --> Model Class Initialized
INFO - 2016-11-26 11:42:21 --> Model Class Initialized
INFO - 2016-11-26 11:42:21 --> Model Class Initialized
INFO - 2016-11-26 11:42:21 --> Model Class Initialized
INFO - 2016-11-26 11:42:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-26 11:42:21 --> Pagination Class Initialized
INFO - 2016-11-26 11:42:21 --> Helper loaded: app_helper
INFO - 2016-11-26 11:42:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-26 11:42:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-26 11:42:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-26 11:42:21 --> Final output sent to browser
DEBUG - 2016-11-26 11:42:21 --> Total execution time: 0.6268
