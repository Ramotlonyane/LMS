<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-23 10:19:28 --> Config Class Initialized
INFO - 2016-11-23 10:19:28 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:19:28 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:19:28 --> Utf8 Class Initialized
INFO - 2016-11-23 10:19:28 --> URI Class Initialized
DEBUG - 2016-11-23 10:19:29 --> No URI present. Default controller set.
INFO - 2016-11-23 10:19:29 --> Router Class Initialized
INFO - 2016-11-23 10:19:29 --> Output Class Initialized
INFO - 2016-11-23 10:19:29 --> Security Class Initialized
DEBUG - 2016-11-23 10:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:19:29 --> Input Class Initialized
INFO - 2016-11-23 10:19:29 --> Language Class Initialized
INFO - 2016-11-23 10:19:30 --> Loader Class Initialized
INFO - 2016-11-23 10:19:30 --> Helper loaded: url_helper
INFO - 2016-11-23 10:19:30 --> Helper loaded: form_helper
INFO - 2016-11-23 10:19:30 --> Database Driver Class Initialized
INFO - 2016-11-23 10:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:19:31 --> Controller Class Initialized
INFO - 2016-11-23 10:19:31 --> Model Class Initialized
INFO - 2016-11-23 10:19:31 --> Model Class Initialized
INFO - 2016-11-23 10:19:31 --> Model Class Initialized
INFO - 2016-11-23 10:19:31 --> Model Class Initialized
INFO - 2016-11-23 10:19:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:19:31 --> Pagination Class Initialized
INFO - 2016-11-23 10:19:31 --> Helper loaded: app_helper
INFO - 2016-11-23 10:19:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 10:19:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-23 10:19:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 10:19:31 --> Final output sent to browser
DEBUG - 2016-11-23 10:19:31 --> Total execution time: 3.3831
INFO - 2016-11-23 10:19:34 --> Config Class Initialized
INFO - 2016-11-23 10:19:34 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:19:34 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:19:34 --> Utf8 Class Initialized
INFO - 2016-11-23 10:19:34 --> URI Class Initialized
DEBUG - 2016-11-23 10:19:34 --> No URI present. Default controller set.
INFO - 2016-11-23 10:19:34 --> Router Class Initialized
INFO - 2016-11-23 10:19:34 --> Output Class Initialized
INFO - 2016-11-23 10:19:34 --> Security Class Initialized
DEBUG - 2016-11-23 10:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:19:34 --> Input Class Initialized
INFO - 2016-11-23 10:19:34 --> Language Class Initialized
INFO - 2016-11-23 10:19:34 --> Loader Class Initialized
INFO - 2016-11-23 10:19:34 --> Helper loaded: url_helper
INFO - 2016-11-23 10:19:34 --> Helper loaded: form_helper
INFO - 2016-11-23 10:19:34 --> Database Driver Class Initialized
INFO - 2016-11-23 10:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:19:34 --> Controller Class Initialized
INFO - 2016-11-23 10:19:34 --> Model Class Initialized
INFO - 2016-11-23 10:19:34 --> Model Class Initialized
INFO - 2016-11-23 10:19:34 --> Model Class Initialized
INFO - 2016-11-23 10:19:34 --> Model Class Initialized
INFO - 2016-11-23 10:19:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:19:34 --> Pagination Class Initialized
INFO - 2016-11-23 10:19:34 --> Helper loaded: app_helper
INFO - 2016-11-23 10:19:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 10:19:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-23 10:19:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 10:19:34 --> Final output sent to browser
DEBUG - 2016-11-23 10:19:34 --> Total execution time: 0.3805
INFO - 2016-11-23 10:20:00 --> Config Class Initialized
INFO - 2016-11-23 10:20:00 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:20:00 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:20:00 --> Utf8 Class Initialized
INFO - 2016-11-23 10:20:00 --> URI Class Initialized
DEBUG - 2016-11-23 10:20:00 --> No URI present. Default controller set.
INFO - 2016-11-23 10:20:00 --> Router Class Initialized
INFO - 2016-11-23 10:20:00 --> Output Class Initialized
INFO - 2016-11-23 10:20:00 --> Security Class Initialized
DEBUG - 2016-11-23 10:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:20:00 --> Input Class Initialized
INFO - 2016-11-23 10:20:00 --> Language Class Initialized
INFO - 2016-11-23 10:20:00 --> Loader Class Initialized
INFO - 2016-11-23 10:20:00 --> Helper loaded: url_helper
INFO - 2016-11-23 10:20:00 --> Helper loaded: form_helper
INFO - 2016-11-23 10:20:00 --> Database Driver Class Initialized
INFO - 2016-11-23 10:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:20:01 --> Controller Class Initialized
INFO - 2016-11-23 10:20:01 --> Model Class Initialized
INFO - 2016-11-23 10:20:01 --> Model Class Initialized
INFO - 2016-11-23 10:20:01 --> Model Class Initialized
INFO - 2016-11-23 10:20:01 --> Model Class Initialized
INFO - 2016-11-23 10:20:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:20:01 --> Pagination Class Initialized
INFO - 2016-11-23 10:20:01 --> Helper loaded: app_helper
INFO - 2016-11-23 10:20:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 10:20:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-23 10:20:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 10:20:01 --> Final output sent to browser
DEBUG - 2016-11-23 10:20:01 --> Total execution time: 0.6646
INFO - 2016-11-23 10:20:16 --> Config Class Initialized
INFO - 2016-11-23 10:20:16 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:20:16 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:20:16 --> Utf8 Class Initialized
INFO - 2016-11-23 10:20:16 --> URI Class Initialized
DEBUG - 2016-11-23 10:20:16 --> No URI present. Default controller set.
INFO - 2016-11-23 10:20:16 --> Router Class Initialized
INFO - 2016-11-23 10:20:16 --> Output Class Initialized
INFO - 2016-11-23 10:20:16 --> Security Class Initialized
DEBUG - 2016-11-23 10:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:20:16 --> Input Class Initialized
INFO - 2016-11-23 10:20:16 --> Language Class Initialized
INFO - 2016-11-23 10:20:16 --> Loader Class Initialized
INFO - 2016-11-23 10:20:16 --> Helper loaded: url_helper
INFO - 2016-11-23 10:20:16 --> Helper loaded: form_helper
INFO - 2016-11-23 10:20:16 --> Database Driver Class Initialized
INFO - 2016-11-23 10:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:20:16 --> Controller Class Initialized
INFO - 2016-11-23 10:20:16 --> Model Class Initialized
INFO - 2016-11-23 10:20:16 --> Model Class Initialized
INFO - 2016-11-23 10:20:16 --> Model Class Initialized
INFO - 2016-11-23 10:20:17 --> Model Class Initialized
INFO - 2016-11-23 10:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:20:17 --> Pagination Class Initialized
INFO - 2016-11-23 10:20:17 --> Helper loaded: app_helper
INFO - 2016-11-23 10:20:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 10:20:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-23 10:20:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 10:20:17 --> Final output sent to browser
DEBUG - 2016-11-23 10:20:17 --> Total execution time: 0.2611
INFO - 2016-11-23 10:20:23 --> Config Class Initialized
INFO - 2016-11-23 10:20:23 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:20:23 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:20:23 --> Utf8 Class Initialized
INFO - 2016-11-23 10:20:23 --> URI Class Initialized
DEBUG - 2016-11-23 10:20:24 --> No URI present. Default controller set.
INFO - 2016-11-23 10:20:24 --> Router Class Initialized
INFO - 2016-11-23 10:20:24 --> Output Class Initialized
INFO - 2016-11-23 10:20:24 --> Security Class Initialized
DEBUG - 2016-11-23 10:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:20:24 --> Input Class Initialized
INFO - 2016-11-23 10:20:24 --> Language Class Initialized
INFO - 2016-11-23 10:20:24 --> Loader Class Initialized
INFO - 2016-11-23 10:20:24 --> Helper loaded: url_helper
INFO - 2016-11-23 10:20:24 --> Helper loaded: form_helper
INFO - 2016-11-23 10:20:24 --> Database Driver Class Initialized
INFO - 2016-11-23 10:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:20:24 --> Controller Class Initialized
INFO - 2016-11-23 10:20:24 --> Model Class Initialized
INFO - 2016-11-23 10:20:24 --> Model Class Initialized
INFO - 2016-11-23 10:20:24 --> Model Class Initialized
INFO - 2016-11-23 10:20:24 --> Model Class Initialized
INFO - 2016-11-23 10:20:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:20:24 --> Pagination Class Initialized
INFO - 2016-11-23 10:20:24 --> Helper loaded: app_helper
INFO - 2016-11-23 10:20:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 10:20:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-23 10:20:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 10:20:24 --> Final output sent to browser
DEBUG - 2016-11-23 10:20:24 --> Total execution time: 0.2751
INFO - 2016-11-23 10:21:41 --> Config Class Initialized
INFO - 2016-11-23 10:21:41 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:21:41 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:21:41 --> Utf8 Class Initialized
INFO - 2016-11-23 10:21:41 --> URI Class Initialized
INFO - 2016-11-23 10:21:41 --> Router Class Initialized
INFO - 2016-11-23 10:21:41 --> Output Class Initialized
INFO - 2016-11-23 10:21:41 --> Security Class Initialized
DEBUG - 2016-11-23 10:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:21:41 --> Input Class Initialized
INFO - 2016-11-23 10:21:41 --> Language Class Initialized
INFO - 2016-11-23 10:21:41 --> Loader Class Initialized
INFO - 2016-11-23 10:21:41 --> Helper loaded: url_helper
INFO - 2016-11-23 10:21:41 --> Helper loaded: form_helper
INFO - 2016-11-23 10:21:41 --> Database Driver Class Initialized
INFO - 2016-11-23 10:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:21:41 --> Controller Class Initialized
INFO - 2016-11-23 10:21:41 --> Model Class Initialized
INFO - 2016-11-23 10:21:41 --> Model Class Initialized
INFO - 2016-11-23 10:21:41 --> Model Class Initialized
INFO - 2016-11-23 10:21:41 --> Model Class Initialized
INFO - 2016-11-23 10:21:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:21:42 --> Pagination Class Initialized
INFO - 2016-11-23 10:21:42 --> Helper loaded: app_helper
DEBUG - 2016-11-23 10:21:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-23 10:21:42 --> Model Class Initialized
INFO - 2016-11-23 10:21:42 --> Final output sent to browser
DEBUG - 2016-11-23 10:21:42 --> Total execution time: 0.4576
INFO - 2016-11-23 10:21:48 --> Config Class Initialized
INFO - 2016-11-23 10:21:48 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:21:48 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:21:48 --> Utf8 Class Initialized
INFO - 2016-11-23 10:21:48 --> URI Class Initialized
INFO - 2016-11-23 10:21:48 --> Router Class Initialized
INFO - 2016-11-23 10:21:48 --> Output Class Initialized
INFO - 2016-11-23 10:21:48 --> Security Class Initialized
DEBUG - 2016-11-23 10:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:21:48 --> Input Class Initialized
INFO - 2016-11-23 10:21:48 --> Language Class Initialized
INFO - 2016-11-23 10:21:48 --> Loader Class Initialized
INFO - 2016-11-23 10:21:48 --> Helper loaded: url_helper
INFO - 2016-11-23 10:21:48 --> Helper loaded: form_helper
INFO - 2016-11-23 10:21:48 --> Database Driver Class Initialized
INFO - 2016-11-23 10:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:21:48 --> Controller Class Initialized
INFO - 2016-11-23 10:21:48 --> Model Class Initialized
INFO - 2016-11-23 10:21:48 --> Model Class Initialized
INFO - 2016-11-23 10:21:48 --> Model Class Initialized
INFO - 2016-11-23 10:21:48 --> Model Class Initialized
INFO - 2016-11-23 10:21:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:21:48 --> Pagination Class Initialized
INFO - 2016-11-23 10:21:48 --> Helper loaded: app_helper
DEBUG - 2016-11-23 10:21:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-23 10:21:48 --> Model Class Initialized
INFO - 2016-11-23 10:21:48 --> Final output sent to browser
DEBUG - 2016-11-23 10:21:48 --> Total execution time: 0.2173
INFO - 2016-11-23 10:21:58 --> Config Class Initialized
INFO - 2016-11-23 10:21:58 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:21:58 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:21:58 --> Utf8 Class Initialized
INFO - 2016-11-23 10:21:58 --> URI Class Initialized
INFO - 2016-11-23 10:21:58 --> Router Class Initialized
INFO - 2016-11-23 10:21:58 --> Output Class Initialized
INFO - 2016-11-23 10:21:58 --> Security Class Initialized
DEBUG - 2016-11-23 10:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:21:58 --> Input Class Initialized
INFO - 2016-11-23 10:21:58 --> Language Class Initialized
INFO - 2016-11-23 10:21:58 --> Loader Class Initialized
INFO - 2016-11-23 10:21:58 --> Helper loaded: url_helper
INFO - 2016-11-23 10:21:58 --> Helper loaded: form_helper
INFO - 2016-11-23 10:21:58 --> Database Driver Class Initialized
INFO - 2016-11-23 10:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:21:58 --> Controller Class Initialized
INFO - 2016-11-23 10:21:58 --> Model Class Initialized
INFO - 2016-11-23 10:21:58 --> Model Class Initialized
INFO - 2016-11-23 10:21:58 --> Model Class Initialized
INFO - 2016-11-23 10:21:58 --> Model Class Initialized
INFO - 2016-11-23 10:21:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:21:58 --> Pagination Class Initialized
INFO - 2016-11-23 10:21:58 --> Helper loaded: app_helper
DEBUG - 2016-11-23 10:21:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-23 10:21:58 --> Model Class Initialized
INFO - 2016-11-23 10:21:58 --> Final output sent to browser
DEBUG - 2016-11-23 10:21:58 --> Total execution time: 0.2468
INFO - 2016-11-23 10:21:58 --> Config Class Initialized
INFO - 2016-11-23 10:21:58 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:21:58 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:21:58 --> Utf8 Class Initialized
INFO - 2016-11-23 10:21:58 --> URI Class Initialized
DEBUG - 2016-11-23 10:21:58 --> No URI present. Default controller set.
INFO - 2016-11-23 10:21:58 --> Router Class Initialized
INFO - 2016-11-23 10:21:58 --> Output Class Initialized
INFO - 2016-11-23 10:21:58 --> Security Class Initialized
DEBUG - 2016-11-23 10:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:21:58 --> Input Class Initialized
INFO - 2016-11-23 10:21:58 --> Language Class Initialized
INFO - 2016-11-23 10:21:58 --> Loader Class Initialized
INFO - 2016-11-23 10:21:58 --> Helper loaded: url_helper
INFO - 2016-11-23 10:21:58 --> Helper loaded: form_helper
INFO - 2016-11-23 10:21:58 --> Database Driver Class Initialized
INFO - 2016-11-23 10:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:21:58 --> Controller Class Initialized
INFO - 2016-11-23 10:21:58 --> Model Class Initialized
INFO - 2016-11-23 10:21:58 --> Model Class Initialized
INFO - 2016-11-23 10:21:58 --> Model Class Initialized
INFO - 2016-11-23 10:21:58 --> Model Class Initialized
INFO - 2016-11-23 10:21:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:21:58 --> Pagination Class Initialized
INFO - 2016-11-23 10:21:58 --> Helper loaded: app_helper
INFO - 2016-11-23 10:21:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 10:21:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-23 10:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-23 10:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-23 10:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 10:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-23 10:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-23 10:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-23 10:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-23 10:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-23 10:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-23 10:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 10:21:59 --> Final output sent to browser
DEBUG - 2016-11-23 10:21:59 --> Total execution time: 1.1351
INFO - 2016-11-23 10:23:02 --> Config Class Initialized
INFO - 2016-11-23 10:23:02 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:23:02 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:23:02 --> Utf8 Class Initialized
INFO - 2016-11-23 10:23:02 --> URI Class Initialized
INFO - 2016-11-23 10:23:02 --> Router Class Initialized
INFO - 2016-11-23 10:23:02 --> Output Class Initialized
INFO - 2016-11-23 10:23:02 --> Security Class Initialized
DEBUG - 2016-11-23 10:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:23:02 --> Input Class Initialized
INFO - 2016-11-23 10:23:02 --> Language Class Initialized
INFO - 2016-11-23 10:23:02 --> Loader Class Initialized
INFO - 2016-11-23 10:23:02 --> Helper loaded: url_helper
INFO - 2016-11-23 10:23:02 --> Helper loaded: form_helper
INFO - 2016-11-23 10:23:02 --> Database Driver Class Initialized
INFO - 2016-11-23 10:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:23:02 --> Controller Class Initialized
INFO - 2016-11-23 10:23:02 --> Model Class Initialized
INFO - 2016-11-23 10:23:02 --> Form Validation Class Initialized
INFO - 2016-11-23 10:23:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:23:02 --> Pagination Class Initialized
INFO - 2016-11-23 10:23:02 --> Helper loaded: app_helper
INFO - 2016-11-23 10:23:02 --> Email Class Initialized
INFO - 2016-11-23 10:23:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-23 10:23:45 --> Config Class Initialized
INFO - 2016-11-23 10:23:45 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:23:45 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:23:45 --> Utf8 Class Initialized
INFO - 2016-11-23 10:23:45 --> URI Class Initialized
INFO - 2016-11-23 10:23:45 --> Router Class Initialized
INFO - 2016-11-23 10:23:45 --> Output Class Initialized
INFO - 2016-11-23 10:23:45 --> Security Class Initialized
DEBUG - 2016-11-23 10:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:23:45 --> Input Class Initialized
INFO - 2016-11-23 10:23:45 --> Language Class Initialized
INFO - 2016-11-23 10:23:45 --> Loader Class Initialized
INFO - 2016-11-23 10:23:45 --> Helper loaded: url_helper
INFO - 2016-11-23 10:23:45 --> Helper loaded: form_helper
INFO - 2016-11-23 10:23:45 --> Database Driver Class Initialized
INFO - 2016-11-23 10:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:23:45 --> Controller Class Initialized
INFO - 2016-11-23 10:23:45 --> Model Class Initialized
INFO - 2016-11-23 10:23:45 --> Form Validation Class Initialized
INFO - 2016-11-23 10:23:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:23:45 --> Pagination Class Initialized
INFO - 2016-11-23 10:23:45 --> Helper loaded: app_helper
INFO - 2016-11-23 10:23:45 --> Email Class Initialized
INFO - 2016-11-23 10:23:45 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-23 09:23:45 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 173
INFO - 2016-11-23 10:24:01 --> Config Class Initialized
INFO - 2016-11-23 10:24:01 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:24:01 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:24:01 --> Utf8 Class Initialized
INFO - 2016-11-23 10:24:01 --> URI Class Initialized
INFO - 2016-11-23 10:24:01 --> Router Class Initialized
INFO - 2016-11-23 10:24:01 --> Output Class Initialized
INFO - 2016-11-23 10:24:01 --> Security Class Initialized
DEBUG - 2016-11-23 10:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:24:01 --> Input Class Initialized
INFO - 2016-11-23 10:24:01 --> Language Class Initialized
INFO - 2016-11-23 10:24:01 --> Loader Class Initialized
INFO - 2016-11-23 10:24:01 --> Helper loaded: url_helper
INFO - 2016-11-23 10:24:01 --> Helper loaded: form_helper
INFO - 2016-11-23 10:24:01 --> Database Driver Class Initialized
INFO - 2016-11-23 10:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:24:01 --> Controller Class Initialized
INFO - 2016-11-23 10:24:01 --> Model Class Initialized
INFO - 2016-11-23 10:24:01 --> Form Validation Class Initialized
INFO - 2016-11-23 10:24:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:24:01 --> Pagination Class Initialized
INFO - 2016-11-23 10:24:01 --> Helper loaded: app_helper
INFO - 2016-11-23 10:24:01 --> Email Class Initialized
INFO - 2016-11-23 10:24:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-23 10:25:22 --> Config Class Initialized
INFO - 2016-11-23 10:25:22 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:25:22 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:25:22 --> Utf8 Class Initialized
INFO - 2016-11-23 10:25:22 --> URI Class Initialized
INFO - 2016-11-23 10:25:22 --> Router Class Initialized
INFO - 2016-11-23 10:25:22 --> Output Class Initialized
INFO - 2016-11-23 10:25:22 --> Security Class Initialized
DEBUG - 2016-11-23 10:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:25:22 --> Input Class Initialized
INFO - 2016-11-23 10:25:22 --> Language Class Initialized
INFO - 2016-11-23 10:25:22 --> Loader Class Initialized
INFO - 2016-11-23 10:25:22 --> Helper loaded: url_helper
INFO - 2016-11-23 10:25:22 --> Helper loaded: form_helper
INFO - 2016-11-23 10:25:22 --> Database Driver Class Initialized
INFO - 2016-11-23 10:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:25:22 --> Controller Class Initialized
INFO - 2016-11-23 10:25:22 --> Model Class Initialized
INFO - 2016-11-23 10:25:22 --> Form Validation Class Initialized
INFO - 2016-11-23 10:25:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:25:22 --> Pagination Class Initialized
INFO - 2016-11-23 10:25:22 --> Helper loaded: app_helper
INFO - 2016-11-23 10:25:22 --> Email Class Initialized
INFO - 2016-11-23 10:25:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-23 10:41:44 --> Config Class Initialized
INFO - 2016-11-23 10:41:44 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:41:44 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:41:44 --> Utf8 Class Initialized
INFO - 2016-11-23 10:41:44 --> URI Class Initialized
INFO - 2016-11-23 10:41:44 --> Router Class Initialized
INFO - 2016-11-23 10:41:44 --> Output Class Initialized
INFO - 2016-11-23 10:41:44 --> Security Class Initialized
DEBUG - 2016-11-23 10:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:41:44 --> Input Class Initialized
INFO - 2016-11-23 10:41:44 --> Language Class Initialized
INFO - 2016-11-23 10:41:44 --> Loader Class Initialized
INFO - 2016-11-23 10:41:44 --> Helper loaded: url_helper
INFO - 2016-11-23 10:41:44 --> Helper loaded: form_helper
INFO - 2016-11-23 10:41:44 --> Database Driver Class Initialized
INFO - 2016-11-23 10:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:41:44 --> Controller Class Initialized
INFO - 2016-11-23 10:41:44 --> Model Class Initialized
INFO - 2016-11-23 10:41:44 --> Form Validation Class Initialized
INFO - 2016-11-23 10:41:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:41:44 --> Pagination Class Initialized
INFO - 2016-11-23 10:41:44 --> Helper loaded: app_helper
INFO - 2016-11-23 10:41:44 --> Email Class Initialized
INFO - 2016-11-23 10:41:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-23 10:41:48 --> Config Class Initialized
INFO - 2016-11-23 10:41:48 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:41:48 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:41:48 --> Utf8 Class Initialized
INFO - 2016-11-23 10:41:48 --> URI Class Initialized
INFO - 2016-11-23 10:41:48 --> Router Class Initialized
INFO - 2016-11-23 10:41:48 --> Output Class Initialized
INFO - 2016-11-23 10:41:48 --> Security Class Initialized
DEBUG - 2016-11-23 10:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:41:48 --> Input Class Initialized
INFO - 2016-11-23 10:41:48 --> Language Class Initialized
INFO - 2016-11-23 10:41:48 --> Loader Class Initialized
INFO - 2016-11-23 10:41:48 --> Helper loaded: url_helper
INFO - 2016-11-23 10:41:48 --> Helper loaded: form_helper
INFO - 2016-11-23 10:41:48 --> Database Driver Class Initialized
INFO - 2016-11-23 10:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:41:48 --> Controller Class Initialized
INFO - 2016-11-23 10:41:48 --> Model Class Initialized
INFO - 2016-11-23 10:41:48 --> Form Validation Class Initialized
INFO - 2016-11-23 10:41:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:41:48 --> Pagination Class Initialized
INFO - 2016-11-23 10:41:48 --> Helper loaded: app_helper
INFO - 2016-11-23 10:41:48 --> Email Class Initialized
INFO - 2016-11-23 10:41:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-23 10:43:06 --> Config Class Initialized
INFO - 2016-11-23 10:43:06 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:43:06 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:43:06 --> Utf8 Class Initialized
INFO - 2016-11-23 10:43:06 --> URI Class Initialized
INFO - 2016-11-23 10:43:06 --> Router Class Initialized
INFO - 2016-11-23 10:43:06 --> Output Class Initialized
INFO - 2016-11-23 10:43:06 --> Security Class Initialized
DEBUG - 2016-11-23 10:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:43:06 --> Input Class Initialized
INFO - 2016-11-23 10:43:06 --> Language Class Initialized
INFO - 2016-11-23 10:43:06 --> Loader Class Initialized
INFO - 2016-11-23 10:43:06 --> Helper loaded: url_helper
INFO - 2016-11-23 10:43:06 --> Helper loaded: form_helper
INFO - 2016-11-23 10:43:06 --> Database Driver Class Initialized
INFO - 2016-11-23 10:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:43:06 --> Controller Class Initialized
INFO - 2016-11-23 10:43:06 --> Model Class Initialized
INFO - 2016-11-23 10:43:06 --> Form Validation Class Initialized
INFO - 2016-11-23 10:43:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:43:06 --> Pagination Class Initialized
INFO - 2016-11-23 10:43:06 --> Helper loaded: app_helper
INFO - 2016-11-23 10:43:06 --> Email Class Initialized
INFO - 2016-11-23 10:43:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-23 09:43:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-23 09:43:06 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-23 09:43:06 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-23 09:43:07 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.critsend.com:465 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-11-23 09:43:07 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-23 09:43:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
ERROR - 2016-11-23 09:43:07 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-23 09:43:07 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.critsend.com:465 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-23 09:43:07 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-23 09:43:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 09:43:07 --> Final output sent to browser
DEBUG - 2016-11-23 09:43:07 --> Total execution time: 0.6735
INFO - 2016-11-23 10:43:56 --> Config Class Initialized
INFO - 2016-11-23 10:43:56 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:43:56 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:43:56 --> Utf8 Class Initialized
INFO - 2016-11-23 10:43:56 --> URI Class Initialized
INFO - 2016-11-23 10:43:56 --> Router Class Initialized
INFO - 2016-11-23 10:43:56 --> Output Class Initialized
INFO - 2016-11-23 10:43:56 --> Security Class Initialized
DEBUG - 2016-11-23 10:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:43:56 --> Input Class Initialized
INFO - 2016-11-23 10:43:56 --> Language Class Initialized
INFO - 2016-11-23 10:43:56 --> Loader Class Initialized
INFO - 2016-11-23 10:43:56 --> Helper loaded: url_helper
INFO - 2016-11-23 10:43:56 --> Helper loaded: form_helper
INFO - 2016-11-23 10:43:56 --> Database Driver Class Initialized
INFO - 2016-11-23 10:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:43:56 --> Controller Class Initialized
INFO - 2016-11-23 10:43:56 --> Model Class Initialized
INFO - 2016-11-23 10:43:56 --> Form Validation Class Initialized
INFO - 2016-11-23 10:43:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:43:56 --> Pagination Class Initialized
INFO - 2016-11-23 10:43:56 --> Helper loaded: app_helper
INFO - 2016-11-23 10:43:56 --> Email Class Initialized
INFO - 2016-11-23 10:43:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-23 09:43:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-23 09:43:56 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-23 09:43:56 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-23 09:43:56 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.critsend.com:465 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-11-23 09:43:56 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-23 09:43:56 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-23 09:43:56 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.critsend.com:465 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-23 09:43:56 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-23 09:43:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 09:43:56 --> Final output sent to browser
DEBUG - 2016-11-23 09:43:56 --> Total execution time: 0.5461
INFO - 2016-11-23 10:43:58 --> Config Class Initialized
INFO - 2016-11-23 10:43:58 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:43:58 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:43:58 --> Utf8 Class Initialized
INFO - 2016-11-23 10:43:58 --> URI Class Initialized
INFO - 2016-11-23 10:43:58 --> Router Class Initialized
INFO - 2016-11-23 10:43:58 --> Output Class Initialized
INFO - 2016-11-23 10:43:58 --> Security Class Initialized
DEBUG - 2016-11-23 10:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:43:58 --> Input Class Initialized
INFO - 2016-11-23 10:43:58 --> Language Class Initialized
INFO - 2016-11-23 10:43:58 --> Loader Class Initialized
INFO - 2016-11-23 10:43:58 --> Helper loaded: url_helper
INFO - 2016-11-23 10:43:58 --> Helper loaded: form_helper
INFO - 2016-11-23 10:43:59 --> Database Driver Class Initialized
INFO - 2016-11-23 10:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:43:59 --> Controller Class Initialized
INFO - 2016-11-23 10:43:59 --> Model Class Initialized
INFO - 2016-11-23 10:43:59 --> Form Validation Class Initialized
INFO - 2016-11-23 10:43:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:43:59 --> Pagination Class Initialized
INFO - 2016-11-23 10:43:59 --> Helper loaded: app_helper
INFO - 2016-11-23 10:43:59 --> Email Class Initialized
INFO - 2016-11-23 10:43:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-23 09:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-23 09:43:59 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-23 09:43:59 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-23 09:43:59 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.critsend.com:465 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-11-23 09:43:59 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-23 09:43:59 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-23 09:43:59 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.critsend.com:465 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-23 09:43:59 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-23 09:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 09:43:59 --> Final output sent to browser
DEBUG - 2016-11-23 09:43:59 --> Total execution time: 0.5077
INFO - 2016-11-23 10:44:39 --> Config Class Initialized
INFO - 2016-11-23 10:44:39 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:44:39 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:44:39 --> Utf8 Class Initialized
INFO - 2016-11-23 10:44:39 --> URI Class Initialized
INFO - 2016-11-23 10:44:39 --> Router Class Initialized
INFO - 2016-11-23 10:44:39 --> Output Class Initialized
INFO - 2016-11-23 10:44:39 --> Security Class Initialized
DEBUG - 2016-11-23 10:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:44:39 --> Input Class Initialized
INFO - 2016-11-23 10:44:39 --> Language Class Initialized
INFO - 2016-11-23 10:44:39 --> Loader Class Initialized
INFO - 2016-11-23 10:44:39 --> Helper loaded: url_helper
INFO - 2016-11-23 10:44:39 --> Helper loaded: form_helper
INFO - 2016-11-23 10:44:39 --> Database Driver Class Initialized
INFO - 2016-11-23 10:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:44:39 --> Controller Class Initialized
INFO - 2016-11-23 10:44:39 --> Model Class Initialized
INFO - 2016-11-23 10:44:39 --> Form Validation Class Initialized
INFO - 2016-11-23 10:44:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:44:39 --> Pagination Class Initialized
INFO - 2016-11-23 10:44:39 --> Helper loaded: app_helper
INFO - 2016-11-23 10:44:39 --> Email Class Initialized
INFO - 2016-11-23 10:44:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-23 09:44:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-23 09:44:39 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-23 09:44:39 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-23 09:44:39 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.critsend.com:465 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-11-23 09:44:39 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-23 09:44:39 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-23 09:44:39 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.critsend.com:465 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-23 09:44:39 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-23 09:44:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 09:44:39 --> Final output sent to browser
DEBUG - 2016-11-23 09:44:39 --> Total execution time: 0.5719
INFO - 2016-11-23 10:49:10 --> Config Class Initialized
INFO - 2016-11-23 10:49:10 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:49:10 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:49:10 --> Utf8 Class Initialized
INFO - 2016-11-23 10:49:10 --> URI Class Initialized
INFO - 2016-11-23 10:49:10 --> Router Class Initialized
INFO - 2016-11-23 10:49:10 --> Output Class Initialized
INFO - 2016-11-23 10:49:10 --> Security Class Initialized
DEBUG - 2016-11-23 10:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:49:10 --> Input Class Initialized
INFO - 2016-11-23 10:49:10 --> Language Class Initialized
INFO - 2016-11-23 10:49:10 --> Loader Class Initialized
INFO - 2016-11-23 10:49:10 --> Helper loaded: url_helper
INFO - 2016-11-23 10:49:10 --> Helper loaded: form_helper
INFO - 2016-11-23 10:49:10 --> Database Driver Class Initialized
INFO - 2016-11-23 10:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:49:10 --> Controller Class Initialized
INFO - 2016-11-23 10:49:10 --> Model Class Initialized
INFO - 2016-11-23 10:49:10 --> Form Validation Class Initialized
INFO - 2016-11-23 10:49:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:49:10 --> Pagination Class Initialized
INFO - 2016-11-23 10:49:10 --> Helper loaded: app_helper
INFO - 2016-11-23 10:49:10 --> Email Class Initialized
INFO - 2016-11-23 10:49:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-23 09:49:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-23 09:49:10 --> Email class already loaded. Second attempt ignored.
DEBUG - 2016-11-23 09:49:10 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-23 09:49:10 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-23 09:49:11 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.critsend.com:465 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-11-23 09:49:11 --> Language file loaded: language/english/email_lang.php
DEBUG - 2016-11-23 09:49:11 --> Email class already loaded. Second attempt ignored.
ERROR - 2016-11-23 09:49:11 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-23 09:49:11 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.critsend.com:465 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-23 09:49:11 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-23 09:49:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 09:49:11 --> Final output sent to browser
DEBUG - 2016-11-23 09:49:11 --> Total execution time: 0.7312
INFO - 2016-11-23 10:49:46 --> Config Class Initialized
INFO - 2016-11-23 10:49:46 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:49:46 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:49:47 --> Utf8 Class Initialized
INFO - 2016-11-23 10:49:47 --> URI Class Initialized
INFO - 2016-11-23 10:49:47 --> Router Class Initialized
INFO - 2016-11-23 10:49:47 --> Output Class Initialized
INFO - 2016-11-23 10:49:47 --> Security Class Initialized
DEBUG - 2016-11-23 10:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:49:47 --> Input Class Initialized
INFO - 2016-11-23 10:49:47 --> Language Class Initialized
INFO - 2016-11-23 10:49:47 --> Loader Class Initialized
INFO - 2016-11-23 10:49:47 --> Helper loaded: url_helper
INFO - 2016-11-23 10:49:47 --> Helper loaded: form_helper
INFO - 2016-11-23 10:49:47 --> Database Driver Class Initialized
INFO - 2016-11-23 10:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:49:47 --> Controller Class Initialized
INFO - 2016-11-23 10:49:47 --> Model Class Initialized
INFO - 2016-11-23 10:49:47 --> Form Validation Class Initialized
INFO - 2016-11-23 10:49:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:49:47 --> Pagination Class Initialized
INFO - 2016-11-23 10:49:47 --> Helper loaded: app_helper
INFO - 2016-11-23 10:49:47 --> Email Class Initialized
INFO - 2016-11-23 10:49:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-23 09:49:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-23 09:49:47 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-23 09:49:47 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-23 09:49:47 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.critsend.com:465 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-11-23 09:49:47 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-23 09:49:47 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-23 09:49:47 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.critsend.com:465 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-23 09:49:47 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-23 09:49:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 09:49:47 --> Final output sent to browser
DEBUG - 2016-11-23 09:49:47 --> Total execution time: 0.7013
INFO - 2016-11-23 10:51:22 --> Config Class Initialized
INFO - 2016-11-23 10:51:22 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:51:22 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:51:22 --> Utf8 Class Initialized
INFO - 2016-11-23 10:51:22 --> URI Class Initialized
DEBUG - 2016-11-23 10:51:22 --> No URI present. Default controller set.
INFO - 2016-11-23 10:51:22 --> Router Class Initialized
INFO - 2016-11-23 10:51:22 --> Output Class Initialized
INFO - 2016-11-23 10:51:22 --> Security Class Initialized
DEBUG - 2016-11-23 10:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:51:22 --> Input Class Initialized
INFO - 2016-11-23 10:51:22 --> Language Class Initialized
INFO - 2016-11-23 10:51:22 --> Loader Class Initialized
INFO - 2016-11-23 10:51:22 --> Helper loaded: url_helper
INFO - 2016-11-23 10:51:22 --> Helper loaded: form_helper
INFO - 2016-11-23 10:51:22 --> Database Driver Class Initialized
INFO - 2016-11-23 10:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:51:22 --> Controller Class Initialized
INFO - 2016-11-23 10:51:22 --> Model Class Initialized
INFO - 2016-11-23 10:51:22 --> Model Class Initialized
INFO - 2016-11-23 10:51:22 --> Model Class Initialized
INFO - 2016-11-23 10:51:22 --> Model Class Initialized
INFO - 2016-11-23 10:51:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:51:22 --> Pagination Class Initialized
INFO - 2016-11-23 10:51:23 --> Helper loaded: app_helper
INFO - 2016-11-23 10:51:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 10:51:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-23 10:51:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-23 10:51:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-23 10:51:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 10:51:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-23 10:51:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-23 10:51:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-23 10:51:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-23 10:51:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-23 10:51:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-23 10:51:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 10:51:23 --> Final output sent to browser
DEBUG - 2016-11-23 10:51:23 --> Total execution time: 0.4197
INFO - 2016-11-23 10:51:26 --> Config Class Initialized
INFO - 2016-11-23 10:51:26 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:51:26 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:51:26 --> Utf8 Class Initialized
INFO - 2016-11-23 10:51:26 --> URI Class Initialized
DEBUG - 2016-11-23 10:51:26 --> No URI present. Default controller set.
INFO - 2016-11-23 10:51:26 --> Router Class Initialized
INFO - 2016-11-23 10:51:26 --> Output Class Initialized
INFO - 2016-11-23 10:51:26 --> Security Class Initialized
DEBUG - 2016-11-23 10:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:51:26 --> Input Class Initialized
INFO - 2016-11-23 10:51:26 --> Language Class Initialized
INFO - 2016-11-23 10:51:26 --> Loader Class Initialized
INFO - 2016-11-23 10:51:26 --> Helper loaded: url_helper
INFO - 2016-11-23 10:51:26 --> Helper loaded: form_helper
INFO - 2016-11-23 10:51:26 --> Database Driver Class Initialized
INFO - 2016-11-23 10:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:51:26 --> Controller Class Initialized
INFO - 2016-11-23 10:51:26 --> Model Class Initialized
INFO - 2016-11-23 10:51:26 --> Model Class Initialized
INFO - 2016-11-23 10:51:26 --> Model Class Initialized
INFO - 2016-11-23 10:51:26 --> Model Class Initialized
INFO - 2016-11-23 10:51:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:51:26 --> Pagination Class Initialized
INFO - 2016-11-23 10:51:26 --> Helper loaded: app_helper
INFO - 2016-11-23 10:51:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 10:51:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-23 10:51:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-23 10:51:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-23 10:51:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 10:51:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-23 10:51:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-23 10:51:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-23 10:51:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-23 10:51:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-23 10:51:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-23 10:51:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 10:51:26 --> Final output sent to browser
DEBUG - 2016-11-23 10:51:26 --> Total execution time: 0.4410
INFO - 2016-11-23 10:51:35 --> Config Class Initialized
INFO - 2016-11-23 10:51:35 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:51:35 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:51:35 --> Utf8 Class Initialized
INFO - 2016-11-23 10:51:35 --> URI Class Initialized
INFO - 2016-11-23 10:51:35 --> Router Class Initialized
INFO - 2016-11-23 10:51:35 --> Output Class Initialized
INFO - 2016-11-23 10:51:35 --> Security Class Initialized
DEBUG - 2016-11-23 10:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:51:35 --> Input Class Initialized
INFO - 2016-11-23 10:51:35 --> Language Class Initialized
INFO - 2016-11-23 10:51:35 --> Loader Class Initialized
INFO - 2016-11-23 10:51:35 --> Helper loaded: url_helper
INFO - 2016-11-23 10:51:35 --> Helper loaded: form_helper
INFO - 2016-11-23 10:51:35 --> Database Driver Class Initialized
INFO - 2016-11-23 10:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:51:35 --> Controller Class Initialized
INFO - 2016-11-23 10:51:35 --> Model Class Initialized
INFO - 2016-11-23 10:51:35 --> Form Validation Class Initialized
INFO - 2016-11-23 10:51:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:51:35 --> Pagination Class Initialized
INFO - 2016-11-23 10:51:35 --> Helper loaded: app_helper
INFO - 2016-11-23 10:51:35 --> Email Class Initialized
INFO - 2016-11-23 10:51:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-23 09:51:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-23 09:51:36 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-23 09:51:36 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-23 09:51:36 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.critsend.com:465 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-11-23 09:51:36 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-23 09:51:36 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-23 09:51:36 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.critsend.com:465 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-23 09:51:36 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-23 09:51:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 09:51:36 --> Final output sent to browser
DEBUG - 2016-11-23 09:51:36 --> Total execution time: 0.6488
INFO - 2016-11-23 10:51:38 --> Config Class Initialized
INFO - 2016-11-23 10:51:38 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:51:38 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:51:38 --> Utf8 Class Initialized
INFO - 2016-11-23 10:51:38 --> URI Class Initialized
INFO - 2016-11-23 10:51:38 --> Router Class Initialized
INFO - 2016-11-23 10:51:38 --> Output Class Initialized
INFO - 2016-11-23 10:51:38 --> Security Class Initialized
DEBUG - 2016-11-23 10:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:51:38 --> Input Class Initialized
INFO - 2016-11-23 10:51:38 --> Language Class Initialized
INFO - 2016-11-23 10:51:38 --> Loader Class Initialized
INFO - 2016-11-23 10:51:38 --> Helper loaded: url_helper
INFO - 2016-11-23 10:51:38 --> Helper loaded: form_helper
INFO - 2016-11-23 10:51:38 --> Database Driver Class Initialized
INFO - 2016-11-23 10:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:51:38 --> Controller Class Initialized
INFO - 2016-11-23 10:51:38 --> Model Class Initialized
INFO - 2016-11-23 10:51:38 --> Form Validation Class Initialized
INFO - 2016-11-23 10:51:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:51:38 --> Pagination Class Initialized
INFO - 2016-11-23 10:51:38 --> Helper loaded: app_helper
INFO - 2016-11-23 10:51:38 --> Email Class Initialized
INFO - 2016-11-23 10:51:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-23 09:51:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-23 09:51:39 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-23 09:51:39 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-23 09:51:39 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.critsend.com:465 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-11-23 09:51:39 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-23 09:51:39 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-23 09:51:39 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.critsend.com:465 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-23 09:51:39 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-23 09:51:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 09:51:39 --> Final output sent to browser
DEBUG - 2016-11-23 09:51:39 --> Total execution time: 0.5941
INFO - 2016-11-23 10:51:44 --> Config Class Initialized
INFO - 2016-11-23 10:51:44 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:51:44 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:51:44 --> Utf8 Class Initialized
INFO - 2016-11-23 10:51:44 --> URI Class Initialized
INFO - 2016-11-23 10:51:44 --> Router Class Initialized
INFO - 2016-11-23 10:51:44 --> Output Class Initialized
INFO - 2016-11-23 10:51:44 --> Security Class Initialized
DEBUG - 2016-11-23 10:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:51:44 --> Input Class Initialized
INFO - 2016-11-23 10:51:44 --> Language Class Initialized
INFO - 2016-11-23 10:51:44 --> Loader Class Initialized
INFO - 2016-11-23 10:51:44 --> Helper loaded: url_helper
INFO - 2016-11-23 10:51:44 --> Helper loaded: form_helper
INFO - 2016-11-23 10:51:44 --> Database Driver Class Initialized
INFO - 2016-11-23 10:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:51:44 --> Controller Class Initialized
INFO - 2016-11-23 10:51:44 --> Model Class Initialized
INFO - 2016-11-23 10:51:44 --> Model Class Initialized
INFO - 2016-11-23 10:51:44 --> Model Class Initialized
INFO - 2016-11-23 10:51:44 --> Model Class Initialized
INFO - 2016-11-23 10:51:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:51:44 --> Pagination Class Initialized
INFO - 2016-11-23 10:51:44 --> Helper loaded: app_helper
DEBUG - 2016-11-23 10:51:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-23 10:51:44 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-23 10:51:44 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-23 10:51:44 --> Config Class Initialized
INFO - 2016-11-23 10:51:44 --> Hooks Class Initialized
DEBUG - 2016-11-23 10:51:44 --> UTF-8 Support Enabled
INFO - 2016-11-23 10:51:44 --> Utf8 Class Initialized
INFO - 2016-11-23 10:51:45 --> URI Class Initialized
DEBUG - 2016-11-23 10:51:45 --> No URI present. Default controller set.
INFO - 2016-11-23 10:51:45 --> Router Class Initialized
INFO - 2016-11-23 10:51:45 --> Output Class Initialized
INFO - 2016-11-23 10:51:45 --> Security Class Initialized
DEBUG - 2016-11-23 10:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 10:51:45 --> Input Class Initialized
INFO - 2016-11-23 10:51:45 --> Language Class Initialized
INFO - 2016-11-23 10:51:45 --> Loader Class Initialized
INFO - 2016-11-23 10:51:45 --> Helper loaded: url_helper
INFO - 2016-11-23 10:51:45 --> Helper loaded: form_helper
INFO - 2016-11-23 10:51:45 --> Database Driver Class Initialized
INFO - 2016-11-23 10:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 10:51:45 --> Controller Class Initialized
INFO - 2016-11-23 10:51:45 --> Model Class Initialized
INFO - 2016-11-23 10:51:45 --> Model Class Initialized
INFO - 2016-11-23 10:51:45 --> Model Class Initialized
INFO - 2016-11-23 10:51:45 --> Model Class Initialized
INFO - 2016-11-23 10:51:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 10:51:45 --> Pagination Class Initialized
INFO - 2016-11-23 10:51:45 --> Helper loaded: app_helper
INFO - 2016-11-23 10:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 10:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-23 10:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 10:51:45 --> Final output sent to browser
DEBUG - 2016-11-23 10:51:45 --> Total execution time: 0.3110
INFO - 2016-11-23 14:30:58 --> Config Class Initialized
INFO - 2016-11-23 14:30:58 --> Hooks Class Initialized
DEBUG - 2016-11-23 14:30:58 --> UTF-8 Support Enabled
INFO - 2016-11-23 14:30:58 --> Utf8 Class Initialized
INFO - 2016-11-23 14:30:58 --> URI Class Initialized
DEBUG - 2016-11-23 14:30:58 --> No URI present. Default controller set.
INFO - 2016-11-23 14:30:58 --> Router Class Initialized
INFO - 2016-11-23 14:30:58 --> Output Class Initialized
INFO - 2016-11-23 14:30:58 --> Security Class Initialized
DEBUG - 2016-11-23 14:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 14:30:58 --> Input Class Initialized
INFO - 2016-11-23 14:30:58 --> Language Class Initialized
INFO - 2016-11-23 14:30:58 --> Loader Class Initialized
INFO - 2016-11-23 14:30:58 --> Helper loaded: url_helper
INFO - 2016-11-23 14:30:58 --> Helper loaded: form_helper
INFO - 2016-11-23 14:30:59 --> Database Driver Class Initialized
INFO - 2016-11-23 14:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 14:30:59 --> Controller Class Initialized
INFO - 2016-11-23 14:30:59 --> Model Class Initialized
INFO - 2016-11-23 14:30:59 --> Model Class Initialized
INFO - 2016-11-23 14:30:59 --> Model Class Initialized
INFO - 2016-11-23 14:30:59 --> Model Class Initialized
INFO - 2016-11-23 14:30:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 14:30:59 --> Pagination Class Initialized
INFO - 2016-11-23 14:30:59 --> Helper loaded: app_helper
INFO - 2016-11-23 14:30:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 14:30:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-23 14:30:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 14:30:59 --> Final output sent to browser
DEBUG - 2016-11-23 14:30:59 --> Total execution time: 1.7413
INFO - 2016-11-23 14:32:14 --> Config Class Initialized
INFO - 2016-11-23 14:32:14 --> Hooks Class Initialized
DEBUG - 2016-11-23 14:32:14 --> UTF-8 Support Enabled
INFO - 2016-11-23 14:32:14 --> Utf8 Class Initialized
INFO - 2016-11-23 14:32:15 --> URI Class Initialized
DEBUG - 2016-11-23 14:32:15 --> No URI present. Default controller set.
INFO - 2016-11-23 14:32:15 --> Router Class Initialized
INFO - 2016-11-23 14:32:15 --> Output Class Initialized
INFO - 2016-11-23 14:32:15 --> Security Class Initialized
DEBUG - 2016-11-23 14:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 14:32:15 --> Input Class Initialized
INFO - 2016-11-23 14:32:15 --> Language Class Initialized
INFO - 2016-11-23 14:32:15 --> Loader Class Initialized
INFO - 2016-11-23 14:32:15 --> Helper loaded: url_helper
INFO - 2016-11-23 14:32:15 --> Helper loaded: form_helper
INFO - 2016-11-23 14:32:15 --> Database Driver Class Initialized
INFO - 2016-11-23 14:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 14:32:15 --> Controller Class Initialized
INFO - 2016-11-23 14:32:15 --> Model Class Initialized
INFO - 2016-11-23 14:32:15 --> Model Class Initialized
INFO - 2016-11-23 14:32:15 --> Model Class Initialized
INFO - 2016-11-23 14:32:15 --> Model Class Initialized
INFO - 2016-11-23 14:32:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 14:32:15 --> Pagination Class Initialized
INFO - 2016-11-23 14:32:15 --> Helper loaded: app_helper
INFO - 2016-11-23 14:32:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 14:32:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-23 14:32:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 14:32:15 --> Final output sent to browser
DEBUG - 2016-11-23 14:32:15 --> Total execution time: 0.3174
INFO - 2016-11-23 14:32:41 --> Config Class Initialized
INFO - 2016-11-23 14:32:41 --> Hooks Class Initialized
DEBUG - 2016-11-23 14:32:41 --> UTF-8 Support Enabled
INFO - 2016-11-23 14:32:41 --> Utf8 Class Initialized
INFO - 2016-11-23 14:32:41 --> URI Class Initialized
INFO - 2016-11-23 14:32:41 --> Router Class Initialized
INFO - 2016-11-23 14:32:41 --> Output Class Initialized
INFO - 2016-11-23 14:32:41 --> Security Class Initialized
DEBUG - 2016-11-23 14:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 14:32:41 --> Input Class Initialized
INFO - 2016-11-23 14:32:41 --> Language Class Initialized
INFO - 2016-11-23 14:32:41 --> Loader Class Initialized
INFO - 2016-11-23 14:32:41 --> Helper loaded: url_helper
INFO - 2016-11-23 14:32:41 --> Helper loaded: form_helper
INFO - 2016-11-23 14:32:41 --> Database Driver Class Initialized
INFO - 2016-11-23 14:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 14:32:41 --> Controller Class Initialized
INFO - 2016-11-23 14:32:41 --> Model Class Initialized
INFO - 2016-11-23 14:32:41 --> Model Class Initialized
INFO - 2016-11-23 14:32:41 --> Model Class Initialized
INFO - 2016-11-23 14:32:41 --> Model Class Initialized
INFO - 2016-11-23 14:32:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 14:32:41 --> Pagination Class Initialized
INFO - 2016-11-23 14:32:41 --> Helper loaded: app_helper
DEBUG - 2016-11-23 14:32:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-23 14:32:41 --> Model Class Initialized
INFO - 2016-11-23 14:32:41 --> Final output sent to browser
DEBUG - 2016-11-23 14:32:41 --> Total execution time: 0.4046
INFO - 2016-11-23 14:32:41 --> Config Class Initialized
INFO - 2016-11-23 14:32:41 --> Hooks Class Initialized
DEBUG - 2016-11-23 14:32:41 --> UTF-8 Support Enabled
INFO - 2016-11-23 14:32:41 --> Utf8 Class Initialized
INFO - 2016-11-23 14:32:41 --> URI Class Initialized
DEBUG - 2016-11-23 14:32:41 --> No URI present. Default controller set.
INFO - 2016-11-23 14:32:41 --> Router Class Initialized
INFO - 2016-11-23 14:32:41 --> Output Class Initialized
INFO - 2016-11-23 14:32:41 --> Security Class Initialized
DEBUG - 2016-11-23 14:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 14:32:41 --> Input Class Initialized
INFO - 2016-11-23 14:32:41 --> Language Class Initialized
INFO - 2016-11-23 14:32:41 --> Loader Class Initialized
INFO - 2016-11-23 14:32:41 --> Helper loaded: url_helper
INFO - 2016-11-23 14:32:41 --> Helper loaded: form_helper
INFO - 2016-11-23 14:32:41 --> Database Driver Class Initialized
INFO - 2016-11-23 14:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 14:32:41 --> Controller Class Initialized
INFO - 2016-11-23 14:32:41 --> Model Class Initialized
INFO - 2016-11-23 14:32:41 --> Model Class Initialized
INFO - 2016-11-23 14:32:41 --> Model Class Initialized
INFO - 2016-11-23 14:32:41 --> Model Class Initialized
INFO - 2016-11-23 14:32:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 14:32:41 --> Pagination Class Initialized
INFO - 2016-11-23 14:32:41 --> Helper loaded: app_helper
INFO - 2016-11-23 14:32:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 14:32:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-23 14:32:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-23 14:32:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-23 14:32:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 14:32:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-23 14:32:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-23 14:32:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-23 14:32:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-23 14:32:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-23 14:32:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-23 14:32:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 14:32:42 --> Final output sent to browser
DEBUG - 2016-11-23 14:32:42 --> Total execution time: 0.7906
INFO - 2016-11-23 14:35:06 --> Config Class Initialized
INFO - 2016-11-23 14:35:06 --> Hooks Class Initialized
DEBUG - 2016-11-23 14:35:06 --> UTF-8 Support Enabled
INFO - 2016-11-23 14:35:06 --> Utf8 Class Initialized
INFO - 2016-11-23 14:35:06 --> URI Class Initialized
INFO - 2016-11-23 14:35:06 --> Router Class Initialized
INFO - 2016-11-23 14:35:06 --> Output Class Initialized
INFO - 2016-11-23 14:35:06 --> Security Class Initialized
DEBUG - 2016-11-23 14:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 14:35:06 --> Input Class Initialized
INFO - 2016-11-23 14:35:06 --> Language Class Initialized
INFO - 2016-11-23 14:35:06 --> Loader Class Initialized
INFO - 2016-11-23 14:35:06 --> Helper loaded: url_helper
INFO - 2016-11-23 14:35:06 --> Helper loaded: form_helper
INFO - 2016-11-23 14:35:06 --> Database Driver Class Initialized
INFO - 2016-11-23 14:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 14:35:06 --> Controller Class Initialized
INFO - 2016-11-23 14:35:06 --> Model Class Initialized
INFO - 2016-11-23 14:35:07 --> Form Validation Class Initialized
INFO - 2016-11-23 14:35:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 14:35:07 --> Pagination Class Initialized
INFO - 2016-11-23 14:35:07 --> Helper loaded: app_helper
INFO - 2016-11-23 14:35:07 --> Email Class Initialized
INFO - 2016-11-23 14:35:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-23 13:35:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-23 13:35:07 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-23 13:35:07 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-23 13:35:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
ERROR - 2016-11-23 13:35:09 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-23 13:35:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 13:35:09 --> Final output sent to browser
DEBUG - 2016-11-23 13:35:09 --> Total execution time: 2.4817
INFO - 2016-11-23 14:38:12 --> Config Class Initialized
INFO - 2016-11-23 14:38:12 --> Hooks Class Initialized
DEBUG - 2016-11-23 14:38:12 --> UTF-8 Support Enabled
INFO - 2016-11-23 14:38:12 --> Utf8 Class Initialized
INFO - 2016-11-23 14:38:12 --> URI Class Initialized
INFO - 2016-11-23 14:38:12 --> Router Class Initialized
INFO - 2016-11-23 14:38:12 --> Output Class Initialized
INFO - 2016-11-23 14:38:12 --> Security Class Initialized
DEBUG - 2016-11-23 14:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 14:38:12 --> Input Class Initialized
INFO - 2016-11-23 14:38:12 --> Language Class Initialized
INFO - 2016-11-23 14:38:12 --> Loader Class Initialized
INFO - 2016-11-23 14:38:12 --> Helper loaded: url_helper
INFO - 2016-11-23 14:38:12 --> Helper loaded: form_helper
INFO - 2016-11-23 14:38:12 --> Database Driver Class Initialized
INFO - 2016-11-23 14:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 14:38:12 --> Controller Class Initialized
INFO - 2016-11-23 14:38:12 --> Model Class Initialized
INFO - 2016-11-23 14:38:12 --> Form Validation Class Initialized
INFO - 2016-11-23 14:38:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 14:38:12 --> Pagination Class Initialized
INFO - 2016-11-23 14:38:12 --> Helper loaded: app_helper
INFO - 2016-11-23 14:38:12 --> Email Class Initialized
INFO - 2016-11-23 14:38:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-23 13:38:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-23 13:38:12 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-11-23 13:38:12 --> Language file loaded: language/english/email_lang.php
INFO - 2016-11-23 13:38:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
ERROR - 2016-11-23 13:38:14 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-23 13:38:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 13:38:14 --> Final output sent to browser
DEBUG - 2016-11-23 13:38:14 --> Total execution time: 2.2002
INFO - 2016-11-23 14:45:36 --> Config Class Initialized
INFO - 2016-11-23 14:45:36 --> Hooks Class Initialized
DEBUG - 2016-11-23 14:45:36 --> UTF-8 Support Enabled
INFO - 2016-11-23 14:45:36 --> Utf8 Class Initialized
INFO - 2016-11-23 14:45:36 --> URI Class Initialized
INFO - 2016-11-23 14:45:36 --> Router Class Initialized
INFO - 2016-11-23 14:45:36 --> Output Class Initialized
INFO - 2016-11-23 14:45:36 --> Security Class Initialized
DEBUG - 2016-11-23 14:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 14:45:36 --> Input Class Initialized
INFO - 2016-11-23 14:45:36 --> Language Class Initialized
INFO - 2016-11-23 14:45:36 --> Loader Class Initialized
INFO - 2016-11-23 14:45:36 --> Helper loaded: url_helper
INFO - 2016-11-23 14:45:36 --> Helper loaded: form_helper
INFO - 2016-11-23 14:45:36 --> Database Driver Class Initialized
INFO - 2016-11-23 14:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 14:45:36 --> Controller Class Initialized
INFO - 2016-11-23 14:45:36 --> Model Class Initialized
INFO - 2016-11-23 14:45:36 --> Form Validation Class Initialized
INFO - 2016-11-23 14:45:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-23 14:45:36 --> Final output sent to browser
DEBUG - 2016-11-23 14:45:36 --> Total execution time: 0.2608
INFO - 2016-11-23 14:45:52 --> Config Class Initialized
INFO - 2016-11-23 14:45:52 --> Hooks Class Initialized
DEBUG - 2016-11-23 14:45:52 --> UTF-8 Support Enabled
INFO - 2016-11-23 14:45:52 --> Utf8 Class Initialized
INFO - 2016-11-23 14:45:52 --> URI Class Initialized
INFO - 2016-11-23 14:45:52 --> Router Class Initialized
INFO - 2016-11-23 14:45:52 --> Output Class Initialized
INFO - 2016-11-23 14:45:52 --> Security Class Initialized
DEBUG - 2016-11-23 14:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 14:45:52 --> Input Class Initialized
INFO - 2016-11-23 14:45:52 --> Language Class Initialized
INFO - 2016-11-23 14:45:52 --> Loader Class Initialized
INFO - 2016-11-23 14:45:52 --> Helper loaded: url_helper
INFO - 2016-11-23 14:45:52 --> Helper loaded: form_helper
INFO - 2016-11-23 14:45:52 --> Database Driver Class Initialized
INFO - 2016-11-23 14:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 14:45:52 --> Controller Class Initialized
INFO - 2016-11-23 14:45:53 --> Model Class Initialized
INFO - 2016-11-23 14:45:53 --> Form Validation Class Initialized
INFO - 2016-11-23 14:45:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-23 14:45:53 --> Final output sent to browser
DEBUG - 2016-11-23 14:45:53 --> Total execution time: 0.2624
INFO - 2016-11-23 14:46:01 --> Config Class Initialized
INFO - 2016-11-23 14:46:01 --> Hooks Class Initialized
DEBUG - 2016-11-23 14:46:01 --> UTF-8 Support Enabled
INFO - 2016-11-23 14:46:01 --> Utf8 Class Initialized
INFO - 2016-11-23 14:46:01 --> URI Class Initialized
INFO - 2016-11-23 14:46:01 --> Router Class Initialized
INFO - 2016-11-23 14:46:01 --> Output Class Initialized
INFO - 2016-11-23 14:46:01 --> Security Class Initialized
DEBUG - 2016-11-23 14:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 14:46:01 --> Input Class Initialized
INFO - 2016-11-23 14:46:01 --> Language Class Initialized
INFO - 2016-11-23 14:46:01 --> Loader Class Initialized
INFO - 2016-11-23 14:46:01 --> Helper loaded: url_helper
INFO - 2016-11-23 14:46:01 --> Helper loaded: form_helper
INFO - 2016-11-23 14:46:01 --> Database Driver Class Initialized
INFO - 2016-11-23 14:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 14:46:01 --> Controller Class Initialized
INFO - 2016-11-23 14:46:01 --> Model Class Initialized
INFO - 2016-11-23 14:46:01 --> Form Validation Class Initialized
INFO - 2016-11-23 14:46:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 14:46:01 --> Pagination Class Initialized
INFO - 2016-11-23 14:46:01 --> Helper loaded: app_helper
INFO - 2016-11-23 14:46:02 --> Email Class Initialized
INFO - 2016-11-23 14:46:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-23 14:46:02 --> Final output sent to browser
DEBUG - 2016-11-23 14:46:02 --> Total execution time: 0.2807
INFO - 2016-11-23 14:46:09 --> Config Class Initialized
INFO - 2016-11-23 14:46:09 --> Hooks Class Initialized
DEBUG - 2016-11-23 14:46:09 --> UTF-8 Support Enabled
INFO - 2016-11-23 14:46:09 --> Utf8 Class Initialized
INFO - 2016-11-23 14:46:09 --> URI Class Initialized
INFO - 2016-11-23 14:46:09 --> Router Class Initialized
INFO - 2016-11-23 14:46:09 --> Output Class Initialized
INFO - 2016-11-23 14:46:09 --> Security Class Initialized
DEBUG - 2016-11-23 14:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 14:46:09 --> Input Class Initialized
INFO - 2016-11-23 14:46:09 --> Language Class Initialized
INFO - 2016-11-23 14:46:09 --> Loader Class Initialized
INFO - 2016-11-23 14:46:09 --> Helper loaded: url_helper
INFO - 2016-11-23 14:46:09 --> Helper loaded: form_helper
INFO - 2016-11-23 14:46:09 --> Database Driver Class Initialized
INFO - 2016-11-23 14:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 14:46:09 --> Controller Class Initialized
INFO - 2016-11-23 14:46:09 --> Model Class Initialized
INFO - 2016-11-23 14:46:09 --> Form Validation Class Initialized
INFO - 2016-11-23 14:46:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 14:46:09 --> Pagination Class Initialized
INFO - 2016-11-23 14:46:09 --> Helper loaded: app_helper
INFO - 2016-11-23 14:46:09 --> Email Class Initialized
INFO - 2016-11-23 14:46:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-23 14:46:09 --> Final output sent to browser
DEBUG - 2016-11-23 14:46:09 --> Total execution time: 0.2693
INFO - 2016-11-23 14:46:53 --> Config Class Initialized
INFO - 2016-11-23 14:46:53 --> Hooks Class Initialized
DEBUG - 2016-11-23 14:46:53 --> UTF-8 Support Enabled
INFO - 2016-11-23 14:46:53 --> Utf8 Class Initialized
INFO - 2016-11-23 14:46:53 --> URI Class Initialized
INFO - 2016-11-23 14:46:53 --> Router Class Initialized
INFO - 2016-11-23 14:46:53 --> Output Class Initialized
INFO - 2016-11-23 14:46:53 --> Security Class Initialized
DEBUG - 2016-11-23 14:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 14:46:53 --> Input Class Initialized
INFO - 2016-11-23 14:46:53 --> Language Class Initialized
INFO - 2016-11-23 14:46:53 --> Loader Class Initialized
INFO - 2016-11-23 14:46:53 --> Helper loaded: url_helper
INFO - 2016-11-23 14:46:53 --> Helper loaded: form_helper
INFO - 2016-11-23 14:46:53 --> Database Driver Class Initialized
INFO - 2016-11-23 14:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 14:46:53 --> Controller Class Initialized
INFO - 2016-11-23 14:46:53 --> Model Class Initialized
INFO - 2016-11-23 14:46:53 --> Form Validation Class Initialized
INFO - 2016-11-23 14:46:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 14:46:53 --> Pagination Class Initialized
INFO - 2016-11-23 14:46:53 --> Helper loaded: app_helper
INFO - 2016-11-23 14:46:53 --> Email Class Initialized
INFO - 2016-11-23 14:46:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-23 14:46:53 --> Final output sent to browser
DEBUG - 2016-11-23 14:46:53 --> Total execution time: 0.2764
INFO - 2016-11-23 14:46:59 --> Config Class Initialized
INFO - 2016-11-23 14:46:59 --> Hooks Class Initialized
DEBUG - 2016-11-23 14:46:59 --> UTF-8 Support Enabled
INFO - 2016-11-23 14:46:59 --> Utf8 Class Initialized
INFO - 2016-11-23 14:46:59 --> URI Class Initialized
DEBUG - 2016-11-23 14:46:59 --> No URI present. Default controller set.
INFO - 2016-11-23 14:46:59 --> Router Class Initialized
INFO - 2016-11-23 14:46:59 --> Output Class Initialized
INFO - 2016-11-23 14:46:59 --> Security Class Initialized
DEBUG - 2016-11-23 14:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 14:46:59 --> Input Class Initialized
INFO - 2016-11-23 14:46:59 --> Language Class Initialized
INFO - 2016-11-23 14:46:59 --> Loader Class Initialized
INFO - 2016-11-23 14:46:59 --> Helper loaded: url_helper
INFO - 2016-11-23 14:46:59 --> Helper loaded: form_helper
INFO - 2016-11-23 14:46:59 --> Database Driver Class Initialized
INFO - 2016-11-23 14:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 14:46:59 --> Controller Class Initialized
INFO - 2016-11-23 14:46:59 --> Model Class Initialized
INFO - 2016-11-23 14:46:59 --> Model Class Initialized
INFO - 2016-11-23 14:46:59 --> Model Class Initialized
INFO - 2016-11-23 14:46:59 --> Model Class Initialized
INFO - 2016-11-23 14:46:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 14:46:59 --> Pagination Class Initialized
INFO - 2016-11-23 14:46:59 --> Helper loaded: app_helper
INFO - 2016-11-23 14:46:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 14:46:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-23 14:46:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-23 14:46:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-23 14:46:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 14:46:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-23 14:46:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-23 14:46:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-23 14:46:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-23 14:46:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-23 14:46:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-23 14:46:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 14:47:00 --> Final output sent to browser
DEBUG - 2016-11-23 14:47:00 --> Total execution time: 0.5077
INFO - 2016-11-23 14:51:35 --> Config Class Initialized
INFO - 2016-11-23 14:51:35 --> Hooks Class Initialized
DEBUG - 2016-11-23 14:51:35 --> UTF-8 Support Enabled
INFO - 2016-11-23 14:51:35 --> Utf8 Class Initialized
INFO - 2016-11-23 14:51:35 --> URI Class Initialized
DEBUG - 2016-11-23 14:51:35 --> No URI present. Default controller set.
INFO - 2016-11-23 14:51:35 --> Router Class Initialized
INFO - 2016-11-23 14:51:35 --> Output Class Initialized
INFO - 2016-11-23 14:51:35 --> Security Class Initialized
DEBUG - 2016-11-23 14:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 14:51:35 --> Input Class Initialized
INFO - 2016-11-23 14:51:35 --> Language Class Initialized
INFO - 2016-11-23 14:51:35 --> Loader Class Initialized
INFO - 2016-11-23 14:51:35 --> Helper loaded: url_helper
INFO - 2016-11-23 14:51:35 --> Helper loaded: form_helper
INFO - 2016-11-23 14:51:35 --> Database Driver Class Initialized
INFO - 2016-11-23 14:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 14:51:35 --> Controller Class Initialized
INFO - 2016-11-23 14:51:35 --> Model Class Initialized
INFO - 2016-11-23 14:51:35 --> Model Class Initialized
INFO - 2016-11-23 14:51:35 --> Model Class Initialized
INFO - 2016-11-23 14:51:35 --> Model Class Initialized
INFO - 2016-11-23 14:51:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 14:51:35 --> Pagination Class Initialized
INFO - 2016-11-23 14:51:35 --> Helper loaded: app_helper
INFO - 2016-11-23 14:51:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 14:51:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-23 14:51:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-23 14:51:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-23 14:51:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 14:51:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-23 14:51:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-23 14:51:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-23 14:51:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-23 14:51:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-23 14:51:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-23 14:51:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 14:51:35 --> Final output sent to browser
DEBUG - 2016-11-23 14:51:35 --> Total execution time: 0.4838
INFO - 2016-11-23 18:25:45 --> Config Class Initialized
INFO - 2016-11-23 18:25:46 --> Hooks Class Initialized
DEBUG - 2016-11-23 18:25:46 --> UTF-8 Support Enabled
INFO - 2016-11-23 18:25:46 --> Utf8 Class Initialized
INFO - 2016-11-23 18:25:46 --> URI Class Initialized
DEBUG - 2016-11-23 18:25:46 --> No URI present. Default controller set.
INFO - 2016-11-23 18:25:46 --> Router Class Initialized
INFO - 2016-11-23 18:25:46 --> Output Class Initialized
INFO - 2016-11-23 18:25:46 --> Security Class Initialized
DEBUG - 2016-11-23 18:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 18:25:46 --> Input Class Initialized
INFO - 2016-11-23 18:25:46 --> Language Class Initialized
INFO - 2016-11-23 18:25:46 --> Loader Class Initialized
INFO - 2016-11-23 18:25:46 --> Helper loaded: url_helper
INFO - 2016-11-23 18:25:46 --> Helper loaded: form_helper
INFO - 2016-11-23 18:25:46 --> Database Driver Class Initialized
INFO - 2016-11-23 18:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 18:25:46 --> Controller Class Initialized
INFO - 2016-11-23 18:25:46 --> Model Class Initialized
INFO - 2016-11-23 18:25:46 --> Model Class Initialized
INFO - 2016-11-23 18:25:46 --> Model Class Initialized
INFO - 2016-11-23 18:25:46 --> Model Class Initialized
INFO - 2016-11-23 18:25:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 18:25:46 --> Pagination Class Initialized
INFO - 2016-11-23 18:25:46 --> Helper loaded: app_helper
INFO - 2016-11-23 18:25:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 18:25:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-23 18:25:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 18:25:46 --> Final output sent to browser
DEBUG - 2016-11-23 18:25:46 --> Total execution time: 0.3392
INFO - 2016-11-23 18:29:06 --> Config Class Initialized
INFO - 2016-11-23 18:29:06 --> Hooks Class Initialized
DEBUG - 2016-11-23 18:29:06 --> UTF-8 Support Enabled
INFO - 2016-11-23 18:29:06 --> Utf8 Class Initialized
INFO - 2016-11-23 18:29:06 --> URI Class Initialized
INFO - 2016-11-23 18:29:06 --> Router Class Initialized
INFO - 2016-11-23 18:29:06 --> Output Class Initialized
INFO - 2016-11-23 18:29:06 --> Security Class Initialized
DEBUG - 2016-11-23 18:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 18:29:06 --> Input Class Initialized
INFO - 2016-11-23 18:29:06 --> Language Class Initialized
INFO - 2016-11-23 18:29:06 --> Loader Class Initialized
INFO - 2016-11-23 18:29:06 --> Helper loaded: url_helper
INFO - 2016-11-23 18:29:06 --> Helper loaded: form_helper
INFO - 2016-11-23 18:29:06 --> Database Driver Class Initialized
INFO - 2016-11-23 18:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 18:29:06 --> Controller Class Initialized
INFO - 2016-11-23 18:29:06 --> Model Class Initialized
INFO - 2016-11-23 18:29:06 --> Model Class Initialized
INFO - 2016-11-23 18:29:06 --> Model Class Initialized
INFO - 2016-11-23 18:29:06 --> Model Class Initialized
INFO - 2016-11-23 18:29:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 18:29:06 --> Pagination Class Initialized
INFO - 2016-11-23 18:29:06 --> Helper loaded: app_helper
DEBUG - 2016-11-23 18:29:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-23 18:29:06 --> Model Class Initialized
INFO - 2016-11-23 18:29:07 --> Final output sent to browser
DEBUG - 2016-11-23 18:29:07 --> Total execution time: 0.3731
INFO - 2016-11-23 18:29:07 --> Config Class Initialized
INFO - 2016-11-23 18:29:07 --> Hooks Class Initialized
DEBUG - 2016-11-23 18:29:07 --> UTF-8 Support Enabled
INFO - 2016-11-23 18:29:07 --> Utf8 Class Initialized
INFO - 2016-11-23 18:29:07 --> URI Class Initialized
DEBUG - 2016-11-23 18:29:07 --> No URI present. Default controller set.
INFO - 2016-11-23 18:29:07 --> Router Class Initialized
INFO - 2016-11-23 18:29:07 --> Output Class Initialized
INFO - 2016-11-23 18:29:07 --> Security Class Initialized
DEBUG - 2016-11-23 18:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 18:29:07 --> Input Class Initialized
INFO - 2016-11-23 18:29:07 --> Language Class Initialized
INFO - 2016-11-23 18:29:07 --> Loader Class Initialized
INFO - 2016-11-23 18:29:07 --> Helper loaded: url_helper
INFO - 2016-11-23 18:29:07 --> Helper loaded: form_helper
INFO - 2016-11-23 18:29:07 --> Database Driver Class Initialized
INFO - 2016-11-23 18:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 18:29:07 --> Controller Class Initialized
INFO - 2016-11-23 18:29:07 --> Model Class Initialized
INFO - 2016-11-23 18:29:07 --> Model Class Initialized
INFO - 2016-11-23 18:29:07 --> Model Class Initialized
INFO - 2016-11-23 18:29:07 --> Model Class Initialized
INFO - 2016-11-23 18:29:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 18:29:07 --> Pagination Class Initialized
INFO - 2016-11-23 18:29:07 --> Helper loaded: app_helper
INFO - 2016-11-23 18:29:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 18:29:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-23 18:29:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-23 18:29:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-23 18:29:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 18:29:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-23 18:29:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-23 18:29:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-23 18:29:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-23 18:29:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-23 18:29:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-23 18:29:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 18:29:07 --> Final output sent to browser
DEBUG - 2016-11-23 18:29:07 --> Total execution time: 0.7335
INFO - 2016-11-23 18:40:59 --> Config Class Initialized
INFO - 2016-11-23 18:40:59 --> Hooks Class Initialized
DEBUG - 2016-11-23 18:40:59 --> UTF-8 Support Enabled
INFO - 2016-11-23 18:40:59 --> Utf8 Class Initialized
INFO - 2016-11-23 18:40:59 --> URI Class Initialized
DEBUG - 2016-11-23 18:40:59 --> No URI present. Default controller set.
INFO - 2016-11-23 18:41:00 --> Router Class Initialized
INFO - 2016-11-23 18:41:00 --> Output Class Initialized
INFO - 2016-11-23 18:41:00 --> Security Class Initialized
DEBUG - 2016-11-23 18:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 18:41:00 --> Input Class Initialized
INFO - 2016-11-23 18:41:00 --> Language Class Initialized
INFO - 2016-11-23 18:41:00 --> Loader Class Initialized
INFO - 2016-11-23 18:41:00 --> Helper loaded: url_helper
INFO - 2016-11-23 18:41:00 --> Helper loaded: form_helper
INFO - 2016-11-23 18:41:00 --> Database Driver Class Initialized
INFO - 2016-11-23 18:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 18:41:00 --> Controller Class Initialized
INFO - 2016-11-23 18:41:00 --> Model Class Initialized
INFO - 2016-11-23 18:41:00 --> Model Class Initialized
INFO - 2016-11-23 18:41:00 --> Model Class Initialized
INFO - 2016-11-23 18:41:00 --> Model Class Initialized
INFO - 2016-11-23 18:41:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 18:41:00 --> Pagination Class Initialized
INFO - 2016-11-23 18:41:00 --> Helper loaded: app_helper
INFO - 2016-11-23 18:41:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 18:41:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-23 18:41:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-23 18:41:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-23 18:41:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 18:41:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-23 18:41:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-23 18:41:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-23 18:41:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-23 18:41:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-23 18:41:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-23 18:41:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 18:41:00 --> Final output sent to browser
DEBUG - 2016-11-23 18:41:00 --> Total execution time: 0.5165
INFO - 2016-11-23 18:41:09 --> Config Class Initialized
INFO - 2016-11-23 18:41:09 --> Hooks Class Initialized
DEBUG - 2016-11-23 18:41:09 --> UTF-8 Support Enabled
INFO - 2016-11-23 18:41:09 --> Utf8 Class Initialized
INFO - 2016-11-23 18:41:09 --> URI Class Initialized
INFO - 2016-11-23 18:41:09 --> Router Class Initialized
INFO - 2016-11-23 18:41:09 --> Output Class Initialized
INFO - 2016-11-23 18:41:09 --> Security Class Initialized
DEBUG - 2016-11-23 18:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 18:41:09 --> Input Class Initialized
INFO - 2016-11-23 18:41:09 --> Language Class Initialized
INFO - 2016-11-23 18:41:09 --> Loader Class Initialized
INFO - 2016-11-23 18:41:09 --> Helper loaded: url_helper
INFO - 2016-11-23 18:41:09 --> Helper loaded: form_helper
INFO - 2016-11-23 18:41:09 --> Database Driver Class Initialized
INFO - 2016-11-23 18:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 18:41:09 --> Controller Class Initialized
INFO - 2016-11-23 18:41:09 --> Model Class Initialized
INFO - 2016-11-23 18:41:09 --> Form Validation Class Initialized
INFO - 2016-11-23 18:41:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 18:41:09 --> Pagination Class Initialized
INFO - 2016-11-23 18:41:09 --> Helper loaded: app_helper
INFO - 2016-11-23 18:41:09 --> Email Class Initialized
INFO - 2016-11-23 18:41:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-23 18:41:09 --> Final output sent to browser
DEBUG - 2016-11-23 18:41:09 --> Total execution time: 0.2816
INFO - 2016-11-23 18:42:28 --> Config Class Initialized
INFO - 2016-11-23 18:42:28 --> Hooks Class Initialized
DEBUG - 2016-11-23 18:42:28 --> UTF-8 Support Enabled
INFO - 2016-11-23 18:42:28 --> Utf8 Class Initialized
INFO - 2016-11-23 18:42:28 --> URI Class Initialized
DEBUG - 2016-11-23 18:42:28 --> No URI present. Default controller set.
INFO - 2016-11-23 18:42:28 --> Router Class Initialized
INFO - 2016-11-23 18:42:28 --> Output Class Initialized
INFO - 2016-11-23 18:42:28 --> Security Class Initialized
DEBUG - 2016-11-23 18:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 18:42:28 --> Input Class Initialized
INFO - 2016-11-23 18:42:28 --> Language Class Initialized
INFO - 2016-11-23 18:42:28 --> Loader Class Initialized
INFO - 2016-11-23 18:42:28 --> Helper loaded: url_helper
INFO - 2016-11-23 18:42:28 --> Helper loaded: form_helper
INFO - 2016-11-23 18:42:28 --> Database Driver Class Initialized
INFO - 2016-11-23 18:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 18:42:28 --> Controller Class Initialized
INFO - 2016-11-23 18:42:28 --> Model Class Initialized
INFO - 2016-11-23 18:42:28 --> Model Class Initialized
INFO - 2016-11-23 18:42:28 --> Model Class Initialized
INFO - 2016-11-23 18:42:28 --> Model Class Initialized
INFO - 2016-11-23 18:42:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 18:42:28 --> Pagination Class Initialized
INFO - 2016-11-23 18:42:28 --> Helper loaded: app_helper
INFO - 2016-11-23 18:42:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 18:42:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-23 18:42:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-23 18:42:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-23 18:42:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 18:42:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-23 18:42:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-23 18:42:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-23 18:42:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-23 18:42:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-23 18:42:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-23 18:42:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 18:42:28 --> Final output sent to browser
DEBUG - 2016-11-23 18:42:28 --> Total execution time: 0.4886
INFO - 2016-11-23 18:44:03 --> Config Class Initialized
INFO - 2016-11-23 18:44:03 --> Hooks Class Initialized
DEBUG - 2016-11-23 18:44:03 --> UTF-8 Support Enabled
INFO - 2016-11-23 18:44:03 --> Utf8 Class Initialized
INFO - 2016-11-23 18:44:03 --> URI Class Initialized
DEBUG - 2016-11-23 18:44:03 --> No URI present. Default controller set.
INFO - 2016-11-23 18:44:03 --> Router Class Initialized
INFO - 2016-11-23 18:44:03 --> Output Class Initialized
INFO - 2016-11-23 18:44:03 --> Security Class Initialized
DEBUG - 2016-11-23 18:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 18:44:03 --> Input Class Initialized
INFO - 2016-11-23 18:44:03 --> Language Class Initialized
INFO - 2016-11-23 18:44:03 --> Loader Class Initialized
INFO - 2016-11-23 18:44:03 --> Helper loaded: url_helper
INFO - 2016-11-23 18:44:03 --> Helper loaded: form_helper
INFO - 2016-11-23 18:44:03 --> Database Driver Class Initialized
INFO - 2016-11-23 18:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 18:44:03 --> Controller Class Initialized
INFO - 2016-11-23 18:44:03 --> Model Class Initialized
INFO - 2016-11-23 18:44:03 --> Model Class Initialized
INFO - 2016-11-23 18:44:03 --> Model Class Initialized
INFO - 2016-11-23 18:44:03 --> Model Class Initialized
INFO - 2016-11-23 18:44:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 18:44:03 --> Pagination Class Initialized
INFO - 2016-11-23 18:44:03 --> Helper loaded: app_helper
INFO - 2016-11-23 18:44:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 18:44:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-23 18:44:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-23 18:44:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-23 18:44:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 18:44:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-23 18:44:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-23 18:44:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-23 18:44:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-23 18:44:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-23 18:44:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-23 18:44:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 18:44:03 --> Final output sent to browser
DEBUG - 2016-11-23 18:44:03 --> Total execution time: 0.5160
INFO - 2016-11-23 18:44:09 --> Config Class Initialized
INFO - 2016-11-23 18:44:09 --> Hooks Class Initialized
DEBUG - 2016-11-23 18:44:09 --> UTF-8 Support Enabled
INFO - 2016-11-23 18:44:09 --> Utf8 Class Initialized
INFO - 2016-11-23 18:44:09 --> URI Class Initialized
INFO - 2016-11-23 18:44:09 --> Router Class Initialized
INFO - 2016-11-23 18:44:09 --> Output Class Initialized
INFO - 2016-11-23 18:44:09 --> Security Class Initialized
DEBUG - 2016-11-23 18:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 18:44:09 --> Input Class Initialized
INFO - 2016-11-23 18:44:09 --> Language Class Initialized
INFO - 2016-11-23 18:44:09 --> Loader Class Initialized
INFO - 2016-11-23 18:44:09 --> Helper loaded: url_helper
INFO - 2016-11-23 18:44:09 --> Helper loaded: form_helper
INFO - 2016-11-23 18:44:09 --> Database Driver Class Initialized
INFO - 2016-11-23 18:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 18:44:09 --> Controller Class Initialized
INFO - 2016-11-23 18:44:09 --> Model Class Initialized
INFO - 2016-11-23 18:44:09 --> Form Validation Class Initialized
INFO - 2016-11-23 18:44:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-23 18:44:09 --> Final output sent to browser
DEBUG - 2016-11-23 18:44:09 --> Total execution time: 0.2282
INFO - 2016-11-23 18:44:11 --> Config Class Initialized
INFO - 2016-11-23 18:44:11 --> Hooks Class Initialized
DEBUG - 2016-11-23 18:44:11 --> UTF-8 Support Enabled
INFO - 2016-11-23 18:44:11 --> Utf8 Class Initialized
INFO - 2016-11-23 18:44:11 --> URI Class Initialized
DEBUG - 2016-11-23 18:44:11 --> No URI present. Default controller set.
INFO - 2016-11-23 18:44:11 --> Router Class Initialized
INFO - 2016-11-23 18:44:11 --> Output Class Initialized
INFO - 2016-11-23 18:44:11 --> Security Class Initialized
DEBUG - 2016-11-23 18:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 18:44:11 --> Input Class Initialized
INFO - 2016-11-23 18:44:11 --> Language Class Initialized
INFO - 2016-11-23 18:44:11 --> Loader Class Initialized
INFO - 2016-11-23 18:44:11 --> Helper loaded: url_helper
INFO - 2016-11-23 18:44:11 --> Helper loaded: form_helper
INFO - 2016-11-23 18:44:11 --> Database Driver Class Initialized
INFO - 2016-11-23 18:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 18:44:11 --> Controller Class Initialized
INFO - 2016-11-23 18:44:11 --> Model Class Initialized
INFO - 2016-11-23 18:44:11 --> Model Class Initialized
INFO - 2016-11-23 18:44:11 --> Model Class Initialized
INFO - 2016-11-23 18:44:11 --> Model Class Initialized
INFO - 2016-11-23 18:44:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 18:44:11 --> Pagination Class Initialized
INFO - 2016-11-23 18:44:11 --> Helper loaded: app_helper
INFO - 2016-11-23 18:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 18:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-23 18:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-23 18:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-23 18:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 18:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-23 18:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-23 18:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-23 18:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-23 18:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-23 18:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-23 18:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 18:44:11 --> Final output sent to browser
DEBUG - 2016-11-23 18:44:11 --> Total execution time: 0.5833
INFO - 2016-11-23 18:44:20 --> Config Class Initialized
INFO - 2016-11-23 18:44:20 --> Hooks Class Initialized
DEBUG - 2016-11-23 18:44:20 --> UTF-8 Support Enabled
INFO - 2016-11-23 18:44:20 --> Utf8 Class Initialized
INFO - 2016-11-23 18:44:20 --> URI Class Initialized
INFO - 2016-11-23 18:44:20 --> Router Class Initialized
INFO - 2016-11-23 18:44:20 --> Output Class Initialized
INFO - 2016-11-23 18:44:20 --> Security Class Initialized
DEBUG - 2016-11-23 18:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 18:44:20 --> Input Class Initialized
INFO - 2016-11-23 18:44:21 --> Language Class Initialized
INFO - 2016-11-23 18:44:21 --> Loader Class Initialized
INFO - 2016-11-23 18:44:21 --> Helper loaded: url_helper
INFO - 2016-11-23 18:44:21 --> Helper loaded: form_helper
INFO - 2016-11-23 18:44:21 --> Database Driver Class Initialized
INFO - 2016-11-23 18:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 18:44:21 --> Controller Class Initialized
INFO - 2016-11-23 18:44:21 --> Model Class Initialized
INFO - 2016-11-23 18:44:21 --> Form Validation Class Initialized
INFO - 2016-11-23 18:44:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 18:44:21 --> Pagination Class Initialized
INFO - 2016-11-23 18:44:21 --> Helper loaded: app_helper
INFO - 2016-11-23 18:44:21 --> Email Class Initialized
INFO - 2016-11-23 18:44:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-23 18:44:21 --> Final output sent to browser
DEBUG - 2016-11-23 18:44:21 --> Total execution time: 0.2874
INFO - 2016-11-23 18:44:31 --> Config Class Initialized
INFO - 2016-11-23 18:44:31 --> Hooks Class Initialized
DEBUG - 2016-11-23 18:44:31 --> UTF-8 Support Enabled
INFO - 2016-11-23 18:44:31 --> Utf8 Class Initialized
INFO - 2016-11-23 18:44:31 --> URI Class Initialized
DEBUG - 2016-11-23 18:44:31 --> No URI present. Default controller set.
INFO - 2016-11-23 18:44:31 --> Router Class Initialized
INFO - 2016-11-23 18:44:31 --> Output Class Initialized
INFO - 2016-11-23 18:44:31 --> Security Class Initialized
DEBUG - 2016-11-23 18:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 18:44:31 --> Input Class Initialized
INFO - 2016-11-23 18:44:31 --> Language Class Initialized
INFO - 2016-11-23 18:44:31 --> Loader Class Initialized
INFO - 2016-11-23 18:44:31 --> Helper loaded: url_helper
INFO - 2016-11-23 18:44:31 --> Helper loaded: form_helper
INFO - 2016-11-23 18:44:31 --> Database Driver Class Initialized
INFO - 2016-11-23 18:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 18:44:31 --> Controller Class Initialized
INFO - 2016-11-23 18:44:31 --> Model Class Initialized
INFO - 2016-11-23 18:44:31 --> Model Class Initialized
INFO - 2016-11-23 18:44:31 --> Model Class Initialized
INFO - 2016-11-23 18:44:31 --> Model Class Initialized
INFO - 2016-11-23 18:44:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 18:44:31 --> Pagination Class Initialized
INFO - 2016-11-23 18:44:31 --> Helper loaded: app_helper
INFO - 2016-11-23 18:44:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 18:44:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-23 18:44:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-23 18:44:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-23 18:44:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 18:44:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-23 18:44:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-23 18:44:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-23 18:44:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-23 18:44:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-23 18:44:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-23 18:44:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 18:44:32 --> Final output sent to browser
DEBUG - 2016-11-23 18:44:32 --> Total execution time: 0.7524
INFO - 2016-11-23 18:44:41 --> Config Class Initialized
INFO - 2016-11-23 18:44:41 --> Hooks Class Initialized
DEBUG - 2016-11-23 18:44:41 --> UTF-8 Support Enabled
INFO - 2016-11-23 18:44:41 --> Utf8 Class Initialized
INFO - 2016-11-23 18:44:41 --> URI Class Initialized
DEBUG - 2016-11-23 18:44:41 --> No URI present. Default controller set.
INFO - 2016-11-23 18:44:41 --> Router Class Initialized
INFO - 2016-11-23 18:44:41 --> Output Class Initialized
INFO - 2016-11-23 18:44:41 --> Security Class Initialized
DEBUG - 2016-11-23 18:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 18:44:41 --> Input Class Initialized
INFO - 2016-11-23 18:44:41 --> Language Class Initialized
INFO - 2016-11-23 18:44:41 --> Loader Class Initialized
INFO - 2016-11-23 18:44:41 --> Helper loaded: url_helper
INFO - 2016-11-23 18:44:41 --> Helper loaded: form_helper
INFO - 2016-11-23 18:44:41 --> Database Driver Class Initialized
INFO - 2016-11-23 18:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 18:44:41 --> Controller Class Initialized
INFO - 2016-11-23 18:44:41 --> Model Class Initialized
INFO - 2016-11-23 18:44:41 --> Model Class Initialized
INFO - 2016-11-23 18:44:41 --> Model Class Initialized
INFO - 2016-11-23 18:44:41 --> Model Class Initialized
INFO - 2016-11-23 18:44:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 18:44:41 --> Pagination Class Initialized
INFO - 2016-11-23 18:44:41 --> Helper loaded: app_helper
INFO - 2016-11-23 18:44:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 18:44:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-23 18:44:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-23 18:44:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-23 18:44:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 18:44:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-23 18:44:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-23 18:44:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-23 18:44:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-23 18:44:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-23 18:44:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-23 18:44:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 18:44:41 --> Final output sent to browser
DEBUG - 2016-11-23 18:44:41 --> Total execution time: 0.5072
INFO - 2016-11-23 18:44:51 --> Config Class Initialized
INFO - 2016-11-23 18:44:51 --> Hooks Class Initialized
DEBUG - 2016-11-23 18:44:51 --> UTF-8 Support Enabled
INFO - 2016-11-23 18:44:51 --> Utf8 Class Initialized
INFO - 2016-11-23 18:44:51 --> URI Class Initialized
DEBUG - 2016-11-23 18:44:51 --> No URI present. Default controller set.
INFO - 2016-11-23 18:44:51 --> Router Class Initialized
INFO - 2016-11-23 18:44:51 --> Output Class Initialized
INFO - 2016-11-23 18:44:51 --> Security Class Initialized
DEBUG - 2016-11-23 18:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 18:44:51 --> Input Class Initialized
INFO - 2016-11-23 18:44:51 --> Language Class Initialized
INFO - 2016-11-23 18:44:51 --> Loader Class Initialized
INFO - 2016-11-23 18:44:51 --> Helper loaded: url_helper
INFO - 2016-11-23 18:44:51 --> Helper loaded: form_helper
INFO - 2016-11-23 18:44:51 --> Database Driver Class Initialized
INFO - 2016-11-23 18:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 18:44:51 --> Controller Class Initialized
INFO - 2016-11-23 18:44:51 --> Model Class Initialized
INFO - 2016-11-23 18:44:51 --> Model Class Initialized
INFO - 2016-11-23 18:44:51 --> Model Class Initialized
INFO - 2016-11-23 18:44:51 --> Model Class Initialized
INFO - 2016-11-23 18:44:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 18:44:51 --> Pagination Class Initialized
INFO - 2016-11-23 18:44:51 --> Helper loaded: app_helper
INFO - 2016-11-23 18:44:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 18:44:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-23 18:44:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-23 18:44:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-23 18:44:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 18:44:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-23 18:44:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-23 18:44:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-23 18:44:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-23 18:44:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-23 18:44:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-23 18:44:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 18:44:51 --> Final output sent to browser
DEBUG - 2016-11-23 18:44:51 --> Total execution time: 0.5116
INFO - 2016-11-23 18:54:12 --> Config Class Initialized
INFO - 2016-11-23 18:54:12 --> Hooks Class Initialized
DEBUG - 2016-11-23 18:54:12 --> UTF-8 Support Enabled
INFO - 2016-11-23 18:54:12 --> Utf8 Class Initialized
INFO - 2016-11-23 18:54:12 --> URI Class Initialized
DEBUG - 2016-11-23 18:54:12 --> No URI present. Default controller set.
INFO - 2016-11-23 18:54:12 --> Router Class Initialized
INFO - 2016-11-23 18:54:12 --> Output Class Initialized
INFO - 2016-11-23 18:54:12 --> Security Class Initialized
DEBUG - 2016-11-23 18:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 18:54:12 --> Input Class Initialized
INFO - 2016-11-23 18:54:12 --> Language Class Initialized
INFO - 2016-11-23 18:54:12 --> Loader Class Initialized
INFO - 2016-11-23 18:54:12 --> Helper loaded: url_helper
INFO - 2016-11-23 18:54:12 --> Helper loaded: form_helper
INFO - 2016-11-23 18:54:12 --> Database Driver Class Initialized
INFO - 2016-11-23 18:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 18:54:12 --> Controller Class Initialized
INFO - 2016-11-23 18:54:12 --> Model Class Initialized
INFO - 2016-11-23 18:54:12 --> Model Class Initialized
INFO - 2016-11-23 18:54:12 --> Model Class Initialized
INFO - 2016-11-23 18:54:12 --> Model Class Initialized
INFO - 2016-11-23 18:54:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 18:54:12 --> Pagination Class Initialized
INFO - 2016-11-23 18:54:12 --> Helper loaded: app_helper
INFO - 2016-11-23 18:54:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 18:54:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-23 18:54:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-23 18:54:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-23 18:54:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 18:54:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-23 18:54:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-23 18:54:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-23 18:54:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-23 18:54:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-23 18:54:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-23 18:54:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 18:54:12 --> Final output sent to browser
DEBUG - 2016-11-23 18:54:12 --> Total execution time: 0.5456
INFO - 2016-11-23 18:54:40 --> Config Class Initialized
INFO - 2016-11-23 18:54:40 --> Hooks Class Initialized
DEBUG - 2016-11-23 18:54:40 --> UTF-8 Support Enabled
INFO - 2016-11-23 18:54:40 --> Utf8 Class Initialized
INFO - 2016-11-23 18:54:40 --> URI Class Initialized
INFO - 2016-11-23 18:54:40 --> Router Class Initialized
INFO - 2016-11-23 18:54:40 --> Output Class Initialized
INFO - 2016-11-23 18:54:40 --> Security Class Initialized
DEBUG - 2016-11-23 18:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 18:54:40 --> Input Class Initialized
INFO - 2016-11-23 18:54:40 --> Language Class Initialized
INFO - 2016-11-23 18:54:40 --> Loader Class Initialized
INFO - 2016-11-23 18:54:40 --> Helper loaded: url_helper
INFO - 2016-11-23 18:54:40 --> Helper loaded: form_helper
INFO - 2016-11-23 18:54:40 --> Database Driver Class Initialized
INFO - 2016-11-23 18:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 18:54:40 --> Controller Class Initialized
INFO - 2016-11-23 18:54:40 --> Model Class Initialized
INFO - 2016-11-23 18:54:40 --> Form Validation Class Initialized
INFO - 2016-11-23 18:54:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 18:54:40 --> Pagination Class Initialized
INFO - 2016-11-23 18:54:40 --> Helper loaded: app_helper
INFO - 2016-11-23 18:54:40 --> Email Class Initialized
INFO - 2016-11-23 18:54:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-23 18:54:40 --> Final output sent to browser
DEBUG - 2016-11-23 18:54:41 --> Total execution time: 0.2853
INFO - 2016-11-23 18:55:03 --> Config Class Initialized
INFO - 2016-11-23 18:55:03 --> Hooks Class Initialized
DEBUG - 2016-11-23 18:55:03 --> UTF-8 Support Enabled
INFO - 2016-11-23 18:55:03 --> Utf8 Class Initialized
INFO - 2016-11-23 18:55:03 --> URI Class Initialized
INFO - 2016-11-23 18:55:03 --> Router Class Initialized
INFO - 2016-11-23 18:55:03 --> Output Class Initialized
INFO - 2016-11-23 18:55:03 --> Security Class Initialized
DEBUG - 2016-11-23 18:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 18:55:03 --> Input Class Initialized
INFO - 2016-11-23 18:55:03 --> Language Class Initialized
INFO - 2016-11-23 18:55:03 --> Loader Class Initialized
INFO - 2016-11-23 18:55:03 --> Helper loaded: url_helper
INFO - 2016-11-23 18:55:03 --> Helper loaded: form_helper
INFO - 2016-11-23 18:55:03 --> Database Driver Class Initialized
INFO - 2016-11-23 18:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 18:55:03 --> Controller Class Initialized
INFO - 2016-11-23 18:55:03 --> Model Class Initialized
INFO - 2016-11-23 18:55:03 --> Form Validation Class Initialized
INFO - 2016-11-23 18:55:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 18:55:03 --> Pagination Class Initialized
INFO - 2016-11-23 18:55:03 --> Helper loaded: app_helper
INFO - 2016-11-23 18:55:03 --> Email Class Initialized
INFO - 2016-11-23 18:55:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-23 18:55:03 --> Final output sent to browser
DEBUG - 2016-11-23 18:55:03 --> Total execution time: 0.2932
INFO - 2016-11-23 18:55:13 --> Config Class Initialized
INFO - 2016-11-23 18:55:13 --> Hooks Class Initialized
DEBUG - 2016-11-23 18:55:13 --> UTF-8 Support Enabled
INFO - 2016-11-23 18:55:13 --> Utf8 Class Initialized
INFO - 2016-11-23 18:55:13 --> URI Class Initialized
INFO - 2016-11-23 18:55:13 --> Router Class Initialized
INFO - 2016-11-23 18:55:13 --> Output Class Initialized
INFO - 2016-11-23 18:55:13 --> Security Class Initialized
DEBUG - 2016-11-23 18:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 18:55:13 --> Input Class Initialized
INFO - 2016-11-23 18:55:13 --> Language Class Initialized
INFO - 2016-11-23 18:55:13 --> Loader Class Initialized
INFO - 2016-11-23 18:55:13 --> Helper loaded: url_helper
INFO - 2016-11-23 18:55:13 --> Helper loaded: form_helper
INFO - 2016-11-23 18:55:13 --> Database Driver Class Initialized
INFO - 2016-11-23 18:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 18:55:13 --> Controller Class Initialized
INFO - 2016-11-23 18:55:13 --> Model Class Initialized
INFO - 2016-11-23 18:55:13 --> Form Validation Class Initialized
INFO - 2016-11-23 18:55:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 18:55:13 --> Pagination Class Initialized
INFO - 2016-11-23 18:55:13 --> Helper loaded: app_helper
INFO - 2016-11-23 18:55:13 --> Email Class Initialized
INFO - 2016-11-23 18:55:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-23 18:55:13 --> Final output sent to browser
DEBUG - 2016-11-23 18:55:13 --> Total execution time: 0.2872
INFO - 2016-11-23 18:55:27 --> Config Class Initialized
INFO - 2016-11-23 18:55:27 --> Hooks Class Initialized
DEBUG - 2016-11-23 18:55:27 --> UTF-8 Support Enabled
INFO - 2016-11-23 18:55:27 --> Utf8 Class Initialized
INFO - 2016-11-23 18:55:27 --> URI Class Initialized
DEBUG - 2016-11-23 18:55:27 --> No URI present. Default controller set.
INFO - 2016-11-23 18:55:27 --> Router Class Initialized
INFO - 2016-11-23 18:55:27 --> Output Class Initialized
INFO - 2016-11-23 18:55:27 --> Security Class Initialized
DEBUG - 2016-11-23 18:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 18:55:27 --> Input Class Initialized
INFO - 2016-11-23 18:55:27 --> Language Class Initialized
INFO - 2016-11-23 18:55:27 --> Loader Class Initialized
INFO - 2016-11-23 18:55:27 --> Helper loaded: url_helper
INFO - 2016-11-23 18:55:27 --> Helper loaded: form_helper
INFO - 2016-11-23 18:55:27 --> Database Driver Class Initialized
INFO - 2016-11-23 18:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 18:55:27 --> Controller Class Initialized
INFO - 2016-11-23 18:55:27 --> Model Class Initialized
INFO - 2016-11-23 18:55:27 --> Model Class Initialized
INFO - 2016-11-23 18:55:27 --> Model Class Initialized
INFO - 2016-11-23 18:55:27 --> Model Class Initialized
INFO - 2016-11-23 18:55:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 18:55:27 --> Pagination Class Initialized
INFO - 2016-11-23 18:55:27 --> Helper loaded: app_helper
INFO - 2016-11-23 18:55:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 18:55:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-23 18:55:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-23 18:55:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-23 18:55:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 18:55:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-23 18:55:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-23 18:55:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-23 18:55:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-23 18:55:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-23 18:55:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-23 18:55:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 18:55:28 --> Final output sent to browser
DEBUG - 2016-11-23 18:55:28 --> Total execution time: 0.4844
INFO - 2016-11-23 18:55:31 --> Config Class Initialized
INFO - 2016-11-23 18:55:31 --> Hooks Class Initialized
DEBUG - 2016-11-23 18:55:31 --> UTF-8 Support Enabled
INFO - 2016-11-23 18:55:31 --> Utf8 Class Initialized
INFO - 2016-11-23 18:55:31 --> URI Class Initialized
INFO - 2016-11-23 18:55:31 --> Router Class Initialized
INFO - 2016-11-23 18:55:31 --> Output Class Initialized
INFO - 2016-11-23 18:55:31 --> Security Class Initialized
DEBUG - 2016-11-23 18:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 18:55:31 --> Input Class Initialized
INFO - 2016-11-23 18:55:31 --> Language Class Initialized
INFO - 2016-11-23 18:55:31 --> Loader Class Initialized
INFO - 2016-11-23 18:55:31 --> Helper loaded: url_helper
INFO - 2016-11-23 18:55:31 --> Helper loaded: form_helper
INFO - 2016-11-23 18:55:31 --> Database Driver Class Initialized
INFO - 2016-11-23 18:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 18:55:31 --> Controller Class Initialized
INFO - 2016-11-23 18:55:31 --> Model Class Initialized
INFO - 2016-11-23 18:55:31 --> Form Validation Class Initialized
INFO - 2016-11-23 18:55:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-23 18:55:31 --> Final output sent to browser
DEBUG - 2016-11-23 18:55:31 --> Total execution time: 0.2425
INFO - 2016-11-23 18:55:39 --> Config Class Initialized
INFO - 2016-11-23 18:55:39 --> Hooks Class Initialized
DEBUG - 2016-11-23 18:55:39 --> UTF-8 Support Enabled
INFO - 2016-11-23 18:55:39 --> Utf8 Class Initialized
INFO - 2016-11-23 18:55:39 --> URI Class Initialized
INFO - 2016-11-23 18:55:39 --> Router Class Initialized
INFO - 2016-11-23 18:55:39 --> Output Class Initialized
INFO - 2016-11-23 18:55:39 --> Security Class Initialized
DEBUG - 2016-11-23 18:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 18:55:39 --> Input Class Initialized
INFO - 2016-11-23 18:55:39 --> Language Class Initialized
INFO - 2016-11-23 18:55:39 --> Loader Class Initialized
INFO - 2016-11-23 18:55:39 --> Helper loaded: url_helper
INFO - 2016-11-23 18:55:39 --> Helper loaded: form_helper
INFO - 2016-11-23 18:55:39 --> Database Driver Class Initialized
INFO - 2016-11-23 18:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 18:55:39 --> Controller Class Initialized
INFO - 2016-11-23 18:55:39 --> Model Class Initialized
INFO - 2016-11-23 18:55:39 --> Model Class Initialized
INFO - 2016-11-23 18:55:39 --> Model Class Initialized
INFO - 2016-11-23 18:55:39 --> Model Class Initialized
INFO - 2016-11-23 18:55:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 18:55:39 --> Pagination Class Initialized
INFO - 2016-11-23 18:55:39 --> Helper loaded: app_helper
DEBUG - 2016-11-23 18:55:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-23 18:55:39 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-23 18:55:39 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-23 18:55:39 --> Config Class Initialized
INFO - 2016-11-23 18:55:39 --> Hooks Class Initialized
DEBUG - 2016-11-23 18:55:39 --> UTF-8 Support Enabled
INFO - 2016-11-23 18:55:39 --> Utf8 Class Initialized
INFO - 2016-11-23 18:55:39 --> URI Class Initialized
DEBUG - 2016-11-23 18:55:39 --> No URI present. Default controller set.
INFO - 2016-11-23 18:55:39 --> Router Class Initialized
INFO - 2016-11-23 18:55:39 --> Output Class Initialized
INFO - 2016-11-23 18:55:39 --> Security Class Initialized
DEBUG - 2016-11-23 18:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 18:55:39 --> Input Class Initialized
INFO - 2016-11-23 18:55:39 --> Language Class Initialized
INFO - 2016-11-23 18:55:39 --> Loader Class Initialized
INFO - 2016-11-23 18:55:39 --> Helper loaded: url_helper
INFO - 2016-11-23 18:55:39 --> Helper loaded: form_helper
INFO - 2016-11-23 18:55:39 --> Database Driver Class Initialized
INFO - 2016-11-23 18:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 18:55:39 --> Controller Class Initialized
INFO - 2016-11-23 18:55:39 --> Model Class Initialized
INFO - 2016-11-23 18:55:39 --> Model Class Initialized
INFO - 2016-11-23 18:55:39 --> Model Class Initialized
INFO - 2016-11-23 18:55:39 --> Model Class Initialized
INFO - 2016-11-23 18:55:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 18:55:39 --> Pagination Class Initialized
INFO - 2016-11-23 18:55:39 --> Helper loaded: app_helper
INFO - 2016-11-23 18:55:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 18:55:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-23 18:55:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 18:55:40 --> Final output sent to browser
DEBUG - 2016-11-23 18:55:40 --> Total execution time: 0.4581
INFO - 2016-11-23 21:13:11 --> Config Class Initialized
INFO - 2016-11-23 21:13:11 --> Hooks Class Initialized
DEBUG - 2016-11-23 21:13:11 --> UTF-8 Support Enabled
INFO - 2016-11-23 21:13:11 --> Utf8 Class Initialized
INFO - 2016-11-23 21:13:11 --> URI Class Initialized
DEBUG - 2016-11-23 21:13:11 --> No URI present. Default controller set.
INFO - 2016-11-23 21:13:11 --> Router Class Initialized
INFO - 2016-11-23 21:13:11 --> Output Class Initialized
INFO - 2016-11-23 21:13:11 --> Security Class Initialized
DEBUG - 2016-11-23 21:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 21:13:11 --> Input Class Initialized
INFO - 2016-11-23 21:13:11 --> Language Class Initialized
INFO - 2016-11-23 21:13:11 --> Loader Class Initialized
INFO - 2016-11-23 21:13:11 --> Helper loaded: url_helper
INFO - 2016-11-23 21:13:11 --> Helper loaded: form_helper
INFO - 2016-11-23 21:13:11 --> Database Driver Class Initialized
INFO - 2016-11-23 21:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 21:13:11 --> Controller Class Initialized
INFO - 2016-11-23 21:13:11 --> Model Class Initialized
INFO - 2016-11-23 21:13:11 --> Model Class Initialized
INFO - 2016-11-23 21:13:11 --> Model Class Initialized
INFO - 2016-11-23 21:13:11 --> Model Class Initialized
INFO - 2016-11-23 21:13:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 21:13:11 --> Pagination Class Initialized
INFO - 2016-11-23 21:13:11 --> Helper loaded: app_helper
INFO - 2016-11-23 21:13:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 21:13:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-23 21:13:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 21:13:12 --> Final output sent to browser
DEBUG - 2016-11-23 21:13:12 --> Total execution time: 0.5638
INFO - 2016-11-23 21:13:22 --> Config Class Initialized
INFO - 2016-11-23 21:13:22 --> Hooks Class Initialized
DEBUG - 2016-11-23 21:13:22 --> UTF-8 Support Enabled
INFO - 2016-11-23 21:13:22 --> Utf8 Class Initialized
INFO - 2016-11-23 21:13:22 --> URI Class Initialized
INFO - 2016-11-23 21:13:22 --> Router Class Initialized
INFO - 2016-11-23 21:13:22 --> Output Class Initialized
INFO - 2016-11-23 21:13:22 --> Security Class Initialized
DEBUG - 2016-11-23 21:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 21:13:22 --> Input Class Initialized
INFO - 2016-11-23 21:13:22 --> Language Class Initialized
INFO - 2016-11-23 21:13:22 --> Loader Class Initialized
INFO - 2016-11-23 21:13:22 --> Helper loaded: url_helper
INFO - 2016-11-23 21:13:22 --> Helper loaded: form_helper
INFO - 2016-11-23 21:13:22 --> Database Driver Class Initialized
INFO - 2016-11-23 21:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 21:13:22 --> Controller Class Initialized
INFO - 2016-11-23 21:13:22 --> Model Class Initialized
INFO - 2016-11-23 21:13:22 --> Model Class Initialized
INFO - 2016-11-23 21:13:22 --> Model Class Initialized
INFO - 2016-11-23 21:13:22 --> Model Class Initialized
INFO - 2016-11-23 21:13:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 21:13:22 --> Pagination Class Initialized
INFO - 2016-11-23 21:13:22 --> Helper loaded: app_helper
DEBUG - 2016-11-23 21:13:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-23 21:13:22 --> Model Class Initialized
INFO - 2016-11-23 21:13:22 --> Final output sent to browser
DEBUG - 2016-11-23 21:13:22 --> Total execution time: 0.3047
INFO - 2016-11-23 21:13:22 --> Config Class Initialized
INFO - 2016-11-23 21:13:22 --> Hooks Class Initialized
DEBUG - 2016-11-23 21:13:22 --> UTF-8 Support Enabled
INFO - 2016-11-23 21:13:22 --> Utf8 Class Initialized
INFO - 2016-11-23 21:13:22 --> URI Class Initialized
DEBUG - 2016-11-23 21:13:22 --> No URI present. Default controller set.
INFO - 2016-11-23 21:13:22 --> Router Class Initialized
INFO - 2016-11-23 21:13:22 --> Output Class Initialized
INFO - 2016-11-23 21:13:22 --> Security Class Initialized
DEBUG - 2016-11-23 21:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 21:13:22 --> Input Class Initialized
INFO - 2016-11-23 21:13:22 --> Language Class Initialized
INFO - 2016-11-23 21:13:22 --> Loader Class Initialized
INFO - 2016-11-23 21:13:22 --> Helper loaded: url_helper
INFO - 2016-11-23 21:13:22 --> Helper loaded: form_helper
INFO - 2016-11-23 21:13:22 --> Database Driver Class Initialized
INFO - 2016-11-23 21:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 21:13:22 --> Controller Class Initialized
INFO - 2016-11-23 21:13:22 --> Model Class Initialized
INFO - 2016-11-23 21:13:22 --> Model Class Initialized
INFO - 2016-11-23 21:13:22 --> Model Class Initialized
INFO - 2016-11-23 21:13:22 --> Model Class Initialized
INFO - 2016-11-23 21:13:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 21:13:22 --> Pagination Class Initialized
INFO - 2016-11-23 21:13:22 --> Helper loaded: app_helper
INFO - 2016-11-23 21:13:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 21:13:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-23 21:13:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-23 21:13:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-23 21:13:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 21:13:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-23 21:13:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-23 21:13:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-23 21:13:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-23 21:13:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-23 21:13:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-23 21:13:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 21:13:23 --> Final output sent to browser
DEBUG - 2016-11-23 21:13:23 --> Total execution time: 0.4797
INFO - 2016-11-23 21:39:21 --> Config Class Initialized
INFO - 2016-11-23 21:39:21 --> Hooks Class Initialized
DEBUG - 2016-11-23 21:39:21 --> UTF-8 Support Enabled
INFO - 2016-11-23 21:39:21 --> Utf8 Class Initialized
INFO - 2016-11-23 21:39:21 --> URI Class Initialized
DEBUG - 2016-11-23 21:39:21 --> No URI present. Default controller set.
INFO - 2016-11-23 21:39:21 --> Router Class Initialized
INFO - 2016-11-23 21:39:21 --> Output Class Initialized
INFO - 2016-11-23 21:39:21 --> Security Class Initialized
DEBUG - 2016-11-23 21:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 21:39:21 --> Input Class Initialized
INFO - 2016-11-23 21:39:21 --> Language Class Initialized
INFO - 2016-11-23 21:39:21 --> Loader Class Initialized
INFO - 2016-11-23 21:39:21 --> Helper loaded: url_helper
INFO - 2016-11-23 21:39:21 --> Helper loaded: form_helper
INFO - 2016-11-23 21:39:22 --> Database Driver Class Initialized
INFO - 2016-11-23 21:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 21:39:22 --> Controller Class Initialized
INFO - 2016-11-23 21:39:22 --> Model Class Initialized
INFO - 2016-11-23 21:39:22 --> Model Class Initialized
INFO - 2016-11-23 21:39:22 --> Model Class Initialized
INFO - 2016-11-23 21:39:22 --> Model Class Initialized
INFO - 2016-11-23 21:39:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 21:39:22 --> Pagination Class Initialized
INFO - 2016-11-23 21:39:22 --> Helper loaded: app_helper
INFO - 2016-11-23 21:39:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 21:39:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-23 21:39:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-23 21:39:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-23 21:39:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 21:39:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-23 21:39:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-23 21:39:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-23 21:39:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-23 21:39:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-23 21:39:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-23 21:39:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 21:39:23 --> Config Class Initialized
INFO - 2016-11-23 21:39:23 --> Final output sent to browser
DEBUG - 2016-11-23 21:39:23 --> Total execution time: 2.1174
INFO - 2016-11-23 21:39:23 --> Hooks Class Initialized
DEBUG - 2016-11-23 21:39:23 --> UTF-8 Support Enabled
INFO - 2016-11-23 21:39:23 --> Utf8 Class Initialized
INFO - 2016-11-23 21:39:23 --> URI Class Initialized
DEBUG - 2016-11-23 21:39:23 --> No URI present. Default controller set.
INFO - 2016-11-23 21:39:23 --> Router Class Initialized
INFO - 2016-11-23 21:39:23 --> Output Class Initialized
INFO - 2016-11-23 21:39:23 --> Security Class Initialized
DEBUG - 2016-11-23 21:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 21:39:23 --> Input Class Initialized
INFO - 2016-11-23 21:39:23 --> Language Class Initialized
INFO - 2016-11-23 21:39:23 --> Loader Class Initialized
INFO - 2016-11-23 21:39:23 --> Helper loaded: url_helper
INFO - 2016-11-23 21:39:23 --> Helper loaded: form_helper
INFO - 2016-11-23 21:39:23 --> Database Driver Class Initialized
INFO - 2016-11-23 21:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 21:39:23 --> Controller Class Initialized
INFO - 2016-11-23 21:39:23 --> Model Class Initialized
INFO - 2016-11-23 21:39:23 --> Model Class Initialized
INFO - 2016-11-23 21:39:23 --> Model Class Initialized
INFO - 2016-11-23 21:39:23 --> Model Class Initialized
INFO - 2016-11-23 21:39:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 21:39:23 --> Pagination Class Initialized
INFO - 2016-11-23 21:39:23 --> Helper loaded: app_helper
INFO - 2016-11-23 21:39:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 21:39:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-23 21:39:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-23 21:39:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-23 21:39:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-23 21:39:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-23 21:39:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-23 21:39:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-23 21:39:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-23 21:39:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-23 21:39:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-23 21:39:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 21:39:23 --> Final output sent to browser
DEBUG - 2016-11-23 21:39:23 --> Total execution time: 0.5748
INFO - 2016-11-23 21:57:25 --> Config Class Initialized
INFO - 2016-11-23 21:57:25 --> Hooks Class Initialized
DEBUG - 2016-11-23 21:57:25 --> UTF-8 Support Enabled
INFO - 2016-11-23 21:57:25 --> Utf8 Class Initialized
INFO - 2016-11-23 21:57:25 --> URI Class Initialized
INFO - 2016-11-23 21:57:25 --> Router Class Initialized
INFO - 2016-11-23 21:57:25 --> Output Class Initialized
INFO - 2016-11-23 21:57:25 --> Security Class Initialized
DEBUG - 2016-11-23 21:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 21:57:25 --> Input Class Initialized
INFO - 2016-11-23 21:57:25 --> Language Class Initialized
INFO - 2016-11-23 21:57:25 --> Loader Class Initialized
INFO - 2016-11-23 21:57:25 --> Helper loaded: url_helper
INFO - 2016-11-23 21:57:25 --> Helper loaded: form_helper
INFO - 2016-11-23 21:57:26 --> Database Driver Class Initialized
INFO - 2016-11-23 21:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 21:57:26 --> Controller Class Initialized
INFO - 2016-11-23 21:57:26 --> Model Class Initialized
INFO - 2016-11-23 21:57:26 --> Model Class Initialized
INFO - 2016-11-23 21:57:26 --> Model Class Initialized
INFO - 2016-11-23 21:57:26 --> Model Class Initialized
INFO - 2016-11-23 21:57:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 21:57:26 --> Pagination Class Initialized
INFO - 2016-11-23 21:57:26 --> Helper loaded: app_helper
DEBUG - 2016-11-23 21:57:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-23 21:57:26 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-23 21:57:26 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-23 21:57:26 --> Config Class Initialized
INFO - 2016-11-23 21:57:26 --> Hooks Class Initialized
DEBUG - 2016-11-23 21:57:26 --> UTF-8 Support Enabled
INFO - 2016-11-23 21:57:26 --> Utf8 Class Initialized
INFO - 2016-11-23 21:57:26 --> URI Class Initialized
DEBUG - 2016-11-23 21:57:26 --> No URI present. Default controller set.
INFO - 2016-11-23 21:57:26 --> Router Class Initialized
INFO - 2016-11-23 21:57:26 --> Output Class Initialized
INFO - 2016-11-23 21:57:26 --> Security Class Initialized
DEBUG - 2016-11-23 21:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-23 21:57:26 --> Input Class Initialized
INFO - 2016-11-23 21:57:26 --> Language Class Initialized
INFO - 2016-11-23 21:57:26 --> Loader Class Initialized
INFO - 2016-11-23 21:57:26 --> Helper loaded: url_helper
INFO - 2016-11-23 21:57:26 --> Helper loaded: form_helper
INFO - 2016-11-23 21:57:26 --> Database Driver Class Initialized
INFO - 2016-11-23 21:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-23 21:57:26 --> Controller Class Initialized
INFO - 2016-11-23 21:57:26 --> Model Class Initialized
INFO - 2016-11-23 21:57:26 --> Model Class Initialized
INFO - 2016-11-23 21:57:26 --> Model Class Initialized
INFO - 2016-11-23 21:57:26 --> Model Class Initialized
INFO - 2016-11-23 21:57:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-23 21:57:26 --> Pagination Class Initialized
INFO - 2016-11-23 21:57:26 --> Helper loaded: app_helper
INFO - 2016-11-23 21:57:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-23 21:57:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-23 21:57:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-23 21:57:26 --> Final output sent to browser
DEBUG - 2016-11-23 21:57:26 --> Total execution time: 0.3733
