<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-26 11:43:34 --> Config Class Initialized
INFO - 2016-10-26 11:43:34 --> Hooks Class Initialized
DEBUG - 2016-10-26 11:43:34 --> UTF-8 Support Enabled
INFO - 2016-10-26 11:43:34 --> Utf8 Class Initialized
INFO - 2016-10-26 11:43:34 --> URI Class Initialized
DEBUG - 2016-10-26 11:43:34 --> No URI present. Default controller set.
INFO - 2016-10-26 11:43:34 --> Router Class Initialized
INFO - 2016-10-26 11:43:34 --> Output Class Initialized
INFO - 2016-10-26 11:43:34 --> Security Class Initialized
DEBUG - 2016-10-26 11:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 11:43:34 --> Input Class Initialized
INFO - 2016-10-26 11:43:34 --> Language Class Initialized
INFO - 2016-10-26 11:43:34 --> Loader Class Initialized
INFO - 2016-10-26 11:43:34 --> Helper loaded: url_helper
INFO - 2016-10-26 11:43:34 --> Helper loaded: form_helper
INFO - 2016-10-26 11:43:34 --> Database Driver Class Initialized
INFO - 2016-10-26 11:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 11:43:34 --> Controller Class Initialized
INFO - 2016-10-26 11:43:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 11:43:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 11:43:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 11:43:34 --> Final output sent to browser
DEBUG - 2016-10-26 11:43:34 --> Total execution time: 0.1664
INFO - 2016-10-26 11:43:36 --> Config Class Initialized
INFO - 2016-10-26 11:43:36 --> Hooks Class Initialized
DEBUG - 2016-10-26 11:43:36 --> UTF-8 Support Enabled
INFO - 2016-10-26 11:43:36 --> Utf8 Class Initialized
INFO - 2016-10-26 11:43:36 --> URI Class Initialized
DEBUG - 2016-10-26 11:43:36 --> No URI present. Default controller set.
INFO - 2016-10-26 11:43:36 --> Router Class Initialized
INFO - 2016-10-26 11:43:36 --> Output Class Initialized
INFO - 2016-10-26 11:43:36 --> Security Class Initialized
DEBUG - 2016-10-26 11:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 11:43:36 --> Input Class Initialized
INFO - 2016-10-26 11:43:36 --> Language Class Initialized
INFO - 2016-10-26 11:43:36 --> Loader Class Initialized
INFO - 2016-10-26 11:43:36 --> Helper loaded: url_helper
INFO - 2016-10-26 11:43:36 --> Helper loaded: form_helper
INFO - 2016-10-26 11:43:36 --> Database Driver Class Initialized
INFO - 2016-10-26 11:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 11:43:36 --> Controller Class Initialized
INFO - 2016-10-26 11:43:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 11:43:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 11:43:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 11:43:36 --> Final output sent to browser
DEBUG - 2016-10-26 11:43:36 --> Total execution time: 0.0178
INFO - 2016-10-26 11:46:32 --> Config Class Initialized
INFO - 2016-10-26 11:46:32 --> Hooks Class Initialized
DEBUG - 2016-10-26 11:46:32 --> UTF-8 Support Enabled
INFO - 2016-10-26 11:46:32 --> Utf8 Class Initialized
INFO - 2016-10-26 11:46:32 --> URI Class Initialized
DEBUG - 2016-10-26 11:46:32 --> No URI present. Default controller set.
INFO - 2016-10-26 11:46:32 --> Router Class Initialized
INFO - 2016-10-26 11:46:32 --> Output Class Initialized
INFO - 2016-10-26 11:46:32 --> Security Class Initialized
DEBUG - 2016-10-26 11:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 11:46:32 --> Input Class Initialized
INFO - 2016-10-26 11:46:32 --> Language Class Initialized
INFO - 2016-10-26 11:46:32 --> Loader Class Initialized
INFO - 2016-10-26 11:46:32 --> Helper loaded: url_helper
INFO - 2016-10-26 11:46:32 --> Helper loaded: form_helper
INFO - 2016-10-26 11:46:32 --> Database Driver Class Initialized
INFO - 2016-10-26 11:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 11:46:32 --> Controller Class Initialized
INFO - 2016-10-26 11:46:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 11:46:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 11:46:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 11:46:32 --> Final output sent to browser
DEBUG - 2016-10-26 11:46:32 --> Total execution time: 0.0199
INFO - 2016-10-26 11:51:14 --> Config Class Initialized
INFO - 2016-10-26 11:51:14 --> Hooks Class Initialized
DEBUG - 2016-10-26 11:51:14 --> UTF-8 Support Enabled
INFO - 2016-10-26 11:51:14 --> Utf8 Class Initialized
INFO - 2016-10-26 11:51:14 --> URI Class Initialized
INFO - 2016-10-26 11:51:14 --> Router Class Initialized
INFO - 2016-10-26 11:51:14 --> Output Class Initialized
INFO - 2016-10-26 11:51:14 --> Security Class Initialized
DEBUG - 2016-10-26 11:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 11:51:14 --> Input Class Initialized
INFO - 2016-10-26 11:51:14 --> Language Class Initialized
INFO - 2016-10-26 11:51:14 --> Loader Class Initialized
INFO - 2016-10-26 11:51:14 --> Helper loaded: url_helper
INFO - 2016-10-26 11:51:14 --> Helper loaded: form_helper
INFO - 2016-10-26 11:51:14 --> Database Driver Class Initialized
INFO - 2016-10-26 11:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 11:51:14 --> Controller Class Initialized
DEBUG - 2016-10-26 11:51:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-26 11:51:14 --> Model Class Initialized
INFO - 2016-10-26 11:51:14 --> Final output sent to browser
DEBUG - 2016-10-26 11:51:14 --> Total execution time: 0.0317
INFO - 2016-10-26 11:51:14 --> Config Class Initialized
INFO - 2016-10-26 11:51:14 --> Hooks Class Initialized
DEBUG - 2016-10-26 11:51:14 --> UTF-8 Support Enabled
INFO - 2016-10-26 11:51:14 --> Utf8 Class Initialized
INFO - 2016-10-26 11:51:14 --> URI Class Initialized
DEBUG - 2016-10-26 11:51:14 --> No URI present. Default controller set.
INFO - 2016-10-26 11:51:14 --> Router Class Initialized
INFO - 2016-10-26 11:51:14 --> Output Class Initialized
INFO - 2016-10-26 11:51:14 --> Security Class Initialized
DEBUG - 2016-10-26 11:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 11:51:14 --> Input Class Initialized
INFO - 2016-10-26 11:51:14 --> Language Class Initialized
INFO - 2016-10-26 11:51:14 --> Loader Class Initialized
INFO - 2016-10-26 11:51:14 --> Helper loaded: url_helper
INFO - 2016-10-26 11:51:14 --> Helper loaded: form_helper
INFO - 2016-10-26 11:51:14 --> Database Driver Class Initialized
INFO - 2016-10-26 11:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 11:51:14 --> Controller Class Initialized
INFO - 2016-10-26 11:51:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 11:51:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 11:51:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 11:51:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 11:51:14 --> Final output sent to browser
DEBUG - 2016-10-26 11:51:14 --> Total execution time: 0.0311
INFO - 2016-10-26 11:55:10 --> Config Class Initialized
INFO - 2016-10-26 11:55:10 --> Hooks Class Initialized
DEBUG - 2016-10-26 11:55:10 --> UTF-8 Support Enabled
INFO - 2016-10-26 11:55:10 --> Utf8 Class Initialized
INFO - 2016-10-26 11:55:10 --> URI Class Initialized
DEBUG - 2016-10-26 11:55:10 --> No URI present. Default controller set.
INFO - 2016-10-26 11:55:10 --> Router Class Initialized
INFO - 2016-10-26 11:55:10 --> Output Class Initialized
INFO - 2016-10-26 11:55:10 --> Security Class Initialized
DEBUG - 2016-10-26 11:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 11:55:10 --> Input Class Initialized
INFO - 2016-10-26 11:55:10 --> Language Class Initialized
INFO - 2016-10-26 11:55:10 --> Loader Class Initialized
INFO - 2016-10-26 11:55:10 --> Helper loaded: url_helper
INFO - 2016-10-26 11:55:10 --> Helper loaded: form_helper
INFO - 2016-10-26 11:55:10 --> Database Driver Class Initialized
INFO - 2016-10-26 11:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 11:55:10 --> Controller Class Initialized
INFO - 2016-10-26 11:55:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 11:55:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 11:55:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/apple_leave.php
INFO - 2016-10-26 11:55:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 11:55:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 11:55:10 --> Final output sent to browser
DEBUG - 2016-10-26 11:55:10 --> Total execution time: 0.0189
INFO - 2016-10-26 11:56:23 --> Config Class Initialized
INFO - 2016-10-26 11:56:23 --> Hooks Class Initialized
DEBUG - 2016-10-26 11:56:23 --> UTF-8 Support Enabled
INFO - 2016-10-26 11:56:23 --> Utf8 Class Initialized
INFO - 2016-10-26 11:56:23 --> URI Class Initialized
DEBUG - 2016-10-26 11:56:23 --> No URI present. Default controller set.
INFO - 2016-10-26 11:56:23 --> Router Class Initialized
INFO - 2016-10-26 11:56:23 --> Output Class Initialized
INFO - 2016-10-26 11:56:23 --> Security Class Initialized
DEBUG - 2016-10-26 11:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 11:56:23 --> Input Class Initialized
INFO - 2016-10-26 11:56:23 --> Language Class Initialized
INFO - 2016-10-26 11:56:23 --> Loader Class Initialized
INFO - 2016-10-26 11:56:23 --> Helper loaded: url_helper
INFO - 2016-10-26 11:56:23 --> Helper loaded: form_helper
INFO - 2016-10-26 11:56:23 --> Database Driver Class Initialized
INFO - 2016-10-26 11:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 11:56:23 --> Controller Class Initialized
INFO - 2016-10-26 11:56:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 11:56:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 11:56:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/apple_leave.php
ERROR - 2016-10-26 11:56:23 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 56
INFO - 2016-10-26 11:56:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 11:56:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 11:56:23 --> Final output sent to browser
DEBUG - 2016-10-26 11:56:23 --> Total execution time: 0.0403
INFO - 2016-10-26 11:56:56 --> Config Class Initialized
INFO - 2016-10-26 11:56:56 --> Hooks Class Initialized
DEBUG - 2016-10-26 11:56:56 --> UTF-8 Support Enabled
INFO - 2016-10-26 11:56:56 --> Utf8 Class Initialized
INFO - 2016-10-26 11:56:56 --> URI Class Initialized
DEBUG - 2016-10-26 11:56:56 --> No URI present. Default controller set.
INFO - 2016-10-26 11:56:56 --> Router Class Initialized
INFO - 2016-10-26 11:56:56 --> Output Class Initialized
INFO - 2016-10-26 11:56:56 --> Security Class Initialized
DEBUG - 2016-10-26 11:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 11:56:56 --> Input Class Initialized
INFO - 2016-10-26 11:56:56 --> Language Class Initialized
INFO - 2016-10-26 11:56:56 --> Loader Class Initialized
INFO - 2016-10-26 11:56:56 --> Helper loaded: url_helper
INFO - 2016-10-26 11:56:56 --> Helper loaded: form_helper
INFO - 2016-10-26 11:56:56 --> Database Driver Class Initialized
INFO - 2016-10-26 11:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 11:56:56 --> Controller Class Initialized
INFO - 2016-10-26 11:56:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 11:56:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 11:56:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/apple_leave.php
INFO - 2016-10-26 11:56:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 11:56:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 11:56:56 --> Final output sent to browser
DEBUG - 2016-10-26 11:56:56 --> Total execution time: 0.0184
INFO - 2016-10-26 11:57:43 --> Config Class Initialized
INFO - 2016-10-26 11:57:43 --> Hooks Class Initialized
DEBUG - 2016-10-26 11:57:43 --> UTF-8 Support Enabled
INFO - 2016-10-26 11:57:43 --> Utf8 Class Initialized
INFO - 2016-10-26 11:57:43 --> URI Class Initialized
DEBUG - 2016-10-26 11:57:43 --> No URI present. Default controller set.
INFO - 2016-10-26 11:57:43 --> Router Class Initialized
INFO - 2016-10-26 11:57:43 --> Output Class Initialized
INFO - 2016-10-26 11:57:43 --> Security Class Initialized
DEBUG - 2016-10-26 11:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 11:57:43 --> Input Class Initialized
INFO - 2016-10-26 11:57:43 --> Language Class Initialized
INFO - 2016-10-26 11:57:43 --> Loader Class Initialized
INFO - 2016-10-26 11:57:43 --> Helper loaded: url_helper
INFO - 2016-10-26 11:57:43 --> Helper loaded: form_helper
INFO - 2016-10-26 11:57:43 --> Database Driver Class Initialized
INFO - 2016-10-26 11:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 11:57:43 --> Controller Class Initialized
INFO - 2016-10-26 11:57:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 11:57:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 11:57:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/apple_leave.php
INFO - 2016-10-26 11:57:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 11:57:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 11:57:43 --> Final output sent to browser
DEBUG - 2016-10-26 11:57:43 --> Total execution time: 0.0181
INFO - 2016-10-26 12:03:36 --> Config Class Initialized
INFO - 2016-10-26 12:03:36 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:03:36 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:03:36 --> Utf8 Class Initialized
INFO - 2016-10-26 12:03:36 --> URI Class Initialized
INFO - 2016-10-26 12:03:36 --> Router Class Initialized
INFO - 2016-10-26 12:03:36 --> Output Class Initialized
INFO - 2016-10-26 12:03:36 --> Security Class Initialized
DEBUG - 2016-10-26 12:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:03:36 --> Input Class Initialized
INFO - 2016-10-26 12:03:36 --> Language Class Initialized
INFO - 2016-10-26 12:03:36 --> Loader Class Initialized
INFO - 2016-10-26 12:03:36 --> Helper loaded: url_helper
INFO - 2016-10-26 12:03:36 --> Helper loaded: form_helper
INFO - 2016-10-26 12:03:36 --> Database Driver Class Initialized
INFO - 2016-10-26 12:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:03:36 --> Controller Class Initialized
DEBUG - 2016-10-26 12:03:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-26 12:03:36 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 141
ERROR - 2016-10-26 12:03:36 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 141
INFO - 2016-10-26 12:03:36 --> Config Class Initialized
INFO - 2016-10-26 12:03:36 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:03:36 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:03:36 --> Utf8 Class Initialized
INFO - 2016-10-26 12:03:36 --> URI Class Initialized
DEBUG - 2016-10-26 12:03:36 --> No URI present. Default controller set.
INFO - 2016-10-26 12:03:36 --> Router Class Initialized
INFO - 2016-10-26 12:03:36 --> Output Class Initialized
INFO - 2016-10-26 12:03:36 --> Security Class Initialized
DEBUG - 2016-10-26 12:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:03:36 --> Input Class Initialized
INFO - 2016-10-26 12:03:36 --> Language Class Initialized
INFO - 2016-10-26 12:03:36 --> Loader Class Initialized
INFO - 2016-10-26 12:03:36 --> Helper loaded: url_helper
INFO - 2016-10-26 12:03:36 --> Helper loaded: form_helper
INFO - 2016-10-26 12:03:36 --> Database Driver Class Initialized
INFO - 2016-10-26 12:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:03:36 --> Controller Class Initialized
INFO - 2016-10-26 12:03:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:03:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 12:03:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:03:36 --> Final output sent to browser
DEBUG - 2016-10-26 12:03:36 --> Total execution time: 0.0157
INFO - 2016-10-26 12:03:47 --> Config Class Initialized
INFO - 2016-10-26 12:03:47 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:03:47 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:03:47 --> Utf8 Class Initialized
INFO - 2016-10-26 12:03:47 --> URI Class Initialized
INFO - 2016-10-26 12:03:47 --> Router Class Initialized
INFO - 2016-10-26 12:03:47 --> Output Class Initialized
INFO - 2016-10-26 12:03:47 --> Security Class Initialized
DEBUG - 2016-10-26 12:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:03:47 --> Input Class Initialized
INFO - 2016-10-26 12:03:47 --> Language Class Initialized
INFO - 2016-10-26 12:03:47 --> Loader Class Initialized
INFO - 2016-10-26 12:03:47 --> Helper loaded: url_helper
INFO - 2016-10-26 12:03:47 --> Helper loaded: form_helper
INFO - 2016-10-26 12:03:47 --> Database Driver Class Initialized
INFO - 2016-10-26 12:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:03:47 --> Controller Class Initialized
DEBUG - 2016-10-26 12:03:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-26 12:03:47 --> Model Class Initialized
INFO - 2016-10-26 12:03:47 --> Final output sent to browser
DEBUG - 2016-10-26 12:03:47 --> Total execution time: 0.0210
INFO - 2016-10-26 12:03:47 --> Config Class Initialized
INFO - 2016-10-26 12:03:47 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:03:47 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:03:47 --> Utf8 Class Initialized
INFO - 2016-10-26 12:03:47 --> URI Class Initialized
DEBUG - 2016-10-26 12:03:47 --> No URI present. Default controller set.
INFO - 2016-10-26 12:03:47 --> Router Class Initialized
INFO - 2016-10-26 12:03:47 --> Output Class Initialized
INFO - 2016-10-26 12:03:47 --> Security Class Initialized
DEBUG - 2016-10-26 12:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:03:47 --> Input Class Initialized
INFO - 2016-10-26 12:03:47 --> Language Class Initialized
INFO - 2016-10-26 12:03:47 --> Loader Class Initialized
INFO - 2016-10-26 12:03:47 --> Helper loaded: url_helper
INFO - 2016-10-26 12:03:47 --> Helper loaded: form_helper
INFO - 2016-10-26 12:03:47 --> Database Driver Class Initialized
INFO - 2016-10-26 12:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:03:47 --> Controller Class Initialized
INFO - 2016-10-26 12:03:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:03:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 12:03:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/apple_leave.php
INFO - 2016-10-26 12:03:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 12:03:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:03:47 --> Final output sent to browser
DEBUG - 2016-10-26 12:03:47 --> Total execution time: 0.0159
INFO - 2016-10-26 12:05:13 --> Config Class Initialized
INFO - 2016-10-26 12:05:13 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:05:13 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:05:13 --> Utf8 Class Initialized
INFO - 2016-10-26 12:05:13 --> URI Class Initialized
INFO - 2016-10-26 12:05:13 --> Router Class Initialized
INFO - 2016-10-26 12:05:13 --> Output Class Initialized
INFO - 2016-10-26 12:05:13 --> Security Class Initialized
DEBUG - 2016-10-26 12:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:05:13 --> Input Class Initialized
INFO - 2016-10-26 12:05:13 --> Language Class Initialized
INFO - 2016-10-26 12:05:13 --> Loader Class Initialized
INFO - 2016-10-26 12:05:13 --> Helper loaded: url_helper
INFO - 2016-10-26 12:05:13 --> Helper loaded: form_helper
INFO - 2016-10-26 12:05:13 --> Database Driver Class Initialized
INFO - 2016-10-26 12:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:05:13 --> Controller Class Initialized
DEBUG - 2016-10-26 12:05:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-26 12:05:13 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 141
ERROR - 2016-10-26 12:05:13 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 141
INFO - 2016-10-26 12:05:13 --> Config Class Initialized
INFO - 2016-10-26 12:05:13 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:05:13 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:05:13 --> Utf8 Class Initialized
INFO - 2016-10-26 12:05:13 --> URI Class Initialized
DEBUG - 2016-10-26 12:05:13 --> No URI present. Default controller set.
INFO - 2016-10-26 12:05:13 --> Router Class Initialized
INFO - 2016-10-26 12:05:13 --> Output Class Initialized
INFO - 2016-10-26 12:05:13 --> Security Class Initialized
DEBUG - 2016-10-26 12:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:05:13 --> Input Class Initialized
INFO - 2016-10-26 12:05:13 --> Language Class Initialized
INFO - 2016-10-26 12:05:13 --> Loader Class Initialized
INFO - 2016-10-26 12:05:13 --> Helper loaded: url_helper
INFO - 2016-10-26 12:05:13 --> Helper loaded: form_helper
INFO - 2016-10-26 12:05:13 --> Database Driver Class Initialized
INFO - 2016-10-26 12:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:05:13 --> Controller Class Initialized
INFO - 2016-10-26 12:05:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:05:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 12:05:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:05:13 --> Final output sent to browser
DEBUG - 2016-10-26 12:05:13 --> Total execution time: 0.0159
INFO - 2016-10-26 12:27:27 --> Config Class Initialized
INFO - 2016-10-26 12:27:27 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:27:27 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:27:27 --> Utf8 Class Initialized
INFO - 2016-10-26 12:27:27 --> URI Class Initialized
DEBUG - 2016-10-26 12:27:27 --> No URI present. Default controller set.
INFO - 2016-10-26 12:27:27 --> Router Class Initialized
INFO - 2016-10-26 12:27:27 --> Output Class Initialized
INFO - 2016-10-26 12:27:27 --> Security Class Initialized
DEBUG - 2016-10-26 12:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:27:27 --> Input Class Initialized
INFO - 2016-10-26 12:27:27 --> Language Class Initialized
INFO - 2016-10-26 12:27:27 --> Loader Class Initialized
INFO - 2016-10-26 12:27:27 --> Helper loaded: url_helper
INFO - 2016-10-26 12:27:27 --> Helper loaded: form_helper
INFO - 2016-10-26 12:27:27 --> Database Driver Class Initialized
INFO - 2016-10-26 12:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:27:27 --> Controller Class Initialized
INFO - 2016-10-26 12:27:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:27:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 12:27:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:27:27 --> Final output sent to browser
DEBUG - 2016-10-26 12:27:27 --> Total execution time: 0.0177
INFO - 2016-10-26 12:27:37 --> Config Class Initialized
INFO - 2016-10-26 12:27:37 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:27:37 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:27:37 --> Utf8 Class Initialized
INFO - 2016-10-26 12:27:37 --> URI Class Initialized
INFO - 2016-10-26 12:27:37 --> Router Class Initialized
INFO - 2016-10-26 12:27:37 --> Output Class Initialized
INFO - 2016-10-26 12:27:37 --> Security Class Initialized
DEBUG - 2016-10-26 12:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:27:37 --> Input Class Initialized
INFO - 2016-10-26 12:27:37 --> Language Class Initialized
INFO - 2016-10-26 12:27:37 --> Loader Class Initialized
INFO - 2016-10-26 12:27:37 --> Helper loaded: url_helper
INFO - 2016-10-26 12:27:37 --> Helper loaded: form_helper
INFO - 2016-10-26 12:27:37 --> Database Driver Class Initialized
INFO - 2016-10-26 12:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:27:37 --> Controller Class Initialized
DEBUG - 2016-10-26 12:27:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-26 12:27:37 --> Model Class Initialized
INFO - 2016-10-26 12:27:37 --> Final output sent to browser
DEBUG - 2016-10-26 12:27:37 --> Total execution time: 0.0174
INFO - 2016-10-26 12:27:38 --> Config Class Initialized
INFO - 2016-10-26 12:27:38 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:27:38 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:27:38 --> Utf8 Class Initialized
INFO - 2016-10-26 12:27:38 --> URI Class Initialized
DEBUG - 2016-10-26 12:27:38 --> No URI present. Default controller set.
INFO - 2016-10-26 12:27:38 --> Router Class Initialized
INFO - 2016-10-26 12:27:38 --> Output Class Initialized
INFO - 2016-10-26 12:27:38 --> Security Class Initialized
DEBUG - 2016-10-26 12:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:27:38 --> Input Class Initialized
INFO - 2016-10-26 12:27:38 --> Language Class Initialized
INFO - 2016-10-26 12:27:38 --> Loader Class Initialized
INFO - 2016-10-26 12:27:38 --> Helper loaded: url_helper
INFO - 2016-10-26 12:27:38 --> Helper loaded: form_helper
INFO - 2016-10-26 12:27:38 --> Database Driver Class Initialized
INFO - 2016-10-26 12:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:27:38 --> Controller Class Initialized
INFO - 2016-10-26 12:27:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:27:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 12:27:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/apple_leave.php
ERROR - 2016-10-26 12:27:38 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 3
ERROR - 2016-10-26 12:27:38 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 8
ERROR - 2016-10-26 12:27:38 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 27
ERROR - 2016-10-26 12:27:38 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 53
ERROR - 2016-10-26 12:27:38 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 69
ERROR - 2016-10-26 12:27:38 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 84
INFO - 2016-10-26 12:27:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 12:27:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:27:38 --> Final output sent to browser
DEBUG - 2016-10-26 12:27:38 --> Total execution time: 0.0165
INFO - 2016-10-26 12:28:34 --> Config Class Initialized
INFO - 2016-10-26 12:28:34 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:28:34 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:28:34 --> Utf8 Class Initialized
INFO - 2016-10-26 12:28:34 --> URI Class Initialized
DEBUG - 2016-10-26 12:28:34 --> No URI present. Default controller set.
INFO - 2016-10-26 12:28:34 --> Router Class Initialized
INFO - 2016-10-26 12:28:34 --> Output Class Initialized
INFO - 2016-10-26 12:28:34 --> Security Class Initialized
DEBUG - 2016-10-26 12:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:28:34 --> Input Class Initialized
INFO - 2016-10-26 12:28:34 --> Language Class Initialized
INFO - 2016-10-26 12:28:34 --> Loader Class Initialized
INFO - 2016-10-26 12:28:34 --> Helper loaded: url_helper
INFO - 2016-10-26 12:28:34 --> Helper loaded: form_helper
INFO - 2016-10-26 12:28:34 --> Database Driver Class Initialized
INFO - 2016-10-26 12:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:28:34 --> Controller Class Initialized
INFO - 2016-10-26 12:28:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:28:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
ERROR - 2016-10-26 12:28:34 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 3
ERROR - 2016-10-26 12:28:34 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 8
ERROR - 2016-10-26 12:28:34 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 27
ERROR - 2016-10-26 12:28:34 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 53
ERROR - 2016-10-26 12:28:34 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 69
ERROR - 2016-10-26 12:28:34 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 84
INFO - 2016-10-26 12:28:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 12:28:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:28:34 --> Final output sent to browser
DEBUG - 2016-10-26 12:28:34 --> Total execution time: 0.0215
INFO - 2016-10-26 12:28:35 --> Config Class Initialized
INFO - 2016-10-26 12:28:35 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:28:35 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:28:35 --> Utf8 Class Initialized
INFO - 2016-10-26 12:28:35 --> URI Class Initialized
DEBUG - 2016-10-26 12:28:35 --> No URI present. Default controller set.
INFO - 2016-10-26 12:28:35 --> Router Class Initialized
INFO - 2016-10-26 12:28:35 --> Output Class Initialized
INFO - 2016-10-26 12:28:35 --> Security Class Initialized
DEBUG - 2016-10-26 12:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:28:35 --> Input Class Initialized
INFO - 2016-10-26 12:28:35 --> Language Class Initialized
INFO - 2016-10-26 12:28:35 --> Loader Class Initialized
INFO - 2016-10-26 12:28:35 --> Helper loaded: url_helper
INFO - 2016-10-26 12:28:35 --> Helper loaded: form_helper
INFO - 2016-10-26 12:28:35 --> Database Driver Class Initialized
INFO - 2016-10-26 12:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:28:35 --> Controller Class Initialized
INFO - 2016-10-26 12:28:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:28:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
ERROR - 2016-10-26 12:28:35 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 3
ERROR - 2016-10-26 12:28:35 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 8
ERROR - 2016-10-26 12:28:35 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 27
ERROR - 2016-10-26 12:28:35 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 53
ERROR - 2016-10-26 12:28:35 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 69
ERROR - 2016-10-26 12:28:35 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 84
INFO - 2016-10-26 12:28:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 12:28:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:28:35 --> Final output sent to browser
DEBUG - 2016-10-26 12:28:35 --> Total execution time: 0.0172
INFO - 2016-10-26 12:28:46 --> Config Class Initialized
INFO - 2016-10-26 12:28:46 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:28:46 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:28:46 --> Utf8 Class Initialized
INFO - 2016-10-26 12:28:46 --> URI Class Initialized
DEBUG - 2016-10-26 12:28:46 --> No URI present. Default controller set.
INFO - 2016-10-26 12:28:46 --> Router Class Initialized
INFO - 2016-10-26 12:28:46 --> Output Class Initialized
INFO - 2016-10-26 12:28:46 --> Security Class Initialized
DEBUG - 2016-10-26 12:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:28:46 --> Input Class Initialized
INFO - 2016-10-26 12:28:46 --> Language Class Initialized
INFO - 2016-10-26 12:28:46 --> Loader Class Initialized
INFO - 2016-10-26 12:28:46 --> Helper loaded: url_helper
INFO - 2016-10-26 12:28:46 --> Helper loaded: form_helper
INFO - 2016-10-26 12:28:46 --> Database Driver Class Initialized
INFO - 2016-10-26 12:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:28:46 --> Controller Class Initialized
INFO - 2016-10-26 12:28:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:28:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 12:28:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/apple_leave.php
ERROR - 2016-10-26 12:28:46 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 3
ERROR - 2016-10-26 12:28:46 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 8
ERROR - 2016-10-26 12:28:46 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 27
ERROR - 2016-10-26 12:28:46 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 53
ERROR - 2016-10-26 12:28:46 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 69
ERROR - 2016-10-26 12:28:46 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 84
INFO - 2016-10-26 12:28:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 12:28:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:28:46 --> Final output sent to browser
DEBUG - 2016-10-26 12:28:46 --> Total execution time: 0.0222
INFO - 2016-10-26 12:29:36 --> Config Class Initialized
INFO - 2016-10-26 12:29:36 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:29:36 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:29:36 --> Utf8 Class Initialized
INFO - 2016-10-26 12:29:36 --> URI Class Initialized
DEBUG - 2016-10-26 12:29:36 --> No URI present. Default controller set.
INFO - 2016-10-26 12:29:36 --> Router Class Initialized
INFO - 2016-10-26 12:29:36 --> Output Class Initialized
INFO - 2016-10-26 12:29:36 --> Security Class Initialized
DEBUG - 2016-10-26 12:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:29:36 --> Input Class Initialized
INFO - 2016-10-26 12:29:36 --> Language Class Initialized
INFO - 2016-10-26 12:29:36 --> Loader Class Initialized
INFO - 2016-10-26 12:29:36 --> Helper loaded: url_helper
INFO - 2016-10-26 12:29:36 --> Helper loaded: form_helper
INFO - 2016-10-26 12:29:36 --> Database Driver Class Initialized
INFO - 2016-10-26 12:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:29:36 --> Controller Class Initialized
INFO - 2016-10-26 12:29:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:29:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 12:29:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/apple_leave.php
ERROR - 2016-10-26 12:29:36 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 3
ERROR - 2016-10-26 12:29:36 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 8
ERROR - 2016-10-26 12:29:36 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 27
ERROR - 2016-10-26 12:29:36 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 53
ERROR - 2016-10-26 12:29:36 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 69
ERROR - 2016-10-26 12:29:36 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 84
INFO - 2016-10-26 12:29:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 12:29:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:29:36 --> Final output sent to browser
DEBUG - 2016-10-26 12:29:36 --> Total execution time: 0.0225
INFO - 2016-10-26 12:29:37 --> Config Class Initialized
INFO - 2016-10-26 12:29:37 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:29:37 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:29:37 --> Utf8 Class Initialized
INFO - 2016-10-26 12:29:37 --> URI Class Initialized
DEBUG - 2016-10-26 12:29:37 --> No URI present. Default controller set.
INFO - 2016-10-26 12:29:37 --> Router Class Initialized
INFO - 2016-10-26 12:29:37 --> Output Class Initialized
INFO - 2016-10-26 12:29:37 --> Security Class Initialized
DEBUG - 2016-10-26 12:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:29:37 --> Input Class Initialized
INFO - 2016-10-26 12:29:37 --> Language Class Initialized
INFO - 2016-10-26 12:29:37 --> Loader Class Initialized
INFO - 2016-10-26 12:29:37 --> Helper loaded: url_helper
INFO - 2016-10-26 12:29:37 --> Helper loaded: form_helper
INFO - 2016-10-26 12:29:37 --> Database Driver Class Initialized
INFO - 2016-10-26 12:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:29:37 --> Controller Class Initialized
INFO - 2016-10-26 12:29:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:29:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 12:29:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/apple_leave.php
ERROR - 2016-10-26 12:29:37 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 3
ERROR - 2016-10-26 12:29:37 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 8
ERROR - 2016-10-26 12:29:37 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 27
ERROR - 2016-10-26 12:29:37 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 53
ERROR - 2016-10-26 12:29:37 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 69
ERROR - 2016-10-26 12:29:37 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 84
INFO - 2016-10-26 12:29:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 12:29:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:29:37 --> Final output sent to browser
DEBUG - 2016-10-26 12:29:37 --> Total execution time: 0.0176
INFO - 2016-10-26 12:29:46 --> Config Class Initialized
INFO - 2016-10-26 12:29:46 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:29:46 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:29:46 --> Utf8 Class Initialized
INFO - 2016-10-26 12:29:46 --> URI Class Initialized
DEBUG - 2016-10-26 12:29:46 --> No URI present. Default controller set.
INFO - 2016-10-26 12:29:46 --> Router Class Initialized
INFO - 2016-10-26 12:29:46 --> Output Class Initialized
INFO - 2016-10-26 12:29:46 --> Security Class Initialized
DEBUG - 2016-10-26 12:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:29:46 --> Input Class Initialized
INFO - 2016-10-26 12:29:46 --> Language Class Initialized
INFO - 2016-10-26 12:29:46 --> Loader Class Initialized
INFO - 2016-10-26 12:29:46 --> Helper loaded: url_helper
INFO - 2016-10-26 12:29:46 --> Helper loaded: form_helper
INFO - 2016-10-26 12:29:46 --> Database Driver Class Initialized
INFO - 2016-10-26 12:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:29:46 --> Controller Class Initialized
INFO - 2016-10-26 12:29:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:29:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 12:29:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/apple_leave.php
ERROR - 2016-10-26 12:29:46 --> Severity: Notice --> Undefined variable: myleave /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 60
INFO - 2016-10-26 12:30:01 --> Config Class Initialized
INFO - 2016-10-26 12:30:01 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:30:01 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:30:01 --> Utf8 Class Initialized
INFO - 2016-10-26 12:30:01 --> URI Class Initialized
DEBUG - 2016-10-26 12:30:01 --> No URI present. Default controller set.
INFO - 2016-10-26 12:30:01 --> Router Class Initialized
INFO - 2016-10-26 12:30:01 --> Output Class Initialized
INFO - 2016-10-26 12:30:01 --> Security Class Initialized
DEBUG - 2016-10-26 12:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:30:01 --> Input Class Initialized
INFO - 2016-10-26 12:30:01 --> Language Class Initialized
INFO - 2016-10-26 12:30:01 --> Loader Class Initialized
INFO - 2016-10-26 12:30:01 --> Helper loaded: url_helper
INFO - 2016-10-26 12:30:01 --> Helper loaded: form_helper
INFO - 2016-10-26 12:30:01 --> Database Driver Class Initialized
INFO - 2016-10-26 12:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:30:01 --> Controller Class Initialized
INFO - 2016-10-26 12:30:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:30:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 12:30:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/apple_leave.php
ERROR - 2016-10-26 12:30:01 --> Severity: Notice --> Undefined variable: myleave /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 60
INFO - 2016-10-26 12:30:02 --> Config Class Initialized
INFO - 2016-10-26 12:30:02 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:30:02 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:30:02 --> Utf8 Class Initialized
INFO - 2016-10-26 12:30:02 --> URI Class Initialized
DEBUG - 2016-10-26 12:30:02 --> No URI present. Default controller set.
INFO - 2016-10-26 12:30:02 --> Router Class Initialized
INFO - 2016-10-26 12:30:02 --> Output Class Initialized
INFO - 2016-10-26 12:30:02 --> Security Class Initialized
DEBUG - 2016-10-26 12:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:30:02 --> Input Class Initialized
INFO - 2016-10-26 12:30:02 --> Language Class Initialized
INFO - 2016-10-26 12:30:02 --> Loader Class Initialized
INFO - 2016-10-26 12:30:02 --> Helper loaded: url_helper
INFO - 2016-10-26 12:30:02 --> Helper loaded: form_helper
INFO - 2016-10-26 12:30:02 --> Database Driver Class Initialized
INFO - 2016-10-26 12:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:30:02 --> Controller Class Initialized
INFO - 2016-10-26 12:30:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:30:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 12:30:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/apple_leave.php
ERROR - 2016-10-26 12:30:02 --> Severity: Notice --> Undefined variable: myleave /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 60
INFO - 2016-10-26 12:30:14 --> Config Class Initialized
INFO - 2016-10-26 12:30:14 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:30:14 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:30:14 --> Utf8 Class Initialized
INFO - 2016-10-26 12:30:14 --> URI Class Initialized
DEBUG - 2016-10-26 12:30:14 --> No URI present. Default controller set.
INFO - 2016-10-26 12:30:14 --> Router Class Initialized
INFO - 2016-10-26 12:30:14 --> Output Class Initialized
INFO - 2016-10-26 12:30:14 --> Security Class Initialized
DEBUG - 2016-10-26 12:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:30:14 --> Input Class Initialized
INFO - 2016-10-26 12:30:14 --> Language Class Initialized
INFO - 2016-10-26 12:30:14 --> Loader Class Initialized
INFO - 2016-10-26 12:30:14 --> Helper loaded: url_helper
INFO - 2016-10-26 12:30:14 --> Helper loaded: form_helper
INFO - 2016-10-26 12:30:14 --> Database Driver Class Initialized
INFO - 2016-10-26 12:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:30:14 --> Controller Class Initialized
INFO - 2016-10-26 12:30:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:30:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 12:30:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/apple_leave.php
INFO - 2016-10-26 12:30:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 12:30:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:30:14 --> Final output sent to browser
DEBUG - 2016-10-26 12:30:14 --> Total execution time: 0.0169
INFO - 2016-10-26 12:30:15 --> Config Class Initialized
INFO - 2016-10-26 12:30:15 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:30:15 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:30:15 --> Utf8 Class Initialized
INFO - 2016-10-26 12:30:15 --> URI Class Initialized
DEBUG - 2016-10-26 12:30:15 --> No URI present. Default controller set.
INFO - 2016-10-26 12:30:15 --> Router Class Initialized
INFO - 2016-10-26 12:30:15 --> Output Class Initialized
INFO - 2016-10-26 12:30:15 --> Security Class Initialized
DEBUG - 2016-10-26 12:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:30:15 --> Input Class Initialized
INFO - 2016-10-26 12:30:15 --> Language Class Initialized
INFO - 2016-10-26 12:30:15 --> Loader Class Initialized
INFO - 2016-10-26 12:30:15 --> Helper loaded: url_helper
INFO - 2016-10-26 12:30:15 --> Helper loaded: form_helper
INFO - 2016-10-26 12:30:15 --> Database Driver Class Initialized
INFO - 2016-10-26 12:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:30:15 --> Controller Class Initialized
INFO - 2016-10-26 12:30:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:30:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 12:30:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/apple_leave.php
INFO - 2016-10-26 12:30:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 12:30:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:30:15 --> Final output sent to browser
DEBUG - 2016-10-26 12:30:15 --> Total execution time: 0.0161
INFO - 2016-10-26 12:30:53 --> Config Class Initialized
INFO - 2016-10-26 12:30:53 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:30:53 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:30:53 --> Utf8 Class Initialized
INFO - 2016-10-26 12:30:53 --> URI Class Initialized
DEBUG - 2016-10-26 12:30:53 --> No URI present. Default controller set.
INFO - 2016-10-26 12:30:53 --> Router Class Initialized
INFO - 2016-10-26 12:30:53 --> Output Class Initialized
INFO - 2016-10-26 12:30:53 --> Security Class Initialized
DEBUG - 2016-10-26 12:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:30:53 --> Input Class Initialized
INFO - 2016-10-26 12:30:53 --> Language Class Initialized
INFO - 2016-10-26 12:30:53 --> Loader Class Initialized
INFO - 2016-10-26 12:30:53 --> Helper loaded: url_helper
INFO - 2016-10-26 12:30:53 --> Helper loaded: form_helper
INFO - 2016-10-26 12:30:53 --> Database Driver Class Initialized
INFO - 2016-10-26 12:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:30:53 --> Controller Class Initialized
INFO - 2016-10-26 12:30:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:30:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 12:30:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/apple_leave.php
INFO - 2016-10-26 12:30:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 12:30:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:30:53 --> Final output sent to browser
DEBUG - 2016-10-26 12:30:53 --> Total execution time: 0.0198
INFO - 2016-10-26 12:30:54 --> Config Class Initialized
INFO - 2016-10-26 12:30:54 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:30:54 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:30:54 --> Utf8 Class Initialized
INFO - 2016-10-26 12:30:54 --> URI Class Initialized
DEBUG - 2016-10-26 12:30:54 --> No URI present. Default controller set.
INFO - 2016-10-26 12:30:54 --> Router Class Initialized
INFO - 2016-10-26 12:30:54 --> Output Class Initialized
INFO - 2016-10-26 12:30:54 --> Security Class Initialized
DEBUG - 2016-10-26 12:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:30:54 --> Input Class Initialized
INFO - 2016-10-26 12:30:54 --> Language Class Initialized
INFO - 2016-10-26 12:30:54 --> Loader Class Initialized
INFO - 2016-10-26 12:30:54 --> Helper loaded: url_helper
INFO - 2016-10-26 12:30:54 --> Helper loaded: form_helper
INFO - 2016-10-26 12:30:54 --> Database Driver Class Initialized
INFO - 2016-10-26 12:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:30:54 --> Controller Class Initialized
INFO - 2016-10-26 12:30:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:30:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 12:30:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/apple_leave.php
INFO - 2016-10-26 12:30:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 12:30:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:30:54 --> Final output sent to browser
DEBUG - 2016-10-26 12:30:54 --> Total execution time: 0.0166
INFO - 2016-10-26 12:31:17 --> Config Class Initialized
INFO - 2016-10-26 12:31:17 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:31:17 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:31:17 --> Utf8 Class Initialized
INFO - 2016-10-26 12:31:17 --> URI Class Initialized
DEBUG - 2016-10-26 12:31:17 --> No URI present. Default controller set.
INFO - 2016-10-26 12:31:17 --> Router Class Initialized
INFO - 2016-10-26 12:31:17 --> Output Class Initialized
INFO - 2016-10-26 12:31:17 --> Security Class Initialized
DEBUG - 2016-10-26 12:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:31:17 --> Input Class Initialized
INFO - 2016-10-26 12:31:17 --> Language Class Initialized
INFO - 2016-10-26 12:31:17 --> Loader Class Initialized
INFO - 2016-10-26 12:31:17 --> Helper loaded: url_helper
INFO - 2016-10-26 12:31:17 --> Helper loaded: form_helper
INFO - 2016-10-26 12:31:17 --> Database Driver Class Initialized
INFO - 2016-10-26 12:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:31:17 --> Controller Class Initialized
INFO - 2016-10-26 12:31:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:31:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
ERROR - 2016-10-26 12:31:17 --> Severity: Notice --> Undefined variable: apply_leave /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 56
INFO - 2016-10-26 12:31:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 12:31:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:31:17 --> Final output sent to browser
DEBUG - 2016-10-26 12:31:17 --> Total execution time: 0.0181
INFO - 2016-10-26 12:31:19 --> Config Class Initialized
INFO - 2016-10-26 12:31:19 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:31:19 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:31:19 --> Utf8 Class Initialized
INFO - 2016-10-26 12:31:19 --> URI Class Initialized
DEBUG - 2016-10-26 12:31:19 --> No URI present. Default controller set.
INFO - 2016-10-26 12:31:19 --> Router Class Initialized
INFO - 2016-10-26 12:31:19 --> Output Class Initialized
INFO - 2016-10-26 12:31:19 --> Security Class Initialized
DEBUG - 2016-10-26 12:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:31:19 --> Input Class Initialized
INFO - 2016-10-26 12:31:19 --> Language Class Initialized
INFO - 2016-10-26 12:31:19 --> Loader Class Initialized
INFO - 2016-10-26 12:31:19 --> Helper loaded: url_helper
INFO - 2016-10-26 12:31:19 --> Helper loaded: form_helper
INFO - 2016-10-26 12:31:19 --> Database Driver Class Initialized
INFO - 2016-10-26 12:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:31:19 --> Controller Class Initialized
INFO - 2016-10-26 12:31:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:31:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
ERROR - 2016-10-26 12:31:19 --> Severity: Notice --> Undefined variable: apply_leave /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 56
INFO - 2016-10-26 12:31:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 12:31:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:31:19 --> Final output sent to browser
DEBUG - 2016-10-26 12:31:19 --> Total execution time: 0.0179
INFO - 2016-10-26 12:31:53 --> Config Class Initialized
INFO - 2016-10-26 12:31:53 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:31:53 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:31:53 --> Utf8 Class Initialized
INFO - 2016-10-26 12:31:53 --> URI Class Initialized
DEBUG - 2016-10-26 12:31:53 --> No URI present. Default controller set.
INFO - 2016-10-26 12:31:53 --> Router Class Initialized
INFO - 2016-10-26 12:31:53 --> Output Class Initialized
INFO - 2016-10-26 12:31:53 --> Security Class Initialized
DEBUG - 2016-10-26 12:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:31:53 --> Input Class Initialized
INFO - 2016-10-26 12:31:53 --> Language Class Initialized
INFO - 2016-10-26 12:31:53 --> Loader Class Initialized
INFO - 2016-10-26 12:31:53 --> Helper loaded: url_helper
INFO - 2016-10-26 12:31:53 --> Helper loaded: form_helper
INFO - 2016-10-26 12:31:53 --> Database Driver Class Initialized
INFO - 2016-10-26 12:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:31:53 --> Controller Class Initialized
INFO - 2016-10-26 12:31:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:31:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
ERROR - 2016-10-26 12:31:53 --> Severity: Notice --> Undefined variable: apply_leave /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 56
INFO - 2016-10-26 12:31:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 12:31:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:31:53 --> Final output sent to browser
DEBUG - 2016-10-26 12:31:53 --> Total execution time: 0.0199
INFO - 2016-10-26 12:32:35 --> Config Class Initialized
INFO - 2016-10-26 12:32:35 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:32:35 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:32:35 --> Utf8 Class Initialized
INFO - 2016-10-26 12:32:35 --> URI Class Initialized
DEBUG - 2016-10-26 12:32:35 --> No URI present. Default controller set.
INFO - 2016-10-26 12:32:35 --> Router Class Initialized
INFO - 2016-10-26 12:32:35 --> Output Class Initialized
INFO - 2016-10-26 12:32:35 --> Security Class Initialized
DEBUG - 2016-10-26 12:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:32:35 --> Input Class Initialized
INFO - 2016-10-26 12:32:35 --> Language Class Initialized
INFO - 2016-10-26 12:32:35 --> Loader Class Initialized
INFO - 2016-10-26 12:32:35 --> Helper loaded: url_helper
INFO - 2016-10-26 12:32:35 --> Helper loaded: form_helper
INFO - 2016-10-26 12:32:35 --> Database Driver Class Initialized
INFO - 2016-10-26 12:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:32:35 --> Controller Class Initialized
INFO - 2016-10-26 12:32:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:32:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
ERROR - 2016-10-26 12:32:35 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 3
ERROR - 2016-10-26 12:32:35 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 8
ERROR - 2016-10-26 12:32:35 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 27
ERROR - 2016-10-26 12:32:35 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 53
ERROR - 2016-10-26 12:32:35 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 69
ERROR - 2016-10-26 12:32:35 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 84
INFO - 2016-10-26 12:32:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 12:32:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:32:35 --> Final output sent to browser
DEBUG - 2016-10-26 12:32:35 --> Total execution time: 0.0185
INFO - 2016-10-26 12:33:37 --> Config Class Initialized
INFO - 2016-10-26 12:33:37 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:33:37 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:33:37 --> Utf8 Class Initialized
INFO - 2016-10-26 12:33:37 --> URI Class Initialized
DEBUG - 2016-10-26 12:33:37 --> No URI present. Default controller set.
INFO - 2016-10-26 12:33:37 --> Router Class Initialized
INFO - 2016-10-26 12:33:37 --> Output Class Initialized
INFO - 2016-10-26 12:33:37 --> Security Class Initialized
DEBUG - 2016-10-26 12:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:33:37 --> Input Class Initialized
INFO - 2016-10-26 12:33:37 --> Language Class Initialized
INFO - 2016-10-26 12:33:37 --> Loader Class Initialized
INFO - 2016-10-26 12:33:37 --> Helper loaded: url_helper
INFO - 2016-10-26 12:33:37 --> Helper loaded: form_helper
INFO - 2016-10-26 12:33:37 --> Database Driver Class Initialized
INFO - 2016-10-26 12:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:33:37 --> Controller Class Initialized
INFO - 2016-10-26 12:33:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:33:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
ERROR - 2016-10-26 12:33:37 --> Severity: Notice --> Undefined variable: apply_leave /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 56
INFO - 2016-10-26 12:33:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 12:33:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:33:37 --> Final output sent to browser
DEBUG - 2016-10-26 12:33:37 --> Total execution time: 0.0205
INFO - 2016-10-26 12:34:18 --> Config Class Initialized
INFO - 2016-10-26 12:34:18 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:34:18 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:34:18 --> Utf8 Class Initialized
INFO - 2016-10-26 12:34:18 --> URI Class Initialized
DEBUG - 2016-10-26 12:34:18 --> No URI present. Default controller set.
INFO - 2016-10-26 12:34:18 --> Router Class Initialized
INFO - 2016-10-26 12:34:18 --> Output Class Initialized
INFO - 2016-10-26 12:34:18 --> Security Class Initialized
DEBUG - 2016-10-26 12:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:34:18 --> Input Class Initialized
INFO - 2016-10-26 12:34:18 --> Language Class Initialized
INFO - 2016-10-26 12:34:18 --> Loader Class Initialized
INFO - 2016-10-26 12:34:18 --> Helper loaded: url_helper
INFO - 2016-10-26 12:34:18 --> Helper loaded: form_helper
INFO - 2016-10-26 12:34:18 --> Database Driver Class Initialized
INFO - 2016-10-26 12:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:34:18 --> Controller Class Initialized
INFO - 2016-10-26 12:34:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:34:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
ERROR - 2016-10-26 12:34:18 --> Severity: Notice --> Undefined variable: apply_leave /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 56
INFO - 2016-10-26 12:34:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/my_leave.php
INFO - 2016-10-26 12:34:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 12:34:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:34:18 --> Final output sent to browser
DEBUG - 2016-10-26 12:34:18 --> Total execution time: 0.0178
INFO - 2016-10-26 12:35:04 --> Config Class Initialized
INFO - 2016-10-26 12:35:04 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:35:04 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:35:04 --> Utf8 Class Initialized
INFO - 2016-10-26 12:35:04 --> URI Class Initialized
DEBUG - 2016-10-26 12:35:04 --> No URI present. Default controller set.
INFO - 2016-10-26 12:35:04 --> Router Class Initialized
INFO - 2016-10-26 12:35:04 --> Output Class Initialized
INFO - 2016-10-26 12:35:04 --> Security Class Initialized
DEBUG - 2016-10-26 12:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:35:04 --> Input Class Initialized
INFO - 2016-10-26 12:35:04 --> Language Class Initialized
INFO - 2016-10-26 12:35:04 --> Loader Class Initialized
INFO - 2016-10-26 12:35:04 --> Helper loaded: url_helper
INFO - 2016-10-26 12:35:04 --> Helper loaded: form_helper
INFO - 2016-10-26 12:35:04 --> Database Driver Class Initialized
INFO - 2016-10-26 12:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:35:04 --> Controller Class Initialized
INFO - 2016-10-26 12:35:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:35:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
ERROR - 2016-10-26 12:35:04 --> Severity: Notice --> Undefined variable: apply_leave /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 56
INFO - 2016-10-26 12:35:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/my_leave.php
INFO - 2016-10-26 12:35:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 12:35:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:35:04 --> Final output sent to browser
DEBUG - 2016-10-26 12:35:04 --> Total execution time: 0.0211
INFO - 2016-10-26 12:37:39 --> Config Class Initialized
INFO - 2016-10-26 12:37:39 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:37:39 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:37:39 --> Utf8 Class Initialized
INFO - 2016-10-26 12:37:39 --> URI Class Initialized
DEBUG - 2016-10-26 12:37:39 --> No URI present. Default controller set.
INFO - 2016-10-26 12:37:39 --> Router Class Initialized
INFO - 2016-10-26 12:37:39 --> Output Class Initialized
INFO - 2016-10-26 12:37:39 --> Security Class Initialized
DEBUG - 2016-10-26 12:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:37:39 --> Input Class Initialized
INFO - 2016-10-26 12:37:39 --> Language Class Initialized
INFO - 2016-10-26 12:37:39 --> Loader Class Initialized
INFO - 2016-10-26 12:37:39 --> Helper loaded: url_helper
INFO - 2016-10-26 12:37:39 --> Helper loaded: form_helper
INFO - 2016-10-26 12:37:39 --> Database Driver Class Initialized
INFO - 2016-10-26 12:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:37:39 --> Controller Class Initialized
INFO - 2016-10-26 12:37:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:37:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 12:37:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/my_leave.php
INFO - 2016-10-26 12:37:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 12:37:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:37:39 --> Final output sent to browser
DEBUG - 2016-10-26 12:37:39 --> Total execution time: 0.0203
INFO - 2016-10-26 12:38:11 --> Config Class Initialized
INFO - 2016-10-26 12:38:11 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:38:11 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:38:11 --> Utf8 Class Initialized
INFO - 2016-10-26 12:38:11 --> URI Class Initialized
DEBUG - 2016-10-26 12:38:11 --> No URI present. Default controller set.
INFO - 2016-10-26 12:38:11 --> Router Class Initialized
INFO - 2016-10-26 12:38:11 --> Output Class Initialized
INFO - 2016-10-26 12:38:11 --> Security Class Initialized
DEBUG - 2016-10-26 12:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:38:11 --> Input Class Initialized
INFO - 2016-10-26 12:38:11 --> Language Class Initialized
INFO - 2016-10-26 12:38:11 --> Loader Class Initialized
INFO - 2016-10-26 12:38:11 --> Helper loaded: url_helper
INFO - 2016-10-26 12:38:11 --> Helper loaded: form_helper
INFO - 2016-10-26 12:38:11 --> Database Driver Class Initialized
INFO - 2016-10-26 12:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:38:11 --> Controller Class Initialized
INFO - 2016-10-26 12:38:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:38:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 12:38:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/apple_leave.php
INFO - 2016-10-26 12:38:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/my_leave.php
INFO - 2016-10-26 12:38:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 12:38:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:38:11 --> Final output sent to browser
DEBUG - 2016-10-26 12:38:11 --> Total execution time: 0.0165
INFO - 2016-10-26 12:38:40 --> Config Class Initialized
INFO - 2016-10-26 12:38:40 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:38:40 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:38:40 --> Utf8 Class Initialized
INFO - 2016-10-26 12:38:40 --> URI Class Initialized
DEBUG - 2016-10-26 12:38:40 --> No URI present. Default controller set.
INFO - 2016-10-26 12:38:40 --> Router Class Initialized
INFO - 2016-10-26 12:38:40 --> Output Class Initialized
INFO - 2016-10-26 12:38:40 --> Security Class Initialized
DEBUG - 2016-10-26 12:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:38:40 --> Input Class Initialized
INFO - 2016-10-26 12:38:40 --> Language Class Initialized
INFO - 2016-10-26 12:38:40 --> Loader Class Initialized
INFO - 2016-10-26 12:38:40 --> Helper loaded: url_helper
INFO - 2016-10-26 12:38:40 --> Helper loaded: form_helper
INFO - 2016-10-26 12:38:40 --> Database Driver Class Initialized
INFO - 2016-10-26 12:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:38:40 --> Controller Class Initialized
INFO - 2016-10-26 12:38:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:38:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 12:38:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/apple_leave.php
INFO - 2016-10-26 12:38:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/my_leave.php
INFO - 2016-10-26 12:38:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 12:38:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:38:40 --> Final output sent to browser
DEBUG - 2016-10-26 12:38:40 --> Total execution time: 0.0197
INFO - 2016-10-26 12:40:07 --> Config Class Initialized
INFO - 2016-10-26 12:40:07 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:40:07 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:40:07 --> Utf8 Class Initialized
INFO - 2016-10-26 12:40:07 --> URI Class Initialized
INFO - 2016-10-26 12:40:07 --> Router Class Initialized
INFO - 2016-10-26 12:40:07 --> Output Class Initialized
INFO - 2016-10-26 12:40:07 --> Security Class Initialized
DEBUG - 2016-10-26 12:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:40:07 --> Input Class Initialized
INFO - 2016-10-26 12:40:07 --> Language Class Initialized
INFO - 2016-10-26 12:40:07 --> Loader Class Initialized
INFO - 2016-10-26 12:40:07 --> Helper loaded: url_helper
INFO - 2016-10-26 12:40:07 --> Helper loaded: form_helper
INFO - 2016-10-26 12:40:07 --> Database Driver Class Initialized
INFO - 2016-10-26 12:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:40:07 --> Controller Class Initialized
DEBUG - 2016-10-26 12:40:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-26 12:40:07 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 147
ERROR - 2016-10-26 12:40:07 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 147
INFO - 2016-10-26 12:40:07 --> Config Class Initialized
INFO - 2016-10-26 12:40:07 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:40:07 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:40:07 --> Utf8 Class Initialized
INFO - 2016-10-26 12:40:07 --> URI Class Initialized
DEBUG - 2016-10-26 12:40:07 --> No URI present. Default controller set.
INFO - 2016-10-26 12:40:07 --> Router Class Initialized
INFO - 2016-10-26 12:40:07 --> Output Class Initialized
INFO - 2016-10-26 12:40:07 --> Security Class Initialized
DEBUG - 2016-10-26 12:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:40:07 --> Input Class Initialized
INFO - 2016-10-26 12:40:07 --> Language Class Initialized
INFO - 2016-10-26 12:40:07 --> Loader Class Initialized
INFO - 2016-10-26 12:40:07 --> Helper loaded: url_helper
INFO - 2016-10-26 12:40:07 --> Helper loaded: form_helper
INFO - 2016-10-26 12:40:07 --> Database Driver Class Initialized
INFO - 2016-10-26 12:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:40:07 --> Controller Class Initialized
INFO - 2016-10-26 12:40:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:40:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 12:40:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:40:07 --> Final output sent to browser
DEBUG - 2016-10-26 12:40:07 --> Total execution time: 0.0173
INFO - 2016-10-26 12:40:12 --> Config Class Initialized
INFO - 2016-10-26 12:40:12 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:40:12 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:40:12 --> Utf8 Class Initialized
INFO - 2016-10-26 12:40:12 --> URI Class Initialized
INFO - 2016-10-26 12:40:12 --> Router Class Initialized
INFO - 2016-10-26 12:40:12 --> Output Class Initialized
INFO - 2016-10-26 12:40:12 --> Security Class Initialized
DEBUG - 2016-10-26 12:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:40:12 --> Input Class Initialized
INFO - 2016-10-26 12:40:12 --> Language Class Initialized
INFO - 2016-10-26 12:40:12 --> Loader Class Initialized
INFO - 2016-10-26 12:40:12 --> Helper loaded: url_helper
INFO - 2016-10-26 12:40:12 --> Helper loaded: form_helper
INFO - 2016-10-26 12:40:12 --> Database Driver Class Initialized
INFO - 2016-10-26 12:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:40:12 --> Controller Class Initialized
DEBUG - 2016-10-26 12:40:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-26 12:40:12 --> Model Class Initialized
INFO - 2016-10-26 12:40:12 --> Final output sent to browser
DEBUG - 2016-10-26 12:40:12 --> Total execution time: 0.0203
INFO - 2016-10-26 12:40:12 --> Config Class Initialized
INFO - 2016-10-26 12:40:12 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:40:12 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:40:12 --> Utf8 Class Initialized
INFO - 2016-10-26 12:40:12 --> URI Class Initialized
DEBUG - 2016-10-26 12:40:12 --> No URI present. Default controller set.
INFO - 2016-10-26 12:40:12 --> Router Class Initialized
INFO - 2016-10-26 12:40:12 --> Output Class Initialized
INFO - 2016-10-26 12:40:12 --> Security Class Initialized
DEBUG - 2016-10-26 12:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:40:12 --> Input Class Initialized
INFO - 2016-10-26 12:40:12 --> Language Class Initialized
INFO - 2016-10-26 12:40:12 --> Loader Class Initialized
INFO - 2016-10-26 12:40:12 --> Helper loaded: url_helper
INFO - 2016-10-26 12:40:12 --> Helper loaded: form_helper
INFO - 2016-10-26 12:40:12 --> Database Driver Class Initialized
INFO - 2016-10-26 12:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:40:12 --> Controller Class Initialized
INFO - 2016-10-26 12:40:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:40:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 12:40:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 12:40:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:40:12 --> Final output sent to browser
DEBUG - 2016-10-26 12:40:12 --> Total execution time: 0.0149
INFO - 2016-10-26 12:40:20 --> Config Class Initialized
INFO - 2016-10-26 12:40:20 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:40:20 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:40:20 --> Utf8 Class Initialized
INFO - 2016-10-26 12:40:20 --> URI Class Initialized
INFO - 2016-10-26 12:40:20 --> Router Class Initialized
INFO - 2016-10-26 12:40:20 --> Output Class Initialized
INFO - 2016-10-26 12:40:20 --> Security Class Initialized
DEBUG - 2016-10-26 12:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:40:20 --> Input Class Initialized
INFO - 2016-10-26 12:40:20 --> Language Class Initialized
INFO - 2016-10-26 12:40:20 --> Loader Class Initialized
INFO - 2016-10-26 12:40:20 --> Helper loaded: url_helper
INFO - 2016-10-26 12:40:20 --> Helper loaded: form_helper
INFO - 2016-10-26 12:40:20 --> Database Driver Class Initialized
INFO - 2016-10-26 12:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:40:20 --> Controller Class Initialized
DEBUG - 2016-10-26 12:40:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-26 12:40:20 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 147
ERROR - 2016-10-26 12:40:20 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 147
INFO - 2016-10-26 12:40:20 --> Config Class Initialized
INFO - 2016-10-26 12:40:20 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:40:20 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:40:20 --> Utf8 Class Initialized
INFO - 2016-10-26 12:40:20 --> URI Class Initialized
DEBUG - 2016-10-26 12:40:20 --> No URI present. Default controller set.
INFO - 2016-10-26 12:40:20 --> Router Class Initialized
INFO - 2016-10-26 12:40:20 --> Output Class Initialized
INFO - 2016-10-26 12:40:20 --> Security Class Initialized
DEBUG - 2016-10-26 12:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:40:20 --> Input Class Initialized
INFO - 2016-10-26 12:40:20 --> Language Class Initialized
INFO - 2016-10-26 12:40:20 --> Loader Class Initialized
INFO - 2016-10-26 12:40:20 --> Helper loaded: url_helper
INFO - 2016-10-26 12:40:20 --> Helper loaded: form_helper
INFO - 2016-10-26 12:40:20 --> Database Driver Class Initialized
INFO - 2016-10-26 12:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:40:20 --> Controller Class Initialized
INFO - 2016-10-26 12:40:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:40:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 12:40:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:40:20 --> Final output sent to browser
DEBUG - 2016-10-26 12:40:20 --> Total execution time: 0.0223
INFO - 2016-10-26 12:40:28 --> Config Class Initialized
INFO - 2016-10-26 12:40:28 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:40:28 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:40:28 --> Utf8 Class Initialized
INFO - 2016-10-26 12:40:28 --> URI Class Initialized
INFO - 2016-10-26 12:40:28 --> Router Class Initialized
INFO - 2016-10-26 12:40:28 --> Output Class Initialized
INFO - 2016-10-26 12:40:28 --> Security Class Initialized
DEBUG - 2016-10-26 12:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:40:28 --> Input Class Initialized
INFO - 2016-10-26 12:40:28 --> Language Class Initialized
INFO - 2016-10-26 12:40:28 --> Loader Class Initialized
INFO - 2016-10-26 12:40:28 --> Helper loaded: url_helper
INFO - 2016-10-26 12:40:28 --> Helper loaded: form_helper
INFO - 2016-10-26 12:40:28 --> Database Driver Class Initialized
INFO - 2016-10-26 12:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:40:28 --> Controller Class Initialized
DEBUG - 2016-10-26 12:40:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-26 12:40:28 --> Model Class Initialized
INFO - 2016-10-26 12:40:28 --> Final output sent to browser
DEBUG - 2016-10-26 12:40:28 --> Total execution time: 0.0176
INFO - 2016-10-26 12:40:28 --> Config Class Initialized
INFO - 2016-10-26 12:40:28 --> Hooks Class Initialized
DEBUG - 2016-10-26 12:40:28 --> UTF-8 Support Enabled
INFO - 2016-10-26 12:40:28 --> Utf8 Class Initialized
INFO - 2016-10-26 12:40:28 --> URI Class Initialized
DEBUG - 2016-10-26 12:40:28 --> No URI present. Default controller set.
INFO - 2016-10-26 12:40:28 --> Router Class Initialized
INFO - 2016-10-26 12:40:28 --> Output Class Initialized
INFO - 2016-10-26 12:40:28 --> Security Class Initialized
DEBUG - 2016-10-26 12:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 12:40:28 --> Input Class Initialized
INFO - 2016-10-26 12:40:28 --> Language Class Initialized
INFO - 2016-10-26 12:40:28 --> Loader Class Initialized
INFO - 2016-10-26 12:40:28 --> Helper loaded: url_helper
INFO - 2016-10-26 12:40:28 --> Helper loaded: form_helper
INFO - 2016-10-26 12:40:28 --> Database Driver Class Initialized
INFO - 2016-10-26 12:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 12:40:28 --> Controller Class Initialized
INFO - 2016-10-26 12:40:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 12:40:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 12:40:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 12:40:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 12:40:28 --> Final output sent to browser
DEBUG - 2016-10-26 12:40:28 --> Total execution time: 0.0153
INFO - 2016-10-26 13:18:39 --> Config Class Initialized
INFO - 2016-10-26 13:18:39 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:18:39 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:18:39 --> Utf8 Class Initialized
INFO - 2016-10-26 13:18:39 --> URI Class Initialized
INFO - 2016-10-26 13:18:39 --> Router Class Initialized
INFO - 2016-10-26 13:18:39 --> Output Class Initialized
INFO - 2016-10-26 13:18:39 --> Security Class Initialized
DEBUG - 2016-10-26 13:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:18:39 --> Input Class Initialized
INFO - 2016-10-26 13:18:39 --> Language Class Initialized
INFO - 2016-10-26 13:18:39 --> Loader Class Initialized
INFO - 2016-10-26 13:18:39 --> Helper loaded: url_helper
INFO - 2016-10-26 13:18:39 --> Helper loaded: form_helper
INFO - 2016-10-26 13:18:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:18:39 --> Controller Class Initialized
DEBUG - 2016-10-26 13:18:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-26 13:18:39 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 148
ERROR - 2016-10-26 13:18:39 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 148
INFO - 2016-10-26 13:18:39 --> Config Class Initialized
INFO - 2016-10-26 13:18:39 --> Hooks Class Initialized
DEBUG - 2016-10-26 13:18:39 --> UTF-8 Support Enabled
INFO - 2016-10-26 13:18:39 --> Utf8 Class Initialized
INFO - 2016-10-26 13:18:39 --> URI Class Initialized
DEBUG - 2016-10-26 13:18:39 --> No URI present. Default controller set.
INFO - 2016-10-26 13:18:39 --> Router Class Initialized
INFO - 2016-10-26 13:18:39 --> Output Class Initialized
INFO - 2016-10-26 13:18:39 --> Security Class Initialized
DEBUG - 2016-10-26 13:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 13:18:39 --> Input Class Initialized
INFO - 2016-10-26 13:18:39 --> Language Class Initialized
INFO - 2016-10-26 13:18:39 --> Loader Class Initialized
INFO - 2016-10-26 13:18:39 --> Helper loaded: url_helper
INFO - 2016-10-26 13:18:39 --> Helper loaded: form_helper
INFO - 2016-10-26 13:18:39 --> Database Driver Class Initialized
INFO - 2016-10-26 13:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 13:18:39 --> Controller Class Initialized
INFO - 2016-10-26 13:18:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 13:18:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 13:18:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 13:18:39 --> Final output sent to browser
DEBUG - 2016-10-26 13:18:39 --> Total execution time: 0.0152
INFO - 2016-10-26 15:22:07 --> Config Class Initialized
INFO - 2016-10-26 15:22:07 --> Hooks Class Initialized
DEBUG - 2016-10-26 15:22:07 --> UTF-8 Support Enabled
INFO - 2016-10-26 15:22:07 --> Utf8 Class Initialized
INFO - 2016-10-26 15:22:07 --> URI Class Initialized
DEBUG - 2016-10-26 15:22:07 --> No URI present. Default controller set.
INFO - 2016-10-26 15:22:07 --> Router Class Initialized
INFO - 2016-10-26 15:22:07 --> Output Class Initialized
INFO - 2016-10-26 15:22:07 --> Security Class Initialized
DEBUG - 2016-10-26 15:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 15:22:07 --> Input Class Initialized
INFO - 2016-10-26 15:22:07 --> Language Class Initialized
INFO - 2016-10-26 15:22:07 --> Loader Class Initialized
INFO - 2016-10-26 15:22:07 --> Helper loaded: url_helper
INFO - 2016-10-26 15:22:07 --> Helper loaded: form_helper
INFO - 2016-10-26 15:22:07 --> Database Driver Class Initialized
INFO - 2016-10-26 15:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 15:22:07 --> Controller Class Initialized
INFO - 2016-10-26 15:22:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 15:22:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 15:22:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 15:22:07 --> Final output sent to browser
DEBUG - 2016-10-26 15:22:07 --> Total execution time: 0.0564
INFO - 2016-10-26 15:22:09 --> Config Class Initialized
INFO - 2016-10-26 15:22:09 --> Hooks Class Initialized
DEBUG - 2016-10-26 15:22:09 --> UTF-8 Support Enabled
INFO - 2016-10-26 15:22:09 --> Utf8 Class Initialized
INFO - 2016-10-26 15:22:09 --> URI Class Initialized
DEBUG - 2016-10-26 15:22:09 --> No URI present. Default controller set.
INFO - 2016-10-26 15:22:09 --> Router Class Initialized
INFO - 2016-10-26 15:22:09 --> Output Class Initialized
INFO - 2016-10-26 15:22:09 --> Security Class Initialized
DEBUG - 2016-10-26 15:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 15:22:09 --> Input Class Initialized
INFO - 2016-10-26 15:22:09 --> Language Class Initialized
INFO - 2016-10-26 15:22:09 --> Loader Class Initialized
INFO - 2016-10-26 15:22:09 --> Helper loaded: url_helper
INFO - 2016-10-26 15:22:09 --> Helper loaded: form_helper
INFO - 2016-10-26 15:22:09 --> Database Driver Class Initialized
INFO - 2016-10-26 15:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 15:22:09 --> Controller Class Initialized
INFO - 2016-10-26 15:22:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 15:22:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 15:22:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 15:22:09 --> Final output sent to browser
DEBUG - 2016-10-26 15:22:09 --> Total execution time: 0.0160
INFO - 2016-10-26 15:22:49 --> Config Class Initialized
INFO - 2016-10-26 15:22:49 --> Hooks Class Initialized
DEBUG - 2016-10-26 15:22:49 --> UTF-8 Support Enabled
INFO - 2016-10-26 15:22:49 --> Utf8 Class Initialized
INFO - 2016-10-26 15:22:49 --> URI Class Initialized
DEBUG - 2016-10-26 15:22:49 --> No URI present. Default controller set.
INFO - 2016-10-26 15:22:49 --> Router Class Initialized
INFO - 2016-10-26 15:22:49 --> Output Class Initialized
INFO - 2016-10-26 15:22:49 --> Security Class Initialized
DEBUG - 2016-10-26 15:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 15:22:49 --> Input Class Initialized
INFO - 2016-10-26 15:22:49 --> Language Class Initialized
INFO - 2016-10-26 15:22:49 --> Loader Class Initialized
INFO - 2016-10-26 15:22:49 --> Helper loaded: url_helper
INFO - 2016-10-26 15:22:49 --> Helper loaded: form_helper
INFO - 2016-10-26 15:22:49 --> Database Driver Class Initialized
INFO - 2016-10-26 15:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 15:22:49 --> Controller Class Initialized
INFO - 2016-10-26 15:22:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 15:22:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 15:22:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 15:22:49 --> Final output sent to browser
DEBUG - 2016-10-26 15:22:49 --> Total execution time: 0.0164
INFO - 2016-10-26 15:44:13 --> Config Class Initialized
INFO - 2016-10-26 15:44:13 --> Hooks Class Initialized
DEBUG - 2016-10-26 15:44:13 --> UTF-8 Support Enabled
INFO - 2016-10-26 15:44:13 --> Utf8 Class Initialized
INFO - 2016-10-26 15:44:13 --> URI Class Initialized
DEBUG - 2016-10-26 15:44:13 --> No URI present. Default controller set.
INFO - 2016-10-26 15:44:13 --> Router Class Initialized
INFO - 2016-10-26 15:44:13 --> Output Class Initialized
INFO - 2016-10-26 15:44:13 --> Security Class Initialized
DEBUG - 2016-10-26 15:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 15:44:13 --> Input Class Initialized
INFO - 2016-10-26 15:44:13 --> Language Class Initialized
INFO - 2016-10-26 15:44:13 --> Loader Class Initialized
INFO - 2016-10-26 15:44:13 --> Helper loaded: url_helper
INFO - 2016-10-26 15:44:13 --> Helper loaded: form_helper
INFO - 2016-10-26 15:44:13 --> Database Driver Class Initialized
INFO - 2016-10-26 15:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 15:44:13 --> Controller Class Initialized
INFO - 2016-10-26 15:44:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 15:44:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 15:44:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 15:44:13 --> Final output sent to browser
DEBUG - 2016-10-26 15:44:13 --> Total execution time: 0.0169
INFO - 2016-10-26 15:53:44 --> Config Class Initialized
INFO - 2016-10-26 15:53:44 --> Hooks Class Initialized
DEBUG - 2016-10-26 15:53:44 --> UTF-8 Support Enabled
INFO - 2016-10-26 15:53:44 --> Utf8 Class Initialized
INFO - 2016-10-26 15:53:44 --> URI Class Initialized
DEBUG - 2016-10-26 15:53:44 --> No URI present. Default controller set.
INFO - 2016-10-26 15:53:44 --> Router Class Initialized
INFO - 2016-10-26 15:53:44 --> Output Class Initialized
INFO - 2016-10-26 15:53:44 --> Security Class Initialized
DEBUG - 2016-10-26 15:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 15:53:44 --> Input Class Initialized
INFO - 2016-10-26 15:53:44 --> Language Class Initialized
INFO - 2016-10-26 15:53:44 --> Loader Class Initialized
INFO - 2016-10-26 15:53:44 --> Helper loaded: url_helper
INFO - 2016-10-26 15:53:44 --> Helper loaded: form_helper
INFO - 2016-10-26 15:53:44 --> Database Driver Class Initialized
INFO - 2016-10-26 15:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 15:53:44 --> Controller Class Initialized
INFO - 2016-10-26 15:53:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 15:53:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 15:53:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 15:53:44 --> Final output sent to browser
DEBUG - 2016-10-26 15:53:44 --> Total execution time: 0.0164
INFO - 2016-10-26 15:53:47 --> Config Class Initialized
INFO - 2016-10-26 15:53:47 --> Hooks Class Initialized
DEBUG - 2016-10-26 15:53:47 --> UTF-8 Support Enabled
INFO - 2016-10-26 15:53:47 --> Utf8 Class Initialized
INFO - 2016-10-26 15:53:47 --> URI Class Initialized
DEBUG - 2016-10-26 15:53:47 --> No URI present. Default controller set.
INFO - 2016-10-26 15:53:47 --> Router Class Initialized
INFO - 2016-10-26 15:53:47 --> Output Class Initialized
INFO - 2016-10-26 15:53:47 --> Security Class Initialized
DEBUG - 2016-10-26 15:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 15:53:47 --> Input Class Initialized
INFO - 2016-10-26 15:53:47 --> Language Class Initialized
INFO - 2016-10-26 15:53:47 --> Loader Class Initialized
INFO - 2016-10-26 15:53:47 --> Helper loaded: url_helper
INFO - 2016-10-26 15:53:47 --> Helper loaded: form_helper
INFO - 2016-10-26 15:53:47 --> Database Driver Class Initialized
INFO - 2016-10-26 15:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 15:53:47 --> Controller Class Initialized
INFO - 2016-10-26 15:53:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 15:53:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 15:53:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 15:53:47 --> Final output sent to browser
DEBUG - 2016-10-26 15:53:47 --> Total execution time: 0.0157
INFO - 2016-10-26 15:54:17 --> Config Class Initialized
INFO - 2016-10-26 15:54:17 --> Hooks Class Initialized
DEBUG - 2016-10-26 15:54:17 --> UTF-8 Support Enabled
INFO - 2016-10-26 15:54:17 --> Utf8 Class Initialized
INFO - 2016-10-26 15:54:17 --> URI Class Initialized
DEBUG - 2016-10-26 15:54:17 --> No URI present. Default controller set.
INFO - 2016-10-26 15:54:17 --> Router Class Initialized
INFO - 2016-10-26 15:54:17 --> Output Class Initialized
INFO - 2016-10-26 15:54:17 --> Security Class Initialized
DEBUG - 2016-10-26 15:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 15:54:17 --> Input Class Initialized
INFO - 2016-10-26 15:54:17 --> Language Class Initialized
INFO - 2016-10-26 15:54:17 --> Loader Class Initialized
INFO - 2016-10-26 15:54:17 --> Helper loaded: url_helper
INFO - 2016-10-26 15:54:17 --> Helper loaded: form_helper
INFO - 2016-10-26 15:54:17 --> Database Driver Class Initialized
INFO - 2016-10-26 15:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 15:54:17 --> Controller Class Initialized
INFO - 2016-10-26 15:54:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 15:54:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 15:54:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 15:54:17 --> Final output sent to browser
DEBUG - 2016-10-26 15:54:17 --> Total execution time: 0.0196
INFO - 2016-10-26 16:30:25 --> Config Class Initialized
INFO - 2016-10-26 16:30:25 --> Hooks Class Initialized
DEBUG - 2016-10-26 16:30:25 --> UTF-8 Support Enabled
INFO - 2016-10-26 16:30:25 --> Utf8 Class Initialized
INFO - 2016-10-26 16:30:25 --> URI Class Initialized
DEBUG - 2016-10-26 16:30:25 --> No URI present. Default controller set.
INFO - 2016-10-26 16:30:25 --> Router Class Initialized
INFO - 2016-10-26 16:30:25 --> Output Class Initialized
INFO - 2016-10-26 16:30:25 --> Security Class Initialized
DEBUG - 2016-10-26 16:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 16:30:25 --> Input Class Initialized
INFO - 2016-10-26 16:30:25 --> Language Class Initialized
INFO - 2016-10-26 16:30:25 --> Loader Class Initialized
INFO - 2016-10-26 16:30:25 --> Helper loaded: url_helper
INFO - 2016-10-26 16:30:25 --> Helper loaded: form_helper
INFO - 2016-10-26 16:30:25 --> Database Driver Class Initialized
INFO - 2016-10-26 16:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 16:30:25 --> Controller Class Initialized
INFO - 2016-10-26 16:30:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 16:30:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 16:30:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 16:30:25 --> Final output sent to browser
DEBUG - 2016-10-26 16:30:25 --> Total execution time: 0.0163
INFO - 2016-10-26 16:30:58 --> Config Class Initialized
INFO - 2016-10-26 16:30:58 --> Hooks Class Initialized
DEBUG - 2016-10-26 16:30:58 --> UTF-8 Support Enabled
INFO - 2016-10-26 16:30:58 --> Utf8 Class Initialized
INFO - 2016-10-26 16:30:58 --> URI Class Initialized
INFO - 2016-10-26 16:30:58 --> Router Class Initialized
INFO - 2016-10-26 16:30:58 --> Output Class Initialized
INFO - 2016-10-26 16:30:58 --> Security Class Initialized
DEBUG - 2016-10-26 16:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 16:30:58 --> Input Class Initialized
INFO - 2016-10-26 16:30:58 --> Language Class Initialized
INFO - 2016-10-26 16:30:58 --> Loader Class Initialized
INFO - 2016-10-26 16:30:58 --> Helper loaded: url_helper
INFO - 2016-10-26 16:30:58 --> Helper loaded: form_helper
INFO - 2016-10-26 16:30:58 --> Database Driver Class Initialized
INFO - 2016-10-26 16:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 16:30:58 --> Controller Class Initialized
DEBUG - 2016-10-26 16:30:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-26 16:30:58 --> Model Class Initialized
INFO - 2016-10-26 16:30:58 --> Final output sent to browser
DEBUG - 2016-10-26 16:30:58 --> Total execution time: 0.0180
INFO - 2016-10-26 16:31:07 --> Config Class Initialized
INFO - 2016-10-26 16:31:07 --> Hooks Class Initialized
DEBUG - 2016-10-26 16:31:07 --> UTF-8 Support Enabled
INFO - 2016-10-26 16:31:07 --> Utf8 Class Initialized
INFO - 2016-10-26 16:31:07 --> URI Class Initialized
INFO - 2016-10-26 16:31:07 --> Router Class Initialized
INFO - 2016-10-26 16:31:07 --> Output Class Initialized
INFO - 2016-10-26 16:31:07 --> Security Class Initialized
DEBUG - 2016-10-26 16:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 16:31:07 --> Input Class Initialized
INFO - 2016-10-26 16:31:07 --> Language Class Initialized
INFO - 2016-10-26 16:31:07 --> Loader Class Initialized
INFO - 2016-10-26 16:31:07 --> Helper loaded: url_helper
INFO - 2016-10-26 16:31:07 --> Helper loaded: form_helper
INFO - 2016-10-26 16:31:07 --> Database Driver Class Initialized
INFO - 2016-10-26 16:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 16:31:07 --> Controller Class Initialized
DEBUG - 2016-10-26 16:31:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-26 16:31:07 --> Model Class Initialized
INFO - 2016-10-26 16:31:07 --> Final output sent to browser
DEBUG - 2016-10-26 16:31:07 --> Total execution time: 0.0171
INFO - 2016-10-26 16:31:07 --> Config Class Initialized
INFO - 2016-10-26 16:31:07 --> Hooks Class Initialized
DEBUG - 2016-10-26 16:31:07 --> UTF-8 Support Enabled
INFO - 2016-10-26 16:31:07 --> Utf8 Class Initialized
INFO - 2016-10-26 16:31:07 --> URI Class Initialized
DEBUG - 2016-10-26 16:31:07 --> No URI present. Default controller set.
INFO - 2016-10-26 16:31:07 --> Router Class Initialized
INFO - 2016-10-26 16:31:07 --> Output Class Initialized
INFO - 2016-10-26 16:31:07 --> Security Class Initialized
DEBUG - 2016-10-26 16:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 16:31:07 --> Input Class Initialized
INFO - 2016-10-26 16:31:07 --> Language Class Initialized
INFO - 2016-10-26 16:31:07 --> Loader Class Initialized
INFO - 2016-10-26 16:31:07 --> Helper loaded: url_helper
INFO - 2016-10-26 16:31:07 --> Helper loaded: form_helper
INFO - 2016-10-26 16:31:07 --> Database Driver Class Initialized
INFO - 2016-10-26 16:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 16:31:07 --> Controller Class Initialized
INFO - 2016-10-26 16:31:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 16:31:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 16:31:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 16:31:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 16:31:07 --> Final output sent to browser
DEBUG - 2016-10-26 16:31:07 --> Total execution time: 0.0149
INFO - 2016-10-26 16:31:09 --> Config Class Initialized
INFO - 2016-10-26 16:31:09 --> Hooks Class Initialized
DEBUG - 2016-10-26 16:31:09 --> UTF-8 Support Enabled
INFO - 2016-10-26 16:31:09 --> Utf8 Class Initialized
INFO - 2016-10-26 16:31:09 --> URI Class Initialized
DEBUG - 2016-10-26 16:31:09 --> No URI present. Default controller set.
INFO - 2016-10-26 16:31:09 --> Router Class Initialized
INFO - 2016-10-26 16:31:09 --> Output Class Initialized
INFO - 2016-10-26 16:31:09 --> Security Class Initialized
DEBUG - 2016-10-26 16:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 16:31:09 --> Input Class Initialized
INFO - 2016-10-26 16:31:09 --> Language Class Initialized
INFO - 2016-10-26 16:31:09 --> Loader Class Initialized
INFO - 2016-10-26 16:31:09 --> Helper loaded: url_helper
INFO - 2016-10-26 16:31:09 --> Helper loaded: form_helper
INFO - 2016-10-26 16:31:09 --> Database Driver Class Initialized
INFO - 2016-10-26 16:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 16:31:09 --> Controller Class Initialized
INFO - 2016-10-26 16:31:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 16:31:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 16:31:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 16:31:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 16:31:09 --> Final output sent to browser
DEBUG - 2016-10-26 16:31:09 --> Total execution time: 0.0172
INFO - 2016-10-26 16:39:13 --> Config Class Initialized
INFO - 2016-10-26 16:39:13 --> Hooks Class Initialized
DEBUG - 2016-10-26 16:39:13 --> UTF-8 Support Enabled
INFO - 2016-10-26 16:39:13 --> Utf8 Class Initialized
INFO - 2016-10-26 16:39:13 --> URI Class Initialized
DEBUG - 2016-10-26 16:39:13 --> No URI present. Default controller set.
INFO - 2016-10-26 16:39:13 --> Router Class Initialized
INFO - 2016-10-26 16:39:13 --> Output Class Initialized
INFO - 2016-10-26 16:39:13 --> Security Class Initialized
DEBUG - 2016-10-26 16:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 16:39:13 --> Input Class Initialized
INFO - 2016-10-26 16:39:13 --> Language Class Initialized
INFO - 2016-10-26 16:39:13 --> Loader Class Initialized
INFO - 2016-10-26 16:39:13 --> Helper loaded: url_helper
INFO - 2016-10-26 16:39:13 --> Helper loaded: form_helper
INFO - 2016-10-26 16:39:13 --> Database Driver Class Initialized
INFO - 2016-10-26 16:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 16:39:13 --> Controller Class Initialized
INFO - 2016-10-26 16:39:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 16:39:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 16:39:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 16:39:13 --> Final output sent to browser
DEBUG - 2016-10-26 16:39:13 --> Total execution time: 0.0178
INFO - 2016-10-26 16:39:22 --> Config Class Initialized
INFO - 2016-10-26 16:39:22 --> Hooks Class Initialized
DEBUG - 2016-10-26 16:39:22 --> UTF-8 Support Enabled
INFO - 2016-10-26 16:39:22 --> Utf8 Class Initialized
INFO - 2016-10-26 16:39:22 --> URI Class Initialized
INFO - 2016-10-26 16:39:22 --> Router Class Initialized
INFO - 2016-10-26 16:39:22 --> Output Class Initialized
INFO - 2016-10-26 16:39:22 --> Security Class Initialized
DEBUG - 2016-10-26 16:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 16:39:22 --> Input Class Initialized
INFO - 2016-10-26 16:39:22 --> Language Class Initialized
INFO - 2016-10-26 16:39:22 --> Loader Class Initialized
INFO - 2016-10-26 16:39:22 --> Helper loaded: url_helper
INFO - 2016-10-26 16:39:22 --> Helper loaded: form_helper
INFO - 2016-10-26 16:39:22 --> Database Driver Class Initialized
INFO - 2016-10-26 16:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 16:39:22 --> Controller Class Initialized
DEBUG - 2016-10-26 16:39:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-26 16:39:22 --> Model Class Initialized
INFO - 2016-10-26 16:39:22 --> Final output sent to browser
DEBUG - 2016-10-26 16:39:22 --> Total execution time: 0.0205
INFO - 2016-10-26 16:39:22 --> Config Class Initialized
INFO - 2016-10-26 16:39:22 --> Hooks Class Initialized
DEBUG - 2016-10-26 16:39:22 --> UTF-8 Support Enabled
INFO - 2016-10-26 16:39:22 --> Utf8 Class Initialized
INFO - 2016-10-26 16:39:22 --> URI Class Initialized
DEBUG - 2016-10-26 16:39:22 --> No URI present. Default controller set.
INFO - 2016-10-26 16:39:22 --> Router Class Initialized
INFO - 2016-10-26 16:39:22 --> Output Class Initialized
INFO - 2016-10-26 16:39:22 --> Security Class Initialized
DEBUG - 2016-10-26 16:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 16:39:22 --> Input Class Initialized
INFO - 2016-10-26 16:39:22 --> Language Class Initialized
INFO - 2016-10-26 16:39:22 --> Loader Class Initialized
INFO - 2016-10-26 16:39:22 --> Helper loaded: url_helper
INFO - 2016-10-26 16:39:22 --> Helper loaded: form_helper
INFO - 2016-10-26 16:39:22 --> Database Driver Class Initialized
INFO - 2016-10-26 16:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 16:39:22 --> Controller Class Initialized
INFO - 2016-10-26 16:39:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 16:39:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 16:39:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 16:39:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 16:39:22 --> Final output sent to browser
DEBUG - 2016-10-26 16:39:22 --> Total execution time: 0.0151
INFO - 2016-10-26 16:39:27 --> Config Class Initialized
INFO - 2016-10-26 16:39:27 --> Hooks Class Initialized
DEBUG - 2016-10-26 16:39:27 --> UTF-8 Support Enabled
INFO - 2016-10-26 16:39:27 --> Utf8 Class Initialized
INFO - 2016-10-26 16:39:27 --> URI Class Initialized
INFO - 2016-10-26 16:39:27 --> Router Class Initialized
INFO - 2016-10-26 16:39:27 --> Output Class Initialized
INFO - 2016-10-26 16:39:27 --> Security Class Initialized
DEBUG - 2016-10-26 16:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 16:39:27 --> Input Class Initialized
INFO - 2016-10-26 16:39:27 --> Language Class Initialized
INFO - 2016-10-26 16:39:27 --> Loader Class Initialized
INFO - 2016-10-26 16:39:27 --> Helper loaded: url_helper
INFO - 2016-10-26 16:39:27 --> Helper loaded: form_helper
INFO - 2016-10-26 16:39:27 --> Database Driver Class Initialized
INFO - 2016-10-26 16:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 16:39:27 --> Controller Class Initialized
DEBUG - 2016-10-26 16:39:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-26 16:39:27 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 148
ERROR - 2016-10-26 16:39:27 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 148
INFO - 2016-10-26 16:39:27 --> Config Class Initialized
INFO - 2016-10-26 16:39:27 --> Hooks Class Initialized
DEBUG - 2016-10-26 16:39:27 --> UTF-8 Support Enabled
INFO - 2016-10-26 16:39:27 --> Utf8 Class Initialized
INFO - 2016-10-26 16:39:27 --> URI Class Initialized
DEBUG - 2016-10-26 16:39:27 --> No URI present. Default controller set.
INFO - 2016-10-26 16:39:27 --> Router Class Initialized
INFO - 2016-10-26 16:39:27 --> Output Class Initialized
INFO - 2016-10-26 16:39:27 --> Security Class Initialized
DEBUG - 2016-10-26 16:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 16:39:27 --> Input Class Initialized
INFO - 2016-10-26 16:39:27 --> Language Class Initialized
INFO - 2016-10-26 16:39:27 --> Loader Class Initialized
INFO - 2016-10-26 16:39:27 --> Helper loaded: url_helper
INFO - 2016-10-26 16:39:27 --> Helper loaded: form_helper
INFO - 2016-10-26 16:39:27 --> Database Driver Class Initialized
INFO - 2016-10-26 16:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 16:39:27 --> Controller Class Initialized
INFO - 2016-10-26 16:39:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 16:39:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 16:39:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 16:39:27 --> Final output sent to browser
DEBUG - 2016-10-26 16:39:27 --> Total execution time: 0.0150
INFO - 2016-10-26 16:40:28 --> Config Class Initialized
INFO - 2016-10-26 16:40:28 --> Hooks Class Initialized
DEBUG - 2016-10-26 16:40:28 --> UTF-8 Support Enabled
INFO - 2016-10-26 16:40:28 --> Utf8 Class Initialized
INFO - 2016-10-26 16:40:28 --> URI Class Initialized
DEBUG - 2016-10-26 16:40:28 --> No URI present. Default controller set.
INFO - 2016-10-26 16:40:28 --> Router Class Initialized
INFO - 2016-10-26 16:40:28 --> Output Class Initialized
INFO - 2016-10-26 16:40:28 --> Security Class Initialized
DEBUG - 2016-10-26 16:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 16:40:28 --> Input Class Initialized
INFO - 2016-10-26 16:40:28 --> Language Class Initialized
INFO - 2016-10-26 16:40:28 --> Loader Class Initialized
INFO - 2016-10-26 16:40:28 --> Helper loaded: url_helper
INFO - 2016-10-26 16:40:28 --> Helper loaded: form_helper
INFO - 2016-10-26 16:40:28 --> Database Driver Class Initialized
INFO - 2016-10-26 16:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 16:40:28 --> Controller Class Initialized
INFO - 2016-10-26 16:40:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 16:40:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 16:40:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 16:40:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 16:40:28 --> Final output sent to browser
DEBUG - 2016-10-26 16:40:28 --> Total execution time: 0.0197
INFO - 2016-10-26 16:44:46 --> Config Class Initialized
INFO - 2016-10-26 16:44:46 --> Hooks Class Initialized
DEBUG - 2016-10-26 16:44:46 --> UTF-8 Support Enabled
INFO - 2016-10-26 16:44:46 --> Utf8 Class Initialized
INFO - 2016-10-26 16:44:46 --> URI Class Initialized
DEBUG - 2016-10-26 16:44:46 --> No URI present. Default controller set.
INFO - 2016-10-26 16:44:46 --> Router Class Initialized
INFO - 2016-10-26 16:44:46 --> Output Class Initialized
INFO - 2016-10-26 16:44:46 --> Security Class Initialized
DEBUG - 2016-10-26 16:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 16:44:46 --> Input Class Initialized
INFO - 2016-10-26 16:44:46 --> Language Class Initialized
INFO - 2016-10-26 16:44:46 --> Loader Class Initialized
INFO - 2016-10-26 16:44:46 --> Helper loaded: url_helper
INFO - 2016-10-26 16:44:46 --> Helper loaded: form_helper
INFO - 2016-10-26 16:44:46 --> Database Driver Class Initialized
INFO - 2016-10-26 16:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 16:44:46 --> Controller Class Initialized
INFO - 2016-10-26 16:44:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 16:44:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 16:44:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 16:44:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 16:44:46 --> Final output sent to browser
DEBUG - 2016-10-26 16:44:46 --> Total execution time: 0.0168
INFO - 2016-10-26 16:57:50 --> Config Class Initialized
INFO - 2016-10-26 16:57:50 --> Hooks Class Initialized
DEBUG - 2016-10-26 16:57:50 --> UTF-8 Support Enabled
INFO - 2016-10-26 16:57:50 --> Utf8 Class Initialized
INFO - 2016-10-26 16:57:50 --> URI Class Initialized
DEBUG - 2016-10-26 16:57:50 --> No URI present. Default controller set.
INFO - 2016-10-26 16:57:50 --> Router Class Initialized
INFO - 2016-10-26 16:57:50 --> Output Class Initialized
INFO - 2016-10-26 16:57:50 --> Security Class Initialized
DEBUG - 2016-10-26 16:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 16:57:50 --> Input Class Initialized
INFO - 2016-10-26 16:57:50 --> Language Class Initialized
INFO - 2016-10-26 16:57:50 --> Loader Class Initialized
INFO - 2016-10-26 16:57:50 --> Helper loaded: url_helper
INFO - 2016-10-26 16:57:50 --> Helper loaded: form_helper
INFO - 2016-10-26 16:57:50 --> Database Driver Class Initialized
INFO - 2016-10-26 16:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 16:57:50 --> Controller Class Initialized
INFO - 2016-10-26 16:57:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 16:57:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 16:57:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 16:57:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 16:57:50 --> Final output sent to browser
DEBUG - 2016-10-26 16:57:50 --> Total execution time: 0.0169
INFO - 2016-10-26 16:57:50 --> Config Class Initialized
INFO - 2016-10-26 16:57:50 --> Hooks Class Initialized
DEBUG - 2016-10-26 16:57:50 --> UTF-8 Support Enabled
INFO - 2016-10-26 16:57:50 --> Utf8 Class Initialized
INFO - 2016-10-26 16:57:50 --> URI Class Initialized
DEBUG - 2016-10-26 16:57:50 --> No URI present. Default controller set.
INFO - 2016-10-26 16:57:50 --> Router Class Initialized
INFO - 2016-10-26 16:57:50 --> Output Class Initialized
INFO - 2016-10-26 16:57:50 --> Security Class Initialized
DEBUG - 2016-10-26 16:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 16:57:50 --> Input Class Initialized
INFO - 2016-10-26 16:57:50 --> Language Class Initialized
INFO - 2016-10-26 16:57:50 --> Loader Class Initialized
INFO - 2016-10-26 16:57:50 --> Helper loaded: url_helper
INFO - 2016-10-26 16:57:50 --> Helper loaded: form_helper
INFO - 2016-10-26 16:57:50 --> Database Driver Class Initialized
INFO - 2016-10-26 16:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 16:57:50 --> Controller Class Initialized
INFO - 2016-10-26 16:57:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 16:57:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 16:57:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 16:57:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 16:57:50 --> Final output sent to browser
DEBUG - 2016-10-26 16:57:50 --> Total execution time: 0.0164
INFO - 2016-10-26 16:57:51 --> Config Class Initialized
INFO - 2016-10-26 16:57:51 --> Hooks Class Initialized
DEBUG - 2016-10-26 16:57:51 --> UTF-8 Support Enabled
INFO - 2016-10-26 16:57:51 --> Utf8 Class Initialized
INFO - 2016-10-26 16:57:51 --> URI Class Initialized
DEBUG - 2016-10-26 16:57:51 --> No URI present. Default controller set.
INFO - 2016-10-26 16:57:51 --> Router Class Initialized
INFO - 2016-10-26 16:57:51 --> Output Class Initialized
INFO - 2016-10-26 16:57:51 --> Security Class Initialized
DEBUG - 2016-10-26 16:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 16:57:51 --> Input Class Initialized
INFO - 2016-10-26 16:57:51 --> Language Class Initialized
INFO - 2016-10-26 16:57:51 --> Loader Class Initialized
INFO - 2016-10-26 16:57:51 --> Helper loaded: url_helper
INFO - 2016-10-26 16:57:51 --> Helper loaded: form_helper
INFO - 2016-10-26 16:57:51 --> Database Driver Class Initialized
INFO - 2016-10-26 16:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 16:57:51 --> Controller Class Initialized
INFO - 2016-10-26 16:57:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 16:57:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 16:57:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 16:57:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 16:57:51 --> Final output sent to browser
DEBUG - 2016-10-26 16:57:51 --> Total execution time: 0.0168
INFO - 2016-10-26 16:58:30 --> Config Class Initialized
INFO - 2016-10-26 16:58:30 --> Hooks Class Initialized
DEBUG - 2016-10-26 16:58:30 --> UTF-8 Support Enabled
INFO - 2016-10-26 16:58:30 --> Utf8 Class Initialized
INFO - 2016-10-26 16:58:30 --> URI Class Initialized
INFO - 2016-10-26 16:58:30 --> Router Class Initialized
INFO - 2016-10-26 16:58:30 --> Output Class Initialized
INFO - 2016-10-26 16:58:30 --> Security Class Initialized
DEBUG - 2016-10-26 16:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 16:58:30 --> Input Class Initialized
INFO - 2016-10-26 16:58:30 --> Language Class Initialized
INFO - 2016-10-26 16:58:30 --> Loader Class Initialized
INFO - 2016-10-26 16:58:30 --> Helper loaded: url_helper
INFO - 2016-10-26 16:58:30 --> Helper loaded: form_helper
INFO - 2016-10-26 16:58:30 --> Database Driver Class Initialized
INFO - 2016-10-26 16:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 16:58:30 --> Controller Class Initialized
DEBUG - 2016-10-26 16:58:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-26 16:58:30 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 148
ERROR - 2016-10-26 16:58:30 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 148
INFO - 2016-10-26 16:58:30 --> Config Class Initialized
INFO - 2016-10-26 16:58:30 --> Hooks Class Initialized
DEBUG - 2016-10-26 16:58:30 --> UTF-8 Support Enabled
INFO - 2016-10-26 16:58:30 --> Utf8 Class Initialized
INFO - 2016-10-26 16:58:30 --> URI Class Initialized
DEBUG - 2016-10-26 16:58:30 --> No URI present. Default controller set.
INFO - 2016-10-26 16:58:30 --> Router Class Initialized
INFO - 2016-10-26 16:58:30 --> Output Class Initialized
INFO - 2016-10-26 16:58:30 --> Security Class Initialized
DEBUG - 2016-10-26 16:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 16:58:30 --> Input Class Initialized
INFO - 2016-10-26 16:58:30 --> Language Class Initialized
INFO - 2016-10-26 16:58:30 --> Loader Class Initialized
INFO - 2016-10-26 16:58:30 --> Helper loaded: url_helper
INFO - 2016-10-26 16:58:30 --> Helper loaded: form_helper
INFO - 2016-10-26 16:58:30 --> Database Driver Class Initialized
INFO - 2016-10-26 16:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 16:58:30 --> Controller Class Initialized
INFO - 2016-10-26 16:58:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 16:58:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 16:58:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 16:58:30 --> Final output sent to browser
DEBUG - 2016-10-26 16:58:30 --> Total execution time: 0.0155
INFO - 2016-10-26 16:58:32 --> Config Class Initialized
INFO - 2016-10-26 16:58:32 --> Hooks Class Initialized
DEBUG - 2016-10-26 16:58:32 --> UTF-8 Support Enabled
INFO - 2016-10-26 16:58:32 --> Utf8 Class Initialized
INFO - 2016-10-26 16:58:32 --> URI Class Initialized
DEBUG - 2016-10-26 16:58:32 --> No URI present. Default controller set.
INFO - 2016-10-26 16:58:32 --> Router Class Initialized
INFO - 2016-10-26 16:58:32 --> Output Class Initialized
INFO - 2016-10-26 16:58:32 --> Security Class Initialized
DEBUG - 2016-10-26 16:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 16:58:32 --> Input Class Initialized
INFO - 2016-10-26 16:58:32 --> Language Class Initialized
INFO - 2016-10-26 16:58:32 --> Loader Class Initialized
INFO - 2016-10-26 16:58:32 --> Helper loaded: url_helper
INFO - 2016-10-26 16:58:32 --> Helper loaded: form_helper
INFO - 2016-10-26 16:58:32 --> Database Driver Class Initialized
INFO - 2016-10-26 16:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 16:58:32 --> Controller Class Initialized
INFO - 2016-10-26 16:58:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 16:58:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 16:58:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 16:58:32 --> Final output sent to browser
DEBUG - 2016-10-26 16:58:32 --> Total execution time: 0.0160
INFO - 2016-10-26 17:05:04 --> Config Class Initialized
INFO - 2016-10-26 17:05:04 --> Hooks Class Initialized
DEBUG - 2016-10-26 17:05:04 --> UTF-8 Support Enabled
INFO - 2016-10-26 17:05:04 --> Utf8 Class Initialized
INFO - 2016-10-26 17:05:04 --> URI Class Initialized
DEBUG - 2016-10-26 17:05:04 --> No URI present. Default controller set.
INFO - 2016-10-26 17:05:04 --> Router Class Initialized
INFO - 2016-10-26 17:05:04 --> Output Class Initialized
INFO - 2016-10-26 17:05:04 --> Security Class Initialized
DEBUG - 2016-10-26 17:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 17:05:04 --> Input Class Initialized
INFO - 2016-10-26 17:05:04 --> Language Class Initialized
INFO - 2016-10-26 17:05:04 --> Loader Class Initialized
INFO - 2016-10-26 17:05:04 --> Helper loaded: url_helper
INFO - 2016-10-26 17:05:04 --> Helper loaded: form_helper
INFO - 2016-10-26 17:05:04 --> Database Driver Class Initialized
INFO - 2016-10-26 17:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 17:05:04 --> Controller Class Initialized
INFO - 2016-10-26 17:05:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 17:05:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 17:05:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 17:05:04 --> Final output sent to browser
DEBUG - 2016-10-26 17:05:04 --> Total execution time: 0.0360
INFO - 2016-10-26 17:05:12 --> Config Class Initialized
INFO - 2016-10-26 17:05:12 --> Hooks Class Initialized
DEBUG - 2016-10-26 17:05:12 --> UTF-8 Support Enabled
INFO - 2016-10-26 17:05:12 --> Utf8 Class Initialized
INFO - 2016-10-26 17:05:12 --> URI Class Initialized
INFO - 2016-10-26 17:05:12 --> Router Class Initialized
INFO - 2016-10-26 17:05:12 --> Output Class Initialized
INFO - 2016-10-26 17:05:12 --> Security Class Initialized
DEBUG - 2016-10-26 17:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 17:05:12 --> Input Class Initialized
INFO - 2016-10-26 17:05:12 --> Language Class Initialized
INFO - 2016-10-26 17:05:12 --> Loader Class Initialized
INFO - 2016-10-26 17:05:12 --> Helper loaded: url_helper
INFO - 2016-10-26 17:05:12 --> Helper loaded: form_helper
INFO - 2016-10-26 17:05:12 --> Database Driver Class Initialized
INFO - 2016-10-26 17:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 17:05:12 --> Controller Class Initialized
DEBUG - 2016-10-26 17:05:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-26 17:05:12 --> Model Class Initialized
INFO - 2016-10-26 17:05:12 --> Final output sent to browser
DEBUG - 2016-10-26 17:05:12 --> Total execution time: 0.0176
INFO - 2016-10-26 17:05:17 --> Config Class Initialized
INFO - 2016-10-26 17:05:17 --> Hooks Class Initialized
DEBUG - 2016-10-26 17:05:17 --> UTF-8 Support Enabled
INFO - 2016-10-26 17:05:17 --> Utf8 Class Initialized
INFO - 2016-10-26 17:05:17 --> URI Class Initialized
INFO - 2016-10-26 17:05:17 --> Router Class Initialized
INFO - 2016-10-26 17:05:17 --> Output Class Initialized
INFO - 2016-10-26 17:05:17 --> Security Class Initialized
DEBUG - 2016-10-26 17:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 17:05:17 --> Input Class Initialized
INFO - 2016-10-26 17:05:17 --> Language Class Initialized
INFO - 2016-10-26 17:05:17 --> Loader Class Initialized
INFO - 2016-10-26 17:05:17 --> Helper loaded: url_helper
INFO - 2016-10-26 17:05:17 --> Helper loaded: form_helper
INFO - 2016-10-26 17:05:17 --> Database Driver Class Initialized
INFO - 2016-10-26 17:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 17:05:17 --> Controller Class Initialized
DEBUG - 2016-10-26 17:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-26 17:05:17 --> Model Class Initialized
INFO - 2016-10-26 17:05:17 --> Final output sent to browser
DEBUG - 2016-10-26 17:05:17 --> Total execution time: 0.0182
INFO - 2016-10-26 17:05:22 --> Config Class Initialized
INFO - 2016-10-26 17:05:22 --> Hooks Class Initialized
DEBUG - 2016-10-26 17:05:22 --> UTF-8 Support Enabled
INFO - 2016-10-26 17:05:22 --> Utf8 Class Initialized
INFO - 2016-10-26 17:05:22 --> URI Class Initialized
INFO - 2016-10-26 17:05:22 --> Router Class Initialized
INFO - 2016-10-26 17:05:22 --> Output Class Initialized
INFO - 2016-10-26 17:05:22 --> Security Class Initialized
DEBUG - 2016-10-26 17:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 17:05:22 --> Input Class Initialized
INFO - 2016-10-26 17:05:22 --> Language Class Initialized
INFO - 2016-10-26 17:05:22 --> Loader Class Initialized
INFO - 2016-10-26 17:05:22 --> Helper loaded: url_helper
INFO - 2016-10-26 17:05:22 --> Helper loaded: form_helper
INFO - 2016-10-26 17:05:22 --> Database Driver Class Initialized
INFO - 2016-10-26 17:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 17:05:22 --> Controller Class Initialized
DEBUG - 2016-10-26 17:05:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-26 17:05:22 --> Model Class Initialized
INFO - 2016-10-26 17:05:22 --> Final output sent to browser
DEBUG - 2016-10-26 17:05:22 --> Total execution time: 0.0166
INFO - 2016-10-26 17:05:22 --> Config Class Initialized
INFO - 2016-10-26 17:05:22 --> Hooks Class Initialized
DEBUG - 2016-10-26 17:05:22 --> UTF-8 Support Enabled
INFO - 2016-10-26 17:05:22 --> Utf8 Class Initialized
INFO - 2016-10-26 17:05:22 --> URI Class Initialized
DEBUG - 2016-10-26 17:05:22 --> No URI present. Default controller set.
INFO - 2016-10-26 17:05:22 --> Router Class Initialized
INFO - 2016-10-26 17:05:22 --> Output Class Initialized
INFO - 2016-10-26 17:05:22 --> Security Class Initialized
DEBUG - 2016-10-26 17:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 17:05:22 --> Input Class Initialized
INFO - 2016-10-26 17:05:22 --> Language Class Initialized
INFO - 2016-10-26 17:05:22 --> Loader Class Initialized
INFO - 2016-10-26 17:05:22 --> Helper loaded: url_helper
INFO - 2016-10-26 17:05:22 --> Helper loaded: form_helper
INFO - 2016-10-26 17:05:22 --> Database Driver Class Initialized
INFO - 2016-10-26 17:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 17:05:22 --> Controller Class Initialized
INFO - 2016-10-26 17:05:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 17:05:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 17:05:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 17:05:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 17:05:22 --> Final output sent to browser
DEBUG - 2016-10-26 17:05:22 --> Total execution time: 0.0193
INFO - 2016-10-26 17:05:33 --> Config Class Initialized
INFO - 2016-10-26 17:05:33 --> Hooks Class Initialized
DEBUG - 2016-10-26 17:05:33 --> UTF-8 Support Enabled
INFO - 2016-10-26 17:05:33 --> Utf8 Class Initialized
INFO - 2016-10-26 17:05:33 --> URI Class Initialized
INFO - 2016-10-26 17:05:33 --> Router Class Initialized
INFO - 2016-10-26 17:05:33 --> Output Class Initialized
INFO - 2016-10-26 17:05:33 --> Security Class Initialized
DEBUG - 2016-10-26 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 17:05:33 --> Input Class Initialized
INFO - 2016-10-26 17:05:33 --> Language Class Initialized
INFO - 2016-10-26 17:05:33 --> Loader Class Initialized
INFO - 2016-10-26 17:05:33 --> Helper loaded: url_helper
INFO - 2016-10-26 17:05:33 --> Helper loaded: form_helper
INFO - 2016-10-26 17:05:33 --> Database Driver Class Initialized
INFO - 2016-10-26 17:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 17:05:33 --> Controller Class Initialized
DEBUG - 2016-10-26 17:05:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-26 17:05:33 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 148
ERROR - 2016-10-26 17:05:33 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 148
INFO - 2016-10-26 17:05:33 --> Config Class Initialized
INFO - 2016-10-26 17:05:33 --> Hooks Class Initialized
DEBUG - 2016-10-26 17:05:33 --> UTF-8 Support Enabled
INFO - 2016-10-26 17:05:33 --> Utf8 Class Initialized
INFO - 2016-10-26 17:05:33 --> URI Class Initialized
DEBUG - 2016-10-26 17:05:33 --> No URI present. Default controller set.
INFO - 2016-10-26 17:05:33 --> Router Class Initialized
INFO - 2016-10-26 17:05:33 --> Output Class Initialized
INFO - 2016-10-26 17:05:33 --> Security Class Initialized
DEBUG - 2016-10-26 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 17:05:33 --> Input Class Initialized
INFO - 2016-10-26 17:05:33 --> Language Class Initialized
INFO - 2016-10-26 17:05:33 --> Loader Class Initialized
INFO - 2016-10-26 17:05:33 --> Helper loaded: url_helper
INFO - 2016-10-26 17:05:33 --> Helper loaded: form_helper
INFO - 2016-10-26 17:05:33 --> Database Driver Class Initialized
INFO - 2016-10-26 17:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 17:05:33 --> Controller Class Initialized
INFO - 2016-10-26 17:05:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 17:05:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 17:05:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 17:05:33 --> Final output sent to browser
DEBUG - 2016-10-26 17:05:33 --> Total execution time: 0.0156
INFO - 2016-10-26 17:07:19 --> Config Class Initialized
INFO - 2016-10-26 17:07:19 --> Hooks Class Initialized
DEBUG - 2016-10-26 17:07:19 --> UTF-8 Support Enabled
INFO - 2016-10-26 17:07:19 --> Utf8 Class Initialized
INFO - 2016-10-26 17:07:19 --> URI Class Initialized
DEBUG - 2016-10-26 17:07:19 --> No URI present. Default controller set.
INFO - 2016-10-26 17:07:19 --> Router Class Initialized
INFO - 2016-10-26 17:07:19 --> Output Class Initialized
INFO - 2016-10-26 17:07:19 --> Security Class Initialized
DEBUG - 2016-10-26 17:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 17:07:19 --> Input Class Initialized
INFO - 2016-10-26 17:07:19 --> Language Class Initialized
INFO - 2016-10-26 17:07:19 --> Loader Class Initialized
INFO - 2016-10-26 17:07:19 --> Helper loaded: url_helper
INFO - 2016-10-26 17:07:19 --> Helper loaded: form_helper
INFO - 2016-10-26 17:07:19 --> Database Driver Class Initialized
INFO - 2016-10-26 17:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 17:07:19 --> Controller Class Initialized
INFO - 2016-10-26 17:07:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 17:07:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 17:07:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 17:07:19 --> Final output sent to browser
DEBUG - 2016-10-26 17:07:19 --> Total execution time: 0.0237
INFO - 2016-10-26 17:31:39 --> Config Class Initialized
INFO - 2016-10-26 17:31:39 --> Hooks Class Initialized
DEBUG - 2016-10-26 17:31:39 --> UTF-8 Support Enabled
INFO - 2016-10-26 17:31:39 --> Utf8 Class Initialized
INFO - 2016-10-26 17:31:39 --> URI Class Initialized
DEBUG - 2016-10-26 17:31:39 --> No URI present. Default controller set.
INFO - 2016-10-26 17:31:39 --> Router Class Initialized
INFO - 2016-10-26 17:31:39 --> Output Class Initialized
INFO - 2016-10-26 17:31:39 --> Security Class Initialized
DEBUG - 2016-10-26 17:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 17:31:39 --> Input Class Initialized
INFO - 2016-10-26 17:31:39 --> Language Class Initialized
INFO - 2016-10-26 17:31:39 --> Loader Class Initialized
INFO - 2016-10-26 17:31:39 --> Helper loaded: url_helper
INFO - 2016-10-26 17:31:39 --> Helper loaded: form_helper
INFO - 2016-10-26 17:31:39 --> Database Driver Class Initialized
INFO - 2016-10-26 17:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 17:31:39 --> Controller Class Initialized
INFO - 2016-10-26 17:31:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 17:31:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 17:31:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 17:31:39 --> Final output sent to browser
DEBUG - 2016-10-26 17:31:39 --> Total execution time: 0.0188
INFO - 2016-10-26 17:35:38 --> Config Class Initialized
INFO - 2016-10-26 17:35:38 --> Hooks Class Initialized
DEBUG - 2016-10-26 17:35:38 --> UTF-8 Support Enabled
INFO - 2016-10-26 17:35:38 --> Utf8 Class Initialized
INFO - 2016-10-26 17:35:38 --> URI Class Initialized
DEBUG - 2016-10-26 17:35:38 --> No URI present. Default controller set.
INFO - 2016-10-26 17:35:38 --> Router Class Initialized
INFO - 2016-10-26 17:35:38 --> Output Class Initialized
INFO - 2016-10-26 17:35:38 --> Security Class Initialized
DEBUG - 2016-10-26 17:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 17:35:38 --> Input Class Initialized
INFO - 2016-10-26 17:35:38 --> Language Class Initialized
INFO - 2016-10-26 17:35:38 --> Loader Class Initialized
INFO - 2016-10-26 17:35:38 --> Helper loaded: url_helper
INFO - 2016-10-26 17:35:38 --> Helper loaded: form_helper
INFO - 2016-10-26 17:35:38 --> Database Driver Class Initialized
INFO - 2016-10-26 17:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 17:35:38 --> Controller Class Initialized
INFO - 2016-10-26 17:35:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 17:35:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 17:35:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 17:35:38 --> Final output sent to browser
DEBUG - 2016-10-26 17:35:38 --> Total execution time: 0.0163
INFO - 2016-10-26 17:37:23 --> Config Class Initialized
INFO - 2016-10-26 17:37:23 --> Hooks Class Initialized
DEBUG - 2016-10-26 17:37:23 --> UTF-8 Support Enabled
INFO - 2016-10-26 17:37:23 --> Utf8 Class Initialized
INFO - 2016-10-26 17:37:23 --> URI Class Initialized
DEBUG - 2016-10-26 17:37:23 --> No URI present. Default controller set.
INFO - 2016-10-26 17:37:23 --> Router Class Initialized
INFO - 2016-10-26 17:37:23 --> Output Class Initialized
INFO - 2016-10-26 17:37:23 --> Security Class Initialized
DEBUG - 2016-10-26 17:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 17:37:23 --> Input Class Initialized
INFO - 2016-10-26 17:37:23 --> Language Class Initialized
INFO - 2016-10-26 17:37:23 --> Loader Class Initialized
INFO - 2016-10-26 17:37:23 --> Helper loaded: url_helper
INFO - 2016-10-26 17:37:23 --> Helper loaded: form_helper
INFO - 2016-10-26 17:37:23 --> Database Driver Class Initialized
INFO - 2016-10-26 17:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 17:37:23 --> Controller Class Initialized
INFO - 2016-10-26 17:37:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 17:37:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 17:37:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 17:37:23 --> Final output sent to browser
DEBUG - 2016-10-26 17:37:23 --> Total execution time: 0.0170
INFO - 2016-10-26 17:38:47 --> Config Class Initialized
INFO - 2016-10-26 17:38:47 --> Hooks Class Initialized
DEBUG - 2016-10-26 17:38:47 --> UTF-8 Support Enabled
INFO - 2016-10-26 17:38:47 --> Utf8 Class Initialized
INFO - 2016-10-26 17:38:47 --> URI Class Initialized
DEBUG - 2016-10-26 17:38:47 --> No URI present. Default controller set.
INFO - 2016-10-26 17:38:47 --> Router Class Initialized
INFO - 2016-10-26 17:38:47 --> Output Class Initialized
INFO - 2016-10-26 17:38:47 --> Security Class Initialized
DEBUG - 2016-10-26 17:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 17:38:47 --> Input Class Initialized
INFO - 2016-10-26 17:38:47 --> Language Class Initialized
INFO - 2016-10-26 17:38:47 --> Loader Class Initialized
INFO - 2016-10-26 17:38:47 --> Helper loaded: url_helper
INFO - 2016-10-26 17:38:47 --> Helper loaded: form_helper
INFO - 2016-10-26 17:38:47 --> Database Driver Class Initialized
INFO - 2016-10-26 17:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 17:38:47 --> Controller Class Initialized
INFO - 2016-10-26 17:38:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 17:38:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 17:38:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 17:38:47 --> Final output sent to browser
DEBUG - 2016-10-26 17:38:47 --> Total execution time: 0.0190
INFO - 2016-10-26 17:52:15 --> Config Class Initialized
INFO - 2016-10-26 17:52:15 --> Hooks Class Initialized
DEBUG - 2016-10-26 17:52:15 --> UTF-8 Support Enabled
INFO - 2016-10-26 17:52:15 --> Utf8 Class Initialized
INFO - 2016-10-26 17:52:15 --> URI Class Initialized
DEBUG - 2016-10-26 17:52:15 --> No URI present. Default controller set.
INFO - 2016-10-26 17:52:15 --> Router Class Initialized
INFO - 2016-10-26 17:52:15 --> Output Class Initialized
INFO - 2016-10-26 17:52:15 --> Security Class Initialized
DEBUG - 2016-10-26 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 17:52:15 --> Input Class Initialized
INFO - 2016-10-26 17:52:15 --> Language Class Initialized
INFO - 2016-10-26 17:52:15 --> Loader Class Initialized
INFO - 2016-10-26 17:52:15 --> Helper loaded: url_helper
INFO - 2016-10-26 17:52:15 --> Helper loaded: form_helper
INFO - 2016-10-26 17:52:15 --> Database Driver Class Initialized
INFO - 2016-10-26 17:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 17:52:15 --> Controller Class Initialized
INFO - 2016-10-26 17:52:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 17:52:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 17:52:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 17:52:15 --> Final output sent to browser
DEBUG - 2016-10-26 17:52:15 --> Total execution time: 0.0174
INFO - 2016-10-26 17:52:31 --> Config Class Initialized
INFO - 2016-10-26 17:52:31 --> Hooks Class Initialized
DEBUG - 2016-10-26 17:52:31 --> UTF-8 Support Enabled
INFO - 2016-10-26 17:52:31 --> Utf8 Class Initialized
INFO - 2016-10-26 17:52:31 --> URI Class Initialized
DEBUG - 2016-10-26 17:52:31 --> No URI present. Default controller set.
INFO - 2016-10-26 17:52:31 --> Router Class Initialized
INFO - 2016-10-26 17:52:31 --> Output Class Initialized
INFO - 2016-10-26 17:52:31 --> Security Class Initialized
DEBUG - 2016-10-26 17:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 17:52:31 --> Input Class Initialized
INFO - 2016-10-26 17:52:31 --> Language Class Initialized
INFO - 2016-10-26 17:52:31 --> Loader Class Initialized
INFO - 2016-10-26 17:52:31 --> Helper loaded: url_helper
INFO - 2016-10-26 17:52:31 --> Helper loaded: form_helper
INFO - 2016-10-26 17:52:31 --> Database Driver Class Initialized
INFO - 2016-10-26 17:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 17:52:31 --> Controller Class Initialized
INFO - 2016-10-26 17:52:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 17:52:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 17:52:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 17:52:31 --> Final output sent to browser
DEBUG - 2016-10-26 17:52:31 --> Total execution time: 0.0163
INFO - 2016-10-26 18:00:49 --> Config Class Initialized
INFO - 2016-10-26 18:00:49 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:00:49 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:00:49 --> Utf8 Class Initialized
INFO - 2016-10-26 18:00:49 --> URI Class Initialized
DEBUG - 2016-10-26 18:00:49 --> No URI present. Default controller set.
INFO - 2016-10-26 18:00:49 --> Router Class Initialized
INFO - 2016-10-26 18:00:49 --> Output Class Initialized
INFO - 2016-10-26 18:00:49 --> Security Class Initialized
DEBUG - 2016-10-26 18:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:00:49 --> Input Class Initialized
INFO - 2016-10-26 18:00:49 --> Language Class Initialized
INFO - 2016-10-26 18:00:49 --> Loader Class Initialized
INFO - 2016-10-26 18:00:49 --> Helper loaded: url_helper
INFO - 2016-10-26 18:00:49 --> Helper loaded: form_helper
INFO - 2016-10-26 18:00:49 --> Database Driver Class Initialized
INFO - 2016-10-26 18:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:00:49 --> Controller Class Initialized
INFO - 2016-10-26 18:00:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:00:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 18:00:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:00:49 --> Final output sent to browser
DEBUG - 2016-10-26 18:00:49 --> Total execution time: 0.0177
INFO - 2016-10-26 18:22:22 --> Config Class Initialized
INFO - 2016-10-26 18:22:22 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:22:22 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:22:22 --> Utf8 Class Initialized
INFO - 2016-10-26 18:22:22 --> URI Class Initialized
DEBUG - 2016-10-26 18:22:22 --> No URI present. Default controller set.
INFO - 2016-10-26 18:22:22 --> Router Class Initialized
INFO - 2016-10-26 18:22:22 --> Output Class Initialized
INFO - 2016-10-26 18:22:22 --> Security Class Initialized
DEBUG - 2016-10-26 18:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:22:22 --> Input Class Initialized
INFO - 2016-10-26 18:22:22 --> Language Class Initialized
INFO - 2016-10-26 18:22:22 --> Loader Class Initialized
INFO - 2016-10-26 18:22:22 --> Helper loaded: url_helper
INFO - 2016-10-26 18:22:22 --> Helper loaded: form_helper
INFO - 2016-10-26 18:22:22 --> Database Driver Class Initialized
INFO - 2016-10-26 18:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:22:22 --> Controller Class Initialized
INFO - 2016-10-26 18:22:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:22:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 18:22:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:22:22 --> Final output sent to browser
DEBUG - 2016-10-26 18:22:22 --> Total execution time: 0.0196
INFO - 2016-10-26 18:22:24 --> Config Class Initialized
INFO - 2016-10-26 18:22:24 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:22:24 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:22:24 --> Utf8 Class Initialized
INFO - 2016-10-26 18:22:24 --> URI Class Initialized
DEBUG - 2016-10-26 18:22:24 --> No URI present. Default controller set.
INFO - 2016-10-26 18:22:24 --> Router Class Initialized
INFO - 2016-10-26 18:22:24 --> Output Class Initialized
INFO - 2016-10-26 18:22:24 --> Security Class Initialized
DEBUG - 2016-10-26 18:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:22:24 --> Input Class Initialized
INFO - 2016-10-26 18:22:24 --> Language Class Initialized
INFO - 2016-10-26 18:22:24 --> Loader Class Initialized
INFO - 2016-10-26 18:22:24 --> Helper loaded: url_helper
INFO - 2016-10-26 18:22:24 --> Helper loaded: form_helper
INFO - 2016-10-26 18:22:24 --> Database Driver Class Initialized
INFO - 2016-10-26 18:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:22:24 --> Controller Class Initialized
INFO - 2016-10-26 18:22:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:22:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 18:22:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:22:24 --> Final output sent to browser
DEBUG - 2016-10-26 18:22:24 --> Total execution time: 0.0171
INFO - 2016-10-26 18:22:34 --> Config Class Initialized
INFO - 2016-10-26 18:22:34 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:22:34 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:22:34 --> Utf8 Class Initialized
INFO - 2016-10-26 18:22:34 --> URI Class Initialized
INFO - 2016-10-26 18:22:34 --> Router Class Initialized
INFO - 2016-10-26 18:22:34 --> Output Class Initialized
INFO - 2016-10-26 18:22:34 --> Security Class Initialized
DEBUG - 2016-10-26 18:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:22:34 --> Input Class Initialized
INFO - 2016-10-26 18:22:34 --> Language Class Initialized
INFO - 2016-10-26 18:22:34 --> Loader Class Initialized
INFO - 2016-10-26 18:22:34 --> Helper loaded: url_helper
INFO - 2016-10-26 18:22:34 --> Helper loaded: form_helper
INFO - 2016-10-26 18:22:34 --> Database Driver Class Initialized
INFO - 2016-10-26 18:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:22:34 --> Controller Class Initialized
DEBUG - 2016-10-26 18:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-26 18:22:34 --> Model Class Initialized
INFO - 2016-10-26 18:22:34 --> Final output sent to browser
DEBUG - 2016-10-26 18:22:34 --> Total execution time: 0.0178
INFO - 2016-10-26 18:22:34 --> Config Class Initialized
INFO - 2016-10-26 18:22:34 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:22:34 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:22:34 --> Utf8 Class Initialized
INFO - 2016-10-26 18:22:34 --> URI Class Initialized
DEBUG - 2016-10-26 18:22:34 --> No URI present. Default controller set.
INFO - 2016-10-26 18:22:34 --> Router Class Initialized
INFO - 2016-10-26 18:22:34 --> Output Class Initialized
INFO - 2016-10-26 18:22:34 --> Security Class Initialized
DEBUG - 2016-10-26 18:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:22:34 --> Input Class Initialized
INFO - 2016-10-26 18:22:34 --> Language Class Initialized
INFO - 2016-10-26 18:22:34 --> Loader Class Initialized
INFO - 2016-10-26 18:22:34 --> Helper loaded: url_helper
INFO - 2016-10-26 18:22:34 --> Helper loaded: form_helper
INFO - 2016-10-26 18:22:34 --> Database Driver Class Initialized
INFO - 2016-10-26 18:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:22:34 --> Controller Class Initialized
INFO - 2016-10-26 18:22:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:22:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 18:22:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 18:22:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:22:34 --> Final output sent to browser
DEBUG - 2016-10-26 18:22:34 --> Total execution time: 0.0151
INFO - 2016-10-26 18:22:38 --> Config Class Initialized
INFO - 2016-10-26 18:22:38 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:22:38 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:22:38 --> Utf8 Class Initialized
INFO - 2016-10-26 18:22:38 --> URI Class Initialized
INFO - 2016-10-26 18:22:38 --> Router Class Initialized
INFO - 2016-10-26 18:22:38 --> Output Class Initialized
INFO - 2016-10-26 18:22:38 --> Security Class Initialized
DEBUG - 2016-10-26 18:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:22:38 --> Input Class Initialized
INFO - 2016-10-26 18:22:38 --> Language Class Initialized
INFO - 2016-10-26 18:22:38 --> Loader Class Initialized
INFO - 2016-10-26 18:22:38 --> Helper loaded: url_helper
INFO - 2016-10-26 18:22:38 --> Helper loaded: form_helper
INFO - 2016-10-26 18:22:38 --> Database Driver Class Initialized
INFO - 2016-10-26 18:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:22:38 --> Controller Class Initialized
DEBUG - 2016-10-26 18:22:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-26 18:22:38 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 148
ERROR - 2016-10-26 18:22:38 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 148
INFO - 2016-10-26 18:22:38 --> Config Class Initialized
INFO - 2016-10-26 18:22:38 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:22:38 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:22:38 --> Utf8 Class Initialized
INFO - 2016-10-26 18:22:38 --> URI Class Initialized
DEBUG - 2016-10-26 18:22:38 --> No URI present. Default controller set.
INFO - 2016-10-26 18:22:38 --> Router Class Initialized
INFO - 2016-10-26 18:22:38 --> Output Class Initialized
INFO - 2016-10-26 18:22:38 --> Security Class Initialized
DEBUG - 2016-10-26 18:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:22:38 --> Input Class Initialized
INFO - 2016-10-26 18:22:38 --> Language Class Initialized
INFO - 2016-10-26 18:22:38 --> Loader Class Initialized
INFO - 2016-10-26 18:22:38 --> Helper loaded: url_helper
INFO - 2016-10-26 18:22:38 --> Helper loaded: form_helper
INFO - 2016-10-26 18:22:38 --> Database Driver Class Initialized
INFO - 2016-10-26 18:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:22:38 --> Controller Class Initialized
INFO - 2016-10-26 18:22:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:22:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 18:22:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:22:38 --> Final output sent to browser
DEBUG - 2016-10-26 18:22:38 --> Total execution time: 0.0153
INFO - 2016-10-26 18:23:32 --> Config Class Initialized
INFO - 2016-10-26 18:23:32 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:23:32 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:23:32 --> Utf8 Class Initialized
INFO - 2016-10-26 18:23:32 --> URI Class Initialized
INFO - 2016-10-26 18:23:32 --> Router Class Initialized
INFO - 2016-10-26 18:23:32 --> Output Class Initialized
INFO - 2016-10-26 18:23:32 --> Security Class Initialized
DEBUG - 2016-10-26 18:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:23:32 --> Input Class Initialized
INFO - 2016-10-26 18:23:32 --> Language Class Initialized
INFO - 2016-10-26 18:23:32 --> Loader Class Initialized
INFO - 2016-10-26 18:23:32 --> Helper loaded: url_helper
INFO - 2016-10-26 18:23:32 --> Helper loaded: form_helper
INFO - 2016-10-26 18:23:32 --> Database Driver Class Initialized
INFO - 2016-10-26 18:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:23:32 --> Controller Class Initialized
DEBUG - 2016-10-26 18:23:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-26 18:23:32 --> Model Class Initialized
INFO - 2016-10-26 18:23:32 --> Final output sent to browser
DEBUG - 2016-10-26 18:23:32 --> Total execution time: 0.0173
INFO - 2016-10-26 18:23:32 --> Config Class Initialized
INFO - 2016-10-26 18:23:32 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:23:32 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:23:32 --> Utf8 Class Initialized
INFO - 2016-10-26 18:23:32 --> URI Class Initialized
DEBUG - 2016-10-26 18:23:32 --> No URI present. Default controller set.
INFO - 2016-10-26 18:23:32 --> Router Class Initialized
INFO - 2016-10-26 18:23:32 --> Output Class Initialized
INFO - 2016-10-26 18:23:32 --> Security Class Initialized
DEBUG - 2016-10-26 18:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:23:32 --> Input Class Initialized
INFO - 2016-10-26 18:23:32 --> Language Class Initialized
INFO - 2016-10-26 18:23:32 --> Loader Class Initialized
INFO - 2016-10-26 18:23:32 --> Helper loaded: url_helper
INFO - 2016-10-26 18:23:32 --> Helper loaded: form_helper
INFO - 2016-10-26 18:23:32 --> Database Driver Class Initialized
INFO - 2016-10-26 18:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:23:32 --> Controller Class Initialized
INFO - 2016-10-26 18:23:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:23:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 18:23:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/apple_leave.php
INFO - 2016-10-26 18:23:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/my_leave.php
INFO - 2016-10-26 18:23:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 18:23:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:23:32 --> Final output sent to browser
DEBUG - 2016-10-26 18:23:32 --> Total execution time: 0.0155
INFO - 2016-10-26 18:23:41 --> Config Class Initialized
INFO - 2016-10-26 18:23:41 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:23:41 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:23:41 --> Utf8 Class Initialized
INFO - 2016-10-26 18:23:41 --> URI Class Initialized
INFO - 2016-10-26 18:23:41 --> Router Class Initialized
INFO - 2016-10-26 18:23:41 --> Output Class Initialized
INFO - 2016-10-26 18:23:41 --> Security Class Initialized
DEBUG - 2016-10-26 18:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:23:41 --> Input Class Initialized
INFO - 2016-10-26 18:23:41 --> Language Class Initialized
INFO - 2016-10-26 18:23:41 --> Loader Class Initialized
INFO - 2016-10-26 18:23:41 --> Helper loaded: url_helper
INFO - 2016-10-26 18:23:41 --> Helper loaded: form_helper
INFO - 2016-10-26 18:23:41 --> Database Driver Class Initialized
INFO - 2016-10-26 18:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:23:41 --> Controller Class Initialized
INFO - 2016-10-26 18:23:41 --> Form Validation Class Initialized
INFO - 2016-10-26 18:23:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-26 18:23:41 --> Final output sent to browser
DEBUG - 2016-10-26 18:23:41 --> Total execution time: 0.0175
INFO - 2016-10-26 18:23:48 --> Config Class Initialized
INFO - 2016-10-26 18:23:48 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:23:48 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:23:48 --> Utf8 Class Initialized
INFO - 2016-10-26 18:23:48 --> URI Class Initialized
INFO - 2016-10-26 18:23:48 --> Router Class Initialized
INFO - 2016-10-26 18:23:48 --> Output Class Initialized
INFO - 2016-10-26 18:23:48 --> Security Class Initialized
DEBUG - 2016-10-26 18:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:23:48 --> Input Class Initialized
INFO - 2016-10-26 18:23:48 --> Language Class Initialized
INFO - 2016-10-26 18:23:48 --> Loader Class Initialized
INFO - 2016-10-26 18:23:48 --> Helper loaded: url_helper
INFO - 2016-10-26 18:23:48 --> Helper loaded: form_helper
INFO - 2016-10-26 18:23:48 --> Database Driver Class Initialized
INFO - 2016-10-26 18:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:23:48 --> Controller Class Initialized
INFO - 2016-10-26 18:23:48 --> Form Validation Class Initialized
INFO - 2016-10-26 18:23:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-26 18:23:48 --> Final output sent to browser
DEBUG - 2016-10-26 18:23:48 --> Total execution time: 0.0174
INFO - 2016-10-26 18:23:52 --> Config Class Initialized
INFO - 2016-10-26 18:23:52 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:23:52 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:23:52 --> Utf8 Class Initialized
INFO - 2016-10-26 18:23:52 --> URI Class Initialized
INFO - 2016-10-26 18:23:52 --> Router Class Initialized
INFO - 2016-10-26 18:23:52 --> Output Class Initialized
INFO - 2016-10-26 18:23:52 --> Security Class Initialized
DEBUG - 2016-10-26 18:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:23:52 --> Input Class Initialized
INFO - 2016-10-26 18:23:52 --> Language Class Initialized
INFO - 2016-10-26 18:23:52 --> Loader Class Initialized
INFO - 2016-10-26 18:23:52 --> Helper loaded: url_helper
INFO - 2016-10-26 18:23:52 --> Helper loaded: form_helper
INFO - 2016-10-26 18:23:52 --> Database Driver Class Initialized
INFO - 2016-10-26 18:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:23:52 --> Controller Class Initialized
INFO - 2016-10-26 18:23:52 --> Form Validation Class Initialized
INFO - 2016-10-26 18:23:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-26 18:23:52 --> Final output sent to browser
DEBUG - 2016-10-26 18:23:52 --> Total execution time: 0.0170
INFO - 2016-10-26 18:23:55 --> Config Class Initialized
INFO - 2016-10-26 18:23:55 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:23:55 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:23:55 --> Utf8 Class Initialized
INFO - 2016-10-26 18:23:55 --> URI Class Initialized
INFO - 2016-10-26 18:23:55 --> Router Class Initialized
INFO - 2016-10-26 18:23:55 --> Output Class Initialized
INFO - 2016-10-26 18:23:55 --> Security Class Initialized
DEBUG - 2016-10-26 18:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:23:55 --> Input Class Initialized
INFO - 2016-10-26 18:23:55 --> Language Class Initialized
INFO - 2016-10-26 18:23:55 --> Loader Class Initialized
INFO - 2016-10-26 18:23:55 --> Helper loaded: url_helper
INFO - 2016-10-26 18:23:55 --> Helper loaded: form_helper
INFO - 2016-10-26 18:23:55 --> Database Driver Class Initialized
INFO - 2016-10-26 18:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:23:55 --> Controller Class Initialized
INFO - 2016-10-26 18:23:55 --> Form Validation Class Initialized
INFO - 2016-10-26 18:23:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-26 18:23:55 --> Final output sent to browser
DEBUG - 2016-10-26 18:23:55 --> Total execution time: 0.0172
INFO - 2016-10-26 18:24:02 --> Config Class Initialized
INFO - 2016-10-26 18:24:02 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:24:02 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:24:02 --> Utf8 Class Initialized
INFO - 2016-10-26 18:24:02 --> URI Class Initialized
INFO - 2016-10-26 18:24:02 --> Router Class Initialized
INFO - 2016-10-26 18:24:02 --> Output Class Initialized
INFO - 2016-10-26 18:24:02 --> Security Class Initialized
DEBUG - 2016-10-26 18:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:24:02 --> Input Class Initialized
INFO - 2016-10-26 18:24:02 --> Language Class Initialized
INFO - 2016-10-26 18:24:02 --> Loader Class Initialized
INFO - 2016-10-26 18:24:02 --> Helper loaded: url_helper
INFO - 2016-10-26 18:24:02 --> Helper loaded: form_helper
INFO - 2016-10-26 18:24:02 --> Database Driver Class Initialized
INFO - 2016-10-26 18:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:24:02 --> Controller Class Initialized
INFO - 2016-10-26 18:24:02 --> Form Validation Class Initialized
INFO - 2016-10-26 18:24:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-26 18:24:02 --> Final output sent to browser
DEBUG - 2016-10-26 18:24:02 --> Total execution time: 0.0174
INFO - 2016-10-26 18:24:06 --> Config Class Initialized
INFO - 2016-10-26 18:24:06 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:24:06 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:24:06 --> Utf8 Class Initialized
INFO - 2016-10-26 18:24:06 --> URI Class Initialized
INFO - 2016-10-26 18:24:06 --> Router Class Initialized
INFO - 2016-10-26 18:24:06 --> Output Class Initialized
INFO - 2016-10-26 18:24:06 --> Security Class Initialized
DEBUG - 2016-10-26 18:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:24:06 --> Input Class Initialized
INFO - 2016-10-26 18:24:06 --> Language Class Initialized
INFO - 2016-10-26 18:24:06 --> Loader Class Initialized
INFO - 2016-10-26 18:24:06 --> Helper loaded: url_helper
INFO - 2016-10-26 18:24:06 --> Helper loaded: form_helper
INFO - 2016-10-26 18:24:06 --> Database Driver Class Initialized
INFO - 2016-10-26 18:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:24:06 --> Controller Class Initialized
INFO - 2016-10-26 18:24:06 --> Form Validation Class Initialized
INFO - 2016-10-26 18:24:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-26 18:24:06 --> Final output sent to browser
DEBUG - 2016-10-26 18:24:06 --> Total execution time: 0.0173
INFO - 2016-10-26 18:24:12 --> Config Class Initialized
INFO - 2016-10-26 18:24:12 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:24:12 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:24:12 --> Utf8 Class Initialized
INFO - 2016-10-26 18:24:12 --> URI Class Initialized
INFO - 2016-10-26 18:24:12 --> Router Class Initialized
INFO - 2016-10-26 18:24:12 --> Output Class Initialized
INFO - 2016-10-26 18:24:12 --> Security Class Initialized
DEBUG - 2016-10-26 18:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:24:12 --> Input Class Initialized
INFO - 2016-10-26 18:24:12 --> Language Class Initialized
INFO - 2016-10-26 18:24:12 --> Loader Class Initialized
INFO - 2016-10-26 18:24:12 --> Helper loaded: url_helper
INFO - 2016-10-26 18:24:12 --> Helper loaded: form_helper
INFO - 2016-10-26 18:24:12 --> Database Driver Class Initialized
INFO - 2016-10-26 18:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:24:12 --> Controller Class Initialized
INFO - 2016-10-26 18:24:12 --> Form Validation Class Initialized
INFO - 2016-10-26 18:24:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-26 18:24:12 --> Final output sent to browser
DEBUG - 2016-10-26 18:24:12 --> Total execution time: 0.0270
INFO - 2016-10-26 18:24:16 --> Config Class Initialized
INFO - 2016-10-26 18:24:16 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:24:16 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:24:16 --> Utf8 Class Initialized
INFO - 2016-10-26 18:24:16 --> URI Class Initialized
INFO - 2016-10-26 18:24:16 --> Router Class Initialized
INFO - 2016-10-26 18:24:16 --> Output Class Initialized
INFO - 2016-10-26 18:24:16 --> Security Class Initialized
DEBUG - 2016-10-26 18:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:24:16 --> Input Class Initialized
INFO - 2016-10-26 18:24:16 --> Language Class Initialized
INFO - 2016-10-26 18:24:16 --> Loader Class Initialized
INFO - 2016-10-26 18:24:16 --> Helper loaded: url_helper
INFO - 2016-10-26 18:24:16 --> Helper loaded: form_helper
INFO - 2016-10-26 18:24:16 --> Database Driver Class Initialized
INFO - 2016-10-26 18:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:24:16 --> Controller Class Initialized
INFO - 2016-10-26 18:24:16 --> Form Validation Class Initialized
INFO - 2016-10-26 18:24:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-26 18:24:16 --> Final output sent to browser
DEBUG - 2016-10-26 18:24:16 --> Total execution time: 0.0170
INFO - 2016-10-26 18:24:23 --> Config Class Initialized
INFO - 2016-10-26 18:24:23 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:24:23 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:24:23 --> Utf8 Class Initialized
INFO - 2016-10-26 18:24:23 --> URI Class Initialized
INFO - 2016-10-26 18:24:23 --> Router Class Initialized
INFO - 2016-10-26 18:24:23 --> Output Class Initialized
INFO - 2016-10-26 18:24:23 --> Security Class Initialized
DEBUG - 2016-10-26 18:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:24:23 --> Input Class Initialized
INFO - 2016-10-26 18:24:23 --> Language Class Initialized
INFO - 2016-10-26 18:24:23 --> Loader Class Initialized
INFO - 2016-10-26 18:24:23 --> Helper loaded: url_helper
INFO - 2016-10-26 18:24:23 --> Helper loaded: form_helper
INFO - 2016-10-26 18:24:23 --> Database Driver Class Initialized
INFO - 2016-10-26 18:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:24:23 --> Controller Class Initialized
INFO - 2016-10-26 18:24:23 --> Form Validation Class Initialized
INFO - 2016-10-26 18:24:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-26 18:24:23 --> Final output sent to browser
DEBUG - 2016-10-26 18:24:23 --> Total execution time: 0.0183
INFO - 2016-10-26 18:24:28 --> Config Class Initialized
INFO - 2016-10-26 18:24:28 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:24:28 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:24:28 --> Utf8 Class Initialized
INFO - 2016-10-26 18:24:28 --> URI Class Initialized
INFO - 2016-10-26 18:24:28 --> Router Class Initialized
INFO - 2016-10-26 18:24:28 --> Output Class Initialized
INFO - 2016-10-26 18:24:28 --> Security Class Initialized
DEBUG - 2016-10-26 18:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:24:28 --> Input Class Initialized
INFO - 2016-10-26 18:24:28 --> Language Class Initialized
INFO - 2016-10-26 18:24:28 --> Loader Class Initialized
INFO - 2016-10-26 18:24:28 --> Helper loaded: url_helper
INFO - 2016-10-26 18:24:28 --> Helper loaded: form_helper
INFO - 2016-10-26 18:24:28 --> Database Driver Class Initialized
INFO - 2016-10-26 18:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:24:28 --> Controller Class Initialized
INFO - 2016-10-26 18:24:28 --> Form Validation Class Initialized
INFO - 2016-10-26 18:24:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-26 18:24:28 --> Final output sent to browser
DEBUG - 2016-10-26 18:24:28 --> Total execution time: 0.0290
INFO - 2016-10-26 18:24:32 --> Config Class Initialized
INFO - 2016-10-26 18:24:32 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:24:32 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:24:32 --> Utf8 Class Initialized
INFO - 2016-10-26 18:24:32 --> URI Class Initialized
INFO - 2016-10-26 18:24:32 --> Router Class Initialized
INFO - 2016-10-26 18:24:32 --> Output Class Initialized
INFO - 2016-10-26 18:24:32 --> Security Class Initialized
DEBUG - 2016-10-26 18:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:24:32 --> Input Class Initialized
INFO - 2016-10-26 18:24:32 --> Language Class Initialized
INFO - 2016-10-26 18:24:32 --> Loader Class Initialized
INFO - 2016-10-26 18:24:32 --> Helper loaded: url_helper
INFO - 2016-10-26 18:24:32 --> Helper loaded: form_helper
INFO - 2016-10-26 18:24:32 --> Database Driver Class Initialized
INFO - 2016-10-26 18:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:24:32 --> Controller Class Initialized
INFO - 2016-10-26 18:24:32 --> Form Validation Class Initialized
INFO - 2016-10-26 18:24:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-26 18:24:32 --> Final output sent to browser
DEBUG - 2016-10-26 18:24:32 --> Total execution time: 0.0172
INFO - 2016-10-26 18:26:03 --> Config Class Initialized
INFO - 2016-10-26 18:26:03 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:26:03 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:26:03 --> Utf8 Class Initialized
INFO - 2016-10-26 18:26:03 --> URI Class Initialized
DEBUG - 2016-10-26 18:26:03 --> No URI present. Default controller set.
INFO - 2016-10-26 18:26:03 --> Router Class Initialized
INFO - 2016-10-26 18:26:03 --> Output Class Initialized
INFO - 2016-10-26 18:26:03 --> Security Class Initialized
DEBUG - 2016-10-26 18:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:26:03 --> Input Class Initialized
INFO - 2016-10-26 18:26:03 --> Language Class Initialized
INFO - 2016-10-26 18:26:03 --> Loader Class Initialized
INFO - 2016-10-26 18:26:03 --> Helper loaded: url_helper
INFO - 2016-10-26 18:26:03 --> Helper loaded: form_helper
INFO - 2016-10-26 18:26:03 --> Database Driver Class Initialized
INFO - 2016-10-26 18:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:26:03 --> Controller Class Initialized
INFO - 2016-10-26 18:26:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:26:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 18:26:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/apple_leave.php
INFO - 2016-10-26 18:26:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/my_leave.php
INFO - 2016-10-26 18:26:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 18:26:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:26:03 --> Final output sent to browser
DEBUG - 2016-10-26 18:26:03 --> Total execution time: 0.0351
INFO - 2016-10-26 18:38:22 --> Config Class Initialized
INFO - 2016-10-26 18:38:22 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:38:22 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:38:22 --> Utf8 Class Initialized
INFO - 2016-10-26 18:38:22 --> URI Class Initialized
DEBUG - 2016-10-26 18:38:22 --> No URI present. Default controller set.
INFO - 2016-10-26 18:38:22 --> Router Class Initialized
INFO - 2016-10-26 18:38:22 --> Output Class Initialized
INFO - 2016-10-26 18:38:22 --> Security Class Initialized
DEBUG - 2016-10-26 18:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:38:22 --> Input Class Initialized
INFO - 2016-10-26 18:38:22 --> Language Class Initialized
INFO - 2016-10-26 18:38:22 --> Loader Class Initialized
INFO - 2016-10-26 18:38:22 --> Helper loaded: url_helper
INFO - 2016-10-26 18:38:22 --> Helper loaded: form_helper
INFO - 2016-10-26 18:38:22 --> Database Driver Class Initialized
INFO - 2016-10-26 18:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:38:22 --> Controller Class Initialized
INFO - 2016-10-26 18:38:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:38:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 18:38:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/employee/apply_leave.php
INFO - 2016-10-26 18:38:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/my_leave.php
INFO - 2016-10-26 18:38:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 18:38:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:38:22 --> Final output sent to browser
DEBUG - 2016-10-26 18:38:22 --> Total execution time: 0.0173
INFO - 2016-10-26 18:39:41 --> Config Class Initialized
INFO - 2016-10-26 18:39:41 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:39:41 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:39:41 --> Utf8 Class Initialized
INFO - 2016-10-26 18:39:41 --> URI Class Initialized
DEBUG - 2016-10-26 18:39:41 --> No URI present. Default controller set.
INFO - 2016-10-26 18:39:41 --> Router Class Initialized
INFO - 2016-10-26 18:39:41 --> Output Class Initialized
INFO - 2016-10-26 18:39:41 --> Security Class Initialized
DEBUG - 2016-10-26 18:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:39:41 --> Input Class Initialized
INFO - 2016-10-26 18:39:41 --> Language Class Initialized
INFO - 2016-10-26 18:39:41 --> Loader Class Initialized
INFO - 2016-10-26 18:39:41 --> Helper loaded: url_helper
INFO - 2016-10-26 18:39:41 --> Helper loaded: form_helper
INFO - 2016-10-26 18:39:41 --> Database Driver Class Initialized
INFO - 2016-10-26 18:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:39:41 --> Controller Class Initialized
INFO - 2016-10-26 18:39:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:39:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 18:39:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/employee/apply_leave.php
INFO - 2016-10-26 18:39:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/employee/my_leave.php
INFO - 2016-10-26 18:39:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 18:39:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:39:41 --> Final output sent to browser
DEBUG - 2016-10-26 18:39:41 --> Total execution time: 0.0170
INFO - 2016-10-26 18:40:02 --> Config Class Initialized
INFO - 2016-10-26 18:40:02 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:40:02 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:40:02 --> Utf8 Class Initialized
INFO - 2016-10-26 18:40:02 --> URI Class Initialized
DEBUG - 2016-10-26 18:40:02 --> No URI present. Default controller set.
INFO - 2016-10-26 18:40:02 --> Router Class Initialized
INFO - 2016-10-26 18:40:02 --> Output Class Initialized
INFO - 2016-10-26 18:40:02 --> Security Class Initialized
DEBUG - 2016-10-26 18:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:40:02 --> Input Class Initialized
INFO - 2016-10-26 18:40:02 --> Language Class Initialized
INFO - 2016-10-26 18:40:02 --> Loader Class Initialized
INFO - 2016-10-26 18:40:02 --> Helper loaded: url_helper
INFO - 2016-10-26 18:40:02 --> Helper loaded: form_helper
INFO - 2016-10-26 18:40:02 --> Database Driver Class Initialized
INFO - 2016-10-26 18:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:40:02 --> Controller Class Initialized
INFO - 2016-10-26 18:40:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:40:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 18:40:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/employee/apply_leave.php
INFO - 2016-10-26 18:40:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/employee/my_leave.php
INFO - 2016-10-26 18:40:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 18:40:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:40:02 --> Final output sent to browser
DEBUG - 2016-10-26 18:40:02 --> Total execution time: 0.0195
INFO - 2016-10-26 18:43:18 --> Config Class Initialized
INFO - 2016-10-26 18:43:18 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:43:18 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:43:18 --> Utf8 Class Initialized
INFO - 2016-10-26 18:43:18 --> URI Class Initialized
DEBUG - 2016-10-26 18:43:18 --> No URI present. Default controller set.
INFO - 2016-10-26 18:43:18 --> Router Class Initialized
INFO - 2016-10-26 18:43:18 --> Output Class Initialized
INFO - 2016-10-26 18:43:18 --> Security Class Initialized
DEBUG - 2016-10-26 18:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:43:18 --> Input Class Initialized
INFO - 2016-10-26 18:43:18 --> Language Class Initialized
INFO - 2016-10-26 18:43:18 --> Loader Class Initialized
INFO - 2016-10-26 18:43:18 --> Helper loaded: url_helper
INFO - 2016-10-26 18:43:18 --> Helper loaded: form_helper
INFO - 2016-10-26 18:43:18 --> Database Driver Class Initialized
INFO - 2016-10-26 18:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:43:18 --> Controller Class Initialized
INFO - 2016-10-26 18:43:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:43:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 18:43:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/employee/apply_leave.php
INFO - 2016-10-26 18:43:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/employee/my_leave.php
INFO - 2016-10-26 18:43:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 18:43:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:43:18 --> Final output sent to browser
DEBUG - 2016-10-26 18:43:18 --> Total execution time: 0.0209
INFO - 2016-10-26 18:43:20 --> Config Class Initialized
INFO - 2016-10-26 18:43:20 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:43:20 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:43:20 --> Utf8 Class Initialized
INFO - 2016-10-26 18:43:20 --> URI Class Initialized
INFO - 2016-10-26 18:43:20 --> Router Class Initialized
INFO - 2016-10-26 18:43:20 --> Output Class Initialized
INFO - 2016-10-26 18:43:20 --> Security Class Initialized
DEBUG - 2016-10-26 18:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:43:20 --> Input Class Initialized
INFO - 2016-10-26 18:43:20 --> Language Class Initialized
INFO - 2016-10-26 18:43:20 --> Loader Class Initialized
INFO - 2016-10-26 18:43:20 --> Helper loaded: url_helper
INFO - 2016-10-26 18:43:20 --> Helper loaded: form_helper
INFO - 2016-10-26 18:43:20 --> Database Driver Class Initialized
INFO - 2016-10-26 18:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:43:20 --> Controller Class Initialized
DEBUG - 2016-10-26 18:43:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-26 18:43:20 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 149
ERROR - 2016-10-26 18:43:20 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 149
INFO - 2016-10-26 18:43:20 --> Config Class Initialized
INFO - 2016-10-26 18:43:20 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:43:20 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:43:20 --> Utf8 Class Initialized
INFO - 2016-10-26 18:43:20 --> URI Class Initialized
DEBUG - 2016-10-26 18:43:20 --> No URI present. Default controller set.
INFO - 2016-10-26 18:43:20 --> Router Class Initialized
INFO - 2016-10-26 18:43:20 --> Output Class Initialized
INFO - 2016-10-26 18:43:20 --> Security Class Initialized
DEBUG - 2016-10-26 18:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:43:20 --> Input Class Initialized
INFO - 2016-10-26 18:43:20 --> Language Class Initialized
INFO - 2016-10-26 18:43:20 --> Loader Class Initialized
INFO - 2016-10-26 18:43:20 --> Helper loaded: url_helper
INFO - 2016-10-26 18:43:20 --> Helper loaded: form_helper
INFO - 2016-10-26 18:43:20 --> Database Driver Class Initialized
INFO - 2016-10-26 18:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:43:20 --> Controller Class Initialized
INFO - 2016-10-26 18:43:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:43:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 18:43:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:43:20 --> Final output sent to browser
DEBUG - 2016-10-26 18:43:20 --> Total execution time: 0.0151
INFO - 2016-10-26 18:43:26 --> Config Class Initialized
INFO - 2016-10-26 18:43:26 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:43:26 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:43:26 --> Utf8 Class Initialized
INFO - 2016-10-26 18:43:26 --> URI Class Initialized
INFO - 2016-10-26 18:43:26 --> Router Class Initialized
INFO - 2016-10-26 18:43:26 --> Output Class Initialized
INFO - 2016-10-26 18:43:26 --> Security Class Initialized
DEBUG - 2016-10-26 18:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:43:26 --> Input Class Initialized
INFO - 2016-10-26 18:43:26 --> Language Class Initialized
INFO - 2016-10-26 18:43:26 --> Loader Class Initialized
INFO - 2016-10-26 18:43:26 --> Helper loaded: url_helper
INFO - 2016-10-26 18:43:26 --> Helper loaded: form_helper
INFO - 2016-10-26 18:43:26 --> Database Driver Class Initialized
INFO - 2016-10-26 18:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:43:26 --> Controller Class Initialized
DEBUG - 2016-10-26 18:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-26 18:43:26 --> Model Class Initialized
INFO - 2016-10-26 18:43:26 --> Final output sent to browser
DEBUG - 2016-10-26 18:43:26 --> Total execution time: 0.0177
INFO - 2016-10-26 18:43:26 --> Config Class Initialized
INFO - 2016-10-26 18:43:26 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:43:26 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:43:26 --> Utf8 Class Initialized
INFO - 2016-10-26 18:43:26 --> URI Class Initialized
DEBUG - 2016-10-26 18:43:26 --> No URI present. Default controller set.
INFO - 2016-10-26 18:43:26 --> Router Class Initialized
INFO - 2016-10-26 18:43:26 --> Output Class Initialized
INFO - 2016-10-26 18:43:26 --> Security Class Initialized
DEBUG - 2016-10-26 18:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:43:26 --> Input Class Initialized
INFO - 2016-10-26 18:43:26 --> Language Class Initialized
INFO - 2016-10-26 18:43:26 --> Loader Class Initialized
INFO - 2016-10-26 18:43:26 --> Helper loaded: url_helper
INFO - 2016-10-26 18:43:26 --> Helper loaded: form_helper
INFO - 2016-10-26 18:43:26 --> Database Driver Class Initialized
INFO - 2016-10-26 18:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:43:26 --> Controller Class Initialized
INFO - 2016-10-26 18:43:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:43:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 18:43:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-26 18:43:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 18:43:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:43:26 --> Final output sent to browser
DEBUG - 2016-10-26 18:43:26 --> Total execution time: 0.0154
INFO - 2016-10-26 18:45:10 --> Config Class Initialized
INFO - 2016-10-26 18:45:10 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:45:10 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:45:10 --> Utf8 Class Initialized
INFO - 2016-10-26 18:45:10 --> URI Class Initialized
DEBUG - 2016-10-26 18:45:10 --> No URI present. Default controller set.
INFO - 2016-10-26 18:45:10 --> Router Class Initialized
INFO - 2016-10-26 18:45:10 --> Output Class Initialized
INFO - 2016-10-26 18:45:10 --> Security Class Initialized
DEBUG - 2016-10-26 18:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:45:10 --> Input Class Initialized
INFO - 2016-10-26 18:45:10 --> Language Class Initialized
INFO - 2016-10-26 18:45:10 --> Loader Class Initialized
INFO - 2016-10-26 18:45:10 --> Helper loaded: url_helper
INFO - 2016-10-26 18:45:10 --> Helper loaded: form_helper
INFO - 2016-10-26 18:45:10 --> Database Driver Class Initialized
INFO - 2016-10-26 18:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:45:10 --> Controller Class Initialized
INFO - 2016-10-26 18:45:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:45:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 18:45:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-26 18:45:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-26 18:45:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 18:45:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:45:10 --> Final output sent to browser
DEBUG - 2016-10-26 18:45:10 --> Total execution time: 0.0198
INFO - 2016-10-26 18:45:34 --> Config Class Initialized
INFO - 2016-10-26 18:45:34 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:45:34 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:45:34 --> Utf8 Class Initialized
INFO - 2016-10-26 18:45:34 --> URI Class Initialized
DEBUG - 2016-10-26 18:45:34 --> No URI present. Default controller set.
INFO - 2016-10-26 18:45:34 --> Router Class Initialized
INFO - 2016-10-26 18:45:34 --> Output Class Initialized
INFO - 2016-10-26 18:45:34 --> Security Class Initialized
DEBUG - 2016-10-26 18:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:45:34 --> Input Class Initialized
INFO - 2016-10-26 18:45:34 --> Language Class Initialized
INFO - 2016-10-26 18:45:34 --> Loader Class Initialized
INFO - 2016-10-26 18:45:34 --> Helper loaded: url_helper
INFO - 2016-10-26 18:45:34 --> Helper loaded: form_helper
INFO - 2016-10-26 18:45:34 --> Database Driver Class Initialized
INFO - 2016-10-26 18:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:45:34 --> Controller Class Initialized
INFO - 2016-10-26 18:45:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:45:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 18:45:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-26 18:45:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-26 18:45:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 18:45:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:45:34 --> Final output sent to browser
DEBUG - 2016-10-26 18:45:34 --> Total execution time: 0.0170
INFO - 2016-10-26 18:46:07 --> Config Class Initialized
INFO - 2016-10-26 18:46:07 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:46:07 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:46:07 --> Utf8 Class Initialized
INFO - 2016-10-26 18:46:07 --> URI Class Initialized
DEBUG - 2016-10-26 18:46:07 --> No URI present. Default controller set.
INFO - 2016-10-26 18:46:07 --> Router Class Initialized
INFO - 2016-10-26 18:46:07 --> Output Class Initialized
INFO - 2016-10-26 18:46:07 --> Security Class Initialized
DEBUG - 2016-10-26 18:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:46:07 --> Input Class Initialized
INFO - 2016-10-26 18:46:07 --> Language Class Initialized
INFO - 2016-10-26 18:46:07 --> Loader Class Initialized
INFO - 2016-10-26 18:46:07 --> Helper loaded: url_helper
INFO - 2016-10-26 18:46:07 --> Helper loaded: form_helper
INFO - 2016-10-26 18:46:07 --> Database Driver Class Initialized
INFO - 2016-10-26 18:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:46:07 --> Controller Class Initialized
INFO - 2016-10-26 18:46:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:46:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 18:46:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-26 18:46:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-26 18:46:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 18:46:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:46:07 --> Final output sent to browser
DEBUG - 2016-10-26 18:46:07 --> Total execution time: 0.0217
INFO - 2016-10-26 18:46:08 --> Config Class Initialized
INFO - 2016-10-26 18:46:08 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:46:08 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:46:08 --> Utf8 Class Initialized
INFO - 2016-10-26 18:46:08 --> URI Class Initialized
DEBUG - 2016-10-26 18:46:08 --> No URI present. Default controller set.
INFO - 2016-10-26 18:46:08 --> Router Class Initialized
INFO - 2016-10-26 18:46:08 --> Output Class Initialized
INFO - 2016-10-26 18:46:08 --> Security Class Initialized
DEBUG - 2016-10-26 18:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:46:08 --> Input Class Initialized
INFO - 2016-10-26 18:46:08 --> Language Class Initialized
INFO - 2016-10-26 18:46:08 --> Loader Class Initialized
INFO - 2016-10-26 18:46:08 --> Helper loaded: url_helper
INFO - 2016-10-26 18:46:08 --> Helper loaded: form_helper
INFO - 2016-10-26 18:46:08 --> Database Driver Class Initialized
INFO - 2016-10-26 18:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:46:08 --> Controller Class Initialized
INFO - 2016-10-26 18:46:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:46:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 18:46:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-26 18:46:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-26 18:46:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 18:46:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:46:08 --> Final output sent to browser
DEBUG - 2016-10-26 18:46:08 --> Total execution time: 0.0163
INFO - 2016-10-26 18:46:08 --> Config Class Initialized
INFO - 2016-10-26 18:46:08 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:46:08 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:46:08 --> Utf8 Class Initialized
INFO - 2016-10-26 18:46:08 --> URI Class Initialized
DEBUG - 2016-10-26 18:46:08 --> No URI present. Default controller set.
INFO - 2016-10-26 18:46:08 --> Router Class Initialized
INFO - 2016-10-26 18:46:08 --> Output Class Initialized
INFO - 2016-10-26 18:46:08 --> Security Class Initialized
DEBUG - 2016-10-26 18:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:46:08 --> Input Class Initialized
INFO - 2016-10-26 18:46:08 --> Language Class Initialized
INFO - 2016-10-26 18:46:08 --> Loader Class Initialized
INFO - 2016-10-26 18:46:08 --> Helper loaded: url_helper
INFO - 2016-10-26 18:46:08 --> Helper loaded: form_helper
INFO - 2016-10-26 18:46:08 --> Database Driver Class Initialized
INFO - 2016-10-26 18:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:46:08 --> Controller Class Initialized
INFO - 2016-10-26 18:46:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:46:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 18:46:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-26 18:46:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-26 18:46:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 18:46:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:46:08 --> Final output sent to browser
DEBUG - 2016-10-26 18:46:08 --> Total execution time: 0.0161
INFO - 2016-10-26 18:46:27 --> Config Class Initialized
INFO - 2016-10-26 18:46:27 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:46:27 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:46:27 --> Utf8 Class Initialized
INFO - 2016-10-26 18:46:27 --> URI Class Initialized
DEBUG - 2016-10-26 18:46:27 --> No URI present. Default controller set.
INFO - 2016-10-26 18:46:27 --> Router Class Initialized
INFO - 2016-10-26 18:46:27 --> Output Class Initialized
INFO - 2016-10-26 18:46:27 --> Security Class Initialized
DEBUG - 2016-10-26 18:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:46:27 --> Input Class Initialized
INFO - 2016-10-26 18:46:27 --> Language Class Initialized
INFO - 2016-10-26 18:46:27 --> Loader Class Initialized
INFO - 2016-10-26 18:46:27 --> Helper loaded: url_helper
INFO - 2016-10-26 18:46:27 --> Helper loaded: form_helper
INFO - 2016-10-26 18:46:27 --> Database Driver Class Initialized
INFO - 2016-10-26 18:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:46:27 --> Controller Class Initialized
INFO - 2016-10-26 18:46:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:46:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 18:46:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-26 18:46:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-26 18:46:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 18:46:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:46:27 --> Final output sent to browser
DEBUG - 2016-10-26 18:46:27 --> Total execution time: 0.0172
INFO - 2016-10-26 18:46:41 --> Config Class Initialized
INFO - 2016-10-26 18:46:41 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:46:41 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:46:41 --> Utf8 Class Initialized
INFO - 2016-10-26 18:46:41 --> URI Class Initialized
DEBUG - 2016-10-26 18:46:41 --> No URI present. Default controller set.
INFO - 2016-10-26 18:46:41 --> Router Class Initialized
INFO - 2016-10-26 18:46:41 --> Output Class Initialized
INFO - 2016-10-26 18:46:41 --> Security Class Initialized
DEBUG - 2016-10-26 18:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:46:41 --> Input Class Initialized
INFO - 2016-10-26 18:46:41 --> Language Class Initialized
INFO - 2016-10-26 18:46:41 --> Loader Class Initialized
INFO - 2016-10-26 18:46:41 --> Helper loaded: url_helper
INFO - 2016-10-26 18:46:41 --> Helper loaded: form_helper
INFO - 2016-10-26 18:46:41 --> Database Driver Class Initialized
INFO - 2016-10-26 18:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:46:41 --> Controller Class Initialized
INFO - 2016-10-26 18:46:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:46:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 18:46:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-26 18:46:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-26 18:46:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 18:46:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:46:41 --> Final output sent to browser
DEBUG - 2016-10-26 18:46:41 --> Total execution time: 0.0166
INFO - 2016-10-26 18:48:36 --> Config Class Initialized
INFO - 2016-10-26 18:48:36 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:48:36 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:48:36 --> Utf8 Class Initialized
INFO - 2016-10-26 18:48:36 --> URI Class Initialized
DEBUG - 2016-10-26 18:48:36 --> No URI present. Default controller set.
INFO - 2016-10-26 18:48:36 --> Router Class Initialized
INFO - 2016-10-26 18:48:36 --> Output Class Initialized
INFO - 2016-10-26 18:48:36 --> Security Class Initialized
DEBUG - 2016-10-26 18:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:48:36 --> Input Class Initialized
INFO - 2016-10-26 18:48:36 --> Language Class Initialized
INFO - 2016-10-26 18:48:36 --> Loader Class Initialized
INFO - 2016-10-26 18:48:36 --> Helper loaded: url_helper
INFO - 2016-10-26 18:48:36 --> Helper loaded: form_helper
INFO - 2016-10-26 18:48:36 --> Database Driver Class Initialized
INFO - 2016-10-26 18:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:48:36 --> Controller Class Initialized
INFO - 2016-10-26 18:48:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:48:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 18:48:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-26 18:48:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-26 18:48:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-26 18:48:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 18:48:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:48:36 --> Final output sent to browser
DEBUG - 2016-10-26 18:48:36 --> Total execution time: 0.0201
INFO - 2016-10-26 18:49:04 --> Config Class Initialized
INFO - 2016-10-26 18:49:04 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:49:04 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:49:04 --> Utf8 Class Initialized
INFO - 2016-10-26 18:49:04 --> URI Class Initialized
DEBUG - 2016-10-26 18:49:04 --> No URI present. Default controller set.
INFO - 2016-10-26 18:49:04 --> Router Class Initialized
INFO - 2016-10-26 18:49:04 --> Output Class Initialized
INFO - 2016-10-26 18:49:04 --> Security Class Initialized
DEBUG - 2016-10-26 18:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:49:04 --> Input Class Initialized
INFO - 2016-10-26 18:49:04 --> Language Class Initialized
INFO - 2016-10-26 18:49:04 --> Loader Class Initialized
INFO - 2016-10-26 18:49:04 --> Helper loaded: url_helper
INFO - 2016-10-26 18:49:04 --> Helper loaded: form_helper
INFO - 2016-10-26 18:49:04 --> Database Driver Class Initialized
INFO - 2016-10-26 18:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:49:04 --> Controller Class Initialized
INFO - 2016-10-26 18:49:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:49:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 18:49:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-26 18:49:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-26 18:49:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-26 18:49:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 18:49:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:49:04 --> Final output sent to browser
DEBUG - 2016-10-26 18:49:04 --> Total execution time: 0.0171
INFO - 2016-10-26 18:50:08 --> Config Class Initialized
INFO - 2016-10-26 18:50:08 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:50:08 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:50:08 --> Utf8 Class Initialized
INFO - 2016-10-26 18:50:08 --> URI Class Initialized
DEBUG - 2016-10-26 18:50:08 --> No URI present. Default controller set.
INFO - 2016-10-26 18:50:08 --> Router Class Initialized
INFO - 2016-10-26 18:50:08 --> Output Class Initialized
INFO - 2016-10-26 18:50:08 --> Security Class Initialized
DEBUG - 2016-10-26 18:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:50:08 --> Input Class Initialized
INFO - 2016-10-26 18:50:08 --> Language Class Initialized
INFO - 2016-10-26 18:50:08 --> Loader Class Initialized
INFO - 2016-10-26 18:50:08 --> Helper loaded: url_helper
INFO - 2016-10-26 18:50:08 --> Helper loaded: form_helper
INFO - 2016-10-26 18:50:08 --> Database Driver Class Initialized
INFO - 2016-10-26 18:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:50:08 --> Controller Class Initialized
INFO - 2016-10-26 18:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 18:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-26 18:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-26 18:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-26 18:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-26 18:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 18:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:50:08 --> Final output sent to browser
DEBUG - 2016-10-26 18:50:08 --> Total execution time: 0.0201
INFO - 2016-10-26 18:50:30 --> Config Class Initialized
INFO - 2016-10-26 18:50:30 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:50:30 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:50:30 --> Utf8 Class Initialized
INFO - 2016-10-26 18:50:30 --> URI Class Initialized
DEBUG - 2016-10-26 18:50:30 --> No URI present. Default controller set.
INFO - 2016-10-26 18:50:30 --> Router Class Initialized
INFO - 2016-10-26 18:50:30 --> Output Class Initialized
INFO - 2016-10-26 18:50:30 --> Security Class Initialized
DEBUG - 2016-10-26 18:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:50:30 --> Input Class Initialized
INFO - 2016-10-26 18:50:30 --> Language Class Initialized
INFO - 2016-10-26 18:50:30 --> Loader Class Initialized
INFO - 2016-10-26 18:50:30 --> Helper loaded: url_helper
INFO - 2016-10-26 18:50:30 --> Helper loaded: form_helper
INFO - 2016-10-26 18:50:30 --> Database Driver Class Initialized
INFO - 2016-10-26 18:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:50:30 --> Controller Class Initialized
INFO - 2016-10-26 18:50:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:50:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 18:50:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-26 18:50:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-26 18:50:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-26 18:50:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-26 18:50:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 18:50:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:50:30 --> Final output sent to browser
DEBUG - 2016-10-26 18:50:30 --> Total execution time: 0.0194
INFO - 2016-10-26 18:51:05 --> Config Class Initialized
INFO - 2016-10-26 18:51:05 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:51:05 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:51:05 --> Utf8 Class Initialized
INFO - 2016-10-26 18:51:05 --> URI Class Initialized
DEBUG - 2016-10-26 18:51:05 --> No URI present. Default controller set.
INFO - 2016-10-26 18:51:05 --> Router Class Initialized
INFO - 2016-10-26 18:51:05 --> Output Class Initialized
INFO - 2016-10-26 18:51:05 --> Security Class Initialized
DEBUG - 2016-10-26 18:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:51:05 --> Input Class Initialized
INFO - 2016-10-26 18:51:05 --> Language Class Initialized
INFO - 2016-10-26 18:51:05 --> Loader Class Initialized
INFO - 2016-10-26 18:51:05 --> Helper loaded: url_helper
INFO - 2016-10-26 18:51:05 --> Helper loaded: form_helper
INFO - 2016-10-26 18:51:05 --> Database Driver Class Initialized
INFO - 2016-10-26 18:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:51:05 --> Controller Class Initialized
INFO - 2016-10-26 18:51:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:51:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 18:51:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-26 18:51:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-26 18:51:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-26 18:51:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-26 18:51:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 18:51:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:51:05 --> Final output sent to browser
DEBUG - 2016-10-26 18:51:05 --> Total execution time: 0.0170
INFO - 2016-10-26 18:51:39 --> Config Class Initialized
INFO - 2016-10-26 18:51:39 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:51:39 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:51:39 --> Utf8 Class Initialized
INFO - 2016-10-26 18:51:39 --> URI Class Initialized
DEBUG - 2016-10-26 18:51:39 --> No URI present. Default controller set.
INFO - 2016-10-26 18:51:39 --> Router Class Initialized
INFO - 2016-10-26 18:51:39 --> Output Class Initialized
INFO - 2016-10-26 18:51:39 --> Security Class Initialized
DEBUG - 2016-10-26 18:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:51:39 --> Input Class Initialized
INFO - 2016-10-26 18:51:39 --> Language Class Initialized
INFO - 2016-10-26 18:51:39 --> Loader Class Initialized
INFO - 2016-10-26 18:51:39 --> Helper loaded: url_helper
INFO - 2016-10-26 18:51:39 --> Helper loaded: form_helper
INFO - 2016-10-26 18:51:39 --> Database Driver Class Initialized
INFO - 2016-10-26 18:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:51:39 --> Controller Class Initialized
INFO - 2016-10-26 18:51:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:51:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 18:51:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-26 18:51:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-26 18:51:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-26 18:51:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-26 18:51:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 18:51:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:51:39 --> Final output sent to browser
DEBUG - 2016-10-26 18:51:39 --> Total execution time: 0.0193
INFO - 2016-10-26 18:52:16 --> Config Class Initialized
INFO - 2016-10-26 18:52:16 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:52:16 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:52:16 --> Utf8 Class Initialized
INFO - 2016-10-26 18:52:16 --> URI Class Initialized
DEBUG - 2016-10-26 18:52:16 --> No URI present. Default controller set.
INFO - 2016-10-26 18:52:16 --> Router Class Initialized
INFO - 2016-10-26 18:52:16 --> Output Class Initialized
INFO - 2016-10-26 18:52:16 --> Security Class Initialized
DEBUG - 2016-10-26 18:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:52:16 --> Input Class Initialized
INFO - 2016-10-26 18:52:16 --> Language Class Initialized
INFO - 2016-10-26 18:52:16 --> Loader Class Initialized
INFO - 2016-10-26 18:52:16 --> Helper loaded: url_helper
INFO - 2016-10-26 18:52:16 --> Helper loaded: form_helper
INFO - 2016-10-26 18:52:16 --> Database Driver Class Initialized
INFO - 2016-10-26 18:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:52:16 --> Controller Class Initialized
INFO - 2016-10-26 18:52:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:52:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 18:52:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-26 18:52:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-26 18:52:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-26 18:52:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-26 18:52:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 18:52:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:52:16 --> Final output sent to browser
DEBUG - 2016-10-26 18:52:16 --> Total execution time: 0.0197
INFO - 2016-10-26 18:58:11 --> Config Class Initialized
INFO - 2016-10-26 18:58:11 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:58:11 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:58:11 --> Utf8 Class Initialized
INFO - 2016-10-26 18:58:11 --> URI Class Initialized
DEBUG - 2016-10-26 18:58:11 --> No URI present. Default controller set.
INFO - 2016-10-26 18:58:11 --> Router Class Initialized
INFO - 2016-10-26 18:58:11 --> Output Class Initialized
INFO - 2016-10-26 18:58:11 --> Security Class Initialized
DEBUG - 2016-10-26 18:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:58:11 --> Input Class Initialized
INFO - 2016-10-26 18:58:11 --> Language Class Initialized
INFO - 2016-10-26 18:58:11 --> Loader Class Initialized
INFO - 2016-10-26 18:58:11 --> Helper loaded: url_helper
INFO - 2016-10-26 18:58:11 --> Helper loaded: form_helper
INFO - 2016-10-26 18:58:11 --> Database Driver Class Initialized
INFO - 2016-10-26 18:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:58:11 --> Controller Class Initialized
INFO - 2016-10-26 18:58:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:58:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-26 18:58:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-26 18:58:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-26 18:58:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-26 18:58:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-26 18:58:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-26 18:58:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:58:11 --> Final output sent to browser
DEBUG - 2016-10-26 18:58:11 --> Total execution time: 0.0201
INFO - 2016-10-26 18:58:20 --> Config Class Initialized
INFO - 2016-10-26 18:58:20 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:58:20 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:58:20 --> Utf8 Class Initialized
INFO - 2016-10-26 18:58:20 --> URI Class Initialized
INFO - 2016-10-26 18:58:20 --> Router Class Initialized
INFO - 2016-10-26 18:58:20 --> Output Class Initialized
INFO - 2016-10-26 18:58:20 --> Security Class Initialized
DEBUG - 2016-10-26 18:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:58:20 --> Input Class Initialized
INFO - 2016-10-26 18:58:20 --> Language Class Initialized
INFO - 2016-10-26 18:58:20 --> Loader Class Initialized
INFO - 2016-10-26 18:58:20 --> Helper loaded: url_helper
INFO - 2016-10-26 18:58:20 --> Helper loaded: form_helper
INFO - 2016-10-26 18:58:20 --> Database Driver Class Initialized
INFO - 2016-10-26 18:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:58:20 --> Controller Class Initialized
DEBUG - 2016-10-26 18:58:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-26 18:58:20 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 152
ERROR - 2016-10-26 18:58:20 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 152
INFO - 2016-10-26 18:58:20 --> Config Class Initialized
INFO - 2016-10-26 18:58:20 --> Hooks Class Initialized
DEBUG - 2016-10-26 18:58:20 --> UTF-8 Support Enabled
INFO - 2016-10-26 18:58:20 --> Utf8 Class Initialized
INFO - 2016-10-26 18:58:20 --> URI Class Initialized
DEBUG - 2016-10-26 18:58:20 --> No URI present. Default controller set.
INFO - 2016-10-26 18:58:20 --> Router Class Initialized
INFO - 2016-10-26 18:58:20 --> Output Class Initialized
INFO - 2016-10-26 18:58:20 --> Security Class Initialized
DEBUG - 2016-10-26 18:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 18:58:20 --> Input Class Initialized
INFO - 2016-10-26 18:58:20 --> Language Class Initialized
INFO - 2016-10-26 18:58:20 --> Loader Class Initialized
INFO - 2016-10-26 18:58:20 --> Helper loaded: url_helper
INFO - 2016-10-26 18:58:20 --> Helper loaded: form_helper
INFO - 2016-10-26 18:58:20 --> Database Driver Class Initialized
INFO - 2016-10-26 18:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 18:58:20 --> Controller Class Initialized
INFO - 2016-10-26 18:58:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-26 18:58:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-26 18:58:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-26 18:58:20 --> Final output sent to browser
DEBUG - 2016-10-26 18:58:20 --> Total execution time: 0.0152
