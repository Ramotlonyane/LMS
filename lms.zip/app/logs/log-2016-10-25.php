<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-25 11:33:51 --> Config Class Initialized
INFO - 2016-10-25 11:33:51 --> Hooks Class Initialized
DEBUG - 2016-10-25 11:33:51 --> UTF-8 Support Enabled
INFO - 2016-10-25 11:33:51 --> Utf8 Class Initialized
INFO - 2016-10-25 11:33:51 --> URI Class Initialized
DEBUG - 2016-10-25 11:33:51 --> No URI present. Default controller set.
INFO - 2016-10-25 11:33:51 --> Router Class Initialized
INFO - 2016-10-25 11:33:51 --> Output Class Initialized
INFO - 2016-10-25 11:33:51 --> Security Class Initialized
DEBUG - 2016-10-25 11:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 11:33:51 --> Input Class Initialized
INFO - 2016-10-25 11:33:51 --> Language Class Initialized
INFO - 2016-10-25 11:33:51 --> Loader Class Initialized
INFO - 2016-10-25 11:33:51 --> Helper loaded: url_helper
INFO - 2016-10-25 11:33:51 --> Helper loaded: form_helper
INFO - 2016-10-25 11:33:51 --> Database Driver Class Initialized
INFO - 2016-10-25 11:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 11:33:51 --> Controller Class Initialized
INFO - 2016-10-25 11:33:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 11:33:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 11:33:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 11:33:51 --> Final output sent to browser
DEBUG - 2016-10-25 11:33:51 --> Total execution time: 0.0937
INFO - 2016-10-25 11:34:03 --> Config Class Initialized
INFO - 2016-10-25 11:34:03 --> Hooks Class Initialized
DEBUG - 2016-10-25 11:34:03 --> UTF-8 Support Enabled
INFO - 2016-10-25 11:34:03 --> Utf8 Class Initialized
INFO - 2016-10-25 11:34:03 --> URI Class Initialized
INFO - 2016-10-25 11:34:03 --> Router Class Initialized
INFO - 2016-10-25 11:34:03 --> Output Class Initialized
INFO - 2016-10-25 11:34:03 --> Security Class Initialized
DEBUG - 2016-10-25 11:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 11:34:03 --> Input Class Initialized
INFO - 2016-10-25 11:34:03 --> Language Class Initialized
INFO - 2016-10-25 11:34:03 --> Loader Class Initialized
INFO - 2016-10-25 11:34:03 --> Helper loaded: url_helper
INFO - 2016-10-25 11:34:03 --> Helper loaded: form_helper
INFO - 2016-10-25 11:34:03 --> Database Driver Class Initialized
INFO - 2016-10-25 11:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 11:34:03 --> Controller Class Initialized
DEBUG - 2016-10-25 11:34:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-25 11:34:03 --> Model Class Initialized
INFO - 2016-10-25 11:34:03 --> Final output sent to browser
DEBUG - 2016-10-25 11:34:03 --> Total execution time: 0.0442
INFO - 2016-10-25 11:34:03 --> Config Class Initialized
INFO - 2016-10-25 11:34:03 --> Hooks Class Initialized
DEBUG - 2016-10-25 11:34:03 --> UTF-8 Support Enabled
INFO - 2016-10-25 11:34:03 --> Utf8 Class Initialized
INFO - 2016-10-25 11:34:03 --> URI Class Initialized
DEBUG - 2016-10-25 11:34:03 --> No URI present. Default controller set.
INFO - 2016-10-25 11:34:03 --> Router Class Initialized
INFO - 2016-10-25 11:34:03 --> Output Class Initialized
INFO - 2016-10-25 11:34:03 --> Security Class Initialized
DEBUG - 2016-10-25 11:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 11:34:03 --> Input Class Initialized
INFO - 2016-10-25 11:34:03 --> Language Class Initialized
INFO - 2016-10-25 11:34:03 --> Loader Class Initialized
INFO - 2016-10-25 11:34:03 --> Helper loaded: url_helper
INFO - 2016-10-25 11:34:03 --> Helper loaded: form_helper
INFO - 2016-10-25 11:34:03 --> Database Driver Class Initialized
INFO - 2016-10-25 11:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 11:34:03 --> Controller Class Initialized
INFO - 2016-10-25 11:34:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 11:34:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-25 11:34:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-25 11:34:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 11:34:03 --> Final output sent to browser
DEBUG - 2016-10-25 11:34:03 --> Total execution time: 0.0281
INFO - 2016-10-25 11:34:07 --> Config Class Initialized
INFO - 2016-10-25 11:34:07 --> Hooks Class Initialized
DEBUG - 2016-10-25 11:34:07 --> UTF-8 Support Enabled
INFO - 2016-10-25 11:34:07 --> Utf8 Class Initialized
INFO - 2016-10-25 11:34:07 --> URI Class Initialized
INFO - 2016-10-25 11:34:07 --> Router Class Initialized
INFO - 2016-10-25 11:34:07 --> Output Class Initialized
INFO - 2016-10-25 11:34:07 --> Security Class Initialized
DEBUG - 2016-10-25 11:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 11:34:07 --> Input Class Initialized
INFO - 2016-10-25 11:34:07 --> Language Class Initialized
INFO - 2016-10-25 11:34:07 --> Loader Class Initialized
INFO - 2016-10-25 11:34:07 --> Helper loaded: url_helper
INFO - 2016-10-25 11:34:07 --> Helper loaded: form_helper
INFO - 2016-10-25 11:34:07 --> Database Driver Class Initialized
INFO - 2016-10-25 11:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 11:34:07 --> Controller Class Initialized
DEBUG - 2016-10-25 11:34:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-25 11:34:07 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-25 11:34:07 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-25 11:34:07 --> Config Class Initialized
INFO - 2016-10-25 11:34:07 --> Hooks Class Initialized
DEBUG - 2016-10-25 11:34:07 --> UTF-8 Support Enabled
INFO - 2016-10-25 11:34:07 --> Utf8 Class Initialized
INFO - 2016-10-25 11:34:07 --> URI Class Initialized
DEBUG - 2016-10-25 11:34:07 --> No URI present. Default controller set.
INFO - 2016-10-25 11:34:07 --> Router Class Initialized
INFO - 2016-10-25 11:34:07 --> Output Class Initialized
INFO - 2016-10-25 11:34:07 --> Security Class Initialized
DEBUG - 2016-10-25 11:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 11:34:07 --> Input Class Initialized
INFO - 2016-10-25 11:34:07 --> Language Class Initialized
INFO - 2016-10-25 11:34:07 --> Loader Class Initialized
INFO - 2016-10-25 11:34:07 --> Helper loaded: url_helper
INFO - 2016-10-25 11:34:07 --> Helper loaded: form_helper
INFO - 2016-10-25 11:34:07 --> Database Driver Class Initialized
INFO - 2016-10-25 11:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 11:34:07 --> Controller Class Initialized
INFO - 2016-10-25 11:34:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 11:34:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 11:34:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 11:34:07 --> Final output sent to browser
DEBUG - 2016-10-25 11:34:07 --> Total execution time: 0.0151
INFO - 2016-10-25 11:34:38 --> Config Class Initialized
INFO - 2016-10-25 11:34:38 --> Hooks Class Initialized
DEBUG - 2016-10-25 11:34:38 --> UTF-8 Support Enabled
INFO - 2016-10-25 11:34:38 --> Utf8 Class Initialized
INFO - 2016-10-25 11:34:38 --> URI Class Initialized
DEBUG - 2016-10-25 11:34:38 --> No URI present. Default controller set.
INFO - 2016-10-25 11:34:38 --> Router Class Initialized
INFO - 2016-10-25 11:34:38 --> Output Class Initialized
INFO - 2016-10-25 11:34:38 --> Security Class Initialized
DEBUG - 2016-10-25 11:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 11:34:38 --> Input Class Initialized
INFO - 2016-10-25 11:34:38 --> Language Class Initialized
INFO - 2016-10-25 11:34:38 --> Loader Class Initialized
INFO - 2016-10-25 11:34:38 --> Helper loaded: url_helper
INFO - 2016-10-25 11:34:38 --> Helper loaded: form_helper
INFO - 2016-10-25 11:34:38 --> Database Driver Class Initialized
INFO - 2016-10-25 11:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 11:34:38 --> Controller Class Initialized
INFO - 2016-10-25 11:34:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 11:34:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 11:34:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 11:34:38 --> Final output sent to browser
DEBUG - 2016-10-25 11:34:38 --> Total execution time: 0.0163
INFO - 2016-10-25 11:34:45 --> Config Class Initialized
INFO - 2016-10-25 11:34:45 --> Hooks Class Initialized
DEBUG - 2016-10-25 11:34:45 --> UTF-8 Support Enabled
INFO - 2016-10-25 11:34:45 --> Utf8 Class Initialized
INFO - 2016-10-25 11:34:45 --> URI Class Initialized
INFO - 2016-10-25 11:34:45 --> Router Class Initialized
INFO - 2016-10-25 11:34:45 --> Output Class Initialized
INFO - 2016-10-25 11:34:45 --> Security Class Initialized
DEBUG - 2016-10-25 11:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 11:34:45 --> Input Class Initialized
INFO - 2016-10-25 11:34:45 --> Language Class Initialized
INFO - 2016-10-25 11:34:45 --> Loader Class Initialized
INFO - 2016-10-25 11:34:45 --> Helper loaded: url_helper
INFO - 2016-10-25 11:34:45 --> Helper loaded: form_helper
INFO - 2016-10-25 11:34:45 --> Database Driver Class Initialized
INFO - 2016-10-25 11:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 11:34:45 --> Controller Class Initialized
DEBUG - 2016-10-25 11:34:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-25 11:34:45 --> Model Class Initialized
INFO - 2016-10-25 11:34:45 --> Final output sent to browser
DEBUG - 2016-10-25 11:34:45 --> Total execution time: 0.0183
INFO - 2016-10-25 11:34:45 --> Config Class Initialized
INFO - 2016-10-25 11:34:45 --> Hooks Class Initialized
DEBUG - 2016-10-25 11:34:45 --> UTF-8 Support Enabled
INFO - 2016-10-25 11:34:45 --> Utf8 Class Initialized
INFO - 2016-10-25 11:34:45 --> URI Class Initialized
DEBUG - 2016-10-25 11:34:45 --> No URI present. Default controller set.
INFO - 2016-10-25 11:34:45 --> Router Class Initialized
INFO - 2016-10-25 11:34:45 --> Output Class Initialized
INFO - 2016-10-25 11:34:45 --> Security Class Initialized
DEBUG - 2016-10-25 11:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 11:34:45 --> Input Class Initialized
INFO - 2016-10-25 11:34:45 --> Language Class Initialized
INFO - 2016-10-25 11:34:45 --> Loader Class Initialized
INFO - 2016-10-25 11:34:45 --> Helper loaded: url_helper
INFO - 2016-10-25 11:34:45 --> Helper loaded: form_helper
INFO - 2016-10-25 11:34:45 --> Database Driver Class Initialized
INFO - 2016-10-25 11:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 11:34:45 --> Controller Class Initialized
INFO - 2016-10-25 11:34:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 11:34:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-25 11:34:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-25 11:34:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 11:34:45 --> Final output sent to browser
DEBUG - 2016-10-25 11:34:45 --> Total execution time: 0.0154
INFO - 2016-10-25 11:34:46 --> Config Class Initialized
INFO - 2016-10-25 11:34:46 --> Hooks Class Initialized
DEBUG - 2016-10-25 11:34:46 --> UTF-8 Support Enabled
INFO - 2016-10-25 11:34:46 --> Utf8 Class Initialized
INFO - 2016-10-25 11:34:46 --> URI Class Initialized
INFO - 2016-10-25 11:34:46 --> Router Class Initialized
INFO - 2016-10-25 11:34:46 --> Output Class Initialized
INFO - 2016-10-25 11:34:46 --> Security Class Initialized
DEBUG - 2016-10-25 11:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 11:34:46 --> Input Class Initialized
INFO - 2016-10-25 11:34:46 --> Language Class Initialized
INFO - 2016-10-25 11:34:46 --> Loader Class Initialized
INFO - 2016-10-25 11:34:46 --> Helper loaded: url_helper
INFO - 2016-10-25 11:34:46 --> Helper loaded: form_helper
INFO - 2016-10-25 11:34:46 --> Database Driver Class Initialized
INFO - 2016-10-25 11:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 11:34:46 --> Controller Class Initialized
DEBUG - 2016-10-25 11:34:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-25 11:34:46 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-25 11:34:46 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-25 11:34:46 --> Config Class Initialized
INFO - 2016-10-25 11:34:46 --> Hooks Class Initialized
DEBUG - 2016-10-25 11:34:46 --> UTF-8 Support Enabled
INFO - 2016-10-25 11:34:46 --> Utf8 Class Initialized
INFO - 2016-10-25 11:34:46 --> URI Class Initialized
DEBUG - 2016-10-25 11:34:46 --> No URI present. Default controller set.
INFO - 2016-10-25 11:34:46 --> Router Class Initialized
INFO - 2016-10-25 11:34:46 --> Output Class Initialized
INFO - 2016-10-25 11:34:46 --> Security Class Initialized
DEBUG - 2016-10-25 11:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 11:34:46 --> Input Class Initialized
INFO - 2016-10-25 11:34:46 --> Language Class Initialized
INFO - 2016-10-25 11:34:46 --> Loader Class Initialized
INFO - 2016-10-25 11:34:46 --> Helper loaded: url_helper
INFO - 2016-10-25 11:34:46 --> Helper loaded: form_helper
INFO - 2016-10-25 11:34:46 --> Database Driver Class Initialized
INFO - 2016-10-25 11:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 11:34:46 --> Controller Class Initialized
INFO - 2016-10-25 11:34:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 11:34:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 11:34:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 11:34:46 --> Final output sent to browser
DEBUG - 2016-10-25 11:34:46 --> Total execution time: 0.0151
INFO - 2016-10-25 11:34:57 --> Config Class Initialized
INFO - 2016-10-25 11:34:57 --> Hooks Class Initialized
DEBUG - 2016-10-25 11:34:57 --> UTF-8 Support Enabled
INFO - 2016-10-25 11:34:57 --> Utf8 Class Initialized
INFO - 2016-10-25 11:34:57 --> URI Class Initialized
DEBUG - 2016-10-25 11:34:57 --> No URI present. Default controller set.
INFO - 2016-10-25 11:34:57 --> Router Class Initialized
INFO - 2016-10-25 11:34:57 --> Output Class Initialized
INFO - 2016-10-25 11:34:57 --> Security Class Initialized
DEBUG - 2016-10-25 11:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 11:34:57 --> Input Class Initialized
INFO - 2016-10-25 11:34:57 --> Language Class Initialized
INFO - 2016-10-25 11:34:57 --> Loader Class Initialized
INFO - 2016-10-25 11:34:57 --> Helper loaded: url_helper
INFO - 2016-10-25 11:34:57 --> Helper loaded: form_helper
INFO - 2016-10-25 11:34:57 --> Database Driver Class Initialized
INFO - 2016-10-25 11:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 11:34:57 --> Controller Class Initialized
INFO - 2016-10-25 11:34:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 11:34:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 11:34:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 11:34:57 --> Final output sent to browser
DEBUG - 2016-10-25 11:34:57 --> Total execution time: 0.0194
INFO - 2016-10-25 11:34:58 --> Config Class Initialized
INFO - 2016-10-25 11:34:58 --> Hooks Class Initialized
DEBUG - 2016-10-25 11:34:58 --> UTF-8 Support Enabled
INFO - 2016-10-25 11:34:58 --> Utf8 Class Initialized
INFO - 2016-10-25 11:34:58 --> URI Class Initialized
DEBUG - 2016-10-25 11:34:58 --> No URI present. Default controller set.
INFO - 2016-10-25 11:34:58 --> Router Class Initialized
INFO - 2016-10-25 11:34:58 --> Output Class Initialized
INFO - 2016-10-25 11:34:58 --> Security Class Initialized
DEBUG - 2016-10-25 11:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 11:34:58 --> Input Class Initialized
INFO - 2016-10-25 11:34:58 --> Language Class Initialized
INFO - 2016-10-25 11:34:58 --> Loader Class Initialized
INFO - 2016-10-25 11:34:58 --> Helper loaded: url_helper
INFO - 2016-10-25 11:34:58 --> Helper loaded: form_helper
INFO - 2016-10-25 11:34:58 --> Database Driver Class Initialized
INFO - 2016-10-25 11:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 11:34:58 --> Controller Class Initialized
INFO - 2016-10-25 11:34:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 11:34:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 11:34:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 11:34:58 --> Final output sent to browser
DEBUG - 2016-10-25 11:34:58 --> Total execution time: 0.0155
INFO - 2016-10-25 11:34:58 --> Config Class Initialized
INFO - 2016-10-25 11:34:58 --> Hooks Class Initialized
DEBUG - 2016-10-25 11:34:58 --> UTF-8 Support Enabled
INFO - 2016-10-25 11:34:58 --> Utf8 Class Initialized
INFO - 2016-10-25 11:34:58 --> URI Class Initialized
DEBUG - 2016-10-25 11:34:58 --> No URI present. Default controller set.
INFO - 2016-10-25 11:34:58 --> Router Class Initialized
INFO - 2016-10-25 11:34:58 --> Output Class Initialized
INFO - 2016-10-25 11:34:58 --> Security Class Initialized
DEBUG - 2016-10-25 11:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 11:34:58 --> Input Class Initialized
INFO - 2016-10-25 11:34:58 --> Language Class Initialized
INFO - 2016-10-25 11:34:58 --> Loader Class Initialized
INFO - 2016-10-25 11:34:58 --> Helper loaded: url_helper
INFO - 2016-10-25 11:34:58 --> Helper loaded: form_helper
INFO - 2016-10-25 11:34:58 --> Database Driver Class Initialized
INFO - 2016-10-25 11:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 11:34:58 --> Controller Class Initialized
INFO - 2016-10-25 11:34:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 11:34:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 11:34:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 11:34:58 --> Final output sent to browser
DEBUG - 2016-10-25 11:34:58 --> Total execution time: 0.0153
INFO - 2016-10-25 11:34:58 --> Config Class Initialized
INFO - 2016-10-25 11:34:58 --> Hooks Class Initialized
DEBUG - 2016-10-25 11:34:58 --> UTF-8 Support Enabled
INFO - 2016-10-25 11:34:58 --> Utf8 Class Initialized
INFO - 2016-10-25 11:34:58 --> URI Class Initialized
DEBUG - 2016-10-25 11:34:58 --> No URI present. Default controller set.
INFO - 2016-10-25 11:34:58 --> Router Class Initialized
INFO - 2016-10-25 11:34:58 --> Output Class Initialized
INFO - 2016-10-25 11:34:58 --> Security Class Initialized
DEBUG - 2016-10-25 11:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 11:34:58 --> Input Class Initialized
INFO - 2016-10-25 11:34:58 --> Language Class Initialized
INFO - 2016-10-25 11:34:58 --> Loader Class Initialized
INFO - 2016-10-25 11:34:58 --> Helper loaded: url_helper
INFO - 2016-10-25 11:34:58 --> Helper loaded: form_helper
INFO - 2016-10-25 11:34:58 --> Database Driver Class Initialized
INFO - 2016-10-25 11:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 11:34:58 --> Controller Class Initialized
INFO - 2016-10-25 11:34:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 11:34:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 11:34:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 11:34:58 --> Final output sent to browser
DEBUG - 2016-10-25 11:34:58 --> Total execution time: 0.0150
INFO - 2016-10-25 11:34:58 --> Config Class Initialized
INFO - 2016-10-25 11:34:58 --> Hooks Class Initialized
DEBUG - 2016-10-25 11:34:58 --> UTF-8 Support Enabled
INFO - 2016-10-25 11:34:58 --> Utf8 Class Initialized
INFO - 2016-10-25 11:34:58 --> URI Class Initialized
DEBUG - 2016-10-25 11:34:58 --> No URI present. Default controller set.
INFO - 2016-10-25 11:34:58 --> Router Class Initialized
INFO - 2016-10-25 11:34:58 --> Output Class Initialized
INFO - 2016-10-25 11:34:58 --> Security Class Initialized
DEBUG - 2016-10-25 11:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 11:34:58 --> Input Class Initialized
INFO - 2016-10-25 11:34:58 --> Language Class Initialized
INFO - 2016-10-25 11:34:58 --> Loader Class Initialized
INFO - 2016-10-25 11:34:58 --> Helper loaded: url_helper
INFO - 2016-10-25 11:34:58 --> Helper loaded: form_helper
INFO - 2016-10-25 11:34:58 --> Database Driver Class Initialized
INFO - 2016-10-25 11:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 11:34:58 --> Controller Class Initialized
INFO - 2016-10-25 11:34:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 11:34:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 11:34:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 11:34:58 --> Final output sent to browser
DEBUG - 2016-10-25 11:34:58 --> Total execution time: 0.0156
INFO - 2016-10-25 11:34:58 --> Config Class Initialized
INFO - 2016-10-25 11:34:58 --> Hooks Class Initialized
DEBUG - 2016-10-25 11:34:58 --> UTF-8 Support Enabled
INFO - 2016-10-25 11:34:58 --> Utf8 Class Initialized
INFO - 2016-10-25 11:34:58 --> URI Class Initialized
DEBUG - 2016-10-25 11:34:58 --> No URI present. Default controller set.
INFO - 2016-10-25 11:34:58 --> Router Class Initialized
INFO - 2016-10-25 11:34:58 --> Output Class Initialized
INFO - 2016-10-25 11:34:58 --> Security Class Initialized
DEBUG - 2016-10-25 11:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 11:34:58 --> Input Class Initialized
INFO - 2016-10-25 11:34:58 --> Language Class Initialized
INFO - 2016-10-25 11:34:58 --> Loader Class Initialized
INFO - 2016-10-25 11:34:58 --> Helper loaded: url_helper
INFO - 2016-10-25 11:34:58 --> Helper loaded: form_helper
INFO - 2016-10-25 11:34:58 --> Database Driver Class Initialized
INFO - 2016-10-25 11:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 11:34:58 --> Controller Class Initialized
INFO - 2016-10-25 11:34:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 11:34:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 11:34:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 11:34:58 --> Final output sent to browser
DEBUG - 2016-10-25 11:34:58 --> Total execution time: 0.0151
INFO - 2016-10-25 11:34:58 --> Config Class Initialized
INFO - 2016-10-25 11:34:58 --> Hooks Class Initialized
DEBUG - 2016-10-25 11:34:58 --> UTF-8 Support Enabled
INFO - 2016-10-25 11:34:58 --> Utf8 Class Initialized
INFO - 2016-10-25 11:34:58 --> URI Class Initialized
DEBUG - 2016-10-25 11:34:58 --> No URI present. Default controller set.
INFO - 2016-10-25 11:34:58 --> Router Class Initialized
INFO - 2016-10-25 11:34:58 --> Output Class Initialized
INFO - 2016-10-25 11:34:58 --> Security Class Initialized
DEBUG - 2016-10-25 11:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 11:34:58 --> Input Class Initialized
INFO - 2016-10-25 11:34:58 --> Language Class Initialized
INFO - 2016-10-25 11:34:58 --> Loader Class Initialized
INFO - 2016-10-25 11:34:58 --> Helper loaded: url_helper
INFO - 2016-10-25 11:34:58 --> Helper loaded: form_helper
INFO - 2016-10-25 11:34:59 --> Database Driver Class Initialized
INFO - 2016-10-25 11:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 11:34:59 --> Controller Class Initialized
INFO - 2016-10-25 11:34:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 11:34:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 11:34:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 11:34:59 --> Final output sent to browser
DEBUG - 2016-10-25 11:34:59 --> Total execution time: 0.0151
INFO - 2016-10-25 11:35:04 --> Config Class Initialized
INFO - 2016-10-25 11:35:04 --> Hooks Class Initialized
DEBUG - 2016-10-25 11:35:04 --> UTF-8 Support Enabled
INFO - 2016-10-25 11:35:04 --> Utf8 Class Initialized
INFO - 2016-10-25 11:35:04 --> URI Class Initialized
INFO - 2016-10-25 11:35:04 --> Router Class Initialized
INFO - 2016-10-25 11:35:04 --> Output Class Initialized
INFO - 2016-10-25 11:35:04 --> Security Class Initialized
DEBUG - 2016-10-25 11:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 11:35:04 --> Input Class Initialized
INFO - 2016-10-25 11:35:04 --> Language Class Initialized
INFO - 2016-10-25 11:35:04 --> Loader Class Initialized
INFO - 2016-10-25 11:35:04 --> Helper loaded: url_helper
INFO - 2016-10-25 11:35:04 --> Helper loaded: form_helper
INFO - 2016-10-25 11:35:04 --> Database Driver Class Initialized
INFO - 2016-10-25 11:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 11:35:04 --> Controller Class Initialized
DEBUG - 2016-10-25 11:35:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-25 11:35:04 --> Model Class Initialized
INFO - 2016-10-25 11:35:04 --> Final output sent to browser
DEBUG - 2016-10-25 11:35:04 --> Total execution time: 0.0177
INFO - 2016-10-25 11:35:04 --> Config Class Initialized
INFO - 2016-10-25 11:35:04 --> Hooks Class Initialized
DEBUG - 2016-10-25 11:35:04 --> UTF-8 Support Enabled
INFO - 2016-10-25 11:35:04 --> Utf8 Class Initialized
INFO - 2016-10-25 11:35:04 --> URI Class Initialized
DEBUG - 2016-10-25 11:35:04 --> No URI present. Default controller set.
INFO - 2016-10-25 11:35:04 --> Router Class Initialized
INFO - 2016-10-25 11:35:04 --> Output Class Initialized
INFO - 2016-10-25 11:35:04 --> Security Class Initialized
DEBUG - 2016-10-25 11:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 11:35:04 --> Input Class Initialized
INFO - 2016-10-25 11:35:04 --> Language Class Initialized
INFO - 2016-10-25 11:35:04 --> Loader Class Initialized
INFO - 2016-10-25 11:35:04 --> Helper loaded: url_helper
INFO - 2016-10-25 11:35:04 --> Helper loaded: form_helper
INFO - 2016-10-25 11:35:04 --> Database Driver Class Initialized
INFO - 2016-10-25 11:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 11:35:04 --> Controller Class Initialized
INFO - 2016-10-25 11:35:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 11:35:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-25 11:35:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-25 11:35:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 11:35:04 --> Final output sent to browser
DEBUG - 2016-10-25 11:35:04 --> Total execution time: 0.0160
INFO - 2016-10-25 11:35:06 --> Config Class Initialized
INFO - 2016-10-25 11:35:06 --> Hooks Class Initialized
DEBUG - 2016-10-25 11:35:06 --> UTF-8 Support Enabled
INFO - 2016-10-25 11:35:06 --> Utf8 Class Initialized
INFO - 2016-10-25 11:35:06 --> URI Class Initialized
INFO - 2016-10-25 11:35:06 --> Router Class Initialized
INFO - 2016-10-25 11:35:06 --> Output Class Initialized
INFO - 2016-10-25 11:35:06 --> Security Class Initialized
DEBUG - 2016-10-25 11:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 11:35:06 --> Input Class Initialized
INFO - 2016-10-25 11:35:06 --> Language Class Initialized
INFO - 2016-10-25 11:35:06 --> Loader Class Initialized
INFO - 2016-10-25 11:35:06 --> Helper loaded: url_helper
INFO - 2016-10-25 11:35:06 --> Helper loaded: form_helper
INFO - 2016-10-25 11:35:06 --> Database Driver Class Initialized
INFO - 2016-10-25 11:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 11:35:06 --> Controller Class Initialized
DEBUG - 2016-10-25 11:35:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-25 11:35:06 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-25 11:35:06 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-25 11:35:06 --> Config Class Initialized
INFO - 2016-10-25 11:35:06 --> Hooks Class Initialized
DEBUG - 2016-10-25 11:35:06 --> UTF-8 Support Enabled
INFO - 2016-10-25 11:35:06 --> Utf8 Class Initialized
INFO - 2016-10-25 11:35:06 --> URI Class Initialized
DEBUG - 2016-10-25 11:35:06 --> No URI present. Default controller set.
INFO - 2016-10-25 11:35:06 --> Router Class Initialized
INFO - 2016-10-25 11:35:06 --> Output Class Initialized
INFO - 2016-10-25 11:35:06 --> Security Class Initialized
DEBUG - 2016-10-25 11:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 11:35:06 --> Input Class Initialized
INFO - 2016-10-25 11:35:06 --> Language Class Initialized
INFO - 2016-10-25 11:35:06 --> Loader Class Initialized
INFO - 2016-10-25 11:35:06 --> Helper loaded: url_helper
INFO - 2016-10-25 11:35:06 --> Helper loaded: form_helper
INFO - 2016-10-25 11:35:06 --> Database Driver Class Initialized
INFO - 2016-10-25 11:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 11:35:06 --> Controller Class Initialized
INFO - 2016-10-25 11:35:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 11:35:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 11:35:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 11:35:06 --> Final output sent to browser
DEBUG - 2016-10-25 11:35:06 --> Total execution time: 0.0148
INFO - 2016-10-25 12:19:59 --> Config Class Initialized
INFO - 2016-10-25 12:19:59 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:19:59 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:19:59 --> Utf8 Class Initialized
INFO - 2016-10-25 12:19:59 --> URI Class Initialized
DEBUG - 2016-10-25 12:19:59 --> No URI present. Default controller set.
INFO - 2016-10-25 12:19:59 --> Router Class Initialized
INFO - 2016-10-25 12:19:59 --> Output Class Initialized
INFO - 2016-10-25 12:19:59 --> Security Class Initialized
DEBUG - 2016-10-25 12:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:19:59 --> Input Class Initialized
INFO - 2016-10-25 12:19:59 --> Language Class Initialized
INFO - 2016-10-25 12:19:59 --> Loader Class Initialized
INFO - 2016-10-25 12:19:59 --> Helper loaded: url_helper
INFO - 2016-10-25 12:19:59 --> Helper loaded: form_helper
INFO - 2016-10-25 12:19:59 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:19:59 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:19:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:19:59 --> Unable to connect to the database
INFO - 2016-10-25 12:19:59 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-25 12:20:02 --> Config Class Initialized
INFO - 2016-10-25 12:20:02 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:20:02 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:20:02 --> Utf8 Class Initialized
INFO - 2016-10-25 12:20:02 --> URI Class Initialized
DEBUG - 2016-10-25 12:20:02 --> No URI present. Default controller set.
INFO - 2016-10-25 12:20:02 --> Router Class Initialized
INFO - 2016-10-25 12:20:02 --> Output Class Initialized
INFO - 2016-10-25 12:20:02 --> Security Class Initialized
DEBUG - 2016-10-25 12:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:20:02 --> Input Class Initialized
INFO - 2016-10-25 12:20:02 --> Language Class Initialized
INFO - 2016-10-25 12:20:02 --> Loader Class Initialized
INFO - 2016-10-25 12:20:02 --> Helper loaded: url_helper
INFO - 2016-10-25 12:20:02 --> Helper loaded: form_helper
INFO - 2016-10-25 12:20:02 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:20:02 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:20:02 --> Unable to connect to the database
INFO - 2016-10-25 12:20:02 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-25 12:20:14 --> Config Class Initialized
INFO - 2016-10-25 12:20:14 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:20:14 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:20:14 --> Utf8 Class Initialized
INFO - 2016-10-25 12:20:14 --> URI Class Initialized
DEBUG - 2016-10-25 12:20:14 --> No URI present. Default controller set.
INFO - 2016-10-25 12:20:14 --> Router Class Initialized
INFO - 2016-10-25 12:20:14 --> Output Class Initialized
INFO - 2016-10-25 12:20:14 --> Security Class Initialized
DEBUG - 2016-10-25 12:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:20:14 --> Input Class Initialized
INFO - 2016-10-25 12:20:14 --> Language Class Initialized
INFO - 2016-10-25 12:20:14 --> Loader Class Initialized
INFO - 2016-10-25 12:20:14 --> Helper loaded: url_helper
INFO - 2016-10-25 12:20:14 --> Helper loaded: form_helper
INFO - 2016-10-25 12:20:14 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:20:14 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:20:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:20:14 --> Unable to connect to the database
INFO - 2016-10-25 12:20:14 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-25 12:20:14 --> Config Class Initialized
INFO - 2016-10-25 12:20:14 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:20:14 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:20:14 --> Utf8 Class Initialized
INFO - 2016-10-25 12:20:14 --> URI Class Initialized
DEBUG - 2016-10-25 12:20:14 --> No URI present. Default controller set.
INFO - 2016-10-25 12:20:14 --> Router Class Initialized
INFO - 2016-10-25 12:20:14 --> Output Class Initialized
INFO - 2016-10-25 12:20:14 --> Security Class Initialized
DEBUG - 2016-10-25 12:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:20:14 --> Input Class Initialized
INFO - 2016-10-25 12:20:14 --> Language Class Initialized
INFO - 2016-10-25 12:20:14 --> Loader Class Initialized
INFO - 2016-10-25 12:20:14 --> Helper loaded: url_helper
INFO - 2016-10-25 12:20:14 --> Helper loaded: form_helper
INFO - 2016-10-25 12:20:14 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:20:15 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:20:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:20:15 --> Unable to connect to the database
INFO - 2016-10-25 12:20:15 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-25 12:20:25 --> Config Class Initialized
INFO - 2016-10-25 12:20:25 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:20:25 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:20:25 --> Utf8 Class Initialized
INFO - 2016-10-25 12:20:25 --> URI Class Initialized
DEBUG - 2016-10-25 12:20:25 --> No URI present. Default controller set.
INFO - 2016-10-25 12:20:25 --> Router Class Initialized
INFO - 2016-10-25 12:20:25 --> Output Class Initialized
INFO - 2016-10-25 12:20:25 --> Security Class Initialized
DEBUG - 2016-10-25 12:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:20:25 --> Input Class Initialized
INFO - 2016-10-25 12:20:25 --> Language Class Initialized
INFO - 2016-10-25 12:20:25 --> Loader Class Initialized
INFO - 2016-10-25 12:20:25 --> Helper loaded: url_helper
INFO - 2016-10-25 12:20:25 --> Helper loaded: form_helper
INFO - 2016-10-25 12:20:25 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:20:25 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:20:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:20:25 --> Unable to connect to the database
INFO - 2016-10-25 12:20:25 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-25 12:20:25 --> Config Class Initialized
INFO - 2016-10-25 12:20:25 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:20:25 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:20:25 --> Utf8 Class Initialized
INFO - 2016-10-25 12:20:25 --> URI Class Initialized
DEBUG - 2016-10-25 12:20:25 --> No URI present. Default controller set.
INFO - 2016-10-25 12:20:25 --> Router Class Initialized
INFO - 2016-10-25 12:20:25 --> Output Class Initialized
INFO - 2016-10-25 12:20:25 --> Security Class Initialized
DEBUG - 2016-10-25 12:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:20:25 --> Input Class Initialized
INFO - 2016-10-25 12:20:25 --> Language Class Initialized
INFO - 2016-10-25 12:20:25 --> Loader Class Initialized
INFO - 2016-10-25 12:20:25 --> Helper loaded: url_helper
INFO - 2016-10-25 12:20:25 --> Helper loaded: form_helper
INFO - 2016-10-25 12:20:25 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:20:25 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:20:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:20:25 --> Unable to connect to the database
INFO - 2016-10-25 12:20:25 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-25 12:26:28 --> Config Class Initialized
INFO - 2016-10-25 12:26:28 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:26:28 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:26:28 --> Utf8 Class Initialized
INFO - 2016-10-25 12:26:28 --> URI Class Initialized
DEBUG - 2016-10-25 12:26:28 --> No URI present. Default controller set.
INFO - 2016-10-25 12:26:28 --> Router Class Initialized
INFO - 2016-10-25 12:26:28 --> Output Class Initialized
INFO - 2016-10-25 12:26:28 --> Security Class Initialized
DEBUG - 2016-10-25 12:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:26:28 --> Input Class Initialized
INFO - 2016-10-25 12:26:28 --> Language Class Initialized
INFO - 2016-10-25 12:26:28 --> Loader Class Initialized
INFO - 2016-10-25 12:26:28 --> Helper loaded: url_helper
INFO - 2016-10-25 12:26:28 --> Helper loaded: form_helper
INFO - 2016-10-25 12:26:28 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:26:29 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:26:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:26:29 --> Unable to connect to the database
INFO - 2016-10-25 12:26:29 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-25 12:26:29 --> Config Class Initialized
INFO - 2016-10-25 12:26:29 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:26:29 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:26:29 --> Utf8 Class Initialized
INFO - 2016-10-25 12:26:29 --> URI Class Initialized
DEBUG - 2016-10-25 12:26:29 --> No URI present. Default controller set.
INFO - 2016-10-25 12:26:29 --> Router Class Initialized
INFO - 2016-10-25 12:26:29 --> Output Class Initialized
INFO - 2016-10-25 12:26:29 --> Security Class Initialized
DEBUG - 2016-10-25 12:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:26:29 --> Input Class Initialized
INFO - 2016-10-25 12:26:29 --> Language Class Initialized
INFO - 2016-10-25 12:26:29 --> Loader Class Initialized
INFO - 2016-10-25 12:26:29 --> Helper loaded: url_helper
INFO - 2016-10-25 12:26:29 --> Helper loaded: form_helper
INFO - 2016-10-25 12:26:29 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:26:29 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:26:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:26:29 --> Unable to connect to the database
INFO - 2016-10-25 12:26:29 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-25 12:26:30 --> Config Class Initialized
INFO - 2016-10-25 12:26:30 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:26:30 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:26:30 --> Utf8 Class Initialized
INFO - 2016-10-25 12:26:30 --> URI Class Initialized
DEBUG - 2016-10-25 12:26:30 --> No URI present. Default controller set.
INFO - 2016-10-25 12:26:30 --> Router Class Initialized
INFO - 2016-10-25 12:26:30 --> Output Class Initialized
INFO - 2016-10-25 12:26:30 --> Security Class Initialized
DEBUG - 2016-10-25 12:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:26:30 --> Input Class Initialized
INFO - 2016-10-25 12:26:30 --> Language Class Initialized
INFO - 2016-10-25 12:26:30 --> Loader Class Initialized
INFO - 2016-10-25 12:26:30 --> Helper loaded: url_helper
INFO - 2016-10-25 12:26:30 --> Helper loaded: form_helper
INFO - 2016-10-25 12:26:30 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:26:30 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:26:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:26:30 --> Unable to connect to the database
INFO - 2016-10-25 12:26:30 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-25 12:26:30 --> Config Class Initialized
INFO - 2016-10-25 12:26:30 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:26:30 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:26:30 --> Utf8 Class Initialized
INFO - 2016-10-25 12:26:30 --> URI Class Initialized
DEBUG - 2016-10-25 12:26:30 --> No URI present. Default controller set.
INFO - 2016-10-25 12:26:30 --> Router Class Initialized
INFO - 2016-10-25 12:26:30 --> Output Class Initialized
INFO - 2016-10-25 12:26:30 --> Security Class Initialized
DEBUG - 2016-10-25 12:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:26:30 --> Input Class Initialized
INFO - 2016-10-25 12:26:30 --> Language Class Initialized
INFO - 2016-10-25 12:26:30 --> Loader Class Initialized
INFO - 2016-10-25 12:26:30 --> Helper loaded: url_helper
INFO - 2016-10-25 12:26:30 --> Helper loaded: form_helper
INFO - 2016-10-25 12:26:30 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:26:30 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:26:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:26:30 --> Unable to connect to the database
INFO - 2016-10-25 12:26:30 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-25 12:27:09 --> Config Class Initialized
INFO - 2016-10-25 12:27:09 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:27:09 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:27:09 --> Utf8 Class Initialized
INFO - 2016-10-25 12:27:09 --> URI Class Initialized
DEBUG - 2016-10-25 12:27:09 --> No URI present. Default controller set.
INFO - 2016-10-25 12:27:09 --> Router Class Initialized
INFO - 2016-10-25 12:27:09 --> Output Class Initialized
INFO - 2016-10-25 12:27:09 --> Security Class Initialized
DEBUG - 2016-10-25 12:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:27:09 --> Input Class Initialized
INFO - 2016-10-25 12:27:09 --> Language Class Initialized
INFO - 2016-10-25 12:27:09 --> Loader Class Initialized
INFO - 2016-10-25 12:27:09 --> Helper loaded: url_helper
INFO - 2016-10-25 12:27:09 --> Helper loaded: form_helper
INFO - 2016-10-25 12:27:09 --> Database Driver Class Initialized
INFO - 2016-10-25 12:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 12:27:09 --> Controller Class Initialized
INFO - 2016-10-25 12:27:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 12:27:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 12:27:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 12:27:09 --> Final output sent to browser
DEBUG - 2016-10-25 12:27:09 --> Total execution time: 0.0170
INFO - 2016-10-25 12:29:35 --> Config Class Initialized
INFO - 2016-10-25 12:29:35 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:29:35 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:29:35 --> Utf8 Class Initialized
INFO - 2016-10-25 12:29:35 --> URI Class Initialized
DEBUG - 2016-10-25 12:29:35 --> No URI present. Default controller set.
INFO - 2016-10-25 12:29:35 --> Router Class Initialized
INFO - 2016-10-25 12:29:35 --> Output Class Initialized
INFO - 2016-10-25 12:29:35 --> Security Class Initialized
DEBUG - 2016-10-25 12:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:29:35 --> Input Class Initialized
INFO - 2016-10-25 12:29:35 --> Language Class Initialized
INFO - 2016-10-25 12:29:35 --> Loader Class Initialized
INFO - 2016-10-25 12:29:35 --> Helper loaded: url_helper
INFO - 2016-10-25 12:29:35 --> Helper loaded: form_helper
INFO - 2016-10-25 12:29:35 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:29:35 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:29:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:29:35 --> Unable to connect to the database
INFO - 2016-10-25 12:29:35 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-25 12:29:36 --> Config Class Initialized
INFO - 2016-10-25 12:29:36 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:29:36 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:29:36 --> Utf8 Class Initialized
INFO - 2016-10-25 12:29:36 --> URI Class Initialized
DEBUG - 2016-10-25 12:29:36 --> No URI present. Default controller set.
INFO - 2016-10-25 12:29:36 --> Router Class Initialized
INFO - 2016-10-25 12:29:36 --> Output Class Initialized
INFO - 2016-10-25 12:29:36 --> Security Class Initialized
DEBUG - 2016-10-25 12:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:29:36 --> Input Class Initialized
INFO - 2016-10-25 12:29:36 --> Language Class Initialized
INFO - 2016-10-25 12:29:36 --> Loader Class Initialized
INFO - 2016-10-25 12:29:36 --> Helper loaded: url_helper
INFO - 2016-10-25 12:29:36 --> Helper loaded: form_helper
INFO - 2016-10-25 12:29:36 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:29:36 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:29:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:29:36 --> Unable to connect to the database
INFO - 2016-10-25 12:29:36 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-25 12:30:26 --> Config Class Initialized
INFO - 2016-10-25 12:30:26 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:30:26 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:30:26 --> Utf8 Class Initialized
INFO - 2016-10-25 12:30:26 --> URI Class Initialized
DEBUG - 2016-10-25 12:30:26 --> No URI present. Default controller set.
INFO - 2016-10-25 12:30:26 --> Router Class Initialized
INFO - 2016-10-25 12:30:26 --> Output Class Initialized
INFO - 2016-10-25 12:30:26 --> Security Class Initialized
DEBUG - 2016-10-25 12:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:30:26 --> Input Class Initialized
INFO - 2016-10-25 12:30:26 --> Language Class Initialized
INFO - 2016-10-25 12:30:26 --> Loader Class Initialized
INFO - 2016-10-25 12:30:26 --> Helper loaded: url_helper
INFO - 2016-10-25 12:30:26 --> Helper loaded: form_helper
INFO - 2016-10-25 12:30:26 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:30:26 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:30:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:30:26 --> Unable to connect to the database
INFO - 2016-10-25 12:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 12:30:26 --> Controller Class Initialized
INFO - 2016-10-25 12:30:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 12:30:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 12:30:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 12:30:26 --> Final output sent to browser
DEBUG - 2016-10-25 12:30:26 --> Total execution time: 0.0692
INFO - 2016-10-25 12:30:38 --> Config Class Initialized
INFO - 2016-10-25 12:30:38 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:30:38 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:30:38 --> Utf8 Class Initialized
INFO - 2016-10-25 12:30:38 --> URI Class Initialized
DEBUG - 2016-10-25 12:30:38 --> No URI present. Default controller set.
INFO - 2016-10-25 12:30:38 --> Router Class Initialized
INFO - 2016-10-25 12:30:38 --> Output Class Initialized
INFO - 2016-10-25 12:30:38 --> Security Class Initialized
DEBUG - 2016-10-25 12:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:30:38 --> Input Class Initialized
INFO - 2016-10-25 12:30:38 --> Language Class Initialized
INFO - 2016-10-25 12:30:38 --> Loader Class Initialized
INFO - 2016-10-25 12:30:38 --> Helper loaded: url_helper
INFO - 2016-10-25 12:30:38 --> Helper loaded: form_helper
INFO - 2016-10-25 12:30:38 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:30:38 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:30:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:30:38 --> Unable to connect to the database
INFO - 2016-10-25 12:30:38 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-25 12:30:49 --> Config Class Initialized
INFO - 2016-10-25 12:30:49 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:30:49 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:30:49 --> Utf8 Class Initialized
INFO - 2016-10-25 12:30:49 --> URI Class Initialized
DEBUG - 2016-10-25 12:30:49 --> No URI present. Default controller set.
INFO - 2016-10-25 12:30:49 --> Router Class Initialized
INFO - 2016-10-25 12:30:49 --> Output Class Initialized
INFO - 2016-10-25 12:30:49 --> Security Class Initialized
DEBUG - 2016-10-25 12:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:30:49 --> Input Class Initialized
INFO - 2016-10-25 12:30:49 --> Language Class Initialized
INFO - 2016-10-25 12:30:49 --> Loader Class Initialized
INFO - 2016-10-25 12:30:49 --> Helper loaded: url_helper
INFO - 2016-10-25 12:30:49 --> Helper loaded: form_helper
INFO - 2016-10-25 12:30:49 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:30:49 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:30:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:30:49 --> Unable to connect to the database
INFO - 2016-10-25 12:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 12:30:49 --> Controller Class Initialized
INFO - 2016-10-25 12:30:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 12:30:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 12:30:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 12:30:49 --> Final output sent to browser
DEBUG - 2016-10-25 12:30:49 --> Total execution time: 0.0649
INFO - 2016-10-25 12:31:23 --> Config Class Initialized
INFO - 2016-10-25 12:31:23 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:31:23 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:31:23 --> Utf8 Class Initialized
INFO - 2016-10-25 12:31:23 --> URI Class Initialized
DEBUG - 2016-10-25 12:31:23 --> No URI present. Default controller set.
INFO - 2016-10-25 12:31:23 --> Router Class Initialized
INFO - 2016-10-25 12:31:23 --> Output Class Initialized
INFO - 2016-10-25 12:31:23 --> Security Class Initialized
DEBUG - 2016-10-25 12:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:31:23 --> Input Class Initialized
INFO - 2016-10-25 12:31:23 --> Language Class Initialized
INFO - 2016-10-25 12:31:23 --> Loader Class Initialized
INFO - 2016-10-25 12:31:23 --> Helper loaded: url_helper
INFO - 2016-10-25 12:31:23 --> Helper loaded: form_helper
INFO - 2016-10-25 12:31:23 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:31:23 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:31:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:31:23 --> Unable to connect to the database
INFO - 2016-10-25 12:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 12:31:23 --> Controller Class Initialized
INFO - 2016-10-25 12:31:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 12:31:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 12:31:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 12:31:23 --> Final output sent to browser
DEBUG - 2016-10-25 12:31:23 --> Total execution time: 0.0627
INFO - 2016-10-25 12:31:40 --> Config Class Initialized
INFO - 2016-10-25 12:31:40 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:31:40 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:31:40 --> Utf8 Class Initialized
INFO - 2016-10-25 12:31:40 --> URI Class Initialized
DEBUG - 2016-10-25 12:31:40 --> No URI present. Default controller set.
INFO - 2016-10-25 12:31:40 --> Router Class Initialized
INFO - 2016-10-25 12:31:40 --> Output Class Initialized
INFO - 2016-10-25 12:31:40 --> Security Class Initialized
DEBUG - 2016-10-25 12:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:31:40 --> Input Class Initialized
INFO - 2016-10-25 12:31:40 --> Language Class Initialized
INFO - 2016-10-25 12:31:40 --> Loader Class Initialized
INFO - 2016-10-25 12:31:40 --> Helper loaded: url_helper
INFO - 2016-10-25 12:31:40 --> Helper loaded: form_helper
INFO - 2016-10-25 12:31:40 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:31:40 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:31:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:31:40 --> Unable to connect to the database
INFO - 2016-10-25 12:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 12:31:40 --> Controller Class Initialized
INFO - 2016-10-25 12:31:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 12:31:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 12:31:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 12:31:40 --> Final output sent to browser
DEBUG - 2016-10-25 12:31:40 --> Total execution time: 0.0667
INFO - 2016-10-25 12:31:50 --> Config Class Initialized
INFO - 2016-10-25 12:31:50 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:31:50 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:31:50 --> Utf8 Class Initialized
INFO - 2016-10-25 12:31:50 --> URI Class Initialized
INFO - 2016-10-25 12:31:50 --> Router Class Initialized
INFO - 2016-10-25 12:31:50 --> Output Class Initialized
INFO - 2016-10-25 12:31:50 --> Security Class Initialized
DEBUG - 2016-10-25 12:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:31:50 --> Input Class Initialized
INFO - 2016-10-25 12:31:50 --> Language Class Initialized
INFO - 2016-10-25 12:31:50 --> Loader Class Initialized
INFO - 2016-10-25 12:31:50 --> Helper loaded: url_helper
INFO - 2016-10-25 12:31:50 --> Helper loaded: form_helper
INFO - 2016-10-25 12:31:50 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:31:50 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:31:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:31:50 --> Unable to connect to the database
INFO - 2016-10-25 12:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 12:31:50 --> Controller Class Initialized
DEBUG - 2016-10-25 12:31:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-25 12:31:50 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:31:50 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:31:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:31:50 --> Unable to connect to the database
INFO - 2016-10-25 12:31:50 --> Model Class Initialized
ERROR - 2016-10-25 12:31:50 --> Severity: Error --> Call to a member function real_escape_string() on a non-object /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 391
INFO - 2016-10-25 12:32:11 --> Config Class Initialized
INFO - 2016-10-25 12:32:11 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:32:11 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:32:11 --> Utf8 Class Initialized
INFO - 2016-10-25 12:32:11 --> URI Class Initialized
DEBUG - 2016-10-25 12:32:11 --> No URI present. Default controller set.
INFO - 2016-10-25 12:32:11 --> Router Class Initialized
INFO - 2016-10-25 12:32:11 --> Output Class Initialized
INFO - 2016-10-25 12:32:11 --> Security Class Initialized
DEBUG - 2016-10-25 12:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:32:11 --> Input Class Initialized
INFO - 2016-10-25 12:32:11 --> Language Class Initialized
INFO - 2016-10-25 12:32:11 --> Loader Class Initialized
INFO - 2016-10-25 12:32:11 --> Helper loaded: url_helper
INFO - 2016-10-25 12:32:11 --> Helper loaded: form_helper
INFO - 2016-10-25 12:32:11 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:32:11 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:32:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:32:11 --> Unable to connect to the database
INFO - 2016-10-25 12:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 12:32:11 --> Controller Class Initialized
INFO - 2016-10-25 12:32:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 12:32:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 12:32:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 12:32:11 --> Final output sent to browser
DEBUG - 2016-10-25 12:32:11 --> Total execution time: 0.0635
INFO - 2016-10-25 12:32:21 --> Config Class Initialized
INFO - 2016-10-25 12:32:21 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:32:21 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:32:21 --> Utf8 Class Initialized
INFO - 2016-10-25 12:32:21 --> URI Class Initialized
INFO - 2016-10-25 12:32:21 --> Router Class Initialized
INFO - 2016-10-25 12:32:21 --> Output Class Initialized
INFO - 2016-10-25 12:32:21 --> Security Class Initialized
DEBUG - 2016-10-25 12:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:32:21 --> Input Class Initialized
INFO - 2016-10-25 12:32:21 --> Language Class Initialized
INFO - 2016-10-25 12:32:21 --> Loader Class Initialized
INFO - 2016-10-25 12:32:21 --> Helper loaded: url_helper
INFO - 2016-10-25 12:32:21 --> Helper loaded: form_helper
INFO - 2016-10-25 12:32:21 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:32:21 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:32:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:32:21 --> Unable to connect to the database
INFO - 2016-10-25 12:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 12:32:21 --> Controller Class Initialized
DEBUG - 2016-10-25 12:32:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-25 12:32:21 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:32:21 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:32:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:32:21 --> Unable to connect to the database
INFO - 2016-10-25 12:32:21 --> Model Class Initialized
ERROR - 2016-10-25 12:32:21 --> Severity: Error --> Call to a member function real_escape_string() on a non-object /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 391
INFO - 2016-10-25 12:32:28 --> Config Class Initialized
INFO - 2016-10-25 12:32:28 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:32:28 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:32:28 --> Utf8 Class Initialized
INFO - 2016-10-25 12:32:28 --> URI Class Initialized
DEBUG - 2016-10-25 12:32:28 --> No URI present. Default controller set.
INFO - 2016-10-25 12:32:28 --> Router Class Initialized
INFO - 2016-10-25 12:32:28 --> Output Class Initialized
INFO - 2016-10-25 12:32:28 --> Security Class Initialized
DEBUG - 2016-10-25 12:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:32:28 --> Input Class Initialized
INFO - 2016-10-25 12:32:28 --> Language Class Initialized
INFO - 2016-10-25 12:32:28 --> Loader Class Initialized
INFO - 2016-10-25 12:32:28 --> Helper loaded: url_helper
INFO - 2016-10-25 12:32:28 --> Helper loaded: form_helper
INFO - 2016-10-25 12:32:28 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:32:28 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:32:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:32:28 --> Unable to connect to the database
INFO - 2016-10-25 12:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 12:32:28 --> Controller Class Initialized
INFO - 2016-10-25 12:32:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 12:32:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 12:32:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 12:32:28 --> Final output sent to browser
DEBUG - 2016-10-25 12:32:28 --> Total execution time: 0.0639
INFO - 2016-10-25 12:32:34 --> Config Class Initialized
INFO - 2016-10-25 12:32:34 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:32:34 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:32:34 --> Utf8 Class Initialized
INFO - 2016-10-25 12:32:34 --> URI Class Initialized
INFO - 2016-10-25 12:32:34 --> Router Class Initialized
INFO - 2016-10-25 12:32:34 --> Output Class Initialized
INFO - 2016-10-25 12:32:34 --> Security Class Initialized
DEBUG - 2016-10-25 12:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:32:34 --> Input Class Initialized
INFO - 2016-10-25 12:32:34 --> Language Class Initialized
INFO - 2016-10-25 12:32:34 --> Loader Class Initialized
INFO - 2016-10-25 12:32:34 --> Helper loaded: url_helper
INFO - 2016-10-25 12:32:34 --> Helper loaded: form_helper
INFO - 2016-10-25 12:32:34 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:32:34 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:32:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:32:34 --> Unable to connect to the database
INFO - 2016-10-25 12:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 12:32:34 --> Controller Class Initialized
DEBUG - 2016-10-25 12:32:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-25 12:32:34 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:32:34 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:32:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:32:34 --> Unable to connect to the database
INFO - 2016-10-25 12:32:34 --> Model Class Initialized
ERROR - 2016-10-25 12:32:34 --> Severity: Error --> Call to a member function real_escape_string() on a non-object /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 391
INFO - 2016-10-25 12:33:25 --> Config Class Initialized
INFO - 2016-10-25 12:33:25 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:33:25 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:33:25 --> Utf8 Class Initialized
INFO - 2016-10-25 12:33:25 --> URI Class Initialized
INFO - 2016-10-25 12:33:25 --> Router Class Initialized
INFO - 2016-10-25 12:33:25 --> Output Class Initialized
INFO - 2016-10-25 12:33:25 --> Security Class Initialized
DEBUG - 2016-10-25 12:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:33:25 --> Input Class Initialized
INFO - 2016-10-25 12:33:25 --> Language Class Initialized
INFO - 2016-10-25 12:33:25 --> Loader Class Initialized
INFO - 2016-10-25 12:33:25 --> Helper loaded: url_helper
INFO - 2016-10-25 12:33:25 --> Helper loaded: form_helper
INFO - 2016-10-25 12:33:25 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:33:25 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:33:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:33:25 --> Unable to connect to the database
INFO - 2016-10-25 12:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 12:33:25 --> Controller Class Initialized
DEBUG - 2016-10-25 12:33:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-25 12:33:25 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:33:25 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:33:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:33:25 --> Unable to connect to the database
INFO - 2016-10-25 12:33:25 --> Model Class Initialized
ERROR - 2016-10-25 12:33:25 --> Severity: Error --> Call to a member function real_escape_string() on a non-object /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 391
INFO - 2016-10-25 12:33:26 --> Config Class Initialized
INFO - 2016-10-25 12:33:26 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:33:26 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:33:26 --> Utf8 Class Initialized
INFO - 2016-10-25 12:33:26 --> URI Class Initialized
DEBUG - 2016-10-25 12:33:26 --> No URI present. Default controller set.
INFO - 2016-10-25 12:33:26 --> Router Class Initialized
INFO - 2016-10-25 12:33:26 --> Output Class Initialized
INFO - 2016-10-25 12:33:26 --> Security Class Initialized
DEBUG - 2016-10-25 12:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:33:26 --> Input Class Initialized
INFO - 2016-10-25 12:33:26 --> Language Class Initialized
INFO - 2016-10-25 12:33:26 --> Loader Class Initialized
INFO - 2016-10-25 12:33:26 --> Helper loaded: url_helper
INFO - 2016-10-25 12:33:26 --> Helper loaded: form_helper
INFO - 2016-10-25 12:33:26 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:33:26 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:33:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:33:26 --> Unable to connect to the database
INFO - 2016-10-25 12:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 12:33:26 --> Controller Class Initialized
INFO - 2016-10-25 12:33:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 12:33:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 12:33:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 12:33:26 --> Final output sent to browser
DEBUG - 2016-10-25 12:33:26 --> Total execution time: 0.0671
INFO - 2016-10-25 12:34:08 --> Config Class Initialized
INFO - 2016-10-25 12:34:08 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:34:08 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:34:08 --> Utf8 Class Initialized
INFO - 2016-10-25 12:34:08 --> URI Class Initialized
DEBUG - 2016-10-25 12:34:08 --> No URI present. Default controller set.
INFO - 2016-10-25 12:34:08 --> Router Class Initialized
INFO - 2016-10-25 12:34:08 --> Output Class Initialized
INFO - 2016-10-25 12:34:08 --> Security Class Initialized
DEBUG - 2016-10-25 12:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:34:08 --> Input Class Initialized
INFO - 2016-10-25 12:34:08 --> Language Class Initialized
INFO - 2016-10-25 12:34:08 --> Loader Class Initialized
INFO - 2016-10-25 12:34:08 --> Helper loaded: url_helper
INFO - 2016-10-25 12:34:08 --> Helper loaded: form_helper
INFO - 2016-10-25 12:34:08 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:34:08 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysql/mysql_driver.php 135
ERROR - 2016-10-25 12:34:08 --> Severity: Warning --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysql/mysql_driver.php 135
ERROR - 2016-10-25 12:34:08 --> Severity: Warning --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysql/mysql_driver.php 135
ERROR - 2016-10-25 12:34:08 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysql/mysql_driver.php 208
ERROR - 2016-10-25 12:34:08 --> Unable to select database: id26008_teste
ERROR - 2016-10-25 12:34:08 --> Unable to connect to the database
INFO - 2016-10-25 12:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 12:34:08 --> Controller Class Initialized
INFO - 2016-10-25 12:34:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 12:34:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 12:34:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 12:34:08 --> Final output sent to browser
DEBUG - 2016-10-25 12:34:08 --> Total execution time: 0.0771
INFO - 2016-10-25 12:34:17 --> Config Class Initialized
INFO - 2016-10-25 12:34:17 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:34:17 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:34:17 --> Utf8 Class Initialized
INFO - 2016-10-25 12:34:17 --> URI Class Initialized
DEBUG - 2016-10-25 12:34:17 --> No URI present. Default controller set.
INFO - 2016-10-25 12:34:17 --> Router Class Initialized
INFO - 2016-10-25 12:34:17 --> Output Class Initialized
INFO - 2016-10-25 12:34:17 --> Security Class Initialized
DEBUG - 2016-10-25 12:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:34:17 --> Input Class Initialized
INFO - 2016-10-25 12:34:17 --> Language Class Initialized
INFO - 2016-10-25 12:34:17 --> Loader Class Initialized
INFO - 2016-10-25 12:34:17 --> Helper loaded: url_helper
INFO - 2016-10-25 12:34:17 --> Helper loaded: form_helper
INFO - 2016-10-25 12:34:17 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:34:18 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:34:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:34:18 --> Unable to connect to the database
INFO - 2016-10-25 12:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 12:34:18 --> Controller Class Initialized
INFO - 2016-10-25 12:34:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 12:34:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 12:34:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 12:34:18 --> Final output sent to browser
DEBUG - 2016-10-25 12:34:18 --> Total execution time: 0.0642
INFO - 2016-10-25 12:38:36 --> Config Class Initialized
INFO - 2016-10-25 12:38:36 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:38:36 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:38:36 --> Utf8 Class Initialized
INFO - 2016-10-25 12:38:36 --> URI Class Initialized
INFO - 2016-10-25 12:38:36 --> Router Class Initialized
INFO - 2016-10-25 12:38:36 --> Output Class Initialized
INFO - 2016-10-25 12:38:36 --> Security Class Initialized
DEBUG - 2016-10-25 12:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:38:36 --> Input Class Initialized
INFO - 2016-10-25 12:38:36 --> Language Class Initialized
INFO - 2016-10-25 12:38:36 --> Loader Class Initialized
INFO - 2016-10-25 12:38:36 --> Helper loaded: url_helper
INFO - 2016-10-25 12:38:36 --> Helper loaded: form_helper
INFO - 2016-10-25 12:38:36 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:38:36 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:38:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:38:36 --> Unable to connect to the database
INFO - 2016-10-25 12:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 12:38:36 --> Controller Class Initialized
DEBUG - 2016-10-25 12:38:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-25 12:38:36 --> Database Driver Class Initialized
ERROR - 2016-10-25 12:38:36 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:38:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-25 12:38:36 --> Unable to connect to the database
INFO - 2016-10-25 12:38:36 --> Model Class Initialized
ERROR - 2016-10-25 12:38:36 --> Severity: Error --> Call to a member function real_escape_string() on a non-object /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 391
INFO - 2016-10-25 12:39:04 --> Config Class Initialized
INFO - 2016-10-25 12:39:04 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:39:04 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:39:04 --> Utf8 Class Initialized
INFO - 2016-10-25 12:39:04 --> URI Class Initialized
DEBUG - 2016-10-25 12:39:04 --> No URI present. Default controller set.
INFO - 2016-10-25 12:39:04 --> Router Class Initialized
INFO - 2016-10-25 12:39:04 --> Output Class Initialized
INFO - 2016-10-25 12:39:04 --> Security Class Initialized
DEBUG - 2016-10-25 12:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:39:04 --> Input Class Initialized
INFO - 2016-10-25 12:39:04 --> Language Class Initialized
INFO - 2016-10-25 12:39:04 --> Loader Class Initialized
INFO - 2016-10-25 12:39:04 --> Helper loaded: url_helper
INFO - 2016-10-25 12:39:04 --> Helper loaded: form_helper
INFO - 2016-10-25 12:39:04 --> Database Driver Class Initialized
INFO - 2016-10-25 12:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 12:39:04 --> Controller Class Initialized
INFO - 2016-10-25 12:39:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 12:39:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 12:39:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 12:39:04 --> Final output sent to browser
DEBUG - 2016-10-25 12:39:04 --> Total execution time: 0.0203
INFO - 2016-10-25 12:40:47 --> Config Class Initialized
INFO - 2016-10-25 12:40:47 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:40:47 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:40:47 --> Utf8 Class Initialized
INFO - 2016-10-25 12:40:47 --> URI Class Initialized
DEBUG - 2016-10-25 12:40:47 --> No URI present. Default controller set.
INFO - 2016-10-25 12:40:47 --> Router Class Initialized
INFO - 2016-10-25 12:40:47 --> Output Class Initialized
INFO - 2016-10-25 12:40:47 --> Security Class Initialized
DEBUG - 2016-10-25 12:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:40:47 --> Input Class Initialized
INFO - 2016-10-25 12:40:47 --> Language Class Initialized
INFO - 2016-10-25 12:40:47 --> Loader Class Initialized
INFO - 2016-10-25 12:40:47 --> Helper loaded: url_helper
INFO - 2016-10-25 12:40:47 --> Helper loaded: form_helper
INFO - 2016-10-25 12:40:47 --> Database Driver Class Initialized
INFO - 2016-10-25 12:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 12:40:47 --> Controller Class Initialized
INFO - 2016-10-25 12:40:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 12:40:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 12:40:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 12:40:47 --> Final output sent to browser
DEBUG - 2016-10-25 12:40:47 --> Total execution time: 0.0170
INFO - 2016-10-25 12:42:17 --> Config Class Initialized
INFO - 2016-10-25 12:42:17 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:42:17 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:42:17 --> Utf8 Class Initialized
INFO - 2016-10-25 12:42:17 --> URI Class Initialized
DEBUG - 2016-10-25 12:42:17 --> No URI present. Default controller set.
INFO - 2016-10-25 12:42:17 --> Router Class Initialized
INFO - 2016-10-25 12:42:17 --> Output Class Initialized
INFO - 2016-10-25 12:42:17 --> Security Class Initialized
DEBUG - 2016-10-25 12:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:42:17 --> Input Class Initialized
INFO - 2016-10-25 12:42:17 --> Language Class Initialized
INFO - 2016-10-25 12:42:17 --> Loader Class Initialized
INFO - 2016-10-25 12:42:17 --> Helper loaded: url_helper
INFO - 2016-10-25 12:42:17 --> Helper loaded: form_helper
INFO - 2016-10-25 12:42:17 --> Database Driver Class Initialized
INFO - 2016-10-25 12:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 12:42:17 --> Controller Class Initialized
INFO - 2016-10-25 12:42:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 12:42:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 12:42:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 12:42:17 --> Final output sent to browser
DEBUG - 2016-10-25 12:42:17 --> Total execution time: 0.0168
INFO - 2016-10-25 12:44:31 --> Config Class Initialized
INFO - 2016-10-25 12:44:31 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:44:31 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:44:31 --> Utf8 Class Initialized
INFO - 2016-10-25 12:44:31 --> URI Class Initialized
DEBUG - 2016-10-25 12:44:31 --> No URI present. Default controller set.
INFO - 2016-10-25 12:44:31 --> Router Class Initialized
INFO - 2016-10-25 12:44:31 --> Output Class Initialized
INFO - 2016-10-25 12:44:31 --> Security Class Initialized
DEBUG - 2016-10-25 12:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:44:31 --> Input Class Initialized
INFO - 2016-10-25 12:44:31 --> Language Class Initialized
INFO - 2016-10-25 12:44:31 --> Loader Class Initialized
INFO - 2016-10-25 12:44:31 --> Helper loaded: url_helper
INFO - 2016-10-25 12:44:31 --> Helper loaded: form_helper
INFO - 2016-10-25 12:44:31 --> Database Driver Class Initialized
INFO - 2016-10-25 12:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 12:44:31 --> Controller Class Initialized
INFO - 2016-10-25 12:44:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 12:44:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 12:44:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 12:44:31 --> Final output sent to browser
DEBUG - 2016-10-25 12:44:31 --> Total execution time: 0.0195
INFO - 2016-10-25 12:44:43 --> Config Class Initialized
INFO - 2016-10-25 12:44:43 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:44:43 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:44:43 --> Utf8 Class Initialized
INFO - 2016-10-25 12:44:43 --> URI Class Initialized
DEBUG - 2016-10-25 12:44:43 --> No URI present. Default controller set.
INFO - 2016-10-25 12:44:43 --> Router Class Initialized
INFO - 2016-10-25 12:44:43 --> Output Class Initialized
INFO - 2016-10-25 12:44:43 --> Security Class Initialized
DEBUG - 2016-10-25 12:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:44:43 --> Input Class Initialized
INFO - 2016-10-25 12:44:43 --> Language Class Initialized
INFO - 2016-10-25 12:44:43 --> Loader Class Initialized
INFO - 2016-10-25 12:44:43 --> Helper loaded: url_helper
INFO - 2016-10-25 12:44:43 --> Helper loaded: form_helper
INFO - 2016-10-25 12:44:43 --> Database Driver Class Initialized
INFO - 2016-10-25 12:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 12:44:43 --> Controller Class Initialized
INFO - 2016-10-25 12:44:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 12:44:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 12:44:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 12:44:43 --> Final output sent to browser
DEBUG - 2016-10-25 12:44:43 --> Total execution time: 0.0171
INFO - 2016-10-25 12:56:29 --> Config Class Initialized
INFO - 2016-10-25 12:56:29 --> Hooks Class Initialized
DEBUG - 2016-10-25 12:56:29 --> UTF-8 Support Enabled
INFO - 2016-10-25 12:56:29 --> Utf8 Class Initialized
INFO - 2016-10-25 12:56:29 --> URI Class Initialized
DEBUG - 2016-10-25 12:56:29 --> No URI present. Default controller set.
INFO - 2016-10-25 12:56:29 --> Router Class Initialized
INFO - 2016-10-25 12:56:29 --> Output Class Initialized
INFO - 2016-10-25 12:56:29 --> Security Class Initialized
DEBUG - 2016-10-25 12:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 12:56:29 --> Input Class Initialized
INFO - 2016-10-25 12:56:29 --> Language Class Initialized
INFO - 2016-10-25 12:56:29 --> Loader Class Initialized
INFO - 2016-10-25 12:56:29 --> Helper loaded: url_helper
INFO - 2016-10-25 12:56:29 --> Helper loaded: form_helper
INFO - 2016-10-25 12:56:29 --> Database Driver Class Initialized
INFO - 2016-10-25 12:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 12:56:29 --> Controller Class Initialized
INFO - 2016-10-25 12:56:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 12:56:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 12:56:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 12:56:29 --> Final output sent to browser
DEBUG - 2016-10-25 12:56:29 --> Total execution time: 0.0171
INFO - 2016-10-25 13:28:22 --> Config Class Initialized
INFO - 2016-10-25 13:28:22 --> Hooks Class Initialized
DEBUG - 2016-10-25 13:28:22 --> UTF-8 Support Enabled
INFO - 2016-10-25 13:28:22 --> Utf8 Class Initialized
INFO - 2016-10-25 13:28:22 --> URI Class Initialized
INFO - 2016-10-25 13:28:22 --> Router Class Initialized
INFO - 2016-10-25 13:28:22 --> Output Class Initialized
INFO - 2016-10-25 13:28:22 --> Security Class Initialized
DEBUG - 2016-10-25 13:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 13:28:22 --> Input Class Initialized
INFO - 2016-10-25 13:28:22 --> Language Class Initialized
INFO - 2016-10-25 13:28:22 --> Loader Class Initialized
INFO - 2016-10-25 13:28:22 --> Helper loaded: url_helper
INFO - 2016-10-25 13:28:22 --> Helper loaded: form_helper
INFO - 2016-10-25 13:28:22 --> Database Driver Class Initialized
INFO - 2016-10-25 13:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 13:28:22 --> Controller Class Initialized
DEBUG - 2016-10-25 13:28:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-25 13:28:22 --> Model Class Initialized
INFO - 2016-10-25 13:28:22 --> Final output sent to browser
DEBUG - 2016-10-25 13:28:22 --> Total execution time: 0.0183
INFO - 2016-10-25 13:28:25 --> Config Class Initialized
INFO - 2016-10-25 13:28:25 --> Hooks Class Initialized
DEBUG - 2016-10-25 13:28:25 --> UTF-8 Support Enabled
INFO - 2016-10-25 13:28:25 --> Utf8 Class Initialized
INFO - 2016-10-25 13:28:25 --> URI Class Initialized
DEBUG - 2016-10-25 13:28:25 --> No URI present. Default controller set.
INFO - 2016-10-25 13:28:25 --> Router Class Initialized
INFO - 2016-10-25 13:28:25 --> Output Class Initialized
INFO - 2016-10-25 13:28:25 --> Security Class Initialized
DEBUG - 2016-10-25 13:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 13:28:25 --> Input Class Initialized
INFO - 2016-10-25 13:28:25 --> Language Class Initialized
INFO - 2016-10-25 13:28:25 --> Loader Class Initialized
INFO - 2016-10-25 13:28:25 --> Helper loaded: url_helper
INFO - 2016-10-25 13:28:25 --> Helper loaded: form_helper
INFO - 2016-10-25 13:28:25 --> Database Driver Class Initialized
INFO - 2016-10-25 13:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 13:28:25 --> Controller Class Initialized
INFO - 2016-10-25 13:28:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 13:28:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 13:28:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 13:28:25 --> Final output sent to browser
DEBUG - 2016-10-25 13:28:25 --> Total execution time: 0.0161
INFO - 2016-10-25 13:30:05 --> Config Class Initialized
INFO - 2016-10-25 13:30:05 --> Hooks Class Initialized
DEBUG - 2016-10-25 13:30:05 --> UTF-8 Support Enabled
INFO - 2016-10-25 13:30:05 --> Utf8 Class Initialized
INFO - 2016-10-25 13:30:05 --> URI Class Initialized
DEBUG - 2016-10-25 13:30:05 --> No URI present. Default controller set.
INFO - 2016-10-25 13:30:05 --> Router Class Initialized
INFO - 2016-10-25 13:30:05 --> Output Class Initialized
INFO - 2016-10-25 13:30:05 --> Security Class Initialized
DEBUG - 2016-10-25 13:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 13:30:05 --> Input Class Initialized
INFO - 2016-10-25 13:30:05 --> Language Class Initialized
INFO - 2016-10-25 13:30:05 --> Loader Class Initialized
INFO - 2016-10-25 13:30:05 --> Helper loaded: url_helper
INFO - 2016-10-25 13:30:05 --> Helper loaded: form_helper
INFO - 2016-10-25 13:30:05 --> Database Driver Class Initialized
INFO - 2016-10-25 13:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 13:30:05 --> Controller Class Initialized
INFO - 2016-10-25 13:30:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 13:30:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 13:30:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 13:30:05 --> Final output sent to browser
DEBUG - 2016-10-25 13:30:05 --> Total execution time: 0.0189
INFO - 2016-10-25 13:30:07 --> Config Class Initialized
INFO - 2016-10-25 13:30:07 --> Hooks Class Initialized
DEBUG - 2016-10-25 13:30:07 --> UTF-8 Support Enabled
INFO - 2016-10-25 13:30:07 --> Utf8 Class Initialized
INFO - 2016-10-25 13:30:07 --> URI Class Initialized
DEBUG - 2016-10-25 13:30:07 --> No URI present. Default controller set.
INFO - 2016-10-25 13:30:07 --> Router Class Initialized
INFO - 2016-10-25 13:30:07 --> Output Class Initialized
INFO - 2016-10-25 13:30:07 --> Security Class Initialized
DEBUG - 2016-10-25 13:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 13:30:07 --> Input Class Initialized
INFO - 2016-10-25 13:30:07 --> Language Class Initialized
INFO - 2016-10-25 13:30:07 --> Loader Class Initialized
INFO - 2016-10-25 13:30:07 --> Helper loaded: url_helper
INFO - 2016-10-25 13:30:07 --> Helper loaded: form_helper
INFO - 2016-10-25 13:30:07 --> Database Driver Class Initialized
INFO - 2016-10-25 13:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 13:30:07 --> Controller Class Initialized
INFO - 2016-10-25 13:30:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 13:30:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 13:30:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 13:30:07 --> Final output sent to browser
DEBUG - 2016-10-25 13:30:07 --> Total execution time: 0.0159
INFO - 2016-10-25 13:30:40 --> Config Class Initialized
INFO - 2016-10-25 13:30:40 --> Hooks Class Initialized
DEBUG - 2016-10-25 13:30:40 --> UTF-8 Support Enabled
INFO - 2016-10-25 13:30:40 --> Utf8 Class Initialized
INFO - 2016-10-25 13:30:40 --> URI Class Initialized
DEBUG - 2016-10-25 13:30:40 --> No URI present. Default controller set.
INFO - 2016-10-25 13:30:40 --> Router Class Initialized
INFO - 2016-10-25 13:30:40 --> Output Class Initialized
INFO - 2016-10-25 13:30:40 --> Security Class Initialized
DEBUG - 2016-10-25 13:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 13:30:40 --> Input Class Initialized
INFO - 2016-10-25 13:30:40 --> Language Class Initialized
INFO - 2016-10-25 13:30:40 --> Loader Class Initialized
INFO - 2016-10-25 13:30:40 --> Helper loaded: url_helper
INFO - 2016-10-25 13:30:40 --> Helper loaded: form_helper
INFO - 2016-10-25 13:30:40 --> Database Driver Class Initialized
INFO - 2016-10-25 13:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 13:30:40 --> Controller Class Initialized
INFO - 2016-10-25 13:30:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 13:30:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 13:30:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 13:30:40 --> Final output sent to browser
DEBUG - 2016-10-25 13:30:40 --> Total execution time: 0.0171
INFO - 2016-10-25 13:30:50 --> Config Class Initialized
INFO - 2016-10-25 13:30:50 --> Hooks Class Initialized
DEBUG - 2016-10-25 13:30:50 --> UTF-8 Support Enabled
INFO - 2016-10-25 13:30:50 --> Utf8 Class Initialized
INFO - 2016-10-25 13:30:50 --> URI Class Initialized
DEBUG - 2016-10-25 13:30:50 --> No URI present. Default controller set.
INFO - 2016-10-25 13:30:50 --> Router Class Initialized
INFO - 2016-10-25 13:30:50 --> Output Class Initialized
INFO - 2016-10-25 13:30:50 --> Security Class Initialized
DEBUG - 2016-10-25 13:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 13:30:50 --> Input Class Initialized
INFO - 2016-10-25 13:30:50 --> Language Class Initialized
INFO - 2016-10-25 13:30:50 --> Loader Class Initialized
INFO - 2016-10-25 13:30:50 --> Helper loaded: url_helper
INFO - 2016-10-25 13:30:50 --> Helper loaded: form_helper
INFO - 2016-10-25 13:30:50 --> Database Driver Class Initialized
INFO - 2016-10-25 13:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 13:30:50 --> Controller Class Initialized
INFO - 2016-10-25 13:30:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 13:30:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 13:30:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 13:30:50 --> Final output sent to browser
DEBUG - 2016-10-25 13:30:50 --> Total execution time: 0.0165
INFO - 2016-10-25 13:30:52 --> Config Class Initialized
INFO - 2016-10-25 13:30:52 --> Hooks Class Initialized
DEBUG - 2016-10-25 13:30:52 --> UTF-8 Support Enabled
INFO - 2016-10-25 13:30:52 --> Utf8 Class Initialized
INFO - 2016-10-25 13:30:52 --> URI Class Initialized
DEBUG - 2016-10-25 13:30:52 --> No URI present. Default controller set.
INFO - 2016-10-25 13:30:52 --> Router Class Initialized
INFO - 2016-10-25 13:30:52 --> Output Class Initialized
INFO - 2016-10-25 13:30:52 --> Security Class Initialized
DEBUG - 2016-10-25 13:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 13:30:52 --> Input Class Initialized
INFO - 2016-10-25 13:30:52 --> Language Class Initialized
INFO - 2016-10-25 13:30:52 --> Loader Class Initialized
INFO - 2016-10-25 13:30:52 --> Helper loaded: url_helper
INFO - 2016-10-25 13:30:52 --> Helper loaded: form_helper
INFO - 2016-10-25 13:30:52 --> Database Driver Class Initialized
INFO - 2016-10-25 13:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 13:30:52 --> Controller Class Initialized
INFO - 2016-10-25 13:30:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 13:30:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 13:30:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 13:30:52 --> Final output sent to browser
DEBUG - 2016-10-25 13:30:52 --> Total execution time: 0.0191
INFO - 2016-10-25 13:30:54 --> Config Class Initialized
INFO - 2016-10-25 13:30:54 --> Hooks Class Initialized
DEBUG - 2016-10-25 13:30:54 --> UTF-8 Support Enabled
INFO - 2016-10-25 13:30:54 --> Utf8 Class Initialized
INFO - 2016-10-25 13:30:54 --> URI Class Initialized
DEBUG - 2016-10-25 13:30:54 --> No URI present. Default controller set.
INFO - 2016-10-25 13:30:54 --> Router Class Initialized
INFO - 2016-10-25 13:30:54 --> Output Class Initialized
INFO - 2016-10-25 13:30:54 --> Security Class Initialized
DEBUG - 2016-10-25 13:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 13:30:54 --> Input Class Initialized
INFO - 2016-10-25 13:30:54 --> Language Class Initialized
INFO - 2016-10-25 13:30:54 --> Loader Class Initialized
INFO - 2016-10-25 13:30:54 --> Helper loaded: url_helper
INFO - 2016-10-25 13:30:54 --> Helper loaded: form_helper
INFO - 2016-10-25 13:30:54 --> Database Driver Class Initialized
INFO - 2016-10-25 13:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 13:30:54 --> Controller Class Initialized
INFO - 2016-10-25 13:30:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 13:30:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 13:30:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 13:30:54 --> Final output sent to browser
DEBUG - 2016-10-25 13:30:54 --> Total execution time: 0.0164
INFO - 2016-10-25 16:20:26 --> Config Class Initialized
INFO - 2016-10-25 16:20:26 --> Hooks Class Initialized
DEBUG - 2016-10-25 16:20:26 --> UTF-8 Support Enabled
INFO - 2016-10-25 16:20:26 --> Utf8 Class Initialized
INFO - 2016-10-25 16:20:26 --> URI Class Initialized
DEBUG - 2016-10-25 16:20:26 --> No URI present. Default controller set.
INFO - 2016-10-25 16:20:26 --> Router Class Initialized
INFO - 2016-10-25 16:20:26 --> Output Class Initialized
INFO - 2016-10-25 16:20:26 --> Security Class Initialized
DEBUG - 2016-10-25 16:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 16:20:26 --> Input Class Initialized
INFO - 2016-10-25 16:20:26 --> Language Class Initialized
INFO - 2016-10-25 16:20:26 --> Loader Class Initialized
INFO - 2016-10-25 16:20:26 --> Helper loaded: url_helper
INFO - 2016-10-25 16:20:26 --> Helper loaded: form_helper
INFO - 2016-10-25 16:20:26 --> Database Driver Class Initialized
INFO - 2016-10-25 16:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 16:20:26 --> Controller Class Initialized
INFO - 2016-10-25 16:20:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 16:20:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 16:20:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 16:20:26 --> Final output sent to browser
DEBUG - 2016-10-25 16:20:26 --> Total execution time: 0.0173
INFO - 2016-10-25 16:20:49 --> Config Class Initialized
INFO - 2016-10-25 16:20:49 --> Hooks Class Initialized
DEBUG - 2016-10-25 16:20:49 --> UTF-8 Support Enabled
INFO - 2016-10-25 16:20:49 --> Utf8 Class Initialized
INFO - 2016-10-25 16:20:49 --> URI Class Initialized
DEBUG - 2016-10-25 16:20:49 --> No URI present. Default controller set.
INFO - 2016-10-25 16:20:49 --> Router Class Initialized
INFO - 2016-10-25 16:20:49 --> Output Class Initialized
INFO - 2016-10-25 16:20:49 --> Security Class Initialized
DEBUG - 2016-10-25 16:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 16:20:49 --> Input Class Initialized
INFO - 2016-10-25 16:20:49 --> Language Class Initialized
INFO - 2016-10-25 16:20:49 --> Loader Class Initialized
INFO - 2016-10-25 16:20:49 --> Helper loaded: url_helper
INFO - 2016-10-25 16:20:49 --> Helper loaded: form_helper
INFO - 2016-10-25 16:20:49 --> Database Driver Class Initialized
INFO - 2016-10-25 16:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 16:20:49 --> Controller Class Initialized
INFO - 2016-10-25 16:20:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 16:20:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 16:20:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 16:20:49 --> Final output sent to browser
DEBUG - 2016-10-25 16:20:49 --> Total execution time: 0.0184
INFO - 2016-10-25 16:33:11 --> Config Class Initialized
INFO - 2016-10-25 16:33:11 --> Hooks Class Initialized
DEBUG - 2016-10-25 16:33:11 --> UTF-8 Support Enabled
INFO - 2016-10-25 16:33:11 --> Utf8 Class Initialized
INFO - 2016-10-25 16:33:11 --> URI Class Initialized
DEBUG - 2016-10-25 16:33:11 --> No URI present. Default controller set.
INFO - 2016-10-25 16:33:11 --> Router Class Initialized
INFO - 2016-10-25 16:33:11 --> Output Class Initialized
INFO - 2016-10-25 16:33:11 --> Security Class Initialized
DEBUG - 2016-10-25 16:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 16:33:11 --> Input Class Initialized
INFO - 2016-10-25 16:33:11 --> Language Class Initialized
INFO - 2016-10-25 16:33:11 --> Loader Class Initialized
INFO - 2016-10-25 16:33:11 --> Helper loaded: url_helper
INFO - 2016-10-25 16:33:11 --> Helper loaded: form_helper
INFO - 2016-10-25 16:33:11 --> Database Driver Class Initialized
INFO - 2016-10-25 16:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 16:33:11 --> Controller Class Initialized
INFO - 2016-10-25 16:33:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 16:33:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 16:33:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 16:33:11 --> Final output sent to browser
DEBUG - 2016-10-25 16:33:11 --> Total execution time: 0.0180
INFO - 2016-10-25 16:33:32 --> Config Class Initialized
INFO - 2016-10-25 16:33:32 --> Hooks Class Initialized
DEBUG - 2016-10-25 16:33:32 --> UTF-8 Support Enabled
INFO - 2016-10-25 16:33:32 --> Utf8 Class Initialized
INFO - 2016-10-25 16:33:32 --> URI Class Initialized
DEBUG - 2016-10-25 16:33:32 --> No URI present. Default controller set.
INFO - 2016-10-25 16:33:32 --> Router Class Initialized
INFO - 2016-10-25 16:33:32 --> Output Class Initialized
INFO - 2016-10-25 16:33:32 --> Security Class Initialized
DEBUG - 2016-10-25 16:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 16:33:32 --> Input Class Initialized
INFO - 2016-10-25 16:33:32 --> Language Class Initialized
INFO - 2016-10-25 16:33:32 --> Loader Class Initialized
INFO - 2016-10-25 16:33:32 --> Helper loaded: url_helper
INFO - 2016-10-25 16:33:32 --> Helper loaded: form_helper
INFO - 2016-10-25 16:33:32 --> Database Driver Class Initialized
INFO - 2016-10-25 16:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 16:33:32 --> Controller Class Initialized
INFO - 2016-10-25 16:33:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 16:33:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 16:33:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 16:33:32 --> Final output sent to browser
DEBUG - 2016-10-25 16:33:32 --> Total execution time: 0.0203
INFO - 2016-10-25 16:35:25 --> Config Class Initialized
INFO - 2016-10-25 16:35:25 --> Hooks Class Initialized
DEBUG - 2016-10-25 16:35:25 --> UTF-8 Support Enabled
INFO - 2016-10-25 16:35:25 --> Utf8 Class Initialized
INFO - 2016-10-25 16:35:25 --> URI Class Initialized
DEBUG - 2016-10-25 16:35:25 --> No URI present. Default controller set.
INFO - 2016-10-25 16:35:25 --> Router Class Initialized
INFO - 2016-10-25 16:35:25 --> Output Class Initialized
INFO - 2016-10-25 16:35:25 --> Security Class Initialized
DEBUG - 2016-10-25 16:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 16:35:25 --> Input Class Initialized
INFO - 2016-10-25 16:35:25 --> Language Class Initialized
INFO - 2016-10-25 16:35:25 --> Loader Class Initialized
INFO - 2016-10-25 16:35:25 --> Helper loaded: url_helper
INFO - 2016-10-25 16:35:25 --> Helper loaded: form_helper
INFO - 2016-10-25 16:35:25 --> Database Driver Class Initialized
INFO - 2016-10-25 16:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 16:35:25 --> Controller Class Initialized
INFO - 2016-10-25 16:35:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 16:35:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 16:35:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 16:35:25 --> Final output sent to browser
DEBUG - 2016-10-25 16:35:25 --> Total execution time: 0.0176
INFO - 2016-10-25 16:55:44 --> Config Class Initialized
INFO - 2016-10-25 16:55:44 --> Hooks Class Initialized
DEBUG - 2016-10-25 16:55:44 --> UTF-8 Support Enabled
INFO - 2016-10-25 16:55:44 --> Utf8 Class Initialized
INFO - 2016-10-25 16:55:44 --> URI Class Initialized
INFO - 2016-10-25 16:55:44 --> Router Class Initialized
INFO - 2016-10-25 16:55:44 --> Output Class Initialized
INFO - 2016-10-25 16:55:44 --> Security Class Initialized
DEBUG - 2016-10-25 16:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 16:55:44 --> Input Class Initialized
INFO - 2016-10-25 16:55:44 --> Language Class Initialized
INFO - 2016-10-25 16:55:44 --> Loader Class Initialized
INFO - 2016-10-25 16:55:44 --> Helper loaded: url_helper
INFO - 2016-10-25 16:55:44 --> Helper loaded: form_helper
INFO - 2016-10-25 16:55:44 --> Database Driver Class Initialized
INFO - 2016-10-25 16:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 16:55:44 --> Controller Class Initialized
DEBUG - 2016-10-25 16:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-25 16:55:44 --> Model Class Initialized
INFO - 2016-10-25 16:55:44 --> Final output sent to browser
DEBUG - 2016-10-25 16:55:44 --> Total execution time: 0.0213
INFO - 2016-10-25 16:55:44 --> Config Class Initialized
INFO - 2016-10-25 16:55:44 --> Hooks Class Initialized
DEBUG - 2016-10-25 16:55:44 --> UTF-8 Support Enabled
INFO - 2016-10-25 16:55:44 --> Utf8 Class Initialized
INFO - 2016-10-25 16:55:44 --> URI Class Initialized
DEBUG - 2016-10-25 16:55:44 --> No URI present. Default controller set.
INFO - 2016-10-25 16:55:44 --> Router Class Initialized
INFO - 2016-10-25 16:55:44 --> Output Class Initialized
INFO - 2016-10-25 16:55:44 --> Security Class Initialized
DEBUG - 2016-10-25 16:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 16:55:44 --> Input Class Initialized
INFO - 2016-10-25 16:55:44 --> Language Class Initialized
INFO - 2016-10-25 16:55:44 --> Loader Class Initialized
INFO - 2016-10-25 16:55:44 --> Helper loaded: url_helper
INFO - 2016-10-25 16:55:44 --> Helper loaded: form_helper
INFO - 2016-10-25 16:55:44 --> Database Driver Class Initialized
INFO - 2016-10-25 16:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 16:55:44 --> Controller Class Initialized
INFO - 2016-10-25 16:55:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 16:55:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-25 16:55:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-25 16:55:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 16:55:44 --> Final output sent to browser
DEBUG - 2016-10-25 16:55:44 --> Total execution time: 0.0363
INFO - 2016-10-25 17:23:58 --> Config Class Initialized
INFO - 2016-10-25 17:23:58 --> Hooks Class Initialized
DEBUG - 2016-10-25 17:23:58 --> UTF-8 Support Enabled
INFO - 2016-10-25 17:23:58 --> Utf8 Class Initialized
INFO - 2016-10-25 17:23:58 --> URI Class Initialized
DEBUG - 2016-10-25 17:23:58 --> No URI present. Default controller set.
INFO - 2016-10-25 17:23:58 --> Router Class Initialized
INFO - 2016-10-25 17:23:58 --> Output Class Initialized
INFO - 2016-10-25 17:23:58 --> Security Class Initialized
DEBUG - 2016-10-25 17:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 17:23:58 --> Input Class Initialized
INFO - 2016-10-25 17:23:58 --> Language Class Initialized
INFO - 2016-10-25 17:23:58 --> Loader Class Initialized
INFO - 2016-10-25 17:23:58 --> Helper loaded: url_helper
INFO - 2016-10-25 17:23:58 --> Helper loaded: form_helper
INFO - 2016-10-25 17:23:58 --> Database Driver Class Initialized
INFO - 2016-10-25 17:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 17:23:58 --> Controller Class Initialized
INFO - 2016-10-25 17:23:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 17:23:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-25 17:23:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-25 17:23:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 17:23:58 --> Final output sent to browser
DEBUG - 2016-10-25 17:23:58 --> Total execution time: 0.0178
INFO - 2016-10-25 17:43:33 --> Config Class Initialized
INFO - 2016-10-25 17:43:33 --> Hooks Class Initialized
DEBUG - 2016-10-25 17:43:33 --> UTF-8 Support Enabled
INFO - 2016-10-25 17:43:33 --> Utf8 Class Initialized
INFO - 2016-10-25 17:43:33 --> URI Class Initialized
DEBUG - 2016-10-25 17:43:33 --> No URI present. Default controller set.
INFO - 2016-10-25 17:43:33 --> Router Class Initialized
INFO - 2016-10-25 17:43:33 --> Output Class Initialized
INFO - 2016-10-25 17:43:33 --> Security Class Initialized
DEBUG - 2016-10-25 17:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 17:43:33 --> Input Class Initialized
INFO - 2016-10-25 17:43:33 --> Language Class Initialized
INFO - 2016-10-25 17:43:33 --> Loader Class Initialized
INFO - 2016-10-25 17:43:33 --> Helper loaded: url_helper
INFO - 2016-10-25 17:43:33 --> Helper loaded: form_helper
INFO - 2016-10-25 17:43:33 --> Database Driver Class Initialized
INFO - 2016-10-25 17:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 17:43:33 --> Controller Class Initialized
INFO - 2016-10-25 17:43:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 17:43:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-25 17:43:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-25 17:43:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 17:43:33 --> Final output sent to browser
DEBUG - 2016-10-25 17:43:33 --> Total execution time: 0.0204
INFO - 2016-10-25 18:14:39 --> Config Class Initialized
INFO - 2016-10-25 18:14:39 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:14:39 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:14:39 --> Utf8 Class Initialized
INFO - 2016-10-25 18:14:39 --> URI Class Initialized
INFO - 2016-10-25 18:14:39 --> Router Class Initialized
INFO - 2016-10-25 18:14:39 --> Output Class Initialized
INFO - 2016-10-25 18:14:39 --> Security Class Initialized
DEBUG - 2016-10-25 18:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:14:39 --> Input Class Initialized
INFO - 2016-10-25 18:14:39 --> Language Class Initialized
INFO - 2016-10-25 18:14:39 --> Loader Class Initialized
INFO - 2016-10-25 18:14:39 --> Helper loaded: url_helper
INFO - 2016-10-25 18:14:39 --> Helper loaded: form_helper
INFO - 2016-10-25 18:14:39 --> Database Driver Class Initialized
INFO - 2016-10-25 18:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:14:39 --> Controller Class Initialized
DEBUG - 2016-10-25 18:14:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-25 18:14:39 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-25 18:14:39 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-25 18:14:39 --> Config Class Initialized
INFO - 2016-10-25 18:14:39 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:14:39 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:14:39 --> Utf8 Class Initialized
INFO - 2016-10-25 18:14:39 --> URI Class Initialized
DEBUG - 2016-10-25 18:14:39 --> No URI present. Default controller set.
INFO - 2016-10-25 18:14:39 --> Router Class Initialized
INFO - 2016-10-25 18:14:39 --> Output Class Initialized
INFO - 2016-10-25 18:14:39 --> Security Class Initialized
DEBUG - 2016-10-25 18:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:14:39 --> Input Class Initialized
INFO - 2016-10-25 18:14:39 --> Language Class Initialized
INFO - 2016-10-25 18:14:39 --> Loader Class Initialized
INFO - 2016-10-25 18:14:39 --> Helper loaded: url_helper
INFO - 2016-10-25 18:14:39 --> Helper loaded: form_helper
INFO - 2016-10-25 18:14:39 --> Database Driver Class Initialized
INFO - 2016-10-25 18:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:14:39 --> Controller Class Initialized
INFO - 2016-10-25 18:14:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 18:14:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 18:14:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 18:14:39 --> Final output sent to browser
DEBUG - 2016-10-25 18:14:39 --> Total execution time: 0.0151
INFO - 2016-10-25 18:14:51 --> Config Class Initialized
INFO - 2016-10-25 18:14:51 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:14:51 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:14:51 --> Utf8 Class Initialized
INFO - 2016-10-25 18:14:51 --> URI Class Initialized
INFO - 2016-10-25 18:14:51 --> Router Class Initialized
INFO - 2016-10-25 18:14:51 --> Output Class Initialized
INFO - 2016-10-25 18:14:51 --> Security Class Initialized
DEBUG - 2016-10-25 18:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:14:51 --> Input Class Initialized
INFO - 2016-10-25 18:14:51 --> Language Class Initialized
INFO - 2016-10-25 18:14:51 --> Loader Class Initialized
INFO - 2016-10-25 18:14:51 --> Helper loaded: url_helper
INFO - 2016-10-25 18:14:51 --> Helper loaded: form_helper
INFO - 2016-10-25 18:14:51 --> Database Driver Class Initialized
INFO - 2016-10-25 18:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:14:51 --> Controller Class Initialized
DEBUG - 2016-10-25 18:14:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-25 18:14:51 --> Model Class Initialized
INFO - 2016-10-25 18:14:51 --> Final output sent to browser
DEBUG - 2016-10-25 18:14:51 --> Total execution time: 0.0192
INFO - 2016-10-25 18:14:51 --> Config Class Initialized
INFO - 2016-10-25 18:14:51 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:14:51 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:14:51 --> Utf8 Class Initialized
INFO - 2016-10-25 18:14:51 --> URI Class Initialized
DEBUG - 2016-10-25 18:14:51 --> No URI present. Default controller set.
INFO - 2016-10-25 18:14:51 --> Router Class Initialized
INFO - 2016-10-25 18:14:51 --> Output Class Initialized
INFO - 2016-10-25 18:14:51 --> Security Class Initialized
DEBUG - 2016-10-25 18:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:14:51 --> Input Class Initialized
INFO - 2016-10-25 18:14:51 --> Language Class Initialized
INFO - 2016-10-25 18:14:51 --> Loader Class Initialized
INFO - 2016-10-25 18:14:51 --> Helper loaded: url_helper
INFO - 2016-10-25 18:14:51 --> Helper loaded: form_helper
INFO - 2016-10-25 18:14:51 --> Database Driver Class Initialized
INFO - 2016-10-25 18:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:14:51 --> Controller Class Initialized
INFO - 2016-10-25 18:14:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 18:14:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-25 18:14:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-25 18:14:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 18:14:51 --> Final output sent to browser
DEBUG - 2016-10-25 18:14:51 --> Total execution time: 0.0158
INFO - 2016-10-25 18:15:30 --> Config Class Initialized
INFO - 2016-10-25 18:15:30 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:15:30 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:15:30 --> Utf8 Class Initialized
INFO - 2016-10-25 18:15:30 --> URI Class Initialized
INFO - 2016-10-25 18:15:30 --> Router Class Initialized
INFO - 2016-10-25 18:15:30 --> Output Class Initialized
INFO - 2016-10-25 18:15:30 --> Security Class Initialized
DEBUG - 2016-10-25 18:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:15:30 --> Input Class Initialized
INFO - 2016-10-25 18:15:30 --> Language Class Initialized
INFO - 2016-10-25 18:15:30 --> Loader Class Initialized
INFO - 2016-10-25 18:15:30 --> Helper loaded: url_helper
INFO - 2016-10-25 18:15:30 --> Helper loaded: form_helper
INFO - 2016-10-25 18:15:30 --> Database Driver Class Initialized
INFO - 2016-10-25 18:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:15:30 --> Controller Class Initialized
DEBUG - 2016-10-25 18:15:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-25 18:15:30 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-25 18:15:30 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-25 18:15:30 --> Config Class Initialized
INFO - 2016-10-25 18:15:30 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:15:30 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:15:30 --> Utf8 Class Initialized
INFO - 2016-10-25 18:15:30 --> URI Class Initialized
DEBUG - 2016-10-25 18:15:30 --> No URI present. Default controller set.
INFO - 2016-10-25 18:15:30 --> Router Class Initialized
INFO - 2016-10-25 18:15:30 --> Output Class Initialized
INFO - 2016-10-25 18:15:30 --> Security Class Initialized
DEBUG - 2016-10-25 18:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:15:30 --> Input Class Initialized
INFO - 2016-10-25 18:15:30 --> Language Class Initialized
INFO - 2016-10-25 18:15:30 --> Loader Class Initialized
INFO - 2016-10-25 18:15:30 --> Helper loaded: url_helper
INFO - 2016-10-25 18:15:30 --> Helper loaded: form_helper
INFO - 2016-10-25 18:15:30 --> Database Driver Class Initialized
INFO - 2016-10-25 18:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:15:30 --> Controller Class Initialized
INFO - 2016-10-25 18:15:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 18:15:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 18:15:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 18:15:30 --> Final output sent to browser
DEBUG - 2016-10-25 18:15:30 --> Total execution time: 0.0152
INFO - 2016-10-25 18:15:43 --> Config Class Initialized
INFO - 2016-10-25 18:15:43 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:15:43 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:15:43 --> Utf8 Class Initialized
INFO - 2016-10-25 18:15:43 --> URI Class Initialized
INFO - 2016-10-25 18:15:43 --> Router Class Initialized
INFO - 2016-10-25 18:15:43 --> Output Class Initialized
INFO - 2016-10-25 18:15:43 --> Security Class Initialized
DEBUG - 2016-10-25 18:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:15:43 --> Input Class Initialized
INFO - 2016-10-25 18:15:43 --> Language Class Initialized
INFO - 2016-10-25 18:15:43 --> Loader Class Initialized
INFO - 2016-10-25 18:15:43 --> Helper loaded: url_helper
INFO - 2016-10-25 18:15:43 --> Helper loaded: form_helper
INFO - 2016-10-25 18:15:43 --> Database Driver Class Initialized
INFO - 2016-10-25 18:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:15:43 --> Controller Class Initialized
DEBUG - 2016-10-25 18:15:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-25 18:15:43 --> Model Class Initialized
INFO - 2016-10-25 18:15:43 --> Final output sent to browser
DEBUG - 2016-10-25 18:15:43 --> Total execution time: 0.0210
INFO - 2016-10-25 18:15:43 --> Config Class Initialized
INFO - 2016-10-25 18:15:43 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:15:43 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:15:43 --> Utf8 Class Initialized
INFO - 2016-10-25 18:15:43 --> URI Class Initialized
DEBUG - 2016-10-25 18:15:43 --> No URI present. Default controller set.
INFO - 2016-10-25 18:15:43 --> Router Class Initialized
INFO - 2016-10-25 18:15:43 --> Output Class Initialized
INFO - 2016-10-25 18:15:43 --> Security Class Initialized
DEBUG - 2016-10-25 18:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:15:43 --> Input Class Initialized
INFO - 2016-10-25 18:15:43 --> Language Class Initialized
INFO - 2016-10-25 18:15:43 --> Loader Class Initialized
INFO - 2016-10-25 18:15:43 --> Helper loaded: url_helper
INFO - 2016-10-25 18:15:43 --> Helper loaded: form_helper
INFO - 2016-10-25 18:15:43 --> Database Driver Class Initialized
INFO - 2016-10-25 18:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:15:43 --> Controller Class Initialized
INFO - 2016-10-25 18:15:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 18:15:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-25 18:15:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-25 18:15:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 18:15:43 --> Final output sent to browser
DEBUG - 2016-10-25 18:15:43 --> Total execution time: 0.0152
INFO - 2016-10-25 18:18:57 --> Config Class Initialized
INFO - 2016-10-25 18:18:57 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:18:57 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:18:57 --> Utf8 Class Initialized
INFO - 2016-10-25 18:18:57 --> URI Class Initialized
DEBUG - 2016-10-25 18:18:57 --> No URI present. Default controller set.
INFO - 2016-10-25 18:18:57 --> Router Class Initialized
INFO - 2016-10-25 18:18:57 --> Output Class Initialized
INFO - 2016-10-25 18:18:57 --> Security Class Initialized
DEBUG - 2016-10-25 18:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:18:57 --> Input Class Initialized
INFO - 2016-10-25 18:18:57 --> Language Class Initialized
INFO - 2016-10-25 18:18:57 --> Loader Class Initialized
INFO - 2016-10-25 18:18:57 --> Helper loaded: url_helper
INFO - 2016-10-25 18:18:57 --> Helper loaded: form_helper
INFO - 2016-10-25 18:18:57 --> Database Driver Class Initialized
INFO - 2016-10-25 18:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:18:57 --> Controller Class Initialized
INFO - 2016-10-25 18:18:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 18:18:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-25 18:18:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-25 18:18:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 18:18:57 --> Final output sent to browser
DEBUG - 2016-10-25 18:18:57 --> Total execution time: 0.0177
INFO - 2016-10-25 18:42:02 --> Config Class Initialized
INFO - 2016-10-25 18:42:02 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:42:02 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:42:02 --> Utf8 Class Initialized
INFO - 2016-10-25 18:42:02 --> URI Class Initialized
INFO - 2016-10-25 18:42:02 --> Router Class Initialized
INFO - 2016-10-25 18:42:02 --> Output Class Initialized
INFO - 2016-10-25 18:42:02 --> Security Class Initialized
DEBUG - 2016-10-25 18:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:42:02 --> Input Class Initialized
INFO - 2016-10-25 18:42:02 --> Language Class Initialized
INFO - 2016-10-25 18:42:02 --> Loader Class Initialized
INFO - 2016-10-25 18:42:02 --> Helper loaded: url_helper
INFO - 2016-10-25 18:42:02 --> Helper loaded: form_helper
INFO - 2016-10-25 18:42:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:42:02 --> Controller Class Initialized
DEBUG - 2016-10-25 18:42:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-25 18:42:02 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-25 18:42:02 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-25 18:42:02 --> Config Class Initialized
INFO - 2016-10-25 18:42:02 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:42:02 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:42:02 --> Utf8 Class Initialized
INFO - 2016-10-25 18:42:02 --> URI Class Initialized
DEBUG - 2016-10-25 18:42:02 --> No URI present. Default controller set.
INFO - 2016-10-25 18:42:02 --> Router Class Initialized
INFO - 2016-10-25 18:42:02 --> Output Class Initialized
INFO - 2016-10-25 18:42:02 --> Security Class Initialized
DEBUG - 2016-10-25 18:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:42:02 --> Input Class Initialized
INFO - 2016-10-25 18:42:02 --> Language Class Initialized
INFO - 2016-10-25 18:42:02 --> Loader Class Initialized
INFO - 2016-10-25 18:42:02 --> Helper loaded: url_helper
INFO - 2016-10-25 18:42:02 --> Helper loaded: form_helper
INFO - 2016-10-25 18:42:02 --> Database Driver Class Initialized
INFO - 2016-10-25 18:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:42:02 --> Controller Class Initialized
INFO - 2016-10-25 18:42:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 18:42:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 18:42:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 18:42:02 --> Final output sent to browser
DEBUG - 2016-10-25 18:42:02 --> Total execution time: 0.0150
INFO - 2016-10-25 18:42:05 --> Config Class Initialized
INFO - 2016-10-25 18:42:05 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:42:05 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:42:05 --> Utf8 Class Initialized
INFO - 2016-10-25 18:42:05 --> URI Class Initialized
DEBUG - 2016-10-25 18:42:05 --> No URI present. Default controller set.
INFO - 2016-10-25 18:42:05 --> Router Class Initialized
INFO - 2016-10-25 18:42:05 --> Output Class Initialized
INFO - 2016-10-25 18:42:05 --> Security Class Initialized
DEBUG - 2016-10-25 18:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:42:05 --> Input Class Initialized
INFO - 2016-10-25 18:42:05 --> Language Class Initialized
INFO - 2016-10-25 18:42:05 --> Loader Class Initialized
INFO - 2016-10-25 18:42:05 --> Helper loaded: url_helper
INFO - 2016-10-25 18:42:05 --> Helper loaded: form_helper
INFO - 2016-10-25 18:42:06 --> Database Driver Class Initialized
INFO - 2016-10-25 18:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:42:06 --> Controller Class Initialized
INFO - 2016-10-25 18:42:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 18:42:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 18:42:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 18:42:06 --> Final output sent to browser
DEBUG - 2016-10-25 18:42:06 --> Total execution time: 0.0167
INFO - 2016-10-25 18:42:44 --> Config Class Initialized
INFO - 2016-10-25 18:42:44 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:42:44 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:42:44 --> Utf8 Class Initialized
INFO - 2016-10-25 18:42:44 --> URI Class Initialized
DEBUG - 2016-10-25 18:42:44 --> No URI present. Default controller set.
INFO - 2016-10-25 18:42:44 --> Router Class Initialized
INFO - 2016-10-25 18:42:44 --> Output Class Initialized
INFO - 2016-10-25 18:42:44 --> Security Class Initialized
DEBUG - 2016-10-25 18:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:42:44 --> Input Class Initialized
INFO - 2016-10-25 18:42:44 --> Language Class Initialized
INFO - 2016-10-25 18:42:44 --> Loader Class Initialized
INFO - 2016-10-25 18:42:44 --> Helper loaded: url_helper
INFO - 2016-10-25 18:42:44 --> Helper loaded: form_helper
INFO - 2016-10-25 18:42:44 --> Database Driver Class Initialized
INFO - 2016-10-25 18:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:42:44 --> Controller Class Initialized
INFO - 2016-10-25 18:42:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 18:42:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 18:42:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 18:42:44 --> Final output sent to browser
DEBUG - 2016-10-25 18:42:44 --> Total execution time: 0.0170
INFO - 2016-10-25 18:52:24 --> Config Class Initialized
INFO - 2016-10-25 18:52:24 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:52:24 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:52:24 --> Utf8 Class Initialized
INFO - 2016-10-25 18:52:24 --> URI Class Initialized
DEBUG - 2016-10-25 18:52:24 --> No URI present. Default controller set.
INFO - 2016-10-25 18:52:24 --> Router Class Initialized
INFO - 2016-10-25 18:52:24 --> Output Class Initialized
INFO - 2016-10-25 18:52:24 --> Security Class Initialized
DEBUG - 2016-10-25 18:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:52:24 --> Input Class Initialized
INFO - 2016-10-25 18:52:24 --> Language Class Initialized
INFO - 2016-10-25 18:52:24 --> Loader Class Initialized
INFO - 2016-10-25 18:52:24 --> Helper loaded: url_helper
INFO - 2016-10-25 18:52:24 --> Helper loaded: form_helper
INFO - 2016-10-25 18:52:24 --> Database Driver Class Initialized
INFO - 2016-10-25 18:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:52:24 --> Controller Class Initialized
INFO - 2016-10-25 18:52:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 18:52:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 18:52:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 18:52:24 --> Final output sent to browser
DEBUG - 2016-10-25 18:52:24 --> Total execution time: 0.0175
INFO - 2016-10-25 18:58:09 --> Config Class Initialized
INFO - 2016-10-25 18:58:09 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:58:09 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:58:09 --> Utf8 Class Initialized
INFO - 2016-10-25 18:58:09 --> URI Class Initialized
INFO - 2016-10-25 18:58:09 --> Router Class Initialized
INFO - 2016-10-25 18:58:09 --> Output Class Initialized
INFO - 2016-10-25 18:58:09 --> Security Class Initialized
DEBUG - 2016-10-25 18:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:58:09 --> Input Class Initialized
INFO - 2016-10-25 18:58:09 --> Language Class Initialized
INFO - 2016-10-25 18:58:09 --> Loader Class Initialized
INFO - 2016-10-25 18:58:09 --> Helper loaded: url_helper
INFO - 2016-10-25 18:58:09 --> Helper loaded: form_helper
INFO - 2016-10-25 18:58:09 --> Database Driver Class Initialized
INFO - 2016-10-25 18:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:58:09 --> Controller Class Initialized
DEBUG - 2016-10-25 18:58:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-25 18:58:09 --> Model Class Initialized
INFO - 2016-10-25 18:58:09 --> Final output sent to browser
DEBUG - 2016-10-25 18:58:09 --> Total execution time: 0.0179
INFO - 2016-10-25 18:58:34 --> Config Class Initialized
INFO - 2016-10-25 18:58:34 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:58:34 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:58:34 --> Utf8 Class Initialized
INFO - 2016-10-25 18:58:34 --> URI Class Initialized
INFO - 2016-10-25 18:58:34 --> Router Class Initialized
INFO - 2016-10-25 18:58:34 --> Output Class Initialized
INFO - 2016-10-25 18:58:34 --> Security Class Initialized
DEBUG - 2016-10-25 18:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:58:34 --> Input Class Initialized
INFO - 2016-10-25 18:58:34 --> Language Class Initialized
INFO - 2016-10-25 18:58:34 --> Loader Class Initialized
INFO - 2016-10-25 18:58:34 --> Helper loaded: url_helper
INFO - 2016-10-25 18:58:34 --> Helper loaded: form_helper
INFO - 2016-10-25 18:58:34 --> Database Driver Class Initialized
INFO - 2016-10-25 18:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:58:34 --> Controller Class Initialized
DEBUG - 2016-10-25 18:58:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-25 18:58:34 --> Model Class Initialized
INFO - 2016-10-25 18:58:34 --> Final output sent to browser
DEBUG - 2016-10-25 18:58:34 --> Total execution time: 0.0201
INFO - 2016-10-25 18:58:35 --> Config Class Initialized
INFO - 2016-10-25 18:58:35 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:58:35 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:58:35 --> Utf8 Class Initialized
INFO - 2016-10-25 18:58:35 --> URI Class Initialized
DEBUG - 2016-10-25 18:58:35 --> No URI present. Default controller set.
INFO - 2016-10-25 18:58:35 --> Router Class Initialized
INFO - 2016-10-25 18:58:35 --> Output Class Initialized
INFO - 2016-10-25 18:58:35 --> Security Class Initialized
DEBUG - 2016-10-25 18:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:58:35 --> Input Class Initialized
INFO - 2016-10-25 18:58:35 --> Language Class Initialized
INFO - 2016-10-25 18:58:35 --> Loader Class Initialized
INFO - 2016-10-25 18:58:35 --> Helper loaded: url_helper
INFO - 2016-10-25 18:58:35 --> Helper loaded: form_helper
INFO - 2016-10-25 18:58:35 --> Database Driver Class Initialized
INFO - 2016-10-25 18:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:58:35 --> Controller Class Initialized
INFO - 2016-10-25 18:58:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 18:58:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 18:58:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 18:58:35 --> Final output sent to browser
DEBUG - 2016-10-25 18:58:35 --> Total execution time: 0.0279
INFO - 2016-10-25 18:58:37 --> Config Class Initialized
INFO - 2016-10-25 18:58:37 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:58:37 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:58:37 --> Utf8 Class Initialized
INFO - 2016-10-25 18:58:37 --> URI Class Initialized
DEBUG - 2016-10-25 18:58:37 --> No URI present. Default controller set.
INFO - 2016-10-25 18:58:37 --> Router Class Initialized
INFO - 2016-10-25 18:58:37 --> Output Class Initialized
INFO - 2016-10-25 18:58:37 --> Security Class Initialized
DEBUG - 2016-10-25 18:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:58:37 --> Input Class Initialized
INFO - 2016-10-25 18:58:37 --> Language Class Initialized
INFO - 2016-10-25 18:58:37 --> Loader Class Initialized
INFO - 2016-10-25 18:58:37 --> Helper loaded: url_helper
INFO - 2016-10-25 18:58:37 --> Helper loaded: form_helper
INFO - 2016-10-25 18:58:37 --> Database Driver Class Initialized
INFO - 2016-10-25 18:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:58:37 --> Controller Class Initialized
INFO - 2016-10-25 18:58:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 18:58:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 18:58:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 18:58:37 --> Final output sent to browser
DEBUG - 2016-10-25 18:58:37 --> Total execution time: 0.0170
INFO - 2016-10-25 18:58:46 --> Config Class Initialized
INFO - 2016-10-25 18:58:46 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:58:46 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:58:46 --> Utf8 Class Initialized
INFO - 2016-10-25 18:58:46 --> URI Class Initialized
INFO - 2016-10-25 18:58:46 --> Router Class Initialized
INFO - 2016-10-25 18:58:46 --> Output Class Initialized
INFO - 2016-10-25 18:58:46 --> Security Class Initialized
DEBUG - 2016-10-25 18:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:58:46 --> Input Class Initialized
INFO - 2016-10-25 18:58:46 --> Language Class Initialized
INFO - 2016-10-25 18:58:46 --> Loader Class Initialized
INFO - 2016-10-25 18:58:46 --> Helper loaded: url_helper
INFO - 2016-10-25 18:58:46 --> Helper loaded: form_helper
INFO - 2016-10-25 18:58:46 --> Database Driver Class Initialized
INFO - 2016-10-25 18:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:58:46 --> Controller Class Initialized
DEBUG - 2016-10-25 18:58:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-25 18:58:46 --> Model Class Initialized
INFO - 2016-10-25 18:58:46 --> Final output sent to browser
DEBUG - 2016-10-25 18:58:46 --> Total execution time: 0.0173
INFO - 2016-10-25 18:58:47 --> Config Class Initialized
INFO - 2016-10-25 18:58:47 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:58:47 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:58:47 --> Utf8 Class Initialized
INFO - 2016-10-25 18:58:47 --> URI Class Initialized
INFO - 2016-10-25 18:58:47 --> Router Class Initialized
INFO - 2016-10-25 18:58:47 --> Output Class Initialized
INFO - 2016-10-25 18:58:47 --> Security Class Initialized
DEBUG - 2016-10-25 18:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:58:47 --> Input Class Initialized
INFO - 2016-10-25 18:58:47 --> Language Class Initialized
INFO - 2016-10-25 18:58:47 --> Loader Class Initialized
INFO - 2016-10-25 18:58:47 --> Helper loaded: url_helper
INFO - 2016-10-25 18:58:47 --> Helper loaded: form_helper
INFO - 2016-10-25 18:58:47 --> Database Driver Class Initialized
INFO - 2016-10-25 18:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:58:47 --> Controller Class Initialized
DEBUG - 2016-10-25 18:58:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-25 18:58:47 --> Model Class Initialized
INFO - 2016-10-25 18:58:47 --> Final output sent to browser
DEBUG - 2016-10-25 18:58:47 --> Total execution time: 0.0168
INFO - 2016-10-25 18:59:19 --> Config Class Initialized
INFO - 2016-10-25 18:59:19 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:59:19 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:59:19 --> Utf8 Class Initialized
INFO - 2016-10-25 18:59:19 --> URI Class Initialized
INFO - 2016-10-25 18:59:19 --> Router Class Initialized
INFO - 2016-10-25 18:59:19 --> Output Class Initialized
INFO - 2016-10-25 18:59:19 --> Security Class Initialized
DEBUG - 2016-10-25 18:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:59:19 --> Input Class Initialized
INFO - 2016-10-25 18:59:19 --> Language Class Initialized
INFO - 2016-10-25 18:59:19 --> Loader Class Initialized
INFO - 2016-10-25 18:59:19 --> Helper loaded: url_helper
INFO - 2016-10-25 18:59:19 --> Helper loaded: form_helper
INFO - 2016-10-25 18:59:19 --> Database Driver Class Initialized
INFO - 2016-10-25 18:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:59:19 --> Controller Class Initialized
DEBUG - 2016-10-25 18:59:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-25 18:59:19 --> Model Class Initialized
INFO - 2016-10-25 18:59:19 --> Final output sent to browser
DEBUG - 2016-10-25 18:59:19 --> Total execution time: 0.0181
INFO - 2016-10-25 18:59:22 --> Config Class Initialized
INFO - 2016-10-25 18:59:22 --> Hooks Class Initialized
DEBUG - 2016-10-25 18:59:22 --> UTF-8 Support Enabled
INFO - 2016-10-25 18:59:22 --> Utf8 Class Initialized
INFO - 2016-10-25 18:59:22 --> URI Class Initialized
DEBUG - 2016-10-25 18:59:22 --> No URI present. Default controller set.
INFO - 2016-10-25 18:59:22 --> Router Class Initialized
INFO - 2016-10-25 18:59:22 --> Output Class Initialized
INFO - 2016-10-25 18:59:22 --> Security Class Initialized
DEBUG - 2016-10-25 18:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-25 18:59:22 --> Input Class Initialized
INFO - 2016-10-25 18:59:22 --> Language Class Initialized
INFO - 2016-10-25 18:59:22 --> Loader Class Initialized
INFO - 2016-10-25 18:59:22 --> Helper loaded: url_helper
INFO - 2016-10-25 18:59:22 --> Helper loaded: form_helper
INFO - 2016-10-25 18:59:22 --> Database Driver Class Initialized
INFO - 2016-10-25 18:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-25 18:59:22 --> Controller Class Initialized
INFO - 2016-10-25 18:59:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-25 18:59:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-25 18:59:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-25 18:59:22 --> Final output sent to browser
DEBUG - 2016-10-25 18:59:22 --> Total execution time: 0.0164
