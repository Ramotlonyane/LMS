<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-07 11:51:18 --> Config Class Initialized
INFO - 2016-11-07 11:51:18 --> Hooks Class Initialized
DEBUG - 2016-11-07 11:51:18 --> UTF-8 Support Enabled
INFO - 2016-11-07 11:51:18 --> Utf8 Class Initialized
INFO - 2016-11-07 11:51:18 --> URI Class Initialized
DEBUG - 2016-11-07 11:51:18 --> No URI present. Default controller set.
INFO - 2016-11-07 11:51:18 --> Router Class Initialized
INFO - 2016-11-07 11:51:18 --> Output Class Initialized
INFO - 2016-11-07 11:51:18 --> Security Class Initialized
DEBUG - 2016-11-07 11:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 11:51:18 --> Input Class Initialized
INFO - 2016-11-07 11:51:18 --> Language Class Initialized
INFO - 2016-11-07 11:51:18 --> Loader Class Initialized
INFO - 2016-11-07 11:51:18 --> Helper loaded: url_helper
INFO - 2016-11-07 11:51:19 --> Helper loaded: form_helper
INFO - 2016-11-07 11:51:19 --> Database Driver Class Initialized
INFO - 2016-11-07 11:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 11:51:19 --> Controller Class Initialized
INFO - 2016-11-07 11:51:19 --> Model Class Initialized
INFO - 2016-11-07 11:51:19 --> Model Class Initialized
INFO - 2016-11-07 11:51:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 11:51:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 11:51:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 11:51:19 --> Final output sent to browser
DEBUG - 2016-11-07 11:51:19 --> Total execution time: 1.3351
INFO - 2016-11-07 11:51:39 --> Config Class Initialized
INFO - 2016-11-07 11:51:40 --> Hooks Class Initialized
DEBUG - 2016-11-07 11:51:40 --> UTF-8 Support Enabled
INFO - 2016-11-07 11:51:40 --> Utf8 Class Initialized
INFO - 2016-11-07 11:51:40 --> URI Class Initialized
INFO - 2016-11-07 11:51:40 --> Router Class Initialized
INFO - 2016-11-07 11:51:40 --> Output Class Initialized
INFO - 2016-11-07 11:51:40 --> Security Class Initialized
DEBUG - 2016-11-07 11:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 11:51:40 --> Input Class Initialized
INFO - 2016-11-07 11:51:40 --> Language Class Initialized
INFO - 2016-11-07 11:51:40 --> Loader Class Initialized
INFO - 2016-11-07 11:51:40 --> Helper loaded: url_helper
INFO - 2016-11-07 11:51:40 --> Helper loaded: form_helper
INFO - 2016-11-07 11:51:40 --> Database Driver Class Initialized
INFO - 2016-11-07 11:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 11:51:40 --> Controller Class Initialized
INFO - 2016-11-07 11:51:40 --> Model Class Initialized
INFO - 2016-11-07 11:51:40 --> Model Class Initialized
DEBUG - 2016-11-07 11:51:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-07 11:51:40 --> Model Class Initialized
INFO - 2016-11-07 11:51:40 --> Final output sent to browser
DEBUG - 2016-11-07 11:51:40 --> Total execution time: 0.3827
INFO - 2016-11-07 11:51:40 --> Config Class Initialized
INFO - 2016-11-07 11:51:40 --> Hooks Class Initialized
DEBUG - 2016-11-07 11:51:40 --> UTF-8 Support Enabled
INFO - 2016-11-07 11:51:40 --> Utf8 Class Initialized
INFO - 2016-11-07 11:51:40 --> URI Class Initialized
DEBUG - 2016-11-07 11:51:40 --> No URI present. Default controller set.
INFO - 2016-11-07 11:51:40 --> Router Class Initialized
INFO - 2016-11-07 11:51:40 --> Output Class Initialized
INFO - 2016-11-07 11:51:40 --> Security Class Initialized
DEBUG - 2016-11-07 11:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 11:51:40 --> Input Class Initialized
INFO - 2016-11-07 11:51:40 --> Language Class Initialized
INFO - 2016-11-07 11:51:40 --> Loader Class Initialized
INFO - 2016-11-07 11:51:40 --> Helper loaded: url_helper
INFO - 2016-11-07 11:51:40 --> Helper loaded: form_helper
INFO - 2016-11-07 11:51:40 --> Database Driver Class Initialized
INFO - 2016-11-07 11:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 11:51:40 --> Controller Class Initialized
INFO - 2016-11-07 11:51:40 --> Model Class Initialized
INFO - 2016-11-07 11:51:40 --> Model Class Initialized
INFO - 2016-11-07 11:51:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 11:51:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-07 11:51:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-07 11:51:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-07 11:51:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-07 11:51:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-07 11:51:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-07 11:51:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-07 11:51:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-07 11:51:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-07 11:51:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 11:51:41 --> Final output sent to browser
DEBUG - 2016-11-07 11:51:41 --> Total execution time: 0.6176
INFO - 2016-11-07 11:51:45 --> Config Class Initialized
INFO - 2016-11-07 11:51:45 --> Hooks Class Initialized
DEBUG - 2016-11-07 11:51:45 --> UTF-8 Support Enabled
INFO - 2016-11-07 11:51:45 --> Utf8 Class Initialized
INFO - 2016-11-07 11:51:45 --> URI Class Initialized
DEBUG - 2016-11-07 11:51:45 --> No URI present. Default controller set.
INFO - 2016-11-07 11:51:45 --> Router Class Initialized
INFO - 2016-11-07 11:51:45 --> Output Class Initialized
INFO - 2016-11-07 11:51:45 --> Security Class Initialized
DEBUG - 2016-11-07 11:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 11:51:45 --> Input Class Initialized
INFO - 2016-11-07 11:51:45 --> Language Class Initialized
INFO - 2016-11-07 11:51:45 --> Loader Class Initialized
INFO - 2016-11-07 11:51:45 --> Helper loaded: url_helper
INFO - 2016-11-07 11:51:45 --> Helper loaded: form_helper
INFO - 2016-11-07 11:51:45 --> Database Driver Class Initialized
INFO - 2016-11-07 11:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 11:51:45 --> Controller Class Initialized
INFO - 2016-11-07 11:51:45 --> Model Class Initialized
INFO - 2016-11-07 11:51:45 --> Model Class Initialized
INFO - 2016-11-07 11:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 11:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-07 11:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-07 11:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-07 11:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-07 11:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-07 11:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-07 11:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-07 11:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-07 11:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-07 11:51:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 11:51:45 --> Final output sent to browser
DEBUG - 2016-11-07 11:51:45 --> Total execution time: 0.3075
INFO - 2016-11-07 11:51:58 --> Config Class Initialized
INFO - 2016-11-07 11:51:58 --> Hooks Class Initialized
DEBUG - 2016-11-07 11:51:58 --> UTF-8 Support Enabled
INFO - 2016-11-07 11:51:58 --> Utf8 Class Initialized
INFO - 2016-11-07 11:51:58 --> URI Class Initialized
INFO - 2016-11-07 11:51:58 --> Router Class Initialized
INFO - 2016-11-07 11:51:58 --> Output Class Initialized
INFO - 2016-11-07 11:51:58 --> Security Class Initialized
DEBUG - 2016-11-07 11:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 11:51:58 --> Input Class Initialized
INFO - 2016-11-07 11:51:58 --> Language Class Initialized
INFO - 2016-11-07 11:51:58 --> Loader Class Initialized
INFO - 2016-11-07 11:51:58 --> Helper loaded: url_helper
INFO - 2016-11-07 11:51:58 --> Helper loaded: form_helper
INFO - 2016-11-07 11:51:58 --> Database Driver Class Initialized
INFO - 2016-11-07 11:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 11:51:58 --> Controller Class Initialized
INFO - 2016-11-07 11:51:58 --> Model Class Initialized
INFO - 2016-11-07 11:51:58 --> Form Validation Class Initialized
INFO - 2016-11-07 11:51:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-07 11:51:58 --> Final output sent to browser
DEBUG - 2016-11-07 11:51:58 --> Total execution time: 0.2847
INFO - 2016-11-07 11:52:00 --> Config Class Initialized
INFO - 2016-11-07 11:52:00 --> Hooks Class Initialized
DEBUG - 2016-11-07 11:52:00 --> UTF-8 Support Enabled
INFO - 2016-11-07 11:52:00 --> Utf8 Class Initialized
INFO - 2016-11-07 11:52:00 --> URI Class Initialized
DEBUG - 2016-11-07 11:52:00 --> No URI present. Default controller set.
INFO - 2016-11-07 11:52:00 --> Router Class Initialized
INFO - 2016-11-07 11:52:00 --> Output Class Initialized
INFO - 2016-11-07 11:52:00 --> Security Class Initialized
DEBUG - 2016-11-07 11:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 11:52:00 --> Input Class Initialized
INFO - 2016-11-07 11:52:00 --> Language Class Initialized
INFO - 2016-11-07 11:52:00 --> Loader Class Initialized
INFO - 2016-11-07 11:52:00 --> Helper loaded: url_helper
INFO - 2016-11-07 11:52:01 --> Helper loaded: form_helper
INFO - 2016-11-07 11:52:01 --> Database Driver Class Initialized
INFO - 2016-11-07 11:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 11:52:01 --> Controller Class Initialized
INFO - 2016-11-07 11:52:01 --> Model Class Initialized
INFO - 2016-11-07 11:52:01 --> Model Class Initialized
INFO - 2016-11-07 11:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 11:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-07 11:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-07 11:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-07 11:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-07 11:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-07 11:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-07 11:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-07 11:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-07 11:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-07 11:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 11:52:01 --> Final output sent to browser
DEBUG - 2016-11-07 11:52:01 --> Total execution time: 0.2706
INFO - 2016-11-07 11:52:23 --> Config Class Initialized
INFO - 2016-11-07 11:52:23 --> Hooks Class Initialized
DEBUG - 2016-11-07 11:52:23 --> UTF-8 Support Enabled
INFO - 2016-11-07 11:52:23 --> Utf8 Class Initialized
INFO - 2016-11-07 11:52:23 --> URI Class Initialized
DEBUG - 2016-11-07 11:52:23 --> No URI present. Default controller set.
INFO - 2016-11-07 11:52:23 --> Router Class Initialized
INFO - 2016-11-07 11:52:23 --> Output Class Initialized
INFO - 2016-11-07 11:52:23 --> Security Class Initialized
DEBUG - 2016-11-07 11:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 11:52:23 --> Input Class Initialized
INFO - 2016-11-07 11:52:23 --> Language Class Initialized
INFO - 2016-11-07 11:52:23 --> Loader Class Initialized
INFO - 2016-11-07 11:52:23 --> Helper loaded: url_helper
INFO - 2016-11-07 11:52:23 --> Helper loaded: form_helper
INFO - 2016-11-07 11:52:23 --> Database Driver Class Initialized
INFO - 2016-11-07 11:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 11:52:23 --> Controller Class Initialized
INFO - 2016-11-07 11:52:23 --> Model Class Initialized
INFO - 2016-11-07 11:52:23 --> Model Class Initialized
INFO - 2016-11-07 11:52:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 11:52:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-07 11:52:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-07 11:52:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-07 11:52:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-07 11:52:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-07 11:52:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-07 11:52:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-07 11:52:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-07 11:52:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-07 11:52:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 11:52:23 --> Final output sent to browser
DEBUG - 2016-11-07 11:52:23 --> Total execution time: 0.2859
INFO - 2016-11-07 11:52:45 --> Config Class Initialized
INFO - 2016-11-07 11:52:45 --> Hooks Class Initialized
DEBUG - 2016-11-07 11:52:45 --> UTF-8 Support Enabled
INFO - 2016-11-07 11:52:45 --> Utf8 Class Initialized
INFO - 2016-11-07 11:52:45 --> URI Class Initialized
INFO - 2016-11-07 11:52:45 --> Router Class Initialized
INFO - 2016-11-07 11:52:45 --> Output Class Initialized
INFO - 2016-11-07 11:52:45 --> Security Class Initialized
DEBUG - 2016-11-07 11:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 11:52:45 --> Input Class Initialized
INFO - 2016-11-07 11:52:45 --> Language Class Initialized
INFO - 2016-11-07 11:52:45 --> Loader Class Initialized
INFO - 2016-11-07 11:52:45 --> Helper loaded: url_helper
INFO - 2016-11-07 11:52:45 --> Helper loaded: form_helper
INFO - 2016-11-07 11:52:45 --> Database Driver Class Initialized
INFO - 2016-11-07 11:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 11:52:45 --> Controller Class Initialized
INFO - 2016-11-07 11:52:45 --> Model Class Initialized
INFO - 2016-11-07 11:52:45 --> Form Validation Class Initialized
INFO - 2016-11-07 11:52:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-07 11:52:45 --> Final output sent to browser
DEBUG - 2016-11-07 11:52:45 --> Total execution time: 0.2061
INFO - 2016-11-07 11:52:47 --> Config Class Initialized
INFO - 2016-11-07 11:52:47 --> Hooks Class Initialized
DEBUG - 2016-11-07 11:52:47 --> UTF-8 Support Enabled
INFO - 2016-11-07 11:52:47 --> Utf8 Class Initialized
INFO - 2016-11-07 11:52:47 --> URI Class Initialized
DEBUG - 2016-11-07 11:52:47 --> No URI present. Default controller set.
INFO - 2016-11-07 11:52:47 --> Router Class Initialized
INFO - 2016-11-07 11:52:47 --> Output Class Initialized
INFO - 2016-11-07 11:52:47 --> Security Class Initialized
DEBUG - 2016-11-07 11:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 11:52:47 --> Input Class Initialized
INFO - 2016-11-07 11:52:47 --> Language Class Initialized
INFO - 2016-11-07 11:52:47 --> Loader Class Initialized
INFO - 2016-11-07 11:52:47 --> Helper loaded: url_helper
INFO - 2016-11-07 11:52:47 --> Helper loaded: form_helper
INFO - 2016-11-07 11:52:47 --> Database Driver Class Initialized
INFO - 2016-11-07 11:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 11:52:47 --> Controller Class Initialized
INFO - 2016-11-07 11:52:47 --> Model Class Initialized
INFO - 2016-11-07 11:52:47 --> Model Class Initialized
INFO - 2016-11-07 11:52:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 11:52:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-07 11:52:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-07 11:52:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-07 11:52:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-07 11:52:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-07 11:52:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-07 11:52:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-07 11:52:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-07 11:52:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-07 11:52:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 11:52:48 --> Final output sent to browser
DEBUG - 2016-11-07 11:52:48 --> Total execution time: 0.2856
INFO - 2016-11-07 12:10:05 --> Config Class Initialized
INFO - 2016-11-07 12:10:05 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:10:05 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:10:05 --> Utf8 Class Initialized
INFO - 2016-11-07 12:10:05 --> URI Class Initialized
INFO - 2016-11-07 12:10:05 --> Router Class Initialized
INFO - 2016-11-07 12:10:05 --> Output Class Initialized
INFO - 2016-11-07 12:10:05 --> Security Class Initialized
DEBUG - 2016-11-07 12:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:10:05 --> Input Class Initialized
INFO - 2016-11-07 12:10:05 --> Language Class Initialized
INFO - 2016-11-07 12:10:05 --> Loader Class Initialized
INFO - 2016-11-07 12:10:05 --> Helper loaded: url_helper
INFO - 2016-11-07 12:10:05 --> Helper loaded: form_helper
INFO - 2016-11-07 12:10:05 --> Database Driver Class Initialized
INFO - 2016-11-07 12:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:10:05 --> Controller Class Initialized
INFO - 2016-11-07 12:10:05 --> Model Class Initialized
INFO - 2016-11-07 12:10:05 --> Model Class Initialized
DEBUG - 2016-11-07 12:10:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-07 12:10:05 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-07 12:10:05 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-07 12:10:05 --> Config Class Initialized
INFO - 2016-11-07 12:10:05 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:10:05 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:10:05 --> Utf8 Class Initialized
INFO - 2016-11-07 12:10:05 --> URI Class Initialized
DEBUG - 2016-11-07 12:10:05 --> No URI present. Default controller set.
INFO - 2016-11-07 12:10:05 --> Router Class Initialized
INFO - 2016-11-07 12:10:05 --> Output Class Initialized
INFO - 2016-11-07 12:10:05 --> Security Class Initialized
DEBUG - 2016-11-07 12:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:10:05 --> Input Class Initialized
INFO - 2016-11-07 12:10:05 --> Language Class Initialized
INFO - 2016-11-07 12:10:06 --> Loader Class Initialized
INFO - 2016-11-07 12:10:06 --> Helper loaded: url_helper
INFO - 2016-11-07 12:10:06 --> Helper loaded: form_helper
INFO - 2016-11-07 12:10:06 --> Database Driver Class Initialized
INFO - 2016-11-07 12:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:10:06 --> Controller Class Initialized
INFO - 2016-11-07 12:10:06 --> Model Class Initialized
INFO - 2016-11-07 12:10:06 --> Model Class Initialized
INFO - 2016-11-07 12:10:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 12:10:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 12:10:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 12:10:06 --> Final output sent to browser
DEBUG - 2016-11-07 12:10:06 --> Total execution time: 0.2309
INFO - 2016-11-07 12:10:09 --> Config Class Initialized
INFO - 2016-11-07 12:10:09 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:10:09 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:10:09 --> Utf8 Class Initialized
INFO - 2016-11-07 12:10:09 --> URI Class Initialized
DEBUG - 2016-11-07 12:10:09 --> No URI present. Default controller set.
INFO - 2016-11-07 12:10:09 --> Router Class Initialized
INFO - 2016-11-07 12:10:09 --> Output Class Initialized
INFO - 2016-11-07 12:10:09 --> Security Class Initialized
DEBUG - 2016-11-07 12:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:10:09 --> Input Class Initialized
INFO - 2016-11-07 12:10:09 --> Language Class Initialized
INFO - 2016-11-07 12:10:09 --> Loader Class Initialized
INFO - 2016-11-07 12:10:09 --> Helper loaded: url_helper
INFO - 2016-11-07 12:10:09 --> Helper loaded: form_helper
INFO - 2016-11-07 12:10:09 --> Database Driver Class Initialized
INFO - 2016-11-07 12:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:10:09 --> Controller Class Initialized
INFO - 2016-11-07 12:10:09 --> Model Class Initialized
INFO - 2016-11-07 12:10:09 --> Model Class Initialized
INFO - 2016-11-07 12:10:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 12:10:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 12:10:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 12:10:09 --> Final output sent to browser
DEBUG - 2016-11-07 12:10:09 --> Total execution time: 0.2294
INFO - 2016-11-07 12:10:14 --> Config Class Initialized
INFO - 2016-11-07 12:10:14 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:10:14 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:10:14 --> Utf8 Class Initialized
INFO - 2016-11-07 12:10:14 --> URI Class Initialized
DEBUG - 2016-11-07 12:10:14 --> No URI present. Default controller set.
INFO - 2016-11-07 12:10:14 --> Router Class Initialized
INFO - 2016-11-07 12:10:14 --> Output Class Initialized
INFO - 2016-11-07 12:10:14 --> Security Class Initialized
DEBUG - 2016-11-07 12:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:10:14 --> Input Class Initialized
INFO - 2016-11-07 12:10:14 --> Language Class Initialized
INFO - 2016-11-07 12:10:14 --> Loader Class Initialized
INFO - 2016-11-07 12:10:14 --> Helper loaded: url_helper
INFO - 2016-11-07 12:10:14 --> Helper loaded: form_helper
INFO - 2016-11-07 12:10:14 --> Database Driver Class Initialized
INFO - 2016-11-07 12:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:10:14 --> Controller Class Initialized
INFO - 2016-11-07 12:10:14 --> Model Class Initialized
INFO - 2016-11-07 12:10:14 --> Model Class Initialized
INFO - 2016-11-07 12:10:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 12:10:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 12:10:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 12:10:14 --> Final output sent to browser
DEBUG - 2016-11-07 12:10:14 --> Total execution time: 0.2179
INFO - 2016-11-07 12:10:22 --> Config Class Initialized
INFO - 2016-11-07 12:10:22 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:10:22 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:10:22 --> Utf8 Class Initialized
INFO - 2016-11-07 12:10:22 --> URI Class Initialized
DEBUG - 2016-11-07 12:10:22 --> No URI present. Default controller set.
INFO - 2016-11-07 12:10:22 --> Router Class Initialized
INFO - 2016-11-07 12:10:22 --> Output Class Initialized
INFO - 2016-11-07 12:10:22 --> Security Class Initialized
DEBUG - 2016-11-07 12:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:10:22 --> Input Class Initialized
INFO - 2016-11-07 12:10:22 --> Language Class Initialized
INFO - 2016-11-07 12:10:22 --> Loader Class Initialized
INFO - 2016-11-07 12:10:22 --> Helper loaded: url_helper
INFO - 2016-11-07 12:10:22 --> Helper loaded: form_helper
INFO - 2016-11-07 12:10:22 --> Database Driver Class Initialized
INFO - 2016-11-07 12:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:10:22 --> Controller Class Initialized
INFO - 2016-11-07 12:10:22 --> Model Class Initialized
INFO - 2016-11-07 12:10:22 --> Model Class Initialized
INFO - 2016-11-07 12:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 12:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 12:10:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 12:10:22 --> Final output sent to browser
DEBUG - 2016-11-07 12:10:22 --> Total execution time: 0.1855
INFO - 2016-11-07 12:10:39 --> Config Class Initialized
INFO - 2016-11-07 12:10:39 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:10:39 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:10:39 --> Utf8 Class Initialized
INFO - 2016-11-07 12:10:39 --> URI Class Initialized
INFO - 2016-11-07 12:10:39 --> Router Class Initialized
INFO - 2016-11-07 12:10:39 --> Output Class Initialized
INFO - 2016-11-07 12:10:39 --> Security Class Initialized
DEBUG - 2016-11-07 12:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:10:39 --> Input Class Initialized
INFO - 2016-11-07 12:10:39 --> Language Class Initialized
INFO - 2016-11-07 12:10:39 --> Loader Class Initialized
INFO - 2016-11-07 12:10:39 --> Helper loaded: url_helper
INFO - 2016-11-07 12:10:39 --> Helper loaded: form_helper
INFO - 2016-11-07 12:10:39 --> Database Driver Class Initialized
INFO - 2016-11-07 12:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:10:39 --> Controller Class Initialized
INFO - 2016-11-07 12:10:39 --> Model Class Initialized
INFO - 2016-11-07 12:10:39 --> Model Class Initialized
DEBUG - 2016-11-07 12:10:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-07 12:10:39 --> Model Class Initialized
INFO - 2016-11-07 12:10:39 --> Final output sent to browser
DEBUG - 2016-11-07 12:10:39 --> Total execution time: 0.1616
INFO - 2016-11-07 12:10:39 --> Config Class Initialized
INFO - 2016-11-07 12:10:39 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:10:39 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:10:39 --> Utf8 Class Initialized
INFO - 2016-11-07 12:10:39 --> URI Class Initialized
DEBUG - 2016-11-07 12:10:39 --> No URI present. Default controller set.
INFO - 2016-11-07 12:10:39 --> Router Class Initialized
INFO - 2016-11-07 12:10:39 --> Output Class Initialized
INFO - 2016-11-07 12:10:39 --> Security Class Initialized
DEBUG - 2016-11-07 12:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:10:39 --> Input Class Initialized
INFO - 2016-11-07 12:10:39 --> Language Class Initialized
INFO - 2016-11-07 12:10:39 --> Loader Class Initialized
INFO - 2016-11-07 12:10:39 --> Helper loaded: url_helper
INFO - 2016-11-07 12:10:39 --> Helper loaded: form_helper
INFO - 2016-11-07 12:10:39 --> Database Driver Class Initialized
INFO - 2016-11-07 12:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:10:39 --> Controller Class Initialized
INFO - 2016-11-07 12:10:39 --> Model Class Initialized
INFO - 2016-11-07 12:10:39 --> Model Class Initialized
INFO - 2016-11-07 12:10:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 12:10:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-07 12:10:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-07 12:10:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-07 12:10:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-07 12:10:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-07 12:10:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-07 12:10:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-07 12:10:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-07 12:10:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-07 12:10:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 12:10:39 --> Final output sent to browser
DEBUG - 2016-11-07 12:10:39 --> Total execution time: 0.2451
INFO - 2016-11-07 12:12:18 --> Config Class Initialized
INFO - 2016-11-07 12:12:18 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:12:18 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:12:18 --> Utf8 Class Initialized
INFO - 2016-11-07 12:12:18 --> URI Class Initialized
INFO - 2016-11-07 12:12:18 --> Router Class Initialized
INFO - 2016-11-07 12:12:18 --> Output Class Initialized
INFO - 2016-11-07 12:12:18 --> Security Class Initialized
DEBUG - 2016-11-07 12:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:12:18 --> Input Class Initialized
INFO - 2016-11-07 12:12:18 --> Language Class Initialized
INFO - 2016-11-07 12:12:18 --> Loader Class Initialized
INFO - 2016-11-07 12:12:18 --> Helper loaded: url_helper
INFO - 2016-11-07 12:12:18 --> Helper loaded: form_helper
INFO - 2016-11-07 12:12:18 --> Database Driver Class Initialized
INFO - 2016-11-07 12:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:12:18 --> Controller Class Initialized
INFO - 2016-11-07 12:12:18 --> Model Class Initialized
INFO - 2016-11-07 12:12:18 --> Model Class Initialized
DEBUG - 2016-11-07 12:12:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-07 12:12:18 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-07 12:12:18 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-07 12:12:18 --> Config Class Initialized
INFO - 2016-11-07 12:12:18 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:12:18 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:12:18 --> Utf8 Class Initialized
INFO - 2016-11-07 12:12:18 --> URI Class Initialized
DEBUG - 2016-11-07 12:12:18 --> No URI present. Default controller set.
INFO - 2016-11-07 12:12:18 --> Router Class Initialized
INFO - 2016-11-07 12:12:18 --> Output Class Initialized
INFO - 2016-11-07 12:12:18 --> Security Class Initialized
DEBUG - 2016-11-07 12:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:12:18 --> Input Class Initialized
INFO - 2016-11-07 12:12:18 --> Language Class Initialized
INFO - 2016-11-07 12:12:18 --> Loader Class Initialized
INFO - 2016-11-07 12:12:18 --> Helper loaded: url_helper
INFO - 2016-11-07 12:12:18 --> Helper loaded: form_helper
INFO - 2016-11-07 12:12:18 --> Database Driver Class Initialized
INFO - 2016-11-07 12:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:12:18 --> Controller Class Initialized
INFO - 2016-11-07 12:12:18 --> Model Class Initialized
INFO - 2016-11-07 12:12:18 --> Model Class Initialized
INFO - 2016-11-07 12:12:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 12:12:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 12:12:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 12:12:18 --> Final output sent to browser
DEBUG - 2016-11-07 12:12:18 --> Total execution time: 0.2124
INFO - 2016-11-07 12:12:28 --> Config Class Initialized
INFO - 2016-11-07 12:12:28 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:12:28 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:12:28 --> Utf8 Class Initialized
INFO - 2016-11-07 12:12:28 --> URI Class Initialized
INFO - 2016-11-07 12:12:28 --> Router Class Initialized
INFO - 2016-11-07 12:12:28 --> Output Class Initialized
INFO - 2016-11-07 12:12:28 --> Security Class Initialized
DEBUG - 2016-11-07 12:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:12:28 --> Input Class Initialized
INFO - 2016-11-07 12:12:28 --> Language Class Initialized
INFO - 2016-11-07 12:12:28 --> Loader Class Initialized
INFO - 2016-11-07 12:12:28 --> Helper loaded: url_helper
INFO - 2016-11-07 12:12:28 --> Helper loaded: form_helper
INFO - 2016-11-07 12:12:28 --> Database Driver Class Initialized
INFO - 2016-11-07 12:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:12:28 --> Controller Class Initialized
INFO - 2016-11-07 12:12:28 --> Model Class Initialized
INFO - 2016-11-07 12:12:28 --> Model Class Initialized
DEBUG - 2016-11-07 12:12:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-07 12:12:28 --> Model Class Initialized
INFO - 2016-11-07 12:12:28 --> Final output sent to browser
DEBUG - 2016-11-07 12:12:28 --> Total execution time: 0.1991
INFO - 2016-11-07 12:12:28 --> Config Class Initialized
INFO - 2016-11-07 12:12:28 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:12:28 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:12:28 --> Utf8 Class Initialized
INFO - 2016-11-07 12:12:28 --> URI Class Initialized
DEBUG - 2016-11-07 12:12:28 --> No URI present. Default controller set.
INFO - 2016-11-07 12:12:28 --> Router Class Initialized
INFO - 2016-11-07 12:12:28 --> Output Class Initialized
INFO - 2016-11-07 12:12:28 --> Security Class Initialized
DEBUG - 2016-11-07 12:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:12:28 --> Input Class Initialized
INFO - 2016-11-07 12:12:28 --> Language Class Initialized
INFO - 2016-11-07 12:12:28 --> Loader Class Initialized
INFO - 2016-11-07 12:12:28 --> Helper loaded: url_helper
INFO - 2016-11-07 12:12:28 --> Helper loaded: form_helper
INFO - 2016-11-07 12:12:28 --> Database Driver Class Initialized
INFO - 2016-11-07 12:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:12:28 --> Controller Class Initialized
INFO - 2016-11-07 12:12:28 --> Model Class Initialized
INFO - 2016-11-07 12:12:28 --> Model Class Initialized
INFO - 2016-11-07 12:12:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 12:12:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-07 12:12:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-07 12:12:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-07 12:12:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-07 12:12:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-07 12:12:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-07 12:12:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-07 12:12:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-07 12:12:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-07 12:12:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 12:12:28 --> Final output sent to browser
DEBUG - 2016-11-07 12:12:28 --> Total execution time: 0.2913
INFO - 2016-11-07 12:14:21 --> Config Class Initialized
INFO - 2016-11-07 12:14:21 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:14:21 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:14:21 --> Utf8 Class Initialized
INFO - 2016-11-07 12:14:21 --> URI Class Initialized
INFO - 2016-11-07 12:14:21 --> Router Class Initialized
INFO - 2016-11-07 12:14:21 --> Output Class Initialized
INFO - 2016-11-07 12:14:21 --> Security Class Initialized
DEBUG - 2016-11-07 12:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:14:21 --> Input Class Initialized
INFO - 2016-11-07 12:14:21 --> Language Class Initialized
INFO - 2016-11-07 12:14:21 --> Loader Class Initialized
INFO - 2016-11-07 12:14:21 --> Helper loaded: url_helper
INFO - 2016-11-07 12:14:21 --> Helper loaded: form_helper
INFO - 2016-11-07 12:14:21 --> Database Driver Class Initialized
INFO - 2016-11-07 12:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:14:21 --> Controller Class Initialized
INFO - 2016-11-07 12:14:21 --> Model Class Initialized
INFO - 2016-11-07 12:14:21 --> Form Validation Class Initialized
INFO - 2016-11-07 12:14:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-07 12:14:21 --> Final output sent to browser
DEBUG - 2016-11-07 12:14:21 --> Total execution time: 0.2189
INFO - 2016-11-07 12:14:25 --> Config Class Initialized
INFO - 2016-11-07 12:14:25 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:14:25 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:14:25 --> Utf8 Class Initialized
INFO - 2016-11-07 12:14:25 --> URI Class Initialized
DEBUG - 2016-11-07 12:14:25 --> No URI present. Default controller set.
INFO - 2016-11-07 12:14:25 --> Router Class Initialized
INFO - 2016-11-07 12:14:25 --> Output Class Initialized
INFO - 2016-11-07 12:14:25 --> Security Class Initialized
DEBUG - 2016-11-07 12:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:14:25 --> Input Class Initialized
INFO - 2016-11-07 12:14:25 --> Language Class Initialized
INFO - 2016-11-07 12:14:25 --> Loader Class Initialized
INFO - 2016-11-07 12:14:25 --> Helper loaded: url_helper
INFO - 2016-11-07 12:14:25 --> Helper loaded: form_helper
INFO - 2016-11-07 12:14:25 --> Database Driver Class Initialized
INFO - 2016-11-07 12:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:14:25 --> Controller Class Initialized
INFO - 2016-11-07 12:14:25 --> Model Class Initialized
INFO - 2016-11-07 12:14:25 --> Model Class Initialized
INFO - 2016-11-07 12:14:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 12:14:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-07 12:14:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-07 12:14:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-07 12:14:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-07 12:14:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-07 12:14:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-07 12:14:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-07 12:14:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-07 12:14:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-07 12:14:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 12:14:25 --> Final output sent to browser
DEBUG - 2016-11-07 12:14:25 --> Total execution time: 0.3074
INFO - 2016-11-07 12:14:50 --> Config Class Initialized
INFO - 2016-11-07 12:14:50 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:14:50 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:14:50 --> Utf8 Class Initialized
INFO - 2016-11-07 12:14:50 --> URI Class Initialized
INFO - 2016-11-07 12:14:50 --> Router Class Initialized
INFO - 2016-11-07 12:14:50 --> Output Class Initialized
INFO - 2016-11-07 12:14:50 --> Security Class Initialized
DEBUG - 2016-11-07 12:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:14:50 --> Input Class Initialized
INFO - 2016-11-07 12:14:50 --> Language Class Initialized
INFO - 2016-11-07 12:14:50 --> Loader Class Initialized
INFO - 2016-11-07 12:14:50 --> Helper loaded: url_helper
INFO - 2016-11-07 12:14:50 --> Helper loaded: form_helper
INFO - 2016-11-07 12:14:50 --> Database Driver Class Initialized
INFO - 2016-11-07 12:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:14:50 --> Controller Class Initialized
INFO - 2016-11-07 12:14:50 --> Model Class Initialized
INFO - 2016-11-07 12:14:50 --> Form Validation Class Initialized
INFO - 2016-11-07 12:14:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-07 12:14:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-07 12:14:51 --> Final output sent to browser
DEBUG - 2016-11-07 12:14:51 --> Total execution time: 0.3173
INFO - 2016-11-07 12:14:54 --> Config Class Initialized
INFO - 2016-11-07 12:14:54 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:14:54 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:14:54 --> Utf8 Class Initialized
INFO - 2016-11-07 12:14:54 --> URI Class Initialized
DEBUG - 2016-11-07 12:14:54 --> No URI present. Default controller set.
INFO - 2016-11-07 12:14:54 --> Router Class Initialized
INFO - 2016-11-07 12:14:54 --> Output Class Initialized
INFO - 2016-11-07 12:14:54 --> Security Class Initialized
DEBUG - 2016-11-07 12:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:14:54 --> Input Class Initialized
INFO - 2016-11-07 12:14:54 --> Language Class Initialized
INFO - 2016-11-07 12:14:54 --> Loader Class Initialized
INFO - 2016-11-07 12:14:54 --> Helper loaded: url_helper
INFO - 2016-11-07 12:14:54 --> Helper loaded: form_helper
INFO - 2016-11-07 12:14:54 --> Database Driver Class Initialized
INFO - 2016-11-07 12:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:14:54 --> Controller Class Initialized
INFO - 2016-11-07 12:14:54 --> Model Class Initialized
INFO - 2016-11-07 12:14:54 --> Model Class Initialized
INFO - 2016-11-07 12:14:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 12:14:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-07 12:14:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-07 12:14:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-07 12:14:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-07 12:14:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-07 12:14:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-07 12:14:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-07 12:14:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-07 12:14:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-07 12:14:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 12:14:54 --> Config Class Initialized
INFO - 2016-11-07 12:14:54 --> Final output sent to browser
INFO - 2016-11-07 12:14:54 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:14:54 --> Total execution time: 0.4848
DEBUG - 2016-11-07 12:14:54 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:14:54 --> Utf8 Class Initialized
INFO - 2016-11-07 12:14:54 --> URI Class Initialized
DEBUG - 2016-11-07 12:14:54 --> No URI present. Default controller set.
INFO - 2016-11-07 12:14:54 --> Router Class Initialized
INFO - 2016-11-07 12:14:54 --> Output Class Initialized
INFO - 2016-11-07 12:14:54 --> Security Class Initialized
DEBUG - 2016-11-07 12:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:14:54 --> Input Class Initialized
INFO - 2016-11-07 12:14:54 --> Language Class Initialized
INFO - 2016-11-07 12:14:54 --> Loader Class Initialized
INFO - 2016-11-07 12:14:54 --> Helper loaded: url_helper
INFO - 2016-11-07 12:14:54 --> Helper loaded: form_helper
INFO - 2016-11-07 12:14:54 --> Database Driver Class Initialized
INFO - 2016-11-07 12:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:14:54 --> Controller Class Initialized
INFO - 2016-11-07 12:14:54 --> Model Class Initialized
INFO - 2016-11-07 12:14:54 --> Model Class Initialized
INFO - 2016-11-07 12:14:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 12:14:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-07 12:14:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-07 12:14:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-07 12:14:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-07 12:14:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-07 12:14:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-07 12:14:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-07 12:14:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-07 12:14:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-07 12:14:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 12:14:54 --> Final output sent to browser
DEBUG - 2016-11-07 12:14:54 --> Total execution time: 0.3199
INFO - 2016-11-07 12:15:06 --> Config Class Initialized
INFO - 2016-11-07 12:15:06 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:15:06 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:15:06 --> Utf8 Class Initialized
INFO - 2016-11-07 12:15:06 --> URI Class Initialized
INFO - 2016-11-07 12:15:06 --> Router Class Initialized
INFO - 2016-11-07 12:15:06 --> Output Class Initialized
INFO - 2016-11-07 12:15:06 --> Security Class Initialized
DEBUG - 2016-11-07 12:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:15:06 --> Input Class Initialized
INFO - 2016-11-07 12:15:06 --> Language Class Initialized
INFO - 2016-11-07 12:15:06 --> Loader Class Initialized
INFO - 2016-11-07 12:15:06 --> Helper loaded: url_helper
INFO - 2016-11-07 12:15:06 --> Helper loaded: form_helper
INFO - 2016-11-07 12:15:06 --> Database Driver Class Initialized
INFO - 2016-11-07 12:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:15:06 --> Controller Class Initialized
INFO - 2016-11-07 12:15:06 --> Model Class Initialized
INFO - 2016-11-07 12:15:06 --> Model Class Initialized
DEBUG - 2016-11-07 12:15:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-07 12:15:06 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-07 12:15:06 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-07 12:15:06 --> Config Class Initialized
INFO - 2016-11-07 12:15:06 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:15:06 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:15:06 --> Utf8 Class Initialized
INFO - 2016-11-07 12:15:06 --> URI Class Initialized
DEBUG - 2016-11-07 12:15:06 --> No URI present. Default controller set.
INFO - 2016-11-07 12:15:06 --> Router Class Initialized
INFO - 2016-11-07 12:15:06 --> Output Class Initialized
INFO - 2016-11-07 12:15:06 --> Security Class Initialized
DEBUG - 2016-11-07 12:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:15:06 --> Input Class Initialized
INFO - 2016-11-07 12:15:06 --> Language Class Initialized
INFO - 2016-11-07 12:15:06 --> Loader Class Initialized
INFO - 2016-11-07 12:15:06 --> Helper loaded: url_helper
INFO - 2016-11-07 12:15:06 --> Helper loaded: form_helper
INFO - 2016-11-07 12:15:06 --> Database Driver Class Initialized
INFO - 2016-11-07 12:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:15:06 --> Controller Class Initialized
INFO - 2016-11-07 12:15:06 --> Model Class Initialized
INFO - 2016-11-07 12:15:06 --> Model Class Initialized
INFO - 2016-11-07 12:15:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 12:15:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 12:15:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 12:15:06 --> Final output sent to browser
DEBUG - 2016-11-07 12:15:06 --> Total execution time: 0.2148
INFO - 2016-11-07 12:15:14 --> Config Class Initialized
INFO - 2016-11-07 12:15:14 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:15:14 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:15:14 --> Utf8 Class Initialized
INFO - 2016-11-07 12:15:14 --> URI Class Initialized
INFO - 2016-11-07 12:15:14 --> Router Class Initialized
INFO - 2016-11-07 12:15:14 --> Output Class Initialized
INFO - 2016-11-07 12:15:14 --> Security Class Initialized
DEBUG - 2016-11-07 12:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:15:14 --> Input Class Initialized
INFO - 2016-11-07 12:15:14 --> Language Class Initialized
INFO - 2016-11-07 12:15:14 --> Loader Class Initialized
INFO - 2016-11-07 12:15:14 --> Helper loaded: url_helper
INFO - 2016-11-07 12:15:14 --> Helper loaded: form_helper
INFO - 2016-11-07 12:15:14 --> Database Driver Class Initialized
INFO - 2016-11-07 12:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:15:14 --> Controller Class Initialized
INFO - 2016-11-07 12:15:14 --> Model Class Initialized
INFO - 2016-11-07 12:15:14 --> Model Class Initialized
DEBUG - 2016-11-07 12:15:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-07 12:15:14 --> Model Class Initialized
INFO - 2016-11-07 12:15:14 --> Final output sent to browser
DEBUG - 2016-11-07 12:15:14 --> Total execution time: 0.1764
INFO - 2016-11-07 12:15:20 --> Config Class Initialized
INFO - 2016-11-07 12:15:20 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:15:20 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:15:20 --> Utf8 Class Initialized
INFO - 2016-11-07 12:15:20 --> URI Class Initialized
INFO - 2016-11-07 12:15:20 --> Router Class Initialized
INFO - 2016-11-07 12:15:20 --> Output Class Initialized
INFO - 2016-11-07 12:15:20 --> Security Class Initialized
DEBUG - 2016-11-07 12:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:15:20 --> Input Class Initialized
INFO - 2016-11-07 12:15:20 --> Language Class Initialized
INFO - 2016-11-07 12:15:20 --> Loader Class Initialized
INFO - 2016-11-07 12:15:20 --> Helper loaded: url_helper
INFO - 2016-11-07 12:15:20 --> Helper loaded: form_helper
INFO - 2016-11-07 12:15:20 --> Database Driver Class Initialized
INFO - 2016-11-07 12:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:15:20 --> Controller Class Initialized
INFO - 2016-11-07 12:15:20 --> Model Class Initialized
INFO - 2016-11-07 12:15:20 --> Model Class Initialized
DEBUG - 2016-11-07 12:15:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-07 12:15:20 --> Model Class Initialized
INFO - 2016-11-07 12:15:20 --> Final output sent to browser
DEBUG - 2016-11-07 12:15:20 --> Total execution time: 0.1809
INFO - 2016-11-07 12:15:27 --> Config Class Initialized
INFO - 2016-11-07 12:15:27 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:15:27 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:15:27 --> Utf8 Class Initialized
INFO - 2016-11-07 12:15:27 --> URI Class Initialized
INFO - 2016-11-07 12:15:27 --> Router Class Initialized
INFO - 2016-11-07 12:15:27 --> Output Class Initialized
INFO - 2016-11-07 12:15:27 --> Security Class Initialized
DEBUG - 2016-11-07 12:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:15:27 --> Input Class Initialized
INFO - 2016-11-07 12:15:27 --> Language Class Initialized
INFO - 2016-11-07 12:15:27 --> Loader Class Initialized
INFO - 2016-11-07 12:15:27 --> Helper loaded: url_helper
INFO - 2016-11-07 12:15:27 --> Helper loaded: form_helper
INFO - 2016-11-07 12:15:27 --> Database Driver Class Initialized
INFO - 2016-11-07 12:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:15:27 --> Controller Class Initialized
INFO - 2016-11-07 12:15:27 --> Model Class Initialized
INFO - 2016-11-07 12:15:27 --> Model Class Initialized
DEBUG - 2016-11-07 12:15:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-07 12:15:27 --> Model Class Initialized
INFO - 2016-11-07 12:15:27 --> Final output sent to browser
DEBUG - 2016-11-07 12:15:27 --> Total execution time: 0.1787
INFO - 2016-11-07 12:15:36 --> Config Class Initialized
INFO - 2016-11-07 12:15:36 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:15:36 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:15:36 --> Utf8 Class Initialized
INFO - 2016-11-07 12:15:36 --> URI Class Initialized
INFO - 2016-11-07 12:15:36 --> Router Class Initialized
INFO - 2016-11-07 12:15:36 --> Output Class Initialized
INFO - 2016-11-07 12:15:36 --> Security Class Initialized
DEBUG - 2016-11-07 12:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:15:36 --> Input Class Initialized
INFO - 2016-11-07 12:15:36 --> Language Class Initialized
INFO - 2016-11-07 12:15:36 --> Loader Class Initialized
INFO - 2016-11-07 12:15:36 --> Helper loaded: url_helper
INFO - 2016-11-07 12:15:36 --> Helper loaded: form_helper
INFO - 2016-11-07 12:15:36 --> Database Driver Class Initialized
INFO - 2016-11-07 12:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:15:36 --> Controller Class Initialized
INFO - 2016-11-07 12:15:36 --> Model Class Initialized
INFO - 2016-11-07 12:15:36 --> Model Class Initialized
DEBUG - 2016-11-07 12:15:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-07 12:15:36 --> Model Class Initialized
INFO - 2016-11-07 12:15:36 --> Final output sent to browser
DEBUG - 2016-11-07 12:15:36 --> Total execution time: 0.2172
INFO - 2016-11-07 12:16:10 --> Config Class Initialized
INFO - 2016-11-07 12:16:10 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:16:10 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:16:10 --> Utf8 Class Initialized
INFO - 2016-11-07 12:16:10 --> URI Class Initialized
INFO - 2016-11-07 12:16:10 --> Router Class Initialized
INFO - 2016-11-07 12:16:10 --> Output Class Initialized
INFO - 2016-11-07 12:16:10 --> Security Class Initialized
DEBUG - 2016-11-07 12:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:16:10 --> Input Class Initialized
INFO - 2016-11-07 12:16:10 --> Language Class Initialized
INFO - 2016-11-07 12:16:10 --> Loader Class Initialized
INFO - 2016-11-07 12:16:10 --> Helper loaded: url_helper
INFO - 2016-11-07 12:16:10 --> Helper loaded: form_helper
INFO - 2016-11-07 12:16:10 --> Database Driver Class Initialized
INFO - 2016-11-07 12:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:16:10 --> Controller Class Initialized
INFO - 2016-11-07 12:16:10 --> Model Class Initialized
INFO - 2016-11-07 12:16:10 --> Model Class Initialized
DEBUG - 2016-11-07 12:16:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-07 12:16:10 --> Model Class Initialized
INFO - 2016-11-07 12:16:10 --> Final output sent to browser
DEBUG - 2016-11-07 12:16:10 --> Total execution time: 0.2363
INFO - 2016-11-07 12:16:19 --> Config Class Initialized
INFO - 2016-11-07 12:16:19 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:16:19 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:16:19 --> Utf8 Class Initialized
INFO - 2016-11-07 12:16:19 --> URI Class Initialized
INFO - 2016-11-07 12:16:19 --> Router Class Initialized
INFO - 2016-11-07 12:16:19 --> Output Class Initialized
INFO - 2016-11-07 12:16:19 --> Security Class Initialized
DEBUG - 2016-11-07 12:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:16:19 --> Input Class Initialized
INFO - 2016-11-07 12:16:19 --> Language Class Initialized
INFO - 2016-11-07 12:16:19 --> Loader Class Initialized
INFO - 2016-11-07 12:16:19 --> Helper loaded: url_helper
INFO - 2016-11-07 12:16:19 --> Helper loaded: form_helper
INFO - 2016-11-07 12:16:19 --> Database Driver Class Initialized
INFO - 2016-11-07 12:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:16:19 --> Controller Class Initialized
INFO - 2016-11-07 12:16:19 --> Model Class Initialized
INFO - 2016-11-07 12:16:19 --> Model Class Initialized
DEBUG - 2016-11-07 12:16:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-07 12:16:19 --> Model Class Initialized
INFO - 2016-11-07 12:16:19 --> Final output sent to browser
DEBUG - 2016-11-07 12:16:19 --> Total execution time: 0.2328
INFO - 2016-11-07 12:16:19 --> Config Class Initialized
INFO - 2016-11-07 12:16:19 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:16:19 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:16:19 --> Utf8 Class Initialized
INFO - 2016-11-07 12:16:19 --> URI Class Initialized
DEBUG - 2016-11-07 12:16:19 --> No URI present. Default controller set.
INFO - 2016-11-07 12:16:19 --> Router Class Initialized
INFO - 2016-11-07 12:16:19 --> Output Class Initialized
INFO - 2016-11-07 12:16:19 --> Security Class Initialized
DEBUG - 2016-11-07 12:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:16:19 --> Input Class Initialized
INFO - 2016-11-07 12:16:19 --> Language Class Initialized
INFO - 2016-11-07 12:16:19 --> Loader Class Initialized
INFO - 2016-11-07 12:16:19 --> Helper loaded: url_helper
INFO - 2016-11-07 12:16:20 --> Helper loaded: form_helper
INFO - 2016-11-07 12:16:20 --> Database Driver Class Initialized
INFO - 2016-11-07 12:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:16:20 --> Controller Class Initialized
INFO - 2016-11-07 12:16:20 --> Model Class Initialized
INFO - 2016-11-07 12:16:20 --> Model Class Initialized
INFO - 2016-11-07 12:16:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 12:16:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-07 12:16:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-07 12:16:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-07 12:16:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-07 12:16:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-07 12:16:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 12:16:20 --> Final output sent to browser
DEBUG - 2016-11-07 12:16:20 --> Total execution time: 0.3352
INFO - 2016-11-07 12:18:07 --> Config Class Initialized
INFO - 2016-11-07 12:18:07 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:18:07 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:18:07 --> Utf8 Class Initialized
INFO - 2016-11-07 12:18:07 --> URI Class Initialized
INFO - 2016-11-07 12:18:07 --> Router Class Initialized
INFO - 2016-11-07 12:18:07 --> Output Class Initialized
INFO - 2016-11-07 12:18:07 --> Security Class Initialized
DEBUG - 2016-11-07 12:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:18:07 --> Input Class Initialized
INFO - 2016-11-07 12:18:07 --> Language Class Initialized
INFO - 2016-11-07 12:18:07 --> Loader Class Initialized
INFO - 2016-11-07 12:18:07 --> Helper loaded: url_helper
INFO - 2016-11-07 12:18:07 --> Helper loaded: form_helper
INFO - 2016-11-07 12:18:07 --> Database Driver Class Initialized
INFO - 2016-11-07 12:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:18:07 --> Controller Class Initialized
INFO - 2016-11-07 12:18:07 --> Model Class Initialized
INFO - 2016-11-07 12:18:07 --> Model Class Initialized
DEBUG - 2016-11-07 12:18:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-07 12:18:07 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-07 12:18:07 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-07 12:18:07 --> Config Class Initialized
INFO - 2016-11-07 12:18:07 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:18:07 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:18:07 --> Utf8 Class Initialized
INFO - 2016-11-07 12:18:07 --> URI Class Initialized
DEBUG - 2016-11-07 12:18:07 --> No URI present. Default controller set.
INFO - 2016-11-07 12:18:07 --> Router Class Initialized
INFO - 2016-11-07 12:18:07 --> Output Class Initialized
INFO - 2016-11-07 12:18:07 --> Security Class Initialized
DEBUG - 2016-11-07 12:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:18:07 --> Input Class Initialized
INFO - 2016-11-07 12:18:07 --> Language Class Initialized
INFO - 2016-11-07 12:18:07 --> Loader Class Initialized
INFO - 2016-11-07 12:18:07 --> Helper loaded: url_helper
INFO - 2016-11-07 12:18:07 --> Helper loaded: form_helper
INFO - 2016-11-07 12:18:07 --> Database Driver Class Initialized
INFO - 2016-11-07 12:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:18:08 --> Controller Class Initialized
INFO - 2016-11-07 12:18:08 --> Model Class Initialized
INFO - 2016-11-07 12:18:08 --> Model Class Initialized
INFO - 2016-11-07 12:18:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 12:18:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 12:18:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 12:18:08 --> Final output sent to browser
DEBUG - 2016-11-07 12:18:08 --> Total execution time: 0.2414
INFO - 2016-11-07 12:18:28 --> Config Class Initialized
INFO - 2016-11-07 12:18:28 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:18:28 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:18:28 --> Utf8 Class Initialized
INFO - 2016-11-07 12:18:28 --> URI Class Initialized
INFO - 2016-11-07 12:18:28 --> Router Class Initialized
INFO - 2016-11-07 12:18:28 --> Output Class Initialized
INFO - 2016-11-07 12:18:28 --> Security Class Initialized
DEBUG - 2016-11-07 12:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:18:28 --> Input Class Initialized
INFO - 2016-11-07 12:18:28 --> Language Class Initialized
INFO - 2016-11-07 12:18:28 --> Loader Class Initialized
INFO - 2016-11-07 12:18:28 --> Helper loaded: url_helper
INFO - 2016-11-07 12:18:28 --> Helper loaded: form_helper
INFO - 2016-11-07 12:18:28 --> Database Driver Class Initialized
INFO - 2016-11-07 12:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:18:28 --> Controller Class Initialized
INFO - 2016-11-07 12:18:28 --> Model Class Initialized
INFO - 2016-11-07 12:18:28 --> Model Class Initialized
DEBUG - 2016-11-07 12:18:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-07 12:18:28 --> Model Class Initialized
INFO - 2016-11-07 12:18:28 --> Final output sent to browser
DEBUG - 2016-11-07 12:18:28 --> Total execution time: 0.1790
INFO - 2016-11-07 12:18:28 --> Config Class Initialized
INFO - 2016-11-07 12:18:28 --> Hooks Class Initialized
DEBUG - 2016-11-07 12:18:28 --> UTF-8 Support Enabled
INFO - 2016-11-07 12:18:28 --> Utf8 Class Initialized
INFO - 2016-11-07 12:18:28 --> URI Class Initialized
DEBUG - 2016-11-07 12:18:28 --> No URI present. Default controller set.
INFO - 2016-11-07 12:18:28 --> Router Class Initialized
INFO - 2016-11-07 12:18:28 --> Output Class Initialized
INFO - 2016-11-07 12:18:28 --> Security Class Initialized
DEBUG - 2016-11-07 12:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 12:18:28 --> Input Class Initialized
INFO - 2016-11-07 12:18:28 --> Language Class Initialized
INFO - 2016-11-07 12:18:28 --> Loader Class Initialized
INFO - 2016-11-07 12:18:28 --> Helper loaded: url_helper
INFO - 2016-11-07 12:18:28 --> Helper loaded: form_helper
INFO - 2016-11-07 12:18:28 --> Database Driver Class Initialized
INFO - 2016-11-07 12:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 12:18:28 --> Controller Class Initialized
INFO - 2016-11-07 12:18:28 --> Model Class Initialized
INFO - 2016-11-07 12:18:28 --> Model Class Initialized
INFO - 2016-11-07 12:18:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 12:18:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-07 12:18:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-07 12:18:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-07 12:18:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-07 12:18:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-07 12:18:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-07 12:18:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-07 12:18:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-07 12:18:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-07 12:18:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 12:18:28 --> Final output sent to browser
DEBUG - 2016-11-07 12:18:28 --> Total execution time: 0.2834
INFO - 2016-11-07 14:42:01 --> Config Class Initialized
INFO - 2016-11-07 14:42:01 --> Hooks Class Initialized
DEBUG - 2016-11-07 14:42:01 --> UTF-8 Support Enabled
INFO - 2016-11-07 14:42:01 --> Utf8 Class Initialized
INFO - 2016-11-07 14:42:01 --> URI Class Initialized
INFO - 2016-11-07 14:42:01 --> Router Class Initialized
INFO - 2016-11-07 14:42:01 --> Output Class Initialized
INFO - 2016-11-07 14:42:01 --> Security Class Initialized
DEBUG - 2016-11-07 14:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 14:42:01 --> Input Class Initialized
INFO - 2016-11-07 14:42:01 --> Language Class Initialized
INFO - 2016-11-07 14:42:01 --> Loader Class Initialized
INFO - 2016-11-07 14:42:01 --> Helper loaded: url_helper
INFO - 2016-11-07 14:42:01 --> Helper loaded: form_helper
INFO - 2016-11-07 14:42:01 --> Database Driver Class Initialized
INFO - 2016-11-07 14:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 14:42:01 --> Controller Class Initialized
INFO - 2016-11-07 14:42:01 --> Model Class Initialized
INFO - 2016-11-07 14:42:01 --> Model Class Initialized
DEBUG - 2016-11-07 14:42:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-07 14:42:01 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-07 14:42:01 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-07 14:42:01 --> Config Class Initialized
INFO - 2016-11-07 14:42:01 --> Hooks Class Initialized
DEBUG - 2016-11-07 14:42:02 --> UTF-8 Support Enabled
INFO - 2016-11-07 14:42:02 --> Utf8 Class Initialized
INFO - 2016-11-07 14:42:02 --> URI Class Initialized
DEBUG - 2016-11-07 14:42:02 --> No URI present. Default controller set.
INFO - 2016-11-07 14:42:02 --> Router Class Initialized
INFO - 2016-11-07 14:42:02 --> Output Class Initialized
INFO - 2016-11-07 14:42:02 --> Security Class Initialized
DEBUG - 2016-11-07 14:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 14:42:02 --> Input Class Initialized
INFO - 2016-11-07 14:42:02 --> Language Class Initialized
INFO - 2016-11-07 14:42:02 --> Loader Class Initialized
INFO - 2016-11-07 14:42:02 --> Helper loaded: url_helper
INFO - 2016-11-07 14:42:02 --> Helper loaded: form_helper
INFO - 2016-11-07 14:42:02 --> Database Driver Class Initialized
INFO - 2016-11-07 14:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 14:42:02 --> Controller Class Initialized
INFO - 2016-11-07 14:42:02 --> Model Class Initialized
INFO - 2016-11-07 14:42:02 --> Model Class Initialized
INFO - 2016-11-07 14:42:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 14:42:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 14:42:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 14:42:02 --> Final output sent to browser
DEBUG - 2016-11-07 14:42:02 --> Total execution time: 0.2493
INFO - 2016-11-07 14:42:15 --> Config Class Initialized
INFO - 2016-11-07 14:42:15 --> Hooks Class Initialized
DEBUG - 2016-11-07 14:42:15 --> UTF-8 Support Enabled
INFO - 2016-11-07 14:42:15 --> Utf8 Class Initialized
INFO - 2016-11-07 14:42:15 --> URI Class Initialized
INFO - 2016-11-07 14:42:15 --> Router Class Initialized
INFO - 2016-11-07 14:42:15 --> Output Class Initialized
INFO - 2016-11-07 14:42:15 --> Security Class Initialized
DEBUG - 2016-11-07 14:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 14:42:15 --> Input Class Initialized
INFO - 2016-11-07 14:42:15 --> Language Class Initialized
INFO - 2016-11-07 14:42:15 --> Loader Class Initialized
INFO - 2016-11-07 14:42:15 --> Helper loaded: url_helper
INFO - 2016-11-07 14:42:15 --> Helper loaded: form_helper
INFO - 2016-11-07 14:42:15 --> Database Driver Class Initialized
INFO - 2016-11-07 14:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 14:42:15 --> Controller Class Initialized
INFO - 2016-11-07 14:42:15 --> Model Class Initialized
INFO - 2016-11-07 14:42:15 --> Model Class Initialized
DEBUG - 2016-11-07 14:42:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-07 14:42:15 --> Model Class Initialized
INFO - 2016-11-07 14:42:15 --> Final output sent to browser
DEBUG - 2016-11-07 14:42:15 --> Total execution time: 0.1835
INFO - 2016-11-07 14:42:15 --> Config Class Initialized
INFO - 2016-11-07 14:42:15 --> Hooks Class Initialized
DEBUG - 2016-11-07 14:42:15 --> UTF-8 Support Enabled
INFO - 2016-11-07 14:42:15 --> Utf8 Class Initialized
INFO - 2016-11-07 14:42:15 --> URI Class Initialized
DEBUG - 2016-11-07 14:42:15 --> No URI present. Default controller set.
INFO - 2016-11-07 14:42:15 --> Router Class Initialized
INFO - 2016-11-07 14:42:15 --> Output Class Initialized
INFO - 2016-11-07 14:42:15 --> Security Class Initialized
DEBUG - 2016-11-07 14:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 14:42:15 --> Input Class Initialized
INFO - 2016-11-07 14:42:15 --> Language Class Initialized
INFO - 2016-11-07 14:42:15 --> Loader Class Initialized
INFO - 2016-11-07 14:42:15 --> Helper loaded: url_helper
INFO - 2016-11-07 14:42:15 --> Helper loaded: form_helper
INFO - 2016-11-07 14:42:15 --> Database Driver Class Initialized
INFO - 2016-11-07 14:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 14:42:15 --> Controller Class Initialized
INFO - 2016-11-07 14:42:15 --> Model Class Initialized
INFO - 2016-11-07 14:42:15 --> Model Class Initialized
INFO - 2016-11-07 14:42:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 14:42:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-07 14:42:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-07 14:42:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-07 14:42:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-07 14:42:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-07 14:42:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-07 14:42:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-07 14:42:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-07 14:42:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-07 14:42:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 14:42:15 --> Final output sent to browser
DEBUG - 2016-11-07 14:42:15 --> Total execution time: 0.2835
INFO - 2016-11-07 14:43:07 --> Config Class Initialized
INFO - 2016-11-07 14:43:07 --> Hooks Class Initialized
DEBUG - 2016-11-07 14:43:07 --> UTF-8 Support Enabled
INFO - 2016-11-07 14:43:07 --> Utf8 Class Initialized
INFO - 2016-11-07 14:43:07 --> URI Class Initialized
INFO - 2016-11-07 14:43:07 --> Router Class Initialized
INFO - 2016-11-07 14:43:07 --> Output Class Initialized
INFO - 2016-11-07 14:43:07 --> Security Class Initialized
DEBUG - 2016-11-07 14:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 14:43:07 --> Input Class Initialized
INFO - 2016-11-07 14:43:07 --> Language Class Initialized
INFO - 2016-11-07 14:43:07 --> Loader Class Initialized
INFO - 2016-11-07 14:43:07 --> Helper loaded: url_helper
INFO - 2016-11-07 14:43:07 --> Helper loaded: form_helper
INFO - 2016-11-07 14:43:07 --> Database Driver Class Initialized
INFO - 2016-11-07 14:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 14:43:07 --> Controller Class Initialized
INFO - 2016-11-07 14:43:07 --> Model Class Initialized
INFO - 2016-11-07 14:43:07 --> Form Validation Class Initialized
INFO - 2016-11-07 14:43:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-07 14:43:07 --> Final output sent to browser
DEBUG - 2016-11-07 14:43:07 --> Total execution time: 0.2202
INFO - 2016-11-07 14:43:16 --> Config Class Initialized
INFO - 2016-11-07 14:43:16 --> Hooks Class Initialized
DEBUG - 2016-11-07 14:43:16 --> UTF-8 Support Enabled
INFO - 2016-11-07 14:43:16 --> Utf8 Class Initialized
INFO - 2016-11-07 14:43:16 --> URI Class Initialized
DEBUG - 2016-11-07 14:43:16 --> No URI present. Default controller set.
INFO - 2016-11-07 14:43:16 --> Router Class Initialized
INFO - 2016-11-07 14:43:16 --> Output Class Initialized
INFO - 2016-11-07 14:43:16 --> Security Class Initialized
DEBUG - 2016-11-07 14:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 14:43:16 --> Input Class Initialized
INFO - 2016-11-07 14:43:16 --> Language Class Initialized
INFO - 2016-11-07 14:43:16 --> Loader Class Initialized
INFO - 2016-11-07 14:43:16 --> Helper loaded: url_helper
INFO - 2016-11-07 14:43:16 --> Helper loaded: form_helper
INFO - 2016-11-07 14:43:16 --> Database Driver Class Initialized
INFO - 2016-11-07 14:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 14:43:16 --> Controller Class Initialized
INFO - 2016-11-07 14:43:16 --> Model Class Initialized
INFO - 2016-11-07 14:43:16 --> Model Class Initialized
INFO - 2016-11-07 14:43:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 14:43:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-07 14:43:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-07 14:43:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-07 14:43:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-07 14:43:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-07 14:43:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-07 14:43:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-07 14:43:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-07 14:43:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-07 14:43:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 14:43:17 --> Final output sent to browser
DEBUG - 2016-11-07 14:43:17 --> Total execution time: 0.3435
INFO - 2016-11-07 14:43:37 --> Config Class Initialized
INFO - 2016-11-07 14:43:37 --> Hooks Class Initialized
DEBUG - 2016-11-07 14:43:37 --> UTF-8 Support Enabled
INFO - 2016-11-07 14:43:37 --> Utf8 Class Initialized
INFO - 2016-11-07 14:43:37 --> URI Class Initialized
INFO - 2016-11-07 14:43:37 --> Router Class Initialized
INFO - 2016-11-07 14:43:37 --> Output Class Initialized
INFO - 2016-11-07 14:43:37 --> Security Class Initialized
DEBUG - 2016-11-07 14:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 14:43:37 --> Input Class Initialized
INFO - 2016-11-07 14:43:37 --> Language Class Initialized
INFO - 2016-11-07 14:43:37 --> Loader Class Initialized
INFO - 2016-11-07 14:43:37 --> Helper loaded: url_helper
INFO - 2016-11-07 14:43:37 --> Helper loaded: form_helper
INFO - 2016-11-07 14:43:37 --> Database Driver Class Initialized
INFO - 2016-11-07 14:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 14:43:37 --> Controller Class Initialized
INFO - 2016-11-07 14:43:37 --> Model Class Initialized
INFO - 2016-11-07 14:43:37 --> Form Validation Class Initialized
INFO - 2016-11-07 14:43:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-07 14:43:37 --> Final output sent to browser
DEBUG - 2016-11-07 14:43:37 --> Total execution time: 0.2370
INFO - 2016-11-07 14:43:42 --> Config Class Initialized
INFO - 2016-11-07 14:43:42 --> Hooks Class Initialized
DEBUG - 2016-11-07 14:43:42 --> UTF-8 Support Enabled
INFO - 2016-11-07 14:43:42 --> Utf8 Class Initialized
INFO - 2016-11-07 14:43:42 --> URI Class Initialized
DEBUG - 2016-11-07 14:43:42 --> No URI present. Default controller set.
INFO - 2016-11-07 14:43:42 --> Router Class Initialized
INFO - 2016-11-07 14:43:42 --> Output Class Initialized
INFO - 2016-11-07 14:43:42 --> Security Class Initialized
DEBUG - 2016-11-07 14:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 14:43:42 --> Input Class Initialized
INFO - 2016-11-07 14:43:42 --> Language Class Initialized
INFO - 2016-11-07 14:43:42 --> Loader Class Initialized
INFO - 2016-11-07 14:43:42 --> Helper loaded: url_helper
INFO - 2016-11-07 14:43:42 --> Helper loaded: form_helper
INFO - 2016-11-07 14:43:42 --> Database Driver Class Initialized
INFO - 2016-11-07 14:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 14:43:42 --> Controller Class Initialized
INFO - 2016-11-07 14:43:42 --> Model Class Initialized
INFO - 2016-11-07 14:43:42 --> Model Class Initialized
INFO - 2016-11-07 14:43:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 14:43:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-07 14:43:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-07 14:43:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-07 14:43:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-07 14:43:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-07 14:43:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-07 14:43:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-07 14:43:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-07 14:43:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-07 14:43:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 14:43:43 --> Final output sent to browser
DEBUG - 2016-11-07 14:43:43 --> Total execution time: 0.3353
INFO - 2016-11-07 14:44:11 --> Config Class Initialized
INFO - 2016-11-07 14:44:11 --> Hooks Class Initialized
DEBUG - 2016-11-07 14:44:11 --> UTF-8 Support Enabled
INFO - 2016-11-07 14:44:11 --> Utf8 Class Initialized
INFO - 2016-11-07 14:44:11 --> URI Class Initialized
INFO - 2016-11-07 14:44:11 --> Router Class Initialized
INFO - 2016-11-07 14:44:11 --> Output Class Initialized
INFO - 2016-11-07 14:44:11 --> Security Class Initialized
DEBUG - 2016-11-07 14:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 14:44:11 --> Input Class Initialized
INFO - 2016-11-07 14:44:11 --> Language Class Initialized
INFO - 2016-11-07 14:44:11 --> Loader Class Initialized
INFO - 2016-11-07 14:44:11 --> Helper loaded: url_helper
INFO - 2016-11-07 14:44:11 --> Helper loaded: form_helper
INFO - 2016-11-07 14:44:11 --> Database Driver Class Initialized
INFO - 2016-11-07 14:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 14:44:11 --> Controller Class Initialized
INFO - 2016-11-07 14:44:11 --> Model Class Initialized
INFO - 2016-11-07 14:44:11 --> Form Validation Class Initialized
INFO - 2016-11-07 14:44:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-07 14:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-07 14:44:11 --> Final output sent to browser
DEBUG - 2016-11-07 14:44:11 --> Total execution time: 0.3527
INFO - 2016-11-07 14:44:13 --> Config Class Initialized
INFO - 2016-11-07 14:44:13 --> Hooks Class Initialized
DEBUG - 2016-11-07 14:44:13 --> UTF-8 Support Enabled
INFO - 2016-11-07 14:44:13 --> Utf8 Class Initialized
INFO - 2016-11-07 14:44:13 --> URI Class Initialized
DEBUG - 2016-11-07 14:44:13 --> No URI present. Default controller set.
INFO - 2016-11-07 14:44:13 --> Router Class Initialized
INFO - 2016-11-07 14:44:13 --> Output Class Initialized
INFO - 2016-11-07 14:44:13 --> Security Class Initialized
DEBUG - 2016-11-07 14:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 14:44:13 --> Input Class Initialized
INFO - 2016-11-07 14:44:13 --> Language Class Initialized
INFO - 2016-11-07 14:44:13 --> Loader Class Initialized
INFO - 2016-11-07 14:44:13 --> Helper loaded: url_helper
INFO - 2016-11-07 14:44:13 --> Helper loaded: form_helper
INFO - 2016-11-07 14:44:13 --> Database Driver Class Initialized
INFO - 2016-11-07 14:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 14:44:13 --> Controller Class Initialized
INFO - 2016-11-07 14:44:13 --> Model Class Initialized
INFO - 2016-11-07 14:44:13 --> Model Class Initialized
INFO - 2016-11-07 14:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 14:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-07 14:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-07 14:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-07 14:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-07 14:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-07 14:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-07 14:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-07 14:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-07 14:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-07 14:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 14:44:13 --> Final output sent to browser
DEBUG - 2016-11-07 14:44:13 --> Total execution time: 0.3347
INFO - 2016-11-07 14:44:15 --> Config Class Initialized
INFO - 2016-11-07 14:44:15 --> Hooks Class Initialized
DEBUG - 2016-11-07 14:44:15 --> UTF-8 Support Enabled
INFO - 2016-11-07 14:44:15 --> Utf8 Class Initialized
INFO - 2016-11-07 14:44:15 --> URI Class Initialized
INFO - 2016-11-07 14:44:15 --> Router Class Initialized
INFO - 2016-11-07 14:44:15 --> Output Class Initialized
INFO - 2016-11-07 14:44:15 --> Security Class Initialized
DEBUG - 2016-11-07 14:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 14:44:15 --> Input Class Initialized
INFO - 2016-11-07 14:44:15 --> Language Class Initialized
INFO - 2016-11-07 14:44:15 --> Loader Class Initialized
INFO - 2016-11-07 14:44:15 --> Helper loaded: url_helper
INFO - 2016-11-07 14:44:15 --> Helper loaded: form_helper
INFO - 2016-11-07 14:44:15 --> Database Driver Class Initialized
INFO - 2016-11-07 14:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 14:44:15 --> Controller Class Initialized
INFO - 2016-11-07 14:44:15 --> Model Class Initialized
INFO - 2016-11-07 14:44:15 --> Model Class Initialized
DEBUG - 2016-11-07 14:44:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-07 14:44:15 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-07 14:44:15 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-07 14:44:15 --> Config Class Initialized
INFO - 2016-11-07 14:44:15 --> Hooks Class Initialized
DEBUG - 2016-11-07 14:44:15 --> UTF-8 Support Enabled
INFO - 2016-11-07 14:44:15 --> Utf8 Class Initialized
INFO - 2016-11-07 14:44:15 --> URI Class Initialized
DEBUG - 2016-11-07 14:44:15 --> No URI present. Default controller set.
INFO - 2016-11-07 14:44:15 --> Router Class Initialized
INFO - 2016-11-07 14:44:15 --> Output Class Initialized
INFO - 2016-11-07 14:44:15 --> Security Class Initialized
DEBUG - 2016-11-07 14:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 14:44:15 --> Input Class Initialized
INFO - 2016-11-07 14:44:15 --> Language Class Initialized
INFO - 2016-11-07 14:44:15 --> Loader Class Initialized
INFO - 2016-11-07 14:44:15 --> Helper loaded: url_helper
INFO - 2016-11-07 14:44:16 --> Helper loaded: form_helper
INFO - 2016-11-07 14:44:16 --> Database Driver Class Initialized
INFO - 2016-11-07 14:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 14:44:16 --> Controller Class Initialized
INFO - 2016-11-07 14:44:16 --> Model Class Initialized
INFO - 2016-11-07 14:44:16 --> Model Class Initialized
INFO - 2016-11-07 14:44:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 14:44:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 14:44:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 14:44:16 --> Final output sent to browser
DEBUG - 2016-11-07 14:44:16 --> Total execution time: 0.2438
INFO - 2016-11-07 14:44:22 --> Config Class Initialized
INFO - 2016-11-07 14:44:22 --> Hooks Class Initialized
DEBUG - 2016-11-07 14:44:22 --> UTF-8 Support Enabled
INFO - 2016-11-07 14:44:22 --> Utf8 Class Initialized
INFO - 2016-11-07 14:44:22 --> URI Class Initialized
INFO - 2016-11-07 14:44:22 --> Router Class Initialized
INFO - 2016-11-07 14:44:22 --> Output Class Initialized
INFO - 2016-11-07 14:44:22 --> Security Class Initialized
DEBUG - 2016-11-07 14:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 14:44:22 --> Input Class Initialized
INFO - 2016-11-07 14:44:22 --> Language Class Initialized
INFO - 2016-11-07 14:44:22 --> Loader Class Initialized
INFO - 2016-11-07 14:44:22 --> Helper loaded: url_helper
INFO - 2016-11-07 14:44:22 --> Helper loaded: form_helper
INFO - 2016-11-07 14:44:22 --> Database Driver Class Initialized
INFO - 2016-11-07 14:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 14:44:22 --> Controller Class Initialized
INFO - 2016-11-07 14:44:22 --> Model Class Initialized
INFO - 2016-11-07 14:44:22 --> Model Class Initialized
DEBUG - 2016-11-07 14:44:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-07 14:44:22 --> Model Class Initialized
INFO - 2016-11-07 14:44:22 --> Final output sent to browser
DEBUG - 2016-11-07 14:44:22 --> Total execution time: 0.2494
INFO - 2016-11-07 14:44:44 --> Config Class Initialized
INFO - 2016-11-07 14:44:44 --> Hooks Class Initialized
DEBUG - 2016-11-07 14:44:44 --> UTF-8 Support Enabled
INFO - 2016-11-07 14:44:44 --> Utf8 Class Initialized
INFO - 2016-11-07 14:44:44 --> URI Class Initialized
INFO - 2016-11-07 14:44:44 --> Router Class Initialized
INFO - 2016-11-07 14:44:44 --> Output Class Initialized
INFO - 2016-11-07 14:44:44 --> Security Class Initialized
DEBUG - 2016-11-07 14:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 14:44:44 --> Input Class Initialized
INFO - 2016-11-07 14:44:44 --> Language Class Initialized
INFO - 2016-11-07 14:44:44 --> Loader Class Initialized
INFO - 2016-11-07 14:44:44 --> Helper loaded: url_helper
INFO - 2016-11-07 14:44:44 --> Helper loaded: form_helper
INFO - 2016-11-07 14:44:44 --> Database Driver Class Initialized
INFO - 2016-11-07 14:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 14:44:44 --> Controller Class Initialized
INFO - 2016-11-07 14:44:44 --> Model Class Initialized
INFO - 2016-11-07 14:44:44 --> Model Class Initialized
DEBUG - 2016-11-07 14:44:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-07 14:44:44 --> Model Class Initialized
INFO - 2016-11-07 14:44:44 --> Final output sent to browser
DEBUG - 2016-11-07 14:44:44 --> Total execution time: 0.2449
INFO - 2016-11-07 14:44:51 --> Config Class Initialized
INFO - 2016-11-07 14:44:51 --> Hooks Class Initialized
DEBUG - 2016-11-07 14:44:51 --> UTF-8 Support Enabled
INFO - 2016-11-07 14:44:51 --> Utf8 Class Initialized
INFO - 2016-11-07 14:44:51 --> URI Class Initialized
INFO - 2016-11-07 14:44:51 --> Router Class Initialized
INFO - 2016-11-07 14:44:51 --> Output Class Initialized
INFO - 2016-11-07 14:44:51 --> Security Class Initialized
DEBUG - 2016-11-07 14:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 14:44:51 --> Input Class Initialized
INFO - 2016-11-07 14:44:51 --> Language Class Initialized
INFO - 2016-11-07 14:44:51 --> Loader Class Initialized
INFO - 2016-11-07 14:44:51 --> Helper loaded: url_helper
INFO - 2016-11-07 14:44:51 --> Helper loaded: form_helper
INFO - 2016-11-07 14:44:51 --> Database Driver Class Initialized
INFO - 2016-11-07 14:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 14:44:51 --> Controller Class Initialized
INFO - 2016-11-07 14:44:51 --> Model Class Initialized
INFO - 2016-11-07 14:44:51 --> Model Class Initialized
DEBUG - 2016-11-07 14:44:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-07 14:44:51 --> Model Class Initialized
INFO - 2016-11-07 14:44:51 --> Final output sent to browser
DEBUG - 2016-11-07 14:44:51 --> Total execution time: 0.2419
INFO - 2016-11-07 14:44:51 --> Config Class Initialized
INFO - 2016-11-07 14:44:51 --> Hooks Class Initialized
DEBUG - 2016-11-07 14:44:51 --> UTF-8 Support Enabled
INFO - 2016-11-07 14:44:51 --> Utf8 Class Initialized
INFO - 2016-11-07 14:44:51 --> URI Class Initialized
DEBUG - 2016-11-07 14:44:51 --> No URI present. Default controller set.
INFO - 2016-11-07 14:44:51 --> Router Class Initialized
INFO - 2016-11-07 14:44:51 --> Output Class Initialized
INFO - 2016-11-07 14:44:51 --> Security Class Initialized
DEBUG - 2016-11-07 14:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 14:44:51 --> Input Class Initialized
INFO - 2016-11-07 14:44:51 --> Language Class Initialized
INFO - 2016-11-07 14:44:51 --> Loader Class Initialized
INFO - 2016-11-07 14:44:51 --> Helper loaded: url_helper
INFO - 2016-11-07 14:44:51 --> Helper loaded: form_helper
INFO - 2016-11-07 14:44:51 --> Database Driver Class Initialized
INFO - 2016-11-07 14:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 14:44:51 --> Controller Class Initialized
INFO - 2016-11-07 14:44:51 --> Model Class Initialized
INFO - 2016-11-07 14:44:51 --> Model Class Initialized
INFO - 2016-11-07 14:44:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 14:44:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-07 14:44:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-07 14:44:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-07 14:44:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-07 14:44:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-07 14:44:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-07 14:44:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-07 14:44:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 14:44:52 --> Final output sent to browser
DEBUG - 2016-11-07 14:44:52 --> Total execution time: 0.4893
INFO - 2016-11-07 14:55:00 --> Config Class Initialized
INFO - 2016-11-07 14:55:00 --> Hooks Class Initialized
DEBUG - 2016-11-07 14:55:00 --> UTF-8 Support Enabled
INFO - 2016-11-07 14:55:00 --> Utf8 Class Initialized
INFO - 2016-11-07 14:55:00 --> URI Class Initialized
INFO - 2016-11-07 14:55:00 --> Router Class Initialized
INFO - 2016-11-07 14:55:00 --> Output Class Initialized
INFO - 2016-11-07 14:55:00 --> Security Class Initialized
DEBUG - 2016-11-07 14:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 14:55:00 --> Input Class Initialized
INFO - 2016-11-07 14:55:00 --> Language Class Initialized
INFO - 2016-11-07 14:55:00 --> Loader Class Initialized
INFO - 2016-11-07 14:55:00 --> Helper loaded: url_helper
INFO - 2016-11-07 14:55:00 --> Helper loaded: form_helper
INFO - 2016-11-07 14:55:00 --> Database Driver Class Initialized
INFO - 2016-11-07 14:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 14:55:00 --> Controller Class Initialized
INFO - 2016-11-07 14:55:00 --> Model Class Initialized
INFO - 2016-11-07 14:55:00 --> Model Class Initialized
DEBUG - 2016-11-07 14:55:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-07 14:55:00 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-07 14:55:00 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-07 14:55:00 --> Config Class Initialized
INFO - 2016-11-07 14:55:00 --> Hooks Class Initialized
DEBUG - 2016-11-07 14:55:00 --> UTF-8 Support Enabled
INFO - 2016-11-07 14:55:00 --> Utf8 Class Initialized
INFO - 2016-11-07 14:55:00 --> URI Class Initialized
DEBUG - 2016-11-07 14:55:00 --> No URI present. Default controller set.
INFO - 2016-11-07 14:55:00 --> Router Class Initialized
INFO - 2016-11-07 14:55:00 --> Output Class Initialized
INFO - 2016-11-07 14:55:00 --> Security Class Initialized
DEBUG - 2016-11-07 14:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 14:55:00 --> Input Class Initialized
INFO - 2016-11-07 14:55:00 --> Language Class Initialized
INFO - 2016-11-07 14:55:00 --> Loader Class Initialized
INFO - 2016-11-07 14:55:00 --> Helper loaded: url_helper
INFO - 2016-11-07 14:55:00 --> Helper loaded: form_helper
INFO - 2016-11-07 14:55:00 --> Database Driver Class Initialized
INFO - 2016-11-07 14:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 14:55:00 --> Controller Class Initialized
INFO - 2016-11-07 14:55:00 --> Model Class Initialized
INFO - 2016-11-07 14:55:00 --> Model Class Initialized
INFO - 2016-11-07 14:55:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 14:55:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 14:55:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 14:55:00 --> Final output sent to browser
DEBUG - 2016-11-07 14:55:00 --> Total execution time: 0.2805
INFO - 2016-11-07 15:03:08 --> Config Class Initialized
INFO - 2016-11-07 15:03:08 --> Hooks Class Initialized
DEBUG - 2016-11-07 15:03:08 --> UTF-8 Support Enabled
INFO - 2016-11-07 15:03:08 --> Utf8 Class Initialized
INFO - 2016-11-07 15:03:08 --> URI Class Initialized
INFO - 2016-11-07 15:03:08 --> Router Class Initialized
INFO - 2016-11-07 15:03:08 --> Output Class Initialized
INFO - 2016-11-07 15:03:08 --> Security Class Initialized
DEBUG - 2016-11-07 15:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 15:03:08 --> Input Class Initialized
INFO - 2016-11-07 15:03:08 --> Language Class Initialized
INFO - 2016-11-07 15:03:08 --> Loader Class Initialized
INFO - 2016-11-07 15:03:08 --> Helper loaded: url_helper
INFO - 2016-11-07 15:03:08 --> Helper loaded: form_helper
INFO - 2016-11-07 15:03:08 --> Database Driver Class Initialized
INFO - 2016-11-07 15:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 15:03:08 --> Controller Class Initialized
INFO - 2016-11-07 15:03:08 --> Model Class Initialized
INFO - 2016-11-07 15:03:08 --> Model Class Initialized
DEBUG - 2016-11-07 15:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-07 15:03:08 --> Model Class Initialized
INFO - 2016-11-07 15:03:08 --> Final output sent to browser
DEBUG - 2016-11-07 15:03:08 --> Total execution time: 0.1937
INFO - 2016-11-07 15:03:08 --> Config Class Initialized
INFO - 2016-11-07 15:03:08 --> Hooks Class Initialized
DEBUG - 2016-11-07 15:03:08 --> UTF-8 Support Enabled
INFO - 2016-11-07 15:03:08 --> Utf8 Class Initialized
INFO - 2016-11-07 15:03:08 --> URI Class Initialized
DEBUG - 2016-11-07 15:03:08 --> No URI present. Default controller set.
INFO - 2016-11-07 15:03:08 --> Router Class Initialized
INFO - 2016-11-07 15:03:08 --> Output Class Initialized
INFO - 2016-11-07 15:03:08 --> Security Class Initialized
DEBUG - 2016-11-07 15:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 15:03:08 --> Input Class Initialized
INFO - 2016-11-07 15:03:08 --> Language Class Initialized
INFO - 2016-11-07 15:03:08 --> Loader Class Initialized
INFO - 2016-11-07 15:03:08 --> Helper loaded: url_helper
INFO - 2016-11-07 15:03:08 --> Helper loaded: form_helper
INFO - 2016-11-07 15:03:08 --> Database Driver Class Initialized
INFO - 2016-11-07 15:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 15:03:08 --> Controller Class Initialized
INFO - 2016-11-07 15:03:08 --> Model Class Initialized
INFO - 2016-11-07 15:03:08 --> Model Class Initialized
INFO - 2016-11-07 15:03:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 15:03:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-07 15:03:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-07 15:03:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-07 15:03:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-07 15:03:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-07 15:03:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-07 15:03:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-07 15:03:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-07 15:03:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-07 15:03:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 15:03:09 --> Final output sent to browser
DEBUG - 2016-11-07 15:03:09 --> Total execution time: 0.5448
INFO - 2016-11-07 15:03:49 --> Config Class Initialized
INFO - 2016-11-07 15:03:49 --> Hooks Class Initialized
DEBUG - 2016-11-07 15:03:49 --> UTF-8 Support Enabled
INFO - 2016-11-07 15:03:49 --> Utf8 Class Initialized
INFO - 2016-11-07 15:03:49 --> URI Class Initialized
INFO - 2016-11-07 15:03:49 --> Router Class Initialized
INFO - 2016-11-07 15:03:49 --> Output Class Initialized
INFO - 2016-11-07 15:03:49 --> Security Class Initialized
DEBUG - 2016-11-07 15:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 15:03:49 --> Input Class Initialized
INFO - 2016-11-07 15:03:49 --> Language Class Initialized
INFO - 2016-11-07 15:03:49 --> Loader Class Initialized
INFO - 2016-11-07 15:03:49 --> Helper loaded: url_helper
INFO - 2016-11-07 15:03:49 --> Helper loaded: form_helper
INFO - 2016-11-07 15:03:49 --> Database Driver Class Initialized
INFO - 2016-11-07 15:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 15:03:49 --> Controller Class Initialized
INFO - 2016-11-07 15:03:49 --> Model Class Initialized
INFO - 2016-11-07 15:03:49 --> Model Class Initialized
DEBUG - 2016-11-07 15:03:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-07 15:03:49 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-07 15:03:49 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-07 15:03:49 --> Config Class Initialized
INFO - 2016-11-07 15:03:49 --> Hooks Class Initialized
DEBUG - 2016-11-07 15:03:49 --> UTF-8 Support Enabled
INFO - 2016-11-07 15:03:49 --> Utf8 Class Initialized
INFO - 2016-11-07 15:03:49 --> URI Class Initialized
DEBUG - 2016-11-07 15:03:49 --> No URI present. Default controller set.
INFO - 2016-11-07 15:03:49 --> Router Class Initialized
INFO - 2016-11-07 15:03:49 --> Output Class Initialized
INFO - 2016-11-07 15:03:49 --> Security Class Initialized
DEBUG - 2016-11-07 15:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 15:03:49 --> Input Class Initialized
INFO - 2016-11-07 15:03:49 --> Language Class Initialized
INFO - 2016-11-07 15:03:49 --> Loader Class Initialized
INFO - 2016-11-07 15:03:49 --> Helper loaded: url_helper
INFO - 2016-11-07 15:03:49 --> Helper loaded: form_helper
INFO - 2016-11-07 15:03:49 --> Database Driver Class Initialized
INFO - 2016-11-07 15:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 15:03:49 --> Controller Class Initialized
INFO - 2016-11-07 15:03:49 --> Model Class Initialized
INFO - 2016-11-07 15:03:49 --> Model Class Initialized
INFO - 2016-11-07 15:03:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 15:03:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 15:03:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 15:03:49 --> Final output sent to browser
DEBUG - 2016-11-07 15:03:49 --> Total execution time: 0.2505
INFO - 2016-11-07 15:03:58 --> Config Class Initialized
INFO - 2016-11-07 15:03:58 --> Hooks Class Initialized
DEBUG - 2016-11-07 15:03:58 --> UTF-8 Support Enabled
INFO - 2016-11-07 15:03:58 --> Utf8 Class Initialized
INFO - 2016-11-07 15:03:58 --> URI Class Initialized
INFO - 2016-11-07 15:03:58 --> Router Class Initialized
INFO - 2016-11-07 15:03:58 --> Output Class Initialized
INFO - 2016-11-07 15:03:58 --> Security Class Initialized
DEBUG - 2016-11-07 15:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 15:03:58 --> Input Class Initialized
INFO - 2016-11-07 15:03:58 --> Language Class Initialized
INFO - 2016-11-07 15:03:58 --> Loader Class Initialized
INFO - 2016-11-07 15:03:58 --> Helper loaded: url_helper
INFO - 2016-11-07 15:03:58 --> Helper loaded: form_helper
INFO - 2016-11-07 15:03:58 --> Database Driver Class Initialized
INFO - 2016-11-07 15:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 15:03:58 --> Controller Class Initialized
INFO - 2016-11-07 15:03:58 --> Model Class Initialized
INFO - 2016-11-07 15:03:58 --> Model Class Initialized
DEBUG - 2016-11-07 15:03:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-07 15:03:58 --> Model Class Initialized
INFO - 2016-11-07 15:03:58 --> Final output sent to browser
DEBUG - 2016-11-07 15:03:58 --> Total execution time: 0.2572
INFO - 2016-11-07 15:04:04 --> Config Class Initialized
INFO - 2016-11-07 15:04:04 --> Hooks Class Initialized
DEBUG - 2016-11-07 15:04:04 --> UTF-8 Support Enabled
INFO - 2016-11-07 15:04:04 --> Utf8 Class Initialized
INFO - 2016-11-07 15:04:04 --> URI Class Initialized
INFO - 2016-11-07 15:04:04 --> Router Class Initialized
INFO - 2016-11-07 15:04:04 --> Output Class Initialized
INFO - 2016-11-07 15:04:04 --> Security Class Initialized
DEBUG - 2016-11-07 15:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 15:04:04 --> Input Class Initialized
INFO - 2016-11-07 15:04:04 --> Language Class Initialized
INFO - 2016-11-07 15:04:04 --> Loader Class Initialized
INFO - 2016-11-07 15:04:04 --> Helper loaded: url_helper
INFO - 2016-11-07 15:04:04 --> Helper loaded: form_helper
INFO - 2016-11-07 15:04:04 --> Database Driver Class Initialized
INFO - 2016-11-07 15:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 15:04:05 --> Controller Class Initialized
INFO - 2016-11-07 15:04:05 --> Model Class Initialized
INFO - 2016-11-07 15:04:05 --> Model Class Initialized
DEBUG - 2016-11-07 15:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-07 15:04:05 --> Model Class Initialized
INFO - 2016-11-07 15:04:05 --> Final output sent to browser
DEBUG - 2016-11-07 15:04:05 --> Total execution time: 0.2517
INFO - 2016-11-07 15:04:05 --> Config Class Initialized
INFO - 2016-11-07 15:04:05 --> Hooks Class Initialized
DEBUG - 2016-11-07 15:04:05 --> UTF-8 Support Enabled
INFO - 2016-11-07 15:04:05 --> Utf8 Class Initialized
INFO - 2016-11-07 15:04:05 --> URI Class Initialized
DEBUG - 2016-11-07 15:04:05 --> No URI present. Default controller set.
INFO - 2016-11-07 15:04:05 --> Router Class Initialized
INFO - 2016-11-07 15:04:05 --> Output Class Initialized
INFO - 2016-11-07 15:04:05 --> Security Class Initialized
DEBUG - 2016-11-07 15:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 15:04:05 --> Input Class Initialized
INFO - 2016-11-07 15:04:05 --> Language Class Initialized
INFO - 2016-11-07 15:04:05 --> Loader Class Initialized
INFO - 2016-11-07 15:04:05 --> Helper loaded: url_helper
INFO - 2016-11-07 15:04:05 --> Helper loaded: form_helper
INFO - 2016-11-07 15:04:05 --> Database Driver Class Initialized
INFO - 2016-11-07 15:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 15:04:05 --> Controller Class Initialized
INFO - 2016-11-07 15:04:05 --> Model Class Initialized
INFO - 2016-11-07 15:04:05 --> Model Class Initialized
INFO - 2016-11-07 15:04:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 15:04:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-07 15:04:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-07 15:04:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-07 15:04:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-07 15:04:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-07 15:04:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-07 15:04:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-07 15:04:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 15:04:05 --> Final output sent to browser
DEBUG - 2016-11-07 15:04:05 --> Total execution time: 0.3277
INFO - 2016-11-07 15:04:48 --> Config Class Initialized
INFO - 2016-11-07 15:04:48 --> Hooks Class Initialized
DEBUG - 2016-11-07 15:04:48 --> UTF-8 Support Enabled
INFO - 2016-11-07 15:04:49 --> Utf8 Class Initialized
INFO - 2016-11-07 15:04:49 --> URI Class Initialized
INFO - 2016-11-07 15:04:49 --> Router Class Initialized
INFO - 2016-11-07 15:04:49 --> Output Class Initialized
INFO - 2016-11-07 15:04:49 --> Security Class Initialized
DEBUG - 2016-11-07 15:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 15:04:49 --> Input Class Initialized
INFO - 2016-11-07 15:04:49 --> Language Class Initialized
INFO - 2016-11-07 15:04:49 --> Loader Class Initialized
INFO - 2016-11-07 15:04:49 --> Helper loaded: url_helper
INFO - 2016-11-07 15:04:49 --> Helper loaded: form_helper
INFO - 2016-11-07 15:04:49 --> Database Driver Class Initialized
INFO - 2016-11-07 15:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 15:04:49 --> Controller Class Initialized
INFO - 2016-11-07 15:04:49 --> Model Class Initialized
INFO - 2016-11-07 15:04:49 --> Model Class Initialized
DEBUG - 2016-11-07 15:04:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-07 15:04:49 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-07 15:04:49 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-07 15:04:49 --> Config Class Initialized
INFO - 2016-11-07 15:04:49 --> Hooks Class Initialized
DEBUG - 2016-11-07 15:04:49 --> UTF-8 Support Enabled
INFO - 2016-11-07 15:04:49 --> Utf8 Class Initialized
INFO - 2016-11-07 15:04:49 --> URI Class Initialized
DEBUG - 2016-11-07 15:04:49 --> No URI present. Default controller set.
INFO - 2016-11-07 15:04:49 --> Router Class Initialized
INFO - 2016-11-07 15:04:49 --> Output Class Initialized
INFO - 2016-11-07 15:04:49 --> Security Class Initialized
DEBUG - 2016-11-07 15:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 15:04:49 --> Input Class Initialized
INFO - 2016-11-07 15:04:49 --> Language Class Initialized
INFO - 2016-11-07 15:04:49 --> Loader Class Initialized
INFO - 2016-11-07 15:04:49 --> Helper loaded: url_helper
INFO - 2016-11-07 15:04:49 --> Helper loaded: form_helper
INFO - 2016-11-07 15:04:49 --> Database Driver Class Initialized
INFO - 2016-11-07 15:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 15:04:49 --> Controller Class Initialized
INFO - 2016-11-07 15:04:49 --> Model Class Initialized
INFO - 2016-11-07 15:04:49 --> Model Class Initialized
INFO - 2016-11-07 15:04:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 15:04:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 15:04:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 15:04:49 --> Final output sent to browser
DEBUG - 2016-11-07 15:04:49 --> Total execution time: 0.2738
INFO - 2016-11-07 15:05:29 --> Config Class Initialized
INFO - 2016-11-07 15:05:29 --> Hooks Class Initialized
DEBUG - 2016-11-07 15:05:29 --> UTF-8 Support Enabled
INFO - 2016-11-07 15:05:29 --> Utf8 Class Initialized
INFO - 2016-11-07 15:05:29 --> URI Class Initialized
INFO - 2016-11-07 15:05:29 --> Router Class Initialized
INFO - 2016-11-07 15:05:29 --> Output Class Initialized
INFO - 2016-11-07 15:05:29 --> Security Class Initialized
DEBUG - 2016-11-07 15:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 15:05:30 --> Input Class Initialized
INFO - 2016-11-07 15:05:30 --> Language Class Initialized
INFO - 2016-11-07 15:05:30 --> Loader Class Initialized
INFO - 2016-11-07 15:05:30 --> Helper loaded: url_helper
INFO - 2016-11-07 15:05:30 --> Helper loaded: form_helper
INFO - 2016-11-07 15:05:30 --> Database Driver Class Initialized
INFO - 2016-11-07 15:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 15:05:30 --> Controller Class Initialized
INFO - 2016-11-07 15:05:30 --> Model Class Initialized
INFO - 2016-11-07 15:05:30 --> Model Class Initialized
DEBUG - 2016-11-07 15:05:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-07 15:05:30 --> Model Class Initialized
INFO - 2016-11-07 15:05:30 --> Final output sent to browser
DEBUG - 2016-11-07 15:05:30 --> Total execution time: 0.2583
INFO - 2016-11-07 15:05:37 --> Config Class Initialized
INFO - 2016-11-07 15:05:37 --> Hooks Class Initialized
DEBUG - 2016-11-07 15:05:37 --> UTF-8 Support Enabled
INFO - 2016-11-07 15:05:37 --> Utf8 Class Initialized
INFO - 2016-11-07 15:05:37 --> URI Class Initialized
INFO - 2016-11-07 15:05:37 --> Router Class Initialized
INFO - 2016-11-07 15:05:37 --> Output Class Initialized
INFO - 2016-11-07 15:05:37 --> Security Class Initialized
DEBUG - 2016-11-07 15:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 15:05:37 --> Input Class Initialized
INFO - 2016-11-07 15:05:37 --> Language Class Initialized
INFO - 2016-11-07 15:05:37 --> Loader Class Initialized
INFO - 2016-11-07 15:05:37 --> Helper loaded: url_helper
INFO - 2016-11-07 15:05:37 --> Helper loaded: form_helper
INFO - 2016-11-07 15:05:37 --> Database Driver Class Initialized
INFO - 2016-11-07 15:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 15:05:37 --> Controller Class Initialized
INFO - 2016-11-07 15:05:37 --> Model Class Initialized
INFO - 2016-11-07 15:05:37 --> Model Class Initialized
DEBUG - 2016-11-07 15:05:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-07 15:05:37 --> Model Class Initialized
INFO - 2016-11-07 15:05:37 --> Final output sent to browser
DEBUG - 2016-11-07 15:05:37 --> Total execution time: 0.2496
INFO - 2016-11-07 15:05:37 --> Config Class Initialized
INFO - 2016-11-07 15:05:37 --> Hooks Class Initialized
DEBUG - 2016-11-07 15:05:37 --> UTF-8 Support Enabled
INFO - 2016-11-07 15:05:37 --> Utf8 Class Initialized
INFO - 2016-11-07 15:05:37 --> URI Class Initialized
DEBUG - 2016-11-07 15:05:37 --> No URI present. Default controller set.
INFO - 2016-11-07 15:05:37 --> Router Class Initialized
INFO - 2016-11-07 15:05:37 --> Output Class Initialized
INFO - 2016-11-07 15:05:37 --> Security Class Initialized
DEBUG - 2016-11-07 15:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 15:05:37 --> Input Class Initialized
INFO - 2016-11-07 15:05:37 --> Language Class Initialized
INFO - 2016-11-07 15:05:37 --> Loader Class Initialized
INFO - 2016-11-07 15:05:37 --> Helper loaded: url_helper
INFO - 2016-11-07 15:05:37 --> Helper loaded: form_helper
INFO - 2016-11-07 15:05:37 --> Database Driver Class Initialized
INFO - 2016-11-07 15:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 15:05:37 --> Controller Class Initialized
INFO - 2016-11-07 15:05:37 --> Model Class Initialized
INFO - 2016-11-07 15:05:37 --> Model Class Initialized
INFO - 2016-11-07 15:05:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 15:05:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-07 15:05:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-07 15:05:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-07 15:05:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-07 15:05:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-07 15:05:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 15:05:37 --> Final output sent to browser
DEBUG - 2016-11-07 15:05:37 --> Total execution time: 0.2973
INFO - 2016-11-07 15:06:31 --> Config Class Initialized
INFO - 2016-11-07 15:06:31 --> Hooks Class Initialized
DEBUG - 2016-11-07 15:06:31 --> UTF-8 Support Enabled
INFO - 2016-11-07 15:06:31 --> Utf8 Class Initialized
INFO - 2016-11-07 15:06:31 --> URI Class Initialized
INFO - 2016-11-07 15:06:31 --> Router Class Initialized
INFO - 2016-11-07 15:06:31 --> Output Class Initialized
INFO - 2016-11-07 15:06:31 --> Security Class Initialized
DEBUG - 2016-11-07 15:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 15:06:31 --> Input Class Initialized
INFO - 2016-11-07 15:06:31 --> Language Class Initialized
INFO - 2016-11-07 15:06:31 --> Loader Class Initialized
INFO - 2016-11-07 15:06:31 --> Helper loaded: url_helper
INFO - 2016-11-07 15:06:31 --> Helper loaded: form_helper
INFO - 2016-11-07 15:06:31 --> Database Driver Class Initialized
INFO - 2016-11-07 15:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 15:06:31 --> Controller Class Initialized
INFO - 2016-11-07 15:06:31 --> Model Class Initialized
INFO - 2016-11-07 15:06:31 --> Model Class Initialized
DEBUG - 2016-11-07 15:06:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-07 15:06:31 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-07 15:06:31 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-07 15:06:31 --> Config Class Initialized
INFO - 2016-11-07 15:06:31 --> Hooks Class Initialized
DEBUG - 2016-11-07 15:06:31 --> UTF-8 Support Enabled
INFO - 2016-11-07 15:06:31 --> Utf8 Class Initialized
INFO - 2016-11-07 15:06:31 --> URI Class Initialized
DEBUG - 2016-11-07 15:06:31 --> No URI present. Default controller set.
INFO - 2016-11-07 15:06:31 --> Router Class Initialized
INFO - 2016-11-07 15:06:31 --> Output Class Initialized
INFO - 2016-11-07 15:06:31 --> Security Class Initialized
DEBUG - 2016-11-07 15:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 15:06:31 --> Input Class Initialized
INFO - 2016-11-07 15:06:31 --> Language Class Initialized
INFO - 2016-11-07 15:06:31 --> Loader Class Initialized
INFO - 2016-11-07 15:06:31 --> Helper loaded: url_helper
INFO - 2016-11-07 15:06:31 --> Helper loaded: form_helper
INFO - 2016-11-07 15:06:32 --> Database Driver Class Initialized
INFO - 2016-11-07 15:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 15:06:32 --> Controller Class Initialized
INFO - 2016-11-07 15:06:32 --> Model Class Initialized
INFO - 2016-11-07 15:06:32 --> Model Class Initialized
INFO - 2016-11-07 15:06:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 15:06:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 15:06:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 15:06:32 --> Final output sent to browser
DEBUG - 2016-11-07 15:06:32 --> Total execution time: 0.2515
INFO - 2016-11-07 18:27:03 --> Config Class Initialized
INFO - 2016-11-07 18:27:03 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:27:03 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:27:03 --> Utf8 Class Initialized
INFO - 2016-11-07 18:27:03 --> URI Class Initialized
INFO - 2016-11-07 18:27:04 --> Router Class Initialized
INFO - 2016-11-07 18:27:04 --> Output Class Initialized
INFO - 2016-11-07 18:27:04 --> Security Class Initialized
DEBUG - 2016-11-07 18:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:27:04 --> Input Class Initialized
INFO - 2016-11-07 18:27:04 --> Language Class Initialized
INFO - 2016-11-07 18:27:04 --> Loader Class Initialized
INFO - 2016-11-07 18:27:05 --> Helper loaded: url_helper
INFO - 2016-11-07 18:27:05 --> Helper loaded: form_helper
INFO - 2016-11-07 18:27:05 --> Database Driver Class Initialized
INFO - 2016-11-07 18:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:27:05 --> Controller Class Initialized
INFO - 2016-11-07 18:27:06 --> Model Class Initialized
INFO - 2016-11-07 18:27:06 --> Model Class Initialized
DEBUG - 2016-11-07 18:27:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-07 18:27:06 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-07 18:27:06 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-07 18:27:06 --> Config Class Initialized
INFO - 2016-11-07 18:27:06 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:27:06 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:27:06 --> Utf8 Class Initialized
INFO - 2016-11-07 18:27:06 --> URI Class Initialized
DEBUG - 2016-11-07 18:27:06 --> No URI present. Default controller set.
INFO - 2016-11-07 18:27:06 --> Router Class Initialized
INFO - 2016-11-07 18:27:06 --> Output Class Initialized
INFO - 2016-11-07 18:27:06 --> Security Class Initialized
DEBUG - 2016-11-07 18:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:27:06 --> Input Class Initialized
INFO - 2016-11-07 18:27:06 --> Language Class Initialized
INFO - 2016-11-07 18:27:06 --> Loader Class Initialized
INFO - 2016-11-07 18:27:06 --> Helper loaded: url_helper
INFO - 2016-11-07 18:27:06 --> Helper loaded: form_helper
INFO - 2016-11-07 18:27:06 --> Database Driver Class Initialized
INFO - 2016-11-07 18:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:27:06 --> Controller Class Initialized
INFO - 2016-11-07 18:27:06 --> Model Class Initialized
INFO - 2016-11-07 18:27:06 --> Model Class Initialized
INFO - 2016-11-07 18:27:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:27:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:27:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:27:06 --> Final output sent to browser
DEBUG - 2016-11-07 18:27:06 --> Total execution time: 0.5282
INFO - 2016-11-07 18:28:37 --> Config Class Initialized
INFO - 2016-11-07 18:28:37 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:28:37 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:28:38 --> Utf8 Class Initialized
INFO - 2016-11-07 18:28:38 --> URI Class Initialized
DEBUG - 2016-11-07 18:28:38 --> No URI present. Default controller set.
INFO - 2016-11-07 18:28:38 --> Router Class Initialized
INFO - 2016-11-07 18:28:38 --> Output Class Initialized
INFO - 2016-11-07 18:28:38 --> Security Class Initialized
DEBUG - 2016-11-07 18:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:28:38 --> Input Class Initialized
INFO - 2016-11-07 18:28:38 --> Language Class Initialized
INFO - 2016-11-07 18:28:38 --> Loader Class Initialized
INFO - 2016-11-07 18:28:38 --> Helper loaded: url_helper
INFO - 2016-11-07 18:28:38 --> Helper loaded: form_helper
INFO - 2016-11-07 18:28:38 --> Database Driver Class Initialized
INFO - 2016-11-07 18:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:28:38 --> Controller Class Initialized
INFO - 2016-11-07 18:28:38 --> Model Class Initialized
INFO - 2016-11-07 18:28:38 --> Model Class Initialized
INFO - 2016-11-07 18:28:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:28:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:28:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:28:38 --> Final output sent to browser
DEBUG - 2016-11-07 18:28:38 --> Total execution time: 0.2337
INFO - 2016-11-07 18:28:59 --> Config Class Initialized
INFO - 2016-11-07 18:28:59 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:28:59 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:28:59 --> Utf8 Class Initialized
INFO - 2016-11-07 18:28:59 --> URI Class Initialized
DEBUG - 2016-11-07 18:28:59 --> No URI present. Default controller set.
INFO - 2016-11-07 18:28:59 --> Router Class Initialized
INFO - 2016-11-07 18:28:59 --> Output Class Initialized
INFO - 2016-11-07 18:28:59 --> Security Class Initialized
DEBUG - 2016-11-07 18:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:28:59 --> Input Class Initialized
INFO - 2016-11-07 18:28:59 --> Language Class Initialized
INFO - 2016-11-07 18:28:59 --> Loader Class Initialized
INFO - 2016-11-07 18:28:59 --> Helper loaded: url_helper
INFO - 2016-11-07 18:28:59 --> Helper loaded: form_helper
INFO - 2016-11-07 18:28:59 --> Database Driver Class Initialized
INFO - 2016-11-07 18:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:28:59 --> Controller Class Initialized
INFO - 2016-11-07 18:28:59 --> Model Class Initialized
INFO - 2016-11-07 18:28:59 --> Model Class Initialized
INFO - 2016-11-07 18:28:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:28:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:28:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:28:59 --> Final output sent to browser
DEBUG - 2016-11-07 18:29:00 --> Total execution time: 0.2297
INFO - 2016-11-07 18:29:16 --> Config Class Initialized
INFO - 2016-11-07 18:29:16 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:29:16 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:29:16 --> Utf8 Class Initialized
INFO - 2016-11-07 18:29:16 --> URI Class Initialized
DEBUG - 2016-11-07 18:29:17 --> No URI present. Default controller set.
INFO - 2016-11-07 18:29:17 --> Router Class Initialized
INFO - 2016-11-07 18:29:17 --> Output Class Initialized
INFO - 2016-11-07 18:29:17 --> Security Class Initialized
DEBUG - 2016-11-07 18:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:29:17 --> Input Class Initialized
INFO - 2016-11-07 18:29:17 --> Language Class Initialized
INFO - 2016-11-07 18:29:17 --> Loader Class Initialized
INFO - 2016-11-07 18:29:17 --> Helper loaded: url_helper
INFO - 2016-11-07 18:29:17 --> Helper loaded: form_helper
INFO - 2016-11-07 18:29:17 --> Database Driver Class Initialized
INFO - 2016-11-07 18:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:29:17 --> Controller Class Initialized
INFO - 2016-11-07 18:29:17 --> Model Class Initialized
INFO - 2016-11-07 18:29:17 --> Model Class Initialized
INFO - 2016-11-07 18:29:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:29:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:29:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:29:17 --> Final output sent to browser
DEBUG - 2016-11-07 18:29:17 --> Total execution time: 0.2290
INFO - 2016-11-07 18:29:30 --> Config Class Initialized
INFO - 2016-11-07 18:29:30 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:29:30 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:29:30 --> Utf8 Class Initialized
INFO - 2016-11-07 18:29:30 --> URI Class Initialized
DEBUG - 2016-11-07 18:29:30 --> No URI present. Default controller set.
INFO - 2016-11-07 18:29:30 --> Router Class Initialized
INFO - 2016-11-07 18:29:30 --> Output Class Initialized
INFO - 2016-11-07 18:29:30 --> Security Class Initialized
DEBUG - 2016-11-07 18:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:29:30 --> Input Class Initialized
INFO - 2016-11-07 18:29:30 --> Language Class Initialized
INFO - 2016-11-07 18:29:30 --> Loader Class Initialized
INFO - 2016-11-07 18:29:30 --> Helper loaded: url_helper
INFO - 2016-11-07 18:29:30 --> Helper loaded: form_helper
INFO - 2016-11-07 18:29:30 --> Database Driver Class Initialized
INFO - 2016-11-07 18:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:29:30 --> Controller Class Initialized
INFO - 2016-11-07 18:29:30 --> Model Class Initialized
INFO - 2016-11-07 18:29:30 --> Model Class Initialized
INFO - 2016-11-07 18:29:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:29:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:29:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:29:30 --> Final output sent to browser
DEBUG - 2016-11-07 18:29:30 --> Total execution time: 0.2322
INFO - 2016-11-07 18:29:34 --> Config Class Initialized
INFO - 2016-11-07 18:29:34 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:29:34 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:29:34 --> Utf8 Class Initialized
INFO - 2016-11-07 18:29:34 --> URI Class Initialized
DEBUG - 2016-11-07 18:29:34 --> No URI present. Default controller set.
INFO - 2016-11-07 18:29:34 --> Router Class Initialized
INFO - 2016-11-07 18:29:34 --> Output Class Initialized
INFO - 2016-11-07 18:29:34 --> Security Class Initialized
DEBUG - 2016-11-07 18:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:29:34 --> Input Class Initialized
INFO - 2016-11-07 18:29:34 --> Language Class Initialized
INFO - 2016-11-07 18:29:34 --> Loader Class Initialized
INFO - 2016-11-07 18:29:34 --> Helper loaded: url_helper
INFO - 2016-11-07 18:29:34 --> Helper loaded: form_helper
INFO - 2016-11-07 18:29:34 --> Database Driver Class Initialized
INFO - 2016-11-07 18:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:29:34 --> Controller Class Initialized
INFO - 2016-11-07 18:29:34 --> Model Class Initialized
INFO - 2016-11-07 18:29:34 --> Model Class Initialized
INFO - 2016-11-07 18:29:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:29:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:29:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:29:34 --> Final output sent to browser
DEBUG - 2016-11-07 18:29:34 --> Total execution time: 0.2781
INFO - 2016-11-07 18:29:35 --> Config Class Initialized
INFO - 2016-11-07 18:29:35 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:29:35 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:29:35 --> Utf8 Class Initialized
INFO - 2016-11-07 18:29:35 --> URI Class Initialized
DEBUG - 2016-11-07 18:29:35 --> No URI present. Default controller set.
INFO - 2016-11-07 18:29:35 --> Router Class Initialized
INFO - 2016-11-07 18:29:35 --> Output Class Initialized
INFO - 2016-11-07 18:29:35 --> Security Class Initialized
DEBUG - 2016-11-07 18:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:29:35 --> Input Class Initialized
INFO - 2016-11-07 18:29:35 --> Language Class Initialized
INFO - 2016-11-07 18:29:35 --> Loader Class Initialized
INFO - 2016-11-07 18:29:35 --> Helper loaded: url_helper
INFO - 2016-11-07 18:29:35 --> Helper loaded: form_helper
INFO - 2016-11-07 18:29:35 --> Database Driver Class Initialized
INFO - 2016-11-07 18:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:29:35 --> Controller Class Initialized
INFO - 2016-11-07 18:29:35 --> Model Class Initialized
INFO - 2016-11-07 18:29:35 --> Model Class Initialized
INFO - 2016-11-07 18:29:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:29:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:29:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:29:35 --> Final output sent to browser
DEBUG - 2016-11-07 18:29:35 --> Total execution time: 0.2581
INFO - 2016-11-07 18:29:35 --> Config Class Initialized
INFO - 2016-11-07 18:29:35 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:29:35 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:29:35 --> Utf8 Class Initialized
INFO - 2016-11-07 18:29:35 --> URI Class Initialized
DEBUG - 2016-11-07 18:29:35 --> No URI present. Default controller set.
INFO - 2016-11-07 18:29:35 --> Router Class Initialized
INFO - 2016-11-07 18:29:35 --> Output Class Initialized
INFO - 2016-11-07 18:29:35 --> Security Class Initialized
DEBUG - 2016-11-07 18:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:29:35 --> Input Class Initialized
INFO - 2016-11-07 18:29:35 --> Language Class Initialized
INFO - 2016-11-07 18:29:35 --> Loader Class Initialized
INFO - 2016-11-07 18:29:35 --> Helper loaded: url_helper
INFO - 2016-11-07 18:29:35 --> Helper loaded: form_helper
INFO - 2016-11-07 18:29:35 --> Database Driver Class Initialized
INFO - 2016-11-07 18:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:29:35 --> Controller Class Initialized
INFO - 2016-11-07 18:29:35 --> Model Class Initialized
INFO - 2016-11-07 18:29:35 --> Model Class Initialized
INFO - 2016-11-07 18:29:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:29:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:29:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:29:35 --> Final output sent to browser
DEBUG - 2016-11-07 18:29:35 --> Total execution time: 0.2672
INFO - 2016-11-07 18:29:40 --> Config Class Initialized
INFO - 2016-11-07 18:29:40 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:29:40 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:29:40 --> Utf8 Class Initialized
INFO - 2016-11-07 18:29:40 --> URI Class Initialized
DEBUG - 2016-11-07 18:29:40 --> No URI present. Default controller set.
INFO - 2016-11-07 18:29:40 --> Router Class Initialized
INFO - 2016-11-07 18:29:40 --> Output Class Initialized
INFO - 2016-11-07 18:29:40 --> Security Class Initialized
DEBUG - 2016-11-07 18:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:29:40 --> Input Class Initialized
INFO - 2016-11-07 18:29:40 --> Language Class Initialized
INFO - 2016-11-07 18:29:40 --> Loader Class Initialized
INFO - 2016-11-07 18:29:40 --> Helper loaded: url_helper
INFO - 2016-11-07 18:29:40 --> Helper loaded: form_helper
INFO - 2016-11-07 18:29:40 --> Database Driver Class Initialized
INFO - 2016-11-07 18:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:29:40 --> Controller Class Initialized
INFO - 2016-11-07 18:29:40 --> Model Class Initialized
INFO - 2016-11-07 18:29:40 --> Model Class Initialized
INFO - 2016-11-07 18:29:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:29:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:29:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:29:40 --> Final output sent to browser
DEBUG - 2016-11-07 18:29:40 --> Total execution time: 0.2389
INFO - 2016-11-07 18:29:45 --> Config Class Initialized
INFO - 2016-11-07 18:29:45 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:29:45 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:29:45 --> Utf8 Class Initialized
INFO - 2016-11-07 18:29:45 --> URI Class Initialized
DEBUG - 2016-11-07 18:29:45 --> No URI present. Default controller set.
INFO - 2016-11-07 18:29:45 --> Router Class Initialized
INFO - 2016-11-07 18:29:45 --> Output Class Initialized
INFO - 2016-11-07 18:29:45 --> Security Class Initialized
DEBUG - 2016-11-07 18:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:29:45 --> Input Class Initialized
INFO - 2016-11-07 18:29:45 --> Language Class Initialized
INFO - 2016-11-07 18:29:45 --> Loader Class Initialized
INFO - 2016-11-07 18:29:45 --> Helper loaded: url_helper
INFO - 2016-11-07 18:29:45 --> Helper loaded: form_helper
INFO - 2016-11-07 18:29:45 --> Database Driver Class Initialized
INFO - 2016-11-07 18:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:29:45 --> Controller Class Initialized
INFO - 2016-11-07 18:29:45 --> Model Class Initialized
INFO - 2016-11-07 18:29:45 --> Model Class Initialized
INFO - 2016-11-07 18:29:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:29:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:29:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:29:45 --> Final output sent to browser
DEBUG - 2016-11-07 18:29:45 --> Total execution time: 0.2394
INFO - 2016-11-07 18:30:12 --> Config Class Initialized
INFO - 2016-11-07 18:30:12 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:30:12 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:30:12 --> Utf8 Class Initialized
INFO - 2016-11-07 18:30:12 --> URI Class Initialized
DEBUG - 2016-11-07 18:30:12 --> No URI present. Default controller set.
INFO - 2016-11-07 18:30:12 --> Router Class Initialized
INFO - 2016-11-07 18:30:12 --> Output Class Initialized
INFO - 2016-11-07 18:30:12 --> Security Class Initialized
DEBUG - 2016-11-07 18:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:30:12 --> Input Class Initialized
INFO - 2016-11-07 18:30:12 --> Language Class Initialized
INFO - 2016-11-07 18:30:12 --> Loader Class Initialized
INFO - 2016-11-07 18:30:12 --> Helper loaded: url_helper
INFO - 2016-11-07 18:30:12 --> Helper loaded: form_helper
INFO - 2016-11-07 18:30:12 --> Database Driver Class Initialized
INFO - 2016-11-07 18:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:30:12 --> Controller Class Initialized
INFO - 2016-11-07 18:30:12 --> Model Class Initialized
INFO - 2016-11-07 18:30:12 --> Model Class Initialized
INFO - 2016-11-07 18:30:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:30:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:30:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:30:12 --> Final output sent to browser
DEBUG - 2016-11-07 18:30:12 --> Total execution time: 0.2325
INFO - 2016-11-07 18:30:28 --> Config Class Initialized
INFO - 2016-11-07 18:30:28 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:30:28 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:30:28 --> Utf8 Class Initialized
INFO - 2016-11-07 18:30:28 --> URI Class Initialized
DEBUG - 2016-11-07 18:30:28 --> No URI present. Default controller set.
INFO - 2016-11-07 18:30:28 --> Router Class Initialized
INFO - 2016-11-07 18:30:28 --> Output Class Initialized
INFO - 2016-11-07 18:30:28 --> Security Class Initialized
DEBUG - 2016-11-07 18:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:30:28 --> Input Class Initialized
INFO - 2016-11-07 18:30:28 --> Language Class Initialized
INFO - 2016-11-07 18:30:28 --> Loader Class Initialized
INFO - 2016-11-07 18:30:28 --> Helper loaded: url_helper
INFO - 2016-11-07 18:30:28 --> Helper loaded: form_helper
INFO - 2016-11-07 18:30:28 --> Database Driver Class Initialized
INFO - 2016-11-07 18:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:30:28 --> Controller Class Initialized
INFO - 2016-11-07 18:30:28 --> Model Class Initialized
INFO - 2016-11-07 18:30:28 --> Model Class Initialized
INFO - 2016-11-07 18:30:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:30:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:30:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:30:28 --> Final output sent to browser
DEBUG - 2016-11-07 18:30:28 --> Total execution time: 0.2360
INFO - 2016-11-07 18:30:41 --> Config Class Initialized
INFO - 2016-11-07 18:30:41 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:30:41 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:30:41 --> Utf8 Class Initialized
INFO - 2016-11-07 18:30:41 --> URI Class Initialized
DEBUG - 2016-11-07 18:30:41 --> No URI present. Default controller set.
INFO - 2016-11-07 18:30:41 --> Router Class Initialized
INFO - 2016-11-07 18:30:41 --> Output Class Initialized
INFO - 2016-11-07 18:30:41 --> Security Class Initialized
DEBUG - 2016-11-07 18:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:30:41 --> Input Class Initialized
INFO - 2016-11-07 18:30:41 --> Language Class Initialized
INFO - 2016-11-07 18:30:41 --> Loader Class Initialized
INFO - 2016-11-07 18:30:41 --> Helper loaded: url_helper
INFO - 2016-11-07 18:30:41 --> Helper loaded: form_helper
INFO - 2016-11-07 18:30:41 --> Database Driver Class Initialized
INFO - 2016-11-07 18:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:30:41 --> Controller Class Initialized
INFO - 2016-11-07 18:30:41 --> Model Class Initialized
INFO - 2016-11-07 18:30:41 --> Model Class Initialized
INFO - 2016-11-07 18:30:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:30:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:30:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:30:41 --> Final output sent to browser
DEBUG - 2016-11-07 18:30:41 --> Total execution time: 0.2391
INFO - 2016-11-07 18:30:47 --> Config Class Initialized
INFO - 2016-11-07 18:30:47 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:30:47 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:30:47 --> Utf8 Class Initialized
INFO - 2016-11-07 18:30:47 --> URI Class Initialized
DEBUG - 2016-11-07 18:30:47 --> No URI present. Default controller set.
INFO - 2016-11-07 18:30:47 --> Router Class Initialized
INFO - 2016-11-07 18:30:47 --> Output Class Initialized
INFO - 2016-11-07 18:30:47 --> Security Class Initialized
DEBUG - 2016-11-07 18:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:30:47 --> Input Class Initialized
INFO - 2016-11-07 18:30:47 --> Language Class Initialized
INFO - 2016-11-07 18:30:47 --> Loader Class Initialized
INFO - 2016-11-07 18:30:47 --> Helper loaded: url_helper
INFO - 2016-11-07 18:30:47 --> Helper loaded: form_helper
INFO - 2016-11-07 18:30:47 --> Database Driver Class Initialized
INFO - 2016-11-07 18:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:30:47 --> Controller Class Initialized
INFO - 2016-11-07 18:30:47 --> Model Class Initialized
INFO - 2016-11-07 18:30:47 --> Model Class Initialized
INFO - 2016-11-07 18:30:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:30:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:30:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:30:47 --> Final output sent to browser
DEBUG - 2016-11-07 18:30:47 --> Total execution time: 0.2491
INFO - 2016-11-07 18:31:08 --> Config Class Initialized
INFO - 2016-11-07 18:31:08 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:31:08 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:31:08 --> Utf8 Class Initialized
INFO - 2016-11-07 18:31:08 --> URI Class Initialized
DEBUG - 2016-11-07 18:31:08 --> No URI present. Default controller set.
INFO - 2016-11-07 18:31:08 --> Router Class Initialized
INFO - 2016-11-07 18:31:08 --> Output Class Initialized
INFO - 2016-11-07 18:31:08 --> Security Class Initialized
DEBUG - 2016-11-07 18:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:31:08 --> Input Class Initialized
INFO - 2016-11-07 18:31:08 --> Language Class Initialized
INFO - 2016-11-07 18:31:08 --> Loader Class Initialized
INFO - 2016-11-07 18:31:08 --> Helper loaded: url_helper
INFO - 2016-11-07 18:31:08 --> Helper loaded: form_helper
INFO - 2016-11-07 18:31:08 --> Database Driver Class Initialized
INFO - 2016-11-07 18:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:31:08 --> Controller Class Initialized
INFO - 2016-11-07 18:31:08 --> Model Class Initialized
INFO - 2016-11-07 18:31:08 --> Model Class Initialized
INFO - 2016-11-07 18:31:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:31:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:31:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:31:08 --> Final output sent to browser
DEBUG - 2016-11-07 18:31:08 --> Total execution time: 0.2366
INFO - 2016-11-07 18:31:21 --> Config Class Initialized
INFO - 2016-11-07 18:31:21 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:31:21 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:31:21 --> Utf8 Class Initialized
INFO - 2016-11-07 18:31:21 --> URI Class Initialized
DEBUG - 2016-11-07 18:31:21 --> No URI present. Default controller set.
INFO - 2016-11-07 18:31:21 --> Router Class Initialized
INFO - 2016-11-07 18:31:21 --> Output Class Initialized
INFO - 2016-11-07 18:31:21 --> Security Class Initialized
DEBUG - 2016-11-07 18:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:31:21 --> Input Class Initialized
INFO - 2016-11-07 18:31:21 --> Language Class Initialized
INFO - 2016-11-07 18:31:21 --> Loader Class Initialized
INFO - 2016-11-07 18:31:21 --> Helper loaded: url_helper
INFO - 2016-11-07 18:31:21 --> Helper loaded: form_helper
INFO - 2016-11-07 18:31:21 --> Database Driver Class Initialized
INFO - 2016-11-07 18:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:31:21 --> Controller Class Initialized
INFO - 2016-11-07 18:31:21 --> Model Class Initialized
INFO - 2016-11-07 18:31:21 --> Model Class Initialized
INFO - 2016-11-07 18:31:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:31:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:31:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:31:21 --> Final output sent to browser
DEBUG - 2016-11-07 18:31:21 --> Total execution time: 0.2578
INFO - 2016-11-07 18:31:32 --> Config Class Initialized
INFO - 2016-11-07 18:31:32 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:31:32 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:31:32 --> Utf8 Class Initialized
INFO - 2016-11-07 18:31:32 --> URI Class Initialized
DEBUG - 2016-11-07 18:31:32 --> No URI present. Default controller set.
INFO - 2016-11-07 18:31:32 --> Router Class Initialized
INFO - 2016-11-07 18:31:32 --> Output Class Initialized
INFO - 2016-11-07 18:31:32 --> Security Class Initialized
DEBUG - 2016-11-07 18:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:31:32 --> Input Class Initialized
INFO - 2016-11-07 18:31:32 --> Language Class Initialized
INFO - 2016-11-07 18:31:32 --> Loader Class Initialized
INFO - 2016-11-07 18:31:32 --> Helper loaded: url_helper
INFO - 2016-11-07 18:31:32 --> Helper loaded: form_helper
INFO - 2016-11-07 18:31:32 --> Database Driver Class Initialized
INFO - 2016-11-07 18:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:31:32 --> Controller Class Initialized
INFO - 2016-11-07 18:31:32 --> Model Class Initialized
INFO - 2016-11-07 18:31:32 --> Model Class Initialized
INFO - 2016-11-07 18:31:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:31:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:31:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:31:32 --> Final output sent to browser
DEBUG - 2016-11-07 18:31:32 --> Total execution time: 0.2450
INFO - 2016-11-07 18:31:57 --> Config Class Initialized
INFO - 2016-11-07 18:31:57 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:31:57 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:31:57 --> Utf8 Class Initialized
INFO - 2016-11-07 18:31:57 --> URI Class Initialized
DEBUG - 2016-11-07 18:31:58 --> No URI present. Default controller set.
INFO - 2016-11-07 18:31:58 --> Router Class Initialized
INFO - 2016-11-07 18:31:58 --> Output Class Initialized
INFO - 2016-11-07 18:31:58 --> Security Class Initialized
DEBUG - 2016-11-07 18:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:31:58 --> Input Class Initialized
INFO - 2016-11-07 18:31:58 --> Language Class Initialized
INFO - 2016-11-07 18:31:58 --> Loader Class Initialized
INFO - 2016-11-07 18:31:58 --> Helper loaded: url_helper
INFO - 2016-11-07 18:31:58 --> Helper loaded: form_helper
INFO - 2016-11-07 18:31:58 --> Database Driver Class Initialized
INFO - 2016-11-07 18:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:31:58 --> Controller Class Initialized
INFO - 2016-11-07 18:31:58 --> Model Class Initialized
INFO - 2016-11-07 18:31:58 --> Model Class Initialized
INFO - 2016-11-07 18:31:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:31:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:31:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:31:58 --> Final output sent to browser
DEBUG - 2016-11-07 18:31:58 --> Total execution time: 0.2375
INFO - 2016-11-07 18:32:27 --> Config Class Initialized
INFO - 2016-11-07 18:32:27 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:32:27 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:32:27 --> Utf8 Class Initialized
INFO - 2016-11-07 18:32:27 --> URI Class Initialized
DEBUG - 2016-11-07 18:32:27 --> No URI present. Default controller set.
INFO - 2016-11-07 18:32:27 --> Router Class Initialized
INFO - 2016-11-07 18:32:27 --> Output Class Initialized
INFO - 2016-11-07 18:32:27 --> Security Class Initialized
DEBUG - 2016-11-07 18:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:32:27 --> Input Class Initialized
INFO - 2016-11-07 18:32:27 --> Language Class Initialized
INFO - 2016-11-07 18:32:27 --> Loader Class Initialized
INFO - 2016-11-07 18:32:27 --> Helper loaded: url_helper
INFO - 2016-11-07 18:32:27 --> Helper loaded: form_helper
INFO - 2016-11-07 18:32:27 --> Database Driver Class Initialized
INFO - 2016-11-07 18:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:32:27 --> Controller Class Initialized
INFO - 2016-11-07 18:32:27 --> Model Class Initialized
INFO - 2016-11-07 18:32:27 --> Model Class Initialized
INFO - 2016-11-07 18:32:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:32:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:32:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:32:27 --> Final output sent to browser
DEBUG - 2016-11-07 18:32:27 --> Total execution time: 0.2443
INFO - 2016-11-07 18:37:33 --> Config Class Initialized
INFO - 2016-11-07 18:37:33 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:37:33 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:37:33 --> Utf8 Class Initialized
INFO - 2016-11-07 18:37:33 --> URI Class Initialized
DEBUG - 2016-11-07 18:37:33 --> No URI present. Default controller set.
INFO - 2016-11-07 18:37:33 --> Router Class Initialized
INFO - 2016-11-07 18:37:33 --> Output Class Initialized
INFO - 2016-11-07 18:37:33 --> Security Class Initialized
DEBUG - 2016-11-07 18:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:37:33 --> Input Class Initialized
INFO - 2016-11-07 18:37:33 --> Language Class Initialized
INFO - 2016-11-07 18:37:33 --> Loader Class Initialized
INFO - 2016-11-07 18:37:33 --> Helper loaded: url_helper
INFO - 2016-11-07 18:37:33 --> Helper loaded: form_helper
INFO - 2016-11-07 18:37:33 --> Database Driver Class Initialized
INFO - 2016-11-07 18:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:37:33 --> Controller Class Initialized
INFO - 2016-11-07 18:37:33 --> Model Class Initialized
INFO - 2016-11-07 18:37:33 --> Model Class Initialized
INFO - 2016-11-07 18:37:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:37:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:37:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:37:33 --> Final output sent to browser
DEBUG - 2016-11-07 18:37:33 --> Total execution time: 0.2754
INFO - 2016-11-07 18:37:38 --> Config Class Initialized
INFO - 2016-11-07 18:37:38 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:37:38 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:37:38 --> Utf8 Class Initialized
INFO - 2016-11-07 18:37:38 --> URI Class Initialized
DEBUG - 2016-11-07 18:37:38 --> No URI present. Default controller set.
INFO - 2016-11-07 18:37:38 --> Router Class Initialized
INFO - 2016-11-07 18:37:38 --> Output Class Initialized
INFO - 2016-11-07 18:37:38 --> Security Class Initialized
DEBUG - 2016-11-07 18:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:37:38 --> Input Class Initialized
INFO - 2016-11-07 18:37:38 --> Language Class Initialized
INFO - 2016-11-07 18:37:38 --> Loader Class Initialized
INFO - 2016-11-07 18:37:38 --> Helper loaded: url_helper
INFO - 2016-11-07 18:37:38 --> Helper loaded: form_helper
INFO - 2016-11-07 18:37:39 --> Database Driver Class Initialized
INFO - 2016-11-07 18:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:37:39 --> Controller Class Initialized
INFO - 2016-11-07 18:37:39 --> Model Class Initialized
INFO - 2016-11-07 18:37:39 --> Model Class Initialized
INFO - 2016-11-07 18:37:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:37:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:37:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:37:39 --> Final output sent to browser
DEBUG - 2016-11-07 18:37:39 --> Total execution time: 0.2506
INFO - 2016-11-07 18:39:38 --> Config Class Initialized
INFO - 2016-11-07 18:39:38 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:39:38 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:39:38 --> Utf8 Class Initialized
INFO - 2016-11-07 18:39:38 --> URI Class Initialized
DEBUG - 2016-11-07 18:39:38 --> No URI present. Default controller set.
INFO - 2016-11-07 18:39:38 --> Router Class Initialized
INFO - 2016-11-07 18:39:38 --> Output Class Initialized
INFO - 2016-11-07 18:39:38 --> Security Class Initialized
DEBUG - 2016-11-07 18:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:39:38 --> Input Class Initialized
INFO - 2016-11-07 18:39:38 --> Language Class Initialized
INFO - 2016-11-07 18:39:38 --> Loader Class Initialized
INFO - 2016-11-07 18:39:38 --> Helper loaded: url_helper
INFO - 2016-11-07 18:39:39 --> Helper loaded: form_helper
INFO - 2016-11-07 18:39:39 --> Database Driver Class Initialized
INFO - 2016-11-07 18:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:39:39 --> Controller Class Initialized
INFO - 2016-11-07 18:39:39 --> Model Class Initialized
INFO - 2016-11-07 18:39:39 --> Model Class Initialized
INFO - 2016-11-07 18:39:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:39:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:39:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:39:39 --> Final output sent to browser
DEBUG - 2016-11-07 18:39:39 --> Total execution time: 0.2562
INFO - 2016-11-07 18:39:49 --> Config Class Initialized
INFO - 2016-11-07 18:39:49 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:39:49 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:39:49 --> Utf8 Class Initialized
INFO - 2016-11-07 18:39:49 --> URI Class Initialized
DEBUG - 2016-11-07 18:39:49 --> No URI present. Default controller set.
INFO - 2016-11-07 18:39:49 --> Router Class Initialized
INFO - 2016-11-07 18:39:49 --> Output Class Initialized
INFO - 2016-11-07 18:39:49 --> Security Class Initialized
DEBUG - 2016-11-07 18:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:39:49 --> Input Class Initialized
INFO - 2016-11-07 18:39:49 --> Language Class Initialized
INFO - 2016-11-07 18:39:49 --> Loader Class Initialized
INFO - 2016-11-07 18:39:49 --> Helper loaded: url_helper
INFO - 2016-11-07 18:39:49 --> Helper loaded: form_helper
INFO - 2016-11-07 18:39:49 --> Database Driver Class Initialized
INFO - 2016-11-07 18:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:39:49 --> Controller Class Initialized
INFO - 2016-11-07 18:39:49 --> Model Class Initialized
INFO - 2016-11-07 18:39:49 --> Model Class Initialized
INFO - 2016-11-07 18:39:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:39:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:39:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:39:49 --> Final output sent to browser
DEBUG - 2016-11-07 18:39:49 --> Total execution time: 0.2538
INFO - 2016-11-07 18:39:55 --> Config Class Initialized
INFO - 2016-11-07 18:39:55 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:39:55 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:39:55 --> Utf8 Class Initialized
INFO - 2016-11-07 18:39:55 --> URI Class Initialized
DEBUG - 2016-11-07 18:39:55 --> No URI present. Default controller set.
INFO - 2016-11-07 18:39:55 --> Router Class Initialized
INFO - 2016-11-07 18:39:55 --> Output Class Initialized
INFO - 2016-11-07 18:39:55 --> Security Class Initialized
DEBUG - 2016-11-07 18:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:39:55 --> Input Class Initialized
INFO - 2016-11-07 18:39:55 --> Language Class Initialized
INFO - 2016-11-07 18:39:55 --> Loader Class Initialized
INFO - 2016-11-07 18:39:55 --> Helper loaded: url_helper
INFO - 2016-11-07 18:39:55 --> Helper loaded: form_helper
INFO - 2016-11-07 18:39:55 --> Database Driver Class Initialized
INFO - 2016-11-07 18:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:39:55 --> Controller Class Initialized
INFO - 2016-11-07 18:39:55 --> Model Class Initialized
INFO - 2016-11-07 18:39:55 --> Model Class Initialized
INFO - 2016-11-07 18:39:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:39:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:39:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:39:55 --> Final output sent to browser
DEBUG - 2016-11-07 18:39:55 --> Total execution time: 0.2500
INFO - 2016-11-07 18:40:12 --> Config Class Initialized
INFO - 2016-11-07 18:40:12 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:40:12 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:40:12 --> Utf8 Class Initialized
INFO - 2016-11-07 18:40:12 --> URI Class Initialized
DEBUG - 2016-11-07 18:40:12 --> No URI present. Default controller set.
INFO - 2016-11-07 18:40:12 --> Router Class Initialized
INFO - 2016-11-07 18:40:12 --> Output Class Initialized
INFO - 2016-11-07 18:40:13 --> Security Class Initialized
DEBUG - 2016-11-07 18:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:40:13 --> Input Class Initialized
INFO - 2016-11-07 18:40:13 --> Language Class Initialized
INFO - 2016-11-07 18:40:13 --> Loader Class Initialized
INFO - 2016-11-07 18:40:13 --> Helper loaded: url_helper
INFO - 2016-11-07 18:40:13 --> Helper loaded: form_helper
INFO - 2016-11-07 18:40:13 --> Database Driver Class Initialized
INFO - 2016-11-07 18:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:40:13 --> Controller Class Initialized
INFO - 2016-11-07 18:40:13 --> Model Class Initialized
INFO - 2016-11-07 18:40:13 --> Model Class Initialized
INFO - 2016-11-07 18:40:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:40:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:40:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:40:13 --> Final output sent to browser
DEBUG - 2016-11-07 18:40:13 --> Total execution time: 0.2536
INFO - 2016-11-07 18:40:59 --> Config Class Initialized
INFO - 2016-11-07 18:40:59 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:40:59 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:40:59 --> Utf8 Class Initialized
INFO - 2016-11-07 18:40:59 --> URI Class Initialized
DEBUG - 2016-11-07 18:40:59 --> No URI present. Default controller set.
INFO - 2016-11-07 18:40:59 --> Router Class Initialized
INFO - 2016-11-07 18:40:59 --> Output Class Initialized
INFO - 2016-11-07 18:40:59 --> Security Class Initialized
DEBUG - 2016-11-07 18:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:40:59 --> Input Class Initialized
INFO - 2016-11-07 18:40:59 --> Language Class Initialized
INFO - 2016-11-07 18:40:59 --> Loader Class Initialized
INFO - 2016-11-07 18:40:59 --> Helper loaded: url_helper
INFO - 2016-11-07 18:40:59 --> Helper loaded: form_helper
INFO - 2016-11-07 18:40:59 --> Database Driver Class Initialized
INFO - 2016-11-07 18:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:40:59 --> Controller Class Initialized
INFO - 2016-11-07 18:40:59 --> Model Class Initialized
INFO - 2016-11-07 18:40:59 --> Model Class Initialized
INFO - 2016-11-07 18:40:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:40:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:40:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:40:59 --> Final output sent to browser
DEBUG - 2016-11-07 18:40:59 --> Total execution time: 0.2658
INFO - 2016-11-07 18:42:19 --> Config Class Initialized
INFO - 2016-11-07 18:42:19 --> Hooks Class Initialized
DEBUG - 2016-11-07 18:42:19 --> UTF-8 Support Enabled
INFO - 2016-11-07 18:42:19 --> Utf8 Class Initialized
INFO - 2016-11-07 18:42:19 --> URI Class Initialized
DEBUG - 2016-11-07 18:42:19 --> No URI present. Default controller set.
INFO - 2016-11-07 18:42:19 --> Router Class Initialized
INFO - 2016-11-07 18:42:19 --> Output Class Initialized
INFO - 2016-11-07 18:42:19 --> Security Class Initialized
DEBUG - 2016-11-07 18:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 18:42:19 --> Input Class Initialized
INFO - 2016-11-07 18:42:19 --> Language Class Initialized
INFO - 2016-11-07 18:42:19 --> Loader Class Initialized
INFO - 2016-11-07 18:42:19 --> Helper loaded: url_helper
INFO - 2016-11-07 18:42:19 --> Helper loaded: form_helper
INFO - 2016-11-07 18:42:19 --> Database Driver Class Initialized
INFO - 2016-11-07 18:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 18:42:19 --> Controller Class Initialized
INFO - 2016-11-07 18:42:19 --> Model Class Initialized
INFO - 2016-11-07 18:42:19 --> Model Class Initialized
INFO - 2016-11-07 18:42:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 18:42:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 18:42:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 18:42:19 --> Final output sent to browser
DEBUG - 2016-11-07 18:42:19 --> Total execution time: 0.2497
INFO - 2016-11-07 22:16:21 --> Config Class Initialized
INFO - 2016-11-07 22:16:21 --> Hooks Class Initialized
DEBUG - 2016-11-07 22:16:21 --> UTF-8 Support Enabled
INFO - 2016-11-07 22:16:21 --> Utf8 Class Initialized
INFO - 2016-11-07 22:16:21 --> URI Class Initialized
DEBUG - 2016-11-07 22:16:21 --> No URI present. Default controller set.
INFO - 2016-11-07 22:16:21 --> Router Class Initialized
INFO - 2016-11-07 22:16:21 --> Output Class Initialized
INFO - 2016-11-07 22:16:21 --> Security Class Initialized
DEBUG - 2016-11-07 22:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 22:16:21 --> Input Class Initialized
INFO - 2016-11-07 22:16:21 --> Language Class Initialized
INFO - 2016-11-07 22:16:22 --> Loader Class Initialized
INFO - 2016-11-07 22:16:22 --> Helper loaded: url_helper
INFO - 2016-11-07 22:16:22 --> Helper loaded: form_helper
INFO - 2016-11-07 22:16:22 --> Database Driver Class Initialized
INFO - 2016-11-07 22:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 22:16:22 --> Controller Class Initialized
INFO - 2016-11-07 22:16:22 --> Model Class Initialized
INFO - 2016-11-07 22:16:22 --> Model Class Initialized
INFO - 2016-11-07 22:16:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 22:16:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 22:16:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 22:16:22 --> Final output sent to browser
DEBUG - 2016-11-07 22:16:22 --> Total execution time: 1.3889
INFO - 2016-11-07 22:16:37 --> Config Class Initialized
INFO - 2016-11-07 22:16:37 --> Hooks Class Initialized
DEBUG - 2016-11-07 22:16:37 --> UTF-8 Support Enabled
INFO - 2016-11-07 22:16:37 --> Utf8 Class Initialized
INFO - 2016-11-07 22:16:37 --> URI Class Initialized
INFO - 2016-11-07 22:16:37 --> Router Class Initialized
INFO - 2016-11-07 22:16:37 --> Output Class Initialized
INFO - 2016-11-07 22:16:37 --> Security Class Initialized
DEBUG - 2016-11-07 22:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 22:16:37 --> Input Class Initialized
INFO - 2016-11-07 22:16:37 --> Language Class Initialized
INFO - 2016-11-07 22:16:37 --> Loader Class Initialized
INFO - 2016-11-07 22:16:37 --> Helper loaded: url_helper
INFO - 2016-11-07 22:16:37 --> Helper loaded: form_helper
INFO - 2016-11-07 22:16:37 --> Database Driver Class Initialized
INFO - 2016-11-07 22:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 22:16:37 --> Controller Class Initialized
INFO - 2016-11-07 22:16:37 --> Model Class Initialized
INFO - 2016-11-07 22:16:37 --> Model Class Initialized
DEBUG - 2016-11-07 22:16:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-07 22:16:37 --> Model Class Initialized
INFO - 2016-11-07 22:16:37 --> Final output sent to browser
DEBUG - 2016-11-07 22:16:37 --> Total execution time: 0.3505
INFO - 2016-11-07 22:16:37 --> Config Class Initialized
INFO - 2016-11-07 22:16:37 --> Hooks Class Initialized
DEBUG - 2016-11-07 22:16:37 --> UTF-8 Support Enabled
INFO - 2016-11-07 22:16:37 --> Utf8 Class Initialized
INFO - 2016-11-07 22:16:37 --> URI Class Initialized
DEBUG - 2016-11-07 22:16:37 --> No URI present. Default controller set.
INFO - 2016-11-07 22:16:37 --> Router Class Initialized
INFO - 2016-11-07 22:16:37 --> Output Class Initialized
INFO - 2016-11-07 22:16:37 --> Security Class Initialized
DEBUG - 2016-11-07 22:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 22:16:37 --> Input Class Initialized
INFO - 2016-11-07 22:16:37 --> Language Class Initialized
INFO - 2016-11-07 22:16:37 --> Loader Class Initialized
INFO - 2016-11-07 22:16:37 --> Helper loaded: url_helper
INFO - 2016-11-07 22:16:37 --> Helper loaded: form_helper
INFO - 2016-11-07 22:16:38 --> Database Driver Class Initialized
INFO - 2016-11-07 22:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 22:16:38 --> Controller Class Initialized
INFO - 2016-11-07 22:16:38 --> Model Class Initialized
INFO - 2016-11-07 22:16:38 --> Model Class Initialized
INFO - 2016-11-07 22:16:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 22:16:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-07 22:16:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-07 22:16:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-07 22:16:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-07 22:16:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-07 22:16:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-07 22:16:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-07 22:16:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 22:16:38 --> Final output sent to browser
DEBUG - 2016-11-07 22:16:38 --> Total execution time: 0.4406
INFO - 2016-11-07 22:17:12 --> Config Class Initialized
INFO - 2016-11-07 22:17:12 --> Hooks Class Initialized
DEBUG - 2016-11-07 22:17:13 --> UTF-8 Support Enabled
INFO - 2016-11-07 22:17:13 --> Utf8 Class Initialized
INFO - 2016-11-07 22:17:13 --> URI Class Initialized
INFO - 2016-11-07 22:17:13 --> Router Class Initialized
INFO - 2016-11-07 22:17:13 --> Output Class Initialized
INFO - 2016-11-07 22:17:13 --> Security Class Initialized
DEBUG - 2016-11-07 22:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 22:17:13 --> Input Class Initialized
INFO - 2016-11-07 22:17:13 --> Language Class Initialized
INFO - 2016-11-07 22:17:13 --> Loader Class Initialized
INFO - 2016-11-07 22:17:13 --> Helper loaded: url_helper
INFO - 2016-11-07 22:17:13 --> Helper loaded: form_helper
INFO - 2016-11-07 22:17:13 --> Database Driver Class Initialized
INFO - 2016-11-07 22:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 22:17:13 --> Controller Class Initialized
INFO - 2016-11-07 22:17:13 --> Model Class Initialized
INFO - 2016-11-07 22:17:13 --> Model Class Initialized
DEBUG - 2016-11-07 22:17:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-07 22:17:13 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-07 22:17:13 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-07 22:17:13 --> Config Class Initialized
INFO - 2016-11-07 22:17:13 --> Hooks Class Initialized
DEBUG - 2016-11-07 22:17:13 --> UTF-8 Support Enabled
INFO - 2016-11-07 22:17:13 --> Utf8 Class Initialized
INFO - 2016-11-07 22:17:13 --> URI Class Initialized
DEBUG - 2016-11-07 22:17:13 --> No URI present. Default controller set.
INFO - 2016-11-07 22:17:13 --> Router Class Initialized
INFO - 2016-11-07 22:17:13 --> Output Class Initialized
INFO - 2016-11-07 22:17:13 --> Security Class Initialized
DEBUG - 2016-11-07 22:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 22:17:13 --> Input Class Initialized
INFO - 2016-11-07 22:17:13 --> Language Class Initialized
INFO - 2016-11-07 22:17:13 --> Loader Class Initialized
INFO - 2016-11-07 22:17:13 --> Helper loaded: url_helper
INFO - 2016-11-07 22:17:13 --> Helper loaded: form_helper
INFO - 2016-11-07 22:17:13 --> Database Driver Class Initialized
INFO - 2016-11-07 22:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 22:17:13 --> Controller Class Initialized
INFO - 2016-11-07 22:17:13 --> Model Class Initialized
INFO - 2016-11-07 22:17:13 --> Model Class Initialized
INFO - 2016-11-07 22:17:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 22:17:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 22:17:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 22:17:13 --> Final output sent to browser
DEBUG - 2016-11-07 22:17:13 --> Total execution time: 0.2919
INFO - 2016-11-07 22:17:20 --> Config Class Initialized
INFO - 2016-11-07 22:17:20 --> Hooks Class Initialized
DEBUG - 2016-11-07 22:17:20 --> UTF-8 Support Enabled
INFO - 2016-11-07 22:17:20 --> Utf8 Class Initialized
INFO - 2016-11-07 22:17:20 --> URI Class Initialized
INFO - 2016-11-07 22:17:20 --> Router Class Initialized
INFO - 2016-11-07 22:17:20 --> Output Class Initialized
INFO - 2016-11-07 22:17:20 --> Security Class Initialized
DEBUG - 2016-11-07 22:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 22:17:20 --> Input Class Initialized
INFO - 2016-11-07 22:17:20 --> Language Class Initialized
INFO - 2016-11-07 22:17:20 --> Loader Class Initialized
INFO - 2016-11-07 22:17:20 --> Helper loaded: url_helper
INFO - 2016-11-07 22:17:20 --> Helper loaded: form_helper
INFO - 2016-11-07 22:17:20 --> Database Driver Class Initialized
INFO - 2016-11-07 22:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 22:17:20 --> Controller Class Initialized
INFO - 2016-11-07 22:17:20 --> Model Class Initialized
INFO - 2016-11-07 22:17:20 --> Model Class Initialized
DEBUG - 2016-11-07 22:17:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-07 22:17:20 --> Model Class Initialized
INFO - 2016-11-07 22:17:20 --> Final output sent to browser
DEBUG - 2016-11-07 22:17:20 --> Total execution time: 0.2398
INFO - 2016-11-07 22:17:20 --> Config Class Initialized
INFO - 2016-11-07 22:17:20 --> Hooks Class Initialized
DEBUG - 2016-11-07 22:17:20 --> UTF-8 Support Enabled
INFO - 2016-11-07 22:17:20 --> Utf8 Class Initialized
INFO - 2016-11-07 22:17:20 --> URI Class Initialized
DEBUG - 2016-11-07 22:17:20 --> No URI present. Default controller set.
INFO - 2016-11-07 22:17:20 --> Router Class Initialized
INFO - 2016-11-07 22:17:20 --> Output Class Initialized
INFO - 2016-11-07 22:17:20 --> Security Class Initialized
DEBUG - 2016-11-07 22:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 22:17:20 --> Input Class Initialized
INFO - 2016-11-07 22:17:20 --> Language Class Initialized
INFO - 2016-11-07 22:17:20 --> Loader Class Initialized
INFO - 2016-11-07 22:17:20 --> Helper loaded: url_helper
INFO - 2016-11-07 22:17:20 --> Helper loaded: form_helper
INFO - 2016-11-07 22:17:20 --> Database Driver Class Initialized
INFO - 2016-11-07 22:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 22:17:20 --> Controller Class Initialized
INFO - 2016-11-07 22:17:20 --> Model Class Initialized
INFO - 2016-11-07 22:17:20 --> Model Class Initialized
INFO - 2016-11-07 22:17:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 22:17:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-07 22:17:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-07 22:17:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-07 22:17:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-07 22:17:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-07 22:17:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-07 22:17:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-07 22:17:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-07 22:17:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-07 22:17:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 22:17:20 --> Final output sent to browser
DEBUG - 2016-11-07 22:17:20 --> Total execution time: 0.3832
INFO - 2016-11-07 22:17:40 --> Config Class Initialized
INFO - 2016-11-07 22:17:40 --> Hooks Class Initialized
DEBUG - 2016-11-07 22:17:40 --> UTF-8 Support Enabled
INFO - 2016-11-07 22:17:40 --> Utf8 Class Initialized
INFO - 2016-11-07 22:17:40 --> URI Class Initialized
INFO - 2016-11-07 22:17:40 --> Router Class Initialized
INFO - 2016-11-07 22:17:40 --> Output Class Initialized
INFO - 2016-11-07 22:17:40 --> Security Class Initialized
DEBUG - 2016-11-07 22:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 22:17:40 --> Input Class Initialized
INFO - 2016-11-07 22:17:40 --> Language Class Initialized
INFO - 2016-11-07 22:17:40 --> Loader Class Initialized
INFO - 2016-11-07 22:17:40 --> Helper loaded: url_helper
INFO - 2016-11-07 22:17:40 --> Helper loaded: form_helper
INFO - 2016-11-07 22:17:40 --> Database Driver Class Initialized
INFO - 2016-11-07 22:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 22:17:40 --> Controller Class Initialized
INFO - 2016-11-07 22:17:40 --> Model Class Initialized
INFO - 2016-11-07 22:17:40 --> Form Validation Class Initialized
INFO - 2016-11-07 22:17:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-07 22:17:40 --> Final output sent to browser
DEBUG - 2016-11-07 22:17:40 --> Total execution time: 0.3205
INFO - 2016-11-07 22:18:14 --> Config Class Initialized
INFO - 2016-11-07 22:18:14 --> Hooks Class Initialized
DEBUG - 2016-11-07 22:18:14 --> UTF-8 Support Enabled
INFO - 2016-11-07 22:18:14 --> Utf8 Class Initialized
INFO - 2016-11-07 22:18:14 --> URI Class Initialized
DEBUG - 2016-11-07 22:18:14 --> No URI present. Default controller set.
INFO - 2016-11-07 22:18:14 --> Router Class Initialized
INFO - 2016-11-07 22:18:14 --> Output Class Initialized
INFO - 2016-11-07 22:18:14 --> Security Class Initialized
DEBUG - 2016-11-07 22:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 22:18:14 --> Input Class Initialized
INFO - 2016-11-07 22:18:14 --> Language Class Initialized
INFO - 2016-11-07 22:18:14 --> Loader Class Initialized
INFO - 2016-11-07 22:18:14 --> Helper loaded: url_helper
INFO - 2016-11-07 22:18:14 --> Helper loaded: form_helper
INFO - 2016-11-07 22:18:14 --> Database Driver Class Initialized
INFO - 2016-11-07 22:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 22:18:14 --> Controller Class Initialized
INFO - 2016-11-07 22:18:14 --> Model Class Initialized
INFO - 2016-11-07 22:18:14 --> Model Class Initialized
INFO - 2016-11-07 22:18:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 22:18:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-07 22:18:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-07 22:18:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-07 22:18:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-07 22:18:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-07 22:18:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-07 22:18:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-07 22:18:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-07 22:18:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-07 22:18:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 22:18:14 --> Final output sent to browser
DEBUG - 2016-11-07 22:18:14 --> Total execution time: 0.3814
INFO - 2016-11-07 22:18:21 --> Config Class Initialized
INFO - 2016-11-07 22:18:21 --> Hooks Class Initialized
DEBUG - 2016-11-07 22:18:21 --> UTF-8 Support Enabled
INFO - 2016-11-07 22:18:21 --> Utf8 Class Initialized
INFO - 2016-11-07 22:18:21 --> URI Class Initialized
INFO - 2016-11-07 22:18:21 --> Router Class Initialized
INFO - 2016-11-07 22:18:21 --> Output Class Initialized
INFO - 2016-11-07 22:18:21 --> Security Class Initialized
DEBUG - 2016-11-07 22:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 22:18:21 --> Input Class Initialized
INFO - 2016-11-07 22:18:21 --> Language Class Initialized
INFO - 2016-11-07 22:18:21 --> Loader Class Initialized
INFO - 2016-11-07 22:18:21 --> Helper loaded: url_helper
INFO - 2016-11-07 22:18:21 --> Helper loaded: form_helper
INFO - 2016-11-07 22:18:21 --> Database Driver Class Initialized
INFO - 2016-11-07 22:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 22:18:21 --> Controller Class Initialized
INFO - 2016-11-07 22:18:21 --> Form Validation Class Initialized
INFO - 2016-11-07 22:18:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-07 22:18:21 --> Final output sent to browser
DEBUG - 2016-11-07 22:18:21 --> Total execution time: 0.2553
INFO - 2016-11-07 22:24:40 --> Config Class Initialized
INFO - 2016-11-07 22:24:40 --> Hooks Class Initialized
DEBUG - 2016-11-07 22:24:40 --> UTF-8 Support Enabled
INFO - 2016-11-07 22:24:40 --> Utf8 Class Initialized
INFO - 2016-11-07 22:24:40 --> URI Class Initialized
DEBUG - 2016-11-07 22:24:40 --> No URI present. Default controller set.
INFO - 2016-11-07 22:24:40 --> Router Class Initialized
INFO - 2016-11-07 22:24:40 --> Output Class Initialized
INFO - 2016-11-07 22:24:40 --> Security Class Initialized
DEBUG - 2016-11-07 22:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 22:24:40 --> Input Class Initialized
INFO - 2016-11-07 22:24:40 --> Language Class Initialized
INFO - 2016-11-07 22:24:40 --> Loader Class Initialized
INFO - 2016-11-07 22:24:40 --> Helper loaded: url_helper
INFO - 2016-11-07 22:24:40 --> Helper loaded: form_helper
INFO - 2016-11-07 22:24:40 --> Database Driver Class Initialized
INFO - 2016-11-07 22:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 22:24:40 --> Controller Class Initialized
INFO - 2016-11-07 22:24:40 --> Model Class Initialized
INFO - 2016-11-07 22:24:40 --> Model Class Initialized
INFO - 2016-11-07 22:24:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 22:24:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-07 22:24:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-07 22:24:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-07 22:24:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-07 22:24:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-07 22:24:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-07 22:24:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-07 22:24:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-07 22:24:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-07 22:24:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 22:24:40 --> Final output sent to browser
DEBUG - 2016-11-07 22:24:40 --> Total execution time: 0.3627
INFO - 2016-11-07 22:26:23 --> Config Class Initialized
INFO - 2016-11-07 22:26:23 --> Hooks Class Initialized
DEBUG - 2016-11-07 22:26:23 --> UTF-8 Support Enabled
INFO - 2016-11-07 22:26:23 --> Utf8 Class Initialized
INFO - 2016-11-07 22:26:23 --> URI Class Initialized
INFO - 2016-11-07 22:26:23 --> Router Class Initialized
INFO - 2016-11-07 22:26:23 --> Output Class Initialized
INFO - 2016-11-07 22:26:23 --> Security Class Initialized
DEBUG - 2016-11-07 22:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 22:26:23 --> Input Class Initialized
INFO - 2016-11-07 22:26:23 --> Language Class Initialized
INFO - 2016-11-07 22:26:23 --> Loader Class Initialized
INFO - 2016-11-07 22:26:23 --> Helper loaded: url_helper
INFO - 2016-11-07 22:26:23 --> Helper loaded: form_helper
INFO - 2016-11-07 22:26:23 --> Database Driver Class Initialized
INFO - 2016-11-07 22:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 22:26:23 --> Controller Class Initialized
INFO - 2016-11-07 22:26:23 --> Model Class Initialized
INFO - 2016-11-07 22:26:23 --> Form Validation Class Initialized
INFO - 2016-11-07 22:26:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-07 22:26:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-07 22:26:23 --> Final output sent to browser
DEBUG - 2016-11-07 22:26:23 --> Total execution time: 0.3258
INFO - 2016-11-07 22:38:20 --> Config Class Initialized
INFO - 2016-11-07 22:38:20 --> Hooks Class Initialized
DEBUG - 2016-11-07 22:38:20 --> UTF-8 Support Enabled
INFO - 2016-11-07 22:38:20 --> Utf8 Class Initialized
INFO - 2016-11-07 22:38:20 --> URI Class Initialized
INFO - 2016-11-07 22:38:20 --> Router Class Initialized
INFO - 2016-11-07 22:38:20 --> Output Class Initialized
INFO - 2016-11-07 22:38:20 --> Security Class Initialized
DEBUG - 2016-11-07 22:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 22:38:20 --> Input Class Initialized
INFO - 2016-11-07 22:38:20 --> Language Class Initialized
INFO - 2016-11-07 22:38:20 --> Loader Class Initialized
INFO - 2016-11-07 22:38:20 --> Helper loaded: url_helper
INFO - 2016-11-07 22:38:20 --> Helper loaded: form_helper
INFO - 2016-11-07 22:38:20 --> Database Driver Class Initialized
INFO - 2016-11-07 22:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 22:38:20 --> Controller Class Initialized
INFO - 2016-11-07 22:38:20 --> Model Class Initialized
INFO - 2016-11-07 22:38:20 --> Form Validation Class Initialized
INFO - 2016-11-07 22:38:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-07 22:38:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-07 22:38:20 --> Final output sent to browser
DEBUG - 2016-11-07 22:38:20 --> Total execution time: 0.4184
INFO - 2016-11-07 22:39:42 --> Config Class Initialized
INFO - 2016-11-07 22:39:42 --> Hooks Class Initialized
DEBUG - 2016-11-07 22:39:42 --> UTF-8 Support Enabled
INFO - 2016-11-07 22:39:42 --> Utf8 Class Initialized
INFO - 2016-11-07 22:39:43 --> URI Class Initialized
INFO - 2016-11-07 22:39:43 --> Router Class Initialized
INFO - 2016-11-07 22:39:43 --> Output Class Initialized
INFO - 2016-11-07 22:39:43 --> Security Class Initialized
DEBUG - 2016-11-07 22:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 22:39:43 --> Input Class Initialized
INFO - 2016-11-07 22:39:43 --> Language Class Initialized
INFO - 2016-11-07 22:39:43 --> Loader Class Initialized
INFO - 2016-11-07 22:39:43 --> Helper loaded: url_helper
INFO - 2016-11-07 22:39:43 --> Helper loaded: form_helper
INFO - 2016-11-07 22:39:43 --> Database Driver Class Initialized
INFO - 2016-11-07 22:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 22:39:43 --> Controller Class Initialized
INFO - 2016-11-07 22:39:43 --> Model Class Initialized
INFO - 2016-11-07 22:39:43 --> Model Class Initialized
DEBUG - 2016-11-07 22:39:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-07 22:39:43 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-07 22:39:43 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-07 22:39:43 --> Config Class Initialized
INFO - 2016-11-07 22:39:43 --> Hooks Class Initialized
DEBUG - 2016-11-07 22:39:43 --> UTF-8 Support Enabled
INFO - 2016-11-07 22:39:43 --> Utf8 Class Initialized
INFO - 2016-11-07 22:39:43 --> URI Class Initialized
DEBUG - 2016-11-07 22:39:43 --> No URI present. Default controller set.
INFO - 2016-11-07 22:39:43 --> Router Class Initialized
INFO - 2016-11-07 22:39:43 --> Output Class Initialized
INFO - 2016-11-07 22:39:43 --> Security Class Initialized
DEBUG - 2016-11-07 22:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-07 22:39:43 --> Input Class Initialized
INFO - 2016-11-07 22:39:43 --> Language Class Initialized
INFO - 2016-11-07 22:39:43 --> Loader Class Initialized
INFO - 2016-11-07 22:39:43 --> Helper loaded: url_helper
INFO - 2016-11-07 22:39:43 --> Helper loaded: form_helper
INFO - 2016-11-07 22:39:43 --> Database Driver Class Initialized
INFO - 2016-11-07 22:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-07 22:39:43 --> Controller Class Initialized
INFO - 2016-11-07 22:39:43 --> Model Class Initialized
INFO - 2016-11-07 22:39:43 --> Model Class Initialized
INFO - 2016-11-07 22:39:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-07 22:39:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-07 22:39:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-07 22:39:43 --> Final output sent to browser
DEBUG - 2016-11-07 22:39:43 --> Total execution time: 0.2630
