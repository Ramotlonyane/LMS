<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-14 21:09:28 --> Config Class Initialized
INFO - 2016-11-14 21:09:28 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:09:28 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:09:28 --> Utf8 Class Initialized
INFO - 2016-11-14 21:09:29 --> URI Class Initialized
DEBUG - 2016-11-14 21:09:29 --> No URI present. Default controller set.
INFO - 2016-11-14 21:09:29 --> Router Class Initialized
INFO - 2016-11-14 21:09:29 --> Output Class Initialized
INFO - 2016-11-14 21:09:29 --> Security Class Initialized
DEBUG - 2016-11-14 21:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:09:29 --> Input Class Initialized
INFO - 2016-11-14 21:09:29 --> Language Class Initialized
INFO - 2016-11-14 21:09:29 --> Loader Class Initialized
INFO - 2016-11-14 21:09:30 --> Helper loaded: url_helper
INFO - 2016-11-14 21:09:30 --> Helper loaded: form_helper
INFO - 2016-11-14 21:09:30 --> Database Driver Class Initialized
INFO - 2016-11-14 21:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:09:31 --> Controller Class Initialized
INFO - 2016-11-14 21:09:31 --> Model Class Initialized
INFO - 2016-11-14 21:09:31 --> Model Class Initialized
INFO - 2016-11-14 21:09:31 --> Model Class Initialized
INFO - 2016-11-14 21:09:31 --> Model Class Initialized
INFO - 2016-11-14 21:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-14 21:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:09:32 --> Final output sent to browser
DEBUG - 2016-11-14 21:09:32 --> Total execution time: 3.6570
INFO - 2016-11-14 21:09:54 --> Config Class Initialized
INFO - 2016-11-14 21:09:54 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:09:54 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:09:54 --> Utf8 Class Initialized
INFO - 2016-11-14 21:09:54 --> URI Class Initialized
INFO - 2016-11-14 21:09:54 --> Router Class Initialized
INFO - 2016-11-14 21:09:54 --> Output Class Initialized
INFO - 2016-11-14 21:09:54 --> Security Class Initialized
DEBUG - 2016-11-14 21:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:09:54 --> Input Class Initialized
INFO - 2016-11-14 21:09:54 --> Language Class Initialized
INFO - 2016-11-14 21:09:54 --> Loader Class Initialized
INFO - 2016-11-14 21:09:54 --> Helper loaded: url_helper
INFO - 2016-11-14 21:09:54 --> Helper loaded: form_helper
INFO - 2016-11-14 21:09:54 --> Database Driver Class Initialized
INFO - 2016-11-14 21:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:09:54 --> Controller Class Initialized
INFO - 2016-11-14 21:09:54 --> Model Class Initialized
INFO - 2016-11-14 21:09:54 --> Model Class Initialized
INFO - 2016-11-14 21:09:54 --> Model Class Initialized
INFO - 2016-11-14 21:09:54 --> Model Class Initialized
DEBUG - 2016-11-14 21:09:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-14 21:09:54 --> Model Class Initialized
INFO - 2016-11-14 21:09:55 --> Final output sent to browser
DEBUG - 2016-11-14 21:09:55 --> Total execution time: 1.3959
INFO - 2016-11-14 21:09:55 --> Config Class Initialized
INFO - 2016-11-14 21:09:55 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:09:55 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:09:55 --> Utf8 Class Initialized
INFO - 2016-11-14 21:09:55 --> URI Class Initialized
DEBUG - 2016-11-14 21:09:55 --> No URI present. Default controller set.
INFO - 2016-11-14 21:09:55 --> Router Class Initialized
INFO - 2016-11-14 21:09:55 --> Output Class Initialized
INFO - 2016-11-14 21:09:55 --> Security Class Initialized
DEBUG - 2016-11-14 21:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:09:56 --> Input Class Initialized
INFO - 2016-11-14 21:09:56 --> Language Class Initialized
INFO - 2016-11-14 21:09:56 --> Loader Class Initialized
INFO - 2016-11-14 21:09:56 --> Helper loaded: url_helper
INFO - 2016-11-14 21:09:56 --> Helper loaded: form_helper
INFO - 2016-11-14 21:09:56 --> Database Driver Class Initialized
INFO - 2016-11-14 21:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:09:56 --> Controller Class Initialized
INFO - 2016-11-14 21:09:56 --> Model Class Initialized
INFO - 2016-11-14 21:09:56 --> Model Class Initialized
INFO - 2016-11-14 21:09:56 --> Model Class Initialized
INFO - 2016-11-14 21:09:56 --> Model Class Initialized
INFO - 2016-11-14 21:09:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:09:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:09:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:09:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:09:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:09:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:09:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:09:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:09:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:09:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:09:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:09:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:09:57 --> Final output sent to browser
DEBUG - 2016-11-14 21:09:57 --> Total execution time: 1.7690
INFO - 2016-11-14 21:12:42 --> Config Class Initialized
INFO - 2016-11-14 21:12:42 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:12:42 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:12:42 --> Utf8 Class Initialized
INFO - 2016-11-14 21:12:42 --> URI Class Initialized
DEBUG - 2016-11-14 21:12:42 --> No URI present. Default controller set.
INFO - 2016-11-14 21:12:42 --> Router Class Initialized
INFO - 2016-11-14 21:12:42 --> Output Class Initialized
INFO - 2016-11-14 21:12:42 --> Security Class Initialized
DEBUG - 2016-11-14 21:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:12:42 --> Input Class Initialized
INFO - 2016-11-14 21:12:42 --> Language Class Initialized
INFO - 2016-11-14 21:12:42 --> Loader Class Initialized
INFO - 2016-11-14 21:12:42 --> Helper loaded: url_helper
INFO - 2016-11-14 21:12:42 --> Helper loaded: form_helper
INFO - 2016-11-14 21:12:43 --> Database Driver Class Initialized
INFO - 2016-11-14 21:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:12:43 --> Controller Class Initialized
INFO - 2016-11-14 21:12:43 --> Model Class Initialized
INFO - 2016-11-14 21:12:43 --> Model Class Initialized
INFO - 2016-11-14 21:12:43 --> Model Class Initialized
INFO - 2016-11-14 21:12:43 --> Model Class Initialized
INFO - 2016-11-14 21:12:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:12:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:12:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:12:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:12:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:12:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:12:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:12:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:12:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:12:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:12:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:12:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:12:44 --> Final output sent to browser
DEBUG - 2016-11-14 21:12:44 --> Total execution time: 1.9929
INFO - 2016-11-14 21:13:01 --> Config Class Initialized
INFO - 2016-11-14 21:13:01 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:13:01 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:13:01 --> Utf8 Class Initialized
INFO - 2016-11-14 21:13:01 --> URI Class Initialized
INFO - 2016-11-14 21:13:01 --> Router Class Initialized
INFO - 2016-11-14 21:13:01 --> Output Class Initialized
INFO - 2016-11-14 21:13:01 --> Security Class Initialized
DEBUG - 2016-11-14 21:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:13:01 --> Input Class Initialized
INFO - 2016-11-14 21:13:01 --> Language Class Initialized
INFO - 2016-11-14 21:13:01 --> Loader Class Initialized
INFO - 2016-11-14 21:13:01 --> Helper loaded: url_helper
INFO - 2016-11-14 21:13:01 --> Helper loaded: form_helper
INFO - 2016-11-14 21:13:01 --> Database Driver Class Initialized
INFO - 2016-11-14 21:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:13:01 --> Controller Class Initialized
INFO - 2016-11-14 21:13:01 --> Model Class Initialized
INFO - 2016-11-14 21:13:01 --> Form Validation Class Initialized
INFO - 2016-11-14 21:13:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-14 21:13:02 --> Final output sent to browser
DEBUG - 2016-11-14 21:13:02 --> Total execution time: 0.2980
INFO - 2016-11-14 21:15:55 --> Config Class Initialized
INFO - 2016-11-14 21:15:55 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:15:55 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:15:55 --> Utf8 Class Initialized
INFO - 2016-11-14 21:15:55 --> URI Class Initialized
DEBUG - 2016-11-14 21:15:55 --> No URI present. Default controller set.
INFO - 2016-11-14 21:15:55 --> Router Class Initialized
INFO - 2016-11-14 21:15:55 --> Output Class Initialized
INFO - 2016-11-14 21:15:55 --> Security Class Initialized
DEBUG - 2016-11-14 21:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:15:56 --> Input Class Initialized
INFO - 2016-11-14 21:15:56 --> Language Class Initialized
INFO - 2016-11-14 21:15:56 --> Loader Class Initialized
INFO - 2016-11-14 21:15:56 --> Helper loaded: url_helper
INFO - 2016-11-14 21:15:56 --> Helper loaded: form_helper
INFO - 2016-11-14 21:15:56 --> Database Driver Class Initialized
INFO - 2016-11-14 21:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:15:56 --> Controller Class Initialized
INFO - 2016-11-14 21:15:56 --> Model Class Initialized
INFO - 2016-11-14 21:15:56 --> Model Class Initialized
INFO - 2016-11-14 21:15:56 --> Model Class Initialized
INFO - 2016-11-14 21:15:56 --> Model Class Initialized
INFO - 2016-11-14 21:15:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:15:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:15:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:15:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:15:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:15:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:15:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:15:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:15:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:15:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:15:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:15:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:15:56 --> Final output sent to browser
DEBUG - 2016-11-14 21:15:56 --> Total execution time: 0.2931
INFO - 2016-11-14 21:16:00 --> Config Class Initialized
INFO - 2016-11-14 21:16:00 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:16:00 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:16:00 --> Utf8 Class Initialized
INFO - 2016-11-14 21:16:00 --> URI Class Initialized
INFO - 2016-11-14 21:16:00 --> Router Class Initialized
INFO - 2016-11-14 21:16:00 --> Output Class Initialized
INFO - 2016-11-14 21:16:00 --> Security Class Initialized
DEBUG - 2016-11-14 21:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:16:00 --> Input Class Initialized
INFO - 2016-11-14 21:16:00 --> Language Class Initialized
INFO - 2016-11-14 21:16:00 --> Loader Class Initialized
INFO - 2016-11-14 21:16:00 --> Helper loaded: url_helper
INFO - 2016-11-14 21:16:00 --> Helper loaded: form_helper
INFO - 2016-11-14 21:16:00 --> Database Driver Class Initialized
INFO - 2016-11-14 21:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:16:00 --> Controller Class Initialized
INFO - 2016-11-14 21:16:00 --> Model Class Initialized
INFO - 2016-11-14 21:16:02 --> Config Class Initialized
INFO - 2016-11-14 21:16:02 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:16:02 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:16:03 --> Utf8 Class Initialized
INFO - 2016-11-14 21:16:03 --> URI Class Initialized
INFO - 2016-11-14 21:16:03 --> Router Class Initialized
INFO - 2016-11-14 21:16:03 --> Output Class Initialized
INFO - 2016-11-14 21:16:03 --> Security Class Initialized
DEBUG - 2016-11-14 21:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:16:03 --> Input Class Initialized
INFO - 2016-11-14 21:16:03 --> Language Class Initialized
INFO - 2016-11-14 21:16:03 --> Loader Class Initialized
INFO - 2016-11-14 21:16:03 --> Helper loaded: url_helper
INFO - 2016-11-14 21:16:03 --> Helper loaded: form_helper
INFO - 2016-11-14 21:16:03 --> Database Driver Class Initialized
INFO - 2016-11-14 21:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:16:03 --> Controller Class Initialized
INFO - 2016-11-14 21:16:03 --> Model Class Initialized
INFO - 2016-11-14 21:16:18 --> Config Class Initialized
INFO - 2016-11-14 21:16:18 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:16:18 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:16:18 --> Utf8 Class Initialized
INFO - 2016-11-14 21:16:18 --> URI Class Initialized
INFO - 2016-11-14 21:16:18 --> Router Class Initialized
INFO - 2016-11-14 21:16:18 --> Output Class Initialized
INFO - 2016-11-14 21:16:19 --> Security Class Initialized
DEBUG - 2016-11-14 21:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:16:19 --> Input Class Initialized
INFO - 2016-11-14 21:16:19 --> Language Class Initialized
INFO - 2016-11-14 21:16:19 --> Loader Class Initialized
INFO - 2016-11-14 21:16:19 --> Helper loaded: url_helper
INFO - 2016-11-14 21:16:19 --> Helper loaded: form_helper
INFO - 2016-11-14 21:16:19 --> Database Driver Class Initialized
INFO - 2016-11-14 21:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:16:19 --> Controller Class Initialized
INFO - 2016-11-14 21:16:19 --> Model Class Initialized
INFO - 2016-11-14 21:16:19 --> Config Class Initialized
INFO - 2016-11-14 21:16:19 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:16:19 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:16:19 --> Utf8 Class Initialized
INFO - 2016-11-14 21:16:19 --> URI Class Initialized
INFO - 2016-11-14 21:16:19 --> Router Class Initialized
INFO - 2016-11-14 21:16:19 --> Output Class Initialized
INFO - 2016-11-14 21:16:19 --> Security Class Initialized
DEBUG - 2016-11-14 21:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:16:19 --> Input Class Initialized
INFO - 2016-11-14 21:16:19 --> Language Class Initialized
INFO - 2016-11-14 21:16:19 --> Loader Class Initialized
INFO - 2016-11-14 21:16:19 --> Helper loaded: url_helper
INFO - 2016-11-14 21:16:19 --> Helper loaded: form_helper
INFO - 2016-11-14 21:16:19 --> Database Driver Class Initialized
INFO - 2016-11-14 21:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:16:19 --> Controller Class Initialized
INFO - 2016-11-14 21:16:19 --> Model Class Initialized
INFO - 2016-11-14 21:16:19 --> Config Class Initialized
INFO - 2016-11-14 21:16:19 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:16:19 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:16:19 --> Utf8 Class Initialized
INFO - 2016-11-14 21:16:19 --> URI Class Initialized
INFO - 2016-11-14 21:16:19 --> Router Class Initialized
INFO - 2016-11-14 21:16:19 --> Output Class Initialized
INFO - 2016-11-14 21:16:19 --> Security Class Initialized
DEBUG - 2016-11-14 21:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:16:19 --> Input Class Initialized
INFO - 2016-11-14 21:16:19 --> Language Class Initialized
INFO - 2016-11-14 21:16:19 --> Loader Class Initialized
INFO - 2016-11-14 21:16:19 --> Helper loaded: url_helper
INFO - 2016-11-14 21:16:19 --> Helper loaded: form_helper
INFO - 2016-11-14 21:16:19 --> Database Driver Class Initialized
INFO - 2016-11-14 21:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:16:19 --> Controller Class Initialized
INFO - 2016-11-14 21:16:19 --> Model Class Initialized
INFO - 2016-11-14 21:16:19 --> Config Class Initialized
INFO - 2016-11-14 21:16:19 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:16:19 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:16:19 --> Utf8 Class Initialized
INFO - 2016-11-14 21:16:19 --> URI Class Initialized
INFO - 2016-11-14 21:16:19 --> Router Class Initialized
INFO - 2016-11-14 21:16:19 --> Output Class Initialized
INFO - 2016-11-14 21:16:19 --> Security Class Initialized
DEBUG - 2016-11-14 21:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:16:20 --> Input Class Initialized
INFO - 2016-11-14 21:16:20 --> Language Class Initialized
INFO - 2016-11-14 21:16:20 --> Loader Class Initialized
INFO - 2016-11-14 21:16:20 --> Helper loaded: url_helper
INFO - 2016-11-14 21:16:20 --> Helper loaded: form_helper
INFO - 2016-11-14 21:16:20 --> Config Class Initialized
INFO - 2016-11-14 21:16:20 --> Hooks Class Initialized
INFO - 2016-11-14 21:16:20 --> Database Driver Class Initialized
DEBUG - 2016-11-14 21:16:20 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:16:20 --> Utf8 Class Initialized
INFO - 2016-11-14 21:16:20 --> Controller Class Initialized
INFO - 2016-11-14 21:16:20 --> URI Class Initialized
INFO - 2016-11-14 21:16:20 --> Model Class Initialized
INFO - 2016-11-14 21:16:20 --> Router Class Initialized
INFO - 2016-11-14 21:16:20 --> Output Class Initialized
INFO - 2016-11-14 21:16:20 --> Security Class Initialized
DEBUG - 2016-11-14 21:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:16:20 --> Input Class Initialized
INFO - 2016-11-14 21:16:20 --> Language Class Initialized
INFO - 2016-11-14 21:16:20 --> Loader Class Initialized
INFO - 2016-11-14 21:16:20 --> Helper loaded: url_helper
INFO - 2016-11-14 21:16:20 --> Helper loaded: form_helper
INFO - 2016-11-14 21:16:20 --> Database Driver Class Initialized
INFO - 2016-11-14 21:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:16:20 --> Controller Class Initialized
INFO - 2016-11-14 21:16:20 --> Model Class Initialized
INFO - 2016-11-14 21:16:21 --> Config Class Initialized
INFO - 2016-11-14 21:16:21 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:16:21 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:16:21 --> Utf8 Class Initialized
INFO - 2016-11-14 21:16:21 --> URI Class Initialized
DEBUG - 2016-11-14 21:16:21 --> No URI present. Default controller set.
INFO - 2016-11-14 21:16:21 --> Router Class Initialized
INFO - 2016-11-14 21:16:21 --> Output Class Initialized
INFO - 2016-11-14 21:16:21 --> Security Class Initialized
DEBUG - 2016-11-14 21:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:16:21 --> Input Class Initialized
INFO - 2016-11-14 21:16:21 --> Language Class Initialized
INFO - 2016-11-14 21:16:21 --> Loader Class Initialized
INFO - 2016-11-14 21:16:21 --> Helper loaded: url_helper
INFO - 2016-11-14 21:16:21 --> Helper loaded: form_helper
INFO - 2016-11-14 21:16:21 --> Database Driver Class Initialized
INFO - 2016-11-14 21:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:16:21 --> Controller Class Initialized
INFO - 2016-11-14 21:16:21 --> Model Class Initialized
INFO - 2016-11-14 21:16:21 --> Model Class Initialized
INFO - 2016-11-14 21:16:21 --> Model Class Initialized
INFO - 2016-11-14 21:16:21 --> Model Class Initialized
INFO - 2016-11-14 21:16:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:16:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:16:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:16:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:16:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:16:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:16:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:16:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:16:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:16:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:16:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:16:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:16:21 --> Final output sent to browser
DEBUG - 2016-11-14 21:16:21 --> Total execution time: 0.4147
INFO - 2016-11-14 21:16:28 --> Config Class Initialized
INFO - 2016-11-14 21:16:28 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:16:28 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:16:28 --> Utf8 Class Initialized
INFO - 2016-11-14 21:16:28 --> URI Class Initialized
INFO - 2016-11-14 21:16:28 --> Router Class Initialized
INFO - 2016-11-14 21:16:28 --> Output Class Initialized
INFO - 2016-11-14 21:16:28 --> Security Class Initialized
DEBUG - 2016-11-14 21:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:16:28 --> Input Class Initialized
INFO - 2016-11-14 21:16:28 --> Language Class Initialized
INFO - 2016-11-14 21:16:28 --> Loader Class Initialized
INFO - 2016-11-14 21:16:28 --> Helper loaded: url_helper
INFO - 2016-11-14 21:16:28 --> Helper loaded: form_helper
INFO - 2016-11-14 21:16:28 --> Database Driver Class Initialized
INFO - 2016-11-14 21:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:16:28 --> Controller Class Initialized
INFO - 2016-11-14 21:16:28 --> Model Class Initialized
INFO - 2016-11-14 21:16:29 --> Config Class Initialized
INFO - 2016-11-14 21:16:29 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:16:29 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:16:29 --> Utf8 Class Initialized
INFO - 2016-11-14 21:16:29 --> URI Class Initialized
INFO - 2016-11-14 21:16:29 --> Router Class Initialized
INFO - 2016-11-14 21:16:29 --> Output Class Initialized
INFO - 2016-11-14 21:16:29 --> Security Class Initialized
DEBUG - 2016-11-14 21:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:16:29 --> Input Class Initialized
INFO - 2016-11-14 21:16:29 --> Language Class Initialized
INFO - 2016-11-14 21:16:29 --> Loader Class Initialized
INFO - 2016-11-14 21:16:29 --> Helper loaded: url_helper
INFO - 2016-11-14 21:16:29 --> Helper loaded: form_helper
INFO - 2016-11-14 21:16:29 --> Database Driver Class Initialized
INFO - 2016-11-14 21:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:16:29 --> Controller Class Initialized
INFO - 2016-11-14 21:16:29 --> Model Class Initialized
INFO - 2016-11-14 21:16:30 --> Config Class Initialized
INFO - 2016-11-14 21:16:30 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:16:30 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:16:30 --> Utf8 Class Initialized
INFO - 2016-11-14 21:16:30 --> URI Class Initialized
INFO - 2016-11-14 21:16:30 --> Router Class Initialized
INFO - 2016-11-14 21:16:30 --> Output Class Initialized
INFO - 2016-11-14 21:16:30 --> Security Class Initialized
DEBUG - 2016-11-14 21:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:16:30 --> Input Class Initialized
INFO - 2016-11-14 21:16:30 --> Language Class Initialized
INFO - 2016-11-14 21:16:30 --> Loader Class Initialized
INFO - 2016-11-14 21:16:30 --> Helper loaded: url_helper
INFO - 2016-11-14 21:16:30 --> Helper loaded: form_helper
INFO - 2016-11-14 21:16:30 --> Database Driver Class Initialized
INFO - 2016-11-14 21:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:16:30 --> Controller Class Initialized
INFO - 2016-11-14 21:16:30 --> Model Class Initialized
INFO - 2016-11-14 21:17:14 --> Config Class Initialized
INFO - 2016-11-14 21:17:14 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:17:14 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:17:14 --> Utf8 Class Initialized
INFO - 2016-11-14 21:17:14 --> URI Class Initialized
DEBUG - 2016-11-14 21:17:14 --> No URI present. Default controller set.
INFO - 2016-11-14 21:17:14 --> Router Class Initialized
INFO - 2016-11-14 21:17:14 --> Output Class Initialized
INFO - 2016-11-14 21:17:14 --> Security Class Initialized
DEBUG - 2016-11-14 21:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:17:14 --> Input Class Initialized
INFO - 2016-11-14 21:17:14 --> Language Class Initialized
INFO - 2016-11-14 21:17:14 --> Loader Class Initialized
INFO - 2016-11-14 21:17:14 --> Helper loaded: url_helper
INFO - 2016-11-14 21:17:14 --> Helper loaded: form_helper
INFO - 2016-11-14 21:17:14 --> Database Driver Class Initialized
INFO - 2016-11-14 21:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:17:14 --> Controller Class Initialized
INFO - 2016-11-14 21:17:14 --> Model Class Initialized
INFO - 2016-11-14 21:17:14 --> Model Class Initialized
INFO - 2016-11-14 21:17:14 --> Model Class Initialized
INFO - 2016-11-14 21:17:14 --> Model Class Initialized
INFO - 2016-11-14 21:17:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:17:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:17:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:17:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:17:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:17:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:17:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:17:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:17:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:17:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:17:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:17:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:17:14 --> Final output sent to browser
DEBUG - 2016-11-14 21:17:14 --> Total execution time: 0.3338
INFO - 2016-11-14 21:17:18 --> Config Class Initialized
INFO - 2016-11-14 21:17:18 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:17:18 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:17:18 --> Utf8 Class Initialized
INFO - 2016-11-14 21:17:18 --> URI Class Initialized
INFO - 2016-11-14 21:17:18 --> Router Class Initialized
INFO - 2016-11-14 21:17:18 --> Output Class Initialized
INFO - 2016-11-14 21:17:18 --> Security Class Initialized
DEBUG - 2016-11-14 21:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:17:18 --> Input Class Initialized
INFO - 2016-11-14 21:17:18 --> Language Class Initialized
INFO - 2016-11-14 21:17:18 --> Loader Class Initialized
INFO - 2016-11-14 21:17:19 --> Helper loaded: url_helper
INFO - 2016-11-14 21:17:19 --> Helper loaded: form_helper
INFO - 2016-11-14 21:17:19 --> Database Driver Class Initialized
INFO - 2016-11-14 21:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:17:19 --> Controller Class Initialized
INFO - 2016-11-14 21:17:19 --> Model Class Initialized
INFO - 2016-11-14 21:17:19 --> Config Class Initialized
INFO - 2016-11-14 21:17:19 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:17:19 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:17:19 --> Utf8 Class Initialized
INFO - 2016-11-14 21:17:19 --> URI Class Initialized
INFO - 2016-11-14 21:17:19 --> Router Class Initialized
INFO - 2016-11-14 21:17:19 --> Output Class Initialized
INFO - 2016-11-14 21:17:19 --> Security Class Initialized
DEBUG - 2016-11-14 21:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:17:19 --> Input Class Initialized
INFO - 2016-11-14 21:17:19 --> Language Class Initialized
INFO - 2016-11-14 21:17:19 --> Loader Class Initialized
INFO - 2016-11-14 21:17:19 --> Helper loaded: url_helper
INFO - 2016-11-14 21:17:19 --> Helper loaded: form_helper
INFO - 2016-11-14 21:17:19 --> Database Driver Class Initialized
INFO - 2016-11-14 21:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:17:20 --> Controller Class Initialized
INFO - 2016-11-14 21:17:20 --> Model Class Initialized
INFO - 2016-11-14 21:17:20 --> Config Class Initialized
INFO - 2016-11-14 21:17:20 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:17:20 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:17:20 --> Utf8 Class Initialized
INFO - 2016-11-14 21:17:20 --> URI Class Initialized
INFO - 2016-11-14 21:17:20 --> Router Class Initialized
INFO - 2016-11-14 21:17:20 --> Output Class Initialized
INFO - 2016-11-14 21:17:20 --> Security Class Initialized
DEBUG - 2016-11-14 21:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:17:20 --> Input Class Initialized
INFO - 2016-11-14 21:17:20 --> Language Class Initialized
INFO - 2016-11-14 21:17:20 --> Loader Class Initialized
INFO - 2016-11-14 21:17:20 --> Helper loaded: url_helper
INFO - 2016-11-14 21:17:20 --> Helper loaded: form_helper
INFO - 2016-11-14 21:17:20 --> Database Driver Class Initialized
INFO - 2016-11-14 21:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:17:20 --> Controller Class Initialized
INFO - 2016-11-14 21:17:20 --> Model Class Initialized
INFO - 2016-11-14 21:17:23 --> Config Class Initialized
INFO - 2016-11-14 21:17:23 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:17:23 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:17:23 --> Utf8 Class Initialized
INFO - 2016-11-14 21:17:23 --> URI Class Initialized
INFO - 2016-11-14 21:17:23 --> Router Class Initialized
INFO - 2016-11-14 21:17:23 --> Output Class Initialized
INFO - 2016-11-14 21:17:23 --> Security Class Initialized
DEBUG - 2016-11-14 21:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:17:23 --> Input Class Initialized
INFO - 2016-11-14 21:17:24 --> Language Class Initialized
INFO - 2016-11-14 21:17:24 --> Loader Class Initialized
INFO - 2016-11-14 21:17:24 --> Helper loaded: url_helper
INFO - 2016-11-14 21:17:24 --> Helper loaded: form_helper
INFO - 2016-11-14 21:17:24 --> Database Driver Class Initialized
INFO - 2016-11-14 21:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:17:24 --> Controller Class Initialized
INFO - 2016-11-14 21:17:24 --> Model Class Initialized
INFO - 2016-11-14 21:17:24 --> Config Class Initialized
INFO - 2016-11-14 21:17:24 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:17:24 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:17:24 --> Utf8 Class Initialized
INFO - 2016-11-14 21:17:24 --> URI Class Initialized
INFO - 2016-11-14 21:17:24 --> Router Class Initialized
INFO - 2016-11-14 21:17:24 --> Output Class Initialized
INFO - 2016-11-14 21:17:24 --> Security Class Initialized
DEBUG - 2016-11-14 21:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:17:24 --> Input Class Initialized
INFO - 2016-11-14 21:17:24 --> Language Class Initialized
INFO - 2016-11-14 21:17:24 --> Loader Class Initialized
INFO - 2016-11-14 21:17:24 --> Helper loaded: url_helper
INFO - 2016-11-14 21:17:24 --> Helper loaded: form_helper
INFO - 2016-11-14 21:17:24 --> Database Driver Class Initialized
INFO - 2016-11-14 21:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:17:24 --> Controller Class Initialized
INFO - 2016-11-14 21:17:24 --> Model Class Initialized
INFO - 2016-11-14 21:19:11 --> Config Class Initialized
INFO - 2016-11-14 21:19:11 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:19:11 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:19:11 --> Utf8 Class Initialized
INFO - 2016-11-14 21:19:11 --> URI Class Initialized
DEBUG - 2016-11-14 21:19:11 --> No URI present. Default controller set.
INFO - 2016-11-14 21:19:11 --> Router Class Initialized
INFO - 2016-11-14 21:19:11 --> Output Class Initialized
INFO - 2016-11-14 21:19:11 --> Security Class Initialized
DEBUG - 2016-11-14 21:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:19:11 --> Input Class Initialized
INFO - 2016-11-14 21:19:11 --> Language Class Initialized
INFO - 2016-11-14 21:19:11 --> Loader Class Initialized
INFO - 2016-11-14 21:19:11 --> Helper loaded: url_helper
INFO - 2016-11-14 21:19:11 --> Helper loaded: form_helper
INFO - 2016-11-14 21:19:11 --> Database Driver Class Initialized
INFO - 2016-11-14 21:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:19:11 --> Controller Class Initialized
INFO - 2016-11-14 21:19:11 --> Model Class Initialized
INFO - 2016-11-14 21:19:11 --> Model Class Initialized
INFO - 2016-11-14 21:19:11 --> Model Class Initialized
INFO - 2016-11-14 21:19:11 --> Model Class Initialized
INFO - 2016-11-14 21:19:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:19:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:19:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:19:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:19:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:19:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:19:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:19:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:19:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:19:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:19:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:19:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:19:11 --> Final output sent to browser
DEBUG - 2016-11-14 21:19:11 --> Total execution time: 0.3229
INFO - 2016-11-14 21:19:14 --> Config Class Initialized
INFO - 2016-11-14 21:19:14 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:19:14 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:19:14 --> Utf8 Class Initialized
INFO - 2016-11-14 21:19:14 --> URI Class Initialized
INFO - 2016-11-14 21:19:14 --> Router Class Initialized
INFO - 2016-11-14 21:19:14 --> Output Class Initialized
INFO - 2016-11-14 21:19:14 --> Security Class Initialized
DEBUG - 2016-11-14 21:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:19:14 --> Input Class Initialized
INFO - 2016-11-14 21:19:14 --> Language Class Initialized
INFO - 2016-11-14 21:19:14 --> Loader Class Initialized
INFO - 2016-11-14 21:19:14 --> Helper loaded: url_helper
INFO - 2016-11-14 21:19:14 --> Helper loaded: form_helper
INFO - 2016-11-14 21:19:14 --> Database Driver Class Initialized
INFO - 2016-11-14 21:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:19:14 --> Controller Class Initialized
INFO - 2016-11-14 21:19:14 --> Model Class Initialized
INFO - 2016-11-14 21:19:14 --> Model Class Initialized
INFO - 2016-11-14 21:19:14 --> Model Class Initialized
INFO - 2016-11-14 21:19:14 --> Model Class Initialized
DEBUG - 2016-11-14 21:19:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-14 21:19:14 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-14 21:19:14 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-14 21:19:14 --> Config Class Initialized
INFO - 2016-11-14 21:19:14 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:19:14 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:19:14 --> Utf8 Class Initialized
INFO - 2016-11-14 21:19:14 --> URI Class Initialized
DEBUG - 2016-11-14 21:19:14 --> No URI present. Default controller set.
INFO - 2016-11-14 21:19:14 --> Router Class Initialized
INFO - 2016-11-14 21:19:14 --> Output Class Initialized
INFO - 2016-11-14 21:19:14 --> Security Class Initialized
DEBUG - 2016-11-14 21:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:19:14 --> Input Class Initialized
INFO - 2016-11-14 21:19:14 --> Language Class Initialized
INFO - 2016-11-14 21:19:14 --> Loader Class Initialized
INFO - 2016-11-14 21:19:14 --> Helper loaded: url_helper
INFO - 2016-11-14 21:19:14 --> Helper loaded: form_helper
INFO - 2016-11-14 21:19:14 --> Database Driver Class Initialized
INFO - 2016-11-14 21:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:19:14 --> Controller Class Initialized
INFO - 2016-11-14 21:19:14 --> Model Class Initialized
INFO - 2016-11-14 21:19:14 --> Model Class Initialized
INFO - 2016-11-14 21:19:14 --> Model Class Initialized
INFO - 2016-11-14 21:19:14 --> Model Class Initialized
INFO - 2016-11-14 21:19:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:19:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-14 21:19:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:19:14 --> Final output sent to browser
DEBUG - 2016-11-14 21:19:14 --> Total execution time: 0.2535
INFO - 2016-11-14 21:19:24 --> Config Class Initialized
INFO - 2016-11-14 21:19:24 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:19:24 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:19:24 --> Utf8 Class Initialized
INFO - 2016-11-14 21:19:24 --> URI Class Initialized
INFO - 2016-11-14 21:19:24 --> Router Class Initialized
INFO - 2016-11-14 21:19:24 --> Output Class Initialized
INFO - 2016-11-14 21:19:24 --> Security Class Initialized
DEBUG - 2016-11-14 21:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:19:24 --> Input Class Initialized
INFO - 2016-11-14 21:19:24 --> Language Class Initialized
INFO - 2016-11-14 21:19:24 --> Loader Class Initialized
INFO - 2016-11-14 21:19:24 --> Helper loaded: url_helper
INFO - 2016-11-14 21:19:24 --> Helper loaded: form_helper
INFO - 2016-11-14 21:19:25 --> Database Driver Class Initialized
INFO - 2016-11-14 21:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:19:25 --> Controller Class Initialized
INFO - 2016-11-14 21:19:25 --> Model Class Initialized
INFO - 2016-11-14 21:19:25 --> Model Class Initialized
INFO - 2016-11-14 21:19:25 --> Model Class Initialized
INFO - 2016-11-14 21:19:25 --> Model Class Initialized
DEBUG - 2016-11-14 21:19:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-14 21:19:25 --> Model Class Initialized
INFO - 2016-11-14 21:19:25 --> Final output sent to browser
DEBUG - 2016-11-14 21:19:25 --> Total execution time: 0.2550
INFO - 2016-11-14 21:19:25 --> Config Class Initialized
INFO - 2016-11-14 21:19:25 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:19:25 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:19:25 --> Utf8 Class Initialized
INFO - 2016-11-14 21:19:25 --> URI Class Initialized
DEBUG - 2016-11-14 21:19:25 --> No URI present. Default controller set.
INFO - 2016-11-14 21:19:25 --> Router Class Initialized
INFO - 2016-11-14 21:19:25 --> Output Class Initialized
INFO - 2016-11-14 21:19:25 --> Security Class Initialized
DEBUG - 2016-11-14 21:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:19:25 --> Input Class Initialized
INFO - 2016-11-14 21:19:25 --> Language Class Initialized
INFO - 2016-11-14 21:19:25 --> Loader Class Initialized
INFO - 2016-11-14 21:19:25 --> Helper loaded: url_helper
INFO - 2016-11-14 21:19:25 --> Helper loaded: form_helper
INFO - 2016-11-14 21:19:25 --> Database Driver Class Initialized
INFO - 2016-11-14 21:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:19:25 --> Controller Class Initialized
INFO - 2016-11-14 21:19:25 --> Model Class Initialized
INFO - 2016-11-14 21:19:25 --> Model Class Initialized
INFO - 2016-11-14 21:19:25 --> Model Class Initialized
INFO - 2016-11-14 21:19:25 --> Model Class Initialized
INFO - 2016-11-14 21:19:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:19:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:19:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:19:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-14 21:19:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-14 21:19:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-14 21:19:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-14 21:19:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-14 21:19:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-14 21:19:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:19:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:19:25 --> Final output sent to browser
DEBUG - 2016-11-14 21:19:25 --> Total execution time: 0.3943
INFO - 2016-11-14 21:19:46 --> Config Class Initialized
INFO - 2016-11-14 21:19:46 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:19:46 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:19:46 --> Utf8 Class Initialized
INFO - 2016-11-14 21:19:46 --> URI Class Initialized
INFO - 2016-11-14 21:19:46 --> Router Class Initialized
INFO - 2016-11-14 21:19:46 --> Output Class Initialized
INFO - 2016-11-14 21:19:46 --> Security Class Initialized
DEBUG - 2016-11-14 21:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:19:46 --> Input Class Initialized
INFO - 2016-11-14 21:19:46 --> Language Class Initialized
INFO - 2016-11-14 21:19:46 --> Loader Class Initialized
INFO - 2016-11-14 21:19:46 --> Helper loaded: url_helper
INFO - 2016-11-14 21:19:46 --> Helper loaded: form_helper
INFO - 2016-11-14 21:19:46 --> Database Driver Class Initialized
INFO - 2016-11-14 21:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:19:46 --> Controller Class Initialized
INFO - 2016-11-14 21:19:46 --> Model Class Initialized
INFO - 2016-11-14 21:19:55 --> Config Class Initialized
INFO - 2016-11-14 21:19:55 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:19:55 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:19:55 --> Utf8 Class Initialized
INFO - 2016-11-14 21:19:55 --> URI Class Initialized
INFO - 2016-11-14 21:19:55 --> Router Class Initialized
INFO - 2016-11-14 21:19:55 --> Output Class Initialized
INFO - 2016-11-14 21:19:55 --> Security Class Initialized
DEBUG - 2016-11-14 21:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:19:55 --> Input Class Initialized
INFO - 2016-11-14 21:19:55 --> Language Class Initialized
INFO - 2016-11-14 21:19:55 --> Loader Class Initialized
INFO - 2016-11-14 21:19:55 --> Helper loaded: url_helper
INFO - 2016-11-14 21:19:55 --> Helper loaded: form_helper
INFO - 2016-11-14 21:19:55 --> Database Driver Class Initialized
INFO - 2016-11-14 21:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:19:55 --> Controller Class Initialized
INFO - 2016-11-14 21:19:55 --> Model Class Initialized
INFO - 2016-11-14 21:19:55 --> Config Class Initialized
INFO - 2016-11-14 21:19:55 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:19:55 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:19:55 --> Utf8 Class Initialized
INFO - 2016-11-14 21:19:55 --> URI Class Initialized
INFO - 2016-11-14 21:19:55 --> Router Class Initialized
INFO - 2016-11-14 21:19:55 --> Output Class Initialized
INFO - 2016-11-14 21:19:55 --> Security Class Initialized
DEBUG - 2016-11-14 21:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:19:55 --> Input Class Initialized
INFO - 2016-11-14 21:19:55 --> Language Class Initialized
INFO - 2016-11-14 21:19:55 --> Loader Class Initialized
INFO - 2016-11-14 21:19:55 --> Helper loaded: url_helper
INFO - 2016-11-14 21:19:55 --> Helper loaded: form_helper
INFO - 2016-11-14 21:19:55 --> Database Driver Class Initialized
INFO - 2016-11-14 21:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:19:55 --> Controller Class Initialized
INFO - 2016-11-14 21:19:55 --> Model Class Initialized
INFO - 2016-11-14 21:19:56 --> Config Class Initialized
INFO - 2016-11-14 21:19:56 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:19:56 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:19:56 --> Utf8 Class Initialized
INFO - 2016-11-14 21:19:56 --> URI Class Initialized
INFO - 2016-11-14 21:19:56 --> Router Class Initialized
INFO - 2016-11-14 21:19:56 --> Output Class Initialized
INFO - 2016-11-14 21:19:56 --> Security Class Initialized
DEBUG - 2016-11-14 21:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:19:56 --> Input Class Initialized
INFO - 2016-11-14 21:19:56 --> Language Class Initialized
INFO - 2016-11-14 21:19:56 --> Loader Class Initialized
INFO - 2016-11-14 21:19:56 --> Helper loaded: url_helper
INFO - 2016-11-14 21:19:56 --> Helper loaded: form_helper
INFO - 2016-11-14 21:19:56 --> Database Driver Class Initialized
INFO - 2016-11-14 21:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:19:56 --> Controller Class Initialized
INFO - 2016-11-14 21:19:56 --> Model Class Initialized
INFO - 2016-11-14 21:19:56 --> Config Class Initialized
INFO - 2016-11-14 21:19:56 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:19:56 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:19:56 --> Utf8 Class Initialized
INFO - 2016-11-14 21:19:56 --> URI Class Initialized
INFO - 2016-11-14 21:19:56 --> Router Class Initialized
INFO - 2016-11-14 21:19:56 --> Output Class Initialized
INFO - 2016-11-14 21:19:56 --> Security Class Initialized
DEBUG - 2016-11-14 21:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:19:56 --> Input Class Initialized
INFO - 2016-11-14 21:19:56 --> Language Class Initialized
INFO - 2016-11-14 21:19:56 --> Loader Class Initialized
INFO - 2016-11-14 21:19:56 --> Helper loaded: url_helper
INFO - 2016-11-14 21:19:56 --> Helper loaded: form_helper
INFO - 2016-11-14 21:19:56 --> Database Driver Class Initialized
INFO - 2016-11-14 21:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:19:56 --> Controller Class Initialized
INFO - 2016-11-14 21:19:56 --> Config Class Initialized
INFO - 2016-11-14 21:19:56 --> Model Class Initialized
INFO - 2016-11-14 21:19:56 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:19:56 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:19:56 --> Utf8 Class Initialized
INFO - 2016-11-14 21:19:56 --> URI Class Initialized
INFO - 2016-11-14 21:19:56 --> Router Class Initialized
INFO - 2016-11-14 21:19:56 --> Output Class Initialized
INFO - 2016-11-14 21:19:56 --> Security Class Initialized
DEBUG - 2016-11-14 21:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:19:56 --> Input Class Initialized
INFO - 2016-11-14 21:19:56 --> Language Class Initialized
INFO - 2016-11-14 21:19:56 --> Loader Class Initialized
INFO - 2016-11-14 21:19:56 --> Helper loaded: url_helper
INFO - 2016-11-14 21:19:56 --> Helper loaded: form_helper
INFO - 2016-11-14 21:19:56 --> Database Driver Class Initialized
INFO - 2016-11-14 21:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:19:56 --> Config Class Initialized
INFO - 2016-11-14 21:19:56 --> Controller Class Initialized
INFO - 2016-11-14 21:19:56 --> Hooks Class Initialized
INFO - 2016-11-14 21:19:56 --> Model Class Initialized
DEBUG - 2016-11-14 21:19:56 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:19:56 --> Utf8 Class Initialized
INFO - 2016-11-14 21:19:56 --> URI Class Initialized
INFO - 2016-11-14 21:19:56 --> Router Class Initialized
INFO - 2016-11-14 21:19:56 --> Output Class Initialized
INFO - 2016-11-14 21:19:56 --> Security Class Initialized
DEBUG - 2016-11-14 21:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:19:56 --> Input Class Initialized
INFO - 2016-11-14 21:19:56 --> Language Class Initialized
INFO - 2016-11-14 21:19:56 --> Loader Class Initialized
INFO - 2016-11-14 21:19:56 --> Helper loaded: url_helper
INFO - 2016-11-14 21:19:56 --> Helper loaded: form_helper
INFO - 2016-11-14 21:19:56 --> Database Driver Class Initialized
INFO - 2016-11-14 21:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:19:56 --> Controller Class Initialized
INFO - 2016-11-14 21:19:56 --> Model Class Initialized
INFO - 2016-11-14 21:19:56 --> Config Class Initialized
INFO - 2016-11-14 21:19:56 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:19:56 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:19:56 --> Utf8 Class Initialized
INFO - 2016-11-14 21:19:56 --> URI Class Initialized
INFO - 2016-11-14 21:19:56 --> Router Class Initialized
INFO - 2016-11-14 21:19:56 --> Output Class Initialized
INFO - 2016-11-14 21:19:56 --> Security Class Initialized
DEBUG - 2016-11-14 21:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:19:56 --> Input Class Initialized
INFO - 2016-11-14 21:19:56 --> Language Class Initialized
INFO - 2016-11-14 21:19:56 --> Loader Class Initialized
INFO - 2016-11-14 21:19:56 --> Helper loaded: url_helper
INFO - 2016-11-14 21:19:56 --> Helper loaded: form_helper
INFO - 2016-11-14 21:19:56 --> Database Driver Class Initialized
INFO - 2016-11-14 21:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:19:56 --> Controller Class Initialized
INFO - 2016-11-14 21:19:57 --> Model Class Initialized
INFO - 2016-11-14 21:20:04 --> Config Class Initialized
INFO - 2016-11-14 21:20:04 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:20:04 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:20:04 --> Utf8 Class Initialized
INFO - 2016-11-14 21:20:04 --> URI Class Initialized
INFO - 2016-11-14 21:20:04 --> Router Class Initialized
INFO - 2016-11-14 21:20:04 --> Output Class Initialized
INFO - 2016-11-14 21:20:04 --> Security Class Initialized
DEBUG - 2016-11-14 21:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:20:04 --> Input Class Initialized
INFO - 2016-11-14 21:20:04 --> Language Class Initialized
INFO - 2016-11-14 21:20:04 --> Loader Class Initialized
INFO - 2016-11-14 21:20:04 --> Helper loaded: url_helper
INFO - 2016-11-14 21:20:04 --> Helper loaded: form_helper
INFO - 2016-11-14 21:20:04 --> Database Driver Class Initialized
INFO - 2016-11-14 21:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:20:04 --> Controller Class Initialized
INFO - 2016-11-14 21:20:04 --> Model Class Initialized
INFO - 2016-11-14 21:20:04 --> Model Class Initialized
INFO - 2016-11-14 21:20:04 --> Model Class Initialized
INFO - 2016-11-14 21:20:04 --> Model Class Initialized
DEBUG - 2016-11-14 21:20:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-14 21:20:04 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-14 21:20:04 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-14 21:20:04 --> Config Class Initialized
INFO - 2016-11-14 21:20:04 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:20:04 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:20:04 --> Utf8 Class Initialized
INFO - 2016-11-14 21:20:04 --> URI Class Initialized
DEBUG - 2016-11-14 21:20:04 --> No URI present. Default controller set.
INFO - 2016-11-14 21:20:04 --> Router Class Initialized
INFO - 2016-11-14 21:20:04 --> Output Class Initialized
INFO - 2016-11-14 21:20:04 --> Security Class Initialized
DEBUG - 2016-11-14 21:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:20:04 --> Input Class Initialized
INFO - 2016-11-14 21:20:04 --> Language Class Initialized
INFO - 2016-11-14 21:20:04 --> Loader Class Initialized
INFO - 2016-11-14 21:20:04 --> Helper loaded: url_helper
INFO - 2016-11-14 21:20:04 --> Helper loaded: form_helper
INFO - 2016-11-14 21:20:04 --> Database Driver Class Initialized
INFO - 2016-11-14 21:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:20:04 --> Controller Class Initialized
INFO - 2016-11-14 21:20:04 --> Model Class Initialized
INFO - 2016-11-14 21:20:04 --> Model Class Initialized
INFO - 2016-11-14 21:20:04 --> Model Class Initialized
INFO - 2016-11-14 21:20:04 --> Model Class Initialized
INFO - 2016-11-14 21:20:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:20:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-14 21:20:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:20:04 --> Final output sent to browser
DEBUG - 2016-11-14 21:20:04 --> Total execution time: 0.3117
INFO - 2016-11-14 21:20:11 --> Config Class Initialized
INFO - 2016-11-14 21:20:11 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:20:11 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:20:11 --> Utf8 Class Initialized
INFO - 2016-11-14 21:20:11 --> URI Class Initialized
INFO - 2016-11-14 21:20:11 --> Router Class Initialized
INFO - 2016-11-14 21:20:12 --> Output Class Initialized
INFO - 2016-11-14 21:20:12 --> Security Class Initialized
DEBUG - 2016-11-14 21:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:20:12 --> Input Class Initialized
INFO - 2016-11-14 21:20:12 --> Language Class Initialized
INFO - 2016-11-14 21:20:12 --> Loader Class Initialized
INFO - 2016-11-14 21:20:12 --> Helper loaded: url_helper
INFO - 2016-11-14 21:20:12 --> Helper loaded: form_helper
INFO - 2016-11-14 21:20:12 --> Database Driver Class Initialized
INFO - 2016-11-14 21:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:20:12 --> Controller Class Initialized
INFO - 2016-11-14 21:20:12 --> Model Class Initialized
INFO - 2016-11-14 21:20:12 --> Model Class Initialized
INFO - 2016-11-14 21:20:12 --> Model Class Initialized
INFO - 2016-11-14 21:20:12 --> Model Class Initialized
DEBUG - 2016-11-14 21:20:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-14 21:20:12 --> Model Class Initialized
INFO - 2016-11-14 21:20:12 --> Final output sent to browser
DEBUG - 2016-11-14 21:20:12 --> Total execution time: 0.1978
INFO - 2016-11-14 21:20:12 --> Config Class Initialized
INFO - 2016-11-14 21:20:12 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:20:12 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:20:12 --> Utf8 Class Initialized
INFO - 2016-11-14 21:20:12 --> URI Class Initialized
DEBUG - 2016-11-14 21:20:12 --> No URI present. Default controller set.
INFO - 2016-11-14 21:20:12 --> Router Class Initialized
INFO - 2016-11-14 21:20:12 --> Output Class Initialized
INFO - 2016-11-14 21:20:12 --> Security Class Initialized
DEBUG - 2016-11-14 21:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:20:12 --> Input Class Initialized
INFO - 2016-11-14 21:20:12 --> Language Class Initialized
INFO - 2016-11-14 21:20:12 --> Loader Class Initialized
INFO - 2016-11-14 21:20:12 --> Helper loaded: url_helper
INFO - 2016-11-14 21:20:12 --> Helper loaded: form_helper
INFO - 2016-11-14 21:20:12 --> Database Driver Class Initialized
INFO - 2016-11-14 21:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:20:12 --> Controller Class Initialized
INFO - 2016-11-14 21:20:12 --> Model Class Initialized
INFO - 2016-11-14 21:20:12 --> Model Class Initialized
INFO - 2016-11-14 21:20:12 --> Model Class Initialized
INFO - 2016-11-14 21:20:12 --> Model Class Initialized
INFO - 2016-11-14 21:20:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:20:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:20:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:20:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:20:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:20:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:20:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:20:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:20:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:20:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:20:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:20:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:20:12 --> Final output sent to browser
DEBUG - 2016-11-14 21:20:12 --> Total execution time: 0.3161
INFO - 2016-11-14 21:20:21 --> Config Class Initialized
INFO - 2016-11-14 21:20:21 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:20:22 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:20:22 --> Utf8 Class Initialized
INFO - 2016-11-14 21:20:22 --> URI Class Initialized
INFO - 2016-11-14 21:20:22 --> Router Class Initialized
INFO - 2016-11-14 21:20:22 --> Output Class Initialized
INFO - 2016-11-14 21:20:22 --> Security Class Initialized
DEBUG - 2016-11-14 21:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:20:22 --> Input Class Initialized
INFO - 2016-11-14 21:20:22 --> Language Class Initialized
INFO - 2016-11-14 21:20:22 --> Loader Class Initialized
INFO - 2016-11-14 21:20:22 --> Helper loaded: url_helper
INFO - 2016-11-14 21:20:22 --> Helper loaded: form_helper
INFO - 2016-11-14 21:20:22 --> Database Driver Class Initialized
INFO - 2016-11-14 21:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:20:22 --> Controller Class Initialized
INFO - 2016-11-14 21:20:22 --> Model Class Initialized
INFO - 2016-11-14 21:20:22 --> Config Class Initialized
INFO - 2016-11-14 21:20:22 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:20:22 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:20:22 --> Utf8 Class Initialized
INFO - 2016-11-14 21:20:22 --> URI Class Initialized
INFO - 2016-11-14 21:20:22 --> Router Class Initialized
INFO - 2016-11-14 21:20:22 --> Output Class Initialized
INFO - 2016-11-14 21:20:22 --> Security Class Initialized
DEBUG - 2016-11-14 21:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:20:22 --> Input Class Initialized
INFO - 2016-11-14 21:20:22 --> Language Class Initialized
INFO - 2016-11-14 21:20:22 --> Loader Class Initialized
INFO - 2016-11-14 21:20:22 --> Helper loaded: url_helper
INFO - 2016-11-14 21:20:22 --> Helper loaded: form_helper
INFO - 2016-11-14 21:20:22 --> Database Driver Class Initialized
INFO - 2016-11-14 21:20:22 --> Config Class Initialized
INFO - 2016-11-14 21:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:20:22 --> Hooks Class Initialized
INFO - 2016-11-14 21:20:22 --> Controller Class Initialized
INFO - 2016-11-14 21:20:22 --> Model Class Initialized
DEBUG - 2016-11-14 21:20:22 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:20:22 --> Utf8 Class Initialized
INFO - 2016-11-14 21:20:22 --> URI Class Initialized
INFO - 2016-11-14 21:20:22 --> Router Class Initialized
INFO - 2016-11-14 21:20:22 --> Output Class Initialized
INFO - 2016-11-14 21:20:22 --> Security Class Initialized
DEBUG - 2016-11-14 21:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:20:22 --> Input Class Initialized
INFO - 2016-11-14 21:20:22 --> Language Class Initialized
INFO - 2016-11-14 21:20:22 --> Loader Class Initialized
INFO - 2016-11-14 21:20:22 --> Helper loaded: url_helper
INFO - 2016-11-14 21:20:22 --> Config Class Initialized
INFO - 2016-11-14 21:20:22 --> Helper loaded: form_helper
INFO - 2016-11-14 21:20:22 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:20:22 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:20:22 --> Database Driver Class Initialized
INFO - 2016-11-14 21:20:22 --> Utf8 Class Initialized
INFO - 2016-11-14 21:20:22 --> URI Class Initialized
INFO - 2016-11-14 21:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:20:22 --> Router Class Initialized
INFO - 2016-11-14 21:20:22 --> Controller Class Initialized
INFO - 2016-11-14 21:20:22 --> Model Class Initialized
INFO - 2016-11-14 21:20:22 --> Output Class Initialized
INFO - 2016-11-14 21:20:23 --> Security Class Initialized
DEBUG - 2016-11-14 21:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:20:23 --> Input Class Initialized
INFO - 2016-11-14 21:20:23 --> Language Class Initialized
INFO - 2016-11-14 21:20:23 --> Loader Class Initialized
INFO - 2016-11-14 21:20:23 --> Helper loaded: url_helper
INFO - 2016-11-14 21:20:23 --> Helper loaded: form_helper
INFO - 2016-11-14 21:20:23 --> Config Class Initialized
INFO - 2016-11-14 21:20:23 --> Database Driver Class Initialized
INFO - 2016-11-14 21:20:23 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:20:23 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:20:23 --> Utf8 Class Initialized
INFO - 2016-11-14 21:20:23 --> Controller Class Initialized
INFO - 2016-11-14 21:20:23 --> URI Class Initialized
INFO - 2016-11-14 21:20:23 --> Model Class Initialized
INFO - 2016-11-14 21:20:23 --> Router Class Initialized
INFO - 2016-11-14 21:20:23 --> Output Class Initialized
INFO - 2016-11-14 21:20:23 --> Security Class Initialized
DEBUG - 2016-11-14 21:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:20:23 --> Input Class Initialized
INFO - 2016-11-14 21:20:23 --> Language Class Initialized
INFO - 2016-11-14 21:20:23 --> Loader Class Initialized
INFO - 2016-11-14 21:20:23 --> Helper loaded: url_helper
INFO - 2016-11-14 21:20:23 --> Helper loaded: form_helper
INFO - 2016-11-14 21:20:23 --> Database Driver Class Initialized
INFO - 2016-11-14 21:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:20:23 --> Controller Class Initialized
INFO - 2016-11-14 21:20:23 --> Model Class Initialized
INFO - 2016-11-14 21:20:23 --> Config Class Initialized
INFO - 2016-11-14 21:20:23 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:20:23 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:20:23 --> Utf8 Class Initialized
INFO - 2016-11-14 21:20:23 --> URI Class Initialized
INFO - 2016-11-14 21:20:23 --> Router Class Initialized
INFO - 2016-11-14 21:20:23 --> Output Class Initialized
INFO - 2016-11-14 21:20:23 --> Security Class Initialized
DEBUG - 2016-11-14 21:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:20:23 --> Input Class Initialized
INFO - 2016-11-14 21:20:23 --> Language Class Initialized
INFO - 2016-11-14 21:20:23 --> Loader Class Initialized
INFO - 2016-11-14 21:20:23 --> Helper loaded: url_helper
INFO - 2016-11-14 21:20:23 --> Helper loaded: form_helper
INFO - 2016-11-14 21:20:23 --> Database Driver Class Initialized
INFO - 2016-11-14 21:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:20:23 --> Controller Class Initialized
INFO - 2016-11-14 21:20:23 --> Model Class Initialized
INFO - 2016-11-14 21:20:23 --> Config Class Initialized
INFO - 2016-11-14 21:20:23 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:20:23 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:20:23 --> Utf8 Class Initialized
INFO - 2016-11-14 21:20:23 --> URI Class Initialized
INFO - 2016-11-14 21:20:23 --> Router Class Initialized
INFO - 2016-11-14 21:20:23 --> Output Class Initialized
INFO - 2016-11-14 21:20:23 --> Security Class Initialized
DEBUG - 2016-11-14 21:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:20:23 --> Input Class Initialized
INFO - 2016-11-14 21:20:23 --> Language Class Initialized
INFO - 2016-11-14 21:20:23 --> Loader Class Initialized
INFO - 2016-11-14 21:20:23 --> Helper loaded: url_helper
INFO - 2016-11-14 21:20:23 --> Helper loaded: form_helper
INFO - 2016-11-14 21:20:23 --> Database Driver Class Initialized
INFO - 2016-11-14 21:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:20:24 --> Controller Class Initialized
INFO - 2016-11-14 21:20:24 --> Model Class Initialized
INFO - 2016-11-14 21:20:24 --> Config Class Initialized
INFO - 2016-11-14 21:20:24 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:20:24 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:20:24 --> Utf8 Class Initialized
INFO - 2016-11-14 21:20:24 --> URI Class Initialized
INFO - 2016-11-14 21:20:24 --> Router Class Initialized
INFO - 2016-11-14 21:20:24 --> Output Class Initialized
INFO - 2016-11-14 21:20:24 --> Security Class Initialized
DEBUG - 2016-11-14 21:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:20:24 --> Input Class Initialized
INFO - 2016-11-14 21:20:24 --> Language Class Initialized
INFO - 2016-11-14 21:20:24 --> Loader Class Initialized
INFO - 2016-11-14 21:20:24 --> Helper loaded: url_helper
INFO - 2016-11-14 21:20:24 --> Helper loaded: form_helper
INFO - 2016-11-14 21:20:24 --> Database Driver Class Initialized
INFO - 2016-11-14 21:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:20:24 --> Controller Class Initialized
INFO - 2016-11-14 21:20:24 --> Model Class Initialized
INFO - 2016-11-14 21:20:24 --> Config Class Initialized
INFO - 2016-11-14 21:20:24 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:20:24 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:20:24 --> Utf8 Class Initialized
INFO - 2016-11-14 21:20:24 --> URI Class Initialized
INFO - 2016-11-14 21:20:24 --> Router Class Initialized
INFO - 2016-11-14 21:20:24 --> Output Class Initialized
INFO - 2016-11-14 21:20:24 --> Security Class Initialized
DEBUG - 2016-11-14 21:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:20:24 --> Input Class Initialized
INFO - 2016-11-14 21:20:24 --> Language Class Initialized
INFO - 2016-11-14 21:20:24 --> Loader Class Initialized
INFO - 2016-11-14 21:20:24 --> Helper loaded: url_helper
INFO - 2016-11-14 21:20:24 --> Helper loaded: form_helper
INFO - 2016-11-14 21:20:24 --> Database Driver Class Initialized
INFO - 2016-11-14 21:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:20:24 --> Controller Class Initialized
INFO - 2016-11-14 21:20:24 --> Model Class Initialized
INFO - 2016-11-14 21:20:24 --> Config Class Initialized
INFO - 2016-11-14 21:20:24 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:20:24 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:20:24 --> Utf8 Class Initialized
INFO - 2016-11-14 21:20:24 --> URI Class Initialized
INFO - 2016-11-14 21:20:24 --> Router Class Initialized
INFO - 2016-11-14 21:20:24 --> Output Class Initialized
INFO - 2016-11-14 21:20:24 --> Security Class Initialized
DEBUG - 2016-11-14 21:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:20:24 --> Input Class Initialized
INFO - 2016-11-14 21:20:24 --> Language Class Initialized
INFO - 2016-11-14 21:20:24 --> Loader Class Initialized
INFO - 2016-11-14 21:20:24 --> Helper loaded: url_helper
INFO - 2016-11-14 21:20:24 --> Helper loaded: form_helper
INFO - 2016-11-14 21:20:24 --> Database Driver Class Initialized
INFO - 2016-11-14 21:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:20:24 --> Controller Class Initialized
INFO - 2016-11-14 21:20:24 --> Model Class Initialized
INFO - 2016-11-14 21:20:24 --> Config Class Initialized
INFO - 2016-11-14 21:20:24 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:20:24 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:20:24 --> Utf8 Class Initialized
INFO - 2016-11-14 21:20:24 --> URI Class Initialized
INFO - 2016-11-14 21:20:24 --> Router Class Initialized
INFO - 2016-11-14 21:20:24 --> Output Class Initialized
INFO - 2016-11-14 21:20:24 --> Security Class Initialized
DEBUG - 2016-11-14 21:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:20:24 --> Input Class Initialized
INFO - 2016-11-14 21:20:24 --> Language Class Initialized
INFO - 2016-11-14 21:20:24 --> Loader Class Initialized
INFO - 2016-11-14 21:20:24 --> Helper loaded: url_helper
INFO - 2016-11-14 21:20:24 --> Helper loaded: form_helper
INFO - 2016-11-14 21:20:24 --> Database Driver Class Initialized
INFO - 2016-11-14 21:20:24 --> Config Class Initialized
INFO - 2016-11-14 21:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:20:24 --> Hooks Class Initialized
INFO - 2016-11-14 21:20:24 --> Controller Class Initialized
DEBUG - 2016-11-14 21:20:24 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:20:24 --> Model Class Initialized
INFO - 2016-11-14 21:20:24 --> Utf8 Class Initialized
INFO - 2016-11-14 21:20:24 --> URI Class Initialized
INFO - 2016-11-14 21:20:24 --> Router Class Initialized
INFO - 2016-11-14 21:20:24 --> Output Class Initialized
INFO - 2016-11-14 21:20:24 --> Security Class Initialized
DEBUG - 2016-11-14 21:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:20:24 --> Input Class Initialized
INFO - 2016-11-14 21:20:24 --> Language Class Initialized
INFO - 2016-11-14 21:20:24 --> Loader Class Initialized
INFO - 2016-11-14 21:20:24 --> Helper loaded: url_helper
INFO - 2016-11-14 21:20:24 --> Helper loaded: form_helper
INFO - 2016-11-14 21:20:24 --> Database Driver Class Initialized
INFO - 2016-11-14 21:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:20:24 --> Controller Class Initialized
INFO - 2016-11-14 21:20:24 --> Config Class Initialized
INFO - 2016-11-14 21:20:24 --> Model Class Initialized
INFO - 2016-11-14 21:20:24 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:20:24 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:20:24 --> Utf8 Class Initialized
INFO - 2016-11-14 21:20:24 --> URI Class Initialized
INFO - 2016-11-14 21:20:24 --> Router Class Initialized
INFO - 2016-11-14 21:20:24 --> Output Class Initialized
INFO - 2016-11-14 21:20:24 --> Security Class Initialized
DEBUG - 2016-11-14 21:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:20:25 --> Input Class Initialized
INFO - 2016-11-14 21:20:25 --> Language Class Initialized
INFO - 2016-11-14 21:20:25 --> Loader Class Initialized
INFO - 2016-11-14 21:20:25 --> Config Class Initialized
INFO - 2016-11-14 21:20:25 --> Helper loaded: url_helper
INFO - 2016-11-14 21:20:25 --> Hooks Class Initialized
INFO - 2016-11-14 21:20:25 --> Helper loaded: form_helper
DEBUG - 2016-11-14 21:20:25 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:20:25 --> Database Driver Class Initialized
INFO - 2016-11-14 21:20:25 --> Utf8 Class Initialized
INFO - 2016-11-14 21:20:25 --> URI Class Initialized
INFO - 2016-11-14 21:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:20:25 --> Router Class Initialized
INFO - 2016-11-14 21:20:25 --> Controller Class Initialized
INFO - 2016-11-14 21:20:25 --> Model Class Initialized
INFO - 2016-11-14 21:20:25 --> Output Class Initialized
INFO - 2016-11-14 21:20:25 --> Security Class Initialized
DEBUG - 2016-11-14 21:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:20:25 --> Input Class Initialized
INFO - 2016-11-14 21:20:25 --> Language Class Initialized
INFO - 2016-11-14 21:20:25 --> Loader Class Initialized
INFO - 2016-11-14 21:20:25 --> Helper loaded: url_helper
INFO - 2016-11-14 21:20:25 --> Helper loaded: form_helper
INFO - 2016-11-14 21:20:25 --> Config Class Initialized
INFO - 2016-11-14 21:20:25 --> Database Driver Class Initialized
INFO - 2016-11-14 21:20:25 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:20:25 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:20:25 --> Utf8 Class Initialized
INFO - 2016-11-14 21:20:25 --> Controller Class Initialized
INFO - 2016-11-14 21:20:25 --> URI Class Initialized
INFO - 2016-11-14 21:20:25 --> Model Class Initialized
INFO - 2016-11-14 21:20:25 --> Router Class Initialized
INFO - 2016-11-14 21:20:25 --> Output Class Initialized
INFO - 2016-11-14 21:20:25 --> Security Class Initialized
DEBUG - 2016-11-14 21:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:20:25 --> Input Class Initialized
INFO - 2016-11-14 21:20:25 --> Language Class Initialized
INFO - 2016-11-14 21:20:25 --> Loader Class Initialized
INFO - 2016-11-14 21:20:25 --> Helper loaded: url_helper
INFO - 2016-11-14 21:20:25 --> Helper loaded: form_helper
INFO - 2016-11-14 21:20:25 --> Database Driver Class Initialized
INFO - 2016-11-14 21:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:20:25 --> Controller Class Initialized
INFO - 2016-11-14 21:20:25 --> Model Class Initialized
INFO - 2016-11-14 21:20:25 --> Config Class Initialized
INFO - 2016-11-14 21:20:25 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:20:25 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:20:25 --> Utf8 Class Initialized
INFO - 2016-11-14 21:20:25 --> URI Class Initialized
INFO - 2016-11-14 21:20:25 --> Router Class Initialized
INFO - 2016-11-14 21:20:25 --> Output Class Initialized
INFO - 2016-11-14 21:20:25 --> Security Class Initialized
DEBUG - 2016-11-14 21:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:20:25 --> Input Class Initialized
INFO - 2016-11-14 21:20:25 --> Language Class Initialized
INFO - 2016-11-14 21:20:25 --> Loader Class Initialized
INFO - 2016-11-14 21:20:25 --> Helper loaded: url_helper
INFO - 2016-11-14 21:20:25 --> Helper loaded: form_helper
INFO - 2016-11-14 21:20:25 --> Database Driver Class Initialized
INFO - 2016-11-14 21:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:20:25 --> Controller Class Initialized
INFO - 2016-11-14 21:20:25 --> Model Class Initialized
INFO - 2016-11-14 21:20:25 --> Config Class Initialized
INFO - 2016-11-14 21:20:25 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:20:25 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:20:25 --> Utf8 Class Initialized
INFO - 2016-11-14 21:20:25 --> URI Class Initialized
INFO - 2016-11-14 21:20:25 --> Router Class Initialized
INFO - 2016-11-14 21:20:25 --> Output Class Initialized
INFO - 2016-11-14 21:20:25 --> Security Class Initialized
DEBUG - 2016-11-14 21:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:20:25 --> Input Class Initialized
INFO - 2016-11-14 21:20:25 --> Language Class Initialized
INFO - 2016-11-14 21:20:25 --> Loader Class Initialized
INFO - 2016-11-14 21:20:25 --> Helper loaded: url_helper
INFO - 2016-11-14 21:20:25 --> Helper loaded: form_helper
INFO - 2016-11-14 21:20:25 --> Database Driver Class Initialized
INFO - 2016-11-14 21:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:20:25 --> Controller Class Initialized
INFO - 2016-11-14 21:20:25 --> Model Class Initialized
INFO - 2016-11-14 21:20:46 --> Config Class Initialized
INFO - 2016-11-14 21:20:46 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:20:46 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:20:46 --> Utf8 Class Initialized
INFO - 2016-11-14 21:20:46 --> URI Class Initialized
INFO - 2016-11-14 21:20:46 --> Router Class Initialized
INFO - 2016-11-14 21:20:46 --> Output Class Initialized
INFO - 2016-11-14 21:20:46 --> Security Class Initialized
DEBUG - 2016-11-14 21:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:20:46 --> Input Class Initialized
INFO - 2016-11-14 21:20:46 --> Language Class Initialized
INFO - 2016-11-14 21:20:46 --> Loader Class Initialized
INFO - 2016-11-14 21:20:46 --> Helper loaded: url_helper
INFO - 2016-11-14 21:20:46 --> Helper loaded: form_helper
INFO - 2016-11-14 21:20:46 --> Database Driver Class Initialized
INFO - 2016-11-14 21:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:20:46 --> Controller Class Initialized
INFO - 2016-11-14 21:20:46 --> Model Class Initialized
INFO - 2016-11-14 21:20:46 --> Model Class Initialized
INFO - 2016-11-14 21:20:46 --> Model Class Initialized
INFO - 2016-11-14 21:20:46 --> Model Class Initialized
DEBUG - 2016-11-14 21:20:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-14 21:20:46 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-14 21:20:46 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-14 21:20:46 --> Config Class Initialized
INFO - 2016-11-14 21:20:46 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:20:46 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:20:46 --> Utf8 Class Initialized
INFO - 2016-11-14 21:20:46 --> URI Class Initialized
DEBUG - 2016-11-14 21:20:46 --> No URI present. Default controller set.
INFO - 2016-11-14 21:20:46 --> Router Class Initialized
INFO - 2016-11-14 21:20:46 --> Output Class Initialized
INFO - 2016-11-14 21:20:46 --> Security Class Initialized
DEBUG - 2016-11-14 21:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:20:46 --> Input Class Initialized
INFO - 2016-11-14 21:20:46 --> Language Class Initialized
INFO - 2016-11-14 21:20:47 --> Loader Class Initialized
INFO - 2016-11-14 21:20:47 --> Helper loaded: url_helper
INFO - 2016-11-14 21:20:47 --> Helper loaded: form_helper
INFO - 2016-11-14 21:20:47 --> Database Driver Class Initialized
INFO - 2016-11-14 21:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:20:47 --> Controller Class Initialized
INFO - 2016-11-14 21:20:47 --> Model Class Initialized
INFO - 2016-11-14 21:20:47 --> Model Class Initialized
INFO - 2016-11-14 21:20:47 --> Model Class Initialized
INFO - 2016-11-14 21:20:47 --> Model Class Initialized
INFO - 2016-11-14 21:20:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:20:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-14 21:20:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:20:47 --> Final output sent to browser
DEBUG - 2016-11-14 21:20:47 --> Total execution time: 0.3392
INFO - 2016-11-14 21:21:11 --> Config Class Initialized
INFO - 2016-11-14 21:21:11 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:21:11 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:21:11 --> Utf8 Class Initialized
INFO - 2016-11-14 21:21:11 --> URI Class Initialized
INFO - 2016-11-14 21:21:11 --> Router Class Initialized
INFO - 2016-11-14 21:21:11 --> Output Class Initialized
INFO - 2016-11-14 21:21:11 --> Security Class Initialized
DEBUG - 2016-11-14 21:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:21:11 --> Input Class Initialized
INFO - 2016-11-14 21:21:11 --> Language Class Initialized
INFO - 2016-11-14 21:21:11 --> Loader Class Initialized
INFO - 2016-11-14 21:21:11 --> Helper loaded: url_helper
INFO - 2016-11-14 21:21:11 --> Helper loaded: form_helper
INFO - 2016-11-14 21:21:11 --> Database Driver Class Initialized
INFO - 2016-11-14 21:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:21:11 --> Controller Class Initialized
INFO - 2016-11-14 21:21:11 --> Model Class Initialized
INFO - 2016-11-14 21:21:11 --> Model Class Initialized
INFO - 2016-11-14 21:21:11 --> Model Class Initialized
INFO - 2016-11-14 21:21:11 --> Model Class Initialized
DEBUG - 2016-11-14 21:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-14 21:21:11 --> Model Class Initialized
INFO - 2016-11-14 21:21:11 --> Final output sent to browser
DEBUG - 2016-11-14 21:21:11 --> Total execution time: 0.2044
INFO - 2016-11-14 21:21:11 --> Config Class Initialized
INFO - 2016-11-14 21:21:11 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:21:11 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:21:11 --> Utf8 Class Initialized
INFO - 2016-11-14 21:21:11 --> URI Class Initialized
DEBUG - 2016-11-14 21:21:11 --> No URI present. Default controller set.
INFO - 2016-11-14 21:21:11 --> Router Class Initialized
INFO - 2016-11-14 21:21:11 --> Output Class Initialized
INFO - 2016-11-14 21:21:11 --> Security Class Initialized
DEBUG - 2016-11-14 21:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:21:11 --> Input Class Initialized
INFO - 2016-11-14 21:21:11 --> Language Class Initialized
INFO - 2016-11-14 21:21:11 --> Loader Class Initialized
INFO - 2016-11-14 21:21:11 --> Helper loaded: url_helper
INFO - 2016-11-14 21:21:11 --> Helper loaded: form_helper
INFO - 2016-11-14 21:21:11 --> Database Driver Class Initialized
INFO - 2016-11-14 21:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:21:11 --> Controller Class Initialized
INFO - 2016-11-14 21:21:11 --> Model Class Initialized
INFO - 2016-11-14 21:21:11 --> Model Class Initialized
INFO - 2016-11-14 21:21:11 --> Model Class Initialized
INFO - 2016-11-14 21:21:11 --> Model Class Initialized
INFO - 2016-11-14 21:21:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:21:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:21:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:21:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-14 21:21:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-14 21:21:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-14 21:21:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-14 21:21:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-14 21:21:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-14 21:21:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:21:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:21:11 --> Final output sent to browser
DEBUG - 2016-11-14 21:21:11 --> Total execution time: 0.3214
INFO - 2016-11-14 21:21:19 --> Config Class Initialized
INFO - 2016-11-14 21:21:19 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:21:19 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:21:19 --> Utf8 Class Initialized
INFO - 2016-11-14 21:21:19 --> URI Class Initialized
INFO - 2016-11-14 21:21:19 --> Router Class Initialized
INFO - 2016-11-14 21:21:19 --> Output Class Initialized
INFO - 2016-11-14 21:21:19 --> Security Class Initialized
DEBUG - 2016-11-14 21:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:21:19 --> Input Class Initialized
INFO - 2016-11-14 21:21:19 --> Language Class Initialized
INFO - 2016-11-14 21:21:19 --> Loader Class Initialized
INFO - 2016-11-14 21:21:19 --> Helper loaded: url_helper
INFO - 2016-11-14 21:21:19 --> Helper loaded: form_helper
INFO - 2016-11-14 21:21:19 --> Database Driver Class Initialized
INFO - 2016-11-14 21:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:21:19 --> Controller Class Initialized
INFO - 2016-11-14 21:21:19 --> Model Class Initialized
INFO - 2016-11-14 21:21:24 --> Config Class Initialized
INFO - 2016-11-14 21:21:24 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:21:24 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:21:24 --> Utf8 Class Initialized
INFO - 2016-11-14 21:21:24 --> URI Class Initialized
INFO - 2016-11-14 21:21:24 --> Router Class Initialized
INFO - 2016-11-14 21:21:24 --> Output Class Initialized
INFO - 2016-11-14 21:21:24 --> Security Class Initialized
DEBUG - 2016-11-14 21:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:21:24 --> Input Class Initialized
INFO - 2016-11-14 21:21:24 --> Language Class Initialized
INFO - 2016-11-14 21:21:24 --> Loader Class Initialized
INFO - 2016-11-14 21:21:24 --> Helper loaded: url_helper
INFO - 2016-11-14 21:21:24 --> Helper loaded: form_helper
INFO - 2016-11-14 21:21:24 --> Database Driver Class Initialized
INFO - 2016-11-14 21:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:21:24 --> Controller Class Initialized
INFO - 2016-11-14 21:21:24 --> Model Class Initialized
INFO - 2016-11-14 21:21:30 --> Config Class Initialized
INFO - 2016-11-14 21:21:30 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:21:30 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:21:30 --> Utf8 Class Initialized
INFO - 2016-11-14 21:21:30 --> URI Class Initialized
INFO - 2016-11-14 21:21:30 --> Router Class Initialized
INFO - 2016-11-14 21:21:30 --> Output Class Initialized
INFO - 2016-11-14 21:21:30 --> Security Class Initialized
DEBUG - 2016-11-14 21:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:21:30 --> Input Class Initialized
INFO - 2016-11-14 21:21:30 --> Language Class Initialized
INFO - 2016-11-14 21:21:30 --> Loader Class Initialized
INFO - 2016-11-14 21:21:30 --> Helper loaded: url_helper
INFO - 2016-11-14 21:21:30 --> Helper loaded: form_helper
INFO - 2016-11-14 21:21:30 --> Database Driver Class Initialized
INFO - 2016-11-14 21:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:21:30 --> Controller Class Initialized
INFO - 2016-11-14 21:21:30 --> Model Class Initialized
INFO - 2016-11-14 21:21:30 --> Config Class Initialized
INFO - 2016-11-14 21:21:30 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:21:30 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:21:30 --> Utf8 Class Initialized
INFO - 2016-11-14 21:21:30 --> URI Class Initialized
INFO - 2016-11-14 21:21:30 --> Router Class Initialized
INFO - 2016-11-14 21:21:30 --> Output Class Initialized
INFO - 2016-11-14 21:21:30 --> Security Class Initialized
DEBUG - 2016-11-14 21:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:21:30 --> Input Class Initialized
INFO - 2016-11-14 21:21:30 --> Language Class Initialized
INFO - 2016-11-14 21:21:30 --> Loader Class Initialized
INFO - 2016-11-14 21:21:30 --> Helper loaded: url_helper
INFO - 2016-11-14 21:21:30 --> Config Class Initialized
INFO - 2016-11-14 21:21:30 --> Helper loaded: form_helper
INFO - 2016-11-14 21:21:30 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:21:30 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:21:30 --> Database Driver Class Initialized
INFO - 2016-11-14 21:21:30 --> Utf8 Class Initialized
INFO - 2016-11-14 21:21:30 --> URI Class Initialized
INFO - 2016-11-14 21:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:21:30 --> Router Class Initialized
INFO - 2016-11-14 21:21:30 --> Controller Class Initialized
INFO - 2016-11-14 21:21:30 --> Model Class Initialized
INFO - 2016-11-14 21:21:30 --> Output Class Initialized
INFO - 2016-11-14 21:21:30 --> Security Class Initialized
DEBUG - 2016-11-14 21:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:21:30 --> Input Class Initialized
INFO - 2016-11-14 21:21:30 --> Language Class Initialized
INFO - 2016-11-14 21:21:30 --> Loader Class Initialized
INFO - 2016-11-14 21:21:30 --> Helper loaded: url_helper
INFO - 2016-11-14 21:21:30 --> Config Class Initialized
INFO - 2016-11-14 21:21:30 --> Helper loaded: form_helper
INFO - 2016-11-14 21:21:30 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:21:30 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:21:30 --> Database Driver Class Initialized
INFO - 2016-11-14 21:21:30 --> Utf8 Class Initialized
INFO - 2016-11-14 21:21:30 --> URI Class Initialized
INFO - 2016-11-14 21:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:21:30 --> Router Class Initialized
INFO - 2016-11-14 21:21:30 --> Controller Class Initialized
INFO - 2016-11-14 21:21:30 --> Model Class Initialized
INFO - 2016-11-14 21:21:30 --> Output Class Initialized
INFO - 2016-11-14 21:21:30 --> Security Class Initialized
DEBUG - 2016-11-14 21:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:21:30 --> Input Class Initialized
INFO - 2016-11-14 21:21:30 --> Language Class Initialized
INFO - 2016-11-14 21:21:30 --> Loader Class Initialized
INFO - 2016-11-14 21:21:30 --> Helper loaded: url_helper
INFO - 2016-11-14 21:21:30 --> Helper loaded: form_helper
INFO - 2016-11-14 21:21:30 --> Database Driver Class Initialized
INFO - 2016-11-14 21:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:21:30 --> Controller Class Initialized
INFO - 2016-11-14 21:21:30 --> Model Class Initialized
INFO - 2016-11-14 21:21:30 --> Config Class Initialized
INFO - 2016-11-14 21:21:30 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:21:30 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:21:30 --> Utf8 Class Initialized
INFO - 2016-11-14 21:21:30 --> URI Class Initialized
INFO - 2016-11-14 21:21:30 --> Router Class Initialized
INFO - 2016-11-14 21:21:30 --> Output Class Initialized
INFO - 2016-11-14 21:21:30 --> Security Class Initialized
DEBUG - 2016-11-14 21:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:21:30 --> Input Class Initialized
INFO - 2016-11-14 21:21:30 --> Language Class Initialized
INFO - 2016-11-14 21:21:30 --> Loader Class Initialized
INFO - 2016-11-14 21:21:30 --> Helper loaded: url_helper
INFO - 2016-11-14 21:21:31 --> Helper loaded: form_helper
INFO - 2016-11-14 21:21:31 --> Database Driver Class Initialized
INFO - 2016-11-14 21:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:21:31 --> Controller Class Initialized
INFO - 2016-11-14 21:21:31 --> Model Class Initialized
INFO - 2016-11-14 21:21:51 --> Config Class Initialized
INFO - 2016-11-14 21:21:51 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:21:51 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:21:51 --> Utf8 Class Initialized
INFO - 2016-11-14 21:21:51 --> URI Class Initialized
INFO - 2016-11-14 21:21:51 --> Router Class Initialized
INFO - 2016-11-14 21:21:51 --> Output Class Initialized
INFO - 2016-11-14 21:21:51 --> Security Class Initialized
DEBUG - 2016-11-14 21:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:21:51 --> Input Class Initialized
INFO - 2016-11-14 21:21:51 --> Language Class Initialized
INFO - 2016-11-14 21:21:51 --> Loader Class Initialized
INFO - 2016-11-14 21:21:51 --> Helper loaded: url_helper
INFO - 2016-11-14 21:21:51 --> Helper loaded: form_helper
INFO - 2016-11-14 21:21:51 --> Database Driver Class Initialized
INFO - 2016-11-14 21:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:21:51 --> Controller Class Initialized
INFO - 2016-11-14 21:21:51 --> Model Class Initialized
INFO - 2016-11-14 21:21:51 --> Model Class Initialized
INFO - 2016-11-14 21:21:51 --> Model Class Initialized
INFO - 2016-11-14 21:21:51 --> Model Class Initialized
DEBUG - 2016-11-14 21:21:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-14 21:21:51 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-14 21:21:51 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-14 21:21:51 --> Config Class Initialized
INFO - 2016-11-14 21:21:51 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:21:51 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:21:51 --> Utf8 Class Initialized
INFO - 2016-11-14 21:21:51 --> URI Class Initialized
DEBUG - 2016-11-14 21:21:51 --> No URI present. Default controller set.
INFO - 2016-11-14 21:21:51 --> Router Class Initialized
INFO - 2016-11-14 21:21:51 --> Output Class Initialized
INFO - 2016-11-14 21:21:51 --> Security Class Initialized
DEBUG - 2016-11-14 21:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:21:51 --> Input Class Initialized
INFO - 2016-11-14 21:21:51 --> Language Class Initialized
INFO - 2016-11-14 21:21:51 --> Loader Class Initialized
INFO - 2016-11-14 21:21:51 --> Helper loaded: url_helper
INFO - 2016-11-14 21:21:51 --> Helper loaded: form_helper
INFO - 2016-11-14 21:21:51 --> Database Driver Class Initialized
INFO - 2016-11-14 21:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:21:51 --> Controller Class Initialized
INFO - 2016-11-14 21:21:51 --> Model Class Initialized
INFO - 2016-11-14 21:21:51 --> Model Class Initialized
INFO - 2016-11-14 21:21:51 --> Model Class Initialized
INFO - 2016-11-14 21:21:51 --> Model Class Initialized
INFO - 2016-11-14 21:21:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:21:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-14 21:21:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:21:52 --> Final output sent to browser
DEBUG - 2016-11-14 21:21:52 --> Total execution time: 0.3359
INFO - 2016-11-14 21:22:04 --> Config Class Initialized
INFO - 2016-11-14 21:22:04 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:22:04 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:22:04 --> Utf8 Class Initialized
INFO - 2016-11-14 21:22:04 --> URI Class Initialized
INFO - 2016-11-14 21:22:04 --> Router Class Initialized
INFO - 2016-11-14 21:22:04 --> Output Class Initialized
INFO - 2016-11-14 21:22:04 --> Security Class Initialized
DEBUG - 2016-11-14 21:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:22:04 --> Input Class Initialized
INFO - 2016-11-14 21:22:04 --> Language Class Initialized
INFO - 2016-11-14 21:22:04 --> Loader Class Initialized
INFO - 2016-11-14 21:22:04 --> Helper loaded: url_helper
INFO - 2016-11-14 21:22:04 --> Helper loaded: form_helper
INFO - 2016-11-14 21:22:04 --> Database Driver Class Initialized
INFO - 2016-11-14 21:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:22:04 --> Controller Class Initialized
INFO - 2016-11-14 21:22:04 --> Model Class Initialized
INFO - 2016-11-14 21:22:04 --> Model Class Initialized
INFO - 2016-11-14 21:22:04 --> Model Class Initialized
INFO - 2016-11-14 21:22:04 --> Model Class Initialized
DEBUG - 2016-11-14 21:22:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-14 21:22:04 --> Model Class Initialized
INFO - 2016-11-14 21:22:04 --> Final output sent to browser
DEBUG - 2016-11-14 21:22:04 --> Total execution time: 0.2597
INFO - 2016-11-14 21:22:04 --> Config Class Initialized
INFO - 2016-11-14 21:22:04 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:22:04 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:22:04 --> Utf8 Class Initialized
INFO - 2016-11-14 21:22:04 --> URI Class Initialized
DEBUG - 2016-11-14 21:22:04 --> No URI present. Default controller set.
INFO - 2016-11-14 21:22:04 --> Router Class Initialized
INFO - 2016-11-14 21:22:04 --> Output Class Initialized
INFO - 2016-11-14 21:22:04 --> Security Class Initialized
DEBUG - 2016-11-14 21:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:22:04 --> Input Class Initialized
INFO - 2016-11-14 21:22:04 --> Language Class Initialized
INFO - 2016-11-14 21:22:04 --> Loader Class Initialized
INFO - 2016-11-14 21:22:05 --> Helper loaded: url_helper
INFO - 2016-11-14 21:22:05 --> Helper loaded: form_helper
INFO - 2016-11-14 21:22:05 --> Database Driver Class Initialized
INFO - 2016-11-14 21:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:22:05 --> Controller Class Initialized
INFO - 2016-11-14 21:22:05 --> Model Class Initialized
INFO - 2016-11-14 21:22:05 --> Model Class Initialized
INFO - 2016-11-14 21:22:05 --> Model Class Initialized
INFO - 2016-11-14 21:22:05 --> Model Class Initialized
INFO - 2016-11-14 21:22:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:22:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:22:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:22:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:22:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:22:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:22:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:22:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:22:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:22:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:22:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:22:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:22:05 --> Final output sent to browser
DEBUG - 2016-11-14 21:22:05 --> Total execution time: 0.3832
INFO - 2016-11-14 21:23:04 --> Config Class Initialized
INFO - 2016-11-14 21:23:04 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:23:04 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:23:04 --> Utf8 Class Initialized
INFO - 2016-11-14 21:23:04 --> URI Class Initialized
INFO - 2016-11-14 21:23:04 --> Router Class Initialized
INFO - 2016-11-14 21:23:04 --> Output Class Initialized
INFO - 2016-11-14 21:23:04 --> Security Class Initialized
DEBUG - 2016-11-14 21:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:23:04 --> Input Class Initialized
INFO - 2016-11-14 21:23:04 --> Language Class Initialized
INFO - 2016-11-14 21:23:04 --> Loader Class Initialized
INFO - 2016-11-14 21:23:04 --> Helper loaded: url_helper
INFO - 2016-11-14 21:23:04 --> Helper loaded: form_helper
INFO - 2016-11-14 21:23:04 --> Database Driver Class Initialized
INFO - 2016-11-14 21:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:23:04 --> Controller Class Initialized
INFO - 2016-11-14 21:23:04 --> Model Class Initialized
INFO - 2016-11-14 21:23:05 --> Config Class Initialized
INFO - 2016-11-14 21:23:05 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:23:05 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:23:05 --> Utf8 Class Initialized
INFO - 2016-11-14 21:23:05 --> URI Class Initialized
INFO - 2016-11-14 21:23:05 --> Router Class Initialized
INFO - 2016-11-14 21:23:05 --> Output Class Initialized
INFO - 2016-11-14 21:23:05 --> Security Class Initialized
DEBUG - 2016-11-14 21:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:23:05 --> Input Class Initialized
INFO - 2016-11-14 21:23:05 --> Language Class Initialized
INFO - 2016-11-14 21:23:05 --> Loader Class Initialized
INFO - 2016-11-14 21:23:05 --> Helper loaded: url_helper
INFO - 2016-11-14 21:23:05 --> Helper loaded: form_helper
INFO - 2016-11-14 21:23:05 --> Database Driver Class Initialized
INFO - 2016-11-14 21:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:23:05 --> Controller Class Initialized
INFO - 2016-11-14 21:23:05 --> Model Class Initialized
INFO - 2016-11-14 21:23:39 --> Config Class Initialized
INFO - 2016-11-14 21:23:39 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:23:39 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:23:39 --> Utf8 Class Initialized
INFO - 2016-11-14 21:23:39 --> URI Class Initialized
DEBUG - 2016-11-14 21:23:39 --> No URI present. Default controller set.
INFO - 2016-11-14 21:23:39 --> Router Class Initialized
INFO - 2016-11-14 21:23:39 --> Output Class Initialized
INFO - 2016-11-14 21:23:39 --> Security Class Initialized
DEBUG - 2016-11-14 21:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:23:39 --> Input Class Initialized
INFO - 2016-11-14 21:23:39 --> Language Class Initialized
INFO - 2016-11-14 21:23:39 --> Loader Class Initialized
INFO - 2016-11-14 21:23:39 --> Helper loaded: url_helper
INFO - 2016-11-14 21:23:39 --> Helper loaded: form_helper
INFO - 2016-11-14 21:23:39 --> Database Driver Class Initialized
INFO - 2016-11-14 21:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:23:39 --> Controller Class Initialized
INFO - 2016-11-14 21:23:39 --> Model Class Initialized
INFO - 2016-11-14 21:23:39 --> Model Class Initialized
INFO - 2016-11-14 21:23:39 --> Model Class Initialized
INFO - 2016-11-14 21:23:39 --> Model Class Initialized
INFO - 2016-11-14 21:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:23:39 --> Final output sent to browser
DEBUG - 2016-11-14 21:23:39 --> Total execution time: 0.3914
INFO - 2016-11-14 21:23:43 --> Config Class Initialized
INFO - 2016-11-14 21:23:43 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:23:43 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:23:43 --> Utf8 Class Initialized
INFO - 2016-11-14 21:23:43 --> URI Class Initialized
INFO - 2016-11-14 21:23:43 --> Router Class Initialized
INFO - 2016-11-14 21:23:43 --> Output Class Initialized
INFO - 2016-11-14 21:23:43 --> Security Class Initialized
DEBUG - 2016-11-14 21:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:23:43 --> Input Class Initialized
INFO - 2016-11-14 21:23:43 --> Language Class Initialized
INFO - 2016-11-14 21:23:43 --> Loader Class Initialized
INFO - 2016-11-14 21:23:43 --> Helper loaded: url_helper
INFO - 2016-11-14 21:23:43 --> Helper loaded: form_helper
INFO - 2016-11-14 21:23:43 --> Database Driver Class Initialized
INFO - 2016-11-14 21:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:23:43 --> Controller Class Initialized
INFO - 2016-11-14 21:23:43 --> Model Class Initialized
INFO - 2016-11-14 21:23:47 --> Config Class Initialized
INFO - 2016-11-14 21:23:47 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:23:47 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:23:47 --> Utf8 Class Initialized
INFO - 2016-11-14 21:23:47 --> URI Class Initialized
INFO - 2016-11-14 21:23:47 --> Router Class Initialized
INFO - 2016-11-14 21:23:47 --> Output Class Initialized
INFO - 2016-11-14 21:23:47 --> Security Class Initialized
DEBUG - 2016-11-14 21:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:23:47 --> Input Class Initialized
INFO - 2016-11-14 21:23:47 --> Language Class Initialized
INFO - 2016-11-14 21:23:47 --> Loader Class Initialized
INFO - 2016-11-14 21:23:47 --> Helper loaded: url_helper
INFO - 2016-11-14 21:23:47 --> Helper loaded: form_helper
INFO - 2016-11-14 21:23:47 --> Database Driver Class Initialized
INFO - 2016-11-14 21:23:47 --> Config Class Initialized
INFO - 2016-11-14 21:23:47 --> Hooks Class Initialized
INFO - 2016-11-14 21:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:23:47 --> Controller Class Initialized
DEBUG - 2016-11-14 21:23:47 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:23:47 --> Model Class Initialized
INFO - 2016-11-14 21:23:47 --> Utf8 Class Initialized
INFO - 2016-11-14 21:23:47 --> URI Class Initialized
INFO - 2016-11-14 21:23:47 --> Router Class Initialized
INFO - 2016-11-14 21:23:47 --> Output Class Initialized
INFO - 2016-11-14 21:23:47 --> Security Class Initialized
INFO - 2016-11-14 21:23:47 --> Config Class Initialized
DEBUG - 2016-11-14 21:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:23:47 --> Hooks Class Initialized
INFO - 2016-11-14 21:23:47 --> Input Class Initialized
DEBUG - 2016-11-14 21:23:47 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:23:47 --> Language Class Initialized
INFO - 2016-11-14 21:23:47 --> Utf8 Class Initialized
INFO - 2016-11-14 21:23:47 --> URI Class Initialized
INFO - 2016-11-14 21:23:47 --> Loader Class Initialized
INFO - 2016-11-14 21:23:47 --> Router Class Initialized
INFO - 2016-11-14 21:23:47 --> Helper loaded: url_helper
INFO - 2016-11-14 21:23:47 --> Output Class Initialized
INFO - 2016-11-14 21:23:47 --> Helper loaded: form_helper
INFO - 2016-11-14 21:23:47 --> Security Class Initialized
INFO - 2016-11-14 21:23:47 --> Database Driver Class Initialized
DEBUG - 2016-11-14 21:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:23:47 --> Input Class Initialized
INFO - 2016-11-14 21:23:47 --> Controller Class Initialized
INFO - 2016-11-14 21:23:47 --> Config Class Initialized
INFO - 2016-11-14 21:23:47 --> Model Class Initialized
INFO - 2016-11-14 21:23:47 --> Language Class Initialized
INFO - 2016-11-14 21:23:47 --> Hooks Class Initialized
INFO - 2016-11-14 21:23:47 --> Loader Class Initialized
DEBUG - 2016-11-14 21:23:47 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:23:47 --> Helper loaded: url_helper
INFO - 2016-11-14 21:23:47 --> Utf8 Class Initialized
INFO - 2016-11-14 21:23:47 --> URI Class Initialized
INFO - 2016-11-14 21:23:47 --> Helper loaded: form_helper
INFO - 2016-11-14 21:23:47 --> Router Class Initialized
INFO - 2016-11-14 21:23:47 --> Database Driver Class Initialized
INFO - 2016-11-14 21:23:47 --> Output Class Initialized
INFO - 2016-11-14 21:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:23:47 --> Security Class Initialized
INFO - 2016-11-14 21:23:47 --> Controller Class Initialized
INFO - 2016-11-14 21:23:47 --> Model Class Initialized
DEBUG - 2016-11-14 21:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:23:47 --> Config Class Initialized
INFO - 2016-11-14 21:23:47 --> Input Class Initialized
INFO - 2016-11-14 21:23:47 --> Hooks Class Initialized
INFO - 2016-11-14 21:23:47 --> Language Class Initialized
DEBUG - 2016-11-14 21:23:47 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:23:47 --> Loader Class Initialized
INFO - 2016-11-14 21:23:47 --> Utf8 Class Initialized
INFO - 2016-11-14 21:23:47 --> URI Class Initialized
INFO - 2016-11-14 21:23:47 --> Helper loaded: url_helper
INFO - 2016-11-14 21:23:47 --> Router Class Initialized
INFO - 2016-11-14 21:23:47 --> Helper loaded: form_helper
INFO - 2016-11-14 21:23:47 --> Output Class Initialized
INFO - 2016-11-14 21:23:47 --> Database Driver Class Initialized
INFO - 2016-11-14 21:23:47 --> Security Class Initialized
INFO - 2016-11-14 21:23:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-14 21:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:23:47 --> Controller Class Initialized
INFO - 2016-11-14 21:23:47 --> Input Class Initialized
INFO - 2016-11-14 21:23:48 --> Model Class Initialized
INFO - 2016-11-14 21:23:48 --> Config Class Initialized
INFO - 2016-11-14 21:23:48 --> Language Class Initialized
INFO - 2016-11-14 21:23:48 --> Hooks Class Initialized
INFO - 2016-11-14 21:23:48 --> Loader Class Initialized
DEBUG - 2016-11-14 21:23:48 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:23:48 --> Helper loaded: url_helper
INFO - 2016-11-14 21:23:48 --> Utf8 Class Initialized
INFO - 2016-11-14 21:23:48 --> URI Class Initialized
INFO - 2016-11-14 21:23:48 --> Helper loaded: form_helper
INFO - 2016-11-14 21:23:48 --> Router Class Initialized
INFO - 2016-11-14 21:23:48 --> Database Driver Class Initialized
INFO - 2016-11-14 21:23:48 --> Output Class Initialized
INFO - 2016-11-14 21:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:23:48 --> Security Class Initialized
INFO - 2016-11-14 21:23:48 --> Controller Class Initialized
INFO - 2016-11-14 21:23:48 --> Model Class Initialized
DEBUG - 2016-11-14 21:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:23:48 --> Input Class Initialized
INFO - 2016-11-14 21:23:48 --> Language Class Initialized
INFO - 2016-11-14 21:23:48 --> Loader Class Initialized
INFO - 2016-11-14 21:23:48 --> Config Class Initialized
INFO - 2016-11-14 21:23:48 --> Helper loaded: url_helper
INFO - 2016-11-14 21:23:48 --> Hooks Class Initialized
INFO - 2016-11-14 21:23:48 --> Helper loaded: form_helper
DEBUG - 2016-11-14 21:23:48 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:23:48 --> Database Driver Class Initialized
INFO - 2016-11-14 21:23:48 --> Utf8 Class Initialized
INFO - 2016-11-14 21:23:48 --> URI Class Initialized
INFO - 2016-11-14 21:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:23:48 --> Router Class Initialized
INFO - 2016-11-14 21:23:48 --> Controller Class Initialized
INFO - 2016-11-14 21:23:48 --> Model Class Initialized
INFO - 2016-11-14 21:23:48 --> Output Class Initialized
INFO - 2016-11-14 21:23:48 --> Security Class Initialized
DEBUG - 2016-11-14 21:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:23:48 --> Input Class Initialized
INFO - 2016-11-14 21:23:48 --> Language Class Initialized
INFO - 2016-11-14 21:23:48 --> Loader Class Initialized
INFO - 2016-11-14 21:23:48 --> Config Class Initialized
INFO - 2016-11-14 21:23:48 --> Helper loaded: url_helper
INFO - 2016-11-14 21:23:48 --> Hooks Class Initialized
INFO - 2016-11-14 21:23:48 --> Helper loaded: form_helper
DEBUG - 2016-11-14 21:23:48 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:23:48 --> Utf8 Class Initialized
INFO - 2016-11-14 21:23:48 --> Database Driver Class Initialized
INFO - 2016-11-14 21:23:48 --> URI Class Initialized
INFO - 2016-11-14 21:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:23:48 --> Router Class Initialized
INFO - 2016-11-14 21:23:48 --> Controller Class Initialized
INFO - 2016-11-14 21:23:48 --> Model Class Initialized
INFO - 2016-11-14 21:23:48 --> Output Class Initialized
INFO - 2016-11-14 21:23:48 --> Security Class Initialized
DEBUG - 2016-11-14 21:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:23:48 --> Input Class Initialized
INFO - 2016-11-14 21:23:48 --> Language Class Initialized
INFO - 2016-11-14 21:23:48 --> Loader Class Initialized
INFO - 2016-11-14 21:23:48 --> Helper loaded: url_helper
INFO - 2016-11-14 21:23:48 --> Helper loaded: form_helper
INFO - 2016-11-14 21:23:48 --> Config Class Initialized
INFO - 2016-11-14 21:23:48 --> Database Driver Class Initialized
INFO - 2016-11-14 21:23:48 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:23:48 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:23:48 --> Utf8 Class Initialized
INFO - 2016-11-14 21:23:48 --> Controller Class Initialized
INFO - 2016-11-14 21:23:48 --> URI Class Initialized
INFO - 2016-11-14 21:23:48 --> Model Class Initialized
INFO - 2016-11-14 21:23:48 --> Router Class Initialized
INFO - 2016-11-14 21:23:48 --> Output Class Initialized
INFO - 2016-11-14 21:23:48 --> Security Class Initialized
DEBUG - 2016-11-14 21:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:23:48 --> Input Class Initialized
INFO - 2016-11-14 21:23:48 --> Language Class Initialized
INFO - 2016-11-14 21:23:48 --> Loader Class Initialized
INFO - 2016-11-14 21:23:48 --> Helper loaded: url_helper
INFO - 2016-11-14 21:23:48 --> Helper loaded: form_helper
INFO - 2016-11-14 21:23:48 --> Database Driver Class Initialized
INFO - 2016-11-14 21:23:48 --> Config Class Initialized
INFO - 2016-11-14 21:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:23:48 --> Hooks Class Initialized
INFO - 2016-11-14 21:23:48 --> Controller Class Initialized
DEBUG - 2016-11-14 21:23:48 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:23:48 --> Model Class Initialized
INFO - 2016-11-14 21:23:48 --> Utf8 Class Initialized
INFO - 2016-11-14 21:23:48 --> URI Class Initialized
INFO - 2016-11-14 21:23:48 --> Router Class Initialized
INFO - 2016-11-14 21:23:48 --> Output Class Initialized
INFO - 2016-11-14 21:23:48 --> Security Class Initialized
DEBUG - 2016-11-14 21:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:23:48 --> Input Class Initialized
INFO - 2016-11-14 21:23:48 --> Language Class Initialized
INFO - 2016-11-14 21:23:48 --> Loader Class Initialized
INFO - 2016-11-14 21:23:48 --> Helper loaded: url_helper
INFO - 2016-11-14 21:23:48 --> Helper loaded: form_helper
INFO - 2016-11-14 21:23:48 --> Database Driver Class Initialized
INFO - 2016-11-14 21:23:48 --> Config Class Initialized
INFO - 2016-11-14 21:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:23:48 --> Hooks Class Initialized
INFO - 2016-11-14 21:23:48 --> Controller Class Initialized
DEBUG - 2016-11-14 21:23:48 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:23:48 --> Model Class Initialized
INFO - 2016-11-14 21:23:48 --> Utf8 Class Initialized
INFO - 2016-11-14 21:23:48 --> URI Class Initialized
INFO - 2016-11-14 21:23:48 --> Router Class Initialized
INFO - 2016-11-14 21:23:48 --> Output Class Initialized
INFO - 2016-11-14 21:23:48 --> Security Class Initialized
DEBUG - 2016-11-14 21:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:23:48 --> Input Class Initialized
INFO - 2016-11-14 21:23:48 --> Language Class Initialized
INFO - 2016-11-14 21:23:48 --> Loader Class Initialized
INFO - 2016-11-14 21:23:48 --> Helper loaded: url_helper
INFO - 2016-11-14 21:23:48 --> Helper loaded: form_helper
INFO - 2016-11-14 21:23:48 --> Config Class Initialized
INFO - 2016-11-14 21:23:49 --> Database Driver Class Initialized
INFO - 2016-11-14 21:23:49 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:23:49 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:23:49 --> Utf8 Class Initialized
INFO - 2016-11-14 21:23:49 --> Controller Class Initialized
INFO - 2016-11-14 21:23:49 --> URI Class Initialized
INFO - 2016-11-14 21:23:49 --> Model Class Initialized
INFO - 2016-11-14 21:23:49 --> Router Class Initialized
INFO - 2016-11-14 21:23:49 --> Output Class Initialized
INFO - 2016-11-14 21:23:49 --> Security Class Initialized
DEBUG - 2016-11-14 21:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:23:49 --> Input Class Initialized
INFO - 2016-11-14 21:23:49 --> Language Class Initialized
INFO - 2016-11-14 21:23:49 --> Loader Class Initialized
INFO - 2016-11-14 21:23:49 --> Helper loaded: url_helper
INFO - 2016-11-14 21:23:49 --> Helper loaded: form_helper
INFO - 2016-11-14 21:23:49 --> Database Driver Class Initialized
INFO - 2016-11-14 21:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:23:49 --> Controller Class Initialized
INFO - 2016-11-14 21:23:49 --> Model Class Initialized
INFO - 2016-11-14 21:26:21 --> Config Class Initialized
INFO - 2016-11-14 21:26:21 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:26:21 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:26:21 --> Utf8 Class Initialized
INFO - 2016-11-14 21:26:21 --> URI Class Initialized
DEBUG - 2016-11-14 21:26:21 --> No URI present. Default controller set.
INFO - 2016-11-14 21:26:21 --> Router Class Initialized
INFO - 2016-11-14 21:26:21 --> Output Class Initialized
INFO - 2016-11-14 21:26:21 --> Security Class Initialized
DEBUG - 2016-11-14 21:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:26:21 --> Input Class Initialized
INFO - 2016-11-14 21:26:21 --> Language Class Initialized
INFO - 2016-11-14 21:26:21 --> Loader Class Initialized
INFO - 2016-11-14 21:26:21 --> Helper loaded: url_helper
INFO - 2016-11-14 21:26:21 --> Helper loaded: form_helper
INFO - 2016-11-14 21:26:21 --> Database Driver Class Initialized
INFO - 2016-11-14 21:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:26:21 --> Controller Class Initialized
INFO - 2016-11-14 21:26:22 --> Model Class Initialized
INFO - 2016-11-14 21:26:22 --> Model Class Initialized
INFO - 2016-11-14 21:26:22 --> Model Class Initialized
INFO - 2016-11-14 21:26:22 --> Model Class Initialized
INFO - 2016-11-14 21:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:26:22 --> Final output sent to browser
DEBUG - 2016-11-14 21:26:22 --> Total execution time: 0.4102
INFO - 2016-11-14 21:26:27 --> Config Class Initialized
INFO - 2016-11-14 21:26:27 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:26:27 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:26:27 --> Utf8 Class Initialized
INFO - 2016-11-14 21:26:27 --> URI Class Initialized
INFO - 2016-11-14 21:26:27 --> Router Class Initialized
INFO - 2016-11-14 21:26:27 --> Output Class Initialized
INFO - 2016-11-14 21:26:27 --> Security Class Initialized
DEBUG - 2016-11-14 21:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:26:27 --> Input Class Initialized
INFO - 2016-11-14 21:26:27 --> Language Class Initialized
INFO - 2016-11-14 21:26:27 --> Loader Class Initialized
INFO - 2016-11-14 21:26:27 --> Helper loaded: url_helper
INFO - 2016-11-14 21:26:27 --> Helper loaded: form_helper
INFO - 2016-11-14 21:26:27 --> Database Driver Class Initialized
INFO - 2016-11-14 21:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:26:27 --> Controller Class Initialized
INFO - 2016-11-14 21:26:27 --> Model Class Initialized
INFO - 2016-11-14 21:26:30 --> Config Class Initialized
INFO - 2016-11-14 21:26:30 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:26:30 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:26:30 --> Utf8 Class Initialized
INFO - 2016-11-14 21:26:30 --> URI Class Initialized
INFO - 2016-11-14 21:26:30 --> Router Class Initialized
INFO - 2016-11-14 21:26:30 --> Output Class Initialized
INFO - 2016-11-14 21:26:30 --> Security Class Initialized
DEBUG - 2016-11-14 21:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:26:30 --> Input Class Initialized
INFO - 2016-11-14 21:26:30 --> Language Class Initialized
INFO - 2016-11-14 21:26:30 --> Loader Class Initialized
INFO - 2016-11-14 21:26:30 --> Helper loaded: url_helper
INFO - 2016-11-14 21:26:30 --> Helper loaded: form_helper
INFO - 2016-11-14 21:26:30 --> Database Driver Class Initialized
INFO - 2016-11-14 21:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:26:30 --> Controller Class Initialized
INFO - 2016-11-14 21:26:30 --> Model Class Initialized
INFO - 2016-11-14 21:26:47 --> Config Class Initialized
INFO - 2016-11-14 21:26:47 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:26:47 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:26:47 --> Utf8 Class Initialized
INFO - 2016-11-14 21:26:47 --> URI Class Initialized
INFO - 2016-11-14 21:26:47 --> Router Class Initialized
INFO - 2016-11-14 21:26:47 --> Output Class Initialized
INFO - 2016-11-14 21:26:47 --> Security Class Initialized
DEBUG - 2016-11-14 21:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:26:47 --> Input Class Initialized
INFO - 2016-11-14 21:26:47 --> Language Class Initialized
INFO - 2016-11-14 21:26:47 --> Loader Class Initialized
INFO - 2016-11-14 21:26:47 --> Helper loaded: url_helper
INFO - 2016-11-14 21:26:47 --> Helper loaded: form_helper
INFO - 2016-11-14 21:26:47 --> Database Driver Class Initialized
INFO - 2016-11-14 21:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:26:47 --> Controller Class Initialized
INFO - 2016-11-14 21:26:47 --> Model Class Initialized
INFO - 2016-11-14 21:26:47 --> Config Class Initialized
INFO - 2016-11-14 21:26:47 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:26:47 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:26:47 --> Utf8 Class Initialized
INFO - 2016-11-14 21:26:47 --> URI Class Initialized
INFO - 2016-11-14 21:26:47 --> Router Class Initialized
INFO - 2016-11-14 21:26:47 --> Output Class Initialized
INFO - 2016-11-14 21:26:47 --> Security Class Initialized
DEBUG - 2016-11-14 21:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:26:47 --> Input Class Initialized
INFO - 2016-11-14 21:26:48 --> Language Class Initialized
INFO - 2016-11-14 21:26:48 --> Loader Class Initialized
INFO - 2016-11-14 21:26:48 --> Helper loaded: url_helper
INFO - 2016-11-14 21:26:48 --> Helper loaded: form_helper
INFO - 2016-11-14 21:26:48 --> Database Driver Class Initialized
INFO - 2016-11-14 21:26:48 --> Config Class Initialized
INFO - 2016-11-14 21:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:26:48 --> Hooks Class Initialized
INFO - 2016-11-14 21:26:48 --> Controller Class Initialized
DEBUG - 2016-11-14 21:26:48 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:26:48 --> Model Class Initialized
INFO - 2016-11-14 21:26:48 --> Utf8 Class Initialized
INFO - 2016-11-14 21:26:48 --> URI Class Initialized
INFO - 2016-11-14 21:26:48 --> Router Class Initialized
INFO - 2016-11-14 21:26:48 --> Output Class Initialized
INFO - 2016-11-14 21:26:48 --> Security Class Initialized
DEBUG - 2016-11-14 21:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:26:48 --> Input Class Initialized
INFO - 2016-11-14 21:26:48 --> Language Class Initialized
INFO - 2016-11-14 21:26:48 --> Loader Class Initialized
INFO - 2016-11-14 21:26:48 --> Helper loaded: url_helper
INFO - 2016-11-14 21:26:48 --> Helper loaded: form_helper
INFO - 2016-11-14 21:26:48 --> Database Driver Class Initialized
INFO - 2016-11-14 21:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:26:48 --> Controller Class Initialized
INFO - 2016-11-14 21:26:48 --> Model Class Initialized
INFO - 2016-11-14 21:26:49 --> Config Class Initialized
INFO - 2016-11-14 21:26:49 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:26:49 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:26:49 --> Utf8 Class Initialized
INFO - 2016-11-14 21:26:49 --> URI Class Initialized
INFO - 2016-11-14 21:26:49 --> Router Class Initialized
INFO - 2016-11-14 21:26:49 --> Output Class Initialized
INFO - 2016-11-14 21:26:49 --> Security Class Initialized
DEBUG - 2016-11-14 21:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:26:49 --> Input Class Initialized
INFO - 2016-11-14 21:26:49 --> Language Class Initialized
INFO - 2016-11-14 21:26:49 --> Loader Class Initialized
INFO - 2016-11-14 21:26:49 --> Helper loaded: url_helper
INFO - 2016-11-14 21:26:49 --> Helper loaded: form_helper
INFO - 2016-11-14 21:26:50 --> Database Driver Class Initialized
INFO - 2016-11-14 21:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:26:50 --> Controller Class Initialized
INFO - 2016-11-14 21:26:50 --> Model Class Initialized
INFO - 2016-11-14 21:27:30 --> Config Class Initialized
INFO - 2016-11-14 21:27:30 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:27:30 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:27:30 --> Utf8 Class Initialized
INFO - 2016-11-14 21:27:30 --> URI Class Initialized
INFO - 2016-11-14 21:27:30 --> Router Class Initialized
INFO - 2016-11-14 21:27:30 --> Output Class Initialized
INFO - 2016-11-14 21:27:30 --> Security Class Initialized
DEBUG - 2016-11-14 21:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:27:30 --> Input Class Initialized
INFO - 2016-11-14 21:27:30 --> Language Class Initialized
INFO - 2016-11-14 21:27:30 --> Loader Class Initialized
INFO - 2016-11-14 21:27:30 --> Helper loaded: url_helper
INFO - 2016-11-14 21:27:30 --> Helper loaded: form_helper
INFO - 2016-11-14 21:27:30 --> Config Class Initialized
INFO - 2016-11-14 21:27:30 --> Database Driver Class Initialized
INFO - 2016-11-14 21:27:30 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:27:30 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:27:30 --> Utf8 Class Initialized
INFO - 2016-11-14 21:27:30 --> Controller Class Initialized
INFO - 2016-11-14 21:27:30 --> URI Class Initialized
INFO - 2016-11-14 21:27:30 --> Model Class Initialized
INFO - 2016-11-14 21:27:30 --> Router Class Initialized
INFO - 2016-11-14 21:27:30 --> Output Class Initialized
INFO - 2016-11-14 21:27:30 --> Security Class Initialized
DEBUG - 2016-11-14 21:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:27:30 --> Input Class Initialized
INFO - 2016-11-14 21:27:30 --> Config Class Initialized
INFO - 2016-11-14 21:27:30 --> Hooks Class Initialized
INFO - 2016-11-14 21:27:30 --> Language Class Initialized
INFO - 2016-11-14 21:27:30 --> Loader Class Initialized
DEBUG - 2016-11-14 21:27:30 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:27:30 --> Utf8 Class Initialized
INFO - 2016-11-14 21:27:30 --> Helper loaded: url_helper
INFO - 2016-11-14 21:27:30 --> URI Class Initialized
INFO - 2016-11-14 21:27:30 --> Helper loaded: form_helper
INFO - 2016-11-14 21:27:30 --> Router Class Initialized
INFO - 2016-11-14 21:27:30 --> Database Driver Class Initialized
INFO - 2016-11-14 21:27:30 --> Output Class Initialized
INFO - 2016-11-14 21:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:27:30 --> Security Class Initialized
INFO - 2016-11-14 21:27:30 --> Controller Class Initialized
INFO - 2016-11-14 21:27:30 --> Model Class Initialized
DEBUG - 2016-11-14 21:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:27:30 --> Input Class Initialized
INFO - 2016-11-14 21:27:30 --> Language Class Initialized
INFO - 2016-11-14 21:27:30 --> Config Class Initialized
INFO - 2016-11-14 21:27:30 --> Loader Class Initialized
INFO - 2016-11-14 21:27:30 --> Hooks Class Initialized
INFO - 2016-11-14 21:27:30 --> Helper loaded: url_helper
DEBUG - 2016-11-14 21:27:30 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:27:30 --> Helper loaded: form_helper
INFO - 2016-11-14 21:27:30 --> Utf8 Class Initialized
INFO - 2016-11-14 21:27:30 --> URI Class Initialized
INFO - 2016-11-14 21:27:30 --> Database Driver Class Initialized
INFO - 2016-11-14 21:27:30 --> Router Class Initialized
INFO - 2016-11-14 21:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:27:30 --> Output Class Initialized
INFO - 2016-11-14 21:27:30 --> Controller Class Initialized
INFO - 2016-11-14 21:27:30 --> Model Class Initialized
INFO - 2016-11-14 21:27:30 --> Security Class Initialized
INFO - 2016-11-14 21:27:30 --> Config Class Initialized
DEBUG - 2016-11-14 21:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:27:30 --> Hooks Class Initialized
INFO - 2016-11-14 21:27:30 --> Input Class Initialized
DEBUG - 2016-11-14 21:27:30 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:27:30 --> Language Class Initialized
INFO - 2016-11-14 21:27:30 --> Utf8 Class Initialized
INFO - 2016-11-14 21:27:30 --> URI Class Initialized
INFO - 2016-11-14 21:27:30 --> Loader Class Initialized
INFO - 2016-11-14 21:27:30 --> Router Class Initialized
INFO - 2016-11-14 21:27:30 --> Helper loaded: url_helper
INFO - 2016-11-14 21:27:30 --> Output Class Initialized
INFO - 2016-11-14 21:27:30 --> Helper loaded: form_helper
INFO - 2016-11-14 21:27:30 --> Security Class Initialized
INFO - 2016-11-14 21:27:30 --> Database Driver Class Initialized
DEBUG - 2016-11-14 21:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:27:30 --> Input Class Initialized
INFO - 2016-11-14 21:27:30 --> Controller Class Initialized
INFO - 2016-11-14 21:27:30 --> Language Class Initialized
INFO - 2016-11-14 21:27:30 --> Model Class Initialized
INFO - 2016-11-14 21:27:30 --> Loader Class Initialized
INFO - 2016-11-14 21:27:30 --> Helper loaded: url_helper
INFO - 2016-11-14 21:27:30 --> Helper loaded: form_helper
INFO - 2016-11-14 21:27:30 --> Database Driver Class Initialized
INFO - 2016-11-14 21:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:27:30 --> Controller Class Initialized
INFO - 2016-11-14 21:27:30 --> Model Class Initialized
INFO - 2016-11-14 21:27:56 --> Config Class Initialized
INFO - 2016-11-14 21:27:56 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:27:56 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:27:56 --> Utf8 Class Initialized
INFO - 2016-11-14 21:27:56 --> URI Class Initialized
DEBUG - 2016-11-14 21:27:56 --> No URI present. Default controller set.
INFO - 2016-11-14 21:27:56 --> Router Class Initialized
INFO - 2016-11-14 21:27:56 --> Output Class Initialized
INFO - 2016-11-14 21:27:56 --> Security Class Initialized
DEBUG - 2016-11-14 21:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:27:56 --> Input Class Initialized
INFO - 2016-11-14 21:27:56 --> Language Class Initialized
INFO - 2016-11-14 21:27:56 --> Loader Class Initialized
INFO - 2016-11-14 21:27:56 --> Helper loaded: url_helper
INFO - 2016-11-14 21:27:56 --> Helper loaded: form_helper
INFO - 2016-11-14 21:27:56 --> Database Driver Class Initialized
INFO - 2016-11-14 21:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:27:56 --> Controller Class Initialized
INFO - 2016-11-14 21:27:56 --> Model Class Initialized
INFO - 2016-11-14 21:27:56 --> Model Class Initialized
INFO - 2016-11-14 21:27:56 --> Model Class Initialized
INFO - 2016-11-14 21:27:57 --> Model Class Initialized
INFO - 2016-11-14 21:27:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:27:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:27:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:27:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:27:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:27:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:27:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:27:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:27:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:27:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:27:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:27:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:27:57 --> Final output sent to browser
DEBUG - 2016-11-14 21:27:57 --> Total execution time: 0.4292
INFO - 2016-11-14 21:28:00 --> Config Class Initialized
INFO - 2016-11-14 21:28:00 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:28:00 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:28:00 --> Utf8 Class Initialized
INFO - 2016-11-14 21:28:00 --> URI Class Initialized
INFO - 2016-11-14 21:28:00 --> Router Class Initialized
INFO - 2016-11-14 21:28:00 --> Output Class Initialized
INFO - 2016-11-14 21:28:00 --> Security Class Initialized
DEBUG - 2016-11-14 21:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:28:00 --> Input Class Initialized
INFO - 2016-11-14 21:28:00 --> Language Class Initialized
INFO - 2016-11-14 21:28:00 --> Loader Class Initialized
INFO - 2016-11-14 21:28:00 --> Helper loaded: url_helper
INFO - 2016-11-14 21:28:00 --> Helper loaded: form_helper
INFO - 2016-11-14 21:28:00 --> Database Driver Class Initialized
INFO - 2016-11-14 21:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:28:00 --> Controller Class Initialized
INFO - 2016-11-14 21:28:00 --> Model Class Initialized
INFO - 2016-11-14 21:28:05 --> Config Class Initialized
INFO - 2016-11-14 21:28:05 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:28:05 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:28:05 --> Utf8 Class Initialized
INFO - 2016-11-14 21:28:05 --> URI Class Initialized
INFO - 2016-11-14 21:28:05 --> Router Class Initialized
INFO - 2016-11-14 21:28:05 --> Output Class Initialized
INFO - 2016-11-14 21:28:05 --> Security Class Initialized
DEBUG - 2016-11-14 21:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:28:05 --> Input Class Initialized
INFO - 2016-11-14 21:28:05 --> Language Class Initialized
INFO - 2016-11-14 21:28:05 --> Config Class Initialized
INFO - 2016-11-14 21:28:05 --> Loader Class Initialized
INFO - 2016-11-14 21:28:05 --> Hooks Class Initialized
INFO - 2016-11-14 21:28:05 --> Helper loaded: url_helper
DEBUG - 2016-11-14 21:28:05 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:28:05 --> Helper loaded: form_helper
INFO - 2016-11-14 21:28:05 --> Utf8 Class Initialized
INFO - 2016-11-14 21:28:05 --> URI Class Initialized
INFO - 2016-11-14 21:28:05 --> Database Driver Class Initialized
INFO - 2016-11-14 21:28:05 --> Router Class Initialized
INFO - 2016-11-14 21:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:28:05 --> Output Class Initialized
INFO - 2016-11-14 21:28:05 --> Controller Class Initialized
INFO - 2016-11-14 21:28:05 --> Model Class Initialized
INFO - 2016-11-14 21:28:05 --> Security Class Initialized
INFO - 2016-11-14 21:28:05 --> Config Class Initialized
INFO - 2016-11-14 21:28:05 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-14 21:28:05 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:28:05 --> Input Class Initialized
INFO - 2016-11-14 21:28:05 --> Utf8 Class Initialized
INFO - 2016-11-14 21:28:05 --> Language Class Initialized
INFO - 2016-11-14 21:28:05 --> URI Class Initialized
INFO - 2016-11-14 21:28:05 --> Loader Class Initialized
INFO - 2016-11-14 21:28:05 --> Router Class Initialized
INFO - 2016-11-14 21:28:05 --> Helper loaded: url_helper
INFO - 2016-11-14 21:28:05 --> Output Class Initialized
INFO - 2016-11-14 21:28:05 --> Helper loaded: form_helper
INFO - 2016-11-14 21:28:05 --> Security Class Initialized
INFO - 2016-11-14 21:28:05 --> Database Driver Class Initialized
DEBUG - 2016-11-14 21:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:28:05 --> Input Class Initialized
INFO - 2016-11-14 21:28:05 --> Controller Class Initialized
INFO - 2016-11-14 21:28:05 --> Language Class Initialized
INFO - 2016-11-14 21:28:05 --> Model Class Initialized
INFO - 2016-11-14 21:28:05 --> Loader Class Initialized
INFO - 2016-11-14 21:28:05 --> Helper loaded: url_helper
INFO - 2016-11-14 21:28:05 --> Helper loaded: form_helper
INFO - 2016-11-14 21:28:05 --> Database Driver Class Initialized
INFO - 2016-11-14 21:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:28:05 --> Controller Class Initialized
INFO - 2016-11-14 21:28:05 --> Model Class Initialized
INFO - 2016-11-14 21:28:43 --> Config Class Initialized
INFO - 2016-11-14 21:28:43 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:28:43 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:28:43 --> Utf8 Class Initialized
INFO - 2016-11-14 21:28:43 --> URI Class Initialized
DEBUG - 2016-11-14 21:28:43 --> No URI present. Default controller set.
INFO - 2016-11-14 21:28:43 --> Router Class Initialized
INFO - 2016-11-14 21:28:43 --> Output Class Initialized
INFO - 2016-11-14 21:28:43 --> Security Class Initialized
DEBUG - 2016-11-14 21:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:28:43 --> Input Class Initialized
INFO - 2016-11-14 21:28:43 --> Language Class Initialized
INFO - 2016-11-14 21:28:43 --> Loader Class Initialized
INFO - 2016-11-14 21:28:43 --> Helper loaded: url_helper
INFO - 2016-11-14 21:28:43 --> Helper loaded: form_helper
INFO - 2016-11-14 21:28:43 --> Database Driver Class Initialized
INFO - 2016-11-14 21:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:28:43 --> Controller Class Initialized
INFO - 2016-11-14 21:28:43 --> Model Class Initialized
INFO - 2016-11-14 21:28:43 --> Model Class Initialized
INFO - 2016-11-14 21:28:43 --> Model Class Initialized
INFO - 2016-11-14 21:28:43 --> Model Class Initialized
INFO - 2016-11-14 21:28:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:28:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:28:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:28:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:28:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:28:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:28:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:28:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:28:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:28:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:28:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:28:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:28:43 --> Final output sent to browser
DEBUG - 2016-11-14 21:28:43 --> Total execution time: 0.4283
INFO - 2016-11-14 21:28:48 --> Config Class Initialized
INFO - 2016-11-14 21:28:48 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:28:48 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:28:48 --> Utf8 Class Initialized
INFO - 2016-11-14 21:28:48 --> URI Class Initialized
INFO - 2016-11-14 21:28:48 --> Router Class Initialized
INFO - 2016-11-14 21:28:48 --> Output Class Initialized
INFO - 2016-11-14 21:28:48 --> Security Class Initialized
DEBUG - 2016-11-14 21:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:28:48 --> Input Class Initialized
INFO - 2016-11-14 21:28:48 --> Language Class Initialized
INFO - 2016-11-14 21:28:48 --> Loader Class Initialized
INFO - 2016-11-14 21:28:48 --> Helper loaded: url_helper
INFO - 2016-11-14 21:28:48 --> Helper loaded: form_helper
INFO - 2016-11-14 21:28:48 --> Database Driver Class Initialized
INFO - 2016-11-14 21:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:28:48 --> Controller Class Initialized
INFO - 2016-11-14 21:28:48 --> Config Class Initialized
INFO - 2016-11-14 21:28:48 --> Model Class Initialized
INFO - 2016-11-14 21:28:48 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:28:48 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:28:48 --> Utf8 Class Initialized
INFO - 2016-11-14 21:28:48 --> URI Class Initialized
INFO - 2016-11-14 21:28:48 --> Router Class Initialized
INFO - 2016-11-14 21:28:48 --> Output Class Initialized
INFO - 2016-11-14 21:28:48 --> Security Class Initialized
DEBUG - 2016-11-14 21:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:28:48 --> Input Class Initialized
INFO - 2016-11-14 21:28:48 --> Language Class Initialized
INFO - 2016-11-14 21:28:48 --> Loader Class Initialized
INFO - 2016-11-14 21:28:48 --> Config Class Initialized
INFO - 2016-11-14 21:28:48 --> Helper loaded: url_helper
INFO - 2016-11-14 21:28:48 --> Hooks Class Initialized
INFO - 2016-11-14 21:28:48 --> Helper loaded: form_helper
DEBUG - 2016-11-14 21:28:48 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:28:48 --> Database Driver Class Initialized
INFO - 2016-11-14 21:28:48 --> Utf8 Class Initialized
INFO - 2016-11-14 21:28:48 --> URI Class Initialized
INFO - 2016-11-14 21:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:28:48 --> Router Class Initialized
INFO - 2016-11-14 21:28:48 --> Controller Class Initialized
INFO - 2016-11-14 21:28:48 --> Model Class Initialized
INFO - 2016-11-14 21:28:48 --> Output Class Initialized
INFO - 2016-11-14 21:28:48 --> Security Class Initialized
DEBUG - 2016-11-14 21:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:28:48 --> Input Class Initialized
INFO - 2016-11-14 21:28:48 --> Language Class Initialized
INFO - 2016-11-14 21:28:48 --> Loader Class Initialized
INFO - 2016-11-14 21:28:48 --> Helper loaded: url_helper
INFO - 2016-11-14 21:28:48 --> Helper loaded: form_helper
INFO - 2016-11-14 21:28:48 --> Database Driver Class Initialized
INFO - 2016-11-14 21:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:28:48 --> Controller Class Initialized
INFO - 2016-11-14 21:28:48 --> Model Class Initialized
INFO - 2016-11-14 21:28:57 --> Config Class Initialized
INFO - 2016-11-14 21:28:57 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:28:57 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:28:57 --> Utf8 Class Initialized
INFO - 2016-11-14 21:28:57 --> URI Class Initialized
INFO - 2016-11-14 21:28:57 --> Router Class Initialized
INFO - 2016-11-14 21:28:57 --> Output Class Initialized
INFO - 2016-11-14 21:28:57 --> Security Class Initialized
DEBUG - 2016-11-14 21:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:28:57 --> Input Class Initialized
INFO - 2016-11-14 21:28:57 --> Language Class Initialized
INFO - 2016-11-14 21:28:57 --> Loader Class Initialized
INFO - 2016-11-14 21:28:57 --> Helper loaded: url_helper
INFO - 2016-11-14 21:28:57 --> Helper loaded: form_helper
INFO - 2016-11-14 21:28:57 --> Database Driver Class Initialized
INFO - 2016-11-14 21:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:28:57 --> Controller Class Initialized
INFO - 2016-11-14 21:28:57 --> Model Class Initialized
INFO - 2016-11-14 21:28:57 --> Config Class Initialized
INFO - 2016-11-14 21:28:57 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:28:57 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:28:57 --> Utf8 Class Initialized
INFO - 2016-11-14 21:28:57 --> URI Class Initialized
INFO - 2016-11-14 21:28:57 --> Router Class Initialized
INFO - 2016-11-14 21:28:57 --> Output Class Initialized
INFO - 2016-11-14 21:28:57 --> Security Class Initialized
DEBUG - 2016-11-14 21:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:28:57 --> Input Class Initialized
INFO - 2016-11-14 21:28:57 --> Language Class Initialized
INFO - 2016-11-14 21:28:57 --> Loader Class Initialized
INFO - 2016-11-14 21:28:57 --> Helper loaded: url_helper
INFO - 2016-11-14 21:28:57 --> Helper loaded: form_helper
INFO - 2016-11-14 21:28:57 --> Database Driver Class Initialized
INFO - 2016-11-14 21:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:28:58 --> Controller Class Initialized
INFO - 2016-11-14 21:28:58 --> Model Class Initialized
INFO - 2016-11-14 21:29:28 --> Config Class Initialized
INFO - 2016-11-14 21:29:28 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:29:28 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:29:28 --> Utf8 Class Initialized
INFO - 2016-11-14 21:29:28 --> URI Class Initialized
DEBUG - 2016-11-14 21:29:28 --> No URI present. Default controller set.
INFO - 2016-11-14 21:29:28 --> Router Class Initialized
INFO - 2016-11-14 21:29:28 --> Output Class Initialized
INFO - 2016-11-14 21:29:28 --> Security Class Initialized
DEBUG - 2016-11-14 21:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:29:28 --> Input Class Initialized
INFO - 2016-11-14 21:29:28 --> Language Class Initialized
INFO - 2016-11-14 21:29:28 --> Loader Class Initialized
INFO - 2016-11-14 21:29:28 --> Helper loaded: url_helper
INFO - 2016-11-14 21:29:28 --> Helper loaded: form_helper
INFO - 2016-11-14 21:29:28 --> Database Driver Class Initialized
INFO - 2016-11-14 21:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:29:28 --> Controller Class Initialized
INFO - 2016-11-14 21:29:28 --> Model Class Initialized
INFO - 2016-11-14 21:29:28 --> Model Class Initialized
INFO - 2016-11-14 21:29:28 --> Model Class Initialized
INFO - 2016-11-14 21:29:28 --> Model Class Initialized
INFO - 2016-11-14 21:29:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:29:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:29:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:29:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:29:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:29:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:29:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:29:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:29:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:29:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:29:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:29:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:29:28 --> Final output sent to browser
DEBUG - 2016-11-14 21:29:28 --> Total execution time: 0.4280
INFO - 2016-11-14 21:29:33 --> Config Class Initialized
INFO - 2016-11-14 21:29:33 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:29:33 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:29:33 --> Utf8 Class Initialized
INFO - 2016-11-14 21:29:33 --> URI Class Initialized
INFO - 2016-11-14 21:29:33 --> Router Class Initialized
INFO - 2016-11-14 21:29:33 --> Output Class Initialized
INFO - 2016-11-14 21:29:33 --> Security Class Initialized
DEBUG - 2016-11-14 21:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:29:33 --> Input Class Initialized
INFO - 2016-11-14 21:29:33 --> Language Class Initialized
INFO - 2016-11-14 21:29:33 --> Loader Class Initialized
INFO - 2016-11-14 21:29:33 --> Helper loaded: url_helper
INFO - 2016-11-14 21:29:33 --> Helper loaded: form_helper
INFO - 2016-11-14 21:29:33 --> Database Driver Class Initialized
INFO - 2016-11-14 21:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:29:33 --> Controller Class Initialized
INFO - 2016-11-14 21:29:33 --> Model Class Initialized
ERROR - 2016-11-14 21:29:33 --> Severity: Warning --> error_log(): &quot;sendmail_from&quot; not set in php.ini or custom &quot;From:&quot; header missing C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 42
INFO - 2016-11-14 21:29:33 --> Config Class Initialized
INFO - 2016-11-14 21:29:33 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:29:33 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:29:33 --> Utf8 Class Initialized
INFO - 2016-11-14 21:29:33 --> URI Class Initialized
INFO - 2016-11-14 21:29:33 --> Router Class Initialized
INFO - 2016-11-14 21:29:33 --> Output Class Initialized
INFO - 2016-11-14 21:29:33 --> Security Class Initialized
DEBUG - 2016-11-14 21:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:29:33 --> Input Class Initialized
INFO - 2016-11-14 21:29:33 --> Language Class Initialized
INFO - 2016-11-14 21:29:33 --> Loader Class Initialized
INFO - 2016-11-14 21:29:34 --> Helper loaded: url_helper
INFO - 2016-11-14 21:29:34 --> Helper loaded: form_helper
INFO - 2016-11-14 21:29:34 --> Database Driver Class Initialized
INFO - 2016-11-14 21:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:29:34 --> Controller Class Initialized
INFO - 2016-11-14 21:29:34 --> Model Class Initialized
ERROR - 2016-11-14 21:29:34 --> Severity: Warning --> error_log(): &quot;sendmail_from&quot; not set in php.ini or custom &quot;From:&quot; header missing C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 42
INFO - 2016-11-14 21:29:43 --> Config Class Initialized
INFO - 2016-11-14 21:29:43 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:29:43 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:29:43 --> Utf8 Class Initialized
INFO - 2016-11-14 21:29:43 --> URI Class Initialized
DEBUG - 2016-11-14 21:29:43 --> No URI present. Default controller set.
INFO - 2016-11-14 21:29:43 --> Router Class Initialized
INFO - 2016-11-14 21:29:43 --> Output Class Initialized
INFO - 2016-11-14 21:29:43 --> Security Class Initialized
DEBUG - 2016-11-14 21:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:29:43 --> Input Class Initialized
INFO - 2016-11-14 21:29:43 --> Language Class Initialized
INFO - 2016-11-14 21:29:43 --> Loader Class Initialized
INFO - 2016-11-14 21:29:43 --> Helper loaded: url_helper
INFO - 2016-11-14 21:29:43 --> Helper loaded: form_helper
INFO - 2016-11-14 21:29:43 --> Database Driver Class Initialized
INFO - 2016-11-14 21:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:29:43 --> Controller Class Initialized
INFO - 2016-11-14 21:29:43 --> Model Class Initialized
INFO - 2016-11-14 21:29:43 --> Model Class Initialized
INFO - 2016-11-14 21:29:43 --> Model Class Initialized
INFO - 2016-11-14 21:29:43 --> Model Class Initialized
INFO - 2016-11-14 21:29:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:29:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:29:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:29:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:29:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:29:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:29:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:29:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:29:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:29:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:29:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:29:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:29:43 --> Final output sent to browser
DEBUG - 2016-11-14 21:29:43 --> Total execution time: 0.4386
INFO - 2016-11-14 21:29:47 --> Config Class Initialized
INFO - 2016-11-14 21:29:47 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:29:47 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:29:47 --> Utf8 Class Initialized
INFO - 2016-11-14 21:29:47 --> URI Class Initialized
INFO - 2016-11-14 21:29:47 --> Router Class Initialized
INFO - 2016-11-14 21:29:47 --> Output Class Initialized
INFO - 2016-11-14 21:29:47 --> Security Class Initialized
DEBUG - 2016-11-14 21:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:29:47 --> Input Class Initialized
INFO - 2016-11-14 21:29:47 --> Language Class Initialized
INFO - 2016-11-14 21:29:47 --> Loader Class Initialized
INFO - 2016-11-14 21:29:47 --> Helper loaded: url_helper
INFO - 2016-11-14 21:29:48 --> Helper loaded: form_helper
INFO - 2016-11-14 21:29:48 --> Database Driver Class Initialized
INFO - 2016-11-14 21:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:29:48 --> Controller Class Initialized
INFO - 2016-11-14 21:29:48 --> Model Class Initialized
ERROR - 2016-11-14 21:29:48 --> Severity: Warning --> error_log(): &quot;sendmail_from&quot; not set in php.ini or custom &quot;From:&quot; header missing C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 42
INFO - 2016-11-14 21:29:48 --> Config Class Initialized
INFO - 2016-11-14 21:29:48 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:29:48 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:29:48 --> Utf8 Class Initialized
INFO - 2016-11-14 21:29:48 --> URI Class Initialized
INFO - 2016-11-14 21:29:48 --> Router Class Initialized
INFO - 2016-11-14 21:29:48 --> Output Class Initialized
INFO - 2016-11-14 21:29:48 --> Security Class Initialized
DEBUG - 2016-11-14 21:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:29:48 --> Input Class Initialized
INFO - 2016-11-14 21:29:48 --> Language Class Initialized
INFO - 2016-11-14 21:29:48 --> Loader Class Initialized
INFO - 2016-11-14 21:29:48 --> Helper loaded: url_helper
INFO - 2016-11-14 21:29:48 --> Helper loaded: form_helper
INFO - 2016-11-14 21:29:48 --> Database Driver Class Initialized
INFO - 2016-11-14 21:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:29:48 --> Controller Class Initialized
INFO - 2016-11-14 21:29:48 --> Model Class Initialized
ERROR - 2016-11-14 21:29:48 --> Severity: Warning --> error_log(): &quot;sendmail_from&quot; not set in php.ini or custom &quot;From:&quot; header missing C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 42
INFO - 2016-11-14 21:31:46 --> Config Class Initialized
INFO - 2016-11-14 21:31:46 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:31:46 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:31:46 --> Utf8 Class Initialized
INFO - 2016-11-14 21:31:46 --> URI Class Initialized
DEBUG - 2016-11-14 21:31:46 --> No URI present. Default controller set.
INFO - 2016-11-14 21:31:46 --> Router Class Initialized
INFO - 2016-11-14 21:31:46 --> Output Class Initialized
INFO - 2016-11-14 21:31:46 --> Security Class Initialized
DEBUG - 2016-11-14 21:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:31:46 --> Input Class Initialized
INFO - 2016-11-14 21:31:46 --> Language Class Initialized
INFO - 2016-11-14 21:31:46 --> Loader Class Initialized
INFO - 2016-11-14 21:31:46 --> Helper loaded: url_helper
INFO - 2016-11-14 21:31:46 --> Helper loaded: form_helper
INFO - 2016-11-14 21:31:46 --> Database Driver Class Initialized
INFO - 2016-11-14 21:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:31:46 --> Controller Class Initialized
INFO - 2016-11-14 21:31:46 --> Model Class Initialized
INFO - 2016-11-14 21:31:46 --> Model Class Initialized
INFO - 2016-11-14 21:31:46 --> Model Class Initialized
INFO - 2016-11-14 21:31:46 --> Model Class Initialized
INFO - 2016-11-14 21:31:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:31:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:31:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:31:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:31:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:31:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:31:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:31:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:31:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:31:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:31:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:31:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:31:46 --> Final output sent to browser
DEBUG - 2016-11-14 21:31:46 --> Total execution time: 0.4301
INFO - 2016-11-14 21:31:50 --> Config Class Initialized
INFO - 2016-11-14 21:31:50 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:31:50 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:31:50 --> Utf8 Class Initialized
INFO - 2016-11-14 21:31:50 --> URI Class Initialized
INFO - 2016-11-14 21:31:50 --> Router Class Initialized
INFO - 2016-11-14 21:31:50 --> Output Class Initialized
INFO - 2016-11-14 21:31:50 --> Security Class Initialized
DEBUG - 2016-11-14 21:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:31:50 --> Input Class Initialized
INFO - 2016-11-14 21:31:50 --> Language Class Initialized
INFO - 2016-11-14 21:31:50 --> Loader Class Initialized
INFO - 2016-11-14 21:31:50 --> Helper loaded: url_helper
INFO - 2016-11-14 21:31:50 --> Helper loaded: form_helper
INFO - 2016-11-14 21:31:50 --> Database Driver Class Initialized
INFO - 2016-11-14 21:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:31:50 --> Controller Class Initialized
INFO - 2016-11-14 21:31:50 --> Model Class Initialized
INFO - 2016-11-14 21:31:51 --> Config Class Initialized
INFO - 2016-11-14 21:31:51 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:31:51 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:31:51 --> Utf8 Class Initialized
INFO - 2016-11-14 21:31:51 --> URI Class Initialized
INFO - 2016-11-14 21:31:51 --> Router Class Initialized
INFO - 2016-11-14 21:31:51 --> Output Class Initialized
INFO - 2016-11-14 21:31:51 --> Security Class Initialized
DEBUG - 2016-11-14 21:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:31:51 --> Input Class Initialized
INFO - 2016-11-14 21:31:51 --> Language Class Initialized
INFO - 2016-11-14 21:31:51 --> Loader Class Initialized
INFO - 2016-11-14 21:31:51 --> Helper loaded: url_helper
INFO - 2016-11-14 21:31:51 --> Helper loaded: form_helper
INFO - 2016-11-14 21:31:51 --> Config Class Initialized
INFO - 2016-11-14 21:31:51 --> Database Driver Class Initialized
INFO - 2016-11-14 21:31:51 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:31:51 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:31:51 --> Utf8 Class Initialized
INFO - 2016-11-14 21:31:51 --> Controller Class Initialized
INFO - 2016-11-14 21:31:51 --> URI Class Initialized
INFO - 2016-11-14 21:31:51 --> Model Class Initialized
INFO - 2016-11-14 21:31:51 --> Router Class Initialized
INFO - 2016-11-14 21:31:51 --> Output Class Initialized
INFO - 2016-11-14 21:31:51 --> Security Class Initialized
DEBUG - 2016-11-14 21:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:31:51 --> Input Class Initialized
INFO - 2016-11-14 21:31:51 --> Language Class Initialized
INFO - 2016-11-14 21:31:51 --> Config Class Initialized
INFO - 2016-11-14 21:31:51 --> Loader Class Initialized
INFO - 2016-11-14 21:31:51 --> Hooks Class Initialized
INFO - 2016-11-14 21:31:51 --> Helper loaded: url_helper
DEBUG - 2016-11-14 21:31:51 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:31:51 --> Utf8 Class Initialized
INFO - 2016-11-14 21:31:51 --> Helper loaded: form_helper
INFO - 2016-11-14 21:31:51 --> URI Class Initialized
INFO - 2016-11-14 21:31:51 --> Database Driver Class Initialized
INFO - 2016-11-14 21:31:51 --> Router Class Initialized
INFO - 2016-11-14 21:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:31:51 --> Output Class Initialized
INFO - 2016-11-14 21:31:51 --> Controller Class Initialized
INFO - 2016-11-14 21:31:51 --> Model Class Initialized
INFO - 2016-11-14 21:31:51 --> Security Class Initialized
INFO - 2016-11-14 21:31:51 --> Config Class Initialized
DEBUG - 2016-11-14 21:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:31:51 --> Hooks Class Initialized
INFO - 2016-11-14 21:31:51 --> Input Class Initialized
DEBUG - 2016-11-14 21:31:51 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:31:51 --> Language Class Initialized
INFO - 2016-11-14 21:31:51 --> Utf8 Class Initialized
INFO - 2016-11-14 21:31:51 --> URI Class Initialized
INFO - 2016-11-14 21:31:51 --> Loader Class Initialized
INFO - 2016-11-14 21:31:51 --> Router Class Initialized
INFO - 2016-11-14 21:31:51 --> Helper loaded: url_helper
INFO - 2016-11-14 21:31:51 --> Output Class Initialized
INFO - 2016-11-14 21:31:51 --> Helper loaded: form_helper
INFO - 2016-11-14 21:31:51 --> Security Class Initialized
INFO - 2016-11-14 21:31:51 --> Database Driver Class Initialized
DEBUG - 2016-11-14 21:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:31:51 --> Config Class Initialized
INFO - 2016-11-14 21:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:31:51 --> Input Class Initialized
INFO - 2016-11-14 21:31:51 --> Controller Class Initialized
INFO - 2016-11-14 21:31:51 --> Hooks Class Initialized
INFO - 2016-11-14 21:31:51 --> Language Class Initialized
INFO - 2016-11-14 21:31:51 --> Model Class Initialized
DEBUG - 2016-11-14 21:31:51 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:31:51 --> Loader Class Initialized
INFO - 2016-11-14 21:31:51 --> Utf8 Class Initialized
INFO - 2016-11-14 21:31:51 --> URI Class Initialized
INFO - 2016-11-14 21:31:51 --> Helper loaded: url_helper
INFO - 2016-11-14 21:31:51 --> Router Class Initialized
INFO - 2016-11-14 21:31:51 --> Helper loaded: form_helper
INFO - 2016-11-14 21:31:51 --> Output Class Initialized
INFO - 2016-11-14 21:31:51 --> Database Driver Class Initialized
INFO - 2016-11-14 21:31:51 --> Security Class Initialized
INFO - 2016-11-14 21:31:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-14 21:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:31:51 --> Controller Class Initialized
INFO - 2016-11-14 21:31:51 --> Input Class Initialized
INFO - 2016-11-14 21:31:51 --> Model Class Initialized
INFO - 2016-11-14 21:31:51 --> Config Class Initialized
INFO - 2016-11-14 21:31:51 --> Hooks Class Initialized
INFO - 2016-11-14 21:31:51 --> Language Class Initialized
INFO - 2016-11-14 21:31:51 --> Loader Class Initialized
DEBUG - 2016-11-14 21:31:51 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:31:51 --> Helper loaded: url_helper
INFO - 2016-11-14 21:31:51 --> Utf8 Class Initialized
INFO - 2016-11-14 21:31:51 --> URI Class Initialized
INFO - 2016-11-14 21:31:51 --> Helper loaded: form_helper
INFO - 2016-11-14 21:31:51 --> Router Class Initialized
INFO - 2016-11-14 21:31:51 --> Database Driver Class Initialized
INFO - 2016-11-14 21:31:51 --> Output Class Initialized
INFO - 2016-11-14 21:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:31:51 --> Security Class Initialized
INFO - 2016-11-14 21:31:51 --> Controller Class Initialized
INFO - 2016-11-14 21:31:51 --> Config Class Initialized
DEBUG - 2016-11-14 21:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:31:51 --> Model Class Initialized
INFO - 2016-11-14 21:31:51 --> Hooks Class Initialized
INFO - 2016-11-14 21:31:51 --> Input Class Initialized
DEBUG - 2016-11-14 21:31:51 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:31:51 --> Language Class Initialized
INFO - 2016-11-14 21:31:51 --> Utf8 Class Initialized
INFO - 2016-11-14 21:31:52 --> URI Class Initialized
INFO - 2016-11-14 21:31:52 --> Loader Class Initialized
INFO - 2016-11-14 21:31:52 --> Router Class Initialized
INFO - 2016-11-14 21:31:52 --> Helper loaded: url_helper
INFO - 2016-11-14 21:31:52 --> Output Class Initialized
INFO - 2016-11-14 21:31:52 --> Helper loaded: form_helper
INFO - 2016-11-14 21:31:52 --> Security Class Initialized
INFO - 2016-11-14 21:31:52 --> Database Driver Class Initialized
DEBUG - 2016-11-14 21:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:31:52 --> Input Class Initialized
INFO - 2016-11-14 21:31:52 --> Controller Class Initialized
INFO - 2016-11-14 21:31:52 --> Language Class Initialized
INFO - 2016-11-14 21:31:52 --> Model Class Initialized
INFO - 2016-11-14 21:31:52 --> Loader Class Initialized
INFO - 2016-11-14 21:31:52 --> Helper loaded: url_helper
INFO - 2016-11-14 21:31:52 --> Helper loaded: form_helper
INFO - 2016-11-14 21:31:52 --> Database Driver Class Initialized
INFO - 2016-11-14 21:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:31:52 --> Controller Class Initialized
INFO - 2016-11-14 21:31:52 --> Model Class Initialized
INFO - 2016-11-14 21:32:29 --> Config Class Initialized
INFO - 2016-11-14 21:32:29 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:32:29 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:32:29 --> Utf8 Class Initialized
INFO - 2016-11-14 21:32:29 --> URI Class Initialized
DEBUG - 2016-11-14 21:32:29 --> No URI present. Default controller set.
INFO - 2016-11-14 21:32:29 --> Router Class Initialized
INFO - 2016-11-14 21:32:29 --> Output Class Initialized
INFO - 2016-11-14 21:32:29 --> Security Class Initialized
DEBUG - 2016-11-14 21:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:32:29 --> Input Class Initialized
INFO - 2016-11-14 21:32:29 --> Language Class Initialized
INFO - 2016-11-14 21:32:29 --> Loader Class Initialized
INFO - 2016-11-14 21:32:29 --> Helper loaded: url_helper
INFO - 2016-11-14 21:32:29 --> Helper loaded: form_helper
INFO - 2016-11-14 21:32:29 --> Database Driver Class Initialized
INFO - 2016-11-14 21:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:32:29 --> Controller Class Initialized
INFO - 2016-11-14 21:32:29 --> Model Class Initialized
INFO - 2016-11-14 21:32:29 --> Model Class Initialized
INFO - 2016-11-14 21:32:29 --> Model Class Initialized
INFO - 2016-11-14 21:32:29 --> Model Class Initialized
INFO - 2016-11-14 21:32:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:32:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:36:20 --> Config Class Initialized
INFO - 2016-11-14 21:36:20 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:36:20 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:36:20 --> Utf8 Class Initialized
INFO - 2016-11-14 21:36:20 --> URI Class Initialized
DEBUG - 2016-11-14 21:36:20 --> No URI present. Default controller set.
INFO - 2016-11-14 21:36:20 --> Router Class Initialized
INFO - 2016-11-14 21:36:20 --> Output Class Initialized
INFO - 2016-11-14 21:36:20 --> Security Class Initialized
DEBUG - 2016-11-14 21:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:36:20 --> Input Class Initialized
INFO - 2016-11-14 21:36:20 --> Language Class Initialized
INFO - 2016-11-14 21:36:20 --> Loader Class Initialized
INFO - 2016-11-14 21:36:20 --> Helper loaded: url_helper
INFO - 2016-11-14 21:36:20 --> Helper loaded: form_helper
INFO - 2016-11-14 21:36:20 --> Database Driver Class Initialized
INFO - 2016-11-14 21:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:36:20 --> Controller Class Initialized
INFO - 2016-11-14 21:36:20 --> Model Class Initialized
INFO - 2016-11-14 21:36:20 --> Model Class Initialized
INFO - 2016-11-14 21:36:20 --> Model Class Initialized
INFO - 2016-11-14 21:36:20 --> Model Class Initialized
INFO - 2016-11-14 21:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:36:20 --> Final output sent to browser
DEBUG - 2016-11-14 21:36:21 --> Total execution time: 0.4268
INFO - 2016-11-14 21:36:27 --> Config Class Initialized
INFO - 2016-11-14 21:36:27 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:36:27 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:36:27 --> Utf8 Class Initialized
INFO - 2016-11-14 21:36:27 --> URI Class Initialized
INFO - 2016-11-14 21:36:27 --> Router Class Initialized
INFO - 2016-11-14 21:36:27 --> Output Class Initialized
INFO - 2016-11-14 21:36:27 --> Security Class Initialized
DEBUG - 2016-11-14 21:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:36:27 --> Input Class Initialized
INFO - 2016-11-14 21:36:27 --> Language Class Initialized
INFO - 2016-11-14 21:36:27 --> Loader Class Initialized
INFO - 2016-11-14 21:36:27 --> Helper loaded: url_helper
INFO - 2016-11-14 21:36:27 --> Helper loaded: form_helper
INFO - 2016-11-14 21:36:27 --> Database Driver Class Initialized
INFO - 2016-11-14 21:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:36:27 --> Controller Class Initialized
INFO - 2016-11-14 21:36:27 --> Model Class Initialized
INFO - 2016-11-14 21:36:27 --> Form Validation Class Initialized
INFO - 2016-11-14 21:36:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-14 21:36:27 --> Final output sent to browser
DEBUG - 2016-11-14 21:36:27 --> Total execution time: 0.2422
INFO - 2016-11-14 21:36:33 --> Config Class Initialized
INFO - 2016-11-14 21:36:33 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:36:33 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:36:33 --> Utf8 Class Initialized
INFO - 2016-11-14 21:36:33 --> URI Class Initialized
INFO - 2016-11-14 21:36:33 --> Router Class Initialized
INFO - 2016-11-14 21:36:33 --> Output Class Initialized
INFO - 2016-11-14 21:36:33 --> Security Class Initialized
DEBUG - 2016-11-14 21:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:36:33 --> Input Class Initialized
INFO - 2016-11-14 21:36:33 --> Language Class Initialized
INFO - 2016-11-14 21:36:33 --> Loader Class Initialized
INFO - 2016-11-14 21:36:33 --> Helper loaded: url_helper
INFO - 2016-11-14 21:36:33 --> Helper loaded: form_helper
INFO - 2016-11-14 21:36:33 --> Database Driver Class Initialized
INFO - 2016-11-14 21:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:36:33 --> Controller Class Initialized
INFO - 2016-11-14 21:36:33 --> Model Class Initialized
INFO - 2016-11-14 21:36:33 --> Form Validation Class Initialized
INFO - 2016-11-14 21:36:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-14 21:36:33 --> Final output sent to browser
DEBUG - 2016-11-14 21:36:33 --> Total execution time: 0.3264
INFO - 2016-11-14 21:36:37 --> Config Class Initialized
INFO - 2016-11-14 21:36:37 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:36:37 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:36:37 --> Utf8 Class Initialized
INFO - 2016-11-14 21:36:37 --> URI Class Initialized
INFO - 2016-11-14 21:36:37 --> Router Class Initialized
INFO - 2016-11-14 21:36:37 --> Output Class Initialized
INFO - 2016-11-14 21:36:37 --> Security Class Initialized
DEBUG - 2016-11-14 21:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:36:37 --> Input Class Initialized
INFO - 2016-11-14 21:36:37 --> Language Class Initialized
INFO - 2016-11-14 21:36:37 --> Loader Class Initialized
INFO - 2016-11-14 21:36:37 --> Helper loaded: url_helper
INFO - 2016-11-14 21:36:37 --> Helper loaded: form_helper
INFO - 2016-11-14 21:36:37 --> Database Driver Class Initialized
INFO - 2016-11-14 21:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:36:37 --> Controller Class Initialized
INFO - 2016-11-14 21:36:37 --> Model Class Initialized
INFO - 2016-11-14 21:36:37 --> Form Validation Class Initialized
INFO - 2016-11-14 21:36:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-14 21:36:37 --> Final output sent to browser
DEBUG - 2016-11-14 21:36:37 --> Total execution time: 0.2930
INFO - 2016-11-14 21:36:42 --> Config Class Initialized
INFO - 2016-11-14 21:36:42 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:36:42 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:36:42 --> Utf8 Class Initialized
INFO - 2016-11-14 21:36:42 --> URI Class Initialized
INFO - 2016-11-14 21:36:42 --> Router Class Initialized
INFO - 2016-11-14 21:36:42 --> Output Class Initialized
INFO - 2016-11-14 21:36:42 --> Security Class Initialized
DEBUG - 2016-11-14 21:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:36:42 --> Input Class Initialized
INFO - 2016-11-14 21:36:42 --> Language Class Initialized
INFO - 2016-11-14 21:36:42 --> Loader Class Initialized
INFO - 2016-11-14 21:36:42 --> Helper loaded: url_helper
INFO - 2016-11-14 21:36:42 --> Helper loaded: form_helper
INFO - 2016-11-14 21:36:42 --> Database Driver Class Initialized
INFO - 2016-11-14 21:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:36:42 --> Controller Class Initialized
INFO - 2016-11-14 21:36:42 --> Model Class Initialized
INFO - 2016-11-14 21:36:42 --> Form Validation Class Initialized
INFO - 2016-11-14 21:36:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-14 21:36:42 --> Final output sent to browser
DEBUG - 2016-11-14 21:36:42 --> Total execution time: 0.3010
INFO - 2016-11-14 21:37:20 --> Config Class Initialized
INFO - 2016-11-14 21:37:20 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:37:20 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:37:20 --> Utf8 Class Initialized
INFO - 2016-11-14 21:37:20 --> URI Class Initialized
INFO - 2016-11-14 21:37:20 --> Router Class Initialized
INFO - 2016-11-14 21:37:20 --> Output Class Initialized
INFO - 2016-11-14 21:37:21 --> Security Class Initialized
DEBUG - 2016-11-14 21:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:37:21 --> Input Class Initialized
INFO - 2016-11-14 21:37:21 --> Language Class Initialized
ERROR - 2016-11-14 21:37:21 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:37:33 --> Config Class Initialized
INFO - 2016-11-14 21:37:33 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:37:33 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:37:33 --> Utf8 Class Initialized
INFO - 2016-11-14 21:37:33 --> URI Class Initialized
INFO - 2016-11-14 21:37:33 --> Router Class Initialized
INFO - 2016-11-14 21:37:33 --> Output Class Initialized
INFO - 2016-11-14 21:37:33 --> Security Class Initialized
DEBUG - 2016-11-14 21:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:37:33 --> Input Class Initialized
INFO - 2016-11-14 21:37:33 --> Language Class Initialized
ERROR - 2016-11-14 21:37:33 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:37:34 --> Config Class Initialized
INFO - 2016-11-14 21:37:34 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:37:34 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:37:34 --> Utf8 Class Initialized
INFO - 2016-11-14 21:37:34 --> URI Class Initialized
INFO - 2016-11-14 21:37:34 --> Router Class Initialized
INFO - 2016-11-14 21:37:34 --> Output Class Initialized
INFO - 2016-11-14 21:37:34 --> Security Class Initialized
DEBUG - 2016-11-14 21:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:37:34 --> Input Class Initialized
INFO - 2016-11-14 21:37:34 --> Language Class Initialized
ERROR - 2016-11-14 21:37:34 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:37:34 --> Config Class Initialized
INFO - 2016-11-14 21:37:34 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:37:34 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:37:34 --> Utf8 Class Initialized
INFO - 2016-11-14 21:37:34 --> URI Class Initialized
INFO - 2016-11-14 21:37:34 --> Router Class Initialized
INFO - 2016-11-14 21:37:34 --> Output Class Initialized
INFO - 2016-11-14 21:37:34 --> Security Class Initialized
DEBUG - 2016-11-14 21:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:37:34 --> Input Class Initialized
INFO - 2016-11-14 21:37:34 --> Language Class Initialized
ERROR - 2016-11-14 21:37:34 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:37:35 --> Config Class Initialized
INFO - 2016-11-14 21:37:35 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:37:35 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:37:35 --> Utf8 Class Initialized
INFO - 2016-11-14 21:37:35 --> URI Class Initialized
INFO - 2016-11-14 21:37:35 --> Router Class Initialized
INFO - 2016-11-14 21:37:35 --> Output Class Initialized
INFO - 2016-11-14 21:37:35 --> Security Class Initialized
DEBUG - 2016-11-14 21:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:37:35 --> Input Class Initialized
INFO - 2016-11-14 21:37:35 --> Language Class Initialized
ERROR - 2016-11-14 21:37:35 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:37:35 --> Config Class Initialized
INFO - 2016-11-14 21:37:35 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:37:35 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:37:35 --> Utf8 Class Initialized
INFO - 2016-11-14 21:37:35 --> URI Class Initialized
INFO - 2016-11-14 21:37:35 --> Router Class Initialized
INFO - 2016-11-14 21:37:35 --> Output Class Initialized
INFO - 2016-11-14 21:37:35 --> Security Class Initialized
DEBUG - 2016-11-14 21:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:37:35 --> Input Class Initialized
INFO - 2016-11-14 21:37:35 --> Language Class Initialized
ERROR - 2016-11-14 21:37:35 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:37:35 --> Config Class Initialized
INFO - 2016-11-14 21:37:35 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:37:35 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:37:35 --> Utf8 Class Initialized
INFO - 2016-11-14 21:37:35 --> URI Class Initialized
INFO - 2016-11-14 21:37:35 --> Router Class Initialized
INFO - 2016-11-14 21:37:35 --> Output Class Initialized
INFO - 2016-11-14 21:37:35 --> Security Class Initialized
DEBUG - 2016-11-14 21:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:37:35 --> Input Class Initialized
INFO - 2016-11-14 21:37:35 --> Language Class Initialized
ERROR - 2016-11-14 21:37:35 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:37:35 --> Config Class Initialized
INFO - 2016-11-14 21:37:35 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:37:35 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:37:35 --> Utf8 Class Initialized
INFO - 2016-11-14 21:37:35 --> URI Class Initialized
INFO - 2016-11-14 21:37:35 --> Router Class Initialized
INFO - 2016-11-14 21:37:35 --> Output Class Initialized
INFO - 2016-11-14 21:37:35 --> Security Class Initialized
DEBUG - 2016-11-14 21:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:37:35 --> Input Class Initialized
INFO - 2016-11-14 21:37:35 --> Language Class Initialized
ERROR - 2016-11-14 21:37:36 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:37:36 --> Config Class Initialized
INFO - 2016-11-14 21:37:36 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:37:36 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:37:36 --> Utf8 Class Initialized
INFO - 2016-11-14 21:37:36 --> URI Class Initialized
INFO - 2016-11-14 21:37:36 --> Router Class Initialized
INFO - 2016-11-14 21:37:36 --> Output Class Initialized
INFO - 2016-11-14 21:37:36 --> Security Class Initialized
DEBUG - 2016-11-14 21:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:37:36 --> Input Class Initialized
INFO - 2016-11-14 21:37:36 --> Language Class Initialized
ERROR - 2016-11-14 21:37:36 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:37:45 --> Config Class Initialized
INFO - 2016-11-14 21:37:45 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:37:45 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:37:45 --> Utf8 Class Initialized
INFO - 2016-11-14 21:37:45 --> URI Class Initialized
INFO - 2016-11-14 21:37:45 --> Router Class Initialized
INFO - 2016-11-14 21:37:45 --> Output Class Initialized
INFO - 2016-11-14 21:37:45 --> Security Class Initialized
DEBUG - 2016-11-14 21:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:37:45 --> Input Class Initialized
INFO - 2016-11-14 21:37:45 --> Language Class Initialized
INFO - 2016-11-14 21:37:45 --> Loader Class Initialized
INFO - 2016-11-14 21:37:45 --> Helper loaded: url_helper
INFO - 2016-11-14 21:37:45 --> Helper loaded: form_helper
INFO - 2016-11-14 21:37:45 --> Database Driver Class Initialized
INFO - 2016-11-14 21:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:37:45 --> Controller Class Initialized
INFO - 2016-11-14 21:37:45 --> Model Class Initialized
INFO - 2016-11-14 21:37:45 --> Form Validation Class Initialized
INFO - 2016-11-14 21:37:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-14 21:37:45 --> Final output sent to browser
DEBUG - 2016-11-14 21:37:45 --> Total execution time: 0.2297
INFO - 2016-11-14 21:37:45 --> Config Class Initialized
INFO - 2016-11-14 21:37:46 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:37:46 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:37:46 --> Utf8 Class Initialized
INFO - 2016-11-14 21:37:46 --> URI Class Initialized
INFO - 2016-11-14 21:37:46 --> Router Class Initialized
INFO - 2016-11-14 21:37:46 --> Output Class Initialized
INFO - 2016-11-14 21:37:46 --> Security Class Initialized
DEBUG - 2016-11-14 21:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:37:46 --> Input Class Initialized
INFO - 2016-11-14 21:37:46 --> Language Class Initialized
INFO - 2016-11-14 21:37:46 --> Loader Class Initialized
INFO - 2016-11-14 21:37:46 --> Helper loaded: url_helper
INFO - 2016-11-14 21:37:46 --> Helper loaded: form_helper
INFO - 2016-11-14 21:37:46 --> Database Driver Class Initialized
INFO - 2016-11-14 21:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:37:46 --> Controller Class Initialized
INFO - 2016-11-14 21:37:46 --> Config Class Initialized
INFO - 2016-11-14 21:37:46 --> Model Class Initialized
INFO - 2016-11-14 21:37:46 --> Hooks Class Initialized
INFO - 2016-11-14 21:37:46 --> Form Validation Class Initialized
DEBUG - 2016-11-14 21:37:46 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:37:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-14 21:37:46 --> Utf8 Class Initialized
INFO - 2016-11-14 21:37:46 --> Final output sent to browser
INFO - 2016-11-14 21:37:46 --> URI Class Initialized
DEBUG - 2016-11-14 21:37:46 --> Total execution time: 0.2530
INFO - 2016-11-14 21:37:46 --> Router Class Initialized
INFO - 2016-11-14 21:37:46 --> Output Class Initialized
INFO - 2016-11-14 21:37:46 --> Security Class Initialized
DEBUG - 2016-11-14 21:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:37:46 --> Input Class Initialized
INFO - 2016-11-14 21:37:46 --> Language Class Initialized
INFO - 2016-11-14 21:37:46 --> Loader Class Initialized
INFO - 2016-11-14 21:37:46 --> Helper loaded: url_helper
INFO - 2016-11-14 21:37:46 --> Helper loaded: form_helper
INFO - 2016-11-14 21:37:46 --> Database Driver Class Initialized
INFO - 2016-11-14 21:37:46 --> Config Class Initialized
INFO - 2016-11-14 21:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:37:46 --> Hooks Class Initialized
INFO - 2016-11-14 21:37:46 --> Controller Class Initialized
DEBUG - 2016-11-14 21:37:46 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:37:46 --> Model Class Initialized
INFO - 2016-11-14 21:37:46 --> Utf8 Class Initialized
INFO - 2016-11-14 21:37:46 --> URI Class Initialized
INFO - 2016-11-14 21:37:46 --> Form Validation Class Initialized
INFO - 2016-11-14 21:37:46 --> Router Class Initialized
INFO - 2016-11-14 21:37:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-14 21:37:46 --> Output Class Initialized
INFO - 2016-11-14 21:37:46 --> Final output sent to browser
INFO - 2016-11-14 21:37:46 --> Security Class Initialized
DEBUG - 2016-11-14 21:37:46 --> Total execution time: 0.2986
DEBUG - 2016-11-14 21:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:37:46 --> Input Class Initialized
INFO - 2016-11-14 21:37:46 --> Language Class Initialized
INFO - 2016-11-14 21:37:46 --> Loader Class Initialized
INFO - 2016-11-14 21:37:46 --> Helper loaded: url_helper
INFO - 2016-11-14 21:37:46 --> Config Class Initialized
INFO - 2016-11-14 21:37:46 --> Helper loaded: form_helper
INFO - 2016-11-14 21:37:46 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:37:46 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:37:46 --> Database Driver Class Initialized
INFO - 2016-11-14 21:37:46 --> Utf8 Class Initialized
INFO - 2016-11-14 21:37:46 --> URI Class Initialized
INFO - 2016-11-14 21:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:37:46 --> Router Class Initialized
INFO - 2016-11-14 21:37:46 --> Controller Class Initialized
INFO - 2016-11-14 21:37:46 --> Model Class Initialized
INFO - 2016-11-14 21:37:46 --> Output Class Initialized
INFO - 2016-11-14 21:37:46 --> Form Validation Class Initialized
INFO - 2016-11-14 21:37:46 --> Security Class Initialized
INFO - 2016-11-14 21:37:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-14 21:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:37:46 --> Final output sent to browser
INFO - 2016-11-14 21:37:46 --> Input Class Initialized
DEBUG - 2016-11-14 21:37:46 --> Total execution time: 0.3239
INFO - 2016-11-14 21:37:46 --> Language Class Initialized
INFO - 2016-11-14 21:37:46 --> Loader Class Initialized
INFO - 2016-11-14 21:37:46 --> Helper loaded: url_helper
INFO - 2016-11-14 21:37:46 --> Helper loaded: form_helper
INFO - 2016-11-14 21:37:46 --> Database Driver Class Initialized
INFO - 2016-11-14 21:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:37:46 --> Controller Class Initialized
INFO - 2016-11-14 21:37:46 --> Model Class Initialized
INFO - 2016-11-14 21:37:46 --> Form Validation Class Initialized
INFO - 2016-11-14 21:37:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-14 21:37:46 --> Final output sent to browser
DEBUG - 2016-11-14 21:37:46 --> Total execution time: 0.3173
INFO - 2016-11-14 21:38:03 --> Config Class Initialized
INFO - 2016-11-14 21:38:03 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:38:03 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:38:03 --> Utf8 Class Initialized
INFO - 2016-11-14 21:38:03 --> URI Class Initialized
INFO - 2016-11-14 21:38:03 --> Router Class Initialized
INFO - 2016-11-14 21:38:03 --> Output Class Initialized
INFO - 2016-11-14 21:38:03 --> Security Class Initialized
DEBUG - 2016-11-14 21:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:38:03 --> Input Class Initialized
INFO - 2016-11-14 21:38:03 --> Language Class Initialized
ERROR - 2016-11-14 21:38:03 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:38:04 --> Config Class Initialized
INFO - 2016-11-14 21:38:04 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:38:04 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:38:04 --> Utf8 Class Initialized
INFO - 2016-11-14 21:38:04 --> URI Class Initialized
INFO - 2016-11-14 21:38:04 --> Router Class Initialized
INFO - 2016-11-14 21:38:04 --> Output Class Initialized
INFO - 2016-11-14 21:38:04 --> Security Class Initialized
DEBUG - 2016-11-14 21:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:38:04 --> Input Class Initialized
INFO - 2016-11-14 21:38:04 --> Language Class Initialized
ERROR - 2016-11-14 21:38:04 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:38:04 --> Config Class Initialized
INFO - 2016-11-14 21:38:04 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:38:04 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:38:04 --> Utf8 Class Initialized
INFO - 2016-11-14 21:38:04 --> URI Class Initialized
INFO - 2016-11-14 21:38:04 --> Router Class Initialized
INFO - 2016-11-14 21:38:04 --> Output Class Initialized
INFO - 2016-11-14 21:38:05 --> Security Class Initialized
DEBUG - 2016-11-14 21:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:38:05 --> Input Class Initialized
INFO - 2016-11-14 21:38:05 --> Language Class Initialized
ERROR - 2016-11-14 21:38:05 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:38:05 --> Config Class Initialized
INFO - 2016-11-14 21:38:05 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:38:05 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:38:05 --> Utf8 Class Initialized
INFO - 2016-11-14 21:38:05 --> URI Class Initialized
INFO - 2016-11-14 21:38:05 --> Router Class Initialized
INFO - 2016-11-14 21:38:05 --> Output Class Initialized
INFO - 2016-11-14 21:38:05 --> Security Class Initialized
DEBUG - 2016-11-14 21:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:38:05 --> Input Class Initialized
INFO - 2016-11-14 21:38:05 --> Language Class Initialized
ERROR - 2016-11-14 21:38:05 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:38:05 --> Config Class Initialized
INFO - 2016-11-14 21:38:05 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:38:05 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:38:05 --> Utf8 Class Initialized
INFO - 2016-11-14 21:38:05 --> URI Class Initialized
INFO - 2016-11-14 21:38:05 --> Router Class Initialized
INFO - 2016-11-14 21:38:05 --> Output Class Initialized
INFO - 2016-11-14 21:38:05 --> Security Class Initialized
DEBUG - 2016-11-14 21:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:38:05 --> Input Class Initialized
INFO - 2016-11-14 21:38:05 --> Language Class Initialized
ERROR - 2016-11-14 21:38:05 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:38:05 --> Config Class Initialized
INFO - 2016-11-14 21:38:05 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:38:05 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:38:05 --> Utf8 Class Initialized
INFO - 2016-11-14 21:38:05 --> URI Class Initialized
INFO - 2016-11-14 21:38:05 --> Router Class Initialized
INFO - 2016-11-14 21:38:05 --> Output Class Initialized
INFO - 2016-11-14 21:38:05 --> Security Class Initialized
DEBUG - 2016-11-14 21:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:38:05 --> Input Class Initialized
INFO - 2016-11-14 21:38:05 --> Language Class Initialized
ERROR - 2016-11-14 21:38:05 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:38:05 --> Config Class Initialized
INFO - 2016-11-14 21:38:05 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:38:05 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:38:05 --> Utf8 Class Initialized
INFO - 2016-11-14 21:38:05 --> URI Class Initialized
INFO - 2016-11-14 21:38:05 --> Router Class Initialized
INFO - 2016-11-14 21:38:05 --> Output Class Initialized
INFO - 2016-11-14 21:38:05 --> Security Class Initialized
DEBUG - 2016-11-14 21:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:38:05 --> Input Class Initialized
INFO - 2016-11-14 21:38:05 --> Language Class Initialized
ERROR - 2016-11-14 21:38:05 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:38:05 --> Config Class Initialized
INFO - 2016-11-14 21:38:05 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:38:05 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:38:05 --> Utf8 Class Initialized
INFO - 2016-11-14 21:38:05 --> URI Class Initialized
INFO - 2016-11-14 21:38:06 --> Router Class Initialized
INFO - 2016-11-14 21:38:06 --> Output Class Initialized
INFO - 2016-11-14 21:38:06 --> Security Class Initialized
DEBUG - 2016-11-14 21:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:38:06 --> Input Class Initialized
INFO - 2016-11-14 21:38:06 --> Language Class Initialized
ERROR - 2016-11-14 21:38:06 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:38:06 --> Config Class Initialized
INFO - 2016-11-14 21:38:06 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:38:06 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:38:06 --> Utf8 Class Initialized
INFO - 2016-11-14 21:38:06 --> URI Class Initialized
INFO - 2016-11-14 21:38:06 --> Router Class Initialized
INFO - 2016-11-14 21:38:06 --> Output Class Initialized
INFO - 2016-11-14 21:38:06 --> Security Class Initialized
DEBUG - 2016-11-14 21:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:38:06 --> Input Class Initialized
INFO - 2016-11-14 21:38:06 --> Language Class Initialized
ERROR - 2016-11-14 21:38:06 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:38:06 --> Config Class Initialized
INFO - 2016-11-14 21:38:06 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:38:06 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:38:06 --> Utf8 Class Initialized
INFO - 2016-11-14 21:38:06 --> URI Class Initialized
INFO - 2016-11-14 21:38:06 --> Router Class Initialized
INFO - 2016-11-14 21:38:06 --> Output Class Initialized
INFO - 2016-11-14 21:38:06 --> Security Class Initialized
DEBUG - 2016-11-14 21:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:38:06 --> Input Class Initialized
INFO - 2016-11-14 21:38:06 --> Language Class Initialized
ERROR - 2016-11-14 21:38:06 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:38:06 --> Config Class Initialized
INFO - 2016-11-14 21:38:06 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:38:06 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:38:06 --> Utf8 Class Initialized
INFO - 2016-11-14 21:38:06 --> URI Class Initialized
INFO - 2016-11-14 21:38:06 --> Router Class Initialized
INFO - 2016-11-14 21:38:06 --> Output Class Initialized
INFO - 2016-11-14 21:38:06 --> Security Class Initialized
DEBUG - 2016-11-14 21:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:38:06 --> Input Class Initialized
INFO - 2016-11-14 21:38:06 --> Language Class Initialized
ERROR - 2016-11-14 21:38:06 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:38:07 --> Config Class Initialized
INFO - 2016-11-14 21:38:07 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:38:07 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:38:07 --> Utf8 Class Initialized
INFO - 2016-11-14 21:38:07 --> URI Class Initialized
INFO - 2016-11-14 21:38:07 --> Router Class Initialized
INFO - 2016-11-14 21:38:07 --> Output Class Initialized
INFO - 2016-11-14 21:38:07 --> Security Class Initialized
DEBUG - 2016-11-14 21:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:38:07 --> Input Class Initialized
INFO - 2016-11-14 21:38:07 --> Language Class Initialized
ERROR - 2016-11-14 21:38:07 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:38:07 --> Config Class Initialized
INFO - 2016-11-14 21:38:07 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:38:07 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:38:07 --> Utf8 Class Initialized
INFO - 2016-11-14 21:38:07 --> URI Class Initialized
INFO - 2016-11-14 21:38:07 --> Router Class Initialized
INFO - 2016-11-14 21:38:07 --> Output Class Initialized
INFO - 2016-11-14 21:38:07 --> Security Class Initialized
DEBUG - 2016-11-14 21:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:38:07 --> Input Class Initialized
INFO - 2016-11-14 21:38:07 --> Language Class Initialized
ERROR - 2016-11-14 21:38:07 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:38:07 --> Config Class Initialized
INFO - 2016-11-14 21:38:07 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:38:07 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:38:07 --> Utf8 Class Initialized
INFO - 2016-11-14 21:38:07 --> URI Class Initialized
INFO - 2016-11-14 21:38:07 --> Router Class Initialized
INFO - 2016-11-14 21:38:07 --> Output Class Initialized
INFO - 2016-11-14 21:38:07 --> Security Class Initialized
DEBUG - 2016-11-14 21:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:38:07 --> Input Class Initialized
INFO - 2016-11-14 21:38:07 --> Language Class Initialized
ERROR - 2016-11-14 21:38:07 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:38:13 --> Config Class Initialized
INFO - 2016-11-14 21:38:13 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:38:13 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:38:13 --> Utf8 Class Initialized
INFO - 2016-11-14 21:38:13 --> URI Class Initialized
INFO - 2016-11-14 21:38:13 --> Router Class Initialized
INFO - 2016-11-14 21:38:13 --> Output Class Initialized
INFO - 2016-11-14 21:38:13 --> Security Class Initialized
DEBUG - 2016-11-14 21:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:38:13 --> Input Class Initialized
INFO - 2016-11-14 21:38:13 --> Language Class Initialized
ERROR - 2016-11-14 21:38:13 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:38:13 --> Config Class Initialized
INFO - 2016-11-14 21:38:13 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:38:13 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:38:13 --> Utf8 Class Initialized
INFO - 2016-11-14 21:38:13 --> URI Class Initialized
INFO - 2016-11-14 21:38:13 --> Router Class Initialized
INFO - 2016-11-14 21:38:13 --> Output Class Initialized
INFO - 2016-11-14 21:38:13 --> Security Class Initialized
DEBUG - 2016-11-14 21:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:38:13 --> Input Class Initialized
INFO - 2016-11-14 21:38:13 --> Language Class Initialized
ERROR - 2016-11-14 21:38:13 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:38:13 --> Config Class Initialized
INFO - 2016-11-14 21:38:13 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:38:13 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:38:13 --> Utf8 Class Initialized
INFO - 2016-11-14 21:38:13 --> URI Class Initialized
INFO - 2016-11-14 21:38:13 --> Router Class Initialized
INFO - 2016-11-14 21:38:13 --> Output Class Initialized
INFO - 2016-11-14 21:38:13 --> Security Class Initialized
DEBUG - 2016-11-14 21:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:38:13 --> Input Class Initialized
INFO - 2016-11-14 21:38:13 --> Language Class Initialized
ERROR - 2016-11-14 21:38:13 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:38:14 --> Config Class Initialized
INFO - 2016-11-14 21:38:14 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:38:14 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:38:14 --> Utf8 Class Initialized
INFO - 2016-11-14 21:38:14 --> URI Class Initialized
INFO - 2016-11-14 21:38:14 --> Router Class Initialized
INFO - 2016-11-14 21:38:14 --> Output Class Initialized
INFO - 2016-11-14 21:38:14 --> Security Class Initialized
DEBUG - 2016-11-14 21:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:38:14 --> Input Class Initialized
INFO - 2016-11-14 21:38:14 --> Language Class Initialized
ERROR - 2016-11-14 21:38:14 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 44
INFO - 2016-11-14 21:38:49 --> Config Class Initialized
INFO - 2016-11-14 21:38:50 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:38:50 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:38:50 --> Utf8 Class Initialized
INFO - 2016-11-14 21:38:50 --> URI Class Initialized
DEBUG - 2016-11-14 21:38:50 --> No URI present. Default controller set.
INFO - 2016-11-14 21:38:50 --> Router Class Initialized
INFO - 2016-11-14 21:38:50 --> Output Class Initialized
INFO - 2016-11-14 21:38:50 --> Security Class Initialized
DEBUG - 2016-11-14 21:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:38:50 --> Input Class Initialized
INFO - 2016-11-14 21:38:50 --> Language Class Initialized
INFO - 2016-11-14 21:38:50 --> Loader Class Initialized
INFO - 2016-11-14 21:38:50 --> Helper loaded: url_helper
INFO - 2016-11-14 21:38:50 --> Helper loaded: form_helper
INFO - 2016-11-14 21:38:50 --> Database Driver Class Initialized
INFO - 2016-11-14 21:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:38:50 --> Controller Class Initialized
INFO - 2016-11-14 21:38:50 --> Model Class Initialized
INFO - 2016-11-14 21:38:50 --> Model Class Initialized
INFO - 2016-11-14 21:38:50 --> Model Class Initialized
INFO - 2016-11-14 21:38:50 --> Model Class Initialized
INFO - 2016-11-14 21:38:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:38:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:38:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:38:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:38:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:38:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:38:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:38:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:38:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:38:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:38:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:38:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:38:50 --> Final output sent to browser
DEBUG - 2016-11-14 21:38:50 --> Total execution time: 0.4770
INFO - 2016-11-14 21:39:46 --> Config Class Initialized
INFO - 2016-11-14 21:39:46 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:39:46 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:39:46 --> Utf8 Class Initialized
INFO - 2016-11-14 21:39:46 --> URI Class Initialized
DEBUG - 2016-11-14 21:39:46 --> No URI present. Default controller set.
INFO - 2016-11-14 21:39:46 --> Router Class Initialized
INFO - 2016-11-14 21:39:46 --> Output Class Initialized
INFO - 2016-11-14 21:39:46 --> Security Class Initialized
DEBUG - 2016-11-14 21:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:39:46 --> Input Class Initialized
INFO - 2016-11-14 21:39:46 --> Language Class Initialized
INFO - 2016-11-14 21:39:46 --> Loader Class Initialized
INFO - 2016-11-14 21:39:46 --> Helper loaded: url_helper
INFO - 2016-11-14 21:39:46 --> Helper loaded: form_helper
INFO - 2016-11-14 21:39:46 --> Database Driver Class Initialized
INFO - 2016-11-14 21:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:39:46 --> Controller Class Initialized
INFO - 2016-11-14 21:39:46 --> Model Class Initialized
INFO - 2016-11-14 21:39:46 --> Model Class Initialized
INFO - 2016-11-14 21:39:46 --> Model Class Initialized
INFO - 2016-11-14 21:39:46 --> Model Class Initialized
INFO - 2016-11-14 21:39:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:39:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:39:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:39:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:39:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:39:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:39:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:39:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:39:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:39:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:39:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:39:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:39:46 --> Final output sent to browser
DEBUG - 2016-11-14 21:39:46 --> Total execution time: 0.4317
INFO - 2016-11-14 21:40:18 --> Config Class Initialized
INFO - 2016-11-14 21:40:18 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:40:18 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:40:18 --> Utf8 Class Initialized
INFO - 2016-11-14 21:40:18 --> URI Class Initialized
DEBUG - 2016-11-14 21:40:18 --> No URI present. Default controller set.
INFO - 2016-11-14 21:40:18 --> Router Class Initialized
INFO - 2016-11-14 21:40:18 --> Output Class Initialized
INFO - 2016-11-14 21:40:18 --> Security Class Initialized
DEBUG - 2016-11-14 21:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:40:18 --> Input Class Initialized
INFO - 2016-11-14 21:40:18 --> Language Class Initialized
INFO - 2016-11-14 21:40:18 --> Loader Class Initialized
INFO - 2016-11-14 21:40:18 --> Helper loaded: url_helper
INFO - 2016-11-14 21:40:18 --> Helper loaded: form_helper
INFO - 2016-11-14 21:40:18 --> Database Driver Class Initialized
INFO - 2016-11-14 21:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:40:18 --> Controller Class Initialized
INFO - 2016-11-14 21:40:18 --> Model Class Initialized
INFO - 2016-11-14 21:40:18 --> Model Class Initialized
INFO - 2016-11-14 21:40:18 --> Model Class Initialized
INFO - 2016-11-14 21:40:18 --> Model Class Initialized
INFO - 2016-11-14 21:40:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:40:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-14 21:40:18 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\LMS\app\views\dashboard.php 225
INFO - 2016-11-14 21:40:38 --> Config Class Initialized
INFO - 2016-11-14 21:40:38 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:40:38 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:40:38 --> Utf8 Class Initialized
INFO - 2016-11-14 21:40:38 --> URI Class Initialized
DEBUG - 2016-11-14 21:40:38 --> No URI present. Default controller set.
INFO - 2016-11-14 21:40:38 --> Router Class Initialized
INFO - 2016-11-14 21:40:38 --> Output Class Initialized
INFO - 2016-11-14 21:40:38 --> Security Class Initialized
DEBUG - 2016-11-14 21:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:40:38 --> Input Class Initialized
INFO - 2016-11-14 21:40:38 --> Language Class Initialized
INFO - 2016-11-14 21:40:38 --> Loader Class Initialized
INFO - 2016-11-14 21:40:38 --> Helper loaded: url_helper
INFO - 2016-11-14 21:40:38 --> Helper loaded: form_helper
INFO - 2016-11-14 21:40:38 --> Database Driver Class Initialized
INFO - 2016-11-14 21:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:40:38 --> Controller Class Initialized
INFO - 2016-11-14 21:40:38 --> Model Class Initialized
INFO - 2016-11-14 21:40:39 --> Model Class Initialized
INFO - 2016-11-14 21:40:39 --> Model Class Initialized
INFO - 2016-11-14 21:40:39 --> Model Class Initialized
INFO - 2016-11-14 21:40:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:40:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:40:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:40:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:40:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:40:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:40:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:40:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:40:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:40:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:40:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:40:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:40:39 --> Final output sent to browser
DEBUG - 2016-11-14 21:40:39 --> Total execution time: 0.4735
INFO - 2016-11-14 21:41:05 --> Config Class Initialized
INFO - 2016-11-14 21:41:05 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:41:05 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:41:05 --> Utf8 Class Initialized
INFO - 2016-11-14 21:41:05 --> URI Class Initialized
DEBUG - 2016-11-14 21:41:05 --> No URI present. Default controller set.
INFO - 2016-11-14 21:41:05 --> Router Class Initialized
INFO - 2016-11-14 21:41:05 --> Output Class Initialized
INFO - 2016-11-14 21:41:05 --> Security Class Initialized
DEBUG - 2016-11-14 21:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:41:05 --> Input Class Initialized
INFO - 2016-11-14 21:41:05 --> Language Class Initialized
INFO - 2016-11-14 21:41:05 --> Loader Class Initialized
INFO - 2016-11-14 21:41:05 --> Helper loaded: url_helper
INFO - 2016-11-14 21:41:05 --> Helper loaded: form_helper
INFO - 2016-11-14 21:41:05 --> Database Driver Class Initialized
INFO - 2016-11-14 21:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:41:05 --> Controller Class Initialized
INFO - 2016-11-14 21:41:05 --> Model Class Initialized
INFO - 2016-11-14 21:41:05 --> Model Class Initialized
INFO - 2016-11-14 21:41:05 --> Model Class Initialized
INFO - 2016-11-14 21:41:05 --> Model Class Initialized
INFO - 2016-11-14 21:41:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:41:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-14 21:41:05 --> Severity: Parsing Error --> syntax error, unexpected 'idrole' (T_STRING), expecting ')' C:\xampp\htdocs\LMS\app\views\dashboard.php 79
INFO - 2016-11-14 21:41:15 --> Config Class Initialized
INFO - 2016-11-14 21:41:15 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:41:15 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:41:15 --> Utf8 Class Initialized
INFO - 2016-11-14 21:41:15 --> URI Class Initialized
DEBUG - 2016-11-14 21:41:15 --> No URI present. Default controller set.
INFO - 2016-11-14 21:41:15 --> Router Class Initialized
INFO - 2016-11-14 21:41:15 --> Output Class Initialized
INFO - 2016-11-14 21:41:15 --> Security Class Initialized
DEBUG - 2016-11-14 21:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:41:15 --> Input Class Initialized
INFO - 2016-11-14 21:41:15 --> Language Class Initialized
INFO - 2016-11-14 21:41:15 --> Loader Class Initialized
INFO - 2016-11-14 21:41:15 --> Helper loaded: url_helper
INFO - 2016-11-14 21:41:15 --> Helper loaded: form_helper
INFO - 2016-11-14 21:41:15 --> Database Driver Class Initialized
INFO - 2016-11-14 21:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:41:15 --> Controller Class Initialized
INFO - 2016-11-14 21:41:15 --> Model Class Initialized
INFO - 2016-11-14 21:41:15 --> Model Class Initialized
INFO - 2016-11-14 21:41:15 --> Model Class Initialized
INFO - 2016-11-14 21:41:15 --> Model Class Initialized
INFO - 2016-11-14 21:41:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:41:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-14 21:41:15 --> Severity: Parsing Error --> syntax error, unexpected 'array' (T_ARRAY) C:\xampp\htdocs\LMS\app\views\dashboard.php 65
INFO - 2016-11-14 21:41:49 --> Config Class Initialized
INFO - 2016-11-14 21:41:49 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:41:49 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:41:49 --> Utf8 Class Initialized
INFO - 2016-11-14 21:41:49 --> URI Class Initialized
DEBUG - 2016-11-14 21:41:49 --> No URI present. Default controller set.
INFO - 2016-11-14 21:41:49 --> Router Class Initialized
INFO - 2016-11-14 21:41:49 --> Output Class Initialized
INFO - 2016-11-14 21:41:49 --> Security Class Initialized
DEBUG - 2016-11-14 21:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:41:49 --> Input Class Initialized
INFO - 2016-11-14 21:41:49 --> Language Class Initialized
INFO - 2016-11-14 21:41:49 --> Loader Class Initialized
INFO - 2016-11-14 21:41:49 --> Helper loaded: url_helper
INFO - 2016-11-14 21:41:49 --> Helper loaded: form_helper
INFO - 2016-11-14 21:41:49 --> Database Driver Class Initialized
INFO - 2016-11-14 21:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:41:49 --> Controller Class Initialized
INFO - 2016-11-14 21:41:49 --> Model Class Initialized
INFO - 2016-11-14 21:41:49 --> Model Class Initialized
INFO - 2016-11-14 21:41:49 --> Model Class Initialized
INFO - 2016-11-14 21:41:49 --> Model Class Initialized
INFO - 2016-11-14 21:41:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:41:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:41:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:41:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:41:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:41:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:41:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:41:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:41:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:41:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:41:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:41:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:41:49 --> Final output sent to browser
DEBUG - 2016-11-14 21:41:49 --> Total execution time: 0.4634
INFO - 2016-11-14 21:41:57 --> Config Class Initialized
INFO - 2016-11-14 21:41:57 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:41:57 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:41:57 --> Utf8 Class Initialized
INFO - 2016-11-14 21:41:57 --> URI Class Initialized
INFO - 2016-11-14 21:41:57 --> Router Class Initialized
INFO - 2016-11-14 21:41:57 --> Output Class Initialized
INFO - 2016-11-14 21:41:57 --> Security Class Initialized
DEBUG - 2016-11-14 21:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:41:57 --> Input Class Initialized
INFO - 2016-11-14 21:41:57 --> Language Class Initialized
ERROR - 2016-11-14 21:41:57 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF), expecting ';' or '{' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 37
INFO - 2016-11-14 21:41:58 --> Config Class Initialized
INFO - 2016-11-14 21:41:58 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:41:58 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:41:58 --> Utf8 Class Initialized
INFO - 2016-11-14 21:41:58 --> URI Class Initialized
INFO - 2016-11-14 21:41:58 --> Router Class Initialized
INFO - 2016-11-14 21:41:58 --> Output Class Initialized
INFO - 2016-11-14 21:41:58 --> Security Class Initialized
DEBUG - 2016-11-14 21:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:41:58 --> Input Class Initialized
INFO - 2016-11-14 21:41:58 --> Language Class Initialized
ERROR - 2016-11-14 21:41:58 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF), expecting ';' or '{' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 37
INFO - 2016-11-14 21:41:58 --> Config Class Initialized
INFO - 2016-11-14 21:41:58 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:41:58 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:41:58 --> Utf8 Class Initialized
INFO - 2016-11-14 21:41:58 --> URI Class Initialized
INFO - 2016-11-14 21:41:58 --> Router Class Initialized
INFO - 2016-11-14 21:41:58 --> Output Class Initialized
INFO - 2016-11-14 21:41:58 --> Security Class Initialized
DEBUG - 2016-11-14 21:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:41:58 --> Input Class Initialized
INFO - 2016-11-14 21:41:58 --> Language Class Initialized
ERROR - 2016-11-14 21:41:58 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF), expecting ';' or '{' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 37
INFO - 2016-11-14 21:41:58 --> Config Class Initialized
INFO - 2016-11-14 21:41:58 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:41:58 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:41:58 --> Utf8 Class Initialized
INFO - 2016-11-14 21:41:58 --> URI Class Initialized
INFO - 2016-11-14 21:41:58 --> Router Class Initialized
INFO - 2016-11-14 21:41:58 --> Output Class Initialized
INFO - 2016-11-14 21:41:58 --> Security Class Initialized
DEBUG - 2016-11-14 21:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:41:58 --> Input Class Initialized
INFO - 2016-11-14 21:41:58 --> Language Class Initialized
ERROR - 2016-11-14 21:41:58 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF), expecting ';' or '{' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 37
INFO - 2016-11-14 21:42:02 --> Config Class Initialized
INFO - 2016-11-14 21:42:02 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:42:02 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:42:02 --> Utf8 Class Initialized
INFO - 2016-11-14 21:42:02 --> URI Class Initialized
INFO - 2016-11-14 21:42:02 --> Router Class Initialized
INFO - 2016-11-14 21:42:02 --> Output Class Initialized
INFO - 2016-11-14 21:42:02 --> Security Class Initialized
DEBUG - 2016-11-14 21:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:42:02 --> Input Class Initialized
INFO - 2016-11-14 21:42:02 --> Language Class Initialized
ERROR - 2016-11-14 21:42:02 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF), expecting ';' or '{' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 37
INFO - 2016-11-14 21:42:02 --> Config Class Initialized
INFO - 2016-11-14 21:42:02 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:42:02 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:42:02 --> Utf8 Class Initialized
INFO - 2016-11-14 21:42:02 --> URI Class Initialized
INFO - 2016-11-14 21:42:02 --> Router Class Initialized
INFO - 2016-11-14 21:42:02 --> Output Class Initialized
INFO - 2016-11-14 21:42:02 --> Security Class Initialized
DEBUG - 2016-11-14 21:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:42:02 --> Input Class Initialized
INFO - 2016-11-14 21:42:02 --> Language Class Initialized
ERROR - 2016-11-14 21:42:02 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF), expecting ';' or '{' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 37
INFO - 2016-11-14 21:42:02 --> Config Class Initialized
INFO - 2016-11-14 21:42:02 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:42:02 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:42:02 --> Utf8 Class Initialized
INFO - 2016-11-14 21:42:02 --> URI Class Initialized
INFO - 2016-11-14 21:42:02 --> Router Class Initialized
INFO - 2016-11-14 21:42:02 --> Output Class Initialized
INFO - 2016-11-14 21:42:02 --> Security Class Initialized
DEBUG - 2016-11-14 21:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:42:02 --> Input Class Initialized
INFO - 2016-11-14 21:42:02 --> Language Class Initialized
ERROR - 2016-11-14 21:42:02 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF), expecting ';' or '{' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 37
INFO - 2016-11-14 21:45:43 --> Config Class Initialized
INFO - 2016-11-14 21:45:43 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:45:43 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:45:43 --> Utf8 Class Initialized
INFO - 2016-11-14 21:45:43 --> URI Class Initialized
INFO - 2016-11-14 21:45:43 --> Router Class Initialized
INFO - 2016-11-14 21:45:43 --> Output Class Initialized
INFO - 2016-11-14 21:45:43 --> Security Class Initialized
DEBUG - 2016-11-14 21:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:45:43 --> Input Class Initialized
INFO - 2016-11-14 21:45:43 --> Language Class Initialized
INFO - 2016-11-14 21:45:43 --> Loader Class Initialized
INFO - 2016-11-14 21:45:43 --> Helper loaded: url_helper
INFO - 2016-11-14 21:45:43 --> Helper loaded: form_helper
INFO - 2016-11-14 21:45:43 --> Database Driver Class Initialized
INFO - 2016-11-14 21:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:45:43 --> Controller Class Initialized
INFO - 2016-11-14 21:45:43 --> Model Class Initialized
INFO - 2016-11-14 21:45:43 --> Form Validation Class Initialized
INFO - 2016-11-14 21:45:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-14 21:45:43 --> Final output sent to browser
DEBUG - 2016-11-14 21:45:43 --> Total execution time: 0.2723
INFO - 2016-11-14 21:45:55 --> Config Class Initialized
INFO - 2016-11-14 21:45:55 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:45:55 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:45:55 --> Utf8 Class Initialized
INFO - 2016-11-14 21:45:55 --> URI Class Initialized
INFO - 2016-11-14 21:45:55 --> Router Class Initialized
INFO - 2016-11-14 21:45:55 --> Output Class Initialized
INFO - 2016-11-14 21:45:55 --> Security Class Initialized
DEBUG - 2016-11-14 21:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:45:55 --> Input Class Initialized
INFO - 2016-11-14 21:45:55 --> Language Class Initialized
INFO - 2016-11-14 21:45:55 --> Loader Class Initialized
INFO - 2016-11-14 21:45:55 --> Helper loaded: url_helper
INFO - 2016-11-14 21:45:55 --> Helper loaded: form_helper
INFO - 2016-11-14 21:45:55 --> Database Driver Class Initialized
INFO - 2016-11-14 21:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:45:55 --> Controller Class Initialized
INFO - 2016-11-14 21:45:55 --> Model Class Initialized
INFO - 2016-11-14 21:45:55 --> Form Validation Class Initialized
INFO - 2016-11-14 21:45:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-14 21:45:55 --> Final output sent to browser
DEBUG - 2016-11-14 21:45:55 --> Total execution time: 0.3272
INFO - 2016-11-14 21:45:58 --> Config Class Initialized
INFO - 2016-11-14 21:45:58 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:45:58 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:45:58 --> Utf8 Class Initialized
INFO - 2016-11-14 21:45:58 --> URI Class Initialized
INFO - 2016-11-14 21:45:58 --> Router Class Initialized
INFO - 2016-11-14 21:45:58 --> Output Class Initialized
INFO - 2016-11-14 21:45:58 --> Security Class Initialized
DEBUG - 2016-11-14 21:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:45:58 --> Input Class Initialized
INFO - 2016-11-14 21:45:58 --> Language Class Initialized
INFO - 2016-11-14 21:45:58 --> Loader Class Initialized
INFO - 2016-11-14 21:45:58 --> Helper loaded: url_helper
INFO - 2016-11-14 21:45:58 --> Helper loaded: form_helper
INFO - 2016-11-14 21:45:58 --> Database Driver Class Initialized
INFO - 2016-11-14 21:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:45:58 --> Controller Class Initialized
INFO - 2016-11-14 21:45:58 --> Model Class Initialized
INFO - 2016-11-14 21:45:58 --> Form Validation Class Initialized
INFO - 2016-11-14 21:45:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-14 21:45:58 --> Final output sent to browser
DEBUG - 2016-11-14 21:45:58 --> Total execution time: 0.3373
INFO - 2016-11-14 21:48:42 --> Config Class Initialized
INFO - 2016-11-14 21:48:42 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:48:42 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:48:42 --> Utf8 Class Initialized
INFO - 2016-11-14 21:48:42 --> URI Class Initialized
INFO - 2016-11-14 21:48:42 --> Router Class Initialized
INFO - 2016-11-14 21:48:42 --> Output Class Initialized
INFO - 2016-11-14 21:48:42 --> Security Class Initialized
DEBUG - 2016-11-14 21:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:48:42 --> Input Class Initialized
INFO - 2016-11-14 21:48:42 --> Language Class Initialized
INFO - 2016-11-14 21:48:42 --> Loader Class Initialized
INFO - 2016-11-14 21:48:42 --> Helper loaded: url_helper
INFO - 2016-11-14 21:48:42 --> Helper loaded: form_helper
INFO - 2016-11-14 21:48:42 --> Database Driver Class Initialized
INFO - 2016-11-14 21:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:48:42 --> Controller Class Initialized
INFO - 2016-11-14 21:48:42 --> Model Class Initialized
INFO - 2016-11-14 21:48:42 --> Form Validation Class Initialized
INFO - 2016-11-14 21:48:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-14 21:48:42 --> Final output sent to browser
DEBUG - 2016-11-14 21:48:42 --> Total execution time: 0.3204
INFO - 2016-11-14 21:48:49 --> Config Class Initialized
INFO - 2016-11-14 21:48:49 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:48:49 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:48:49 --> Utf8 Class Initialized
INFO - 2016-11-14 21:48:49 --> URI Class Initialized
INFO - 2016-11-14 21:48:49 --> Router Class Initialized
INFO - 2016-11-14 21:48:50 --> Output Class Initialized
INFO - 2016-11-14 21:48:50 --> Security Class Initialized
DEBUG - 2016-11-14 21:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:48:50 --> Input Class Initialized
INFO - 2016-11-14 21:48:50 --> Language Class Initialized
INFO - 2016-11-14 21:48:50 --> Loader Class Initialized
INFO - 2016-11-14 21:48:50 --> Helper loaded: url_helper
INFO - 2016-11-14 21:48:50 --> Helper loaded: form_helper
INFO - 2016-11-14 21:48:50 --> Database Driver Class Initialized
INFO - 2016-11-14 21:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:48:50 --> Controller Class Initialized
INFO - 2016-11-14 21:48:50 --> Model Class Initialized
INFO - 2016-11-14 21:48:50 --> Form Validation Class Initialized
INFO - 2016-11-14 21:48:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-14 21:48:50 --> Final output sent to browser
DEBUG - 2016-11-14 21:48:50 --> Total execution time: 0.3153
INFO - 2016-11-14 21:48:54 --> Config Class Initialized
INFO - 2016-11-14 21:48:54 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:48:54 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:48:54 --> Utf8 Class Initialized
INFO - 2016-11-14 21:48:54 --> URI Class Initialized
INFO - 2016-11-14 21:48:54 --> Router Class Initialized
INFO - 2016-11-14 21:48:54 --> Output Class Initialized
INFO - 2016-11-14 21:48:54 --> Security Class Initialized
DEBUG - 2016-11-14 21:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:48:54 --> Input Class Initialized
INFO - 2016-11-14 21:48:54 --> Language Class Initialized
INFO - 2016-11-14 21:48:54 --> Loader Class Initialized
INFO - 2016-11-14 21:48:54 --> Helper loaded: url_helper
INFO - 2016-11-14 21:48:54 --> Helper loaded: form_helper
INFO - 2016-11-14 21:48:54 --> Database Driver Class Initialized
INFO - 2016-11-14 21:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:48:54 --> Controller Class Initialized
INFO - 2016-11-14 21:48:54 --> Model Class Initialized
INFO - 2016-11-14 21:48:54 --> Form Validation Class Initialized
INFO - 2016-11-14 21:48:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-14 21:48:54 --> Final output sent to browser
DEBUG - 2016-11-14 21:48:54 --> Total execution time: 0.3288
INFO - 2016-11-14 21:49:59 --> Config Class Initialized
INFO - 2016-11-14 21:49:59 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:49:59 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:49:59 --> Utf8 Class Initialized
INFO - 2016-11-14 21:49:59 --> URI Class Initialized
INFO - 2016-11-14 21:49:59 --> Router Class Initialized
INFO - 2016-11-14 21:49:59 --> Output Class Initialized
INFO - 2016-11-14 21:49:59 --> Security Class Initialized
DEBUG - 2016-11-14 21:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:49:59 --> Input Class Initialized
INFO - 2016-11-14 21:49:59 --> Language Class Initialized
ERROR - 2016-11-14 21:49:59 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:50:02 --> Config Class Initialized
INFO - 2016-11-14 21:50:02 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:50:02 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:50:02 --> Utf8 Class Initialized
INFO - 2016-11-14 21:50:02 --> URI Class Initialized
INFO - 2016-11-14 21:50:02 --> Router Class Initialized
INFO - 2016-11-14 21:50:02 --> Output Class Initialized
INFO - 2016-11-14 21:50:02 --> Security Class Initialized
DEBUG - 2016-11-14 21:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:50:02 --> Input Class Initialized
INFO - 2016-11-14 21:50:02 --> Language Class Initialized
ERROR - 2016-11-14 21:50:02 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:50:07 --> Config Class Initialized
INFO - 2016-11-14 21:50:07 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:50:07 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:50:07 --> Utf8 Class Initialized
INFO - 2016-11-14 21:50:07 --> URI Class Initialized
INFO - 2016-11-14 21:50:07 --> Router Class Initialized
INFO - 2016-11-14 21:50:07 --> Output Class Initialized
INFO - 2016-11-14 21:50:07 --> Security Class Initialized
DEBUG - 2016-11-14 21:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:50:07 --> Input Class Initialized
INFO - 2016-11-14 21:50:07 --> Language Class Initialized
ERROR - 2016-11-14 21:50:08 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:50:08 --> Config Class Initialized
INFO - 2016-11-14 21:50:08 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:50:08 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:50:08 --> Utf8 Class Initialized
INFO - 2016-11-14 21:50:08 --> URI Class Initialized
INFO - 2016-11-14 21:50:08 --> Router Class Initialized
INFO - 2016-11-14 21:50:08 --> Output Class Initialized
INFO - 2016-11-14 21:50:08 --> Security Class Initialized
DEBUG - 2016-11-14 21:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:50:08 --> Input Class Initialized
INFO - 2016-11-14 21:50:08 --> Language Class Initialized
ERROR - 2016-11-14 21:50:08 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:50:08 --> Config Class Initialized
INFO - 2016-11-14 21:50:08 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:50:08 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:50:08 --> Utf8 Class Initialized
INFO - 2016-11-14 21:50:08 --> URI Class Initialized
INFO - 2016-11-14 21:50:08 --> Router Class Initialized
INFO - 2016-11-14 21:50:08 --> Output Class Initialized
INFO - 2016-11-14 21:50:08 --> Security Class Initialized
DEBUG - 2016-11-14 21:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:50:08 --> Input Class Initialized
INFO - 2016-11-14 21:50:08 --> Language Class Initialized
ERROR - 2016-11-14 21:50:08 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:50:08 --> Config Class Initialized
INFO - 2016-11-14 21:50:08 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:50:08 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:50:08 --> Utf8 Class Initialized
INFO - 2016-11-14 21:50:08 --> URI Class Initialized
INFO - 2016-11-14 21:50:08 --> Router Class Initialized
INFO - 2016-11-14 21:50:08 --> Output Class Initialized
INFO - 2016-11-14 21:50:08 --> Security Class Initialized
DEBUG - 2016-11-14 21:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:50:08 --> Input Class Initialized
INFO - 2016-11-14 21:50:08 --> Language Class Initialized
ERROR - 2016-11-14 21:50:08 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:50:09 --> Config Class Initialized
INFO - 2016-11-14 21:50:09 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:50:09 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:50:09 --> Utf8 Class Initialized
INFO - 2016-11-14 21:50:09 --> URI Class Initialized
DEBUG - 2016-11-14 21:50:09 --> No URI present. Default controller set.
INFO - 2016-11-14 21:50:09 --> Router Class Initialized
INFO - 2016-11-14 21:50:09 --> Output Class Initialized
INFO - 2016-11-14 21:50:09 --> Security Class Initialized
DEBUG - 2016-11-14 21:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:50:09 --> Input Class Initialized
INFO - 2016-11-14 21:50:09 --> Language Class Initialized
INFO - 2016-11-14 21:50:09 --> Loader Class Initialized
INFO - 2016-11-14 21:50:09 --> Helper loaded: url_helper
INFO - 2016-11-14 21:50:09 --> Helper loaded: form_helper
INFO - 2016-11-14 21:50:09 --> Database Driver Class Initialized
INFO - 2016-11-14 21:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:50:09 --> Controller Class Initialized
INFO - 2016-11-14 21:50:09 --> Model Class Initialized
INFO - 2016-11-14 21:50:09 --> Model Class Initialized
INFO - 2016-11-14 21:50:09 --> Model Class Initialized
INFO - 2016-11-14 21:50:09 --> Model Class Initialized
INFO - 2016-11-14 21:50:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:50:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:50:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:50:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:50:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:50:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:50:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:50:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:50:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:50:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:50:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:50:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:50:09 --> Final output sent to browser
DEBUG - 2016-11-14 21:50:10 --> Total execution time: 0.5133
INFO - 2016-11-14 21:50:18 --> Config Class Initialized
INFO - 2016-11-14 21:50:18 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:50:18 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:50:18 --> Utf8 Class Initialized
INFO - 2016-11-14 21:50:18 --> URI Class Initialized
INFO - 2016-11-14 21:50:18 --> Router Class Initialized
INFO - 2016-11-14 21:50:18 --> Output Class Initialized
INFO - 2016-11-14 21:50:18 --> Security Class Initialized
DEBUG - 2016-11-14 21:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:50:18 --> Input Class Initialized
INFO - 2016-11-14 21:50:18 --> Language Class Initialized
ERROR - 2016-11-14 21:50:18 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:50:18 --> Config Class Initialized
INFO - 2016-11-14 21:50:18 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:50:18 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:50:18 --> Utf8 Class Initialized
INFO - 2016-11-14 21:50:18 --> URI Class Initialized
INFO - 2016-11-14 21:50:18 --> Router Class Initialized
INFO - 2016-11-14 21:50:18 --> Output Class Initialized
INFO - 2016-11-14 21:50:18 --> Security Class Initialized
DEBUG - 2016-11-14 21:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:50:18 --> Input Class Initialized
INFO - 2016-11-14 21:50:18 --> Language Class Initialized
ERROR - 2016-11-14 21:50:18 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:50:18 --> Config Class Initialized
INFO - 2016-11-14 21:50:18 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:50:18 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:50:18 --> Utf8 Class Initialized
INFO - 2016-11-14 21:50:18 --> URI Class Initialized
INFO - 2016-11-14 21:50:18 --> Router Class Initialized
INFO - 2016-11-14 21:50:18 --> Output Class Initialized
INFO - 2016-11-14 21:50:18 --> Security Class Initialized
DEBUG - 2016-11-14 21:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:50:18 --> Input Class Initialized
INFO - 2016-11-14 21:50:18 --> Language Class Initialized
ERROR - 2016-11-14 21:50:18 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:50:18 --> Config Class Initialized
INFO - 2016-11-14 21:50:18 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:50:18 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:50:18 --> Utf8 Class Initialized
INFO - 2016-11-14 21:50:18 --> URI Class Initialized
INFO - 2016-11-14 21:50:18 --> Router Class Initialized
INFO - 2016-11-14 21:50:18 --> Output Class Initialized
INFO - 2016-11-14 21:50:18 --> Security Class Initialized
DEBUG - 2016-11-14 21:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:50:18 --> Input Class Initialized
INFO - 2016-11-14 21:50:18 --> Language Class Initialized
ERROR - 2016-11-14 21:50:18 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:50:18 --> Config Class Initialized
INFO - 2016-11-14 21:50:18 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:50:18 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:50:18 --> Utf8 Class Initialized
INFO - 2016-11-14 21:50:18 --> URI Class Initialized
INFO - 2016-11-14 21:50:18 --> Router Class Initialized
INFO - 2016-11-14 21:50:18 --> Output Class Initialized
INFO - 2016-11-14 21:50:18 --> Security Class Initialized
DEBUG - 2016-11-14 21:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:50:18 --> Input Class Initialized
INFO - 2016-11-14 21:50:18 --> Language Class Initialized
INFO - 2016-11-14 21:50:18 --> Config Class Initialized
ERROR - 2016-11-14 21:50:19 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:50:19 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:50:19 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:50:19 --> Utf8 Class Initialized
INFO - 2016-11-14 21:50:19 --> URI Class Initialized
INFO - 2016-11-14 21:50:19 --> Config Class Initialized
INFO - 2016-11-14 21:50:19 --> Router Class Initialized
INFO - 2016-11-14 21:50:19 --> Hooks Class Initialized
INFO - 2016-11-14 21:50:19 --> Output Class Initialized
DEBUG - 2016-11-14 21:50:19 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:50:19 --> Security Class Initialized
INFO - 2016-11-14 21:50:19 --> Utf8 Class Initialized
INFO - 2016-11-14 21:50:19 --> URI Class Initialized
DEBUG - 2016-11-14 21:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:50:19 --> Router Class Initialized
INFO - 2016-11-14 21:50:19 --> Input Class Initialized
INFO - 2016-11-14 21:50:19 --> Language Class Initialized
INFO - 2016-11-14 21:50:19 --> Output Class Initialized
ERROR - 2016-11-14 21:50:19 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:50:19 --> Security Class Initialized
INFO - 2016-11-14 21:50:19 --> Config Class Initialized
DEBUG - 2016-11-14 21:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:50:19 --> Hooks Class Initialized
INFO - 2016-11-14 21:50:19 --> Input Class Initialized
DEBUG - 2016-11-14 21:50:19 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:50:19 --> Language Class Initialized
INFO - 2016-11-14 21:50:19 --> Utf8 Class Initialized
INFO - 2016-11-14 21:50:19 --> URI Class Initialized
ERROR - 2016-11-14 21:50:19 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:50:19 --> Router Class Initialized
INFO - 2016-11-14 21:50:19 --> Output Class Initialized
INFO - 2016-11-14 21:50:19 --> Security Class Initialized
DEBUG - 2016-11-14 21:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:50:19 --> Input Class Initialized
INFO - 2016-11-14 21:50:19 --> Language Class Initialized
ERROR - 2016-11-14 21:50:19 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:50:19 --> Config Class Initialized
INFO - 2016-11-14 21:50:19 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:50:19 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:50:19 --> Utf8 Class Initialized
INFO - 2016-11-14 21:50:19 --> URI Class Initialized
INFO - 2016-11-14 21:50:19 --> Router Class Initialized
INFO - 2016-11-14 21:50:19 --> Output Class Initialized
INFO - 2016-11-14 21:50:19 --> Security Class Initialized
DEBUG - 2016-11-14 21:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:50:19 --> Input Class Initialized
INFO - 2016-11-14 21:50:19 --> Language Class Initialized
ERROR - 2016-11-14 21:50:19 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:50:19 --> Config Class Initialized
INFO - 2016-11-14 21:50:19 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:50:19 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:50:19 --> Utf8 Class Initialized
INFO - 2016-11-14 21:50:19 --> URI Class Initialized
INFO - 2016-11-14 21:50:19 --> Router Class Initialized
INFO - 2016-11-14 21:50:19 --> Output Class Initialized
INFO - 2016-11-14 21:50:19 --> Security Class Initialized
DEBUG - 2016-11-14 21:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:50:19 --> Input Class Initialized
INFO - 2016-11-14 21:50:19 --> Language Class Initialized
ERROR - 2016-11-14 21:50:19 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:50:19 --> Config Class Initialized
INFO - 2016-11-14 21:50:20 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:50:20 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:50:20 --> Utf8 Class Initialized
INFO - 2016-11-14 21:50:20 --> URI Class Initialized
INFO - 2016-11-14 21:50:20 --> Router Class Initialized
INFO - 2016-11-14 21:50:20 --> Output Class Initialized
INFO - 2016-11-14 21:50:20 --> Security Class Initialized
DEBUG - 2016-11-14 21:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:50:20 --> Input Class Initialized
INFO - 2016-11-14 21:50:20 --> Language Class Initialized
ERROR - 2016-11-14 21:50:20 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:51:00 --> Config Class Initialized
INFO - 2016-11-14 21:51:00 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:51:00 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:51:00 --> Utf8 Class Initialized
INFO - 2016-11-14 21:51:00 --> URI Class Initialized
INFO - 2016-11-14 21:51:00 --> Router Class Initialized
INFO - 2016-11-14 21:51:00 --> Output Class Initialized
INFO - 2016-11-14 21:51:00 --> Security Class Initialized
DEBUG - 2016-11-14 21:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:51:01 --> Input Class Initialized
INFO - 2016-11-14 21:51:01 --> Language Class Initialized
ERROR - 2016-11-14 21:51:01 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:51:01 --> Config Class Initialized
INFO - 2016-11-14 21:51:01 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:51:01 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:51:01 --> Utf8 Class Initialized
INFO - 2016-11-14 21:51:01 --> URI Class Initialized
INFO - 2016-11-14 21:51:01 --> Router Class Initialized
INFO - 2016-11-14 21:51:01 --> Output Class Initialized
INFO - 2016-11-14 21:51:01 --> Security Class Initialized
DEBUG - 2016-11-14 21:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:51:01 --> Input Class Initialized
INFO - 2016-11-14 21:51:01 --> Language Class Initialized
ERROR - 2016-11-14 21:51:01 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:51:01 --> Config Class Initialized
INFO - 2016-11-14 21:51:01 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:51:01 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:51:01 --> Utf8 Class Initialized
INFO - 2016-11-14 21:51:01 --> URI Class Initialized
INFO - 2016-11-14 21:51:01 --> Router Class Initialized
INFO - 2016-11-14 21:51:01 --> Output Class Initialized
INFO - 2016-11-14 21:51:01 --> Security Class Initialized
DEBUG - 2016-11-14 21:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:51:01 --> Input Class Initialized
INFO - 2016-11-14 21:51:01 --> Language Class Initialized
ERROR - 2016-11-14 21:51:01 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:51:05 --> Config Class Initialized
INFO - 2016-11-14 21:51:05 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:51:05 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:51:05 --> Utf8 Class Initialized
INFO - 2016-11-14 21:51:05 --> URI Class Initialized
INFO - 2016-11-14 21:51:05 --> Router Class Initialized
INFO - 2016-11-14 21:51:05 --> Output Class Initialized
INFO - 2016-11-14 21:51:05 --> Security Class Initialized
DEBUG - 2016-11-14 21:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:51:05 --> Input Class Initialized
INFO - 2016-11-14 21:51:05 --> Language Class Initialized
ERROR - 2016-11-14 21:51:05 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:51:05 --> Config Class Initialized
INFO - 2016-11-14 21:51:05 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:51:05 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:51:05 --> Utf8 Class Initialized
INFO - 2016-11-14 21:51:05 --> URI Class Initialized
INFO - 2016-11-14 21:51:05 --> Router Class Initialized
INFO - 2016-11-14 21:51:05 --> Output Class Initialized
INFO - 2016-11-14 21:51:05 --> Security Class Initialized
DEBUG - 2016-11-14 21:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:51:05 --> Input Class Initialized
INFO - 2016-11-14 21:51:05 --> Language Class Initialized
ERROR - 2016-11-14 21:51:05 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:51:06 --> Config Class Initialized
INFO - 2016-11-14 21:51:06 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:51:06 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:51:06 --> Utf8 Class Initialized
INFO - 2016-11-14 21:51:06 --> URI Class Initialized
INFO - 2016-11-14 21:51:06 --> Router Class Initialized
INFO - 2016-11-14 21:51:06 --> Output Class Initialized
INFO - 2016-11-14 21:51:06 --> Security Class Initialized
DEBUG - 2016-11-14 21:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:51:06 --> Input Class Initialized
INFO - 2016-11-14 21:51:06 --> Config Class Initialized
INFO - 2016-11-14 21:51:06 --> Language Class Initialized
INFO - 2016-11-14 21:51:06 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:51:06 --> UTF-8 Support Enabled
ERROR - 2016-11-14 21:51:06 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:51:06 --> Utf8 Class Initialized
INFO - 2016-11-14 21:51:06 --> URI Class Initialized
INFO - 2016-11-14 21:51:06 --> Router Class Initialized
INFO - 2016-11-14 21:51:06 --> Output Class Initialized
INFO - 2016-11-14 21:51:06 --> Security Class Initialized
DEBUG - 2016-11-14 21:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:51:06 --> Input Class Initialized
INFO - 2016-11-14 21:51:06 --> Config Class Initialized
INFO - 2016-11-14 21:51:06 --> Language Class Initialized
INFO - 2016-11-14 21:51:06 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:51:06 --> UTF-8 Support Enabled
ERROR - 2016-11-14 21:51:06 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:51:06 --> Utf8 Class Initialized
INFO - 2016-11-14 21:51:06 --> URI Class Initialized
INFO - 2016-11-14 21:51:06 --> Router Class Initialized
INFO - 2016-11-14 21:51:06 --> Output Class Initialized
INFO - 2016-11-14 21:51:06 --> Security Class Initialized
DEBUG - 2016-11-14 21:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:51:06 --> Config Class Initialized
INFO - 2016-11-14 21:51:06 --> Input Class Initialized
INFO - 2016-11-14 21:51:06 --> Hooks Class Initialized
INFO - 2016-11-14 21:51:06 --> Language Class Initialized
DEBUG - 2016-11-14 21:51:06 --> UTF-8 Support Enabled
ERROR - 2016-11-14 21:51:06 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:51:06 --> Utf8 Class Initialized
INFO - 2016-11-14 21:51:06 --> URI Class Initialized
INFO - 2016-11-14 21:51:06 --> Router Class Initialized
INFO - 2016-11-14 21:51:06 --> Output Class Initialized
INFO - 2016-11-14 21:51:06 --> Security Class Initialized
DEBUG - 2016-11-14 21:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:51:06 --> Input Class Initialized
INFO - 2016-11-14 21:51:06 --> Language Class Initialized
INFO - 2016-11-14 21:51:06 --> Config Class Initialized
ERROR - 2016-11-14 21:51:06 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:51:06 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:51:06 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:51:06 --> Utf8 Class Initialized
INFO - 2016-11-14 21:51:06 --> URI Class Initialized
INFO - 2016-11-14 21:51:06 --> Router Class Initialized
INFO - 2016-11-14 21:51:06 --> Output Class Initialized
INFO - 2016-11-14 21:51:06 --> Security Class Initialized
DEBUG - 2016-11-14 21:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:51:06 --> Input Class Initialized
INFO - 2016-11-14 21:51:06 --> Language Class Initialized
INFO - 2016-11-14 21:51:06 --> Config Class Initialized
ERROR - 2016-11-14 21:51:06 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:51:06 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:51:06 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:51:06 --> Utf8 Class Initialized
INFO - 2016-11-14 21:51:06 --> URI Class Initialized
INFO - 2016-11-14 21:51:06 --> Router Class Initialized
INFO - 2016-11-14 21:51:06 --> Output Class Initialized
INFO - 2016-11-14 21:51:06 --> Security Class Initialized
DEBUG - 2016-11-14 21:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:51:07 --> Input Class Initialized
INFO - 2016-11-14 21:51:07 --> Language Class Initialized
INFO - 2016-11-14 21:51:07 --> Config Class Initialized
ERROR - 2016-11-14 21:51:07 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:51:07 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:51:07 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:51:07 --> Utf8 Class Initialized
INFO - 2016-11-14 21:51:07 --> URI Class Initialized
INFO - 2016-11-14 21:51:07 --> Router Class Initialized
INFO - 2016-11-14 21:51:07 --> Output Class Initialized
INFO - 2016-11-14 21:51:07 --> Security Class Initialized
DEBUG - 2016-11-14 21:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:51:07 --> Input Class Initialized
INFO - 2016-11-14 21:51:07 --> Language Class Initialized
ERROR - 2016-11-14 21:51:07 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:51:07 --> Config Class Initialized
INFO - 2016-11-14 21:51:07 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:51:07 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:51:07 --> Utf8 Class Initialized
INFO - 2016-11-14 21:51:07 --> URI Class Initialized
INFO - 2016-11-14 21:51:07 --> Router Class Initialized
INFO - 2016-11-14 21:51:07 --> Output Class Initialized
INFO - 2016-11-14 21:51:07 --> Security Class Initialized
DEBUG - 2016-11-14 21:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:51:07 --> Input Class Initialized
INFO - 2016-11-14 21:51:07 --> Language Class Initialized
ERROR - 2016-11-14 21:51:07 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:51:07 --> Config Class Initialized
INFO - 2016-11-14 21:51:07 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:51:07 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:51:07 --> Utf8 Class Initialized
INFO - 2016-11-14 21:51:07 --> URI Class Initialized
INFO - 2016-11-14 21:51:07 --> Router Class Initialized
INFO - 2016-11-14 21:51:07 --> Output Class Initialized
INFO - 2016-11-14 21:51:07 --> Security Class Initialized
DEBUG - 2016-11-14 21:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:51:07 --> Input Class Initialized
INFO - 2016-11-14 21:51:07 --> Language Class Initialized
ERROR - 2016-11-14 21:51:07 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:51:07 --> Config Class Initialized
INFO - 2016-11-14 21:51:07 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:51:07 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:51:07 --> Utf8 Class Initialized
INFO - 2016-11-14 21:51:07 --> URI Class Initialized
INFO - 2016-11-14 21:51:07 --> Router Class Initialized
INFO - 2016-11-14 21:51:07 --> Output Class Initialized
INFO - 2016-11-14 21:51:07 --> Security Class Initialized
DEBUG - 2016-11-14 21:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:51:07 --> Input Class Initialized
INFO - 2016-11-14 21:51:07 --> Language Class Initialized
ERROR - 2016-11-14 21:51:07 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:51:07 --> Config Class Initialized
INFO - 2016-11-14 21:51:07 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:51:07 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:51:07 --> Utf8 Class Initialized
INFO - 2016-11-14 21:51:07 --> URI Class Initialized
INFO - 2016-11-14 21:51:07 --> Router Class Initialized
INFO - 2016-11-14 21:51:07 --> Output Class Initialized
INFO - 2016-11-14 21:51:07 --> Security Class Initialized
DEBUG - 2016-11-14 21:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:51:07 --> Input Class Initialized
INFO - 2016-11-14 21:51:07 --> Language Class Initialized
ERROR - 2016-11-14 21:51:07 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:51:07 --> Config Class Initialized
INFO - 2016-11-14 21:51:07 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:51:08 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:51:08 --> Utf8 Class Initialized
INFO - 2016-11-14 21:51:08 --> URI Class Initialized
INFO - 2016-11-14 21:51:08 --> Router Class Initialized
INFO - 2016-11-14 21:51:08 --> Output Class Initialized
INFO - 2016-11-14 21:51:08 --> Security Class Initialized
DEBUG - 2016-11-14 21:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:51:08 --> Input Class Initialized
INFO - 2016-11-14 21:51:08 --> Language Class Initialized
ERROR - 2016-11-14 21:51:08 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:51:08 --> Config Class Initialized
INFO - 2016-11-14 21:51:08 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:51:08 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:51:08 --> Utf8 Class Initialized
INFO - 2016-11-14 21:51:08 --> URI Class Initialized
INFO - 2016-11-14 21:51:08 --> Router Class Initialized
INFO - 2016-11-14 21:51:08 --> Output Class Initialized
INFO - 2016-11-14 21:51:08 --> Config Class Initialized
INFO - 2016-11-14 21:51:08 --> Security Class Initialized
INFO - 2016-11-14 21:51:08 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:51:08 --> Input Class Initialized
DEBUG - 2016-11-14 21:51:08 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:51:08 --> Utf8 Class Initialized
INFO - 2016-11-14 21:51:08 --> Language Class Initialized
INFO - 2016-11-14 21:51:08 --> URI Class Initialized
ERROR - 2016-11-14 21:51:08 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:51:08 --> Router Class Initialized
INFO - 2016-11-14 21:51:08 --> Output Class Initialized
INFO - 2016-11-14 21:51:08 --> Security Class Initialized
DEBUG - 2016-11-14 21:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:51:08 --> Input Class Initialized
INFO - 2016-11-14 21:51:08 --> Language Class Initialized
ERROR - 2016-11-14 21:51:08 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:51:10 --> Config Class Initialized
INFO - 2016-11-14 21:51:10 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:51:10 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:51:10 --> Utf8 Class Initialized
INFO - 2016-11-14 21:51:10 --> URI Class Initialized
INFO - 2016-11-14 21:51:10 --> Router Class Initialized
INFO - 2016-11-14 21:51:10 --> Output Class Initialized
INFO - 2016-11-14 21:51:10 --> Security Class Initialized
DEBUG - 2016-11-14 21:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:51:10 --> Input Class Initialized
INFO - 2016-11-14 21:51:10 --> Language Class Initialized
ERROR - 2016-11-14 21:51:10 --> Severity: Parsing Error --> syntax error, unexpected ''description'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 57
INFO - 2016-11-14 21:54:05 --> Config Class Initialized
INFO - 2016-11-14 21:54:05 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:54:05 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:54:05 --> Utf8 Class Initialized
INFO - 2016-11-14 21:54:05 --> URI Class Initialized
DEBUG - 2016-11-14 21:54:05 --> No URI present. Default controller set.
INFO - 2016-11-14 21:54:05 --> Router Class Initialized
INFO - 2016-11-14 21:54:05 --> Output Class Initialized
INFO - 2016-11-14 21:54:05 --> Security Class Initialized
DEBUG - 2016-11-14 21:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:54:05 --> Input Class Initialized
INFO - 2016-11-14 21:54:05 --> Language Class Initialized
INFO - 2016-11-14 21:54:05 --> Loader Class Initialized
INFO - 2016-11-14 21:54:05 --> Helper loaded: url_helper
INFO - 2016-11-14 21:54:05 --> Helper loaded: form_helper
INFO - 2016-11-14 21:54:05 --> Database Driver Class Initialized
INFO - 2016-11-14 21:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:54:05 --> Controller Class Initialized
INFO - 2016-11-14 21:54:05 --> Model Class Initialized
INFO - 2016-11-14 21:54:05 --> Model Class Initialized
INFO - 2016-11-14 21:54:05 --> Model Class Initialized
INFO - 2016-11-14 21:54:05 --> Model Class Initialized
INFO - 2016-11-14 21:54:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:54:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:54:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:54:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:54:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:54:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:54:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:54:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:54:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:54:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:54:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:54:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:54:05 --> Final output sent to browser
DEBUG - 2016-11-14 21:54:05 --> Total execution time: 0.5148
INFO - 2016-11-14 21:54:13 --> Config Class Initialized
INFO - 2016-11-14 21:54:13 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:54:13 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:54:13 --> Utf8 Class Initialized
INFO - 2016-11-14 21:54:13 --> URI Class Initialized
INFO - 2016-11-14 21:54:13 --> Router Class Initialized
INFO - 2016-11-14 21:54:13 --> Output Class Initialized
INFO - 2016-11-14 21:54:13 --> Security Class Initialized
DEBUG - 2016-11-14 21:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:54:13 --> Input Class Initialized
INFO - 2016-11-14 21:54:13 --> Language Class Initialized
INFO - 2016-11-14 21:54:13 --> Loader Class Initialized
INFO - 2016-11-14 21:54:13 --> Helper loaded: url_helper
INFO - 2016-11-14 21:54:13 --> Helper loaded: form_helper
INFO - 2016-11-14 21:54:14 --> Database Driver Class Initialized
INFO - 2016-11-14 21:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:54:14 --> Controller Class Initialized
INFO - 2016-11-14 21:54:14 --> Model Class Initialized
INFO - 2016-11-14 21:54:14 --> Form Validation Class Initialized
INFO - 2016-11-14 21:54:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-14 21:54:14 --> Final output sent to browser
DEBUG - 2016-11-14 21:54:14 --> Total execution time: 0.2875
INFO - 2016-11-14 21:54:17 --> Config Class Initialized
INFO - 2016-11-14 21:54:17 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:54:17 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:54:17 --> Utf8 Class Initialized
INFO - 2016-11-14 21:54:17 --> URI Class Initialized
INFO - 2016-11-14 21:54:17 --> Router Class Initialized
INFO - 2016-11-14 21:54:17 --> Output Class Initialized
INFO - 2016-11-14 21:54:17 --> Security Class Initialized
DEBUG - 2016-11-14 21:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:54:17 --> Input Class Initialized
INFO - 2016-11-14 21:54:17 --> Language Class Initialized
INFO - 2016-11-14 21:54:17 --> Loader Class Initialized
INFO - 2016-11-14 21:54:17 --> Helper loaded: url_helper
INFO - 2016-11-14 21:54:17 --> Helper loaded: form_helper
INFO - 2016-11-14 21:54:17 --> Database Driver Class Initialized
INFO - 2016-11-14 21:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:54:17 --> Controller Class Initialized
INFO - 2016-11-14 21:54:17 --> Model Class Initialized
INFO - 2016-11-14 21:54:17 --> Form Validation Class Initialized
INFO - 2016-11-14 21:54:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-14 21:54:17 --> Final output sent to browser
DEBUG - 2016-11-14 21:54:17 --> Total execution time: 0.3373
INFO - 2016-11-14 21:55:20 --> Config Class Initialized
INFO - 2016-11-14 21:55:20 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:55:20 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:55:20 --> Utf8 Class Initialized
INFO - 2016-11-14 21:55:20 --> URI Class Initialized
INFO - 2016-11-14 21:55:20 --> Router Class Initialized
INFO - 2016-11-14 21:55:21 --> Output Class Initialized
INFO - 2016-11-14 21:55:21 --> Security Class Initialized
DEBUG - 2016-11-14 21:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:55:21 --> Input Class Initialized
INFO - 2016-11-14 21:55:21 --> Language Class Initialized
INFO - 2016-11-14 21:55:21 --> Loader Class Initialized
INFO - 2016-11-14 21:55:21 --> Helper loaded: url_helper
INFO - 2016-11-14 21:55:21 --> Helper loaded: form_helper
INFO - 2016-11-14 21:55:21 --> Database Driver Class Initialized
INFO - 2016-11-14 21:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:55:21 --> Controller Class Initialized
INFO - 2016-11-14 21:55:21 --> Model Class Initialized
INFO - 2016-11-14 21:55:21 --> Form Validation Class Initialized
INFO - 2016-11-14 21:55:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-14 21:55:21 --> Final output sent to browser
DEBUG - 2016-11-14 21:55:21 --> Total execution time: 0.3553
INFO - 2016-11-14 21:55:36 --> Config Class Initialized
INFO - 2016-11-14 21:55:36 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:55:36 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:55:36 --> Utf8 Class Initialized
INFO - 2016-11-14 21:55:36 --> URI Class Initialized
DEBUG - 2016-11-14 21:55:36 --> No URI present. Default controller set.
INFO - 2016-11-14 21:55:36 --> Router Class Initialized
INFO - 2016-11-14 21:55:36 --> Output Class Initialized
INFO - 2016-11-14 21:55:36 --> Security Class Initialized
DEBUG - 2016-11-14 21:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:55:36 --> Input Class Initialized
INFO - 2016-11-14 21:55:36 --> Language Class Initialized
INFO - 2016-11-14 21:55:36 --> Loader Class Initialized
INFO - 2016-11-14 21:55:36 --> Helper loaded: url_helper
INFO - 2016-11-14 21:55:36 --> Helper loaded: form_helper
INFO - 2016-11-14 21:55:36 --> Database Driver Class Initialized
INFO - 2016-11-14 21:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:55:36 --> Controller Class Initialized
INFO - 2016-11-14 21:55:36 --> Model Class Initialized
INFO - 2016-11-14 21:55:36 --> Model Class Initialized
INFO - 2016-11-14 21:55:36 --> Model Class Initialized
INFO - 2016-11-14 21:55:36 --> Model Class Initialized
INFO - 2016-11-14 21:55:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:55:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:55:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:55:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:55:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:55:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:55:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:55:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:55:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:55:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:55:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:55:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:55:36 --> Final output sent to browser
DEBUG - 2016-11-14 21:55:36 --> Total execution time: 0.5352
INFO - 2016-11-14 21:55:41 --> Config Class Initialized
INFO - 2016-11-14 21:55:41 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:55:41 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:55:41 --> Utf8 Class Initialized
INFO - 2016-11-14 21:55:41 --> URI Class Initialized
INFO - 2016-11-14 21:55:41 --> Router Class Initialized
INFO - 2016-11-14 21:55:41 --> Output Class Initialized
INFO - 2016-11-14 21:55:41 --> Security Class Initialized
DEBUG - 2016-11-14 21:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:55:41 --> Input Class Initialized
INFO - 2016-11-14 21:55:41 --> Language Class Initialized
ERROR - 2016-11-14 21:55:41 --> Severity: Parsing Error --> syntax error, unexpected ']' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 40
INFO - 2016-11-14 21:55:42 --> Config Class Initialized
INFO - 2016-11-14 21:55:42 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:55:42 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:55:42 --> Utf8 Class Initialized
INFO - 2016-11-14 21:55:42 --> URI Class Initialized
INFO - 2016-11-14 21:55:42 --> Router Class Initialized
INFO - 2016-11-14 21:55:42 --> Output Class Initialized
INFO - 2016-11-14 21:55:42 --> Security Class Initialized
DEBUG - 2016-11-14 21:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:55:42 --> Input Class Initialized
INFO - 2016-11-14 21:55:42 --> Language Class Initialized
ERROR - 2016-11-14 21:55:42 --> Severity: Parsing Error --> syntax error, unexpected ']' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 40
INFO - 2016-11-14 21:55:42 --> Config Class Initialized
INFO - 2016-11-14 21:55:42 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:55:42 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:55:42 --> Utf8 Class Initialized
INFO - 2016-11-14 21:55:42 --> URI Class Initialized
INFO - 2016-11-14 21:55:42 --> Router Class Initialized
INFO - 2016-11-14 21:55:42 --> Output Class Initialized
INFO - 2016-11-14 21:55:42 --> Security Class Initialized
DEBUG - 2016-11-14 21:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:55:42 --> Input Class Initialized
INFO - 2016-11-14 21:55:42 --> Config Class Initialized
INFO - 2016-11-14 21:55:42 --> Language Class Initialized
INFO - 2016-11-14 21:55:42 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:55:42 --> UTF-8 Support Enabled
ERROR - 2016-11-14 21:55:42 --> Severity: Parsing Error --> syntax error, unexpected ']' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 40
INFO - 2016-11-14 21:55:42 --> Utf8 Class Initialized
INFO - 2016-11-14 21:55:42 --> URI Class Initialized
INFO - 2016-11-14 21:55:42 --> Router Class Initialized
INFO - 2016-11-14 21:55:42 --> Output Class Initialized
INFO - 2016-11-14 21:55:42 --> Security Class Initialized
DEBUG - 2016-11-14 21:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:55:42 --> Input Class Initialized
INFO - 2016-11-14 21:55:42 --> Language Class Initialized
ERROR - 2016-11-14 21:55:42 --> Severity: Parsing Error --> syntax error, unexpected ']' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 40
INFO - 2016-11-14 21:55:59 --> Config Class Initialized
INFO - 2016-11-14 21:55:59 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:55:59 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:55:59 --> Utf8 Class Initialized
INFO - 2016-11-14 21:55:59 --> URI Class Initialized
DEBUG - 2016-11-14 21:55:59 --> No URI present. Default controller set.
INFO - 2016-11-14 21:55:59 --> Router Class Initialized
INFO - 2016-11-14 21:55:59 --> Output Class Initialized
INFO - 2016-11-14 21:55:59 --> Security Class Initialized
DEBUG - 2016-11-14 21:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:55:59 --> Input Class Initialized
INFO - 2016-11-14 21:55:59 --> Language Class Initialized
INFO - 2016-11-14 21:55:59 --> Loader Class Initialized
INFO - 2016-11-14 21:55:59 --> Helper loaded: url_helper
INFO - 2016-11-14 21:55:59 --> Helper loaded: form_helper
INFO - 2016-11-14 21:55:59 --> Database Driver Class Initialized
INFO - 2016-11-14 21:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:55:59 --> Controller Class Initialized
INFO - 2016-11-14 21:55:59 --> Model Class Initialized
INFO - 2016-11-14 21:55:59 --> Model Class Initialized
INFO - 2016-11-14 21:55:59 --> Model Class Initialized
INFO - 2016-11-14 21:55:59 --> Model Class Initialized
INFO - 2016-11-14 21:55:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:55:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:55:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:55:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:55:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:55:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:55:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:55:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:55:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:55:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:55:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:55:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:55:59 --> Final output sent to browser
DEBUG - 2016-11-14 21:55:59 --> Total execution time: 0.5234
INFO - 2016-11-14 21:56:04 --> Config Class Initialized
INFO - 2016-11-14 21:56:04 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:56:04 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:56:04 --> Utf8 Class Initialized
INFO - 2016-11-14 21:56:04 --> URI Class Initialized
INFO - 2016-11-14 21:56:04 --> Router Class Initialized
INFO - 2016-11-14 21:56:04 --> Output Class Initialized
INFO - 2016-11-14 21:56:04 --> Security Class Initialized
DEBUG - 2016-11-14 21:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:56:04 --> Input Class Initialized
INFO - 2016-11-14 21:56:04 --> Language Class Initialized
ERROR - 2016-11-14 21:56:04 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 31
INFO - 2016-11-14 21:56:04 --> Config Class Initialized
INFO - 2016-11-14 21:56:04 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:56:04 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:56:04 --> Utf8 Class Initialized
INFO - 2016-11-14 21:56:04 --> URI Class Initialized
INFO - 2016-11-14 21:56:04 --> Router Class Initialized
INFO - 2016-11-14 21:56:04 --> Output Class Initialized
INFO - 2016-11-14 21:56:04 --> Security Class Initialized
DEBUG - 2016-11-14 21:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:56:04 --> Input Class Initialized
INFO - 2016-11-14 21:56:04 --> Language Class Initialized
ERROR - 2016-11-14 21:56:04 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 31
INFO - 2016-11-14 21:56:05 --> Config Class Initialized
INFO - 2016-11-14 21:56:05 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:56:05 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:56:05 --> Utf8 Class Initialized
INFO - 2016-11-14 21:56:05 --> URI Class Initialized
INFO - 2016-11-14 21:56:05 --> Router Class Initialized
INFO - 2016-11-14 21:56:05 --> Output Class Initialized
INFO - 2016-11-14 21:56:05 --> Security Class Initialized
DEBUG - 2016-11-14 21:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:56:05 --> Input Class Initialized
INFO - 2016-11-14 21:56:05 --> Language Class Initialized
INFO - 2016-11-14 21:56:05 --> Config Class Initialized
ERROR - 2016-11-14 21:56:05 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 31
INFO - 2016-11-14 21:56:05 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:56:05 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:56:05 --> Utf8 Class Initialized
INFO - 2016-11-14 21:56:05 --> URI Class Initialized
INFO - 2016-11-14 21:56:05 --> Router Class Initialized
INFO - 2016-11-14 21:56:05 --> Output Class Initialized
INFO - 2016-11-14 21:56:05 --> Security Class Initialized
INFO - 2016-11-14 21:56:05 --> Config Class Initialized
INFO - 2016-11-14 21:56:05 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:56:05 --> Input Class Initialized
DEBUG - 2016-11-14 21:56:05 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:56:05 --> Language Class Initialized
INFO - 2016-11-14 21:56:05 --> Utf8 Class Initialized
INFO - 2016-11-14 21:56:05 --> URI Class Initialized
ERROR - 2016-11-14 21:56:05 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 31
INFO - 2016-11-14 21:56:05 --> Router Class Initialized
INFO - 2016-11-14 21:56:05 --> Output Class Initialized
INFO - 2016-11-14 21:56:05 --> Security Class Initialized
DEBUG - 2016-11-14 21:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:56:05 --> Input Class Initialized
INFO - 2016-11-14 21:56:05 --> Language Class Initialized
ERROR - 2016-11-14 21:56:05 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 31
INFO - 2016-11-14 21:56:20 --> Config Class Initialized
INFO - 2016-11-14 21:56:20 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:56:20 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:56:20 --> Utf8 Class Initialized
INFO - 2016-11-14 21:56:20 --> URI Class Initialized
DEBUG - 2016-11-14 21:56:20 --> No URI present. Default controller set.
INFO - 2016-11-14 21:56:20 --> Router Class Initialized
INFO - 2016-11-14 21:56:20 --> Output Class Initialized
INFO - 2016-11-14 21:56:20 --> Security Class Initialized
DEBUG - 2016-11-14 21:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:56:20 --> Input Class Initialized
INFO - 2016-11-14 21:56:20 --> Language Class Initialized
INFO - 2016-11-14 21:56:20 --> Loader Class Initialized
INFO - 2016-11-14 21:56:20 --> Helper loaded: url_helper
INFO - 2016-11-14 21:56:20 --> Helper loaded: form_helper
INFO - 2016-11-14 21:56:20 --> Database Driver Class Initialized
INFO - 2016-11-14 21:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:56:20 --> Controller Class Initialized
INFO - 2016-11-14 21:56:20 --> Model Class Initialized
INFO - 2016-11-14 21:56:20 --> Model Class Initialized
INFO - 2016-11-14 21:56:20 --> Model Class Initialized
INFO - 2016-11-14 21:56:20 --> Model Class Initialized
INFO - 2016-11-14 21:56:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:56:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:56:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:56:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:56:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:56:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:56:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:56:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:56:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:56:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:56:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:56:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:56:20 --> Final output sent to browser
DEBUG - 2016-11-14 21:56:20 --> Total execution time: 0.5307
INFO - 2016-11-14 21:56:30 --> Config Class Initialized
INFO - 2016-11-14 21:56:30 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:56:30 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:56:30 --> Utf8 Class Initialized
INFO - 2016-11-14 21:56:30 --> URI Class Initialized
INFO - 2016-11-14 21:56:30 --> Router Class Initialized
INFO - 2016-11-14 21:56:30 --> Output Class Initialized
INFO - 2016-11-14 21:56:30 --> Security Class Initialized
DEBUG - 2016-11-14 21:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:56:30 --> Input Class Initialized
INFO - 2016-11-14 21:56:30 --> Language Class Initialized
ERROR - 2016-11-14 21:56:30 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 31
INFO - 2016-11-14 21:56:31 --> Config Class Initialized
INFO - 2016-11-14 21:56:31 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:56:31 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:56:31 --> Utf8 Class Initialized
INFO - 2016-11-14 21:56:31 --> URI Class Initialized
INFO - 2016-11-14 21:56:31 --> Router Class Initialized
INFO - 2016-11-14 21:56:31 --> Output Class Initialized
INFO - 2016-11-14 21:56:31 --> Security Class Initialized
DEBUG - 2016-11-14 21:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:56:31 --> Input Class Initialized
INFO - 2016-11-14 21:56:31 --> Language Class Initialized
ERROR - 2016-11-14 21:56:31 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 31
INFO - 2016-11-14 21:56:31 --> Config Class Initialized
INFO - 2016-11-14 21:56:31 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:56:31 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:56:31 --> Utf8 Class Initialized
INFO - 2016-11-14 21:56:31 --> URI Class Initialized
INFO - 2016-11-14 21:56:31 --> Router Class Initialized
INFO - 2016-11-14 21:56:31 --> Output Class Initialized
INFO - 2016-11-14 21:56:31 --> Security Class Initialized
DEBUG - 2016-11-14 21:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:56:31 --> Input Class Initialized
INFO - 2016-11-14 21:56:31 --> Language Class Initialized
ERROR - 2016-11-14 21:56:31 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 31
INFO - 2016-11-14 21:56:32 --> Config Class Initialized
INFO - 2016-11-14 21:56:32 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:56:32 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:56:32 --> Utf8 Class Initialized
INFO - 2016-11-14 21:56:32 --> URI Class Initialized
INFO - 2016-11-14 21:56:32 --> Router Class Initialized
INFO - 2016-11-14 21:56:32 --> Output Class Initialized
INFO - 2016-11-14 21:56:32 --> Security Class Initialized
DEBUG - 2016-11-14 21:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:56:32 --> Input Class Initialized
INFO - 2016-11-14 21:56:32 --> Language Class Initialized
ERROR - 2016-11-14 21:56:32 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 31
INFO - 2016-11-14 21:56:35 --> Config Class Initialized
INFO - 2016-11-14 21:56:35 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:56:35 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:56:35 --> Utf8 Class Initialized
INFO - 2016-11-14 21:56:35 --> URI Class Initialized
INFO - 2016-11-14 21:56:35 --> Router Class Initialized
INFO - 2016-11-14 21:56:35 --> Output Class Initialized
INFO - 2016-11-14 21:56:35 --> Security Class Initialized
DEBUG - 2016-11-14 21:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:56:35 --> Input Class Initialized
INFO - 2016-11-14 21:56:35 --> Language Class Initialized
INFO - 2016-11-14 21:56:35 --> Config Class Initialized
ERROR - 2016-11-14 21:56:35 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 31
INFO - 2016-11-14 21:56:35 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:56:35 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:56:35 --> Utf8 Class Initialized
INFO - 2016-11-14 21:56:35 --> URI Class Initialized
INFO - 2016-11-14 21:56:35 --> Router Class Initialized
INFO - 2016-11-14 21:56:35 --> Output Class Initialized
INFO - 2016-11-14 21:56:35 --> Security Class Initialized
DEBUG - 2016-11-14 21:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:56:35 --> Input Class Initialized
INFO - 2016-11-14 21:56:35 --> Config Class Initialized
INFO - 2016-11-14 21:56:35 --> Language Class Initialized
INFO - 2016-11-14 21:56:35 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:56:35 --> UTF-8 Support Enabled
ERROR - 2016-11-14 21:56:35 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 31
INFO - 2016-11-14 21:56:35 --> Utf8 Class Initialized
INFO - 2016-11-14 21:56:36 --> URI Class Initialized
INFO - 2016-11-14 21:56:36 --> Router Class Initialized
INFO - 2016-11-14 21:56:36 --> Output Class Initialized
INFO - 2016-11-14 21:56:36 --> Security Class Initialized
DEBUG - 2016-11-14 21:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:56:36 --> Input Class Initialized
INFO - 2016-11-14 21:56:36 --> Language Class Initialized
INFO - 2016-11-14 21:56:36 --> Config Class Initialized
ERROR - 2016-11-14 21:56:36 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 31
INFO - 2016-11-14 21:56:36 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:56:36 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:56:36 --> Utf8 Class Initialized
INFO - 2016-11-14 21:56:36 --> URI Class Initialized
INFO - 2016-11-14 21:56:36 --> Router Class Initialized
INFO - 2016-11-14 21:56:36 --> Output Class Initialized
INFO - 2016-11-14 21:56:36 --> Security Class Initialized
DEBUG - 2016-11-14 21:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:56:36 --> Input Class Initialized
INFO - 2016-11-14 21:56:36 --> Language Class Initialized
ERROR - 2016-11-14 21:56:36 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 31
INFO - 2016-11-14 21:57:10 --> Config Class Initialized
INFO - 2016-11-14 21:57:10 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:57:10 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:57:10 --> Utf8 Class Initialized
INFO - 2016-11-14 21:57:10 --> URI Class Initialized
DEBUG - 2016-11-14 21:57:10 --> No URI present. Default controller set.
INFO - 2016-11-14 21:57:10 --> Router Class Initialized
INFO - 2016-11-14 21:57:10 --> Output Class Initialized
INFO - 2016-11-14 21:57:10 --> Security Class Initialized
DEBUG - 2016-11-14 21:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:57:10 --> Input Class Initialized
INFO - 2016-11-14 21:57:10 --> Language Class Initialized
INFO - 2016-11-14 21:57:10 --> Loader Class Initialized
INFO - 2016-11-14 21:57:10 --> Helper loaded: url_helper
INFO - 2016-11-14 21:57:10 --> Helper loaded: form_helper
INFO - 2016-11-14 21:57:10 --> Database Driver Class Initialized
INFO - 2016-11-14 21:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:57:10 --> Controller Class Initialized
INFO - 2016-11-14 21:57:10 --> Model Class Initialized
INFO - 2016-11-14 21:57:10 --> Model Class Initialized
INFO - 2016-11-14 21:57:10 --> Model Class Initialized
INFO - 2016-11-14 21:57:10 --> Model Class Initialized
INFO - 2016-11-14 21:57:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:57:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:57:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:57:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:57:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:57:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:57:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:57:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:57:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:57:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:57:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:57:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:57:10 --> Final output sent to browser
DEBUG - 2016-11-14 21:57:10 --> Total execution time: 0.5275
INFO - 2016-11-14 21:57:19 --> Config Class Initialized
INFO - 2016-11-14 21:57:19 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:57:19 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:57:19 --> Utf8 Class Initialized
INFO - 2016-11-14 21:57:19 --> URI Class Initialized
INFO - 2016-11-14 21:57:19 --> Router Class Initialized
INFO - 2016-11-14 21:57:19 --> Output Class Initialized
INFO - 2016-11-14 21:57:19 --> Security Class Initialized
DEBUG - 2016-11-14 21:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:57:19 --> Input Class Initialized
INFO - 2016-11-14 21:57:19 --> Language Class Initialized
ERROR - 2016-11-14 21:57:19 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 52
INFO - 2016-11-14 21:57:20 --> Config Class Initialized
INFO - 2016-11-14 21:57:20 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:57:20 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:57:20 --> Utf8 Class Initialized
INFO - 2016-11-14 21:57:20 --> URI Class Initialized
INFO - 2016-11-14 21:57:20 --> Router Class Initialized
INFO - 2016-11-14 21:57:20 --> Output Class Initialized
INFO - 2016-11-14 21:57:20 --> Security Class Initialized
DEBUG - 2016-11-14 21:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:57:20 --> Input Class Initialized
INFO - 2016-11-14 21:57:20 --> Language Class Initialized
INFO - 2016-11-14 21:57:20 --> Config Class Initialized
ERROR - 2016-11-14 21:57:20 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 52
INFO - 2016-11-14 21:57:20 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:57:20 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:57:20 --> Utf8 Class Initialized
INFO - 2016-11-14 21:57:20 --> URI Class Initialized
INFO - 2016-11-14 21:57:20 --> Router Class Initialized
INFO - 2016-11-14 21:57:20 --> Output Class Initialized
INFO - 2016-11-14 21:57:20 --> Security Class Initialized
DEBUG - 2016-11-14 21:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:57:20 --> Input Class Initialized
INFO - 2016-11-14 21:57:20 --> Language Class Initialized
ERROR - 2016-11-14 21:57:20 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 52
INFO - 2016-11-14 21:57:56 --> Config Class Initialized
INFO - 2016-11-14 21:57:56 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:57:57 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:57:57 --> Utf8 Class Initialized
INFO - 2016-11-14 21:57:57 --> URI Class Initialized
DEBUG - 2016-11-14 21:57:57 --> No URI present. Default controller set.
INFO - 2016-11-14 21:57:57 --> Router Class Initialized
INFO - 2016-11-14 21:57:57 --> Output Class Initialized
INFO - 2016-11-14 21:57:57 --> Security Class Initialized
DEBUG - 2016-11-14 21:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:57:57 --> Input Class Initialized
INFO - 2016-11-14 21:57:57 --> Language Class Initialized
INFO - 2016-11-14 21:57:57 --> Loader Class Initialized
INFO - 2016-11-14 21:57:57 --> Helper loaded: url_helper
INFO - 2016-11-14 21:57:57 --> Helper loaded: form_helper
INFO - 2016-11-14 21:57:57 --> Database Driver Class Initialized
INFO - 2016-11-14 21:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:57:57 --> Controller Class Initialized
INFO - 2016-11-14 21:57:57 --> Model Class Initialized
INFO - 2016-11-14 21:57:57 --> Model Class Initialized
INFO - 2016-11-14 21:57:57 --> Model Class Initialized
INFO - 2016-11-14 21:57:57 --> Model Class Initialized
INFO - 2016-11-14 21:57:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:57:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:57:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:57:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:57:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:57:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:57:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:57:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:57:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:57:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:57:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:57:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:57:57 --> Final output sent to browser
DEBUG - 2016-11-14 21:57:57 --> Total execution time: 0.5698
INFO - 2016-11-14 21:58:04 --> Config Class Initialized
INFO - 2016-11-14 21:58:04 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:58:04 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:58:04 --> Utf8 Class Initialized
INFO - 2016-11-14 21:58:04 --> URI Class Initialized
INFO - 2016-11-14 21:58:04 --> Router Class Initialized
INFO - 2016-11-14 21:58:04 --> Output Class Initialized
INFO - 2016-11-14 21:58:04 --> Security Class Initialized
DEBUG - 2016-11-14 21:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:58:04 --> Input Class Initialized
INFO - 2016-11-14 21:58:04 --> Language Class Initialized
INFO - 2016-11-14 21:58:04 --> Loader Class Initialized
INFO - 2016-11-14 21:58:04 --> Helper loaded: url_helper
INFO - 2016-11-14 21:58:04 --> Helper loaded: form_helper
INFO - 2016-11-14 21:58:05 --> Database Driver Class Initialized
INFO - 2016-11-14 21:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:58:05 --> Controller Class Initialized
INFO - 2016-11-14 21:58:05 --> Model Class Initialized
INFO - 2016-11-14 21:58:05 --> Form Validation Class Initialized
ERROR - 2016-11-14 21:58:05 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-14 21:58:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-14 21:58:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:58:05 --> Final output sent to browser
DEBUG - 2016-11-14 21:58:05 --> Total execution time: 0.4283
INFO - 2016-11-14 21:58:33 --> Config Class Initialized
INFO - 2016-11-14 21:58:33 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:58:33 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:58:33 --> Utf8 Class Initialized
INFO - 2016-11-14 21:58:33 --> URI Class Initialized
INFO - 2016-11-14 21:58:33 --> Router Class Initialized
INFO - 2016-11-14 21:58:33 --> Output Class Initialized
INFO - 2016-11-14 21:58:33 --> Security Class Initialized
DEBUG - 2016-11-14 21:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:58:33 --> Input Class Initialized
INFO - 2016-11-14 21:58:33 --> Language Class Initialized
INFO - 2016-11-14 21:58:33 --> Loader Class Initialized
INFO - 2016-11-14 21:58:33 --> Helper loaded: url_helper
INFO - 2016-11-14 21:58:33 --> Helper loaded: form_helper
INFO - 2016-11-14 21:58:33 --> Database Driver Class Initialized
INFO - 2016-11-14 21:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:58:34 --> Controller Class Initialized
INFO - 2016-11-14 21:58:34 --> Model Class Initialized
INFO - 2016-11-14 21:58:34 --> Form Validation Class Initialized
INFO - 2016-11-14 21:58:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-14 21:58:34 --> Final output sent to browser
DEBUG - 2016-11-14 21:58:34 --> Total execution time: 0.2851
INFO - 2016-11-14 21:59:34 --> Config Class Initialized
INFO - 2016-11-14 21:59:34 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:59:34 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:59:34 --> Utf8 Class Initialized
INFO - 2016-11-14 21:59:34 --> URI Class Initialized
DEBUG - 2016-11-14 21:59:34 --> No URI present. Default controller set.
INFO - 2016-11-14 21:59:34 --> Router Class Initialized
INFO - 2016-11-14 21:59:34 --> Output Class Initialized
INFO - 2016-11-14 21:59:34 --> Security Class Initialized
DEBUG - 2016-11-14 21:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:59:34 --> Input Class Initialized
INFO - 2016-11-14 21:59:35 --> Language Class Initialized
INFO - 2016-11-14 21:59:35 --> Loader Class Initialized
INFO - 2016-11-14 21:59:35 --> Helper loaded: url_helper
INFO - 2016-11-14 21:59:35 --> Helper loaded: form_helper
INFO - 2016-11-14 21:59:35 --> Database Driver Class Initialized
INFO - 2016-11-14 21:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 21:59:35 --> Controller Class Initialized
INFO - 2016-11-14 21:59:35 --> Model Class Initialized
INFO - 2016-11-14 21:59:35 --> Model Class Initialized
INFO - 2016-11-14 21:59:35 --> Model Class Initialized
INFO - 2016-11-14 21:59:35 --> Model Class Initialized
INFO - 2016-11-14 21:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 21:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 21:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 21:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 21:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 21:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 21:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 21:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 21:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 21:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 21:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 21:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 21:59:35 --> Final output sent to browser
DEBUG - 2016-11-14 21:59:35 --> Total execution time: 0.5884
INFO - 2016-11-14 21:59:39 --> Config Class Initialized
INFO - 2016-11-14 21:59:39 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:59:39 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:59:39 --> Utf8 Class Initialized
INFO - 2016-11-14 21:59:39 --> URI Class Initialized
INFO - 2016-11-14 21:59:39 --> Router Class Initialized
INFO - 2016-11-14 21:59:39 --> Output Class Initialized
INFO - 2016-11-14 21:59:39 --> Security Class Initialized
DEBUG - 2016-11-14 21:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:59:39 --> Input Class Initialized
INFO - 2016-11-14 21:59:39 --> Language Class Initialized
ERROR - 2016-11-14 21:59:39 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 51
INFO - 2016-11-14 21:59:40 --> Config Class Initialized
INFO - 2016-11-14 21:59:40 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:59:40 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:59:40 --> Utf8 Class Initialized
INFO - 2016-11-14 21:59:40 --> URI Class Initialized
INFO - 2016-11-14 21:59:40 --> Router Class Initialized
INFO - 2016-11-14 21:59:40 --> Output Class Initialized
INFO - 2016-11-14 21:59:40 --> Security Class Initialized
DEBUG - 2016-11-14 21:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:59:40 --> Input Class Initialized
INFO - 2016-11-14 21:59:40 --> Language Class Initialized
INFO - 2016-11-14 21:59:40 --> Config Class Initialized
ERROR - 2016-11-14 21:59:40 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 51
INFO - 2016-11-14 21:59:40 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:59:40 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:59:40 --> Utf8 Class Initialized
INFO - 2016-11-14 21:59:40 --> URI Class Initialized
INFO - 2016-11-14 21:59:40 --> Router Class Initialized
INFO - 2016-11-14 21:59:40 --> Output Class Initialized
INFO - 2016-11-14 21:59:40 --> Security Class Initialized
DEBUG - 2016-11-14 21:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:59:40 --> Config Class Initialized
INFO - 2016-11-14 21:59:40 --> Input Class Initialized
INFO - 2016-11-14 21:59:40 --> Hooks Class Initialized
INFO - 2016-11-14 21:59:40 --> Language Class Initialized
DEBUG - 2016-11-14 21:59:40 --> UTF-8 Support Enabled
ERROR - 2016-11-14 21:59:40 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 51
INFO - 2016-11-14 21:59:40 --> Utf8 Class Initialized
INFO - 2016-11-14 21:59:40 --> URI Class Initialized
INFO - 2016-11-14 21:59:40 --> Router Class Initialized
INFO - 2016-11-14 21:59:40 --> Output Class Initialized
INFO - 2016-11-14 21:59:40 --> Security Class Initialized
INFO - 2016-11-14 21:59:40 --> Config Class Initialized
DEBUG - 2016-11-14 21:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:59:40 --> Hooks Class Initialized
INFO - 2016-11-14 21:59:40 --> Input Class Initialized
DEBUG - 2016-11-14 21:59:40 --> UTF-8 Support Enabled
INFO - 2016-11-14 21:59:40 --> Utf8 Class Initialized
INFO - 2016-11-14 21:59:40 --> Language Class Initialized
INFO - 2016-11-14 21:59:40 --> URI Class Initialized
ERROR - 2016-11-14 21:59:41 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 51
INFO - 2016-11-14 21:59:41 --> Router Class Initialized
INFO - 2016-11-14 21:59:41 --> Output Class Initialized
INFO - 2016-11-14 21:59:41 --> Security Class Initialized
DEBUG - 2016-11-14 21:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:59:41 --> Input Class Initialized
INFO - 2016-11-14 21:59:41 --> Config Class Initialized
INFO - 2016-11-14 21:59:41 --> Language Class Initialized
INFO - 2016-11-14 21:59:41 --> Hooks Class Initialized
DEBUG - 2016-11-14 21:59:41 --> UTF-8 Support Enabled
ERROR - 2016-11-14 21:59:41 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 51
INFO - 2016-11-14 21:59:41 --> Utf8 Class Initialized
INFO - 2016-11-14 21:59:41 --> URI Class Initialized
INFO - 2016-11-14 21:59:41 --> Router Class Initialized
INFO - 2016-11-14 21:59:41 --> Output Class Initialized
INFO - 2016-11-14 21:59:41 --> Security Class Initialized
DEBUG - 2016-11-14 21:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 21:59:41 --> Input Class Initialized
INFO - 2016-11-14 21:59:41 --> Language Class Initialized
ERROR - 2016-11-14 21:59:41 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 51
INFO - 2016-11-14 22:00:18 --> Config Class Initialized
INFO - 2016-11-14 22:00:18 --> Hooks Class Initialized
DEBUG - 2016-11-14 22:00:18 --> UTF-8 Support Enabled
INFO - 2016-11-14 22:00:18 --> Utf8 Class Initialized
INFO - 2016-11-14 22:00:18 --> URI Class Initialized
DEBUG - 2016-11-14 22:00:18 --> No URI present. Default controller set.
INFO - 2016-11-14 22:00:18 --> Router Class Initialized
INFO - 2016-11-14 22:00:18 --> Output Class Initialized
INFO - 2016-11-14 22:00:18 --> Security Class Initialized
DEBUG - 2016-11-14 22:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 22:00:18 --> Input Class Initialized
INFO - 2016-11-14 22:00:18 --> Language Class Initialized
INFO - 2016-11-14 22:00:18 --> Loader Class Initialized
INFO - 2016-11-14 22:00:18 --> Helper loaded: url_helper
INFO - 2016-11-14 22:00:18 --> Helper loaded: form_helper
INFO - 2016-11-14 22:00:18 --> Database Driver Class Initialized
INFO - 2016-11-14 22:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 22:00:18 --> Controller Class Initialized
INFO - 2016-11-14 22:00:18 --> Model Class Initialized
INFO - 2016-11-14 22:00:18 --> Model Class Initialized
INFO - 2016-11-14 22:00:18 --> Model Class Initialized
INFO - 2016-11-14 22:00:18 --> Model Class Initialized
INFO - 2016-11-14 22:00:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-14 22:00:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-14 22:00:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-14 22:00:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-14 22:00:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-14 22:00:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-14 22:00:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-14 22:00:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-14 22:00:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-14 22:00:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-14 22:00:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-14 22:00:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-14 22:00:18 --> Final output sent to browser
DEBUG - 2016-11-14 22:00:18 --> Total execution time: 0.5424
INFO - 2016-11-14 22:00:24 --> Config Class Initialized
INFO - 2016-11-14 22:00:24 --> Hooks Class Initialized
DEBUG - 2016-11-14 22:00:24 --> UTF-8 Support Enabled
INFO - 2016-11-14 22:00:24 --> Utf8 Class Initialized
INFO - 2016-11-14 22:00:24 --> URI Class Initialized
INFO - 2016-11-14 22:00:24 --> Router Class Initialized
INFO - 2016-11-14 22:00:24 --> Output Class Initialized
INFO - 2016-11-14 22:00:24 --> Security Class Initialized
DEBUG - 2016-11-14 22:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 22:00:24 --> Input Class Initialized
INFO - 2016-11-14 22:00:24 --> Language Class Initialized
ERROR - 2016-11-14 22:00:24 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 61
INFO - 2016-11-14 22:00:25 --> Config Class Initialized
INFO - 2016-11-14 22:00:25 --> Hooks Class Initialized
DEBUG - 2016-11-14 22:00:25 --> UTF-8 Support Enabled
INFO - 2016-11-14 22:00:25 --> Utf8 Class Initialized
INFO - 2016-11-14 22:00:25 --> URI Class Initialized
INFO - 2016-11-14 22:00:25 --> Router Class Initialized
INFO - 2016-11-14 22:00:25 --> Output Class Initialized
INFO - 2016-11-14 22:00:25 --> Security Class Initialized
DEBUG - 2016-11-14 22:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 22:00:25 --> Input Class Initialized
INFO - 2016-11-14 22:00:25 --> Config Class Initialized
INFO - 2016-11-14 22:00:25 --> Language Class Initialized
INFO - 2016-11-14 22:00:25 --> Hooks Class Initialized
DEBUG - 2016-11-14 22:00:25 --> UTF-8 Support Enabled
INFO - 2016-11-14 22:00:25 --> Utf8 Class Initialized
ERROR - 2016-11-14 22:00:25 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 61
INFO - 2016-11-14 22:00:25 --> URI Class Initialized
INFO - 2016-11-14 22:00:25 --> Router Class Initialized
INFO - 2016-11-14 22:00:25 --> Output Class Initialized
INFO - 2016-11-14 22:00:25 --> Security Class Initialized
DEBUG - 2016-11-14 22:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 22:00:25 --> Config Class Initialized
INFO - 2016-11-14 22:00:25 --> Input Class Initialized
INFO - 2016-11-14 22:00:25 --> Hooks Class Initialized
INFO - 2016-11-14 22:00:25 --> Language Class Initialized
DEBUG - 2016-11-14 22:00:25 --> UTF-8 Support Enabled
INFO - 2016-11-14 22:00:25 --> Utf8 Class Initialized
ERROR - 2016-11-14 22:00:25 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 61
INFO - 2016-11-14 22:00:25 --> URI Class Initialized
INFO - 2016-11-14 22:00:25 --> Router Class Initialized
INFO - 2016-11-14 22:00:25 --> Output Class Initialized
INFO - 2016-11-14 22:00:25 --> Security Class Initialized
DEBUG - 2016-11-14 22:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 22:00:25 --> Config Class Initialized
INFO - 2016-11-14 22:00:25 --> Input Class Initialized
INFO - 2016-11-14 22:00:25 --> Hooks Class Initialized
INFO - 2016-11-14 22:00:25 --> Language Class Initialized
DEBUG - 2016-11-14 22:00:25 --> UTF-8 Support Enabled
ERROR - 2016-11-14 22:00:25 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 61
INFO - 2016-11-14 22:00:25 --> Utf8 Class Initialized
INFO - 2016-11-14 22:00:25 --> URI Class Initialized
INFO - 2016-11-14 22:00:25 --> Router Class Initialized
INFO - 2016-11-14 22:00:25 --> Output Class Initialized
INFO - 2016-11-14 22:00:25 --> Config Class Initialized
INFO - 2016-11-14 22:00:25 --> Security Class Initialized
INFO - 2016-11-14 22:00:25 --> Hooks Class Initialized
DEBUG - 2016-11-14 22:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-14 22:00:25 --> UTF-8 Support Enabled
INFO - 2016-11-14 22:00:25 --> Input Class Initialized
INFO - 2016-11-14 22:00:25 --> Utf8 Class Initialized
INFO - 2016-11-14 22:00:25 --> Language Class Initialized
INFO - 2016-11-14 22:00:25 --> URI Class Initialized
ERROR - 2016-11-14 22:00:25 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 61
INFO - 2016-11-14 22:00:25 --> Router Class Initialized
INFO - 2016-11-14 22:00:25 --> Output Class Initialized
INFO - 2016-11-14 22:00:25 --> Security Class Initialized
DEBUG - 2016-11-14 22:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 22:00:25 --> Input Class Initialized
INFO - 2016-11-14 22:00:26 --> Language Class Initialized
ERROR - 2016-11-14 22:00:26 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 61
INFO - 2016-11-14 22:01:30 --> Config Class Initialized
INFO - 2016-11-14 22:01:30 --> Hooks Class Initialized
DEBUG - 2016-11-14 22:01:30 --> UTF-8 Support Enabled
INFO - 2016-11-14 22:01:30 --> Utf8 Class Initialized
INFO - 2016-11-14 22:01:30 --> URI Class Initialized
INFO - 2016-11-14 22:01:30 --> Router Class Initialized
INFO - 2016-11-14 22:01:31 --> Output Class Initialized
INFO - 2016-11-14 22:01:31 --> Security Class Initialized
DEBUG - 2016-11-14 22:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-14 22:01:31 --> Input Class Initialized
INFO - 2016-11-14 22:01:31 --> Language Class Initialized
INFO - 2016-11-14 22:01:31 --> Loader Class Initialized
INFO - 2016-11-14 22:01:31 --> Helper loaded: url_helper
INFO - 2016-11-14 22:01:31 --> Helper loaded: form_helper
INFO - 2016-11-14 22:01:31 --> Database Driver Class Initialized
INFO - 2016-11-14 22:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-14 22:01:31 --> Controller Class Initialized
INFO - 2016-11-14 22:01:31 --> Model Class Initialized
INFO - 2016-11-14 22:01:31 --> Form Validation Class Initialized
INFO - 2016-11-14 22:01:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-14 22:01:31 --> Final output sent to browser
DEBUG - 2016-11-14 22:01:31 --> Total execution time: 0.3129
