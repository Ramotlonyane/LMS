<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-07-07 09:37:07 --> Config Class Initialized
INFO - 2016-07-07 09:37:07 --> Hooks Class Initialized
DEBUG - 2016-07-07 09:37:07 --> UTF-8 Support Enabled
INFO - 2016-07-07 09:37:07 --> Utf8 Class Initialized
INFO - 2016-07-07 09:37:07 --> URI Class Initialized
DEBUG - 2016-07-07 09:37:07 --> No URI present. Default controller set.
INFO - 2016-07-07 09:37:07 --> Router Class Initialized
INFO - 2016-07-07 09:37:08 --> Output Class Initialized
INFO - 2016-07-07 09:37:08 --> Security Class Initialized
DEBUG - 2016-07-07 09:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-07 09:37:08 --> Input Class Initialized
INFO - 2016-07-07 09:37:08 --> Language Class Initialized
INFO - 2016-07-07 09:37:08 --> Loader Class Initialized
INFO - 2016-07-07 09:37:08 --> Controller Class Initialized
INFO - 2016-07-07 09:37:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\welcome_message.php
INFO - 2016-07-07 09:37:08 --> Final output sent to browser
DEBUG - 2016-07-07 09:37:08 --> Total execution time: 1.1025
