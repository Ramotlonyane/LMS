<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-02 13:24:09 --> Config Class Initialized
INFO - 2016-12-02 13:24:09 --> Hooks Class Initialized
DEBUG - 2016-12-02 13:24:09 --> UTF-8 Support Enabled
INFO - 2016-12-02 13:24:09 --> Utf8 Class Initialized
INFO - 2016-12-02 13:24:09 --> URI Class Initialized
DEBUG - 2016-12-02 13:24:09 --> No URI present. Default controller set.
INFO - 2016-12-02 13:24:09 --> Router Class Initialized
INFO - 2016-12-02 13:24:09 --> Output Class Initialized
INFO - 2016-12-02 13:24:10 --> Security Class Initialized
DEBUG - 2016-12-02 13:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 13:24:10 --> Input Class Initialized
INFO - 2016-12-02 13:24:10 --> Language Class Initialized
INFO - 2016-12-02 13:24:10 --> Loader Class Initialized
INFO - 2016-12-02 13:24:10 --> Helper loaded: url_helper
INFO - 2016-12-02 13:24:10 --> Helper loaded: form_helper
INFO - 2016-12-02 13:24:10 --> Config Class Initialized
INFO - 2016-12-02 13:24:10 --> Hooks Class Initialized
DEBUG - 2016-12-02 13:24:10 --> UTF-8 Support Enabled
INFO - 2016-12-02 13:24:10 --> Database Driver Class Initialized
INFO - 2016-12-02 13:24:10 --> Utf8 Class Initialized
INFO - 2016-12-02 13:24:10 --> URI Class Initialized
DEBUG - 2016-12-02 13:24:10 --> No URI present. Default controller set.
INFO - 2016-12-02 13:24:10 --> Router Class Initialized
INFO - 2016-12-02 13:24:10 --> Output Class Initialized
INFO - 2016-12-02 13:24:10 --> Security Class Initialized
DEBUG - 2016-12-02 13:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 13:24:10 --> Input Class Initialized
INFO - 2016-12-02 13:24:10 --> Language Class Initialized
INFO - 2016-12-02 13:24:10 --> Loader Class Initialized
INFO - 2016-12-02 13:24:10 --> Helper loaded: url_helper
INFO - 2016-12-02 13:24:10 --> Helper loaded: form_helper
INFO - 2016-12-02 13:24:10 --> Database Driver Class Initialized
INFO - 2016-12-02 13:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 13:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 13:24:10 --> Controller Class Initialized
INFO - 2016-12-02 13:24:10 --> Controller Class Initialized
INFO - 2016-12-02 13:24:10 --> Model Class Initialized
INFO - 2016-12-02 13:24:10 --> Model Class Initialized
INFO - 2016-12-02 13:24:10 --> Model Class Initialized
INFO - 2016-12-02 13:24:10 --> Model Class Initialized
INFO - 2016-12-02 13:24:10 --> Model Class Initialized
INFO - 2016-12-02 13:24:10 --> Model Class Initialized
INFO - 2016-12-02 13:24:10 --> Model Class Initialized
INFO - 2016-12-02 13:24:10 --> Model Class Initialized
INFO - 2016-12-02 13:24:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 13:24:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 13:24:10 --> Pagination Class Initialized
INFO - 2016-12-02 13:24:10 --> Pagination Class Initialized
INFO - 2016-12-02 13:24:10 --> Helper loaded: app_helper
INFO - 2016-12-02 13:24:10 --> Helper loaded: app_helper
INFO - 2016-12-02 13:24:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 13:24:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 13:24:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-02 13:24:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-02 13:24:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 13:24:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 13:24:11 --> Final output sent to browser
INFO - 2016-12-02 13:24:11 --> Final output sent to browser
DEBUG - 2016-12-02 13:24:11 --> Total execution time: 0.5570
DEBUG - 2016-12-02 13:24:11 --> Total execution time: 1.3778
INFO - 2016-12-02 13:24:24 --> Config Class Initialized
INFO - 2016-12-02 13:24:24 --> Hooks Class Initialized
DEBUG - 2016-12-02 13:24:24 --> UTF-8 Support Enabled
INFO - 2016-12-02 13:24:24 --> Utf8 Class Initialized
INFO - 2016-12-02 13:24:24 --> URI Class Initialized
INFO - 2016-12-02 13:24:24 --> Router Class Initialized
INFO - 2016-12-02 13:24:24 --> Output Class Initialized
INFO - 2016-12-02 13:24:24 --> Security Class Initialized
DEBUG - 2016-12-02 13:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 13:24:24 --> Input Class Initialized
INFO - 2016-12-02 13:24:24 --> Language Class Initialized
INFO - 2016-12-02 13:24:24 --> Loader Class Initialized
INFO - 2016-12-02 13:24:24 --> Helper loaded: url_helper
INFO - 2016-12-02 13:24:24 --> Helper loaded: form_helper
INFO - 2016-12-02 13:24:24 --> Database Driver Class Initialized
INFO - 2016-12-02 13:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 13:24:24 --> Controller Class Initialized
INFO - 2016-12-02 13:24:24 --> Model Class Initialized
INFO - 2016-12-02 13:24:24 --> Model Class Initialized
INFO - 2016-12-02 13:24:24 --> Model Class Initialized
INFO - 2016-12-02 13:24:24 --> Model Class Initialized
INFO - 2016-12-02 13:24:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 13:24:24 --> Pagination Class Initialized
INFO - 2016-12-02 13:24:24 --> Helper loaded: app_helper
DEBUG - 2016-12-02 13:24:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 13:24:24 --> Model Class Initialized
INFO - 2016-12-02 13:24:24 --> Final output sent to browser
DEBUG - 2016-12-02 13:24:24 --> Total execution time: 0.3764
INFO - 2016-12-02 13:24:24 --> Config Class Initialized
INFO - 2016-12-02 13:24:24 --> Hooks Class Initialized
DEBUG - 2016-12-02 13:24:24 --> UTF-8 Support Enabled
INFO - 2016-12-02 13:24:24 --> Utf8 Class Initialized
INFO - 2016-12-02 13:24:24 --> URI Class Initialized
DEBUG - 2016-12-02 13:24:24 --> No URI present. Default controller set.
INFO - 2016-12-02 13:24:24 --> Router Class Initialized
INFO - 2016-12-02 13:24:24 --> Output Class Initialized
INFO - 2016-12-02 13:24:24 --> Security Class Initialized
DEBUG - 2016-12-02 13:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 13:24:24 --> Input Class Initialized
INFO - 2016-12-02 13:24:24 --> Language Class Initialized
INFO - 2016-12-02 13:24:24 --> Loader Class Initialized
INFO - 2016-12-02 13:24:24 --> Helper loaded: url_helper
INFO - 2016-12-02 13:24:24 --> Helper loaded: form_helper
INFO - 2016-12-02 13:24:24 --> Database Driver Class Initialized
INFO - 2016-12-02 13:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 13:24:24 --> Controller Class Initialized
INFO - 2016-12-02 13:24:24 --> Model Class Initialized
INFO - 2016-12-02 13:24:24 --> Model Class Initialized
INFO - 2016-12-02 13:24:24 --> Model Class Initialized
INFO - 2016-12-02 13:24:24 --> Model Class Initialized
INFO - 2016-12-02 13:24:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 13:24:24 --> Pagination Class Initialized
INFO - 2016-12-02 13:24:24 --> Helper loaded: app_helper
INFO - 2016-12-02 13:24:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 13:24:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 13:24:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 13:24:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 13:24:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 13:24:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 13:24:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 13:24:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 13:24:25 --> Final output sent to browser
DEBUG - 2016-12-02 13:24:25 --> Total execution time: 0.6002
INFO - 2016-12-02 13:25:02 --> Config Class Initialized
INFO - 2016-12-02 13:25:02 --> Hooks Class Initialized
DEBUG - 2016-12-02 13:25:02 --> UTF-8 Support Enabled
INFO - 2016-12-02 13:25:02 --> Utf8 Class Initialized
INFO - 2016-12-02 13:25:02 --> URI Class Initialized
INFO - 2016-12-02 13:25:02 --> Router Class Initialized
INFO - 2016-12-02 13:25:02 --> Output Class Initialized
INFO - 2016-12-02 13:25:02 --> Security Class Initialized
DEBUG - 2016-12-02 13:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 13:25:02 --> Input Class Initialized
INFO - 2016-12-02 13:25:02 --> Language Class Initialized
INFO - 2016-12-02 13:25:02 --> Loader Class Initialized
INFO - 2016-12-02 13:25:02 --> Helper loaded: url_helper
INFO - 2016-12-02 13:25:02 --> Helper loaded: form_helper
INFO - 2016-12-02 13:25:02 --> Database Driver Class Initialized
INFO - 2016-12-02 13:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 13:25:02 --> Controller Class Initialized
INFO - 2016-12-02 13:25:02 --> Model Class Initialized
INFO - 2016-12-02 13:25:02 --> Form Validation Class Initialized
INFO - 2016-12-02 13:25:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 13:25:02 --> Pagination Class Initialized
INFO - 2016-12-02 13:25:02 --> Helper loaded: app_helper
INFO - 2016-12-02 13:25:02 --> Email Class Initialized
INFO - 2016-12-02 13:25:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-02 12:25:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-02 12:25:02 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-02 12:25:03 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-02 12:25:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-02 12:25:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 12:25:03 --> Final output sent to browser
DEBUG - 2016-12-02 12:25:03 --> Total execution time: 1.7361
INFO - 2016-12-02 13:25:44 --> Config Class Initialized
INFO - 2016-12-02 13:25:45 --> Hooks Class Initialized
DEBUG - 2016-12-02 13:25:45 --> UTF-8 Support Enabled
INFO - 2016-12-02 13:25:45 --> Utf8 Class Initialized
INFO - 2016-12-02 13:25:45 --> URI Class Initialized
DEBUG - 2016-12-02 13:25:45 --> No URI present. Default controller set.
INFO - 2016-12-02 13:25:45 --> Router Class Initialized
INFO - 2016-12-02 13:25:45 --> Output Class Initialized
INFO - 2016-12-02 13:25:45 --> Security Class Initialized
DEBUG - 2016-12-02 13:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 13:25:45 --> Input Class Initialized
INFO - 2016-12-02 13:25:45 --> Language Class Initialized
INFO - 2016-12-02 13:25:45 --> Loader Class Initialized
INFO - 2016-12-02 13:25:45 --> Helper loaded: url_helper
INFO - 2016-12-02 13:25:45 --> Helper loaded: form_helper
INFO - 2016-12-02 13:25:45 --> Database Driver Class Initialized
INFO - 2016-12-02 13:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 13:25:45 --> Controller Class Initialized
INFO - 2016-12-02 13:25:45 --> Model Class Initialized
INFO - 2016-12-02 13:25:45 --> Model Class Initialized
INFO - 2016-12-02 13:25:45 --> Model Class Initialized
INFO - 2016-12-02 13:25:45 --> Model Class Initialized
INFO - 2016-12-02 13:25:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 13:25:45 --> Pagination Class Initialized
INFO - 2016-12-02 13:25:45 --> Helper loaded: app_helper
INFO - 2016-12-02 13:25:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 13:25:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 13:25:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 13:25:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 13:25:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 13:25:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 13:25:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 13:25:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 13:25:45 --> Final output sent to browser
DEBUG - 2016-12-02 13:25:45 --> Total execution time: 0.4764
INFO - 2016-12-02 13:27:08 --> Config Class Initialized
INFO - 2016-12-02 13:27:08 --> Hooks Class Initialized
DEBUG - 2016-12-02 13:27:08 --> UTF-8 Support Enabled
INFO - 2016-12-02 13:27:08 --> Utf8 Class Initialized
INFO - 2016-12-02 13:27:08 --> URI Class Initialized
INFO - 2016-12-02 13:27:08 --> Router Class Initialized
INFO - 2016-12-02 13:27:08 --> Output Class Initialized
INFO - 2016-12-02 13:27:08 --> Security Class Initialized
DEBUG - 2016-12-02 13:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 13:27:08 --> Input Class Initialized
INFO - 2016-12-02 13:27:08 --> Language Class Initialized
INFO - 2016-12-02 13:27:08 --> Loader Class Initialized
INFO - 2016-12-02 13:27:08 --> Helper loaded: url_helper
INFO - 2016-12-02 13:27:08 --> Helper loaded: form_helper
INFO - 2016-12-02 13:27:08 --> Database Driver Class Initialized
INFO - 2016-12-02 13:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 13:27:08 --> Controller Class Initialized
INFO - 2016-12-02 13:27:08 --> Model Class Initialized
INFO - 2016-12-02 13:27:08 --> Form Validation Class Initialized
INFO - 2016-12-02 13:27:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 13:27:08 --> Pagination Class Initialized
INFO - 2016-12-02 13:27:08 --> Helper loaded: app_helper
INFO - 2016-12-02 13:27:08 --> Email Class Initialized
INFO - 2016-12-02 13:27:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-02 12:27:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-02 12:27:08 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-02 12:27:09 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-02 12:27:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-02 12:27:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 12:27:12 --> Final output sent to browser
DEBUG - 2016-12-02 12:27:12 --> Total execution time: 4.0469
INFO - 2016-12-02 13:30:37 --> Config Class Initialized
INFO - 2016-12-02 13:30:37 --> Hooks Class Initialized
DEBUG - 2016-12-02 13:30:37 --> UTF-8 Support Enabled
INFO - 2016-12-02 13:30:37 --> Utf8 Class Initialized
INFO - 2016-12-02 13:30:37 --> URI Class Initialized
DEBUG - 2016-12-02 13:30:37 --> No URI present. Default controller set.
INFO - 2016-12-02 13:30:37 --> Router Class Initialized
INFO - 2016-12-02 13:30:37 --> Output Class Initialized
INFO - 2016-12-02 13:30:37 --> Security Class Initialized
DEBUG - 2016-12-02 13:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 13:30:37 --> Input Class Initialized
INFO - 2016-12-02 13:30:37 --> Language Class Initialized
INFO - 2016-12-02 13:30:37 --> Loader Class Initialized
INFO - 2016-12-02 13:30:37 --> Helper loaded: url_helper
INFO - 2016-12-02 13:30:37 --> Helper loaded: form_helper
INFO - 2016-12-02 13:30:37 --> Database Driver Class Initialized
INFO - 2016-12-02 13:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 13:30:37 --> Controller Class Initialized
INFO - 2016-12-02 13:30:37 --> Model Class Initialized
INFO - 2016-12-02 13:30:37 --> Model Class Initialized
INFO - 2016-12-02 13:30:37 --> Model Class Initialized
INFO - 2016-12-02 13:30:37 --> Model Class Initialized
INFO - 2016-12-02 13:30:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 13:30:37 --> Pagination Class Initialized
INFO - 2016-12-02 13:30:37 --> Helper loaded: app_helper
INFO - 2016-12-02 13:30:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 13:30:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 13:30:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 13:30:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 13:30:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 13:30:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 13:30:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 13:30:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 13:30:37 --> Final output sent to browser
DEBUG - 2016-12-02 13:30:37 --> Total execution time: 0.4254
INFO - 2016-12-02 13:30:56 --> Config Class Initialized
INFO - 2016-12-02 13:30:56 --> Hooks Class Initialized
DEBUG - 2016-12-02 13:30:56 --> UTF-8 Support Enabled
INFO - 2016-12-02 13:30:56 --> Utf8 Class Initialized
INFO - 2016-12-02 13:30:56 --> URI Class Initialized
INFO - 2016-12-02 13:30:56 --> Router Class Initialized
INFO - 2016-12-02 13:30:56 --> Output Class Initialized
INFO - 2016-12-02 13:30:56 --> Security Class Initialized
DEBUG - 2016-12-02 13:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 13:30:56 --> Input Class Initialized
INFO - 2016-12-02 13:30:56 --> Language Class Initialized
INFO - 2016-12-02 13:30:56 --> Loader Class Initialized
INFO - 2016-12-02 13:30:56 --> Helper loaded: url_helper
INFO - 2016-12-02 13:30:56 --> Helper loaded: form_helper
INFO - 2016-12-02 13:30:56 --> Database Driver Class Initialized
INFO - 2016-12-02 13:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 13:30:56 --> Controller Class Initialized
INFO - 2016-12-02 13:30:56 --> Model Class Initialized
INFO - 2016-12-02 13:30:56 --> Form Validation Class Initialized
INFO - 2016-12-02 13:30:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 13:30:56 --> Pagination Class Initialized
INFO - 2016-12-02 13:30:56 --> Helper loaded: app_helper
INFO - 2016-12-02 13:30:56 --> Email Class Initialized
INFO - 2016-12-02 13:30:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-02 12:30:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-02 12:30:56 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-02 12:30:57 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-02 12:30:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-02 12:30:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 12:30:59 --> Final output sent to browser
DEBUG - 2016-12-02 12:30:59 --> Total execution time: 3.6684
INFO - 2016-12-02 13:39:03 --> Config Class Initialized
INFO - 2016-12-02 13:39:03 --> Hooks Class Initialized
DEBUG - 2016-12-02 13:39:03 --> UTF-8 Support Enabled
INFO - 2016-12-02 13:39:03 --> Utf8 Class Initialized
INFO - 2016-12-02 13:39:03 --> URI Class Initialized
DEBUG - 2016-12-02 13:39:03 --> No URI present. Default controller set.
INFO - 2016-12-02 13:39:03 --> Router Class Initialized
INFO - 2016-12-02 13:39:03 --> Output Class Initialized
INFO - 2016-12-02 13:39:03 --> Security Class Initialized
DEBUG - 2016-12-02 13:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 13:39:03 --> Input Class Initialized
INFO - 2016-12-02 13:39:03 --> Language Class Initialized
INFO - 2016-12-02 13:39:03 --> Loader Class Initialized
INFO - 2016-12-02 13:39:03 --> Helper loaded: url_helper
INFO - 2016-12-02 13:39:03 --> Helper loaded: form_helper
INFO - 2016-12-02 13:39:03 --> Database Driver Class Initialized
INFO - 2016-12-02 13:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 13:39:03 --> Controller Class Initialized
INFO - 2016-12-02 13:39:03 --> Model Class Initialized
INFO - 2016-12-02 13:39:03 --> Model Class Initialized
INFO - 2016-12-02 13:39:03 --> Model Class Initialized
INFO - 2016-12-02 13:39:03 --> Model Class Initialized
INFO - 2016-12-02 13:39:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 13:39:03 --> Pagination Class Initialized
INFO - 2016-12-02 13:39:03 --> Helper loaded: app_helper
INFO - 2016-12-02 13:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 13:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 13:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 13:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 13:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 13:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 13:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 13:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 13:39:03 --> Final output sent to browser
DEBUG - 2016-12-02 13:39:03 --> Total execution time: 0.3921
INFO - 2016-12-02 13:39:14 --> Config Class Initialized
INFO - 2016-12-02 13:39:14 --> Hooks Class Initialized
DEBUG - 2016-12-02 13:39:14 --> UTF-8 Support Enabled
INFO - 2016-12-02 13:39:14 --> Utf8 Class Initialized
INFO - 2016-12-02 13:39:14 --> URI Class Initialized
INFO - 2016-12-02 13:39:14 --> Router Class Initialized
INFO - 2016-12-02 13:39:14 --> Output Class Initialized
INFO - 2016-12-02 13:39:14 --> Security Class Initialized
DEBUG - 2016-12-02 13:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 13:39:14 --> Input Class Initialized
INFO - 2016-12-02 13:39:14 --> Language Class Initialized
INFO - 2016-12-02 13:39:14 --> Loader Class Initialized
INFO - 2016-12-02 13:39:14 --> Helper loaded: url_helper
INFO - 2016-12-02 13:39:14 --> Helper loaded: form_helper
INFO - 2016-12-02 13:39:14 --> Database Driver Class Initialized
INFO - 2016-12-02 13:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 13:39:14 --> Controller Class Initialized
INFO - 2016-12-02 13:39:14 --> Model Class Initialized
INFO - 2016-12-02 13:39:14 --> Form Validation Class Initialized
INFO - 2016-12-02 13:39:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 13:39:14 --> Pagination Class Initialized
INFO - 2016-12-02 13:39:14 --> Helper loaded: app_helper
INFO - 2016-12-02 13:39:14 --> Email Class Initialized
INFO - 2016-12-02 13:39:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-02 12:39:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-02 12:39:14 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-02 12:39:15 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-02 12:39:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-02 12:39:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 12:39:19 --> Final output sent to browser
DEBUG - 2016-12-02 12:39:19 --> Total execution time: 5.3182
INFO - 2016-12-02 13:41:40 --> Config Class Initialized
INFO - 2016-12-02 13:41:40 --> Hooks Class Initialized
DEBUG - 2016-12-02 13:41:40 --> UTF-8 Support Enabled
INFO - 2016-12-02 13:41:40 --> Utf8 Class Initialized
INFO - 2016-12-02 13:41:40 --> URI Class Initialized
DEBUG - 2016-12-02 13:41:40 --> No URI present. Default controller set.
INFO - 2016-12-02 13:41:40 --> Router Class Initialized
INFO - 2016-12-02 13:41:40 --> Output Class Initialized
INFO - 2016-12-02 13:41:40 --> Security Class Initialized
DEBUG - 2016-12-02 13:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 13:41:40 --> Input Class Initialized
INFO - 2016-12-02 13:41:40 --> Language Class Initialized
INFO - 2016-12-02 13:41:40 --> Loader Class Initialized
INFO - 2016-12-02 13:41:40 --> Helper loaded: url_helper
INFO - 2016-12-02 13:41:40 --> Helper loaded: form_helper
INFO - 2016-12-02 13:41:40 --> Database Driver Class Initialized
INFO - 2016-12-02 13:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 13:41:40 --> Controller Class Initialized
INFO - 2016-12-02 13:41:40 --> Model Class Initialized
INFO - 2016-12-02 13:41:40 --> Model Class Initialized
INFO - 2016-12-02 13:41:40 --> Model Class Initialized
INFO - 2016-12-02 13:41:40 --> Model Class Initialized
INFO - 2016-12-02 13:41:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 13:41:40 --> Pagination Class Initialized
INFO - 2016-12-02 13:41:40 --> Helper loaded: app_helper
INFO - 2016-12-02 13:41:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 13:41:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 13:41:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 13:41:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 13:41:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 13:41:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 13:41:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 13:41:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 13:41:40 --> Final output sent to browser
DEBUG - 2016-12-02 13:41:40 --> Total execution time: 0.3656
INFO - 2016-12-02 13:41:45 --> Config Class Initialized
INFO - 2016-12-02 13:41:45 --> Hooks Class Initialized
DEBUG - 2016-12-02 13:41:45 --> UTF-8 Support Enabled
INFO - 2016-12-02 13:41:45 --> Utf8 Class Initialized
INFO - 2016-12-02 13:41:45 --> URI Class Initialized
INFO - 2016-12-02 13:41:45 --> Router Class Initialized
INFO - 2016-12-02 13:41:45 --> Output Class Initialized
INFO - 2016-12-02 13:41:45 --> Security Class Initialized
DEBUG - 2016-12-02 13:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 13:41:45 --> Input Class Initialized
INFO - 2016-12-02 13:41:45 --> Language Class Initialized
INFO - 2016-12-02 13:41:45 --> Loader Class Initialized
INFO - 2016-12-02 13:41:45 --> Helper loaded: url_helper
INFO - 2016-12-02 13:41:45 --> Helper loaded: form_helper
INFO - 2016-12-02 13:41:45 --> Database Driver Class Initialized
INFO - 2016-12-02 13:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 13:41:45 --> Controller Class Initialized
INFO - 2016-12-02 13:41:45 --> Model Class Initialized
INFO - 2016-12-02 13:41:45 --> Model Class Initialized
INFO - 2016-12-02 13:41:45 --> Model Class Initialized
INFO - 2016-12-02 13:41:45 --> Model Class Initialized
INFO - 2016-12-02 13:41:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 13:41:45 --> Pagination Class Initialized
INFO - 2016-12-02 13:41:45 --> Helper loaded: app_helper
DEBUG - 2016-12-02 13:41:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-12-02 13:41:45 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-12-02 13:41:45 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-12-02 13:41:45 --> Config Class Initialized
INFO - 2016-12-02 13:41:45 --> Hooks Class Initialized
DEBUG - 2016-12-02 13:41:45 --> UTF-8 Support Enabled
INFO - 2016-12-02 13:41:45 --> Utf8 Class Initialized
INFO - 2016-12-02 13:41:45 --> URI Class Initialized
DEBUG - 2016-12-02 13:41:45 --> No URI present. Default controller set.
INFO - 2016-12-02 13:41:45 --> Router Class Initialized
INFO - 2016-12-02 13:41:45 --> Output Class Initialized
INFO - 2016-12-02 13:41:45 --> Security Class Initialized
DEBUG - 2016-12-02 13:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 13:41:45 --> Input Class Initialized
INFO - 2016-12-02 13:41:45 --> Language Class Initialized
INFO - 2016-12-02 13:41:45 --> Loader Class Initialized
INFO - 2016-12-02 13:41:45 --> Helper loaded: url_helper
INFO - 2016-12-02 13:41:45 --> Helper loaded: form_helper
INFO - 2016-12-02 13:41:45 --> Database Driver Class Initialized
INFO - 2016-12-02 13:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 13:41:45 --> Controller Class Initialized
INFO - 2016-12-02 13:41:45 --> Model Class Initialized
INFO - 2016-12-02 13:41:45 --> Model Class Initialized
INFO - 2016-12-02 13:41:45 --> Model Class Initialized
INFO - 2016-12-02 13:41:45 --> Model Class Initialized
INFO - 2016-12-02 13:41:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 13:41:45 --> Pagination Class Initialized
INFO - 2016-12-02 13:41:45 --> Helper loaded: app_helper
INFO - 2016-12-02 13:41:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 13:41:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-02 13:41:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 13:41:45 --> Final output sent to browser
DEBUG - 2016-12-02 13:41:45 --> Total execution time: 0.2995
INFO - 2016-12-02 13:42:16 --> Config Class Initialized
INFO - 2016-12-02 13:42:16 --> Hooks Class Initialized
DEBUG - 2016-12-02 13:42:16 --> UTF-8 Support Enabled
INFO - 2016-12-02 13:42:16 --> Utf8 Class Initialized
INFO - 2016-12-02 13:42:16 --> URI Class Initialized
INFO - 2016-12-02 13:42:16 --> Router Class Initialized
INFO - 2016-12-02 13:42:16 --> Output Class Initialized
INFO - 2016-12-02 13:42:16 --> Security Class Initialized
DEBUG - 2016-12-02 13:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 13:42:16 --> Input Class Initialized
INFO - 2016-12-02 13:42:16 --> Language Class Initialized
INFO - 2016-12-02 13:42:16 --> Loader Class Initialized
INFO - 2016-12-02 13:42:16 --> Helper loaded: url_helper
INFO - 2016-12-02 13:42:16 --> Helper loaded: form_helper
INFO - 2016-12-02 13:42:16 --> Database Driver Class Initialized
INFO - 2016-12-02 13:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 13:42:16 --> Controller Class Initialized
INFO - 2016-12-02 13:42:16 --> Model Class Initialized
INFO - 2016-12-02 13:42:16 --> Model Class Initialized
INFO - 2016-12-02 13:42:16 --> Model Class Initialized
INFO - 2016-12-02 13:42:16 --> Model Class Initialized
INFO - 2016-12-02 13:42:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 13:42:16 --> Pagination Class Initialized
INFO - 2016-12-02 13:42:16 --> Helper loaded: app_helper
DEBUG - 2016-12-02 13:42:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 13:42:16 --> Model Class Initialized
INFO - 2016-12-02 13:42:16 --> Final output sent to browser
DEBUG - 2016-12-02 13:42:16 --> Total execution time: 0.2260
INFO - 2016-12-02 13:42:16 --> Config Class Initialized
INFO - 2016-12-02 13:42:17 --> Hooks Class Initialized
DEBUG - 2016-12-02 13:42:17 --> UTF-8 Support Enabled
INFO - 2016-12-02 13:42:17 --> Utf8 Class Initialized
INFO - 2016-12-02 13:42:17 --> URI Class Initialized
DEBUG - 2016-12-02 13:42:17 --> No URI present. Default controller set.
INFO - 2016-12-02 13:42:17 --> Router Class Initialized
INFO - 2016-12-02 13:42:17 --> Output Class Initialized
INFO - 2016-12-02 13:42:17 --> Security Class Initialized
DEBUG - 2016-12-02 13:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 13:42:17 --> Input Class Initialized
INFO - 2016-12-02 13:42:17 --> Language Class Initialized
INFO - 2016-12-02 13:42:17 --> Loader Class Initialized
INFO - 2016-12-02 13:42:17 --> Helper loaded: url_helper
INFO - 2016-12-02 13:42:17 --> Helper loaded: form_helper
INFO - 2016-12-02 13:42:17 --> Database Driver Class Initialized
INFO - 2016-12-02 13:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 13:42:17 --> Controller Class Initialized
INFO - 2016-12-02 13:42:17 --> Model Class Initialized
INFO - 2016-12-02 13:42:17 --> Model Class Initialized
INFO - 2016-12-02 13:42:17 --> Model Class Initialized
INFO - 2016-12-02 13:42:17 --> Model Class Initialized
INFO - 2016-12-02 13:42:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 13:42:17 --> Pagination Class Initialized
INFO - 2016-12-02 13:42:17 --> Helper loaded: app_helper
INFO - 2016-12-02 13:42:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 13:42:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 13:42:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 13:42:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 13:42:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 13:42:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 13:42:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 13:42:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 13:42:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 13:42:17 --> Final output sent to browser
DEBUG - 2016-12-02 13:42:17 --> Total execution time: 0.3724
INFO - 2016-12-02 13:42:27 --> Config Class Initialized
INFO - 2016-12-02 13:42:27 --> Hooks Class Initialized
DEBUG - 2016-12-02 13:42:27 --> UTF-8 Support Enabled
INFO - 2016-12-02 13:42:27 --> Utf8 Class Initialized
INFO - 2016-12-02 13:42:27 --> URI Class Initialized
INFO - 2016-12-02 13:42:27 --> Router Class Initialized
INFO - 2016-12-02 13:42:27 --> Output Class Initialized
INFO - 2016-12-02 13:42:27 --> Security Class Initialized
DEBUG - 2016-12-02 13:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 13:42:27 --> Input Class Initialized
INFO - 2016-12-02 13:42:27 --> Language Class Initialized
INFO - 2016-12-02 13:42:27 --> Loader Class Initialized
INFO - 2016-12-02 13:42:27 --> Helper loaded: url_helper
INFO - 2016-12-02 13:42:27 --> Helper loaded: form_helper
INFO - 2016-12-02 13:42:28 --> Database Driver Class Initialized
INFO - 2016-12-02 13:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 13:42:28 --> Controller Class Initialized
INFO - 2016-12-02 13:42:28 --> Model Class Initialized
INFO - 2016-12-02 13:42:28 --> Form Validation Class Initialized
INFO - 2016-12-02 13:42:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 13:42:28 --> Pagination Class Initialized
INFO - 2016-12-02 13:42:28 --> Helper loaded: app_helper
INFO - 2016-12-02 13:42:28 --> Email Class Initialized
INFO - 2016-12-02 13:42:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-02 12:42:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-02 12:42:28 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-02 12:42:28 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-02 12:42:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-02 12:42:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 12:42:32 --> Final output sent to browser
DEBUG - 2016-12-02 12:42:32 --> Total execution time: 4.5557
INFO - 2016-12-02 13:46:04 --> Config Class Initialized
INFO - 2016-12-02 13:46:05 --> Hooks Class Initialized
DEBUG - 2016-12-02 13:46:05 --> UTF-8 Support Enabled
INFO - 2016-12-02 13:46:05 --> Utf8 Class Initialized
INFO - 2016-12-02 13:46:05 --> URI Class Initialized
DEBUG - 2016-12-02 13:46:05 --> No URI present. Default controller set.
INFO - 2016-12-02 13:46:05 --> Router Class Initialized
INFO - 2016-12-02 13:46:05 --> Output Class Initialized
INFO - 2016-12-02 13:46:05 --> Security Class Initialized
DEBUG - 2016-12-02 13:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 13:46:05 --> Input Class Initialized
INFO - 2016-12-02 13:46:05 --> Language Class Initialized
INFO - 2016-12-02 13:46:05 --> Loader Class Initialized
INFO - 2016-12-02 13:46:05 --> Helper loaded: url_helper
INFO - 2016-12-02 13:46:05 --> Helper loaded: form_helper
INFO - 2016-12-02 13:46:05 --> Database Driver Class Initialized
INFO - 2016-12-02 13:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 13:46:05 --> Controller Class Initialized
INFO - 2016-12-02 13:46:05 --> Model Class Initialized
INFO - 2016-12-02 13:46:05 --> Model Class Initialized
INFO - 2016-12-02 13:46:05 --> Model Class Initialized
INFO - 2016-12-02 13:46:05 --> Model Class Initialized
INFO - 2016-12-02 13:46:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 13:46:05 --> Pagination Class Initialized
INFO - 2016-12-02 13:46:05 --> Helper loaded: app_helper
INFO - 2016-12-02 13:46:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 13:46:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 13:46:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 13:46:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 13:46:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 13:46:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 13:46:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 13:46:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 13:46:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 13:46:05 --> Final output sent to browser
DEBUG - 2016-12-02 13:46:05 --> Total execution time: 0.3809
INFO - 2016-12-02 13:50:18 --> Config Class Initialized
INFO - 2016-12-02 13:50:18 --> Hooks Class Initialized
DEBUG - 2016-12-02 13:50:18 --> UTF-8 Support Enabled
INFO - 2016-12-02 13:50:18 --> Utf8 Class Initialized
INFO - 2016-12-02 13:50:18 --> URI Class Initialized
DEBUG - 2016-12-02 13:50:18 --> No URI present. Default controller set.
INFO - 2016-12-02 13:50:18 --> Router Class Initialized
INFO - 2016-12-02 13:50:18 --> Output Class Initialized
INFO - 2016-12-02 13:50:18 --> Security Class Initialized
DEBUG - 2016-12-02 13:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 13:50:18 --> Input Class Initialized
INFO - 2016-12-02 13:50:18 --> Language Class Initialized
INFO - 2016-12-02 13:50:18 --> Loader Class Initialized
INFO - 2016-12-02 13:50:18 --> Helper loaded: url_helper
INFO - 2016-12-02 13:50:18 --> Helper loaded: form_helper
INFO - 2016-12-02 13:50:18 --> Database Driver Class Initialized
INFO - 2016-12-02 13:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 13:50:18 --> Controller Class Initialized
INFO - 2016-12-02 13:50:18 --> Model Class Initialized
INFO - 2016-12-02 13:50:18 --> Model Class Initialized
INFO - 2016-12-02 13:50:18 --> Model Class Initialized
INFO - 2016-12-02 13:50:18 --> Model Class Initialized
INFO - 2016-12-02 13:50:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 13:50:18 --> Pagination Class Initialized
INFO - 2016-12-02 13:50:18 --> Helper loaded: app_helper
INFO - 2016-12-02 13:50:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 13:50:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 13:50:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 13:50:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 13:50:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 13:50:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 13:50:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 13:50:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 13:50:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 13:50:18 --> Final output sent to browser
DEBUG - 2016-12-02 13:50:18 --> Total execution time: 0.3888
INFO - 2016-12-02 14:20:28 --> Config Class Initialized
INFO - 2016-12-02 14:20:28 --> Hooks Class Initialized
DEBUG - 2016-12-02 14:20:29 --> UTF-8 Support Enabled
INFO - 2016-12-02 14:20:29 --> Utf8 Class Initialized
INFO - 2016-12-02 14:20:29 --> URI Class Initialized
DEBUG - 2016-12-02 14:20:29 --> No URI present. Default controller set.
INFO - 2016-12-02 14:20:29 --> Router Class Initialized
INFO - 2016-12-02 14:20:29 --> Output Class Initialized
INFO - 2016-12-02 14:20:29 --> Security Class Initialized
DEBUG - 2016-12-02 14:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 14:20:29 --> Input Class Initialized
INFO - 2016-12-02 14:20:29 --> Language Class Initialized
INFO - 2016-12-02 14:20:29 --> Loader Class Initialized
INFO - 2016-12-02 14:20:29 --> Helper loaded: url_helper
INFO - 2016-12-02 14:20:29 --> Helper loaded: form_helper
INFO - 2016-12-02 14:20:29 --> Database Driver Class Initialized
INFO - 2016-12-02 14:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 14:20:30 --> Controller Class Initialized
INFO - 2016-12-02 14:20:30 --> Model Class Initialized
INFO - 2016-12-02 14:20:30 --> Model Class Initialized
INFO - 2016-12-02 14:20:30 --> Model Class Initialized
INFO - 2016-12-02 14:20:30 --> Model Class Initialized
INFO - 2016-12-02 14:20:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 14:20:30 --> Pagination Class Initialized
INFO - 2016-12-02 14:20:30 --> Helper loaded: app_helper
INFO - 2016-12-02 14:20:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 14:20:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-02 14:20:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 14:20:30 --> Final output sent to browser
DEBUG - 2016-12-02 14:20:30 --> Total execution time: 1.8783
INFO - 2016-12-02 14:25:28 --> Config Class Initialized
INFO - 2016-12-02 14:25:28 --> Hooks Class Initialized
DEBUG - 2016-12-02 14:25:28 --> UTF-8 Support Enabled
INFO - 2016-12-02 14:25:28 --> Utf8 Class Initialized
INFO - 2016-12-02 14:25:28 --> URI Class Initialized
INFO - 2016-12-02 14:25:28 --> Router Class Initialized
INFO - 2016-12-02 14:25:28 --> Output Class Initialized
INFO - 2016-12-02 14:25:28 --> Security Class Initialized
DEBUG - 2016-12-02 14:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 14:25:28 --> Input Class Initialized
INFO - 2016-12-02 14:25:28 --> Language Class Initialized
INFO - 2016-12-02 14:25:28 --> Loader Class Initialized
INFO - 2016-12-02 14:25:28 --> Helper loaded: url_helper
INFO - 2016-12-02 14:25:28 --> Helper loaded: form_helper
INFO - 2016-12-02 14:25:28 --> Database Driver Class Initialized
INFO - 2016-12-02 14:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 14:25:28 --> Controller Class Initialized
INFO - 2016-12-02 14:25:28 --> Model Class Initialized
INFO - 2016-12-02 14:25:28 --> Model Class Initialized
INFO - 2016-12-02 14:25:28 --> Model Class Initialized
INFO - 2016-12-02 14:25:28 --> Model Class Initialized
INFO - 2016-12-02 14:25:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 14:25:28 --> Pagination Class Initialized
INFO - 2016-12-02 14:25:29 --> Helper loaded: app_helper
DEBUG - 2016-12-02 14:25:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-12-02 14:25:29 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-12-02 14:25:29 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-12-02 14:25:29 --> Config Class Initialized
INFO - 2016-12-02 14:25:29 --> Hooks Class Initialized
DEBUG - 2016-12-02 14:25:29 --> UTF-8 Support Enabled
INFO - 2016-12-02 14:25:29 --> Utf8 Class Initialized
INFO - 2016-12-02 14:25:29 --> URI Class Initialized
DEBUG - 2016-12-02 14:25:29 --> No URI present. Default controller set.
INFO - 2016-12-02 14:25:29 --> Router Class Initialized
INFO - 2016-12-02 14:25:29 --> Output Class Initialized
INFO - 2016-12-02 14:25:29 --> Security Class Initialized
DEBUG - 2016-12-02 14:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 14:25:29 --> Input Class Initialized
INFO - 2016-12-02 14:25:29 --> Language Class Initialized
INFO - 2016-12-02 14:25:29 --> Loader Class Initialized
INFO - 2016-12-02 14:25:29 --> Helper loaded: url_helper
INFO - 2016-12-02 14:25:29 --> Helper loaded: form_helper
INFO - 2016-12-02 14:25:29 --> Database Driver Class Initialized
INFO - 2016-12-02 14:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 14:25:29 --> Controller Class Initialized
INFO - 2016-12-02 14:25:29 --> Model Class Initialized
INFO - 2016-12-02 14:25:29 --> Model Class Initialized
INFO - 2016-12-02 14:25:29 --> Model Class Initialized
INFO - 2016-12-02 14:25:29 --> Model Class Initialized
INFO - 2016-12-02 14:25:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 14:25:29 --> Pagination Class Initialized
INFO - 2016-12-02 14:25:29 --> Helper loaded: app_helper
INFO - 2016-12-02 14:25:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 14:25:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-02 14:25:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 14:25:29 --> Final output sent to browser
DEBUG - 2016-12-02 14:25:29 --> Total execution time: 0.4031
INFO - 2016-12-02 15:00:41 --> Config Class Initialized
INFO - 2016-12-02 15:00:42 --> Hooks Class Initialized
DEBUG - 2016-12-02 15:00:42 --> UTF-8 Support Enabled
INFO - 2016-12-02 15:00:42 --> Utf8 Class Initialized
INFO - 2016-12-02 15:00:42 --> URI Class Initialized
DEBUG - 2016-12-02 15:00:42 --> No URI present. Default controller set.
INFO - 2016-12-02 15:00:42 --> Router Class Initialized
INFO - 2016-12-02 15:00:42 --> Output Class Initialized
INFO - 2016-12-02 15:00:42 --> Security Class Initialized
DEBUG - 2016-12-02 15:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 15:00:42 --> Input Class Initialized
INFO - 2016-12-02 15:00:42 --> Language Class Initialized
INFO - 2016-12-02 15:00:42 --> Loader Class Initialized
INFO - 2016-12-02 15:00:42 --> Helper loaded: url_helper
INFO - 2016-12-02 15:00:42 --> Helper loaded: form_helper
INFO - 2016-12-02 15:00:42 --> Database Driver Class Initialized
INFO - 2016-12-02 15:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 15:00:43 --> Controller Class Initialized
INFO - 2016-12-02 15:00:43 --> Model Class Initialized
INFO - 2016-12-02 15:00:43 --> Model Class Initialized
INFO - 2016-12-02 15:00:43 --> Model Class Initialized
INFO - 2016-12-02 15:00:43 --> Model Class Initialized
INFO - 2016-12-02 15:00:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 15:00:43 --> Pagination Class Initialized
INFO - 2016-12-02 15:00:43 --> Helper loaded: app_helper
INFO - 2016-12-02 15:00:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 15:00:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-02 15:00:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 15:00:43 --> Final output sent to browser
DEBUG - 2016-12-02 15:00:43 --> Total execution time: 1.5726
INFO - 2016-12-02 18:31:14 --> Config Class Initialized
INFO - 2016-12-02 18:31:14 --> Hooks Class Initialized
INFO - 2016-12-02 18:31:14 --> Config Class Initialized
INFO - 2016-12-02 18:31:14 --> Hooks Class Initialized
DEBUG - 2016-12-02 18:31:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-02 18:31:15 --> UTF-8 Support Enabled
INFO - 2016-12-02 18:31:15 --> Utf8 Class Initialized
INFO - 2016-12-02 18:31:15 --> Utf8 Class Initialized
INFO - 2016-12-02 18:31:15 --> URI Class Initialized
INFO - 2016-12-02 18:31:15 --> URI Class Initialized
DEBUG - 2016-12-02 18:31:15 --> No URI present. Default controller set.
DEBUG - 2016-12-02 18:31:15 --> No URI present. Default controller set.
INFO - 2016-12-02 18:31:15 --> Router Class Initialized
INFO - 2016-12-02 18:31:15 --> Router Class Initialized
INFO - 2016-12-02 18:31:15 --> Output Class Initialized
INFO - 2016-12-02 18:31:15 --> Output Class Initialized
INFO - 2016-12-02 18:31:15 --> Security Class Initialized
INFO - 2016-12-02 18:31:15 --> Security Class Initialized
DEBUG - 2016-12-02 18:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-12-02 18:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 18:31:16 --> Input Class Initialized
INFO - 2016-12-02 18:31:16 --> Input Class Initialized
INFO - 2016-12-02 18:31:16 --> Language Class Initialized
INFO - 2016-12-02 18:31:16 --> Language Class Initialized
INFO - 2016-12-02 18:31:16 --> Loader Class Initialized
INFO - 2016-12-02 18:31:16 --> Loader Class Initialized
INFO - 2016-12-02 18:31:16 --> Helper loaded: url_helper
INFO - 2016-12-02 18:31:16 --> Helper loaded: url_helper
INFO - 2016-12-02 18:31:16 --> Helper loaded: form_helper
INFO - 2016-12-02 18:31:16 --> Helper loaded: form_helper
INFO - 2016-12-02 18:31:17 --> Database Driver Class Initialized
INFO - 2016-12-02 18:31:17 --> Database Driver Class Initialized
INFO - 2016-12-02 18:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 18:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 18:31:18 --> Controller Class Initialized
INFO - 2016-12-02 18:31:18 --> Controller Class Initialized
INFO - 2016-12-02 18:31:18 --> Model Class Initialized
INFO - 2016-12-02 18:31:18 --> Model Class Initialized
INFO - 2016-12-02 18:31:18 --> Model Class Initialized
INFO - 2016-12-02 18:31:18 --> Model Class Initialized
INFO - 2016-12-02 18:31:18 --> Model Class Initialized
INFO - 2016-12-02 18:31:18 --> Model Class Initialized
INFO - 2016-12-02 18:31:18 --> Model Class Initialized
INFO - 2016-12-02 18:31:18 --> Model Class Initialized
INFO - 2016-12-02 18:31:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 18:31:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 18:31:18 --> Pagination Class Initialized
INFO - 2016-12-02 18:31:18 --> Pagination Class Initialized
INFO - 2016-12-02 18:31:19 --> Helper loaded: app_helper
INFO - 2016-12-02 18:31:19 --> Helper loaded: app_helper
INFO - 2016-12-02 18:31:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 18:31:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 18:31:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-02 18:31:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-02 18:31:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 18:31:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 18:31:19 --> Final output sent to browser
INFO - 2016-12-02 18:31:19 --> Final output sent to browser
DEBUG - 2016-12-02 18:31:19 --> Total execution time: 4.4391
DEBUG - 2016-12-02 18:31:19 --> Total execution time: 5.0008
INFO - 2016-12-02 18:31:34 --> Config Class Initialized
INFO - 2016-12-02 18:31:34 --> Hooks Class Initialized
DEBUG - 2016-12-02 18:31:34 --> UTF-8 Support Enabled
INFO - 2016-12-02 18:31:34 --> Utf8 Class Initialized
INFO - 2016-12-02 18:31:34 --> URI Class Initialized
INFO - 2016-12-02 18:31:34 --> Router Class Initialized
INFO - 2016-12-02 18:31:34 --> Output Class Initialized
INFO - 2016-12-02 18:31:34 --> Security Class Initialized
DEBUG - 2016-12-02 18:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 18:31:35 --> Input Class Initialized
INFO - 2016-12-02 18:31:35 --> Language Class Initialized
INFO - 2016-12-02 18:31:35 --> Loader Class Initialized
INFO - 2016-12-02 18:31:35 --> Helper loaded: url_helper
INFO - 2016-12-02 18:31:35 --> Helper loaded: form_helper
INFO - 2016-12-02 18:31:35 --> Database Driver Class Initialized
INFO - 2016-12-02 18:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 18:31:35 --> Controller Class Initialized
INFO - 2016-12-02 18:31:35 --> Model Class Initialized
INFO - 2016-12-02 18:31:35 --> Model Class Initialized
INFO - 2016-12-02 18:31:35 --> Model Class Initialized
INFO - 2016-12-02 18:31:35 --> Model Class Initialized
INFO - 2016-12-02 18:31:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 18:31:35 --> Pagination Class Initialized
INFO - 2016-12-02 18:31:35 --> Helper loaded: app_helper
DEBUG - 2016-12-02 18:31:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 18:31:35 --> Model Class Initialized
INFO - 2016-12-02 18:31:35 --> Final output sent to browser
DEBUG - 2016-12-02 18:31:35 --> Total execution time: 0.5319
INFO - 2016-12-02 18:31:35 --> Config Class Initialized
INFO - 2016-12-02 18:31:35 --> Hooks Class Initialized
DEBUG - 2016-12-02 18:31:35 --> UTF-8 Support Enabled
INFO - 2016-12-02 18:31:35 --> Utf8 Class Initialized
INFO - 2016-12-02 18:31:35 --> URI Class Initialized
DEBUG - 2016-12-02 18:31:35 --> No URI present. Default controller set.
INFO - 2016-12-02 18:31:35 --> Router Class Initialized
INFO - 2016-12-02 18:31:35 --> Output Class Initialized
INFO - 2016-12-02 18:31:35 --> Security Class Initialized
DEBUG - 2016-12-02 18:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 18:31:35 --> Input Class Initialized
INFO - 2016-12-02 18:31:35 --> Language Class Initialized
INFO - 2016-12-02 18:31:35 --> Loader Class Initialized
INFO - 2016-12-02 18:31:35 --> Helper loaded: url_helper
INFO - 2016-12-02 18:31:35 --> Helper loaded: form_helper
INFO - 2016-12-02 18:31:35 --> Database Driver Class Initialized
INFO - 2016-12-02 18:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 18:31:35 --> Controller Class Initialized
INFO - 2016-12-02 18:31:35 --> Model Class Initialized
INFO - 2016-12-02 18:31:35 --> Model Class Initialized
INFO - 2016-12-02 18:31:35 --> Model Class Initialized
INFO - 2016-12-02 18:31:35 --> Model Class Initialized
INFO - 2016-12-02 18:31:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 18:31:35 --> Pagination Class Initialized
INFO - 2016-12-02 18:31:35 --> Helper loaded: app_helper
INFO - 2016-12-02 18:31:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 18:31:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 18:31:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 18:31:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 18:31:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 18:31:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 18:31:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 18:31:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 18:31:36 --> Final output sent to browser
DEBUG - 2016-12-02 18:31:36 --> Total execution time: 1.0956
INFO - 2016-12-02 18:32:48 --> Config Class Initialized
INFO - 2016-12-02 18:32:48 --> Hooks Class Initialized
DEBUG - 2016-12-02 18:32:48 --> UTF-8 Support Enabled
INFO - 2016-12-02 18:32:48 --> Utf8 Class Initialized
INFO - 2016-12-02 18:32:48 --> URI Class Initialized
INFO - 2016-12-02 18:32:48 --> Router Class Initialized
INFO - 2016-12-02 18:32:48 --> Output Class Initialized
INFO - 2016-12-02 18:32:48 --> Security Class Initialized
DEBUG - 2016-12-02 18:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 18:32:48 --> Input Class Initialized
INFO - 2016-12-02 18:32:48 --> Language Class Initialized
INFO - 2016-12-02 18:32:48 --> Loader Class Initialized
INFO - 2016-12-02 18:32:48 --> Helper loaded: url_helper
INFO - 2016-12-02 18:32:48 --> Helper loaded: form_helper
INFO - 2016-12-02 18:32:48 --> Database Driver Class Initialized
INFO - 2016-12-02 18:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 18:32:48 --> Controller Class Initialized
INFO - 2016-12-02 18:32:48 --> Model Class Initialized
INFO - 2016-12-02 18:32:48 --> Form Validation Class Initialized
INFO - 2016-12-02 18:32:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 18:32:48 --> Pagination Class Initialized
INFO - 2016-12-02 18:32:48 --> Helper loaded: app_helper
INFO - 2016-12-02 18:32:48 --> Email Class Initialized
INFO - 2016-12-02 18:32:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-02 17:32:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-02 17:32:49 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-02 17:32:49 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-02 17:32:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-02 17:32:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 17:32:54 --> Final output sent to browser
DEBUG - 2016-12-02 17:32:54 --> Total execution time: 5.4973
INFO - 2016-12-02 19:01:33 --> Config Class Initialized
INFO - 2016-12-02 19:01:33 --> Hooks Class Initialized
DEBUG - 2016-12-02 19:01:33 --> UTF-8 Support Enabled
INFO - 2016-12-02 19:01:33 --> Utf8 Class Initialized
INFO - 2016-12-02 19:01:33 --> URI Class Initialized
INFO - 2016-12-02 19:01:33 --> Router Class Initialized
INFO - 2016-12-02 19:01:33 --> Output Class Initialized
INFO - 2016-12-02 19:01:33 --> Security Class Initialized
DEBUG - 2016-12-02 19:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 19:01:34 --> Input Class Initialized
INFO - 2016-12-02 19:01:34 --> Language Class Initialized
INFO - 2016-12-02 19:01:34 --> Loader Class Initialized
INFO - 2016-12-02 19:01:34 --> Helper loaded: url_helper
INFO - 2016-12-02 19:01:34 --> Helper loaded: form_helper
INFO - 2016-12-02 19:01:34 --> Database Driver Class Initialized
INFO - 2016-12-02 19:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 19:01:34 --> Controller Class Initialized
INFO - 2016-12-02 19:01:34 --> Model Class Initialized
INFO - 2016-12-02 19:01:34 --> Form Validation Class Initialized
INFO - 2016-12-02 19:01:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 19:01:34 --> Pagination Class Initialized
INFO - 2016-12-02 19:01:34 --> Helper loaded: app_helper
INFO - 2016-12-02 19:01:34 --> Email Class Initialized
INFO - 2016-12-02 19:01:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-02 18:01:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-02 18:01:34 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-02 18:01:35 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-02 18:01:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-02 18:01:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 18:01:39 --> Final output sent to browser
DEBUG - 2016-12-02 18:01:39 --> Total execution time: 5.7879
INFO - 2016-12-02 19:53:07 --> Config Class Initialized
INFO - 2016-12-02 19:53:07 --> Hooks Class Initialized
DEBUG - 2016-12-02 19:53:07 --> UTF-8 Support Enabled
INFO - 2016-12-02 19:53:07 --> Utf8 Class Initialized
INFO - 2016-12-02 19:53:07 --> URI Class Initialized
INFO - 2016-12-02 19:53:07 --> Router Class Initialized
INFO - 2016-12-02 19:53:07 --> Output Class Initialized
INFO - 2016-12-02 19:53:07 --> Security Class Initialized
DEBUG - 2016-12-02 19:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 19:53:07 --> Input Class Initialized
INFO - 2016-12-02 19:53:07 --> Language Class Initialized
INFO - 2016-12-02 19:53:07 --> Loader Class Initialized
INFO - 2016-12-02 19:53:07 --> Helper loaded: url_helper
INFO - 2016-12-02 19:53:07 --> Helper loaded: form_helper
INFO - 2016-12-02 19:53:07 --> Database Driver Class Initialized
INFO - 2016-12-02 19:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 19:53:07 --> Controller Class Initialized
INFO - 2016-12-02 19:53:07 --> Model Class Initialized
INFO - 2016-12-02 19:53:07 --> Form Validation Class Initialized
INFO - 2016-12-02 19:53:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 19:53:07 --> Pagination Class Initialized
INFO - 2016-12-02 19:53:07 --> Helper loaded: app_helper
INFO - 2016-12-02 19:53:07 --> Email Class Initialized
INFO - 2016-12-02 19:53:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-02 18:53:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-02 18:53:07 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-02 18:53:10 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-02 18:53:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-02 18:53:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 18:53:16 --> Final output sent to browser
DEBUG - 2016-12-02 18:53:16 --> Total execution time: 8.8823
INFO - 2016-12-02 19:55:45 --> Config Class Initialized
INFO - 2016-12-02 19:55:45 --> Hooks Class Initialized
DEBUG - 2016-12-02 19:55:45 --> UTF-8 Support Enabled
INFO - 2016-12-02 19:55:45 --> Utf8 Class Initialized
INFO - 2016-12-02 19:55:45 --> URI Class Initialized
INFO - 2016-12-02 19:55:45 --> Router Class Initialized
INFO - 2016-12-02 19:55:45 --> Output Class Initialized
INFO - 2016-12-02 19:55:45 --> Security Class Initialized
DEBUG - 2016-12-02 19:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 19:55:46 --> Input Class Initialized
INFO - 2016-12-02 19:55:46 --> Language Class Initialized
INFO - 2016-12-02 19:55:46 --> Loader Class Initialized
INFO - 2016-12-02 19:55:46 --> Helper loaded: url_helper
INFO - 2016-12-02 19:55:46 --> Helper loaded: form_helper
INFO - 2016-12-02 19:55:46 --> Database Driver Class Initialized
INFO - 2016-12-02 19:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 19:55:46 --> Controller Class Initialized
INFO - 2016-12-02 19:55:46 --> Model Class Initialized
INFO - 2016-12-02 19:55:46 --> Form Validation Class Initialized
INFO - 2016-12-02 19:55:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 19:55:46 --> Pagination Class Initialized
INFO - 2016-12-02 19:55:46 --> Helper loaded: app_helper
INFO - 2016-12-02 19:55:46 --> Email Class Initialized
INFO - 2016-12-02 19:55:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-02 18:55:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-02 18:55:46 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-02 18:55:46 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-02 18:55:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-02 18:55:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 18:55:49 --> Final output sent to browser
DEBUG - 2016-12-02 18:55:49 --> Total execution time: 4.0429
INFO - 2016-12-02 19:55:58 --> Config Class Initialized
INFO - 2016-12-02 19:55:58 --> Hooks Class Initialized
DEBUG - 2016-12-02 19:55:58 --> UTF-8 Support Enabled
INFO - 2016-12-02 19:55:58 --> Utf8 Class Initialized
INFO - 2016-12-02 19:55:58 --> URI Class Initialized
INFO - 2016-12-02 19:55:58 --> Router Class Initialized
INFO - 2016-12-02 19:55:58 --> Output Class Initialized
INFO - 2016-12-02 19:55:58 --> Security Class Initialized
DEBUG - 2016-12-02 19:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 19:55:58 --> Input Class Initialized
INFO - 2016-12-02 19:55:58 --> Language Class Initialized
INFO - 2016-12-02 19:55:58 --> Loader Class Initialized
INFO - 2016-12-02 19:55:59 --> Helper loaded: url_helper
INFO - 2016-12-02 19:55:59 --> Helper loaded: form_helper
INFO - 2016-12-02 19:55:59 --> Database Driver Class Initialized
INFO - 2016-12-02 19:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 19:55:59 --> Controller Class Initialized
INFO - 2016-12-02 19:55:59 --> Model Class Initialized
INFO - 2016-12-02 19:55:59 --> Form Validation Class Initialized
INFO - 2016-12-02 19:55:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 19:55:59 --> Pagination Class Initialized
INFO - 2016-12-02 19:55:59 --> Helper loaded: app_helper
INFO - 2016-12-02 19:55:59 --> Email Class Initialized
INFO - 2016-12-02 20:03:25 --> Config Class Initialized
INFO - 2016-12-02 20:03:25 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:03:25 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:03:25 --> Utf8 Class Initialized
INFO - 2016-12-02 20:03:25 --> URI Class Initialized
INFO - 2016-12-02 20:03:25 --> Router Class Initialized
INFO - 2016-12-02 20:03:25 --> Output Class Initialized
INFO - 2016-12-02 20:03:25 --> Security Class Initialized
DEBUG - 2016-12-02 20:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:03:25 --> Input Class Initialized
INFO - 2016-12-02 20:03:25 --> Language Class Initialized
INFO - 2016-12-02 20:03:25 --> Loader Class Initialized
INFO - 2016-12-02 20:03:25 --> Helper loaded: url_helper
INFO - 2016-12-02 20:03:25 --> Helper loaded: form_helper
INFO - 2016-12-02 20:03:25 --> Database Driver Class Initialized
INFO - 2016-12-02 20:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:03:25 --> Controller Class Initialized
INFO - 2016-12-02 20:03:25 --> Model Class Initialized
INFO - 2016-12-02 20:03:25 --> Form Validation Class Initialized
INFO - 2016-12-02 20:03:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:03:25 --> Pagination Class Initialized
INFO - 2016-12-02 20:03:25 --> Helper loaded: app_helper
INFO - 2016-12-02 20:03:25 --> Email Class Initialized
ERROR - 2016-12-02 20:03:25 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 17
ERROR - 2016-12-02 20:03:25 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 17
INFO - 2016-12-02 20:05:44 --> Config Class Initialized
INFO - 2016-12-02 20:05:44 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:05:44 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:05:44 --> Utf8 Class Initialized
INFO - 2016-12-02 20:05:44 --> URI Class Initialized
INFO - 2016-12-02 20:05:44 --> Router Class Initialized
INFO - 2016-12-02 20:05:44 --> Output Class Initialized
INFO - 2016-12-02 20:05:44 --> Security Class Initialized
DEBUG - 2016-12-02 20:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:05:44 --> Input Class Initialized
INFO - 2016-12-02 20:05:44 --> Language Class Initialized
INFO - 2016-12-02 20:05:44 --> Loader Class Initialized
INFO - 2016-12-02 20:05:44 --> Helper loaded: url_helper
INFO - 2016-12-02 20:05:44 --> Helper loaded: form_helper
INFO - 2016-12-02 20:05:44 --> Database Driver Class Initialized
INFO - 2016-12-02 20:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:05:44 --> Controller Class Initialized
INFO - 2016-12-02 20:05:44 --> Model Class Initialized
INFO - 2016-12-02 20:05:44 --> Form Validation Class Initialized
INFO - 2016-12-02 20:05:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:05:44 --> Pagination Class Initialized
INFO - 2016-12-02 20:05:44 --> Helper loaded: app_helper
INFO - 2016-12-02 20:05:44 --> Email Class Initialized
ERROR - 2016-12-02 20:05:44 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 20
ERROR - 2016-12-02 20:05:44 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 27
ERROR - 2016-12-02 20:05:44 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-12-02 20:05:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-12-02 20:05:44 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 20
ERROR - 2016-12-02 20:05:44 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 27
ERROR - 2016-12-02 20:05:44 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-12-02 20:05:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-12-02 20:05:44 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 20
ERROR - 2016-12-02 20:05:45 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 27
ERROR - 2016-12-02 20:05:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-12-02 20:05:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-12-02 20:05:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 20:05:45 --> Final output sent to browser
DEBUG - 2016-12-02 20:05:45 --> Total execution time: 0.4336
INFO - 2016-12-02 20:11:50 --> Config Class Initialized
INFO - 2016-12-02 20:11:50 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:11:50 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:11:50 --> Utf8 Class Initialized
INFO - 2016-12-02 20:11:50 --> URI Class Initialized
INFO - 2016-12-02 20:11:50 --> Router Class Initialized
INFO - 2016-12-02 20:11:50 --> Output Class Initialized
INFO - 2016-12-02 20:11:50 --> Security Class Initialized
DEBUG - 2016-12-02 20:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:11:50 --> Input Class Initialized
INFO - 2016-12-02 20:11:50 --> Language Class Initialized
INFO - 2016-12-02 20:11:50 --> Loader Class Initialized
INFO - 2016-12-02 20:11:50 --> Helper loaded: url_helper
INFO - 2016-12-02 20:11:50 --> Helper loaded: form_helper
INFO - 2016-12-02 20:11:50 --> Database Driver Class Initialized
INFO - 2016-12-02 20:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:11:50 --> Controller Class Initialized
INFO - 2016-12-02 20:11:50 --> Model Class Initialized
INFO - 2016-12-02 20:11:50 --> Form Validation Class Initialized
INFO - 2016-12-02 20:11:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:11:50 --> Pagination Class Initialized
INFO - 2016-12-02 20:11:50 --> Helper loaded: app_helper
INFO - 2016-12-02 20:11:51 --> Email Class Initialized
ERROR - 2016-12-02 20:11:51 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 20
ERROR - 2016-12-02 20:11:51 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 27
ERROR - 2016-12-02 20:11:51 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-12-02 20:11:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-12-02 20:11:51 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 20
ERROR - 2016-12-02 20:11:51 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 27
ERROR - 2016-12-02 20:11:51 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-12-02 20:11:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-12-02 20:11:51 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 20
ERROR - 2016-12-02 20:11:51 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 27
ERROR - 2016-12-02 20:11:51 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-12-02 20:11:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-12-02 20:11:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 20:11:51 --> Final output sent to browser
DEBUG - 2016-12-02 20:11:51 --> Total execution time: 0.4425
INFO - 2016-12-02 20:15:55 --> Config Class Initialized
INFO - 2016-12-02 20:15:56 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:15:56 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:15:56 --> Utf8 Class Initialized
INFO - 2016-12-02 20:15:56 --> URI Class Initialized
INFO - 2016-12-02 20:15:56 --> Router Class Initialized
INFO - 2016-12-02 20:15:56 --> Output Class Initialized
INFO - 2016-12-02 20:15:56 --> Security Class Initialized
DEBUG - 2016-12-02 20:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:15:56 --> Input Class Initialized
INFO - 2016-12-02 20:15:56 --> Language Class Initialized
ERROR - 2016-12-02 20:15:56 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 149
INFO - 2016-12-02 20:18:10 --> Config Class Initialized
INFO - 2016-12-02 20:18:10 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:18:10 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:18:10 --> Utf8 Class Initialized
INFO - 2016-12-02 20:18:10 --> URI Class Initialized
INFO - 2016-12-02 20:18:10 --> Router Class Initialized
INFO - 2016-12-02 20:18:10 --> Output Class Initialized
INFO - 2016-12-02 20:18:10 --> Security Class Initialized
DEBUG - 2016-12-02 20:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:18:10 --> Input Class Initialized
INFO - 2016-12-02 20:18:10 --> Language Class Initialized
INFO - 2016-12-02 20:18:10 --> Loader Class Initialized
INFO - 2016-12-02 20:18:10 --> Helper loaded: url_helper
INFO - 2016-12-02 20:18:10 --> Helper loaded: form_helper
INFO - 2016-12-02 20:18:10 --> Database Driver Class Initialized
INFO - 2016-12-02 20:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:18:10 --> Controller Class Initialized
INFO - 2016-12-02 20:18:10 --> Model Class Initialized
INFO - 2016-12-02 20:18:10 --> Form Validation Class Initialized
INFO - 2016-12-02 20:18:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:18:10 --> Pagination Class Initialized
INFO - 2016-12-02 20:18:10 --> Helper loaded: app_helper
INFO - 2016-12-02 20:18:10 --> Email Class Initialized
INFO - 2016-12-02 20:23:13 --> Config Class Initialized
INFO - 2016-12-02 20:23:13 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:23:13 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:23:13 --> Utf8 Class Initialized
INFO - 2016-12-02 20:23:13 --> URI Class Initialized
INFO - 2016-12-02 20:23:13 --> Router Class Initialized
INFO - 2016-12-02 20:23:13 --> Output Class Initialized
INFO - 2016-12-02 20:23:13 --> Security Class Initialized
DEBUG - 2016-12-02 20:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:23:13 --> Input Class Initialized
INFO - 2016-12-02 20:23:13 --> Language Class Initialized
INFO - 2016-12-02 20:23:13 --> Loader Class Initialized
INFO - 2016-12-02 20:23:13 --> Helper loaded: url_helper
INFO - 2016-12-02 20:23:13 --> Helper loaded: form_helper
INFO - 2016-12-02 20:23:13 --> Database Driver Class Initialized
INFO - 2016-12-02 20:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:23:13 --> Controller Class Initialized
INFO - 2016-12-02 20:23:13 --> Model Class Initialized
INFO - 2016-12-02 20:23:13 --> Form Validation Class Initialized
INFO - 2016-12-02 20:23:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:23:13 --> Pagination Class Initialized
INFO - 2016-12-02 20:23:13 --> Helper loaded: app_helper
INFO - 2016-12-02 20:23:13 --> Email Class Initialized
ERROR - 2016-12-02 20:23:13 --> Severity: Notice --> Undefined property: mysqli::$id C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 149
INFO - 2016-12-02 20:26:07 --> Config Class Initialized
INFO - 2016-12-02 20:26:07 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:26:07 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:26:07 --> Utf8 Class Initialized
INFO - 2016-12-02 20:26:07 --> URI Class Initialized
INFO - 2016-12-02 20:26:07 --> Router Class Initialized
INFO - 2016-12-02 20:26:07 --> Output Class Initialized
INFO - 2016-12-02 20:26:07 --> Security Class Initialized
DEBUG - 2016-12-02 20:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:26:07 --> Input Class Initialized
INFO - 2016-12-02 20:26:07 --> Language Class Initialized
INFO - 2016-12-02 20:26:07 --> Loader Class Initialized
INFO - 2016-12-02 20:26:07 --> Helper loaded: url_helper
INFO - 2016-12-02 20:26:07 --> Helper loaded: form_helper
INFO - 2016-12-02 20:26:07 --> Database Driver Class Initialized
INFO - 2016-12-02 20:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:26:07 --> Controller Class Initialized
INFO - 2016-12-02 20:26:07 --> Model Class Initialized
INFO - 2016-12-02 20:26:07 --> Form Validation Class Initialized
INFO - 2016-12-02 20:26:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:26:07 --> Pagination Class Initialized
INFO - 2016-12-02 20:26:07 --> Helper loaded: app_helper
INFO - 2016-12-02 20:26:07 --> Email Class Initialized
ERROR - 2016-12-02 20:26:08 --> Severity: Notice --> Undefined property: mysqli::$name C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 149
INFO - 2016-12-02 20:26:59 --> Config Class Initialized
INFO - 2016-12-02 20:26:59 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:26:59 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:26:59 --> Utf8 Class Initialized
INFO - 2016-12-02 20:26:59 --> URI Class Initialized
INFO - 2016-12-02 20:26:59 --> Router Class Initialized
INFO - 2016-12-02 20:26:59 --> Output Class Initialized
INFO - 2016-12-02 20:26:59 --> Security Class Initialized
DEBUG - 2016-12-02 20:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:26:59 --> Input Class Initialized
INFO - 2016-12-02 20:26:59 --> Language Class Initialized
INFO - 2016-12-02 20:26:59 --> Loader Class Initialized
INFO - 2016-12-02 20:26:59 --> Helper loaded: url_helper
INFO - 2016-12-02 20:26:59 --> Helper loaded: form_helper
INFO - 2016-12-02 20:26:59 --> Database Driver Class Initialized
INFO - 2016-12-02 20:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:26:59 --> Controller Class Initialized
INFO - 2016-12-02 20:26:59 --> Model Class Initialized
INFO - 2016-12-02 20:26:59 --> Form Validation Class Initialized
INFO - 2016-12-02 20:26:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:26:59 --> Pagination Class Initialized
INFO - 2016-12-02 20:26:59 --> Helper loaded: app_helper
INFO - 2016-12-02 20:26:59 --> Email Class Initialized
ERROR - 2016-12-02 20:26:59 --> Severity: Notice --> Undefined property: mysqli::$startDate C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 149
INFO - 2016-12-02 20:27:01 --> Config Class Initialized
INFO - 2016-12-02 20:27:01 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:27:01 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:27:01 --> Utf8 Class Initialized
INFO - 2016-12-02 20:27:01 --> URI Class Initialized
INFO - 2016-12-02 20:27:01 --> Router Class Initialized
INFO - 2016-12-02 20:27:01 --> Output Class Initialized
INFO - 2016-12-02 20:27:01 --> Security Class Initialized
DEBUG - 2016-12-02 20:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:27:01 --> Input Class Initialized
INFO - 2016-12-02 20:27:01 --> Language Class Initialized
INFO - 2016-12-02 20:27:01 --> Loader Class Initialized
INFO - 2016-12-02 20:27:01 --> Helper loaded: url_helper
INFO - 2016-12-02 20:27:01 --> Helper loaded: form_helper
INFO - 2016-12-02 20:27:01 --> Database Driver Class Initialized
INFO - 2016-12-02 20:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:27:01 --> Controller Class Initialized
INFO - 2016-12-02 20:27:01 --> Model Class Initialized
INFO - 2016-12-02 20:27:01 --> Form Validation Class Initialized
INFO - 2016-12-02 20:27:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:27:01 --> Pagination Class Initialized
INFO - 2016-12-02 20:27:01 --> Helper loaded: app_helper
INFO - 2016-12-02 20:27:01 --> Email Class Initialized
ERROR - 2016-12-02 20:27:01 --> Severity: Notice --> Undefined property: mysqli::$startDate C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 149
INFO - 2016-12-02 20:28:41 --> Config Class Initialized
INFO - 2016-12-02 20:28:41 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:28:41 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:28:41 --> Utf8 Class Initialized
INFO - 2016-12-02 20:28:41 --> URI Class Initialized
INFO - 2016-12-02 20:28:41 --> Router Class Initialized
INFO - 2016-12-02 20:28:41 --> Output Class Initialized
INFO - 2016-12-02 20:28:41 --> Security Class Initialized
DEBUG - 2016-12-02 20:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:28:41 --> Input Class Initialized
INFO - 2016-12-02 20:28:41 --> Language Class Initialized
INFO - 2016-12-02 20:28:41 --> Loader Class Initialized
INFO - 2016-12-02 20:28:41 --> Helper loaded: url_helper
INFO - 2016-12-02 20:28:41 --> Helper loaded: form_helper
INFO - 2016-12-02 20:28:41 --> Database Driver Class Initialized
INFO - 2016-12-02 20:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:28:41 --> Controller Class Initialized
INFO - 2016-12-02 20:28:41 --> Model Class Initialized
INFO - 2016-12-02 20:28:41 --> Form Validation Class Initialized
INFO - 2016-12-02 20:28:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:28:41 --> Pagination Class Initialized
INFO - 2016-12-02 20:28:41 --> Helper loaded: app_helper
INFO - 2016-12-02 20:28:41 --> Email Class Initialized
ERROR - 2016-12-02 20:28:41 --> Severity: Error --> Cannot use object of type CI_DB_mysqli_result as array C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 148
INFO - 2016-12-02 20:33:06 --> Config Class Initialized
INFO - 2016-12-02 20:33:06 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:33:06 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:33:06 --> Utf8 Class Initialized
INFO - 2016-12-02 20:33:06 --> URI Class Initialized
INFO - 2016-12-02 20:33:06 --> Router Class Initialized
INFO - 2016-12-02 20:33:06 --> Output Class Initialized
INFO - 2016-12-02 20:33:06 --> Security Class Initialized
DEBUG - 2016-12-02 20:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:33:06 --> Input Class Initialized
INFO - 2016-12-02 20:33:06 --> Language Class Initialized
ERROR - 2016-12-02 20:33:06 --> Severity: Parsing Error --> syntax error, unexpected ''startDate'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 151
INFO - 2016-12-02 20:33:07 --> Config Class Initialized
INFO - 2016-12-02 20:33:07 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:33:07 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:33:07 --> Utf8 Class Initialized
INFO - 2016-12-02 20:33:07 --> URI Class Initialized
INFO - 2016-12-02 20:33:07 --> Router Class Initialized
INFO - 2016-12-02 20:33:07 --> Output Class Initialized
INFO - 2016-12-02 20:33:07 --> Security Class Initialized
DEBUG - 2016-12-02 20:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:33:08 --> Input Class Initialized
INFO - 2016-12-02 20:33:08 --> Language Class Initialized
ERROR - 2016-12-02 20:33:08 --> Severity: Parsing Error --> syntax error, unexpected ''startDate'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 151
INFO - 2016-12-02 20:33:35 --> Config Class Initialized
INFO - 2016-12-02 20:33:35 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:33:35 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:33:35 --> Utf8 Class Initialized
INFO - 2016-12-02 20:33:35 --> URI Class Initialized
INFO - 2016-12-02 20:33:35 --> Router Class Initialized
INFO - 2016-12-02 20:33:35 --> Output Class Initialized
INFO - 2016-12-02 20:33:35 --> Security Class Initialized
DEBUG - 2016-12-02 20:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:33:35 --> Input Class Initialized
INFO - 2016-12-02 20:33:35 --> Language Class Initialized
INFO - 2016-12-02 20:33:35 --> Loader Class Initialized
INFO - 2016-12-02 20:33:35 --> Helper loaded: url_helper
INFO - 2016-12-02 20:33:35 --> Helper loaded: form_helper
INFO - 2016-12-02 20:33:35 --> Database Driver Class Initialized
INFO - 2016-12-02 20:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:33:35 --> Controller Class Initialized
INFO - 2016-12-02 20:33:35 --> Model Class Initialized
INFO - 2016-12-02 20:33:35 --> Form Validation Class Initialized
INFO - 2016-12-02 20:33:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:33:35 --> Pagination Class Initialized
INFO - 2016-12-02 20:33:35 --> Helper loaded: app_helper
INFO - 2016-12-02 20:33:35 --> Email Class Initialized
ERROR - 2016-12-02 20:33:35 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$id C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 145
INFO - 2016-12-02 20:35:13 --> Config Class Initialized
INFO - 2016-12-02 20:35:13 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:35:13 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:35:13 --> Utf8 Class Initialized
INFO - 2016-12-02 20:35:13 --> URI Class Initialized
INFO - 2016-12-02 20:35:13 --> Router Class Initialized
INFO - 2016-12-02 20:35:13 --> Output Class Initialized
INFO - 2016-12-02 20:35:13 --> Security Class Initialized
DEBUG - 2016-12-02 20:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:35:13 --> Input Class Initialized
INFO - 2016-12-02 20:35:13 --> Language Class Initialized
INFO - 2016-12-02 20:35:13 --> Loader Class Initialized
INFO - 2016-12-02 20:35:13 --> Helper loaded: url_helper
INFO - 2016-12-02 20:35:13 --> Helper loaded: form_helper
INFO - 2016-12-02 20:35:13 --> Database Driver Class Initialized
INFO - 2016-12-02 20:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:35:13 --> Controller Class Initialized
INFO - 2016-12-02 20:35:13 --> Model Class Initialized
INFO - 2016-12-02 20:35:13 --> Form Validation Class Initialized
INFO - 2016-12-02 20:35:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:35:13 --> Pagination Class Initialized
INFO - 2016-12-02 20:35:13 --> Helper loaded: app_helper
INFO - 2016-12-02 20:35:13 --> Email Class Initialized
INFO - 2016-12-02 20:35:44 --> Config Class Initialized
INFO - 2016-12-02 20:35:44 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:35:44 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:35:44 --> Utf8 Class Initialized
INFO - 2016-12-02 20:35:44 --> URI Class Initialized
INFO - 2016-12-02 20:35:44 --> Router Class Initialized
INFO - 2016-12-02 20:35:44 --> Output Class Initialized
INFO - 2016-12-02 20:35:44 --> Security Class Initialized
DEBUG - 2016-12-02 20:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:35:44 --> Input Class Initialized
INFO - 2016-12-02 20:35:44 --> Language Class Initialized
INFO - 2016-12-02 20:35:44 --> Loader Class Initialized
INFO - 2016-12-02 20:35:44 --> Helper loaded: url_helper
INFO - 2016-12-02 20:35:44 --> Helper loaded: form_helper
INFO - 2016-12-02 20:35:44 --> Database Driver Class Initialized
INFO - 2016-12-02 20:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:35:44 --> Controller Class Initialized
INFO - 2016-12-02 20:35:44 --> Model Class Initialized
INFO - 2016-12-02 20:35:44 --> Form Validation Class Initialized
INFO - 2016-12-02 20:35:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:35:44 --> Pagination Class Initialized
INFO - 2016-12-02 20:35:44 --> Helper loaded: app_helper
INFO - 2016-12-02 20:35:44 --> Email Class Initialized
INFO - 2016-12-02 20:38:29 --> Config Class Initialized
INFO - 2016-12-02 20:38:29 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:38:29 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:38:29 --> Utf8 Class Initialized
INFO - 2016-12-02 20:38:29 --> URI Class Initialized
INFO - 2016-12-02 20:38:30 --> Router Class Initialized
INFO - 2016-12-02 20:38:30 --> Output Class Initialized
INFO - 2016-12-02 20:38:30 --> Security Class Initialized
DEBUG - 2016-12-02 20:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:38:30 --> Input Class Initialized
INFO - 2016-12-02 20:38:30 --> Language Class Initialized
INFO - 2016-12-02 20:38:30 --> Loader Class Initialized
INFO - 2016-12-02 20:38:30 --> Helper loaded: url_helper
INFO - 2016-12-02 20:38:30 --> Helper loaded: form_helper
INFO - 2016-12-02 20:38:30 --> Database Driver Class Initialized
INFO - 2016-12-02 20:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:38:30 --> Controller Class Initialized
INFO - 2016-12-02 20:38:30 --> Model Class Initialized
INFO - 2016-12-02 20:38:30 --> Form Validation Class Initialized
INFO - 2016-12-02 20:38:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:38:30 --> Pagination Class Initialized
INFO - 2016-12-02 20:38:30 --> Helper loaded: app_helper
INFO - 2016-12-02 20:38:30 --> Email Class Initialized
ERROR - 2016-12-02 20:38:30 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2016-12-02 20:38:30 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-02 20:39:56 --> Config Class Initialized
INFO - 2016-12-02 20:39:56 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:39:56 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:39:56 --> Utf8 Class Initialized
INFO - 2016-12-02 20:39:56 --> URI Class Initialized
INFO - 2016-12-02 20:39:56 --> Router Class Initialized
INFO - 2016-12-02 20:39:56 --> Output Class Initialized
INFO - 2016-12-02 20:39:56 --> Security Class Initialized
DEBUG - 2016-12-02 20:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:39:56 --> Input Class Initialized
INFO - 2016-12-02 20:39:56 --> Language Class Initialized
INFO - 2016-12-02 20:39:56 --> Loader Class Initialized
INFO - 2016-12-02 20:39:56 --> Helper loaded: url_helper
INFO - 2016-12-02 20:39:56 --> Helper loaded: form_helper
INFO - 2016-12-02 20:39:56 --> Database Driver Class Initialized
INFO - 2016-12-02 20:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:39:56 --> Controller Class Initialized
INFO - 2016-12-02 20:39:56 --> Model Class Initialized
INFO - 2016-12-02 20:39:56 --> Form Validation Class Initialized
INFO - 2016-12-02 20:39:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:39:56 --> Pagination Class Initialized
INFO - 2016-12-02 20:39:56 --> Helper loaded: app_helper
INFO - 2016-12-02 20:39:56 --> Email Class Initialized
ERROR - 2016-12-02 20:39:56 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2016-12-02 20:39:56 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-02 20:39:57 --> Config Class Initialized
INFO - 2016-12-02 20:39:57 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:39:57 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:39:57 --> Utf8 Class Initialized
INFO - 2016-12-02 20:39:58 --> URI Class Initialized
INFO - 2016-12-02 20:39:58 --> Router Class Initialized
INFO - 2016-12-02 20:39:58 --> Output Class Initialized
INFO - 2016-12-02 20:39:58 --> Security Class Initialized
DEBUG - 2016-12-02 20:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:39:58 --> Input Class Initialized
INFO - 2016-12-02 20:39:58 --> Language Class Initialized
INFO - 2016-12-02 20:39:58 --> Loader Class Initialized
INFO - 2016-12-02 20:39:58 --> Helper loaded: url_helper
INFO - 2016-12-02 20:39:58 --> Helper loaded: form_helper
INFO - 2016-12-02 20:39:58 --> Database Driver Class Initialized
INFO - 2016-12-02 20:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:39:58 --> Controller Class Initialized
INFO - 2016-12-02 20:39:58 --> Model Class Initialized
INFO - 2016-12-02 20:39:58 --> Form Validation Class Initialized
INFO - 2016-12-02 20:39:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:39:58 --> Pagination Class Initialized
INFO - 2016-12-02 20:39:58 --> Helper loaded: app_helper
INFO - 2016-12-02 20:39:58 --> Email Class Initialized
ERROR - 2016-12-02 20:39:58 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2016-12-02 20:39:58 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-02 20:41:02 --> Config Class Initialized
INFO - 2016-12-02 20:41:02 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:41:02 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:41:02 --> Utf8 Class Initialized
INFO - 2016-12-02 20:41:02 --> URI Class Initialized
INFO - 2016-12-02 20:41:02 --> Router Class Initialized
INFO - 2016-12-02 20:41:02 --> Output Class Initialized
INFO - 2016-12-02 20:41:02 --> Security Class Initialized
DEBUG - 2016-12-02 20:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:41:02 --> Input Class Initialized
INFO - 2016-12-02 20:41:02 --> Language Class Initialized
INFO - 2016-12-02 20:41:03 --> Loader Class Initialized
INFO - 2016-12-02 20:41:03 --> Helper loaded: url_helper
INFO - 2016-12-02 20:41:03 --> Helper loaded: form_helper
INFO - 2016-12-02 20:41:03 --> Database Driver Class Initialized
INFO - 2016-12-02 20:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:41:03 --> Controller Class Initialized
INFO - 2016-12-02 20:41:03 --> Model Class Initialized
INFO - 2016-12-02 20:41:03 --> Form Validation Class Initialized
INFO - 2016-12-02 20:41:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:41:03 --> Pagination Class Initialized
INFO - 2016-12-02 20:41:03 --> Helper loaded: app_helper
INFO - 2016-12-02 20:41:03 --> Email Class Initialized
ERROR - 2016-12-02 20:41:03 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2016-12-02 20:41:03 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-02 20:41:05 --> Config Class Initialized
INFO - 2016-12-02 20:41:05 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:41:05 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:41:05 --> Utf8 Class Initialized
INFO - 2016-12-02 20:41:05 --> URI Class Initialized
INFO - 2016-12-02 20:41:05 --> Router Class Initialized
INFO - 2016-12-02 20:41:05 --> Output Class Initialized
INFO - 2016-12-02 20:41:05 --> Security Class Initialized
DEBUG - 2016-12-02 20:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:41:05 --> Input Class Initialized
INFO - 2016-12-02 20:41:05 --> Language Class Initialized
INFO - 2016-12-02 20:41:05 --> Loader Class Initialized
INFO - 2016-12-02 20:41:05 --> Helper loaded: url_helper
INFO - 2016-12-02 20:41:05 --> Helper loaded: form_helper
INFO - 2016-12-02 20:41:05 --> Database Driver Class Initialized
INFO - 2016-12-02 20:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:41:05 --> Controller Class Initialized
INFO - 2016-12-02 20:41:05 --> Model Class Initialized
INFO - 2016-12-02 20:41:05 --> Form Validation Class Initialized
INFO - 2016-12-02 20:41:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:41:05 --> Pagination Class Initialized
INFO - 2016-12-02 20:41:05 --> Helper loaded: app_helper
INFO - 2016-12-02 20:41:05 --> Email Class Initialized
ERROR - 2016-12-02 20:41:05 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2016-12-02 20:41:05 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-02 20:41:26 --> Config Class Initialized
INFO - 2016-12-02 20:41:26 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:41:26 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:41:26 --> Utf8 Class Initialized
INFO - 2016-12-02 20:41:26 --> URI Class Initialized
INFO - 2016-12-02 20:41:26 --> Router Class Initialized
INFO - 2016-12-02 20:41:26 --> Output Class Initialized
INFO - 2016-12-02 20:41:26 --> Security Class Initialized
DEBUG - 2016-12-02 20:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:41:26 --> Input Class Initialized
INFO - 2016-12-02 20:41:26 --> Language Class Initialized
INFO - 2016-12-02 20:41:26 --> Loader Class Initialized
INFO - 2016-12-02 20:41:26 --> Helper loaded: url_helper
INFO - 2016-12-02 20:41:26 --> Helper loaded: form_helper
INFO - 2016-12-02 20:41:26 --> Database Driver Class Initialized
INFO - 2016-12-02 20:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:41:26 --> Controller Class Initialized
INFO - 2016-12-02 20:41:26 --> Model Class Initialized
INFO - 2016-12-02 20:41:26 --> Form Validation Class Initialized
INFO - 2016-12-02 20:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:41:26 --> Pagination Class Initialized
INFO - 2016-12-02 20:41:26 --> Helper loaded: app_helper
INFO - 2016-12-02 20:41:26 --> Email Class Initialized
ERROR - 2016-12-02 20:41:26 --> Severity: Error --> Call to undefined method stdClass::num_rows() C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 146
INFO - 2016-12-02 20:42:53 --> Config Class Initialized
INFO - 2016-12-02 20:42:53 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:42:53 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:42:53 --> Utf8 Class Initialized
INFO - 2016-12-02 20:42:53 --> URI Class Initialized
INFO - 2016-12-02 20:42:53 --> Router Class Initialized
INFO - 2016-12-02 20:42:53 --> Output Class Initialized
INFO - 2016-12-02 20:42:53 --> Security Class Initialized
DEBUG - 2016-12-02 20:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:42:53 --> Input Class Initialized
INFO - 2016-12-02 20:42:53 --> Language Class Initialized
INFO - 2016-12-02 20:42:53 --> Loader Class Initialized
INFO - 2016-12-02 20:42:53 --> Helper loaded: url_helper
INFO - 2016-12-02 20:42:53 --> Helper loaded: form_helper
INFO - 2016-12-02 20:42:53 --> Database Driver Class Initialized
INFO - 2016-12-02 20:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:42:53 --> Controller Class Initialized
INFO - 2016-12-02 20:42:53 --> Model Class Initialized
INFO - 2016-12-02 20:42:53 --> Form Validation Class Initialized
INFO - 2016-12-02 20:42:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:42:53 --> Pagination Class Initialized
INFO - 2016-12-02 20:42:53 --> Helper loaded: app_helper
INFO - 2016-12-02 20:42:53 --> Email Class Initialized
INFO - 2016-12-02 20:42:53 --> Final output sent to browser
DEBUG - 2016-12-02 20:42:53 --> Total execution time: 0.3189
INFO - 2016-12-02 20:43:38 --> Config Class Initialized
INFO - 2016-12-02 20:43:38 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:43:38 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:43:38 --> Utf8 Class Initialized
INFO - 2016-12-02 20:43:39 --> URI Class Initialized
INFO - 2016-12-02 20:43:39 --> Router Class Initialized
INFO - 2016-12-02 20:43:39 --> Output Class Initialized
INFO - 2016-12-02 20:43:39 --> Security Class Initialized
DEBUG - 2016-12-02 20:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:43:39 --> Input Class Initialized
INFO - 2016-12-02 20:43:39 --> Language Class Initialized
INFO - 2016-12-02 20:43:39 --> Loader Class Initialized
INFO - 2016-12-02 20:43:39 --> Helper loaded: url_helper
INFO - 2016-12-02 20:43:39 --> Helper loaded: form_helper
INFO - 2016-12-02 20:43:39 --> Database Driver Class Initialized
INFO - 2016-12-02 20:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:43:39 --> Controller Class Initialized
INFO - 2016-12-02 20:43:39 --> Model Class Initialized
INFO - 2016-12-02 20:43:39 --> Form Validation Class Initialized
INFO - 2016-12-02 20:43:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:43:39 --> Pagination Class Initialized
INFO - 2016-12-02 20:43:39 --> Helper loaded: app_helper
INFO - 2016-12-02 20:43:39 --> Email Class Initialized
INFO - 2016-12-02 20:43:39 --> Final output sent to browser
DEBUG - 2016-12-02 20:43:39 --> Total execution time: 0.6774
INFO - 2016-12-02 20:44:55 --> Config Class Initialized
INFO - 2016-12-02 20:44:55 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:44:55 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:44:55 --> Utf8 Class Initialized
INFO - 2016-12-02 20:44:55 --> URI Class Initialized
INFO - 2016-12-02 20:44:55 --> Router Class Initialized
INFO - 2016-12-02 20:44:55 --> Output Class Initialized
INFO - 2016-12-02 20:44:55 --> Security Class Initialized
DEBUG - 2016-12-02 20:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:44:56 --> Input Class Initialized
INFO - 2016-12-02 20:44:56 --> Language Class Initialized
INFO - 2016-12-02 20:44:56 --> Loader Class Initialized
INFO - 2016-12-02 20:44:56 --> Helper loaded: url_helper
INFO - 2016-12-02 20:44:56 --> Helper loaded: form_helper
INFO - 2016-12-02 20:44:56 --> Database Driver Class Initialized
INFO - 2016-12-02 20:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:44:56 --> Controller Class Initialized
INFO - 2016-12-02 20:44:56 --> Model Class Initialized
INFO - 2016-12-02 20:44:56 --> Form Validation Class Initialized
INFO - 2016-12-02 20:44:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:44:56 --> Pagination Class Initialized
INFO - 2016-12-02 20:44:56 --> Helper loaded: app_helper
INFO - 2016-12-02 20:44:56 --> Email Class Initialized
INFO - 2016-12-02 20:44:56 --> Final output sent to browser
DEBUG - 2016-12-02 20:44:56 --> Total execution time: 0.3211
INFO - 2016-12-02 20:44:57 --> Config Class Initialized
INFO - 2016-12-02 20:44:57 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:44:57 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:44:57 --> Utf8 Class Initialized
INFO - 2016-12-02 20:44:57 --> URI Class Initialized
INFO - 2016-12-02 20:44:57 --> Router Class Initialized
INFO - 2016-12-02 20:44:57 --> Output Class Initialized
INFO - 2016-12-02 20:44:57 --> Security Class Initialized
DEBUG - 2016-12-02 20:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:44:57 --> Input Class Initialized
INFO - 2016-12-02 20:44:57 --> Language Class Initialized
INFO - 2016-12-02 20:44:57 --> Loader Class Initialized
INFO - 2016-12-02 20:44:57 --> Helper loaded: url_helper
INFO - 2016-12-02 20:44:57 --> Helper loaded: form_helper
INFO - 2016-12-02 20:44:57 --> Database Driver Class Initialized
INFO - 2016-12-02 20:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:44:57 --> Controller Class Initialized
INFO - 2016-12-02 20:44:57 --> Model Class Initialized
INFO - 2016-12-02 20:44:57 --> Form Validation Class Initialized
INFO - 2016-12-02 20:44:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:44:57 --> Pagination Class Initialized
INFO - 2016-12-02 20:44:57 --> Helper loaded: app_helper
INFO - 2016-12-02 20:44:57 --> Email Class Initialized
INFO - 2016-12-02 20:44:57 --> Final output sent to browser
DEBUG - 2016-12-02 20:44:57 --> Total execution time: 0.3531
INFO - 2016-12-02 20:45:00 --> Config Class Initialized
INFO - 2016-12-02 20:45:00 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:45:00 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:45:00 --> Utf8 Class Initialized
INFO - 2016-12-02 20:45:00 --> URI Class Initialized
INFO - 2016-12-02 20:45:00 --> Router Class Initialized
INFO - 2016-12-02 20:45:00 --> Output Class Initialized
INFO - 2016-12-02 20:45:00 --> Security Class Initialized
DEBUG - 2016-12-02 20:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:45:00 --> Input Class Initialized
INFO - 2016-12-02 20:45:00 --> Language Class Initialized
INFO - 2016-12-02 20:45:00 --> Loader Class Initialized
INFO - 2016-12-02 20:45:00 --> Helper loaded: url_helper
INFO - 2016-12-02 20:45:00 --> Helper loaded: form_helper
INFO - 2016-12-02 20:45:00 --> Database Driver Class Initialized
INFO - 2016-12-02 20:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:45:00 --> Controller Class Initialized
INFO - 2016-12-02 20:45:00 --> Model Class Initialized
INFO - 2016-12-02 20:45:00 --> Form Validation Class Initialized
INFO - 2016-12-02 20:45:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:45:00 --> Pagination Class Initialized
INFO - 2016-12-02 20:45:00 --> Helper loaded: app_helper
INFO - 2016-12-02 20:45:00 --> Email Class Initialized
INFO - 2016-12-02 20:45:00 --> Final output sent to browser
DEBUG - 2016-12-02 20:45:00 --> Total execution time: 0.2964
INFO - 2016-12-02 20:46:16 --> Config Class Initialized
INFO - 2016-12-02 20:46:16 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:46:16 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:46:16 --> Utf8 Class Initialized
INFO - 2016-12-02 20:46:16 --> URI Class Initialized
INFO - 2016-12-02 20:46:16 --> Router Class Initialized
INFO - 2016-12-02 20:46:16 --> Output Class Initialized
INFO - 2016-12-02 20:46:16 --> Security Class Initialized
DEBUG - 2016-12-02 20:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:46:16 --> Input Class Initialized
INFO - 2016-12-02 20:46:16 --> Language Class Initialized
INFO - 2016-12-02 20:46:16 --> Loader Class Initialized
INFO - 2016-12-02 20:46:16 --> Helper loaded: url_helper
INFO - 2016-12-02 20:46:16 --> Helper loaded: form_helper
INFO - 2016-12-02 20:46:16 --> Database Driver Class Initialized
INFO - 2016-12-02 20:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:46:16 --> Controller Class Initialized
INFO - 2016-12-02 20:46:16 --> Model Class Initialized
INFO - 2016-12-02 20:46:16 --> Form Validation Class Initialized
INFO - 2016-12-02 20:46:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:46:16 --> Pagination Class Initialized
INFO - 2016-12-02 20:46:16 --> Helper loaded: app_helper
INFO - 2016-12-02 20:46:16 --> Email Class Initialized
INFO - 2016-12-02 20:46:16 --> Final output sent to browser
DEBUG - 2016-12-02 20:46:16 --> Total execution time: 0.3318
INFO - 2016-12-02 20:47:38 --> Config Class Initialized
INFO - 2016-12-02 20:47:38 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:47:38 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:47:38 --> Utf8 Class Initialized
INFO - 2016-12-02 20:47:38 --> URI Class Initialized
INFO - 2016-12-02 20:47:38 --> Router Class Initialized
INFO - 2016-12-02 20:47:38 --> Output Class Initialized
INFO - 2016-12-02 20:47:38 --> Security Class Initialized
DEBUG - 2016-12-02 20:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:47:38 --> Input Class Initialized
INFO - 2016-12-02 20:47:38 --> Language Class Initialized
INFO - 2016-12-02 20:47:38 --> Loader Class Initialized
INFO - 2016-12-02 20:47:38 --> Helper loaded: url_helper
INFO - 2016-12-02 20:47:38 --> Helper loaded: form_helper
INFO - 2016-12-02 20:47:38 --> Database Driver Class Initialized
INFO - 2016-12-02 20:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:47:38 --> Controller Class Initialized
INFO - 2016-12-02 20:47:38 --> Model Class Initialized
INFO - 2016-12-02 20:47:38 --> Form Validation Class Initialized
INFO - 2016-12-02 20:47:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:47:38 --> Pagination Class Initialized
INFO - 2016-12-02 20:47:38 --> Helper loaded: app_helper
INFO - 2016-12-02 20:47:38 --> Email Class Initialized
ERROR - 2016-12-02 20:47:38 --> Severity: Error --> Call to a member function result() on array C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 17
INFO - 2016-12-02 20:48:38 --> Config Class Initialized
INFO - 2016-12-02 20:48:38 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:48:38 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:48:38 --> Utf8 Class Initialized
INFO - 2016-12-02 20:48:38 --> URI Class Initialized
INFO - 2016-12-02 20:48:38 --> Router Class Initialized
INFO - 2016-12-02 20:48:38 --> Output Class Initialized
INFO - 2016-12-02 20:48:39 --> Security Class Initialized
DEBUG - 2016-12-02 20:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:48:39 --> Input Class Initialized
INFO - 2016-12-02 20:48:39 --> Language Class Initialized
INFO - 2016-12-02 20:48:39 --> Loader Class Initialized
INFO - 2016-12-02 20:48:39 --> Helper loaded: url_helper
INFO - 2016-12-02 20:48:39 --> Helper loaded: form_helper
INFO - 2016-12-02 20:48:39 --> Database Driver Class Initialized
INFO - 2016-12-02 20:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:48:39 --> Controller Class Initialized
INFO - 2016-12-02 20:48:39 --> Model Class Initialized
INFO - 2016-12-02 20:48:39 --> Form Validation Class Initialized
INFO - 2016-12-02 20:48:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:48:39 --> Pagination Class Initialized
INFO - 2016-12-02 20:48:39 --> Helper loaded: app_helper
INFO - 2016-12-02 20:48:39 --> Email Class Initialized
ERROR - 2016-12-02 20:48:39 --> Severity: Error --> Call to a member function result() on array C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 17
INFO - 2016-12-02 20:49:37 --> Config Class Initialized
INFO - 2016-12-02 20:49:37 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:49:37 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:49:37 --> Utf8 Class Initialized
INFO - 2016-12-02 20:49:38 --> URI Class Initialized
DEBUG - 2016-12-02 20:49:38 --> No URI present. Default controller set.
INFO - 2016-12-02 20:49:38 --> Router Class Initialized
INFO - 2016-12-02 20:49:38 --> Output Class Initialized
INFO - 2016-12-02 20:49:38 --> Security Class Initialized
DEBUG - 2016-12-02 20:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:49:38 --> Input Class Initialized
INFO - 2016-12-02 20:49:38 --> Language Class Initialized
INFO - 2016-12-02 20:49:38 --> Loader Class Initialized
INFO - 2016-12-02 20:49:38 --> Helper loaded: url_helper
INFO - 2016-12-02 20:49:38 --> Helper loaded: form_helper
INFO - 2016-12-02 20:49:38 --> Database Driver Class Initialized
INFO - 2016-12-02 20:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:49:38 --> Controller Class Initialized
INFO - 2016-12-02 20:49:38 --> Model Class Initialized
INFO - 2016-12-02 20:49:38 --> Model Class Initialized
INFO - 2016-12-02 20:49:38 --> Model Class Initialized
INFO - 2016-12-02 20:49:38 --> Model Class Initialized
INFO - 2016-12-02 20:49:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:49:38 --> Pagination Class Initialized
INFO - 2016-12-02 20:49:38 --> Helper loaded: app_helper
INFO - 2016-12-02 20:49:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 20:49:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 20:49:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 20:49:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 20:49:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 20:49:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 20:49:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 20:49:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 20:49:38 --> Final output sent to browser
DEBUG - 2016-12-02 20:49:38 --> Total execution time: 1.0543
INFO - 2016-12-02 20:52:41 --> Config Class Initialized
INFO - 2016-12-02 20:52:41 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:52:41 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:52:41 --> Utf8 Class Initialized
INFO - 2016-12-02 20:52:41 --> URI Class Initialized
INFO - 2016-12-02 20:52:41 --> Router Class Initialized
INFO - 2016-12-02 20:52:41 --> Output Class Initialized
INFO - 2016-12-02 20:52:41 --> Security Class Initialized
DEBUG - 2016-12-02 20:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:52:41 --> Input Class Initialized
INFO - 2016-12-02 20:52:41 --> Language Class Initialized
INFO - 2016-12-02 20:52:41 --> Loader Class Initialized
INFO - 2016-12-02 20:52:41 --> Helper loaded: url_helper
INFO - 2016-12-02 20:52:41 --> Helper loaded: form_helper
INFO - 2016-12-02 20:52:41 --> Database Driver Class Initialized
INFO - 2016-12-02 20:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:52:41 --> Controller Class Initialized
INFO - 2016-12-02 20:52:41 --> Model Class Initialized
INFO - 2016-12-02 20:52:41 --> Form Validation Class Initialized
INFO - 2016-12-02 20:52:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:52:41 --> Pagination Class Initialized
INFO - 2016-12-02 20:52:41 --> Helper loaded: app_helper
INFO - 2016-12-02 20:52:41 --> Email Class Initialized
ERROR - 2016-12-02 20:52:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 20:52:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 21
ERROR - 2016-12-02 20:52:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 22
ERROR - 2016-12-02 20:52:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 23
ERROR - 2016-12-02 20:52:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 20:52:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 25
ERROR - 2016-12-02 20:52:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
ERROR - 2016-12-02 20:52:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 29
ERROR - 2016-12-02 20:52:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 29
ERROR - 2016-12-02 20:52:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 36
ERROR - 2016-12-02 20:52:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 20:52:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 21
ERROR - 2016-12-02 20:52:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 22
ERROR - 2016-12-02 20:52:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 23
ERROR - 2016-12-02 20:52:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 20:52:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 25
ERROR - 2016-12-02 20:52:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
ERROR - 2016-12-02 20:52:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 29
ERROR - 2016-12-02 20:52:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 29
ERROR - 2016-12-02 20:52:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 36
ERROR - 2016-12-02 20:52:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 20:52:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 21
ERROR - 2016-12-02 20:52:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 22
ERROR - 2016-12-02 20:52:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 23
ERROR - 2016-12-02 20:52:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 20:52:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 25
ERROR - 2016-12-02 20:52:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
ERROR - 2016-12-02 20:52:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 29
ERROR - 2016-12-02 20:52:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 29
ERROR - 2016-12-02 20:52:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 36
ERROR - 2016-12-02 20:52:42 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 43
INFO - 2016-12-02 20:52:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 20:52:42 --> Final output sent to browser
DEBUG - 2016-12-02 20:52:42 --> Total execution time: 0.6688
INFO - 2016-12-02 20:54:00 --> Config Class Initialized
INFO - 2016-12-02 20:54:00 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:54:00 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:54:00 --> Utf8 Class Initialized
INFO - 2016-12-02 20:54:00 --> URI Class Initialized
INFO - 2016-12-02 20:54:00 --> Router Class Initialized
INFO - 2016-12-02 20:54:00 --> Output Class Initialized
INFO - 2016-12-02 20:54:00 --> Security Class Initialized
DEBUG - 2016-12-02 20:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:54:00 --> Input Class Initialized
INFO - 2016-12-02 20:54:00 --> Language Class Initialized
INFO - 2016-12-02 20:54:00 --> Loader Class Initialized
INFO - 2016-12-02 20:54:00 --> Helper loaded: url_helper
INFO - 2016-12-02 20:54:00 --> Helper loaded: form_helper
INFO - 2016-12-02 20:54:00 --> Database Driver Class Initialized
INFO - 2016-12-02 20:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:54:01 --> Controller Class Initialized
INFO - 2016-12-02 20:54:01 --> Model Class Initialized
INFO - 2016-12-02 20:54:01 --> Form Validation Class Initialized
INFO - 2016-12-02 20:54:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:54:01 --> Pagination Class Initialized
INFO - 2016-12-02 20:54:01 --> Helper loaded: app_helper
INFO - 2016-12-02 20:54:01 --> Email Class Initialized
ERROR - 2016-12-02 20:54:01 --> Severity: Error --> Call to a member function result() on array C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 17
INFO - 2016-12-02 20:54:18 --> Config Class Initialized
INFO - 2016-12-02 20:54:18 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:54:18 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:54:18 --> Utf8 Class Initialized
INFO - 2016-12-02 20:54:18 --> URI Class Initialized
INFO - 2016-12-02 20:54:18 --> Router Class Initialized
INFO - 2016-12-02 20:54:18 --> Output Class Initialized
INFO - 2016-12-02 20:54:18 --> Security Class Initialized
DEBUG - 2016-12-02 20:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:54:18 --> Input Class Initialized
INFO - 2016-12-02 20:54:18 --> Language Class Initialized
INFO - 2016-12-02 20:54:18 --> Loader Class Initialized
INFO - 2016-12-02 20:54:19 --> Helper loaded: url_helper
INFO - 2016-12-02 20:54:19 --> Helper loaded: form_helper
INFO - 2016-12-02 20:54:19 --> Database Driver Class Initialized
INFO - 2016-12-02 20:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:54:19 --> Controller Class Initialized
INFO - 2016-12-02 20:54:19 --> Model Class Initialized
INFO - 2016-12-02 20:54:19 --> Form Validation Class Initialized
INFO - 2016-12-02 20:54:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:54:19 --> Pagination Class Initialized
INFO - 2016-12-02 20:54:19 --> Helper loaded: app_helper
INFO - 2016-12-02 20:54:19 --> Email Class Initialized
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 21
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 22
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 23
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 25
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 29
ERROR - 2016-12-02 20:54:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 29
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 36
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 21
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 22
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 23
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 25
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 29
ERROR - 2016-12-02 20:54:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 29
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 36
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 21
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 22
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 23
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 25
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 29
ERROR - 2016-12-02 20:54:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 29
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 36
ERROR - 2016-12-02 20:54:19 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 43
INFO - 2016-12-02 20:54:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 20:54:19 --> Final output sent to browser
DEBUG - 2016-12-02 20:54:19 --> Total execution time: 0.6801
INFO - 2016-12-02 20:55:07 --> Config Class Initialized
INFO - 2016-12-02 20:55:07 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:55:07 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:55:07 --> Utf8 Class Initialized
INFO - 2016-12-02 20:55:07 --> URI Class Initialized
INFO - 2016-12-02 20:55:07 --> Router Class Initialized
INFO - 2016-12-02 20:55:07 --> Output Class Initialized
INFO - 2016-12-02 20:55:07 --> Security Class Initialized
DEBUG - 2016-12-02 20:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:55:07 --> Input Class Initialized
INFO - 2016-12-02 20:55:07 --> Language Class Initialized
INFO - 2016-12-02 20:55:07 --> Loader Class Initialized
INFO - 2016-12-02 20:55:07 --> Helper loaded: url_helper
INFO - 2016-12-02 20:55:07 --> Helper loaded: form_helper
INFO - 2016-12-02 20:55:07 --> Database Driver Class Initialized
INFO - 2016-12-02 20:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:55:07 --> Controller Class Initialized
INFO - 2016-12-02 20:55:07 --> Model Class Initialized
INFO - 2016-12-02 20:55:07 --> Form Validation Class Initialized
INFO - 2016-12-02 20:55:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:55:07 --> Pagination Class Initialized
INFO - 2016-12-02 20:55:07 --> Helper loaded: app_helper
INFO - 2016-12-02 20:55:07 --> Email Class Initialized
ERROR - 2016-12-02 20:55:07 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2016-12-02 20:55:07 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-02 20:56:03 --> Config Class Initialized
INFO - 2016-12-02 20:56:03 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:56:03 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:56:03 --> Utf8 Class Initialized
INFO - 2016-12-02 20:56:03 --> URI Class Initialized
INFO - 2016-12-02 20:56:03 --> Router Class Initialized
INFO - 2016-12-02 20:56:03 --> Output Class Initialized
INFO - 2016-12-02 20:56:03 --> Security Class Initialized
DEBUG - 2016-12-02 20:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:56:03 --> Input Class Initialized
INFO - 2016-12-02 20:56:03 --> Language Class Initialized
INFO - 2016-12-02 20:56:03 --> Loader Class Initialized
INFO - 2016-12-02 20:56:03 --> Helper loaded: url_helper
INFO - 2016-12-02 20:56:03 --> Helper loaded: form_helper
INFO - 2016-12-02 20:56:03 --> Database Driver Class Initialized
INFO - 2016-12-02 20:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:56:03 --> Controller Class Initialized
INFO - 2016-12-02 20:56:03 --> Model Class Initialized
INFO - 2016-12-02 20:56:03 --> Form Validation Class Initialized
INFO - 2016-12-02 20:56:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:56:03 --> Pagination Class Initialized
INFO - 2016-12-02 20:56:03 --> Helper loaded: app_helper
INFO - 2016-12-02 20:56:03 --> Email Class Initialized
ERROR - 2016-12-02 20:56:03 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2016-12-02 20:56:03 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-02 20:57:37 --> Config Class Initialized
INFO - 2016-12-02 20:57:37 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:57:37 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:57:37 --> Utf8 Class Initialized
INFO - 2016-12-02 20:57:37 --> URI Class Initialized
INFO - 2016-12-02 20:57:37 --> Router Class Initialized
INFO - 2016-12-02 20:57:37 --> Output Class Initialized
INFO - 2016-12-02 20:57:37 --> Security Class Initialized
DEBUG - 2016-12-02 20:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:57:37 --> Input Class Initialized
INFO - 2016-12-02 20:57:37 --> Language Class Initialized
INFO - 2016-12-02 20:57:37 --> Loader Class Initialized
INFO - 2016-12-02 20:57:37 --> Helper loaded: url_helper
INFO - 2016-12-02 20:57:37 --> Helper loaded: form_helper
INFO - 2016-12-02 20:57:37 --> Database Driver Class Initialized
INFO - 2016-12-02 20:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:57:37 --> Controller Class Initialized
INFO - 2016-12-02 20:57:37 --> Model Class Initialized
INFO - 2016-12-02 20:57:37 --> Form Validation Class Initialized
INFO - 2016-12-02 20:57:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 20:57:37 --> Pagination Class Initialized
INFO - 2016-12-02 20:57:37 --> Helper loaded: app_helper
INFO - 2016-12-02 20:57:37 --> Email Class Initialized
ERROR - 2016-12-02 20:57:37 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2016-12-02 20:57:38 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-02 21:00:13 --> Config Class Initialized
INFO - 2016-12-02 21:00:13 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:00:13 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:00:13 --> Utf8 Class Initialized
INFO - 2016-12-02 21:00:13 --> URI Class Initialized
INFO - 2016-12-02 21:00:13 --> Router Class Initialized
INFO - 2016-12-02 21:00:13 --> Output Class Initialized
INFO - 2016-12-02 21:00:13 --> Security Class Initialized
DEBUG - 2016-12-02 21:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:00:13 --> Input Class Initialized
INFO - 2016-12-02 21:00:13 --> Language Class Initialized
INFO - 2016-12-02 21:00:13 --> Loader Class Initialized
INFO - 2016-12-02 21:00:13 --> Helper loaded: url_helper
INFO - 2016-12-02 21:00:13 --> Helper loaded: form_helper
INFO - 2016-12-02 21:00:13 --> Database Driver Class Initialized
INFO - 2016-12-02 21:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:00:13 --> Controller Class Initialized
INFO - 2016-12-02 21:00:13 --> Model Class Initialized
INFO - 2016-12-02 21:00:13 --> Form Validation Class Initialized
INFO - 2016-12-02 21:00:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:00:13 --> Pagination Class Initialized
INFO - 2016-12-02 21:00:13 --> Helper loaded: app_helper
INFO - 2016-12-02 21:00:13 --> Email Class Initialized
ERROR - 2016-12-02 21:00:13 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2016-12-02 21:00:13 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-02 21:01:53 --> Config Class Initialized
INFO - 2016-12-02 21:01:53 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:01:53 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:01:53 --> Utf8 Class Initialized
INFO - 2016-12-02 21:01:53 --> URI Class Initialized
INFO - 2016-12-02 21:01:53 --> Router Class Initialized
INFO - 2016-12-02 21:01:53 --> Output Class Initialized
INFO - 2016-12-02 21:01:53 --> Security Class Initialized
DEBUG - 2016-12-02 21:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:01:53 --> Input Class Initialized
INFO - 2016-12-02 21:01:53 --> Language Class Initialized
INFO - 2016-12-02 21:01:53 --> Loader Class Initialized
INFO - 2016-12-02 21:01:53 --> Helper loaded: url_helper
INFO - 2016-12-02 21:01:53 --> Helper loaded: form_helper
INFO - 2016-12-02 21:01:53 --> Database Driver Class Initialized
INFO - 2016-12-02 21:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:01:53 --> Controller Class Initialized
INFO - 2016-12-02 21:01:53 --> Model Class Initialized
INFO - 2016-12-02 21:01:53 --> Form Validation Class Initialized
INFO - 2016-12-02 21:01:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:01:53 --> Pagination Class Initialized
INFO - 2016-12-02 21:01:53 --> Helper loaded: app_helper
INFO - 2016-12-02 21:01:53 --> Email Class Initialized
ERROR - 2016-12-02 21:01:53 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2016-12-02 21:01:53 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-02 21:01:56 --> Config Class Initialized
INFO - 2016-12-02 21:01:56 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:01:56 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:01:56 --> Utf8 Class Initialized
INFO - 2016-12-02 21:01:56 --> URI Class Initialized
INFO - 2016-12-02 21:01:56 --> Router Class Initialized
INFO - 2016-12-02 21:01:56 --> Output Class Initialized
INFO - 2016-12-02 21:01:56 --> Security Class Initialized
DEBUG - 2016-12-02 21:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:01:56 --> Input Class Initialized
INFO - 2016-12-02 21:01:56 --> Language Class Initialized
INFO - 2016-12-02 21:01:56 --> Loader Class Initialized
INFO - 2016-12-02 21:01:56 --> Helper loaded: url_helper
INFO - 2016-12-02 21:01:56 --> Helper loaded: form_helper
INFO - 2016-12-02 21:01:56 --> Database Driver Class Initialized
INFO - 2016-12-02 21:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:01:56 --> Controller Class Initialized
INFO - 2016-12-02 21:01:56 --> Model Class Initialized
INFO - 2016-12-02 21:01:56 --> Form Validation Class Initialized
INFO - 2016-12-02 21:01:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:01:56 --> Pagination Class Initialized
INFO - 2016-12-02 21:01:56 --> Helper loaded: app_helper
INFO - 2016-12-02 21:01:56 --> Email Class Initialized
ERROR - 2016-12-02 21:01:56 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2016-12-02 21:01:56 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-02 21:02:24 --> Config Class Initialized
INFO - 2016-12-02 21:02:24 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:02:24 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:02:24 --> Utf8 Class Initialized
INFO - 2016-12-02 21:02:24 --> URI Class Initialized
INFO - 2016-12-02 21:02:24 --> Router Class Initialized
INFO - 2016-12-02 21:02:24 --> Output Class Initialized
INFO - 2016-12-02 21:02:24 --> Security Class Initialized
DEBUG - 2016-12-02 21:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:02:24 --> Input Class Initialized
INFO - 2016-12-02 21:02:24 --> Language Class Initialized
INFO - 2016-12-02 21:02:24 --> Loader Class Initialized
INFO - 2016-12-02 21:02:24 --> Helper loaded: url_helper
INFO - 2016-12-02 21:02:24 --> Helper loaded: form_helper
INFO - 2016-12-02 21:02:24 --> Database Driver Class Initialized
INFO - 2016-12-02 21:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:02:24 --> Controller Class Initialized
INFO - 2016-12-02 21:02:24 --> Model Class Initialized
INFO - 2016-12-02 21:02:24 --> Form Validation Class Initialized
INFO - 2016-12-02 21:02:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:02:24 --> Pagination Class Initialized
INFO - 2016-12-02 21:02:24 --> Helper loaded: app_helper
INFO - 2016-12-02 21:02:24 --> Email Class Initialized
ERROR - 2016-12-02 21:02:24 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2016-12-02 21:02:24 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-02 21:02:25 --> Config Class Initialized
INFO - 2016-12-02 21:02:25 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:02:25 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:02:25 --> Utf8 Class Initialized
INFO - 2016-12-02 21:02:25 --> URI Class Initialized
INFO - 2016-12-02 21:02:25 --> Router Class Initialized
INFO - 2016-12-02 21:02:25 --> Output Class Initialized
INFO - 2016-12-02 21:02:25 --> Security Class Initialized
DEBUG - 2016-12-02 21:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:02:25 --> Input Class Initialized
INFO - 2016-12-02 21:02:25 --> Language Class Initialized
INFO - 2016-12-02 21:02:25 --> Loader Class Initialized
INFO - 2016-12-02 21:02:25 --> Helper loaded: url_helper
INFO - 2016-12-02 21:02:25 --> Helper loaded: form_helper
INFO - 2016-12-02 21:02:25 --> Database Driver Class Initialized
INFO - 2016-12-02 21:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:02:25 --> Controller Class Initialized
INFO - 2016-12-02 21:02:26 --> Model Class Initialized
INFO - 2016-12-02 21:02:26 --> Form Validation Class Initialized
INFO - 2016-12-02 21:02:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:02:26 --> Pagination Class Initialized
INFO - 2016-12-02 21:02:26 --> Helper loaded: app_helper
INFO - 2016-12-02 21:02:26 --> Email Class Initialized
ERROR - 2016-12-02 21:02:26 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2016-12-02 21:02:26 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-02 21:04:09 --> Config Class Initialized
INFO - 2016-12-02 21:04:09 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:04:09 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:04:09 --> Utf8 Class Initialized
INFO - 2016-12-02 21:04:09 --> URI Class Initialized
INFO - 2016-12-02 21:04:09 --> Router Class Initialized
INFO - 2016-12-02 21:04:09 --> Output Class Initialized
INFO - 2016-12-02 21:04:09 --> Security Class Initialized
DEBUG - 2016-12-02 21:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:04:09 --> Input Class Initialized
INFO - 2016-12-02 21:04:10 --> Language Class Initialized
INFO - 2016-12-02 21:04:10 --> Loader Class Initialized
INFO - 2016-12-02 21:04:10 --> Helper loaded: url_helper
INFO - 2016-12-02 21:04:10 --> Helper loaded: form_helper
INFO - 2016-12-02 21:04:10 --> Database Driver Class Initialized
INFO - 2016-12-02 21:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:04:10 --> Controller Class Initialized
INFO - 2016-12-02 21:04:10 --> Model Class Initialized
INFO - 2016-12-02 21:04:10 --> Form Validation Class Initialized
INFO - 2016-12-02 21:04:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:04:10 --> Pagination Class Initialized
INFO - 2016-12-02 21:04:10 --> Helper loaded: app_helper
INFO - 2016-12-02 21:04:10 --> Email Class Initialized
ERROR - 2016-12-02 21:04:10 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2016-12-02 21:04:10 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-02 21:04:11 --> Config Class Initialized
INFO - 2016-12-02 21:04:11 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:04:11 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:04:11 --> Utf8 Class Initialized
INFO - 2016-12-02 21:04:11 --> URI Class Initialized
INFO - 2016-12-02 21:04:11 --> Router Class Initialized
INFO - 2016-12-02 21:04:11 --> Output Class Initialized
INFO - 2016-12-02 21:04:11 --> Security Class Initialized
DEBUG - 2016-12-02 21:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:04:11 --> Input Class Initialized
INFO - 2016-12-02 21:04:11 --> Language Class Initialized
INFO - 2016-12-02 21:04:11 --> Loader Class Initialized
INFO - 2016-12-02 21:04:11 --> Helper loaded: url_helper
INFO - 2016-12-02 21:04:11 --> Helper loaded: form_helper
INFO - 2016-12-02 21:04:11 --> Database Driver Class Initialized
INFO - 2016-12-02 21:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:04:11 --> Controller Class Initialized
INFO - 2016-12-02 21:04:11 --> Model Class Initialized
INFO - 2016-12-02 21:04:11 --> Form Validation Class Initialized
INFO - 2016-12-02 21:04:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:04:11 --> Pagination Class Initialized
INFO - 2016-12-02 21:04:11 --> Helper loaded: app_helper
INFO - 2016-12-02 21:04:11 --> Email Class Initialized
ERROR - 2016-12-02 21:04:11 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2016-12-02 21:04:11 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-02 21:06:00 --> Config Class Initialized
INFO - 2016-12-02 21:06:00 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:06:00 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:06:00 --> Utf8 Class Initialized
INFO - 2016-12-02 21:06:00 --> URI Class Initialized
INFO - 2016-12-02 21:06:00 --> Router Class Initialized
INFO - 2016-12-02 21:06:00 --> Output Class Initialized
INFO - 2016-12-02 21:06:00 --> Security Class Initialized
DEBUG - 2016-12-02 21:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:06:00 --> Input Class Initialized
INFO - 2016-12-02 21:06:00 --> Language Class Initialized
INFO - 2016-12-02 21:06:00 --> Loader Class Initialized
INFO - 2016-12-02 21:06:00 --> Helper loaded: url_helper
INFO - 2016-12-02 21:06:00 --> Helper loaded: form_helper
INFO - 2016-12-02 21:06:00 --> Database Driver Class Initialized
INFO - 2016-12-02 21:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:06:00 --> Controller Class Initialized
INFO - 2016-12-02 21:06:00 --> Model Class Initialized
INFO - 2016-12-02 21:06:00 --> Form Validation Class Initialized
INFO - 2016-12-02 21:06:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:06:00 --> Pagination Class Initialized
INFO - 2016-12-02 21:06:00 --> Helper loaded: app_helper
INFO - 2016-12-02 21:06:00 --> Email Class Initialized
ERROR - 2016-12-02 21:06:00 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2016-12-02 21:06:00 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-02 21:06:38 --> Config Class Initialized
INFO - 2016-12-02 21:06:38 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:06:38 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:06:38 --> Utf8 Class Initialized
INFO - 2016-12-02 21:06:38 --> URI Class Initialized
INFO - 2016-12-02 21:06:38 --> Router Class Initialized
INFO - 2016-12-02 21:06:38 --> Output Class Initialized
INFO - 2016-12-02 21:06:38 --> Security Class Initialized
DEBUG - 2016-12-02 21:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:06:38 --> Input Class Initialized
INFO - 2016-12-02 21:06:38 --> Language Class Initialized
INFO - 2016-12-02 21:06:38 --> Loader Class Initialized
INFO - 2016-12-02 21:06:38 --> Helper loaded: url_helper
INFO - 2016-12-02 21:06:38 --> Helper loaded: form_helper
INFO - 2016-12-02 21:06:38 --> Database Driver Class Initialized
INFO - 2016-12-02 21:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:06:38 --> Controller Class Initialized
INFO - 2016-12-02 21:06:38 --> Model Class Initialized
INFO - 2016-12-02 21:06:38 --> Form Validation Class Initialized
INFO - 2016-12-02 21:06:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:06:38 --> Pagination Class Initialized
INFO - 2016-12-02 21:06:38 --> Helper loaded: app_helper
INFO - 2016-12-02 21:06:39 --> Email Class Initialized
ERROR - 2016-12-02 21:06:39 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2016-12-02 21:06:39 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-02 21:07:32 --> Config Class Initialized
INFO - 2016-12-02 21:07:32 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:07:32 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:07:32 --> Utf8 Class Initialized
INFO - 2016-12-02 21:07:32 --> URI Class Initialized
INFO - 2016-12-02 21:07:32 --> Router Class Initialized
INFO - 2016-12-02 21:07:32 --> Output Class Initialized
INFO - 2016-12-02 21:07:32 --> Security Class Initialized
DEBUG - 2016-12-02 21:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:07:32 --> Input Class Initialized
INFO - 2016-12-02 21:07:32 --> Language Class Initialized
INFO - 2016-12-02 21:07:32 --> Loader Class Initialized
INFO - 2016-12-02 21:07:32 --> Helper loaded: url_helper
INFO - 2016-12-02 21:07:32 --> Helper loaded: form_helper
INFO - 2016-12-02 21:07:32 --> Database Driver Class Initialized
INFO - 2016-12-02 21:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:07:32 --> Controller Class Initialized
INFO - 2016-12-02 21:07:32 --> Model Class Initialized
INFO - 2016-12-02 21:07:32 --> Form Validation Class Initialized
INFO - 2016-12-02 21:07:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:07:32 --> Pagination Class Initialized
INFO - 2016-12-02 21:07:32 --> Helper loaded: app_helper
INFO - 2016-12-02 21:07:32 --> Email Class Initialized
ERROR - 2016-12-02 21:07:32 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2016-12-02 21:07:32 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-02 21:07:32 --> Config Class Initialized
INFO - 2016-12-02 21:07:32 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:07:32 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:07:32 --> Utf8 Class Initialized
INFO - 2016-12-02 21:07:32 --> URI Class Initialized
INFO - 2016-12-02 21:07:32 --> Router Class Initialized
INFO - 2016-12-02 21:07:32 --> Output Class Initialized
INFO - 2016-12-02 21:07:32 --> Security Class Initialized
DEBUG - 2016-12-02 21:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:07:32 --> Input Class Initialized
INFO - 2016-12-02 21:07:32 --> Language Class Initialized
INFO - 2016-12-02 21:07:32 --> Loader Class Initialized
INFO - 2016-12-02 21:07:32 --> Helper loaded: url_helper
INFO - 2016-12-02 21:07:32 --> Helper loaded: form_helper
INFO - 2016-12-02 21:07:32 --> Database Driver Class Initialized
INFO - 2016-12-02 21:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:07:33 --> Controller Class Initialized
INFO - 2016-12-02 21:07:33 --> Model Class Initialized
INFO - 2016-12-02 21:07:33 --> Form Validation Class Initialized
INFO - 2016-12-02 21:07:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:07:33 --> Pagination Class Initialized
INFO - 2016-12-02 21:07:33 --> Helper loaded: app_helper
INFO - 2016-12-02 21:07:33 --> Email Class Initialized
ERROR - 2016-12-02 21:07:33 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2016-12-02 21:07:33 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-02 21:08:01 --> Config Class Initialized
INFO - 2016-12-02 21:08:01 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:08:01 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:08:01 --> Utf8 Class Initialized
INFO - 2016-12-02 21:08:01 --> URI Class Initialized
INFO - 2016-12-02 21:08:01 --> Router Class Initialized
INFO - 2016-12-02 21:08:01 --> Output Class Initialized
INFO - 2016-12-02 21:08:01 --> Security Class Initialized
DEBUG - 2016-12-02 21:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:08:02 --> Input Class Initialized
INFO - 2016-12-02 21:08:02 --> Language Class Initialized
INFO - 2016-12-02 21:08:02 --> Loader Class Initialized
INFO - 2016-12-02 21:08:02 --> Helper loaded: url_helper
INFO - 2016-12-02 21:08:02 --> Helper loaded: form_helper
INFO - 2016-12-02 21:08:02 --> Database Driver Class Initialized
INFO - 2016-12-02 21:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:08:02 --> Controller Class Initialized
INFO - 2016-12-02 21:08:02 --> Model Class Initialized
INFO - 2016-12-02 21:08:02 --> Form Validation Class Initialized
INFO - 2016-12-02 21:08:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:08:02 --> Pagination Class Initialized
INFO - 2016-12-02 21:08:02 --> Helper loaded: app_helper
INFO - 2016-12-02 21:08:02 --> Email Class Initialized
ERROR - 2016-12-02 21:08:02 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2016-12-02 21:08:02 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-02 21:08:18 --> Config Class Initialized
INFO - 2016-12-02 21:08:18 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:08:18 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:08:18 --> Utf8 Class Initialized
INFO - 2016-12-02 21:08:18 --> URI Class Initialized
INFO - 2016-12-02 21:08:18 --> Router Class Initialized
INFO - 2016-12-02 21:08:18 --> Output Class Initialized
INFO - 2016-12-02 21:08:18 --> Security Class Initialized
DEBUG - 2016-12-02 21:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:08:18 --> Input Class Initialized
INFO - 2016-12-02 21:08:18 --> Language Class Initialized
INFO - 2016-12-02 21:08:18 --> Loader Class Initialized
INFO - 2016-12-02 21:08:19 --> Helper loaded: url_helper
INFO - 2016-12-02 21:08:19 --> Helper loaded: form_helper
INFO - 2016-12-02 21:08:19 --> Database Driver Class Initialized
INFO - 2016-12-02 21:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:08:19 --> Controller Class Initialized
INFO - 2016-12-02 21:08:19 --> Model Class Initialized
INFO - 2016-12-02 21:08:19 --> Form Validation Class Initialized
INFO - 2016-12-02 21:08:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:08:19 --> Pagination Class Initialized
INFO - 2016-12-02 21:08:19 --> Helper loaded: app_helper
INFO - 2016-12-02 21:08:19 --> Email Class Initialized
ERROR - 2016-12-02 21:08:19 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 24
ERROR - 2016-12-02 21:08:19 --> Severity: Error --> Call to a member function row() on null C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 24
INFO - 2016-12-02 21:08:32 --> Config Class Initialized
INFO - 2016-12-02 21:08:32 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:08:32 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:08:32 --> Utf8 Class Initialized
INFO - 2016-12-02 21:08:32 --> URI Class Initialized
INFO - 2016-12-02 21:08:33 --> Router Class Initialized
INFO - 2016-12-02 21:08:33 --> Output Class Initialized
INFO - 2016-12-02 21:08:33 --> Security Class Initialized
DEBUG - 2016-12-02 21:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:08:33 --> Input Class Initialized
INFO - 2016-12-02 21:08:33 --> Language Class Initialized
INFO - 2016-12-02 21:08:33 --> Loader Class Initialized
INFO - 2016-12-02 21:08:33 --> Helper loaded: url_helper
INFO - 2016-12-02 21:08:33 --> Helper loaded: form_helper
INFO - 2016-12-02 21:08:33 --> Database Driver Class Initialized
INFO - 2016-12-02 21:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:08:33 --> Controller Class Initialized
INFO - 2016-12-02 21:08:33 --> Model Class Initialized
INFO - 2016-12-02 21:08:33 --> Form Validation Class Initialized
INFO - 2016-12-02 21:08:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:08:33 --> Pagination Class Initialized
INFO - 2016-12-02 21:08:33 --> Helper loaded: app_helper
INFO - 2016-12-02 21:08:33 --> Email Class Initialized
ERROR - 2016-12-02 21:08:33 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 24
ERROR - 2016-12-02 21:08:33 --> Severity: Error --> Call to a member function row() on null C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 24
INFO - 2016-12-02 21:08:47 --> Config Class Initialized
INFO - 2016-12-02 21:08:47 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:08:48 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:08:48 --> Utf8 Class Initialized
INFO - 2016-12-02 21:08:48 --> URI Class Initialized
INFO - 2016-12-02 21:08:48 --> Router Class Initialized
INFO - 2016-12-02 21:08:48 --> Output Class Initialized
INFO - 2016-12-02 21:08:48 --> Security Class Initialized
DEBUG - 2016-12-02 21:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:08:48 --> Input Class Initialized
INFO - 2016-12-02 21:08:48 --> Language Class Initialized
INFO - 2016-12-02 21:08:48 --> Loader Class Initialized
INFO - 2016-12-02 21:08:48 --> Helper loaded: url_helper
INFO - 2016-12-02 21:08:48 --> Helper loaded: form_helper
INFO - 2016-12-02 21:08:48 --> Database Driver Class Initialized
INFO - 2016-12-02 21:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:08:48 --> Controller Class Initialized
INFO - 2016-12-02 21:08:48 --> Model Class Initialized
INFO - 2016-12-02 21:08:48 --> Form Validation Class Initialized
INFO - 2016-12-02 21:08:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:08:48 --> Pagination Class Initialized
INFO - 2016-12-02 21:08:48 --> Helper loaded: app_helper
INFO - 2016-12-02 21:08:48 --> Email Class Initialized
ERROR - 2016-12-02 21:08:48 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 24
ERROR - 2016-12-02 21:08:48 --> Severity: Error --> Call to a member function row() on null C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 24
INFO - 2016-12-02 21:09:39 --> Config Class Initialized
INFO - 2016-12-02 21:09:39 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:09:39 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:09:39 --> Utf8 Class Initialized
INFO - 2016-12-02 21:09:39 --> URI Class Initialized
INFO - 2016-12-02 21:09:39 --> Router Class Initialized
INFO - 2016-12-02 21:09:39 --> Output Class Initialized
INFO - 2016-12-02 21:09:39 --> Security Class Initialized
DEBUG - 2016-12-02 21:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:09:39 --> Input Class Initialized
INFO - 2016-12-02 21:09:39 --> Language Class Initialized
INFO - 2016-12-02 21:09:39 --> Loader Class Initialized
INFO - 2016-12-02 21:09:39 --> Helper loaded: url_helper
INFO - 2016-12-02 21:09:39 --> Helper loaded: form_helper
INFO - 2016-12-02 21:09:39 --> Database Driver Class Initialized
INFO - 2016-12-02 21:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:09:39 --> Controller Class Initialized
INFO - 2016-12-02 21:09:39 --> Model Class Initialized
INFO - 2016-12-02 21:09:39 --> Form Validation Class Initialized
INFO - 2016-12-02 21:09:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:09:39 --> Pagination Class Initialized
INFO - 2016-12-02 21:09:39 --> Helper loaded: app_helper
INFO - 2016-12-02 21:09:39 --> Email Class Initialized
ERROR - 2016-12-02 21:09:39 --> Severity: Error --> Call to undefined method stdClass::result() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 17
INFO - 2016-12-02 21:17:25 --> Config Class Initialized
INFO - 2016-12-02 21:17:25 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:17:25 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:17:25 --> Utf8 Class Initialized
INFO - 2016-12-02 21:17:25 --> URI Class Initialized
INFO - 2016-12-02 21:17:25 --> Router Class Initialized
INFO - 2016-12-02 21:17:25 --> Output Class Initialized
INFO - 2016-12-02 21:17:25 --> Security Class Initialized
DEBUG - 2016-12-02 21:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:17:25 --> Input Class Initialized
INFO - 2016-12-02 21:17:25 --> Language Class Initialized
INFO - 2016-12-02 21:17:25 --> Loader Class Initialized
INFO - 2016-12-02 21:17:25 --> Helper loaded: url_helper
INFO - 2016-12-02 21:17:25 --> Helper loaded: form_helper
INFO - 2016-12-02 21:17:25 --> Database Driver Class Initialized
INFO - 2016-12-02 21:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:17:25 --> Controller Class Initialized
INFO - 2016-12-02 21:17:25 --> Model Class Initialized
INFO - 2016-12-02 21:17:25 --> Form Validation Class Initialized
INFO - 2016-12-02 21:17:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:17:25 --> Pagination Class Initialized
INFO - 2016-12-02 21:17:25 --> Helper loaded: app_helper
INFO - 2016-12-02 21:17:25 --> Email Class Initialized
ERROR - 2016-12-02 21:17:25 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 20
ERROR - 2016-12-02 21:17:25 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 27
ERROR - 2016-12-02 21:17:25 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-12-02 21:17:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-12-02 21:17:25 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-12-02 21:17:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 21:17:25 --> Final output sent to browser
DEBUG - 2016-12-02 21:17:25 --> Total execution time: 0.4747
INFO - 2016-12-02 21:22:43 --> Config Class Initialized
INFO - 2016-12-02 21:22:43 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:22:43 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:22:43 --> Utf8 Class Initialized
INFO - 2016-12-02 21:22:43 --> URI Class Initialized
INFO - 2016-12-02 21:22:43 --> Router Class Initialized
INFO - 2016-12-02 21:22:43 --> Output Class Initialized
INFO - 2016-12-02 21:22:43 --> Security Class Initialized
DEBUG - 2016-12-02 21:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:22:43 --> Input Class Initialized
INFO - 2016-12-02 21:22:43 --> Language Class Initialized
INFO - 2016-12-02 21:22:43 --> Loader Class Initialized
INFO - 2016-12-02 21:22:43 --> Helper loaded: url_helper
INFO - 2016-12-02 21:22:43 --> Helper loaded: form_helper
INFO - 2016-12-02 21:22:43 --> Database Driver Class Initialized
INFO - 2016-12-02 21:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:22:43 --> Controller Class Initialized
INFO - 2016-12-02 21:22:43 --> Model Class Initialized
INFO - 2016-12-02 21:22:43 --> Form Validation Class Initialized
INFO - 2016-12-02 21:22:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:22:43 --> Pagination Class Initialized
INFO - 2016-12-02 21:22:43 --> Helper loaded: app_helper
INFO - 2016-12-02 21:22:43 --> Email Class Initialized
ERROR - 2016-12-02 21:22:43 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 20
ERROR - 2016-12-02 21:22:43 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 27
ERROR - 2016-12-02 21:22:43 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-12-02 21:22:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-12-02 21:22:43 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-12-02 21:22:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 21:22:43 --> Final output sent to browser
DEBUG - 2016-12-02 21:22:43 --> Total execution time: 0.4651
INFO - 2016-12-02 21:22:46 --> Config Class Initialized
INFO - 2016-12-02 21:22:46 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:22:46 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:22:46 --> Utf8 Class Initialized
INFO - 2016-12-02 21:22:46 --> URI Class Initialized
INFO - 2016-12-02 21:22:46 --> Router Class Initialized
INFO - 2016-12-02 21:22:46 --> Output Class Initialized
INFO - 2016-12-02 21:22:46 --> Security Class Initialized
DEBUG - 2016-12-02 21:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:22:46 --> Input Class Initialized
INFO - 2016-12-02 21:22:46 --> Language Class Initialized
INFO - 2016-12-02 21:22:46 --> Loader Class Initialized
INFO - 2016-12-02 21:22:46 --> Helper loaded: url_helper
INFO - 2016-12-02 21:22:46 --> Helper loaded: form_helper
INFO - 2016-12-02 21:22:46 --> Database Driver Class Initialized
INFO - 2016-12-02 21:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:22:47 --> Controller Class Initialized
INFO - 2016-12-02 21:22:47 --> Model Class Initialized
INFO - 2016-12-02 21:22:47 --> Form Validation Class Initialized
INFO - 2016-12-02 21:22:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:22:47 --> Pagination Class Initialized
INFO - 2016-12-02 21:22:47 --> Helper loaded: app_helper
INFO - 2016-12-02 21:22:47 --> Email Class Initialized
ERROR - 2016-12-02 21:22:47 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 20
ERROR - 2016-12-02 21:22:47 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 27
ERROR - 2016-12-02 21:22:47 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-12-02 21:22:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-12-02 21:22:48 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-12-02 21:22:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 21:22:48 --> Final output sent to browser
DEBUG - 2016-12-02 21:22:48 --> Total execution time: 2.0401
INFO - 2016-12-02 21:28:27 --> Config Class Initialized
INFO - 2016-12-02 21:28:27 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:28:27 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:28:27 --> Utf8 Class Initialized
INFO - 2016-12-02 21:28:27 --> URI Class Initialized
INFO - 2016-12-02 21:28:27 --> Router Class Initialized
INFO - 2016-12-02 21:28:27 --> Output Class Initialized
INFO - 2016-12-02 21:28:27 --> Security Class Initialized
DEBUG - 2016-12-02 21:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:28:27 --> Input Class Initialized
INFO - 2016-12-02 21:28:27 --> Language Class Initialized
INFO - 2016-12-02 21:28:27 --> Loader Class Initialized
INFO - 2016-12-02 21:28:27 --> Helper loaded: url_helper
INFO - 2016-12-02 21:28:27 --> Helper loaded: form_helper
INFO - 2016-12-02 21:28:27 --> Database Driver Class Initialized
INFO - 2016-12-02 21:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:28:28 --> Controller Class Initialized
INFO - 2016-12-02 21:28:28 --> Model Class Initialized
INFO - 2016-12-02 21:28:28 --> Form Validation Class Initialized
INFO - 2016-12-02 21:28:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:28:28 --> Pagination Class Initialized
INFO - 2016-12-02 21:28:28 --> Helper loaded: app_helper
INFO - 2016-12-02 21:28:28 --> Email Class Initialized
ERROR - 2016-12-02 21:28:28 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 144
ERROR - 2016-12-02 21:28:28 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-12-02 21:28:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 21:28:28 --> Final output sent to browser
DEBUG - 2016-12-02 21:28:28 --> Total execution time: 0.3788
INFO - 2016-12-02 21:28:46 --> Config Class Initialized
INFO - 2016-12-02 21:28:46 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:28:46 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:28:46 --> Utf8 Class Initialized
INFO - 2016-12-02 21:28:46 --> URI Class Initialized
INFO - 2016-12-02 21:28:46 --> Router Class Initialized
INFO - 2016-12-02 21:28:46 --> Output Class Initialized
INFO - 2016-12-02 21:28:46 --> Security Class Initialized
DEBUG - 2016-12-02 21:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:28:46 --> Input Class Initialized
INFO - 2016-12-02 21:28:46 --> Language Class Initialized
INFO - 2016-12-02 21:28:46 --> Loader Class Initialized
INFO - 2016-12-02 21:28:46 --> Helper loaded: url_helper
INFO - 2016-12-02 21:28:46 --> Helper loaded: form_helper
INFO - 2016-12-02 21:28:46 --> Database Driver Class Initialized
INFO - 2016-12-02 21:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:28:46 --> Controller Class Initialized
INFO - 2016-12-02 21:28:46 --> Model Class Initialized
INFO - 2016-12-02 21:28:46 --> Form Validation Class Initialized
INFO - 2016-12-02 21:28:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:28:46 --> Pagination Class Initialized
INFO - 2016-12-02 21:28:46 --> Helper loaded: app_helper
INFO - 2016-12-02 21:28:46 --> Email Class Initialized
ERROR - 2016-12-02 21:28:46 --> Severity: Warning --> Missing argument 2 for Leave_application_m::all_leave_application(), called in C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php on line 144 and defined C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 7
ERROR - 2016-12-02 21:28:46 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 11
ERROR - 2016-12-02 21:28:46 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-12-02 21:28:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 21:28:46 --> Final output sent to browser
DEBUG - 2016-12-02 21:28:46 --> Total execution time: 0.4124
INFO - 2016-12-02 21:29:08 --> Config Class Initialized
INFO - 2016-12-02 21:29:08 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:29:08 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:29:08 --> Utf8 Class Initialized
INFO - 2016-12-02 21:29:08 --> URI Class Initialized
INFO - 2016-12-02 21:29:08 --> Router Class Initialized
INFO - 2016-12-02 21:29:08 --> Output Class Initialized
INFO - 2016-12-02 21:29:08 --> Security Class Initialized
DEBUG - 2016-12-02 21:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:29:08 --> Input Class Initialized
INFO - 2016-12-02 21:29:08 --> Language Class Initialized
INFO - 2016-12-02 21:29:08 --> Loader Class Initialized
INFO - 2016-12-02 21:29:08 --> Helper loaded: url_helper
INFO - 2016-12-02 21:29:08 --> Helper loaded: form_helper
INFO - 2016-12-02 21:29:08 --> Database Driver Class Initialized
INFO - 2016-12-02 21:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:29:08 --> Controller Class Initialized
INFO - 2016-12-02 21:29:08 --> Model Class Initialized
INFO - 2016-12-02 21:29:08 --> Form Validation Class Initialized
INFO - 2016-12-02 21:29:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:29:08 --> Pagination Class Initialized
INFO - 2016-12-02 21:29:08 --> Helper loaded: app_helper
INFO - 2016-12-02 21:29:08 --> Email Class Initialized
ERROR - 2016-12-02 21:29:08 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-12-02 21:29:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 21:29:08 --> Final output sent to browser
DEBUG - 2016-12-02 21:29:08 --> Total execution time: 0.3848
INFO - 2016-12-02 21:30:10 --> Config Class Initialized
INFO - 2016-12-02 21:30:10 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:30:10 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:30:10 --> Utf8 Class Initialized
INFO - 2016-12-02 21:30:10 --> URI Class Initialized
INFO - 2016-12-02 21:30:10 --> Router Class Initialized
INFO - 2016-12-02 21:30:10 --> Output Class Initialized
INFO - 2016-12-02 21:30:10 --> Security Class Initialized
DEBUG - 2016-12-02 21:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:30:10 --> Input Class Initialized
INFO - 2016-12-02 21:30:10 --> Language Class Initialized
INFO - 2016-12-02 21:30:10 --> Loader Class Initialized
INFO - 2016-12-02 21:30:10 --> Helper loaded: url_helper
INFO - 2016-12-02 21:30:10 --> Helper loaded: form_helper
INFO - 2016-12-02 21:30:10 --> Database Driver Class Initialized
INFO - 2016-12-02 21:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:30:10 --> Controller Class Initialized
INFO - 2016-12-02 21:30:10 --> Model Class Initialized
INFO - 2016-12-02 21:30:10 --> Form Validation Class Initialized
INFO - 2016-12-02 21:30:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:30:10 --> Pagination Class Initialized
INFO - 2016-12-02 21:30:10 --> Helper loaded: app_helper
INFO - 2016-12-02 21:30:10 --> Email Class Initialized
ERROR - 2016-12-02 21:30:10 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 148
ERROR - 2016-12-02 21:30:10 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 150
ERROR - 2016-12-02 21:30:10 --> Severity: Notice --> Undefined variable: idleaveType C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 150
ERROR - 2016-12-02 21:30:10 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-12-02 21:30:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 21:30:10 --> Final output sent to browser
DEBUG - 2016-12-02 21:30:10 --> Total execution time: 0.4148
INFO - 2016-12-02 21:31:52 --> Config Class Initialized
INFO - 2016-12-02 21:31:52 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:31:52 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:31:52 --> Utf8 Class Initialized
INFO - 2016-12-02 21:31:52 --> URI Class Initialized
INFO - 2016-12-02 21:31:52 --> Router Class Initialized
INFO - 2016-12-02 21:31:52 --> Output Class Initialized
INFO - 2016-12-02 21:31:52 --> Security Class Initialized
DEBUG - 2016-12-02 21:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:31:52 --> Input Class Initialized
INFO - 2016-12-02 21:31:52 --> Language Class Initialized
INFO - 2016-12-02 21:31:52 --> Loader Class Initialized
INFO - 2016-12-02 21:31:52 --> Helper loaded: url_helper
INFO - 2016-12-02 21:31:52 --> Helper loaded: form_helper
INFO - 2016-12-02 21:31:52 --> Database Driver Class Initialized
INFO - 2016-12-02 21:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:31:52 --> Controller Class Initialized
INFO - 2016-12-02 21:31:52 --> Model Class Initialized
INFO - 2016-12-02 21:31:52 --> Form Validation Class Initialized
INFO - 2016-12-02 21:31:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:31:52 --> Pagination Class Initialized
INFO - 2016-12-02 21:31:52 --> Helper loaded: app_helper
INFO - 2016-12-02 21:31:52 --> Email Class Initialized
ERROR - 2016-12-02 21:31:52 --> Severity: Warning --> Missing argument 1 for Leave_application_m::count_Leave_application(), called in C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php on line 148 and defined C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 52
ERROR - 2016-12-02 21:31:53 --> Severity: Notice --> Undefined variable: userID C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 55
ERROR - 2016-12-02 21:31:53 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-12-02 21:31:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 21:31:53 --> Final output sent to browser
DEBUG - 2016-12-02 21:31:53 --> Total execution time: 0.3879
INFO - 2016-12-02 21:48:00 --> Config Class Initialized
INFO - 2016-12-02 21:48:00 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:48:00 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:48:00 --> Utf8 Class Initialized
INFO - 2016-12-02 21:48:00 --> URI Class Initialized
INFO - 2016-12-02 21:48:00 --> Router Class Initialized
INFO - 2016-12-02 21:48:00 --> Output Class Initialized
INFO - 2016-12-02 21:48:00 --> Security Class Initialized
DEBUG - 2016-12-02 21:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:48:00 --> Input Class Initialized
INFO - 2016-12-02 21:48:00 --> Language Class Initialized
INFO - 2016-12-02 21:48:00 --> Loader Class Initialized
INFO - 2016-12-02 21:48:00 --> Helper loaded: url_helper
INFO - 2016-12-02 21:48:00 --> Helper loaded: form_helper
INFO - 2016-12-02 21:48:01 --> Database Driver Class Initialized
INFO - 2016-12-02 21:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:48:01 --> Controller Class Initialized
INFO - 2016-12-02 21:48:01 --> Model Class Initialized
INFO - 2016-12-02 21:48:01 --> Form Validation Class Initialized
INFO - 2016-12-02 21:48:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:48:01 --> Pagination Class Initialized
INFO - 2016-12-02 21:48:01 --> Helper loaded: app_helper
INFO - 2016-12-02 21:48:01 --> Email Class Initialized
INFO - 2016-12-02 21:48:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-02 20:48:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-02 20:48:01 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-02 20:48:01 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-02 20:48:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-02 20:48:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 20:48:05 --> Final output sent to browser
DEBUG - 2016-12-02 20:48:05 --> Total execution time: 4.7594
INFO - 2016-12-02 21:48:22 --> Config Class Initialized
INFO - 2016-12-02 21:48:22 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:48:22 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:48:22 --> Utf8 Class Initialized
INFO - 2016-12-02 21:48:22 --> URI Class Initialized
INFO - 2016-12-02 21:48:22 --> Router Class Initialized
INFO - 2016-12-02 21:48:22 --> Output Class Initialized
INFO - 2016-12-02 21:48:22 --> Security Class Initialized
DEBUG - 2016-12-02 21:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:48:22 --> Input Class Initialized
INFO - 2016-12-02 21:48:22 --> Language Class Initialized
INFO - 2016-12-02 21:48:22 --> Loader Class Initialized
INFO - 2016-12-02 21:48:22 --> Helper loaded: url_helper
INFO - 2016-12-02 21:48:22 --> Helper loaded: form_helper
INFO - 2016-12-02 21:48:22 --> Database Driver Class Initialized
INFO - 2016-12-02 21:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:48:22 --> Controller Class Initialized
INFO - 2016-12-02 21:48:22 --> Model Class Initialized
INFO - 2016-12-02 21:48:22 --> Form Validation Class Initialized
INFO - 2016-12-02 21:48:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:48:22 --> Pagination Class Initialized
INFO - 2016-12-02 21:48:22 --> Helper loaded: app_helper
INFO - 2016-12-02 21:48:22 --> Email Class Initialized
ERROR - 2016-12-02 21:48:22 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-12-02 21:48:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 21:48:22 --> Final output sent to browser
DEBUG - 2016-12-02 21:48:22 --> Total execution time: 0.3547
INFO - 2016-12-02 21:50:49 --> Config Class Initialized
INFO - 2016-12-02 21:50:49 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:50:49 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:50:49 --> Utf8 Class Initialized
INFO - 2016-12-02 21:50:49 --> URI Class Initialized
INFO - 2016-12-02 21:50:49 --> Router Class Initialized
INFO - 2016-12-02 21:50:49 --> Output Class Initialized
INFO - 2016-12-02 21:50:49 --> Security Class Initialized
DEBUG - 2016-12-02 21:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:50:49 --> Input Class Initialized
INFO - 2016-12-02 21:50:49 --> Language Class Initialized
INFO - 2016-12-02 21:50:49 --> Loader Class Initialized
INFO - 2016-12-02 21:50:49 --> Helper loaded: url_helper
INFO - 2016-12-02 21:50:49 --> Helper loaded: form_helper
INFO - 2016-12-02 21:50:49 --> Database Driver Class Initialized
INFO - 2016-12-02 21:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:50:49 --> Controller Class Initialized
INFO - 2016-12-02 21:50:50 --> Model Class Initialized
INFO - 2016-12-02 21:50:50 --> Form Validation Class Initialized
INFO - 2016-12-02 21:50:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:50:50 --> Pagination Class Initialized
INFO - 2016-12-02 21:50:50 --> Helper loaded: app_helper
INFO - 2016-12-02 21:50:50 --> Email Class Initialized
ERROR - 2016-12-02 21:50:50 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-12-02 21:50:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 21:50:50 --> Final output sent to browser
DEBUG - 2016-12-02 21:50:50 --> Total execution time: 0.4117
INFO - 2016-12-02 21:52:12 --> Config Class Initialized
INFO - 2016-12-02 21:52:12 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:52:12 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:52:12 --> Utf8 Class Initialized
INFO - 2016-12-02 21:52:12 --> URI Class Initialized
INFO - 2016-12-02 21:52:12 --> Router Class Initialized
INFO - 2016-12-02 21:52:12 --> Output Class Initialized
INFO - 2016-12-02 21:52:12 --> Security Class Initialized
DEBUG - 2016-12-02 21:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:52:12 --> Input Class Initialized
INFO - 2016-12-02 21:52:12 --> Language Class Initialized
INFO - 2016-12-02 21:52:12 --> Loader Class Initialized
INFO - 2016-12-02 21:52:12 --> Helper loaded: url_helper
INFO - 2016-12-02 21:52:12 --> Helper loaded: form_helper
INFO - 2016-12-02 21:52:12 --> Database Driver Class Initialized
INFO - 2016-12-02 21:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:52:12 --> Controller Class Initialized
INFO - 2016-12-02 21:52:12 --> Model Class Initialized
INFO - 2016-12-02 21:52:13 --> Form Validation Class Initialized
INFO - 2016-12-02 21:52:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:52:13 --> Pagination Class Initialized
INFO - 2016-12-02 21:52:13 --> Helper loaded: app_helper
INFO - 2016-12-02 21:52:13 --> Email Class Initialized
ERROR - 2016-12-02 21:52:13 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-12-02 21:52:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 21:52:13 --> Final output sent to browser
DEBUG - 2016-12-02 21:52:13 --> Total execution time: 0.3998
INFO - 2016-12-02 21:55:17 --> Config Class Initialized
INFO - 2016-12-02 21:55:17 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:55:17 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:55:17 --> Utf8 Class Initialized
INFO - 2016-12-02 21:55:17 --> URI Class Initialized
INFO - 2016-12-02 21:55:17 --> Router Class Initialized
INFO - 2016-12-02 21:55:17 --> Output Class Initialized
INFO - 2016-12-02 21:55:17 --> Security Class Initialized
DEBUG - 2016-12-02 21:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:55:17 --> Input Class Initialized
INFO - 2016-12-02 21:55:17 --> Language Class Initialized
INFO - 2016-12-02 21:55:17 --> Loader Class Initialized
INFO - 2016-12-02 21:55:17 --> Helper loaded: url_helper
INFO - 2016-12-02 21:55:17 --> Helper loaded: form_helper
INFO - 2016-12-02 21:55:17 --> Database Driver Class Initialized
INFO - 2016-12-02 21:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:55:17 --> Controller Class Initialized
INFO - 2016-12-02 21:55:17 --> Model Class Initialized
INFO - 2016-12-02 21:55:17 --> Form Validation Class Initialized
INFO - 2016-12-02 21:55:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:55:17 --> Pagination Class Initialized
INFO - 2016-12-02 21:55:18 --> Helper loaded: app_helper
INFO - 2016-12-02 21:55:18 --> Email Class Initialized
ERROR - 2016-12-02 21:55:18 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 20
ERROR - 2016-12-02 21:55:18 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 27
ERROR - 2016-12-02 21:55:18 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-12-02 21:55:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 21:55:18 --> Final output sent to browser
DEBUG - 2016-12-02 21:55:18 --> Total execution time: 0.4119
INFO - 2016-12-02 21:57:31 --> Config Class Initialized
INFO - 2016-12-02 21:57:31 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:57:31 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:57:31 --> Utf8 Class Initialized
INFO - 2016-12-02 21:57:31 --> URI Class Initialized
DEBUG - 2016-12-02 21:57:31 --> No URI present. Default controller set.
INFO - 2016-12-02 21:57:31 --> Router Class Initialized
INFO - 2016-12-02 21:57:31 --> Output Class Initialized
INFO - 2016-12-02 21:57:31 --> Security Class Initialized
DEBUG - 2016-12-02 21:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:57:31 --> Input Class Initialized
INFO - 2016-12-02 21:57:31 --> Language Class Initialized
INFO - 2016-12-02 21:57:31 --> Loader Class Initialized
INFO - 2016-12-02 21:57:31 --> Helper loaded: url_helper
INFO - 2016-12-02 21:57:31 --> Helper loaded: form_helper
INFO - 2016-12-02 21:57:31 --> Database Driver Class Initialized
INFO - 2016-12-02 21:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:57:31 --> Controller Class Initialized
INFO - 2016-12-02 21:57:31 --> Model Class Initialized
INFO - 2016-12-02 21:57:31 --> Model Class Initialized
INFO - 2016-12-02 21:57:31 --> Model Class Initialized
INFO - 2016-12-02 21:57:31 --> Model Class Initialized
INFO - 2016-12-02 21:57:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:57:31 --> Pagination Class Initialized
INFO - 2016-12-02 21:57:31 --> Helper loaded: app_helper
INFO - 2016-12-02 21:57:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 21:57:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 21:57:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 21:57:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 21:57:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 21:57:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 21:57:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 21:57:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 21:57:31 --> Final output sent to browser
DEBUG - 2016-12-02 21:57:31 --> Total execution time: 0.5802
INFO - 2016-12-02 21:57:45 --> Config Class Initialized
INFO - 2016-12-02 21:57:45 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:57:45 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:57:45 --> Utf8 Class Initialized
INFO - 2016-12-02 21:57:45 --> URI Class Initialized
DEBUG - 2016-12-02 21:57:45 --> No URI present. Default controller set.
INFO - 2016-12-02 21:57:45 --> Router Class Initialized
INFO - 2016-12-02 21:57:45 --> Output Class Initialized
INFO - 2016-12-02 21:57:45 --> Security Class Initialized
DEBUG - 2016-12-02 21:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:57:45 --> Input Class Initialized
INFO - 2016-12-02 21:57:45 --> Language Class Initialized
INFO - 2016-12-02 21:57:45 --> Loader Class Initialized
INFO - 2016-12-02 21:57:45 --> Helper loaded: url_helper
INFO - 2016-12-02 21:57:45 --> Helper loaded: form_helper
INFO - 2016-12-02 21:57:45 --> Database Driver Class Initialized
INFO - 2016-12-02 21:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:57:45 --> Controller Class Initialized
INFO - 2016-12-02 21:57:46 --> Model Class Initialized
INFO - 2016-12-02 21:57:46 --> Model Class Initialized
INFO - 2016-12-02 21:57:46 --> Model Class Initialized
INFO - 2016-12-02 21:57:46 --> Model Class Initialized
INFO - 2016-12-02 21:57:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:57:46 --> Pagination Class Initialized
INFO - 2016-12-02 21:57:46 --> Helper loaded: app_helper
INFO - 2016-12-02 21:57:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 21:57:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 21:57:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 21:57:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 21:57:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 21:57:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 21:57:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 21:57:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 21:57:46 --> Final output sent to browser
DEBUG - 2016-12-02 21:57:46 --> Total execution time: 0.5145
INFO - 2016-12-02 21:58:36 --> Config Class Initialized
INFO - 2016-12-02 21:58:36 --> Hooks Class Initialized
DEBUG - 2016-12-02 21:58:36 --> UTF-8 Support Enabled
INFO - 2016-12-02 21:58:36 --> Utf8 Class Initialized
INFO - 2016-12-02 21:58:36 --> URI Class Initialized
DEBUG - 2016-12-02 21:58:36 --> No URI present. Default controller set.
INFO - 2016-12-02 21:58:36 --> Router Class Initialized
INFO - 2016-12-02 21:58:36 --> Output Class Initialized
INFO - 2016-12-02 21:58:36 --> Security Class Initialized
DEBUG - 2016-12-02 21:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 21:58:36 --> Input Class Initialized
INFO - 2016-12-02 21:58:36 --> Language Class Initialized
INFO - 2016-12-02 21:58:36 --> Loader Class Initialized
INFO - 2016-12-02 21:58:36 --> Helper loaded: url_helper
INFO - 2016-12-02 21:58:36 --> Helper loaded: form_helper
INFO - 2016-12-02 21:58:36 --> Database Driver Class Initialized
INFO - 2016-12-02 21:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 21:58:36 --> Controller Class Initialized
INFO - 2016-12-02 21:58:36 --> Model Class Initialized
INFO - 2016-12-02 21:58:36 --> Model Class Initialized
INFO - 2016-12-02 21:58:36 --> Model Class Initialized
INFO - 2016-12-02 21:58:36 --> Model Class Initialized
INFO - 2016-12-02 21:58:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 21:58:36 --> Pagination Class Initialized
INFO - 2016-12-02 21:58:36 --> Helper loaded: app_helper
INFO - 2016-12-02 21:58:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 21:58:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 21:58:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 21:58:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 21:58:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 21:58:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 21:58:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 21:58:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 21:58:37 --> Final output sent to browser
DEBUG - 2016-12-02 21:58:37 --> Total execution time: 0.5205
INFO - 2016-12-02 22:01:19 --> Config Class Initialized
INFO - 2016-12-02 22:01:19 --> Hooks Class Initialized
DEBUG - 2016-12-02 22:01:19 --> UTF-8 Support Enabled
INFO - 2016-12-02 22:01:19 --> Utf8 Class Initialized
INFO - 2016-12-02 22:01:19 --> URI Class Initialized
DEBUG - 2016-12-02 22:01:19 --> No URI present. Default controller set.
INFO - 2016-12-02 22:01:19 --> Router Class Initialized
INFO - 2016-12-02 22:01:19 --> Output Class Initialized
INFO - 2016-12-02 22:01:19 --> Security Class Initialized
DEBUG - 2016-12-02 22:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 22:01:19 --> Input Class Initialized
INFO - 2016-12-02 22:01:19 --> Language Class Initialized
INFO - 2016-12-02 22:01:19 --> Loader Class Initialized
INFO - 2016-12-02 22:01:19 --> Helper loaded: url_helper
INFO - 2016-12-02 22:01:19 --> Helper loaded: form_helper
INFO - 2016-12-02 22:01:19 --> Database Driver Class Initialized
INFO - 2016-12-02 22:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 22:01:19 --> Controller Class Initialized
INFO - 2016-12-02 22:01:19 --> Model Class Initialized
INFO - 2016-12-02 22:01:19 --> Model Class Initialized
INFO - 2016-12-02 22:01:19 --> Model Class Initialized
INFO - 2016-12-02 22:01:19 --> Model Class Initialized
INFO - 2016-12-02 22:01:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 22:01:19 --> Pagination Class Initialized
INFO - 2016-12-02 22:01:19 --> Helper loaded: app_helper
INFO - 2016-12-02 22:01:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 22:01:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 22:01:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 22:01:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 22:01:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 22:01:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 22:01:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 22:01:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 22:01:20 --> Final output sent to browser
DEBUG - 2016-12-02 22:01:20 --> Total execution time: 0.5454
INFO - 2016-12-02 22:02:51 --> Config Class Initialized
INFO - 2016-12-02 22:02:51 --> Hooks Class Initialized
DEBUG - 2016-12-02 22:02:51 --> UTF-8 Support Enabled
INFO - 2016-12-02 22:02:51 --> Utf8 Class Initialized
INFO - 2016-12-02 22:02:51 --> URI Class Initialized
DEBUG - 2016-12-02 22:02:51 --> No URI present. Default controller set.
INFO - 2016-12-02 22:02:51 --> Router Class Initialized
INFO - 2016-12-02 22:02:51 --> Output Class Initialized
INFO - 2016-12-02 22:02:51 --> Security Class Initialized
DEBUG - 2016-12-02 22:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 22:02:51 --> Input Class Initialized
INFO - 2016-12-02 22:02:51 --> Language Class Initialized
INFO - 2016-12-02 22:02:51 --> Loader Class Initialized
INFO - 2016-12-02 22:02:51 --> Helper loaded: url_helper
INFO - 2016-12-02 22:02:51 --> Helper loaded: form_helper
INFO - 2016-12-02 22:02:51 --> Database Driver Class Initialized
INFO - 2016-12-02 22:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 22:02:51 --> Controller Class Initialized
INFO - 2016-12-02 22:02:51 --> Model Class Initialized
INFO - 2016-12-02 22:02:51 --> Model Class Initialized
INFO - 2016-12-02 22:02:51 --> Model Class Initialized
INFO - 2016-12-02 22:02:51 --> Model Class Initialized
INFO - 2016-12-02 22:02:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 22:02:51 --> Pagination Class Initialized
INFO - 2016-12-02 22:02:51 --> Helper loaded: app_helper
INFO - 2016-12-02 22:02:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 22:02:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 22:02:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 22:02:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 22:02:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 22:02:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 22:02:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 22:02:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 22:02:52 --> Final output sent to browser
DEBUG - 2016-12-02 22:02:52 --> Total execution time: 0.5856
INFO - 2016-12-02 22:03:40 --> Config Class Initialized
INFO - 2016-12-02 22:03:41 --> Hooks Class Initialized
DEBUG - 2016-12-02 22:03:41 --> UTF-8 Support Enabled
INFO - 2016-12-02 22:03:41 --> Utf8 Class Initialized
INFO - 2016-12-02 22:03:41 --> URI Class Initialized
DEBUG - 2016-12-02 22:03:41 --> No URI present. Default controller set.
INFO - 2016-12-02 22:03:41 --> Router Class Initialized
INFO - 2016-12-02 22:03:41 --> Output Class Initialized
INFO - 2016-12-02 22:03:41 --> Security Class Initialized
DEBUG - 2016-12-02 22:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 22:03:41 --> Input Class Initialized
INFO - 2016-12-02 22:03:41 --> Language Class Initialized
INFO - 2016-12-02 22:03:41 --> Loader Class Initialized
INFO - 2016-12-02 22:03:41 --> Helper loaded: url_helper
INFO - 2016-12-02 22:03:41 --> Helper loaded: form_helper
INFO - 2016-12-02 22:03:41 --> Database Driver Class Initialized
INFO - 2016-12-02 22:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 22:03:41 --> Controller Class Initialized
INFO - 2016-12-02 22:03:41 --> Model Class Initialized
INFO - 2016-12-02 22:03:41 --> Model Class Initialized
INFO - 2016-12-02 22:03:41 --> Model Class Initialized
INFO - 2016-12-02 22:03:41 --> Model Class Initialized
INFO - 2016-12-02 22:03:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 22:03:41 --> Pagination Class Initialized
INFO - 2016-12-02 22:03:41 --> Helper loaded: app_helper
INFO - 2016-12-02 22:03:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 22:03:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 22:03:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 22:03:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 22:03:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 22:03:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 22:03:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 22:03:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 22:03:41 --> Final output sent to browser
DEBUG - 2016-12-02 22:03:41 --> Total execution time: 0.5352
INFO - 2016-12-02 22:04:17 --> Config Class Initialized
INFO - 2016-12-02 22:04:17 --> Hooks Class Initialized
DEBUG - 2016-12-02 22:04:17 --> UTF-8 Support Enabled
INFO - 2016-12-02 22:04:17 --> Utf8 Class Initialized
INFO - 2016-12-02 22:04:17 --> URI Class Initialized
INFO - 2016-12-02 22:04:17 --> Router Class Initialized
INFO - 2016-12-02 22:04:17 --> Output Class Initialized
INFO - 2016-12-02 22:04:17 --> Security Class Initialized
DEBUG - 2016-12-02 22:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 22:04:17 --> Input Class Initialized
INFO - 2016-12-02 22:04:17 --> Language Class Initialized
ERROR - 2016-12-02 22:04:17 --> Severity: Parsing Error --> syntax error, unexpected '$', expecting variable (T_VARIABLE) C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 142
INFO - 2016-12-02 22:05:16 --> Config Class Initialized
INFO - 2016-12-02 22:05:16 --> Hooks Class Initialized
DEBUG - 2016-12-02 22:05:16 --> UTF-8 Support Enabled
INFO - 2016-12-02 22:05:16 --> Utf8 Class Initialized
INFO - 2016-12-02 22:05:16 --> URI Class Initialized
INFO - 2016-12-02 22:05:16 --> Router Class Initialized
INFO - 2016-12-02 22:05:16 --> Output Class Initialized
INFO - 2016-12-02 22:05:16 --> Security Class Initialized
DEBUG - 2016-12-02 22:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 22:05:16 --> Input Class Initialized
INFO - 2016-12-02 22:05:16 --> Language Class Initialized
INFO - 2016-12-02 22:05:16 --> Loader Class Initialized
INFO - 2016-12-02 22:05:16 --> Helper loaded: url_helper
INFO - 2016-12-02 22:05:16 --> Helper loaded: form_helper
INFO - 2016-12-02 22:05:16 --> Database Driver Class Initialized
INFO - 2016-12-02 22:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 22:05:16 --> Controller Class Initialized
INFO - 2016-12-02 22:05:16 --> Model Class Initialized
INFO - 2016-12-02 22:05:16 --> Form Validation Class Initialized
INFO - 2016-12-02 22:05:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 22:05:16 --> Pagination Class Initialized
INFO - 2016-12-02 22:05:16 --> Helper loaded: app_helper
INFO - 2016-12-02 22:05:16 --> Email Class Initialized
INFO - 2016-12-02 22:05:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-02 21:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-02 21:05:16 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-02 21:05:17 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-02 21:05:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-02 21:05:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 21:05:22 --> Final output sent to browser
DEBUG - 2016-12-02 21:05:22 --> Total execution time: 5.9592
INFO - 2016-12-02 22:05:36 --> Config Class Initialized
INFO - 2016-12-02 22:05:36 --> Hooks Class Initialized
DEBUG - 2016-12-02 22:05:36 --> UTF-8 Support Enabled
INFO - 2016-12-02 22:05:36 --> Utf8 Class Initialized
INFO - 2016-12-02 22:05:36 --> URI Class Initialized
INFO - 2016-12-02 22:05:36 --> Router Class Initialized
INFO - 2016-12-02 22:05:36 --> Output Class Initialized
INFO - 2016-12-02 22:05:36 --> Security Class Initialized
DEBUG - 2016-12-02 22:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 22:05:36 --> Input Class Initialized
INFO - 2016-12-02 22:05:36 --> Language Class Initialized
INFO - 2016-12-02 22:05:36 --> Loader Class Initialized
INFO - 2016-12-02 22:05:36 --> Helper loaded: url_helper
INFO - 2016-12-02 22:05:36 --> Helper loaded: form_helper
INFO - 2016-12-02 22:05:36 --> Database Driver Class Initialized
INFO - 2016-12-02 22:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 22:05:36 --> Controller Class Initialized
INFO - 2016-12-02 22:05:36 --> Model Class Initialized
INFO - 2016-12-02 22:05:36 --> Form Validation Class Initialized
INFO - 2016-12-02 22:05:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 22:05:36 --> Pagination Class Initialized
INFO - 2016-12-02 22:05:37 --> Helper loaded: app_helper
INFO - 2016-12-02 22:05:37 --> Email Class Initialized
ERROR - 2016-12-02 22:05:37 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 24
ERROR - 2016-12-02 22:05:37 --> Severity: Error --> Call to a member function row() on null C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 24
INFO - 2016-12-02 22:07:16 --> Config Class Initialized
INFO - 2016-12-02 22:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-02 22:07:16 --> UTF-8 Support Enabled
INFO - 2016-12-02 22:07:16 --> Utf8 Class Initialized
INFO - 2016-12-02 22:07:16 --> URI Class Initialized
INFO - 2016-12-02 22:07:16 --> Router Class Initialized
INFO - 2016-12-02 22:07:16 --> Output Class Initialized
INFO - 2016-12-02 22:07:16 --> Security Class Initialized
DEBUG - 2016-12-02 22:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 22:07:17 --> Input Class Initialized
INFO - 2016-12-02 22:07:17 --> Language Class Initialized
INFO - 2016-12-02 22:07:17 --> Loader Class Initialized
INFO - 2016-12-02 22:07:17 --> Helper loaded: url_helper
INFO - 2016-12-02 22:07:17 --> Helper loaded: form_helper
INFO - 2016-12-02 22:07:17 --> Database Driver Class Initialized
INFO - 2016-12-02 22:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 22:07:17 --> Controller Class Initialized
INFO - 2016-12-02 22:07:17 --> Model Class Initialized
INFO - 2016-12-02 22:07:17 --> Form Validation Class Initialized
INFO - 2016-12-02 22:07:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 22:07:17 --> Pagination Class Initialized
INFO - 2016-12-02 22:07:17 --> Helper loaded: app_helper
INFO - 2016-12-02 22:07:17 --> Email Class Initialized
ERROR - 2016-12-02 22:07:17 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 24
ERROR - 2016-12-02 22:07:17 --> Severity: Error --> Call to a member function row() on null C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 24
INFO - 2016-12-02 22:14:25 --> Config Class Initialized
INFO - 2016-12-02 22:14:25 --> Hooks Class Initialized
DEBUG - 2016-12-02 22:14:25 --> UTF-8 Support Enabled
INFO - 2016-12-02 22:14:25 --> Utf8 Class Initialized
INFO - 2016-12-02 22:14:25 --> URI Class Initialized
DEBUG - 2016-12-02 22:14:25 --> No URI present. Default controller set.
INFO - 2016-12-02 22:14:25 --> Router Class Initialized
INFO - 2016-12-02 22:14:25 --> Output Class Initialized
INFO - 2016-12-02 22:14:25 --> Security Class Initialized
DEBUG - 2016-12-02 22:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 22:14:25 --> Input Class Initialized
INFO - 2016-12-02 22:14:25 --> Language Class Initialized
INFO - 2016-12-02 22:14:25 --> Loader Class Initialized
INFO - 2016-12-02 22:14:25 --> Helper loaded: url_helper
INFO - 2016-12-02 22:14:25 --> Helper loaded: form_helper
INFO - 2016-12-02 22:14:25 --> Database Driver Class Initialized
INFO - 2016-12-02 22:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 22:14:25 --> Controller Class Initialized
INFO - 2016-12-02 22:14:25 --> Model Class Initialized
INFO - 2016-12-02 22:14:25 --> Model Class Initialized
INFO - 2016-12-02 22:14:25 --> Model Class Initialized
INFO - 2016-12-02 22:14:25 --> Model Class Initialized
INFO - 2016-12-02 22:14:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 22:14:25 --> Pagination Class Initialized
INFO - 2016-12-02 22:14:25 --> Helper loaded: app_helper
INFO - 2016-12-02 22:14:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 22:14:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 22:14:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 22:14:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 22:14:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 22:14:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 22:14:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 22:14:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 22:14:25 --> Final output sent to browser
DEBUG - 2016-12-02 22:14:25 --> Total execution time: 0.5471
INFO - 2016-12-02 22:14:30 --> Config Class Initialized
INFO - 2016-12-02 22:14:30 --> Hooks Class Initialized
DEBUG - 2016-12-02 22:14:30 --> UTF-8 Support Enabled
INFO - 2016-12-02 22:14:30 --> Utf8 Class Initialized
INFO - 2016-12-02 22:14:30 --> URI Class Initialized
INFO - 2016-12-02 22:14:30 --> Router Class Initialized
INFO - 2016-12-02 22:14:30 --> Output Class Initialized
INFO - 2016-12-02 22:14:30 --> Security Class Initialized
DEBUG - 2016-12-02 22:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 22:14:30 --> Input Class Initialized
INFO - 2016-12-02 22:14:30 --> Language Class Initialized
INFO - 2016-12-02 22:14:30 --> Loader Class Initialized
INFO - 2016-12-02 22:14:30 --> Helper loaded: url_helper
INFO - 2016-12-02 22:14:30 --> Helper loaded: form_helper
INFO - 2016-12-02 22:14:30 --> Database Driver Class Initialized
INFO - 2016-12-02 22:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 22:14:31 --> Controller Class Initialized
INFO - 2016-12-02 22:14:31 --> Model Class Initialized
INFO - 2016-12-02 22:14:31 --> Model Class Initialized
INFO - 2016-12-02 22:14:31 --> Model Class Initialized
INFO - 2016-12-02 22:14:31 --> Model Class Initialized
INFO - 2016-12-02 22:14:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 22:14:31 --> Pagination Class Initialized
INFO - 2016-12-02 22:14:31 --> Helper loaded: app_helper
DEBUG - 2016-12-02 22:14:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-12-02 22:14:31 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-12-02 22:14:31 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-12-02 22:14:31 --> Config Class Initialized
INFO - 2016-12-02 22:14:31 --> Hooks Class Initialized
DEBUG - 2016-12-02 22:14:31 --> UTF-8 Support Enabled
INFO - 2016-12-02 22:14:31 --> Utf8 Class Initialized
INFO - 2016-12-02 22:14:31 --> URI Class Initialized
DEBUG - 2016-12-02 22:14:31 --> No URI present. Default controller set.
INFO - 2016-12-02 22:14:31 --> Router Class Initialized
INFO - 2016-12-02 22:14:31 --> Output Class Initialized
INFO - 2016-12-02 22:14:31 --> Security Class Initialized
DEBUG - 2016-12-02 22:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 22:14:31 --> Input Class Initialized
INFO - 2016-12-02 22:14:31 --> Language Class Initialized
INFO - 2016-12-02 22:14:31 --> Loader Class Initialized
INFO - 2016-12-02 22:14:31 --> Helper loaded: url_helper
INFO - 2016-12-02 22:14:31 --> Helper loaded: form_helper
INFO - 2016-12-02 22:14:31 --> Database Driver Class Initialized
INFO - 2016-12-02 22:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 22:14:31 --> Controller Class Initialized
INFO - 2016-12-02 22:14:31 --> Model Class Initialized
INFO - 2016-12-02 22:14:31 --> Model Class Initialized
INFO - 2016-12-02 22:14:31 --> Model Class Initialized
INFO - 2016-12-02 22:14:31 --> Model Class Initialized
INFO - 2016-12-02 22:14:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 22:14:31 --> Pagination Class Initialized
INFO - 2016-12-02 22:14:31 --> Helper loaded: app_helper
INFO - 2016-12-02 22:14:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 22:14:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-12-02 22:14:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 22:14:31 --> Final output sent to browser
DEBUG - 2016-12-02 22:14:31 --> Total execution time: 0.4229
INFO - 2016-12-02 22:14:38 --> Config Class Initialized
INFO - 2016-12-02 22:14:38 --> Hooks Class Initialized
DEBUG - 2016-12-02 22:14:38 --> UTF-8 Support Enabled
INFO - 2016-12-02 22:14:38 --> Utf8 Class Initialized
INFO - 2016-12-02 22:14:38 --> URI Class Initialized
INFO - 2016-12-02 22:14:38 --> Router Class Initialized
INFO - 2016-12-02 22:14:38 --> Output Class Initialized
INFO - 2016-12-02 22:14:38 --> Security Class Initialized
DEBUG - 2016-12-02 22:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 22:14:38 --> Input Class Initialized
INFO - 2016-12-02 22:14:38 --> Language Class Initialized
INFO - 2016-12-02 22:14:38 --> Loader Class Initialized
INFO - 2016-12-02 22:14:38 --> Helper loaded: url_helper
INFO - 2016-12-02 22:14:38 --> Helper loaded: form_helper
INFO - 2016-12-02 22:14:38 --> Database Driver Class Initialized
INFO - 2016-12-02 22:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 22:14:38 --> Controller Class Initialized
INFO - 2016-12-02 22:14:38 --> Model Class Initialized
INFO - 2016-12-02 22:14:38 --> Model Class Initialized
INFO - 2016-12-02 22:14:38 --> Model Class Initialized
INFO - 2016-12-02 22:14:38 --> Model Class Initialized
INFO - 2016-12-02 22:14:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 22:14:38 --> Pagination Class Initialized
INFO - 2016-12-02 22:14:38 --> Helper loaded: app_helper
DEBUG - 2016-12-02 22:14:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 22:14:38 --> Model Class Initialized
INFO - 2016-12-02 22:14:38 --> Final output sent to browser
DEBUG - 2016-12-02 22:14:38 --> Total execution time: 0.3644
INFO - 2016-12-02 22:14:38 --> Config Class Initialized
INFO - 2016-12-02 22:14:38 --> Hooks Class Initialized
DEBUG - 2016-12-02 22:14:38 --> UTF-8 Support Enabled
INFO - 2016-12-02 22:14:38 --> Utf8 Class Initialized
INFO - 2016-12-02 22:14:38 --> URI Class Initialized
DEBUG - 2016-12-02 22:14:38 --> No URI present. Default controller set.
INFO - 2016-12-02 22:14:38 --> Router Class Initialized
INFO - 2016-12-02 22:14:38 --> Output Class Initialized
INFO - 2016-12-02 22:14:38 --> Security Class Initialized
DEBUG - 2016-12-02 22:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 22:14:38 --> Input Class Initialized
INFO - 2016-12-02 22:14:38 --> Language Class Initialized
INFO - 2016-12-02 22:14:38 --> Loader Class Initialized
INFO - 2016-12-02 22:14:38 --> Helper loaded: url_helper
INFO - 2016-12-02 22:14:38 --> Helper loaded: form_helper
INFO - 2016-12-02 22:14:38 --> Database Driver Class Initialized
INFO - 2016-12-02 22:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 22:14:38 --> Controller Class Initialized
INFO - 2016-12-02 22:14:38 --> Model Class Initialized
INFO - 2016-12-02 22:14:39 --> Model Class Initialized
INFO - 2016-12-02 22:14:39 --> Model Class Initialized
INFO - 2016-12-02 22:14:39 --> Model Class Initialized
INFO - 2016-12-02 22:14:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 22:14:39 --> Pagination Class Initialized
INFO - 2016-12-02 22:14:39 --> Helper loaded: app_helper
INFO - 2016-12-02 22:14:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 22:14:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 22:14:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 22:14:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 22:14:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 22:14:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 22:14:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 22:14:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 22:14:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 22:14:39 --> Final output sent to browser
DEBUG - 2016-12-02 22:14:39 --> Total execution time: 0.4861
INFO - 2016-12-02 22:16:21 --> Config Class Initialized
INFO - 2016-12-02 22:16:21 --> Hooks Class Initialized
DEBUG - 2016-12-02 22:16:21 --> UTF-8 Support Enabled
INFO - 2016-12-02 22:16:21 --> Utf8 Class Initialized
INFO - 2016-12-02 22:16:21 --> URI Class Initialized
INFO - 2016-12-02 22:16:21 --> Router Class Initialized
INFO - 2016-12-02 22:16:21 --> Output Class Initialized
INFO - 2016-12-02 22:16:21 --> Security Class Initialized
DEBUG - 2016-12-02 22:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 22:16:21 --> Input Class Initialized
INFO - 2016-12-02 22:16:21 --> Language Class Initialized
INFO - 2016-12-02 22:16:21 --> Loader Class Initialized
INFO - 2016-12-02 22:16:21 --> Helper loaded: url_helper
INFO - 2016-12-02 22:16:21 --> Helper loaded: form_helper
INFO - 2016-12-02 22:16:21 --> Database Driver Class Initialized
INFO - 2016-12-02 22:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 22:16:21 --> Controller Class Initialized
INFO - 2016-12-02 22:16:21 --> Model Class Initialized
INFO - 2016-12-02 22:16:21 --> Form Validation Class Initialized
INFO - 2016-12-02 22:16:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 22:16:21 --> Pagination Class Initialized
INFO - 2016-12-02 22:16:21 --> Helper loaded: app_helper
INFO - 2016-12-02 22:16:21 --> Email Class Initialized
ERROR - 2016-12-02 22:16:21 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 24
ERROR - 2016-12-02 22:16:21 --> Severity: Error --> Call to a member function row() on null C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 24
INFO - 2016-12-02 22:49:53 --> Config Class Initialized
INFO - 2016-12-02 22:49:53 --> Hooks Class Initialized
DEBUG - 2016-12-02 22:49:53 --> UTF-8 Support Enabled
INFO - 2016-12-02 22:49:53 --> Utf8 Class Initialized
INFO - 2016-12-02 22:49:53 --> URI Class Initialized
INFO - 2016-12-02 22:49:53 --> Router Class Initialized
INFO - 2016-12-02 22:49:53 --> Output Class Initialized
INFO - 2016-12-02 22:49:53 --> Security Class Initialized
DEBUG - 2016-12-02 22:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 22:49:53 --> Input Class Initialized
INFO - 2016-12-02 22:49:53 --> Language Class Initialized
INFO - 2016-12-02 22:49:53 --> Loader Class Initialized
INFO - 2016-12-02 22:49:53 --> Helper loaded: url_helper
INFO - 2016-12-02 22:49:53 --> Helper loaded: form_helper
INFO - 2016-12-02 22:49:53 --> Database Driver Class Initialized
INFO - 2016-12-02 22:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 22:49:53 --> Controller Class Initialized
INFO - 2016-12-02 22:49:54 --> Model Class Initialized
INFO - 2016-12-02 22:49:54 --> Form Validation Class Initialized
INFO - 2016-12-02 22:49:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 22:49:54 --> Pagination Class Initialized
INFO - 2016-12-02 22:49:54 --> Helper loaded: app_helper
INFO - 2016-12-02 22:49:54 --> Email Class Initialized
ERROR - 2016-12-02 22:49:54 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 24
ERROR - 2016-12-02 22:49:54 --> Severity: Error --> Call to a member function row() on null C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 24
INFO - 2016-12-02 22:50:15 --> Config Class Initialized
INFO - 2016-12-02 22:50:15 --> Hooks Class Initialized
DEBUG - 2016-12-02 22:50:15 --> UTF-8 Support Enabled
INFO - 2016-12-02 22:50:15 --> Utf8 Class Initialized
INFO - 2016-12-02 22:50:15 --> URI Class Initialized
INFO - 2016-12-02 22:50:15 --> Router Class Initialized
INFO - 2016-12-02 22:50:15 --> Output Class Initialized
INFO - 2016-12-02 22:50:15 --> Security Class Initialized
DEBUG - 2016-12-02 22:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 22:50:15 --> Input Class Initialized
INFO - 2016-12-02 22:50:15 --> Language Class Initialized
INFO - 2016-12-02 22:50:15 --> Loader Class Initialized
INFO - 2016-12-02 22:50:15 --> Helper loaded: url_helper
INFO - 2016-12-02 22:50:15 --> Helper loaded: form_helper
INFO - 2016-12-02 22:50:15 --> Database Driver Class Initialized
INFO - 2016-12-02 22:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 22:50:15 --> Controller Class Initialized
INFO - 2016-12-02 22:50:15 --> Model Class Initialized
INFO - 2016-12-02 22:50:15 --> Form Validation Class Initialized
INFO - 2016-12-02 22:50:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 22:50:15 --> Pagination Class Initialized
INFO - 2016-12-02 22:50:16 --> Helper loaded: app_helper
INFO - 2016-12-02 22:50:16 --> Email Class Initialized
ERROR - 2016-12-02 22:50:16 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 24
ERROR - 2016-12-02 22:50:16 --> Severity: Error --> Call to a member function row() on null C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 24
INFO - 2016-12-02 22:56:47 --> Config Class Initialized
INFO - 2016-12-02 22:56:47 --> Hooks Class Initialized
DEBUG - 2016-12-02 22:56:47 --> UTF-8 Support Enabled
INFO - 2016-12-02 22:56:47 --> Utf8 Class Initialized
INFO - 2016-12-02 22:56:47 --> URI Class Initialized
INFO - 2016-12-02 22:56:47 --> Router Class Initialized
INFO - 2016-12-02 22:56:47 --> Output Class Initialized
INFO - 2016-12-02 22:56:47 --> Security Class Initialized
DEBUG - 2016-12-02 22:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 22:56:47 --> Input Class Initialized
INFO - 2016-12-02 22:56:47 --> Language Class Initialized
INFO - 2016-12-02 22:56:47 --> Loader Class Initialized
INFO - 2016-12-02 22:56:47 --> Helper loaded: url_helper
INFO - 2016-12-02 22:56:48 --> Helper loaded: form_helper
INFO - 2016-12-02 22:56:48 --> Database Driver Class Initialized
INFO - 2016-12-02 22:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 22:56:48 --> Controller Class Initialized
INFO - 2016-12-02 22:56:48 --> Model Class Initialized
INFO - 2016-12-02 22:56:48 --> Form Validation Class Initialized
INFO - 2016-12-02 22:56:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 22:56:48 --> Pagination Class Initialized
INFO - 2016-12-02 22:56:48 --> Helper loaded: app_helper
INFO - 2016-12-02 22:56:48 --> Email Class Initialized
ERROR - 2016-12-02 22:56:48 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2016-12-02 22:56:48 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-02 22:56:52 --> Config Class Initialized
INFO - 2016-12-02 22:56:52 --> Hooks Class Initialized
DEBUG - 2016-12-02 22:56:52 --> UTF-8 Support Enabled
INFO - 2016-12-02 22:56:52 --> Utf8 Class Initialized
INFO - 2016-12-02 22:56:52 --> URI Class Initialized
INFO - 2016-12-02 22:56:52 --> Router Class Initialized
INFO - 2016-12-02 22:56:52 --> Output Class Initialized
INFO - 2016-12-02 22:56:52 --> Security Class Initialized
DEBUG - 2016-12-02 22:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 22:56:52 --> Input Class Initialized
INFO - 2016-12-02 22:56:52 --> Language Class Initialized
INFO - 2016-12-02 22:56:52 --> Loader Class Initialized
INFO - 2016-12-02 22:56:52 --> Helper loaded: url_helper
INFO - 2016-12-02 22:56:52 --> Helper loaded: form_helper
INFO - 2016-12-02 22:56:52 --> Database Driver Class Initialized
INFO - 2016-12-02 22:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 22:56:52 --> Controller Class Initialized
INFO - 2016-12-02 22:56:52 --> Model Class Initialized
INFO - 2016-12-02 22:56:52 --> Form Validation Class Initialized
INFO - 2016-12-02 22:56:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 22:56:52 --> Pagination Class Initialized
INFO - 2016-12-02 22:56:52 --> Helper loaded: app_helper
INFO - 2016-12-02 22:56:52 --> Email Class Initialized
ERROR - 2016-12-02 22:56:52 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2016-12-02 22:56:52 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-02 22:57:27 --> Config Class Initialized
INFO - 2016-12-02 22:57:27 --> Hooks Class Initialized
DEBUG - 2016-12-02 22:57:27 --> UTF-8 Support Enabled
INFO - 2016-12-02 22:57:27 --> Utf8 Class Initialized
INFO - 2016-12-02 22:57:27 --> URI Class Initialized
INFO - 2016-12-02 22:57:27 --> Router Class Initialized
INFO - 2016-12-02 22:57:27 --> Output Class Initialized
INFO - 2016-12-02 22:57:27 --> Security Class Initialized
DEBUG - 2016-12-02 22:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 22:57:27 --> Input Class Initialized
INFO - 2016-12-02 22:57:27 --> Language Class Initialized
INFO - 2016-12-02 22:57:27 --> Loader Class Initialized
INFO - 2016-12-02 22:57:27 --> Helper loaded: url_helper
INFO - 2016-12-02 22:57:27 --> Helper loaded: form_helper
INFO - 2016-12-02 22:57:27 --> Database Driver Class Initialized
INFO - 2016-12-02 22:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 22:57:27 --> Controller Class Initialized
INFO - 2016-12-02 22:57:27 --> Model Class Initialized
INFO - 2016-12-02 22:57:27 --> Form Validation Class Initialized
INFO - 2016-12-02 22:57:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 22:57:27 --> Pagination Class Initialized
INFO - 2016-12-02 22:57:27 --> Helper loaded: app_helper
INFO - 2016-12-02 22:57:27 --> Email Class Initialized
ERROR - 2016-12-02 22:57:27 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2016-12-02 22:57:27 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-02 22:57:29 --> Config Class Initialized
INFO - 2016-12-02 22:57:29 --> Hooks Class Initialized
DEBUG - 2016-12-02 22:57:29 --> UTF-8 Support Enabled
INFO - 2016-12-02 22:57:29 --> Utf8 Class Initialized
INFO - 2016-12-02 22:57:29 --> URI Class Initialized
INFO - 2016-12-02 22:57:29 --> Router Class Initialized
INFO - 2016-12-02 22:57:29 --> Output Class Initialized
INFO - 2016-12-02 22:57:29 --> Security Class Initialized
DEBUG - 2016-12-02 22:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 22:57:29 --> Input Class Initialized
INFO - 2016-12-02 22:57:29 --> Language Class Initialized
INFO - 2016-12-02 22:57:29 --> Loader Class Initialized
INFO - 2016-12-02 22:57:29 --> Helper loaded: url_helper
INFO - 2016-12-02 22:57:29 --> Helper loaded: form_helper
INFO - 2016-12-02 22:57:29 --> Database Driver Class Initialized
INFO - 2016-12-02 22:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 22:57:29 --> Controller Class Initialized
INFO - 2016-12-02 22:57:29 --> Model Class Initialized
INFO - 2016-12-02 22:57:29 --> Form Validation Class Initialized
INFO - 2016-12-02 22:57:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 22:57:29 --> Pagination Class Initialized
INFO - 2016-12-02 22:57:29 --> Helper loaded: app_helper
INFO - 2016-12-02 22:57:29 --> Email Class Initialized
ERROR - 2016-12-02 22:57:29 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2016-12-02 22:57:29 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-02 22:57:30 --> Config Class Initialized
INFO - 2016-12-02 22:57:30 --> Hooks Class Initialized
DEBUG - 2016-12-02 22:57:30 --> UTF-8 Support Enabled
INFO - 2016-12-02 22:57:30 --> Utf8 Class Initialized
INFO - 2016-12-02 22:57:30 --> URI Class Initialized
INFO - 2016-12-02 22:57:30 --> Router Class Initialized
INFO - 2016-12-02 22:57:30 --> Output Class Initialized
INFO - 2016-12-02 22:57:30 --> Security Class Initialized
DEBUG - 2016-12-02 22:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 22:57:30 --> Input Class Initialized
INFO - 2016-12-02 22:57:30 --> Language Class Initialized
INFO - 2016-12-02 22:57:30 --> Loader Class Initialized
INFO - 2016-12-02 22:57:30 --> Helper loaded: url_helper
INFO - 2016-12-02 22:57:30 --> Helper loaded: form_helper
INFO - 2016-12-02 22:57:30 --> Database Driver Class Initialized
INFO - 2016-12-02 22:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 22:57:30 --> Controller Class Initialized
INFO - 2016-12-02 22:57:30 --> Model Class Initialized
INFO - 2016-12-02 22:57:30 --> Form Validation Class Initialized
INFO - 2016-12-02 22:57:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 22:57:30 --> Pagination Class Initialized
INFO - 2016-12-02 22:57:30 --> Helper loaded: app_helper
INFO - 2016-12-02 22:57:30 --> Email Class Initialized
ERROR - 2016-12-02 22:57:30 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2016-12-02 22:57:30 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-02 23:00:08 --> Config Class Initialized
INFO - 2016-12-02 23:00:08 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:00:08 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:00:08 --> Utf8 Class Initialized
INFO - 2016-12-02 23:00:08 --> URI Class Initialized
INFO - 2016-12-02 23:00:08 --> Router Class Initialized
INFO - 2016-12-02 23:00:08 --> Output Class Initialized
INFO - 2016-12-02 23:00:08 --> Security Class Initialized
DEBUG - 2016-12-02 23:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:00:08 --> Input Class Initialized
INFO - 2016-12-02 23:00:08 --> Language Class Initialized
INFO - 2016-12-02 23:00:08 --> Loader Class Initialized
INFO - 2016-12-02 23:00:08 --> Helper loaded: url_helper
INFO - 2016-12-02 23:00:08 --> Helper loaded: form_helper
INFO - 2016-12-02 23:00:08 --> Database Driver Class Initialized
INFO - 2016-12-02 23:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:00:08 --> Controller Class Initialized
INFO - 2016-12-02 23:00:08 --> Model Class Initialized
INFO - 2016-12-02 23:00:08 --> Form Validation Class Initialized
INFO - 2016-12-02 23:00:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:00:09 --> Pagination Class Initialized
INFO - 2016-12-02 23:00:09 --> Helper loaded: app_helper
INFO - 2016-12-02 23:00:09 --> Email Class Initialized
ERROR - 2016-12-02 23:00:09 --> Severity: Notice --> Object of class stdClass could not be converted to int C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 147
ERROR - 2016-12-02 23:00:09 --> Severity: Error --> Call to undefined method stdClass::result() C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 17
INFO - 2016-12-02 23:00:53 --> Config Class Initialized
INFO - 2016-12-02 23:00:53 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:00:53 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:00:53 --> Utf8 Class Initialized
INFO - 2016-12-02 23:00:53 --> URI Class Initialized
INFO - 2016-12-02 23:00:53 --> Router Class Initialized
INFO - 2016-12-02 23:00:53 --> Output Class Initialized
INFO - 2016-12-02 23:00:53 --> Security Class Initialized
DEBUG - 2016-12-02 23:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:00:53 --> Input Class Initialized
INFO - 2016-12-02 23:00:53 --> Language Class Initialized
INFO - 2016-12-02 23:00:53 --> Loader Class Initialized
INFO - 2016-12-02 23:00:53 --> Helper loaded: url_helper
INFO - 2016-12-02 23:00:53 --> Helper loaded: form_helper
INFO - 2016-12-02 23:00:53 --> Database Driver Class Initialized
INFO - 2016-12-02 23:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:00:53 --> Controller Class Initialized
INFO - 2016-12-02 23:00:53 --> Model Class Initialized
INFO - 2016-12-02 23:00:53 --> Form Validation Class Initialized
INFO - 2016-12-02 23:00:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:00:53 --> Pagination Class Initialized
INFO - 2016-12-02 23:00:54 --> Helper loaded: app_helper
INFO - 2016-12-02 23:00:54 --> Email Class Initialized
ERROR - 2016-12-02 23:00:54 --> Severity: Notice --> Object of class stdClass could not be converted to int C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 147
ERROR - 2016-12-02 23:00:54 --> Severity: Error --> Call to undefined method stdClass::result() C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 17
INFO - 2016-12-02 23:05:21 --> Config Class Initialized
INFO - 2016-12-02 23:05:21 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:05:21 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:05:21 --> Utf8 Class Initialized
INFO - 2016-12-02 23:05:21 --> URI Class Initialized
INFO - 2016-12-02 23:05:21 --> Router Class Initialized
INFO - 2016-12-02 23:05:21 --> Output Class Initialized
INFO - 2016-12-02 23:05:21 --> Security Class Initialized
DEBUG - 2016-12-02 23:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:05:21 --> Input Class Initialized
INFO - 2016-12-02 23:05:21 --> Language Class Initialized
INFO - 2016-12-02 23:05:21 --> Loader Class Initialized
INFO - 2016-12-02 23:05:21 --> Helper loaded: url_helper
INFO - 2016-12-02 23:05:21 --> Helper loaded: form_helper
INFO - 2016-12-02 23:05:21 --> Database Driver Class Initialized
INFO - 2016-12-02 23:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:05:21 --> Controller Class Initialized
INFO - 2016-12-02 23:05:21 --> Model Class Initialized
INFO - 2016-12-02 23:05:21 --> Form Validation Class Initialized
INFO - 2016-12-02 23:05:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:05:21 --> Pagination Class Initialized
INFO - 2016-12-02 23:05:21 --> Helper loaded: app_helper
INFO - 2016-12-02 23:05:21 --> Email Class Initialized
ERROR - 2016-12-02 23:05:21 --> Severity: Notice --> Object of class stdClass could not be converted to int C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 147
ERROR - 2016-12-02 23:05:21 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 17
ERROR - 2016-12-02 23:05:21 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 17
INFO - 2016-12-02 23:05:41 --> Config Class Initialized
INFO - 2016-12-02 23:05:41 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:05:41 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:05:41 --> Utf8 Class Initialized
INFO - 2016-12-02 23:05:41 --> URI Class Initialized
INFO - 2016-12-02 23:05:41 --> Router Class Initialized
INFO - 2016-12-02 23:05:41 --> Output Class Initialized
INFO - 2016-12-02 23:05:41 --> Security Class Initialized
DEBUG - 2016-12-02 23:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:05:41 --> Input Class Initialized
INFO - 2016-12-02 23:05:41 --> Language Class Initialized
INFO - 2016-12-02 23:05:41 --> Loader Class Initialized
INFO - 2016-12-02 23:05:41 --> Helper loaded: url_helper
INFO - 2016-12-02 23:05:42 --> Helper loaded: form_helper
INFO - 2016-12-02 23:05:42 --> Database Driver Class Initialized
INFO - 2016-12-02 23:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:05:42 --> Controller Class Initialized
INFO - 2016-12-02 23:05:42 --> Model Class Initialized
INFO - 2016-12-02 23:05:42 --> Form Validation Class Initialized
INFO - 2016-12-02 23:05:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:05:42 --> Pagination Class Initialized
INFO - 2016-12-02 23:05:42 --> Helper loaded: app_helper
INFO - 2016-12-02 23:05:42 --> Email Class Initialized
ERROR - 2016-12-02 23:05:42 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 17
ERROR - 2016-12-02 23:05:42 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 17
INFO - 2016-12-02 23:06:04 --> Config Class Initialized
INFO - 2016-12-02 23:06:04 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:06:04 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:06:04 --> Utf8 Class Initialized
INFO - 2016-12-02 23:06:04 --> URI Class Initialized
INFO - 2016-12-02 23:06:04 --> Router Class Initialized
INFO - 2016-12-02 23:06:04 --> Output Class Initialized
INFO - 2016-12-02 23:06:04 --> Security Class Initialized
DEBUG - 2016-12-02 23:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:06:04 --> Input Class Initialized
INFO - 2016-12-02 23:06:04 --> Language Class Initialized
INFO - 2016-12-02 23:06:04 --> Loader Class Initialized
INFO - 2016-12-02 23:06:04 --> Helper loaded: url_helper
INFO - 2016-12-02 23:06:04 --> Helper loaded: form_helper
INFO - 2016-12-02 23:06:04 --> Database Driver Class Initialized
INFO - 2016-12-02 23:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:06:04 --> Controller Class Initialized
INFO - 2016-12-02 23:06:04 --> Model Class Initialized
INFO - 2016-12-02 23:06:04 --> Form Validation Class Initialized
INFO - 2016-12-02 23:06:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:06:04 --> Pagination Class Initialized
INFO - 2016-12-02 23:06:04 --> Helper loaded: app_helper
INFO - 2016-12-02 23:06:04 --> Email Class Initialized
ERROR - 2016-12-02 23:06:04 --> Severity: Error --> Call to undefined method stdClass::result() C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 17
INFO - 2016-12-02 23:06:47 --> Config Class Initialized
INFO - 2016-12-02 23:06:47 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:06:47 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:06:48 --> Utf8 Class Initialized
INFO - 2016-12-02 23:06:48 --> URI Class Initialized
INFO - 2016-12-02 23:06:48 --> Router Class Initialized
INFO - 2016-12-02 23:06:48 --> Output Class Initialized
INFO - 2016-12-02 23:06:48 --> Security Class Initialized
DEBUG - 2016-12-02 23:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:06:48 --> Input Class Initialized
INFO - 2016-12-02 23:06:48 --> Language Class Initialized
INFO - 2016-12-02 23:06:48 --> Loader Class Initialized
INFO - 2016-12-02 23:06:48 --> Helper loaded: url_helper
INFO - 2016-12-02 23:06:48 --> Helper loaded: form_helper
INFO - 2016-12-02 23:06:48 --> Database Driver Class Initialized
INFO - 2016-12-02 23:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:06:48 --> Controller Class Initialized
INFO - 2016-12-02 23:06:48 --> Model Class Initialized
INFO - 2016-12-02 23:06:48 --> Form Validation Class Initialized
INFO - 2016-12-02 23:06:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:06:48 --> Pagination Class Initialized
INFO - 2016-12-02 23:06:48 --> Helper loaded: app_helper
INFO - 2016-12-02 23:06:48 --> Email Class Initialized
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 21
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 22
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 23
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 25
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 36
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 21
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 22
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 23
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 25
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 36
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 21
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 22
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 23
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 25
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 36
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 21
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 22
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 23
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 25
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 36
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 21
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 22
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 23
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 25
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 36
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 21
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 22
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 23
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 25
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 36
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 21
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 22
ERROR - 2016-12-02 23:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 23
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 25
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 36
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 21
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 22
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 23
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 25
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 36
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 21
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 22
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 23
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 25
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 36
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 21
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 22
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 23
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 25
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 36
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 21
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 22
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 23
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 25
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 36
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 21
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 22
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 23
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 25
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
ERROR - 2016-12-02 23:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 36
INFO - 2016-12-02 23:06:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:06:49 --> Final output sent to browser
DEBUG - 2016-12-02 23:06:49 --> Total execution time: 1.6349
INFO - 2016-12-02 23:08:58 --> Config Class Initialized
INFO - 2016-12-02 23:08:58 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:08:58 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:08:58 --> Utf8 Class Initialized
INFO - 2016-12-02 23:08:58 --> URI Class Initialized
INFO - 2016-12-02 23:08:58 --> Router Class Initialized
INFO - 2016-12-02 23:08:58 --> Output Class Initialized
INFO - 2016-12-02 23:08:58 --> Security Class Initialized
DEBUG - 2016-12-02 23:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:08:58 --> Input Class Initialized
INFO - 2016-12-02 23:08:58 --> Language Class Initialized
INFO - 2016-12-02 23:08:58 --> Loader Class Initialized
INFO - 2016-12-02 23:08:58 --> Helper loaded: url_helper
INFO - 2016-12-02 23:08:58 --> Helper loaded: form_helper
INFO - 2016-12-02 23:08:58 --> Database Driver Class Initialized
INFO - 2016-12-02 23:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:08:58 --> Controller Class Initialized
INFO - 2016-12-02 23:08:58 --> Model Class Initialized
INFO - 2016-12-02 23:08:58 --> Form Validation Class Initialized
INFO - 2016-12-02 23:08:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:08:59 --> Pagination Class Initialized
INFO - 2016-12-02 23:08:59 --> Helper loaded: app_helper
INFO - 2016-12-02 23:08:59 --> Email Class Initialized
ERROR - 2016-12-02 23:08:59 --> Severity: Error --> Call to a member function result() on array C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 17
INFO - 2016-12-02 23:09:14 --> Config Class Initialized
INFO - 2016-12-02 23:09:14 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:09:14 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:09:14 --> Utf8 Class Initialized
INFO - 2016-12-02 23:09:14 --> URI Class Initialized
INFO - 2016-12-02 23:09:14 --> Router Class Initialized
INFO - 2016-12-02 23:09:15 --> Output Class Initialized
INFO - 2016-12-02 23:09:15 --> Security Class Initialized
DEBUG - 2016-12-02 23:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:09:15 --> Input Class Initialized
INFO - 2016-12-02 23:09:15 --> Language Class Initialized
INFO - 2016-12-02 23:09:15 --> Loader Class Initialized
INFO - 2016-12-02 23:09:15 --> Helper loaded: url_helper
INFO - 2016-12-02 23:09:15 --> Helper loaded: form_helper
INFO - 2016-12-02 23:09:15 --> Database Driver Class Initialized
INFO - 2016-12-02 23:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:09:15 --> Controller Class Initialized
INFO - 2016-12-02 23:09:15 --> Model Class Initialized
INFO - 2016-12-02 23:09:15 --> Form Validation Class Initialized
INFO - 2016-12-02 23:09:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:09:15 --> Pagination Class Initialized
INFO - 2016-12-02 23:09:15 --> Helper loaded: app_helper
INFO - 2016-12-02 23:09:15 --> Email Class Initialized
ERROR - 2016-12-02 23:09:15 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 23:09:15 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 23:09:15 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
INFO - 2016-12-02 23:09:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:09:15 --> Final output sent to browser
DEBUG - 2016-12-02 23:09:15 --> Total execution time: 0.4185
INFO - 2016-12-02 23:12:55 --> Config Class Initialized
INFO - 2016-12-02 23:12:55 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:12:55 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:12:55 --> Utf8 Class Initialized
INFO - 2016-12-02 23:12:55 --> URI Class Initialized
INFO - 2016-12-02 23:12:56 --> Router Class Initialized
INFO - 2016-12-02 23:12:56 --> Output Class Initialized
INFO - 2016-12-02 23:12:56 --> Security Class Initialized
DEBUG - 2016-12-02 23:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:12:56 --> Input Class Initialized
INFO - 2016-12-02 23:12:56 --> Language Class Initialized
INFO - 2016-12-02 23:12:56 --> Loader Class Initialized
INFO - 2016-12-02 23:12:56 --> Helper loaded: url_helper
INFO - 2016-12-02 23:12:56 --> Helper loaded: form_helper
INFO - 2016-12-02 23:12:56 --> Database Driver Class Initialized
INFO - 2016-12-02 23:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:12:56 --> Controller Class Initialized
INFO - 2016-12-02 23:12:56 --> Model Class Initialized
INFO - 2016-12-02 23:12:56 --> Form Validation Class Initialized
INFO - 2016-12-02 23:12:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:12:56 --> Pagination Class Initialized
INFO - 2016-12-02 23:12:56 --> Helper loaded: app_helper
INFO - 2016-12-02 23:12:56 --> Email Class Initialized
ERROR - 2016-12-02 23:12:56 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 23:12:56 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 23:12:56 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
INFO - 2016-12-02 23:12:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:12:56 --> Final output sent to browser
DEBUG - 2016-12-02 23:12:56 --> Total execution time: 0.5279
INFO - 2016-12-02 23:13:52 --> Config Class Initialized
INFO - 2016-12-02 23:13:52 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:13:52 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:13:52 --> Utf8 Class Initialized
INFO - 2016-12-02 23:13:52 --> URI Class Initialized
INFO - 2016-12-02 23:13:52 --> Router Class Initialized
INFO - 2016-12-02 23:13:52 --> Output Class Initialized
INFO - 2016-12-02 23:13:52 --> Security Class Initialized
DEBUG - 2016-12-02 23:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:13:52 --> Input Class Initialized
INFO - 2016-12-02 23:13:52 --> Language Class Initialized
INFO - 2016-12-02 23:13:52 --> Loader Class Initialized
INFO - 2016-12-02 23:13:52 --> Helper loaded: url_helper
INFO - 2016-12-02 23:13:52 --> Helper loaded: form_helper
INFO - 2016-12-02 23:13:52 --> Database Driver Class Initialized
INFO - 2016-12-02 23:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:13:52 --> Controller Class Initialized
INFO - 2016-12-02 23:13:52 --> Model Class Initialized
INFO - 2016-12-02 23:13:52 --> Form Validation Class Initialized
INFO - 2016-12-02 23:13:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:13:52 --> Pagination Class Initialized
INFO - 2016-12-02 23:13:52 --> Helper loaded: app_helper
INFO - 2016-12-02 23:13:52 --> Email Class Initialized
ERROR - 2016-12-02 23:13:52 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 23:13:52 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 23:13:52 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
INFO - 2016-12-02 23:13:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:13:52 --> Final output sent to browser
DEBUG - 2016-12-02 23:13:52 --> Total execution time: 0.4472
INFO - 2016-12-02 23:13:56 --> Config Class Initialized
INFO - 2016-12-02 23:13:56 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:13:56 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:13:56 --> Utf8 Class Initialized
INFO - 2016-12-02 23:13:56 --> URI Class Initialized
INFO - 2016-12-02 23:13:56 --> Router Class Initialized
INFO - 2016-12-02 23:13:56 --> Output Class Initialized
INFO - 2016-12-02 23:13:56 --> Security Class Initialized
DEBUG - 2016-12-02 23:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:13:56 --> Input Class Initialized
INFO - 2016-12-02 23:13:56 --> Language Class Initialized
INFO - 2016-12-02 23:13:56 --> Loader Class Initialized
INFO - 2016-12-02 23:13:56 --> Helper loaded: url_helper
INFO - 2016-12-02 23:13:56 --> Helper loaded: form_helper
INFO - 2016-12-02 23:13:56 --> Database Driver Class Initialized
INFO - 2016-12-02 23:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:13:56 --> Controller Class Initialized
INFO - 2016-12-02 23:13:56 --> Model Class Initialized
INFO - 2016-12-02 23:13:56 --> Form Validation Class Initialized
INFO - 2016-12-02 23:13:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:13:56 --> Pagination Class Initialized
INFO - 2016-12-02 23:13:56 --> Helper loaded: app_helper
INFO - 2016-12-02 23:13:56 --> Email Class Initialized
ERROR - 2016-12-02 23:13:56 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 23:13:56 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 23:13:56 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
INFO - 2016-12-02 23:13:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:13:56 --> Final output sent to browser
DEBUG - 2016-12-02 23:13:56 --> Total execution time: 0.4648
INFO - 2016-12-02 23:14:06 --> Config Class Initialized
INFO - 2016-12-02 23:14:06 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:14:06 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:14:06 --> Utf8 Class Initialized
INFO - 2016-12-02 23:14:06 --> URI Class Initialized
INFO - 2016-12-02 23:14:06 --> Router Class Initialized
INFO - 2016-12-02 23:14:06 --> Output Class Initialized
INFO - 2016-12-02 23:14:06 --> Security Class Initialized
DEBUG - 2016-12-02 23:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:14:07 --> Input Class Initialized
INFO - 2016-12-02 23:14:07 --> Language Class Initialized
INFO - 2016-12-02 23:14:07 --> Loader Class Initialized
INFO - 2016-12-02 23:14:07 --> Helper loaded: url_helper
INFO - 2016-12-02 23:14:07 --> Helper loaded: form_helper
INFO - 2016-12-02 23:14:07 --> Database Driver Class Initialized
INFO - 2016-12-02 23:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:14:07 --> Controller Class Initialized
INFO - 2016-12-02 23:14:07 --> Model Class Initialized
INFO - 2016-12-02 23:14:07 --> Form Validation Class Initialized
INFO - 2016-12-02 23:14:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:14:07 --> Pagination Class Initialized
INFO - 2016-12-02 23:14:07 --> Helper loaded: app_helper
INFO - 2016-12-02 23:14:07 --> Email Class Initialized
ERROR - 2016-12-02 23:14:07 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 23:14:07 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 23:14:07 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
INFO - 2016-12-02 23:14:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:14:07 --> Final output sent to browser
DEBUG - 2016-12-02 23:14:07 --> Total execution time: 0.4680
INFO - 2016-12-02 23:14:23 --> Config Class Initialized
INFO - 2016-12-02 23:14:23 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:14:23 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:14:23 --> Utf8 Class Initialized
INFO - 2016-12-02 23:14:23 --> URI Class Initialized
INFO - 2016-12-02 23:14:23 --> Router Class Initialized
INFO - 2016-12-02 23:14:23 --> Output Class Initialized
INFO - 2016-12-02 23:14:23 --> Security Class Initialized
DEBUG - 2016-12-02 23:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:14:23 --> Input Class Initialized
INFO - 2016-12-02 23:14:23 --> Language Class Initialized
INFO - 2016-12-02 23:14:23 --> Loader Class Initialized
INFO - 2016-12-02 23:14:23 --> Helper loaded: url_helper
INFO - 2016-12-02 23:14:23 --> Helper loaded: form_helper
INFO - 2016-12-02 23:14:23 --> Database Driver Class Initialized
INFO - 2016-12-02 23:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:14:23 --> Controller Class Initialized
INFO - 2016-12-02 23:14:23 --> Model Class Initialized
INFO - 2016-12-02 23:14:23 --> Form Validation Class Initialized
INFO - 2016-12-02 23:14:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:14:23 --> Pagination Class Initialized
INFO - 2016-12-02 23:14:23 --> Helper loaded: app_helper
INFO - 2016-12-02 23:14:23 --> Email Class Initialized
ERROR - 2016-12-02 23:14:23 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 23:14:23 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 23:14:23 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
INFO - 2016-12-02 23:14:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:14:23 --> Final output sent to browser
DEBUG - 2016-12-02 23:14:23 --> Total execution time: 0.4316
INFO - 2016-12-02 23:14:25 --> Config Class Initialized
INFO - 2016-12-02 23:14:25 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:14:25 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:14:25 --> Utf8 Class Initialized
INFO - 2016-12-02 23:14:25 --> URI Class Initialized
INFO - 2016-12-02 23:14:25 --> Router Class Initialized
INFO - 2016-12-02 23:14:25 --> Output Class Initialized
INFO - 2016-12-02 23:14:25 --> Security Class Initialized
DEBUG - 2016-12-02 23:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:14:25 --> Input Class Initialized
INFO - 2016-12-02 23:14:25 --> Language Class Initialized
INFO - 2016-12-02 23:14:25 --> Loader Class Initialized
INFO - 2016-12-02 23:14:25 --> Helper loaded: url_helper
INFO - 2016-12-02 23:14:25 --> Helper loaded: form_helper
INFO - 2016-12-02 23:14:25 --> Database Driver Class Initialized
INFO - 2016-12-02 23:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:14:25 --> Controller Class Initialized
INFO - 2016-12-02 23:14:25 --> Model Class Initialized
INFO - 2016-12-02 23:14:25 --> Form Validation Class Initialized
INFO - 2016-12-02 23:14:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:14:25 --> Pagination Class Initialized
INFO - 2016-12-02 23:14:25 --> Helper loaded: app_helper
INFO - 2016-12-02 23:14:25 --> Email Class Initialized
ERROR - 2016-12-02 23:14:25 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 23:14:25 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 23:14:25 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
INFO - 2016-12-02 23:14:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:14:25 --> Final output sent to browser
DEBUG - 2016-12-02 23:14:25 --> Total execution time: 0.4780
INFO - 2016-12-02 23:15:43 --> Config Class Initialized
INFO - 2016-12-02 23:15:43 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:15:43 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:15:43 --> Utf8 Class Initialized
INFO - 2016-12-02 23:15:43 --> URI Class Initialized
INFO - 2016-12-02 23:15:43 --> Router Class Initialized
INFO - 2016-12-02 23:15:43 --> Output Class Initialized
INFO - 2016-12-02 23:15:43 --> Security Class Initialized
DEBUG - 2016-12-02 23:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:15:43 --> Input Class Initialized
INFO - 2016-12-02 23:15:43 --> Language Class Initialized
INFO - 2016-12-02 23:15:43 --> Loader Class Initialized
INFO - 2016-12-02 23:15:43 --> Helper loaded: url_helper
INFO - 2016-12-02 23:15:43 --> Helper loaded: form_helper
INFO - 2016-12-02 23:15:43 --> Database Driver Class Initialized
INFO - 2016-12-02 23:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:15:43 --> Controller Class Initialized
INFO - 2016-12-02 23:15:43 --> Model Class Initialized
INFO - 2016-12-02 23:15:43 --> Form Validation Class Initialized
INFO - 2016-12-02 23:15:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:15:43 --> Pagination Class Initialized
INFO - 2016-12-02 23:15:43 --> Helper loaded: app_helper
INFO - 2016-12-02 23:15:43 --> Email Class Initialized
ERROR - 2016-12-02 23:15:43 --> Severity: Notice --> Undefined property: stdClass::$idemployee C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 20
ERROR - 2016-12-02 23:15:43 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 23:15:43 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
INFO - 2016-12-02 23:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:15:43 --> Final output sent to browser
DEBUG - 2016-12-02 23:15:43 --> Total execution time: 0.4601
INFO - 2016-12-02 23:15:53 --> Config Class Initialized
INFO - 2016-12-02 23:15:54 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:15:54 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:15:54 --> Utf8 Class Initialized
INFO - 2016-12-02 23:15:54 --> URI Class Initialized
INFO - 2016-12-02 23:15:54 --> Router Class Initialized
INFO - 2016-12-02 23:15:54 --> Output Class Initialized
INFO - 2016-12-02 23:15:54 --> Security Class Initialized
DEBUG - 2016-12-02 23:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:15:54 --> Input Class Initialized
INFO - 2016-12-02 23:15:54 --> Language Class Initialized
INFO - 2016-12-02 23:15:54 --> Loader Class Initialized
INFO - 2016-12-02 23:15:54 --> Helper loaded: url_helper
INFO - 2016-12-02 23:15:54 --> Helper loaded: form_helper
INFO - 2016-12-02 23:15:54 --> Database Driver Class Initialized
INFO - 2016-12-02 23:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:15:54 --> Controller Class Initialized
INFO - 2016-12-02 23:15:54 --> Model Class Initialized
INFO - 2016-12-02 23:15:54 --> Form Validation Class Initialized
INFO - 2016-12-02 23:15:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:15:54 --> Pagination Class Initialized
INFO - 2016-12-02 23:15:54 --> Helper loaded: app_helper
INFO - 2016-12-02 23:15:54 --> Email Class Initialized
ERROR - 2016-12-02 23:15:54 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 24
ERROR - 2016-12-02 23:15:54 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
INFO - 2016-12-02 23:15:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:15:54 --> Final output sent to browser
DEBUG - 2016-12-02 23:15:54 --> Total execution time: 0.4296
INFO - 2016-12-02 23:30:20 --> Config Class Initialized
INFO - 2016-12-02 23:30:20 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:30:20 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:30:20 --> Utf8 Class Initialized
INFO - 2016-12-02 23:30:20 --> URI Class Initialized
INFO - 2016-12-02 23:30:20 --> Router Class Initialized
INFO - 2016-12-02 23:30:20 --> Output Class Initialized
INFO - 2016-12-02 23:30:20 --> Security Class Initialized
DEBUG - 2016-12-02 23:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:30:20 --> Input Class Initialized
INFO - 2016-12-02 23:30:20 --> Language Class Initialized
INFO - 2016-12-02 23:30:20 --> Loader Class Initialized
INFO - 2016-12-02 23:30:20 --> Helper loaded: url_helper
INFO - 2016-12-02 23:30:20 --> Helper loaded: form_helper
INFO - 2016-12-02 23:30:20 --> Database Driver Class Initialized
INFO - 2016-12-02 23:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:30:20 --> Controller Class Initialized
INFO - 2016-12-02 23:30:20 --> Model Class Initialized
INFO - 2016-12-02 23:30:20 --> Form Validation Class Initialized
INFO - 2016-12-02 23:30:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:30:20 --> Pagination Class Initialized
INFO - 2016-12-02 23:30:20 --> Helper loaded: app_helper
INFO - 2016-12-02 23:30:20 --> Email Class Initialized
ERROR - 2016-12-02 23:30:20 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result() C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 30
INFO - 2016-12-02 23:31:22 --> Config Class Initialized
INFO - 2016-12-02 23:31:22 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:31:22 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:31:22 --> Utf8 Class Initialized
INFO - 2016-12-02 23:31:22 --> URI Class Initialized
INFO - 2016-12-02 23:31:22 --> Router Class Initialized
INFO - 2016-12-02 23:31:22 --> Output Class Initialized
INFO - 2016-12-02 23:31:22 --> Security Class Initialized
DEBUG - 2016-12-02 23:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:31:22 --> Input Class Initialized
INFO - 2016-12-02 23:31:22 --> Language Class Initialized
INFO - 2016-12-02 23:31:22 --> Loader Class Initialized
INFO - 2016-12-02 23:31:22 --> Helper loaded: url_helper
INFO - 2016-12-02 23:31:22 --> Helper loaded: form_helper
INFO - 2016-12-02 23:31:22 --> Database Driver Class Initialized
INFO - 2016-12-02 23:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:31:23 --> Controller Class Initialized
INFO - 2016-12-02 23:31:23 --> Model Class Initialized
INFO - 2016-12-02 23:31:23 --> Form Validation Class Initialized
INFO - 2016-12-02 23:31:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:31:23 --> Pagination Class Initialized
INFO - 2016-12-02 23:31:23 --> Helper loaded: app_helper
INFO - 2016-12-02 23:31:23 --> Email Class Initialized
ERROR - 2016-12-02 23:31:23 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result() C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 29
INFO - 2016-12-02 23:32:16 --> Config Class Initialized
INFO - 2016-12-02 23:32:16 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:32:16 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:32:16 --> Utf8 Class Initialized
INFO - 2016-12-02 23:32:16 --> URI Class Initialized
INFO - 2016-12-02 23:32:16 --> Router Class Initialized
INFO - 2016-12-02 23:32:16 --> Output Class Initialized
INFO - 2016-12-02 23:32:16 --> Security Class Initialized
DEBUG - 2016-12-02 23:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:32:16 --> Input Class Initialized
INFO - 2016-12-02 23:32:16 --> Language Class Initialized
INFO - 2016-12-02 23:32:16 --> Loader Class Initialized
INFO - 2016-12-02 23:32:16 --> Helper loaded: url_helper
INFO - 2016-12-02 23:32:16 --> Helper loaded: form_helper
INFO - 2016-12-02 23:32:16 --> Database Driver Class Initialized
INFO - 2016-12-02 23:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:32:16 --> Controller Class Initialized
INFO - 2016-12-02 23:32:16 --> Model Class Initialized
INFO - 2016-12-02 23:32:16 --> Form Validation Class Initialized
INFO - 2016-12-02 23:32:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:32:16 --> Pagination Class Initialized
INFO - 2016-12-02 23:32:16 --> Helper loaded: app_helper
INFO - 2016-12-02 23:32:16 --> Email Class Initialized
ERROR - 2016-12-02 23:32:16 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
INFO - 2016-12-02 23:32:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:32:16 --> Final output sent to browser
DEBUG - 2016-12-02 23:32:16 --> Total execution time: 0.4479
INFO - 2016-12-02 23:32:35 --> Config Class Initialized
INFO - 2016-12-02 23:32:35 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:32:35 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:32:35 --> Utf8 Class Initialized
INFO - 2016-12-02 23:32:35 --> URI Class Initialized
INFO - 2016-12-02 23:32:35 --> Router Class Initialized
INFO - 2016-12-02 23:32:35 --> Output Class Initialized
INFO - 2016-12-02 23:32:36 --> Security Class Initialized
DEBUG - 2016-12-02 23:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:32:36 --> Input Class Initialized
INFO - 2016-12-02 23:32:36 --> Language Class Initialized
INFO - 2016-12-02 23:32:36 --> Loader Class Initialized
INFO - 2016-12-02 23:32:36 --> Helper loaded: url_helper
INFO - 2016-12-02 23:32:36 --> Helper loaded: form_helper
INFO - 2016-12-02 23:32:36 --> Database Driver Class Initialized
INFO - 2016-12-02 23:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:32:36 --> Controller Class Initialized
INFO - 2016-12-02 23:32:36 --> Model Class Initialized
INFO - 2016-12-02 23:32:36 --> Form Validation Class Initialized
INFO - 2016-12-02 23:32:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:32:36 --> Pagination Class Initialized
INFO - 2016-12-02 23:32:36 --> Helper loaded: app_helper
INFO - 2016-12-02 23:32:36 --> Email Class Initialized
ERROR - 2016-12-02 23:32:36 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
INFO - 2016-12-02 23:32:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:32:36 --> Final output sent to browser
DEBUG - 2016-12-02 23:32:36 --> Total execution time: 0.4357
INFO - 2016-12-02 23:34:10 --> Config Class Initialized
INFO - 2016-12-02 23:34:10 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:34:10 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:34:11 --> Utf8 Class Initialized
INFO - 2016-12-02 23:34:11 --> URI Class Initialized
INFO - 2016-12-02 23:34:11 --> Router Class Initialized
INFO - 2016-12-02 23:34:11 --> Output Class Initialized
INFO - 2016-12-02 23:34:11 --> Security Class Initialized
DEBUG - 2016-12-02 23:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:34:11 --> Input Class Initialized
INFO - 2016-12-02 23:34:11 --> Language Class Initialized
INFO - 2016-12-02 23:34:11 --> Loader Class Initialized
INFO - 2016-12-02 23:34:11 --> Helper loaded: url_helper
INFO - 2016-12-02 23:34:11 --> Helper loaded: form_helper
INFO - 2016-12-02 23:34:11 --> Database Driver Class Initialized
INFO - 2016-12-02 23:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:34:11 --> Controller Class Initialized
INFO - 2016-12-02 23:34:11 --> Model Class Initialized
INFO - 2016-12-02 23:34:11 --> Form Validation Class Initialized
INFO - 2016-12-02 23:34:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:34:11 --> Pagination Class Initialized
INFO - 2016-12-02 23:34:11 --> Helper loaded: app_helper
INFO - 2016-12-02 23:34:11 --> Email Class Initialized
INFO - 2016-12-02 23:34:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
ERROR - 2016-12-02 23:34:11 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
INFO - 2016-12-02 23:34:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:34:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:34:11 --> Final output sent to browser
DEBUG - 2016-12-02 23:34:11 --> Total execution time: 0.4592
INFO - 2016-12-02 23:37:53 --> Config Class Initialized
INFO - 2016-12-02 23:37:53 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:37:53 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:37:53 --> Utf8 Class Initialized
INFO - 2016-12-02 23:37:53 --> URI Class Initialized
INFO - 2016-12-02 23:37:53 --> Router Class Initialized
INFO - 2016-12-02 23:37:53 --> Output Class Initialized
INFO - 2016-12-02 23:37:53 --> Security Class Initialized
DEBUG - 2016-12-02 23:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:37:53 --> Input Class Initialized
INFO - 2016-12-02 23:37:53 --> Language Class Initialized
INFO - 2016-12-02 23:37:53 --> Loader Class Initialized
INFO - 2016-12-02 23:37:53 --> Helper loaded: url_helper
INFO - 2016-12-02 23:37:53 --> Helper loaded: form_helper
INFO - 2016-12-02 23:37:53 --> Database Driver Class Initialized
INFO - 2016-12-02 23:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:37:53 --> Controller Class Initialized
INFO - 2016-12-02 23:37:53 --> Model Class Initialized
INFO - 2016-12-02 23:37:53 --> Form Validation Class Initialized
INFO - 2016-12-02 23:37:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:37:53 --> Pagination Class Initialized
INFO - 2016-12-02 23:37:53 --> Helper loaded: app_helper
INFO - 2016-12-02 23:37:53 --> Email Class Initialized
INFO - 2016-12-02 23:37:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
ERROR - 2016-12-02 23:37:53 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
INFO - 2016-12-02 23:37:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:37:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:37:53 --> Final output sent to browser
DEBUG - 2016-12-02 23:37:53 --> Total execution time: 0.5285
INFO - 2016-12-02 23:38:06 --> Config Class Initialized
INFO - 2016-12-02 23:38:06 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:38:06 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:38:06 --> Utf8 Class Initialized
INFO - 2016-12-02 23:38:06 --> URI Class Initialized
INFO - 2016-12-02 23:38:06 --> Router Class Initialized
INFO - 2016-12-02 23:38:06 --> Output Class Initialized
INFO - 2016-12-02 23:38:06 --> Security Class Initialized
DEBUG - 2016-12-02 23:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:38:06 --> Input Class Initialized
INFO - 2016-12-02 23:38:06 --> Language Class Initialized
INFO - 2016-12-02 23:38:06 --> Loader Class Initialized
INFO - 2016-12-02 23:38:06 --> Helper loaded: url_helper
INFO - 2016-12-02 23:38:06 --> Helper loaded: form_helper
INFO - 2016-12-02 23:38:06 --> Database Driver Class Initialized
INFO - 2016-12-02 23:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:38:07 --> Controller Class Initialized
INFO - 2016-12-02 23:38:07 --> Model Class Initialized
INFO - 2016-12-02 23:38:07 --> Form Validation Class Initialized
INFO - 2016-12-02 23:38:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:38:07 --> Pagination Class Initialized
INFO - 2016-12-02 23:38:07 --> Helper loaded: app_helper
INFO - 2016-12-02 23:38:07 --> Email Class Initialized
INFO - 2016-12-02 23:38:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
ERROR - 2016-12-02 23:38:07 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
INFO - 2016-12-02 23:38:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:38:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:38:07 --> Final output sent to browser
DEBUG - 2016-12-02 23:38:07 --> Total execution time: 0.4854
INFO - 2016-12-02 23:38:18 --> Config Class Initialized
INFO - 2016-12-02 23:38:18 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:38:18 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:38:18 --> Utf8 Class Initialized
INFO - 2016-12-02 23:38:18 --> URI Class Initialized
INFO - 2016-12-02 23:38:18 --> Router Class Initialized
INFO - 2016-12-02 23:38:18 --> Output Class Initialized
INFO - 2016-12-02 23:38:18 --> Security Class Initialized
DEBUG - 2016-12-02 23:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:38:18 --> Input Class Initialized
INFO - 2016-12-02 23:38:18 --> Language Class Initialized
INFO - 2016-12-02 23:38:18 --> Loader Class Initialized
INFO - 2016-12-02 23:38:18 --> Helper loaded: url_helper
INFO - 2016-12-02 23:38:18 --> Helper loaded: form_helper
INFO - 2016-12-02 23:38:18 --> Database Driver Class Initialized
INFO - 2016-12-02 23:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:38:18 --> Controller Class Initialized
INFO - 2016-12-02 23:38:18 --> Model Class Initialized
INFO - 2016-12-02 23:38:19 --> Form Validation Class Initialized
INFO - 2016-12-02 23:38:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:38:19 --> Pagination Class Initialized
INFO - 2016-12-02 23:38:19 --> Helper loaded: app_helper
INFO - 2016-12-02 23:38:19 --> Email Class Initialized
INFO - 2016-12-02 23:38:19 --> Final output sent to browser
DEBUG - 2016-12-02 23:38:19 --> Total execution time: 0.3728
INFO - 2016-12-02 23:38:19 --> Config Class Initialized
INFO - 2016-12-02 23:38:19 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:38:19 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:38:19 --> Utf8 Class Initialized
INFO - 2016-12-02 23:38:19 --> URI Class Initialized
INFO - 2016-12-02 23:38:19 --> Router Class Initialized
INFO - 2016-12-02 23:38:19 --> Output Class Initialized
INFO - 2016-12-02 23:38:19 --> Security Class Initialized
DEBUG - 2016-12-02 23:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:38:19 --> Input Class Initialized
INFO - 2016-12-02 23:38:19 --> Language Class Initialized
INFO - 2016-12-02 23:38:19 --> Loader Class Initialized
INFO - 2016-12-02 23:38:19 --> Helper loaded: url_helper
INFO - 2016-12-02 23:38:19 --> Helper loaded: form_helper
INFO - 2016-12-02 23:38:19 --> Database Driver Class Initialized
INFO - 2016-12-02 23:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:38:19 --> Controller Class Initialized
INFO - 2016-12-02 23:38:19 --> Model Class Initialized
INFO - 2016-12-02 23:38:19 --> Form Validation Class Initialized
INFO - 2016-12-02 23:38:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:38:19 --> Pagination Class Initialized
INFO - 2016-12-02 23:38:19 --> Helper loaded: app_helper
INFO - 2016-12-02 23:38:19 --> Email Class Initialized
INFO - 2016-12-02 23:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
ERROR - 2016-12-02 23:38:19 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\manager\email_leave_applied.php 27
INFO - 2016-12-02 23:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:38:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:38:20 --> Final output sent to browser
DEBUG - 2016-12-02 23:38:20 --> Total execution time: 0.4115
INFO - 2016-12-02 23:38:39 --> Config Class Initialized
INFO - 2016-12-02 23:38:39 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:38:39 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:38:39 --> Utf8 Class Initialized
INFO - 2016-12-02 23:38:39 --> URI Class Initialized
DEBUG - 2016-12-02 23:38:39 --> No URI present. Default controller set.
INFO - 2016-12-02 23:38:39 --> Router Class Initialized
INFO - 2016-12-02 23:38:39 --> Output Class Initialized
INFO - 2016-12-02 23:38:39 --> Security Class Initialized
DEBUG - 2016-12-02 23:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:38:39 --> Input Class Initialized
INFO - 2016-12-02 23:38:39 --> Language Class Initialized
INFO - 2016-12-02 23:38:39 --> Loader Class Initialized
INFO - 2016-12-02 23:38:39 --> Helper loaded: url_helper
INFO - 2016-12-02 23:38:39 --> Helper loaded: form_helper
INFO - 2016-12-02 23:38:39 --> Database Driver Class Initialized
INFO - 2016-12-02 23:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:38:39 --> Controller Class Initialized
INFO - 2016-12-02 23:38:39 --> Model Class Initialized
INFO - 2016-12-02 23:38:39 --> Model Class Initialized
INFO - 2016-12-02 23:38:39 --> Model Class Initialized
INFO - 2016-12-02 23:38:39 --> Model Class Initialized
INFO - 2016-12-02 23:38:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:38:39 --> Pagination Class Initialized
INFO - 2016-12-02 23:38:39 --> Helper loaded: app_helper
INFO - 2016-12-02 23:38:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:38:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 23:38:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 23:38:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 23:38:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 23:38:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 23:38:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 23:38:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 23:38:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:38:40 --> Final output sent to browser
DEBUG - 2016-12-02 23:38:40 --> Total execution time: 0.6725
INFO - 2016-12-02 23:39:06 --> Config Class Initialized
INFO - 2016-12-02 23:39:06 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:39:06 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:39:06 --> Utf8 Class Initialized
INFO - 2016-12-02 23:39:06 --> URI Class Initialized
DEBUG - 2016-12-02 23:39:06 --> No URI present. Default controller set.
INFO - 2016-12-02 23:39:06 --> Router Class Initialized
INFO - 2016-12-02 23:39:06 --> Output Class Initialized
INFO - 2016-12-02 23:39:06 --> Security Class Initialized
DEBUG - 2016-12-02 23:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:39:06 --> Input Class Initialized
INFO - 2016-12-02 23:39:06 --> Language Class Initialized
INFO - 2016-12-02 23:39:06 --> Loader Class Initialized
INFO - 2016-12-02 23:39:06 --> Helper loaded: url_helper
INFO - 2016-12-02 23:39:06 --> Helper loaded: form_helper
INFO - 2016-12-02 23:39:06 --> Database Driver Class Initialized
INFO - 2016-12-02 23:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:39:06 --> Controller Class Initialized
INFO - 2016-12-02 23:39:06 --> Model Class Initialized
INFO - 2016-12-02 23:39:06 --> Model Class Initialized
INFO - 2016-12-02 23:39:06 --> Model Class Initialized
INFO - 2016-12-02 23:39:06 --> Model Class Initialized
INFO - 2016-12-02 23:39:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:39:06 --> Pagination Class Initialized
INFO - 2016-12-02 23:39:06 --> Helper loaded: app_helper
INFO - 2016-12-02 23:39:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:39:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 23:39:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 23:39:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 23:39:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 23:39:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 23:39:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 23:39:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 23:39:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:39:06 --> Final output sent to browser
DEBUG - 2016-12-02 23:39:06 --> Total execution time: 0.6037
INFO - 2016-12-02 23:39:31 --> Config Class Initialized
INFO - 2016-12-02 23:39:31 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:39:31 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:39:31 --> Utf8 Class Initialized
INFO - 2016-12-02 23:39:31 --> URI Class Initialized
DEBUG - 2016-12-02 23:39:31 --> No URI present. Default controller set.
INFO - 2016-12-02 23:39:31 --> Router Class Initialized
INFO - 2016-12-02 23:39:31 --> Output Class Initialized
INFO - 2016-12-02 23:39:31 --> Security Class Initialized
DEBUG - 2016-12-02 23:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:39:31 --> Input Class Initialized
INFO - 2016-12-02 23:39:31 --> Language Class Initialized
INFO - 2016-12-02 23:39:31 --> Loader Class Initialized
INFO - 2016-12-02 23:39:31 --> Helper loaded: url_helper
INFO - 2016-12-02 23:39:31 --> Helper loaded: form_helper
INFO - 2016-12-02 23:39:31 --> Database Driver Class Initialized
INFO - 2016-12-02 23:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:39:31 --> Controller Class Initialized
INFO - 2016-12-02 23:39:31 --> Model Class Initialized
INFO - 2016-12-02 23:39:31 --> Model Class Initialized
INFO - 2016-12-02 23:39:31 --> Model Class Initialized
INFO - 2016-12-02 23:39:31 --> Model Class Initialized
INFO - 2016-12-02 23:39:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:39:31 --> Pagination Class Initialized
INFO - 2016-12-02 23:39:31 --> Helper loaded: app_helper
INFO - 2016-12-02 23:39:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:39:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 23:39:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 23:39:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 23:39:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 23:39:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 23:39:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 23:39:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 23:39:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:39:32 --> Final output sent to browser
DEBUG - 2016-12-02 23:39:32 --> Total execution time: 0.5695
INFO - 2016-12-02 23:43:15 --> Config Class Initialized
INFO - 2016-12-02 23:43:15 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:43:15 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:43:15 --> Utf8 Class Initialized
INFO - 2016-12-02 23:43:15 --> URI Class Initialized
INFO - 2016-12-02 23:43:15 --> Router Class Initialized
INFO - 2016-12-02 23:43:15 --> Output Class Initialized
INFO - 2016-12-02 23:43:15 --> Security Class Initialized
DEBUG - 2016-12-02 23:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:43:15 --> Input Class Initialized
INFO - 2016-12-02 23:43:15 --> Language Class Initialized
INFO - 2016-12-02 23:43:15 --> Loader Class Initialized
INFO - 2016-12-02 23:43:16 --> Helper loaded: url_helper
INFO - 2016-12-02 23:43:16 --> Helper loaded: form_helper
INFO - 2016-12-02 23:43:16 --> Database Driver Class Initialized
INFO - 2016-12-02 23:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:43:16 --> Controller Class Initialized
INFO - 2016-12-02 23:43:16 --> Model Class Initialized
INFO - 2016-12-02 23:43:16 --> Form Validation Class Initialized
INFO - 2016-12-02 23:43:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:43:16 --> Pagination Class Initialized
INFO - 2016-12-02 23:43:16 --> Helper loaded: app_helper
INFO - 2016-12-02 23:43:16 --> Email Class Initialized
INFO - 2016-12-02 23:43:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:43:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:43:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:43:16 --> Final output sent to browser
DEBUG - 2016-12-02 23:43:16 --> Total execution time: 0.5224
INFO - 2016-12-02 23:43:20 --> Config Class Initialized
INFO - 2016-12-02 23:43:20 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:43:20 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:43:20 --> Utf8 Class Initialized
INFO - 2016-12-02 23:43:20 --> URI Class Initialized
INFO - 2016-12-02 23:43:20 --> Router Class Initialized
INFO - 2016-12-02 23:43:20 --> Output Class Initialized
INFO - 2016-12-02 23:43:20 --> Security Class Initialized
DEBUG - 2016-12-02 23:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:43:21 --> Input Class Initialized
INFO - 2016-12-02 23:43:21 --> Language Class Initialized
INFO - 2016-12-02 23:43:21 --> Loader Class Initialized
INFO - 2016-12-02 23:43:21 --> Helper loaded: url_helper
INFO - 2016-12-02 23:43:21 --> Helper loaded: form_helper
INFO - 2016-12-02 23:43:21 --> Database Driver Class Initialized
INFO - 2016-12-02 23:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:43:21 --> Controller Class Initialized
INFO - 2016-12-02 23:43:21 --> Model Class Initialized
INFO - 2016-12-02 23:43:21 --> Form Validation Class Initialized
INFO - 2016-12-02 23:43:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:43:21 --> Pagination Class Initialized
INFO - 2016-12-02 23:43:21 --> Helper loaded: app_helper
INFO - 2016-12-02 23:43:21 --> Email Class Initialized
INFO - 2016-12-02 23:43:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:43:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:43:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:43:21 --> Final output sent to browser
DEBUG - 2016-12-02 23:43:21 --> Total execution time: 0.4839
INFO - 2016-12-02 23:44:06 --> Config Class Initialized
INFO - 2016-12-02 23:44:06 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:44:06 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:44:06 --> Utf8 Class Initialized
INFO - 2016-12-02 23:44:06 --> URI Class Initialized
INFO - 2016-12-02 23:44:06 --> Router Class Initialized
INFO - 2016-12-02 23:44:06 --> Output Class Initialized
INFO - 2016-12-02 23:44:06 --> Security Class Initialized
DEBUG - 2016-12-02 23:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:44:06 --> Input Class Initialized
INFO - 2016-12-02 23:44:06 --> Language Class Initialized
INFO - 2016-12-02 23:44:06 --> Loader Class Initialized
INFO - 2016-12-02 23:44:06 --> Helper loaded: url_helper
INFO - 2016-12-02 23:44:06 --> Helper loaded: form_helper
INFO - 2016-12-02 23:44:06 --> Database Driver Class Initialized
INFO - 2016-12-02 23:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:44:06 --> Controller Class Initialized
INFO - 2016-12-02 23:44:06 --> Model Class Initialized
INFO - 2016-12-02 23:44:06 --> Form Validation Class Initialized
INFO - 2016-12-02 23:44:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:44:06 --> Pagination Class Initialized
INFO - 2016-12-02 23:44:06 --> Helper loaded: app_helper
INFO - 2016-12-02 23:44:06 --> Email Class Initialized
INFO - 2016-12-02 23:44:06 --> Final output sent to browser
DEBUG - 2016-12-02 23:44:06 --> Total execution time: 0.3838
INFO - 2016-12-02 23:44:06 --> Config Class Initialized
INFO - 2016-12-02 23:44:06 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:44:06 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:44:06 --> Utf8 Class Initialized
INFO - 2016-12-02 23:44:06 --> URI Class Initialized
INFO - 2016-12-02 23:44:06 --> Router Class Initialized
INFO - 2016-12-02 23:44:06 --> Output Class Initialized
INFO - 2016-12-02 23:44:07 --> Security Class Initialized
DEBUG - 2016-12-02 23:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:44:07 --> Input Class Initialized
INFO - 2016-12-02 23:44:07 --> Language Class Initialized
INFO - 2016-12-02 23:44:07 --> Loader Class Initialized
INFO - 2016-12-02 23:44:07 --> Helper loaded: url_helper
INFO - 2016-12-02 23:44:07 --> Helper loaded: form_helper
INFO - 2016-12-02 23:44:07 --> Database Driver Class Initialized
INFO - 2016-12-02 23:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:44:07 --> Controller Class Initialized
INFO - 2016-12-02 23:44:07 --> Model Class Initialized
INFO - 2016-12-02 23:44:07 --> Form Validation Class Initialized
INFO - 2016-12-02 23:44:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:44:07 --> Pagination Class Initialized
INFO - 2016-12-02 23:44:07 --> Helper loaded: app_helper
INFO - 2016-12-02 23:44:07 --> Email Class Initialized
INFO - 2016-12-02 23:44:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:44:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:44:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:44:07 --> Final output sent to browser
DEBUG - 2016-12-02 23:44:07 --> Total execution time: 0.4685
INFO - 2016-12-02 23:44:15 --> Config Class Initialized
INFO - 2016-12-02 23:44:15 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:44:15 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:44:15 --> Utf8 Class Initialized
INFO - 2016-12-02 23:44:15 --> URI Class Initialized
DEBUG - 2016-12-02 23:44:15 --> No URI present. Default controller set.
INFO - 2016-12-02 23:44:15 --> Router Class Initialized
INFO - 2016-12-02 23:44:15 --> Output Class Initialized
INFO - 2016-12-02 23:44:15 --> Security Class Initialized
DEBUG - 2016-12-02 23:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:44:15 --> Input Class Initialized
INFO - 2016-12-02 23:44:15 --> Language Class Initialized
INFO - 2016-12-02 23:44:15 --> Loader Class Initialized
INFO - 2016-12-02 23:44:15 --> Helper loaded: url_helper
INFO - 2016-12-02 23:44:15 --> Helper loaded: form_helper
INFO - 2016-12-02 23:44:15 --> Database Driver Class Initialized
INFO - 2016-12-02 23:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:44:15 --> Controller Class Initialized
INFO - 2016-12-02 23:44:15 --> Model Class Initialized
INFO - 2016-12-02 23:44:15 --> Model Class Initialized
INFO - 2016-12-02 23:44:15 --> Model Class Initialized
INFO - 2016-12-02 23:44:15 --> Model Class Initialized
INFO - 2016-12-02 23:44:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:44:15 --> Pagination Class Initialized
INFO - 2016-12-02 23:44:15 --> Helper loaded: app_helper
INFO - 2016-12-02 23:44:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:44:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 23:44:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 23:44:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 23:44:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 23:44:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 23:44:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 23:44:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 23:44:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:44:15 --> Final output sent to browser
DEBUG - 2016-12-02 23:44:15 --> Total execution time: 0.6079
INFO - 2016-12-02 23:44:20 --> Config Class Initialized
INFO - 2016-12-02 23:44:20 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:44:20 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:44:20 --> Utf8 Class Initialized
INFO - 2016-12-02 23:44:20 --> URI Class Initialized
DEBUG - 2016-12-02 23:44:20 --> No URI present. Default controller set.
INFO - 2016-12-02 23:44:20 --> Router Class Initialized
INFO - 2016-12-02 23:44:20 --> Output Class Initialized
INFO - 2016-12-02 23:44:20 --> Security Class Initialized
DEBUG - 2016-12-02 23:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:44:20 --> Input Class Initialized
INFO - 2016-12-02 23:44:20 --> Language Class Initialized
INFO - 2016-12-02 23:44:20 --> Loader Class Initialized
INFO - 2016-12-02 23:44:20 --> Helper loaded: url_helper
INFO - 2016-12-02 23:44:20 --> Helper loaded: form_helper
INFO - 2016-12-02 23:44:20 --> Database Driver Class Initialized
INFO - 2016-12-02 23:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:44:21 --> Controller Class Initialized
INFO - 2016-12-02 23:44:21 --> Model Class Initialized
INFO - 2016-12-02 23:44:21 --> Model Class Initialized
INFO - 2016-12-02 23:44:21 --> Model Class Initialized
INFO - 2016-12-02 23:44:21 --> Model Class Initialized
INFO - 2016-12-02 23:44:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:44:21 --> Pagination Class Initialized
INFO - 2016-12-02 23:44:21 --> Helper loaded: app_helper
INFO - 2016-12-02 23:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 23:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 23:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 23:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 23:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 23:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 23:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 23:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:44:21 --> Final output sent to browser
DEBUG - 2016-12-02 23:44:21 --> Total execution time: 0.6252
INFO - 2016-12-02 23:45:24 --> Config Class Initialized
INFO - 2016-12-02 23:45:24 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:45:24 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:45:24 --> Utf8 Class Initialized
INFO - 2016-12-02 23:45:24 --> URI Class Initialized
INFO - 2016-12-02 23:45:24 --> Router Class Initialized
INFO - 2016-12-02 23:45:24 --> Output Class Initialized
INFO - 2016-12-02 23:45:24 --> Security Class Initialized
DEBUG - 2016-12-02 23:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:45:25 --> Input Class Initialized
INFO - 2016-12-02 23:45:25 --> Language Class Initialized
INFO - 2016-12-02 23:45:25 --> Loader Class Initialized
INFO - 2016-12-02 23:45:25 --> Helper loaded: url_helper
INFO - 2016-12-02 23:45:25 --> Helper loaded: form_helper
INFO - 2016-12-02 23:45:25 --> Database Driver Class Initialized
INFO - 2016-12-02 23:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:45:25 --> Controller Class Initialized
INFO - 2016-12-02 23:45:25 --> Model Class Initialized
INFO - 2016-12-02 23:45:25 --> Form Validation Class Initialized
INFO - 2016-12-02 23:45:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:45:25 --> Pagination Class Initialized
INFO - 2016-12-02 23:45:25 --> Helper loaded: app_helper
INFO - 2016-12-02 23:45:25 --> Email Class Initialized
INFO - 2016-12-02 23:45:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:45:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:45:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:45:25 --> Final output sent to browser
DEBUG - 2016-12-02 23:45:25 --> Total execution time: 0.4609
INFO - 2016-12-02 23:45:52 --> Config Class Initialized
INFO - 2016-12-02 23:45:52 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:45:52 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:45:52 --> Utf8 Class Initialized
INFO - 2016-12-02 23:45:52 --> URI Class Initialized
INFO - 2016-12-02 23:45:52 --> Router Class Initialized
INFO - 2016-12-02 23:45:53 --> Output Class Initialized
INFO - 2016-12-02 23:45:53 --> Security Class Initialized
DEBUG - 2016-12-02 23:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:45:53 --> Input Class Initialized
INFO - 2016-12-02 23:45:53 --> Language Class Initialized
INFO - 2016-12-02 23:45:53 --> Loader Class Initialized
INFO - 2016-12-02 23:45:53 --> Helper loaded: url_helper
INFO - 2016-12-02 23:45:53 --> Helper loaded: form_helper
INFO - 2016-12-02 23:45:53 --> Database Driver Class Initialized
INFO - 2016-12-02 23:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:45:53 --> Controller Class Initialized
INFO - 2016-12-02 23:45:53 --> Model Class Initialized
INFO - 2016-12-02 23:45:53 --> Form Validation Class Initialized
INFO - 2016-12-02 23:45:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:45:53 --> Pagination Class Initialized
INFO - 2016-12-02 23:45:53 --> Helper loaded: app_helper
INFO - 2016-12-02 23:45:53 --> Email Class Initialized
INFO - 2016-12-02 23:45:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:45:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:45:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:45:53 --> Final output sent to browser
DEBUG - 2016-12-02 23:45:53 --> Total execution time: 0.5094
INFO - 2016-12-02 23:49:44 --> Config Class Initialized
INFO - 2016-12-02 23:49:44 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:49:44 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:49:44 --> Utf8 Class Initialized
INFO - 2016-12-02 23:49:44 --> URI Class Initialized
INFO - 2016-12-02 23:49:44 --> Router Class Initialized
INFO - 2016-12-02 23:49:44 --> Output Class Initialized
INFO - 2016-12-02 23:49:44 --> Security Class Initialized
DEBUG - 2016-12-02 23:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:49:44 --> Input Class Initialized
INFO - 2016-12-02 23:49:44 --> Language Class Initialized
INFO - 2016-12-02 23:49:44 --> Loader Class Initialized
INFO - 2016-12-02 23:49:44 --> Helper loaded: url_helper
INFO - 2016-12-02 23:49:44 --> Helper loaded: form_helper
INFO - 2016-12-02 23:49:44 --> Database Driver Class Initialized
INFO - 2016-12-02 23:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:49:44 --> Controller Class Initialized
INFO - 2016-12-02 23:49:44 --> Model Class Initialized
INFO - 2016-12-02 23:49:44 --> Form Validation Class Initialized
INFO - 2016-12-02 23:49:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:49:44 --> Pagination Class Initialized
INFO - 2016-12-02 23:49:44 --> Helper loaded: app_helper
INFO - 2016-12-02 23:49:44 --> Email Class Initialized
INFO - 2016-12-02 23:49:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:49:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:49:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:49:44 --> Final output sent to browser
DEBUG - 2016-12-02 23:49:44 --> Total execution time: 0.4912
INFO - 2016-12-02 23:49:58 --> Config Class Initialized
INFO - 2016-12-02 23:49:58 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:49:58 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:49:58 --> Utf8 Class Initialized
INFO - 2016-12-02 23:49:58 --> URI Class Initialized
INFO - 2016-12-02 23:49:58 --> Router Class Initialized
INFO - 2016-12-02 23:49:58 --> Output Class Initialized
INFO - 2016-12-02 23:49:58 --> Security Class Initialized
DEBUG - 2016-12-02 23:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:49:58 --> Input Class Initialized
INFO - 2016-12-02 23:49:58 --> Language Class Initialized
INFO - 2016-12-02 23:49:58 --> Loader Class Initialized
INFO - 2016-12-02 23:49:58 --> Helper loaded: url_helper
INFO - 2016-12-02 23:49:58 --> Helper loaded: form_helper
INFO - 2016-12-02 23:49:58 --> Database Driver Class Initialized
INFO - 2016-12-02 23:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:49:58 --> Controller Class Initialized
INFO - 2016-12-02 23:49:58 --> Model Class Initialized
INFO - 2016-12-02 23:49:58 --> Form Validation Class Initialized
INFO - 2016-12-02 23:49:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:49:58 --> Pagination Class Initialized
INFO - 2016-12-02 23:49:58 --> Helper loaded: app_helper
INFO - 2016-12-02 23:49:58 --> Email Class Initialized
INFO - 2016-12-02 23:49:58 --> Final output sent to browser
DEBUG - 2016-12-02 23:49:58 --> Total execution time: 0.3777
INFO - 2016-12-02 23:50:40 --> Config Class Initialized
INFO - 2016-12-02 23:50:40 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:50:40 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:50:40 --> Utf8 Class Initialized
INFO - 2016-12-02 23:50:40 --> URI Class Initialized
DEBUG - 2016-12-02 23:50:40 --> No URI present. Default controller set.
INFO - 2016-12-02 23:50:40 --> Router Class Initialized
INFO - 2016-12-02 23:50:40 --> Output Class Initialized
INFO - 2016-12-02 23:50:40 --> Security Class Initialized
DEBUG - 2016-12-02 23:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:50:40 --> Input Class Initialized
INFO - 2016-12-02 23:50:40 --> Language Class Initialized
INFO - 2016-12-02 23:50:40 --> Loader Class Initialized
INFO - 2016-12-02 23:50:40 --> Helper loaded: url_helper
INFO - 2016-12-02 23:50:40 --> Helper loaded: form_helper
INFO - 2016-12-02 23:50:40 --> Database Driver Class Initialized
INFO - 2016-12-02 23:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:50:40 --> Controller Class Initialized
INFO - 2016-12-02 23:50:40 --> Model Class Initialized
INFO - 2016-12-02 23:50:40 --> Model Class Initialized
INFO - 2016-12-02 23:50:40 --> Model Class Initialized
INFO - 2016-12-02 23:50:40 --> Model Class Initialized
INFO - 2016-12-02 23:50:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:50:40 --> Pagination Class Initialized
INFO - 2016-12-02 23:50:40 --> Helper loaded: app_helper
INFO - 2016-12-02 23:50:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:50:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 23:50:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 23:50:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 23:50:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 23:50:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 23:50:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 23:50:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 23:50:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:50:40 --> Final output sent to browser
DEBUG - 2016-12-02 23:50:40 --> Total execution time: 0.6070
INFO - 2016-12-02 23:50:57 --> Config Class Initialized
INFO - 2016-12-02 23:50:57 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:50:57 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:50:57 --> Utf8 Class Initialized
INFO - 2016-12-02 23:50:57 --> URI Class Initialized
INFO - 2016-12-02 23:50:57 --> Router Class Initialized
INFO - 2016-12-02 23:50:57 --> Output Class Initialized
INFO - 2016-12-02 23:50:57 --> Security Class Initialized
DEBUG - 2016-12-02 23:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:50:57 --> Input Class Initialized
INFO - 2016-12-02 23:50:57 --> Language Class Initialized
INFO - 2016-12-02 23:50:57 --> Loader Class Initialized
INFO - 2016-12-02 23:50:57 --> Helper loaded: url_helper
INFO - 2016-12-02 23:50:57 --> Helper loaded: form_helper
INFO - 2016-12-02 23:50:57 --> Database Driver Class Initialized
INFO - 2016-12-02 23:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:50:57 --> Controller Class Initialized
INFO - 2016-12-02 23:50:57 --> Model Class Initialized
INFO - 2016-12-02 23:50:57 --> Form Validation Class Initialized
INFO - 2016-12-02 23:50:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:50:57 --> Pagination Class Initialized
INFO - 2016-12-02 23:50:57 --> Helper loaded: app_helper
INFO - 2016-12-02 23:50:57 --> Email Class Initialized
INFO - 2016-12-02 23:50:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:50:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:50:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:50:57 --> Final output sent to browser
DEBUG - 2016-12-02 23:50:57 --> Total execution time: 0.4954
INFO - 2016-12-02 23:51:00 --> Config Class Initialized
INFO - 2016-12-02 23:51:00 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:51:00 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:51:00 --> Utf8 Class Initialized
INFO - 2016-12-02 23:51:00 --> URI Class Initialized
INFO - 2016-12-02 23:51:00 --> Router Class Initialized
INFO - 2016-12-02 23:51:00 --> Output Class Initialized
INFO - 2016-12-02 23:51:00 --> Security Class Initialized
DEBUG - 2016-12-02 23:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:51:00 --> Input Class Initialized
INFO - 2016-12-02 23:51:00 --> Language Class Initialized
INFO - 2016-12-02 23:51:00 --> Loader Class Initialized
INFO - 2016-12-02 23:51:00 --> Helper loaded: url_helper
INFO - 2016-12-02 23:51:00 --> Helper loaded: form_helper
INFO - 2016-12-02 23:51:00 --> Database Driver Class Initialized
INFO - 2016-12-02 23:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:51:00 --> Controller Class Initialized
INFO - 2016-12-02 23:51:00 --> Model Class Initialized
INFO - 2016-12-02 23:51:00 --> Form Validation Class Initialized
INFO - 2016-12-02 23:51:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:51:00 --> Pagination Class Initialized
INFO - 2016-12-02 23:51:00 --> Helper loaded: app_helper
INFO - 2016-12-02 23:51:00 --> Email Class Initialized
INFO - 2016-12-02 23:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:51:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:51:00 --> Final output sent to browser
DEBUG - 2016-12-02 23:51:00 --> Total execution time: 0.4858
INFO - 2016-12-02 23:51:53 --> Config Class Initialized
INFO - 2016-12-02 23:51:53 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:51:53 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:51:53 --> Utf8 Class Initialized
INFO - 2016-12-02 23:51:53 --> URI Class Initialized
INFO - 2016-12-02 23:51:53 --> Router Class Initialized
INFO - 2016-12-02 23:51:53 --> Output Class Initialized
INFO - 2016-12-02 23:51:53 --> Security Class Initialized
DEBUG - 2016-12-02 23:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:51:53 --> Input Class Initialized
INFO - 2016-12-02 23:51:53 --> Language Class Initialized
INFO - 2016-12-02 23:51:53 --> Loader Class Initialized
INFO - 2016-12-02 23:51:53 --> Helper loaded: url_helper
INFO - 2016-12-02 23:51:53 --> Helper loaded: form_helper
INFO - 2016-12-02 23:51:53 --> Database Driver Class Initialized
INFO - 2016-12-02 23:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:51:53 --> Controller Class Initialized
INFO - 2016-12-02 23:51:53 --> Model Class Initialized
INFO - 2016-12-02 23:51:53 --> Form Validation Class Initialized
INFO - 2016-12-02 23:51:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:51:53 --> Pagination Class Initialized
INFO - 2016-12-02 23:51:53 --> Helper loaded: app_helper
INFO - 2016-12-02 23:51:53 --> Email Class Initialized
ERROR - 2016-12-02 23:51:53 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-12-02 23:51:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-12-02 23:51:53 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-12-02 23:51:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 23:51:53 --> Final output sent to browser
DEBUG - 2016-12-02 23:51:53 --> Total execution time: 0.5607
INFO - 2016-12-02 23:51:54 --> Config Class Initialized
INFO - 2016-12-02 23:51:54 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:51:54 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:51:54 --> Utf8 Class Initialized
INFO - 2016-12-02 23:51:54 --> URI Class Initialized
DEBUG - 2016-12-02 23:51:54 --> No URI present. Default controller set.
INFO - 2016-12-02 23:51:54 --> Router Class Initialized
INFO - 2016-12-02 23:51:54 --> Output Class Initialized
INFO - 2016-12-02 23:51:54 --> Security Class Initialized
DEBUG - 2016-12-02 23:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:51:54 --> Input Class Initialized
INFO - 2016-12-02 23:51:54 --> Language Class Initialized
INFO - 2016-12-02 23:51:54 --> Loader Class Initialized
INFO - 2016-12-02 23:51:54 --> Helper loaded: url_helper
INFO - 2016-12-02 23:51:54 --> Helper loaded: form_helper
INFO - 2016-12-02 23:51:54 --> Database Driver Class Initialized
INFO - 2016-12-02 23:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:51:54 --> Controller Class Initialized
INFO - 2016-12-02 23:51:54 --> Model Class Initialized
INFO - 2016-12-02 23:51:54 --> Model Class Initialized
INFO - 2016-12-02 23:51:54 --> Model Class Initialized
INFO - 2016-12-02 23:51:54 --> Model Class Initialized
INFO - 2016-12-02 23:51:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:51:54 --> Pagination Class Initialized
INFO - 2016-12-02 23:51:54 --> Helper loaded: app_helper
INFO - 2016-12-02 23:51:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:51:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 23:51:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 23:51:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 23:51:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 23:51:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 23:51:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 23:51:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 23:51:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:51:54 --> Final output sent to browser
DEBUG - 2016-12-02 23:51:54 --> Total execution time: 0.5497
INFO - 2016-12-02 23:52:06 --> Config Class Initialized
INFO - 2016-12-02 23:52:06 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:52:06 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:52:06 --> Utf8 Class Initialized
INFO - 2016-12-02 23:52:06 --> URI Class Initialized
INFO - 2016-12-02 23:52:06 --> Router Class Initialized
INFO - 2016-12-02 23:52:06 --> Output Class Initialized
INFO - 2016-12-02 23:52:06 --> Security Class Initialized
DEBUG - 2016-12-02 23:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:52:06 --> Input Class Initialized
INFO - 2016-12-02 23:52:06 --> Language Class Initialized
INFO - 2016-12-02 23:52:06 --> Loader Class Initialized
INFO - 2016-12-02 23:52:07 --> Helper loaded: url_helper
INFO - 2016-12-02 23:52:07 --> Helper loaded: form_helper
INFO - 2016-12-02 23:52:07 --> Database Driver Class Initialized
INFO - 2016-12-02 23:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:52:07 --> Controller Class Initialized
INFO - 2016-12-02 23:52:07 --> Model Class Initialized
INFO - 2016-12-02 23:52:07 --> Form Validation Class Initialized
INFO - 2016-12-02 23:52:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:52:07 --> Pagination Class Initialized
INFO - 2016-12-02 23:52:07 --> Helper loaded: app_helper
INFO - 2016-12-02 23:52:07 --> Email Class Initialized
INFO - 2016-12-02 23:52:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:52:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:52:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:52:07 --> Final output sent to browser
DEBUG - 2016-12-02 23:52:07 --> Total execution time: 0.4737
INFO - 2016-12-02 23:52:10 --> Config Class Initialized
INFO - 2016-12-02 23:52:10 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:52:10 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:52:10 --> Utf8 Class Initialized
INFO - 2016-12-02 23:52:10 --> URI Class Initialized
INFO - 2016-12-02 23:52:10 --> Router Class Initialized
INFO - 2016-12-02 23:52:10 --> Output Class Initialized
INFO - 2016-12-02 23:52:10 --> Security Class Initialized
DEBUG - 2016-12-02 23:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:52:10 --> Input Class Initialized
INFO - 2016-12-02 23:52:10 --> Language Class Initialized
INFO - 2016-12-02 23:52:10 --> Loader Class Initialized
INFO - 2016-12-02 23:52:10 --> Helper loaded: url_helper
INFO - 2016-12-02 23:52:10 --> Helper loaded: form_helper
INFO - 2016-12-02 23:52:10 --> Database Driver Class Initialized
INFO - 2016-12-02 23:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:52:10 --> Controller Class Initialized
INFO - 2016-12-02 23:52:10 --> Model Class Initialized
INFO - 2016-12-02 23:52:10 --> Form Validation Class Initialized
INFO - 2016-12-02 23:52:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:52:10 --> Pagination Class Initialized
INFO - 2016-12-02 23:52:10 --> Helper loaded: app_helper
INFO - 2016-12-02 23:52:10 --> Email Class Initialized
INFO - 2016-12-02 23:52:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:52:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:52:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:52:10 --> Final output sent to browser
DEBUG - 2016-12-02 23:52:10 --> Total execution time: 0.4841
INFO - 2016-12-02 23:52:26 --> Config Class Initialized
INFO - 2016-12-02 23:52:26 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:52:26 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:52:26 --> Utf8 Class Initialized
INFO - 2016-12-02 23:52:26 --> URI Class Initialized
INFO - 2016-12-02 23:52:26 --> Router Class Initialized
INFO - 2016-12-02 23:52:26 --> Output Class Initialized
INFO - 2016-12-02 23:52:26 --> Security Class Initialized
DEBUG - 2016-12-02 23:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:52:26 --> Input Class Initialized
INFO - 2016-12-02 23:52:26 --> Language Class Initialized
INFO - 2016-12-02 23:52:26 --> Loader Class Initialized
INFO - 2016-12-02 23:52:26 --> Helper loaded: url_helper
INFO - 2016-12-02 23:52:26 --> Helper loaded: form_helper
INFO - 2016-12-02 23:52:26 --> Database Driver Class Initialized
INFO - 2016-12-02 23:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:52:26 --> Controller Class Initialized
INFO - 2016-12-02 23:52:26 --> Model Class Initialized
INFO - 2016-12-02 23:52:26 --> Form Validation Class Initialized
INFO - 2016-12-02 23:52:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:52:26 --> Pagination Class Initialized
INFO - 2016-12-02 23:52:26 --> Helper loaded: app_helper
INFO - 2016-12-02 23:52:26 --> Email Class Initialized
INFO - 2016-12-02 23:52:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:52:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:52:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:52:26 --> Final output sent to browser
DEBUG - 2016-12-02 23:52:26 --> Total execution time: 0.4873
INFO - 2016-12-02 23:52:28 --> Config Class Initialized
INFO - 2016-12-02 23:52:28 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:52:28 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:52:28 --> Utf8 Class Initialized
INFO - 2016-12-02 23:52:28 --> URI Class Initialized
INFO - 2016-12-02 23:52:28 --> Router Class Initialized
INFO - 2016-12-02 23:52:28 --> Output Class Initialized
INFO - 2016-12-02 23:52:28 --> Security Class Initialized
DEBUG - 2016-12-02 23:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:52:28 --> Input Class Initialized
INFO - 2016-12-02 23:52:28 --> Language Class Initialized
INFO - 2016-12-02 23:52:28 --> Loader Class Initialized
INFO - 2016-12-02 23:52:28 --> Helper loaded: url_helper
INFO - 2016-12-02 23:52:28 --> Helper loaded: form_helper
INFO - 2016-12-02 23:52:28 --> Database Driver Class Initialized
INFO - 2016-12-02 23:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:52:28 --> Controller Class Initialized
INFO - 2016-12-02 23:52:28 --> Model Class Initialized
INFO - 2016-12-02 23:52:28 --> Form Validation Class Initialized
INFO - 2016-12-02 23:52:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:52:29 --> Pagination Class Initialized
INFO - 2016-12-02 23:52:29 --> Helper loaded: app_helper
INFO - 2016-12-02 23:52:29 --> Email Class Initialized
INFO - 2016-12-02 23:52:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:52:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:52:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:52:29 --> Final output sent to browser
DEBUG - 2016-12-02 23:52:29 --> Total execution time: 0.5036
INFO - 2016-12-02 23:52:29 --> Config Class Initialized
INFO - 2016-12-02 23:52:29 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:52:29 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:52:29 --> Utf8 Class Initialized
INFO - 2016-12-02 23:52:29 --> URI Class Initialized
INFO - 2016-12-02 23:52:29 --> Router Class Initialized
INFO - 2016-12-02 23:52:29 --> Output Class Initialized
INFO - 2016-12-02 23:52:29 --> Security Class Initialized
DEBUG - 2016-12-02 23:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:52:29 --> Input Class Initialized
INFO - 2016-12-02 23:52:29 --> Language Class Initialized
INFO - 2016-12-02 23:52:29 --> Loader Class Initialized
INFO - 2016-12-02 23:52:29 --> Helper loaded: url_helper
INFO - 2016-12-02 23:52:29 --> Helper loaded: form_helper
INFO - 2016-12-02 23:52:29 --> Database Driver Class Initialized
INFO - 2016-12-02 23:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:52:29 --> Controller Class Initialized
INFO - 2016-12-02 23:52:29 --> Model Class Initialized
INFO - 2016-12-02 23:52:29 --> Form Validation Class Initialized
INFO - 2016-12-02 23:52:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:52:29 --> Pagination Class Initialized
INFO - 2016-12-02 23:52:29 --> Helper loaded: app_helper
INFO - 2016-12-02 23:52:29 --> Email Class Initialized
INFO - 2016-12-02 23:52:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:52:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:52:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:52:29 --> Final output sent to browser
DEBUG - 2016-12-02 23:52:29 --> Total execution time: 0.4646
INFO - 2016-12-02 23:52:31 --> Config Class Initialized
INFO - 2016-12-02 23:52:31 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:52:31 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:52:31 --> Utf8 Class Initialized
INFO - 2016-12-02 23:52:31 --> URI Class Initialized
INFO - 2016-12-02 23:52:31 --> Router Class Initialized
INFO - 2016-12-02 23:52:31 --> Output Class Initialized
INFO - 2016-12-02 23:52:31 --> Security Class Initialized
DEBUG - 2016-12-02 23:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:52:31 --> Input Class Initialized
INFO - 2016-12-02 23:52:31 --> Language Class Initialized
INFO - 2016-12-02 23:52:31 --> Loader Class Initialized
INFO - 2016-12-02 23:52:31 --> Helper loaded: url_helper
INFO - 2016-12-02 23:52:31 --> Helper loaded: form_helper
INFO - 2016-12-02 23:52:31 --> Database Driver Class Initialized
INFO - 2016-12-02 23:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:52:31 --> Controller Class Initialized
INFO - 2016-12-02 23:52:31 --> Model Class Initialized
INFO - 2016-12-02 23:52:31 --> Form Validation Class Initialized
INFO - 2016-12-02 23:52:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:52:31 --> Pagination Class Initialized
INFO - 2016-12-02 23:52:31 --> Helper loaded: app_helper
INFO - 2016-12-02 23:52:31 --> Email Class Initialized
INFO - 2016-12-02 23:52:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:52:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:52:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:52:31 --> Final output sent to browser
DEBUG - 2016-12-02 23:52:31 --> Total execution time: 0.5097
INFO - 2016-12-02 23:52:31 --> Config Class Initialized
INFO - 2016-12-02 23:52:31 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:52:31 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:52:31 --> Utf8 Class Initialized
INFO - 2016-12-02 23:52:31 --> URI Class Initialized
INFO - 2016-12-02 23:52:31 --> Router Class Initialized
INFO - 2016-12-02 23:52:31 --> Output Class Initialized
INFO - 2016-12-02 23:52:31 --> Security Class Initialized
DEBUG - 2016-12-02 23:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:52:31 --> Input Class Initialized
INFO - 2016-12-02 23:52:32 --> Language Class Initialized
INFO - 2016-12-02 23:52:32 --> Loader Class Initialized
INFO - 2016-12-02 23:52:32 --> Helper loaded: url_helper
INFO - 2016-12-02 23:52:32 --> Helper loaded: form_helper
INFO - 2016-12-02 23:52:32 --> Database Driver Class Initialized
INFO - 2016-12-02 23:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:52:32 --> Controller Class Initialized
INFO - 2016-12-02 23:52:32 --> Model Class Initialized
INFO - 2016-12-02 23:52:32 --> Form Validation Class Initialized
INFO - 2016-12-02 23:52:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:52:32 --> Pagination Class Initialized
INFO - 2016-12-02 23:52:32 --> Helper loaded: app_helper
INFO - 2016-12-02 23:52:32 --> Email Class Initialized
INFO - 2016-12-02 23:52:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:52:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:52:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:52:32 --> Final output sent to browser
DEBUG - 2016-12-02 23:52:32 --> Total execution time: 0.5288
INFO - 2016-12-02 23:52:37 --> Config Class Initialized
INFO - 2016-12-02 23:52:37 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:52:37 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:52:37 --> Utf8 Class Initialized
INFO - 2016-12-02 23:52:37 --> URI Class Initialized
INFO - 2016-12-02 23:52:37 --> Router Class Initialized
INFO - 2016-12-02 23:52:37 --> Output Class Initialized
INFO - 2016-12-02 23:52:37 --> Security Class Initialized
DEBUG - 2016-12-02 23:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:52:37 --> Input Class Initialized
INFO - 2016-12-02 23:52:37 --> Language Class Initialized
INFO - 2016-12-02 23:52:37 --> Loader Class Initialized
INFO - 2016-12-02 23:52:37 --> Helper loaded: url_helper
INFO - 2016-12-02 23:52:37 --> Helper loaded: form_helper
INFO - 2016-12-02 23:52:37 --> Database Driver Class Initialized
INFO - 2016-12-02 23:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:52:37 --> Controller Class Initialized
INFO - 2016-12-02 23:52:37 --> Model Class Initialized
INFO - 2016-12-02 23:52:38 --> Form Validation Class Initialized
INFO - 2016-12-02 23:52:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:52:38 --> Pagination Class Initialized
INFO - 2016-12-02 23:52:38 --> Helper loaded: app_helper
INFO - 2016-12-02 23:52:38 --> Email Class Initialized
INFO - 2016-12-02 23:52:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:52:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:52:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:52:38 --> Final output sent to browser
DEBUG - 2016-12-02 23:52:38 --> Total execution time: 0.4842
INFO - 2016-12-02 23:52:41 --> Config Class Initialized
INFO - 2016-12-02 23:52:41 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:52:41 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:52:41 --> Utf8 Class Initialized
INFO - 2016-12-02 23:52:42 --> URI Class Initialized
INFO - 2016-12-02 23:52:42 --> Router Class Initialized
INFO - 2016-12-02 23:52:42 --> Output Class Initialized
INFO - 2016-12-02 23:52:42 --> Security Class Initialized
DEBUG - 2016-12-02 23:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:52:42 --> Input Class Initialized
INFO - 2016-12-02 23:52:42 --> Language Class Initialized
INFO - 2016-12-02 23:52:42 --> Loader Class Initialized
INFO - 2016-12-02 23:52:42 --> Helper loaded: url_helper
INFO - 2016-12-02 23:52:42 --> Helper loaded: form_helper
INFO - 2016-12-02 23:52:42 --> Database Driver Class Initialized
INFO - 2016-12-02 23:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:52:42 --> Controller Class Initialized
INFO - 2016-12-02 23:52:42 --> Model Class Initialized
INFO - 2016-12-02 23:52:42 --> Form Validation Class Initialized
INFO - 2016-12-02 23:52:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:52:42 --> Pagination Class Initialized
INFO - 2016-12-02 23:52:42 --> Helper loaded: app_helper
INFO - 2016-12-02 23:52:42 --> Email Class Initialized
INFO - 2016-12-02 23:52:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:52:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:52:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:52:42 --> Final output sent to browser
DEBUG - 2016-12-02 23:52:42 --> Total execution time: 0.4801
INFO - 2016-12-02 23:53:04 --> Config Class Initialized
INFO - 2016-12-02 23:53:04 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:53:04 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:53:04 --> Utf8 Class Initialized
INFO - 2016-12-02 23:53:04 --> URI Class Initialized
INFO - 2016-12-02 23:53:04 --> Router Class Initialized
INFO - 2016-12-02 23:53:04 --> Output Class Initialized
INFO - 2016-12-02 23:53:04 --> Security Class Initialized
DEBUG - 2016-12-02 23:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:53:04 --> Input Class Initialized
INFO - 2016-12-02 23:53:04 --> Language Class Initialized
INFO - 2016-12-02 23:53:04 --> Loader Class Initialized
INFO - 2016-12-02 23:53:04 --> Helper loaded: url_helper
INFO - 2016-12-02 23:53:04 --> Helper loaded: form_helper
INFO - 2016-12-02 23:53:04 --> Database Driver Class Initialized
INFO - 2016-12-02 23:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:53:04 --> Controller Class Initialized
INFO - 2016-12-02 23:53:04 --> Model Class Initialized
INFO - 2016-12-02 23:53:04 --> Form Validation Class Initialized
INFO - 2016-12-02 23:53:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:53:04 --> Pagination Class Initialized
INFO - 2016-12-02 23:53:04 --> Helper loaded: app_helper
INFO - 2016-12-02 23:53:04 --> Email Class Initialized
INFO - 2016-12-02 23:53:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:53:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:53:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:53:04 --> Final output sent to browser
DEBUG - 2016-12-02 23:53:04 --> Total execution time: 0.4695
INFO - 2016-12-02 23:53:09 --> Config Class Initialized
INFO - 2016-12-02 23:53:09 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:53:09 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:53:09 --> Utf8 Class Initialized
INFO - 2016-12-02 23:53:09 --> URI Class Initialized
INFO - 2016-12-02 23:53:09 --> Router Class Initialized
INFO - 2016-12-02 23:53:09 --> Output Class Initialized
INFO - 2016-12-02 23:53:09 --> Security Class Initialized
DEBUG - 2016-12-02 23:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:53:09 --> Input Class Initialized
INFO - 2016-12-02 23:53:09 --> Language Class Initialized
INFO - 2016-12-02 23:53:09 --> Loader Class Initialized
INFO - 2016-12-02 23:53:09 --> Helper loaded: url_helper
INFO - 2016-12-02 23:53:09 --> Helper loaded: form_helper
INFO - 2016-12-02 23:53:09 --> Database Driver Class Initialized
INFO - 2016-12-02 23:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:53:09 --> Controller Class Initialized
INFO - 2016-12-02 23:53:09 --> Model Class Initialized
INFO - 2016-12-02 23:53:09 --> Form Validation Class Initialized
INFO - 2016-12-02 23:53:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:53:09 --> Pagination Class Initialized
INFO - 2016-12-02 23:53:09 --> Helper loaded: app_helper
INFO - 2016-12-02 23:53:09 --> Email Class Initialized
INFO - 2016-12-02 23:53:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:53:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:53:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:53:09 --> Final output sent to browser
DEBUG - 2016-12-02 23:53:09 --> Total execution time: 0.4738
INFO - 2016-12-02 23:53:16 --> Config Class Initialized
INFO - 2016-12-02 23:53:16 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:53:16 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:53:16 --> Utf8 Class Initialized
INFO - 2016-12-02 23:53:16 --> URI Class Initialized
INFO - 2016-12-02 23:53:16 --> Router Class Initialized
INFO - 2016-12-02 23:53:16 --> Output Class Initialized
INFO - 2016-12-02 23:53:16 --> Security Class Initialized
DEBUG - 2016-12-02 23:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:53:16 --> Input Class Initialized
INFO - 2016-12-02 23:53:16 --> Language Class Initialized
INFO - 2016-12-02 23:53:16 --> Loader Class Initialized
INFO - 2016-12-02 23:53:16 --> Helper loaded: url_helper
INFO - 2016-12-02 23:53:16 --> Helper loaded: form_helper
INFO - 2016-12-02 23:53:16 --> Database Driver Class Initialized
INFO - 2016-12-02 23:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:53:16 --> Controller Class Initialized
INFO - 2016-12-02 23:53:16 --> Model Class Initialized
INFO - 2016-12-02 23:53:16 --> Form Validation Class Initialized
INFO - 2016-12-02 23:53:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:53:16 --> Pagination Class Initialized
INFO - 2016-12-02 23:53:16 --> Helper loaded: app_helper
INFO - 2016-12-02 23:53:16 --> Email Class Initialized
INFO - 2016-12-02 23:53:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:53:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:53:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:53:16 --> Final output sent to browser
DEBUG - 2016-12-02 23:53:16 --> Total execution time: 0.4203
INFO - 2016-12-02 23:53:45 --> Config Class Initialized
INFO - 2016-12-02 23:53:45 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:53:45 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:53:45 --> Utf8 Class Initialized
INFO - 2016-12-02 23:53:45 --> URI Class Initialized
INFO - 2016-12-02 23:53:45 --> Router Class Initialized
INFO - 2016-12-02 23:53:45 --> Output Class Initialized
INFO - 2016-12-02 23:53:45 --> Security Class Initialized
DEBUG - 2016-12-02 23:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:53:45 --> Input Class Initialized
INFO - 2016-12-02 23:53:45 --> Language Class Initialized
INFO - 2016-12-02 23:53:45 --> Loader Class Initialized
INFO - 2016-12-02 23:53:45 --> Helper loaded: url_helper
INFO - 2016-12-02 23:53:45 --> Helper loaded: form_helper
INFO - 2016-12-02 23:53:45 --> Database Driver Class Initialized
INFO - 2016-12-02 23:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:53:45 --> Controller Class Initialized
INFO - 2016-12-02 23:53:45 --> Model Class Initialized
INFO - 2016-12-02 23:53:45 --> Form Validation Class Initialized
INFO - 2016-12-02 23:53:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:53:46 --> Pagination Class Initialized
INFO - 2016-12-02 23:53:46 --> Helper loaded: app_helper
INFO - 2016-12-02 23:53:46 --> Email Class Initialized
INFO - 2016-12-02 23:53:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:53:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:53:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:53:46 --> Final output sent to browser
DEBUG - 2016-12-02 23:53:46 --> Total execution time: 0.5102
INFO - 2016-12-02 23:54:52 --> Config Class Initialized
INFO - 2016-12-02 23:54:52 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:54:52 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:54:52 --> Utf8 Class Initialized
INFO - 2016-12-02 23:54:52 --> URI Class Initialized
DEBUG - 2016-12-02 23:54:52 --> No URI present. Default controller set.
INFO - 2016-12-02 23:54:52 --> Router Class Initialized
INFO - 2016-12-02 23:54:52 --> Output Class Initialized
INFO - 2016-12-02 23:54:52 --> Security Class Initialized
DEBUG - 2016-12-02 23:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:54:52 --> Input Class Initialized
INFO - 2016-12-02 23:54:52 --> Language Class Initialized
INFO - 2016-12-02 23:54:52 --> Loader Class Initialized
INFO - 2016-12-02 23:54:52 --> Helper loaded: url_helper
INFO - 2016-12-02 23:54:52 --> Helper loaded: form_helper
INFO - 2016-12-02 23:54:52 --> Database Driver Class Initialized
INFO - 2016-12-02 23:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:54:52 --> Controller Class Initialized
INFO - 2016-12-02 23:54:52 --> Model Class Initialized
INFO - 2016-12-02 23:54:52 --> Model Class Initialized
INFO - 2016-12-02 23:54:52 --> Model Class Initialized
INFO - 2016-12-02 23:54:52 --> Model Class Initialized
INFO - 2016-12-02 23:54:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:54:53 --> Pagination Class Initialized
INFO - 2016-12-02 23:54:53 --> Helper loaded: app_helper
INFO - 2016-12-02 23:54:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:54:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-12-02 23:54:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-12-02 23:54:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-12-02 23:54:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 23:54:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-12-02 23:54:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-12-02 23:54:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-12-02 23:54:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:54:53 --> Final output sent to browser
DEBUG - 2016-12-02 23:54:53 --> Total execution time: 0.6393
INFO - 2016-12-02 23:55:35 --> Config Class Initialized
INFO - 2016-12-02 23:55:35 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:55:35 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:55:35 --> Utf8 Class Initialized
INFO - 2016-12-02 23:55:35 --> URI Class Initialized
INFO - 2016-12-02 23:55:35 --> Router Class Initialized
INFO - 2016-12-02 23:55:35 --> Output Class Initialized
INFO - 2016-12-02 23:55:35 --> Security Class Initialized
DEBUG - 2016-12-02 23:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:55:35 --> Input Class Initialized
INFO - 2016-12-02 23:55:35 --> Language Class Initialized
INFO - 2016-12-02 23:55:35 --> Loader Class Initialized
INFO - 2016-12-02 23:55:35 --> Helper loaded: url_helper
INFO - 2016-12-02 23:55:35 --> Helper loaded: form_helper
INFO - 2016-12-02 23:55:35 --> Database Driver Class Initialized
INFO - 2016-12-02 23:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:55:35 --> Controller Class Initialized
INFO - 2016-12-02 23:55:36 --> Model Class Initialized
INFO - 2016-12-02 23:55:36 --> Form Validation Class Initialized
INFO - 2016-12-02 23:55:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:55:36 --> Pagination Class Initialized
INFO - 2016-12-02 23:55:36 --> Helper loaded: app_helper
INFO - 2016-12-02 23:55:36 --> Email Class Initialized
INFO - 2016-12-02 23:55:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-02 23:55:36 --> Final output sent to browser
DEBUG - 2016-12-02 23:55:36 --> Total execution time: 0.5055
INFO - 2016-12-02 23:56:01 --> Config Class Initialized
INFO - 2016-12-02 23:56:01 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:56:01 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:56:01 --> Utf8 Class Initialized
INFO - 2016-12-02 23:56:01 --> URI Class Initialized
INFO - 2016-12-02 23:56:01 --> Router Class Initialized
INFO - 2016-12-02 23:56:01 --> Output Class Initialized
INFO - 2016-12-02 23:56:01 --> Security Class Initialized
DEBUG - 2016-12-02 23:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:56:01 --> Input Class Initialized
INFO - 2016-12-02 23:56:01 --> Language Class Initialized
INFO - 2016-12-02 23:56:01 --> Loader Class Initialized
INFO - 2016-12-02 23:56:01 --> Helper loaded: url_helper
INFO - 2016-12-02 23:56:01 --> Helper loaded: form_helper
INFO - 2016-12-02 23:56:01 --> Database Driver Class Initialized
INFO - 2016-12-02 23:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:56:01 --> Controller Class Initialized
INFO - 2016-12-02 23:56:01 --> Model Class Initialized
INFO - 2016-12-02 23:56:01 --> Form Validation Class Initialized
INFO - 2016-12-02 23:56:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:56:01 --> Pagination Class Initialized
INFO - 2016-12-02 23:56:01 --> Helper loaded: app_helper
INFO - 2016-12-02 23:56:01 --> Email Class Initialized
INFO - 2016-12-02 23:56:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-02 22:56:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-12-02 22:56:01 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
INFO - 2016-12-02 22:56:02 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-02 22:56:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
INFO - 2016-12-02 22:56:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-12-02 22:56:07 --> Final output sent to browser
DEBUG - 2016-12-02 22:56:07 --> Total execution time: 5.7603
INFO - 2016-12-02 23:56:37 --> Config Class Initialized
INFO - 2016-12-02 23:56:38 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:56:38 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:56:38 --> Utf8 Class Initialized
INFO - 2016-12-02 23:56:38 --> URI Class Initialized
INFO - 2016-12-02 23:56:38 --> Router Class Initialized
INFO - 2016-12-02 23:56:38 --> Output Class Initialized
INFO - 2016-12-02 23:56:38 --> Security Class Initialized
DEBUG - 2016-12-02 23:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:56:38 --> Input Class Initialized
INFO - 2016-12-02 23:56:38 --> Language Class Initialized
INFO - 2016-12-02 23:56:38 --> Loader Class Initialized
INFO - 2016-12-02 23:56:38 --> Helper loaded: url_helper
INFO - 2016-12-02 23:56:38 --> Helper loaded: form_helper
INFO - 2016-12-02 23:56:38 --> Database Driver Class Initialized
INFO - 2016-12-02 23:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:56:38 --> Controller Class Initialized
INFO - 2016-12-02 23:56:38 --> Model Class Initialized
INFO - 2016-12-02 23:56:38 --> Form Validation Class Initialized
INFO - 2016-12-02 23:56:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:56:38 --> Pagination Class Initialized
INFO - 2016-12-02 23:56:38 --> Helper loaded: app_helper
INFO - 2016-12-02 23:56:38 --> Email Class Initialized
INFO - 2016-12-02 23:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-12-02 23:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/email_leave_applied.php
INFO - 2016-12-02 23:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-12-02 23:56:38 --> Final output sent to browser
DEBUG - 2016-12-02 23:56:38 --> Total execution time: 0.6064
INFO - 2016-12-02 23:57:51 --> Config Class Initialized
INFO - 2016-12-02 23:57:51 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:57:51 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:57:51 --> Utf8 Class Initialized
INFO - 2016-12-02 23:57:51 --> URI Class Initialized
INFO - 2016-12-02 23:57:51 --> Router Class Initialized
INFO - 2016-12-02 23:57:51 --> Output Class Initialized
INFO - 2016-12-02 23:57:51 --> Security Class Initialized
DEBUG - 2016-12-02 23:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:57:51 --> Input Class Initialized
INFO - 2016-12-02 23:57:51 --> Language Class Initialized
INFO - 2016-12-02 23:57:51 --> Loader Class Initialized
INFO - 2016-12-02 23:57:51 --> Helper loaded: url_helper
INFO - 2016-12-02 23:57:51 --> Helper loaded: form_helper
INFO - 2016-12-02 23:57:51 --> Database Driver Class Initialized
INFO - 2016-12-02 23:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:57:51 --> Controller Class Initialized
INFO - 2016-12-02 23:57:51 --> Model Class Initialized
INFO - 2016-12-02 23:57:51 --> Form Validation Class Initialized
INFO - 2016-12-02 23:57:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:57:51 --> Pagination Class Initialized
INFO - 2016-12-02 23:57:51 --> Helper loaded: app_helper
INFO - 2016-12-02 23:57:51 --> Email Class Initialized
INFO - 2016-12-02 23:57:51 --> Final output sent to browser
DEBUG - 2016-12-02 23:57:51 --> Total execution time: 0.4328
INFO - 2016-12-02 23:59:21 --> Config Class Initialized
INFO - 2016-12-02 23:59:21 --> Hooks Class Initialized
DEBUG - 2016-12-02 23:59:22 --> UTF-8 Support Enabled
INFO - 2016-12-02 23:59:22 --> Utf8 Class Initialized
INFO - 2016-12-02 23:59:22 --> URI Class Initialized
INFO - 2016-12-02 23:59:22 --> Router Class Initialized
INFO - 2016-12-02 23:59:22 --> Output Class Initialized
INFO - 2016-12-02 23:59:22 --> Security Class Initialized
DEBUG - 2016-12-02 23:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 23:59:22 --> Input Class Initialized
INFO - 2016-12-02 23:59:22 --> Language Class Initialized
INFO - 2016-12-02 23:59:22 --> Loader Class Initialized
INFO - 2016-12-02 23:59:22 --> Helper loaded: url_helper
INFO - 2016-12-02 23:59:22 --> Helper loaded: form_helper
INFO - 2016-12-02 23:59:22 --> Database Driver Class Initialized
INFO - 2016-12-02 23:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 23:59:22 --> Controller Class Initialized
INFO - 2016-12-02 23:59:22 --> Model Class Initialized
INFO - 2016-12-02 23:59:22 --> Form Validation Class Initialized
INFO - 2016-12-02 23:59:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-12-02 23:59:22 --> Pagination Class Initialized
INFO - 2016-12-02 23:59:22 --> Helper loaded: app_helper
INFO - 2016-12-02 23:59:22 --> Email Class Initialized
INFO - 2016-12-02 23:59:22 --> Final output sent to browser
DEBUG - 2016-12-02 23:59:22 --> Total execution time: 0.4476
