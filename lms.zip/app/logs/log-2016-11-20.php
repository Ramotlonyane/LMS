<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-20 00:01:13 --> Config Class Initialized
INFO - 2016-11-20 00:01:13 --> Hooks Class Initialized
DEBUG - 2016-11-20 00:01:13 --> UTF-8 Support Enabled
INFO - 2016-11-20 00:01:13 --> Utf8 Class Initialized
INFO - 2016-11-20 00:01:13 --> URI Class Initialized
DEBUG - 2016-11-20 00:01:13 --> No URI present. Default controller set.
INFO - 2016-11-20 00:01:13 --> Router Class Initialized
INFO - 2016-11-20 00:01:13 --> Output Class Initialized
INFO - 2016-11-20 00:01:13 --> Security Class Initialized
DEBUG - 2016-11-20 00:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 00:01:13 --> Input Class Initialized
INFO - 2016-11-20 00:01:13 --> Language Class Initialized
INFO - 2016-11-20 00:01:13 --> Loader Class Initialized
INFO - 2016-11-20 00:01:13 --> Helper loaded: url_helper
INFO - 2016-11-20 00:01:13 --> Helper loaded: form_helper
INFO - 2016-11-20 00:01:13 --> Database Driver Class Initialized
INFO - 2016-11-20 00:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 00:01:13 --> Controller Class Initialized
INFO - 2016-11-20 00:01:13 --> Model Class Initialized
INFO - 2016-11-20 00:01:13 --> Model Class Initialized
INFO - 2016-11-20 00:01:13 --> Model Class Initialized
INFO - 2016-11-20 00:01:13 --> Model Class Initialized
INFO - 2016-11-20 00:01:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 00:01:13 --> Pagination Class Initialized
INFO - 2016-11-20 00:01:13 --> Helper loaded: app_helper
INFO - 2016-11-20 00:01:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 00:01:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
DEBUG - 2016-11-20 00:01:13 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-11-20 00:01:13 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-11-20 00:01:13 --> Pagination class already loaded. Second attempt ignored.
INFO - 2016-11-20 00:01:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 00:01:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 00:01:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 00:01:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 00:01:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 00:01:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 00:01:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 00:01:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 00:01:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 00:01:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 00:01:13 --> Final output sent to browser
DEBUG - 2016-11-20 00:01:13 --> Total execution time: 0.3823
INFO - 2016-11-20 00:53:10 --> Config Class Initialized
INFO - 2016-11-20 00:53:10 --> Hooks Class Initialized
DEBUG - 2016-11-20 00:53:10 --> UTF-8 Support Enabled
INFO - 2016-11-20 00:53:10 --> Utf8 Class Initialized
INFO - 2016-11-20 00:53:10 --> URI Class Initialized
DEBUG - 2016-11-20 00:53:10 --> No URI present. Default controller set.
INFO - 2016-11-20 00:53:10 --> Router Class Initialized
INFO - 2016-11-20 00:53:10 --> Output Class Initialized
INFO - 2016-11-20 00:53:10 --> Security Class Initialized
DEBUG - 2016-11-20 00:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 00:53:10 --> Input Class Initialized
INFO - 2016-11-20 00:53:10 --> Language Class Initialized
INFO - 2016-11-20 00:53:10 --> Loader Class Initialized
INFO - 2016-11-20 00:53:10 --> Helper loaded: url_helper
INFO - 2016-11-20 00:53:10 --> Helper loaded: form_helper
INFO - 2016-11-20 00:53:10 --> Database Driver Class Initialized
INFO - 2016-11-20 00:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 00:53:10 --> Controller Class Initialized
INFO - 2016-11-20 00:53:10 --> Model Class Initialized
INFO - 2016-11-20 00:53:10 --> Model Class Initialized
INFO - 2016-11-20 00:53:10 --> Model Class Initialized
INFO - 2016-11-20 00:53:10 --> Model Class Initialized
INFO - 2016-11-20 00:53:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 00:53:10 --> Pagination Class Initialized
INFO - 2016-11-20 00:53:10 --> Helper loaded: app_helper
INFO - 2016-11-20 00:53:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 00:53:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
DEBUG - 2016-11-20 00:53:10 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-11-20 00:53:10 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-11-20 00:53:10 --> Pagination class already loaded. Second attempt ignored.
INFO - 2016-11-20 00:53:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 00:53:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 00:53:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 00:53:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 00:53:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 00:53:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 00:53:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 00:53:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 00:53:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 00:53:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 00:53:10 --> Final output sent to browser
DEBUG - 2016-11-20 00:53:10 --> Total execution time: 0.4288
INFO - 2016-11-20 01:07:06 --> Config Class Initialized
INFO - 2016-11-20 01:07:06 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:07:06 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:07:06 --> Utf8 Class Initialized
INFO - 2016-11-20 01:07:06 --> URI Class Initialized
DEBUG - 2016-11-20 01:07:06 --> No URI present. Default controller set.
INFO - 2016-11-20 01:07:06 --> Router Class Initialized
INFO - 2016-11-20 01:07:06 --> Output Class Initialized
INFO - 2016-11-20 01:07:06 --> Security Class Initialized
DEBUG - 2016-11-20 01:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:07:06 --> Input Class Initialized
INFO - 2016-11-20 01:07:06 --> Language Class Initialized
INFO - 2016-11-20 01:07:06 --> Loader Class Initialized
INFO - 2016-11-20 01:07:06 --> Helper loaded: url_helper
INFO - 2016-11-20 01:07:06 --> Helper loaded: form_helper
INFO - 2016-11-20 01:07:06 --> Database Driver Class Initialized
INFO - 2016-11-20 01:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:07:06 --> Controller Class Initialized
INFO - 2016-11-20 01:07:06 --> Model Class Initialized
INFO - 2016-11-20 01:07:06 --> Model Class Initialized
INFO - 2016-11-20 01:07:06 --> Model Class Initialized
INFO - 2016-11-20 01:07:06 --> Model Class Initialized
INFO - 2016-11-20 01:07:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 01:07:06 --> Pagination Class Initialized
INFO - 2016-11-20 01:07:06 --> Helper loaded: app_helper
INFO - 2016-11-20 01:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 01:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
DEBUG - 2016-11-20 01:07:06 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-11-20 01:07:06 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-11-20 01:07:06 --> Pagination class already loaded. Second attempt ignored.
INFO - 2016-11-20 01:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 01:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 01:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 01:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 01:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 01:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 01:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 01:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 01:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 01:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 01:07:06 --> Final output sent to browser
DEBUG - 2016-11-20 01:07:06 --> Total execution time: 0.4290
INFO - 2016-11-20 01:24:15 --> Config Class Initialized
INFO - 2016-11-20 01:24:15 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:24:15 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:24:15 --> Utf8 Class Initialized
INFO - 2016-11-20 01:24:15 --> URI Class Initialized
DEBUG - 2016-11-20 01:24:15 --> No URI present. Default controller set.
INFO - 2016-11-20 01:24:15 --> Router Class Initialized
INFO - 2016-11-20 01:24:15 --> Output Class Initialized
INFO - 2016-11-20 01:24:15 --> Security Class Initialized
DEBUG - 2016-11-20 01:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:24:15 --> Input Class Initialized
INFO - 2016-11-20 01:24:15 --> Language Class Initialized
INFO - 2016-11-20 01:24:15 --> Loader Class Initialized
INFO - 2016-11-20 01:24:15 --> Helper loaded: url_helper
INFO - 2016-11-20 01:24:15 --> Helper loaded: form_helper
INFO - 2016-11-20 01:24:15 --> Database Driver Class Initialized
INFO - 2016-11-20 01:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:24:15 --> Controller Class Initialized
INFO - 2016-11-20 01:24:15 --> Model Class Initialized
INFO - 2016-11-20 01:24:15 --> Model Class Initialized
INFO - 2016-11-20 01:24:15 --> Model Class Initialized
INFO - 2016-11-20 01:24:15 --> Model Class Initialized
INFO - 2016-11-20 01:24:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 01:24:15 --> Pagination Class Initialized
INFO - 2016-11-20 01:24:15 --> Helper loaded: app_helper
INFO - 2016-11-20 01:24:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 01:24:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
DEBUG - 2016-11-20 01:24:15 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-11-20 01:24:15 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-11-20 01:24:15 --> Pagination class already loaded. Second attempt ignored.
INFO - 2016-11-20 01:24:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 01:24:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 01:24:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 01:24:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 01:24:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 01:24:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 01:24:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 01:24:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 01:24:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 01:24:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 01:24:16 --> Final output sent to browser
DEBUG - 2016-11-20 01:24:16 --> Total execution time: 0.5093
INFO - 2016-11-20 01:38:12 --> Config Class Initialized
INFO - 2016-11-20 01:38:12 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:38:12 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:38:12 --> Utf8 Class Initialized
INFO - 2016-11-20 01:38:12 --> URI Class Initialized
DEBUG - 2016-11-20 01:38:12 --> No URI present. Default controller set.
INFO - 2016-11-20 01:38:12 --> Router Class Initialized
INFO - 2016-11-20 01:38:12 --> Output Class Initialized
INFO - 2016-11-20 01:38:12 --> Security Class Initialized
DEBUG - 2016-11-20 01:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:38:12 --> Input Class Initialized
INFO - 2016-11-20 01:38:12 --> Language Class Initialized
INFO - 2016-11-20 01:38:12 --> Loader Class Initialized
INFO - 2016-11-20 01:38:12 --> Helper loaded: url_helper
INFO - 2016-11-20 01:38:12 --> Helper loaded: form_helper
INFO - 2016-11-20 01:38:12 --> Database Driver Class Initialized
INFO - 2016-11-20 01:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:38:12 --> Controller Class Initialized
INFO - 2016-11-20 01:38:12 --> Model Class Initialized
INFO - 2016-11-20 01:38:12 --> Model Class Initialized
INFO - 2016-11-20 01:38:12 --> Model Class Initialized
INFO - 2016-11-20 01:38:12 --> Model Class Initialized
INFO - 2016-11-20 01:38:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 01:38:12 --> Pagination Class Initialized
INFO - 2016-11-20 01:38:12 --> Helper loaded: app_helper
INFO - 2016-11-20 01:38:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 01:38:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-20 01:38:12 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\LMS\app\helpers\app_helper.php 52
INFO - 2016-11-20 01:39:33 --> Config Class Initialized
INFO - 2016-11-20 01:39:33 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:39:33 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:39:33 --> Utf8 Class Initialized
INFO - 2016-11-20 01:39:33 --> URI Class Initialized
DEBUG - 2016-11-20 01:39:33 --> No URI present. Default controller set.
INFO - 2016-11-20 01:39:33 --> Router Class Initialized
INFO - 2016-11-20 01:39:33 --> Output Class Initialized
INFO - 2016-11-20 01:39:33 --> Security Class Initialized
DEBUG - 2016-11-20 01:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:39:33 --> Input Class Initialized
INFO - 2016-11-20 01:39:33 --> Language Class Initialized
INFO - 2016-11-20 01:39:33 --> Loader Class Initialized
INFO - 2016-11-20 01:39:33 --> Helper loaded: url_helper
INFO - 2016-11-20 01:39:33 --> Helper loaded: form_helper
INFO - 2016-11-20 01:39:33 --> Database Driver Class Initialized
INFO - 2016-11-20 01:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:39:33 --> Controller Class Initialized
INFO - 2016-11-20 01:39:33 --> Model Class Initialized
INFO - 2016-11-20 01:39:33 --> Model Class Initialized
INFO - 2016-11-20 01:39:33 --> Model Class Initialized
INFO - 2016-11-20 01:39:33 --> Model Class Initialized
INFO - 2016-11-20 01:39:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 01:39:34 --> Pagination Class Initialized
INFO - 2016-11-20 01:39:34 --> Helper loaded: app_helper
INFO - 2016-11-20 01:39:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 01:39:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-20 01:39:34 --> Severity: Notice --> Undefined property: Auth::$ajax_pagination C:\xampp\htdocs\LMS\app\helpers\app_helper.php 53
ERROR - 2016-11-20 01:39:34 --> Severity: Error --> Call to a member function initialize() on null C:\xampp\htdocs\LMS\app\helpers\app_helper.php 53
INFO - 2016-11-20 01:41:05 --> Config Class Initialized
INFO - 2016-11-20 01:41:05 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:41:05 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:41:05 --> Utf8 Class Initialized
INFO - 2016-11-20 01:41:05 --> URI Class Initialized
DEBUG - 2016-11-20 01:41:05 --> No URI present. Default controller set.
INFO - 2016-11-20 01:41:05 --> Router Class Initialized
INFO - 2016-11-20 01:41:05 --> Output Class Initialized
INFO - 2016-11-20 01:41:05 --> Security Class Initialized
DEBUG - 2016-11-20 01:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:41:05 --> Input Class Initialized
INFO - 2016-11-20 01:41:05 --> Language Class Initialized
INFO - 2016-11-20 01:41:05 --> Loader Class Initialized
INFO - 2016-11-20 01:41:05 --> Helper loaded: url_helper
INFO - 2016-11-20 01:41:05 --> Helper loaded: form_helper
INFO - 2016-11-20 01:41:05 --> Database Driver Class Initialized
INFO - 2016-11-20 01:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:41:05 --> Controller Class Initialized
INFO - 2016-11-20 01:41:05 --> Model Class Initialized
INFO - 2016-11-20 01:41:05 --> Model Class Initialized
INFO - 2016-11-20 01:41:05 --> Model Class Initialized
INFO - 2016-11-20 01:41:05 --> Model Class Initialized
INFO - 2016-11-20 01:41:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 01:41:05 --> Pagination Class Initialized
INFO - 2016-11-20 01:41:05 --> Helper loaded: app_helper
INFO - 2016-11-20 01:41:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 01:41:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-20 01:41:05 --> Severity: Notice --> Undefined property: Auth::$ajax_pagination C:\xampp\htdocs\LMS\app\helpers\app_helper.php 60
ERROR - 2016-11-20 01:41:05 --> Severity: Error --> Call to a member function initialize() on null C:\xampp\htdocs\LMS\app\helpers\app_helper.php 60
INFO - 2016-11-20 01:41:07 --> Config Class Initialized
INFO - 2016-11-20 01:41:07 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:41:07 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:41:07 --> Utf8 Class Initialized
INFO - 2016-11-20 01:41:07 --> URI Class Initialized
DEBUG - 2016-11-20 01:41:07 --> No URI present. Default controller set.
INFO - 2016-11-20 01:41:07 --> Router Class Initialized
INFO - 2016-11-20 01:41:07 --> Output Class Initialized
INFO - 2016-11-20 01:41:07 --> Security Class Initialized
DEBUG - 2016-11-20 01:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:41:07 --> Input Class Initialized
INFO - 2016-11-20 01:41:07 --> Language Class Initialized
INFO - 2016-11-20 01:41:07 --> Loader Class Initialized
INFO - 2016-11-20 01:41:07 --> Helper loaded: url_helper
INFO - 2016-11-20 01:41:07 --> Helper loaded: form_helper
INFO - 2016-11-20 01:41:07 --> Database Driver Class Initialized
INFO - 2016-11-20 01:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:41:07 --> Controller Class Initialized
INFO - 2016-11-20 01:41:07 --> Model Class Initialized
INFO - 2016-11-20 01:41:07 --> Model Class Initialized
INFO - 2016-11-20 01:41:07 --> Model Class Initialized
INFO - 2016-11-20 01:41:07 --> Model Class Initialized
INFO - 2016-11-20 01:41:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 01:41:07 --> Pagination Class Initialized
INFO - 2016-11-20 01:41:07 --> Helper loaded: app_helper
INFO - 2016-11-20 01:41:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 01:41:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-20 01:41:07 --> Severity: Notice --> Undefined property: Auth::$ajax_pagination C:\xampp\htdocs\LMS\app\helpers\app_helper.php 60
ERROR - 2016-11-20 01:41:07 --> Severity: Error --> Call to a member function initialize() on null C:\xampp\htdocs\LMS\app\helpers\app_helper.php 60
INFO - 2016-11-20 01:42:11 --> Config Class Initialized
INFO - 2016-11-20 01:42:11 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:42:12 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:42:12 --> Utf8 Class Initialized
INFO - 2016-11-20 01:42:12 --> URI Class Initialized
DEBUG - 2016-11-20 01:42:12 --> No URI present. Default controller set.
INFO - 2016-11-20 01:42:12 --> Router Class Initialized
INFO - 2016-11-20 01:42:12 --> Output Class Initialized
INFO - 2016-11-20 01:42:12 --> Security Class Initialized
DEBUG - 2016-11-20 01:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:42:12 --> Input Class Initialized
INFO - 2016-11-20 01:42:12 --> Language Class Initialized
INFO - 2016-11-20 01:42:12 --> Loader Class Initialized
INFO - 2016-11-20 01:42:12 --> Helper loaded: url_helper
INFO - 2016-11-20 01:42:12 --> Helper loaded: form_helper
INFO - 2016-11-20 01:42:12 --> Database Driver Class Initialized
INFO - 2016-11-20 01:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:42:12 --> Controller Class Initialized
INFO - 2016-11-20 01:42:12 --> Model Class Initialized
INFO - 2016-11-20 01:42:12 --> Model Class Initialized
INFO - 2016-11-20 01:42:12 --> Model Class Initialized
INFO - 2016-11-20 01:42:12 --> Model Class Initialized
INFO - 2016-11-20 01:42:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 01:42:12 --> Pagination Class Initialized
INFO - 2016-11-20 01:42:12 --> Helper loaded: app_helper
INFO - 2016-11-20 01:42:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 01:42:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-20 01:42:12 --> Severity: Notice --> Undefined property: Auth::$ajax_pagination C:\xampp\htdocs\LMS\app\helpers\app_helper.php 60
ERROR - 2016-11-20 01:42:12 --> Severity: Error --> Call to a member function initialize() on null C:\xampp\htdocs\LMS\app\helpers\app_helper.php 60
INFO - 2016-11-20 01:43:27 --> Config Class Initialized
INFO - 2016-11-20 01:43:27 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:43:27 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:43:27 --> Utf8 Class Initialized
INFO - 2016-11-20 01:43:27 --> URI Class Initialized
DEBUG - 2016-11-20 01:43:27 --> No URI present. Default controller set.
INFO - 2016-11-20 01:43:27 --> Router Class Initialized
INFO - 2016-11-20 01:43:27 --> Output Class Initialized
INFO - 2016-11-20 01:43:27 --> Security Class Initialized
DEBUG - 2016-11-20 01:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:43:27 --> Input Class Initialized
INFO - 2016-11-20 01:43:27 --> Language Class Initialized
INFO - 2016-11-20 01:43:27 --> Loader Class Initialized
INFO - 2016-11-20 01:43:27 --> Helper loaded: url_helper
INFO - 2016-11-20 01:43:27 --> Helper loaded: form_helper
INFO - 2016-11-20 01:43:27 --> Database Driver Class Initialized
INFO - 2016-11-20 01:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:43:27 --> Controller Class Initialized
INFO - 2016-11-20 01:43:27 --> Model Class Initialized
INFO - 2016-11-20 01:43:27 --> Model Class Initialized
INFO - 2016-11-20 01:43:27 --> Model Class Initialized
INFO - 2016-11-20 01:43:27 --> Model Class Initialized
INFO - 2016-11-20 01:43:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 01:43:27 --> Pagination Class Initialized
INFO - 2016-11-20 01:43:27 --> Helper loaded: app_helper
INFO - 2016-11-20 01:43:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 01:43:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
DEBUG - 2016-11-20 01:43:27 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-11-20 01:43:27 --> Pagination class already loaded. Second attempt ignored.
INFO - 2016-11-20 01:43:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 01:43:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 01:43:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 01:43:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 01:43:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 01:43:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 01:43:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 01:43:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 01:43:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 01:43:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 01:43:27 --> Final output sent to browser
DEBUG - 2016-11-20 01:43:27 --> Total execution time: 0.4299
INFO - 2016-11-20 01:44:26 --> Config Class Initialized
INFO - 2016-11-20 01:44:26 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:44:26 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:44:26 --> Utf8 Class Initialized
INFO - 2016-11-20 01:44:26 --> URI Class Initialized
DEBUG - 2016-11-20 01:44:26 --> No URI present. Default controller set.
INFO - 2016-11-20 01:44:26 --> Router Class Initialized
INFO - 2016-11-20 01:44:26 --> Output Class Initialized
INFO - 2016-11-20 01:44:26 --> Security Class Initialized
DEBUG - 2016-11-20 01:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:44:26 --> Input Class Initialized
INFO - 2016-11-20 01:44:26 --> Language Class Initialized
INFO - 2016-11-20 01:44:26 --> Loader Class Initialized
INFO - 2016-11-20 01:44:26 --> Helper loaded: url_helper
INFO - 2016-11-20 01:44:26 --> Helper loaded: form_helper
INFO - 2016-11-20 01:44:26 --> Database Driver Class Initialized
INFO - 2016-11-20 01:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:44:26 --> Controller Class Initialized
INFO - 2016-11-20 01:44:26 --> Model Class Initialized
INFO - 2016-11-20 01:44:26 --> Model Class Initialized
INFO - 2016-11-20 01:44:26 --> Model Class Initialized
INFO - 2016-11-20 01:44:26 --> Model Class Initialized
INFO - 2016-11-20 01:44:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 01:44:26 --> Pagination Class Initialized
INFO - 2016-11-20 01:44:26 --> Helper loaded: app_helper
INFO - 2016-11-20 01:44:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 01:44:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-20 01:44:26 --> Severity: Notice --> Undefined property: Auth::$ajax_pagination C:\xampp\htdocs\LMS\app\helpers\app_helper.php 60
ERROR - 2016-11-20 01:44:26 --> Severity: Error --> Call to a member function initialize() on null C:\xampp\htdocs\LMS\app\helpers\app_helper.php 60
INFO - 2016-11-20 01:44:42 --> Config Class Initialized
INFO - 2016-11-20 01:44:42 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:44:42 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:44:42 --> Utf8 Class Initialized
INFO - 2016-11-20 01:44:42 --> URI Class Initialized
DEBUG - 2016-11-20 01:44:42 --> No URI present. Default controller set.
INFO - 2016-11-20 01:44:42 --> Router Class Initialized
INFO - 2016-11-20 01:44:42 --> Output Class Initialized
INFO - 2016-11-20 01:44:42 --> Security Class Initialized
DEBUG - 2016-11-20 01:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:44:42 --> Input Class Initialized
INFO - 2016-11-20 01:44:42 --> Language Class Initialized
INFO - 2016-11-20 01:44:42 --> Loader Class Initialized
INFO - 2016-11-20 01:44:42 --> Helper loaded: url_helper
INFO - 2016-11-20 01:44:42 --> Helper loaded: form_helper
INFO - 2016-11-20 01:44:42 --> Database Driver Class Initialized
INFO - 2016-11-20 01:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:44:42 --> Controller Class Initialized
INFO - 2016-11-20 01:44:42 --> Model Class Initialized
INFO - 2016-11-20 01:44:42 --> Model Class Initialized
INFO - 2016-11-20 01:44:42 --> Model Class Initialized
INFO - 2016-11-20 01:44:42 --> Model Class Initialized
INFO - 2016-11-20 01:44:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 01:44:42 --> Pagination Class Initialized
INFO - 2016-11-20 01:44:42 --> Helper loaded: app_helper
INFO - 2016-11-20 01:44:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 01:44:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
DEBUG - 2016-11-20 01:44:42 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-11-20 01:44:42 --> Pagination class already loaded. Second attempt ignored.
ERROR - 2016-11-20 01:44:42 --> Severity: Notice --> Undefined variable: pagination_links_leaves C:\xampp\htdocs\LMS\app\controllers\Auth.php 83
INFO - 2016-11-20 01:44:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 01:44:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 01:44:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 01:44:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 01:44:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 01:44:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 01:44:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 01:44:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 01:44:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 01:44:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 01:44:42 --> Final output sent to browser
DEBUG - 2016-11-20 01:44:42 --> Total execution time: 0.4532
INFO - 2016-11-20 01:45:03 --> Config Class Initialized
INFO - 2016-11-20 01:45:03 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:45:03 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:45:03 --> Utf8 Class Initialized
INFO - 2016-11-20 01:45:03 --> URI Class Initialized
DEBUG - 2016-11-20 01:45:03 --> No URI present. Default controller set.
INFO - 2016-11-20 01:45:03 --> Router Class Initialized
INFO - 2016-11-20 01:45:03 --> Output Class Initialized
INFO - 2016-11-20 01:45:03 --> Security Class Initialized
DEBUG - 2016-11-20 01:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:45:03 --> Input Class Initialized
INFO - 2016-11-20 01:45:03 --> Language Class Initialized
INFO - 2016-11-20 01:45:03 --> Loader Class Initialized
INFO - 2016-11-20 01:45:03 --> Helper loaded: url_helper
INFO - 2016-11-20 01:45:03 --> Helper loaded: form_helper
INFO - 2016-11-20 01:45:03 --> Database Driver Class Initialized
INFO - 2016-11-20 01:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:45:03 --> Controller Class Initialized
INFO - 2016-11-20 01:45:03 --> Model Class Initialized
INFO - 2016-11-20 01:45:03 --> Model Class Initialized
INFO - 2016-11-20 01:45:03 --> Model Class Initialized
INFO - 2016-11-20 01:45:03 --> Model Class Initialized
INFO - 2016-11-20 01:45:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 01:45:03 --> Pagination Class Initialized
INFO - 2016-11-20 01:45:03 --> Helper loaded: app_helper
INFO - 2016-11-20 01:45:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 01:45:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
DEBUG - 2016-11-20 01:45:03 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-11-20 01:45:03 --> Pagination class already loaded. Second attempt ignored.
INFO - 2016-11-20 01:45:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 01:45:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 01:45:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 01:45:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 01:45:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 01:45:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 01:45:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 01:45:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 01:45:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 01:45:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 01:45:03 --> Final output sent to browser
DEBUG - 2016-11-20 01:45:03 --> Total execution time: 0.4710
INFO - 2016-11-20 01:45:26 --> Config Class Initialized
INFO - 2016-11-20 01:45:26 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:45:26 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:45:26 --> Utf8 Class Initialized
INFO - 2016-11-20 01:45:26 --> URI Class Initialized
DEBUG - 2016-11-20 01:45:26 --> No URI present. Default controller set.
INFO - 2016-11-20 01:45:26 --> Router Class Initialized
INFO - 2016-11-20 01:45:26 --> Output Class Initialized
INFO - 2016-11-20 01:45:26 --> Security Class Initialized
DEBUG - 2016-11-20 01:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:45:27 --> Input Class Initialized
INFO - 2016-11-20 01:45:27 --> Language Class Initialized
INFO - 2016-11-20 01:45:27 --> Loader Class Initialized
INFO - 2016-11-20 01:45:27 --> Helper loaded: url_helper
INFO - 2016-11-20 01:45:27 --> Helper loaded: form_helper
INFO - 2016-11-20 01:45:27 --> Database Driver Class Initialized
INFO - 2016-11-20 01:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:45:27 --> Controller Class Initialized
INFO - 2016-11-20 01:45:27 --> Model Class Initialized
INFO - 2016-11-20 01:45:27 --> Model Class Initialized
INFO - 2016-11-20 01:45:27 --> Model Class Initialized
INFO - 2016-11-20 01:45:27 --> Model Class Initialized
INFO - 2016-11-20 01:45:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 01:45:27 --> Pagination Class Initialized
INFO - 2016-11-20 01:45:27 --> Helper loaded: app_helper
INFO - 2016-11-20 01:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 01:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 01:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 01:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 01:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 01:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 01:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 01:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 01:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 01:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 01:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 01:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 01:45:27 --> Final output sent to browser
DEBUG - 2016-11-20 01:45:27 --> Total execution time: 0.4544
INFO - 2016-11-20 01:46:41 --> Config Class Initialized
INFO - 2016-11-20 01:46:41 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:46:41 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:46:41 --> Utf8 Class Initialized
INFO - 2016-11-20 01:46:41 --> URI Class Initialized
DEBUG - 2016-11-20 01:46:41 --> No URI present. Default controller set.
INFO - 2016-11-20 01:46:41 --> Router Class Initialized
INFO - 2016-11-20 01:46:41 --> Output Class Initialized
INFO - 2016-11-20 01:46:41 --> Security Class Initialized
DEBUG - 2016-11-20 01:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:46:41 --> Input Class Initialized
INFO - 2016-11-20 01:46:41 --> Language Class Initialized
INFO - 2016-11-20 01:46:41 --> Loader Class Initialized
INFO - 2016-11-20 01:46:41 --> Helper loaded: url_helper
INFO - 2016-11-20 01:46:41 --> Helper loaded: form_helper
INFO - 2016-11-20 01:46:41 --> Database Driver Class Initialized
INFO - 2016-11-20 01:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:46:41 --> Controller Class Initialized
INFO - 2016-11-20 01:46:41 --> Model Class Initialized
INFO - 2016-11-20 01:46:41 --> Model Class Initialized
INFO - 2016-11-20 01:46:41 --> Model Class Initialized
INFO - 2016-11-20 01:46:41 --> Model Class Initialized
INFO - 2016-11-20 01:46:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 01:46:41 --> Pagination Class Initialized
INFO - 2016-11-20 01:46:41 --> Helper loaded: app_helper
INFO - 2016-11-20 01:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 01:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 01:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 01:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 01:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 01:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 01:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 01:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 01:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 01:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 01:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 01:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 01:46:41 --> Final output sent to browser
DEBUG - 2016-11-20 01:46:41 --> Total execution time: 0.4390
INFO - 2016-11-20 01:47:49 --> Config Class Initialized
INFO - 2016-11-20 01:47:49 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:47:49 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:47:49 --> Utf8 Class Initialized
INFO - 2016-11-20 01:47:49 --> URI Class Initialized
DEBUG - 2016-11-20 01:47:49 --> No URI present. Default controller set.
INFO - 2016-11-20 01:47:49 --> Router Class Initialized
INFO - 2016-11-20 01:47:49 --> Output Class Initialized
INFO - 2016-11-20 01:47:49 --> Security Class Initialized
DEBUG - 2016-11-20 01:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:47:49 --> Input Class Initialized
INFO - 2016-11-20 01:47:49 --> Language Class Initialized
INFO - 2016-11-20 01:47:49 --> Loader Class Initialized
INFO - 2016-11-20 01:47:49 --> Helper loaded: url_helper
INFO - 2016-11-20 01:47:49 --> Helper loaded: form_helper
INFO - 2016-11-20 01:47:49 --> Database Driver Class Initialized
INFO - 2016-11-20 01:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:47:49 --> Controller Class Initialized
INFO - 2016-11-20 01:47:49 --> Model Class Initialized
INFO - 2016-11-20 01:47:49 --> Model Class Initialized
INFO - 2016-11-20 01:47:49 --> Model Class Initialized
INFO - 2016-11-20 01:47:49 --> Model Class Initialized
INFO - 2016-11-20 01:47:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 01:47:49 --> Pagination Class Initialized
INFO - 2016-11-20 01:47:49 --> Helper loaded: app_helper
INFO - 2016-11-20 01:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 01:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 01:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 01:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 01:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 01:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 01:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 01:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 01:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 01:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 01:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 01:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 01:47:49 --> Final output sent to browser
DEBUG - 2016-11-20 01:47:49 --> Total execution time: 0.4632
INFO - 2016-11-20 01:48:18 --> Config Class Initialized
INFO - 2016-11-20 01:48:18 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:48:18 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:48:18 --> Utf8 Class Initialized
INFO - 2016-11-20 01:48:18 --> URI Class Initialized
DEBUG - 2016-11-20 01:48:18 --> No URI present. Default controller set.
INFO - 2016-11-20 01:48:18 --> Router Class Initialized
INFO - 2016-11-20 01:48:18 --> Output Class Initialized
INFO - 2016-11-20 01:48:18 --> Security Class Initialized
DEBUG - 2016-11-20 01:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:48:18 --> Input Class Initialized
INFO - 2016-11-20 01:48:18 --> Language Class Initialized
INFO - 2016-11-20 01:48:18 --> Loader Class Initialized
INFO - 2016-11-20 01:48:18 --> Helper loaded: url_helper
INFO - 2016-11-20 01:48:18 --> Helper loaded: form_helper
INFO - 2016-11-20 01:48:18 --> Database Driver Class Initialized
INFO - 2016-11-20 01:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:48:19 --> Controller Class Initialized
INFO - 2016-11-20 01:48:19 --> Model Class Initialized
INFO - 2016-11-20 01:48:19 --> Model Class Initialized
INFO - 2016-11-20 01:48:19 --> Model Class Initialized
INFO - 2016-11-20 01:48:19 --> Model Class Initialized
INFO - 2016-11-20 01:48:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 01:48:19 --> Pagination Class Initialized
INFO - 2016-11-20 01:48:19 --> Helper loaded: app_helper
INFO - 2016-11-20 01:48:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 01:48:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 01:48:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 01:48:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 01:48:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 01:48:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 01:48:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 01:48:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 01:48:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 01:48:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 01:48:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 01:48:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 01:48:19 --> Final output sent to browser
DEBUG - 2016-11-20 01:48:19 --> Total execution time: 0.4618
INFO - 2016-11-20 01:49:14 --> Config Class Initialized
INFO - 2016-11-20 01:49:14 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:49:14 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:49:14 --> Utf8 Class Initialized
INFO - 2016-11-20 01:49:14 --> URI Class Initialized
DEBUG - 2016-11-20 01:49:14 --> No URI present. Default controller set.
INFO - 2016-11-20 01:49:14 --> Router Class Initialized
INFO - 2016-11-20 01:49:14 --> Output Class Initialized
INFO - 2016-11-20 01:49:14 --> Security Class Initialized
DEBUG - 2016-11-20 01:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:49:14 --> Input Class Initialized
INFO - 2016-11-20 01:49:14 --> Language Class Initialized
INFO - 2016-11-20 01:49:14 --> Loader Class Initialized
INFO - 2016-11-20 01:49:14 --> Helper loaded: url_helper
INFO - 2016-11-20 01:49:14 --> Helper loaded: form_helper
INFO - 2016-11-20 01:49:14 --> Database Driver Class Initialized
INFO - 2016-11-20 01:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:49:14 --> Controller Class Initialized
INFO - 2016-11-20 01:49:14 --> Model Class Initialized
INFO - 2016-11-20 01:49:14 --> Model Class Initialized
INFO - 2016-11-20 01:49:14 --> Model Class Initialized
INFO - 2016-11-20 01:49:14 --> Model Class Initialized
INFO - 2016-11-20 01:49:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 01:49:14 --> Pagination Class Initialized
INFO - 2016-11-20 01:49:14 --> Helper loaded: app_helper
INFO - 2016-11-20 01:49:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 01:49:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 01:49:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 01:49:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 01:49:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 01:49:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 01:49:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 01:49:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 01:49:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 01:49:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 01:49:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 01:49:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 01:49:14 --> Final output sent to browser
DEBUG - 2016-11-20 01:49:14 --> Total execution time: 0.4390
INFO - 2016-11-20 01:50:01 --> Config Class Initialized
INFO - 2016-11-20 01:50:01 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:50:01 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:50:01 --> Utf8 Class Initialized
INFO - 2016-11-20 01:50:01 --> URI Class Initialized
DEBUG - 2016-11-20 01:50:01 --> No URI present. Default controller set.
INFO - 2016-11-20 01:50:01 --> Router Class Initialized
INFO - 2016-11-20 01:50:01 --> Output Class Initialized
INFO - 2016-11-20 01:50:01 --> Security Class Initialized
DEBUG - 2016-11-20 01:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:50:01 --> Input Class Initialized
INFO - 2016-11-20 01:50:01 --> Language Class Initialized
INFO - 2016-11-20 01:50:01 --> Loader Class Initialized
INFO - 2016-11-20 01:50:01 --> Helper loaded: url_helper
INFO - 2016-11-20 01:50:01 --> Helper loaded: form_helper
INFO - 2016-11-20 01:50:01 --> Database Driver Class Initialized
INFO - 2016-11-20 01:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:50:01 --> Controller Class Initialized
INFO - 2016-11-20 01:50:01 --> Model Class Initialized
INFO - 2016-11-20 01:50:01 --> Model Class Initialized
INFO - 2016-11-20 01:50:01 --> Model Class Initialized
INFO - 2016-11-20 01:50:01 --> Model Class Initialized
INFO - 2016-11-20 01:50:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 01:50:01 --> Pagination Class Initialized
INFO - 2016-11-20 01:50:01 --> Helper loaded: app_helper
INFO - 2016-11-20 01:50:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 01:50:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 01:50:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 01:50:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 01:50:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 01:50:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 01:50:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 01:50:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 01:50:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 01:50:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 01:50:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 01:50:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 01:50:01 --> Final output sent to browser
DEBUG - 2016-11-20 01:50:01 --> Total execution time: 0.4624
INFO - 2016-11-20 01:50:50 --> Config Class Initialized
INFO - 2016-11-20 01:50:50 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:50:50 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:50:50 --> Utf8 Class Initialized
INFO - 2016-11-20 01:50:50 --> URI Class Initialized
DEBUG - 2016-11-20 01:50:50 --> No URI present. Default controller set.
INFO - 2016-11-20 01:50:50 --> Router Class Initialized
INFO - 2016-11-20 01:50:50 --> Output Class Initialized
INFO - 2016-11-20 01:50:50 --> Security Class Initialized
DEBUG - 2016-11-20 01:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:50:50 --> Input Class Initialized
INFO - 2016-11-20 01:50:50 --> Language Class Initialized
INFO - 2016-11-20 01:50:50 --> Loader Class Initialized
INFO - 2016-11-20 01:50:50 --> Helper loaded: url_helper
INFO - 2016-11-20 01:50:50 --> Helper loaded: form_helper
INFO - 2016-11-20 01:50:50 --> Database Driver Class Initialized
INFO - 2016-11-20 01:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:50:50 --> Controller Class Initialized
INFO - 2016-11-20 01:50:50 --> Model Class Initialized
INFO - 2016-11-20 01:50:50 --> Model Class Initialized
INFO - 2016-11-20 01:50:50 --> Model Class Initialized
INFO - 2016-11-20 01:50:50 --> Model Class Initialized
INFO - 2016-11-20 01:50:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 01:50:50 --> Pagination Class Initialized
INFO - 2016-11-20 01:50:50 --> Helper loaded: app_helper
INFO - 2016-11-20 01:50:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 01:50:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 01:50:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 01:50:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 01:50:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 01:50:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 01:50:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 01:50:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 01:50:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 01:50:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 01:50:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 01:50:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 01:50:50 --> Final output sent to browser
DEBUG - 2016-11-20 01:50:50 --> Total execution time: 0.4490
INFO - 2016-11-20 01:51:04 --> Config Class Initialized
INFO - 2016-11-20 01:51:04 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:51:04 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:51:04 --> Utf8 Class Initialized
INFO - 2016-11-20 01:51:04 --> URI Class Initialized
DEBUG - 2016-11-20 01:51:04 --> No URI present. Default controller set.
INFO - 2016-11-20 01:51:04 --> Router Class Initialized
INFO - 2016-11-20 01:51:04 --> Output Class Initialized
INFO - 2016-11-20 01:51:04 --> Security Class Initialized
DEBUG - 2016-11-20 01:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:51:04 --> Input Class Initialized
INFO - 2016-11-20 01:51:04 --> Language Class Initialized
INFO - 2016-11-20 01:51:04 --> Loader Class Initialized
INFO - 2016-11-20 01:51:04 --> Helper loaded: url_helper
INFO - 2016-11-20 01:51:04 --> Helper loaded: form_helper
INFO - 2016-11-20 01:51:04 --> Database Driver Class Initialized
INFO - 2016-11-20 01:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:51:04 --> Controller Class Initialized
INFO - 2016-11-20 01:51:04 --> Model Class Initialized
INFO - 2016-11-20 01:51:04 --> Model Class Initialized
INFO - 2016-11-20 01:51:04 --> Model Class Initialized
INFO - 2016-11-20 01:51:04 --> Model Class Initialized
INFO - 2016-11-20 01:51:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 01:51:04 --> Pagination Class Initialized
INFO - 2016-11-20 01:51:04 --> Helper loaded: app_helper
INFO - 2016-11-20 01:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 01:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 01:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 01:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 01:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 01:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 01:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 01:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 01:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 01:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 01:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 01:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 01:51:04 --> Final output sent to browser
DEBUG - 2016-11-20 01:51:04 --> Total execution time: 0.5010
INFO - 2016-11-20 01:56:59 --> Config Class Initialized
INFO - 2016-11-20 01:56:59 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:56:59 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:56:59 --> Utf8 Class Initialized
INFO - 2016-11-20 01:56:59 --> URI Class Initialized
DEBUG - 2016-11-20 01:56:59 --> No URI present. Default controller set.
INFO - 2016-11-20 01:56:59 --> Router Class Initialized
INFO - 2016-11-20 01:56:59 --> Output Class Initialized
INFO - 2016-11-20 01:56:59 --> Security Class Initialized
DEBUG - 2016-11-20 01:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:56:59 --> Input Class Initialized
INFO - 2016-11-20 01:56:59 --> Language Class Initialized
INFO - 2016-11-20 01:56:59 --> Loader Class Initialized
INFO - 2016-11-20 01:56:59 --> Helper loaded: url_helper
INFO - 2016-11-20 01:56:59 --> Helper loaded: form_helper
INFO - 2016-11-20 01:56:59 --> Database Driver Class Initialized
INFO - 2016-11-20 01:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:56:59 --> Controller Class Initialized
INFO - 2016-11-20 01:56:59 --> Model Class Initialized
INFO - 2016-11-20 01:56:59 --> Model Class Initialized
INFO - 2016-11-20 01:56:59 --> Model Class Initialized
INFO - 2016-11-20 01:56:59 --> Model Class Initialized
INFO - 2016-11-20 01:56:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 01:56:59 --> Pagination Class Initialized
INFO - 2016-11-20 01:56:59 --> Helper loaded: app_helper
INFO - 2016-11-20 01:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 01:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 01:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 01:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 01:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 01:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 01:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 01:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 01:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 01:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 01:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 01:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 01:56:59 --> Final output sent to browser
DEBUG - 2016-11-20 01:56:59 --> Total execution time: 0.5177
INFO - 2016-11-20 01:57:23 --> Config Class Initialized
INFO - 2016-11-20 01:57:23 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:57:23 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:57:23 --> Utf8 Class Initialized
INFO - 2016-11-20 01:57:23 --> URI Class Initialized
DEBUG - 2016-11-20 01:57:23 --> No URI present. Default controller set.
INFO - 2016-11-20 01:57:23 --> Router Class Initialized
INFO - 2016-11-20 01:57:23 --> Output Class Initialized
INFO - 2016-11-20 01:57:23 --> Security Class Initialized
DEBUG - 2016-11-20 01:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:57:23 --> Input Class Initialized
INFO - 2016-11-20 01:57:23 --> Language Class Initialized
INFO - 2016-11-20 01:57:23 --> Loader Class Initialized
INFO - 2016-11-20 01:57:23 --> Helper loaded: url_helper
INFO - 2016-11-20 01:57:23 --> Helper loaded: form_helper
INFO - 2016-11-20 01:57:23 --> Database Driver Class Initialized
INFO - 2016-11-20 01:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:57:23 --> Controller Class Initialized
INFO - 2016-11-20 01:57:23 --> Model Class Initialized
INFO - 2016-11-20 01:57:23 --> Model Class Initialized
INFO - 2016-11-20 01:57:23 --> Model Class Initialized
INFO - 2016-11-20 01:57:23 --> Model Class Initialized
INFO - 2016-11-20 01:57:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 01:57:24 --> Pagination Class Initialized
INFO - 2016-11-20 01:57:24 --> Helper loaded: app_helper
INFO - 2016-11-20 01:57:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 01:57:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 01:57:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 01:57:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 01:57:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 01:57:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 01:57:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 01:57:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 01:57:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 01:57:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 01:57:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 01:57:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 01:57:24 --> Final output sent to browser
DEBUG - 2016-11-20 01:57:24 --> Total execution time: 0.5312
INFO - 2016-11-20 01:57:34 --> Config Class Initialized
INFO - 2016-11-20 01:57:34 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:57:34 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:57:34 --> Utf8 Class Initialized
INFO - 2016-11-20 01:57:34 --> URI Class Initialized
INFO - 2016-11-20 01:57:34 --> Router Class Initialized
INFO - 2016-11-20 01:57:34 --> Output Class Initialized
INFO - 2016-11-20 01:57:34 --> Security Class Initialized
DEBUG - 2016-11-20 01:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:57:34 --> Input Class Initialized
INFO - 2016-11-20 01:57:34 --> Language Class Initialized
INFO - 2016-11-20 01:57:34 --> Loader Class Initialized
INFO - 2016-11-20 01:57:34 --> Helper loaded: url_helper
INFO - 2016-11-20 01:57:34 --> Helper loaded: form_helper
INFO - 2016-11-20 01:57:35 --> Database Driver Class Initialized
INFO - 2016-11-20 01:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:57:35 --> Controller Class Initialized
INFO - 2016-11-20 01:57:35 --> Model Class Initialized
ERROR - 2016-11-20 01:57:35 --> Severity: Error --> Call to undefined function pagination() C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 113
INFO - 2016-11-20 01:57:38 --> Config Class Initialized
INFO - 2016-11-20 01:57:38 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:57:38 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:57:38 --> Utf8 Class Initialized
INFO - 2016-11-20 01:57:38 --> URI Class Initialized
DEBUG - 2016-11-20 01:57:38 --> No URI present. Default controller set.
INFO - 2016-11-20 01:57:38 --> Router Class Initialized
INFO - 2016-11-20 01:57:38 --> Output Class Initialized
INFO - 2016-11-20 01:57:38 --> Security Class Initialized
DEBUG - 2016-11-20 01:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:57:38 --> Input Class Initialized
INFO - 2016-11-20 01:57:38 --> Language Class Initialized
INFO - 2016-11-20 01:57:38 --> Loader Class Initialized
INFO - 2016-11-20 01:57:38 --> Helper loaded: url_helper
INFO - 2016-11-20 01:57:38 --> Helper loaded: form_helper
INFO - 2016-11-20 01:57:38 --> Database Driver Class Initialized
INFO - 2016-11-20 01:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:57:38 --> Controller Class Initialized
INFO - 2016-11-20 01:57:38 --> Model Class Initialized
INFO - 2016-11-20 01:57:38 --> Model Class Initialized
INFO - 2016-11-20 01:57:38 --> Model Class Initialized
INFO - 2016-11-20 01:57:38 --> Model Class Initialized
INFO - 2016-11-20 01:57:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 01:57:38 --> Pagination Class Initialized
INFO - 2016-11-20 01:57:38 --> Helper loaded: app_helper
INFO - 2016-11-20 01:57:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 01:57:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 01:57:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 01:57:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 01:57:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 01:57:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 01:57:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 01:57:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 01:57:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 01:57:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 01:57:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 01:57:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 01:57:38 --> Final output sent to browser
DEBUG - 2016-11-20 01:57:39 --> Total execution time: 0.5042
INFO - 2016-11-20 01:58:06 --> Config Class Initialized
INFO - 2016-11-20 01:58:06 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:58:06 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:58:06 --> Utf8 Class Initialized
INFO - 2016-11-20 01:58:06 --> URI Class Initialized
INFO - 2016-11-20 01:58:06 --> Router Class Initialized
INFO - 2016-11-20 01:58:06 --> Output Class Initialized
INFO - 2016-11-20 01:58:06 --> Security Class Initialized
DEBUG - 2016-11-20 01:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:58:06 --> Input Class Initialized
INFO - 2016-11-20 01:58:06 --> Language Class Initialized
INFO - 2016-11-20 01:58:06 --> Loader Class Initialized
INFO - 2016-11-20 01:58:06 --> Helper loaded: url_helper
INFO - 2016-11-20 01:58:06 --> Helper loaded: form_helper
INFO - 2016-11-20 01:58:06 --> Database Driver Class Initialized
INFO - 2016-11-20 01:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:58:06 --> Controller Class Initialized
INFO - 2016-11-20 01:58:06 --> Model Class Initialized
INFO - 2016-11-20 01:58:06 --> Form Validation Class Initialized
ERROR - 2016-11-20 01:58:06 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 01:58:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 01:58:06 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 01:58:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 01:58:06 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 01:58:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 01:58:06 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 01:58:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 01:58:06 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-11-20 01:58:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 01:58:07 --> Final output sent to browser
DEBUG - 2016-11-20 01:58:07 --> Total execution time: 0.4430
INFO - 2016-11-20 01:58:07 --> Config Class Initialized
INFO - 2016-11-20 01:58:07 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:58:07 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:58:07 --> Utf8 Class Initialized
INFO - 2016-11-20 01:58:07 --> URI Class Initialized
DEBUG - 2016-11-20 01:58:07 --> No URI present. Default controller set.
INFO - 2016-11-20 01:58:07 --> Router Class Initialized
INFO - 2016-11-20 01:58:07 --> Output Class Initialized
INFO - 2016-11-20 01:58:07 --> Security Class Initialized
DEBUG - 2016-11-20 01:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:58:07 --> Input Class Initialized
INFO - 2016-11-20 01:58:07 --> Language Class Initialized
INFO - 2016-11-20 01:58:07 --> Loader Class Initialized
INFO - 2016-11-20 01:58:07 --> Helper loaded: url_helper
INFO - 2016-11-20 01:58:07 --> Helper loaded: form_helper
INFO - 2016-11-20 01:58:07 --> Database Driver Class Initialized
INFO - 2016-11-20 01:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:58:07 --> Controller Class Initialized
INFO - 2016-11-20 01:58:07 --> Model Class Initialized
INFO - 2016-11-20 01:58:07 --> Model Class Initialized
INFO - 2016-11-20 01:58:07 --> Model Class Initialized
INFO - 2016-11-20 01:58:07 --> Model Class Initialized
INFO - 2016-11-20 01:58:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 01:58:07 --> Pagination Class Initialized
INFO - 2016-11-20 01:58:07 --> Helper loaded: app_helper
INFO - 2016-11-20 01:58:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 01:58:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 01:58:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 01:58:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 01:58:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 01:58:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 01:58:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 01:58:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 01:58:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 01:58:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 01:58:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 01:58:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 01:58:07 --> Final output sent to browser
DEBUG - 2016-11-20 01:58:07 --> Total execution time: 0.4294
INFO - 2016-11-20 01:58:19 --> Config Class Initialized
INFO - 2016-11-20 01:58:19 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:58:19 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:58:19 --> Utf8 Class Initialized
INFO - 2016-11-20 01:58:19 --> URI Class Initialized
INFO - 2016-11-20 01:58:19 --> Router Class Initialized
INFO - 2016-11-20 01:58:19 --> Output Class Initialized
INFO - 2016-11-20 01:58:19 --> Security Class Initialized
DEBUG - 2016-11-20 01:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:58:19 --> Input Class Initialized
INFO - 2016-11-20 01:58:19 --> Language Class Initialized
INFO - 2016-11-20 01:58:19 --> Loader Class Initialized
INFO - 2016-11-20 01:58:19 --> Helper loaded: url_helper
INFO - 2016-11-20 01:58:19 --> Helper loaded: form_helper
INFO - 2016-11-20 01:58:19 --> Database Driver Class Initialized
INFO - 2016-11-20 01:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:58:19 --> Controller Class Initialized
INFO - 2016-11-20 01:58:19 --> Model Class Initialized
INFO - 2016-11-20 01:58:19 --> Model Class Initialized
INFO - 2016-11-20 01:58:19 --> Model Class Initialized
INFO - 2016-11-20 01:58:19 --> Model Class Initialized
INFO - 2016-11-20 01:58:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 01:58:19 --> Pagination Class Initialized
INFO - 2016-11-20 01:58:19 --> Helper loaded: app_helper
DEBUG - 2016-11-20 01:58:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-20 01:58:19 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 168
ERROR - 2016-11-20 01:58:19 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 168
INFO - 2016-11-20 01:58:19 --> Config Class Initialized
INFO - 2016-11-20 01:58:19 --> Hooks Class Initialized
DEBUG - 2016-11-20 01:58:19 --> UTF-8 Support Enabled
INFO - 2016-11-20 01:58:19 --> Utf8 Class Initialized
INFO - 2016-11-20 01:58:19 --> URI Class Initialized
DEBUG - 2016-11-20 01:58:19 --> No URI present. Default controller set.
INFO - 2016-11-20 01:58:19 --> Router Class Initialized
INFO - 2016-11-20 01:58:19 --> Output Class Initialized
INFO - 2016-11-20 01:58:19 --> Security Class Initialized
DEBUG - 2016-11-20 01:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 01:58:19 --> Input Class Initialized
INFO - 2016-11-20 01:58:19 --> Language Class Initialized
INFO - 2016-11-20 01:58:19 --> Loader Class Initialized
INFO - 2016-11-20 01:58:19 --> Helper loaded: url_helper
INFO - 2016-11-20 01:58:19 --> Helper loaded: form_helper
INFO - 2016-11-20 01:58:19 --> Database Driver Class Initialized
INFO - 2016-11-20 01:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 01:58:19 --> Controller Class Initialized
INFO - 2016-11-20 01:58:19 --> Model Class Initialized
INFO - 2016-11-20 01:58:19 --> Model Class Initialized
INFO - 2016-11-20 01:58:19 --> Model Class Initialized
INFO - 2016-11-20 01:58:19 --> Model Class Initialized
INFO - 2016-11-20 01:58:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 01:58:19 --> Pagination Class Initialized
INFO - 2016-11-20 01:58:19 --> Helper loaded: app_helper
INFO - 2016-11-20 01:58:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 01:58:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-20 01:58:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 01:58:19 --> Final output sent to browser
DEBUG - 2016-11-20 01:58:19 --> Total execution time: 0.3297
INFO - 2016-11-20 13:57:45 --> Config Class Initialized
INFO - 2016-11-20 13:57:45 --> Hooks Class Initialized
DEBUG - 2016-11-20 13:57:46 --> UTF-8 Support Enabled
INFO - 2016-11-20 13:57:46 --> Utf8 Class Initialized
INFO - 2016-11-20 13:57:46 --> URI Class Initialized
DEBUG - 2016-11-20 13:57:46 --> No URI present. Default controller set.
INFO - 2016-11-20 13:57:46 --> Router Class Initialized
INFO - 2016-11-20 13:57:46 --> Output Class Initialized
INFO - 2016-11-20 13:57:46 --> Security Class Initialized
DEBUG - 2016-11-20 13:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 13:57:46 --> Input Class Initialized
INFO - 2016-11-20 13:57:46 --> Language Class Initialized
INFO - 2016-11-20 13:57:46 --> Loader Class Initialized
INFO - 2016-11-20 13:57:46 --> Helper loaded: url_helper
INFO - 2016-11-20 13:57:46 --> Helper loaded: form_helper
INFO - 2016-11-20 13:57:46 --> Database Driver Class Initialized
INFO - 2016-11-20 13:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 13:57:46 --> Controller Class Initialized
INFO - 2016-11-20 13:57:46 --> Model Class Initialized
INFO - 2016-11-20 13:57:46 --> Model Class Initialized
INFO - 2016-11-20 13:57:46 --> Model Class Initialized
INFO - 2016-11-20 13:57:47 --> Model Class Initialized
INFO - 2016-11-20 13:57:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 13:57:47 --> Pagination Class Initialized
INFO - 2016-11-20 13:57:47 --> Helper loaded: app_helper
INFO - 2016-11-20 13:57:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 13:57:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-20 13:57:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 13:57:47 --> Final output sent to browser
DEBUG - 2016-11-20 13:57:47 --> Total execution time: 1.6320
INFO - 2016-11-20 13:58:24 --> Config Class Initialized
INFO - 2016-11-20 13:58:24 --> Hooks Class Initialized
DEBUG - 2016-11-20 13:58:24 --> UTF-8 Support Enabled
INFO - 2016-11-20 13:58:24 --> Utf8 Class Initialized
INFO - 2016-11-20 13:58:24 --> URI Class Initialized
INFO - 2016-11-20 13:58:24 --> Router Class Initialized
INFO - 2016-11-20 13:58:24 --> Output Class Initialized
INFO - 2016-11-20 13:58:24 --> Security Class Initialized
DEBUG - 2016-11-20 13:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 13:58:24 --> Input Class Initialized
INFO - 2016-11-20 13:58:24 --> Language Class Initialized
INFO - 2016-11-20 13:58:24 --> Loader Class Initialized
INFO - 2016-11-20 13:58:24 --> Helper loaded: url_helper
INFO - 2016-11-20 13:58:24 --> Helper loaded: form_helper
INFO - 2016-11-20 13:58:24 --> Database Driver Class Initialized
INFO - 2016-11-20 13:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 13:58:24 --> Controller Class Initialized
INFO - 2016-11-20 13:58:24 --> Model Class Initialized
INFO - 2016-11-20 13:58:24 --> Model Class Initialized
INFO - 2016-11-20 13:58:24 --> Model Class Initialized
INFO - 2016-11-20 13:58:24 --> Model Class Initialized
INFO - 2016-11-20 13:58:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 13:58:24 --> Pagination Class Initialized
INFO - 2016-11-20 13:58:24 --> Helper loaded: app_helper
DEBUG - 2016-11-20 13:58:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-20 13:58:24 --> Model Class Initialized
INFO - 2016-11-20 13:58:24 --> Final output sent to browser
DEBUG - 2016-11-20 13:58:24 --> Total execution time: 0.3803
INFO - 2016-11-20 13:58:24 --> Config Class Initialized
INFO - 2016-11-20 13:58:24 --> Hooks Class Initialized
DEBUG - 2016-11-20 13:58:24 --> UTF-8 Support Enabled
INFO - 2016-11-20 13:58:24 --> Utf8 Class Initialized
INFO - 2016-11-20 13:58:24 --> URI Class Initialized
DEBUG - 2016-11-20 13:58:24 --> No URI present. Default controller set.
INFO - 2016-11-20 13:58:24 --> Router Class Initialized
INFO - 2016-11-20 13:58:24 --> Output Class Initialized
INFO - 2016-11-20 13:58:24 --> Security Class Initialized
DEBUG - 2016-11-20 13:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 13:58:24 --> Input Class Initialized
INFO - 2016-11-20 13:58:24 --> Language Class Initialized
INFO - 2016-11-20 13:58:24 --> Loader Class Initialized
INFO - 2016-11-20 13:58:24 --> Helper loaded: url_helper
INFO - 2016-11-20 13:58:24 --> Helper loaded: form_helper
INFO - 2016-11-20 13:58:24 --> Database Driver Class Initialized
INFO - 2016-11-20 13:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 13:58:24 --> Controller Class Initialized
INFO - 2016-11-20 13:58:24 --> Model Class Initialized
INFO - 2016-11-20 13:58:24 --> Model Class Initialized
INFO - 2016-11-20 13:58:24 --> Model Class Initialized
INFO - 2016-11-20 13:58:24 --> Model Class Initialized
INFO - 2016-11-20 13:58:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 13:58:24 --> Pagination Class Initialized
INFO - 2016-11-20 13:58:24 --> Helper loaded: app_helper
INFO - 2016-11-20 13:58:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 13:58:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 13:58:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 13:58:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 13:58:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 13:58:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 13:58:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 13:58:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 13:58:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 13:58:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 13:58:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 13:58:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 13:58:25 --> Final output sent to browser
DEBUG - 2016-11-20 13:58:25 --> Total execution time: 1.0895
INFO - 2016-11-20 14:01:20 --> Config Class Initialized
INFO - 2016-11-20 14:01:20 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:01:20 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:01:20 --> Utf8 Class Initialized
INFO - 2016-11-20 14:01:20 --> URI Class Initialized
DEBUG - 2016-11-20 14:01:20 --> No URI present. Default controller set.
INFO - 2016-11-20 14:01:20 --> Router Class Initialized
INFO - 2016-11-20 14:01:20 --> Output Class Initialized
INFO - 2016-11-20 14:01:20 --> Security Class Initialized
DEBUG - 2016-11-20 14:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:01:20 --> Input Class Initialized
INFO - 2016-11-20 14:01:20 --> Language Class Initialized
INFO - 2016-11-20 14:01:20 --> Loader Class Initialized
INFO - 2016-11-20 14:01:20 --> Helper loaded: url_helper
INFO - 2016-11-20 14:01:20 --> Helper loaded: form_helper
INFO - 2016-11-20 14:01:20 --> Database Driver Class Initialized
INFO - 2016-11-20 14:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:01:20 --> Controller Class Initialized
INFO - 2016-11-20 14:01:20 --> Model Class Initialized
INFO - 2016-11-20 14:01:20 --> Model Class Initialized
INFO - 2016-11-20 14:01:20 --> Model Class Initialized
INFO - 2016-11-20 14:01:20 --> Model Class Initialized
INFO - 2016-11-20 14:01:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:01:21 --> Pagination Class Initialized
INFO - 2016-11-20 14:01:21 --> Helper loaded: app_helper
INFO - 2016-11-20 14:01:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:01:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 14:01:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 14:01:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 14:01:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 14:01:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 14:01:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 14:01:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 14:01:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 14:01:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 14:01:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 14:01:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 14:01:21 --> Final output sent to browser
DEBUG - 2016-11-20 14:01:21 --> Total execution time: 0.6005
INFO - 2016-11-20 14:02:25 --> Config Class Initialized
INFO - 2016-11-20 14:02:25 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:02:25 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:02:25 --> Utf8 Class Initialized
INFO - 2016-11-20 14:02:25 --> URI Class Initialized
DEBUG - 2016-11-20 14:02:25 --> No URI present. Default controller set.
INFO - 2016-11-20 14:02:25 --> Router Class Initialized
INFO - 2016-11-20 14:02:25 --> Output Class Initialized
INFO - 2016-11-20 14:02:25 --> Security Class Initialized
DEBUG - 2016-11-20 14:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:02:25 --> Input Class Initialized
INFO - 2016-11-20 14:02:25 --> Language Class Initialized
INFO - 2016-11-20 14:02:25 --> Loader Class Initialized
INFO - 2016-11-20 14:02:25 --> Helper loaded: url_helper
INFO - 2016-11-20 14:02:25 --> Helper loaded: form_helper
INFO - 2016-11-20 14:02:25 --> Database Driver Class Initialized
INFO - 2016-11-20 14:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:02:25 --> Controller Class Initialized
INFO - 2016-11-20 14:02:25 --> Model Class Initialized
INFO - 2016-11-20 14:02:25 --> Model Class Initialized
INFO - 2016-11-20 14:02:25 --> Model Class Initialized
INFO - 2016-11-20 14:02:25 --> Model Class Initialized
INFO - 2016-11-20 14:02:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:02:25 --> Pagination Class Initialized
INFO - 2016-11-20 14:02:25 --> Helper loaded: app_helper
INFO - 2016-11-20 14:02:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:02:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 14:02:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 14:02:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 14:02:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 14:02:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 14:02:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 14:02:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 14:02:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 14:02:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 14:02:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 14:02:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 14:02:25 --> Final output sent to browser
DEBUG - 2016-11-20 14:02:25 --> Total execution time: 0.4746
INFO - 2016-11-20 14:17:10 --> Config Class Initialized
INFO - 2016-11-20 14:17:10 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:17:10 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:17:10 --> Utf8 Class Initialized
INFO - 2016-11-20 14:17:10 --> URI Class Initialized
DEBUG - 2016-11-20 14:17:10 --> No URI present. Default controller set.
INFO - 2016-11-20 14:17:10 --> Router Class Initialized
INFO - 2016-11-20 14:17:10 --> Output Class Initialized
INFO - 2016-11-20 14:17:10 --> Security Class Initialized
DEBUG - 2016-11-20 14:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:17:10 --> Input Class Initialized
INFO - 2016-11-20 14:17:10 --> Language Class Initialized
INFO - 2016-11-20 14:17:10 --> Loader Class Initialized
INFO - 2016-11-20 14:17:10 --> Helper loaded: url_helper
INFO - 2016-11-20 14:17:10 --> Helper loaded: form_helper
INFO - 2016-11-20 14:17:10 --> Database Driver Class Initialized
INFO - 2016-11-20 14:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:17:10 --> Controller Class Initialized
INFO - 2016-11-20 14:17:10 --> Model Class Initialized
INFO - 2016-11-20 14:17:10 --> Model Class Initialized
INFO - 2016-11-20 14:17:10 --> Model Class Initialized
INFO - 2016-11-20 14:17:10 --> Model Class Initialized
INFO - 2016-11-20 14:17:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:17:10 --> Pagination Class Initialized
INFO - 2016-11-20 14:17:10 --> Helper loaded: app_helper
INFO - 2016-11-20 14:17:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:17:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-20 14:17:10 --> Severity: Warning --> Missing argument 1 for Leave_record_m::count_leave_records(), called in C:\xampp\htdocs\LMS\app\controllers\Auth.php on line 69 and defined C:\xampp\htdocs\LMS\app\models\Leave_record_m.php 47
ERROR - 2016-11-20 14:17:10 --> Severity: Warning --> Missing argument 2 for Leave_record_m::count_leave_records(), called in C:\xampp\htdocs\LMS\app\controllers\Auth.php on line 69 and defined C:\xampp\htdocs\LMS\app\models\Leave_record_m.php 47
ERROR - 2016-11-20 14:17:10 --> Severity: Notice --> Undefined variable: subordinate C:\xampp\htdocs\LMS\app\models\Leave_record_m.php 51
ERROR - 2016-11-20 14:17:10 --> Severity: Notice --> Undefined variable: sub_subordinate C:\xampp\htdocs\LMS\app\models\Leave_record_m.php 51
INFO - 2016-11-20 14:17:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 14:17:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 14:17:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 14:17:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 14:17:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 14:17:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 14:17:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 14:17:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 14:17:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 14:17:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 14:17:10 --> Final output sent to browser
DEBUG - 2016-11-20 14:17:11 --> Total execution time: 0.6302
INFO - 2016-11-20 14:18:29 --> Config Class Initialized
INFO - 2016-11-20 14:18:29 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:18:29 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:18:29 --> Utf8 Class Initialized
INFO - 2016-11-20 14:18:29 --> URI Class Initialized
DEBUG - 2016-11-20 14:18:29 --> No URI present. Default controller set.
INFO - 2016-11-20 14:18:29 --> Router Class Initialized
INFO - 2016-11-20 14:18:29 --> Output Class Initialized
INFO - 2016-11-20 14:18:29 --> Security Class Initialized
DEBUG - 2016-11-20 14:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:18:29 --> Input Class Initialized
INFO - 2016-11-20 14:18:29 --> Language Class Initialized
INFO - 2016-11-20 14:18:29 --> Loader Class Initialized
INFO - 2016-11-20 14:18:29 --> Helper loaded: url_helper
INFO - 2016-11-20 14:18:29 --> Helper loaded: form_helper
INFO - 2016-11-20 14:18:29 --> Database Driver Class Initialized
INFO - 2016-11-20 14:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:18:29 --> Controller Class Initialized
INFO - 2016-11-20 14:18:29 --> Model Class Initialized
INFO - 2016-11-20 14:18:29 --> Model Class Initialized
INFO - 2016-11-20 14:18:29 --> Model Class Initialized
INFO - 2016-11-20 14:18:29 --> Model Class Initialized
INFO - 2016-11-20 14:18:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:18:29 --> Pagination Class Initialized
INFO - 2016-11-20 14:18:29 --> Helper loaded: app_helper
INFO - 2016-11-20 14:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 14:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 14:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 14:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 14:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 14:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 14:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 14:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 14:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 14:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 14:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 14:18:29 --> Final output sent to browser
DEBUG - 2016-11-20 14:18:29 --> Total execution time: 0.4507
INFO - 2016-11-20 14:19:54 --> Config Class Initialized
INFO - 2016-11-20 14:19:54 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:19:54 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:19:54 --> Utf8 Class Initialized
INFO - 2016-11-20 14:19:54 --> URI Class Initialized
INFO - 2016-11-20 14:19:54 --> Router Class Initialized
INFO - 2016-11-20 14:19:54 --> Output Class Initialized
INFO - 2016-11-20 14:19:54 --> Security Class Initialized
DEBUG - 2016-11-20 14:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:19:54 --> Input Class Initialized
INFO - 2016-11-20 14:19:54 --> Language Class Initialized
INFO - 2016-11-20 14:19:54 --> Loader Class Initialized
INFO - 2016-11-20 14:19:54 --> Helper loaded: url_helper
INFO - 2016-11-20 14:19:54 --> Helper loaded: form_helper
INFO - 2016-11-20 14:19:54 --> Database Driver Class Initialized
INFO - 2016-11-20 14:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:19:54 --> Controller Class Initialized
INFO - 2016-11-20 14:19:54 --> Model Class Initialized
INFO - 2016-11-20 14:19:54 --> Model Class Initialized
INFO - 2016-11-20 14:19:54 --> Model Class Initialized
INFO - 2016-11-20 14:19:54 --> Model Class Initialized
INFO - 2016-11-20 14:19:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:19:54 --> Pagination Class Initialized
INFO - 2016-11-20 14:19:54 --> Helper loaded: app_helper
DEBUG - 2016-11-20 14:19:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-20 14:19:54 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 168
ERROR - 2016-11-20 14:19:54 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 168
INFO - 2016-11-20 14:19:54 --> Config Class Initialized
INFO - 2016-11-20 14:19:54 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:19:54 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:19:54 --> Utf8 Class Initialized
INFO - 2016-11-20 14:19:54 --> URI Class Initialized
DEBUG - 2016-11-20 14:19:54 --> No URI present. Default controller set.
INFO - 2016-11-20 14:19:54 --> Router Class Initialized
INFO - 2016-11-20 14:19:54 --> Output Class Initialized
INFO - 2016-11-20 14:19:54 --> Security Class Initialized
DEBUG - 2016-11-20 14:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:19:54 --> Input Class Initialized
INFO - 2016-11-20 14:19:54 --> Language Class Initialized
INFO - 2016-11-20 14:19:54 --> Loader Class Initialized
INFO - 2016-11-20 14:19:54 --> Helper loaded: url_helper
INFO - 2016-11-20 14:19:54 --> Helper loaded: form_helper
INFO - 2016-11-20 14:19:54 --> Database Driver Class Initialized
INFO - 2016-11-20 14:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:19:54 --> Controller Class Initialized
INFO - 2016-11-20 14:19:54 --> Model Class Initialized
INFO - 2016-11-20 14:19:54 --> Model Class Initialized
INFO - 2016-11-20 14:19:54 --> Model Class Initialized
INFO - 2016-11-20 14:19:54 --> Model Class Initialized
INFO - 2016-11-20 14:19:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:19:54 --> Pagination Class Initialized
INFO - 2016-11-20 14:19:54 --> Helper loaded: app_helper
INFO - 2016-11-20 14:19:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:19:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-20 14:19:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 14:19:54 --> Final output sent to browser
DEBUG - 2016-11-20 14:19:54 --> Total execution time: 0.3444
INFO - 2016-11-20 14:20:07 --> Config Class Initialized
INFO - 2016-11-20 14:20:07 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:20:07 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:20:07 --> Utf8 Class Initialized
INFO - 2016-11-20 14:20:07 --> URI Class Initialized
INFO - 2016-11-20 14:20:07 --> Router Class Initialized
INFO - 2016-11-20 14:20:07 --> Output Class Initialized
INFO - 2016-11-20 14:20:07 --> Security Class Initialized
DEBUG - 2016-11-20 14:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:20:07 --> Input Class Initialized
INFO - 2016-11-20 14:20:07 --> Language Class Initialized
INFO - 2016-11-20 14:20:07 --> Loader Class Initialized
INFO - 2016-11-20 14:20:07 --> Helper loaded: url_helper
INFO - 2016-11-20 14:20:07 --> Helper loaded: form_helper
INFO - 2016-11-20 14:20:07 --> Database Driver Class Initialized
INFO - 2016-11-20 14:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:20:07 --> Controller Class Initialized
INFO - 2016-11-20 14:20:07 --> Model Class Initialized
INFO - 2016-11-20 14:20:07 --> Model Class Initialized
INFO - 2016-11-20 14:20:07 --> Model Class Initialized
INFO - 2016-11-20 14:20:07 --> Model Class Initialized
INFO - 2016-11-20 14:20:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:20:07 --> Pagination Class Initialized
INFO - 2016-11-20 14:20:07 --> Helper loaded: app_helper
DEBUG - 2016-11-20 14:20:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-20 14:20:07 --> Model Class Initialized
INFO - 2016-11-20 14:20:07 --> Final output sent to browser
DEBUG - 2016-11-20 14:20:07 --> Total execution time: 0.3438
INFO - 2016-11-20 14:20:07 --> Config Class Initialized
INFO - 2016-11-20 14:20:07 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:20:07 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:20:07 --> Utf8 Class Initialized
INFO - 2016-11-20 14:20:07 --> URI Class Initialized
DEBUG - 2016-11-20 14:20:07 --> No URI present. Default controller set.
INFO - 2016-11-20 14:20:07 --> Router Class Initialized
INFO - 2016-11-20 14:20:07 --> Output Class Initialized
INFO - 2016-11-20 14:20:07 --> Security Class Initialized
DEBUG - 2016-11-20 14:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:20:07 --> Input Class Initialized
INFO - 2016-11-20 14:20:07 --> Language Class Initialized
INFO - 2016-11-20 14:20:08 --> Loader Class Initialized
INFO - 2016-11-20 14:20:08 --> Helper loaded: url_helper
INFO - 2016-11-20 14:20:08 --> Helper loaded: form_helper
INFO - 2016-11-20 14:20:08 --> Database Driver Class Initialized
INFO - 2016-11-20 14:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:20:08 --> Controller Class Initialized
INFO - 2016-11-20 14:20:08 --> Model Class Initialized
INFO - 2016-11-20 14:20:08 --> Model Class Initialized
INFO - 2016-11-20 14:20:08 --> Model Class Initialized
INFO - 2016-11-20 14:20:08 --> Model Class Initialized
INFO - 2016-11-20 14:20:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:20:08 --> Pagination Class Initialized
INFO - 2016-11-20 14:20:08 --> Helper loaded: app_helper
INFO - 2016-11-20 14:20:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:20:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 14:20:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 14:20:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 14:20:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 14:20:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 14:20:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 14:20:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 14:20:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 14:20:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 14:20:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 14:20:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 14:20:08 --> Final output sent to browser
DEBUG - 2016-11-20 14:20:08 --> Total execution time: 0.4420
INFO - 2016-11-20 14:23:40 --> Config Class Initialized
INFO - 2016-11-20 14:23:40 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:23:40 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:23:40 --> Utf8 Class Initialized
INFO - 2016-11-20 14:23:40 --> URI Class Initialized
DEBUG - 2016-11-20 14:23:40 --> No URI present. Default controller set.
INFO - 2016-11-20 14:23:40 --> Router Class Initialized
INFO - 2016-11-20 14:23:40 --> Output Class Initialized
INFO - 2016-11-20 14:23:40 --> Security Class Initialized
DEBUG - 2016-11-20 14:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:23:40 --> Input Class Initialized
INFO - 2016-11-20 14:23:40 --> Language Class Initialized
INFO - 2016-11-20 14:23:40 --> Loader Class Initialized
INFO - 2016-11-20 14:23:40 --> Helper loaded: url_helper
INFO - 2016-11-20 14:23:40 --> Helper loaded: form_helper
INFO - 2016-11-20 14:23:40 --> Database Driver Class Initialized
INFO - 2016-11-20 14:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:23:40 --> Controller Class Initialized
INFO - 2016-11-20 14:23:40 --> Model Class Initialized
INFO - 2016-11-20 14:23:40 --> Model Class Initialized
INFO - 2016-11-20 14:23:40 --> Model Class Initialized
INFO - 2016-11-20 14:23:40 --> Model Class Initialized
INFO - 2016-11-20 14:23:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:23:41 --> Pagination Class Initialized
INFO - 2016-11-20 14:23:41 --> Helper loaded: app_helper
INFO - 2016-11-20 14:23:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:23:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 14:23:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 14:23:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 14:23:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 14:23:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 14:23:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 14:23:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 14:23:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 14:23:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 14:23:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 14:23:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 14:23:41 --> Final output sent to browser
DEBUG - 2016-11-20 14:23:41 --> Total execution time: 0.5052
INFO - 2016-11-20 14:24:42 --> Config Class Initialized
INFO - 2016-11-20 14:24:42 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:24:42 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:24:42 --> Utf8 Class Initialized
INFO - 2016-11-20 14:24:42 --> URI Class Initialized
DEBUG - 2016-11-20 14:24:42 --> No URI present. Default controller set.
INFO - 2016-11-20 14:24:42 --> Router Class Initialized
INFO - 2016-11-20 14:24:42 --> Output Class Initialized
INFO - 2016-11-20 14:24:42 --> Security Class Initialized
DEBUG - 2016-11-20 14:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:24:42 --> Input Class Initialized
INFO - 2016-11-20 14:24:42 --> Language Class Initialized
INFO - 2016-11-20 14:24:42 --> Loader Class Initialized
INFO - 2016-11-20 14:24:42 --> Helper loaded: url_helper
INFO - 2016-11-20 14:24:42 --> Helper loaded: form_helper
INFO - 2016-11-20 14:24:42 --> Database Driver Class Initialized
INFO - 2016-11-20 14:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:24:42 --> Controller Class Initialized
INFO - 2016-11-20 14:24:42 --> Model Class Initialized
INFO - 2016-11-20 14:24:42 --> Model Class Initialized
INFO - 2016-11-20 14:24:42 --> Model Class Initialized
INFO - 2016-11-20 14:24:42 --> Model Class Initialized
INFO - 2016-11-20 14:24:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:24:42 --> Pagination Class Initialized
INFO - 2016-11-20 14:24:42 --> Helper loaded: app_helper
INFO - 2016-11-20 14:24:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:24:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 14:24:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 14:24:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 14:24:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 14:24:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 14:24:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 14:24:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 14:24:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 14:24:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 14:24:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 14:24:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 14:24:43 --> Final output sent to browser
DEBUG - 2016-11-20 14:24:43 --> Total execution time: 0.5161
INFO - 2016-11-20 14:26:44 --> Config Class Initialized
INFO - 2016-11-20 14:26:44 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:26:44 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:26:44 --> Utf8 Class Initialized
INFO - 2016-11-20 14:26:44 --> URI Class Initialized
DEBUG - 2016-11-20 14:26:44 --> No URI present. Default controller set.
INFO - 2016-11-20 14:26:44 --> Router Class Initialized
INFO - 2016-11-20 14:26:44 --> Output Class Initialized
INFO - 2016-11-20 14:26:44 --> Security Class Initialized
DEBUG - 2016-11-20 14:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:26:44 --> Input Class Initialized
INFO - 2016-11-20 14:26:44 --> Language Class Initialized
INFO - 2016-11-20 14:26:44 --> Loader Class Initialized
INFO - 2016-11-20 14:26:44 --> Helper loaded: url_helper
INFO - 2016-11-20 14:26:44 --> Helper loaded: form_helper
INFO - 2016-11-20 14:26:44 --> Database Driver Class Initialized
INFO - 2016-11-20 14:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:26:44 --> Controller Class Initialized
INFO - 2016-11-20 14:26:44 --> Model Class Initialized
INFO - 2016-11-20 14:26:44 --> Model Class Initialized
INFO - 2016-11-20 14:26:44 --> Model Class Initialized
INFO - 2016-11-20 14:26:44 --> Model Class Initialized
INFO - 2016-11-20 14:26:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:26:44 --> Pagination Class Initialized
INFO - 2016-11-20 14:26:44 --> Helper loaded: app_helper
INFO - 2016-11-20 14:26:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:26:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 14:26:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 14:26:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 14:26:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 14:26:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 14:26:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 14:26:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 14:26:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 14:26:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 14:26:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 14:26:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 14:26:44 --> Final output sent to browser
DEBUG - 2016-11-20 14:26:44 --> Total execution time: 0.4835
INFO - 2016-11-20 14:26:50 --> Config Class Initialized
INFO - 2016-11-20 14:26:50 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:26:50 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:26:50 --> Utf8 Class Initialized
INFO - 2016-11-20 14:26:50 --> URI Class Initialized
INFO - 2016-11-20 14:26:50 --> Router Class Initialized
INFO - 2016-11-20 14:26:50 --> Output Class Initialized
INFO - 2016-11-20 14:26:50 --> Security Class Initialized
DEBUG - 2016-11-20 14:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:26:50 --> Input Class Initialized
INFO - 2016-11-20 14:26:50 --> Language Class Initialized
INFO - 2016-11-20 14:26:50 --> Loader Class Initialized
INFO - 2016-11-20 14:26:50 --> Helper loaded: url_helper
INFO - 2016-11-20 14:26:50 --> Helper loaded: form_helper
INFO - 2016-11-20 14:26:50 --> Database Driver Class Initialized
INFO - 2016-11-20 14:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:26:50 --> Controller Class Initialized
INFO - 2016-11-20 14:26:50 --> Model Class Initialized
ERROR - 2016-11-20 14:26:50 --> Severity: Error --> Call to undefined function ajax_pagination() C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 113
INFO - 2016-11-20 14:27:13 --> Config Class Initialized
INFO - 2016-11-20 14:27:13 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:27:13 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:27:13 --> Utf8 Class Initialized
INFO - 2016-11-20 14:27:13 --> URI Class Initialized
DEBUG - 2016-11-20 14:27:13 --> No URI present. Default controller set.
INFO - 2016-11-20 14:27:13 --> Router Class Initialized
INFO - 2016-11-20 14:27:13 --> Output Class Initialized
INFO - 2016-11-20 14:27:13 --> Security Class Initialized
DEBUG - 2016-11-20 14:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:27:13 --> Input Class Initialized
INFO - 2016-11-20 14:27:13 --> Language Class Initialized
INFO - 2016-11-20 14:27:13 --> Loader Class Initialized
INFO - 2016-11-20 14:27:13 --> Helper loaded: url_helper
INFO - 2016-11-20 14:27:13 --> Helper loaded: form_helper
INFO - 2016-11-20 14:27:13 --> Database Driver Class Initialized
INFO - 2016-11-20 14:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:27:13 --> Controller Class Initialized
INFO - 2016-11-20 14:27:13 --> Model Class Initialized
INFO - 2016-11-20 14:27:13 --> Model Class Initialized
INFO - 2016-11-20 14:27:13 --> Model Class Initialized
INFO - 2016-11-20 14:27:13 --> Model Class Initialized
INFO - 2016-11-20 14:27:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:27:13 --> Pagination Class Initialized
INFO - 2016-11-20 14:27:13 --> Helper loaded: app_helper
INFO - 2016-11-20 14:27:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:27:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 14:27:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 14:27:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 14:27:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 14:27:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 14:27:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 14:27:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 14:27:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 14:27:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 14:27:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 14:27:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 14:27:13 --> Final output sent to browser
DEBUG - 2016-11-20 14:27:13 --> Total execution time: 0.4984
INFO - 2016-11-20 14:27:32 --> Config Class Initialized
INFO - 2016-11-20 14:27:32 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:27:32 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:27:32 --> Utf8 Class Initialized
INFO - 2016-11-20 14:27:32 --> URI Class Initialized
DEBUG - 2016-11-20 14:27:32 --> No URI present. Default controller set.
INFO - 2016-11-20 14:27:32 --> Router Class Initialized
INFO - 2016-11-20 14:27:32 --> Output Class Initialized
INFO - 2016-11-20 14:27:32 --> Security Class Initialized
DEBUG - 2016-11-20 14:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:27:32 --> Input Class Initialized
INFO - 2016-11-20 14:27:32 --> Language Class Initialized
INFO - 2016-11-20 14:27:32 --> Loader Class Initialized
INFO - 2016-11-20 14:27:32 --> Helper loaded: url_helper
INFO - 2016-11-20 14:27:32 --> Helper loaded: form_helper
INFO - 2016-11-20 14:27:32 --> Database Driver Class Initialized
INFO - 2016-11-20 14:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:27:33 --> Controller Class Initialized
INFO - 2016-11-20 14:27:33 --> Model Class Initialized
INFO - 2016-11-20 14:27:33 --> Model Class Initialized
INFO - 2016-11-20 14:27:33 --> Model Class Initialized
INFO - 2016-11-20 14:27:33 --> Model Class Initialized
INFO - 2016-11-20 14:27:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:27:33 --> Pagination Class Initialized
INFO - 2016-11-20 14:27:33 --> Helper loaded: app_helper
INFO - 2016-11-20 14:27:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:27:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 14:27:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 14:27:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 14:27:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 14:27:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 14:27:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 14:27:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 14:27:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 14:27:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 14:27:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 14:27:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 14:27:33 --> Final output sent to browser
DEBUG - 2016-11-20 14:27:33 --> Total execution time: 0.5187
INFO - 2016-11-20 14:29:38 --> Config Class Initialized
INFO - 2016-11-20 14:29:38 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:29:38 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:29:38 --> Utf8 Class Initialized
INFO - 2016-11-20 14:29:38 --> URI Class Initialized
DEBUG - 2016-11-20 14:29:38 --> No URI present. Default controller set.
INFO - 2016-11-20 14:29:38 --> Router Class Initialized
INFO - 2016-11-20 14:29:38 --> Output Class Initialized
INFO - 2016-11-20 14:29:38 --> Security Class Initialized
DEBUG - 2016-11-20 14:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:29:38 --> Input Class Initialized
INFO - 2016-11-20 14:29:38 --> Language Class Initialized
INFO - 2016-11-20 14:29:38 --> Loader Class Initialized
INFO - 2016-11-20 14:29:38 --> Helper loaded: url_helper
INFO - 2016-11-20 14:29:38 --> Helper loaded: form_helper
INFO - 2016-11-20 14:29:38 --> Database Driver Class Initialized
INFO - 2016-11-20 14:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:29:38 --> Controller Class Initialized
INFO - 2016-11-20 14:29:38 --> Model Class Initialized
INFO - 2016-11-20 14:29:38 --> Model Class Initialized
INFO - 2016-11-20 14:29:38 --> Model Class Initialized
INFO - 2016-11-20 14:29:38 --> Model Class Initialized
INFO - 2016-11-20 14:29:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:29:38 --> Pagination Class Initialized
INFO - 2016-11-20 14:29:38 --> Helper loaded: app_helper
INFO - 2016-11-20 14:29:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:29:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 14:29:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 14:29:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 14:29:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 14:29:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 14:29:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 14:29:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 14:29:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 14:29:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 14:29:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 14:29:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 14:29:38 --> Final output sent to browser
DEBUG - 2016-11-20 14:29:38 --> Total execution time: 0.4952
INFO - 2016-11-20 14:39:49 --> Config Class Initialized
INFO - 2016-11-20 14:39:49 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:39:49 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:39:49 --> Utf8 Class Initialized
INFO - 2016-11-20 14:39:49 --> URI Class Initialized
DEBUG - 2016-11-20 14:39:49 --> No URI present. Default controller set.
INFO - 2016-11-20 14:39:49 --> Router Class Initialized
INFO - 2016-11-20 14:39:49 --> Output Class Initialized
INFO - 2016-11-20 14:39:49 --> Security Class Initialized
DEBUG - 2016-11-20 14:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:39:49 --> Input Class Initialized
INFO - 2016-11-20 14:39:49 --> Language Class Initialized
INFO - 2016-11-20 14:39:49 --> Loader Class Initialized
INFO - 2016-11-20 14:39:49 --> Helper loaded: url_helper
INFO - 2016-11-20 14:39:49 --> Helper loaded: form_helper
INFO - 2016-11-20 14:39:49 --> Database Driver Class Initialized
INFO - 2016-11-20 14:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:39:49 --> Controller Class Initialized
INFO - 2016-11-20 14:39:49 --> Model Class Initialized
INFO - 2016-11-20 14:39:49 --> Model Class Initialized
INFO - 2016-11-20 14:39:49 --> Model Class Initialized
INFO - 2016-11-20 14:39:49 --> Model Class Initialized
INFO - 2016-11-20 14:39:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:39:49 --> Pagination Class Initialized
INFO - 2016-11-20 14:39:49 --> Helper loaded: app_helper
INFO - 2016-11-20 14:39:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:39:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-20 14:39:49 --> Query error: Unknown column 'lv.bDeleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `applicationdata` `ad`
LEFT JOIN `employee` as `em` ON `em`.`id` = `ad`.`idEmployee`
WHERE `em`.`idRole` IN(7, 8)
AND `lv`.`bDeleted` =0
INFO - 2016-11-20 14:39:49 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-20 14:40:10 --> Config Class Initialized
INFO - 2016-11-20 14:40:10 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:40:10 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:40:10 --> Utf8 Class Initialized
INFO - 2016-11-20 14:40:10 --> URI Class Initialized
DEBUG - 2016-11-20 14:40:10 --> No URI present. Default controller set.
INFO - 2016-11-20 14:40:10 --> Router Class Initialized
INFO - 2016-11-20 14:40:10 --> Output Class Initialized
INFO - 2016-11-20 14:40:10 --> Security Class Initialized
DEBUG - 2016-11-20 14:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:40:10 --> Input Class Initialized
INFO - 2016-11-20 14:40:10 --> Language Class Initialized
INFO - 2016-11-20 14:40:10 --> Loader Class Initialized
INFO - 2016-11-20 14:40:10 --> Helper loaded: url_helper
INFO - 2016-11-20 14:40:10 --> Helper loaded: form_helper
INFO - 2016-11-20 14:40:10 --> Database Driver Class Initialized
INFO - 2016-11-20 14:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:40:10 --> Controller Class Initialized
INFO - 2016-11-20 14:40:10 --> Model Class Initialized
INFO - 2016-11-20 14:40:10 --> Model Class Initialized
INFO - 2016-11-20 14:40:10 --> Model Class Initialized
INFO - 2016-11-20 14:40:10 --> Model Class Initialized
INFO - 2016-11-20 14:40:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:40:10 --> Pagination Class Initialized
INFO - 2016-11-20 14:40:10 --> Helper loaded: app_helper
INFO - 2016-11-20 14:40:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:40:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-20 14:40:10 --> Query error: Unknown column 'lv.bDeleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `applicationdata` `ad`
LEFT JOIN `employee` as `em` ON `em`.`id` = `ad`.`idEmployee`
WHERE `em`.`idRole` IN(7, 8)
AND `lv`.`bDeleted` =0
INFO - 2016-11-20 14:40:10 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-20 14:42:17 --> Config Class Initialized
INFO - 2016-11-20 14:42:17 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:42:17 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:42:17 --> Utf8 Class Initialized
INFO - 2016-11-20 14:42:17 --> URI Class Initialized
DEBUG - 2016-11-20 14:42:17 --> No URI present. Default controller set.
INFO - 2016-11-20 14:42:17 --> Router Class Initialized
INFO - 2016-11-20 14:42:17 --> Output Class Initialized
INFO - 2016-11-20 14:42:17 --> Security Class Initialized
DEBUG - 2016-11-20 14:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:42:17 --> Input Class Initialized
INFO - 2016-11-20 14:42:17 --> Language Class Initialized
INFO - 2016-11-20 14:42:17 --> Loader Class Initialized
INFO - 2016-11-20 14:42:17 --> Helper loaded: url_helper
INFO - 2016-11-20 14:42:17 --> Helper loaded: form_helper
INFO - 2016-11-20 14:42:17 --> Database Driver Class Initialized
INFO - 2016-11-20 14:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:42:17 --> Controller Class Initialized
INFO - 2016-11-20 14:42:17 --> Model Class Initialized
INFO - 2016-11-20 14:42:17 --> Model Class Initialized
INFO - 2016-11-20 14:42:17 --> Model Class Initialized
INFO - 2016-11-20 14:42:17 --> Model Class Initialized
INFO - 2016-11-20 14:42:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:42:17 --> Pagination Class Initialized
INFO - 2016-11-20 14:42:17 --> Helper loaded: app_helper
INFO - 2016-11-20 14:42:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:42:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-20 14:42:17 --> Query error: Unknown column 'lv.bDeleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `applicationdata` `ad`
LEFT JOIN `employee` as `em` ON `em`.`id` = `ad`.`idEmployee`
WHERE `em`.`idRole` IN(7, 8)
AND `lv`.`bDeleted` =0
INFO - 2016-11-20 14:42:17 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-20 14:43:34 --> Config Class Initialized
INFO - 2016-11-20 14:43:34 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:43:34 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:43:34 --> Utf8 Class Initialized
INFO - 2016-11-20 14:43:34 --> URI Class Initialized
DEBUG - 2016-11-20 14:43:34 --> No URI present. Default controller set.
INFO - 2016-11-20 14:43:34 --> Router Class Initialized
INFO - 2016-11-20 14:43:34 --> Output Class Initialized
INFO - 2016-11-20 14:43:34 --> Security Class Initialized
DEBUG - 2016-11-20 14:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:43:34 --> Input Class Initialized
INFO - 2016-11-20 14:43:34 --> Language Class Initialized
INFO - 2016-11-20 14:43:34 --> Loader Class Initialized
INFO - 2016-11-20 14:43:34 --> Helper loaded: url_helper
INFO - 2016-11-20 14:43:34 --> Helper loaded: form_helper
INFO - 2016-11-20 14:43:34 --> Database Driver Class Initialized
INFO - 2016-11-20 14:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:43:34 --> Controller Class Initialized
INFO - 2016-11-20 14:43:34 --> Model Class Initialized
INFO - 2016-11-20 14:43:34 --> Model Class Initialized
INFO - 2016-11-20 14:43:34 --> Model Class Initialized
INFO - 2016-11-20 14:43:34 --> Model Class Initialized
INFO - 2016-11-20 14:43:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:43:34 --> Pagination Class Initialized
INFO - 2016-11-20 14:43:34 --> Helper loaded: app_helper
INFO - 2016-11-20 14:43:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:43:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-20 14:43:34 --> Query error: Unknown column 'lv.bDeleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `applicationdata` `ad`
LEFT JOIN `employee` as `em` ON `em`.`id` = `ad`.`idEmployee`
WHERE `em`.`idRole` IN(7, 8)
AND `lv`.`bDeleted` =0
INFO - 2016-11-20 14:43:34 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-20 14:43:36 --> Config Class Initialized
INFO - 2016-11-20 14:43:36 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:43:36 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:43:36 --> Utf8 Class Initialized
INFO - 2016-11-20 14:43:36 --> URI Class Initialized
DEBUG - 2016-11-20 14:43:36 --> No URI present. Default controller set.
INFO - 2016-11-20 14:43:36 --> Router Class Initialized
INFO - 2016-11-20 14:43:36 --> Output Class Initialized
INFO - 2016-11-20 14:43:36 --> Security Class Initialized
DEBUG - 2016-11-20 14:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:43:36 --> Input Class Initialized
INFO - 2016-11-20 14:43:36 --> Language Class Initialized
INFO - 2016-11-20 14:43:36 --> Loader Class Initialized
INFO - 2016-11-20 14:43:36 --> Helper loaded: url_helper
INFO - 2016-11-20 14:43:36 --> Helper loaded: form_helper
INFO - 2016-11-20 14:43:36 --> Database Driver Class Initialized
INFO - 2016-11-20 14:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:43:36 --> Controller Class Initialized
INFO - 2016-11-20 14:43:36 --> Model Class Initialized
INFO - 2016-11-20 14:43:36 --> Model Class Initialized
INFO - 2016-11-20 14:43:36 --> Model Class Initialized
INFO - 2016-11-20 14:43:36 --> Model Class Initialized
INFO - 2016-11-20 14:43:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:43:36 --> Pagination Class Initialized
INFO - 2016-11-20 14:43:36 --> Helper loaded: app_helper
INFO - 2016-11-20 14:43:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:43:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-20 14:43:36 --> Query error: Unknown column 'lv.bDeleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `applicationdata` `ad`
LEFT JOIN `employee` as `em` ON `em`.`id` = `ad`.`idEmployee`
WHERE `em`.`idRole` IN(7, 8)
AND `lv`.`bDeleted` =0
INFO - 2016-11-20 14:43:36 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-20 14:44:55 --> Config Class Initialized
INFO - 2016-11-20 14:44:55 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:44:55 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:44:55 --> Utf8 Class Initialized
INFO - 2016-11-20 14:44:55 --> URI Class Initialized
DEBUG - 2016-11-20 14:44:55 --> No URI present. Default controller set.
INFO - 2016-11-20 14:44:55 --> Router Class Initialized
INFO - 2016-11-20 14:44:55 --> Output Class Initialized
INFO - 2016-11-20 14:44:55 --> Security Class Initialized
DEBUG - 2016-11-20 14:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:44:55 --> Input Class Initialized
INFO - 2016-11-20 14:44:55 --> Language Class Initialized
INFO - 2016-11-20 14:44:55 --> Loader Class Initialized
INFO - 2016-11-20 14:44:55 --> Helper loaded: url_helper
INFO - 2016-11-20 14:44:55 --> Helper loaded: form_helper
INFO - 2016-11-20 14:44:55 --> Database Driver Class Initialized
INFO - 2016-11-20 14:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:44:55 --> Controller Class Initialized
INFO - 2016-11-20 14:44:55 --> Model Class Initialized
INFO - 2016-11-20 14:44:55 --> Model Class Initialized
INFO - 2016-11-20 14:44:55 --> Model Class Initialized
INFO - 2016-11-20 14:44:55 --> Model Class Initialized
INFO - 2016-11-20 14:44:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:44:55 --> Pagination Class Initialized
INFO - 2016-11-20 14:44:55 --> Helper loaded: app_helper
INFO - 2016-11-20 14:44:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:44:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-20 14:44:55 --> Query error: Unknown column 'lv.bDeleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `applicationdata` `ad`
LEFT JOIN `employee` as `em` ON `em`.`id` = `ad`.`idEmployee`
WHERE `em`.`idRole` IN(7, 8)
AND `lv`.`bDeleted` =0
INFO - 2016-11-20 14:44:55 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-20 14:44:58 --> Config Class Initialized
INFO - 2016-11-20 14:44:58 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:44:58 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:44:58 --> Utf8 Class Initialized
INFO - 2016-11-20 14:44:58 --> URI Class Initialized
DEBUG - 2016-11-20 14:44:58 --> No URI present. Default controller set.
INFO - 2016-11-20 14:44:58 --> Router Class Initialized
INFO - 2016-11-20 14:44:58 --> Output Class Initialized
INFO - 2016-11-20 14:44:58 --> Security Class Initialized
DEBUG - 2016-11-20 14:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:44:58 --> Input Class Initialized
INFO - 2016-11-20 14:44:58 --> Language Class Initialized
INFO - 2016-11-20 14:44:58 --> Loader Class Initialized
INFO - 2016-11-20 14:44:58 --> Helper loaded: url_helper
INFO - 2016-11-20 14:44:58 --> Helper loaded: form_helper
INFO - 2016-11-20 14:44:58 --> Database Driver Class Initialized
INFO - 2016-11-20 14:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:44:58 --> Controller Class Initialized
INFO - 2016-11-20 14:44:58 --> Model Class Initialized
INFO - 2016-11-20 14:44:58 --> Model Class Initialized
INFO - 2016-11-20 14:44:58 --> Model Class Initialized
INFO - 2016-11-20 14:44:58 --> Model Class Initialized
INFO - 2016-11-20 14:44:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:44:58 --> Pagination Class Initialized
INFO - 2016-11-20 14:44:58 --> Helper loaded: app_helper
INFO - 2016-11-20 14:44:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:44:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-20 14:44:58 --> Query error: Unknown column 'lv.bDeleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `applicationdata` `ad`
LEFT JOIN `employee` as `em` ON `em`.`id` = `ad`.`idEmployee`
WHERE `em`.`idRole` IN(7, 8)
AND `lv`.`bDeleted` =0
INFO - 2016-11-20 14:44:58 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-20 14:45:45 --> Config Class Initialized
INFO - 2016-11-20 14:45:45 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:45:45 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:45:45 --> Utf8 Class Initialized
INFO - 2016-11-20 14:45:45 --> URI Class Initialized
DEBUG - 2016-11-20 14:45:45 --> No URI present. Default controller set.
INFO - 2016-11-20 14:45:45 --> Router Class Initialized
INFO - 2016-11-20 14:45:45 --> Output Class Initialized
INFO - 2016-11-20 14:45:45 --> Security Class Initialized
DEBUG - 2016-11-20 14:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:45:45 --> Input Class Initialized
INFO - 2016-11-20 14:45:45 --> Language Class Initialized
INFO - 2016-11-20 14:45:45 --> Loader Class Initialized
INFO - 2016-11-20 14:45:45 --> Helper loaded: url_helper
INFO - 2016-11-20 14:45:45 --> Helper loaded: form_helper
INFO - 2016-11-20 14:45:45 --> Database Driver Class Initialized
INFO - 2016-11-20 14:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:45:45 --> Controller Class Initialized
INFO - 2016-11-20 14:45:45 --> Model Class Initialized
INFO - 2016-11-20 14:45:45 --> Model Class Initialized
INFO - 2016-11-20 14:45:45 --> Model Class Initialized
INFO - 2016-11-20 14:45:45 --> Model Class Initialized
INFO - 2016-11-20 14:45:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:45:45 --> Pagination Class Initialized
INFO - 2016-11-20 14:45:45 --> Helper loaded: app_helper
INFO - 2016-11-20 14:45:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:45:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-20 14:45:45 --> Query error: Unknown column 'em.idEmployee' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `applicationdata` `ad`
LEFT JOIN `employee` as `em` ON `em`.`id` = `ad`.`idEmployee`
WHERE `em`.`idEmployee` = '18'
AND `ad`.`bDeleted` =0
INFO - 2016-11-20 14:45:45 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-20 14:45:46 --> Config Class Initialized
INFO - 2016-11-20 14:45:46 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:45:46 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:45:46 --> Utf8 Class Initialized
INFO - 2016-11-20 14:45:46 --> URI Class Initialized
DEBUG - 2016-11-20 14:45:46 --> No URI present. Default controller set.
INFO - 2016-11-20 14:45:46 --> Router Class Initialized
INFO - 2016-11-20 14:45:46 --> Output Class Initialized
INFO - 2016-11-20 14:45:46 --> Security Class Initialized
DEBUG - 2016-11-20 14:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:45:46 --> Input Class Initialized
INFO - 2016-11-20 14:45:46 --> Language Class Initialized
INFO - 2016-11-20 14:45:46 --> Loader Class Initialized
INFO - 2016-11-20 14:45:46 --> Helper loaded: url_helper
INFO - 2016-11-20 14:45:46 --> Helper loaded: form_helper
INFO - 2016-11-20 14:45:46 --> Database Driver Class Initialized
INFO - 2016-11-20 14:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:45:46 --> Controller Class Initialized
INFO - 2016-11-20 14:45:46 --> Model Class Initialized
INFO - 2016-11-20 14:45:46 --> Model Class Initialized
INFO - 2016-11-20 14:45:46 --> Model Class Initialized
INFO - 2016-11-20 14:45:46 --> Model Class Initialized
INFO - 2016-11-20 14:45:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:45:46 --> Pagination Class Initialized
INFO - 2016-11-20 14:45:46 --> Helper loaded: app_helper
INFO - 2016-11-20 14:45:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:45:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-20 14:45:46 --> Query error: Unknown column 'em.idEmployee' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `applicationdata` `ad`
LEFT JOIN `employee` as `em` ON `em`.`id` = `ad`.`idEmployee`
WHERE `em`.`idEmployee` = '18'
AND `ad`.`bDeleted` =0
INFO - 2016-11-20 14:45:46 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-20 14:52:01 --> Config Class Initialized
INFO - 2016-11-20 14:52:01 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:52:01 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:52:01 --> Utf8 Class Initialized
INFO - 2016-11-20 14:52:01 --> URI Class Initialized
DEBUG - 2016-11-20 14:52:01 --> No URI present. Default controller set.
INFO - 2016-11-20 14:52:01 --> Router Class Initialized
INFO - 2016-11-20 14:52:01 --> Output Class Initialized
INFO - 2016-11-20 14:52:01 --> Security Class Initialized
DEBUG - 2016-11-20 14:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:52:01 --> Input Class Initialized
INFO - 2016-11-20 14:52:01 --> Language Class Initialized
INFO - 2016-11-20 14:52:01 --> Loader Class Initialized
INFO - 2016-11-20 14:52:01 --> Helper loaded: url_helper
INFO - 2016-11-20 14:52:01 --> Helper loaded: form_helper
INFO - 2016-11-20 14:52:01 --> Database Driver Class Initialized
INFO - 2016-11-20 14:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:52:01 --> Controller Class Initialized
INFO - 2016-11-20 14:52:01 --> Model Class Initialized
INFO - 2016-11-20 14:52:01 --> Model Class Initialized
INFO - 2016-11-20 14:52:01 --> Model Class Initialized
INFO - 2016-11-20 14:52:01 --> Model Class Initialized
INFO - 2016-11-20 14:52:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:52:01 --> Pagination Class Initialized
INFO - 2016-11-20 14:52:01 --> Helper loaded: app_helper
INFO - 2016-11-20 14:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 14:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 14:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 14:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 14:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 14:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 14:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 14:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 14:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 14:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 14:52:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 14:52:01 --> Final output sent to browser
DEBUG - 2016-11-20 14:52:01 --> Total execution time: 0.4977
INFO - 2016-11-20 14:52:24 --> Config Class Initialized
INFO - 2016-11-20 14:52:24 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:52:24 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:52:24 --> Utf8 Class Initialized
INFO - 2016-11-20 14:52:24 --> URI Class Initialized
DEBUG - 2016-11-20 14:52:24 --> No URI present. Default controller set.
INFO - 2016-11-20 14:52:24 --> Router Class Initialized
INFO - 2016-11-20 14:52:24 --> Output Class Initialized
INFO - 2016-11-20 14:52:24 --> Security Class Initialized
DEBUG - 2016-11-20 14:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:52:24 --> Input Class Initialized
INFO - 2016-11-20 14:52:24 --> Language Class Initialized
INFO - 2016-11-20 14:52:24 --> Loader Class Initialized
INFO - 2016-11-20 14:52:24 --> Helper loaded: url_helper
INFO - 2016-11-20 14:52:24 --> Helper loaded: form_helper
INFO - 2016-11-20 14:52:24 --> Database Driver Class Initialized
INFO - 2016-11-20 14:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:52:24 --> Controller Class Initialized
INFO - 2016-11-20 14:52:24 --> Model Class Initialized
INFO - 2016-11-20 14:52:24 --> Model Class Initialized
INFO - 2016-11-20 14:52:24 --> Model Class Initialized
INFO - 2016-11-20 14:52:24 --> Model Class Initialized
INFO - 2016-11-20 14:52:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:52:24 --> Pagination Class Initialized
INFO - 2016-11-20 14:52:24 --> Helper loaded: app_helper
INFO - 2016-11-20 14:52:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:52:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 14:52:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 14:52:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 14:52:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 14:52:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 14:52:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 14:52:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 14:52:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 14:52:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 14:52:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 14:52:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 14:52:24 --> Final output sent to browser
DEBUG - 2016-11-20 14:52:24 --> Total execution time: 0.5089
INFO - 2016-11-20 14:53:47 --> Config Class Initialized
INFO - 2016-11-20 14:53:47 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:53:47 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:53:47 --> Utf8 Class Initialized
INFO - 2016-11-20 14:53:47 --> URI Class Initialized
DEBUG - 2016-11-20 14:53:47 --> No URI present. Default controller set.
INFO - 2016-11-20 14:53:47 --> Router Class Initialized
INFO - 2016-11-20 14:53:47 --> Output Class Initialized
INFO - 2016-11-20 14:53:47 --> Security Class Initialized
DEBUG - 2016-11-20 14:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:53:47 --> Input Class Initialized
INFO - 2016-11-20 14:53:47 --> Language Class Initialized
INFO - 2016-11-20 14:53:47 --> Loader Class Initialized
INFO - 2016-11-20 14:53:47 --> Helper loaded: url_helper
INFO - 2016-11-20 14:53:47 --> Helper loaded: form_helper
INFO - 2016-11-20 14:53:47 --> Database Driver Class Initialized
INFO - 2016-11-20 14:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:53:47 --> Controller Class Initialized
INFO - 2016-11-20 14:53:47 --> Model Class Initialized
INFO - 2016-11-20 14:53:47 --> Model Class Initialized
INFO - 2016-11-20 14:53:47 --> Model Class Initialized
INFO - 2016-11-20 14:53:47 --> Model Class Initialized
INFO - 2016-11-20 14:53:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:53:47 --> Pagination Class Initialized
INFO - 2016-11-20 14:53:47 --> Helper loaded: app_helper
INFO - 2016-11-20 14:53:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:53:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 14:53:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 14:53:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 14:53:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 14:53:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 14:53:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 14:53:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 14:53:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 14:53:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 14:53:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 14:53:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 14:53:48 --> Final output sent to browser
DEBUG - 2016-11-20 14:53:48 --> Total execution time: 0.5427
INFO - 2016-11-20 14:54:50 --> Config Class Initialized
INFO - 2016-11-20 14:54:50 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:54:50 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:54:50 --> Utf8 Class Initialized
INFO - 2016-11-20 14:54:51 --> URI Class Initialized
DEBUG - 2016-11-20 14:54:51 --> No URI present. Default controller set.
INFO - 2016-11-20 14:54:51 --> Router Class Initialized
INFO - 2016-11-20 14:54:51 --> Output Class Initialized
INFO - 2016-11-20 14:54:51 --> Security Class Initialized
DEBUG - 2016-11-20 14:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:54:51 --> Input Class Initialized
INFO - 2016-11-20 14:54:51 --> Language Class Initialized
INFO - 2016-11-20 14:54:51 --> Loader Class Initialized
INFO - 2016-11-20 14:54:51 --> Helper loaded: url_helper
INFO - 2016-11-20 14:54:51 --> Helper loaded: form_helper
INFO - 2016-11-20 14:54:51 --> Database Driver Class Initialized
INFO - 2016-11-20 14:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:54:51 --> Controller Class Initialized
INFO - 2016-11-20 14:54:51 --> Model Class Initialized
INFO - 2016-11-20 14:54:51 --> Model Class Initialized
INFO - 2016-11-20 14:54:51 --> Model Class Initialized
INFO - 2016-11-20 14:54:51 --> Model Class Initialized
INFO - 2016-11-20 14:54:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:54:51 --> Pagination Class Initialized
INFO - 2016-11-20 14:54:51 --> Helper loaded: app_helper
INFO - 2016-11-20 14:54:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:54:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 14:54:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 14:54:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 14:54:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 14:54:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 14:54:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 14:54:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 14:54:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 14:54:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 14:54:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 14:54:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 14:54:51 --> Final output sent to browser
DEBUG - 2016-11-20 14:54:51 --> Total execution time: 0.5421
INFO - 2016-11-20 14:56:47 --> Config Class Initialized
INFO - 2016-11-20 14:56:47 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:56:47 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:56:47 --> Utf8 Class Initialized
INFO - 2016-11-20 14:56:47 --> URI Class Initialized
INFO - 2016-11-20 14:56:47 --> Router Class Initialized
INFO - 2016-11-20 14:56:47 --> Output Class Initialized
INFO - 2016-11-20 14:56:47 --> Security Class Initialized
DEBUG - 2016-11-20 14:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:56:47 --> Input Class Initialized
INFO - 2016-11-20 14:56:47 --> Language Class Initialized
INFO - 2016-11-20 14:56:47 --> Loader Class Initialized
INFO - 2016-11-20 14:56:47 --> Helper loaded: url_helper
INFO - 2016-11-20 14:56:47 --> Helper loaded: form_helper
INFO - 2016-11-20 14:56:47 --> Database Driver Class Initialized
INFO - 2016-11-20 14:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:56:47 --> Controller Class Initialized
INFO - 2016-11-20 14:56:47 --> Model Class Initialized
INFO - 2016-11-20 14:56:47 --> Model Class Initialized
INFO - 2016-11-20 14:56:47 --> Model Class Initialized
INFO - 2016-11-20 14:56:47 --> Model Class Initialized
INFO - 2016-11-20 14:56:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:56:47 --> Pagination Class Initialized
INFO - 2016-11-20 14:56:48 --> Helper loaded: app_helper
DEBUG - 2016-11-20 14:56:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-20 14:56:48 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 174
ERROR - 2016-11-20 14:56:48 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 174
INFO - 2016-11-20 14:56:48 --> Config Class Initialized
INFO - 2016-11-20 14:56:48 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:56:48 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:56:48 --> Utf8 Class Initialized
INFO - 2016-11-20 14:56:48 --> URI Class Initialized
DEBUG - 2016-11-20 14:56:48 --> No URI present. Default controller set.
INFO - 2016-11-20 14:56:48 --> Router Class Initialized
INFO - 2016-11-20 14:56:48 --> Output Class Initialized
INFO - 2016-11-20 14:56:48 --> Security Class Initialized
DEBUG - 2016-11-20 14:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:56:48 --> Input Class Initialized
INFO - 2016-11-20 14:56:48 --> Language Class Initialized
INFO - 2016-11-20 14:56:48 --> Loader Class Initialized
INFO - 2016-11-20 14:56:48 --> Helper loaded: url_helper
INFO - 2016-11-20 14:56:48 --> Helper loaded: form_helper
INFO - 2016-11-20 14:56:48 --> Database Driver Class Initialized
INFO - 2016-11-20 14:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:56:48 --> Controller Class Initialized
INFO - 2016-11-20 14:56:48 --> Model Class Initialized
INFO - 2016-11-20 14:56:48 --> Model Class Initialized
INFO - 2016-11-20 14:56:48 --> Model Class Initialized
INFO - 2016-11-20 14:56:48 --> Model Class Initialized
INFO - 2016-11-20 14:56:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:56:48 --> Pagination Class Initialized
INFO - 2016-11-20 14:56:48 --> Helper loaded: app_helper
INFO - 2016-11-20 14:56:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:56:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-20 14:56:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 14:56:48 --> Final output sent to browser
DEBUG - 2016-11-20 14:56:48 --> Total execution time: 0.3768
INFO - 2016-11-20 14:57:02 --> Config Class Initialized
INFO - 2016-11-20 14:57:02 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:57:02 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:57:02 --> Utf8 Class Initialized
INFO - 2016-11-20 14:57:02 --> URI Class Initialized
INFO - 2016-11-20 14:57:02 --> Router Class Initialized
INFO - 2016-11-20 14:57:02 --> Output Class Initialized
INFO - 2016-11-20 14:57:02 --> Security Class Initialized
DEBUG - 2016-11-20 14:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:57:02 --> Input Class Initialized
INFO - 2016-11-20 14:57:02 --> Language Class Initialized
INFO - 2016-11-20 14:57:02 --> Loader Class Initialized
INFO - 2016-11-20 14:57:02 --> Helper loaded: url_helper
INFO - 2016-11-20 14:57:02 --> Helper loaded: form_helper
INFO - 2016-11-20 14:57:02 --> Database Driver Class Initialized
INFO - 2016-11-20 14:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:57:02 --> Controller Class Initialized
INFO - 2016-11-20 14:57:02 --> Model Class Initialized
INFO - 2016-11-20 14:57:02 --> Model Class Initialized
INFO - 2016-11-20 14:57:02 --> Model Class Initialized
INFO - 2016-11-20 14:57:02 --> Model Class Initialized
INFO - 2016-11-20 14:57:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:57:02 --> Pagination Class Initialized
INFO - 2016-11-20 14:57:02 --> Helper loaded: app_helper
DEBUG - 2016-11-20 14:57:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-20 14:57:02 --> Model Class Initialized
INFO - 2016-11-20 14:57:02 --> Final output sent to browser
DEBUG - 2016-11-20 14:57:02 --> Total execution time: 0.2842
INFO - 2016-11-20 14:57:02 --> Config Class Initialized
INFO - 2016-11-20 14:57:02 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:57:02 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:57:02 --> Utf8 Class Initialized
INFO - 2016-11-20 14:57:02 --> URI Class Initialized
DEBUG - 2016-11-20 14:57:02 --> No URI present. Default controller set.
INFO - 2016-11-20 14:57:02 --> Router Class Initialized
INFO - 2016-11-20 14:57:02 --> Output Class Initialized
INFO - 2016-11-20 14:57:02 --> Security Class Initialized
DEBUG - 2016-11-20 14:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:57:02 --> Input Class Initialized
INFO - 2016-11-20 14:57:02 --> Language Class Initialized
INFO - 2016-11-20 14:57:02 --> Loader Class Initialized
INFO - 2016-11-20 14:57:02 --> Helper loaded: url_helper
INFO - 2016-11-20 14:57:02 --> Helper loaded: form_helper
INFO - 2016-11-20 14:57:02 --> Database Driver Class Initialized
INFO - 2016-11-20 14:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:57:02 --> Controller Class Initialized
INFO - 2016-11-20 14:57:02 --> Model Class Initialized
INFO - 2016-11-20 14:57:02 --> Model Class Initialized
INFO - 2016-11-20 14:57:02 --> Model Class Initialized
INFO - 2016-11-20 14:57:02 --> Model Class Initialized
INFO - 2016-11-20 14:57:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:57:02 --> Pagination Class Initialized
INFO - 2016-11-20 14:57:02 --> Helper loaded: app_helper
INFO - 2016-11-20 14:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 14:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 14:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 14:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 14:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 14:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 14:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 14:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 14:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 14:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 14:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 14:57:02 --> Final output sent to browser
DEBUG - 2016-11-20 14:57:02 --> Total execution time: 0.4501
INFO - 2016-11-20 14:57:28 --> Config Class Initialized
INFO - 2016-11-20 14:57:28 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:57:28 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:57:28 --> Utf8 Class Initialized
INFO - 2016-11-20 14:57:28 --> URI Class Initialized
DEBUG - 2016-11-20 14:57:28 --> No URI present. Default controller set.
INFO - 2016-11-20 14:57:28 --> Router Class Initialized
INFO - 2016-11-20 14:57:28 --> Output Class Initialized
INFO - 2016-11-20 14:57:28 --> Security Class Initialized
DEBUG - 2016-11-20 14:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:57:28 --> Input Class Initialized
INFO - 2016-11-20 14:57:28 --> Language Class Initialized
INFO - 2016-11-20 14:57:28 --> Loader Class Initialized
INFO - 2016-11-20 14:57:28 --> Helper loaded: url_helper
INFO - 2016-11-20 14:57:28 --> Helper loaded: form_helper
INFO - 2016-11-20 14:57:28 --> Database Driver Class Initialized
INFO - 2016-11-20 14:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:57:28 --> Controller Class Initialized
INFO - 2016-11-20 14:57:28 --> Model Class Initialized
INFO - 2016-11-20 14:57:28 --> Model Class Initialized
INFO - 2016-11-20 14:57:28 --> Model Class Initialized
INFO - 2016-11-20 14:57:28 --> Model Class Initialized
INFO - 2016-11-20 14:57:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:57:28 --> Pagination Class Initialized
INFO - 2016-11-20 14:57:28 --> Helper loaded: app_helper
INFO - 2016-11-20 14:57:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:57:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 14:57:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 14:57:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 14:57:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 14:57:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 14:57:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 14:57:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 14:57:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 14:57:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 14:57:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 14:57:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 14:57:29 --> Final output sent to browser
DEBUG - 2016-11-20 14:57:29 --> Total execution time: 0.5089
INFO - 2016-11-20 14:59:38 --> Config Class Initialized
INFO - 2016-11-20 14:59:38 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:59:38 --> UTF-8 Support Enabled
INFO - 2016-11-20 14:59:38 --> Utf8 Class Initialized
INFO - 2016-11-20 14:59:38 --> URI Class Initialized
DEBUG - 2016-11-20 14:59:38 --> No URI present. Default controller set.
INFO - 2016-11-20 14:59:38 --> Router Class Initialized
INFO - 2016-11-20 14:59:38 --> Output Class Initialized
INFO - 2016-11-20 14:59:38 --> Security Class Initialized
DEBUG - 2016-11-20 14:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 14:59:38 --> Input Class Initialized
INFO - 2016-11-20 14:59:38 --> Language Class Initialized
INFO - 2016-11-20 14:59:38 --> Loader Class Initialized
INFO - 2016-11-20 14:59:38 --> Helper loaded: url_helper
INFO - 2016-11-20 14:59:38 --> Helper loaded: form_helper
INFO - 2016-11-20 14:59:38 --> Database Driver Class Initialized
INFO - 2016-11-20 14:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 14:59:38 --> Controller Class Initialized
INFO - 2016-11-20 14:59:38 --> Model Class Initialized
INFO - 2016-11-20 14:59:38 --> Model Class Initialized
INFO - 2016-11-20 14:59:38 --> Model Class Initialized
INFO - 2016-11-20 14:59:38 --> Model Class Initialized
INFO - 2016-11-20 14:59:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 14:59:38 --> Pagination Class Initialized
INFO - 2016-11-20 14:59:38 --> Helper loaded: app_helper
INFO - 2016-11-20 14:59:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 14:59:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 14:59:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 14:59:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 14:59:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 14:59:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 14:59:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 14:59:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 14:59:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 14:59:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 14:59:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 14:59:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 14:59:38 --> Final output sent to browser
DEBUG - 2016-11-20 14:59:39 --> Total execution time: 0.5662
INFO - 2016-11-20 15:00:29 --> Config Class Initialized
INFO - 2016-11-20 15:00:30 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:00:30 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:00:30 --> Utf8 Class Initialized
INFO - 2016-11-20 15:00:30 --> URI Class Initialized
DEBUG - 2016-11-20 15:00:30 --> No URI present. Default controller set.
INFO - 2016-11-20 15:00:30 --> Router Class Initialized
INFO - 2016-11-20 15:00:30 --> Output Class Initialized
INFO - 2016-11-20 15:00:30 --> Security Class Initialized
DEBUG - 2016-11-20 15:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:00:30 --> Input Class Initialized
INFO - 2016-11-20 15:00:30 --> Language Class Initialized
INFO - 2016-11-20 15:00:30 --> Loader Class Initialized
INFO - 2016-11-20 15:00:30 --> Helper loaded: url_helper
INFO - 2016-11-20 15:00:30 --> Helper loaded: form_helper
INFO - 2016-11-20 15:00:30 --> Database Driver Class Initialized
INFO - 2016-11-20 15:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:00:30 --> Controller Class Initialized
INFO - 2016-11-20 15:00:30 --> Model Class Initialized
INFO - 2016-11-20 15:00:30 --> Model Class Initialized
INFO - 2016-11-20 15:00:30 --> Model Class Initialized
INFO - 2016-11-20 15:00:30 --> Model Class Initialized
INFO - 2016-11-20 15:00:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:00:30 --> Pagination Class Initialized
INFO - 2016-11-20 15:00:30 --> Helper loaded: app_helper
INFO - 2016-11-20 15:00:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:00:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 15:00:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 15:00:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 15:00:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 15:00:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 15:00:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 15:00:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 15:00:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 15:00:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 15:00:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 15:00:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 15:00:30 --> Final output sent to browser
DEBUG - 2016-11-20 15:00:30 --> Total execution time: 0.5521
INFO - 2016-11-20 15:03:27 --> Config Class Initialized
INFO - 2016-11-20 15:03:27 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:03:27 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:03:27 --> Utf8 Class Initialized
INFO - 2016-11-20 15:03:27 --> URI Class Initialized
DEBUG - 2016-11-20 15:03:27 --> No URI present. Default controller set.
INFO - 2016-11-20 15:03:27 --> Router Class Initialized
INFO - 2016-11-20 15:03:27 --> Output Class Initialized
INFO - 2016-11-20 15:03:27 --> Security Class Initialized
DEBUG - 2016-11-20 15:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:03:27 --> Input Class Initialized
INFO - 2016-11-20 15:03:27 --> Language Class Initialized
INFO - 2016-11-20 15:03:27 --> Loader Class Initialized
INFO - 2016-11-20 15:03:27 --> Helper loaded: url_helper
INFO - 2016-11-20 15:03:27 --> Helper loaded: form_helper
INFO - 2016-11-20 15:03:27 --> Database Driver Class Initialized
INFO - 2016-11-20 15:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:03:27 --> Controller Class Initialized
INFO - 2016-11-20 15:03:27 --> Model Class Initialized
INFO - 2016-11-20 15:03:27 --> Model Class Initialized
INFO - 2016-11-20 15:03:27 --> Model Class Initialized
INFO - 2016-11-20 15:03:27 --> Model Class Initialized
INFO - 2016-11-20 15:03:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:03:27 --> Pagination Class Initialized
INFO - 2016-11-20 15:03:28 --> Helper loaded: app_helper
INFO - 2016-11-20 15:03:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:03:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 15:03:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 15:03:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 15:03:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 15:03:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 15:03:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 15:03:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 15:03:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 15:03:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 15:03:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 15:03:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 15:03:28 --> Final output sent to browser
DEBUG - 2016-11-20 15:03:28 --> Total execution time: 0.5558
INFO - 2016-11-20 15:03:33 --> Config Class Initialized
INFO - 2016-11-20 15:03:33 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:03:33 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:03:33 --> Utf8 Class Initialized
INFO - 2016-11-20 15:03:33 --> URI Class Initialized
DEBUG - 2016-11-20 15:03:33 --> No URI present. Default controller set.
INFO - 2016-11-20 15:03:33 --> Router Class Initialized
INFO - 2016-11-20 15:03:33 --> Output Class Initialized
INFO - 2016-11-20 15:03:33 --> Security Class Initialized
DEBUG - 2016-11-20 15:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:03:33 --> Input Class Initialized
INFO - 2016-11-20 15:03:33 --> Language Class Initialized
INFO - 2016-11-20 15:03:33 --> Loader Class Initialized
INFO - 2016-11-20 15:03:33 --> Helper loaded: url_helper
INFO - 2016-11-20 15:03:33 --> Helper loaded: form_helper
INFO - 2016-11-20 15:03:33 --> Database Driver Class Initialized
INFO - 2016-11-20 15:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:03:33 --> Controller Class Initialized
INFO - 2016-11-20 15:03:33 --> Model Class Initialized
INFO - 2016-11-20 15:03:33 --> Model Class Initialized
INFO - 2016-11-20 15:03:33 --> Model Class Initialized
INFO - 2016-11-20 15:03:33 --> Model Class Initialized
INFO - 2016-11-20 15:03:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:03:33 --> Pagination Class Initialized
INFO - 2016-11-20 15:03:33 --> Helper loaded: app_helper
INFO - 2016-11-20 15:03:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:03:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 15:03:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 15:03:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 15:03:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 15:03:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 15:03:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 15:03:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 15:03:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 15:03:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 15:03:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 15:03:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 15:03:33 --> Final output sent to browser
DEBUG - 2016-11-20 15:03:34 --> Total execution time: 0.5506
INFO - 2016-11-20 15:04:21 --> Config Class Initialized
INFO - 2016-11-20 15:04:21 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:04:21 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:04:21 --> Utf8 Class Initialized
INFO - 2016-11-20 15:04:21 --> URI Class Initialized
DEBUG - 2016-11-20 15:04:21 --> No URI present. Default controller set.
INFO - 2016-11-20 15:04:21 --> Router Class Initialized
INFO - 2016-11-20 15:04:21 --> Output Class Initialized
INFO - 2016-11-20 15:04:21 --> Security Class Initialized
DEBUG - 2016-11-20 15:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:04:21 --> Input Class Initialized
INFO - 2016-11-20 15:04:21 --> Language Class Initialized
INFO - 2016-11-20 15:04:21 --> Loader Class Initialized
INFO - 2016-11-20 15:04:21 --> Helper loaded: url_helper
INFO - 2016-11-20 15:04:21 --> Helper loaded: form_helper
INFO - 2016-11-20 15:04:21 --> Database Driver Class Initialized
INFO - 2016-11-20 15:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:04:21 --> Controller Class Initialized
INFO - 2016-11-20 15:04:21 --> Model Class Initialized
INFO - 2016-11-20 15:04:21 --> Model Class Initialized
INFO - 2016-11-20 15:04:21 --> Model Class Initialized
INFO - 2016-11-20 15:04:21 --> Model Class Initialized
INFO - 2016-11-20 15:04:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:04:22 --> Pagination Class Initialized
INFO - 2016-11-20 15:04:22 --> Helper loaded: app_helper
INFO - 2016-11-20 15:04:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:04:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 15:04:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 15:04:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 15:04:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 15:04:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 15:04:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 15:04:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 15:04:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 15:04:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 15:04:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 15:04:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 15:04:22 --> Final output sent to browser
DEBUG - 2016-11-20 15:04:22 --> Total execution time: 0.5419
INFO - 2016-11-20 15:06:20 --> Config Class Initialized
INFO - 2016-11-20 15:06:20 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:06:20 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:06:20 --> Utf8 Class Initialized
INFO - 2016-11-20 15:06:20 --> URI Class Initialized
INFO - 2016-11-20 15:06:20 --> Router Class Initialized
INFO - 2016-11-20 15:06:20 --> Output Class Initialized
INFO - 2016-11-20 15:06:20 --> Security Class Initialized
DEBUG - 2016-11-20 15:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:06:20 --> Input Class Initialized
INFO - 2016-11-20 15:06:20 --> Language Class Initialized
INFO - 2016-11-20 15:06:20 --> Loader Class Initialized
INFO - 2016-11-20 15:06:20 --> Helper loaded: url_helper
INFO - 2016-11-20 15:06:20 --> Helper loaded: form_helper
INFO - 2016-11-20 15:06:20 --> Database Driver Class Initialized
INFO - 2016-11-20 15:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:06:20 --> Controller Class Initialized
INFO - 2016-11-20 15:06:20 --> Model Class Initialized
INFO - 2016-11-20 15:06:20 --> Form Validation Class Initialized
ERROR - 2016-11-20 15:06:20 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 15:06:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 15:06:20 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 15:06:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 15:06:20 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 15:06:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 15:06:20 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 15:06:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 15:06:20 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-11-20 15:06:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 15:06:20 --> Final output sent to browser
DEBUG - 2016-11-20 15:06:20 --> Total execution time: 0.6082
INFO - 2016-11-20 15:06:20 --> Config Class Initialized
INFO - 2016-11-20 15:06:21 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:06:21 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:06:21 --> Utf8 Class Initialized
INFO - 2016-11-20 15:06:21 --> URI Class Initialized
DEBUG - 2016-11-20 15:06:21 --> No URI present. Default controller set.
INFO - 2016-11-20 15:06:21 --> Router Class Initialized
INFO - 2016-11-20 15:06:21 --> Output Class Initialized
INFO - 2016-11-20 15:06:21 --> Security Class Initialized
DEBUG - 2016-11-20 15:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:06:21 --> Input Class Initialized
INFO - 2016-11-20 15:06:21 --> Language Class Initialized
INFO - 2016-11-20 15:06:21 --> Loader Class Initialized
INFO - 2016-11-20 15:06:21 --> Helper loaded: url_helper
INFO - 2016-11-20 15:06:21 --> Helper loaded: form_helper
INFO - 2016-11-20 15:06:21 --> Database Driver Class Initialized
INFO - 2016-11-20 15:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:06:21 --> Controller Class Initialized
INFO - 2016-11-20 15:06:21 --> Model Class Initialized
INFO - 2016-11-20 15:06:21 --> Model Class Initialized
INFO - 2016-11-20 15:06:21 --> Model Class Initialized
INFO - 2016-11-20 15:06:21 --> Model Class Initialized
INFO - 2016-11-20 15:06:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:06:21 --> Pagination Class Initialized
INFO - 2016-11-20 15:06:21 --> Helper loaded: app_helper
INFO - 2016-11-20 15:06:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:06:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 15:06:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 15:06:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 15:06:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 15:06:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 15:06:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 15:06:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 15:06:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 15:06:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 15:06:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 15:06:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 15:06:21 --> Final output sent to browser
DEBUG - 2016-11-20 15:06:21 --> Total execution time: 0.4841
INFO - 2016-11-20 15:10:19 --> Config Class Initialized
INFO - 2016-11-20 15:10:19 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:10:19 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:10:19 --> Utf8 Class Initialized
INFO - 2016-11-20 15:10:19 --> URI Class Initialized
DEBUG - 2016-11-20 15:10:19 --> No URI present. Default controller set.
INFO - 2016-11-20 15:10:19 --> Router Class Initialized
INFO - 2016-11-20 15:10:19 --> Output Class Initialized
INFO - 2016-11-20 15:10:19 --> Security Class Initialized
DEBUG - 2016-11-20 15:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:10:19 --> Input Class Initialized
INFO - 2016-11-20 15:10:19 --> Language Class Initialized
INFO - 2016-11-20 15:10:19 --> Loader Class Initialized
INFO - 2016-11-20 15:10:19 --> Helper loaded: url_helper
INFO - 2016-11-20 15:10:19 --> Helper loaded: form_helper
INFO - 2016-11-20 15:10:19 --> Database Driver Class Initialized
INFO - 2016-11-20 15:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:10:19 --> Controller Class Initialized
INFO - 2016-11-20 15:10:19 --> Model Class Initialized
INFO - 2016-11-20 15:10:19 --> Model Class Initialized
INFO - 2016-11-20 15:10:19 --> Model Class Initialized
INFO - 2016-11-20 15:10:19 --> Model Class Initialized
INFO - 2016-11-20 15:10:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:10:19 --> Pagination Class Initialized
INFO - 2016-11-20 15:10:19 --> Helper loaded: app_helper
INFO - 2016-11-20 15:10:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:10:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 15:10:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 15:10:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 15:10:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 15:10:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 15:10:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 15:10:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 15:10:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 15:10:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 15:10:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 15:10:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 15:10:19 --> Final output sent to browser
DEBUG - 2016-11-20 15:10:19 --> Total execution time: 0.5533
INFO - 2016-11-20 15:10:24 --> Config Class Initialized
INFO - 2016-11-20 15:10:24 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:10:24 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:10:24 --> Utf8 Class Initialized
INFO - 2016-11-20 15:10:24 --> URI Class Initialized
DEBUG - 2016-11-20 15:10:24 --> No URI present. Default controller set.
INFO - 2016-11-20 15:10:24 --> Router Class Initialized
INFO - 2016-11-20 15:10:24 --> Output Class Initialized
INFO - 2016-11-20 15:10:24 --> Security Class Initialized
DEBUG - 2016-11-20 15:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:10:24 --> Input Class Initialized
INFO - 2016-11-20 15:10:24 --> Language Class Initialized
INFO - 2016-11-20 15:10:24 --> Loader Class Initialized
INFO - 2016-11-20 15:10:24 --> Helper loaded: url_helper
INFO - 2016-11-20 15:10:25 --> Helper loaded: form_helper
INFO - 2016-11-20 15:10:25 --> Database Driver Class Initialized
INFO - 2016-11-20 15:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:10:25 --> Controller Class Initialized
INFO - 2016-11-20 15:10:25 --> Model Class Initialized
INFO - 2016-11-20 15:10:25 --> Model Class Initialized
INFO - 2016-11-20 15:10:25 --> Model Class Initialized
INFO - 2016-11-20 15:10:25 --> Model Class Initialized
INFO - 2016-11-20 15:10:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:10:25 --> Pagination Class Initialized
INFO - 2016-11-20 15:10:25 --> Helper loaded: app_helper
INFO - 2016-11-20 15:10:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:10:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 15:10:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 15:10:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 15:10:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 15:10:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 15:10:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 15:10:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 15:10:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 15:10:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 15:10:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 15:10:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 15:10:26 --> Final output sent to browser
DEBUG - 2016-11-20 15:10:26 --> Total execution time: 2.0944
INFO - 2016-11-20 15:11:31 --> Config Class Initialized
INFO - 2016-11-20 15:11:31 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:11:31 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:11:31 --> Utf8 Class Initialized
INFO - 2016-11-20 15:11:31 --> URI Class Initialized
DEBUG - 2016-11-20 15:11:31 --> No URI present. Default controller set.
INFO - 2016-11-20 15:11:31 --> Router Class Initialized
INFO - 2016-11-20 15:11:31 --> Output Class Initialized
INFO - 2016-11-20 15:11:31 --> Security Class Initialized
DEBUG - 2016-11-20 15:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:11:31 --> Input Class Initialized
INFO - 2016-11-20 15:11:31 --> Language Class Initialized
INFO - 2016-11-20 15:11:31 --> Loader Class Initialized
INFO - 2016-11-20 15:11:31 --> Helper loaded: url_helper
INFO - 2016-11-20 15:11:31 --> Helper loaded: form_helper
INFO - 2016-11-20 15:11:31 --> Database Driver Class Initialized
INFO - 2016-11-20 15:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:11:31 --> Controller Class Initialized
INFO - 2016-11-20 15:11:31 --> Model Class Initialized
INFO - 2016-11-20 15:11:31 --> Model Class Initialized
INFO - 2016-11-20 15:11:32 --> Model Class Initialized
INFO - 2016-11-20 15:11:32 --> Model Class Initialized
INFO - 2016-11-20 15:11:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:11:32 --> Pagination Class Initialized
INFO - 2016-11-20 15:11:32 --> Helper loaded: app_helper
INFO - 2016-11-20 15:11:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:11:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 15:11:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 15:11:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 15:11:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 15:11:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 15:11:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 15:11:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 15:11:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 15:11:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 15:11:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 15:11:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 15:11:32 --> Final output sent to browser
DEBUG - 2016-11-20 15:11:32 --> Total execution time: 0.5538
INFO - 2016-11-20 15:12:56 --> Config Class Initialized
INFO - 2016-11-20 15:12:56 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:12:56 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:12:56 --> Utf8 Class Initialized
INFO - 2016-11-20 15:12:56 --> URI Class Initialized
DEBUG - 2016-11-20 15:12:56 --> No URI present. Default controller set.
INFO - 2016-11-20 15:12:56 --> Router Class Initialized
INFO - 2016-11-20 15:12:56 --> Output Class Initialized
INFO - 2016-11-20 15:12:56 --> Security Class Initialized
DEBUG - 2016-11-20 15:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:12:56 --> Input Class Initialized
INFO - 2016-11-20 15:12:56 --> Language Class Initialized
INFO - 2016-11-20 15:12:56 --> Loader Class Initialized
INFO - 2016-11-20 15:12:56 --> Helper loaded: url_helper
INFO - 2016-11-20 15:12:56 --> Helper loaded: form_helper
INFO - 2016-11-20 15:12:56 --> Database Driver Class Initialized
INFO - 2016-11-20 15:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:12:56 --> Controller Class Initialized
INFO - 2016-11-20 15:12:56 --> Model Class Initialized
INFO - 2016-11-20 15:12:56 --> Model Class Initialized
INFO - 2016-11-20 15:12:56 --> Model Class Initialized
INFO - 2016-11-20 15:12:56 --> Model Class Initialized
INFO - 2016-11-20 15:12:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:12:56 --> Pagination Class Initialized
INFO - 2016-11-20 15:12:56 --> Helper loaded: app_helper
INFO - 2016-11-20 15:12:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:12:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 15:12:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 15:12:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 15:12:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 15:12:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 15:12:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 15:12:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 15:12:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 15:12:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 15:12:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 15:12:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 15:12:57 --> Final output sent to browser
DEBUG - 2016-11-20 15:12:57 --> Total execution time: 0.5425
INFO - 2016-11-20 15:15:36 --> Config Class Initialized
INFO - 2016-11-20 15:15:36 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:15:37 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:15:37 --> Utf8 Class Initialized
INFO - 2016-11-20 15:15:37 --> URI Class Initialized
INFO - 2016-11-20 15:15:37 --> Router Class Initialized
INFO - 2016-11-20 15:15:37 --> Output Class Initialized
INFO - 2016-11-20 15:15:37 --> Security Class Initialized
DEBUG - 2016-11-20 15:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:15:37 --> Input Class Initialized
INFO - 2016-11-20 15:15:37 --> Language Class Initialized
INFO - 2016-11-20 15:15:37 --> Loader Class Initialized
INFO - 2016-11-20 15:15:37 --> Helper loaded: url_helper
INFO - 2016-11-20 15:15:37 --> Helper loaded: form_helper
INFO - 2016-11-20 15:15:37 --> Database Driver Class Initialized
INFO - 2016-11-20 15:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:15:37 --> Controller Class Initialized
INFO - 2016-11-20 15:15:37 --> Model Class Initialized
ERROR - 2016-11-20 15:15:37 --> Severity: Error --> Call to undefined function ajax_pagination() C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 113
INFO - 2016-11-20 15:15:43 --> Config Class Initialized
INFO - 2016-11-20 15:15:43 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:15:43 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:15:43 --> Utf8 Class Initialized
INFO - 2016-11-20 15:15:43 --> URI Class Initialized
DEBUG - 2016-11-20 15:15:43 --> No URI present. Default controller set.
INFO - 2016-11-20 15:15:43 --> Router Class Initialized
INFO - 2016-11-20 15:15:43 --> Output Class Initialized
INFO - 2016-11-20 15:15:43 --> Security Class Initialized
DEBUG - 2016-11-20 15:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:15:43 --> Input Class Initialized
INFO - 2016-11-20 15:15:43 --> Language Class Initialized
INFO - 2016-11-20 15:15:43 --> Loader Class Initialized
INFO - 2016-11-20 15:15:43 --> Helper loaded: url_helper
INFO - 2016-11-20 15:15:43 --> Helper loaded: form_helper
INFO - 2016-11-20 15:15:43 --> Database Driver Class Initialized
INFO - 2016-11-20 15:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:15:43 --> Controller Class Initialized
INFO - 2016-11-20 15:15:43 --> Model Class Initialized
INFO - 2016-11-20 15:15:43 --> Model Class Initialized
INFO - 2016-11-20 15:15:43 --> Model Class Initialized
INFO - 2016-11-20 15:15:43 --> Model Class Initialized
INFO - 2016-11-20 15:15:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:15:43 --> Pagination Class Initialized
INFO - 2016-11-20 15:15:43 --> Helper loaded: app_helper
INFO - 2016-11-20 15:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 15:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 15:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 15:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 15:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 15:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 15:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 15:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 15:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 15:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 15:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 15:15:43 --> Final output sent to browser
DEBUG - 2016-11-20 15:15:43 --> Total execution time: 0.5512
INFO - 2016-11-20 15:18:12 --> Config Class Initialized
INFO - 2016-11-20 15:18:12 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:18:12 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:18:12 --> Utf8 Class Initialized
INFO - 2016-11-20 15:18:12 --> URI Class Initialized
DEBUG - 2016-11-20 15:18:12 --> No URI present. Default controller set.
INFO - 2016-11-20 15:18:12 --> Router Class Initialized
INFO - 2016-11-20 15:18:12 --> Output Class Initialized
INFO - 2016-11-20 15:18:12 --> Security Class Initialized
DEBUG - 2016-11-20 15:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:18:12 --> Input Class Initialized
INFO - 2016-11-20 15:18:12 --> Language Class Initialized
INFO - 2016-11-20 15:18:12 --> Loader Class Initialized
INFO - 2016-11-20 15:18:12 --> Helper loaded: url_helper
INFO - 2016-11-20 15:18:12 --> Helper loaded: form_helper
INFO - 2016-11-20 15:18:12 --> Database Driver Class Initialized
INFO - 2016-11-20 15:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:18:12 --> Controller Class Initialized
INFO - 2016-11-20 15:18:12 --> Model Class Initialized
INFO - 2016-11-20 15:18:12 --> Model Class Initialized
INFO - 2016-11-20 15:18:12 --> Model Class Initialized
INFO - 2016-11-20 15:18:12 --> Model Class Initialized
INFO - 2016-11-20 15:18:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:18:12 --> Pagination Class Initialized
INFO - 2016-11-20 15:18:12 --> Helper loaded: app_helper
INFO - 2016-11-20 15:18:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:18:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 15:18:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 15:18:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 15:18:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 15:18:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 15:18:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 15:18:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 15:18:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 15:18:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 15:18:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 15:18:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 15:18:13 --> Final output sent to browser
DEBUG - 2016-11-20 15:18:13 --> Total execution time: 0.5509
INFO - 2016-11-20 15:18:40 --> Config Class Initialized
INFO - 2016-11-20 15:18:40 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:18:40 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:18:40 --> Utf8 Class Initialized
INFO - 2016-11-20 15:18:41 --> URI Class Initialized
DEBUG - 2016-11-20 15:18:41 --> No URI present. Default controller set.
INFO - 2016-11-20 15:18:41 --> Router Class Initialized
INFO - 2016-11-20 15:18:41 --> Output Class Initialized
INFO - 2016-11-20 15:18:41 --> Security Class Initialized
DEBUG - 2016-11-20 15:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:18:41 --> Input Class Initialized
INFO - 2016-11-20 15:18:41 --> Language Class Initialized
INFO - 2016-11-20 15:18:41 --> Loader Class Initialized
INFO - 2016-11-20 15:18:41 --> Helper loaded: url_helper
INFO - 2016-11-20 15:18:41 --> Helper loaded: form_helper
INFO - 2016-11-20 15:18:41 --> Database Driver Class Initialized
INFO - 2016-11-20 15:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:18:41 --> Controller Class Initialized
INFO - 2016-11-20 15:18:41 --> Model Class Initialized
INFO - 2016-11-20 15:18:41 --> Model Class Initialized
INFO - 2016-11-20 15:18:41 --> Model Class Initialized
INFO - 2016-11-20 15:18:41 --> Model Class Initialized
INFO - 2016-11-20 15:18:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:18:41 --> Pagination Class Initialized
INFO - 2016-11-20 15:18:41 --> Helper loaded: app_helper
INFO - 2016-11-20 15:18:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:18:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 15:18:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 15:18:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 15:18:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 15:18:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 15:18:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 15:18:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 15:18:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 15:18:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 15:18:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 15:18:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 15:18:41 --> Final output sent to browser
DEBUG - 2016-11-20 15:18:41 --> Total execution time: 0.5402
INFO - 2016-11-20 15:20:28 --> Config Class Initialized
INFO - 2016-11-20 15:20:28 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:20:28 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:20:28 --> Utf8 Class Initialized
INFO - 2016-11-20 15:20:28 --> URI Class Initialized
DEBUG - 2016-11-20 15:20:28 --> No URI present. Default controller set.
INFO - 2016-11-20 15:20:28 --> Router Class Initialized
INFO - 2016-11-20 15:20:28 --> Output Class Initialized
INFO - 2016-11-20 15:20:28 --> Security Class Initialized
DEBUG - 2016-11-20 15:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:20:28 --> Input Class Initialized
INFO - 2016-11-20 15:20:28 --> Language Class Initialized
INFO - 2016-11-20 15:20:28 --> Loader Class Initialized
INFO - 2016-11-20 15:20:28 --> Helper loaded: url_helper
INFO - 2016-11-20 15:20:28 --> Helper loaded: form_helper
INFO - 2016-11-20 15:20:28 --> Database Driver Class Initialized
INFO - 2016-11-20 15:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:20:28 --> Controller Class Initialized
INFO - 2016-11-20 15:20:28 --> Model Class Initialized
INFO - 2016-11-20 15:20:28 --> Model Class Initialized
INFO - 2016-11-20 15:20:28 --> Model Class Initialized
INFO - 2016-11-20 15:20:28 --> Model Class Initialized
INFO - 2016-11-20 15:20:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:20:28 --> Pagination Class Initialized
INFO - 2016-11-20 15:20:28 --> Helper loaded: app_helper
INFO - 2016-11-20 15:20:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:20:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 15:20:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 15:20:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 15:20:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 20
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 27
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 20
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 27
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 20
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 27
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 20
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 27
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 20
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 27
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 20
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 27
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 20
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 27
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 20
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 27
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 20
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 27
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 20
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:20:28 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 27
INFO - 2016-11-20 15:20:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 15:20:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 15:20:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 15:20:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 15:20:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 15:20:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 15:20:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 15:20:29 --> Final output sent to browser
DEBUG - 2016-11-20 15:20:29 --> Total execution time: 0.9902
INFO - 2016-11-20 15:21:20 --> Config Class Initialized
INFO - 2016-11-20 15:21:20 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:21:20 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:21:20 --> Utf8 Class Initialized
INFO - 2016-11-20 15:21:20 --> URI Class Initialized
DEBUG - 2016-11-20 15:21:20 --> No URI present. Default controller set.
INFO - 2016-11-20 15:21:20 --> Router Class Initialized
INFO - 2016-11-20 15:21:20 --> Output Class Initialized
INFO - 2016-11-20 15:21:20 --> Security Class Initialized
DEBUG - 2016-11-20 15:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:21:20 --> Input Class Initialized
INFO - 2016-11-20 15:21:21 --> Language Class Initialized
INFO - 2016-11-20 15:21:21 --> Loader Class Initialized
INFO - 2016-11-20 15:21:21 --> Helper loaded: url_helper
INFO - 2016-11-20 15:21:21 --> Helper loaded: form_helper
INFO - 2016-11-20 15:21:21 --> Database Driver Class Initialized
INFO - 2016-11-20 15:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:21:21 --> Controller Class Initialized
INFO - 2016-11-20 15:21:21 --> Model Class Initialized
INFO - 2016-11-20 15:21:21 --> Model Class Initialized
INFO - 2016-11-20 15:21:21 --> Model Class Initialized
INFO - 2016-11-20 15:21:21 --> Model Class Initialized
INFO - 2016-11-20 15:21:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:21:21 --> Pagination Class Initialized
INFO - 2016-11-20 15:21:21 --> Helper loaded: app_helper
INFO - 2016-11-20 15:21:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:21:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 15:21:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 15:21:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 15:21:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
ERROR - 2016-11-20 15:21:21 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:21:21 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 25
ERROR - 2016-11-20 15:21:21 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:21:21 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 25
ERROR - 2016-11-20 15:21:21 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:21:21 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 25
ERROR - 2016-11-20 15:21:21 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:21:21 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 25
ERROR - 2016-11-20 15:21:21 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:21:21 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 25
ERROR - 2016-11-20 15:21:21 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:21:21 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 25
ERROR - 2016-11-20 15:21:21 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:21:21 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 25
ERROR - 2016-11-20 15:21:21 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:21:21 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 25
ERROR - 2016-11-20 15:21:21 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:21:21 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 25
ERROR - 2016-11-20 15:21:21 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:21:21 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 25
INFO - 2016-11-20 15:21:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 15:21:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 15:21:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 15:21:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 15:21:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 15:21:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 15:21:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 15:21:21 --> Final output sent to browser
DEBUG - 2016-11-20 15:21:21 --> Total execution time: 0.8015
INFO - 2016-11-20 15:22:03 --> Config Class Initialized
INFO - 2016-11-20 15:22:03 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:22:03 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:22:03 --> Utf8 Class Initialized
INFO - 2016-11-20 15:22:03 --> URI Class Initialized
DEBUG - 2016-11-20 15:22:03 --> No URI present. Default controller set.
INFO - 2016-11-20 15:22:03 --> Router Class Initialized
INFO - 2016-11-20 15:22:03 --> Output Class Initialized
INFO - 2016-11-20 15:22:03 --> Security Class Initialized
DEBUG - 2016-11-20 15:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:22:04 --> Input Class Initialized
INFO - 2016-11-20 15:22:04 --> Language Class Initialized
INFO - 2016-11-20 15:22:04 --> Loader Class Initialized
INFO - 2016-11-20 15:22:04 --> Helper loaded: url_helper
INFO - 2016-11-20 15:22:04 --> Helper loaded: form_helper
INFO - 2016-11-20 15:22:04 --> Database Driver Class Initialized
INFO - 2016-11-20 15:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:22:04 --> Controller Class Initialized
INFO - 2016-11-20 15:22:04 --> Model Class Initialized
INFO - 2016-11-20 15:22:04 --> Model Class Initialized
INFO - 2016-11-20 15:22:04 --> Model Class Initialized
INFO - 2016-11-20 15:22:04 --> Model Class Initialized
INFO - 2016-11-20 15:22:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:22:04 --> Pagination Class Initialized
INFO - 2016-11-20 15:22:04 --> Helper loaded: app_helper
INFO - 2016-11-20 15:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 15:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 15:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 15:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
ERROR - 2016-11-20 15:22:04 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:22:04 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:22:04 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:22:04 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:22:04 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:22:04 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:22:04 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:22:04 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:22:04 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:22:04 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
INFO - 2016-11-20 15:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 15:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 15:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 15:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 15:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 15:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 15:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 15:22:04 --> Final output sent to browser
DEBUG - 2016-11-20 15:22:04 --> Total execution time: 0.6742
INFO - 2016-11-20 15:22:17 --> Config Class Initialized
INFO - 2016-11-20 15:22:17 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:22:17 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:22:17 --> Utf8 Class Initialized
INFO - 2016-11-20 15:22:17 --> URI Class Initialized
DEBUG - 2016-11-20 15:22:17 --> No URI present. Default controller set.
INFO - 2016-11-20 15:22:17 --> Router Class Initialized
INFO - 2016-11-20 15:22:17 --> Output Class Initialized
INFO - 2016-11-20 15:22:17 --> Security Class Initialized
DEBUG - 2016-11-20 15:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:22:17 --> Input Class Initialized
INFO - 2016-11-20 15:22:17 --> Language Class Initialized
INFO - 2016-11-20 15:22:17 --> Loader Class Initialized
INFO - 2016-11-20 15:22:17 --> Helper loaded: url_helper
INFO - 2016-11-20 15:22:17 --> Helper loaded: form_helper
INFO - 2016-11-20 15:22:17 --> Database Driver Class Initialized
INFO - 2016-11-20 15:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:22:17 --> Controller Class Initialized
INFO - 2016-11-20 15:22:17 --> Model Class Initialized
INFO - 2016-11-20 15:22:17 --> Model Class Initialized
INFO - 2016-11-20 15:22:17 --> Model Class Initialized
INFO - 2016-11-20 15:22:17 --> Model Class Initialized
INFO - 2016-11-20 15:22:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:22:17 --> Pagination Class Initialized
INFO - 2016-11-20 15:22:17 --> Helper loaded: app_helper
INFO - 2016-11-20 15:22:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 15:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 15:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 15:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
ERROR - 2016-11-20 15:22:18 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:22:18 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:22:18 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:22:18 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:22:18 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:22:18 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:22:18 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:22:18 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:22:18 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:22:18 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
INFO - 2016-11-20 15:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 15:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 15:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 15:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 15:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 15:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 15:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 15:22:18 --> Final output sent to browser
DEBUG - 2016-11-20 15:22:18 --> Total execution time: 0.7313
INFO - 2016-11-20 15:23:10 --> Config Class Initialized
INFO - 2016-11-20 15:23:10 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:23:10 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:23:10 --> Utf8 Class Initialized
INFO - 2016-11-20 15:23:10 --> URI Class Initialized
DEBUG - 2016-11-20 15:23:10 --> No URI present. Default controller set.
INFO - 2016-11-20 15:23:10 --> Router Class Initialized
INFO - 2016-11-20 15:23:10 --> Output Class Initialized
INFO - 2016-11-20 15:23:10 --> Security Class Initialized
DEBUG - 2016-11-20 15:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:23:10 --> Input Class Initialized
INFO - 2016-11-20 15:23:10 --> Language Class Initialized
INFO - 2016-11-20 15:23:10 --> Loader Class Initialized
INFO - 2016-11-20 15:23:10 --> Helper loaded: url_helper
INFO - 2016-11-20 15:23:10 --> Helper loaded: form_helper
INFO - 2016-11-20 15:23:10 --> Database Driver Class Initialized
INFO - 2016-11-20 15:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:23:10 --> Controller Class Initialized
INFO - 2016-11-20 15:23:10 --> Model Class Initialized
INFO - 2016-11-20 15:23:10 --> Model Class Initialized
INFO - 2016-11-20 15:23:10 --> Model Class Initialized
INFO - 2016-11-20 15:23:10 --> Model Class Initialized
INFO - 2016-11-20 15:23:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:23:10 --> Pagination Class Initialized
INFO - 2016-11-20 15:23:10 --> Helper loaded: app_helper
INFO - 2016-11-20 15:23:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:23:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 15:23:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 15:23:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 15:23:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
ERROR - 2016-11-20 15:23:10 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:23:10 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:23:10 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:23:10 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:23:10 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:23:10 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:23:10 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:23:10 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:23:10 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:23:10 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:23:10 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:23:10 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:23:10 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:23:10 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:23:11 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:23:11 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:23:11 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:23:11 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:23:11 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:23:11 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
INFO - 2016-11-20 15:23:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 15:23:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 15:23:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 15:23:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 15:23:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 15:23:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 15:23:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 15:23:11 --> Final output sent to browser
DEBUG - 2016-11-20 15:23:11 --> Total execution time: 0.8092
INFO - 2016-11-20 15:45:48 --> Config Class Initialized
INFO - 2016-11-20 15:45:48 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:45:48 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:45:48 --> Utf8 Class Initialized
INFO - 2016-11-20 15:45:48 --> URI Class Initialized
DEBUG - 2016-11-20 15:45:48 --> No URI present. Default controller set.
INFO - 2016-11-20 15:45:48 --> Router Class Initialized
INFO - 2016-11-20 15:45:48 --> Output Class Initialized
INFO - 2016-11-20 15:45:48 --> Security Class Initialized
DEBUG - 2016-11-20 15:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:45:48 --> Input Class Initialized
INFO - 2016-11-20 15:45:48 --> Language Class Initialized
INFO - 2016-11-20 15:45:48 --> Loader Class Initialized
INFO - 2016-11-20 15:45:48 --> Helper loaded: url_helper
INFO - 2016-11-20 15:45:48 --> Helper loaded: form_helper
INFO - 2016-11-20 15:45:48 --> Database Driver Class Initialized
INFO - 2016-11-20 15:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:45:48 --> Controller Class Initialized
INFO - 2016-11-20 15:45:48 --> Model Class Initialized
INFO - 2016-11-20 15:45:48 --> Model Class Initialized
INFO - 2016-11-20 15:45:48 --> Model Class Initialized
INFO - 2016-11-20 15:45:48 --> Model Class Initialized
INFO - 2016-11-20 15:45:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:45:48 --> Pagination Class Initialized
INFO - 2016-11-20 15:45:48 --> Helper loaded: app_helper
INFO - 2016-11-20 15:45:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:45:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-20 15:45:48 --> Query error: Unknown column 'em.idEmployee' in 'where clause' - Invalid query: SELECT `ap`.`startDate`, `ap`.`endDate`, `ap`.`id`, `ap`.`applicationDate`, `ap`.`numberOfDays`, `lt`.`typeName`, `ls`.`statusName`, `em`.`surname`
FROM `applicationData` `ap`
LEFT JOIN `employee` as `em` ON `em`.`id` = `ap`.`idEmployee`
LEFT JOIN `leaveType` as `lt` ON `lt`.`id` = `ap`.`idLeaveType`
LEFT JOIN `leaveStatus` as `ls` ON `ls`.`id` = `ap`.`idLeaveStatus`
WHERE `em`.`idEmployee` = '19'
AND `ap`.`bDeleted` =0
 LIMIT 10
INFO - 2016-11-20 15:45:48 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-20 15:49:24 --> Config Class Initialized
INFO - 2016-11-20 15:49:24 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:49:24 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:49:24 --> Utf8 Class Initialized
INFO - 2016-11-20 15:49:24 --> URI Class Initialized
DEBUG - 2016-11-20 15:49:24 --> No URI present. Default controller set.
INFO - 2016-11-20 15:49:24 --> Router Class Initialized
INFO - 2016-11-20 15:49:24 --> Output Class Initialized
INFO - 2016-11-20 15:49:24 --> Security Class Initialized
DEBUG - 2016-11-20 15:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:49:24 --> Input Class Initialized
INFO - 2016-11-20 15:49:24 --> Language Class Initialized
INFO - 2016-11-20 15:49:24 --> Loader Class Initialized
INFO - 2016-11-20 15:49:25 --> Helper loaded: url_helper
INFO - 2016-11-20 15:49:25 --> Helper loaded: form_helper
INFO - 2016-11-20 15:49:25 --> Database Driver Class Initialized
INFO - 2016-11-20 15:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:49:25 --> Controller Class Initialized
INFO - 2016-11-20 15:49:25 --> Model Class Initialized
INFO - 2016-11-20 15:49:25 --> Model Class Initialized
INFO - 2016-11-20 15:49:25 --> Model Class Initialized
INFO - 2016-11-20 15:49:25 --> Model Class Initialized
INFO - 2016-11-20 15:49:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:49:25 --> Pagination Class Initialized
INFO - 2016-11-20 15:49:25 --> Helper loaded: app_helper
INFO - 2016-11-20 15:49:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:49:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-20 15:49:25 --> Query error: Unknown column 'em.idEmployee' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `applicationdata` `ad`
LEFT JOIN `employee` as `em` ON `em`.`id` = `ad`.`idEmployee`
LEFT JOIN `leaveStatus` as `ls` ON `ls`.`id` = `ad`.`idLeaveStatus`
LEFT JOIN `leaveType` as `lt` ON `lt`.`id` = `ad`.`idLeaveType`
WHERE `em`.`idEmployee` = '19'
AND `ad`.`bDeleted` =0
INFO - 2016-11-20 15:49:25 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-20 15:50:33 --> Config Class Initialized
INFO - 2016-11-20 15:50:33 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:50:33 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:50:33 --> Utf8 Class Initialized
INFO - 2016-11-20 15:50:33 --> URI Class Initialized
DEBUG - 2016-11-20 15:50:33 --> No URI present. Default controller set.
INFO - 2016-11-20 15:50:33 --> Router Class Initialized
INFO - 2016-11-20 15:50:33 --> Output Class Initialized
INFO - 2016-11-20 15:50:33 --> Security Class Initialized
DEBUG - 2016-11-20 15:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:50:33 --> Input Class Initialized
INFO - 2016-11-20 15:50:33 --> Language Class Initialized
INFO - 2016-11-20 15:50:33 --> Loader Class Initialized
INFO - 2016-11-20 15:50:33 --> Helper loaded: url_helper
INFO - 2016-11-20 15:50:33 --> Helper loaded: form_helper
INFO - 2016-11-20 15:50:33 --> Database Driver Class Initialized
INFO - 2016-11-20 15:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:50:33 --> Controller Class Initialized
INFO - 2016-11-20 15:50:33 --> Model Class Initialized
INFO - 2016-11-20 15:50:33 --> Model Class Initialized
INFO - 2016-11-20 15:50:33 --> Model Class Initialized
INFO - 2016-11-20 15:50:33 --> Model Class Initialized
INFO - 2016-11-20 15:50:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:50:33 --> Pagination Class Initialized
INFO - 2016-11-20 15:50:33 --> Helper loaded: app_helper
INFO - 2016-11-20 15:50:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:50:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-20 15:50:33 --> Query error: Unknown column 'em.idEmployee' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `applicationdata` `ad`
LEFT JOIN `employee` as `em` ON `em`.`id` = `ad`.`idEmployee`
LEFT JOIN `leaveStatus` as `ls` ON `ls`.`id` = `ad`.`idLeaveStatus`
LEFT JOIN `leaveType` as `lt` ON `lt`.`id` = `ad`.`idLeaveType`
WHERE `em`.`idEmployee` = '19'
AND `ad`.`bDeleted` =0
INFO - 2016-11-20 15:50:33 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-20 15:51:02 --> Config Class Initialized
INFO - 2016-11-20 15:51:02 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:51:02 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:51:02 --> Utf8 Class Initialized
INFO - 2016-11-20 15:51:02 --> URI Class Initialized
DEBUG - 2016-11-20 15:51:02 --> No URI present. Default controller set.
INFO - 2016-11-20 15:51:02 --> Router Class Initialized
INFO - 2016-11-20 15:51:02 --> Output Class Initialized
INFO - 2016-11-20 15:51:02 --> Security Class Initialized
DEBUG - 2016-11-20 15:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:51:02 --> Input Class Initialized
INFO - 2016-11-20 15:51:02 --> Language Class Initialized
INFO - 2016-11-20 15:51:02 --> Loader Class Initialized
INFO - 2016-11-20 15:51:02 --> Helper loaded: url_helper
INFO - 2016-11-20 15:51:02 --> Helper loaded: form_helper
INFO - 2016-11-20 15:51:02 --> Database Driver Class Initialized
INFO - 2016-11-20 15:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:51:02 --> Controller Class Initialized
INFO - 2016-11-20 15:51:02 --> Model Class Initialized
INFO - 2016-11-20 15:51:02 --> Model Class Initialized
INFO - 2016-11-20 15:51:02 --> Model Class Initialized
INFO - 2016-11-20 15:51:02 --> Model Class Initialized
INFO - 2016-11-20 15:51:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:51:03 --> Pagination Class Initialized
INFO - 2016-11-20 15:51:03 --> Helper loaded: app_helper
INFO - 2016-11-20 15:51:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:51:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-20 15:51:03 --> Query error: Unknown column 'ap.idEmployee' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `applicationdata` `ad`
LEFT JOIN `employee` as `em` ON `em`.`id` = `ad`.`idEmployee`
LEFT JOIN `leaveStatus` as `ls` ON `ls`.`id` = `ad`.`idLeaveStatus`
LEFT JOIN `leaveType` as `lt` ON `lt`.`id` = `ad`.`idLeaveType`
WHERE `ap`.`idEmployee` = '19'
AND `ad`.`bDeleted` =0
INFO - 2016-11-20 15:51:03 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-20 15:51:27 --> Config Class Initialized
INFO - 2016-11-20 15:51:27 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:51:27 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:51:27 --> Utf8 Class Initialized
INFO - 2016-11-20 15:51:27 --> URI Class Initialized
DEBUG - 2016-11-20 15:51:27 --> No URI present. Default controller set.
INFO - 2016-11-20 15:51:27 --> Router Class Initialized
INFO - 2016-11-20 15:51:27 --> Output Class Initialized
INFO - 2016-11-20 15:51:27 --> Security Class Initialized
DEBUG - 2016-11-20 15:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:51:27 --> Input Class Initialized
INFO - 2016-11-20 15:51:28 --> Language Class Initialized
INFO - 2016-11-20 15:51:28 --> Loader Class Initialized
INFO - 2016-11-20 15:51:28 --> Helper loaded: url_helper
INFO - 2016-11-20 15:51:28 --> Helper loaded: form_helper
INFO - 2016-11-20 15:51:28 --> Database Driver Class Initialized
INFO - 2016-11-20 15:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:51:28 --> Controller Class Initialized
INFO - 2016-11-20 15:51:28 --> Model Class Initialized
INFO - 2016-11-20 15:51:28 --> Model Class Initialized
INFO - 2016-11-20 15:51:28 --> Model Class Initialized
INFO - 2016-11-20 15:51:28 --> Model Class Initialized
INFO - 2016-11-20 15:51:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:51:28 --> Pagination Class Initialized
INFO - 2016-11-20 15:51:28 --> Helper loaded: app_helper
INFO - 2016-11-20 15:51:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:51:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 15:51:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 15:51:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 15:51:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
ERROR - 2016-11-20 15:51:28 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:51:28 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:51:28 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:51:28 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:51:28 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:51:28 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:51:28 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:51:28 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:51:28 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:51:28 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:51:28 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:51:28 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:51:28 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:51:28 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:51:28 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:51:28 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:51:28 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:51:28 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
ERROR - 2016-11-20 15:51:28 --> Severity: Notice --> Undefined property: stdClass::$typeName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 22
ERROR - 2016-11-20 15:51:28 --> Severity: Notice --> Undefined property: stdClass::$statusName C:\xampp\htdocs\LMS\app\views\employee\my_leave.php 24
INFO - 2016-11-20 15:51:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 15:51:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 15:51:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 15:51:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 15:51:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 15:51:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 15:51:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 15:51:28 --> Final output sent to browser
DEBUG - 2016-11-20 15:51:28 --> Total execution time: 0.8067
INFO - 2016-11-20 15:55:12 --> Config Class Initialized
INFO - 2016-11-20 15:55:12 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:55:12 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:55:12 --> Utf8 Class Initialized
INFO - 2016-11-20 15:55:12 --> URI Class Initialized
DEBUG - 2016-11-20 15:55:12 --> No URI present. Default controller set.
INFO - 2016-11-20 15:55:12 --> Router Class Initialized
INFO - 2016-11-20 15:55:12 --> Output Class Initialized
INFO - 2016-11-20 15:55:12 --> Security Class Initialized
DEBUG - 2016-11-20 15:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:55:12 --> Input Class Initialized
INFO - 2016-11-20 15:55:12 --> Language Class Initialized
INFO - 2016-11-20 15:55:12 --> Loader Class Initialized
INFO - 2016-11-20 15:55:12 --> Helper loaded: url_helper
INFO - 2016-11-20 15:55:13 --> Helper loaded: form_helper
INFO - 2016-11-20 15:55:13 --> Database Driver Class Initialized
INFO - 2016-11-20 15:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:55:13 --> Controller Class Initialized
INFO - 2016-11-20 15:55:13 --> Model Class Initialized
INFO - 2016-11-20 15:55:13 --> Model Class Initialized
INFO - 2016-11-20 15:55:13 --> Model Class Initialized
INFO - 2016-11-20 15:55:13 --> Model Class Initialized
INFO - 2016-11-20 15:55:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:55:13 --> Pagination Class Initialized
INFO - 2016-11-20 15:55:13 --> Helper loaded: app_helper
INFO - 2016-11-20 15:55:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:55:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 15:55:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 15:55:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 15:55:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 15:55:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 15:55:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 15:55:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 15:55:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 15:55:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 15:55:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 15:55:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 15:55:13 --> Final output sent to browser
DEBUG - 2016-11-20 15:55:13 --> Total execution time: 0.5757
INFO - 2016-11-20 15:55:41 --> Config Class Initialized
INFO - 2016-11-20 15:55:41 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:55:41 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:55:41 --> Utf8 Class Initialized
INFO - 2016-11-20 15:55:41 --> URI Class Initialized
INFO - 2016-11-20 15:55:41 --> Router Class Initialized
INFO - 2016-11-20 15:55:41 --> Output Class Initialized
INFO - 2016-11-20 15:55:41 --> Security Class Initialized
DEBUG - 2016-11-20 15:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:55:41 --> Input Class Initialized
INFO - 2016-11-20 15:55:41 --> Language Class Initialized
INFO - 2016-11-20 15:55:41 --> Loader Class Initialized
INFO - 2016-11-20 15:55:41 --> Helper loaded: url_helper
INFO - 2016-11-20 15:55:41 --> Helper loaded: form_helper
INFO - 2016-11-20 15:55:41 --> Database Driver Class Initialized
INFO - 2016-11-20 15:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:55:41 --> Controller Class Initialized
INFO - 2016-11-20 15:55:41 --> Model Class Initialized
INFO - 2016-11-20 15:55:41 --> Model Class Initialized
INFO - 2016-11-20 15:55:41 --> Model Class Initialized
INFO - 2016-11-20 15:55:41 --> Model Class Initialized
INFO - 2016-11-20 15:55:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:55:41 --> Pagination Class Initialized
INFO - 2016-11-20 15:55:41 --> Helper loaded: app_helper
DEBUG - 2016-11-20 15:55:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-20 15:55:41 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 180
ERROR - 2016-11-20 15:55:41 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 180
INFO - 2016-11-20 15:55:41 --> Config Class Initialized
INFO - 2016-11-20 15:55:41 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:55:41 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:55:41 --> Utf8 Class Initialized
INFO - 2016-11-20 15:55:41 --> URI Class Initialized
DEBUG - 2016-11-20 15:55:41 --> No URI present. Default controller set.
INFO - 2016-11-20 15:55:41 --> Router Class Initialized
INFO - 2016-11-20 15:55:41 --> Output Class Initialized
INFO - 2016-11-20 15:55:41 --> Security Class Initialized
DEBUG - 2016-11-20 15:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:55:41 --> Input Class Initialized
INFO - 2016-11-20 15:55:41 --> Language Class Initialized
INFO - 2016-11-20 15:55:41 --> Loader Class Initialized
INFO - 2016-11-20 15:55:41 --> Helper loaded: url_helper
INFO - 2016-11-20 15:55:41 --> Helper loaded: form_helper
INFO - 2016-11-20 15:55:41 --> Database Driver Class Initialized
INFO - 2016-11-20 15:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:55:41 --> Controller Class Initialized
INFO - 2016-11-20 15:55:41 --> Model Class Initialized
INFO - 2016-11-20 15:55:41 --> Model Class Initialized
INFO - 2016-11-20 15:55:41 --> Model Class Initialized
INFO - 2016-11-20 15:55:41 --> Model Class Initialized
INFO - 2016-11-20 15:55:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:55:41 --> Pagination Class Initialized
INFO - 2016-11-20 15:55:41 --> Helper loaded: app_helper
INFO - 2016-11-20 15:55:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:55:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-20 15:55:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 15:55:42 --> Final output sent to browser
DEBUG - 2016-11-20 15:55:42 --> Total execution time: 0.4122
INFO - 2016-11-20 15:55:52 --> Config Class Initialized
INFO - 2016-11-20 15:55:52 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:55:52 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:55:52 --> Utf8 Class Initialized
INFO - 2016-11-20 15:55:52 --> URI Class Initialized
INFO - 2016-11-20 15:55:53 --> Router Class Initialized
INFO - 2016-11-20 15:55:53 --> Output Class Initialized
INFO - 2016-11-20 15:55:53 --> Security Class Initialized
DEBUG - 2016-11-20 15:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:55:53 --> Input Class Initialized
INFO - 2016-11-20 15:55:53 --> Language Class Initialized
INFO - 2016-11-20 15:55:53 --> Loader Class Initialized
INFO - 2016-11-20 15:55:53 --> Helper loaded: url_helper
INFO - 2016-11-20 15:55:53 --> Helper loaded: form_helper
INFO - 2016-11-20 15:55:53 --> Database Driver Class Initialized
INFO - 2016-11-20 15:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:55:53 --> Controller Class Initialized
INFO - 2016-11-20 15:55:53 --> Model Class Initialized
INFO - 2016-11-20 15:55:53 --> Model Class Initialized
INFO - 2016-11-20 15:55:53 --> Model Class Initialized
INFO - 2016-11-20 15:55:53 --> Model Class Initialized
INFO - 2016-11-20 15:55:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:55:53 --> Pagination Class Initialized
INFO - 2016-11-20 15:55:53 --> Helper loaded: app_helper
DEBUG - 2016-11-20 15:55:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-20 15:55:53 --> Model Class Initialized
INFO - 2016-11-20 15:55:53 --> Final output sent to browser
DEBUG - 2016-11-20 15:55:53 --> Total execution time: 0.3289
INFO - 2016-11-20 15:55:53 --> Config Class Initialized
INFO - 2016-11-20 15:55:53 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:55:53 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:55:53 --> Utf8 Class Initialized
INFO - 2016-11-20 15:55:53 --> URI Class Initialized
DEBUG - 2016-11-20 15:55:53 --> No URI present. Default controller set.
INFO - 2016-11-20 15:55:53 --> Router Class Initialized
INFO - 2016-11-20 15:55:53 --> Output Class Initialized
INFO - 2016-11-20 15:55:53 --> Security Class Initialized
DEBUG - 2016-11-20 15:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:55:53 --> Input Class Initialized
INFO - 2016-11-20 15:55:53 --> Language Class Initialized
INFO - 2016-11-20 15:55:53 --> Loader Class Initialized
INFO - 2016-11-20 15:55:53 --> Helper loaded: url_helper
INFO - 2016-11-20 15:55:53 --> Helper loaded: form_helper
INFO - 2016-11-20 15:55:53 --> Database Driver Class Initialized
INFO - 2016-11-20 15:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:55:53 --> Controller Class Initialized
INFO - 2016-11-20 15:55:53 --> Model Class Initialized
INFO - 2016-11-20 15:55:53 --> Model Class Initialized
INFO - 2016-11-20 15:55:53 --> Model Class Initialized
INFO - 2016-11-20 15:55:53 --> Model Class Initialized
INFO - 2016-11-20 15:55:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:55:53 --> Pagination Class Initialized
INFO - 2016-11-20 15:55:53 --> Helper loaded: app_helper
INFO - 2016-11-20 15:55:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:55:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 15:55:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 15:55:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 15:55:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 15:55:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 15:55:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 15:55:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 15:55:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 15:55:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 15:55:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 15:55:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 15:55:53 --> Final output sent to browser
DEBUG - 2016-11-20 15:55:53 --> Total execution time: 0.5066
INFO - 2016-11-20 15:58:01 --> Config Class Initialized
INFO - 2016-11-20 15:58:01 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:58:01 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:58:01 --> Utf8 Class Initialized
INFO - 2016-11-20 15:58:01 --> URI Class Initialized
DEBUG - 2016-11-20 15:58:01 --> No URI present. Default controller set.
INFO - 2016-11-20 15:58:01 --> Router Class Initialized
INFO - 2016-11-20 15:58:01 --> Output Class Initialized
INFO - 2016-11-20 15:58:01 --> Security Class Initialized
DEBUG - 2016-11-20 15:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:58:01 --> Input Class Initialized
INFO - 2016-11-20 15:58:01 --> Language Class Initialized
INFO - 2016-11-20 15:58:01 --> Loader Class Initialized
INFO - 2016-11-20 15:58:01 --> Helper loaded: url_helper
INFO - 2016-11-20 15:58:01 --> Helper loaded: form_helper
INFO - 2016-11-20 15:58:01 --> Database Driver Class Initialized
INFO - 2016-11-20 15:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:58:01 --> Controller Class Initialized
INFO - 2016-11-20 15:58:01 --> Model Class Initialized
INFO - 2016-11-20 15:58:01 --> Model Class Initialized
INFO - 2016-11-20 15:58:01 --> Model Class Initialized
INFO - 2016-11-20 15:58:01 --> Model Class Initialized
INFO - 2016-11-20 15:58:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:58:01 --> Pagination Class Initialized
INFO - 2016-11-20 15:58:01 --> Helper loaded: app_helper
INFO - 2016-11-20 15:58:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:58:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 15:58:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 15:58:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 15:58:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 15:58:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 15:58:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 15:58:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 15:58:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 15:58:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 15:58:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 15:58:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 15:58:01 --> Final output sent to browser
DEBUG - 2016-11-20 15:58:01 --> Total execution time: 0.5953
INFO - 2016-11-20 15:59:30 --> Config Class Initialized
INFO - 2016-11-20 15:59:30 --> Hooks Class Initialized
DEBUG - 2016-11-20 15:59:30 --> UTF-8 Support Enabled
INFO - 2016-11-20 15:59:30 --> Utf8 Class Initialized
INFO - 2016-11-20 15:59:30 --> URI Class Initialized
DEBUG - 2016-11-20 15:59:30 --> No URI present. Default controller set.
INFO - 2016-11-20 15:59:30 --> Router Class Initialized
INFO - 2016-11-20 15:59:30 --> Output Class Initialized
INFO - 2016-11-20 15:59:30 --> Security Class Initialized
DEBUG - 2016-11-20 15:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 15:59:30 --> Input Class Initialized
INFO - 2016-11-20 15:59:30 --> Language Class Initialized
INFO - 2016-11-20 15:59:30 --> Loader Class Initialized
INFO - 2016-11-20 15:59:30 --> Helper loaded: url_helper
INFO - 2016-11-20 15:59:30 --> Helper loaded: form_helper
INFO - 2016-11-20 15:59:30 --> Database Driver Class Initialized
INFO - 2016-11-20 15:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 15:59:30 --> Controller Class Initialized
INFO - 2016-11-20 15:59:30 --> Model Class Initialized
INFO - 2016-11-20 15:59:30 --> Model Class Initialized
INFO - 2016-11-20 15:59:30 --> Model Class Initialized
INFO - 2016-11-20 15:59:30 --> Model Class Initialized
INFO - 2016-11-20 15:59:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 15:59:30 --> Pagination Class Initialized
INFO - 2016-11-20 15:59:30 --> Helper loaded: app_helper
INFO - 2016-11-20 15:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 15:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 15:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 15:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 15:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 15:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 15:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 15:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 15:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 15:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 15:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 15:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 15:59:31 --> Final output sent to browser
DEBUG - 2016-11-20 15:59:31 --> Total execution time: 0.6152
INFO - 2016-11-20 16:00:21 --> Config Class Initialized
INFO - 2016-11-20 16:00:21 --> Hooks Class Initialized
DEBUG - 2016-11-20 16:00:21 --> UTF-8 Support Enabled
INFO - 2016-11-20 16:00:21 --> Utf8 Class Initialized
INFO - 2016-11-20 16:00:21 --> URI Class Initialized
INFO - 2016-11-20 16:00:21 --> Router Class Initialized
INFO - 2016-11-20 16:00:21 --> Output Class Initialized
INFO - 2016-11-20 16:00:21 --> Security Class Initialized
DEBUG - 2016-11-20 16:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 16:00:21 --> Input Class Initialized
INFO - 2016-11-20 16:00:21 --> Language Class Initialized
INFO - 2016-11-20 16:00:21 --> Loader Class Initialized
INFO - 2016-11-20 16:00:21 --> Helper loaded: url_helper
INFO - 2016-11-20 16:00:21 --> Helper loaded: form_helper
INFO - 2016-11-20 16:00:21 --> Database Driver Class Initialized
INFO - 2016-11-20 16:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 16:00:22 --> Controller Class Initialized
INFO - 2016-11-20 16:00:22 --> Model Class Initialized
INFO - 2016-11-20 16:00:22 --> Form Validation Class Initialized
ERROR - 2016-11-20 16:00:22 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:22 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:22 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:22 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:22 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:22 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:22 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:22 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:22 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:22 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:22 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:22 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:22 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-11-20 16:00:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 16:00:22 --> Final output sent to browser
DEBUG - 2016-11-20 16:00:22 --> Total execution time: 0.9757
INFO - 2016-11-20 16:00:22 --> Config Class Initialized
INFO - 2016-11-20 16:00:22 --> Hooks Class Initialized
DEBUG - 2016-11-20 16:00:22 --> UTF-8 Support Enabled
INFO - 2016-11-20 16:00:22 --> Utf8 Class Initialized
INFO - 2016-11-20 16:00:22 --> URI Class Initialized
DEBUG - 2016-11-20 16:00:22 --> No URI present. Default controller set.
INFO - 2016-11-20 16:00:22 --> Router Class Initialized
INFO - 2016-11-20 16:00:22 --> Output Class Initialized
INFO - 2016-11-20 16:00:22 --> Security Class Initialized
DEBUG - 2016-11-20 16:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 16:00:22 --> Input Class Initialized
INFO - 2016-11-20 16:00:22 --> Language Class Initialized
INFO - 2016-11-20 16:00:22 --> Loader Class Initialized
INFO - 2016-11-20 16:00:22 --> Helper loaded: url_helper
INFO - 2016-11-20 16:00:22 --> Helper loaded: form_helper
INFO - 2016-11-20 16:00:22 --> Database Driver Class Initialized
INFO - 2016-11-20 16:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 16:00:23 --> Controller Class Initialized
INFO - 2016-11-20 16:00:23 --> Model Class Initialized
INFO - 2016-11-20 16:00:23 --> Model Class Initialized
INFO - 2016-11-20 16:00:23 --> Model Class Initialized
INFO - 2016-11-20 16:00:23 --> Model Class Initialized
INFO - 2016-11-20 16:00:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 16:00:23 --> Pagination Class Initialized
INFO - 2016-11-20 16:00:23 --> Helper loaded: app_helper
INFO - 2016-11-20 16:00:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 16:00:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 16:00:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 16:00:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 16:00:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 16:00:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 16:00:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 16:00:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 16:00:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 16:00:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 16:00:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 16:00:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 16:00:23 --> Final output sent to browser
DEBUG - 2016-11-20 16:00:23 --> Total execution time: 0.5396
INFO - 2016-11-20 16:00:44 --> Config Class Initialized
INFO - 2016-11-20 16:00:44 --> Hooks Class Initialized
DEBUG - 2016-11-20 16:00:44 --> UTF-8 Support Enabled
INFO - 2016-11-20 16:00:44 --> Utf8 Class Initialized
INFO - 2016-11-20 16:00:44 --> URI Class Initialized
INFO - 2016-11-20 16:00:44 --> Router Class Initialized
INFO - 2016-11-20 16:00:44 --> Output Class Initialized
INFO - 2016-11-20 16:00:44 --> Security Class Initialized
DEBUG - 2016-11-20 16:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 16:00:44 --> Input Class Initialized
INFO - 2016-11-20 16:00:44 --> Language Class Initialized
INFO - 2016-11-20 16:00:44 --> Loader Class Initialized
INFO - 2016-11-20 16:00:44 --> Helper loaded: url_helper
INFO - 2016-11-20 16:00:44 --> Helper loaded: form_helper
INFO - 2016-11-20 16:00:44 --> Database Driver Class Initialized
INFO - 2016-11-20 16:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 16:00:44 --> Controller Class Initialized
INFO - 2016-11-20 16:00:44 --> Model Class Initialized
INFO - 2016-11-20 16:00:44 --> Form Validation Class Initialized
ERROR - 2016-11-20 16:00:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 16:00:45 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-11-20 16:00:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 16:00:45 --> Final output sent to browser
DEBUG - 2016-11-20 16:00:45 --> Total execution time: 0.7725
INFO - 2016-11-20 16:00:45 --> Config Class Initialized
INFO - 2016-11-20 16:00:45 --> Hooks Class Initialized
DEBUG - 2016-11-20 16:00:45 --> UTF-8 Support Enabled
INFO - 2016-11-20 16:00:45 --> Utf8 Class Initialized
INFO - 2016-11-20 16:00:45 --> URI Class Initialized
DEBUG - 2016-11-20 16:00:45 --> No URI present. Default controller set.
INFO - 2016-11-20 16:00:45 --> Router Class Initialized
INFO - 2016-11-20 16:00:45 --> Output Class Initialized
INFO - 2016-11-20 16:00:45 --> Security Class Initialized
DEBUG - 2016-11-20 16:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 16:00:45 --> Input Class Initialized
INFO - 2016-11-20 16:00:45 --> Language Class Initialized
INFO - 2016-11-20 16:00:45 --> Loader Class Initialized
INFO - 2016-11-20 16:00:45 --> Helper loaded: url_helper
INFO - 2016-11-20 16:00:45 --> Helper loaded: form_helper
INFO - 2016-11-20 16:00:45 --> Database Driver Class Initialized
INFO - 2016-11-20 16:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 16:00:45 --> Controller Class Initialized
INFO - 2016-11-20 16:00:45 --> Model Class Initialized
INFO - 2016-11-20 16:00:45 --> Model Class Initialized
INFO - 2016-11-20 16:00:45 --> Model Class Initialized
INFO - 2016-11-20 16:00:45 --> Model Class Initialized
INFO - 2016-11-20 16:00:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 16:00:45 --> Pagination Class Initialized
INFO - 2016-11-20 16:00:45 --> Helper loaded: app_helper
INFO - 2016-11-20 16:00:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 16:00:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 16:00:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 16:00:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 16:00:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 16:00:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 16:00:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 16:00:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 16:00:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 16:00:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 16:00:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 16:00:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 16:00:46 --> Final output sent to browser
DEBUG - 2016-11-20 16:00:46 --> Total execution time: 0.5419
INFO - 2016-11-20 16:06:18 --> Config Class Initialized
INFO - 2016-11-20 16:06:18 --> Hooks Class Initialized
DEBUG - 2016-11-20 16:06:18 --> UTF-8 Support Enabled
INFO - 2016-11-20 16:06:18 --> Utf8 Class Initialized
INFO - 2016-11-20 16:06:18 --> URI Class Initialized
DEBUG - 2016-11-20 16:06:18 --> No URI present. Default controller set.
INFO - 2016-11-20 16:06:18 --> Router Class Initialized
INFO - 2016-11-20 16:06:18 --> Output Class Initialized
INFO - 2016-11-20 16:06:18 --> Security Class Initialized
DEBUG - 2016-11-20 16:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 16:06:18 --> Input Class Initialized
INFO - 2016-11-20 16:06:18 --> Language Class Initialized
INFO - 2016-11-20 16:06:18 --> Loader Class Initialized
INFO - 2016-11-20 16:06:18 --> Helper loaded: url_helper
INFO - 2016-11-20 16:06:18 --> Helper loaded: form_helper
INFO - 2016-11-20 16:06:18 --> Database Driver Class Initialized
INFO - 2016-11-20 16:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 16:06:18 --> Controller Class Initialized
INFO - 2016-11-20 16:06:18 --> Model Class Initialized
INFO - 2016-11-20 16:06:18 --> Model Class Initialized
INFO - 2016-11-20 16:06:18 --> Model Class Initialized
INFO - 2016-11-20 16:06:18 --> Model Class Initialized
INFO - 2016-11-20 16:06:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 16:06:18 --> Pagination Class Initialized
INFO - 2016-11-20 16:06:18 --> Helper loaded: app_helper
INFO - 2016-11-20 16:06:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 16:06:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 16:06:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 16:06:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 16:06:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 16:06:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 16:06:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 16:06:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 16:06:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 16:06:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 16:06:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 16:06:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 16:06:18 --> Final output sent to browser
DEBUG - 2016-11-20 16:06:18 --> Total execution time: 0.6306
INFO - 2016-11-20 16:08:31 --> Config Class Initialized
INFO - 2016-11-20 16:08:31 --> Hooks Class Initialized
DEBUG - 2016-11-20 16:08:31 --> UTF-8 Support Enabled
INFO - 2016-11-20 16:08:31 --> Utf8 Class Initialized
INFO - 2016-11-20 16:08:31 --> URI Class Initialized
DEBUG - 2016-11-20 16:08:31 --> No URI present. Default controller set.
INFO - 2016-11-20 16:08:32 --> Router Class Initialized
INFO - 2016-11-20 16:08:32 --> Output Class Initialized
INFO - 2016-11-20 16:08:32 --> Security Class Initialized
DEBUG - 2016-11-20 16:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 16:08:32 --> Input Class Initialized
INFO - 2016-11-20 16:08:32 --> Language Class Initialized
INFO - 2016-11-20 16:08:32 --> Loader Class Initialized
INFO - 2016-11-20 16:08:32 --> Helper loaded: url_helper
INFO - 2016-11-20 16:08:32 --> Helper loaded: form_helper
INFO - 2016-11-20 16:08:32 --> Database Driver Class Initialized
INFO - 2016-11-20 16:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 16:08:32 --> Controller Class Initialized
INFO - 2016-11-20 16:08:32 --> Model Class Initialized
INFO - 2016-11-20 16:08:32 --> Model Class Initialized
INFO - 2016-11-20 16:08:32 --> Model Class Initialized
INFO - 2016-11-20 16:08:32 --> Model Class Initialized
INFO - 2016-11-20 16:08:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 16:08:32 --> Pagination Class Initialized
INFO - 2016-11-20 16:08:32 --> Helper loaded: app_helper
INFO - 2016-11-20 16:08:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 16:08:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 16:08:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 16:08:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 16:08:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 16:08:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 16:08:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 16:08:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 16:08:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 16:08:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 16:08:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 16:08:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 16:08:32 --> Final output sent to browser
DEBUG - 2016-11-20 16:08:32 --> Total execution time: 0.6860
INFO - 2016-11-20 16:08:50 --> Config Class Initialized
INFO - 2016-11-20 16:08:50 --> Hooks Class Initialized
DEBUG - 2016-11-20 16:08:50 --> UTF-8 Support Enabled
INFO - 2016-11-20 16:08:50 --> Utf8 Class Initialized
INFO - 2016-11-20 16:08:50 --> URI Class Initialized
DEBUG - 2016-11-20 16:08:50 --> No URI present. Default controller set.
INFO - 2016-11-20 16:08:50 --> Router Class Initialized
INFO - 2016-11-20 16:08:50 --> Output Class Initialized
INFO - 2016-11-20 16:08:50 --> Security Class Initialized
DEBUG - 2016-11-20 16:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 16:08:50 --> Input Class Initialized
INFO - 2016-11-20 16:08:50 --> Language Class Initialized
INFO - 2016-11-20 16:08:50 --> Loader Class Initialized
INFO - 2016-11-20 16:08:50 --> Helper loaded: url_helper
INFO - 2016-11-20 16:08:50 --> Helper loaded: form_helper
INFO - 2016-11-20 16:08:51 --> Database Driver Class Initialized
INFO - 2016-11-20 16:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 16:08:51 --> Controller Class Initialized
INFO - 2016-11-20 16:08:51 --> Model Class Initialized
INFO - 2016-11-20 16:08:51 --> Model Class Initialized
INFO - 2016-11-20 16:08:51 --> Model Class Initialized
INFO - 2016-11-20 16:08:51 --> Model Class Initialized
INFO - 2016-11-20 16:08:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 16:08:51 --> Pagination Class Initialized
INFO - 2016-11-20 16:08:51 --> Helper loaded: app_helper
INFO - 2016-11-20 16:08:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 16:08:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 16:08:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 16:08:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 16:08:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 16:08:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 16:08:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 16:08:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 16:08:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 16:08:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 16:08:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 16:08:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 16:08:51 --> Final output sent to browser
DEBUG - 2016-11-20 16:08:51 --> Total execution time: 0.6135
INFO - 2016-11-20 16:09:22 --> Config Class Initialized
INFO - 2016-11-20 16:09:22 --> Hooks Class Initialized
DEBUG - 2016-11-20 16:09:22 --> UTF-8 Support Enabled
INFO - 2016-11-20 16:09:22 --> Utf8 Class Initialized
INFO - 2016-11-20 16:09:22 --> URI Class Initialized
DEBUG - 2016-11-20 16:09:22 --> No URI present. Default controller set.
INFO - 2016-11-20 16:09:22 --> Router Class Initialized
INFO - 2016-11-20 16:09:22 --> Output Class Initialized
INFO - 2016-11-20 16:09:22 --> Security Class Initialized
DEBUG - 2016-11-20 16:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 16:09:22 --> Input Class Initialized
INFO - 2016-11-20 16:09:22 --> Language Class Initialized
INFO - 2016-11-20 16:09:22 --> Loader Class Initialized
INFO - 2016-11-20 16:09:22 --> Helper loaded: url_helper
INFO - 2016-11-20 16:09:22 --> Helper loaded: form_helper
INFO - 2016-11-20 16:09:23 --> Database Driver Class Initialized
INFO - 2016-11-20 16:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 16:09:23 --> Controller Class Initialized
INFO - 2016-11-20 16:09:23 --> Model Class Initialized
INFO - 2016-11-20 16:09:23 --> Model Class Initialized
INFO - 2016-11-20 16:09:23 --> Model Class Initialized
INFO - 2016-11-20 16:09:23 --> Model Class Initialized
INFO - 2016-11-20 16:09:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 16:09:23 --> Pagination Class Initialized
INFO - 2016-11-20 16:09:23 --> Helper loaded: app_helper
INFO - 2016-11-20 16:09:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 16:09:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 16:09:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 16:09:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 16:09:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 16:09:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 16:09:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 16:09:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 16:09:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 16:09:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 16:09:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 16:09:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 16:09:23 --> Final output sent to browser
DEBUG - 2016-11-20 16:09:23 --> Total execution time: 0.6174
INFO - 2016-11-20 16:13:24 --> Config Class Initialized
INFO - 2016-11-20 16:13:24 --> Hooks Class Initialized
DEBUG - 2016-11-20 16:13:24 --> UTF-8 Support Enabled
INFO - 2016-11-20 16:13:24 --> Utf8 Class Initialized
INFO - 2016-11-20 16:13:24 --> URI Class Initialized
DEBUG - 2016-11-20 16:13:24 --> No URI present. Default controller set.
INFO - 2016-11-20 16:13:24 --> Router Class Initialized
INFO - 2016-11-20 16:13:24 --> Output Class Initialized
INFO - 2016-11-20 16:13:24 --> Security Class Initialized
DEBUG - 2016-11-20 16:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 16:13:24 --> Input Class Initialized
INFO - 2016-11-20 16:13:24 --> Language Class Initialized
INFO - 2016-11-20 16:13:24 --> Loader Class Initialized
INFO - 2016-11-20 16:13:24 --> Helper loaded: url_helper
INFO - 2016-11-20 16:13:24 --> Helper loaded: form_helper
INFO - 2016-11-20 16:13:24 --> Database Driver Class Initialized
INFO - 2016-11-20 16:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 16:13:24 --> Controller Class Initialized
INFO - 2016-11-20 16:13:24 --> Model Class Initialized
INFO - 2016-11-20 16:13:24 --> Model Class Initialized
INFO - 2016-11-20 16:13:24 --> Model Class Initialized
INFO - 2016-11-20 16:13:24 --> Model Class Initialized
INFO - 2016-11-20 16:13:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 16:13:24 --> Pagination Class Initialized
INFO - 2016-11-20 16:13:24 --> Helper loaded: app_helper
INFO - 2016-11-20 16:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 16:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 16:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 16:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 16:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 16:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 16:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 16:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 16:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 16:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 16:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 16:13:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 16:13:24 --> Final output sent to browser
DEBUG - 2016-11-20 16:13:24 --> Total execution time: 0.6292
INFO - 2016-11-20 16:15:07 --> Config Class Initialized
INFO - 2016-11-20 16:15:07 --> Hooks Class Initialized
DEBUG - 2016-11-20 16:15:07 --> UTF-8 Support Enabled
INFO - 2016-11-20 16:15:07 --> Utf8 Class Initialized
INFO - 2016-11-20 16:15:07 --> URI Class Initialized
DEBUG - 2016-11-20 16:15:07 --> No URI present. Default controller set.
INFO - 2016-11-20 16:15:07 --> Router Class Initialized
INFO - 2016-11-20 16:15:07 --> Output Class Initialized
INFO - 2016-11-20 16:15:07 --> Security Class Initialized
DEBUG - 2016-11-20 16:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 16:15:07 --> Input Class Initialized
INFO - 2016-11-20 16:15:07 --> Language Class Initialized
INFO - 2016-11-20 16:15:07 --> Loader Class Initialized
INFO - 2016-11-20 16:15:07 --> Helper loaded: url_helper
INFO - 2016-11-20 16:15:07 --> Helper loaded: form_helper
INFO - 2016-11-20 16:15:07 --> Database Driver Class Initialized
INFO - 2016-11-20 16:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 16:15:07 --> Controller Class Initialized
INFO - 2016-11-20 16:15:07 --> Model Class Initialized
INFO - 2016-11-20 16:15:07 --> Model Class Initialized
INFO - 2016-11-20 16:15:07 --> Model Class Initialized
INFO - 2016-11-20 16:15:07 --> Model Class Initialized
INFO - 2016-11-20 16:15:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 16:15:08 --> Pagination Class Initialized
INFO - 2016-11-20 16:15:08 --> Helper loaded: app_helper
INFO - 2016-11-20 16:15:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 16:15:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 16:15:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 16:15:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 16:15:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 16:15:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 16:15:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 16:15:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 16:15:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 16:15:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 16:15:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 16:15:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 16:15:08 --> Final output sent to browser
DEBUG - 2016-11-20 16:15:08 --> Total execution time: 0.6139
INFO - 2016-11-20 16:16:54 --> Config Class Initialized
INFO - 2016-11-20 16:16:54 --> Hooks Class Initialized
DEBUG - 2016-11-20 16:16:54 --> UTF-8 Support Enabled
INFO - 2016-11-20 16:16:54 --> Utf8 Class Initialized
INFO - 2016-11-20 16:16:54 --> URI Class Initialized
DEBUG - 2016-11-20 16:16:54 --> No URI present. Default controller set.
INFO - 2016-11-20 16:16:54 --> Router Class Initialized
INFO - 2016-11-20 16:16:54 --> Output Class Initialized
INFO - 2016-11-20 16:16:54 --> Security Class Initialized
DEBUG - 2016-11-20 16:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 16:16:54 --> Input Class Initialized
INFO - 2016-11-20 16:16:54 --> Language Class Initialized
INFO - 2016-11-20 16:16:54 --> Loader Class Initialized
INFO - 2016-11-20 16:16:54 --> Helper loaded: url_helper
INFO - 2016-11-20 16:16:54 --> Helper loaded: form_helper
INFO - 2016-11-20 16:16:54 --> Database Driver Class Initialized
INFO - 2016-11-20 16:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 16:16:54 --> Controller Class Initialized
INFO - 2016-11-20 16:16:54 --> Model Class Initialized
INFO - 2016-11-20 16:16:54 --> Model Class Initialized
INFO - 2016-11-20 16:16:54 --> Model Class Initialized
INFO - 2016-11-20 16:16:54 --> Model Class Initialized
INFO - 2016-11-20 16:16:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 16:16:54 --> Pagination Class Initialized
INFO - 2016-11-20 16:16:54 --> Helper loaded: app_helper
INFO - 2016-11-20 16:16:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 16:16:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 16:16:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 16:16:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 16:16:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 16:16:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 16:16:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 16:16:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 16:16:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 16:16:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 16:16:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 16:16:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 16:16:54 --> Final output sent to browser
DEBUG - 2016-11-20 16:16:54 --> Total execution time: 0.6149
INFO - 2016-11-20 16:17:51 --> Config Class Initialized
INFO - 2016-11-20 16:17:51 --> Hooks Class Initialized
DEBUG - 2016-11-20 16:17:51 --> UTF-8 Support Enabled
INFO - 2016-11-20 16:17:51 --> Utf8 Class Initialized
INFO - 2016-11-20 16:17:52 --> URI Class Initialized
DEBUG - 2016-11-20 16:17:52 --> No URI present. Default controller set.
INFO - 2016-11-20 16:17:52 --> Router Class Initialized
INFO - 2016-11-20 16:17:52 --> Output Class Initialized
INFO - 2016-11-20 16:17:52 --> Security Class Initialized
DEBUG - 2016-11-20 16:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 16:17:52 --> Input Class Initialized
INFO - 2016-11-20 16:17:52 --> Language Class Initialized
INFO - 2016-11-20 16:17:52 --> Loader Class Initialized
INFO - 2016-11-20 16:17:52 --> Helper loaded: url_helper
INFO - 2016-11-20 16:17:52 --> Helper loaded: form_helper
INFO - 2016-11-20 16:17:52 --> Database Driver Class Initialized
INFO - 2016-11-20 16:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 16:17:52 --> Controller Class Initialized
INFO - 2016-11-20 16:17:52 --> Model Class Initialized
INFO - 2016-11-20 16:17:52 --> Model Class Initialized
INFO - 2016-11-20 16:17:52 --> Model Class Initialized
INFO - 2016-11-20 16:17:52 --> Model Class Initialized
INFO - 2016-11-20 16:17:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 16:17:52 --> Pagination Class Initialized
INFO - 2016-11-20 16:17:52 --> Helper loaded: app_helper
INFO - 2016-11-20 16:17:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 16:17:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 16:17:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 16:17:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 16:17:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 16:17:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 16:17:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 16:17:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 16:17:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 16:17:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 16:17:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 16:17:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 16:17:52 --> Final output sent to browser
DEBUG - 2016-11-20 16:17:52 --> Total execution time: 0.6244
INFO - 2016-11-20 16:18:36 --> Config Class Initialized
INFO - 2016-11-20 16:18:36 --> Hooks Class Initialized
DEBUG - 2016-11-20 16:18:36 --> UTF-8 Support Enabled
INFO - 2016-11-20 16:18:36 --> Utf8 Class Initialized
INFO - 2016-11-20 16:18:36 --> URI Class Initialized
DEBUG - 2016-11-20 16:18:36 --> No URI present. Default controller set.
INFO - 2016-11-20 16:18:36 --> Router Class Initialized
INFO - 2016-11-20 16:18:36 --> Output Class Initialized
INFO - 2016-11-20 16:18:36 --> Security Class Initialized
DEBUG - 2016-11-20 16:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 16:18:36 --> Input Class Initialized
INFO - 2016-11-20 16:18:36 --> Language Class Initialized
INFO - 2016-11-20 16:18:36 --> Loader Class Initialized
INFO - 2016-11-20 16:18:37 --> Helper loaded: url_helper
INFO - 2016-11-20 16:18:37 --> Helper loaded: form_helper
INFO - 2016-11-20 16:18:37 --> Database Driver Class Initialized
INFO - 2016-11-20 16:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 16:18:37 --> Controller Class Initialized
INFO - 2016-11-20 16:18:37 --> Model Class Initialized
INFO - 2016-11-20 16:18:37 --> Model Class Initialized
INFO - 2016-11-20 16:18:37 --> Model Class Initialized
INFO - 2016-11-20 16:18:37 --> Model Class Initialized
INFO - 2016-11-20 16:18:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 16:18:37 --> Pagination Class Initialized
INFO - 2016-11-20 16:18:37 --> Helper loaded: app_helper
INFO - 2016-11-20 16:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 16:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 16:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 16:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 16:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 16:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 16:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 16:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 16:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 16:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 16:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 16:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 16:18:37 --> Final output sent to browser
DEBUG - 2016-11-20 16:18:37 --> Total execution time: 0.8910
INFO - 2016-11-20 16:21:26 --> Config Class Initialized
INFO - 2016-11-20 16:21:26 --> Hooks Class Initialized
DEBUG - 2016-11-20 16:21:26 --> UTF-8 Support Enabled
INFO - 2016-11-20 16:21:26 --> Utf8 Class Initialized
INFO - 2016-11-20 16:21:26 --> URI Class Initialized
INFO - 2016-11-20 16:21:26 --> Router Class Initialized
INFO - 2016-11-20 16:21:26 --> Output Class Initialized
INFO - 2016-11-20 16:21:26 --> Security Class Initialized
DEBUG - 2016-11-20 16:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 16:21:26 --> Input Class Initialized
INFO - 2016-11-20 16:21:26 --> Language Class Initialized
INFO - 2016-11-20 16:21:26 --> Loader Class Initialized
INFO - 2016-11-20 16:21:26 --> Helper loaded: url_helper
INFO - 2016-11-20 16:21:26 --> Helper loaded: form_helper
INFO - 2016-11-20 16:21:26 --> Database Driver Class Initialized
INFO - 2016-11-20 16:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 16:21:26 --> Controller Class Initialized
INFO - 2016-11-20 16:21:26 --> Model Class Initialized
INFO - 2016-11-20 16:21:26 --> Model Class Initialized
INFO - 2016-11-20 16:21:26 --> Model Class Initialized
INFO - 2016-11-20 16:21:26 --> Model Class Initialized
INFO - 2016-11-20 16:21:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 16:21:27 --> Pagination Class Initialized
INFO - 2016-11-20 16:21:27 --> Helper loaded: app_helper
DEBUG - 2016-11-20 16:21:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-20 16:21:27 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 180
ERROR - 2016-11-20 16:21:27 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 180
INFO - 2016-11-20 16:21:27 --> Config Class Initialized
INFO - 2016-11-20 16:21:27 --> Hooks Class Initialized
DEBUG - 2016-11-20 16:21:27 --> UTF-8 Support Enabled
INFO - 2016-11-20 16:21:27 --> Utf8 Class Initialized
INFO - 2016-11-20 16:21:27 --> URI Class Initialized
DEBUG - 2016-11-20 16:21:27 --> No URI present. Default controller set.
INFO - 2016-11-20 16:21:27 --> Router Class Initialized
INFO - 2016-11-20 16:21:27 --> Output Class Initialized
INFO - 2016-11-20 16:21:27 --> Security Class Initialized
DEBUG - 2016-11-20 16:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 16:21:27 --> Input Class Initialized
INFO - 2016-11-20 16:21:27 --> Language Class Initialized
INFO - 2016-11-20 16:21:27 --> Loader Class Initialized
INFO - 2016-11-20 16:21:27 --> Helper loaded: url_helper
INFO - 2016-11-20 16:21:27 --> Helper loaded: form_helper
INFO - 2016-11-20 16:21:27 --> Database Driver Class Initialized
INFO - 2016-11-20 16:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 16:21:27 --> Controller Class Initialized
INFO - 2016-11-20 16:21:27 --> Model Class Initialized
INFO - 2016-11-20 16:21:27 --> Model Class Initialized
INFO - 2016-11-20 16:21:27 --> Model Class Initialized
INFO - 2016-11-20 16:21:27 --> Model Class Initialized
INFO - 2016-11-20 16:21:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 16:21:27 --> Pagination Class Initialized
INFO - 2016-11-20 16:21:27 --> Helper loaded: app_helper
INFO - 2016-11-20 16:21:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 16:21:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-20 16:21:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 16:21:27 --> Final output sent to browser
DEBUG - 2016-11-20 16:21:27 --> Total execution time: 0.4499
INFO - 2016-11-20 16:21:35 --> Config Class Initialized
INFO - 2016-11-20 16:21:35 --> Hooks Class Initialized
DEBUG - 2016-11-20 16:21:35 --> UTF-8 Support Enabled
INFO - 2016-11-20 16:21:35 --> Utf8 Class Initialized
INFO - 2016-11-20 16:21:35 --> URI Class Initialized
INFO - 2016-11-20 16:21:35 --> Router Class Initialized
INFO - 2016-11-20 16:21:35 --> Output Class Initialized
INFO - 2016-11-20 16:21:35 --> Security Class Initialized
DEBUG - 2016-11-20 16:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 16:21:35 --> Input Class Initialized
INFO - 2016-11-20 16:21:35 --> Language Class Initialized
INFO - 2016-11-20 16:21:35 --> Loader Class Initialized
INFO - 2016-11-20 16:21:35 --> Helper loaded: url_helper
INFO - 2016-11-20 16:21:35 --> Helper loaded: form_helper
INFO - 2016-11-20 16:21:35 --> Database Driver Class Initialized
INFO - 2016-11-20 16:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 16:21:35 --> Controller Class Initialized
INFO - 2016-11-20 16:21:35 --> Model Class Initialized
INFO - 2016-11-20 16:21:36 --> Model Class Initialized
INFO - 2016-11-20 16:21:36 --> Model Class Initialized
INFO - 2016-11-20 16:21:36 --> Model Class Initialized
INFO - 2016-11-20 16:21:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 16:21:36 --> Pagination Class Initialized
INFO - 2016-11-20 16:21:36 --> Helper loaded: app_helper
DEBUG - 2016-11-20 16:21:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-20 16:21:36 --> Model Class Initialized
INFO - 2016-11-20 16:21:36 --> Final output sent to browser
DEBUG - 2016-11-20 16:21:36 --> Total execution time: 0.3444
INFO - 2016-11-20 16:21:36 --> Config Class Initialized
INFO - 2016-11-20 16:21:36 --> Hooks Class Initialized
DEBUG - 2016-11-20 16:21:36 --> UTF-8 Support Enabled
INFO - 2016-11-20 16:21:36 --> Utf8 Class Initialized
INFO - 2016-11-20 16:21:36 --> URI Class Initialized
DEBUG - 2016-11-20 16:21:36 --> No URI present. Default controller set.
INFO - 2016-11-20 16:21:36 --> Router Class Initialized
INFO - 2016-11-20 16:21:36 --> Output Class Initialized
INFO - 2016-11-20 16:21:36 --> Security Class Initialized
DEBUG - 2016-11-20 16:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 16:21:36 --> Input Class Initialized
INFO - 2016-11-20 16:21:36 --> Language Class Initialized
INFO - 2016-11-20 16:21:36 --> Loader Class Initialized
INFO - 2016-11-20 16:21:36 --> Helper loaded: url_helper
INFO - 2016-11-20 16:21:36 --> Helper loaded: form_helper
INFO - 2016-11-20 16:21:36 --> Database Driver Class Initialized
INFO - 2016-11-20 16:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 16:21:36 --> Controller Class Initialized
INFO - 2016-11-20 16:21:36 --> Model Class Initialized
INFO - 2016-11-20 16:21:36 --> Model Class Initialized
INFO - 2016-11-20 16:21:36 --> Model Class Initialized
INFO - 2016-11-20 16:21:36 --> Model Class Initialized
INFO - 2016-11-20 16:21:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 16:21:36 --> Pagination Class Initialized
INFO - 2016-11-20 16:21:36 --> Helper loaded: app_helper
INFO - 2016-11-20 16:21:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 16:21:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 16:21:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 16:21:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 16:21:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 16:21:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 16:21:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 16:21:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 16:21:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 16:21:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 16:21:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 16:21:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 16:21:36 --> Final output sent to browser
DEBUG - 2016-11-20 16:21:36 --> Total execution time: 0.5412
INFO - 2016-11-20 16:22:18 --> Config Class Initialized
INFO - 2016-11-20 16:22:18 --> Hooks Class Initialized
DEBUG - 2016-11-20 16:22:18 --> UTF-8 Support Enabled
INFO - 2016-11-20 16:22:18 --> Utf8 Class Initialized
INFO - 2016-11-20 16:22:18 --> URI Class Initialized
DEBUG - 2016-11-20 16:22:18 --> No URI present. Default controller set.
INFO - 2016-11-20 16:22:19 --> Router Class Initialized
INFO - 2016-11-20 16:22:19 --> Output Class Initialized
INFO - 2016-11-20 16:22:19 --> Security Class Initialized
DEBUG - 2016-11-20 16:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 16:22:19 --> Input Class Initialized
INFO - 2016-11-20 16:22:19 --> Language Class Initialized
INFO - 2016-11-20 16:22:19 --> Loader Class Initialized
INFO - 2016-11-20 16:22:19 --> Helper loaded: url_helper
INFO - 2016-11-20 16:22:19 --> Helper loaded: form_helper
INFO - 2016-11-20 16:22:19 --> Database Driver Class Initialized
INFO - 2016-11-20 16:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 16:22:19 --> Controller Class Initialized
INFO - 2016-11-20 16:22:19 --> Model Class Initialized
INFO - 2016-11-20 16:22:19 --> Model Class Initialized
INFO - 2016-11-20 16:22:19 --> Model Class Initialized
INFO - 2016-11-20 16:22:19 --> Model Class Initialized
INFO - 2016-11-20 16:22:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 16:22:19 --> Pagination Class Initialized
INFO - 2016-11-20 16:22:19 --> Helper loaded: app_helper
INFO - 2016-11-20 16:22:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 16:22:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 16:22:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 16:22:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 16:22:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 16:22:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 16:22:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 16:22:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 16:22:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 16:22:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 16:22:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 16:22:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 16:22:19 --> Final output sent to browser
DEBUG - 2016-11-20 16:22:19 --> Total execution time: 0.6742
INFO - 2016-11-20 16:23:34 --> Config Class Initialized
INFO - 2016-11-20 16:23:34 --> Hooks Class Initialized
DEBUG - 2016-11-20 16:23:34 --> UTF-8 Support Enabled
INFO - 2016-11-20 16:23:35 --> Utf8 Class Initialized
INFO - 2016-11-20 16:23:35 --> URI Class Initialized
INFO - 2016-11-20 16:23:35 --> Router Class Initialized
INFO - 2016-11-20 16:23:35 --> Output Class Initialized
INFO - 2016-11-20 16:23:35 --> Security Class Initialized
DEBUG - 2016-11-20 16:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 16:23:35 --> Input Class Initialized
INFO - 2016-11-20 16:23:35 --> Language Class Initialized
INFO - 2016-11-20 16:23:35 --> Loader Class Initialized
INFO - 2016-11-20 16:23:35 --> Helper loaded: url_helper
INFO - 2016-11-20 16:23:35 --> Helper loaded: form_helper
INFO - 2016-11-20 16:23:35 --> Database Driver Class Initialized
INFO - 2016-11-20 16:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 16:23:35 --> Controller Class Initialized
INFO - 2016-11-20 16:23:35 --> Model Class Initialized
INFO - 2016-11-20 16:23:35 --> Model Class Initialized
INFO - 2016-11-20 16:23:35 --> Model Class Initialized
INFO - 2016-11-20 16:23:35 --> Model Class Initialized
INFO - 2016-11-20 16:23:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 16:23:35 --> Pagination Class Initialized
INFO - 2016-11-20 16:23:35 --> Helper loaded: app_helper
DEBUG - 2016-11-20 16:23:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-20 16:23:35 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 180
ERROR - 2016-11-20 16:23:35 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 180
INFO - 2016-11-20 16:23:35 --> Config Class Initialized
INFO - 2016-11-20 16:23:35 --> Hooks Class Initialized
DEBUG - 2016-11-20 16:23:35 --> UTF-8 Support Enabled
INFO - 2016-11-20 16:23:35 --> Utf8 Class Initialized
INFO - 2016-11-20 16:23:35 --> URI Class Initialized
DEBUG - 2016-11-20 16:23:35 --> No URI present. Default controller set.
INFO - 2016-11-20 16:23:35 --> Router Class Initialized
INFO - 2016-11-20 16:23:35 --> Output Class Initialized
INFO - 2016-11-20 16:23:35 --> Security Class Initialized
DEBUG - 2016-11-20 16:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 16:23:35 --> Input Class Initialized
INFO - 2016-11-20 16:23:35 --> Language Class Initialized
INFO - 2016-11-20 16:23:35 --> Loader Class Initialized
INFO - 2016-11-20 16:23:35 --> Helper loaded: url_helper
INFO - 2016-11-20 16:23:35 --> Helper loaded: form_helper
INFO - 2016-11-20 16:23:35 --> Database Driver Class Initialized
INFO - 2016-11-20 16:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 16:23:35 --> Controller Class Initialized
INFO - 2016-11-20 16:23:35 --> Model Class Initialized
INFO - 2016-11-20 16:23:35 --> Model Class Initialized
INFO - 2016-11-20 16:23:35 --> Model Class Initialized
INFO - 2016-11-20 16:23:35 --> Model Class Initialized
INFO - 2016-11-20 16:23:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 16:23:35 --> Pagination Class Initialized
INFO - 2016-11-20 16:23:35 --> Helper loaded: app_helper
INFO - 2016-11-20 16:23:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 16:23:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-20 16:23:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 16:23:35 --> Final output sent to browser
DEBUG - 2016-11-20 16:23:35 --> Total execution time: 0.4646
INFO - 2016-11-20 16:23:57 --> Config Class Initialized
INFO - 2016-11-20 16:23:57 --> Hooks Class Initialized
DEBUG - 2016-11-20 16:23:57 --> UTF-8 Support Enabled
INFO - 2016-11-20 16:23:57 --> Utf8 Class Initialized
INFO - 2016-11-20 16:23:57 --> URI Class Initialized
INFO - 2016-11-20 16:23:57 --> Router Class Initialized
INFO - 2016-11-20 16:23:57 --> Output Class Initialized
INFO - 2016-11-20 16:23:57 --> Security Class Initialized
DEBUG - 2016-11-20 16:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 16:23:57 --> Input Class Initialized
INFO - 2016-11-20 16:23:57 --> Language Class Initialized
INFO - 2016-11-20 16:23:57 --> Loader Class Initialized
INFO - 2016-11-20 16:23:57 --> Helper loaded: url_helper
INFO - 2016-11-20 16:23:57 --> Helper loaded: form_helper
INFO - 2016-11-20 16:23:57 --> Database Driver Class Initialized
INFO - 2016-11-20 16:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 16:23:57 --> Controller Class Initialized
INFO - 2016-11-20 16:23:57 --> Model Class Initialized
INFO - 2016-11-20 16:23:57 --> Model Class Initialized
INFO - 2016-11-20 16:23:57 --> Model Class Initialized
INFO - 2016-11-20 16:23:57 --> Model Class Initialized
INFO - 2016-11-20 16:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 16:23:57 --> Pagination Class Initialized
INFO - 2016-11-20 16:23:57 --> Helper loaded: app_helper
DEBUG - 2016-11-20 16:23:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-20 16:23:57 --> Model Class Initialized
INFO - 2016-11-20 16:23:57 --> Final output sent to browser
DEBUG - 2016-11-20 16:23:57 --> Total execution time: 0.3458
INFO - 2016-11-20 16:23:57 --> Config Class Initialized
INFO - 2016-11-20 16:23:57 --> Hooks Class Initialized
DEBUG - 2016-11-20 16:23:57 --> UTF-8 Support Enabled
INFO - 2016-11-20 16:23:57 --> Utf8 Class Initialized
INFO - 2016-11-20 16:23:57 --> URI Class Initialized
DEBUG - 2016-11-20 16:23:57 --> No URI present. Default controller set.
INFO - 2016-11-20 16:23:57 --> Router Class Initialized
INFO - 2016-11-20 16:23:57 --> Output Class Initialized
INFO - 2016-11-20 16:23:57 --> Security Class Initialized
DEBUG - 2016-11-20 16:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 16:23:57 --> Input Class Initialized
INFO - 2016-11-20 16:23:57 --> Language Class Initialized
INFO - 2016-11-20 16:23:57 --> Loader Class Initialized
INFO - 2016-11-20 16:23:57 --> Helper loaded: url_helper
INFO - 2016-11-20 16:23:57 --> Helper loaded: form_helper
INFO - 2016-11-20 16:23:57 --> Database Driver Class Initialized
INFO - 2016-11-20 16:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 16:23:57 --> Controller Class Initialized
INFO - 2016-11-20 16:23:57 --> Model Class Initialized
INFO - 2016-11-20 16:23:57 --> Model Class Initialized
INFO - 2016-11-20 16:23:57 --> Model Class Initialized
INFO - 2016-11-20 16:23:57 --> Model Class Initialized
INFO - 2016-11-20 16:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 16:23:57 --> Pagination Class Initialized
INFO - 2016-11-20 16:23:57 --> Helper loaded: app_helper
INFO - 2016-11-20 16:23:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 16:23:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 16:23:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 16:23:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 16:23:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 16:23:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 16:23:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 16:23:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 16:23:58 --> Final output sent to browser
DEBUG - 2016-11-20 16:23:58 --> Total execution time: 0.4949
INFO - 2016-11-20 16:43:51 --> Config Class Initialized
INFO - 2016-11-20 16:43:52 --> Hooks Class Initialized
DEBUG - 2016-11-20 16:43:52 --> UTF-8 Support Enabled
INFO - 2016-11-20 16:43:52 --> Utf8 Class Initialized
INFO - 2016-11-20 16:43:52 --> URI Class Initialized
INFO - 2016-11-20 16:43:52 --> Router Class Initialized
INFO - 2016-11-20 16:43:52 --> Output Class Initialized
INFO - 2016-11-20 16:43:52 --> Security Class Initialized
DEBUG - 2016-11-20 16:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 16:43:52 --> Input Class Initialized
INFO - 2016-11-20 16:43:52 --> Language Class Initialized
INFO - 2016-11-20 16:43:52 --> Loader Class Initialized
INFO - 2016-11-20 16:43:52 --> Helper loaded: url_helper
INFO - 2016-11-20 16:43:52 --> Helper loaded: form_helper
INFO - 2016-11-20 16:43:52 --> Database Driver Class Initialized
INFO - 2016-11-20 16:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 16:43:52 --> Controller Class Initialized
INFO - 2016-11-20 16:43:52 --> Model Class Initialized
INFO - 2016-11-20 16:43:52 --> Form Validation Class Initialized
INFO - 2016-11-20 16:43:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-20 16:43:52 --> Final output sent to browser
DEBUG - 2016-11-20 16:43:52 --> Total execution time: 0.4970
INFO - 2016-11-20 16:44:01 --> Config Class Initialized
INFO - 2016-11-20 16:44:01 --> Hooks Class Initialized
DEBUG - 2016-11-20 16:44:01 --> UTF-8 Support Enabled
INFO - 2016-11-20 16:44:01 --> Utf8 Class Initialized
INFO - 2016-11-20 16:44:01 --> URI Class Initialized
INFO - 2016-11-20 16:44:01 --> Router Class Initialized
INFO - 2016-11-20 16:44:01 --> Output Class Initialized
INFO - 2016-11-20 16:44:01 --> Security Class Initialized
DEBUG - 2016-11-20 16:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 16:44:01 --> Input Class Initialized
INFO - 2016-11-20 16:44:01 --> Language Class Initialized
INFO - 2016-11-20 16:44:01 --> Loader Class Initialized
INFO - 2016-11-20 16:44:01 --> Helper loaded: url_helper
INFO - 2016-11-20 16:44:01 --> Helper loaded: form_helper
INFO - 2016-11-20 16:44:01 --> Database Driver Class Initialized
INFO - 2016-11-20 16:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 16:44:01 --> Controller Class Initialized
INFO - 2016-11-20 16:44:01 --> Model Class Initialized
INFO - 2016-11-20 16:44:01 --> Model Class Initialized
INFO - 2016-11-20 16:44:01 --> Model Class Initialized
INFO - 2016-11-20 16:44:01 --> Model Class Initialized
INFO - 2016-11-20 16:44:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 16:44:01 --> Pagination Class Initialized
INFO - 2016-11-20 16:44:01 --> Helper loaded: app_helper
DEBUG - 2016-11-20 16:44:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-20 16:44:01 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 180
ERROR - 2016-11-20 16:44:01 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 180
INFO - 2016-11-20 16:44:01 --> Config Class Initialized
INFO - 2016-11-20 16:44:01 --> Hooks Class Initialized
DEBUG - 2016-11-20 16:44:01 --> UTF-8 Support Enabled
INFO - 2016-11-20 16:44:01 --> Utf8 Class Initialized
INFO - 2016-11-20 16:44:01 --> URI Class Initialized
DEBUG - 2016-11-20 16:44:01 --> No URI present. Default controller set.
INFO - 2016-11-20 16:44:01 --> Router Class Initialized
INFO - 2016-11-20 16:44:01 --> Output Class Initialized
INFO - 2016-11-20 16:44:01 --> Security Class Initialized
DEBUG - 2016-11-20 16:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 16:44:01 --> Input Class Initialized
INFO - 2016-11-20 16:44:01 --> Language Class Initialized
INFO - 2016-11-20 16:44:01 --> Loader Class Initialized
INFO - 2016-11-20 16:44:01 --> Helper loaded: url_helper
INFO - 2016-11-20 16:44:01 --> Helper loaded: form_helper
INFO - 2016-11-20 16:44:01 --> Database Driver Class Initialized
INFO - 2016-11-20 16:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 16:44:01 --> Controller Class Initialized
INFO - 2016-11-20 16:44:01 --> Model Class Initialized
INFO - 2016-11-20 16:44:01 --> Model Class Initialized
INFO - 2016-11-20 16:44:02 --> Model Class Initialized
INFO - 2016-11-20 16:44:02 --> Model Class Initialized
INFO - 2016-11-20 16:44:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 16:44:02 --> Pagination Class Initialized
INFO - 2016-11-20 16:44:02 --> Helper loaded: app_helper
INFO - 2016-11-20 16:44:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 16:44:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-20 16:44:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 16:44:02 --> Final output sent to browser
DEBUG - 2016-11-20 16:44:02 --> Total execution time: 0.4278
INFO - 2016-11-20 22:04:59 --> Config Class Initialized
INFO - 2016-11-20 22:04:59 --> Hooks Class Initialized
DEBUG - 2016-11-20 22:05:00 --> UTF-8 Support Enabled
INFO - 2016-11-20 22:05:00 --> Utf8 Class Initialized
INFO - 2016-11-20 22:05:00 --> URI Class Initialized
DEBUG - 2016-11-20 22:05:00 --> No URI present. Default controller set.
INFO - 2016-11-20 22:05:00 --> Router Class Initialized
INFO - 2016-11-20 22:05:00 --> Output Class Initialized
INFO - 2016-11-20 22:05:00 --> Security Class Initialized
DEBUG - 2016-11-20 22:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 22:05:00 --> Input Class Initialized
INFO - 2016-11-20 22:05:00 --> Language Class Initialized
INFO - 2016-11-20 22:05:00 --> Loader Class Initialized
INFO - 2016-11-20 22:05:00 --> Helper loaded: url_helper
INFO - 2016-11-20 22:05:00 --> Helper loaded: form_helper
INFO - 2016-11-20 22:05:00 --> Database Driver Class Initialized
INFO - 2016-11-20 22:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 22:05:01 --> Controller Class Initialized
INFO - 2016-11-20 22:05:01 --> Model Class Initialized
INFO - 2016-11-20 22:05:01 --> Model Class Initialized
INFO - 2016-11-20 22:05:01 --> Model Class Initialized
INFO - 2016-11-20 22:05:01 --> Model Class Initialized
INFO - 2016-11-20 22:05:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 22:05:01 --> Pagination Class Initialized
INFO - 2016-11-20 22:05:01 --> Helper loaded: app_helper
INFO - 2016-11-20 22:05:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 22:05:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-20 22:05:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 22:05:01 --> Final output sent to browser
DEBUG - 2016-11-20 22:05:01 --> Total execution time: 1.5676
INFO - 2016-11-20 22:05:15 --> Config Class Initialized
INFO - 2016-11-20 22:05:15 --> Hooks Class Initialized
DEBUG - 2016-11-20 22:05:15 --> UTF-8 Support Enabled
INFO - 2016-11-20 22:05:15 --> Utf8 Class Initialized
INFO - 2016-11-20 22:05:15 --> URI Class Initialized
INFO - 2016-11-20 22:05:15 --> Router Class Initialized
INFO - 2016-11-20 22:05:15 --> Output Class Initialized
INFO - 2016-11-20 22:05:15 --> Security Class Initialized
DEBUG - 2016-11-20 22:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 22:05:15 --> Input Class Initialized
INFO - 2016-11-20 22:05:15 --> Language Class Initialized
INFO - 2016-11-20 22:05:15 --> Loader Class Initialized
INFO - 2016-11-20 22:05:15 --> Helper loaded: url_helper
INFO - 2016-11-20 22:05:15 --> Helper loaded: form_helper
INFO - 2016-11-20 22:05:15 --> Database Driver Class Initialized
INFO - 2016-11-20 22:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 22:05:15 --> Controller Class Initialized
INFO - 2016-11-20 22:05:15 --> Model Class Initialized
INFO - 2016-11-20 22:05:15 --> Model Class Initialized
INFO - 2016-11-20 22:05:15 --> Model Class Initialized
INFO - 2016-11-20 22:05:15 --> Model Class Initialized
INFO - 2016-11-20 22:05:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 22:05:15 --> Pagination Class Initialized
INFO - 2016-11-20 22:05:15 --> Helper loaded: app_helper
DEBUG - 2016-11-20 22:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-20 22:05:15 --> Model Class Initialized
INFO - 2016-11-20 22:05:16 --> Final output sent to browser
DEBUG - 2016-11-20 22:05:16 --> Total execution time: 0.6434
INFO - 2016-11-20 22:05:16 --> Config Class Initialized
INFO - 2016-11-20 22:05:16 --> Hooks Class Initialized
DEBUG - 2016-11-20 22:05:16 --> UTF-8 Support Enabled
INFO - 2016-11-20 22:05:16 --> Utf8 Class Initialized
INFO - 2016-11-20 22:05:16 --> URI Class Initialized
DEBUG - 2016-11-20 22:05:16 --> No URI present. Default controller set.
INFO - 2016-11-20 22:05:16 --> Router Class Initialized
INFO - 2016-11-20 22:05:16 --> Output Class Initialized
INFO - 2016-11-20 22:05:16 --> Security Class Initialized
DEBUG - 2016-11-20 22:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 22:05:16 --> Input Class Initialized
INFO - 2016-11-20 22:05:16 --> Language Class Initialized
INFO - 2016-11-20 22:05:16 --> Loader Class Initialized
INFO - 2016-11-20 22:05:16 --> Helper loaded: url_helper
INFO - 2016-11-20 22:05:16 --> Helper loaded: form_helper
INFO - 2016-11-20 22:05:16 --> Database Driver Class Initialized
INFO - 2016-11-20 22:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 22:05:16 --> Controller Class Initialized
INFO - 2016-11-20 22:05:16 --> Model Class Initialized
INFO - 2016-11-20 22:05:16 --> Model Class Initialized
INFO - 2016-11-20 22:05:16 --> Model Class Initialized
INFO - 2016-11-20 22:05:16 --> Model Class Initialized
INFO - 2016-11-20 22:05:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 22:05:16 --> Pagination Class Initialized
INFO - 2016-11-20 22:05:16 --> Helper loaded: app_helper
INFO - 2016-11-20 22:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 22:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 22:05:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 22:05:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 22:05:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 22:05:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 22:05:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 22:05:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 22:05:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 22:05:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 22:05:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 22:05:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 22:05:17 --> Final output sent to browser
DEBUG - 2016-11-20 22:05:17 --> Total execution time: 1.4174
INFO - 2016-11-20 22:06:07 --> Config Class Initialized
INFO - 2016-11-20 22:06:07 --> Hooks Class Initialized
DEBUG - 2016-11-20 22:06:07 --> UTF-8 Support Enabled
INFO - 2016-11-20 22:06:07 --> Utf8 Class Initialized
INFO - 2016-11-20 22:06:07 --> URI Class Initialized
INFO - 2016-11-20 22:06:07 --> Router Class Initialized
INFO - 2016-11-20 22:06:07 --> Output Class Initialized
INFO - 2016-11-20 22:06:07 --> Security Class Initialized
DEBUG - 2016-11-20 22:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 22:06:07 --> Input Class Initialized
INFO - 2016-11-20 22:06:07 --> Language Class Initialized
INFO - 2016-11-20 22:06:07 --> Loader Class Initialized
INFO - 2016-11-20 22:06:07 --> Helper loaded: url_helper
INFO - 2016-11-20 22:06:07 --> Helper loaded: form_helper
INFO - 2016-11-20 22:06:07 --> Database Driver Class Initialized
INFO - 2016-11-20 22:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 22:06:07 --> Controller Class Initialized
INFO - 2016-11-20 22:06:07 --> Model Class Initialized
INFO - 2016-11-20 22:06:07 --> Form Validation Class Initialized
INFO - 2016-11-20 22:06:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-20 22:06:07 --> Final output sent to browser
DEBUG - 2016-11-20 22:06:07 --> Total execution time: 0.3871
INFO - 2016-11-20 22:06:31 --> Config Class Initialized
INFO - 2016-11-20 22:06:31 --> Hooks Class Initialized
DEBUG - 2016-11-20 22:06:31 --> UTF-8 Support Enabled
INFO - 2016-11-20 22:06:31 --> Utf8 Class Initialized
INFO - 2016-11-20 22:06:31 --> URI Class Initialized
INFO - 2016-11-20 22:06:31 --> Router Class Initialized
INFO - 2016-11-20 22:06:31 --> Output Class Initialized
INFO - 2016-11-20 22:06:31 --> Security Class Initialized
DEBUG - 2016-11-20 22:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 22:06:31 --> Input Class Initialized
INFO - 2016-11-20 22:06:31 --> Language Class Initialized
INFO - 2016-11-20 22:06:31 --> Loader Class Initialized
INFO - 2016-11-20 22:06:31 --> Helper loaded: url_helper
INFO - 2016-11-20 22:06:31 --> Helper loaded: form_helper
INFO - 2016-11-20 22:06:31 --> Database Driver Class Initialized
INFO - 2016-11-20 22:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 22:06:31 --> Controller Class Initialized
INFO - 2016-11-20 22:06:31 --> Model Class Initialized
INFO - 2016-11-20 22:06:31 --> Form Validation Class Initialized
ERROR - 2016-11-20 22:06:31 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 22:06:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 22:06:31 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 22:06:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 22:06:31 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 22:06:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 22:06:31 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 22:06:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-20 22:06:31 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-11-20 22:06:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 22:06:31 --> Final output sent to browser
DEBUG - 2016-11-20 22:06:31 --> Total execution time: 0.5979
INFO - 2016-11-20 22:06:31 --> Config Class Initialized
INFO - 2016-11-20 22:06:31 --> Hooks Class Initialized
DEBUG - 2016-11-20 22:06:31 --> UTF-8 Support Enabled
INFO - 2016-11-20 22:06:31 --> Utf8 Class Initialized
INFO - 2016-11-20 22:06:31 --> URI Class Initialized
DEBUG - 2016-11-20 22:06:32 --> No URI present. Default controller set.
INFO - 2016-11-20 22:06:32 --> Router Class Initialized
INFO - 2016-11-20 22:06:32 --> Output Class Initialized
INFO - 2016-11-20 22:06:32 --> Security Class Initialized
DEBUG - 2016-11-20 22:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 22:06:32 --> Input Class Initialized
INFO - 2016-11-20 22:06:32 --> Language Class Initialized
INFO - 2016-11-20 22:06:32 --> Loader Class Initialized
INFO - 2016-11-20 22:06:32 --> Helper loaded: url_helper
INFO - 2016-11-20 22:06:32 --> Helper loaded: form_helper
INFO - 2016-11-20 22:06:32 --> Database Driver Class Initialized
INFO - 2016-11-20 22:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 22:06:32 --> Controller Class Initialized
INFO - 2016-11-20 22:06:32 --> Model Class Initialized
INFO - 2016-11-20 22:06:32 --> Model Class Initialized
INFO - 2016-11-20 22:06:32 --> Model Class Initialized
INFO - 2016-11-20 22:06:32 --> Model Class Initialized
INFO - 2016-11-20 22:06:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 22:06:32 --> Pagination Class Initialized
INFO - 2016-11-20 22:06:32 --> Helper loaded: app_helper
INFO - 2016-11-20 22:06:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 22:06:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 22:06:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 22:06:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 22:06:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 22:06:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 22:06:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 22:06:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 22:06:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 22:06:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 22:06:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 22:06:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 22:06:32 --> Final output sent to browser
DEBUG - 2016-11-20 22:06:32 --> Total execution time: 0.5888
INFO - 2016-11-20 22:06:49 --> Config Class Initialized
INFO - 2016-11-20 22:06:49 --> Hooks Class Initialized
DEBUG - 2016-11-20 22:06:49 --> UTF-8 Support Enabled
INFO - 2016-11-20 22:06:49 --> Utf8 Class Initialized
INFO - 2016-11-20 22:06:49 --> URI Class Initialized
DEBUG - 2016-11-20 22:06:49 --> No URI present. Default controller set.
INFO - 2016-11-20 22:06:49 --> Router Class Initialized
INFO - 2016-11-20 22:06:49 --> Output Class Initialized
INFO - 2016-11-20 22:06:49 --> Security Class Initialized
DEBUG - 2016-11-20 22:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 22:06:49 --> Input Class Initialized
INFO - 2016-11-20 22:06:49 --> Language Class Initialized
INFO - 2016-11-20 22:06:49 --> Loader Class Initialized
INFO - 2016-11-20 22:06:49 --> Helper loaded: url_helper
INFO - 2016-11-20 22:06:49 --> Helper loaded: form_helper
INFO - 2016-11-20 22:06:49 --> Database Driver Class Initialized
INFO - 2016-11-20 22:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 22:06:49 --> Controller Class Initialized
INFO - 2016-11-20 22:06:49 --> Model Class Initialized
INFO - 2016-11-20 22:06:49 --> Model Class Initialized
INFO - 2016-11-20 22:06:49 --> Model Class Initialized
INFO - 2016-11-20 22:06:49 --> Model Class Initialized
INFO - 2016-11-20 22:06:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 22:06:49 --> Pagination Class Initialized
INFO - 2016-11-20 22:06:49 --> Helper loaded: app_helper
INFO - 2016-11-20 22:06:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 22:06:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 22:06:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 22:06:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 22:06:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 22:06:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 22:06:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 22:06:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 22:06:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 22:06:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 22:06:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 22:06:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 22:06:50 --> Final output sent to browser
DEBUG - 2016-11-20 22:06:50 --> Total execution time: 0.6963
INFO - 2016-11-20 22:08:37 --> Config Class Initialized
INFO - 2016-11-20 22:08:37 --> Hooks Class Initialized
DEBUG - 2016-11-20 22:08:37 --> UTF-8 Support Enabled
INFO - 2016-11-20 22:08:37 --> Utf8 Class Initialized
INFO - 2016-11-20 22:08:37 --> URI Class Initialized
DEBUG - 2016-11-20 22:08:37 --> No URI present. Default controller set.
INFO - 2016-11-20 22:08:37 --> Router Class Initialized
INFO - 2016-11-20 22:08:37 --> Output Class Initialized
INFO - 2016-11-20 22:08:37 --> Security Class Initialized
DEBUG - 2016-11-20 22:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 22:08:37 --> Input Class Initialized
INFO - 2016-11-20 22:08:37 --> Language Class Initialized
INFO - 2016-11-20 22:08:37 --> Loader Class Initialized
INFO - 2016-11-20 22:08:37 --> Helper loaded: url_helper
INFO - 2016-11-20 22:08:37 --> Helper loaded: form_helper
INFO - 2016-11-20 22:08:37 --> Database Driver Class Initialized
INFO - 2016-11-20 22:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 22:08:37 --> Controller Class Initialized
INFO - 2016-11-20 22:08:37 --> Model Class Initialized
INFO - 2016-11-20 22:08:37 --> Model Class Initialized
INFO - 2016-11-20 22:08:37 --> Model Class Initialized
INFO - 2016-11-20 22:08:37 --> Model Class Initialized
INFO - 2016-11-20 22:08:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 22:08:37 --> Pagination Class Initialized
INFO - 2016-11-20 22:08:37 --> Helper loaded: app_helper
INFO - 2016-11-20 22:08:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 22:08:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 22:08:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 22:08:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 22:08:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 22:08:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 22:08:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 22:08:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 22:08:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 22:08:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 22:08:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 22:08:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 22:08:38 --> Final output sent to browser
DEBUG - 2016-11-20 22:08:38 --> Total execution time: 0.6728
INFO - 2016-11-20 22:15:10 --> Config Class Initialized
INFO - 2016-11-20 22:15:10 --> Hooks Class Initialized
DEBUG - 2016-11-20 22:15:10 --> UTF-8 Support Enabled
INFO - 2016-11-20 22:15:10 --> Utf8 Class Initialized
INFO - 2016-11-20 22:15:10 --> URI Class Initialized
DEBUG - 2016-11-20 22:15:10 --> No URI present. Default controller set.
INFO - 2016-11-20 22:15:10 --> Router Class Initialized
INFO - 2016-11-20 22:15:10 --> Output Class Initialized
INFO - 2016-11-20 22:15:10 --> Security Class Initialized
DEBUG - 2016-11-20 22:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 22:15:10 --> Input Class Initialized
INFO - 2016-11-20 22:15:10 --> Language Class Initialized
INFO - 2016-11-20 22:15:10 --> Loader Class Initialized
INFO - 2016-11-20 22:15:10 --> Helper loaded: url_helper
INFO - 2016-11-20 22:15:10 --> Helper loaded: form_helper
INFO - 2016-11-20 22:15:10 --> Database Driver Class Initialized
INFO - 2016-11-20 22:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 22:15:10 --> Controller Class Initialized
INFO - 2016-11-20 22:15:10 --> Model Class Initialized
INFO - 2016-11-20 22:15:10 --> Model Class Initialized
INFO - 2016-11-20 22:15:10 --> Model Class Initialized
INFO - 2016-11-20 22:15:10 --> Model Class Initialized
INFO - 2016-11-20 22:15:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 22:15:10 --> Pagination Class Initialized
INFO - 2016-11-20 22:15:10 --> Helper loaded: app_helper
INFO - 2016-11-20 22:15:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 22:15:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 22:15:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 22:15:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 22:15:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 22:15:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 22:15:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 22:15:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 22:15:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 22:15:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 22:15:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 22:15:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 22:15:10 --> Final output sent to browser
DEBUG - 2016-11-20 22:15:10 --> Total execution time: 0.6681
INFO - 2016-11-20 22:15:27 --> Config Class Initialized
INFO - 2016-11-20 22:15:27 --> Hooks Class Initialized
DEBUG - 2016-11-20 22:15:27 --> UTF-8 Support Enabled
INFO - 2016-11-20 22:15:27 --> Utf8 Class Initialized
INFO - 2016-11-20 22:15:27 --> URI Class Initialized
DEBUG - 2016-11-20 22:15:27 --> No URI present. Default controller set.
INFO - 2016-11-20 22:15:27 --> Router Class Initialized
INFO - 2016-11-20 22:15:27 --> Output Class Initialized
INFO - 2016-11-20 22:15:27 --> Security Class Initialized
DEBUG - 2016-11-20 22:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-20 22:15:27 --> Input Class Initialized
INFO - 2016-11-20 22:15:27 --> Language Class Initialized
INFO - 2016-11-20 22:15:28 --> Loader Class Initialized
INFO - 2016-11-20 22:15:28 --> Helper loaded: url_helper
INFO - 2016-11-20 22:15:28 --> Helper loaded: form_helper
INFO - 2016-11-20 22:15:28 --> Database Driver Class Initialized
INFO - 2016-11-20 22:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-20 22:15:28 --> Controller Class Initialized
INFO - 2016-11-20 22:15:28 --> Model Class Initialized
INFO - 2016-11-20 22:15:28 --> Model Class Initialized
INFO - 2016-11-20 22:15:28 --> Model Class Initialized
INFO - 2016-11-20 22:15:28 --> Model Class Initialized
INFO - 2016-11-20 22:15:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-20 22:15:28 --> Pagination Class Initialized
INFO - 2016-11-20 22:15:28 --> Helper loaded: app_helper
INFO - 2016-11-20 22:15:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-20 22:15:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-20 22:15:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-20 22:15:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-20 22:15:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-20 22:15:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-20 22:15:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-20 22:15:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-20 22:15:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-20 22:15:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-20 22:15:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-20 22:15:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-20 22:15:28 --> Final output sent to browser
DEBUG - 2016-11-20 22:15:28 --> Total execution time: 0.6917
