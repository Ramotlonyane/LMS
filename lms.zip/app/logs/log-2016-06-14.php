<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-06-14 22:27:40 --> Config Class Initialized
INFO - 2016-06-14 22:27:40 --> Hooks Class Initialized
DEBUG - 2016-06-14 22:27:40 --> UTF-8 Support Enabled
INFO - 2016-06-14 22:27:40 --> Utf8 Class Initialized
INFO - 2016-06-14 22:27:40 --> URI Class Initialized
DEBUG - 2016-06-14 22:27:40 --> No URI present. Default controller set.
INFO - 2016-06-14 22:27:40 --> Router Class Initialized
INFO - 2016-06-14 22:27:40 --> Output Class Initialized
INFO - 2016-06-14 22:27:40 --> Security Class Initialized
DEBUG - 2016-06-14 22:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-14 22:27:40 --> Input Class Initialized
INFO - 2016-06-14 22:27:40 --> Language Class Initialized
INFO - 2016-06-14 22:27:40 --> Loader Class Initialized
INFO - 2016-06-14 22:27:40 --> Controller Class Initialized
INFO - 2016-06-14 22:27:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\welcome_message.php
INFO - 2016-06-14 22:27:40 --> Final output sent to browser
DEBUG - 2016-06-14 22:27:40 --> Total execution time: 0.1532
INFO - 2016-06-14 22:27:41 --> Config Class Initialized
INFO - 2016-06-14 22:27:41 --> Hooks Class Initialized
DEBUG - 2016-06-14 22:27:41 --> UTF-8 Support Enabled
INFO - 2016-06-14 22:27:41 --> Utf8 Class Initialized
INFO - 2016-06-14 22:27:41 --> URI Class Initialized
DEBUG - 2016-06-14 22:27:41 --> No URI present. Default controller set.
INFO - 2016-06-14 22:27:41 --> Router Class Initialized
INFO - 2016-06-14 22:27:41 --> Output Class Initialized
INFO - 2016-06-14 22:27:41 --> Security Class Initialized
DEBUG - 2016-06-14 22:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-14 22:27:41 --> Input Class Initialized
INFO - 2016-06-14 22:27:41 --> Language Class Initialized
INFO - 2016-06-14 22:27:41 --> Loader Class Initialized
INFO - 2016-06-14 22:27:41 --> Controller Class Initialized
INFO - 2016-06-14 22:27:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\welcome_message.php
INFO - 2016-06-14 22:27:41 --> Final output sent to browser
DEBUG - 2016-06-14 22:27:41 --> Total execution time: 0.1002
INFO - 2016-06-14 22:45:36 --> Config Class Initialized
INFO - 2016-06-14 22:45:36 --> Hooks Class Initialized
DEBUG - 2016-06-14 22:45:36 --> UTF-8 Support Enabled
INFO - 2016-06-14 22:45:36 --> Utf8 Class Initialized
INFO - 2016-06-14 22:45:36 --> URI Class Initialized
DEBUG - 2016-06-14 22:45:36 --> No URI present. Default controller set.
INFO - 2016-06-14 22:45:36 --> Router Class Initialized
INFO - 2016-06-14 22:45:36 --> Output Class Initialized
INFO - 2016-06-14 22:45:36 --> Security Class Initialized
DEBUG - 2016-06-14 22:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-14 22:45:36 --> Input Class Initialized
INFO - 2016-06-14 22:45:36 --> Language Class Initialized
INFO - 2016-06-14 22:45:36 --> Loader Class Initialized
INFO - 2016-06-14 22:45:36 --> Controller Class Initialized
INFO - 2016-06-14 22:45:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\welcome_message.php
INFO - 2016-06-14 22:45:36 --> Final output sent to browser
DEBUG - 2016-06-14 22:45:36 --> Total execution time: 0.1285
