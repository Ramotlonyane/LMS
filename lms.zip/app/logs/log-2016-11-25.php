<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-25 11:43:54 --> Config Class Initialized
INFO - 2016-11-25 11:43:54 --> Hooks Class Initialized
DEBUG - 2016-11-25 11:43:54 --> UTF-8 Support Enabled
INFO - 2016-11-25 11:43:54 --> Utf8 Class Initialized
INFO - 2016-11-25 11:43:54 --> URI Class Initialized
DEBUG - 2016-11-25 11:43:54 --> No URI present. Default controller set.
INFO - 2016-11-25 11:43:54 --> Router Class Initialized
INFO - 2016-11-25 11:43:54 --> Output Class Initialized
INFO - 2016-11-25 11:43:54 --> Security Class Initialized
DEBUG - 2016-11-25 11:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 11:43:54 --> Input Class Initialized
INFO - 2016-11-25 11:43:54 --> Language Class Initialized
INFO - 2016-11-25 11:43:55 --> Loader Class Initialized
INFO - 2016-11-25 11:43:55 --> Helper loaded: url_helper
INFO - 2016-11-25 11:43:55 --> Helper loaded: form_helper
INFO - 2016-11-25 11:43:55 --> Database Driver Class Initialized
INFO - 2016-11-25 11:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 11:43:55 --> Controller Class Initialized
INFO - 2016-11-25 11:43:55 --> Model Class Initialized
INFO - 2016-11-25 11:43:55 --> Model Class Initialized
INFO - 2016-11-25 11:43:55 --> Model Class Initialized
INFO - 2016-11-25 11:43:55 --> Model Class Initialized
INFO - 2016-11-25 11:43:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 11:43:55 --> Pagination Class Initialized
INFO - 2016-11-25 11:43:55 --> Helper loaded: app_helper
INFO - 2016-11-25 11:43:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 11:43:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-25 11:43:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 11:43:55 --> Final output sent to browser
DEBUG - 2016-11-25 11:43:55 --> Total execution time: 1.7762
INFO - 2016-11-25 11:44:03 --> Config Class Initialized
INFO - 2016-11-25 11:44:03 --> Hooks Class Initialized
DEBUG - 2016-11-25 11:44:03 --> UTF-8 Support Enabled
INFO - 2016-11-25 11:44:03 --> Utf8 Class Initialized
INFO - 2016-11-25 11:44:03 --> URI Class Initialized
INFO - 2016-11-25 11:44:03 --> Router Class Initialized
INFO - 2016-11-25 11:44:03 --> Output Class Initialized
INFO - 2016-11-25 11:44:03 --> Security Class Initialized
DEBUG - 2016-11-25 11:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 11:44:03 --> Input Class Initialized
INFO - 2016-11-25 11:44:03 --> Language Class Initialized
INFO - 2016-11-25 11:44:03 --> Loader Class Initialized
INFO - 2016-11-25 11:44:03 --> Helper loaded: url_helper
INFO - 2016-11-25 11:44:03 --> Helper loaded: form_helper
INFO - 2016-11-25 11:44:03 --> Database Driver Class Initialized
INFO - 2016-11-25 11:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 11:44:03 --> Controller Class Initialized
INFO - 2016-11-25 11:44:03 --> Model Class Initialized
INFO - 2016-11-25 11:44:03 --> Model Class Initialized
INFO - 2016-11-25 11:44:03 --> Model Class Initialized
INFO - 2016-11-25 11:44:03 --> Model Class Initialized
INFO - 2016-11-25 11:44:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 11:44:03 --> Pagination Class Initialized
INFO - 2016-11-25 11:44:03 --> Helper loaded: app_helper
DEBUG - 2016-11-25 11:44:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-25 11:44:03 --> Model Class Initialized
INFO - 2016-11-25 11:44:03 --> Final output sent to browser
DEBUG - 2016-11-25 11:44:03 --> Total execution time: 0.3735
INFO - 2016-11-25 11:44:03 --> Config Class Initialized
INFO - 2016-11-25 11:44:03 --> Hooks Class Initialized
DEBUG - 2016-11-25 11:44:03 --> UTF-8 Support Enabled
INFO - 2016-11-25 11:44:03 --> Utf8 Class Initialized
INFO - 2016-11-25 11:44:03 --> URI Class Initialized
DEBUG - 2016-11-25 11:44:03 --> No URI present. Default controller set.
INFO - 2016-11-25 11:44:03 --> Router Class Initialized
INFO - 2016-11-25 11:44:03 --> Output Class Initialized
INFO - 2016-11-25 11:44:03 --> Security Class Initialized
DEBUG - 2016-11-25 11:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 11:44:03 --> Input Class Initialized
INFO - 2016-11-25 11:44:03 --> Language Class Initialized
INFO - 2016-11-25 11:44:04 --> Loader Class Initialized
INFO - 2016-11-25 11:44:04 --> Helper loaded: url_helper
INFO - 2016-11-25 11:44:04 --> Helper loaded: form_helper
INFO - 2016-11-25 11:44:04 --> Database Driver Class Initialized
INFO - 2016-11-25 11:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 11:44:04 --> Controller Class Initialized
INFO - 2016-11-25 11:44:04 --> Model Class Initialized
INFO - 2016-11-25 11:44:04 --> Model Class Initialized
INFO - 2016-11-25 11:44:04 --> Model Class Initialized
INFO - 2016-11-25 11:44:04 --> Model Class Initialized
INFO - 2016-11-25 11:44:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 11:44:04 --> Pagination Class Initialized
INFO - 2016-11-25 11:44:04 --> Helper loaded: app_helper
INFO - 2016-11-25 11:44:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 11:44:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-25 11:44:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-25 11:44:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-25 11:44:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-25 11:44:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-25 11:44:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-25 11:44:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-25 11:44:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-25 11:44:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-25 11:44:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 11:44:04 --> Final output sent to browser
DEBUG - 2016-11-25 11:44:04 --> Total execution time: 1.2103
INFO - 2016-11-25 11:44:13 --> Config Class Initialized
INFO - 2016-11-25 11:44:13 --> Hooks Class Initialized
DEBUG - 2016-11-25 11:44:13 --> UTF-8 Support Enabled
INFO - 2016-11-25 11:44:13 --> Utf8 Class Initialized
INFO - 2016-11-25 11:44:13 --> URI Class Initialized
INFO - 2016-11-25 11:44:13 --> Router Class Initialized
INFO - 2016-11-25 11:44:13 --> Output Class Initialized
INFO - 2016-11-25 11:44:13 --> Security Class Initialized
DEBUG - 2016-11-25 11:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 11:44:13 --> Input Class Initialized
INFO - 2016-11-25 11:44:13 --> Language Class Initialized
INFO - 2016-11-25 11:44:13 --> Loader Class Initialized
INFO - 2016-11-25 11:44:14 --> Helper loaded: url_helper
INFO - 2016-11-25 11:44:14 --> Helper loaded: form_helper
INFO - 2016-11-25 11:44:14 --> Database Driver Class Initialized
INFO - 2016-11-25 11:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 11:44:14 --> Controller Class Initialized
INFO - 2016-11-25 11:44:14 --> Model Class Initialized
INFO - 2016-11-25 11:44:14 --> Form Validation Class Initialized
INFO - 2016-11-25 11:44:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-25 11:44:14 --> Final output sent to browser
DEBUG - 2016-11-25 11:44:14 --> Total execution time: 0.2579
INFO - 2016-11-25 11:45:29 --> Config Class Initialized
INFO - 2016-11-25 11:45:29 --> Hooks Class Initialized
DEBUG - 2016-11-25 11:45:29 --> UTF-8 Support Enabled
INFO - 2016-11-25 11:45:29 --> Utf8 Class Initialized
INFO - 2016-11-25 11:45:29 --> URI Class Initialized
INFO - 2016-11-25 11:45:29 --> Router Class Initialized
INFO - 2016-11-25 11:45:29 --> Output Class Initialized
INFO - 2016-11-25 11:45:29 --> Security Class Initialized
DEBUG - 2016-11-25 11:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 11:45:29 --> Input Class Initialized
INFO - 2016-11-25 11:45:29 --> Language Class Initialized
INFO - 2016-11-25 11:45:29 --> Loader Class Initialized
INFO - 2016-11-25 11:45:29 --> Helper loaded: url_helper
INFO - 2016-11-25 11:45:29 --> Helper loaded: form_helper
INFO - 2016-11-25 11:45:29 --> Database Driver Class Initialized
INFO - 2016-11-25 11:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 11:45:29 --> Controller Class Initialized
INFO - 2016-11-25 11:45:29 --> Model Class Initialized
INFO - 2016-11-25 11:45:29 --> Form Validation Class Initialized
INFO - 2016-11-25 11:45:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-25 11:45:29 --> Final output sent to browser
DEBUG - 2016-11-25 11:45:29 --> Total execution time: 0.2254
INFO - 2016-11-25 11:45:46 --> Config Class Initialized
INFO - 2016-11-25 11:45:46 --> Hooks Class Initialized
DEBUG - 2016-11-25 11:45:46 --> UTF-8 Support Enabled
INFO - 2016-11-25 11:45:46 --> Utf8 Class Initialized
INFO - 2016-11-25 11:45:46 --> URI Class Initialized
INFO - 2016-11-25 11:45:46 --> Router Class Initialized
INFO - 2016-11-25 11:45:46 --> Output Class Initialized
INFO - 2016-11-25 11:45:46 --> Security Class Initialized
DEBUG - 2016-11-25 11:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 11:45:46 --> Input Class Initialized
INFO - 2016-11-25 11:45:46 --> Language Class Initialized
INFO - 2016-11-25 11:45:46 --> Loader Class Initialized
INFO - 2016-11-25 11:45:46 --> Helper loaded: url_helper
INFO - 2016-11-25 11:45:46 --> Helper loaded: form_helper
INFO - 2016-11-25 11:45:46 --> Database Driver Class Initialized
INFO - 2016-11-25 11:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 11:45:46 --> Controller Class Initialized
INFO - 2016-11-25 11:45:46 --> Model Class Initialized
INFO - 2016-11-25 11:45:46 --> Form Validation Class Initialized
INFO - 2016-11-25 11:45:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-25 11:45:46 --> Final output sent to browser
DEBUG - 2016-11-25 11:45:46 --> Total execution time: 0.2073
INFO - 2016-11-25 11:53:55 --> Config Class Initialized
INFO - 2016-11-25 11:53:55 --> Hooks Class Initialized
DEBUG - 2016-11-25 11:53:55 --> UTF-8 Support Enabled
INFO - 2016-11-25 11:53:55 --> Utf8 Class Initialized
INFO - 2016-11-25 11:53:55 --> URI Class Initialized
DEBUG - 2016-11-25 11:53:55 --> No URI present. Default controller set.
INFO - 2016-11-25 11:53:55 --> Router Class Initialized
INFO - 2016-11-25 11:53:55 --> Output Class Initialized
INFO - 2016-11-25 11:53:55 --> Security Class Initialized
DEBUG - 2016-11-25 11:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 11:53:55 --> Input Class Initialized
INFO - 2016-11-25 11:53:55 --> Language Class Initialized
INFO - 2016-11-25 11:53:55 --> Loader Class Initialized
INFO - 2016-11-25 11:53:55 --> Helper loaded: url_helper
INFO - 2016-11-25 11:53:55 --> Helper loaded: form_helper
INFO - 2016-11-25 11:53:55 --> Database Driver Class Initialized
INFO - 2016-11-25 11:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 11:53:55 --> Controller Class Initialized
INFO - 2016-11-25 11:53:55 --> Model Class Initialized
INFO - 2016-11-25 11:53:55 --> Model Class Initialized
INFO - 2016-11-25 11:53:55 --> Model Class Initialized
INFO - 2016-11-25 11:53:55 --> Model Class Initialized
INFO - 2016-11-25 11:53:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 11:53:55 --> Pagination Class Initialized
INFO - 2016-11-25 11:53:55 --> Helper loaded: app_helper
INFO - 2016-11-25 11:53:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 11:53:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-25 11:53:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-25 11:53:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-25 11:53:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-25 11:53:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-25 11:53:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-25 11:53:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-25 11:53:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-25 11:53:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-25 11:53:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 11:53:56 --> Final output sent to browser
DEBUG - 2016-11-25 11:53:56 --> Total execution time: 0.4531
INFO - 2016-11-25 11:54:24 --> Config Class Initialized
INFO - 2016-11-25 11:54:24 --> Hooks Class Initialized
DEBUG - 2016-11-25 11:54:24 --> UTF-8 Support Enabled
INFO - 2016-11-25 11:54:24 --> Utf8 Class Initialized
INFO - 2016-11-25 11:54:24 --> URI Class Initialized
INFO - 2016-11-25 11:54:24 --> Router Class Initialized
INFO - 2016-11-25 11:54:24 --> Output Class Initialized
INFO - 2016-11-25 11:54:24 --> Security Class Initialized
DEBUG - 2016-11-25 11:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 11:54:24 --> Input Class Initialized
INFO - 2016-11-25 11:54:24 --> Language Class Initialized
INFO - 2016-11-25 11:54:24 --> Loader Class Initialized
INFO - 2016-11-25 11:54:24 --> Helper loaded: url_helper
INFO - 2016-11-25 11:54:24 --> Helper loaded: form_helper
INFO - 2016-11-25 11:54:24 --> Database Driver Class Initialized
INFO - 2016-11-25 11:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 11:54:24 --> Controller Class Initialized
INFO - 2016-11-25 11:54:24 --> Model Class Initialized
INFO - 2016-11-25 11:54:24 --> Model Class Initialized
INFO - 2016-11-25 11:54:24 --> Model Class Initialized
INFO - 2016-11-25 11:54:24 --> Model Class Initialized
INFO - 2016-11-25 11:54:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 11:54:24 --> Pagination Class Initialized
INFO - 2016-11-25 11:54:24 --> Helper loaded: app_helper
DEBUG - 2016-11-25 11:54:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-25 11:54:24 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-25 11:54:24 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-25 11:54:24 --> Config Class Initialized
INFO - 2016-11-25 11:54:24 --> Hooks Class Initialized
DEBUG - 2016-11-25 11:54:24 --> UTF-8 Support Enabled
INFO - 2016-11-25 11:54:24 --> Utf8 Class Initialized
INFO - 2016-11-25 11:54:24 --> URI Class Initialized
DEBUG - 2016-11-25 11:54:24 --> No URI present. Default controller set.
INFO - 2016-11-25 11:54:24 --> Router Class Initialized
INFO - 2016-11-25 11:54:24 --> Output Class Initialized
INFO - 2016-11-25 11:54:24 --> Security Class Initialized
DEBUG - 2016-11-25 11:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 11:54:24 --> Input Class Initialized
INFO - 2016-11-25 11:54:24 --> Language Class Initialized
INFO - 2016-11-25 11:54:24 --> Loader Class Initialized
INFO - 2016-11-25 11:54:24 --> Helper loaded: url_helper
INFO - 2016-11-25 11:54:24 --> Helper loaded: form_helper
INFO - 2016-11-25 11:54:24 --> Database Driver Class Initialized
INFO - 2016-11-25 11:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 11:54:24 --> Controller Class Initialized
INFO - 2016-11-25 11:54:24 --> Model Class Initialized
INFO - 2016-11-25 11:54:24 --> Model Class Initialized
INFO - 2016-11-25 11:54:24 --> Model Class Initialized
INFO - 2016-11-25 11:54:24 --> Model Class Initialized
INFO - 2016-11-25 11:54:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 11:54:24 --> Pagination Class Initialized
INFO - 2016-11-25 11:54:24 --> Helper loaded: app_helper
INFO - 2016-11-25 11:54:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 11:54:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-25 11:54:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 11:54:24 --> Final output sent to browser
DEBUG - 2016-11-25 11:54:24 --> Total execution time: 0.4223
INFO - 2016-11-25 22:23:23 --> Config Class Initialized
INFO - 2016-11-25 22:23:23 --> Hooks Class Initialized
DEBUG - 2016-11-25 22:23:23 --> UTF-8 Support Enabled
INFO - 2016-11-25 22:23:23 --> Utf8 Class Initialized
INFO - 2016-11-25 22:23:23 --> URI Class Initialized
DEBUG - 2016-11-25 22:23:23 --> No URI present. Default controller set.
INFO - 2016-11-25 22:23:23 --> Router Class Initialized
INFO - 2016-11-25 22:23:23 --> Output Class Initialized
INFO - 2016-11-25 22:23:24 --> Security Class Initialized
DEBUG - 2016-11-25 22:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 22:23:24 --> Input Class Initialized
INFO - 2016-11-25 22:23:24 --> Language Class Initialized
INFO - 2016-11-25 22:23:24 --> Loader Class Initialized
INFO - 2016-11-25 22:23:24 --> Helper loaded: url_helper
INFO - 2016-11-25 22:23:24 --> Helper loaded: form_helper
INFO - 2016-11-25 22:23:24 --> Database Driver Class Initialized
INFO - 2016-11-25 22:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 22:23:24 --> Controller Class Initialized
INFO - 2016-11-25 22:23:24 --> Model Class Initialized
INFO - 2016-11-25 22:23:24 --> Model Class Initialized
INFO - 2016-11-25 22:23:24 --> Model Class Initialized
INFO - 2016-11-25 22:23:24 --> Model Class Initialized
INFO - 2016-11-25 22:23:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 22:23:24 --> Pagination Class Initialized
INFO - 2016-11-25 22:23:24 --> Helper loaded: app_helper
INFO - 2016-11-25 22:23:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 22:23:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-25 22:23:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 22:23:25 --> Final output sent to browser
DEBUG - 2016-11-25 22:23:25 --> Total execution time: 1.5772
INFO - 2016-11-25 22:23:39 --> Config Class Initialized
INFO - 2016-11-25 22:23:39 --> Hooks Class Initialized
DEBUG - 2016-11-25 22:23:39 --> UTF-8 Support Enabled
INFO - 2016-11-25 22:23:39 --> Utf8 Class Initialized
INFO - 2016-11-25 22:23:39 --> URI Class Initialized
INFO - 2016-11-25 22:23:39 --> Router Class Initialized
INFO - 2016-11-25 22:23:39 --> Output Class Initialized
INFO - 2016-11-25 22:23:39 --> Security Class Initialized
DEBUG - 2016-11-25 22:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 22:23:39 --> Input Class Initialized
INFO - 2016-11-25 22:23:39 --> Language Class Initialized
INFO - 2016-11-25 22:23:39 --> Loader Class Initialized
INFO - 2016-11-25 22:23:39 --> Helper loaded: url_helper
INFO - 2016-11-25 22:23:39 --> Helper loaded: form_helper
INFO - 2016-11-25 22:23:39 --> Database Driver Class Initialized
INFO - 2016-11-25 22:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 22:23:39 --> Controller Class Initialized
INFO - 2016-11-25 22:23:39 --> Model Class Initialized
INFO - 2016-11-25 22:23:39 --> Model Class Initialized
INFO - 2016-11-25 22:23:39 --> Model Class Initialized
INFO - 2016-11-25 22:23:39 --> Model Class Initialized
INFO - 2016-11-25 22:23:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 22:23:39 --> Pagination Class Initialized
INFO - 2016-11-25 22:23:39 --> Helper loaded: app_helper
DEBUG - 2016-11-25 22:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-25 22:23:39 --> Model Class Initialized
INFO - 2016-11-25 22:23:39 --> Final output sent to browser
DEBUG - 2016-11-25 22:23:39 --> Total execution time: 0.5861
INFO - 2016-11-25 22:23:39 --> Config Class Initialized
INFO - 2016-11-25 22:23:39 --> Hooks Class Initialized
DEBUG - 2016-11-25 22:23:39 --> UTF-8 Support Enabled
INFO - 2016-11-25 22:23:39 --> Utf8 Class Initialized
INFO - 2016-11-25 22:23:39 --> URI Class Initialized
DEBUG - 2016-11-25 22:23:39 --> No URI present. Default controller set.
INFO - 2016-11-25 22:23:39 --> Router Class Initialized
INFO - 2016-11-25 22:23:39 --> Output Class Initialized
INFO - 2016-11-25 22:23:39 --> Security Class Initialized
DEBUG - 2016-11-25 22:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 22:23:39 --> Input Class Initialized
INFO - 2016-11-25 22:23:39 --> Language Class Initialized
INFO - 2016-11-25 22:23:39 --> Loader Class Initialized
INFO - 2016-11-25 22:23:39 --> Helper loaded: url_helper
INFO - 2016-11-25 22:23:39 --> Helper loaded: form_helper
INFO - 2016-11-25 22:23:39 --> Database Driver Class Initialized
INFO - 2016-11-25 22:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 22:23:39 --> Controller Class Initialized
INFO - 2016-11-25 22:23:39 --> Model Class Initialized
INFO - 2016-11-25 22:23:39 --> Model Class Initialized
INFO - 2016-11-25 22:23:39 --> Model Class Initialized
INFO - 2016-11-25 22:23:39 --> Model Class Initialized
INFO - 2016-11-25 22:23:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 22:23:39 --> Pagination Class Initialized
INFO - 2016-11-25 22:23:39 --> Helper loaded: app_helper
INFO - 2016-11-25 22:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 22:23:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-25 22:23:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-25 22:23:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-25 22:23:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-25 22:23:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-25 22:23:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-25 22:23:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-25 22:23:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-25 22:23:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-25 22:23:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-25 22:23:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 22:23:40 --> Final output sent to browser
DEBUG - 2016-11-25 22:23:40 --> Total execution time: 1.0460
INFO - 2016-11-25 22:25:23 --> Config Class Initialized
INFO - 2016-11-25 22:25:23 --> Hooks Class Initialized
DEBUG - 2016-11-25 22:25:23 --> UTF-8 Support Enabled
INFO - 2016-11-25 22:25:23 --> Utf8 Class Initialized
INFO - 2016-11-25 22:25:23 --> URI Class Initialized
DEBUG - 2016-11-25 22:25:23 --> No URI present. Default controller set.
INFO - 2016-11-25 22:25:23 --> Router Class Initialized
INFO - 2016-11-25 22:25:23 --> Output Class Initialized
INFO - 2016-11-25 22:25:23 --> Security Class Initialized
DEBUG - 2016-11-25 22:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 22:25:23 --> Input Class Initialized
INFO - 2016-11-25 22:25:23 --> Language Class Initialized
INFO - 2016-11-25 22:25:23 --> Loader Class Initialized
INFO - 2016-11-25 22:25:23 --> Helper loaded: url_helper
INFO - 2016-11-25 22:25:23 --> Helper loaded: form_helper
INFO - 2016-11-25 22:25:23 --> Database Driver Class Initialized
INFO - 2016-11-25 22:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 22:25:23 --> Controller Class Initialized
INFO - 2016-11-25 22:25:23 --> Model Class Initialized
INFO - 2016-11-25 22:25:23 --> Model Class Initialized
INFO - 2016-11-25 22:25:23 --> Model Class Initialized
INFO - 2016-11-25 22:25:23 --> Model Class Initialized
INFO - 2016-11-25 22:25:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 22:25:23 --> Pagination Class Initialized
INFO - 2016-11-25 22:25:23 --> Helper loaded: app_helper
INFO - 2016-11-25 22:25:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 22:25:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-25 22:25:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-25 22:25:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-25 22:25:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-25 22:25:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-25 22:25:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-25 22:25:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-25 22:25:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-25 22:25:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-25 22:25:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-25 22:25:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 22:25:23 --> Final output sent to browser
DEBUG - 2016-11-25 22:25:23 --> Total execution time: 0.4478
INFO - 2016-11-25 23:09:06 --> Config Class Initialized
INFO - 2016-11-25 23:09:06 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:09:06 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:09:06 --> Utf8 Class Initialized
INFO - 2016-11-25 23:09:06 --> URI Class Initialized
INFO - 2016-11-25 23:09:06 --> Router Class Initialized
INFO - 2016-11-25 23:09:06 --> Output Class Initialized
INFO - 2016-11-25 23:09:06 --> Security Class Initialized
DEBUG - 2016-11-25 23:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:09:07 --> Input Class Initialized
INFO - 2016-11-25 23:09:07 --> Language Class Initialized
INFO - 2016-11-25 23:09:07 --> Loader Class Initialized
INFO - 2016-11-25 23:09:07 --> Helper loaded: url_helper
INFO - 2016-11-25 23:09:07 --> Helper loaded: form_helper
INFO - 2016-11-25 23:09:07 --> Database Driver Class Initialized
INFO - 2016-11-25 23:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:09:07 --> Controller Class Initialized
INFO - 2016-11-25 23:09:07 --> Model Class Initialized
INFO - 2016-11-25 23:09:07 --> Model Class Initialized
INFO - 2016-11-25 23:09:07 --> Model Class Initialized
INFO - 2016-11-25 23:09:07 --> Model Class Initialized
INFO - 2016-11-25 23:09:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:09:07 --> Pagination Class Initialized
INFO - 2016-11-25 23:09:07 --> Helper loaded: app_helper
DEBUG - 2016-11-25 23:09:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-25 23:09:08 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-25 23:09:08 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-25 23:09:08 --> Config Class Initialized
INFO - 2016-11-25 23:09:08 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:09:08 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:09:08 --> Utf8 Class Initialized
INFO - 2016-11-25 23:09:08 --> URI Class Initialized
DEBUG - 2016-11-25 23:09:08 --> No URI present. Default controller set.
INFO - 2016-11-25 23:09:08 --> Router Class Initialized
INFO - 2016-11-25 23:09:08 --> Output Class Initialized
INFO - 2016-11-25 23:09:08 --> Security Class Initialized
DEBUG - 2016-11-25 23:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:09:08 --> Input Class Initialized
INFO - 2016-11-25 23:09:08 --> Language Class Initialized
INFO - 2016-11-25 23:09:08 --> Loader Class Initialized
INFO - 2016-11-25 23:09:08 --> Helper loaded: url_helper
INFO - 2016-11-25 23:09:08 --> Helper loaded: form_helper
INFO - 2016-11-25 23:09:08 --> Database Driver Class Initialized
INFO - 2016-11-25 23:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:09:08 --> Controller Class Initialized
INFO - 2016-11-25 23:09:08 --> Model Class Initialized
INFO - 2016-11-25 23:09:08 --> Model Class Initialized
INFO - 2016-11-25 23:09:08 --> Model Class Initialized
INFO - 2016-11-25 23:09:08 --> Model Class Initialized
INFO - 2016-11-25 23:09:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:09:08 --> Pagination Class Initialized
INFO - 2016-11-25 23:09:08 --> Helper loaded: app_helper
INFO - 2016-11-25 23:09:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 23:09:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-25 23:09:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 23:09:08 --> Final output sent to browser
DEBUG - 2016-11-25 23:09:08 --> Total execution time: 0.3030
INFO - 2016-11-25 23:18:15 --> Config Class Initialized
INFO - 2016-11-25 23:18:15 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:18:15 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:18:15 --> Utf8 Class Initialized
INFO - 2016-11-25 23:18:15 --> URI Class Initialized
DEBUG - 2016-11-25 23:18:15 --> No URI present. Default controller set.
INFO - 2016-11-25 23:18:15 --> Router Class Initialized
INFO - 2016-11-25 23:18:15 --> Output Class Initialized
INFO - 2016-11-25 23:18:15 --> Security Class Initialized
DEBUG - 2016-11-25 23:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:18:15 --> Input Class Initialized
INFO - 2016-11-25 23:18:15 --> Language Class Initialized
INFO - 2016-11-25 23:18:15 --> Loader Class Initialized
INFO - 2016-11-25 23:18:15 --> Helper loaded: url_helper
INFO - 2016-11-25 23:18:15 --> Helper loaded: form_helper
INFO - 2016-11-25 23:18:15 --> Database Driver Class Initialized
INFO - 2016-11-25 23:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:18:15 --> Controller Class Initialized
INFO - 2016-11-25 23:18:15 --> Model Class Initialized
INFO - 2016-11-25 23:18:15 --> Model Class Initialized
INFO - 2016-11-25 23:18:15 --> Model Class Initialized
INFO - 2016-11-25 23:18:15 --> Model Class Initialized
INFO - 2016-11-25 23:18:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:18:16 --> Pagination Class Initialized
INFO - 2016-11-25 23:18:16 --> Helper loaded: app_helper
INFO - 2016-11-25 23:18:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 23:18:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-25 23:18:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 23:18:16 --> Final output sent to browser
DEBUG - 2016-11-25 23:18:16 --> Total execution time: 0.2929
INFO - 2016-11-25 23:18:29 --> Config Class Initialized
INFO - 2016-11-25 23:18:29 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:18:29 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:18:29 --> Utf8 Class Initialized
INFO - 2016-11-25 23:18:29 --> URI Class Initialized
INFO - 2016-11-25 23:18:29 --> Router Class Initialized
INFO - 2016-11-25 23:18:29 --> Output Class Initialized
INFO - 2016-11-25 23:18:29 --> Security Class Initialized
DEBUG - 2016-11-25 23:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:18:29 --> Input Class Initialized
INFO - 2016-11-25 23:18:29 --> Language Class Initialized
INFO - 2016-11-25 23:18:29 --> Loader Class Initialized
INFO - 2016-11-25 23:18:29 --> Helper loaded: url_helper
INFO - 2016-11-25 23:18:29 --> Helper loaded: form_helper
INFO - 2016-11-25 23:18:29 --> Database Driver Class Initialized
INFO - 2016-11-25 23:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:18:29 --> Controller Class Initialized
INFO - 2016-11-25 23:18:29 --> Model Class Initialized
INFO - 2016-11-25 23:18:29 --> Model Class Initialized
INFO - 2016-11-25 23:18:29 --> Model Class Initialized
INFO - 2016-11-25 23:18:29 --> Model Class Initialized
INFO - 2016-11-25 23:18:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:18:29 --> Pagination Class Initialized
INFO - 2016-11-25 23:18:29 --> Helper loaded: app_helper
DEBUG - 2016-11-25 23:18:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-25 23:18:29 --> Model Class Initialized
INFO - 2016-11-25 23:18:29 --> Final output sent to browser
DEBUG - 2016-11-25 23:18:29 --> Total execution time: 0.3657
INFO - 2016-11-25 23:18:29 --> Config Class Initialized
INFO - 2016-11-25 23:18:29 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:18:29 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:18:29 --> Utf8 Class Initialized
INFO - 2016-11-25 23:18:29 --> URI Class Initialized
DEBUG - 2016-11-25 23:18:29 --> No URI present. Default controller set.
INFO - 2016-11-25 23:18:29 --> Router Class Initialized
INFO - 2016-11-25 23:18:29 --> Output Class Initialized
INFO - 2016-11-25 23:18:29 --> Security Class Initialized
DEBUG - 2016-11-25 23:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:18:29 --> Input Class Initialized
INFO - 2016-11-25 23:18:29 --> Language Class Initialized
INFO - 2016-11-25 23:18:29 --> Loader Class Initialized
INFO - 2016-11-25 23:18:29 --> Helper loaded: url_helper
INFO - 2016-11-25 23:18:29 --> Helper loaded: form_helper
INFO - 2016-11-25 23:18:29 --> Database Driver Class Initialized
INFO - 2016-11-25 23:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:18:29 --> Controller Class Initialized
INFO - 2016-11-25 23:18:29 --> Model Class Initialized
INFO - 2016-11-25 23:18:29 --> Model Class Initialized
INFO - 2016-11-25 23:18:29 --> Model Class Initialized
INFO - 2016-11-25 23:18:29 --> Model Class Initialized
INFO - 2016-11-25 23:18:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:18:29 --> Pagination Class Initialized
INFO - 2016-11-25 23:18:29 --> Helper loaded: app_helper
INFO - 2016-11-25 23:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 23:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-25 23:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-25 23:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-25 23:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-25 23:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-25 23:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-25 23:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-25 23:18:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-25 23:18:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-25 23:18:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-25 23:18:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 23:18:30 --> Final output sent to browser
DEBUG - 2016-11-25 23:18:30 --> Total execution time: 0.4012
INFO - 2016-11-25 23:18:45 --> Config Class Initialized
INFO - 2016-11-25 23:18:45 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:18:45 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:18:45 --> Utf8 Class Initialized
INFO - 2016-11-25 23:18:45 --> URI Class Initialized
DEBUG - 2016-11-25 23:18:45 --> No URI present. Default controller set.
INFO - 2016-11-25 23:18:45 --> Router Class Initialized
INFO - 2016-11-25 23:18:45 --> Output Class Initialized
INFO - 2016-11-25 23:18:45 --> Security Class Initialized
DEBUG - 2016-11-25 23:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:18:45 --> Input Class Initialized
INFO - 2016-11-25 23:18:45 --> Language Class Initialized
INFO - 2016-11-25 23:18:45 --> Loader Class Initialized
INFO - 2016-11-25 23:18:45 --> Helper loaded: url_helper
INFO - 2016-11-25 23:18:45 --> Helper loaded: form_helper
INFO - 2016-11-25 23:18:45 --> Database Driver Class Initialized
INFO - 2016-11-25 23:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:18:45 --> Controller Class Initialized
INFO - 2016-11-25 23:18:45 --> Model Class Initialized
INFO - 2016-11-25 23:18:45 --> Model Class Initialized
INFO - 2016-11-25 23:18:45 --> Model Class Initialized
INFO - 2016-11-25 23:18:45 --> Model Class Initialized
INFO - 2016-11-25 23:18:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:18:45 --> Pagination Class Initialized
INFO - 2016-11-25 23:18:45 --> Helper loaded: app_helper
INFO - 2016-11-25 23:18:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 23:18:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-25 23:18:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-25 23:18:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-25 23:18:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-25 23:18:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-25 23:18:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-25 23:18:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-25 23:18:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-25 23:18:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-25 23:18:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-25 23:18:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 23:18:45 --> Final output sent to browser
DEBUG - 2016-11-25 23:18:45 --> Total execution time: 0.4527
INFO - 2016-11-25 23:20:02 --> Config Class Initialized
INFO - 2016-11-25 23:20:02 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:20:02 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:20:02 --> Utf8 Class Initialized
INFO - 2016-11-25 23:20:02 --> URI Class Initialized
DEBUG - 2016-11-25 23:20:02 --> No URI present. Default controller set.
INFO - 2016-11-25 23:20:02 --> Router Class Initialized
INFO - 2016-11-25 23:20:02 --> Output Class Initialized
INFO - 2016-11-25 23:20:02 --> Security Class Initialized
DEBUG - 2016-11-25 23:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:20:02 --> Input Class Initialized
INFO - 2016-11-25 23:20:02 --> Language Class Initialized
INFO - 2016-11-25 23:20:02 --> Loader Class Initialized
INFO - 2016-11-25 23:20:02 --> Helper loaded: url_helper
INFO - 2016-11-25 23:20:02 --> Helper loaded: form_helper
INFO - 2016-11-25 23:20:02 --> Database Driver Class Initialized
INFO - 2016-11-25 23:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:20:02 --> Controller Class Initialized
INFO - 2016-11-25 23:20:02 --> Model Class Initialized
INFO - 2016-11-25 23:20:02 --> Model Class Initialized
INFO - 2016-11-25 23:20:02 --> Model Class Initialized
INFO - 2016-11-25 23:20:02 --> Model Class Initialized
INFO - 2016-11-25 23:20:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:20:02 --> Pagination Class Initialized
INFO - 2016-11-25 23:20:02 --> Helper loaded: app_helper
INFO - 2016-11-25 23:20:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 23:20:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-25 23:20:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-25 23:20:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-25 23:20:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-25 23:20:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-25 23:20:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-25 23:20:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-25 23:20:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-25 23:20:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-25 23:20:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-25 23:20:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 23:20:02 --> Final output sent to browser
DEBUG - 2016-11-25 23:20:02 --> Total execution time: 0.4466
INFO - 2016-11-25 23:20:33 --> Config Class Initialized
INFO - 2016-11-25 23:20:33 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:20:33 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:20:33 --> Utf8 Class Initialized
INFO - 2016-11-25 23:20:33 --> URI Class Initialized
DEBUG - 2016-11-25 23:20:33 --> No URI present. Default controller set.
INFO - 2016-11-25 23:20:33 --> Router Class Initialized
INFO - 2016-11-25 23:20:33 --> Output Class Initialized
INFO - 2016-11-25 23:20:33 --> Security Class Initialized
DEBUG - 2016-11-25 23:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:20:33 --> Input Class Initialized
INFO - 2016-11-25 23:20:33 --> Language Class Initialized
INFO - 2016-11-25 23:20:33 --> Loader Class Initialized
INFO - 2016-11-25 23:20:33 --> Helper loaded: url_helper
INFO - 2016-11-25 23:20:33 --> Helper loaded: form_helper
INFO - 2016-11-25 23:20:33 --> Database Driver Class Initialized
INFO - 2016-11-25 23:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:20:33 --> Controller Class Initialized
INFO - 2016-11-25 23:20:33 --> Model Class Initialized
INFO - 2016-11-25 23:20:33 --> Model Class Initialized
INFO - 2016-11-25 23:20:33 --> Model Class Initialized
INFO - 2016-11-25 23:20:33 --> Model Class Initialized
INFO - 2016-11-25 23:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:20:33 --> Pagination Class Initialized
INFO - 2016-11-25 23:20:33 --> Helper loaded: app_helper
INFO - 2016-11-25 23:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 23:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-25 23:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-25 23:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-25 23:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-25 23:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-25 23:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-25 23:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-25 23:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-25 23:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-25 23:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-25 23:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 23:20:33 --> Final output sent to browser
DEBUG - 2016-11-25 23:20:33 --> Total execution time: 0.4625
INFO - 2016-11-25 23:20:42 --> Config Class Initialized
INFO - 2016-11-25 23:20:42 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:20:42 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:20:42 --> Utf8 Class Initialized
INFO - 2016-11-25 23:20:42 --> URI Class Initialized
INFO - 2016-11-25 23:20:42 --> Router Class Initialized
INFO - 2016-11-25 23:20:42 --> Output Class Initialized
INFO - 2016-11-25 23:20:42 --> Security Class Initialized
DEBUG - 2016-11-25 23:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:20:42 --> Input Class Initialized
INFO - 2016-11-25 23:20:42 --> Language Class Initialized
INFO - 2016-11-25 23:20:42 --> Loader Class Initialized
INFO - 2016-11-25 23:20:42 --> Helper loaded: url_helper
INFO - 2016-11-25 23:20:42 --> Helper loaded: form_helper
INFO - 2016-11-25 23:20:42 --> Database Driver Class Initialized
INFO - 2016-11-25 23:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:20:42 --> Controller Class Initialized
INFO - 2016-11-25 23:20:42 --> Model Class Initialized
INFO - 2016-11-25 23:20:42 --> Model Class Initialized
INFO - 2016-11-25 23:20:42 --> Model Class Initialized
INFO - 2016-11-25 23:20:42 --> Model Class Initialized
INFO - 2016-11-25 23:20:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:20:42 --> Pagination Class Initialized
INFO - 2016-11-25 23:20:42 --> Helper loaded: app_helper
DEBUG - 2016-11-25 23:20:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-25 23:20:42 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-25 23:20:42 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-25 23:20:42 --> Config Class Initialized
INFO - 2016-11-25 23:20:42 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:20:42 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:20:42 --> Utf8 Class Initialized
INFO - 2016-11-25 23:20:42 --> URI Class Initialized
DEBUG - 2016-11-25 23:20:42 --> No URI present. Default controller set.
INFO - 2016-11-25 23:20:42 --> Router Class Initialized
INFO - 2016-11-25 23:20:42 --> Output Class Initialized
INFO - 2016-11-25 23:20:42 --> Security Class Initialized
DEBUG - 2016-11-25 23:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:20:43 --> Input Class Initialized
INFO - 2016-11-25 23:20:43 --> Language Class Initialized
INFO - 2016-11-25 23:20:43 --> Loader Class Initialized
INFO - 2016-11-25 23:20:43 --> Helper loaded: url_helper
INFO - 2016-11-25 23:20:43 --> Helper loaded: form_helper
INFO - 2016-11-25 23:20:43 --> Database Driver Class Initialized
INFO - 2016-11-25 23:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:20:43 --> Controller Class Initialized
INFO - 2016-11-25 23:20:43 --> Model Class Initialized
INFO - 2016-11-25 23:20:43 --> Model Class Initialized
INFO - 2016-11-25 23:20:43 --> Model Class Initialized
INFO - 2016-11-25 23:20:43 --> Model Class Initialized
INFO - 2016-11-25 23:20:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:20:43 --> Pagination Class Initialized
INFO - 2016-11-25 23:20:43 --> Helper loaded: app_helper
INFO - 2016-11-25 23:20:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 23:20:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-25 23:20:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 23:20:43 --> Final output sent to browser
DEBUG - 2016-11-25 23:20:43 --> Total execution time: 0.3422
INFO - 2016-11-25 23:20:53 --> Config Class Initialized
INFO - 2016-11-25 23:20:53 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:20:53 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:20:53 --> Utf8 Class Initialized
INFO - 2016-11-25 23:20:53 --> URI Class Initialized
INFO - 2016-11-25 23:20:53 --> Router Class Initialized
INFO - 2016-11-25 23:20:53 --> Output Class Initialized
INFO - 2016-11-25 23:20:53 --> Security Class Initialized
DEBUG - 2016-11-25 23:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:20:53 --> Input Class Initialized
INFO - 2016-11-25 23:20:53 --> Language Class Initialized
INFO - 2016-11-25 23:20:53 --> Loader Class Initialized
INFO - 2016-11-25 23:20:53 --> Helper loaded: url_helper
INFO - 2016-11-25 23:20:53 --> Helper loaded: form_helper
INFO - 2016-11-25 23:20:53 --> Database Driver Class Initialized
INFO - 2016-11-25 23:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:20:53 --> Controller Class Initialized
INFO - 2016-11-25 23:20:53 --> Model Class Initialized
INFO - 2016-11-25 23:20:53 --> Model Class Initialized
INFO - 2016-11-25 23:20:53 --> Model Class Initialized
INFO - 2016-11-25 23:20:53 --> Model Class Initialized
INFO - 2016-11-25 23:20:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:20:54 --> Pagination Class Initialized
INFO - 2016-11-25 23:20:54 --> Helper loaded: app_helper
DEBUG - 2016-11-25 23:20:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-25 23:20:54 --> Model Class Initialized
INFO - 2016-11-25 23:20:54 --> Final output sent to browser
DEBUG - 2016-11-25 23:20:54 --> Total execution time: 0.2578
INFO - 2016-11-25 23:20:54 --> Config Class Initialized
INFO - 2016-11-25 23:20:54 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:20:54 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:20:54 --> Utf8 Class Initialized
INFO - 2016-11-25 23:20:54 --> URI Class Initialized
DEBUG - 2016-11-25 23:20:54 --> No URI present. Default controller set.
INFO - 2016-11-25 23:20:54 --> Router Class Initialized
INFO - 2016-11-25 23:20:54 --> Output Class Initialized
INFO - 2016-11-25 23:20:54 --> Security Class Initialized
DEBUG - 2016-11-25 23:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:20:54 --> Input Class Initialized
INFO - 2016-11-25 23:20:54 --> Language Class Initialized
INFO - 2016-11-25 23:20:54 --> Loader Class Initialized
INFO - 2016-11-25 23:20:54 --> Helper loaded: url_helper
INFO - 2016-11-25 23:20:54 --> Helper loaded: form_helper
INFO - 2016-11-25 23:20:54 --> Database Driver Class Initialized
INFO - 2016-11-25 23:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:20:54 --> Controller Class Initialized
INFO - 2016-11-25 23:20:54 --> Model Class Initialized
INFO - 2016-11-25 23:20:54 --> Model Class Initialized
INFO - 2016-11-25 23:20:54 --> Model Class Initialized
INFO - 2016-11-25 23:20:54 --> Model Class Initialized
INFO - 2016-11-25 23:20:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:20:54 --> Pagination Class Initialized
INFO - 2016-11-25 23:20:54 --> Helper loaded: app_helper
INFO - 2016-11-25 23:20:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 23:20:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-25 23:20:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-25 23:20:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-25 23:20:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-25 23:20:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-25 23:20:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-25 23:20:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-25 23:20:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-25 23:20:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-25 23:20:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 23:20:54 --> Final output sent to browser
DEBUG - 2016-11-25 23:20:54 --> Total execution time: 0.5572
INFO - 2016-11-25 23:22:39 --> Config Class Initialized
INFO - 2016-11-25 23:22:39 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:22:39 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:22:39 --> Utf8 Class Initialized
INFO - 2016-11-25 23:22:39 --> URI Class Initialized
DEBUG - 2016-11-25 23:22:39 --> No URI present. Default controller set.
INFO - 2016-11-25 23:22:39 --> Router Class Initialized
INFO - 2016-11-25 23:22:39 --> Output Class Initialized
INFO - 2016-11-25 23:22:39 --> Security Class Initialized
DEBUG - 2016-11-25 23:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:22:39 --> Input Class Initialized
INFO - 2016-11-25 23:22:39 --> Language Class Initialized
INFO - 2016-11-25 23:22:39 --> Loader Class Initialized
INFO - 2016-11-25 23:22:39 --> Helper loaded: url_helper
INFO - 2016-11-25 23:22:39 --> Helper loaded: form_helper
INFO - 2016-11-25 23:22:39 --> Database Driver Class Initialized
INFO - 2016-11-25 23:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:22:39 --> Controller Class Initialized
INFO - 2016-11-25 23:22:39 --> Model Class Initialized
INFO - 2016-11-25 23:22:39 --> Model Class Initialized
INFO - 2016-11-25 23:22:39 --> Model Class Initialized
INFO - 2016-11-25 23:22:39 --> Model Class Initialized
INFO - 2016-11-25 23:22:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:22:39 --> Pagination Class Initialized
INFO - 2016-11-25 23:22:39 --> Helper loaded: app_helper
INFO - 2016-11-25 23:22:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 23:22:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-25 23:22:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-25 23:22:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-25 23:22:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-25 23:22:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-25 23:22:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-25 23:22:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-25 23:22:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-25 23:22:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-25 23:22:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 23:22:39 --> Final output sent to browser
DEBUG - 2016-11-25 23:22:39 --> Total execution time: 0.4538
INFO - 2016-11-25 23:24:42 --> Config Class Initialized
INFO - 2016-11-25 23:24:42 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:24:42 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:24:42 --> Utf8 Class Initialized
INFO - 2016-11-25 23:24:42 --> URI Class Initialized
INFO - 2016-11-25 23:24:42 --> Router Class Initialized
INFO - 2016-11-25 23:24:42 --> Output Class Initialized
INFO - 2016-11-25 23:24:42 --> Security Class Initialized
DEBUG - 2016-11-25 23:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:24:42 --> Input Class Initialized
INFO - 2016-11-25 23:24:42 --> Language Class Initialized
INFO - 2016-11-25 23:24:42 --> Loader Class Initialized
INFO - 2016-11-25 23:24:42 --> Helper loaded: url_helper
INFO - 2016-11-25 23:24:42 --> Helper loaded: form_helper
INFO - 2016-11-25 23:24:42 --> Database Driver Class Initialized
INFO - 2016-11-25 23:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:24:42 --> Controller Class Initialized
INFO - 2016-11-25 23:24:42 --> Model Class Initialized
INFO - 2016-11-25 23:24:42 --> Form Validation Class Initialized
INFO - 2016-11-25 23:24:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-25 23:24:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-25 23:24:42 --> Final output sent to browser
DEBUG - 2016-11-25 23:24:42 --> Total execution time: 0.4172
INFO - 2016-11-25 23:25:00 --> Config Class Initialized
INFO - 2016-11-25 23:25:00 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:25:00 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:25:00 --> Utf8 Class Initialized
INFO - 2016-11-25 23:25:00 --> URI Class Initialized
INFO - 2016-11-25 23:25:00 --> Router Class Initialized
INFO - 2016-11-25 23:25:00 --> Output Class Initialized
INFO - 2016-11-25 23:25:00 --> Security Class Initialized
DEBUG - 2016-11-25 23:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:25:00 --> Input Class Initialized
INFO - 2016-11-25 23:25:00 --> Language Class Initialized
INFO - 2016-11-25 23:25:00 --> Loader Class Initialized
INFO - 2016-11-25 23:25:00 --> Helper loaded: url_helper
INFO - 2016-11-25 23:25:00 --> Helper loaded: form_helper
INFO - 2016-11-25 23:25:00 --> Database Driver Class Initialized
INFO - 2016-11-25 23:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:25:00 --> Controller Class Initialized
INFO - 2016-11-25 23:25:00 --> Model Class Initialized
INFO - 2016-11-25 23:25:00 --> Model Class Initialized
INFO - 2016-11-25 23:25:00 --> Model Class Initialized
INFO - 2016-11-25 23:25:00 --> Model Class Initialized
INFO - 2016-11-25 23:25:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:25:00 --> Pagination Class Initialized
INFO - 2016-11-25 23:25:00 --> Helper loaded: app_helper
DEBUG - 2016-11-25 23:25:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-25 23:25:00 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-25 23:25:00 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-25 23:25:00 --> Config Class Initialized
INFO - 2016-11-25 23:25:00 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:25:00 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:25:00 --> Utf8 Class Initialized
INFO - 2016-11-25 23:25:00 --> URI Class Initialized
DEBUG - 2016-11-25 23:25:00 --> No URI present. Default controller set.
INFO - 2016-11-25 23:25:00 --> Router Class Initialized
INFO - 2016-11-25 23:25:00 --> Output Class Initialized
INFO - 2016-11-25 23:25:00 --> Security Class Initialized
DEBUG - 2016-11-25 23:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:25:00 --> Input Class Initialized
INFO - 2016-11-25 23:25:00 --> Language Class Initialized
INFO - 2016-11-25 23:25:00 --> Loader Class Initialized
INFO - 2016-11-25 23:25:00 --> Helper loaded: url_helper
INFO - 2016-11-25 23:25:00 --> Helper loaded: form_helper
INFO - 2016-11-25 23:25:00 --> Database Driver Class Initialized
INFO - 2016-11-25 23:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:25:00 --> Controller Class Initialized
INFO - 2016-11-25 23:25:00 --> Model Class Initialized
INFO - 2016-11-25 23:25:00 --> Model Class Initialized
INFO - 2016-11-25 23:25:00 --> Model Class Initialized
INFO - 2016-11-25 23:25:01 --> Model Class Initialized
INFO - 2016-11-25 23:25:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:25:01 --> Pagination Class Initialized
INFO - 2016-11-25 23:25:01 --> Helper loaded: app_helper
INFO - 2016-11-25 23:25:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 23:25:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-25 23:25:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 23:25:01 --> Final output sent to browser
DEBUG - 2016-11-25 23:25:01 --> Total execution time: 0.3442
INFO - 2016-11-25 23:25:37 --> Config Class Initialized
INFO - 2016-11-25 23:25:37 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:25:37 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:25:37 --> Utf8 Class Initialized
INFO - 2016-11-25 23:25:37 --> URI Class Initialized
INFO - 2016-11-25 23:25:37 --> Router Class Initialized
INFO - 2016-11-25 23:25:37 --> Output Class Initialized
INFO - 2016-11-25 23:25:37 --> Security Class Initialized
DEBUG - 2016-11-25 23:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:25:37 --> Input Class Initialized
INFO - 2016-11-25 23:25:37 --> Language Class Initialized
INFO - 2016-11-25 23:25:37 --> Loader Class Initialized
INFO - 2016-11-25 23:25:37 --> Helper loaded: url_helper
INFO - 2016-11-25 23:25:37 --> Helper loaded: form_helper
INFO - 2016-11-25 23:25:37 --> Database Driver Class Initialized
INFO - 2016-11-25 23:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:25:37 --> Controller Class Initialized
INFO - 2016-11-25 23:25:37 --> Model Class Initialized
INFO - 2016-11-25 23:25:37 --> Model Class Initialized
INFO - 2016-11-25 23:25:37 --> Model Class Initialized
INFO - 2016-11-25 23:25:37 --> Model Class Initialized
INFO - 2016-11-25 23:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:25:37 --> Pagination Class Initialized
INFO - 2016-11-25 23:25:37 --> Helper loaded: app_helper
DEBUG - 2016-11-25 23:25:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-25 23:25:37 --> Model Class Initialized
INFO - 2016-11-25 23:25:37 --> Final output sent to browser
DEBUG - 2016-11-25 23:25:37 --> Total execution time: 0.3094
INFO - 2016-11-25 23:25:37 --> Config Class Initialized
INFO - 2016-11-25 23:25:37 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:25:37 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:25:37 --> Utf8 Class Initialized
INFO - 2016-11-25 23:25:37 --> URI Class Initialized
DEBUG - 2016-11-25 23:25:37 --> No URI present. Default controller set.
INFO - 2016-11-25 23:25:37 --> Router Class Initialized
INFO - 2016-11-25 23:25:37 --> Output Class Initialized
INFO - 2016-11-25 23:25:37 --> Security Class Initialized
DEBUG - 2016-11-25 23:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:25:38 --> Input Class Initialized
INFO - 2016-11-25 23:25:38 --> Language Class Initialized
INFO - 2016-11-25 23:25:38 --> Loader Class Initialized
INFO - 2016-11-25 23:25:38 --> Helper loaded: url_helper
INFO - 2016-11-25 23:25:38 --> Helper loaded: form_helper
INFO - 2016-11-25 23:25:38 --> Database Driver Class Initialized
INFO - 2016-11-25 23:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:25:38 --> Controller Class Initialized
INFO - 2016-11-25 23:25:38 --> Model Class Initialized
INFO - 2016-11-25 23:25:38 --> Model Class Initialized
INFO - 2016-11-25 23:25:38 --> Model Class Initialized
INFO - 2016-11-25 23:25:38 --> Model Class Initialized
INFO - 2016-11-25 23:25:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:25:38 --> Pagination Class Initialized
INFO - 2016-11-25 23:25:38 --> Helper loaded: app_helper
INFO - 2016-11-25 23:25:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 23:25:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-25 23:25:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-25 23:25:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-25 23:25:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 23:25:38 --> Final output sent to browser
DEBUG - 2016-11-25 23:25:38 --> Total execution time: 0.3642
INFO - 2016-11-25 23:27:40 --> Config Class Initialized
INFO - 2016-11-25 23:27:40 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:27:40 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:27:40 --> Utf8 Class Initialized
INFO - 2016-11-25 23:27:40 --> URI Class Initialized
DEBUG - 2016-11-25 23:27:40 --> No URI present. Default controller set.
INFO - 2016-11-25 23:27:40 --> Router Class Initialized
INFO - 2016-11-25 23:27:40 --> Output Class Initialized
INFO - 2016-11-25 23:27:40 --> Security Class Initialized
DEBUG - 2016-11-25 23:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:27:40 --> Input Class Initialized
INFO - 2016-11-25 23:27:40 --> Language Class Initialized
INFO - 2016-11-25 23:27:40 --> Loader Class Initialized
INFO - 2016-11-25 23:27:40 --> Helper loaded: url_helper
INFO - 2016-11-25 23:27:40 --> Helper loaded: form_helper
INFO - 2016-11-25 23:27:40 --> Database Driver Class Initialized
INFO - 2016-11-25 23:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:27:40 --> Controller Class Initialized
INFO - 2016-11-25 23:27:40 --> Model Class Initialized
INFO - 2016-11-25 23:27:40 --> Model Class Initialized
INFO - 2016-11-25 23:27:40 --> Model Class Initialized
INFO - 2016-11-25 23:27:40 --> Model Class Initialized
INFO - 2016-11-25 23:27:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:27:40 --> Pagination Class Initialized
INFO - 2016-11-25 23:27:40 --> Helper loaded: app_helper
INFO - 2016-11-25 23:27:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 23:27:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-25 23:27:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-25 23:27:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-25 23:27:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 23:27:40 --> Final output sent to browser
DEBUG - 2016-11-25 23:27:40 --> Total execution time: 0.3624
INFO - 2016-11-25 23:30:06 --> Config Class Initialized
INFO - 2016-11-25 23:30:06 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:30:06 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:30:06 --> Utf8 Class Initialized
INFO - 2016-11-25 23:30:06 --> URI Class Initialized
DEBUG - 2016-11-25 23:30:06 --> No URI present. Default controller set.
INFO - 2016-11-25 23:30:06 --> Router Class Initialized
INFO - 2016-11-25 23:30:06 --> Output Class Initialized
INFO - 2016-11-25 23:30:06 --> Security Class Initialized
DEBUG - 2016-11-25 23:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:30:07 --> Input Class Initialized
INFO - 2016-11-25 23:30:07 --> Language Class Initialized
INFO - 2016-11-25 23:30:07 --> Loader Class Initialized
INFO - 2016-11-25 23:30:07 --> Helper loaded: url_helper
INFO - 2016-11-25 23:30:07 --> Helper loaded: form_helper
INFO - 2016-11-25 23:30:07 --> Database Driver Class Initialized
INFO - 2016-11-25 23:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:30:07 --> Controller Class Initialized
INFO - 2016-11-25 23:30:07 --> Model Class Initialized
INFO - 2016-11-25 23:30:07 --> Model Class Initialized
INFO - 2016-11-25 23:30:07 --> Model Class Initialized
INFO - 2016-11-25 23:30:07 --> Model Class Initialized
INFO - 2016-11-25 23:30:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:30:07 --> Pagination Class Initialized
INFO - 2016-11-25 23:30:07 --> Helper loaded: app_helper
INFO - 2016-11-25 23:30:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 23:30:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-25 23:30:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-25 23:30:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-25 23:30:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 23:30:07 --> Final output sent to browser
DEBUG - 2016-11-25 23:30:07 --> Total execution time: 0.3608
INFO - 2016-11-25 23:33:49 --> Config Class Initialized
INFO - 2016-11-25 23:33:49 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:33:49 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:33:49 --> Utf8 Class Initialized
INFO - 2016-11-25 23:33:49 --> URI Class Initialized
DEBUG - 2016-11-25 23:33:49 --> No URI present. Default controller set.
INFO - 2016-11-25 23:33:49 --> Router Class Initialized
INFO - 2016-11-25 23:33:49 --> Output Class Initialized
INFO - 2016-11-25 23:33:49 --> Security Class Initialized
DEBUG - 2016-11-25 23:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:33:49 --> Input Class Initialized
INFO - 2016-11-25 23:33:49 --> Language Class Initialized
INFO - 2016-11-25 23:33:49 --> Loader Class Initialized
INFO - 2016-11-25 23:33:49 --> Helper loaded: url_helper
INFO - 2016-11-25 23:33:49 --> Helper loaded: form_helper
INFO - 2016-11-25 23:33:49 --> Database Driver Class Initialized
INFO - 2016-11-25 23:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:33:49 --> Controller Class Initialized
INFO - 2016-11-25 23:33:49 --> Model Class Initialized
INFO - 2016-11-25 23:33:49 --> Model Class Initialized
INFO - 2016-11-25 23:33:49 --> Model Class Initialized
INFO - 2016-11-25 23:33:49 --> Model Class Initialized
INFO - 2016-11-25 23:33:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:33:49 --> Pagination Class Initialized
INFO - 2016-11-25 23:33:49 --> Helper loaded: app_helper
INFO - 2016-11-25 23:33:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 23:33:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-25 23:33:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-25 23:33:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-25 23:33:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-25 23:33:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-25 23:33:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 23:33:49 --> Final output sent to browser
DEBUG - 2016-11-25 23:33:49 --> Total execution time: 0.4135
INFO - 2016-11-25 23:34:00 --> Config Class Initialized
INFO - 2016-11-25 23:34:00 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:34:00 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:34:00 --> Utf8 Class Initialized
INFO - 2016-11-25 23:34:00 --> URI Class Initialized
DEBUG - 2016-11-25 23:34:00 --> No URI present. Default controller set.
INFO - 2016-11-25 23:34:00 --> Router Class Initialized
INFO - 2016-11-25 23:34:00 --> Output Class Initialized
INFO - 2016-11-25 23:34:00 --> Security Class Initialized
DEBUG - 2016-11-25 23:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:34:00 --> Input Class Initialized
INFO - 2016-11-25 23:34:00 --> Language Class Initialized
INFO - 2016-11-25 23:34:00 --> Loader Class Initialized
INFO - 2016-11-25 23:34:00 --> Helper loaded: url_helper
INFO - 2016-11-25 23:34:00 --> Helper loaded: form_helper
INFO - 2016-11-25 23:34:00 --> Database Driver Class Initialized
INFO - 2016-11-25 23:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:34:00 --> Controller Class Initialized
INFO - 2016-11-25 23:34:00 --> Model Class Initialized
INFO - 2016-11-25 23:34:00 --> Model Class Initialized
INFO - 2016-11-25 23:34:00 --> Model Class Initialized
INFO - 2016-11-25 23:34:00 --> Model Class Initialized
INFO - 2016-11-25 23:34:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:34:00 --> Pagination Class Initialized
INFO - 2016-11-25 23:34:00 --> Helper loaded: app_helper
INFO - 2016-11-25 23:34:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 23:34:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-25 23:34:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-25 23:34:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-25 23:34:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-25 23:34:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-25 23:34:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 23:34:00 --> Final output sent to browser
DEBUG - 2016-11-25 23:34:00 --> Total execution time: 0.3955
INFO - 2016-11-25 23:38:55 --> Config Class Initialized
INFO - 2016-11-25 23:38:55 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:38:55 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:38:55 --> Utf8 Class Initialized
INFO - 2016-11-25 23:38:55 --> URI Class Initialized
DEBUG - 2016-11-25 23:38:55 --> No URI present. Default controller set.
INFO - 2016-11-25 23:38:55 --> Router Class Initialized
INFO - 2016-11-25 23:38:55 --> Output Class Initialized
INFO - 2016-11-25 23:38:55 --> Security Class Initialized
DEBUG - 2016-11-25 23:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:38:55 --> Input Class Initialized
INFO - 2016-11-25 23:38:55 --> Language Class Initialized
INFO - 2016-11-25 23:38:55 --> Loader Class Initialized
INFO - 2016-11-25 23:38:55 --> Helper loaded: url_helper
INFO - 2016-11-25 23:38:55 --> Helper loaded: form_helper
INFO - 2016-11-25 23:38:55 --> Database Driver Class Initialized
INFO - 2016-11-25 23:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:38:55 --> Controller Class Initialized
INFO - 2016-11-25 23:38:55 --> Model Class Initialized
INFO - 2016-11-25 23:38:55 --> Model Class Initialized
INFO - 2016-11-25 23:38:55 --> Model Class Initialized
INFO - 2016-11-25 23:38:55 --> Model Class Initialized
INFO - 2016-11-25 23:38:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:38:55 --> Pagination Class Initialized
INFO - 2016-11-25 23:38:55 --> Helper loaded: app_helper
INFO - 2016-11-25 23:38:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 23:38:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-25 23:38:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-25 23:38:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-25 23:38:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-25 23:38:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-25 23:38:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 23:38:56 --> Final output sent to browser
DEBUG - 2016-11-25 23:38:56 --> Total execution time: 0.3850
INFO - 2016-11-25 23:40:34 --> Config Class Initialized
INFO - 2016-11-25 23:40:34 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:40:34 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:40:34 --> Utf8 Class Initialized
INFO - 2016-11-25 23:40:34 --> URI Class Initialized
DEBUG - 2016-11-25 23:40:34 --> No URI present. Default controller set.
INFO - 2016-11-25 23:40:34 --> Router Class Initialized
INFO - 2016-11-25 23:40:34 --> Output Class Initialized
INFO - 2016-11-25 23:40:34 --> Security Class Initialized
DEBUG - 2016-11-25 23:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:40:34 --> Input Class Initialized
INFO - 2016-11-25 23:40:34 --> Language Class Initialized
INFO - 2016-11-25 23:40:34 --> Loader Class Initialized
INFO - 2016-11-25 23:40:34 --> Helper loaded: url_helper
INFO - 2016-11-25 23:40:34 --> Helper loaded: form_helper
INFO - 2016-11-25 23:40:34 --> Database Driver Class Initialized
INFO - 2016-11-25 23:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:40:34 --> Controller Class Initialized
INFO - 2016-11-25 23:40:34 --> Model Class Initialized
INFO - 2016-11-25 23:40:34 --> Model Class Initialized
INFO - 2016-11-25 23:40:34 --> Model Class Initialized
INFO - 2016-11-25 23:40:34 --> Model Class Initialized
INFO - 2016-11-25 23:40:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:40:34 --> Pagination Class Initialized
INFO - 2016-11-25 23:40:34 --> Helper loaded: app_helper
INFO - 2016-11-25 23:40:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 23:40:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-25 23:40:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-25 23:40:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-25 23:40:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-25 23:40:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-25 23:40:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 23:40:34 --> Final output sent to browser
DEBUG - 2016-11-25 23:40:34 --> Total execution time: 0.3976
INFO - 2016-11-25 23:43:24 --> Config Class Initialized
INFO - 2016-11-25 23:43:24 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:43:24 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:43:24 --> Utf8 Class Initialized
INFO - 2016-11-25 23:43:24 --> URI Class Initialized
DEBUG - 2016-11-25 23:43:24 --> No URI present. Default controller set.
INFO - 2016-11-25 23:43:24 --> Router Class Initialized
INFO - 2016-11-25 23:43:24 --> Output Class Initialized
INFO - 2016-11-25 23:43:24 --> Security Class Initialized
DEBUG - 2016-11-25 23:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:43:24 --> Input Class Initialized
INFO - 2016-11-25 23:43:24 --> Language Class Initialized
INFO - 2016-11-25 23:43:24 --> Loader Class Initialized
INFO - 2016-11-25 23:43:24 --> Helper loaded: url_helper
INFO - 2016-11-25 23:43:24 --> Helper loaded: form_helper
INFO - 2016-11-25 23:43:24 --> Database Driver Class Initialized
INFO - 2016-11-25 23:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:43:24 --> Controller Class Initialized
INFO - 2016-11-25 23:43:24 --> Model Class Initialized
INFO - 2016-11-25 23:43:24 --> Model Class Initialized
INFO - 2016-11-25 23:43:24 --> Model Class Initialized
INFO - 2016-11-25 23:43:24 --> Model Class Initialized
INFO - 2016-11-25 23:43:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:43:24 --> Pagination Class Initialized
INFO - 2016-11-25 23:43:24 --> Helper loaded: app_helper
INFO - 2016-11-25 23:43:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 23:43:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-25 23:43:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-25 23:43:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-25 23:43:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-25 23:43:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-25 23:43:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 23:43:25 --> Final output sent to browser
DEBUG - 2016-11-25 23:43:25 --> Total execution time: 0.4121
INFO - 2016-11-25 23:43:28 --> Config Class Initialized
INFO - 2016-11-25 23:43:28 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:43:28 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:43:28 --> Utf8 Class Initialized
INFO - 2016-11-25 23:43:28 --> URI Class Initialized
DEBUG - 2016-11-25 23:43:28 --> No URI present. Default controller set.
INFO - 2016-11-25 23:43:28 --> Router Class Initialized
INFO - 2016-11-25 23:43:28 --> Output Class Initialized
INFO - 2016-11-25 23:43:28 --> Security Class Initialized
DEBUG - 2016-11-25 23:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:43:28 --> Input Class Initialized
INFO - 2016-11-25 23:43:28 --> Language Class Initialized
INFO - 2016-11-25 23:43:28 --> Loader Class Initialized
INFO - 2016-11-25 23:43:28 --> Helper loaded: url_helper
INFO - 2016-11-25 23:43:28 --> Helper loaded: form_helper
INFO - 2016-11-25 23:43:28 --> Database Driver Class Initialized
INFO - 2016-11-25 23:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:43:28 --> Controller Class Initialized
INFO - 2016-11-25 23:43:28 --> Model Class Initialized
INFO - 2016-11-25 23:43:28 --> Model Class Initialized
INFO - 2016-11-25 23:43:28 --> Model Class Initialized
INFO - 2016-11-25 23:43:28 --> Model Class Initialized
INFO - 2016-11-25 23:43:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:43:28 --> Pagination Class Initialized
INFO - 2016-11-25 23:43:28 --> Helper loaded: app_helper
INFO - 2016-11-25 23:43:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 23:43:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-25 23:43:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-25 23:43:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-25 23:43:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-25 23:43:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-25 23:43:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 23:43:28 --> Final output sent to browser
DEBUG - 2016-11-25 23:43:28 --> Total execution time: 0.4274
INFO - 2016-11-25 23:47:22 --> Config Class Initialized
INFO - 2016-11-25 23:47:22 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:47:22 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:47:22 --> Utf8 Class Initialized
INFO - 2016-11-25 23:47:22 --> URI Class Initialized
DEBUG - 2016-11-25 23:47:22 --> No URI present. Default controller set.
INFO - 2016-11-25 23:47:22 --> Router Class Initialized
INFO - 2016-11-25 23:47:22 --> Output Class Initialized
INFO - 2016-11-25 23:47:22 --> Security Class Initialized
DEBUG - 2016-11-25 23:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:47:22 --> Input Class Initialized
INFO - 2016-11-25 23:47:22 --> Language Class Initialized
INFO - 2016-11-25 23:47:22 --> Loader Class Initialized
INFO - 2016-11-25 23:47:22 --> Helper loaded: url_helper
INFO - 2016-11-25 23:47:22 --> Helper loaded: form_helper
INFO - 2016-11-25 23:47:22 --> Database Driver Class Initialized
INFO - 2016-11-25 23:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:47:22 --> Controller Class Initialized
INFO - 2016-11-25 23:47:22 --> Model Class Initialized
INFO - 2016-11-25 23:47:22 --> Model Class Initialized
INFO - 2016-11-25 23:47:22 --> Model Class Initialized
INFO - 2016-11-25 23:47:22 --> Model Class Initialized
INFO - 2016-11-25 23:47:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:47:22 --> Pagination Class Initialized
INFO - 2016-11-25 23:47:23 --> Helper loaded: app_helper
INFO - 2016-11-25 23:47:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 23:47:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-25 23:47:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-25 23:47:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-25 23:47:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-25 23:47:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-25 23:47:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 23:47:23 --> Final output sent to browser
DEBUG - 2016-11-25 23:47:23 --> Total execution time: 0.4249
INFO - 2016-11-25 23:52:21 --> Config Class Initialized
INFO - 2016-11-25 23:52:21 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:52:21 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:52:21 --> Utf8 Class Initialized
INFO - 2016-11-25 23:52:21 --> URI Class Initialized
DEBUG - 2016-11-25 23:52:21 --> No URI present. Default controller set.
INFO - 2016-11-25 23:52:21 --> Router Class Initialized
INFO - 2016-11-25 23:52:21 --> Output Class Initialized
INFO - 2016-11-25 23:52:21 --> Security Class Initialized
DEBUG - 2016-11-25 23:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:52:21 --> Input Class Initialized
INFO - 2016-11-25 23:52:21 --> Language Class Initialized
INFO - 2016-11-25 23:52:21 --> Loader Class Initialized
INFO - 2016-11-25 23:52:21 --> Helper loaded: url_helper
INFO - 2016-11-25 23:52:21 --> Helper loaded: form_helper
INFO - 2016-11-25 23:52:21 --> Database Driver Class Initialized
INFO - 2016-11-25 23:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:52:21 --> Controller Class Initialized
INFO - 2016-11-25 23:52:21 --> Model Class Initialized
INFO - 2016-11-25 23:52:21 --> Model Class Initialized
INFO - 2016-11-25 23:52:21 --> Model Class Initialized
INFO - 2016-11-25 23:52:21 --> Model Class Initialized
INFO - 2016-11-25 23:52:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:52:21 --> Pagination Class Initialized
INFO - 2016-11-25 23:52:21 --> Helper loaded: app_helper
INFO - 2016-11-25 23:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 23:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-25 23:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-25 23:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-25 23:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-25 23:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-25 23:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 23:52:21 --> Final output sent to browser
DEBUG - 2016-11-25 23:52:21 --> Total execution time: 0.4293
INFO - 2016-11-25 23:53:36 --> Config Class Initialized
INFO - 2016-11-25 23:53:36 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:53:36 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:53:36 --> Utf8 Class Initialized
INFO - 2016-11-25 23:53:36 --> URI Class Initialized
DEBUG - 2016-11-25 23:53:36 --> No URI present. Default controller set.
INFO - 2016-11-25 23:53:36 --> Router Class Initialized
INFO - 2016-11-25 23:53:36 --> Output Class Initialized
INFO - 2016-11-25 23:53:36 --> Security Class Initialized
DEBUG - 2016-11-25 23:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:53:36 --> Input Class Initialized
INFO - 2016-11-25 23:53:36 --> Language Class Initialized
INFO - 2016-11-25 23:53:36 --> Loader Class Initialized
INFO - 2016-11-25 23:53:36 --> Helper loaded: url_helper
INFO - 2016-11-25 23:53:36 --> Helper loaded: form_helper
INFO - 2016-11-25 23:53:36 --> Database Driver Class Initialized
INFO - 2016-11-25 23:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:53:36 --> Controller Class Initialized
INFO - 2016-11-25 23:53:36 --> Model Class Initialized
INFO - 2016-11-25 23:53:36 --> Model Class Initialized
INFO - 2016-11-25 23:53:36 --> Model Class Initialized
INFO - 2016-11-25 23:53:36 --> Model Class Initialized
INFO - 2016-11-25 23:53:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:53:36 --> Pagination Class Initialized
INFO - 2016-11-25 23:53:36 --> Helper loaded: app_helper
INFO - 2016-11-25 23:53:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 23:53:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-25 23:53:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-25 23:53:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-25 23:53:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-25 23:53:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-25 23:53:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 23:53:36 --> Final output sent to browser
DEBUG - 2016-11-25 23:53:36 --> Total execution time: 0.4209
INFO - 2016-11-25 23:58:05 --> Config Class Initialized
INFO - 2016-11-25 23:58:05 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:58:05 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:58:05 --> Utf8 Class Initialized
INFO - 2016-11-25 23:58:05 --> URI Class Initialized
INFO - 2016-11-25 23:58:05 --> Router Class Initialized
INFO - 2016-11-25 23:58:05 --> Output Class Initialized
INFO - 2016-11-25 23:58:05 --> Security Class Initialized
DEBUG - 2016-11-25 23:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:58:05 --> Input Class Initialized
INFO - 2016-11-25 23:58:05 --> Language Class Initialized
INFO - 2016-11-25 23:58:05 --> Loader Class Initialized
INFO - 2016-11-25 23:58:05 --> Helper loaded: url_helper
INFO - 2016-11-25 23:58:05 --> Helper loaded: form_helper
INFO - 2016-11-25 23:58:05 --> Database Driver Class Initialized
INFO - 2016-11-25 23:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:58:05 --> Controller Class Initialized
INFO - 2016-11-25 23:58:05 --> Model Class Initialized
INFO - 2016-11-25 23:58:05 --> Form Validation Class Initialized
INFO - 2016-11-25 23:58:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-25 23:58:06 --> Final output sent to browser
DEBUG - 2016-11-25 23:58:06 --> Total execution time: 0.2438
INFO - 2016-11-25 23:59:08 --> Config Class Initialized
INFO - 2016-11-25 23:59:08 --> Hooks Class Initialized
DEBUG - 2016-11-25 23:59:08 --> UTF-8 Support Enabled
INFO - 2016-11-25 23:59:08 --> Utf8 Class Initialized
INFO - 2016-11-25 23:59:08 --> URI Class Initialized
DEBUG - 2016-11-25 23:59:08 --> No URI present. Default controller set.
INFO - 2016-11-25 23:59:08 --> Router Class Initialized
INFO - 2016-11-25 23:59:08 --> Output Class Initialized
INFO - 2016-11-25 23:59:08 --> Security Class Initialized
DEBUG - 2016-11-25 23:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-25 23:59:08 --> Input Class Initialized
INFO - 2016-11-25 23:59:08 --> Language Class Initialized
INFO - 2016-11-25 23:59:08 --> Loader Class Initialized
INFO - 2016-11-25 23:59:08 --> Helper loaded: url_helper
INFO - 2016-11-25 23:59:08 --> Helper loaded: form_helper
INFO - 2016-11-25 23:59:08 --> Database Driver Class Initialized
INFO - 2016-11-25 23:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-25 23:59:08 --> Controller Class Initialized
INFO - 2016-11-25 23:59:08 --> Model Class Initialized
INFO - 2016-11-25 23:59:08 --> Model Class Initialized
INFO - 2016-11-25 23:59:08 --> Model Class Initialized
INFO - 2016-11-25 23:59:08 --> Model Class Initialized
INFO - 2016-11-25 23:59:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-25 23:59:08 --> Pagination Class Initialized
INFO - 2016-11-25 23:59:08 --> Helper loaded: app_helper
INFO - 2016-11-25 23:59:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-25 23:59:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-25 23:59:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-25 23:59:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-25 23:59:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-25 23:59:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-25 23:59:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-25 23:59:08 --> Final output sent to browser
DEBUG - 2016-11-25 23:59:08 --> Total execution time: 0.4199
