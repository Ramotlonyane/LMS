<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-18 09:36:29 --> Config Class Initialized
INFO - 2016-11-18 09:36:29 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:36:29 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:36:29 --> Utf8 Class Initialized
INFO - 2016-11-18 09:36:30 --> URI Class Initialized
DEBUG - 2016-11-18 09:36:30 --> No URI present. Default controller set.
INFO - 2016-11-18 09:36:30 --> Router Class Initialized
INFO - 2016-11-18 09:36:30 --> Output Class Initialized
INFO - 2016-11-18 09:36:30 --> Security Class Initialized
DEBUG - 2016-11-18 09:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:36:30 --> Input Class Initialized
INFO - 2016-11-18 09:36:30 --> Language Class Initialized
INFO - 2016-11-18 09:36:30 --> Loader Class Initialized
INFO - 2016-11-18 09:36:30 --> Helper loaded: url_helper
INFO - 2016-11-18 09:36:31 --> Helper loaded: form_helper
INFO - 2016-11-18 09:36:31 --> Database Driver Class Initialized
INFO - 2016-11-18 09:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:36:31 --> Controller Class Initialized
INFO - 2016-11-18 09:36:31 --> Model Class Initialized
INFO - 2016-11-18 09:36:31 --> Model Class Initialized
INFO - 2016-11-18 09:36:32 --> Model Class Initialized
INFO - 2016-11-18 09:36:32 --> Model Class Initialized
INFO - 2016-11-18 09:36:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 09:36:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 09:36:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 09:36:32 --> Final output sent to browser
DEBUG - 2016-11-18 09:36:32 --> Total execution time: 2.6277
INFO - 2016-11-18 09:37:08 --> Config Class Initialized
INFO - 2016-11-18 09:37:08 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:37:08 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:37:08 --> Utf8 Class Initialized
INFO - 2016-11-18 09:37:08 --> URI Class Initialized
INFO - 2016-11-18 09:37:08 --> Router Class Initialized
INFO - 2016-11-18 09:37:08 --> Output Class Initialized
INFO - 2016-11-18 09:37:08 --> Security Class Initialized
DEBUG - 2016-11-18 09:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:37:08 --> Input Class Initialized
INFO - 2016-11-18 09:37:08 --> Language Class Initialized
INFO - 2016-11-18 09:37:08 --> Loader Class Initialized
INFO - 2016-11-18 09:37:08 --> Helper loaded: url_helper
INFO - 2016-11-18 09:37:08 --> Helper loaded: form_helper
INFO - 2016-11-18 09:37:08 --> Database Driver Class Initialized
INFO - 2016-11-18 09:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:37:08 --> Controller Class Initialized
INFO - 2016-11-18 09:37:08 --> Model Class Initialized
INFO - 2016-11-18 09:37:08 --> Model Class Initialized
INFO - 2016-11-18 09:37:08 --> Model Class Initialized
INFO - 2016-11-18 09:37:08 --> Model Class Initialized
DEBUG - 2016-11-18 09:37:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-18 09:37:08 --> Model Class Initialized
INFO - 2016-11-18 09:37:09 --> Final output sent to browser
DEBUG - 2016-11-18 09:37:09 --> Total execution time: 0.7376
INFO - 2016-11-18 09:37:09 --> Config Class Initialized
INFO - 2016-11-18 09:37:09 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:37:09 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:37:09 --> Utf8 Class Initialized
INFO - 2016-11-18 09:37:09 --> URI Class Initialized
DEBUG - 2016-11-18 09:37:09 --> No URI present. Default controller set.
INFO - 2016-11-18 09:37:09 --> Router Class Initialized
INFO - 2016-11-18 09:37:09 --> Output Class Initialized
INFO - 2016-11-18 09:37:09 --> Security Class Initialized
DEBUG - 2016-11-18 09:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:37:09 --> Input Class Initialized
INFO - 2016-11-18 09:37:09 --> Language Class Initialized
INFO - 2016-11-18 09:37:09 --> Loader Class Initialized
INFO - 2016-11-18 09:37:09 --> Helper loaded: url_helper
INFO - 2016-11-18 09:37:09 --> Helper loaded: form_helper
INFO - 2016-11-18 09:37:09 --> Database Driver Class Initialized
INFO - 2016-11-18 09:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:37:09 --> Controller Class Initialized
INFO - 2016-11-18 09:37:09 --> Model Class Initialized
INFO - 2016-11-18 09:37:09 --> Model Class Initialized
INFO - 2016-11-18 09:37:09 --> Model Class Initialized
INFO - 2016-11-18 09:37:09 --> Model Class Initialized
INFO - 2016-11-18 09:37:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 09:37:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 09:37:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 09:37:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 09:37:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 09:37:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 09:37:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 09:37:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 09:37:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 09:37:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 09:37:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 09:37:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 09:37:10 --> Final output sent to browser
DEBUG - 2016-11-18 09:37:10 --> Total execution time: 1.4495
INFO - 2016-11-18 09:37:13 --> Config Class Initialized
INFO - 2016-11-18 09:37:13 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:37:13 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:37:13 --> Utf8 Class Initialized
INFO - 2016-11-18 09:37:13 --> URI Class Initialized
DEBUG - 2016-11-18 09:37:13 --> No URI present. Default controller set.
INFO - 2016-11-18 09:37:13 --> Router Class Initialized
INFO - 2016-11-18 09:37:13 --> Output Class Initialized
INFO - 2016-11-18 09:37:13 --> Security Class Initialized
DEBUG - 2016-11-18 09:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:37:13 --> Input Class Initialized
INFO - 2016-11-18 09:37:13 --> Language Class Initialized
INFO - 2016-11-18 09:37:13 --> Loader Class Initialized
INFO - 2016-11-18 09:37:13 --> Helper loaded: url_helper
INFO - 2016-11-18 09:37:13 --> Helper loaded: form_helper
INFO - 2016-11-18 09:37:13 --> Database Driver Class Initialized
INFO - 2016-11-18 09:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:37:13 --> Controller Class Initialized
INFO - 2016-11-18 09:37:13 --> Model Class Initialized
INFO - 2016-11-18 09:37:13 --> Model Class Initialized
INFO - 2016-11-18 09:37:13 --> Model Class Initialized
INFO - 2016-11-18 09:37:13 --> Model Class Initialized
INFO - 2016-11-18 09:37:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 09:37:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 09:37:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 09:37:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 09:37:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 09:37:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 09:37:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 09:37:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 09:37:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 09:37:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 09:37:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 09:37:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 09:37:13 --> Final output sent to browser
DEBUG - 2016-11-18 09:37:13 --> Total execution time: 0.3286
INFO - 2016-11-18 09:38:49 --> Config Class Initialized
INFO - 2016-11-18 09:38:49 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:38:49 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:38:49 --> Utf8 Class Initialized
INFO - 2016-11-18 09:38:49 --> URI Class Initialized
DEBUG - 2016-11-18 09:38:49 --> No URI present. Default controller set.
INFO - 2016-11-18 09:38:49 --> Router Class Initialized
INFO - 2016-11-18 09:38:49 --> Output Class Initialized
INFO - 2016-11-18 09:38:49 --> Security Class Initialized
DEBUG - 2016-11-18 09:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:38:49 --> Input Class Initialized
INFO - 2016-11-18 09:38:49 --> Language Class Initialized
INFO - 2016-11-18 09:38:49 --> Loader Class Initialized
INFO - 2016-11-18 09:38:49 --> Helper loaded: url_helper
INFO - 2016-11-18 09:38:49 --> Helper loaded: form_helper
INFO - 2016-11-18 09:38:49 --> Database Driver Class Initialized
INFO - 2016-11-18 09:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:38:49 --> Controller Class Initialized
INFO - 2016-11-18 09:38:49 --> Model Class Initialized
INFO - 2016-11-18 09:38:49 --> Model Class Initialized
INFO - 2016-11-18 09:38:49 --> Model Class Initialized
INFO - 2016-11-18 09:38:49 --> Model Class Initialized
INFO - 2016-11-18 09:38:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 09:38:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 09:38:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 09:38:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 09:38:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 09:38:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 09:38:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 09:38:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 09:38:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 09:38:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 09:38:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 09:38:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 09:38:49 --> Final output sent to browser
DEBUG - 2016-11-18 09:38:49 --> Total execution time: 0.3272
INFO - 2016-11-18 09:38:53 --> Config Class Initialized
INFO - 2016-11-18 09:38:53 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:38:53 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:38:53 --> Utf8 Class Initialized
INFO - 2016-11-18 09:38:53 --> URI Class Initialized
INFO - 2016-11-18 09:38:53 --> Router Class Initialized
INFO - 2016-11-18 09:38:53 --> Output Class Initialized
INFO - 2016-11-18 09:38:53 --> Security Class Initialized
DEBUG - 2016-11-18 09:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:38:53 --> Input Class Initialized
INFO - 2016-11-18 09:38:53 --> Language Class Initialized
INFO - 2016-11-18 09:38:53 --> Loader Class Initialized
INFO - 2016-11-18 09:38:53 --> Helper loaded: url_helper
INFO - 2016-11-18 09:38:53 --> Helper loaded: form_helper
INFO - 2016-11-18 09:38:53 --> Database Driver Class Initialized
INFO - 2016-11-18 09:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:38:53 --> Controller Class Initialized
INFO - 2016-11-18 09:38:53 --> Model Class Initialized
INFO - 2016-11-18 09:38:53 --> Form Validation Class Initialized
INFO - 2016-11-18 09:38:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 09:38:53 --> Final output sent to browser
DEBUG - 2016-11-18 09:38:53 --> Total execution time: 0.3362
INFO - 2016-11-18 09:39:08 --> Config Class Initialized
INFO - 2016-11-18 09:39:08 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:39:08 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:39:08 --> Utf8 Class Initialized
INFO - 2016-11-18 09:39:08 --> URI Class Initialized
INFO - 2016-11-18 09:39:08 --> Router Class Initialized
INFO - 2016-11-18 09:39:08 --> Output Class Initialized
INFO - 2016-11-18 09:39:08 --> Security Class Initialized
DEBUG - 2016-11-18 09:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:39:08 --> Input Class Initialized
INFO - 2016-11-18 09:39:08 --> Language Class Initialized
INFO - 2016-11-18 09:39:08 --> Loader Class Initialized
INFO - 2016-11-18 09:39:08 --> Helper loaded: url_helper
INFO - 2016-11-18 09:39:08 --> Helper loaded: form_helper
INFO - 2016-11-18 09:39:08 --> Database Driver Class Initialized
INFO - 2016-11-18 09:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:39:08 --> Controller Class Initialized
INFO - 2016-11-18 09:39:08 --> Model Class Initialized
INFO - 2016-11-18 09:39:08 --> Form Validation Class Initialized
INFO - 2016-11-18 09:39:08 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-18 09:39:08 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-18 09:39:09 --> Config Class Initialized
INFO - 2016-11-18 09:39:09 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:39:09 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:39:09 --> Utf8 Class Initialized
ERROR - 2016-11-18 09:39:09 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-05', '5', '1', '2016-11-18 09:39:08', '1', '')
INFO - 2016-11-18 09:39:09 --> URI Class Initialized
INFO - 2016-11-18 09:39:09 --> Router Class Initialized
INFO - 2016-11-18 09:39:09 --> Output Class Initialized
INFO - 2016-11-18 09:39:09 --> Security Class Initialized
DEBUG - 2016-11-18 09:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:39:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-18 09:39:09 --> Input Class Initialized
INFO - 2016-11-18 09:39:09 --> Language Class Initialized
INFO - 2016-11-18 09:39:09 --> Loader Class Initialized
INFO - 2016-11-18 09:39:09 --> Helper loaded: url_helper
INFO - 2016-11-18 09:39:09 --> Helper loaded: form_helper
INFO - 2016-11-18 09:39:09 --> Database Driver Class Initialized
INFO - 2016-11-18 09:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:39:09 --> Controller Class Initialized
INFO - 2016-11-18 09:39:09 --> Model Class Initialized
INFO - 2016-11-18 09:39:09 --> Form Validation Class Initialized
INFO - 2016-11-18 09:39:09 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-18 09:39:09 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-18 09:39:09 --> Config Class Initialized
INFO - 2016-11-18 09:39:09 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:39:09 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:39:09 --> Utf8 Class Initialized
INFO - 2016-11-18 09:39:09 --> URI Class Initialized
INFO - 2016-11-18 09:39:09 --> Router Class Initialized
INFO - 2016-11-18 09:39:09 --> Output Class Initialized
INFO - 2016-11-18 09:39:09 --> Security Class Initialized
DEBUG - 2016-11-18 09:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:39:09 --> Input Class Initialized
INFO - 2016-11-18 09:39:09 --> Language Class Initialized
INFO - 2016-11-18 09:39:09 --> Loader Class Initialized
INFO - 2016-11-18 09:39:09 --> Helper loaded: url_helper
INFO - 2016-11-18 09:39:09 --> Helper loaded: form_helper
INFO - 2016-11-18 09:39:09 --> Database Driver Class Initialized
ERROR - 2016-11-18 09:39:09 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-05', '5', '1', '2016-11-18 09:39:09', '1', '')
INFO - 2016-11-18 09:39:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-18 09:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:39:09 --> Controller Class Initialized
INFO - 2016-11-18 09:39:09 --> Config Class Initialized
INFO - 2016-11-18 09:39:09 --> Model Class Initialized
INFO - 2016-11-18 09:39:09 --> Hooks Class Initialized
INFO - 2016-11-18 09:39:09 --> Form Validation Class Initialized
DEBUG - 2016-11-18 09:39:09 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:39:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 09:39:09 --> Utf8 Class Initialized
INFO - 2016-11-18 09:39:09 --> URI Class Initialized
ERROR - 2016-11-18 09:39:09 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-18 09:39:09 --> Router Class Initialized
INFO - 2016-11-18 09:39:09 --> Output Class Initialized
INFO - 2016-11-18 09:39:09 --> Security Class Initialized
DEBUG - 2016-11-18 09:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:39:09 --> Input Class Initialized
INFO - 2016-11-18 09:39:09 --> Language Class Initialized
INFO - 2016-11-18 09:39:09 --> Loader Class Initialized
INFO - 2016-11-18 09:39:09 --> Helper loaded: url_helper
INFO - 2016-11-18 09:39:09 --> Helper loaded: form_helper
ERROR - 2016-11-18 09:39:09 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-05', '5', '1', '2016-11-18 09:39:09', '1', '')
INFO - 2016-11-18 09:39:09 --> Database Driver Class Initialized
INFO - 2016-11-18 09:39:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-18 09:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:39:10 --> Controller Class Initialized
INFO - 2016-11-18 09:39:10 --> Config Class Initialized
INFO - 2016-11-18 09:39:10 --> Model Class Initialized
INFO - 2016-11-18 09:39:10 --> Hooks Class Initialized
INFO - 2016-11-18 09:39:10 --> Form Validation Class Initialized
DEBUG - 2016-11-18 09:39:10 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:39:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 09:39:10 --> Utf8 Class Initialized
ERROR - 2016-11-18 09:39:10 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-18 09:39:10 --> URI Class Initialized
INFO - 2016-11-18 09:39:10 --> Router Class Initialized
INFO - 2016-11-18 09:39:10 --> Output Class Initialized
INFO - 2016-11-18 09:39:10 --> Security Class Initialized
DEBUG - 2016-11-18 09:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:39:10 --> Input Class Initialized
INFO - 2016-11-18 09:39:10 --> Language Class Initialized
INFO - 2016-11-18 09:39:10 --> Loader Class Initialized
ERROR - 2016-11-18 09:39:10 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-05', '5', '1', '2016-11-18 09:39:10', '1', '')
INFO - 2016-11-18 09:39:10 --> Helper loaded: url_helper
INFO - 2016-11-18 09:39:10 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-18 09:39:10 --> Helper loaded: form_helper
INFO - 2016-11-18 09:39:10 --> Config Class Initialized
INFO - 2016-11-18 09:39:10 --> Database Driver Class Initialized
INFO - 2016-11-18 09:39:10 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:39:10 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:39:10 --> Utf8 Class Initialized
INFO - 2016-11-18 09:39:10 --> Controller Class Initialized
INFO - 2016-11-18 09:39:10 --> URI Class Initialized
INFO - 2016-11-18 09:39:10 --> Model Class Initialized
INFO - 2016-11-18 09:39:10 --> Router Class Initialized
INFO - 2016-11-18 09:39:10 --> Form Validation Class Initialized
INFO - 2016-11-18 09:39:10 --> Output Class Initialized
INFO - 2016-11-18 09:39:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 09:39:10 --> Security Class Initialized
ERROR - 2016-11-18 09:39:10 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
DEBUG - 2016-11-18 09:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:39:10 --> Input Class Initialized
INFO - 2016-11-18 09:39:10 --> Language Class Initialized
INFO - 2016-11-18 09:39:10 --> Config Class Initialized
INFO - 2016-11-18 09:39:10 --> Loader Class Initialized
INFO - 2016-11-18 09:39:10 --> Hooks Class Initialized
INFO - 2016-11-18 09:39:10 --> Helper loaded: url_helper
ERROR - 2016-11-18 09:39:10 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-05', '5', '1', '2016-11-18 09:39:10', '1', '')
DEBUG - 2016-11-18 09:39:10 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:39:10 --> Helper loaded: form_helper
INFO - 2016-11-18 09:39:10 --> Utf8 Class Initialized
INFO - 2016-11-18 09:39:10 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-18 09:39:10 --> URI Class Initialized
INFO - 2016-11-18 09:39:10 --> Database Driver Class Initialized
INFO - 2016-11-18 09:39:10 --> Router Class Initialized
INFO - 2016-11-18 09:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:39:10 --> Output Class Initialized
INFO - 2016-11-18 09:39:10 --> Controller Class Initialized
INFO - 2016-11-18 09:39:10 --> Model Class Initialized
INFO - 2016-11-18 09:39:10 --> Security Class Initialized
INFO - 2016-11-18 09:39:10 --> Form Validation Class Initialized
INFO - 2016-11-18 09:39:10 --> Config Class Initialized
DEBUG - 2016-11-18 09:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:39:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 09:39:10 --> Input Class Initialized
INFO - 2016-11-18 09:39:10 --> Hooks Class Initialized
INFO - 2016-11-18 09:39:10 --> Language Class Initialized
DEBUG - 2016-11-18 09:39:10 --> UTF-8 Support Enabled
ERROR - 2016-11-18 09:39:10 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-18 09:39:10 --> Utf8 Class Initialized
INFO - 2016-11-18 09:39:10 --> Loader Class Initialized
INFO - 2016-11-18 09:39:10 --> URI Class Initialized
INFO - 2016-11-18 09:39:10 --> Helper loaded: url_helper
INFO - 2016-11-18 09:39:10 --> Router Class Initialized
INFO - 2016-11-18 09:39:10 --> Helper loaded: form_helper
INFO - 2016-11-18 09:39:10 --> Output Class Initialized
INFO - 2016-11-18 09:39:10 --> Database Driver Class Initialized
INFO - 2016-11-18 09:39:10 --> Security Class Initialized
ERROR - 2016-11-18 09:39:10 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-05', '5', '1', '2016-11-18 09:39:10', '1', '')
DEBUG - 2016-11-18 09:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:39:10 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-18 09:39:10 --> Input Class Initialized
INFO - 2016-11-18 09:39:10 --> Language Class Initialized
INFO - 2016-11-18 09:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:39:10 --> Loader Class Initialized
INFO - 2016-11-18 09:39:10 --> Controller Class Initialized
INFO - 2016-11-18 09:39:10 --> Model Class Initialized
INFO - 2016-11-18 09:39:10 --> Helper loaded: url_helper
INFO - 2016-11-18 09:39:10 --> Helper loaded: form_helper
INFO - 2016-11-18 09:39:10 --> Form Validation Class Initialized
INFO - 2016-11-18 09:39:10 --> Database Driver Class Initialized
INFO - 2016-11-18 09:39:10 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-18 09:39:10 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-18 09:39:10 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-05', '5', '1', '2016-11-18 09:39:10', '1', '')
INFO - 2016-11-18 09:39:10 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-18 09:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:39:10 --> Controller Class Initialized
INFO - 2016-11-18 09:39:10 --> Model Class Initialized
INFO - 2016-11-18 09:39:10 --> Form Validation Class Initialized
INFO - 2016-11-18 09:39:10 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-18 09:39:10 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-18 09:39:11 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-04', '2016-11-05', '5', '1', '2016-11-18 09:39:10', '1', '')
INFO - 2016-11-18 09:39:11 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-18 09:39:25 --> Config Class Initialized
INFO - 2016-11-18 09:39:25 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:39:25 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:39:25 --> Utf8 Class Initialized
INFO - 2016-11-18 09:39:25 --> URI Class Initialized
INFO - 2016-11-18 09:39:25 --> Router Class Initialized
INFO - 2016-11-18 09:39:25 --> Output Class Initialized
INFO - 2016-11-18 09:39:25 --> Security Class Initialized
DEBUG - 2016-11-18 09:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:39:25 --> Input Class Initialized
INFO - 2016-11-18 09:39:25 --> Language Class Initialized
INFO - 2016-11-18 09:39:25 --> Loader Class Initialized
INFO - 2016-11-18 09:39:25 --> Helper loaded: url_helper
INFO - 2016-11-18 09:39:25 --> Helper loaded: form_helper
INFO - 2016-11-18 09:39:25 --> Database Driver Class Initialized
INFO - 2016-11-18 09:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:39:25 --> Controller Class Initialized
INFO - 2016-11-18 09:39:25 --> Model Class Initialized
INFO - 2016-11-18 09:39:25 --> Form Validation Class Initialized
ERROR - 2016-11-18 09:39:25 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 09:39:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-18 09:39:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 09:39:26 --> Final output sent to browser
DEBUG - 2016-11-18 09:39:26 --> Total execution time: 0.7004
INFO - 2016-11-18 09:39:30 --> Config Class Initialized
INFO - 2016-11-18 09:39:30 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:39:30 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:39:30 --> Utf8 Class Initialized
INFO - 2016-11-18 09:39:30 --> URI Class Initialized
DEBUG - 2016-11-18 09:39:30 --> No URI present. Default controller set.
INFO - 2016-11-18 09:39:30 --> Router Class Initialized
INFO - 2016-11-18 09:39:30 --> Output Class Initialized
INFO - 2016-11-18 09:39:30 --> Security Class Initialized
DEBUG - 2016-11-18 09:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:39:30 --> Input Class Initialized
INFO - 2016-11-18 09:39:30 --> Language Class Initialized
INFO - 2016-11-18 09:39:30 --> Loader Class Initialized
INFO - 2016-11-18 09:39:30 --> Helper loaded: url_helper
INFO - 2016-11-18 09:39:30 --> Helper loaded: form_helper
INFO - 2016-11-18 09:39:30 --> Database Driver Class Initialized
INFO - 2016-11-18 09:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:39:30 --> Controller Class Initialized
INFO - 2016-11-18 09:39:30 --> Model Class Initialized
INFO - 2016-11-18 09:39:30 --> Model Class Initialized
INFO - 2016-11-18 09:39:30 --> Model Class Initialized
INFO - 2016-11-18 09:39:30 --> Model Class Initialized
INFO - 2016-11-18 09:39:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 09:39:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 09:39:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 09:39:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 09:39:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 09:39:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 09:39:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 09:39:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 09:39:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 09:39:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 09:39:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 09:39:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 09:39:30 --> Final output sent to browser
DEBUG - 2016-11-18 09:39:30 --> Total execution time: 0.3608
INFO - 2016-11-18 09:39:47 --> Config Class Initialized
INFO - 2016-11-18 09:39:47 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:39:47 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:39:47 --> Utf8 Class Initialized
INFO - 2016-11-18 09:39:47 --> URI Class Initialized
INFO - 2016-11-18 09:39:47 --> Router Class Initialized
INFO - 2016-11-18 09:39:47 --> Output Class Initialized
INFO - 2016-11-18 09:39:47 --> Security Class Initialized
DEBUG - 2016-11-18 09:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:39:47 --> Input Class Initialized
INFO - 2016-11-18 09:39:47 --> Language Class Initialized
INFO - 2016-11-18 09:39:47 --> Loader Class Initialized
INFO - 2016-11-18 09:39:47 --> Helper loaded: url_helper
INFO - 2016-11-18 09:39:47 --> Helper loaded: form_helper
INFO - 2016-11-18 09:39:47 --> Database Driver Class Initialized
INFO - 2016-11-18 09:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:39:47 --> Controller Class Initialized
INFO - 2016-11-18 09:39:47 --> Model Class Initialized
INFO - 2016-11-18 09:39:47 --> Form Validation Class Initialized
INFO - 2016-11-18 09:39:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 09:39:47 --> Final output sent to browser
DEBUG - 2016-11-18 09:39:47 --> Total execution time: 0.2095
INFO - 2016-11-18 09:40:19 --> Config Class Initialized
INFO - 2016-11-18 09:40:19 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:40:19 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:40:19 --> Utf8 Class Initialized
INFO - 2016-11-18 09:40:19 --> URI Class Initialized
INFO - 2016-11-18 09:40:19 --> Router Class Initialized
INFO - 2016-11-18 09:40:19 --> Output Class Initialized
INFO - 2016-11-18 09:40:19 --> Security Class Initialized
DEBUG - 2016-11-18 09:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:40:19 --> Input Class Initialized
INFO - 2016-11-18 09:40:19 --> Language Class Initialized
INFO - 2016-11-18 09:40:19 --> Loader Class Initialized
INFO - 2016-11-18 09:40:19 --> Helper loaded: url_helper
INFO - 2016-11-18 09:40:19 --> Helper loaded: form_helper
INFO - 2016-11-18 09:40:19 --> Database Driver Class Initialized
INFO - 2016-11-18 09:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:40:19 --> Controller Class Initialized
INFO - 2016-11-18 09:40:19 --> Model Class Initialized
INFO - 2016-11-18 09:40:19 --> Form Validation Class Initialized
INFO - 2016-11-18 09:40:19 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-18 09:40:19 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-18 09:40:20 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-18', '2016-11-18', '1', '1', '2016-11-18 09:40:19', '1', '')
INFO - 2016-11-18 09:40:20 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-18 09:40:21 --> Config Class Initialized
INFO - 2016-11-18 09:40:21 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:40:21 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:40:21 --> Utf8 Class Initialized
INFO - 2016-11-18 09:40:21 --> URI Class Initialized
INFO - 2016-11-18 09:40:21 --> Router Class Initialized
INFO - 2016-11-18 09:40:21 --> Output Class Initialized
INFO - 2016-11-18 09:40:21 --> Security Class Initialized
DEBUG - 2016-11-18 09:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:40:21 --> Input Class Initialized
INFO - 2016-11-18 09:40:21 --> Language Class Initialized
INFO - 2016-11-18 09:40:21 --> Loader Class Initialized
INFO - 2016-11-18 09:40:21 --> Helper loaded: url_helper
INFO - 2016-11-18 09:40:21 --> Helper loaded: form_helper
INFO - 2016-11-18 09:40:21 --> Database Driver Class Initialized
INFO - 2016-11-18 09:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:40:21 --> Controller Class Initialized
INFO - 2016-11-18 09:40:21 --> Model Class Initialized
INFO - 2016-11-18 09:40:21 --> Form Validation Class Initialized
INFO - 2016-11-18 09:40:21 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-18 09:40:21 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-18 09:40:22 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-18', '2016-11-18', '1', '1', '2016-11-18 09:40:21', '1', '')
INFO - 2016-11-18 09:40:22 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-18 09:44:10 --> Config Class Initialized
INFO - 2016-11-18 09:44:10 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:44:10 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:44:10 --> Utf8 Class Initialized
INFO - 2016-11-18 09:44:10 --> URI Class Initialized
DEBUG - 2016-11-18 09:44:10 --> No URI present. Default controller set.
INFO - 2016-11-18 09:44:10 --> Router Class Initialized
INFO - 2016-11-18 09:44:10 --> Output Class Initialized
INFO - 2016-11-18 09:44:10 --> Security Class Initialized
DEBUG - 2016-11-18 09:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:44:10 --> Input Class Initialized
INFO - 2016-11-18 09:44:10 --> Language Class Initialized
INFO - 2016-11-18 09:44:10 --> Loader Class Initialized
INFO - 2016-11-18 09:44:10 --> Helper loaded: url_helper
INFO - 2016-11-18 09:44:10 --> Helper loaded: form_helper
INFO - 2016-11-18 09:44:10 --> Database Driver Class Initialized
INFO - 2016-11-18 09:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:44:10 --> Controller Class Initialized
INFO - 2016-11-18 09:44:10 --> Model Class Initialized
INFO - 2016-11-18 09:44:10 --> Model Class Initialized
INFO - 2016-11-18 09:44:10 --> Model Class Initialized
INFO - 2016-11-18 09:44:10 --> Model Class Initialized
INFO - 2016-11-18 09:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 09:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 09:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 09:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 09:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 09:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 09:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 09:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 09:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 09:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 09:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 09:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 09:44:10 --> Final output sent to browser
DEBUG - 2016-11-18 09:44:11 --> Total execution time: 0.3653
INFO - 2016-11-18 09:44:16 --> Config Class Initialized
INFO - 2016-11-18 09:44:16 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:44:16 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:44:16 --> Utf8 Class Initialized
INFO - 2016-11-18 09:44:16 --> URI Class Initialized
INFO - 2016-11-18 09:44:16 --> Router Class Initialized
INFO - 2016-11-18 09:44:16 --> Output Class Initialized
INFO - 2016-11-18 09:44:16 --> Security Class Initialized
DEBUG - 2016-11-18 09:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:44:16 --> Input Class Initialized
INFO - 2016-11-18 09:44:16 --> Language Class Initialized
INFO - 2016-11-18 09:44:16 --> Loader Class Initialized
INFO - 2016-11-18 09:44:16 --> Helper loaded: url_helper
INFO - 2016-11-18 09:44:16 --> Helper loaded: form_helper
INFO - 2016-11-18 09:44:16 --> Database Driver Class Initialized
INFO - 2016-11-18 09:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:44:16 --> Controller Class Initialized
INFO - 2016-11-18 09:44:16 --> Model Class Initialized
INFO - 2016-11-18 09:44:16 --> Form Validation Class Initialized
INFO - 2016-11-18 09:44:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 09:44:16 --> Final output sent to browser
DEBUG - 2016-11-18 09:44:16 --> Total execution time: 0.1928
INFO - 2016-11-18 09:45:27 --> Config Class Initialized
INFO - 2016-11-18 09:45:27 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:45:27 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:45:27 --> Utf8 Class Initialized
INFO - 2016-11-18 09:45:27 --> URI Class Initialized
DEBUG - 2016-11-18 09:45:27 --> No URI present. Default controller set.
INFO - 2016-11-18 09:45:27 --> Router Class Initialized
INFO - 2016-11-18 09:45:27 --> Output Class Initialized
INFO - 2016-11-18 09:45:27 --> Security Class Initialized
DEBUG - 2016-11-18 09:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:45:27 --> Input Class Initialized
INFO - 2016-11-18 09:45:27 --> Language Class Initialized
INFO - 2016-11-18 09:45:27 --> Loader Class Initialized
INFO - 2016-11-18 09:45:27 --> Helper loaded: url_helper
INFO - 2016-11-18 09:45:27 --> Helper loaded: form_helper
INFO - 2016-11-18 09:45:27 --> Database Driver Class Initialized
INFO - 2016-11-18 09:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:45:27 --> Controller Class Initialized
INFO - 2016-11-18 09:45:27 --> Model Class Initialized
INFO - 2016-11-18 09:45:27 --> Model Class Initialized
INFO - 2016-11-18 09:45:27 --> Model Class Initialized
INFO - 2016-11-18 09:45:27 --> Model Class Initialized
INFO - 2016-11-18 09:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 09:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 09:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 09:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 09:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 09:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 09:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 09:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 09:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 09:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 09:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 09:45:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 09:45:27 --> Final output sent to browser
DEBUG - 2016-11-18 09:45:27 --> Total execution time: 0.5084
INFO - 2016-11-18 09:45:43 --> Config Class Initialized
INFO - 2016-11-18 09:45:43 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:45:43 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:45:43 --> Utf8 Class Initialized
INFO - 2016-11-18 09:45:43 --> URI Class Initialized
INFO - 2016-11-18 09:45:43 --> Router Class Initialized
INFO - 2016-11-18 09:45:43 --> Output Class Initialized
INFO - 2016-11-18 09:45:43 --> Security Class Initialized
DEBUG - 2016-11-18 09:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:45:43 --> Input Class Initialized
INFO - 2016-11-18 09:45:43 --> Language Class Initialized
INFO - 2016-11-18 09:45:43 --> Loader Class Initialized
INFO - 2016-11-18 09:45:43 --> Helper loaded: url_helper
INFO - 2016-11-18 09:45:43 --> Helper loaded: form_helper
INFO - 2016-11-18 09:45:43 --> Database Driver Class Initialized
INFO - 2016-11-18 09:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:45:43 --> Controller Class Initialized
INFO - 2016-11-18 09:45:43 --> Model Class Initialized
INFO - 2016-11-18 09:45:43 --> Form Validation Class Initialized
INFO - 2016-11-18 09:45:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 09:45:43 --> Config Class Initialized
INFO - 2016-11-18 09:45:43 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:45:43 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:45:43 --> Utf8 Class Initialized
INFO - 2016-11-18 09:45:43 --> URI Class Initialized
INFO - 2016-11-18 09:45:43 --> Router Class Initialized
INFO - 2016-11-18 09:45:43 --> Output Class Initialized
INFO - 2016-11-18 09:45:43 --> Security Class Initialized
DEBUG - 2016-11-18 09:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:45:43 --> Input Class Initialized
INFO - 2016-11-18 09:45:43 --> Language Class Initialized
INFO - 2016-11-18 09:45:43 --> Loader Class Initialized
INFO - 2016-11-18 09:45:43 --> Helper loaded: url_helper
INFO - 2016-11-18 09:45:43 --> Helper loaded: form_helper
INFO - 2016-11-18 09:45:43 --> Database Driver Class Initialized
INFO - 2016-11-18 09:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:45:43 --> Controller Class Initialized
INFO - 2016-11-18 09:45:43 --> Model Class Initialized
INFO - 2016-11-18 09:45:43 --> Form Validation Class Initialized
INFO - 2016-11-18 09:45:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 09:46:29 --> Config Class Initialized
INFO - 2016-11-18 09:46:29 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:46:29 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:46:29 --> Utf8 Class Initialized
INFO - 2016-11-18 09:46:29 --> URI Class Initialized
DEBUG - 2016-11-18 09:46:29 --> No URI present. Default controller set.
INFO - 2016-11-18 09:46:29 --> Router Class Initialized
INFO - 2016-11-18 09:46:29 --> Output Class Initialized
INFO - 2016-11-18 09:46:29 --> Security Class Initialized
DEBUG - 2016-11-18 09:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:46:29 --> Input Class Initialized
INFO - 2016-11-18 09:46:29 --> Language Class Initialized
INFO - 2016-11-18 09:46:29 --> Loader Class Initialized
INFO - 2016-11-18 09:46:29 --> Helper loaded: url_helper
INFO - 2016-11-18 09:46:29 --> Helper loaded: form_helper
INFO - 2016-11-18 09:46:29 --> Database Driver Class Initialized
INFO - 2016-11-18 09:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:46:29 --> Controller Class Initialized
INFO - 2016-11-18 09:46:29 --> Model Class Initialized
INFO - 2016-11-18 09:46:29 --> Model Class Initialized
INFO - 2016-11-18 09:46:29 --> Model Class Initialized
INFO - 2016-11-18 09:46:29 --> Model Class Initialized
INFO - 2016-11-18 09:46:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 09:46:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 09:46:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 09:46:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 09:46:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 09:46:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 09:46:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 09:46:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 09:46:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 09:46:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 09:46:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 09:46:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 09:46:29 --> Final output sent to browser
DEBUG - 2016-11-18 09:46:29 --> Total execution time: 0.3788
INFO - 2016-11-18 09:46:51 --> Config Class Initialized
INFO - 2016-11-18 09:46:51 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:46:51 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:46:51 --> Utf8 Class Initialized
INFO - 2016-11-18 09:46:51 --> URI Class Initialized
INFO - 2016-11-18 09:46:51 --> Router Class Initialized
INFO - 2016-11-18 09:46:51 --> Output Class Initialized
INFO - 2016-11-18 09:46:51 --> Security Class Initialized
DEBUG - 2016-11-18 09:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:46:51 --> Input Class Initialized
INFO - 2016-11-18 09:46:51 --> Language Class Initialized
INFO - 2016-11-18 09:46:51 --> Loader Class Initialized
INFO - 2016-11-18 09:46:51 --> Helper loaded: url_helper
INFO - 2016-11-18 09:46:51 --> Helper loaded: form_helper
INFO - 2016-11-18 09:46:51 --> Database Driver Class Initialized
INFO - 2016-11-18 09:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:46:51 --> Controller Class Initialized
INFO - 2016-11-18 09:46:51 --> Model Class Initialized
INFO - 2016-11-18 09:46:51 --> Form Validation Class Initialized
INFO - 2016-11-18 09:46:51 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-18 09:46:51 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 101
INFO - 2016-11-18 09:46:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 09:46:51 --> Final output sent to browser
DEBUG - 2016-11-18 09:46:51 --> Total execution time: 0.6187
INFO - 2016-11-18 09:47:31 --> Config Class Initialized
INFO - 2016-11-18 09:47:31 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:47:31 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:47:31 --> Utf8 Class Initialized
INFO - 2016-11-18 09:47:31 --> URI Class Initialized
DEBUG - 2016-11-18 09:47:31 --> No URI present. Default controller set.
INFO - 2016-11-18 09:47:31 --> Router Class Initialized
INFO - 2016-11-18 09:47:31 --> Output Class Initialized
INFO - 2016-11-18 09:47:31 --> Security Class Initialized
DEBUG - 2016-11-18 09:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:47:31 --> Input Class Initialized
INFO - 2016-11-18 09:47:31 --> Language Class Initialized
INFO - 2016-11-18 09:47:31 --> Loader Class Initialized
INFO - 2016-11-18 09:47:31 --> Helper loaded: url_helper
INFO - 2016-11-18 09:47:32 --> Helper loaded: form_helper
INFO - 2016-11-18 09:47:32 --> Database Driver Class Initialized
INFO - 2016-11-18 09:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:47:32 --> Controller Class Initialized
INFO - 2016-11-18 09:47:32 --> Model Class Initialized
INFO - 2016-11-18 09:47:32 --> Model Class Initialized
INFO - 2016-11-18 09:47:32 --> Model Class Initialized
INFO - 2016-11-18 09:47:32 --> Model Class Initialized
INFO - 2016-11-18 09:47:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 09:47:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 09:47:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 09:47:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 09:47:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 09:47:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 09:47:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 09:47:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 09:47:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 09:47:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 09:47:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 09:47:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 09:47:32 --> Final output sent to browser
DEBUG - 2016-11-18 09:47:32 --> Total execution time: 0.3724
INFO - 2016-11-18 09:47:46 --> Config Class Initialized
INFO - 2016-11-18 09:47:46 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:47:46 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:47:46 --> Utf8 Class Initialized
INFO - 2016-11-18 09:47:46 --> URI Class Initialized
INFO - 2016-11-18 09:47:46 --> Router Class Initialized
INFO - 2016-11-18 09:47:46 --> Output Class Initialized
INFO - 2016-11-18 09:47:46 --> Security Class Initialized
DEBUG - 2016-11-18 09:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:47:47 --> Input Class Initialized
INFO - 2016-11-18 09:47:47 --> Language Class Initialized
INFO - 2016-11-18 09:47:47 --> Loader Class Initialized
INFO - 2016-11-18 09:47:47 --> Helper loaded: url_helper
INFO - 2016-11-18 09:47:47 --> Helper loaded: form_helper
INFO - 2016-11-18 09:47:47 --> Database Driver Class Initialized
INFO - 2016-11-18 09:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:47:47 --> Controller Class Initialized
INFO - 2016-11-18 09:47:47 --> Model Class Initialized
INFO - 2016-11-18 09:47:47 --> Form Validation Class Initialized
INFO - 2016-11-18 09:47:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 09:47:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 09:47:47 --> Final output sent to browser
DEBUG - 2016-11-18 09:47:47 --> Total execution time: 0.4084
INFO - 2016-11-18 09:48:13 --> Config Class Initialized
INFO - 2016-11-18 09:48:13 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:48:13 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:48:13 --> Utf8 Class Initialized
INFO - 2016-11-18 09:48:13 --> URI Class Initialized
INFO - 2016-11-18 09:48:13 --> Router Class Initialized
INFO - 2016-11-18 09:48:13 --> Output Class Initialized
INFO - 2016-11-18 09:48:13 --> Security Class Initialized
DEBUG - 2016-11-18 09:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:48:13 --> Input Class Initialized
INFO - 2016-11-18 09:48:13 --> Language Class Initialized
INFO - 2016-11-18 09:48:13 --> Loader Class Initialized
INFO - 2016-11-18 09:48:13 --> Helper loaded: url_helper
INFO - 2016-11-18 09:48:13 --> Helper loaded: form_helper
INFO - 2016-11-18 09:48:13 --> Database Driver Class Initialized
INFO - 2016-11-18 09:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:48:13 --> Controller Class Initialized
INFO - 2016-11-18 09:48:13 --> Model Class Initialized
INFO - 2016-11-18 09:48:13 --> Form Validation Class Initialized
INFO - 2016-11-18 09:48:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 09:48:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 09:48:14 --> Final output sent to browser
DEBUG - 2016-11-18 09:48:14 --> Total execution time: 0.5282
INFO - 2016-11-18 09:49:55 --> Config Class Initialized
INFO - 2016-11-18 09:49:55 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:49:55 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:49:55 --> Utf8 Class Initialized
INFO - 2016-11-18 09:49:55 --> URI Class Initialized
DEBUG - 2016-11-18 09:49:55 --> No URI present. Default controller set.
INFO - 2016-11-18 09:49:55 --> Router Class Initialized
INFO - 2016-11-18 09:49:55 --> Output Class Initialized
INFO - 2016-11-18 09:49:55 --> Security Class Initialized
DEBUG - 2016-11-18 09:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:49:55 --> Input Class Initialized
INFO - 2016-11-18 09:49:55 --> Language Class Initialized
INFO - 2016-11-18 09:49:55 --> Loader Class Initialized
INFO - 2016-11-18 09:49:55 --> Helper loaded: url_helper
INFO - 2016-11-18 09:49:55 --> Helper loaded: form_helper
INFO - 2016-11-18 09:49:55 --> Database Driver Class Initialized
INFO - 2016-11-18 09:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:49:55 --> Controller Class Initialized
INFO - 2016-11-18 09:49:55 --> Model Class Initialized
INFO - 2016-11-18 09:49:55 --> Model Class Initialized
INFO - 2016-11-18 09:49:55 --> Model Class Initialized
INFO - 2016-11-18 09:49:55 --> Model Class Initialized
INFO - 2016-11-18 09:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 09:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 09:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 09:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 09:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 09:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 09:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 09:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 09:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 09:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 09:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 09:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 09:49:55 --> Final output sent to browser
DEBUG - 2016-11-18 09:49:55 --> Total execution time: 0.3934
INFO - 2016-11-18 09:50:10 --> Config Class Initialized
INFO - 2016-11-18 09:50:11 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:50:11 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:50:11 --> Utf8 Class Initialized
INFO - 2016-11-18 09:50:11 --> URI Class Initialized
INFO - 2016-11-18 09:50:11 --> Router Class Initialized
INFO - 2016-11-18 09:50:11 --> Output Class Initialized
INFO - 2016-11-18 09:50:11 --> Security Class Initialized
DEBUG - 2016-11-18 09:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:50:11 --> Input Class Initialized
INFO - 2016-11-18 09:50:11 --> Language Class Initialized
INFO - 2016-11-18 09:50:11 --> Loader Class Initialized
INFO - 2016-11-18 09:50:11 --> Helper loaded: url_helper
INFO - 2016-11-18 09:50:11 --> Helper loaded: form_helper
INFO - 2016-11-18 09:50:11 --> Database Driver Class Initialized
INFO - 2016-11-18 09:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:50:11 --> Controller Class Initialized
INFO - 2016-11-18 09:50:11 --> Model Class Initialized
INFO - 2016-11-18 09:50:11 --> Form Validation Class Initialized
INFO - 2016-11-18 09:50:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 09:50:11 --> Final output sent to browser
DEBUG - 2016-11-18 09:50:11 --> Total execution time: 0.4114
INFO - 2016-11-18 09:50:30 --> Config Class Initialized
INFO - 2016-11-18 09:50:30 --> Hooks Class Initialized
DEBUG - 2016-11-18 09:50:30 --> UTF-8 Support Enabled
INFO - 2016-11-18 09:50:30 --> Utf8 Class Initialized
INFO - 2016-11-18 09:50:30 --> URI Class Initialized
INFO - 2016-11-18 09:50:30 --> Router Class Initialized
INFO - 2016-11-18 09:50:30 --> Output Class Initialized
INFO - 2016-11-18 09:50:30 --> Security Class Initialized
DEBUG - 2016-11-18 09:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 09:50:30 --> Input Class Initialized
INFO - 2016-11-18 09:50:30 --> Language Class Initialized
INFO - 2016-11-18 09:50:30 --> Loader Class Initialized
INFO - 2016-11-18 09:50:30 --> Helper loaded: url_helper
INFO - 2016-11-18 09:50:30 --> Helper loaded: form_helper
INFO - 2016-11-18 09:50:30 --> Database Driver Class Initialized
INFO - 2016-11-18 09:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 09:50:30 --> Controller Class Initialized
INFO - 2016-11-18 09:50:30 --> Model Class Initialized
INFO - 2016-11-18 09:50:30 --> Form Validation Class Initialized
INFO - 2016-11-18 09:50:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 09:50:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 09:50:30 --> Final output sent to browser
DEBUG - 2016-11-18 09:50:30 --> Total execution time: 0.4900
INFO - 2016-11-18 10:09:34 --> Config Class Initialized
INFO - 2016-11-18 10:09:34 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:09:34 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:09:34 --> Utf8 Class Initialized
INFO - 2016-11-18 10:09:34 --> URI Class Initialized
DEBUG - 2016-11-18 10:09:35 --> No URI present. Default controller set.
INFO - 2016-11-18 10:09:35 --> Router Class Initialized
INFO - 2016-11-18 10:09:35 --> Output Class Initialized
INFO - 2016-11-18 10:09:35 --> Security Class Initialized
DEBUG - 2016-11-18 10:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:09:35 --> Input Class Initialized
INFO - 2016-11-18 10:09:35 --> Language Class Initialized
INFO - 2016-11-18 10:09:35 --> Loader Class Initialized
INFO - 2016-11-18 10:09:36 --> Helper loaded: url_helper
INFO - 2016-11-18 10:09:36 --> Helper loaded: form_helper
INFO - 2016-11-18 10:09:36 --> Database Driver Class Initialized
INFO - 2016-11-18 10:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:09:36 --> Controller Class Initialized
INFO - 2016-11-18 10:09:36 --> Model Class Initialized
INFO - 2016-11-18 10:09:36 --> Model Class Initialized
INFO - 2016-11-18 10:09:37 --> Model Class Initialized
INFO - 2016-11-18 10:09:37 --> Model Class Initialized
INFO - 2016-11-18 10:09:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 10:09:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 10:09:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 10:09:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 10:09:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 10:09:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 10:09:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 10:09:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 10:09:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 10:09:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 10:09:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 10:09:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 10:09:37 --> Final output sent to browser
DEBUG - 2016-11-18 10:09:37 --> Total execution time: 3.6243
INFO - 2016-11-18 10:09:51 --> Config Class Initialized
INFO - 2016-11-18 10:09:51 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:09:51 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:09:51 --> Utf8 Class Initialized
INFO - 2016-11-18 10:09:51 --> URI Class Initialized
INFO - 2016-11-18 10:09:51 --> Router Class Initialized
INFO - 2016-11-18 10:09:51 --> Output Class Initialized
INFO - 2016-11-18 10:09:51 --> Security Class Initialized
DEBUG - 2016-11-18 10:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:09:51 --> Input Class Initialized
INFO - 2016-11-18 10:09:51 --> Language Class Initialized
INFO - 2016-11-18 10:09:51 --> Loader Class Initialized
INFO - 2016-11-18 10:09:51 --> Helper loaded: url_helper
INFO - 2016-11-18 10:09:51 --> Helper loaded: form_helper
INFO - 2016-11-18 10:09:51 --> Database Driver Class Initialized
INFO - 2016-11-18 10:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:09:51 --> Controller Class Initialized
INFO - 2016-11-18 10:09:51 --> Model Class Initialized
INFO - 2016-11-18 10:09:51 --> Form Validation Class Initialized
INFO - 2016-11-18 10:09:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 10:09:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 10:09:51 --> Final output sent to browser
DEBUG - 2016-11-18 10:09:51 --> Total execution time: 0.3926
INFO - 2016-11-18 10:14:19 --> Config Class Initialized
INFO - 2016-11-18 10:14:19 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:14:19 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:14:19 --> Utf8 Class Initialized
INFO - 2016-11-18 10:14:19 --> URI Class Initialized
INFO - 2016-11-18 10:14:19 --> Router Class Initialized
INFO - 2016-11-18 10:14:19 --> Output Class Initialized
INFO - 2016-11-18 10:14:19 --> Security Class Initialized
DEBUG - 2016-11-18 10:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:14:19 --> Input Class Initialized
INFO - 2016-11-18 10:14:19 --> Language Class Initialized
INFO - 2016-11-18 10:14:19 --> Loader Class Initialized
INFO - 2016-11-18 10:14:19 --> Helper loaded: url_helper
INFO - 2016-11-18 10:14:19 --> Helper loaded: form_helper
INFO - 2016-11-18 10:14:20 --> Database Driver Class Initialized
INFO - 2016-11-18 10:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:14:20 --> Controller Class Initialized
INFO - 2016-11-18 10:14:20 --> Model Class Initialized
INFO - 2016-11-18 10:14:20 --> Form Validation Class Initialized
INFO - 2016-11-18 10:14:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 10:14:56 --> Config Class Initialized
INFO - 2016-11-18 10:14:56 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:14:56 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:14:56 --> Utf8 Class Initialized
INFO - 2016-11-18 10:14:56 --> URI Class Initialized
INFO - 2016-11-18 10:14:56 --> Router Class Initialized
INFO - 2016-11-18 10:14:56 --> Output Class Initialized
INFO - 2016-11-18 10:14:56 --> Security Class Initialized
DEBUG - 2016-11-18 10:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:14:56 --> Input Class Initialized
INFO - 2016-11-18 10:14:56 --> Language Class Initialized
INFO - 2016-11-18 10:14:56 --> Loader Class Initialized
INFO - 2016-11-18 10:14:56 --> Helper loaded: url_helper
INFO - 2016-11-18 10:14:56 --> Helper loaded: form_helper
INFO - 2016-11-18 10:14:56 --> Database Driver Class Initialized
INFO - 2016-11-18 10:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:14:56 --> Controller Class Initialized
INFO - 2016-11-18 10:14:56 --> Model Class Initialized
INFO - 2016-11-18 10:14:56 --> Form Validation Class Initialized
INFO - 2016-11-18 10:14:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 10:15:54 --> Config Class Initialized
INFO - 2016-11-18 10:15:54 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:15:54 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:15:54 --> Utf8 Class Initialized
INFO - 2016-11-18 10:15:54 --> URI Class Initialized
INFO - 2016-11-18 10:15:54 --> Router Class Initialized
INFO - 2016-11-18 10:15:55 --> Output Class Initialized
INFO - 2016-11-18 10:15:55 --> Security Class Initialized
DEBUG - 2016-11-18 10:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:15:55 --> Input Class Initialized
INFO - 2016-11-18 10:15:55 --> Language Class Initialized
INFO - 2016-11-18 10:15:55 --> Loader Class Initialized
INFO - 2016-11-18 10:15:55 --> Helper loaded: url_helper
INFO - 2016-11-18 10:15:55 --> Helper loaded: form_helper
INFO - 2016-11-18 10:15:55 --> Database Driver Class Initialized
INFO - 2016-11-18 10:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:15:55 --> Controller Class Initialized
INFO - 2016-11-18 10:15:55 --> Model Class Initialized
INFO - 2016-11-18 10:15:55 --> Form Validation Class Initialized
INFO - 2016-11-18 10:15:55 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-18 10:15:55 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::last_query() C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 84
INFO - 2016-11-18 10:16:13 --> Config Class Initialized
INFO - 2016-11-18 10:16:13 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:16:13 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:16:13 --> Utf8 Class Initialized
INFO - 2016-11-18 10:16:13 --> URI Class Initialized
INFO - 2016-11-18 10:16:13 --> Router Class Initialized
INFO - 2016-11-18 10:16:13 --> Output Class Initialized
INFO - 2016-11-18 10:16:13 --> Security Class Initialized
DEBUG - 2016-11-18 10:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:16:14 --> Input Class Initialized
INFO - 2016-11-18 10:16:14 --> Language Class Initialized
INFO - 2016-11-18 10:16:14 --> Loader Class Initialized
INFO - 2016-11-18 10:16:14 --> Helper loaded: url_helper
INFO - 2016-11-18 10:16:14 --> Helper loaded: form_helper
INFO - 2016-11-18 10:16:14 --> Database Driver Class Initialized
INFO - 2016-11-18 10:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:16:14 --> Controller Class Initialized
INFO - 2016-11-18 10:16:14 --> Model Class Initialized
INFO - 2016-11-18 10:16:14 --> Form Validation Class Initialized
INFO - 2016-11-18 10:16:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 10:17:13 --> Config Class Initialized
INFO - 2016-11-18 10:17:13 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:17:13 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:17:13 --> Utf8 Class Initialized
INFO - 2016-11-18 10:17:13 --> URI Class Initialized
INFO - 2016-11-18 10:17:13 --> Router Class Initialized
INFO - 2016-11-18 10:17:13 --> Output Class Initialized
INFO - 2016-11-18 10:17:13 --> Security Class Initialized
DEBUG - 2016-11-18 10:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:17:13 --> Input Class Initialized
INFO - 2016-11-18 10:17:13 --> Language Class Initialized
INFO - 2016-11-18 10:17:13 --> Loader Class Initialized
INFO - 2016-11-18 10:17:13 --> Helper loaded: url_helper
INFO - 2016-11-18 10:17:13 --> Helper loaded: form_helper
INFO - 2016-11-18 10:17:13 --> Database Driver Class Initialized
INFO - 2016-11-18 10:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:17:13 --> Controller Class Initialized
INFO - 2016-11-18 10:17:13 --> Model Class Initialized
INFO - 2016-11-18 10:17:13 --> Form Validation Class Initialized
INFO - 2016-11-18 10:17:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 10:17:39 --> Config Class Initialized
INFO - 2016-11-18 10:17:39 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:17:39 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:17:39 --> Utf8 Class Initialized
INFO - 2016-11-18 10:17:39 --> URI Class Initialized
DEBUG - 2016-11-18 10:17:39 --> No URI present. Default controller set.
INFO - 2016-11-18 10:17:39 --> Router Class Initialized
INFO - 2016-11-18 10:17:39 --> Output Class Initialized
INFO - 2016-11-18 10:17:39 --> Security Class Initialized
DEBUG - 2016-11-18 10:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:17:39 --> Input Class Initialized
INFO - 2016-11-18 10:17:39 --> Language Class Initialized
INFO - 2016-11-18 10:17:39 --> Loader Class Initialized
INFO - 2016-11-18 10:17:39 --> Helper loaded: url_helper
INFO - 2016-11-18 10:17:39 --> Helper loaded: form_helper
INFO - 2016-11-18 10:17:39 --> Database Driver Class Initialized
INFO - 2016-11-18 10:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:17:39 --> Controller Class Initialized
INFO - 2016-11-18 10:17:39 --> Model Class Initialized
INFO - 2016-11-18 10:17:39 --> Model Class Initialized
INFO - 2016-11-18 10:17:39 --> Model Class Initialized
INFO - 2016-11-18 10:17:39 --> Model Class Initialized
INFO - 2016-11-18 10:17:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 10:17:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 10:17:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 10:17:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 10:17:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 10:17:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 10:17:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 10:17:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 10:17:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 10:17:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 10:17:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 10:17:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 10:17:39 --> Final output sent to browser
DEBUG - 2016-11-18 10:17:39 --> Total execution time: 0.5113
INFO - 2016-11-18 10:17:52 --> Config Class Initialized
INFO - 2016-11-18 10:17:52 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:17:52 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:17:52 --> Utf8 Class Initialized
INFO - 2016-11-18 10:17:52 --> URI Class Initialized
INFO - 2016-11-18 10:17:52 --> Router Class Initialized
INFO - 2016-11-18 10:17:52 --> Output Class Initialized
INFO - 2016-11-18 10:17:52 --> Security Class Initialized
DEBUG - 2016-11-18 10:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:17:52 --> Input Class Initialized
INFO - 2016-11-18 10:17:52 --> Language Class Initialized
INFO - 2016-11-18 10:17:52 --> Loader Class Initialized
INFO - 2016-11-18 10:17:52 --> Helper loaded: url_helper
INFO - 2016-11-18 10:17:52 --> Helper loaded: form_helper
INFO - 2016-11-18 10:17:52 --> Database Driver Class Initialized
INFO - 2016-11-18 10:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:17:52 --> Controller Class Initialized
INFO - 2016-11-18 10:17:52 --> Model Class Initialized
INFO - 2016-11-18 10:17:52 --> Form Validation Class Initialized
INFO - 2016-11-18 10:17:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 10:17:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 10:17:52 --> Final output sent to browser
DEBUG - 2016-11-18 10:17:53 --> Total execution time: 0.3092
INFO - 2016-11-18 10:18:39 --> Config Class Initialized
INFO - 2016-11-18 10:18:39 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:18:39 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:18:39 --> Utf8 Class Initialized
INFO - 2016-11-18 10:18:39 --> URI Class Initialized
DEBUG - 2016-11-18 10:18:39 --> No URI present. Default controller set.
INFO - 2016-11-18 10:18:39 --> Router Class Initialized
INFO - 2016-11-18 10:18:39 --> Output Class Initialized
INFO - 2016-11-18 10:18:39 --> Security Class Initialized
DEBUG - 2016-11-18 10:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:18:39 --> Input Class Initialized
INFO - 2016-11-18 10:18:39 --> Language Class Initialized
INFO - 2016-11-18 10:18:39 --> Loader Class Initialized
INFO - 2016-11-18 10:18:39 --> Helper loaded: url_helper
INFO - 2016-11-18 10:18:39 --> Helper loaded: form_helper
INFO - 2016-11-18 10:18:39 --> Database Driver Class Initialized
INFO - 2016-11-18 10:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:18:39 --> Controller Class Initialized
INFO - 2016-11-18 10:18:39 --> Model Class Initialized
INFO - 2016-11-18 10:18:39 --> Model Class Initialized
INFO - 2016-11-18 10:18:39 --> Model Class Initialized
INFO - 2016-11-18 10:18:39 --> Model Class Initialized
INFO - 2016-11-18 10:18:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 10:18:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 10:18:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 10:18:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 10:18:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 10:18:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 10:18:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 10:18:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 10:18:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 10:18:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 10:18:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 10:18:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 10:18:39 --> Final output sent to browser
DEBUG - 2016-11-18 10:18:39 --> Total execution time: 0.3920
INFO - 2016-11-18 10:19:35 --> Config Class Initialized
INFO - 2016-11-18 10:19:35 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:19:36 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:19:36 --> Utf8 Class Initialized
INFO - 2016-11-18 10:19:36 --> URI Class Initialized
DEBUG - 2016-11-18 10:19:36 --> No URI present. Default controller set.
INFO - 2016-11-18 10:19:36 --> Router Class Initialized
INFO - 2016-11-18 10:19:36 --> Output Class Initialized
INFO - 2016-11-18 10:19:36 --> Security Class Initialized
DEBUG - 2016-11-18 10:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:19:36 --> Input Class Initialized
INFO - 2016-11-18 10:19:36 --> Language Class Initialized
INFO - 2016-11-18 10:19:36 --> Loader Class Initialized
INFO - 2016-11-18 10:19:36 --> Helper loaded: url_helper
INFO - 2016-11-18 10:19:36 --> Helper loaded: form_helper
INFO - 2016-11-18 10:19:36 --> Database Driver Class Initialized
INFO - 2016-11-18 10:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:19:36 --> Controller Class Initialized
INFO - 2016-11-18 10:19:36 --> Model Class Initialized
INFO - 2016-11-18 10:19:36 --> Model Class Initialized
INFO - 2016-11-18 10:19:36 --> Model Class Initialized
INFO - 2016-11-18 10:19:36 --> Model Class Initialized
INFO - 2016-11-18 10:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 10:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 10:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 10:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 10:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 10:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 10:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 10:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 10:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 10:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 10:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 10:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 10:19:36 --> Final output sent to browser
DEBUG - 2016-11-18 10:19:36 --> Total execution time: 0.4008
INFO - 2016-11-18 10:19:47 --> Config Class Initialized
INFO - 2016-11-18 10:19:47 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:19:47 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:19:47 --> Utf8 Class Initialized
INFO - 2016-11-18 10:19:47 --> URI Class Initialized
INFO - 2016-11-18 10:19:47 --> Router Class Initialized
INFO - 2016-11-18 10:19:47 --> Output Class Initialized
INFO - 2016-11-18 10:19:47 --> Security Class Initialized
DEBUG - 2016-11-18 10:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:19:47 --> Input Class Initialized
INFO - 2016-11-18 10:19:47 --> Language Class Initialized
INFO - 2016-11-18 10:19:47 --> Loader Class Initialized
INFO - 2016-11-18 10:19:47 --> Helper loaded: url_helper
INFO - 2016-11-18 10:19:47 --> Helper loaded: form_helper
INFO - 2016-11-18 10:19:47 --> Database Driver Class Initialized
INFO - 2016-11-18 10:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:19:47 --> Controller Class Initialized
INFO - 2016-11-18 10:19:47 --> Model Class Initialized
INFO - 2016-11-18 10:19:47 --> Form Validation Class Initialized
ERROR - 2016-11-18 10:19:47 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 10:19:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-18 10:19:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 10:19:47 --> Final output sent to browser
DEBUG - 2016-11-18 10:19:47 --> Total execution time: 0.3683
INFO - 2016-11-18 10:20:47 --> Config Class Initialized
INFO - 2016-11-18 10:20:47 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:20:47 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:20:47 --> Utf8 Class Initialized
INFO - 2016-11-18 10:20:47 --> URI Class Initialized
INFO - 2016-11-18 10:20:47 --> Router Class Initialized
INFO - 2016-11-18 10:20:47 --> Output Class Initialized
INFO - 2016-11-18 10:20:47 --> Security Class Initialized
DEBUG - 2016-11-18 10:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:20:47 --> Input Class Initialized
INFO - 2016-11-18 10:20:47 --> Language Class Initialized
INFO - 2016-11-18 10:20:47 --> Loader Class Initialized
INFO - 2016-11-18 10:20:47 --> Helper loaded: url_helper
INFO - 2016-11-18 10:20:47 --> Helper loaded: form_helper
INFO - 2016-11-18 10:20:47 --> Database Driver Class Initialized
INFO - 2016-11-18 10:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:20:47 --> Controller Class Initialized
INFO - 2016-11-18 10:20:47 --> Model Class Initialized
INFO - 2016-11-18 10:20:47 --> Form Validation Class Initialized
INFO - 2016-11-18 10:20:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 10:20:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 10:20:48 --> Final output sent to browser
DEBUG - 2016-11-18 10:20:48 --> Total execution time: 0.3157
INFO - 2016-11-18 10:21:01 --> Config Class Initialized
INFO - 2016-11-18 10:21:01 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:21:01 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:21:01 --> Utf8 Class Initialized
INFO - 2016-11-18 10:21:01 --> URI Class Initialized
DEBUG - 2016-11-18 10:21:01 --> No URI present. Default controller set.
INFO - 2016-11-18 10:21:01 --> Router Class Initialized
INFO - 2016-11-18 10:21:01 --> Output Class Initialized
INFO - 2016-11-18 10:21:01 --> Security Class Initialized
DEBUG - 2016-11-18 10:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:21:01 --> Input Class Initialized
INFO - 2016-11-18 10:21:01 --> Language Class Initialized
INFO - 2016-11-18 10:21:01 --> Loader Class Initialized
INFO - 2016-11-18 10:21:01 --> Helper loaded: url_helper
INFO - 2016-11-18 10:21:01 --> Helper loaded: form_helper
INFO - 2016-11-18 10:21:01 --> Database Driver Class Initialized
INFO - 2016-11-18 10:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:21:01 --> Controller Class Initialized
INFO - 2016-11-18 10:21:01 --> Model Class Initialized
INFO - 2016-11-18 10:21:01 --> Model Class Initialized
INFO - 2016-11-18 10:21:01 --> Model Class Initialized
INFO - 2016-11-18 10:21:01 --> Model Class Initialized
INFO - 2016-11-18 10:21:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 10:21:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 10:21:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 10:21:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 10:21:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 10:21:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 10:21:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 10:21:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 10:21:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 10:21:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 10:21:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 10:21:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 10:21:01 --> Final output sent to browser
DEBUG - 2016-11-18 10:21:02 --> Total execution time: 0.3897
INFO - 2016-11-18 10:22:08 --> Config Class Initialized
INFO - 2016-11-18 10:22:08 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:22:08 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:22:08 --> Utf8 Class Initialized
INFO - 2016-11-18 10:22:08 --> URI Class Initialized
DEBUG - 2016-11-18 10:22:08 --> No URI present. Default controller set.
INFO - 2016-11-18 10:22:08 --> Router Class Initialized
INFO - 2016-11-18 10:22:08 --> Output Class Initialized
INFO - 2016-11-18 10:22:08 --> Security Class Initialized
DEBUG - 2016-11-18 10:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:22:08 --> Input Class Initialized
INFO - 2016-11-18 10:22:08 --> Language Class Initialized
INFO - 2016-11-18 10:22:08 --> Loader Class Initialized
INFO - 2016-11-18 10:22:08 --> Helper loaded: url_helper
INFO - 2016-11-18 10:22:08 --> Helper loaded: form_helper
INFO - 2016-11-18 10:22:08 --> Database Driver Class Initialized
INFO - 2016-11-18 10:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:22:08 --> Controller Class Initialized
INFO - 2016-11-18 10:22:08 --> Model Class Initialized
INFO - 2016-11-18 10:22:08 --> Model Class Initialized
INFO - 2016-11-18 10:22:08 --> Model Class Initialized
INFO - 2016-11-18 10:22:08 --> Model Class Initialized
INFO - 2016-11-18 10:22:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 10:22:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 10:22:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 10:22:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 10:22:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 10:22:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 10:22:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 10:22:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 10:22:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 10:22:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 10:22:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 10:22:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 10:22:08 --> Final output sent to browser
DEBUG - 2016-11-18 10:22:08 --> Total execution time: 0.3929
INFO - 2016-11-18 10:26:53 --> Config Class Initialized
INFO - 2016-11-18 10:26:53 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:26:53 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:26:53 --> Utf8 Class Initialized
INFO - 2016-11-18 10:26:53 --> URI Class Initialized
DEBUG - 2016-11-18 10:26:53 --> No URI present. Default controller set.
INFO - 2016-11-18 10:26:53 --> Router Class Initialized
INFO - 2016-11-18 10:26:53 --> Output Class Initialized
INFO - 2016-11-18 10:26:53 --> Security Class Initialized
DEBUG - 2016-11-18 10:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:26:53 --> Input Class Initialized
INFO - 2016-11-18 10:26:53 --> Language Class Initialized
INFO - 2016-11-18 10:26:53 --> Loader Class Initialized
INFO - 2016-11-18 10:26:53 --> Helper loaded: url_helper
INFO - 2016-11-18 10:26:53 --> Helper loaded: form_helper
INFO - 2016-11-18 10:26:53 --> Database Driver Class Initialized
INFO - 2016-11-18 10:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:26:53 --> Controller Class Initialized
INFO - 2016-11-18 10:26:53 --> Model Class Initialized
INFO - 2016-11-18 10:26:53 --> Model Class Initialized
INFO - 2016-11-18 10:26:53 --> Model Class Initialized
INFO - 2016-11-18 10:26:53 --> Model Class Initialized
INFO - 2016-11-18 10:26:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 10:26:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 10:26:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 10:26:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 10:26:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 10:26:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 10:26:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 10:26:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 10:26:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 10:26:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 10:26:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 10:26:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 10:26:53 --> Final output sent to browser
DEBUG - 2016-11-18 10:26:53 --> Total execution time: 0.3906
INFO - 2016-11-18 10:27:01 --> Config Class Initialized
INFO - 2016-11-18 10:27:01 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:27:01 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:27:01 --> Utf8 Class Initialized
INFO - 2016-11-18 10:27:01 --> URI Class Initialized
DEBUG - 2016-11-18 10:27:01 --> No URI present. Default controller set.
INFO - 2016-11-18 10:27:01 --> Router Class Initialized
INFO - 2016-11-18 10:27:01 --> Output Class Initialized
INFO - 2016-11-18 10:27:01 --> Security Class Initialized
DEBUG - 2016-11-18 10:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:27:01 --> Input Class Initialized
INFO - 2016-11-18 10:27:01 --> Language Class Initialized
INFO - 2016-11-18 10:27:01 --> Loader Class Initialized
INFO - 2016-11-18 10:27:01 --> Helper loaded: url_helper
INFO - 2016-11-18 10:27:01 --> Helper loaded: form_helper
INFO - 2016-11-18 10:27:01 --> Database Driver Class Initialized
INFO - 2016-11-18 10:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:27:01 --> Controller Class Initialized
INFO - 2016-11-18 10:27:01 --> Model Class Initialized
INFO - 2016-11-18 10:27:01 --> Model Class Initialized
INFO - 2016-11-18 10:27:01 --> Model Class Initialized
INFO - 2016-11-18 10:27:01 --> Model Class Initialized
INFO - 2016-11-18 10:27:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 10:27:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 10:27:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 10:27:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 10:27:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 10:27:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 10:27:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 10:27:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 10:27:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 10:27:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 10:27:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 10:27:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 10:27:01 --> Final output sent to browser
DEBUG - 2016-11-18 10:27:01 --> Total execution time: 0.3824
INFO - 2016-11-18 10:27:23 --> Config Class Initialized
INFO - 2016-11-18 10:27:23 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:27:23 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:27:23 --> Utf8 Class Initialized
INFO - 2016-11-18 10:27:23 --> URI Class Initialized
DEBUG - 2016-11-18 10:27:23 --> No URI present. Default controller set.
INFO - 2016-11-18 10:27:23 --> Router Class Initialized
INFO - 2016-11-18 10:27:23 --> Output Class Initialized
INFO - 2016-11-18 10:27:23 --> Security Class Initialized
DEBUG - 2016-11-18 10:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:27:23 --> Input Class Initialized
INFO - 2016-11-18 10:27:23 --> Language Class Initialized
INFO - 2016-11-18 10:27:23 --> Loader Class Initialized
INFO - 2016-11-18 10:27:23 --> Helper loaded: url_helper
INFO - 2016-11-18 10:27:23 --> Helper loaded: form_helper
INFO - 2016-11-18 10:27:23 --> Database Driver Class Initialized
INFO - 2016-11-18 10:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:27:23 --> Controller Class Initialized
INFO - 2016-11-18 10:27:23 --> Model Class Initialized
INFO - 2016-11-18 10:27:23 --> Model Class Initialized
INFO - 2016-11-18 10:27:23 --> Model Class Initialized
INFO - 2016-11-18 10:27:23 --> Model Class Initialized
INFO - 2016-11-18 10:27:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 10:27:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 10:27:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 10:27:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 10:27:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 10:27:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 10:27:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 10:27:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 10:27:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 10:27:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 10:27:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 10:27:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 10:27:23 --> Final output sent to browser
DEBUG - 2016-11-18 10:27:23 --> Total execution time: 0.4109
INFO - 2016-11-18 10:27:48 --> Config Class Initialized
INFO - 2016-11-18 10:27:48 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:27:48 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:27:48 --> Utf8 Class Initialized
INFO - 2016-11-18 10:27:48 --> URI Class Initialized
INFO - 2016-11-18 10:27:48 --> Router Class Initialized
INFO - 2016-11-18 10:27:48 --> Output Class Initialized
INFO - 2016-11-18 10:27:48 --> Security Class Initialized
DEBUG - 2016-11-18 10:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:27:48 --> Input Class Initialized
INFO - 2016-11-18 10:27:48 --> Language Class Initialized
INFO - 2016-11-18 10:27:48 --> Loader Class Initialized
INFO - 2016-11-18 10:27:48 --> Helper loaded: url_helper
INFO - 2016-11-18 10:27:48 --> Helper loaded: form_helper
INFO - 2016-11-18 10:27:48 --> Database Driver Class Initialized
INFO - 2016-11-18 10:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:27:48 --> Controller Class Initialized
INFO - 2016-11-18 10:27:48 --> Model Class Initialized
INFO - 2016-11-18 10:27:48 --> Form Validation Class Initialized
INFO - 2016-11-18 10:27:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 10:27:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 10:27:48 --> Final output sent to browser
DEBUG - 2016-11-18 10:27:48 --> Total execution time: 0.3225
INFO - 2016-11-18 10:28:01 --> Config Class Initialized
INFO - 2016-11-18 10:28:01 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:28:01 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:28:01 --> Utf8 Class Initialized
INFO - 2016-11-18 10:28:01 --> URI Class Initialized
DEBUG - 2016-11-18 10:28:01 --> No URI present. Default controller set.
INFO - 2016-11-18 10:28:01 --> Router Class Initialized
INFO - 2016-11-18 10:28:01 --> Output Class Initialized
INFO - 2016-11-18 10:28:01 --> Security Class Initialized
DEBUG - 2016-11-18 10:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:28:01 --> Input Class Initialized
INFO - 2016-11-18 10:28:01 --> Language Class Initialized
INFO - 2016-11-18 10:28:01 --> Loader Class Initialized
INFO - 2016-11-18 10:28:01 --> Helper loaded: url_helper
INFO - 2016-11-18 10:28:01 --> Helper loaded: form_helper
INFO - 2016-11-18 10:28:01 --> Database Driver Class Initialized
INFO - 2016-11-18 10:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:28:01 --> Controller Class Initialized
INFO - 2016-11-18 10:28:01 --> Model Class Initialized
INFO - 2016-11-18 10:28:01 --> Model Class Initialized
INFO - 2016-11-18 10:28:01 --> Model Class Initialized
INFO - 2016-11-18 10:28:01 --> Model Class Initialized
INFO - 2016-11-18 10:28:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 10:28:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 10:28:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 10:28:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 10:28:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 10:28:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 10:28:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 10:28:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 10:28:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 10:28:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 10:28:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 10:28:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 10:28:01 --> Final output sent to browser
DEBUG - 2016-11-18 10:28:01 --> Total execution time: 0.4055
INFO - 2016-11-18 10:28:43 --> Config Class Initialized
INFO - 2016-11-18 10:28:43 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:28:43 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:28:43 --> Utf8 Class Initialized
INFO - 2016-11-18 10:28:43 --> URI Class Initialized
DEBUG - 2016-11-18 10:28:43 --> No URI present. Default controller set.
INFO - 2016-11-18 10:28:43 --> Router Class Initialized
INFO - 2016-11-18 10:28:43 --> Output Class Initialized
INFO - 2016-11-18 10:28:43 --> Security Class Initialized
DEBUG - 2016-11-18 10:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:28:43 --> Input Class Initialized
INFO - 2016-11-18 10:28:43 --> Language Class Initialized
INFO - 2016-11-18 10:28:43 --> Loader Class Initialized
INFO - 2016-11-18 10:28:43 --> Helper loaded: url_helper
INFO - 2016-11-18 10:28:43 --> Helper loaded: form_helper
INFO - 2016-11-18 10:28:43 --> Database Driver Class Initialized
INFO - 2016-11-18 10:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:28:43 --> Controller Class Initialized
INFO - 2016-11-18 10:28:43 --> Model Class Initialized
INFO - 2016-11-18 10:28:43 --> Model Class Initialized
INFO - 2016-11-18 10:28:43 --> Model Class Initialized
INFO - 2016-11-18 10:28:43 --> Model Class Initialized
INFO - 2016-11-18 10:28:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 10:28:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 10:28:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 10:28:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 10:28:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 10:28:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 10:28:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 10:28:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 10:28:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 10:28:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 10:28:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 10:28:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 10:28:43 --> Final output sent to browser
DEBUG - 2016-11-18 10:28:43 --> Total execution time: 0.3696
INFO - 2016-11-18 10:29:26 --> Config Class Initialized
INFO - 2016-11-18 10:29:26 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:29:26 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:29:26 --> Utf8 Class Initialized
INFO - 2016-11-18 10:29:26 --> URI Class Initialized
DEBUG - 2016-11-18 10:29:26 --> No URI present. Default controller set.
INFO - 2016-11-18 10:29:26 --> Router Class Initialized
INFO - 2016-11-18 10:29:26 --> Output Class Initialized
INFO - 2016-11-18 10:29:26 --> Security Class Initialized
DEBUG - 2016-11-18 10:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:29:26 --> Input Class Initialized
INFO - 2016-11-18 10:29:26 --> Language Class Initialized
INFO - 2016-11-18 10:29:26 --> Loader Class Initialized
INFO - 2016-11-18 10:29:26 --> Helper loaded: url_helper
INFO - 2016-11-18 10:29:26 --> Helper loaded: form_helper
INFO - 2016-11-18 10:29:26 --> Database Driver Class Initialized
INFO - 2016-11-18 10:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:29:26 --> Controller Class Initialized
INFO - 2016-11-18 10:29:26 --> Model Class Initialized
INFO - 2016-11-18 10:29:26 --> Model Class Initialized
INFO - 2016-11-18 10:29:26 --> Model Class Initialized
INFO - 2016-11-18 10:29:26 --> Model Class Initialized
INFO - 2016-11-18 10:29:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 10:29:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 10:29:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 10:29:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 10:29:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 10:29:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 10:29:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 10:29:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 10:29:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 10:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 10:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 10:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 10:29:27 --> Final output sent to browser
DEBUG - 2016-11-18 10:29:27 --> Total execution time: 0.4096
INFO - 2016-11-18 10:30:03 --> Config Class Initialized
INFO - 2016-11-18 10:30:03 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:30:03 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:30:03 --> Utf8 Class Initialized
INFO - 2016-11-18 10:30:03 --> URI Class Initialized
DEBUG - 2016-11-18 10:30:03 --> No URI present. Default controller set.
INFO - 2016-11-18 10:30:03 --> Router Class Initialized
INFO - 2016-11-18 10:30:03 --> Output Class Initialized
INFO - 2016-11-18 10:30:03 --> Security Class Initialized
DEBUG - 2016-11-18 10:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:30:03 --> Input Class Initialized
INFO - 2016-11-18 10:30:03 --> Language Class Initialized
INFO - 2016-11-18 10:30:03 --> Loader Class Initialized
INFO - 2016-11-18 10:30:03 --> Helper loaded: url_helper
INFO - 2016-11-18 10:30:03 --> Helper loaded: form_helper
INFO - 2016-11-18 10:30:03 --> Database Driver Class Initialized
INFO - 2016-11-18 10:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:30:03 --> Controller Class Initialized
INFO - 2016-11-18 10:30:03 --> Model Class Initialized
INFO - 2016-11-18 10:30:03 --> Model Class Initialized
INFO - 2016-11-18 10:30:03 --> Model Class Initialized
INFO - 2016-11-18 10:30:03 --> Model Class Initialized
INFO - 2016-11-18 10:30:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 10:30:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 10:30:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 10:30:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 10:30:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 10:30:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 10:30:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 10:30:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 10:30:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 10:30:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 10:30:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 10:30:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 10:30:03 --> Final output sent to browser
DEBUG - 2016-11-18 10:30:03 --> Total execution time: 0.4226
INFO - 2016-11-18 10:33:11 --> Config Class Initialized
INFO - 2016-11-18 10:33:11 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:33:11 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:33:11 --> Utf8 Class Initialized
INFO - 2016-11-18 10:33:11 --> URI Class Initialized
DEBUG - 2016-11-18 10:33:11 --> No URI present. Default controller set.
INFO - 2016-11-18 10:33:11 --> Router Class Initialized
INFO - 2016-11-18 10:33:11 --> Output Class Initialized
INFO - 2016-11-18 10:33:11 --> Security Class Initialized
DEBUG - 2016-11-18 10:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:33:11 --> Input Class Initialized
INFO - 2016-11-18 10:33:11 --> Language Class Initialized
INFO - 2016-11-18 10:33:11 --> Loader Class Initialized
INFO - 2016-11-18 10:33:11 --> Helper loaded: url_helper
INFO - 2016-11-18 10:33:11 --> Helper loaded: form_helper
INFO - 2016-11-18 10:33:11 --> Database Driver Class Initialized
INFO - 2016-11-18 10:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:33:11 --> Controller Class Initialized
INFO - 2016-11-18 10:33:11 --> Model Class Initialized
INFO - 2016-11-18 10:33:11 --> Model Class Initialized
INFO - 2016-11-18 10:33:11 --> Model Class Initialized
INFO - 2016-11-18 10:33:11 --> Model Class Initialized
INFO - 2016-11-18 10:33:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 10:33:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 10:33:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 10:33:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 10:33:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 10:33:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 10:33:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 10:33:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 10:33:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 10:33:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 10:33:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 10:33:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 10:33:11 --> Final output sent to browser
DEBUG - 2016-11-18 10:33:11 --> Total execution time: 0.4294
INFO - 2016-11-18 10:33:15 --> Config Class Initialized
INFO - 2016-11-18 10:33:15 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:33:15 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:33:15 --> Utf8 Class Initialized
INFO - 2016-11-18 10:33:15 --> URI Class Initialized
INFO - 2016-11-18 10:33:15 --> Router Class Initialized
INFO - 2016-11-18 10:33:15 --> Output Class Initialized
INFO - 2016-11-18 10:33:15 --> Security Class Initialized
DEBUG - 2016-11-18 10:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:33:15 --> Input Class Initialized
INFO - 2016-11-18 10:33:15 --> Language Class Initialized
INFO - 2016-11-18 10:33:15 --> Loader Class Initialized
INFO - 2016-11-18 10:33:15 --> Helper loaded: url_helper
INFO - 2016-11-18 10:33:15 --> Helper loaded: form_helper
INFO - 2016-11-18 10:33:15 --> Database Driver Class Initialized
INFO - 2016-11-18 10:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:33:15 --> Controller Class Initialized
INFO - 2016-11-18 10:33:15 --> Model Class Initialized
INFO - 2016-11-18 10:33:15 --> Model Class Initialized
INFO - 2016-11-18 10:33:15 --> Model Class Initialized
INFO - 2016-11-18 10:33:15 --> Model Class Initialized
DEBUG - 2016-11-18 10:33:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-18 10:33:15 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-18 10:33:15 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-18 10:33:15 --> Config Class Initialized
INFO - 2016-11-18 10:33:15 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:33:15 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:33:15 --> Utf8 Class Initialized
INFO - 2016-11-18 10:33:15 --> URI Class Initialized
DEBUG - 2016-11-18 10:33:15 --> No URI present. Default controller set.
INFO - 2016-11-18 10:33:15 --> Router Class Initialized
INFO - 2016-11-18 10:33:15 --> Output Class Initialized
INFO - 2016-11-18 10:33:15 --> Security Class Initialized
DEBUG - 2016-11-18 10:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:33:15 --> Input Class Initialized
INFO - 2016-11-18 10:33:15 --> Language Class Initialized
INFO - 2016-11-18 10:33:15 --> Loader Class Initialized
INFO - 2016-11-18 10:33:15 --> Helper loaded: url_helper
INFO - 2016-11-18 10:33:15 --> Helper loaded: form_helper
INFO - 2016-11-18 10:33:15 --> Database Driver Class Initialized
INFO - 2016-11-18 10:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:33:15 --> Controller Class Initialized
INFO - 2016-11-18 10:33:15 --> Model Class Initialized
INFO - 2016-11-18 10:33:15 --> Model Class Initialized
INFO - 2016-11-18 10:33:15 --> Model Class Initialized
INFO - 2016-11-18 10:33:15 --> Model Class Initialized
INFO - 2016-11-18 10:33:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 10:33:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 10:33:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 10:33:15 --> Final output sent to browser
DEBUG - 2016-11-18 10:33:15 --> Total execution time: 0.3207
INFO - 2016-11-18 10:33:38 --> Config Class Initialized
INFO - 2016-11-18 10:33:38 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:33:38 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:33:38 --> Utf8 Class Initialized
INFO - 2016-11-18 10:33:38 --> URI Class Initialized
INFO - 2016-11-18 10:33:38 --> Router Class Initialized
INFO - 2016-11-18 10:33:38 --> Output Class Initialized
INFO - 2016-11-18 10:33:38 --> Security Class Initialized
DEBUG - 2016-11-18 10:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:33:38 --> Input Class Initialized
INFO - 2016-11-18 10:33:38 --> Language Class Initialized
INFO - 2016-11-18 10:33:38 --> Loader Class Initialized
INFO - 2016-11-18 10:33:38 --> Helper loaded: url_helper
INFO - 2016-11-18 10:33:38 --> Helper loaded: form_helper
INFO - 2016-11-18 10:33:38 --> Database Driver Class Initialized
INFO - 2016-11-18 10:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:33:38 --> Controller Class Initialized
INFO - 2016-11-18 10:33:38 --> Model Class Initialized
INFO - 2016-11-18 10:33:38 --> Model Class Initialized
INFO - 2016-11-18 10:33:38 --> Model Class Initialized
INFO - 2016-11-18 10:33:38 --> Model Class Initialized
DEBUG - 2016-11-18 10:33:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-18 10:33:38 --> Model Class Initialized
INFO - 2016-11-18 10:33:38 --> Final output sent to browser
DEBUG - 2016-11-18 10:33:38 --> Total execution time: 0.2513
INFO - 2016-11-18 10:33:38 --> Config Class Initialized
INFO - 2016-11-18 10:33:38 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:33:38 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:33:38 --> Utf8 Class Initialized
INFO - 2016-11-18 10:33:38 --> URI Class Initialized
DEBUG - 2016-11-18 10:33:38 --> No URI present. Default controller set.
INFO - 2016-11-18 10:33:38 --> Router Class Initialized
INFO - 2016-11-18 10:33:38 --> Output Class Initialized
INFO - 2016-11-18 10:33:38 --> Security Class Initialized
DEBUG - 2016-11-18 10:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:33:38 --> Input Class Initialized
INFO - 2016-11-18 10:33:38 --> Language Class Initialized
INFO - 2016-11-18 10:33:38 --> Loader Class Initialized
INFO - 2016-11-18 10:33:38 --> Helper loaded: url_helper
INFO - 2016-11-18 10:33:38 --> Helper loaded: form_helper
INFO - 2016-11-18 10:33:38 --> Database Driver Class Initialized
INFO - 2016-11-18 10:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:33:39 --> Controller Class Initialized
INFO - 2016-11-18 10:33:39 --> Model Class Initialized
INFO - 2016-11-18 10:33:39 --> Model Class Initialized
INFO - 2016-11-18 10:33:39 --> Model Class Initialized
INFO - 2016-11-18 10:33:39 --> Model Class Initialized
INFO - 2016-11-18 10:33:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 10:33:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 10:33:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 10:33:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-18 10:33:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-18 10:33:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-18 10:33:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 10:33:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-18 10:33:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-18 10:33:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 10:33:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 10:33:39 --> Final output sent to browser
DEBUG - 2016-11-18 10:33:39 --> Total execution time: 0.6681
INFO - 2016-11-18 10:33:44 --> Config Class Initialized
INFO - 2016-11-18 10:33:44 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:33:44 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:33:44 --> Utf8 Class Initialized
INFO - 2016-11-18 10:33:44 --> URI Class Initialized
DEBUG - 2016-11-18 10:33:44 --> No URI present. Default controller set.
INFO - 2016-11-18 10:33:44 --> Router Class Initialized
INFO - 2016-11-18 10:33:44 --> Output Class Initialized
INFO - 2016-11-18 10:33:44 --> Security Class Initialized
DEBUG - 2016-11-18 10:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:33:44 --> Input Class Initialized
INFO - 2016-11-18 10:33:44 --> Language Class Initialized
INFO - 2016-11-18 10:33:44 --> Loader Class Initialized
INFO - 2016-11-18 10:33:44 --> Helper loaded: url_helper
INFO - 2016-11-18 10:33:44 --> Helper loaded: form_helper
INFO - 2016-11-18 10:33:44 --> Database Driver Class Initialized
INFO - 2016-11-18 10:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:33:44 --> Controller Class Initialized
INFO - 2016-11-18 10:33:44 --> Model Class Initialized
INFO - 2016-11-18 10:33:44 --> Model Class Initialized
INFO - 2016-11-18 10:33:44 --> Model Class Initialized
INFO - 2016-11-18 10:33:44 --> Model Class Initialized
INFO - 2016-11-18 10:33:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 10:33:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 10:33:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 10:33:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-18 10:33:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-18 10:33:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-18 10:33:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 10:33:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-18 10:33:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-18 10:33:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 10:33:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 10:33:44 --> Final output sent to browser
DEBUG - 2016-11-18 10:33:44 --> Total execution time: 0.4121
INFO - 2016-11-18 10:34:55 --> Config Class Initialized
INFO - 2016-11-18 10:34:55 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:34:55 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:34:55 --> Utf8 Class Initialized
INFO - 2016-11-18 10:34:55 --> URI Class Initialized
INFO - 2016-11-18 10:34:55 --> Router Class Initialized
INFO - 2016-11-18 10:34:55 --> Output Class Initialized
INFO - 2016-11-18 10:34:55 --> Security Class Initialized
DEBUG - 2016-11-18 10:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:34:55 --> Input Class Initialized
INFO - 2016-11-18 10:34:55 --> Language Class Initialized
INFO - 2016-11-18 10:34:56 --> Loader Class Initialized
INFO - 2016-11-18 10:34:56 --> Helper loaded: url_helper
INFO - 2016-11-18 10:34:56 --> Helper loaded: form_helper
INFO - 2016-11-18 10:34:56 --> Database Driver Class Initialized
INFO - 2016-11-18 10:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:34:56 --> Controller Class Initialized
INFO - 2016-11-18 10:34:56 --> Model Class Initialized
INFO - 2016-11-18 10:34:56 --> Form Validation Class Initialized
INFO - 2016-11-18 10:34:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 10:34:56 --> Final output sent to browser
DEBUG - 2016-11-18 10:34:56 --> Total execution time: 0.4446
INFO - 2016-11-18 10:36:52 --> Config Class Initialized
INFO - 2016-11-18 10:36:52 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:36:52 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:36:52 --> Utf8 Class Initialized
INFO - 2016-11-18 10:36:52 --> URI Class Initialized
DEBUG - 2016-11-18 10:36:52 --> No URI present. Default controller set.
INFO - 2016-11-18 10:36:52 --> Router Class Initialized
INFO - 2016-11-18 10:36:52 --> Output Class Initialized
INFO - 2016-11-18 10:36:52 --> Security Class Initialized
DEBUG - 2016-11-18 10:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:36:52 --> Input Class Initialized
INFO - 2016-11-18 10:36:52 --> Language Class Initialized
INFO - 2016-11-18 10:36:52 --> Loader Class Initialized
INFO - 2016-11-18 10:36:52 --> Helper loaded: url_helper
INFO - 2016-11-18 10:36:52 --> Helper loaded: form_helper
INFO - 2016-11-18 10:36:52 --> Database Driver Class Initialized
INFO - 2016-11-18 10:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:36:52 --> Controller Class Initialized
INFO - 2016-11-18 10:36:52 --> Model Class Initialized
INFO - 2016-11-18 10:36:52 --> Model Class Initialized
INFO - 2016-11-18 10:36:52 --> Model Class Initialized
INFO - 2016-11-18 10:36:52 --> Model Class Initialized
INFO - 2016-11-18 10:36:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 10:36:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 10:36:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 10:36:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-18 10:36:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-18 10:36:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-18 10:36:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 10:36:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-18 10:36:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-18 10:36:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 10:36:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 10:36:52 --> Final output sent to browser
DEBUG - 2016-11-18 10:36:52 --> Total execution time: 0.4156
INFO - 2016-11-18 10:36:55 --> Config Class Initialized
INFO - 2016-11-18 10:36:55 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:36:55 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:36:55 --> Utf8 Class Initialized
INFO - 2016-11-18 10:36:55 --> URI Class Initialized
INFO - 2016-11-18 10:36:55 --> Router Class Initialized
INFO - 2016-11-18 10:36:55 --> Output Class Initialized
INFO - 2016-11-18 10:36:55 --> Security Class Initialized
DEBUG - 2016-11-18 10:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:36:55 --> Input Class Initialized
INFO - 2016-11-18 10:36:55 --> Language Class Initialized
INFO - 2016-11-18 10:36:55 --> Loader Class Initialized
INFO - 2016-11-18 10:36:55 --> Helper loaded: url_helper
INFO - 2016-11-18 10:36:55 --> Helper loaded: form_helper
INFO - 2016-11-18 10:36:55 --> Database Driver Class Initialized
INFO - 2016-11-18 10:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:36:55 --> Controller Class Initialized
INFO - 2016-11-18 10:36:55 --> Model Class Initialized
INFO - 2016-11-18 10:36:55 --> Form Validation Class Initialized
INFO - 2016-11-18 10:36:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 10:36:55 --> Final output sent to browser
DEBUG - 2016-11-18 10:36:55 --> Total execution time: 0.3252
INFO - 2016-11-18 10:37:01 --> Config Class Initialized
INFO - 2016-11-18 10:37:01 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:37:01 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:37:01 --> Utf8 Class Initialized
INFO - 2016-11-18 10:37:01 --> URI Class Initialized
DEBUG - 2016-11-18 10:37:01 --> No URI present. Default controller set.
INFO - 2016-11-18 10:37:01 --> Router Class Initialized
INFO - 2016-11-18 10:37:01 --> Output Class Initialized
INFO - 2016-11-18 10:37:01 --> Security Class Initialized
DEBUG - 2016-11-18 10:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:37:01 --> Input Class Initialized
INFO - 2016-11-18 10:37:01 --> Language Class Initialized
INFO - 2016-11-18 10:37:01 --> Loader Class Initialized
INFO - 2016-11-18 10:37:01 --> Helper loaded: url_helper
INFO - 2016-11-18 10:37:01 --> Helper loaded: form_helper
INFO - 2016-11-18 10:37:01 --> Database Driver Class Initialized
INFO - 2016-11-18 10:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:37:01 --> Controller Class Initialized
INFO - 2016-11-18 10:37:01 --> Model Class Initialized
INFO - 2016-11-18 10:37:01 --> Model Class Initialized
INFO - 2016-11-18 10:37:01 --> Model Class Initialized
INFO - 2016-11-18 10:37:01 --> Model Class Initialized
INFO - 2016-11-18 10:37:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 10:37:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 10:37:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 10:37:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-18 10:37:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-18 10:37:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-18 10:37:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 10:37:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-18 10:37:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-18 10:37:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 10:37:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 10:37:01 --> Final output sent to browser
DEBUG - 2016-11-18 10:37:01 --> Total execution time: 0.4199
INFO - 2016-11-18 10:37:07 --> Config Class Initialized
INFO - 2016-11-18 10:37:07 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:37:07 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:37:07 --> Utf8 Class Initialized
INFO - 2016-11-18 10:37:07 --> URI Class Initialized
INFO - 2016-11-18 10:37:07 --> Router Class Initialized
INFO - 2016-11-18 10:37:07 --> Output Class Initialized
INFO - 2016-11-18 10:37:07 --> Security Class Initialized
DEBUG - 2016-11-18 10:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:37:07 --> Input Class Initialized
INFO - 2016-11-18 10:37:07 --> Language Class Initialized
INFO - 2016-11-18 10:37:07 --> Loader Class Initialized
INFO - 2016-11-18 10:37:07 --> Helper loaded: url_helper
INFO - 2016-11-18 10:37:07 --> Helper loaded: form_helper
INFO - 2016-11-18 10:37:07 --> Database Driver Class Initialized
INFO - 2016-11-18 10:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:37:07 --> Controller Class Initialized
INFO - 2016-11-18 10:37:07 --> Model Class Initialized
INFO - 2016-11-18 10:37:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 10:37:07 --> Final output sent to browser
DEBUG - 2016-11-18 10:37:07 --> Total execution time: 0.4724
INFO - 2016-11-18 10:37:09 --> Config Class Initialized
INFO - 2016-11-18 10:37:09 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:37:09 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:37:09 --> Utf8 Class Initialized
INFO - 2016-11-18 10:37:09 --> URI Class Initialized
DEBUG - 2016-11-18 10:37:09 --> No URI present. Default controller set.
INFO - 2016-11-18 10:37:09 --> Router Class Initialized
INFO - 2016-11-18 10:37:09 --> Output Class Initialized
INFO - 2016-11-18 10:37:09 --> Security Class Initialized
DEBUG - 2016-11-18 10:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:37:09 --> Input Class Initialized
INFO - 2016-11-18 10:37:09 --> Language Class Initialized
INFO - 2016-11-18 10:37:09 --> Loader Class Initialized
INFO - 2016-11-18 10:37:09 --> Helper loaded: url_helper
INFO - 2016-11-18 10:37:09 --> Helper loaded: form_helper
INFO - 2016-11-18 10:37:09 --> Database Driver Class Initialized
INFO - 2016-11-18 10:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:37:09 --> Controller Class Initialized
INFO - 2016-11-18 10:37:09 --> Model Class Initialized
INFO - 2016-11-18 10:37:09 --> Model Class Initialized
INFO - 2016-11-18 10:37:09 --> Model Class Initialized
INFO - 2016-11-18 10:37:09 --> Model Class Initialized
INFO - 2016-11-18 10:37:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 10:37:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 10:37:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 10:37:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-18 10:37:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-18 10:37:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-18 10:37:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 10:37:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-18 10:37:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-18 10:37:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 10:37:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 10:37:09 --> Final output sent to browser
DEBUG - 2016-11-18 10:37:09 --> Total execution time: 0.4476
INFO - 2016-11-18 10:38:56 --> Config Class Initialized
INFO - 2016-11-18 10:38:56 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:38:56 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:38:56 --> Utf8 Class Initialized
INFO - 2016-11-18 10:38:56 --> URI Class Initialized
DEBUG - 2016-11-18 10:38:56 --> No URI present. Default controller set.
INFO - 2016-11-18 10:38:56 --> Router Class Initialized
INFO - 2016-11-18 10:38:56 --> Output Class Initialized
INFO - 2016-11-18 10:38:56 --> Security Class Initialized
DEBUG - 2016-11-18 10:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:38:56 --> Input Class Initialized
INFO - 2016-11-18 10:38:56 --> Language Class Initialized
INFO - 2016-11-18 10:38:56 --> Loader Class Initialized
INFO - 2016-11-18 10:38:56 --> Helper loaded: url_helper
INFO - 2016-11-18 10:38:56 --> Helper loaded: form_helper
INFO - 2016-11-18 10:38:56 --> Database Driver Class Initialized
INFO - 2016-11-18 10:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:38:56 --> Controller Class Initialized
INFO - 2016-11-18 10:38:56 --> Model Class Initialized
INFO - 2016-11-18 10:38:56 --> Model Class Initialized
INFO - 2016-11-18 10:38:56 --> Model Class Initialized
INFO - 2016-11-18 10:38:56 --> Model Class Initialized
INFO - 2016-11-18 10:38:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 10:38:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 10:38:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 10:38:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-18 10:38:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-18 10:38:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-18 10:38:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 10:38:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-18 10:38:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-18 10:38:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 10:38:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 10:38:56 --> Final output sent to browser
DEBUG - 2016-11-18 10:38:56 --> Total execution time: 0.3690
INFO - 2016-11-18 10:39:01 --> Config Class Initialized
INFO - 2016-11-18 10:39:01 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:39:01 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:39:01 --> Utf8 Class Initialized
INFO - 2016-11-18 10:39:01 --> URI Class Initialized
INFO - 2016-11-18 10:39:01 --> Router Class Initialized
INFO - 2016-11-18 10:39:01 --> Output Class Initialized
INFO - 2016-11-18 10:39:01 --> Security Class Initialized
DEBUG - 2016-11-18 10:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:39:01 --> Input Class Initialized
INFO - 2016-11-18 10:39:01 --> Language Class Initialized
INFO - 2016-11-18 10:39:01 --> Loader Class Initialized
INFO - 2016-11-18 10:39:01 --> Helper loaded: url_helper
INFO - 2016-11-18 10:39:01 --> Helper loaded: form_helper
INFO - 2016-11-18 10:39:01 --> Database Driver Class Initialized
INFO - 2016-11-18 10:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:39:01 --> Controller Class Initialized
INFO - 2016-11-18 10:39:01 --> Model Class Initialized
INFO - 2016-11-18 10:39:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 10:39:01 --> Final output sent to browser
DEBUG - 2016-11-18 10:39:01 --> Total execution time: 0.3615
INFO - 2016-11-18 10:39:03 --> Config Class Initialized
INFO - 2016-11-18 10:39:03 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:39:03 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:39:03 --> Utf8 Class Initialized
INFO - 2016-11-18 10:39:03 --> URI Class Initialized
DEBUG - 2016-11-18 10:39:03 --> No URI present. Default controller set.
INFO - 2016-11-18 10:39:03 --> Router Class Initialized
INFO - 2016-11-18 10:39:03 --> Output Class Initialized
INFO - 2016-11-18 10:39:03 --> Security Class Initialized
DEBUG - 2016-11-18 10:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:39:03 --> Input Class Initialized
INFO - 2016-11-18 10:39:03 --> Language Class Initialized
INFO - 2016-11-18 10:39:03 --> Loader Class Initialized
INFO - 2016-11-18 10:39:03 --> Helper loaded: url_helper
INFO - 2016-11-18 10:39:03 --> Helper loaded: form_helper
INFO - 2016-11-18 10:39:03 --> Database Driver Class Initialized
INFO - 2016-11-18 10:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:39:03 --> Controller Class Initialized
INFO - 2016-11-18 10:39:03 --> Model Class Initialized
INFO - 2016-11-18 10:39:03 --> Model Class Initialized
INFO - 2016-11-18 10:39:03 --> Model Class Initialized
INFO - 2016-11-18 10:39:03 --> Model Class Initialized
INFO - 2016-11-18 10:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 10:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 10:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 10:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-18 10:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-18 10:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-18 10:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 10:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-18 10:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-18 10:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 10:39:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 10:39:03 --> Final output sent to browser
DEBUG - 2016-11-18 10:39:03 --> Total execution time: 0.4566
INFO - 2016-11-18 10:39:45 --> Config Class Initialized
INFO - 2016-11-18 10:39:45 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:39:45 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:39:45 --> Utf8 Class Initialized
INFO - 2016-11-18 10:39:45 --> URI Class Initialized
DEBUG - 2016-11-18 10:39:45 --> No URI present. Default controller set.
INFO - 2016-11-18 10:39:45 --> Router Class Initialized
INFO - 2016-11-18 10:39:45 --> Output Class Initialized
INFO - 2016-11-18 10:39:45 --> Security Class Initialized
DEBUG - 2016-11-18 10:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:39:45 --> Input Class Initialized
INFO - 2016-11-18 10:39:46 --> Language Class Initialized
INFO - 2016-11-18 10:39:46 --> Loader Class Initialized
INFO - 2016-11-18 10:39:46 --> Helper loaded: url_helper
INFO - 2016-11-18 10:39:46 --> Helper loaded: form_helper
INFO - 2016-11-18 10:39:46 --> Database Driver Class Initialized
INFO - 2016-11-18 10:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:39:46 --> Controller Class Initialized
INFO - 2016-11-18 10:39:46 --> Model Class Initialized
INFO - 2016-11-18 10:39:46 --> Model Class Initialized
INFO - 2016-11-18 10:39:46 --> Model Class Initialized
INFO - 2016-11-18 10:39:46 --> Model Class Initialized
INFO - 2016-11-18 10:39:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 10:39:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 10:39:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 10:39:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-18 10:39:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-18 10:39:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-18 10:39:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 10:39:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-18 10:39:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-18 10:39:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 10:39:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 10:39:46 --> Final output sent to browser
DEBUG - 2016-11-18 10:39:46 --> Total execution time: 0.3955
INFO - 2016-11-18 10:40:08 --> Config Class Initialized
INFO - 2016-11-18 10:40:08 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:40:08 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:40:08 --> Utf8 Class Initialized
INFO - 2016-11-18 10:40:08 --> URI Class Initialized
INFO - 2016-11-18 10:40:08 --> Router Class Initialized
INFO - 2016-11-18 10:40:08 --> Output Class Initialized
INFO - 2016-11-18 10:40:08 --> Security Class Initialized
DEBUG - 2016-11-18 10:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:40:08 --> Input Class Initialized
INFO - 2016-11-18 10:40:08 --> Language Class Initialized
INFO - 2016-11-18 10:40:08 --> Loader Class Initialized
INFO - 2016-11-18 10:40:08 --> Helper loaded: url_helper
INFO - 2016-11-18 10:40:08 --> Helper loaded: form_helper
INFO - 2016-11-18 10:40:08 --> Database Driver Class Initialized
INFO - 2016-11-18 10:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:40:08 --> Controller Class Initialized
INFO - 2016-11-18 10:40:08 --> Model Class Initialized
INFO - 2016-11-18 10:40:08 --> Form Validation Class Initialized
INFO - 2016-11-18 10:40:08 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-18 10:40:08 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Normal', '3', 'Normal Leave')
INFO - 2016-11-18 10:40:08 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-18 10:40:09 --> Config Class Initialized
INFO - 2016-11-18 10:40:09 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:40:09 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:40:09 --> Utf8 Class Initialized
INFO - 2016-11-18 10:40:09 --> URI Class Initialized
INFO - 2016-11-18 10:40:09 --> Router Class Initialized
INFO - 2016-11-18 10:40:10 --> Output Class Initialized
INFO - 2016-11-18 10:40:10 --> Security Class Initialized
DEBUG - 2016-11-18 10:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:40:10 --> Input Class Initialized
INFO - 2016-11-18 10:40:10 --> Language Class Initialized
INFO - 2016-11-18 10:40:10 --> Loader Class Initialized
INFO - 2016-11-18 10:40:10 --> Helper loaded: url_helper
INFO - 2016-11-18 10:40:10 --> Helper loaded: form_helper
INFO - 2016-11-18 10:40:10 --> Database Driver Class Initialized
INFO - 2016-11-18 10:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:40:10 --> Controller Class Initialized
INFO - 2016-11-18 10:40:10 --> Model Class Initialized
INFO - 2016-11-18 10:40:10 --> Form Validation Class Initialized
INFO - 2016-11-18 10:40:10 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-18 10:40:10 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Normal', '3', 'Normal Leave')
INFO - 2016-11-18 10:40:10 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-18 10:40:10 --> Config Class Initialized
INFO - 2016-11-18 10:40:10 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:40:10 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:40:10 --> Utf8 Class Initialized
INFO - 2016-11-18 10:40:10 --> URI Class Initialized
INFO - 2016-11-18 10:40:10 --> Router Class Initialized
INFO - 2016-11-18 10:40:10 --> Output Class Initialized
INFO - 2016-11-18 10:40:10 --> Security Class Initialized
DEBUG - 2016-11-18 10:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:40:10 --> Input Class Initialized
INFO - 2016-11-18 10:40:10 --> Language Class Initialized
INFO - 2016-11-18 10:40:10 --> Loader Class Initialized
INFO - 2016-11-18 10:40:10 --> Helper loaded: url_helper
INFO - 2016-11-18 10:40:10 --> Helper loaded: form_helper
INFO - 2016-11-18 10:40:10 --> Config Class Initialized
INFO - 2016-11-18 10:40:10 --> Database Driver Class Initialized
INFO - 2016-11-18 10:40:10 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:40:10 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:40:10 --> Utf8 Class Initialized
INFO - 2016-11-18 10:40:10 --> Controller Class Initialized
INFO - 2016-11-18 10:40:10 --> URI Class Initialized
INFO - 2016-11-18 10:40:10 --> Model Class Initialized
INFO - 2016-11-18 10:40:10 --> Router Class Initialized
INFO - 2016-11-18 10:40:10 --> Form Validation Class Initialized
INFO - 2016-11-18 10:40:10 --> Output Class Initialized
INFO - 2016-11-18 10:40:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 10:40:10 --> Security Class Initialized
ERROR - 2016-11-18 10:40:10 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Normal', '3', 'Normal Leave')
DEBUG - 2016-11-18 10:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:40:10 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-18 10:40:10 --> Input Class Initialized
INFO - 2016-11-18 10:40:10 --> Language Class Initialized
INFO - 2016-11-18 10:40:10 --> Loader Class Initialized
INFO - 2016-11-18 10:40:10 --> Helper loaded: url_helper
INFO - 2016-11-18 10:40:10 --> Helper loaded: form_helper
INFO - 2016-11-18 10:40:10 --> Database Driver Class Initialized
INFO - 2016-11-18 10:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:40:10 --> Controller Class Initialized
INFO - 2016-11-18 10:40:10 --> Model Class Initialized
INFO - 2016-11-18 10:40:10 --> Form Validation Class Initialized
INFO - 2016-11-18 10:40:10 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-18 10:40:10 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Normal', '3', 'Normal Leave')
INFO - 2016-11-18 10:40:10 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-18 10:40:11 --> Config Class Initialized
INFO - 2016-11-18 10:40:11 --> Hooks Class Initialized
DEBUG - 2016-11-18 10:40:11 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:40:11 --> Utf8 Class Initialized
INFO - 2016-11-18 10:40:11 --> URI Class Initialized
INFO - 2016-11-18 10:40:11 --> Router Class Initialized
INFO - 2016-11-18 10:40:11 --> Output Class Initialized
INFO - 2016-11-18 10:40:11 --> Security Class Initialized
DEBUG - 2016-11-18 10:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:40:11 --> Input Class Initialized
INFO - 2016-11-18 10:40:11 --> Language Class Initialized
INFO - 2016-11-18 10:40:11 --> Loader Class Initialized
INFO - 2016-11-18 10:40:11 --> Helper loaded: url_helper
INFO - 2016-11-18 10:40:11 --> Helper loaded: form_helper
INFO - 2016-11-18 10:40:11 --> Database Driver Class Initialized
INFO - 2016-11-18 10:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:40:11 --> Controller Class Initialized
INFO - 2016-11-18 10:40:11 --> Config Class Initialized
INFO - 2016-11-18 10:40:11 --> Model Class Initialized
INFO - 2016-11-18 10:40:11 --> Hooks Class Initialized
INFO - 2016-11-18 10:40:11 --> Form Validation Class Initialized
DEBUG - 2016-11-18 10:40:11 --> UTF-8 Support Enabled
INFO - 2016-11-18 10:40:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 10:40:11 --> Utf8 Class Initialized
ERROR - 2016-11-18 10:40:11 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Normal', '3', 'Normal Leave')
INFO - 2016-11-18 10:40:11 --> URI Class Initialized
INFO - 2016-11-18 10:40:11 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-18 10:40:11 --> Router Class Initialized
INFO - 2016-11-18 10:40:11 --> Output Class Initialized
INFO - 2016-11-18 10:40:11 --> Security Class Initialized
DEBUG - 2016-11-18 10:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 10:40:11 --> Input Class Initialized
INFO - 2016-11-18 10:40:11 --> Language Class Initialized
INFO - 2016-11-18 10:40:11 --> Loader Class Initialized
INFO - 2016-11-18 10:40:11 --> Helper loaded: url_helper
INFO - 2016-11-18 10:40:11 --> Helper loaded: form_helper
INFO - 2016-11-18 10:40:11 --> Database Driver Class Initialized
INFO - 2016-11-18 10:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 10:40:11 --> Controller Class Initialized
INFO - 2016-11-18 10:40:11 --> Model Class Initialized
INFO - 2016-11-18 10:40:11 --> Form Validation Class Initialized
INFO - 2016-11-18 10:40:11 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-18 10:40:11 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Normal', '3', 'Normal Leave')
INFO - 2016-11-18 10:40:11 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-18 11:03:57 --> Config Class Initialized
INFO - 2016-11-18 11:03:57 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:03:57 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:03:57 --> Utf8 Class Initialized
INFO - 2016-11-18 11:03:57 --> URI Class Initialized
DEBUG - 2016-11-18 11:03:57 --> No URI present. Default controller set.
INFO - 2016-11-18 11:03:57 --> Router Class Initialized
INFO - 2016-11-18 11:03:57 --> Output Class Initialized
INFO - 2016-11-18 11:03:57 --> Security Class Initialized
DEBUG - 2016-11-18 11:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:03:57 --> Input Class Initialized
INFO - 2016-11-18 11:03:57 --> Language Class Initialized
INFO - 2016-11-18 11:03:57 --> Loader Class Initialized
INFO - 2016-11-18 11:03:57 --> Helper loaded: url_helper
INFO - 2016-11-18 11:03:57 --> Helper loaded: form_helper
INFO - 2016-11-18 11:03:57 --> Database Driver Class Initialized
INFO - 2016-11-18 11:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:03:57 --> Controller Class Initialized
ERROR - 2016-11-18 11:03:57 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\LMS\app\models\Leave_type_m.php 56
INFO - 2016-11-18 11:04:19 --> Config Class Initialized
INFO - 2016-11-18 11:04:19 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:04:19 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:04:19 --> Utf8 Class Initialized
INFO - 2016-11-18 11:04:19 --> URI Class Initialized
DEBUG - 2016-11-18 11:04:19 --> No URI present. Default controller set.
INFO - 2016-11-18 11:04:19 --> Router Class Initialized
INFO - 2016-11-18 11:04:19 --> Output Class Initialized
INFO - 2016-11-18 11:04:19 --> Security Class Initialized
DEBUG - 2016-11-18 11:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:04:19 --> Input Class Initialized
INFO - 2016-11-18 11:04:19 --> Language Class Initialized
INFO - 2016-11-18 11:04:19 --> Loader Class Initialized
INFO - 2016-11-18 11:04:19 --> Helper loaded: url_helper
INFO - 2016-11-18 11:04:19 --> Helper loaded: form_helper
INFO - 2016-11-18 11:04:19 --> Database Driver Class Initialized
INFO - 2016-11-18 11:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:04:19 --> Controller Class Initialized
INFO - 2016-11-18 11:04:19 --> Model Class Initialized
INFO - 2016-11-18 11:04:19 --> Model Class Initialized
INFO - 2016-11-18 11:04:19 --> Model Class Initialized
INFO - 2016-11-18 11:04:19 --> Model Class Initialized
INFO - 2016-11-18 11:04:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:04:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:04:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:04:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-18 11:04:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-18 11:04:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-18 11:04:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 11:04:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-18 11:04:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-18 11:04:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:04:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:04:19 --> Final output sent to browser
DEBUG - 2016-11-18 11:04:19 --> Total execution time: 0.4047
INFO - 2016-11-18 11:04:24 --> Config Class Initialized
INFO - 2016-11-18 11:04:24 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:04:24 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:04:24 --> Utf8 Class Initialized
INFO - 2016-11-18 11:04:24 --> URI Class Initialized
INFO - 2016-11-18 11:04:24 --> Router Class Initialized
INFO - 2016-11-18 11:04:24 --> Output Class Initialized
INFO - 2016-11-18 11:04:24 --> Security Class Initialized
DEBUG - 2016-11-18 11:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:04:24 --> Input Class Initialized
INFO - 2016-11-18 11:04:24 --> Language Class Initialized
INFO - 2016-11-18 11:04:24 --> Loader Class Initialized
INFO - 2016-11-18 11:04:24 --> Helper loaded: url_helper
INFO - 2016-11-18 11:04:24 --> Helper loaded: form_helper
INFO - 2016-11-18 11:04:24 --> Database Driver Class Initialized
INFO - 2016-11-18 11:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:04:24 --> Controller Class Initialized
INFO - 2016-11-18 11:04:24 --> Model Class Initialized
INFO - 2016-11-18 11:04:24 --> Form Validation Class Initialized
INFO - 2016-11-18 11:04:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 11:04:24 --> Final output sent to browser
DEBUG - 2016-11-18 11:04:24 --> Total execution time: 0.2276
INFO - 2016-11-18 11:04:33 --> Config Class Initialized
INFO - 2016-11-18 11:04:33 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:04:33 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:04:33 --> Utf8 Class Initialized
INFO - 2016-11-18 11:04:33 --> URI Class Initialized
INFO - 2016-11-18 11:04:33 --> Router Class Initialized
INFO - 2016-11-18 11:04:33 --> Output Class Initialized
INFO - 2016-11-18 11:04:33 --> Security Class Initialized
DEBUG - 2016-11-18 11:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:04:33 --> Input Class Initialized
INFO - 2016-11-18 11:04:33 --> Language Class Initialized
INFO - 2016-11-18 11:04:33 --> Loader Class Initialized
INFO - 2016-11-18 11:04:33 --> Helper loaded: url_helper
INFO - 2016-11-18 11:04:33 --> Helper loaded: form_helper
INFO - 2016-11-18 11:04:33 --> Database Driver Class Initialized
INFO - 2016-11-18 11:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:04:33 --> Controller Class Initialized
INFO - 2016-11-18 11:04:33 --> Model Class Initialized
INFO - 2016-11-18 11:04:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 11:04:33 --> Final output sent to browser
DEBUG - 2016-11-18 11:04:33 --> Total execution time: 0.2439
INFO - 2016-11-18 11:05:01 --> Config Class Initialized
INFO - 2016-11-18 11:05:01 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:05:01 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:05:01 --> Utf8 Class Initialized
INFO - 2016-11-18 11:05:01 --> URI Class Initialized
INFO - 2016-11-18 11:05:01 --> Router Class Initialized
INFO - 2016-11-18 11:05:01 --> Output Class Initialized
INFO - 2016-11-18 11:05:01 --> Security Class Initialized
DEBUG - 2016-11-18 11:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:05:01 --> Input Class Initialized
INFO - 2016-11-18 11:05:01 --> Language Class Initialized
INFO - 2016-11-18 11:05:02 --> Loader Class Initialized
INFO - 2016-11-18 11:05:02 --> Helper loaded: url_helper
INFO - 2016-11-18 11:05:02 --> Helper loaded: form_helper
INFO - 2016-11-18 11:05:02 --> Database Driver Class Initialized
INFO - 2016-11-18 11:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:05:02 --> Controller Class Initialized
INFO - 2016-11-18 11:05:02 --> Model Class Initialized
INFO - 2016-11-18 11:05:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 11:05:02 --> Final output sent to browser
DEBUG - 2016-11-18 11:05:02 --> Total execution time: 0.2294
INFO - 2016-11-18 11:05:32 --> Config Class Initialized
INFO - 2016-11-18 11:05:32 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:05:32 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:05:32 --> Utf8 Class Initialized
INFO - 2016-11-18 11:05:32 --> URI Class Initialized
INFO - 2016-11-18 11:05:32 --> Router Class Initialized
INFO - 2016-11-18 11:05:32 --> Output Class Initialized
INFO - 2016-11-18 11:05:32 --> Security Class Initialized
DEBUG - 2016-11-18 11:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:05:32 --> Input Class Initialized
INFO - 2016-11-18 11:05:32 --> Language Class Initialized
INFO - 2016-11-18 11:05:32 --> Loader Class Initialized
INFO - 2016-11-18 11:05:32 --> Helper loaded: url_helper
INFO - 2016-11-18 11:05:32 --> Helper loaded: form_helper
INFO - 2016-11-18 11:05:32 --> Database Driver Class Initialized
INFO - 2016-11-18 11:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:05:32 --> Controller Class Initialized
INFO - 2016-11-18 11:05:32 --> Model Class Initialized
INFO - 2016-11-18 11:05:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 11:05:32 --> Final output sent to browser
DEBUG - 2016-11-18 11:05:32 --> Total execution time: 0.2346
INFO - 2016-11-18 11:05:35 --> Config Class Initialized
INFO - 2016-11-18 11:05:35 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:05:35 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:05:35 --> Utf8 Class Initialized
INFO - 2016-11-18 11:05:35 --> URI Class Initialized
DEBUG - 2016-11-18 11:05:35 --> No URI present. Default controller set.
INFO - 2016-11-18 11:05:35 --> Router Class Initialized
INFO - 2016-11-18 11:05:35 --> Output Class Initialized
INFO - 2016-11-18 11:05:35 --> Security Class Initialized
DEBUG - 2016-11-18 11:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:05:35 --> Input Class Initialized
INFO - 2016-11-18 11:05:35 --> Language Class Initialized
INFO - 2016-11-18 11:05:35 --> Loader Class Initialized
INFO - 2016-11-18 11:05:35 --> Helper loaded: url_helper
INFO - 2016-11-18 11:05:35 --> Helper loaded: form_helper
INFO - 2016-11-18 11:05:35 --> Database Driver Class Initialized
INFO - 2016-11-18 11:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:05:35 --> Controller Class Initialized
INFO - 2016-11-18 11:05:35 --> Model Class Initialized
INFO - 2016-11-18 11:05:35 --> Model Class Initialized
INFO - 2016-11-18 11:05:35 --> Model Class Initialized
INFO - 2016-11-18 11:05:35 --> Model Class Initialized
INFO - 2016-11-18 11:05:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:05:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:05:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:05:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-18 11:05:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-18 11:05:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-18 11:05:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 11:05:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-18 11:05:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-18 11:05:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:05:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:05:35 --> Final output sent to browser
DEBUG - 2016-11-18 11:05:35 --> Total execution time: 0.5089
INFO - 2016-11-18 11:05:41 --> Config Class Initialized
INFO - 2016-11-18 11:05:41 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:05:41 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:05:41 --> Utf8 Class Initialized
INFO - 2016-11-18 11:05:41 --> URI Class Initialized
INFO - 2016-11-18 11:05:41 --> Router Class Initialized
INFO - 2016-11-18 11:05:41 --> Output Class Initialized
INFO - 2016-11-18 11:05:41 --> Security Class Initialized
DEBUG - 2016-11-18 11:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:05:41 --> Input Class Initialized
INFO - 2016-11-18 11:05:41 --> Language Class Initialized
INFO - 2016-11-18 11:05:41 --> Loader Class Initialized
INFO - 2016-11-18 11:05:41 --> Helper loaded: url_helper
INFO - 2016-11-18 11:05:41 --> Helper loaded: form_helper
INFO - 2016-11-18 11:05:41 --> Database Driver Class Initialized
INFO - 2016-11-18 11:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:05:41 --> Controller Class Initialized
INFO - 2016-11-18 11:05:41 --> Model Class Initialized
INFO - 2016-11-18 11:05:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 11:05:41 --> Final output sent to browser
DEBUG - 2016-11-18 11:05:41 --> Total execution time: 0.2482
INFO - 2016-11-18 11:05:47 --> Config Class Initialized
INFO - 2016-11-18 11:05:48 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:05:48 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:05:48 --> Utf8 Class Initialized
INFO - 2016-11-18 11:05:48 --> URI Class Initialized
DEBUG - 2016-11-18 11:05:48 --> No URI present. Default controller set.
INFO - 2016-11-18 11:05:48 --> Router Class Initialized
INFO - 2016-11-18 11:05:48 --> Output Class Initialized
INFO - 2016-11-18 11:05:48 --> Security Class Initialized
DEBUG - 2016-11-18 11:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:05:48 --> Input Class Initialized
INFO - 2016-11-18 11:05:48 --> Language Class Initialized
INFO - 2016-11-18 11:05:48 --> Loader Class Initialized
INFO - 2016-11-18 11:05:48 --> Helper loaded: url_helper
INFO - 2016-11-18 11:05:48 --> Helper loaded: form_helper
INFO - 2016-11-18 11:05:48 --> Database Driver Class Initialized
INFO - 2016-11-18 11:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:05:48 --> Controller Class Initialized
INFO - 2016-11-18 11:05:48 --> Model Class Initialized
INFO - 2016-11-18 11:05:48 --> Model Class Initialized
INFO - 2016-11-18 11:05:48 --> Model Class Initialized
INFO - 2016-11-18 11:05:48 --> Model Class Initialized
INFO - 2016-11-18 11:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-18 11:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-18 11:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-18 11:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 11:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-18 11:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-18 11:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:05:48 --> Final output sent to browser
DEBUG - 2016-11-18 11:05:48 --> Total execution time: 0.4253
INFO - 2016-11-18 11:09:32 --> Config Class Initialized
INFO - 2016-11-18 11:09:32 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:09:32 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:09:32 --> Utf8 Class Initialized
INFO - 2016-11-18 11:09:32 --> URI Class Initialized
DEBUG - 2016-11-18 11:09:32 --> No URI present. Default controller set.
INFO - 2016-11-18 11:09:32 --> Router Class Initialized
INFO - 2016-11-18 11:09:32 --> Output Class Initialized
INFO - 2016-11-18 11:09:32 --> Security Class Initialized
DEBUG - 2016-11-18 11:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:09:32 --> Input Class Initialized
INFO - 2016-11-18 11:09:32 --> Language Class Initialized
INFO - 2016-11-18 11:09:32 --> Loader Class Initialized
INFO - 2016-11-18 11:09:32 --> Helper loaded: url_helper
INFO - 2016-11-18 11:09:32 --> Helper loaded: form_helper
INFO - 2016-11-18 11:09:32 --> Database Driver Class Initialized
INFO - 2016-11-18 11:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:09:32 --> Controller Class Initialized
INFO - 2016-11-18 11:09:32 --> Model Class Initialized
INFO - 2016-11-18 11:09:32 --> Model Class Initialized
INFO - 2016-11-18 11:09:32 --> Model Class Initialized
INFO - 2016-11-18 11:09:32 --> Model Class Initialized
INFO - 2016-11-18 11:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-18 11:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-18 11:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-18 11:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 11:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-18 11:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-18 11:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:09:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:09:32 --> Final output sent to browser
DEBUG - 2016-11-18 11:09:32 --> Total execution time: 0.4422
INFO - 2016-11-18 11:09:39 --> Config Class Initialized
INFO - 2016-11-18 11:09:39 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:09:39 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:09:39 --> Utf8 Class Initialized
INFO - 2016-11-18 11:09:39 --> URI Class Initialized
DEBUG - 2016-11-18 11:09:39 --> No URI present. Default controller set.
INFO - 2016-11-18 11:09:39 --> Router Class Initialized
INFO - 2016-11-18 11:09:39 --> Output Class Initialized
INFO - 2016-11-18 11:09:39 --> Security Class Initialized
DEBUG - 2016-11-18 11:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:09:39 --> Input Class Initialized
INFO - 2016-11-18 11:09:39 --> Language Class Initialized
INFO - 2016-11-18 11:09:39 --> Loader Class Initialized
INFO - 2016-11-18 11:09:39 --> Helper loaded: url_helper
INFO - 2016-11-18 11:09:39 --> Helper loaded: form_helper
INFO - 2016-11-18 11:09:39 --> Database Driver Class Initialized
INFO - 2016-11-18 11:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:09:39 --> Controller Class Initialized
INFO - 2016-11-18 11:09:39 --> Model Class Initialized
INFO - 2016-11-18 11:09:39 --> Model Class Initialized
INFO - 2016-11-18 11:09:39 --> Model Class Initialized
INFO - 2016-11-18 11:09:39 --> Model Class Initialized
INFO - 2016-11-18 11:09:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:09:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:09:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:09:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-18 11:09:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-18 11:09:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-18 11:09:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 11:09:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-18 11:09:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-18 11:09:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:09:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:09:39 --> Final output sent to browser
DEBUG - 2016-11-18 11:09:39 --> Total execution time: 0.4591
INFO - 2016-11-18 11:09:46 --> Config Class Initialized
INFO - 2016-11-18 11:09:46 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:09:46 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:09:46 --> Utf8 Class Initialized
INFO - 2016-11-18 11:09:46 --> URI Class Initialized
INFO - 2016-11-18 11:09:46 --> Router Class Initialized
INFO - 2016-11-18 11:09:46 --> Output Class Initialized
INFO - 2016-11-18 11:09:46 --> Security Class Initialized
DEBUG - 2016-11-18 11:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:09:46 --> Input Class Initialized
INFO - 2016-11-18 11:09:46 --> Language Class Initialized
INFO - 2016-11-18 11:09:46 --> Loader Class Initialized
INFO - 2016-11-18 11:09:46 --> Helper loaded: url_helper
INFO - 2016-11-18 11:09:46 --> Helper loaded: form_helper
INFO - 2016-11-18 11:09:46 --> Database Driver Class Initialized
INFO - 2016-11-18 11:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:09:46 --> Controller Class Initialized
INFO - 2016-11-18 11:09:46 --> Model Class Initialized
INFO - 2016-11-18 11:09:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 11:09:46 --> Final output sent to browser
DEBUG - 2016-11-18 11:09:46 --> Total execution time: 0.3418
INFO - 2016-11-18 11:09:49 --> Config Class Initialized
INFO - 2016-11-18 11:09:49 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:09:49 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:09:49 --> Utf8 Class Initialized
INFO - 2016-11-18 11:09:49 --> URI Class Initialized
DEBUG - 2016-11-18 11:09:49 --> No URI present. Default controller set.
INFO - 2016-11-18 11:09:49 --> Router Class Initialized
INFO - 2016-11-18 11:09:49 --> Output Class Initialized
INFO - 2016-11-18 11:09:49 --> Security Class Initialized
DEBUG - 2016-11-18 11:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:09:49 --> Input Class Initialized
INFO - 2016-11-18 11:09:49 --> Language Class Initialized
INFO - 2016-11-18 11:09:49 --> Loader Class Initialized
INFO - 2016-11-18 11:09:49 --> Helper loaded: url_helper
INFO - 2016-11-18 11:09:49 --> Helper loaded: form_helper
INFO - 2016-11-18 11:09:49 --> Database Driver Class Initialized
INFO - 2016-11-18 11:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:09:49 --> Controller Class Initialized
INFO - 2016-11-18 11:09:49 --> Model Class Initialized
INFO - 2016-11-18 11:09:49 --> Model Class Initialized
INFO - 2016-11-18 11:09:49 --> Model Class Initialized
INFO - 2016-11-18 11:09:49 --> Model Class Initialized
INFO - 2016-11-18 11:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-18 11:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-18 11:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-18 11:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 11:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-18 11:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-18 11:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:09:49 --> Final output sent to browser
DEBUG - 2016-11-18 11:09:49 --> Total execution time: 0.4577
INFO - 2016-11-18 11:10:14 --> Config Class Initialized
INFO - 2016-11-18 11:10:14 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:10:14 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:10:14 --> Utf8 Class Initialized
INFO - 2016-11-18 11:10:14 --> URI Class Initialized
DEBUG - 2016-11-18 11:10:14 --> No URI present. Default controller set.
INFO - 2016-11-18 11:10:14 --> Router Class Initialized
INFO - 2016-11-18 11:10:14 --> Output Class Initialized
INFO - 2016-11-18 11:10:14 --> Security Class Initialized
DEBUG - 2016-11-18 11:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:10:14 --> Input Class Initialized
INFO - 2016-11-18 11:10:14 --> Language Class Initialized
INFO - 2016-11-18 11:10:14 --> Loader Class Initialized
INFO - 2016-11-18 11:10:14 --> Helper loaded: url_helper
INFO - 2016-11-18 11:10:14 --> Helper loaded: form_helper
INFO - 2016-11-18 11:10:14 --> Database Driver Class Initialized
INFO - 2016-11-18 11:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:10:14 --> Controller Class Initialized
INFO - 2016-11-18 11:10:14 --> Model Class Initialized
INFO - 2016-11-18 11:10:14 --> Model Class Initialized
INFO - 2016-11-18 11:10:14 --> Model Class Initialized
INFO - 2016-11-18 11:10:14 --> Model Class Initialized
INFO - 2016-11-18 11:10:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:10:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:10:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:10:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-18 11:10:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-18 11:10:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-18 11:10:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 11:10:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-18 11:10:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-18 11:10:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:10:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:10:14 --> Final output sent to browser
DEBUG - 2016-11-18 11:10:15 --> Total execution time: 0.4374
INFO - 2016-11-18 11:13:09 --> Config Class Initialized
INFO - 2016-11-18 11:13:09 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:13:09 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:13:09 --> Utf8 Class Initialized
INFO - 2016-11-18 11:13:09 --> URI Class Initialized
DEBUG - 2016-11-18 11:13:09 --> No URI present. Default controller set.
INFO - 2016-11-18 11:13:09 --> Router Class Initialized
INFO - 2016-11-18 11:13:09 --> Output Class Initialized
INFO - 2016-11-18 11:13:09 --> Security Class Initialized
DEBUG - 2016-11-18 11:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:13:09 --> Input Class Initialized
INFO - 2016-11-18 11:13:09 --> Language Class Initialized
INFO - 2016-11-18 11:13:09 --> Loader Class Initialized
INFO - 2016-11-18 11:13:09 --> Helper loaded: url_helper
INFO - 2016-11-18 11:13:09 --> Helper loaded: form_helper
INFO - 2016-11-18 11:13:09 --> Database Driver Class Initialized
INFO - 2016-11-18 11:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:13:09 --> Controller Class Initialized
INFO - 2016-11-18 11:13:09 --> Model Class Initialized
INFO - 2016-11-18 11:13:09 --> Model Class Initialized
INFO - 2016-11-18 11:13:09 --> Model Class Initialized
INFO - 2016-11-18 11:13:09 --> Model Class Initialized
INFO - 2016-11-18 11:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-18 11:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-18 11:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-18 11:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 11:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-18 11:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-18 11:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:13:09 --> Final output sent to browser
DEBUG - 2016-11-18 11:13:09 --> Total execution time: 0.4136
INFO - 2016-11-18 11:13:22 --> Config Class Initialized
INFO - 2016-11-18 11:13:22 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:13:22 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:13:22 --> Utf8 Class Initialized
INFO - 2016-11-18 11:13:22 --> URI Class Initialized
INFO - 2016-11-18 11:13:22 --> Router Class Initialized
INFO - 2016-11-18 11:13:22 --> Output Class Initialized
INFO - 2016-11-18 11:13:22 --> Security Class Initialized
DEBUG - 2016-11-18 11:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:13:22 --> Input Class Initialized
INFO - 2016-11-18 11:13:22 --> Language Class Initialized
INFO - 2016-11-18 11:13:22 --> Loader Class Initialized
INFO - 2016-11-18 11:13:22 --> Helper loaded: url_helper
INFO - 2016-11-18 11:13:22 --> Helper loaded: form_helper
INFO - 2016-11-18 11:13:22 --> Database Driver Class Initialized
INFO - 2016-11-18 11:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:13:22 --> Controller Class Initialized
INFO - 2016-11-18 11:13:22 --> Model Class Initialized
INFO - 2016-11-18 11:13:22 --> Form Validation Class Initialized
INFO - 2016-11-18 11:13:22 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-18 11:13:22 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`, `bDeleted`) VALUES ('Normal', '3', 'Test', 0)
INFO - 2016-11-18 11:13:22 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-18 11:13:24 --> Config Class Initialized
INFO - 2016-11-18 11:13:24 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:13:24 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:13:24 --> Utf8 Class Initialized
INFO - 2016-11-18 11:13:24 --> URI Class Initialized
INFO - 2016-11-18 11:13:24 --> Router Class Initialized
INFO - 2016-11-18 11:13:24 --> Output Class Initialized
INFO - 2016-11-18 11:13:24 --> Security Class Initialized
DEBUG - 2016-11-18 11:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:13:24 --> Input Class Initialized
INFO - 2016-11-18 11:13:24 --> Language Class Initialized
INFO - 2016-11-18 11:13:24 --> Loader Class Initialized
INFO - 2016-11-18 11:13:24 --> Helper loaded: url_helper
INFO - 2016-11-18 11:13:24 --> Helper loaded: form_helper
INFO - 2016-11-18 11:13:24 --> Database Driver Class Initialized
INFO - 2016-11-18 11:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:13:24 --> Controller Class Initialized
INFO - 2016-11-18 11:13:24 --> Model Class Initialized
INFO - 2016-11-18 11:13:24 --> Form Validation Class Initialized
INFO - 2016-11-18 11:13:24 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-18 11:13:24 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`, `bDeleted`) VALUES ('Normal', '3', 'Test', 0)
INFO - 2016-11-18 11:13:24 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-18 11:13:25 --> Config Class Initialized
INFO - 2016-11-18 11:13:25 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:13:25 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:13:25 --> Utf8 Class Initialized
INFO - 2016-11-18 11:13:25 --> URI Class Initialized
INFO - 2016-11-18 11:13:25 --> Router Class Initialized
INFO - 2016-11-18 11:13:25 --> Output Class Initialized
INFO - 2016-11-18 11:13:25 --> Security Class Initialized
DEBUG - 2016-11-18 11:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:13:25 --> Input Class Initialized
INFO - 2016-11-18 11:13:25 --> Language Class Initialized
INFO - 2016-11-18 11:13:25 --> Loader Class Initialized
INFO - 2016-11-18 11:13:25 --> Helper loaded: url_helper
INFO - 2016-11-18 11:13:25 --> Helper loaded: form_helper
INFO - 2016-11-18 11:13:25 --> Config Class Initialized
INFO - 2016-11-18 11:13:25 --> Database Driver Class Initialized
INFO - 2016-11-18 11:13:25 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:13:25 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:13:25 --> Utf8 Class Initialized
INFO - 2016-11-18 11:13:25 --> Controller Class Initialized
INFO - 2016-11-18 11:13:25 --> URI Class Initialized
INFO - 2016-11-18 11:13:25 --> Model Class Initialized
INFO - 2016-11-18 11:13:25 --> Router Class Initialized
INFO - 2016-11-18 11:13:25 --> Form Validation Class Initialized
INFO - 2016-11-18 11:13:25 --> Output Class Initialized
INFO - 2016-11-18 11:13:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 11:13:25 --> Security Class Initialized
ERROR - 2016-11-18 11:13:25 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`, `bDeleted`) VALUES ('Normal', '3', 'Test', 0)
DEBUG - 2016-11-18 11:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:13:25 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-18 11:13:25 --> Input Class Initialized
INFO - 2016-11-18 11:13:25 --> Language Class Initialized
INFO - 2016-11-18 11:13:25 --> Loader Class Initialized
INFO - 2016-11-18 11:13:25 --> Helper loaded: url_helper
INFO - 2016-11-18 11:13:25 --> Config Class Initialized
INFO - 2016-11-18 11:13:25 --> Helper loaded: form_helper
INFO - 2016-11-18 11:13:25 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:13:25 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:13:25 --> Database Driver Class Initialized
INFO - 2016-11-18 11:13:25 --> Utf8 Class Initialized
INFO - 2016-11-18 11:13:25 --> URI Class Initialized
INFO - 2016-11-18 11:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:13:25 --> Router Class Initialized
INFO - 2016-11-18 11:13:25 --> Controller Class Initialized
INFO - 2016-11-18 11:13:25 --> Model Class Initialized
INFO - 2016-11-18 11:13:25 --> Output Class Initialized
INFO - 2016-11-18 11:13:25 --> Form Validation Class Initialized
INFO - 2016-11-18 11:13:25 --> Security Class Initialized
INFO - 2016-11-18 11:13:25 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-18 11:13:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-11-18 11:13:26 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`, `bDeleted`) VALUES ('Normal', '3', 'Test', 0)
INFO - 2016-11-18 11:13:26 --> Input Class Initialized
INFO - 2016-11-18 11:13:26 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-18 11:13:26 --> Language Class Initialized
INFO - 2016-11-18 11:13:26 --> Loader Class Initialized
INFO - 2016-11-18 11:13:26 --> Helper loaded: url_helper
INFO - 2016-11-18 11:13:26 --> Helper loaded: form_helper
INFO - 2016-11-18 11:13:26 --> Database Driver Class Initialized
INFO - 2016-11-18 11:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:13:26 --> Controller Class Initialized
INFO - 2016-11-18 11:13:26 --> Model Class Initialized
INFO - 2016-11-18 11:13:26 --> Form Validation Class Initialized
INFO - 2016-11-18 11:13:26 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-18 11:13:26 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`, `bDeleted`) VALUES ('Normal', '3', 'Test', 0)
INFO - 2016-11-18 11:13:26 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-18 11:15:32 --> Config Class Initialized
INFO - 2016-11-18 11:15:32 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:15:32 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:15:32 --> Utf8 Class Initialized
INFO - 2016-11-18 11:15:32 --> URI Class Initialized
INFO - 2016-11-18 11:15:32 --> Router Class Initialized
INFO - 2016-11-18 11:15:32 --> Output Class Initialized
INFO - 2016-11-18 11:15:32 --> Security Class Initialized
DEBUG - 2016-11-18 11:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:15:32 --> Input Class Initialized
INFO - 2016-11-18 11:15:32 --> Language Class Initialized
INFO - 2016-11-18 11:15:32 --> Loader Class Initialized
INFO - 2016-11-18 11:15:32 --> Helper loaded: url_helper
INFO - 2016-11-18 11:15:32 --> Helper loaded: form_helper
INFO - 2016-11-18 11:15:32 --> Database Driver Class Initialized
INFO - 2016-11-18 11:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:15:32 --> Controller Class Initialized
INFO - 2016-11-18 11:15:32 --> Model Class Initialized
INFO - 2016-11-18 11:15:32 --> Form Validation Class Initialized
INFO - 2016-11-18 11:15:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 11:15:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 11:15:32 --> Final output sent to browser
DEBUG - 2016-11-18 11:15:32 --> Total execution time: 0.3309
INFO - 2016-11-18 11:16:33 --> Config Class Initialized
INFO - 2016-11-18 11:16:33 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:16:33 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:16:33 --> Utf8 Class Initialized
INFO - 2016-11-18 11:16:33 --> URI Class Initialized
INFO - 2016-11-18 11:16:33 --> Router Class Initialized
INFO - 2016-11-18 11:16:33 --> Output Class Initialized
INFO - 2016-11-18 11:16:33 --> Security Class Initialized
DEBUG - 2016-11-18 11:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:16:33 --> Input Class Initialized
INFO - 2016-11-18 11:16:33 --> Language Class Initialized
INFO - 2016-11-18 11:16:33 --> Loader Class Initialized
INFO - 2016-11-18 11:16:33 --> Helper loaded: url_helper
INFO - 2016-11-18 11:16:33 --> Helper loaded: form_helper
INFO - 2016-11-18 11:16:33 --> Database Driver Class Initialized
INFO - 2016-11-18 11:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:16:33 --> Controller Class Initialized
INFO - 2016-11-18 11:16:33 --> Model Class Initialized
INFO - 2016-11-18 11:16:33 --> Form Validation Class Initialized
INFO - 2016-11-18 11:16:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 11:16:33 --> Final output sent to browser
DEBUG - 2016-11-18 11:16:33 --> Total execution time: 0.4471
INFO - 2016-11-18 11:17:06 --> Config Class Initialized
INFO - 2016-11-18 11:17:06 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:17:06 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:17:06 --> Utf8 Class Initialized
INFO - 2016-11-18 11:17:06 --> URI Class Initialized
DEBUG - 2016-11-18 11:17:06 --> No URI present. Default controller set.
INFO - 2016-11-18 11:17:06 --> Router Class Initialized
INFO - 2016-11-18 11:17:06 --> Output Class Initialized
INFO - 2016-11-18 11:17:06 --> Security Class Initialized
DEBUG - 2016-11-18 11:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:17:06 --> Input Class Initialized
INFO - 2016-11-18 11:17:06 --> Language Class Initialized
INFO - 2016-11-18 11:17:06 --> Loader Class Initialized
INFO - 2016-11-18 11:17:06 --> Helper loaded: url_helper
INFO - 2016-11-18 11:17:06 --> Helper loaded: form_helper
INFO - 2016-11-18 11:17:06 --> Database Driver Class Initialized
INFO - 2016-11-18 11:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:17:06 --> Controller Class Initialized
INFO - 2016-11-18 11:17:06 --> Model Class Initialized
INFO - 2016-11-18 11:17:06 --> Model Class Initialized
INFO - 2016-11-18 11:17:06 --> Model Class Initialized
INFO - 2016-11-18 11:17:06 --> Model Class Initialized
INFO - 2016-11-18 11:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-18 11:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-18 11:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-18 11:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 11:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-18 11:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-18 11:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:17:06 --> Final output sent to browser
DEBUG - 2016-11-18 11:17:06 --> Total execution time: 0.4683
INFO - 2016-11-18 11:17:17 --> Config Class Initialized
INFO - 2016-11-18 11:17:17 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:17:17 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:17:17 --> Utf8 Class Initialized
INFO - 2016-11-18 11:17:17 --> URI Class Initialized
INFO - 2016-11-18 11:17:17 --> Router Class Initialized
INFO - 2016-11-18 11:17:17 --> Output Class Initialized
INFO - 2016-11-18 11:17:17 --> Security Class Initialized
DEBUG - 2016-11-18 11:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:17:17 --> Input Class Initialized
INFO - 2016-11-18 11:17:17 --> Language Class Initialized
INFO - 2016-11-18 11:17:17 --> Loader Class Initialized
INFO - 2016-11-18 11:17:17 --> Helper loaded: url_helper
INFO - 2016-11-18 11:17:17 --> Helper loaded: form_helper
INFO - 2016-11-18 11:17:17 --> Database Driver Class Initialized
INFO - 2016-11-18 11:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:17:17 --> Controller Class Initialized
INFO - 2016-11-18 11:17:17 --> Model Class Initialized
INFO - 2016-11-18 11:17:17 --> Model Class Initialized
INFO - 2016-11-18 11:17:17 --> Model Class Initialized
INFO - 2016-11-18 11:17:17 --> Model Class Initialized
DEBUG - 2016-11-18 11:17:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-18 11:17:17 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-18 11:17:17 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-18 11:17:17 --> Config Class Initialized
INFO - 2016-11-18 11:17:17 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:17:17 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:17:17 --> Utf8 Class Initialized
INFO - 2016-11-18 11:17:17 --> URI Class Initialized
DEBUG - 2016-11-18 11:17:17 --> No URI present. Default controller set.
INFO - 2016-11-18 11:17:17 --> Router Class Initialized
INFO - 2016-11-18 11:17:17 --> Output Class Initialized
INFO - 2016-11-18 11:17:17 --> Security Class Initialized
DEBUG - 2016-11-18 11:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:17:17 --> Input Class Initialized
INFO - 2016-11-18 11:17:17 --> Language Class Initialized
INFO - 2016-11-18 11:17:17 --> Loader Class Initialized
INFO - 2016-11-18 11:17:17 --> Helper loaded: url_helper
INFO - 2016-11-18 11:17:17 --> Helper loaded: form_helper
INFO - 2016-11-18 11:17:17 --> Database Driver Class Initialized
INFO - 2016-11-18 11:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:17:17 --> Controller Class Initialized
INFO - 2016-11-18 11:17:17 --> Model Class Initialized
INFO - 2016-11-18 11:17:17 --> Model Class Initialized
INFO - 2016-11-18 11:17:17 --> Model Class Initialized
INFO - 2016-11-18 11:17:17 --> Model Class Initialized
INFO - 2016-11-18 11:17:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:17:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 11:17:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:17:17 --> Final output sent to browser
DEBUG - 2016-11-18 11:17:17 --> Total execution time: 0.3193
INFO - 2016-11-18 11:17:28 --> Config Class Initialized
INFO - 2016-11-18 11:17:28 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:17:28 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:17:28 --> Utf8 Class Initialized
INFO - 2016-11-18 11:17:28 --> URI Class Initialized
INFO - 2016-11-18 11:17:28 --> Router Class Initialized
INFO - 2016-11-18 11:17:28 --> Output Class Initialized
INFO - 2016-11-18 11:17:28 --> Security Class Initialized
DEBUG - 2016-11-18 11:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:17:28 --> Input Class Initialized
INFO - 2016-11-18 11:17:28 --> Language Class Initialized
INFO - 2016-11-18 11:17:28 --> Loader Class Initialized
INFO - 2016-11-18 11:17:28 --> Helper loaded: url_helper
INFO - 2016-11-18 11:17:28 --> Helper loaded: form_helper
INFO - 2016-11-18 11:17:28 --> Database Driver Class Initialized
INFO - 2016-11-18 11:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:17:28 --> Controller Class Initialized
INFO - 2016-11-18 11:17:28 --> Model Class Initialized
INFO - 2016-11-18 11:17:28 --> Model Class Initialized
INFO - 2016-11-18 11:17:28 --> Model Class Initialized
INFO - 2016-11-18 11:17:28 --> Model Class Initialized
DEBUG - 2016-11-18 11:17:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-18 11:17:28 --> Model Class Initialized
INFO - 2016-11-18 11:17:28 --> Final output sent to browser
DEBUG - 2016-11-18 11:17:28 --> Total execution time: 0.3050
INFO - 2016-11-18 11:17:28 --> Config Class Initialized
INFO - 2016-11-18 11:17:28 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:17:28 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:17:28 --> Utf8 Class Initialized
INFO - 2016-11-18 11:17:28 --> URI Class Initialized
DEBUG - 2016-11-18 11:17:28 --> No URI present. Default controller set.
INFO - 2016-11-18 11:17:28 --> Router Class Initialized
INFO - 2016-11-18 11:17:28 --> Output Class Initialized
INFO - 2016-11-18 11:17:28 --> Security Class Initialized
DEBUG - 2016-11-18 11:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:17:28 --> Input Class Initialized
INFO - 2016-11-18 11:17:28 --> Language Class Initialized
INFO - 2016-11-18 11:17:28 --> Loader Class Initialized
INFO - 2016-11-18 11:17:28 --> Helper loaded: url_helper
INFO - 2016-11-18 11:17:28 --> Helper loaded: form_helper
INFO - 2016-11-18 11:17:28 --> Database Driver Class Initialized
INFO - 2016-11-18 11:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:17:28 --> Controller Class Initialized
INFO - 2016-11-18 11:17:28 --> Model Class Initialized
INFO - 2016-11-18 11:17:28 --> Model Class Initialized
INFO - 2016-11-18 11:17:28 --> Model Class Initialized
INFO - 2016-11-18 11:17:28 --> Model Class Initialized
INFO - 2016-11-18 11:17:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:17:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:17:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:17:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:17:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:17:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:17:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:17:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:17:28 --> Final output sent to browser
DEBUG - 2016-11-18 11:17:29 --> Total execution time: 0.3904
INFO - 2016-11-18 11:17:55 --> Config Class Initialized
INFO - 2016-11-18 11:17:55 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:17:55 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:17:55 --> Utf8 Class Initialized
INFO - 2016-11-18 11:17:55 --> URI Class Initialized
INFO - 2016-11-18 11:17:55 --> Router Class Initialized
INFO - 2016-11-18 11:17:55 --> Output Class Initialized
INFO - 2016-11-18 11:17:55 --> Security Class Initialized
DEBUG - 2016-11-18 11:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:17:55 --> Input Class Initialized
INFO - 2016-11-18 11:17:55 --> Language Class Initialized
INFO - 2016-11-18 11:17:55 --> Loader Class Initialized
INFO - 2016-11-18 11:17:55 --> Helper loaded: url_helper
INFO - 2016-11-18 11:17:55 --> Helper loaded: form_helper
INFO - 2016-11-18 11:17:55 --> Database Driver Class Initialized
INFO - 2016-11-18 11:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:17:56 --> Controller Class Initialized
INFO - 2016-11-18 11:17:56 --> Model Class Initialized
INFO - 2016-11-18 11:17:56 --> Form Validation Class Initialized
INFO - 2016-11-18 11:17:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 11:17:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:17:56 --> Final output sent to browser
DEBUG - 2016-11-18 11:17:56 --> Total execution time: 0.3715
INFO - 2016-11-18 11:17:58 --> Config Class Initialized
INFO - 2016-11-18 11:17:58 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:17:58 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:17:58 --> Utf8 Class Initialized
INFO - 2016-11-18 11:17:58 --> URI Class Initialized
DEBUG - 2016-11-18 11:17:58 --> No URI present. Default controller set.
INFO - 2016-11-18 11:17:58 --> Router Class Initialized
INFO - 2016-11-18 11:17:58 --> Output Class Initialized
INFO - 2016-11-18 11:17:58 --> Security Class Initialized
DEBUG - 2016-11-18 11:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:17:58 --> Input Class Initialized
INFO - 2016-11-18 11:17:58 --> Language Class Initialized
INFO - 2016-11-18 11:17:58 --> Loader Class Initialized
INFO - 2016-11-18 11:17:58 --> Helper loaded: url_helper
INFO - 2016-11-18 11:17:58 --> Helper loaded: form_helper
INFO - 2016-11-18 11:17:58 --> Database Driver Class Initialized
INFO - 2016-11-18 11:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:17:58 --> Controller Class Initialized
INFO - 2016-11-18 11:17:58 --> Model Class Initialized
INFO - 2016-11-18 11:17:58 --> Model Class Initialized
INFO - 2016-11-18 11:17:58 --> Model Class Initialized
INFO - 2016-11-18 11:17:58 --> Model Class Initialized
INFO - 2016-11-18 11:17:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:17:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:17:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:17:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:17:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:17:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:17:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:17:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:17:58 --> Final output sent to browser
DEBUG - 2016-11-18 11:17:58 --> Total execution time: 0.4326
INFO - 2016-11-18 11:18:34 --> Config Class Initialized
INFO - 2016-11-18 11:18:34 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:18:34 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:18:34 --> Utf8 Class Initialized
INFO - 2016-11-18 11:18:34 --> URI Class Initialized
DEBUG - 2016-11-18 11:18:34 --> No URI present. Default controller set.
INFO - 2016-11-18 11:18:34 --> Router Class Initialized
INFO - 2016-11-18 11:18:34 --> Output Class Initialized
INFO - 2016-11-18 11:18:34 --> Security Class Initialized
DEBUG - 2016-11-18 11:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:18:34 --> Input Class Initialized
INFO - 2016-11-18 11:18:34 --> Language Class Initialized
INFO - 2016-11-18 11:18:34 --> Loader Class Initialized
INFO - 2016-11-18 11:18:34 --> Helper loaded: url_helper
INFO - 2016-11-18 11:18:34 --> Helper loaded: form_helper
INFO - 2016-11-18 11:18:34 --> Database Driver Class Initialized
INFO - 2016-11-18 11:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:18:34 --> Controller Class Initialized
INFO - 2016-11-18 11:18:34 --> Model Class Initialized
INFO - 2016-11-18 11:18:34 --> Model Class Initialized
INFO - 2016-11-18 11:18:34 --> Model Class Initialized
INFO - 2016-11-18 11:18:34 --> Model Class Initialized
INFO - 2016-11-18 11:18:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:18:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:18:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:18:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:18:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:18:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:18:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:18:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:18:34 --> Final output sent to browser
DEBUG - 2016-11-18 11:18:34 --> Total execution time: 0.4121
INFO - 2016-11-18 11:19:27 --> Config Class Initialized
INFO - 2016-11-18 11:19:27 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:19:27 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:19:27 --> Utf8 Class Initialized
INFO - 2016-11-18 11:19:27 --> URI Class Initialized
INFO - 2016-11-18 11:19:27 --> Router Class Initialized
INFO - 2016-11-18 11:19:27 --> Output Class Initialized
INFO - 2016-11-18 11:19:27 --> Security Class Initialized
DEBUG - 2016-11-18 11:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:19:27 --> Input Class Initialized
INFO - 2016-11-18 11:19:27 --> Language Class Initialized
INFO - 2016-11-18 11:19:27 --> Loader Class Initialized
INFO - 2016-11-18 11:19:27 --> Helper loaded: url_helper
INFO - 2016-11-18 11:19:28 --> Helper loaded: form_helper
INFO - 2016-11-18 11:19:28 --> Database Driver Class Initialized
INFO - 2016-11-18 11:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:19:28 --> Controller Class Initialized
INFO - 2016-11-18 11:19:28 --> Model Class Initialized
INFO - 2016-11-18 11:19:28 --> Model Class Initialized
INFO - 2016-11-18 11:19:28 --> Model Class Initialized
INFO - 2016-11-18 11:19:28 --> Model Class Initialized
DEBUG - 2016-11-18 11:19:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-18 11:19:28 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-18 11:19:28 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-18 11:19:28 --> Config Class Initialized
INFO - 2016-11-18 11:19:28 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:19:28 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:19:28 --> Utf8 Class Initialized
INFO - 2016-11-18 11:19:28 --> URI Class Initialized
DEBUG - 2016-11-18 11:19:28 --> No URI present. Default controller set.
INFO - 2016-11-18 11:19:28 --> Router Class Initialized
INFO - 2016-11-18 11:19:28 --> Output Class Initialized
INFO - 2016-11-18 11:19:28 --> Security Class Initialized
DEBUG - 2016-11-18 11:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:19:28 --> Input Class Initialized
INFO - 2016-11-18 11:19:28 --> Language Class Initialized
INFO - 2016-11-18 11:19:28 --> Loader Class Initialized
INFO - 2016-11-18 11:19:28 --> Helper loaded: url_helper
INFO - 2016-11-18 11:19:28 --> Helper loaded: form_helper
INFO - 2016-11-18 11:19:28 --> Database Driver Class Initialized
INFO - 2016-11-18 11:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:19:28 --> Controller Class Initialized
INFO - 2016-11-18 11:19:28 --> Model Class Initialized
INFO - 2016-11-18 11:19:28 --> Model Class Initialized
INFO - 2016-11-18 11:19:28 --> Model Class Initialized
INFO - 2016-11-18 11:19:28 --> Model Class Initialized
INFO - 2016-11-18 11:19:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:19:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 11:19:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:19:28 --> Final output sent to browser
DEBUG - 2016-11-18 11:19:28 --> Total execution time: 0.3205
INFO - 2016-11-18 11:20:14 --> Config Class Initialized
INFO - 2016-11-18 11:20:14 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:20:14 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:20:14 --> Utf8 Class Initialized
INFO - 2016-11-18 11:20:14 --> URI Class Initialized
INFO - 2016-11-18 11:20:14 --> Router Class Initialized
INFO - 2016-11-18 11:20:14 --> Output Class Initialized
INFO - 2016-11-18 11:20:14 --> Security Class Initialized
DEBUG - 2016-11-18 11:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:20:14 --> Input Class Initialized
INFO - 2016-11-18 11:20:14 --> Language Class Initialized
INFO - 2016-11-18 11:20:14 --> Loader Class Initialized
INFO - 2016-11-18 11:20:14 --> Helper loaded: url_helper
INFO - 2016-11-18 11:20:14 --> Helper loaded: form_helper
INFO - 2016-11-18 11:20:14 --> Database Driver Class Initialized
INFO - 2016-11-18 11:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:20:14 --> Controller Class Initialized
INFO - 2016-11-18 11:20:14 --> Model Class Initialized
INFO - 2016-11-18 11:20:14 --> Model Class Initialized
INFO - 2016-11-18 11:20:14 --> Model Class Initialized
INFO - 2016-11-18 11:20:14 --> Model Class Initialized
DEBUG - 2016-11-18 11:20:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-18 11:20:14 --> Model Class Initialized
INFO - 2016-11-18 11:20:14 --> Final output sent to browser
DEBUG - 2016-11-18 11:20:14 --> Total execution time: 0.2837
INFO - 2016-11-18 11:20:14 --> Config Class Initialized
INFO - 2016-11-18 11:20:14 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:20:14 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:20:14 --> Utf8 Class Initialized
INFO - 2016-11-18 11:20:14 --> URI Class Initialized
DEBUG - 2016-11-18 11:20:14 --> No URI present. Default controller set.
INFO - 2016-11-18 11:20:14 --> Router Class Initialized
INFO - 2016-11-18 11:20:14 --> Output Class Initialized
INFO - 2016-11-18 11:20:14 --> Security Class Initialized
DEBUG - 2016-11-18 11:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:20:14 --> Input Class Initialized
INFO - 2016-11-18 11:20:14 --> Language Class Initialized
INFO - 2016-11-18 11:20:14 --> Loader Class Initialized
INFO - 2016-11-18 11:20:14 --> Helper loaded: url_helper
INFO - 2016-11-18 11:20:14 --> Helper loaded: form_helper
INFO - 2016-11-18 11:20:14 --> Database Driver Class Initialized
INFO - 2016-11-18 11:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:20:14 --> Controller Class Initialized
INFO - 2016-11-18 11:20:14 --> Model Class Initialized
INFO - 2016-11-18 11:20:14 --> Model Class Initialized
INFO - 2016-11-18 11:20:14 --> Model Class Initialized
INFO - 2016-11-18 11:20:14 --> Model Class Initialized
INFO - 2016-11-18 11:20:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:20:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:20:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:20:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:20:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:20:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:20:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:20:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:20:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:20:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:20:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:20:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:20:14 --> Final output sent to browser
DEBUG - 2016-11-18 11:20:14 --> Total execution time: 0.4539
INFO - 2016-11-18 11:21:15 --> Config Class Initialized
INFO - 2016-11-18 11:21:15 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:21:15 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:21:15 --> Utf8 Class Initialized
INFO - 2016-11-18 11:21:15 --> URI Class Initialized
DEBUG - 2016-11-18 11:21:15 --> No URI present. Default controller set.
INFO - 2016-11-18 11:21:15 --> Router Class Initialized
INFO - 2016-11-18 11:21:15 --> Output Class Initialized
INFO - 2016-11-18 11:21:15 --> Security Class Initialized
DEBUG - 2016-11-18 11:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:21:15 --> Input Class Initialized
INFO - 2016-11-18 11:21:15 --> Language Class Initialized
INFO - 2016-11-18 11:21:15 --> Loader Class Initialized
INFO - 2016-11-18 11:21:15 --> Helper loaded: url_helper
INFO - 2016-11-18 11:21:15 --> Helper loaded: form_helper
INFO - 2016-11-18 11:21:15 --> Database Driver Class Initialized
INFO - 2016-11-18 11:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:21:15 --> Controller Class Initialized
INFO - 2016-11-18 11:21:15 --> Model Class Initialized
INFO - 2016-11-18 11:21:15 --> Model Class Initialized
INFO - 2016-11-18 11:21:15 --> Model Class Initialized
INFO - 2016-11-18 11:21:15 --> Model Class Initialized
INFO - 2016-11-18 11:21:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:21:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:21:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:21:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:21:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:21:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:21:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:21:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:21:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:21:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:21:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:21:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:21:16 --> Final output sent to browser
DEBUG - 2016-11-18 11:21:16 --> Total execution time: 0.4896
INFO - 2016-11-18 11:24:26 --> Config Class Initialized
INFO - 2016-11-18 11:24:26 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:24:26 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:24:26 --> Utf8 Class Initialized
INFO - 2016-11-18 11:24:26 --> URI Class Initialized
INFO - 2016-11-18 11:24:26 --> Router Class Initialized
INFO - 2016-11-18 11:24:26 --> Output Class Initialized
INFO - 2016-11-18 11:24:26 --> Security Class Initialized
DEBUG - 2016-11-18 11:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:24:26 --> Input Class Initialized
INFO - 2016-11-18 11:24:26 --> Language Class Initialized
INFO - 2016-11-18 11:24:26 --> Loader Class Initialized
INFO - 2016-11-18 11:24:26 --> Helper loaded: url_helper
INFO - 2016-11-18 11:24:26 --> Helper loaded: form_helper
INFO - 2016-11-18 11:24:26 --> Database Driver Class Initialized
INFO - 2016-11-18 11:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:24:26 --> Controller Class Initialized
INFO - 2016-11-18 11:24:26 --> Model Class Initialized
INFO - 2016-11-18 11:24:26 --> Model Class Initialized
INFO - 2016-11-18 11:24:26 --> Model Class Initialized
INFO - 2016-11-18 11:24:26 --> Model Class Initialized
DEBUG - 2016-11-18 11:24:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-18 11:24:26 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-18 11:24:26 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-18 11:24:26 --> Config Class Initialized
INFO - 2016-11-18 11:24:26 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:24:26 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:24:26 --> Utf8 Class Initialized
INFO - 2016-11-18 11:24:26 --> URI Class Initialized
DEBUG - 2016-11-18 11:24:26 --> No URI present. Default controller set.
INFO - 2016-11-18 11:24:26 --> Router Class Initialized
INFO - 2016-11-18 11:24:26 --> Output Class Initialized
INFO - 2016-11-18 11:24:26 --> Security Class Initialized
DEBUG - 2016-11-18 11:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:24:26 --> Input Class Initialized
INFO - 2016-11-18 11:24:26 --> Language Class Initialized
INFO - 2016-11-18 11:24:26 --> Loader Class Initialized
INFO - 2016-11-18 11:24:26 --> Helper loaded: url_helper
INFO - 2016-11-18 11:24:26 --> Helper loaded: form_helper
INFO - 2016-11-18 11:24:26 --> Database Driver Class Initialized
INFO - 2016-11-18 11:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:24:26 --> Controller Class Initialized
INFO - 2016-11-18 11:24:26 --> Model Class Initialized
INFO - 2016-11-18 11:24:26 --> Model Class Initialized
INFO - 2016-11-18 11:24:26 --> Model Class Initialized
INFO - 2016-11-18 11:24:26 --> Model Class Initialized
INFO - 2016-11-18 11:24:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:24:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 11:24:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:24:26 --> Final output sent to browser
DEBUG - 2016-11-18 11:24:26 --> Total execution time: 0.3305
INFO - 2016-11-18 11:24:35 --> Config Class Initialized
INFO - 2016-11-18 11:24:35 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:24:35 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:24:35 --> Utf8 Class Initialized
INFO - 2016-11-18 11:24:35 --> URI Class Initialized
INFO - 2016-11-18 11:24:35 --> Router Class Initialized
INFO - 2016-11-18 11:24:35 --> Output Class Initialized
INFO - 2016-11-18 11:24:35 --> Security Class Initialized
DEBUG - 2016-11-18 11:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:24:35 --> Input Class Initialized
INFO - 2016-11-18 11:24:35 --> Language Class Initialized
INFO - 2016-11-18 11:24:35 --> Loader Class Initialized
INFO - 2016-11-18 11:24:35 --> Helper loaded: url_helper
INFO - 2016-11-18 11:24:35 --> Helper loaded: form_helper
INFO - 2016-11-18 11:24:35 --> Database Driver Class Initialized
INFO - 2016-11-18 11:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:24:35 --> Controller Class Initialized
INFO - 2016-11-18 11:24:35 --> Model Class Initialized
INFO - 2016-11-18 11:24:36 --> Model Class Initialized
INFO - 2016-11-18 11:24:36 --> Model Class Initialized
INFO - 2016-11-18 11:24:36 --> Model Class Initialized
DEBUG - 2016-11-18 11:24:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-18 11:24:36 --> Model Class Initialized
INFO - 2016-11-18 11:24:36 --> Final output sent to browser
DEBUG - 2016-11-18 11:24:36 --> Total execution time: 0.3189
INFO - 2016-11-18 11:24:36 --> Config Class Initialized
INFO - 2016-11-18 11:24:36 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:24:36 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:24:36 --> Utf8 Class Initialized
INFO - 2016-11-18 11:24:36 --> URI Class Initialized
DEBUG - 2016-11-18 11:24:36 --> No URI present. Default controller set.
INFO - 2016-11-18 11:24:36 --> Router Class Initialized
INFO - 2016-11-18 11:24:36 --> Output Class Initialized
INFO - 2016-11-18 11:24:36 --> Security Class Initialized
DEBUG - 2016-11-18 11:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:24:36 --> Input Class Initialized
INFO - 2016-11-18 11:24:36 --> Language Class Initialized
INFO - 2016-11-18 11:24:36 --> Loader Class Initialized
INFO - 2016-11-18 11:24:36 --> Helper loaded: url_helper
INFO - 2016-11-18 11:24:36 --> Helper loaded: form_helper
INFO - 2016-11-18 11:24:36 --> Database Driver Class Initialized
INFO - 2016-11-18 11:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:24:36 --> Controller Class Initialized
INFO - 2016-11-18 11:24:36 --> Model Class Initialized
INFO - 2016-11-18 11:24:36 --> Model Class Initialized
INFO - 2016-11-18 11:24:36 --> Model Class Initialized
INFO - 2016-11-18 11:24:36 --> Model Class Initialized
INFO - 2016-11-18 11:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:24:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:24:36 --> Final output sent to browser
DEBUG - 2016-11-18 11:24:36 --> Total execution time: 0.4674
INFO - 2016-11-18 11:28:11 --> Config Class Initialized
INFO - 2016-11-18 11:28:11 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:28:11 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:28:11 --> Utf8 Class Initialized
INFO - 2016-11-18 11:28:11 --> URI Class Initialized
DEBUG - 2016-11-18 11:28:11 --> No URI present. Default controller set.
INFO - 2016-11-18 11:28:11 --> Router Class Initialized
INFO - 2016-11-18 11:28:11 --> Output Class Initialized
INFO - 2016-11-18 11:28:11 --> Security Class Initialized
DEBUG - 2016-11-18 11:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:28:11 --> Input Class Initialized
INFO - 2016-11-18 11:28:11 --> Language Class Initialized
INFO - 2016-11-18 11:28:11 --> Loader Class Initialized
INFO - 2016-11-18 11:28:11 --> Helper loaded: url_helper
INFO - 2016-11-18 11:28:11 --> Helper loaded: form_helper
INFO - 2016-11-18 11:28:11 --> Database Driver Class Initialized
INFO - 2016-11-18 11:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:28:11 --> Controller Class Initialized
INFO - 2016-11-18 11:28:11 --> Model Class Initialized
INFO - 2016-11-18 11:28:11 --> Model Class Initialized
INFO - 2016-11-18 11:28:11 --> Model Class Initialized
INFO - 2016-11-18 11:28:11 --> Model Class Initialized
INFO - 2016-11-18 11:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:28:11 --> Final output sent to browser
DEBUG - 2016-11-18 11:28:11 --> Total execution time: 0.4802
INFO - 2016-11-18 11:28:14 --> Config Class Initialized
INFO - 2016-11-18 11:28:14 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:28:14 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:28:14 --> Utf8 Class Initialized
INFO - 2016-11-18 11:28:14 --> URI Class Initialized
INFO - 2016-11-18 11:28:14 --> Router Class Initialized
INFO - 2016-11-18 11:28:14 --> Output Class Initialized
INFO - 2016-11-18 11:28:14 --> Security Class Initialized
DEBUG - 2016-11-18 11:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:28:14 --> Input Class Initialized
INFO - 2016-11-18 11:28:14 --> Language Class Initialized
INFO - 2016-11-18 11:28:14 --> Loader Class Initialized
INFO - 2016-11-18 11:28:14 --> Helper loaded: url_helper
INFO - 2016-11-18 11:28:14 --> Helper loaded: form_helper
INFO - 2016-11-18 11:28:14 --> Database Driver Class Initialized
INFO - 2016-11-18 11:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:28:14 --> Controller Class Initialized
INFO - 2016-11-18 11:28:14 --> Model Class Initialized
INFO - 2016-11-18 11:28:14 --> Form Validation Class Initialized
INFO - 2016-11-18 11:28:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 11:28:14 --> Final output sent to browser
DEBUG - 2016-11-18 11:28:15 --> Total execution time: 0.2550
INFO - 2016-11-18 11:28:28 --> Config Class Initialized
INFO - 2016-11-18 11:28:28 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:28:28 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:28:28 --> Utf8 Class Initialized
INFO - 2016-11-18 11:28:28 --> URI Class Initialized
DEBUG - 2016-11-18 11:28:28 --> No URI present. Default controller set.
INFO - 2016-11-18 11:28:28 --> Router Class Initialized
INFO - 2016-11-18 11:28:28 --> Output Class Initialized
INFO - 2016-11-18 11:28:28 --> Security Class Initialized
DEBUG - 2016-11-18 11:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:28:28 --> Input Class Initialized
INFO - 2016-11-18 11:28:28 --> Language Class Initialized
INFO - 2016-11-18 11:28:28 --> Loader Class Initialized
INFO - 2016-11-18 11:28:28 --> Helper loaded: url_helper
INFO - 2016-11-18 11:28:28 --> Helper loaded: form_helper
INFO - 2016-11-18 11:28:29 --> Database Driver Class Initialized
INFO - 2016-11-18 11:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:28:29 --> Controller Class Initialized
INFO - 2016-11-18 11:28:29 --> Model Class Initialized
INFO - 2016-11-18 11:28:29 --> Model Class Initialized
INFO - 2016-11-18 11:28:29 --> Model Class Initialized
INFO - 2016-11-18 11:28:29 --> Model Class Initialized
INFO - 2016-11-18 11:28:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:28:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:28:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:28:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:28:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:28:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:28:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:28:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:28:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:28:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:28:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:28:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:28:29 --> Final output sent to browser
DEBUG - 2016-11-18 11:28:29 --> Total execution time: 0.5028
INFO - 2016-11-18 11:28:31 --> Config Class Initialized
INFO - 2016-11-18 11:28:31 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:28:31 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:28:31 --> Utf8 Class Initialized
INFO - 2016-11-18 11:28:31 --> URI Class Initialized
INFO - 2016-11-18 11:28:31 --> Router Class Initialized
INFO - 2016-11-18 11:28:31 --> Output Class Initialized
INFO - 2016-11-18 11:28:31 --> Security Class Initialized
DEBUG - 2016-11-18 11:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:28:31 --> Input Class Initialized
INFO - 2016-11-18 11:28:31 --> Language Class Initialized
INFO - 2016-11-18 11:28:31 --> Loader Class Initialized
INFO - 2016-11-18 11:28:31 --> Helper loaded: url_helper
INFO - 2016-11-18 11:28:31 --> Helper loaded: form_helper
INFO - 2016-11-18 11:28:31 --> Database Driver Class Initialized
INFO - 2016-11-18 11:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:28:31 --> Controller Class Initialized
INFO - 2016-11-18 11:28:31 --> Model Class Initialized
INFO - 2016-11-18 11:28:31 --> Form Validation Class Initialized
INFO - 2016-11-18 11:28:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 11:28:31 --> Final output sent to browser
DEBUG - 2016-11-18 11:28:31 --> Total execution time: 0.2601
INFO - 2016-11-18 11:28:43 --> Config Class Initialized
INFO - 2016-11-18 11:28:43 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:28:43 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:28:43 --> Utf8 Class Initialized
INFO - 2016-11-18 11:28:43 --> URI Class Initialized
INFO - 2016-11-18 11:28:43 --> Router Class Initialized
INFO - 2016-11-18 11:28:43 --> Output Class Initialized
INFO - 2016-11-18 11:28:43 --> Security Class Initialized
DEBUG - 2016-11-18 11:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:28:43 --> Input Class Initialized
INFO - 2016-11-18 11:28:43 --> Language Class Initialized
INFO - 2016-11-18 11:28:43 --> Loader Class Initialized
INFO - 2016-11-18 11:28:43 --> Helper loaded: url_helper
INFO - 2016-11-18 11:28:43 --> Helper loaded: form_helper
INFO - 2016-11-18 11:28:43 --> Database Driver Class Initialized
INFO - 2016-11-18 11:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:28:43 --> Controller Class Initialized
INFO - 2016-11-18 11:28:43 --> Model Class Initialized
INFO - 2016-11-18 11:28:43 --> Form Validation Class Initialized
INFO - 2016-11-18 11:28:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 11:28:43 --> Final output sent to browser
DEBUG - 2016-11-18 11:28:44 --> Total execution time: 0.3352
INFO - 2016-11-18 11:30:13 --> Config Class Initialized
INFO - 2016-11-18 11:30:13 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:30:13 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:30:13 --> Utf8 Class Initialized
INFO - 2016-11-18 11:30:13 --> URI Class Initialized
DEBUG - 2016-11-18 11:30:13 --> No URI present. Default controller set.
INFO - 2016-11-18 11:30:13 --> Router Class Initialized
INFO - 2016-11-18 11:30:13 --> Output Class Initialized
INFO - 2016-11-18 11:30:13 --> Security Class Initialized
DEBUG - 2016-11-18 11:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:30:13 --> Input Class Initialized
INFO - 2016-11-18 11:30:13 --> Language Class Initialized
INFO - 2016-11-18 11:30:13 --> Loader Class Initialized
INFO - 2016-11-18 11:30:13 --> Helper loaded: url_helper
INFO - 2016-11-18 11:30:13 --> Helper loaded: form_helper
INFO - 2016-11-18 11:30:13 --> Database Driver Class Initialized
INFO - 2016-11-18 11:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:30:14 --> Controller Class Initialized
INFO - 2016-11-18 11:30:14 --> Model Class Initialized
INFO - 2016-11-18 11:30:14 --> Model Class Initialized
INFO - 2016-11-18 11:30:14 --> Model Class Initialized
INFO - 2016-11-18 11:30:14 --> Model Class Initialized
INFO - 2016-11-18 11:30:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:30:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:30:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:30:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:30:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:30:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:30:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:30:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:30:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:30:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:30:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:30:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:30:14 --> Final output sent to browser
DEBUG - 2016-11-18 11:30:14 --> Total execution time: 0.4979
INFO - 2016-11-18 11:30:16 --> Config Class Initialized
INFO - 2016-11-18 11:30:16 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:30:16 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:30:16 --> Utf8 Class Initialized
INFO - 2016-11-18 11:30:16 --> URI Class Initialized
INFO - 2016-11-18 11:30:16 --> Router Class Initialized
INFO - 2016-11-18 11:30:16 --> Output Class Initialized
INFO - 2016-11-18 11:30:16 --> Security Class Initialized
DEBUG - 2016-11-18 11:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:30:16 --> Input Class Initialized
INFO - 2016-11-18 11:30:16 --> Language Class Initialized
INFO - 2016-11-18 11:30:16 --> Loader Class Initialized
INFO - 2016-11-18 11:30:16 --> Helper loaded: url_helper
INFO - 2016-11-18 11:30:16 --> Helper loaded: form_helper
INFO - 2016-11-18 11:30:16 --> Database Driver Class Initialized
INFO - 2016-11-18 11:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:30:16 --> Controller Class Initialized
INFO - 2016-11-18 11:30:16 --> Model Class Initialized
INFO - 2016-11-18 11:30:16 --> Form Validation Class Initialized
INFO - 2016-11-18 11:30:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 11:30:17 --> Final output sent to browser
DEBUG - 2016-11-18 11:30:17 --> Total execution time: 0.2877
INFO - 2016-11-18 11:31:21 --> Config Class Initialized
INFO - 2016-11-18 11:31:21 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:31:21 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:31:21 --> Utf8 Class Initialized
INFO - 2016-11-18 11:31:21 --> URI Class Initialized
DEBUG - 2016-11-18 11:31:21 --> No URI present. Default controller set.
INFO - 2016-11-18 11:31:21 --> Router Class Initialized
INFO - 2016-11-18 11:31:21 --> Output Class Initialized
INFO - 2016-11-18 11:31:21 --> Security Class Initialized
DEBUG - 2016-11-18 11:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:31:21 --> Input Class Initialized
INFO - 2016-11-18 11:31:21 --> Language Class Initialized
INFO - 2016-11-18 11:31:21 --> Loader Class Initialized
INFO - 2016-11-18 11:31:21 --> Helper loaded: url_helper
INFO - 2016-11-18 11:31:21 --> Helper loaded: form_helper
INFO - 2016-11-18 11:31:21 --> Database Driver Class Initialized
INFO - 2016-11-18 11:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:31:21 --> Controller Class Initialized
INFO - 2016-11-18 11:31:21 --> Model Class Initialized
INFO - 2016-11-18 11:31:21 --> Model Class Initialized
INFO - 2016-11-18 11:31:21 --> Model Class Initialized
INFO - 2016-11-18 11:31:21 --> Model Class Initialized
INFO - 2016-11-18 11:31:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:31:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:31:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:31:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:31:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:31:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:31:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:31:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:31:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:31:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:31:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:31:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:31:21 --> Final output sent to browser
DEBUG - 2016-11-18 11:31:21 --> Total execution time: 0.5317
INFO - 2016-11-18 11:31:25 --> Config Class Initialized
INFO - 2016-11-18 11:31:25 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:31:25 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:31:25 --> Utf8 Class Initialized
INFO - 2016-11-18 11:31:25 --> URI Class Initialized
INFO - 2016-11-18 11:31:25 --> Router Class Initialized
INFO - 2016-11-18 11:31:25 --> Output Class Initialized
INFO - 2016-11-18 11:31:25 --> Security Class Initialized
DEBUG - 2016-11-18 11:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:31:25 --> Input Class Initialized
INFO - 2016-11-18 11:31:25 --> Language Class Initialized
INFO - 2016-11-18 11:31:25 --> Loader Class Initialized
INFO - 2016-11-18 11:31:25 --> Helper loaded: url_helper
INFO - 2016-11-18 11:31:25 --> Helper loaded: form_helper
INFO - 2016-11-18 11:31:25 --> Database Driver Class Initialized
INFO - 2016-11-18 11:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:31:25 --> Controller Class Initialized
INFO - 2016-11-18 11:31:25 --> Model Class Initialized
INFO - 2016-11-18 11:31:25 --> Form Validation Class Initialized
INFO - 2016-11-18 11:31:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 11:31:25 --> Final output sent to browser
DEBUG - 2016-11-18 11:31:25 --> Total execution time: 0.2987
INFO - 2016-11-18 11:31:41 --> Config Class Initialized
INFO - 2016-11-18 11:31:41 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:31:41 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:31:41 --> Utf8 Class Initialized
INFO - 2016-11-18 11:31:41 --> URI Class Initialized
INFO - 2016-11-18 11:31:41 --> Router Class Initialized
INFO - 2016-11-18 11:31:41 --> Output Class Initialized
INFO - 2016-11-18 11:31:41 --> Security Class Initialized
DEBUG - 2016-11-18 11:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:31:41 --> Input Class Initialized
INFO - 2016-11-18 11:31:41 --> Language Class Initialized
INFO - 2016-11-18 11:31:41 --> Loader Class Initialized
INFO - 2016-11-18 11:31:41 --> Helper loaded: url_helper
INFO - 2016-11-18 11:31:41 --> Helper loaded: form_helper
INFO - 2016-11-18 11:31:41 --> Database Driver Class Initialized
INFO - 2016-11-18 11:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:31:41 --> Controller Class Initialized
INFO - 2016-11-18 11:31:41 --> Model Class Initialized
INFO - 2016-11-18 11:31:41 --> Form Validation Class Initialized
INFO - 2016-11-18 11:31:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 11:31:41 --> Final output sent to browser
DEBUG - 2016-11-18 11:31:41 --> Total execution time: 0.2709
INFO - 2016-11-18 11:31:44 --> Config Class Initialized
INFO - 2016-11-18 11:31:44 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:31:45 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:31:45 --> Utf8 Class Initialized
INFO - 2016-11-18 11:31:45 --> URI Class Initialized
INFO - 2016-11-18 11:31:45 --> Router Class Initialized
INFO - 2016-11-18 11:31:45 --> Output Class Initialized
INFO - 2016-11-18 11:31:45 --> Security Class Initialized
DEBUG - 2016-11-18 11:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:31:45 --> Input Class Initialized
INFO - 2016-11-18 11:31:45 --> Language Class Initialized
INFO - 2016-11-18 11:31:45 --> Loader Class Initialized
INFO - 2016-11-18 11:31:45 --> Helper loaded: url_helper
INFO - 2016-11-18 11:31:45 --> Helper loaded: form_helper
INFO - 2016-11-18 11:31:45 --> Database Driver Class Initialized
INFO - 2016-11-18 11:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:31:45 --> Controller Class Initialized
INFO - 2016-11-18 11:31:45 --> Model Class Initialized
INFO - 2016-11-18 11:31:45 --> Form Validation Class Initialized
INFO - 2016-11-18 11:31:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 11:31:45 --> Final output sent to browser
DEBUG - 2016-11-18 11:31:45 --> Total execution time: 0.2775
INFO - 2016-11-18 11:31:50 --> Config Class Initialized
INFO - 2016-11-18 11:31:50 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:31:50 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:31:50 --> Utf8 Class Initialized
INFO - 2016-11-18 11:31:51 --> URI Class Initialized
INFO - 2016-11-18 11:31:51 --> Router Class Initialized
INFO - 2016-11-18 11:31:51 --> Output Class Initialized
INFO - 2016-11-18 11:31:51 --> Security Class Initialized
DEBUG - 2016-11-18 11:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:31:51 --> Input Class Initialized
INFO - 2016-11-18 11:31:51 --> Language Class Initialized
INFO - 2016-11-18 11:31:51 --> Loader Class Initialized
INFO - 2016-11-18 11:31:51 --> Helper loaded: url_helper
INFO - 2016-11-18 11:31:51 --> Helper loaded: form_helper
INFO - 2016-11-18 11:31:51 --> Database Driver Class Initialized
INFO - 2016-11-18 11:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:31:51 --> Controller Class Initialized
INFO - 2016-11-18 11:31:51 --> Model Class Initialized
INFO - 2016-11-18 11:31:51 --> Form Validation Class Initialized
INFO - 2016-11-18 11:31:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 11:31:51 --> Final output sent to browser
DEBUG - 2016-11-18 11:31:51 --> Total execution time: 0.3658
INFO - 2016-11-18 11:31:57 --> Config Class Initialized
INFO - 2016-11-18 11:31:57 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:31:57 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:31:57 --> Utf8 Class Initialized
INFO - 2016-11-18 11:31:57 --> URI Class Initialized
INFO - 2016-11-18 11:31:57 --> Router Class Initialized
INFO - 2016-11-18 11:31:57 --> Output Class Initialized
INFO - 2016-11-18 11:31:57 --> Security Class Initialized
DEBUG - 2016-11-18 11:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:31:57 --> Input Class Initialized
INFO - 2016-11-18 11:31:57 --> Language Class Initialized
INFO - 2016-11-18 11:31:57 --> Loader Class Initialized
INFO - 2016-11-18 11:31:57 --> Helper loaded: url_helper
INFO - 2016-11-18 11:31:57 --> Helper loaded: form_helper
INFO - 2016-11-18 11:31:57 --> Database Driver Class Initialized
INFO - 2016-11-18 11:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:31:57 --> Controller Class Initialized
INFO - 2016-11-18 11:31:57 --> Model Class Initialized
INFO - 2016-11-18 11:31:57 --> Form Validation Class Initialized
INFO - 2016-11-18 11:31:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 11:31:57 --> Final output sent to browser
DEBUG - 2016-11-18 11:31:57 --> Total execution time: 0.2894
INFO - 2016-11-18 11:32:02 --> Config Class Initialized
INFO - 2016-11-18 11:32:02 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:32:02 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:32:02 --> Utf8 Class Initialized
INFO - 2016-11-18 11:32:02 --> URI Class Initialized
INFO - 2016-11-18 11:32:02 --> Router Class Initialized
INFO - 2016-11-18 11:32:02 --> Output Class Initialized
INFO - 2016-11-18 11:32:02 --> Security Class Initialized
DEBUG - 2016-11-18 11:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:32:02 --> Input Class Initialized
INFO - 2016-11-18 11:32:02 --> Language Class Initialized
INFO - 2016-11-18 11:32:02 --> Loader Class Initialized
INFO - 2016-11-18 11:32:02 --> Helper loaded: url_helper
INFO - 2016-11-18 11:32:02 --> Helper loaded: form_helper
INFO - 2016-11-18 11:32:02 --> Database Driver Class Initialized
INFO - 2016-11-18 11:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:32:02 --> Controller Class Initialized
INFO - 2016-11-18 11:32:02 --> Model Class Initialized
INFO - 2016-11-18 11:32:02 --> Form Validation Class Initialized
INFO - 2016-11-18 11:32:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 11:32:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:32:02 --> Final output sent to browser
DEBUG - 2016-11-18 11:32:02 --> Total execution time: 0.3796
INFO - 2016-11-18 11:32:12 --> Config Class Initialized
INFO - 2016-11-18 11:32:12 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:32:12 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:32:12 --> Utf8 Class Initialized
INFO - 2016-11-18 11:32:12 --> URI Class Initialized
DEBUG - 2016-11-18 11:32:12 --> No URI present. Default controller set.
INFO - 2016-11-18 11:32:12 --> Router Class Initialized
INFO - 2016-11-18 11:32:12 --> Output Class Initialized
INFO - 2016-11-18 11:32:12 --> Security Class Initialized
DEBUG - 2016-11-18 11:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:32:13 --> Input Class Initialized
INFO - 2016-11-18 11:32:13 --> Language Class Initialized
INFO - 2016-11-18 11:32:13 --> Loader Class Initialized
INFO - 2016-11-18 11:32:13 --> Helper loaded: url_helper
INFO - 2016-11-18 11:32:13 --> Helper loaded: form_helper
INFO - 2016-11-18 11:32:13 --> Database Driver Class Initialized
INFO - 2016-11-18 11:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:32:13 --> Controller Class Initialized
INFO - 2016-11-18 11:32:13 --> Model Class Initialized
INFO - 2016-11-18 11:32:13 --> Model Class Initialized
INFO - 2016-11-18 11:32:13 --> Model Class Initialized
INFO - 2016-11-18 11:32:13 --> Model Class Initialized
INFO - 2016-11-18 11:32:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:32:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:32:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:32:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:32:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:32:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:32:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:32:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:32:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:32:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:32:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:32:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:32:13 --> Final output sent to browser
DEBUG - 2016-11-18 11:32:13 --> Total execution time: 0.5177
INFO - 2016-11-18 11:33:46 --> Config Class Initialized
INFO - 2016-11-18 11:33:46 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:33:46 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:33:46 --> Utf8 Class Initialized
INFO - 2016-11-18 11:33:46 --> URI Class Initialized
DEBUG - 2016-11-18 11:33:46 --> No URI present. Default controller set.
INFO - 2016-11-18 11:33:46 --> Router Class Initialized
INFO - 2016-11-18 11:33:46 --> Output Class Initialized
INFO - 2016-11-18 11:33:46 --> Security Class Initialized
DEBUG - 2016-11-18 11:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:33:46 --> Input Class Initialized
INFO - 2016-11-18 11:33:46 --> Language Class Initialized
INFO - 2016-11-18 11:33:46 --> Loader Class Initialized
INFO - 2016-11-18 11:33:46 --> Helper loaded: url_helper
INFO - 2016-11-18 11:33:46 --> Helper loaded: form_helper
INFO - 2016-11-18 11:33:46 --> Database Driver Class Initialized
INFO - 2016-11-18 11:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:33:46 --> Controller Class Initialized
INFO - 2016-11-18 11:33:46 --> Model Class Initialized
INFO - 2016-11-18 11:33:46 --> Model Class Initialized
INFO - 2016-11-18 11:33:47 --> Model Class Initialized
INFO - 2016-11-18 11:33:47 --> Model Class Initialized
INFO - 2016-11-18 11:33:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:33:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:33:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:33:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:33:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:33:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:33:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:33:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:33:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:33:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:33:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:33:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:33:47 --> Final output sent to browser
DEBUG - 2016-11-18 11:33:47 --> Total execution time: 0.5189
INFO - 2016-11-18 11:33:57 --> Config Class Initialized
INFO - 2016-11-18 11:33:57 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:33:57 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:33:57 --> Utf8 Class Initialized
INFO - 2016-11-18 11:33:57 --> URI Class Initialized
INFO - 2016-11-18 11:33:57 --> Router Class Initialized
INFO - 2016-11-18 11:33:57 --> Output Class Initialized
INFO - 2016-11-18 11:33:57 --> Security Class Initialized
DEBUG - 2016-11-18 11:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:33:57 --> Input Class Initialized
INFO - 2016-11-18 11:33:57 --> Language Class Initialized
INFO - 2016-11-18 11:33:57 --> Loader Class Initialized
INFO - 2016-11-18 11:33:57 --> Helper loaded: url_helper
INFO - 2016-11-18 11:33:57 --> Helper loaded: form_helper
INFO - 2016-11-18 11:33:57 --> Database Driver Class Initialized
INFO - 2016-11-18 11:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:33:57 --> Controller Class Initialized
INFO - 2016-11-18 11:33:57 --> Model Class Initialized
INFO - 2016-11-18 11:33:57 --> Form Validation Class Initialized
INFO - 2016-11-18 11:33:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 11:33:57 --> Final output sent to browser
DEBUG - 2016-11-18 11:33:57 --> Total execution time: 0.2834
INFO - 2016-11-18 11:34:05 --> Config Class Initialized
INFO - 2016-11-18 11:34:06 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:34:06 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:34:06 --> Utf8 Class Initialized
INFO - 2016-11-18 11:34:06 --> URI Class Initialized
INFO - 2016-11-18 11:34:06 --> Router Class Initialized
INFO - 2016-11-18 11:34:06 --> Output Class Initialized
INFO - 2016-11-18 11:34:06 --> Security Class Initialized
DEBUG - 2016-11-18 11:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:34:06 --> Input Class Initialized
INFO - 2016-11-18 11:34:06 --> Language Class Initialized
INFO - 2016-11-18 11:34:06 --> Loader Class Initialized
INFO - 2016-11-18 11:34:06 --> Helper loaded: url_helper
INFO - 2016-11-18 11:34:06 --> Helper loaded: form_helper
INFO - 2016-11-18 11:34:06 --> Database Driver Class Initialized
INFO - 2016-11-18 11:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:34:06 --> Controller Class Initialized
INFO - 2016-11-18 11:34:06 --> Model Class Initialized
INFO - 2016-11-18 11:34:06 --> Form Validation Class Initialized
INFO - 2016-11-18 11:34:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 11:34:06 --> Final output sent to browser
DEBUG - 2016-11-18 11:34:06 --> Total execution time: 0.2806
INFO - 2016-11-18 11:34:10 --> Config Class Initialized
INFO - 2016-11-18 11:34:10 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:34:10 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:34:10 --> Utf8 Class Initialized
INFO - 2016-11-18 11:34:10 --> URI Class Initialized
INFO - 2016-11-18 11:34:11 --> Router Class Initialized
INFO - 2016-11-18 11:34:11 --> Output Class Initialized
INFO - 2016-11-18 11:34:11 --> Security Class Initialized
DEBUG - 2016-11-18 11:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:34:11 --> Input Class Initialized
INFO - 2016-11-18 11:34:11 --> Language Class Initialized
INFO - 2016-11-18 11:34:11 --> Loader Class Initialized
INFO - 2016-11-18 11:34:11 --> Helper loaded: url_helper
INFO - 2016-11-18 11:34:11 --> Helper loaded: form_helper
INFO - 2016-11-18 11:34:11 --> Database Driver Class Initialized
INFO - 2016-11-18 11:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:34:11 --> Controller Class Initialized
INFO - 2016-11-18 11:34:11 --> Model Class Initialized
INFO - 2016-11-18 11:34:11 --> Form Validation Class Initialized
INFO - 2016-11-18 11:34:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 11:34:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:34:11 --> Final output sent to browser
DEBUG - 2016-11-18 11:34:11 --> Total execution time: 0.3790
INFO - 2016-11-18 11:37:34 --> Config Class Initialized
INFO - 2016-11-18 11:37:34 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:37:34 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:37:34 --> Utf8 Class Initialized
INFO - 2016-11-18 11:37:34 --> URI Class Initialized
DEBUG - 2016-11-18 11:37:34 --> No URI present. Default controller set.
INFO - 2016-11-18 11:37:34 --> Router Class Initialized
INFO - 2016-11-18 11:37:34 --> Output Class Initialized
INFO - 2016-11-18 11:37:34 --> Security Class Initialized
DEBUG - 2016-11-18 11:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:37:34 --> Input Class Initialized
INFO - 2016-11-18 11:37:34 --> Language Class Initialized
INFO - 2016-11-18 11:37:34 --> Loader Class Initialized
INFO - 2016-11-18 11:37:34 --> Helper loaded: url_helper
INFO - 2016-11-18 11:37:34 --> Helper loaded: form_helper
INFO - 2016-11-18 11:37:34 --> Database Driver Class Initialized
INFO - 2016-11-18 11:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:37:34 --> Controller Class Initialized
INFO - 2016-11-18 11:37:34 --> Model Class Initialized
INFO - 2016-11-18 11:37:34 --> Model Class Initialized
INFO - 2016-11-18 11:37:34 --> Model Class Initialized
INFO - 2016-11-18 11:37:34 --> Model Class Initialized
INFO - 2016-11-18 11:37:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:37:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:37:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:37:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:37:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:37:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:37:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:37:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:37:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:37:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:37:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:37:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:37:34 --> Final output sent to browser
DEBUG - 2016-11-18 11:37:34 --> Total execution time: 0.5174
INFO - 2016-11-18 11:38:43 --> Config Class Initialized
INFO - 2016-11-18 11:38:43 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:38:43 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:38:43 --> Utf8 Class Initialized
INFO - 2016-11-18 11:38:43 --> URI Class Initialized
DEBUG - 2016-11-18 11:38:43 --> No URI present. Default controller set.
INFO - 2016-11-18 11:38:43 --> Router Class Initialized
INFO - 2016-11-18 11:38:44 --> Output Class Initialized
INFO - 2016-11-18 11:38:44 --> Security Class Initialized
DEBUG - 2016-11-18 11:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:38:44 --> Input Class Initialized
INFO - 2016-11-18 11:38:44 --> Language Class Initialized
INFO - 2016-11-18 11:38:44 --> Loader Class Initialized
INFO - 2016-11-18 11:38:44 --> Helper loaded: url_helper
INFO - 2016-11-18 11:38:44 --> Helper loaded: form_helper
INFO - 2016-11-18 11:38:44 --> Database Driver Class Initialized
INFO - 2016-11-18 11:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:38:44 --> Controller Class Initialized
INFO - 2016-11-18 11:38:44 --> Model Class Initialized
INFO - 2016-11-18 11:38:44 --> Model Class Initialized
INFO - 2016-11-18 11:38:44 --> Model Class Initialized
INFO - 2016-11-18 11:38:44 --> Model Class Initialized
INFO - 2016-11-18 11:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:38:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:38:44 --> Final output sent to browser
DEBUG - 2016-11-18 11:38:44 --> Total execution time: 0.6416
INFO - 2016-11-18 11:38:48 --> Config Class Initialized
INFO - 2016-11-18 11:38:48 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:38:48 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:38:48 --> Utf8 Class Initialized
INFO - 2016-11-18 11:38:48 --> URI Class Initialized
INFO - 2016-11-18 11:38:48 --> Router Class Initialized
INFO - 2016-11-18 11:38:48 --> Output Class Initialized
INFO - 2016-11-18 11:38:48 --> Security Class Initialized
DEBUG - 2016-11-18 11:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:38:48 --> Input Class Initialized
INFO - 2016-11-18 11:38:48 --> Language Class Initialized
INFO - 2016-11-18 11:38:48 --> Loader Class Initialized
INFO - 2016-11-18 11:38:48 --> Helper loaded: url_helper
INFO - 2016-11-18 11:38:48 --> Helper loaded: form_helper
INFO - 2016-11-18 11:38:48 --> Database Driver Class Initialized
INFO - 2016-11-18 11:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:38:48 --> Controller Class Initialized
INFO - 2016-11-18 11:38:48 --> Model Class Initialized
INFO - 2016-11-18 11:38:48 --> Model Class Initialized
INFO - 2016-11-18 11:38:48 --> Model Class Initialized
INFO - 2016-11-18 11:38:48 --> Model Class Initialized
DEBUG - 2016-11-18 11:38:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-18 11:38:48 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-18 11:38:48 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-18 11:38:48 --> Config Class Initialized
INFO - 2016-11-18 11:38:48 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:38:48 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:38:48 --> Utf8 Class Initialized
INFO - 2016-11-18 11:38:48 --> URI Class Initialized
DEBUG - 2016-11-18 11:38:48 --> No URI present. Default controller set.
INFO - 2016-11-18 11:38:48 --> Router Class Initialized
INFO - 2016-11-18 11:38:48 --> Output Class Initialized
INFO - 2016-11-18 11:38:48 --> Security Class Initialized
DEBUG - 2016-11-18 11:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:38:48 --> Input Class Initialized
INFO - 2016-11-18 11:38:48 --> Language Class Initialized
INFO - 2016-11-18 11:38:48 --> Loader Class Initialized
INFO - 2016-11-18 11:38:48 --> Helper loaded: url_helper
INFO - 2016-11-18 11:38:48 --> Helper loaded: form_helper
INFO - 2016-11-18 11:38:48 --> Database Driver Class Initialized
INFO - 2016-11-18 11:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:38:48 --> Controller Class Initialized
INFO - 2016-11-18 11:38:48 --> Model Class Initialized
INFO - 2016-11-18 11:38:48 --> Model Class Initialized
INFO - 2016-11-18 11:38:48 --> Model Class Initialized
INFO - 2016-11-18 11:38:48 --> Model Class Initialized
INFO - 2016-11-18 11:38:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:38:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 11:38:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:38:49 --> Final output sent to browser
DEBUG - 2016-11-18 11:38:49 --> Total execution time: 0.3609
INFO - 2016-11-18 11:38:57 --> Config Class Initialized
INFO - 2016-11-18 11:38:57 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:38:57 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:38:57 --> Utf8 Class Initialized
INFO - 2016-11-18 11:38:57 --> URI Class Initialized
INFO - 2016-11-18 11:38:57 --> Router Class Initialized
INFO - 2016-11-18 11:38:57 --> Output Class Initialized
INFO - 2016-11-18 11:38:57 --> Security Class Initialized
DEBUG - 2016-11-18 11:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:38:57 --> Input Class Initialized
INFO - 2016-11-18 11:38:57 --> Language Class Initialized
INFO - 2016-11-18 11:38:57 --> Loader Class Initialized
INFO - 2016-11-18 11:38:57 --> Helper loaded: url_helper
INFO - 2016-11-18 11:38:57 --> Helper loaded: form_helper
INFO - 2016-11-18 11:38:57 --> Database Driver Class Initialized
INFO - 2016-11-18 11:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:38:57 --> Controller Class Initialized
INFO - 2016-11-18 11:38:57 --> Model Class Initialized
INFO - 2016-11-18 11:38:57 --> Model Class Initialized
INFO - 2016-11-18 11:38:57 --> Model Class Initialized
INFO - 2016-11-18 11:38:57 --> Model Class Initialized
DEBUG - 2016-11-18 11:38:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-18 11:38:57 --> Model Class Initialized
INFO - 2016-11-18 11:38:57 --> Final output sent to browser
DEBUG - 2016-11-18 11:38:57 --> Total execution time: 0.3839
INFO - 2016-11-18 11:38:58 --> Config Class Initialized
INFO - 2016-11-18 11:38:58 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:38:58 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:38:58 --> Utf8 Class Initialized
INFO - 2016-11-18 11:38:58 --> URI Class Initialized
DEBUG - 2016-11-18 11:38:58 --> No URI present. Default controller set.
INFO - 2016-11-18 11:38:58 --> Router Class Initialized
INFO - 2016-11-18 11:38:58 --> Output Class Initialized
INFO - 2016-11-18 11:38:58 --> Security Class Initialized
DEBUG - 2016-11-18 11:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:38:58 --> Input Class Initialized
INFO - 2016-11-18 11:38:58 --> Language Class Initialized
INFO - 2016-11-18 11:38:58 --> Loader Class Initialized
INFO - 2016-11-18 11:38:58 --> Helper loaded: url_helper
INFO - 2016-11-18 11:38:58 --> Helper loaded: form_helper
INFO - 2016-11-18 11:38:58 --> Database Driver Class Initialized
INFO - 2016-11-18 11:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:38:58 --> Controller Class Initialized
INFO - 2016-11-18 11:38:58 --> Model Class Initialized
INFO - 2016-11-18 11:38:58 --> Model Class Initialized
INFO - 2016-11-18 11:38:58 --> Model Class Initialized
INFO - 2016-11-18 11:38:58 --> Model Class Initialized
INFO - 2016-11-18 11:38:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:38:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:38:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:38:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:38:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:38:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:38:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:38:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:38:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:38:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:38:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:38:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:38:58 --> Final output sent to browser
DEBUG - 2016-11-18 11:38:58 --> Total execution time: 0.4855
INFO - 2016-11-18 11:39:03 --> Config Class Initialized
INFO - 2016-11-18 11:39:03 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:39:03 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:39:03 --> Utf8 Class Initialized
INFO - 2016-11-18 11:39:03 --> URI Class Initialized
INFO - 2016-11-18 11:39:03 --> Router Class Initialized
INFO - 2016-11-18 11:39:03 --> Output Class Initialized
INFO - 2016-11-18 11:39:03 --> Security Class Initialized
DEBUG - 2016-11-18 11:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:39:03 --> Input Class Initialized
INFO - 2016-11-18 11:39:03 --> Language Class Initialized
INFO - 2016-11-18 11:39:03 --> Loader Class Initialized
INFO - 2016-11-18 11:39:03 --> Helper loaded: url_helper
INFO - 2016-11-18 11:39:03 --> Helper loaded: form_helper
INFO - 2016-11-18 11:39:03 --> Database Driver Class Initialized
INFO - 2016-11-18 11:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:39:03 --> Controller Class Initialized
INFO - 2016-11-18 11:39:03 --> Model Class Initialized
INFO - 2016-11-18 11:39:03 --> Model Class Initialized
INFO - 2016-11-18 11:39:03 --> Model Class Initialized
INFO - 2016-11-18 11:39:03 --> Model Class Initialized
DEBUG - 2016-11-18 11:39:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-18 11:39:03 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-18 11:39:03 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-18 11:39:03 --> Config Class Initialized
INFO - 2016-11-18 11:39:03 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:39:03 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:39:03 --> Utf8 Class Initialized
INFO - 2016-11-18 11:39:03 --> URI Class Initialized
DEBUG - 2016-11-18 11:39:03 --> No URI present. Default controller set.
INFO - 2016-11-18 11:39:03 --> Router Class Initialized
INFO - 2016-11-18 11:39:04 --> Output Class Initialized
INFO - 2016-11-18 11:39:04 --> Security Class Initialized
DEBUG - 2016-11-18 11:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:39:04 --> Input Class Initialized
INFO - 2016-11-18 11:39:04 --> Language Class Initialized
INFO - 2016-11-18 11:39:04 --> Loader Class Initialized
INFO - 2016-11-18 11:39:04 --> Helper loaded: url_helper
INFO - 2016-11-18 11:39:04 --> Helper loaded: form_helper
INFO - 2016-11-18 11:39:04 --> Database Driver Class Initialized
INFO - 2016-11-18 11:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:39:04 --> Controller Class Initialized
INFO - 2016-11-18 11:39:04 --> Model Class Initialized
INFO - 2016-11-18 11:39:04 --> Model Class Initialized
INFO - 2016-11-18 11:39:04 --> Model Class Initialized
INFO - 2016-11-18 11:39:04 --> Model Class Initialized
INFO - 2016-11-18 11:39:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:39:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 11:39:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:39:04 --> Final output sent to browser
DEBUG - 2016-11-18 11:39:04 --> Total execution time: 0.3570
INFO - 2016-11-18 11:39:15 --> Config Class Initialized
INFO - 2016-11-18 11:39:15 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:39:15 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:39:15 --> Utf8 Class Initialized
INFO - 2016-11-18 11:39:15 --> URI Class Initialized
INFO - 2016-11-18 11:39:15 --> Router Class Initialized
INFO - 2016-11-18 11:39:15 --> Output Class Initialized
INFO - 2016-11-18 11:39:15 --> Security Class Initialized
DEBUG - 2016-11-18 11:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:39:15 --> Input Class Initialized
INFO - 2016-11-18 11:39:15 --> Language Class Initialized
INFO - 2016-11-18 11:39:15 --> Loader Class Initialized
INFO - 2016-11-18 11:39:15 --> Helper loaded: url_helper
INFO - 2016-11-18 11:39:15 --> Helper loaded: form_helper
INFO - 2016-11-18 11:39:15 --> Database Driver Class Initialized
INFO - 2016-11-18 11:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:39:15 --> Controller Class Initialized
INFO - 2016-11-18 11:39:15 --> Model Class Initialized
INFO - 2016-11-18 11:39:15 --> Model Class Initialized
INFO - 2016-11-18 11:39:15 --> Model Class Initialized
INFO - 2016-11-18 11:39:15 --> Model Class Initialized
DEBUG - 2016-11-18 11:39:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-18 11:39:15 --> Model Class Initialized
INFO - 2016-11-18 11:39:15 --> Final output sent to browser
DEBUG - 2016-11-18 11:39:15 --> Total execution time: 0.3115
INFO - 2016-11-18 11:39:15 --> Config Class Initialized
INFO - 2016-11-18 11:39:15 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:39:15 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:39:15 --> Utf8 Class Initialized
INFO - 2016-11-18 11:39:15 --> URI Class Initialized
DEBUG - 2016-11-18 11:39:15 --> No URI present. Default controller set.
INFO - 2016-11-18 11:39:15 --> Router Class Initialized
INFO - 2016-11-18 11:39:15 --> Output Class Initialized
INFO - 2016-11-18 11:39:15 --> Security Class Initialized
DEBUG - 2016-11-18 11:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:39:15 --> Input Class Initialized
INFO - 2016-11-18 11:39:15 --> Language Class Initialized
INFO - 2016-11-18 11:39:15 --> Loader Class Initialized
INFO - 2016-11-18 11:39:15 --> Helper loaded: url_helper
INFO - 2016-11-18 11:39:15 --> Helper loaded: form_helper
INFO - 2016-11-18 11:39:15 --> Database Driver Class Initialized
INFO - 2016-11-18 11:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:39:15 --> Controller Class Initialized
INFO - 2016-11-18 11:39:15 --> Model Class Initialized
INFO - 2016-11-18 11:39:15 --> Model Class Initialized
INFO - 2016-11-18 11:39:15 --> Model Class Initialized
INFO - 2016-11-18 11:39:15 --> Model Class Initialized
INFO - 2016-11-18 11:39:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:39:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:39:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:39:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:39:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:39:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:39:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:39:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:39:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:39:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:39:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:39:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:39:16 --> Final output sent to browser
DEBUG - 2016-11-18 11:39:16 --> Total execution time: 0.5027
INFO - 2016-11-18 11:39:28 --> Config Class Initialized
INFO - 2016-11-18 11:39:28 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:39:28 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:39:28 --> Utf8 Class Initialized
INFO - 2016-11-18 11:39:28 --> URI Class Initialized
INFO - 2016-11-18 11:39:28 --> Router Class Initialized
INFO - 2016-11-18 11:39:28 --> Output Class Initialized
INFO - 2016-11-18 11:39:28 --> Security Class Initialized
DEBUG - 2016-11-18 11:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:39:28 --> Input Class Initialized
INFO - 2016-11-18 11:39:28 --> Language Class Initialized
INFO - 2016-11-18 11:39:28 --> Loader Class Initialized
INFO - 2016-11-18 11:39:28 --> Helper loaded: url_helper
INFO - 2016-11-18 11:39:28 --> Helper loaded: form_helper
INFO - 2016-11-18 11:39:28 --> Database Driver Class Initialized
INFO - 2016-11-18 11:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:39:28 --> Controller Class Initialized
INFO - 2016-11-18 11:39:28 --> Model Class Initialized
INFO - 2016-11-18 11:39:28 --> Form Validation Class Initialized
INFO - 2016-11-18 11:39:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 11:39:28 --> Final output sent to browser
DEBUG - 2016-11-18 11:39:28 --> Total execution time: 0.3210
INFO - 2016-11-18 11:39:31 --> Config Class Initialized
INFO - 2016-11-18 11:39:31 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:39:31 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:39:31 --> Utf8 Class Initialized
INFO - 2016-11-18 11:39:31 --> URI Class Initialized
DEBUG - 2016-11-18 11:39:31 --> No URI present. Default controller set.
INFO - 2016-11-18 11:39:31 --> Router Class Initialized
INFO - 2016-11-18 11:39:31 --> Output Class Initialized
INFO - 2016-11-18 11:39:31 --> Security Class Initialized
DEBUG - 2016-11-18 11:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:39:31 --> Input Class Initialized
INFO - 2016-11-18 11:39:31 --> Language Class Initialized
INFO - 2016-11-18 11:39:31 --> Loader Class Initialized
INFO - 2016-11-18 11:39:31 --> Helper loaded: url_helper
INFO - 2016-11-18 11:39:31 --> Helper loaded: form_helper
INFO - 2016-11-18 11:39:31 --> Database Driver Class Initialized
INFO - 2016-11-18 11:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:39:31 --> Controller Class Initialized
INFO - 2016-11-18 11:39:31 --> Model Class Initialized
INFO - 2016-11-18 11:39:31 --> Model Class Initialized
INFO - 2016-11-18 11:39:31 --> Model Class Initialized
INFO - 2016-11-18 11:39:31 --> Model Class Initialized
INFO - 2016-11-18 11:39:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:39:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:39:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:39:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:39:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:39:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:39:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:39:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:39:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:39:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:39:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:39:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:39:31 --> Final output sent to browser
DEBUG - 2016-11-18 11:39:31 --> Total execution time: 0.5346
INFO - 2016-11-18 11:39:41 --> Config Class Initialized
INFO - 2016-11-18 11:39:41 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:39:41 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:39:41 --> Utf8 Class Initialized
INFO - 2016-11-18 11:39:41 --> URI Class Initialized
INFO - 2016-11-18 11:39:41 --> Router Class Initialized
INFO - 2016-11-18 11:39:41 --> Output Class Initialized
INFO - 2016-11-18 11:39:41 --> Security Class Initialized
DEBUG - 2016-11-18 11:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:39:41 --> Input Class Initialized
INFO - 2016-11-18 11:39:41 --> Language Class Initialized
INFO - 2016-11-18 11:39:41 --> Loader Class Initialized
INFO - 2016-11-18 11:39:41 --> Helper loaded: url_helper
INFO - 2016-11-18 11:39:41 --> Helper loaded: form_helper
INFO - 2016-11-18 11:39:41 --> Database Driver Class Initialized
INFO - 2016-11-18 11:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:39:41 --> Controller Class Initialized
INFO - 2016-11-18 11:39:41 --> Model Class Initialized
INFO - 2016-11-18 11:39:41 --> Form Validation Class Initialized
INFO - 2016-11-18 11:39:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 11:39:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:39:42 --> Final output sent to browser
DEBUG - 2016-11-18 11:39:42 --> Total execution time: 0.4355
INFO - 2016-11-18 11:39:43 --> Config Class Initialized
INFO - 2016-11-18 11:39:43 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:39:43 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:39:43 --> Utf8 Class Initialized
INFO - 2016-11-18 11:39:43 --> URI Class Initialized
DEBUG - 2016-11-18 11:39:43 --> No URI present. Default controller set.
INFO - 2016-11-18 11:39:43 --> Router Class Initialized
INFO - 2016-11-18 11:39:44 --> Output Class Initialized
INFO - 2016-11-18 11:39:44 --> Security Class Initialized
DEBUG - 2016-11-18 11:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:39:44 --> Input Class Initialized
INFO - 2016-11-18 11:39:44 --> Language Class Initialized
INFO - 2016-11-18 11:39:44 --> Loader Class Initialized
INFO - 2016-11-18 11:39:44 --> Helper loaded: url_helper
INFO - 2016-11-18 11:39:44 --> Helper loaded: form_helper
INFO - 2016-11-18 11:39:44 --> Database Driver Class Initialized
INFO - 2016-11-18 11:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:39:44 --> Controller Class Initialized
INFO - 2016-11-18 11:39:44 --> Model Class Initialized
INFO - 2016-11-18 11:39:44 --> Model Class Initialized
INFO - 2016-11-18 11:39:44 --> Model Class Initialized
INFO - 2016-11-18 11:39:44 --> Model Class Initialized
INFO - 2016-11-18 11:39:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:39:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:39:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:39:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:39:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:39:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:39:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:39:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:39:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:39:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:39:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:39:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:39:44 --> Final output sent to browser
DEBUG - 2016-11-18 11:39:44 --> Total execution time: 0.6076
INFO - 2016-11-18 11:39:57 --> Config Class Initialized
INFO - 2016-11-18 11:39:57 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:39:57 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:39:57 --> Utf8 Class Initialized
INFO - 2016-11-18 11:39:57 --> URI Class Initialized
INFO - 2016-11-18 11:39:57 --> Router Class Initialized
INFO - 2016-11-18 11:39:57 --> Output Class Initialized
INFO - 2016-11-18 11:39:57 --> Security Class Initialized
DEBUG - 2016-11-18 11:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:39:57 --> Input Class Initialized
INFO - 2016-11-18 11:39:57 --> Language Class Initialized
INFO - 2016-11-18 11:39:57 --> Loader Class Initialized
INFO - 2016-11-18 11:39:57 --> Helper loaded: url_helper
INFO - 2016-11-18 11:39:57 --> Helper loaded: form_helper
INFO - 2016-11-18 11:39:57 --> Database Driver Class Initialized
INFO - 2016-11-18 11:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:39:57 --> Controller Class Initialized
INFO - 2016-11-18 11:39:57 --> Model Class Initialized
INFO - 2016-11-18 11:39:57 --> Model Class Initialized
INFO - 2016-11-18 11:39:57 --> Model Class Initialized
INFO - 2016-11-18 11:39:57 --> Model Class Initialized
DEBUG - 2016-11-18 11:39:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-18 11:39:57 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-18 11:39:57 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-18 11:39:57 --> Config Class Initialized
INFO - 2016-11-18 11:39:57 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:39:57 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:39:57 --> Utf8 Class Initialized
INFO - 2016-11-18 11:39:57 --> URI Class Initialized
DEBUG - 2016-11-18 11:39:58 --> No URI present. Default controller set.
INFO - 2016-11-18 11:39:58 --> Router Class Initialized
INFO - 2016-11-18 11:39:58 --> Output Class Initialized
INFO - 2016-11-18 11:39:58 --> Security Class Initialized
DEBUG - 2016-11-18 11:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:39:58 --> Input Class Initialized
INFO - 2016-11-18 11:39:58 --> Language Class Initialized
INFO - 2016-11-18 11:39:58 --> Loader Class Initialized
INFO - 2016-11-18 11:39:58 --> Helper loaded: url_helper
INFO - 2016-11-18 11:39:58 --> Helper loaded: form_helper
INFO - 2016-11-18 11:39:58 --> Database Driver Class Initialized
INFO - 2016-11-18 11:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:39:58 --> Controller Class Initialized
INFO - 2016-11-18 11:39:58 --> Model Class Initialized
INFO - 2016-11-18 11:39:58 --> Model Class Initialized
INFO - 2016-11-18 11:39:58 --> Model Class Initialized
INFO - 2016-11-18 11:39:58 --> Model Class Initialized
INFO - 2016-11-18 11:39:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:39:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 11:39:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:39:58 --> Final output sent to browser
DEBUG - 2016-11-18 11:39:58 --> Total execution time: 0.3641
INFO - 2016-11-18 11:40:09 --> Config Class Initialized
INFO - 2016-11-18 11:40:09 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:40:09 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:40:09 --> Utf8 Class Initialized
INFO - 2016-11-18 11:40:09 --> URI Class Initialized
INFO - 2016-11-18 11:40:09 --> Router Class Initialized
INFO - 2016-11-18 11:40:09 --> Output Class Initialized
INFO - 2016-11-18 11:40:09 --> Security Class Initialized
DEBUG - 2016-11-18 11:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:40:09 --> Input Class Initialized
INFO - 2016-11-18 11:40:09 --> Language Class Initialized
INFO - 2016-11-18 11:40:09 --> Loader Class Initialized
INFO - 2016-11-18 11:40:09 --> Helper loaded: url_helper
INFO - 2016-11-18 11:40:09 --> Helper loaded: form_helper
INFO - 2016-11-18 11:40:09 --> Database Driver Class Initialized
INFO - 2016-11-18 11:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:40:09 --> Controller Class Initialized
INFO - 2016-11-18 11:40:09 --> Model Class Initialized
INFO - 2016-11-18 11:40:09 --> Model Class Initialized
INFO - 2016-11-18 11:40:09 --> Model Class Initialized
INFO - 2016-11-18 11:40:09 --> Model Class Initialized
DEBUG - 2016-11-18 11:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-18 11:40:09 --> Model Class Initialized
INFO - 2016-11-18 11:40:09 --> Final output sent to browser
DEBUG - 2016-11-18 11:40:09 --> Total execution time: 0.3472
INFO - 2016-11-18 11:40:09 --> Config Class Initialized
INFO - 2016-11-18 11:40:09 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:40:09 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:40:09 --> Utf8 Class Initialized
INFO - 2016-11-18 11:40:09 --> URI Class Initialized
DEBUG - 2016-11-18 11:40:09 --> No URI present. Default controller set.
INFO - 2016-11-18 11:40:09 --> Router Class Initialized
INFO - 2016-11-18 11:40:09 --> Output Class Initialized
INFO - 2016-11-18 11:40:09 --> Security Class Initialized
DEBUG - 2016-11-18 11:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:40:09 --> Input Class Initialized
INFO - 2016-11-18 11:40:09 --> Language Class Initialized
INFO - 2016-11-18 11:40:09 --> Loader Class Initialized
INFO - 2016-11-18 11:40:09 --> Helper loaded: url_helper
INFO - 2016-11-18 11:40:09 --> Helper loaded: form_helper
INFO - 2016-11-18 11:40:09 --> Database Driver Class Initialized
INFO - 2016-11-18 11:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:40:09 --> Controller Class Initialized
INFO - 2016-11-18 11:40:09 --> Model Class Initialized
INFO - 2016-11-18 11:40:09 --> Model Class Initialized
INFO - 2016-11-18 11:40:09 --> Model Class Initialized
INFO - 2016-11-18 11:40:10 --> Model Class Initialized
INFO - 2016-11-18 11:40:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:40:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:40:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:40:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:40:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:40:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:40:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:40:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:40:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:40:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:40:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:40:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:40:10 --> Final output sent to browser
DEBUG - 2016-11-18 11:40:10 --> Total execution time: 0.4949
INFO - 2016-11-18 11:40:26 --> Config Class Initialized
INFO - 2016-11-18 11:40:26 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:40:26 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:40:26 --> Utf8 Class Initialized
INFO - 2016-11-18 11:40:26 --> URI Class Initialized
INFO - 2016-11-18 11:40:26 --> Router Class Initialized
INFO - 2016-11-18 11:40:26 --> Output Class Initialized
INFO - 2016-11-18 11:40:26 --> Security Class Initialized
DEBUG - 2016-11-18 11:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:40:26 --> Input Class Initialized
INFO - 2016-11-18 11:40:26 --> Language Class Initialized
INFO - 2016-11-18 11:40:26 --> Loader Class Initialized
INFO - 2016-11-18 11:40:26 --> Helper loaded: url_helper
INFO - 2016-11-18 11:40:26 --> Helper loaded: form_helper
INFO - 2016-11-18 11:40:26 --> Database Driver Class Initialized
INFO - 2016-11-18 11:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:40:26 --> Controller Class Initialized
INFO - 2016-11-18 11:40:26 --> Model Class Initialized
INFO - 2016-11-18 11:40:26 --> Form Validation Class Initialized
INFO - 2016-11-18 11:40:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 11:40:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:40:26 --> Final output sent to browser
DEBUG - 2016-11-18 11:40:26 --> Total execution time: 0.4122
INFO - 2016-11-18 11:40:28 --> Config Class Initialized
INFO - 2016-11-18 11:40:28 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:40:28 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:40:28 --> Utf8 Class Initialized
INFO - 2016-11-18 11:40:28 --> URI Class Initialized
DEBUG - 2016-11-18 11:40:28 --> No URI present. Default controller set.
INFO - 2016-11-18 11:40:29 --> Router Class Initialized
INFO - 2016-11-18 11:40:29 --> Output Class Initialized
INFO - 2016-11-18 11:40:29 --> Security Class Initialized
DEBUG - 2016-11-18 11:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:40:29 --> Input Class Initialized
INFO - 2016-11-18 11:40:29 --> Language Class Initialized
INFO - 2016-11-18 11:40:29 --> Loader Class Initialized
INFO - 2016-11-18 11:40:29 --> Helper loaded: url_helper
INFO - 2016-11-18 11:40:29 --> Helper loaded: form_helper
INFO - 2016-11-18 11:40:29 --> Database Driver Class Initialized
INFO - 2016-11-18 11:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:40:29 --> Controller Class Initialized
INFO - 2016-11-18 11:40:29 --> Model Class Initialized
INFO - 2016-11-18 11:40:29 --> Model Class Initialized
INFO - 2016-11-18 11:40:29 --> Model Class Initialized
INFO - 2016-11-18 11:40:29 --> Model Class Initialized
INFO - 2016-11-18 11:40:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:40:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:40:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:40:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:40:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:40:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:40:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:40:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:40:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:40:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:40:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:40:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:40:29 --> Final output sent to browser
DEBUG - 2016-11-18 11:40:29 --> Total execution time: 0.5535
INFO - 2016-11-18 11:40:39 --> Config Class Initialized
INFO - 2016-11-18 11:40:39 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:40:39 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:40:39 --> Utf8 Class Initialized
INFO - 2016-11-18 11:40:39 --> URI Class Initialized
DEBUG - 2016-11-18 11:40:39 --> No URI present. Default controller set.
INFO - 2016-11-18 11:40:39 --> Router Class Initialized
INFO - 2016-11-18 11:40:39 --> Output Class Initialized
INFO - 2016-11-18 11:40:39 --> Security Class Initialized
DEBUG - 2016-11-18 11:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:40:39 --> Input Class Initialized
INFO - 2016-11-18 11:40:39 --> Language Class Initialized
INFO - 2016-11-18 11:40:39 --> Loader Class Initialized
INFO - 2016-11-18 11:40:39 --> Helper loaded: url_helper
INFO - 2016-11-18 11:40:39 --> Helper loaded: form_helper
INFO - 2016-11-18 11:40:39 --> Database Driver Class Initialized
INFO - 2016-11-18 11:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:40:39 --> Controller Class Initialized
INFO - 2016-11-18 11:40:39 --> Model Class Initialized
INFO - 2016-11-18 11:40:39 --> Model Class Initialized
INFO - 2016-11-18 11:40:39 --> Model Class Initialized
INFO - 2016-11-18 11:40:39 --> Model Class Initialized
INFO - 2016-11-18 11:40:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:40:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:40:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:40:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:40:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:40:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:40:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:40:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:40:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:40:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:40:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:40:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:40:39 --> Final output sent to browser
DEBUG - 2016-11-18 11:40:39 --> Total execution time: 0.5576
INFO - 2016-11-18 11:41:43 --> Config Class Initialized
INFO - 2016-11-18 11:41:43 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:41:44 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:41:44 --> Utf8 Class Initialized
INFO - 2016-11-18 11:41:44 --> URI Class Initialized
INFO - 2016-11-18 11:41:44 --> Router Class Initialized
INFO - 2016-11-18 11:41:44 --> Output Class Initialized
INFO - 2016-11-18 11:41:44 --> Security Class Initialized
DEBUG - 2016-11-18 11:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:41:44 --> Input Class Initialized
INFO - 2016-11-18 11:41:44 --> Language Class Initialized
INFO - 2016-11-18 11:41:44 --> Loader Class Initialized
INFO - 2016-11-18 11:41:44 --> Helper loaded: url_helper
INFO - 2016-11-18 11:41:44 --> Helper loaded: form_helper
INFO - 2016-11-18 11:41:44 --> Database Driver Class Initialized
INFO - 2016-11-18 11:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:41:44 --> Controller Class Initialized
INFO - 2016-11-18 11:41:44 --> Model Class Initialized
INFO - 2016-11-18 11:41:44 --> Form Validation Class Initialized
ERROR - 2016-11-18 11:41:44 --> Severity: Notice --> Undefined variable: subordinate C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 123
ERROR - 2016-11-18 11:41:44 --> Severity: Notice --> Undefined variable: sub_subordinate C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 123
INFO - 2016-11-18 11:41:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:41:44 --> Final output sent to browser
DEBUG - 2016-11-18 11:41:44 --> Total execution time: 0.4828
INFO - 2016-11-18 11:43:36 --> Config Class Initialized
INFO - 2016-11-18 11:43:36 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:43:36 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:43:36 --> Utf8 Class Initialized
INFO - 2016-11-18 11:43:36 --> URI Class Initialized
DEBUG - 2016-11-18 11:43:36 --> No URI present. Default controller set.
INFO - 2016-11-18 11:43:36 --> Router Class Initialized
INFO - 2016-11-18 11:43:36 --> Output Class Initialized
INFO - 2016-11-18 11:43:36 --> Security Class Initialized
DEBUG - 2016-11-18 11:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:43:36 --> Input Class Initialized
INFO - 2016-11-18 11:43:36 --> Language Class Initialized
INFO - 2016-11-18 11:43:36 --> Loader Class Initialized
INFO - 2016-11-18 11:43:36 --> Helper loaded: url_helper
INFO - 2016-11-18 11:43:36 --> Helper loaded: form_helper
INFO - 2016-11-18 11:43:36 --> Database Driver Class Initialized
INFO - 2016-11-18 11:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:43:36 --> Controller Class Initialized
INFO - 2016-11-18 11:43:36 --> Model Class Initialized
INFO - 2016-11-18 11:43:36 --> Model Class Initialized
INFO - 2016-11-18 11:43:36 --> Model Class Initialized
INFO - 2016-11-18 11:43:36 --> Model Class Initialized
INFO - 2016-11-18 11:43:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:43:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:43:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:43:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:43:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:43:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:43:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:43:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:43:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:43:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:43:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:43:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:43:36 --> Final output sent to browser
DEBUG - 2016-11-18 11:43:36 --> Total execution time: 0.5048
INFO - 2016-11-18 11:43:43 --> Config Class Initialized
INFO - 2016-11-18 11:43:43 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:43:43 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:43:43 --> Utf8 Class Initialized
INFO - 2016-11-18 11:43:43 --> URI Class Initialized
DEBUG - 2016-11-18 11:43:43 --> No URI present. Default controller set.
INFO - 2016-11-18 11:43:43 --> Router Class Initialized
INFO - 2016-11-18 11:43:43 --> Output Class Initialized
INFO - 2016-11-18 11:43:43 --> Security Class Initialized
DEBUG - 2016-11-18 11:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:43:43 --> Input Class Initialized
INFO - 2016-11-18 11:43:43 --> Language Class Initialized
INFO - 2016-11-18 11:43:43 --> Loader Class Initialized
INFO - 2016-11-18 11:43:43 --> Helper loaded: url_helper
INFO - 2016-11-18 11:43:43 --> Helper loaded: form_helper
INFO - 2016-11-18 11:43:43 --> Database Driver Class Initialized
INFO - 2016-11-18 11:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:43:44 --> Controller Class Initialized
INFO - 2016-11-18 11:43:44 --> Model Class Initialized
INFO - 2016-11-18 11:43:44 --> Model Class Initialized
INFO - 2016-11-18 11:43:44 --> Model Class Initialized
INFO - 2016-11-18 11:43:44 --> Model Class Initialized
INFO - 2016-11-18 11:43:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:43:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:43:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:43:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:43:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:43:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:43:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:43:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:43:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:43:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:43:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:43:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:43:44 --> Final output sent to browser
DEBUG - 2016-11-18 11:43:44 --> Total execution time: 0.5528
INFO - 2016-11-18 11:43:49 --> Config Class Initialized
INFO - 2016-11-18 11:43:49 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:43:49 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:43:49 --> Utf8 Class Initialized
INFO - 2016-11-18 11:43:49 --> URI Class Initialized
INFO - 2016-11-18 11:43:49 --> Router Class Initialized
INFO - 2016-11-18 11:43:49 --> Output Class Initialized
INFO - 2016-11-18 11:43:49 --> Security Class Initialized
DEBUG - 2016-11-18 11:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:43:49 --> Input Class Initialized
INFO - 2016-11-18 11:43:49 --> Language Class Initialized
INFO - 2016-11-18 11:43:49 --> Loader Class Initialized
INFO - 2016-11-18 11:43:49 --> Helper loaded: url_helper
INFO - 2016-11-18 11:43:49 --> Helper loaded: form_helper
INFO - 2016-11-18 11:43:49 --> Database Driver Class Initialized
INFO - 2016-11-18 11:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:43:49 --> Controller Class Initialized
INFO - 2016-11-18 11:43:49 --> Model Class Initialized
INFO - 2016-11-18 11:43:49 --> Form Validation Class Initialized
ERROR - 2016-11-18 11:43:50 --> Severity: Notice --> Undefined variable: subordinate C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 127
ERROR - 2016-11-18 11:43:50 --> Severity: Notice --> Undefined variable: sub_subordinate C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 127
INFO - 2016-11-18 11:43:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:43:50 --> Final output sent to browser
DEBUG - 2016-11-18 11:43:50 --> Total execution time: 0.5035
INFO - 2016-11-18 11:45:01 --> Config Class Initialized
INFO - 2016-11-18 11:45:01 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:45:01 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:45:01 --> Utf8 Class Initialized
INFO - 2016-11-18 11:45:01 --> URI Class Initialized
DEBUG - 2016-11-18 11:45:01 --> No URI present. Default controller set.
INFO - 2016-11-18 11:45:01 --> Router Class Initialized
INFO - 2016-11-18 11:45:01 --> Output Class Initialized
INFO - 2016-11-18 11:45:01 --> Security Class Initialized
DEBUG - 2016-11-18 11:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:45:01 --> Input Class Initialized
INFO - 2016-11-18 11:45:01 --> Language Class Initialized
INFO - 2016-11-18 11:45:01 --> Loader Class Initialized
INFO - 2016-11-18 11:45:01 --> Helper loaded: url_helper
INFO - 2016-11-18 11:45:01 --> Helper loaded: form_helper
INFO - 2016-11-18 11:45:01 --> Database Driver Class Initialized
INFO - 2016-11-18 11:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:45:01 --> Controller Class Initialized
INFO - 2016-11-18 11:45:01 --> Model Class Initialized
INFO - 2016-11-18 11:45:01 --> Model Class Initialized
INFO - 2016-11-18 11:45:01 --> Model Class Initialized
INFO - 2016-11-18 11:45:01 --> Model Class Initialized
INFO - 2016-11-18 11:45:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:45:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:45:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:45:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:45:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:45:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:45:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:45:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:45:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:45:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:45:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:45:02 --> Final output sent to browser
DEBUG - 2016-11-18 11:45:02 --> Total execution time: 0.5398
INFO - 2016-11-18 11:45:09 --> Config Class Initialized
INFO - 2016-11-18 11:45:09 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:45:09 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:45:09 --> Utf8 Class Initialized
INFO - 2016-11-18 11:45:09 --> URI Class Initialized
INFO - 2016-11-18 11:45:09 --> Router Class Initialized
INFO - 2016-11-18 11:45:09 --> Output Class Initialized
INFO - 2016-11-18 11:45:09 --> Security Class Initialized
DEBUG - 2016-11-18 11:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:45:09 --> Input Class Initialized
INFO - 2016-11-18 11:45:09 --> Language Class Initialized
INFO - 2016-11-18 11:45:09 --> Loader Class Initialized
INFO - 2016-11-18 11:45:09 --> Helper loaded: url_helper
INFO - 2016-11-18 11:45:09 --> Helper loaded: form_helper
INFO - 2016-11-18 11:45:09 --> Database Driver Class Initialized
INFO - 2016-11-18 11:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:45:09 --> Controller Class Initialized
INFO - 2016-11-18 11:45:09 --> Model Class Initialized
INFO - 2016-11-18 11:45:10 --> Form Validation Class Initialized
ERROR - 2016-11-18 11:45:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:45:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:45:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:45:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:45:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:45:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:45:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:45:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:45:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:45:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:45:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:45:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-18 11:45:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:45:10 --> Final output sent to browser
DEBUG - 2016-11-18 11:45:10 --> Total execution time: 1.1726
INFO - 2016-11-18 11:45:51 --> Config Class Initialized
INFO - 2016-11-18 11:45:51 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:45:51 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:45:51 --> Utf8 Class Initialized
INFO - 2016-11-18 11:45:51 --> URI Class Initialized
DEBUG - 2016-11-18 11:45:51 --> No URI present. Default controller set.
INFO - 2016-11-18 11:45:51 --> Router Class Initialized
INFO - 2016-11-18 11:45:51 --> Output Class Initialized
INFO - 2016-11-18 11:45:51 --> Security Class Initialized
DEBUG - 2016-11-18 11:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:45:51 --> Input Class Initialized
INFO - 2016-11-18 11:45:51 --> Language Class Initialized
INFO - 2016-11-18 11:45:51 --> Loader Class Initialized
INFO - 2016-11-18 11:45:51 --> Helper loaded: url_helper
INFO - 2016-11-18 11:45:52 --> Helper loaded: form_helper
INFO - 2016-11-18 11:45:52 --> Database Driver Class Initialized
INFO - 2016-11-18 11:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:45:52 --> Controller Class Initialized
INFO - 2016-11-18 11:45:52 --> Model Class Initialized
INFO - 2016-11-18 11:45:52 --> Model Class Initialized
INFO - 2016-11-18 11:45:52 --> Model Class Initialized
INFO - 2016-11-18 11:45:52 --> Model Class Initialized
INFO - 2016-11-18 11:45:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:45:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:45:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:45:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:45:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:45:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:45:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:45:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:45:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:45:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:45:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:45:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:45:52 --> Final output sent to browser
DEBUG - 2016-11-18 11:45:52 --> Total execution time: 0.5853
INFO - 2016-11-18 11:46:04 --> Config Class Initialized
INFO - 2016-11-18 11:46:04 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:46:04 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:46:04 --> Utf8 Class Initialized
INFO - 2016-11-18 11:46:04 --> URI Class Initialized
INFO - 2016-11-18 11:46:04 --> Router Class Initialized
INFO - 2016-11-18 11:46:04 --> Output Class Initialized
INFO - 2016-11-18 11:46:04 --> Security Class Initialized
DEBUG - 2016-11-18 11:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:46:04 --> Input Class Initialized
INFO - 2016-11-18 11:46:04 --> Language Class Initialized
INFO - 2016-11-18 11:46:04 --> Loader Class Initialized
INFO - 2016-11-18 11:46:04 --> Helper loaded: url_helper
INFO - 2016-11-18 11:46:04 --> Helper loaded: form_helper
INFO - 2016-11-18 11:46:04 --> Database Driver Class Initialized
INFO - 2016-11-18 11:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:46:04 --> Controller Class Initialized
INFO - 2016-11-18 11:46:04 --> Model Class Initialized
INFO - 2016-11-18 11:46:04 --> Form Validation Class Initialized
ERROR - 2016-11-18 11:46:04 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:46:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:46:04 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:46:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:46:04 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:46:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:46:04 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:46:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:46:05 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:46:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:46:05 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:46:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:46:05 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:46:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:46:05 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:46:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:46:05 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:46:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:46:05 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:46:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:46:05 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:46:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:46:05 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:46:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-18 11:46:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:46:05 --> Final output sent to browser
DEBUG - 2016-11-18 11:46:05 --> Total execution time: 0.9909
INFO - 2016-11-18 11:46:33 --> Config Class Initialized
INFO - 2016-11-18 11:46:33 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:46:33 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:46:33 --> Utf8 Class Initialized
INFO - 2016-11-18 11:46:33 --> URI Class Initialized
DEBUG - 2016-11-18 11:46:33 --> No URI present. Default controller set.
INFO - 2016-11-18 11:46:33 --> Router Class Initialized
INFO - 2016-11-18 11:46:33 --> Output Class Initialized
INFO - 2016-11-18 11:46:33 --> Security Class Initialized
DEBUG - 2016-11-18 11:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:46:33 --> Input Class Initialized
INFO - 2016-11-18 11:46:33 --> Language Class Initialized
INFO - 2016-11-18 11:46:33 --> Loader Class Initialized
INFO - 2016-11-18 11:46:33 --> Helper loaded: url_helper
INFO - 2016-11-18 11:46:33 --> Helper loaded: form_helper
INFO - 2016-11-18 11:46:33 --> Database Driver Class Initialized
INFO - 2016-11-18 11:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:46:33 --> Controller Class Initialized
INFO - 2016-11-18 11:46:33 --> Model Class Initialized
INFO - 2016-11-18 11:46:33 --> Model Class Initialized
INFO - 2016-11-18 11:46:33 --> Model Class Initialized
INFO - 2016-11-18 11:46:33 --> Model Class Initialized
INFO - 2016-11-18 11:46:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:46:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:46:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:46:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:46:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:46:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:46:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:46:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:46:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:46:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:46:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:46:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:46:33 --> Final output sent to browser
DEBUG - 2016-11-18 11:46:33 --> Total execution time: 0.5831
INFO - 2016-11-18 11:47:56 --> Config Class Initialized
INFO - 2016-11-18 11:47:56 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:47:56 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:47:56 --> Utf8 Class Initialized
INFO - 2016-11-18 11:47:56 --> URI Class Initialized
DEBUG - 2016-11-18 11:47:56 --> No URI present. Default controller set.
INFO - 2016-11-18 11:47:56 --> Router Class Initialized
INFO - 2016-11-18 11:47:56 --> Output Class Initialized
INFO - 2016-11-18 11:47:56 --> Security Class Initialized
DEBUG - 2016-11-18 11:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:47:56 --> Input Class Initialized
INFO - 2016-11-18 11:47:56 --> Language Class Initialized
INFO - 2016-11-18 11:47:56 --> Loader Class Initialized
INFO - 2016-11-18 11:47:56 --> Helper loaded: url_helper
INFO - 2016-11-18 11:47:56 --> Helper loaded: form_helper
INFO - 2016-11-18 11:47:56 --> Database Driver Class Initialized
INFO - 2016-11-18 11:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:47:56 --> Controller Class Initialized
INFO - 2016-11-18 11:47:56 --> Model Class Initialized
INFO - 2016-11-18 11:47:56 --> Model Class Initialized
INFO - 2016-11-18 11:47:56 --> Model Class Initialized
INFO - 2016-11-18 11:47:57 --> Model Class Initialized
INFO - 2016-11-18 11:47:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:47:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:47:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:47:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:47:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:47:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:47:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:47:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:47:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:47:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:47:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:47:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:47:57 --> Final output sent to browser
DEBUG - 2016-11-18 11:47:57 --> Total execution time: 0.5499
INFO - 2016-11-18 11:48:02 --> Config Class Initialized
INFO - 2016-11-18 11:48:03 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:48:03 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:48:03 --> Utf8 Class Initialized
INFO - 2016-11-18 11:48:03 --> URI Class Initialized
INFO - 2016-11-18 11:48:03 --> Router Class Initialized
INFO - 2016-11-18 11:48:03 --> Output Class Initialized
INFO - 2016-11-18 11:48:03 --> Security Class Initialized
DEBUG - 2016-11-18 11:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:48:03 --> Input Class Initialized
INFO - 2016-11-18 11:48:03 --> Language Class Initialized
INFO - 2016-11-18 11:48:03 --> Loader Class Initialized
INFO - 2016-11-18 11:48:03 --> Helper loaded: url_helper
INFO - 2016-11-18 11:48:03 --> Helper loaded: form_helper
INFO - 2016-11-18 11:48:03 --> Database Driver Class Initialized
INFO - 2016-11-18 11:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:48:03 --> Controller Class Initialized
INFO - 2016-11-18 11:48:03 --> Model Class Initialized
INFO - 2016-11-18 11:48:03 --> Form Validation Class Initialized
ERROR - 2016-11-18 11:48:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:48:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:48:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:48:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:48:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:48:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:48:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:48:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:48:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:48:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:48:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:48:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:48:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:48:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:48:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:48:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:48:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:48:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:48:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:48:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:48:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:48:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:48:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:48:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-18 11:48:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:48:04 --> Final output sent to browser
DEBUG - 2016-11-18 11:48:04 --> Total execution time: 1.0484
INFO - 2016-11-18 11:48:04 --> Config Class Initialized
INFO - 2016-11-18 11:48:04 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:48:04 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:48:04 --> Utf8 Class Initialized
INFO - 2016-11-18 11:48:04 --> URI Class Initialized
DEBUG - 2016-11-18 11:48:04 --> No URI present. Default controller set.
INFO - 2016-11-18 11:48:04 --> Router Class Initialized
INFO - 2016-11-18 11:48:04 --> Output Class Initialized
INFO - 2016-11-18 11:48:04 --> Security Class Initialized
DEBUG - 2016-11-18 11:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:48:04 --> Input Class Initialized
INFO - 2016-11-18 11:48:04 --> Language Class Initialized
INFO - 2016-11-18 11:48:04 --> Loader Class Initialized
INFO - 2016-11-18 11:48:04 --> Helper loaded: url_helper
INFO - 2016-11-18 11:48:04 --> Helper loaded: form_helper
INFO - 2016-11-18 11:48:04 --> Database Driver Class Initialized
INFO - 2016-11-18 11:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:48:04 --> Controller Class Initialized
INFO - 2016-11-18 11:48:04 --> Model Class Initialized
INFO - 2016-11-18 11:48:04 --> Model Class Initialized
INFO - 2016-11-18 11:48:04 --> Model Class Initialized
INFO - 2016-11-18 11:48:04 --> Model Class Initialized
INFO - 2016-11-18 11:48:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:48:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:48:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:48:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:48:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:48:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:48:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:48:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:48:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:48:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:48:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:48:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:48:04 --> Final output sent to browser
DEBUG - 2016-11-18 11:48:04 --> Total execution time: 0.5458
INFO - 2016-11-18 11:49:10 --> Config Class Initialized
INFO - 2016-11-18 11:49:10 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:49:10 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:49:10 --> Utf8 Class Initialized
INFO - 2016-11-18 11:49:10 --> URI Class Initialized
DEBUG - 2016-11-18 11:49:10 --> No URI present. Default controller set.
INFO - 2016-11-18 11:49:10 --> Router Class Initialized
INFO - 2016-11-18 11:49:10 --> Output Class Initialized
INFO - 2016-11-18 11:49:10 --> Security Class Initialized
DEBUG - 2016-11-18 11:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:49:10 --> Input Class Initialized
INFO - 2016-11-18 11:49:10 --> Language Class Initialized
INFO - 2016-11-18 11:49:10 --> Loader Class Initialized
INFO - 2016-11-18 11:49:10 --> Helper loaded: url_helper
INFO - 2016-11-18 11:49:10 --> Helper loaded: form_helper
INFO - 2016-11-18 11:49:10 --> Database Driver Class Initialized
INFO - 2016-11-18 11:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:49:10 --> Controller Class Initialized
INFO - 2016-11-18 11:49:10 --> Model Class Initialized
INFO - 2016-11-18 11:49:10 --> Model Class Initialized
INFO - 2016-11-18 11:49:10 --> Model Class Initialized
INFO - 2016-11-18 11:49:10 --> Model Class Initialized
INFO - 2016-11-18 11:49:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:49:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:49:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:49:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:49:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:49:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:49:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:49:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:49:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:49:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:49:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:49:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:49:10 --> Final output sent to browser
DEBUG - 2016-11-18 11:49:10 --> Total execution time: 0.5351
INFO - 2016-11-18 11:49:25 --> Config Class Initialized
INFO - 2016-11-18 11:49:25 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:49:25 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:49:25 --> Utf8 Class Initialized
INFO - 2016-11-18 11:49:25 --> URI Class Initialized
INFO - 2016-11-18 11:49:25 --> Router Class Initialized
INFO - 2016-11-18 11:49:25 --> Output Class Initialized
INFO - 2016-11-18 11:49:25 --> Security Class Initialized
DEBUG - 2016-11-18 11:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:49:25 --> Input Class Initialized
INFO - 2016-11-18 11:49:25 --> Language Class Initialized
INFO - 2016-11-18 11:49:25 --> Loader Class Initialized
INFO - 2016-11-18 11:49:25 --> Helper loaded: url_helper
INFO - 2016-11-18 11:49:25 --> Helper loaded: form_helper
INFO - 2016-11-18 11:49:25 --> Database Driver Class Initialized
INFO - 2016-11-18 11:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:49:25 --> Controller Class Initialized
INFO - 2016-11-18 11:49:25 --> Model Class Initialized
INFO - 2016-11-18 11:49:25 --> Form Validation Class Initialized
INFO - 2016-11-18 11:49:25 --> Final output sent to browser
DEBUG - 2016-11-18 11:49:25 --> Total execution time: 0.3035
INFO - 2016-11-18 11:49:25 --> Config Class Initialized
INFO - 2016-11-18 11:49:25 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:49:25 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:49:25 --> Utf8 Class Initialized
INFO - 2016-11-18 11:49:25 --> URI Class Initialized
DEBUG - 2016-11-18 11:49:25 --> No URI present. Default controller set.
INFO - 2016-11-18 11:49:25 --> Router Class Initialized
INFO - 2016-11-18 11:49:25 --> Output Class Initialized
INFO - 2016-11-18 11:49:25 --> Security Class Initialized
DEBUG - 2016-11-18 11:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:49:25 --> Input Class Initialized
INFO - 2016-11-18 11:49:25 --> Language Class Initialized
INFO - 2016-11-18 11:49:25 --> Loader Class Initialized
INFO - 2016-11-18 11:49:25 --> Helper loaded: url_helper
INFO - 2016-11-18 11:49:25 --> Helper loaded: form_helper
INFO - 2016-11-18 11:49:25 --> Database Driver Class Initialized
INFO - 2016-11-18 11:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:49:25 --> Controller Class Initialized
INFO - 2016-11-18 11:49:25 --> Model Class Initialized
INFO - 2016-11-18 11:49:25 --> Model Class Initialized
INFO - 2016-11-18 11:49:25 --> Model Class Initialized
INFO - 2016-11-18 11:49:25 --> Model Class Initialized
INFO - 2016-11-18 11:49:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:49:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:49:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:49:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:49:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:49:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:49:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:49:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:49:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:49:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:49:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:49:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:49:26 --> Final output sent to browser
DEBUG - 2016-11-18 11:49:26 --> Total execution time: 0.5407
INFO - 2016-11-18 11:49:47 --> Config Class Initialized
INFO - 2016-11-18 11:49:47 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:49:47 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:49:47 --> Utf8 Class Initialized
INFO - 2016-11-18 11:49:47 --> URI Class Initialized
DEBUG - 2016-11-18 11:49:47 --> No URI present. Default controller set.
INFO - 2016-11-18 11:49:47 --> Router Class Initialized
INFO - 2016-11-18 11:49:47 --> Output Class Initialized
INFO - 2016-11-18 11:49:47 --> Security Class Initialized
DEBUG - 2016-11-18 11:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:49:47 --> Input Class Initialized
INFO - 2016-11-18 11:49:48 --> Language Class Initialized
INFO - 2016-11-18 11:49:48 --> Loader Class Initialized
INFO - 2016-11-18 11:49:48 --> Helper loaded: url_helper
INFO - 2016-11-18 11:49:48 --> Helper loaded: form_helper
INFO - 2016-11-18 11:49:48 --> Database Driver Class Initialized
INFO - 2016-11-18 11:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:49:48 --> Controller Class Initialized
INFO - 2016-11-18 11:49:48 --> Model Class Initialized
INFO - 2016-11-18 11:49:48 --> Model Class Initialized
INFO - 2016-11-18 11:49:48 --> Model Class Initialized
INFO - 2016-11-18 11:49:48 --> Model Class Initialized
INFO - 2016-11-18 11:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:49:48 --> Final output sent to browser
DEBUG - 2016-11-18 11:49:48 --> Total execution time: 0.5541
INFO - 2016-11-18 11:49:54 --> Config Class Initialized
INFO - 2016-11-18 11:49:54 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:49:54 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:49:54 --> Utf8 Class Initialized
INFO - 2016-11-18 11:49:54 --> URI Class Initialized
INFO - 2016-11-18 11:49:54 --> Router Class Initialized
INFO - 2016-11-18 11:49:54 --> Output Class Initialized
INFO - 2016-11-18 11:49:54 --> Security Class Initialized
DEBUG - 2016-11-18 11:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:49:54 --> Input Class Initialized
INFO - 2016-11-18 11:49:54 --> Language Class Initialized
INFO - 2016-11-18 11:49:54 --> Loader Class Initialized
INFO - 2016-11-18 11:49:55 --> Helper loaded: url_helper
INFO - 2016-11-18 11:49:55 --> Helper loaded: form_helper
INFO - 2016-11-18 11:49:55 --> Database Driver Class Initialized
INFO - 2016-11-18 11:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:49:55 --> Controller Class Initialized
INFO - 2016-11-18 11:49:55 --> Model Class Initialized
INFO - 2016-11-18 11:49:55 --> Form Validation Class Initialized
INFO - 2016-11-18 11:49:55 --> Final output sent to browser
DEBUG - 2016-11-18 11:49:55 --> Total execution time: 0.2889
INFO - 2016-11-18 11:49:55 --> Config Class Initialized
INFO - 2016-11-18 11:49:55 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:49:55 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:49:55 --> Utf8 Class Initialized
INFO - 2016-11-18 11:49:55 --> URI Class Initialized
DEBUG - 2016-11-18 11:49:55 --> No URI present. Default controller set.
INFO - 2016-11-18 11:49:55 --> Router Class Initialized
INFO - 2016-11-18 11:49:55 --> Output Class Initialized
INFO - 2016-11-18 11:49:55 --> Security Class Initialized
DEBUG - 2016-11-18 11:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:49:55 --> Input Class Initialized
INFO - 2016-11-18 11:49:55 --> Language Class Initialized
INFO - 2016-11-18 11:49:55 --> Loader Class Initialized
INFO - 2016-11-18 11:49:55 --> Helper loaded: url_helper
INFO - 2016-11-18 11:49:55 --> Helper loaded: form_helper
INFO - 2016-11-18 11:49:55 --> Database Driver Class Initialized
INFO - 2016-11-18 11:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:49:55 --> Controller Class Initialized
INFO - 2016-11-18 11:49:55 --> Model Class Initialized
INFO - 2016-11-18 11:49:55 --> Model Class Initialized
INFO - 2016-11-18 11:49:55 --> Model Class Initialized
INFO - 2016-11-18 11:49:55 --> Model Class Initialized
INFO - 2016-11-18 11:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:49:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:49:55 --> Final output sent to browser
DEBUG - 2016-11-18 11:49:55 --> Total execution time: 0.5473
INFO - 2016-11-18 11:50:07 --> Config Class Initialized
INFO - 2016-11-18 11:50:07 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:50:07 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:50:07 --> Utf8 Class Initialized
INFO - 2016-11-18 11:50:07 --> URI Class Initialized
DEBUG - 2016-11-18 11:50:07 --> No URI present. Default controller set.
INFO - 2016-11-18 11:50:07 --> Router Class Initialized
INFO - 2016-11-18 11:50:07 --> Output Class Initialized
INFO - 2016-11-18 11:50:07 --> Security Class Initialized
DEBUG - 2016-11-18 11:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:50:07 --> Input Class Initialized
INFO - 2016-11-18 11:50:07 --> Language Class Initialized
INFO - 2016-11-18 11:50:07 --> Loader Class Initialized
INFO - 2016-11-18 11:50:07 --> Helper loaded: url_helper
INFO - 2016-11-18 11:50:07 --> Helper loaded: form_helper
INFO - 2016-11-18 11:50:07 --> Database Driver Class Initialized
INFO - 2016-11-18 11:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:50:07 --> Controller Class Initialized
INFO - 2016-11-18 11:50:07 --> Model Class Initialized
INFO - 2016-11-18 11:50:07 --> Model Class Initialized
INFO - 2016-11-18 11:50:07 --> Model Class Initialized
INFO - 2016-11-18 11:50:07 --> Model Class Initialized
INFO - 2016-11-18 11:50:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:50:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:50:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:50:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:50:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:50:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:50:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:50:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:50:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:50:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:50:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:50:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:50:07 --> Final output sent to browser
DEBUG - 2016-11-18 11:50:07 --> Total execution time: 0.6003
INFO - 2016-11-18 11:50:19 --> Config Class Initialized
INFO - 2016-11-18 11:50:19 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:50:19 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:50:19 --> Utf8 Class Initialized
INFO - 2016-11-18 11:50:19 --> URI Class Initialized
INFO - 2016-11-18 11:50:19 --> Router Class Initialized
INFO - 2016-11-18 11:50:19 --> Output Class Initialized
INFO - 2016-11-18 11:50:19 --> Security Class Initialized
DEBUG - 2016-11-18 11:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:50:19 --> Input Class Initialized
INFO - 2016-11-18 11:50:19 --> Language Class Initialized
INFO - 2016-11-18 11:50:19 --> Loader Class Initialized
INFO - 2016-11-18 11:50:19 --> Helper loaded: url_helper
INFO - 2016-11-18 11:50:19 --> Helper loaded: form_helper
INFO - 2016-11-18 11:50:19 --> Database Driver Class Initialized
INFO - 2016-11-18 11:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:50:19 --> Controller Class Initialized
INFO - 2016-11-18 11:50:19 --> Model Class Initialized
INFO - 2016-11-18 11:50:19 --> Form Validation Class Initialized
INFO - 2016-11-18 11:50:19 --> Final output sent to browser
DEBUG - 2016-11-18 11:50:19 --> Total execution time: 0.2962
INFO - 2016-11-18 11:50:41 --> Config Class Initialized
INFO - 2016-11-18 11:50:41 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:50:41 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:50:41 --> Utf8 Class Initialized
INFO - 2016-11-18 11:50:41 --> URI Class Initialized
DEBUG - 2016-11-18 11:50:41 --> No URI present. Default controller set.
INFO - 2016-11-18 11:50:41 --> Router Class Initialized
INFO - 2016-11-18 11:50:41 --> Output Class Initialized
INFO - 2016-11-18 11:50:41 --> Security Class Initialized
DEBUG - 2016-11-18 11:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:50:41 --> Input Class Initialized
INFO - 2016-11-18 11:50:41 --> Language Class Initialized
INFO - 2016-11-18 11:50:41 --> Loader Class Initialized
INFO - 2016-11-18 11:50:41 --> Helper loaded: url_helper
INFO - 2016-11-18 11:50:41 --> Helper loaded: form_helper
INFO - 2016-11-18 11:50:41 --> Database Driver Class Initialized
INFO - 2016-11-18 11:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:50:41 --> Controller Class Initialized
INFO - 2016-11-18 11:50:41 --> Model Class Initialized
INFO - 2016-11-18 11:50:41 --> Model Class Initialized
INFO - 2016-11-18 11:50:41 --> Model Class Initialized
INFO - 2016-11-18 11:50:41 --> Model Class Initialized
INFO - 2016-11-18 11:50:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:50:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:50:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:50:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:50:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:50:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:50:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:50:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:50:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:50:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:50:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:50:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:50:42 --> Final output sent to browser
DEBUG - 2016-11-18 11:50:42 --> Total execution time: 0.5900
INFO - 2016-11-18 11:50:51 --> Config Class Initialized
INFO - 2016-11-18 11:50:51 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:50:51 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:50:51 --> Utf8 Class Initialized
INFO - 2016-11-18 11:50:51 --> URI Class Initialized
INFO - 2016-11-18 11:50:51 --> Router Class Initialized
INFO - 2016-11-18 11:50:51 --> Output Class Initialized
INFO - 2016-11-18 11:50:51 --> Security Class Initialized
DEBUG - 2016-11-18 11:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:50:51 --> Input Class Initialized
INFO - 2016-11-18 11:50:51 --> Language Class Initialized
INFO - 2016-11-18 11:50:51 --> Loader Class Initialized
INFO - 2016-11-18 11:50:51 --> Helper loaded: url_helper
INFO - 2016-11-18 11:50:51 --> Helper loaded: form_helper
INFO - 2016-11-18 11:50:51 --> Database Driver Class Initialized
INFO - 2016-11-18 11:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:50:51 --> Controller Class Initialized
INFO - 2016-11-18 11:50:51 --> Model Class Initialized
INFO - 2016-11-18 11:50:51 --> Form Validation Class Initialized
ERROR - 2016-11-18 11:50:51 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:50:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:50:51 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:50:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:50:51 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:50:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:50:51 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:50:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:50:52 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:50:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:50:52 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:50:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:50:52 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:50:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:50:52 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:50:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:50:52 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:50:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:50:52 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:50:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:50:52 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:50:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:50:52 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:50:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-18 11:50:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:50:52 --> Final output sent to browser
DEBUG - 2016-11-18 11:50:52 --> Total execution time: 1.2317
INFO - 2016-11-18 11:51:03 --> Config Class Initialized
INFO - 2016-11-18 11:51:03 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:51:03 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:51:03 --> Utf8 Class Initialized
INFO - 2016-11-18 11:51:03 --> URI Class Initialized
DEBUG - 2016-11-18 11:51:03 --> No URI present. Default controller set.
INFO - 2016-11-18 11:51:03 --> Router Class Initialized
INFO - 2016-11-18 11:51:03 --> Output Class Initialized
INFO - 2016-11-18 11:51:03 --> Security Class Initialized
DEBUG - 2016-11-18 11:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:51:03 --> Input Class Initialized
INFO - 2016-11-18 11:51:03 --> Language Class Initialized
INFO - 2016-11-18 11:51:03 --> Loader Class Initialized
INFO - 2016-11-18 11:51:03 --> Helper loaded: url_helper
INFO - 2016-11-18 11:51:03 --> Helper loaded: form_helper
INFO - 2016-11-18 11:51:03 --> Database Driver Class Initialized
INFO - 2016-11-18 11:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:51:03 --> Controller Class Initialized
INFO - 2016-11-18 11:51:03 --> Model Class Initialized
INFO - 2016-11-18 11:51:03 --> Model Class Initialized
INFO - 2016-11-18 11:51:03 --> Model Class Initialized
INFO - 2016-11-18 11:51:03 --> Model Class Initialized
INFO - 2016-11-18 11:51:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:51:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:51:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:51:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:51:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:51:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:51:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:51:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:51:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:51:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:51:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:51:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:51:03 --> Final output sent to browser
DEBUG - 2016-11-18 11:51:03 --> Total execution time: 0.6337
INFO - 2016-11-18 11:51:10 --> Config Class Initialized
INFO - 2016-11-18 11:51:10 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:51:10 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:51:10 --> Utf8 Class Initialized
INFO - 2016-11-18 11:51:10 --> URI Class Initialized
INFO - 2016-11-18 11:51:10 --> Router Class Initialized
INFO - 2016-11-18 11:51:10 --> Output Class Initialized
INFO - 2016-11-18 11:51:10 --> Security Class Initialized
DEBUG - 2016-11-18 11:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:51:10 --> Input Class Initialized
INFO - 2016-11-18 11:51:10 --> Language Class Initialized
INFO - 2016-11-18 11:51:10 --> Loader Class Initialized
INFO - 2016-11-18 11:51:10 --> Helper loaded: url_helper
INFO - 2016-11-18 11:51:10 --> Helper loaded: form_helper
INFO - 2016-11-18 11:51:10 --> Database Driver Class Initialized
INFO - 2016-11-18 11:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:51:10 --> Controller Class Initialized
INFO - 2016-11-18 11:51:10 --> Model Class Initialized
INFO - 2016-11-18 11:51:10 --> Form Validation Class Initialized
INFO - 2016-11-18 11:51:10 --> Final output sent to browser
DEBUG - 2016-11-18 11:51:10 --> Total execution time: 0.3056
INFO - 2016-11-18 11:51:19 --> Config Class Initialized
INFO - 2016-11-18 11:51:19 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:51:19 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:51:19 --> Utf8 Class Initialized
INFO - 2016-11-18 11:51:20 --> URI Class Initialized
DEBUG - 2016-11-18 11:51:20 --> No URI present. Default controller set.
INFO - 2016-11-18 11:51:20 --> Router Class Initialized
INFO - 2016-11-18 11:51:20 --> Output Class Initialized
INFO - 2016-11-18 11:51:20 --> Security Class Initialized
DEBUG - 2016-11-18 11:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:51:20 --> Input Class Initialized
INFO - 2016-11-18 11:51:20 --> Language Class Initialized
INFO - 2016-11-18 11:51:20 --> Loader Class Initialized
INFO - 2016-11-18 11:51:20 --> Helper loaded: url_helper
INFO - 2016-11-18 11:51:20 --> Helper loaded: form_helper
INFO - 2016-11-18 11:51:20 --> Database Driver Class Initialized
INFO - 2016-11-18 11:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:51:20 --> Controller Class Initialized
INFO - 2016-11-18 11:51:20 --> Model Class Initialized
INFO - 2016-11-18 11:51:20 --> Model Class Initialized
INFO - 2016-11-18 11:51:20 --> Model Class Initialized
INFO - 2016-11-18 11:51:20 --> Model Class Initialized
INFO - 2016-11-18 11:51:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:51:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:51:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:51:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:51:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:51:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:51:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:51:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:51:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:51:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:51:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:51:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:51:20 --> Final output sent to browser
DEBUG - 2016-11-18 11:51:20 --> Total execution time: 0.5807
INFO - 2016-11-18 11:51:30 --> Config Class Initialized
INFO - 2016-11-18 11:51:30 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:51:30 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:51:30 --> Utf8 Class Initialized
INFO - 2016-11-18 11:51:30 --> URI Class Initialized
INFO - 2016-11-18 11:51:30 --> Router Class Initialized
INFO - 2016-11-18 11:51:30 --> Output Class Initialized
INFO - 2016-11-18 11:51:30 --> Security Class Initialized
DEBUG - 2016-11-18 11:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:51:30 --> Input Class Initialized
INFO - 2016-11-18 11:51:30 --> Language Class Initialized
INFO - 2016-11-18 11:51:30 --> Loader Class Initialized
INFO - 2016-11-18 11:51:30 --> Helper loaded: url_helper
INFO - 2016-11-18 11:51:30 --> Helper loaded: form_helper
INFO - 2016-11-18 11:51:30 --> Database Driver Class Initialized
INFO - 2016-11-18 11:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:51:30 --> Controller Class Initialized
INFO - 2016-11-18 11:51:30 --> Model Class Initialized
INFO - 2016-11-18 11:51:30 --> Form Validation Class Initialized
INFO - 2016-11-18 11:51:30 --> Final output sent to browser
DEBUG - 2016-11-18 11:51:30 --> Total execution time: 0.3190
INFO - 2016-11-18 11:51:34 --> Config Class Initialized
INFO - 2016-11-18 11:51:34 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:51:34 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:51:34 --> Utf8 Class Initialized
INFO - 2016-11-18 11:51:34 --> URI Class Initialized
DEBUG - 2016-11-18 11:51:34 --> No URI present. Default controller set.
INFO - 2016-11-18 11:51:34 --> Router Class Initialized
INFO - 2016-11-18 11:51:34 --> Output Class Initialized
INFO - 2016-11-18 11:51:34 --> Security Class Initialized
DEBUG - 2016-11-18 11:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:51:34 --> Input Class Initialized
INFO - 2016-11-18 11:51:34 --> Language Class Initialized
INFO - 2016-11-18 11:51:34 --> Loader Class Initialized
INFO - 2016-11-18 11:51:34 --> Helper loaded: url_helper
INFO - 2016-11-18 11:51:34 --> Helper loaded: form_helper
INFO - 2016-11-18 11:51:34 --> Database Driver Class Initialized
INFO - 2016-11-18 11:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:51:34 --> Controller Class Initialized
INFO - 2016-11-18 11:51:34 --> Model Class Initialized
INFO - 2016-11-18 11:51:34 --> Model Class Initialized
INFO - 2016-11-18 11:51:34 --> Model Class Initialized
INFO - 2016-11-18 11:51:34 --> Model Class Initialized
INFO - 2016-11-18 11:51:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:51:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:51:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:51:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:51:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:51:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:51:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:51:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:51:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:51:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:51:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:51:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:51:35 --> Final output sent to browser
DEBUG - 2016-11-18 11:51:35 --> Total execution time: 0.6048
INFO - 2016-11-18 11:51:46 --> Config Class Initialized
INFO - 2016-11-18 11:51:46 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:51:46 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:51:46 --> Utf8 Class Initialized
INFO - 2016-11-18 11:51:46 --> URI Class Initialized
INFO - 2016-11-18 11:51:46 --> Router Class Initialized
INFO - 2016-11-18 11:51:46 --> Output Class Initialized
INFO - 2016-11-18 11:51:46 --> Security Class Initialized
DEBUG - 2016-11-18 11:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:51:46 --> Input Class Initialized
INFO - 2016-11-18 11:51:46 --> Language Class Initialized
INFO - 2016-11-18 11:51:46 --> Loader Class Initialized
INFO - 2016-11-18 11:51:46 --> Helper loaded: url_helper
INFO - 2016-11-18 11:51:46 --> Helper loaded: form_helper
INFO - 2016-11-18 11:51:46 --> Database Driver Class Initialized
INFO - 2016-11-18 11:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:51:46 --> Controller Class Initialized
INFO - 2016-11-18 11:51:46 --> Model Class Initialized
INFO - 2016-11-18 11:51:46 --> Form Validation Class Initialized
INFO - 2016-11-18 11:51:46 --> Final output sent to browser
DEBUG - 2016-11-18 11:51:46 --> Total execution time: 0.4479
INFO - 2016-11-18 11:51:50 --> Config Class Initialized
INFO - 2016-11-18 11:51:50 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:51:50 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:51:50 --> Utf8 Class Initialized
INFO - 2016-11-18 11:51:50 --> URI Class Initialized
DEBUG - 2016-11-18 11:51:50 --> No URI present. Default controller set.
INFO - 2016-11-18 11:51:50 --> Router Class Initialized
INFO - 2016-11-18 11:51:50 --> Output Class Initialized
INFO - 2016-11-18 11:51:50 --> Security Class Initialized
DEBUG - 2016-11-18 11:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:51:50 --> Input Class Initialized
INFO - 2016-11-18 11:51:50 --> Language Class Initialized
INFO - 2016-11-18 11:51:50 --> Loader Class Initialized
INFO - 2016-11-18 11:51:50 --> Helper loaded: url_helper
INFO - 2016-11-18 11:51:50 --> Helper loaded: form_helper
INFO - 2016-11-18 11:51:50 --> Database Driver Class Initialized
INFO - 2016-11-18 11:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:51:50 --> Controller Class Initialized
INFO - 2016-11-18 11:51:50 --> Model Class Initialized
INFO - 2016-11-18 11:51:50 --> Model Class Initialized
INFO - 2016-11-18 11:51:50 --> Model Class Initialized
INFO - 2016-11-18 11:51:50 --> Model Class Initialized
INFO - 2016-11-18 11:51:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:51:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:51:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:51:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:51:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:51:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:51:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:51:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:51:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:51:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:51:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:51:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:51:50 --> Final output sent to browser
DEBUG - 2016-11-18 11:51:50 --> Total execution time: 0.6005
INFO - 2016-11-18 11:52:00 --> Config Class Initialized
INFO - 2016-11-18 11:52:00 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:52:00 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:52:00 --> Utf8 Class Initialized
INFO - 2016-11-18 11:52:00 --> URI Class Initialized
INFO - 2016-11-18 11:52:00 --> Router Class Initialized
INFO - 2016-11-18 11:52:00 --> Output Class Initialized
INFO - 2016-11-18 11:52:00 --> Security Class Initialized
DEBUG - 2016-11-18 11:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:52:00 --> Input Class Initialized
INFO - 2016-11-18 11:52:00 --> Language Class Initialized
INFO - 2016-11-18 11:52:00 --> Loader Class Initialized
INFO - 2016-11-18 11:52:00 --> Helper loaded: url_helper
INFO - 2016-11-18 11:52:00 --> Helper loaded: form_helper
INFO - 2016-11-18 11:52:01 --> Database Driver Class Initialized
INFO - 2016-11-18 11:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:52:01 --> Controller Class Initialized
INFO - 2016-11-18 11:52:01 --> Model Class Initialized
INFO - 2016-11-18 11:52:01 --> Form Validation Class Initialized
INFO - 2016-11-18 11:52:01 --> Final output sent to browser
DEBUG - 2016-11-18 11:52:01 --> Total execution time: 0.3904
INFO - 2016-11-18 11:52:37 --> Config Class Initialized
INFO - 2016-11-18 11:52:37 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:52:37 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:52:37 --> Utf8 Class Initialized
INFO - 2016-11-18 11:52:37 --> URI Class Initialized
DEBUG - 2016-11-18 11:52:37 --> No URI present. Default controller set.
INFO - 2016-11-18 11:52:37 --> Router Class Initialized
INFO - 2016-11-18 11:52:37 --> Output Class Initialized
INFO - 2016-11-18 11:52:37 --> Security Class Initialized
DEBUG - 2016-11-18 11:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:52:37 --> Input Class Initialized
INFO - 2016-11-18 11:52:37 --> Language Class Initialized
INFO - 2016-11-18 11:52:37 --> Loader Class Initialized
INFO - 2016-11-18 11:52:37 --> Helper loaded: url_helper
INFO - 2016-11-18 11:52:37 --> Helper loaded: form_helper
INFO - 2016-11-18 11:52:37 --> Database Driver Class Initialized
INFO - 2016-11-18 11:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:52:38 --> Controller Class Initialized
INFO - 2016-11-18 11:52:38 --> Model Class Initialized
INFO - 2016-11-18 11:52:38 --> Model Class Initialized
INFO - 2016-11-18 11:52:38 --> Model Class Initialized
INFO - 2016-11-18 11:52:38 --> Model Class Initialized
INFO - 2016-11-18 11:52:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:52:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:52:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:52:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:52:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:52:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:52:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:52:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:52:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:52:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:52:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:52:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:52:38 --> Final output sent to browser
DEBUG - 2016-11-18 11:52:38 --> Total execution time: 0.6115
INFO - 2016-11-18 11:53:03 --> Config Class Initialized
INFO - 2016-11-18 11:53:03 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:53:03 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:53:03 --> Utf8 Class Initialized
INFO - 2016-11-18 11:53:03 --> URI Class Initialized
INFO - 2016-11-18 11:53:03 --> Router Class Initialized
INFO - 2016-11-18 11:53:03 --> Output Class Initialized
INFO - 2016-11-18 11:53:03 --> Security Class Initialized
DEBUG - 2016-11-18 11:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:53:03 --> Input Class Initialized
INFO - 2016-11-18 11:53:03 --> Language Class Initialized
INFO - 2016-11-18 11:53:03 --> Loader Class Initialized
INFO - 2016-11-18 11:53:03 --> Helper loaded: url_helper
INFO - 2016-11-18 11:53:03 --> Helper loaded: form_helper
INFO - 2016-11-18 11:53:03 --> Database Driver Class Initialized
INFO - 2016-11-18 11:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:53:03 --> Controller Class Initialized
INFO - 2016-11-18 11:53:03 --> Model Class Initialized
INFO - 2016-11-18 11:53:03 --> Form Validation Class Initialized
INFO - 2016-11-18 11:53:03 --> Final output sent to browser
DEBUG - 2016-11-18 11:53:03 --> Total execution time: 0.4515
INFO - 2016-11-18 11:53:27 --> Config Class Initialized
INFO - 2016-11-18 11:53:27 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:53:27 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:53:27 --> Utf8 Class Initialized
INFO - 2016-11-18 11:53:27 --> URI Class Initialized
DEBUG - 2016-11-18 11:53:27 --> No URI present. Default controller set.
INFO - 2016-11-18 11:53:27 --> Router Class Initialized
INFO - 2016-11-18 11:53:27 --> Output Class Initialized
INFO - 2016-11-18 11:53:27 --> Security Class Initialized
DEBUG - 2016-11-18 11:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:53:27 --> Input Class Initialized
INFO - 2016-11-18 11:53:27 --> Language Class Initialized
INFO - 2016-11-18 11:53:28 --> Loader Class Initialized
INFO - 2016-11-18 11:53:28 --> Helper loaded: url_helper
INFO - 2016-11-18 11:53:28 --> Helper loaded: form_helper
INFO - 2016-11-18 11:53:28 --> Database Driver Class Initialized
INFO - 2016-11-18 11:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:53:28 --> Controller Class Initialized
INFO - 2016-11-18 11:53:28 --> Model Class Initialized
INFO - 2016-11-18 11:53:28 --> Model Class Initialized
INFO - 2016-11-18 11:53:28 --> Model Class Initialized
INFO - 2016-11-18 11:53:28 --> Model Class Initialized
INFO - 2016-11-18 11:53:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:53:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:53:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:53:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:53:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:53:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:53:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:53:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:53:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:53:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:53:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:53:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:53:28 --> Final output sent to browser
DEBUG - 2016-11-18 11:53:28 --> Total execution time: 0.6117
INFO - 2016-11-18 11:54:35 --> Config Class Initialized
INFO - 2016-11-18 11:54:35 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:54:35 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:54:35 --> Utf8 Class Initialized
INFO - 2016-11-18 11:54:35 --> URI Class Initialized
DEBUG - 2016-11-18 11:54:35 --> No URI present. Default controller set.
INFO - 2016-11-18 11:54:35 --> Router Class Initialized
INFO - 2016-11-18 11:54:35 --> Output Class Initialized
INFO - 2016-11-18 11:54:35 --> Security Class Initialized
DEBUG - 2016-11-18 11:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:54:35 --> Input Class Initialized
INFO - 2016-11-18 11:54:35 --> Language Class Initialized
INFO - 2016-11-18 11:54:35 --> Loader Class Initialized
INFO - 2016-11-18 11:54:35 --> Helper loaded: url_helper
INFO - 2016-11-18 11:54:35 --> Helper loaded: form_helper
INFO - 2016-11-18 11:54:35 --> Database Driver Class Initialized
INFO - 2016-11-18 11:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:54:35 --> Controller Class Initialized
INFO - 2016-11-18 11:54:35 --> Model Class Initialized
INFO - 2016-11-18 11:54:36 --> Model Class Initialized
INFO - 2016-11-18 11:54:36 --> Model Class Initialized
INFO - 2016-11-18 11:54:36 --> Model Class Initialized
INFO - 2016-11-18 11:54:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:54:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:54:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:54:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:54:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:54:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:54:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:54:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:54:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:54:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:54:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:54:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:54:36 --> Final output sent to browser
DEBUG - 2016-11-18 11:54:36 --> Total execution time: 0.5609
INFO - 2016-11-18 11:54:43 --> Config Class Initialized
INFO - 2016-11-18 11:54:43 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:54:43 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:54:43 --> Utf8 Class Initialized
INFO - 2016-11-18 11:54:43 --> URI Class Initialized
INFO - 2016-11-18 11:54:43 --> Router Class Initialized
INFO - 2016-11-18 11:54:43 --> Output Class Initialized
INFO - 2016-11-18 11:54:43 --> Security Class Initialized
DEBUG - 2016-11-18 11:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:54:43 --> Input Class Initialized
INFO - 2016-11-18 11:54:43 --> Language Class Initialized
INFO - 2016-11-18 11:54:43 --> Loader Class Initialized
INFO - 2016-11-18 11:54:43 --> Helper loaded: url_helper
INFO - 2016-11-18 11:54:43 --> Helper loaded: form_helper
INFO - 2016-11-18 11:54:43 --> Database Driver Class Initialized
INFO - 2016-11-18 11:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:54:43 --> Controller Class Initialized
INFO - 2016-11-18 11:54:43 --> Model Class Initialized
INFO - 2016-11-18 11:54:43 --> Form Validation Class Initialized
INFO - 2016-11-18 11:54:43 --> Final output sent to browser
DEBUG - 2016-11-18 11:54:43 --> Total execution time: 0.3114
INFO - 2016-11-18 11:54:45 --> Config Class Initialized
INFO - 2016-11-18 11:54:45 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:54:45 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:54:45 --> Utf8 Class Initialized
INFO - 2016-11-18 11:54:45 --> URI Class Initialized
DEBUG - 2016-11-18 11:54:45 --> No URI present. Default controller set.
INFO - 2016-11-18 11:54:45 --> Router Class Initialized
INFO - 2016-11-18 11:54:45 --> Output Class Initialized
INFO - 2016-11-18 11:54:45 --> Security Class Initialized
DEBUG - 2016-11-18 11:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:54:45 --> Input Class Initialized
INFO - 2016-11-18 11:54:45 --> Language Class Initialized
INFO - 2016-11-18 11:54:45 --> Loader Class Initialized
INFO - 2016-11-18 11:54:45 --> Helper loaded: url_helper
INFO - 2016-11-18 11:54:45 --> Helper loaded: form_helper
INFO - 2016-11-18 11:54:45 --> Database Driver Class Initialized
INFO - 2016-11-18 11:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:54:46 --> Controller Class Initialized
INFO - 2016-11-18 11:54:46 --> Model Class Initialized
INFO - 2016-11-18 11:54:46 --> Model Class Initialized
INFO - 2016-11-18 11:54:46 --> Model Class Initialized
INFO - 2016-11-18 11:54:46 --> Model Class Initialized
INFO - 2016-11-18 11:54:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:54:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:54:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:54:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:54:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:54:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:54:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:54:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:54:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:54:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:54:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:54:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:54:46 --> Final output sent to browser
DEBUG - 2016-11-18 11:54:46 --> Total execution time: 0.6497
INFO - 2016-11-18 11:54:55 --> Config Class Initialized
INFO - 2016-11-18 11:54:55 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:54:55 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:54:55 --> Utf8 Class Initialized
INFO - 2016-11-18 11:54:55 --> URI Class Initialized
DEBUG - 2016-11-18 11:54:55 --> No URI present. Default controller set.
INFO - 2016-11-18 11:54:55 --> Router Class Initialized
INFO - 2016-11-18 11:54:55 --> Output Class Initialized
INFO - 2016-11-18 11:54:55 --> Security Class Initialized
DEBUG - 2016-11-18 11:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:54:55 --> Input Class Initialized
INFO - 2016-11-18 11:54:55 --> Language Class Initialized
INFO - 2016-11-18 11:54:55 --> Loader Class Initialized
INFO - 2016-11-18 11:54:55 --> Helper loaded: url_helper
INFO - 2016-11-18 11:54:55 --> Helper loaded: form_helper
INFO - 2016-11-18 11:54:55 --> Database Driver Class Initialized
INFO - 2016-11-18 11:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:54:55 --> Controller Class Initialized
INFO - 2016-11-18 11:54:55 --> Model Class Initialized
INFO - 2016-11-18 11:54:55 --> Model Class Initialized
INFO - 2016-11-18 11:54:55 --> Model Class Initialized
INFO - 2016-11-18 11:54:55 --> Model Class Initialized
INFO - 2016-11-18 11:54:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:54:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:54:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:54:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:54:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:54:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:54:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:54:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:54:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:54:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:54:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:54:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:54:56 --> Final output sent to browser
DEBUG - 2016-11-18 11:54:56 --> Total execution time: 0.5995
INFO - 2016-11-18 11:55:03 --> Config Class Initialized
INFO - 2016-11-18 11:55:03 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:55:03 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:55:03 --> Utf8 Class Initialized
INFO - 2016-11-18 11:55:03 --> URI Class Initialized
INFO - 2016-11-18 11:55:03 --> Router Class Initialized
INFO - 2016-11-18 11:55:03 --> Output Class Initialized
INFO - 2016-11-18 11:55:03 --> Security Class Initialized
DEBUG - 2016-11-18 11:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:55:03 --> Input Class Initialized
INFO - 2016-11-18 11:55:03 --> Language Class Initialized
INFO - 2016-11-18 11:55:03 --> Loader Class Initialized
INFO - 2016-11-18 11:55:03 --> Helper loaded: url_helper
INFO - 2016-11-18 11:55:03 --> Helper loaded: form_helper
INFO - 2016-11-18 11:55:03 --> Database Driver Class Initialized
INFO - 2016-11-18 11:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:55:03 --> Controller Class Initialized
INFO - 2016-11-18 11:55:03 --> Model Class Initialized
INFO - 2016-11-18 11:55:03 --> Form Validation Class Initialized
INFO - 2016-11-18 11:55:03 --> Final output sent to browser
DEBUG - 2016-11-18 11:55:03 --> Total execution time: 0.3261
INFO - 2016-11-18 11:55:05 --> Config Class Initialized
INFO - 2016-11-18 11:55:05 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:55:05 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:55:05 --> Utf8 Class Initialized
INFO - 2016-11-18 11:55:05 --> URI Class Initialized
DEBUG - 2016-11-18 11:55:05 --> No URI present. Default controller set.
INFO - 2016-11-18 11:55:05 --> Router Class Initialized
INFO - 2016-11-18 11:55:05 --> Output Class Initialized
INFO - 2016-11-18 11:55:05 --> Security Class Initialized
DEBUG - 2016-11-18 11:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:55:05 --> Input Class Initialized
INFO - 2016-11-18 11:55:05 --> Language Class Initialized
INFO - 2016-11-18 11:55:05 --> Loader Class Initialized
INFO - 2016-11-18 11:55:05 --> Helper loaded: url_helper
INFO - 2016-11-18 11:55:05 --> Helper loaded: form_helper
INFO - 2016-11-18 11:55:05 --> Database Driver Class Initialized
INFO - 2016-11-18 11:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:55:05 --> Controller Class Initialized
INFO - 2016-11-18 11:55:05 --> Model Class Initialized
INFO - 2016-11-18 11:55:05 --> Model Class Initialized
INFO - 2016-11-18 11:55:05 --> Model Class Initialized
INFO - 2016-11-18 11:55:05 --> Model Class Initialized
INFO - 2016-11-18 11:55:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:55:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:55:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:55:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:55:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:55:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:55:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:55:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:55:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:55:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:55:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:55:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:55:06 --> Final output sent to browser
DEBUG - 2016-11-18 11:55:06 --> Total execution time: 0.6912
INFO - 2016-11-18 11:55:13 --> Config Class Initialized
INFO - 2016-11-18 11:55:13 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:55:13 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:55:13 --> Utf8 Class Initialized
INFO - 2016-11-18 11:55:13 --> URI Class Initialized
INFO - 2016-11-18 11:55:13 --> Router Class Initialized
INFO - 2016-11-18 11:55:13 --> Output Class Initialized
INFO - 2016-11-18 11:55:13 --> Security Class Initialized
DEBUG - 2016-11-18 11:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:55:13 --> Input Class Initialized
INFO - 2016-11-18 11:55:13 --> Language Class Initialized
INFO - 2016-11-18 11:55:13 --> Loader Class Initialized
INFO - 2016-11-18 11:55:13 --> Helper loaded: url_helper
INFO - 2016-11-18 11:55:13 --> Helper loaded: form_helper
INFO - 2016-11-18 11:55:13 --> Database Driver Class Initialized
INFO - 2016-11-18 11:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:55:13 --> Controller Class Initialized
INFO - 2016-11-18 11:55:13 --> Model Class Initialized
INFO - 2016-11-18 11:55:13 --> Form Validation Class Initialized
ERROR - 2016-11-18 11:55:13 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:55:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:55:13 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:55:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:55:13 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:55:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:55:13 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:55:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:55:13 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:55:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:55:13 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:55:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:55:14 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:55:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:55:14 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:55:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:55:14 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:55:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:55:14 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:55:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:55:14 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:55:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:55:14 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 11:55:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-18 11:55:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:55:14 --> Final output sent to browser
DEBUG - 2016-11-18 11:55:14 --> Total execution time: 0.9870
INFO - 2016-11-18 11:55:42 --> Config Class Initialized
INFO - 2016-11-18 11:55:42 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:55:42 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:55:42 --> Utf8 Class Initialized
INFO - 2016-11-18 11:55:42 --> URI Class Initialized
DEBUG - 2016-11-18 11:55:42 --> No URI present. Default controller set.
INFO - 2016-11-18 11:55:42 --> Router Class Initialized
INFO - 2016-11-18 11:55:42 --> Output Class Initialized
INFO - 2016-11-18 11:55:42 --> Security Class Initialized
DEBUG - 2016-11-18 11:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:55:42 --> Input Class Initialized
INFO - 2016-11-18 11:55:42 --> Language Class Initialized
INFO - 2016-11-18 11:55:42 --> Loader Class Initialized
INFO - 2016-11-18 11:55:42 --> Helper loaded: url_helper
INFO - 2016-11-18 11:55:42 --> Helper loaded: form_helper
INFO - 2016-11-18 11:55:42 --> Database Driver Class Initialized
INFO - 2016-11-18 11:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:55:42 --> Controller Class Initialized
INFO - 2016-11-18 11:55:42 --> Model Class Initialized
INFO - 2016-11-18 11:55:42 --> Model Class Initialized
INFO - 2016-11-18 11:55:42 --> Model Class Initialized
INFO - 2016-11-18 11:55:43 --> Model Class Initialized
INFO - 2016-11-18 11:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:55:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:55:43 --> Final output sent to browser
DEBUG - 2016-11-18 11:55:43 --> Total execution time: 0.6673
INFO - 2016-11-18 11:58:48 --> Config Class Initialized
INFO - 2016-11-18 11:58:48 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:58:48 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:58:48 --> Utf8 Class Initialized
INFO - 2016-11-18 11:58:48 --> URI Class Initialized
DEBUG - 2016-11-18 11:58:48 --> No URI present. Default controller set.
INFO - 2016-11-18 11:58:48 --> Router Class Initialized
INFO - 2016-11-18 11:58:48 --> Output Class Initialized
INFO - 2016-11-18 11:58:48 --> Security Class Initialized
DEBUG - 2016-11-18 11:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:58:48 --> Input Class Initialized
INFO - 2016-11-18 11:58:48 --> Language Class Initialized
INFO - 2016-11-18 11:58:48 --> Loader Class Initialized
INFO - 2016-11-18 11:58:48 --> Helper loaded: url_helper
INFO - 2016-11-18 11:58:48 --> Helper loaded: form_helper
INFO - 2016-11-18 11:58:48 --> Database Driver Class Initialized
INFO - 2016-11-18 11:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:58:48 --> Controller Class Initialized
INFO - 2016-11-18 11:58:48 --> Model Class Initialized
INFO - 2016-11-18 11:58:48 --> Model Class Initialized
INFO - 2016-11-18 11:58:48 --> Model Class Initialized
INFO - 2016-11-18 11:58:48 --> Model Class Initialized
INFO - 2016-11-18 11:58:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:58:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:58:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:58:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:58:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:58:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:58:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:58:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:58:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:58:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:58:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:58:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:58:48 --> Final output sent to browser
DEBUG - 2016-11-18 11:58:48 --> Total execution time: 0.5683
INFO - 2016-11-18 11:59:51 --> Config Class Initialized
INFO - 2016-11-18 11:59:51 --> Hooks Class Initialized
DEBUG - 2016-11-18 11:59:51 --> UTF-8 Support Enabled
INFO - 2016-11-18 11:59:51 --> Utf8 Class Initialized
INFO - 2016-11-18 11:59:51 --> URI Class Initialized
DEBUG - 2016-11-18 11:59:51 --> No URI present. Default controller set.
INFO - 2016-11-18 11:59:51 --> Router Class Initialized
INFO - 2016-11-18 11:59:51 --> Output Class Initialized
INFO - 2016-11-18 11:59:51 --> Security Class Initialized
DEBUG - 2016-11-18 11:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 11:59:51 --> Input Class Initialized
INFO - 2016-11-18 11:59:51 --> Language Class Initialized
INFO - 2016-11-18 11:59:51 --> Loader Class Initialized
INFO - 2016-11-18 11:59:51 --> Helper loaded: url_helper
INFO - 2016-11-18 11:59:51 --> Helper loaded: form_helper
INFO - 2016-11-18 11:59:51 --> Database Driver Class Initialized
INFO - 2016-11-18 11:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 11:59:51 --> Controller Class Initialized
INFO - 2016-11-18 11:59:51 --> Model Class Initialized
INFO - 2016-11-18 11:59:51 --> Model Class Initialized
INFO - 2016-11-18 11:59:51 --> Model Class Initialized
INFO - 2016-11-18 11:59:51 --> Model Class Initialized
INFO - 2016-11-18 11:59:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 11:59:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 11:59:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 11:59:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 11:59:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 11:59:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 11:59:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 11:59:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 11:59:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 11:59:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 11:59:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 11:59:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 11:59:52 --> Final output sent to browser
DEBUG - 2016-11-18 11:59:52 --> Total execution time: 0.6406
INFO - 2016-11-18 12:01:14 --> Config Class Initialized
INFO - 2016-11-18 12:01:14 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:01:14 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:01:14 --> Utf8 Class Initialized
INFO - 2016-11-18 12:01:14 --> URI Class Initialized
DEBUG - 2016-11-18 12:01:14 --> No URI present. Default controller set.
INFO - 2016-11-18 12:01:14 --> Router Class Initialized
INFO - 2016-11-18 12:01:14 --> Output Class Initialized
INFO - 2016-11-18 12:01:14 --> Security Class Initialized
DEBUG - 2016-11-18 12:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:01:14 --> Input Class Initialized
INFO - 2016-11-18 12:01:14 --> Language Class Initialized
INFO - 2016-11-18 12:01:14 --> Loader Class Initialized
INFO - 2016-11-18 12:01:14 --> Helper loaded: url_helper
INFO - 2016-11-18 12:01:14 --> Helper loaded: form_helper
INFO - 2016-11-18 12:01:14 --> Database Driver Class Initialized
INFO - 2016-11-18 12:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:01:14 --> Controller Class Initialized
INFO - 2016-11-18 12:01:14 --> Model Class Initialized
INFO - 2016-11-18 12:01:14 --> Model Class Initialized
INFO - 2016-11-18 12:01:14 --> Model Class Initialized
INFO - 2016-11-18 12:01:14 --> Model Class Initialized
INFO - 2016-11-18 12:01:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:01:15 --> Final output sent to browser
DEBUG - 2016-11-18 12:01:15 --> Total execution time: 0.6241
INFO - 2016-11-18 12:01:35 --> Config Class Initialized
INFO - 2016-11-18 12:01:35 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:01:35 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:01:35 --> Utf8 Class Initialized
INFO - 2016-11-18 12:01:35 --> URI Class Initialized
INFO - 2016-11-18 12:01:35 --> Router Class Initialized
INFO - 2016-11-18 12:01:35 --> Output Class Initialized
INFO - 2016-11-18 12:01:35 --> Security Class Initialized
DEBUG - 2016-11-18 12:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:01:35 --> Input Class Initialized
INFO - 2016-11-18 12:01:35 --> Language Class Initialized
INFO - 2016-11-18 12:01:35 --> Loader Class Initialized
INFO - 2016-11-18 12:01:35 --> Helper loaded: url_helper
INFO - 2016-11-18 12:01:35 --> Helper loaded: form_helper
INFO - 2016-11-18 12:01:35 --> Database Driver Class Initialized
INFO - 2016-11-18 12:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:01:35 --> Controller Class Initialized
INFO - 2016-11-18 12:01:35 --> Model Class Initialized
INFO - 2016-11-18 12:01:35 --> Model Class Initialized
INFO - 2016-11-18 12:01:35 --> Model Class Initialized
INFO - 2016-11-18 12:01:35 --> Model Class Initialized
DEBUG - 2016-11-18 12:01:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-18 12:01:35 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-18 12:01:35 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-18 12:01:35 --> Config Class Initialized
INFO - 2016-11-18 12:01:35 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:01:35 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:01:35 --> Utf8 Class Initialized
INFO - 2016-11-18 12:01:35 --> URI Class Initialized
DEBUG - 2016-11-18 12:01:35 --> No URI present. Default controller set.
INFO - 2016-11-18 12:01:35 --> Router Class Initialized
INFO - 2016-11-18 12:01:35 --> Output Class Initialized
INFO - 2016-11-18 12:01:35 --> Security Class Initialized
DEBUG - 2016-11-18 12:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:01:35 --> Input Class Initialized
INFO - 2016-11-18 12:01:35 --> Language Class Initialized
INFO - 2016-11-18 12:01:36 --> Loader Class Initialized
INFO - 2016-11-18 12:01:36 --> Helper loaded: url_helper
INFO - 2016-11-18 12:01:36 --> Helper loaded: form_helper
INFO - 2016-11-18 12:01:36 --> Database Driver Class Initialized
INFO - 2016-11-18 12:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:01:36 --> Controller Class Initialized
INFO - 2016-11-18 12:01:36 --> Model Class Initialized
INFO - 2016-11-18 12:01:36 --> Model Class Initialized
INFO - 2016-11-18 12:01:36 --> Model Class Initialized
INFO - 2016-11-18 12:01:36 --> Model Class Initialized
INFO - 2016-11-18 12:01:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:01:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 12:01:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:01:36 --> Final output sent to browser
DEBUG - 2016-11-18 12:01:36 --> Total execution time: 0.4547
INFO - 2016-11-18 12:01:46 --> Config Class Initialized
INFO - 2016-11-18 12:01:46 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:01:46 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:01:46 --> Utf8 Class Initialized
INFO - 2016-11-18 12:01:46 --> URI Class Initialized
DEBUG - 2016-11-18 12:01:46 --> No URI present. Default controller set.
INFO - 2016-11-18 12:01:46 --> Router Class Initialized
INFO - 2016-11-18 12:01:46 --> Output Class Initialized
INFO - 2016-11-18 12:01:46 --> Security Class Initialized
DEBUG - 2016-11-18 12:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:01:46 --> Input Class Initialized
INFO - 2016-11-18 12:01:46 --> Language Class Initialized
INFO - 2016-11-18 12:01:46 --> Loader Class Initialized
INFO - 2016-11-18 12:01:46 --> Helper loaded: url_helper
INFO - 2016-11-18 12:01:46 --> Helper loaded: form_helper
INFO - 2016-11-18 12:01:46 --> Database Driver Class Initialized
INFO - 2016-11-18 12:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:01:46 --> Controller Class Initialized
INFO - 2016-11-18 12:01:46 --> Model Class Initialized
INFO - 2016-11-18 12:01:46 --> Model Class Initialized
INFO - 2016-11-18 12:01:46 --> Model Class Initialized
INFO - 2016-11-18 12:01:47 --> Model Class Initialized
INFO - 2016-11-18 12:01:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:01:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 12:01:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:01:47 --> Final output sent to browser
DEBUG - 2016-11-18 12:01:47 --> Total execution time: 0.8227
INFO - 2016-11-18 12:02:03 --> Config Class Initialized
INFO - 2016-11-18 12:02:04 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:02:04 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:02:04 --> Utf8 Class Initialized
INFO - 2016-11-18 12:02:04 --> URI Class Initialized
INFO - 2016-11-18 12:02:04 --> Router Class Initialized
INFO - 2016-11-18 12:02:04 --> Output Class Initialized
INFO - 2016-11-18 12:02:04 --> Security Class Initialized
DEBUG - 2016-11-18 12:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:02:04 --> Input Class Initialized
INFO - 2016-11-18 12:02:04 --> Language Class Initialized
INFO - 2016-11-18 12:02:04 --> Loader Class Initialized
INFO - 2016-11-18 12:02:04 --> Helper loaded: url_helper
INFO - 2016-11-18 12:02:04 --> Helper loaded: form_helper
INFO - 2016-11-18 12:02:04 --> Database Driver Class Initialized
INFO - 2016-11-18 12:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:02:04 --> Controller Class Initialized
INFO - 2016-11-18 12:02:04 --> Model Class Initialized
INFO - 2016-11-18 12:02:04 --> Model Class Initialized
INFO - 2016-11-18 12:02:04 --> Model Class Initialized
INFO - 2016-11-18 12:02:04 --> Model Class Initialized
DEBUG - 2016-11-18 12:02:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-18 12:02:04 --> Model Class Initialized
INFO - 2016-11-18 12:02:04 --> Final output sent to browser
DEBUG - 2016-11-18 12:02:04 --> Total execution time: 0.6559
INFO - 2016-11-18 12:02:04 --> Config Class Initialized
INFO - 2016-11-18 12:02:04 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:02:04 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:02:04 --> Utf8 Class Initialized
INFO - 2016-11-18 12:02:04 --> URI Class Initialized
DEBUG - 2016-11-18 12:02:04 --> No URI present. Default controller set.
INFO - 2016-11-18 12:02:04 --> Router Class Initialized
INFO - 2016-11-18 12:02:04 --> Output Class Initialized
INFO - 2016-11-18 12:02:04 --> Security Class Initialized
DEBUG - 2016-11-18 12:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:02:04 --> Input Class Initialized
INFO - 2016-11-18 12:02:04 --> Language Class Initialized
INFO - 2016-11-18 12:02:04 --> Loader Class Initialized
INFO - 2016-11-18 12:02:04 --> Helper loaded: url_helper
INFO - 2016-11-18 12:02:04 --> Helper loaded: form_helper
INFO - 2016-11-18 12:02:04 --> Database Driver Class Initialized
INFO - 2016-11-18 12:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:02:04 --> Controller Class Initialized
INFO - 2016-11-18 12:02:04 --> Model Class Initialized
INFO - 2016-11-18 12:02:05 --> Model Class Initialized
INFO - 2016-11-18 12:02:05 --> Model Class Initialized
INFO - 2016-11-18 12:02:05 --> Model Class Initialized
INFO - 2016-11-18 12:02:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:02:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:02:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:02:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:02:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:02:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:02:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:02:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:02:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:02:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:02:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:02:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:02:05 --> Final output sent to browser
DEBUG - 2016-11-18 12:02:05 --> Total execution time: 0.6496
INFO - 2016-11-18 12:02:52 --> Config Class Initialized
INFO - 2016-11-18 12:02:52 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:02:52 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:02:52 --> Utf8 Class Initialized
INFO - 2016-11-18 12:02:52 --> URI Class Initialized
DEBUG - 2016-11-18 12:02:52 --> No URI present. Default controller set.
INFO - 2016-11-18 12:02:52 --> Router Class Initialized
INFO - 2016-11-18 12:02:53 --> Output Class Initialized
INFO - 2016-11-18 12:02:53 --> Security Class Initialized
DEBUG - 2016-11-18 12:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:02:53 --> Input Class Initialized
INFO - 2016-11-18 12:02:53 --> Language Class Initialized
INFO - 2016-11-18 12:02:53 --> Loader Class Initialized
INFO - 2016-11-18 12:02:53 --> Helper loaded: url_helper
INFO - 2016-11-18 12:02:53 --> Helper loaded: form_helper
INFO - 2016-11-18 12:02:53 --> Database Driver Class Initialized
INFO - 2016-11-18 12:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:02:53 --> Controller Class Initialized
INFO - 2016-11-18 12:02:53 --> Model Class Initialized
INFO - 2016-11-18 12:02:53 --> Model Class Initialized
INFO - 2016-11-18 12:02:53 --> Model Class Initialized
INFO - 2016-11-18 12:02:53 --> Model Class Initialized
INFO - 2016-11-18 12:02:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:02:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:02:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:02:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:02:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:02:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:02:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:02:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:02:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:02:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:02:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:02:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:02:53 --> Final output sent to browser
DEBUG - 2016-11-18 12:02:53 --> Total execution time: 0.6322
INFO - 2016-11-18 12:02:56 --> Config Class Initialized
INFO - 2016-11-18 12:02:56 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:02:56 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:02:56 --> Utf8 Class Initialized
INFO - 2016-11-18 12:02:56 --> URI Class Initialized
INFO - 2016-11-18 12:02:56 --> Router Class Initialized
INFO - 2016-11-18 12:02:56 --> Output Class Initialized
INFO - 2016-11-18 12:02:56 --> Security Class Initialized
DEBUG - 2016-11-18 12:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:02:56 --> Input Class Initialized
INFO - 2016-11-18 12:02:56 --> Language Class Initialized
INFO - 2016-11-18 12:02:56 --> Loader Class Initialized
INFO - 2016-11-18 12:02:56 --> Helper loaded: url_helper
INFO - 2016-11-18 12:02:56 --> Helper loaded: form_helper
INFO - 2016-11-18 12:02:56 --> Database Driver Class Initialized
INFO - 2016-11-18 12:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:02:56 --> Controller Class Initialized
INFO - 2016-11-18 12:02:56 --> Model Class Initialized
INFO - 2016-11-18 12:02:56 --> Form Validation Class Initialized
INFO - 2016-11-18 12:02:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:02:56 --> Final output sent to browser
DEBUG - 2016-11-18 12:02:57 --> Total execution time: 0.3297
INFO - 2016-11-18 12:03:14 --> Config Class Initialized
INFO - 2016-11-18 12:03:14 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:03:14 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:03:14 --> Utf8 Class Initialized
INFO - 2016-11-18 12:03:14 --> URI Class Initialized
INFO - 2016-11-18 12:03:14 --> Router Class Initialized
INFO - 2016-11-18 12:03:14 --> Output Class Initialized
INFO - 2016-11-18 12:03:14 --> Security Class Initialized
DEBUG - 2016-11-18 12:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:03:14 --> Input Class Initialized
INFO - 2016-11-18 12:03:14 --> Language Class Initialized
INFO - 2016-11-18 12:03:14 --> Loader Class Initialized
INFO - 2016-11-18 12:03:14 --> Helper loaded: url_helper
INFO - 2016-11-18 12:03:14 --> Helper loaded: form_helper
INFO - 2016-11-18 12:03:14 --> Database Driver Class Initialized
INFO - 2016-11-18 12:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:03:14 --> Controller Class Initialized
INFO - 2016-11-18 12:03:14 --> Model Class Initialized
INFO - 2016-11-18 12:03:14 --> Form Validation Class Initialized
INFO - 2016-11-18 12:03:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:03:14 --> Final output sent to browser
DEBUG - 2016-11-18 12:03:14 --> Total execution time: 0.3959
INFO - 2016-11-18 12:03:19 --> Config Class Initialized
INFO - 2016-11-18 12:03:19 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:03:19 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:03:19 --> Utf8 Class Initialized
INFO - 2016-11-18 12:03:19 --> URI Class Initialized
INFO - 2016-11-18 12:03:19 --> Router Class Initialized
INFO - 2016-11-18 12:03:19 --> Output Class Initialized
INFO - 2016-11-18 12:03:19 --> Security Class Initialized
DEBUG - 2016-11-18 12:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:03:19 --> Input Class Initialized
INFO - 2016-11-18 12:03:19 --> Language Class Initialized
INFO - 2016-11-18 12:03:19 --> Loader Class Initialized
INFO - 2016-11-18 12:03:19 --> Helper loaded: url_helper
INFO - 2016-11-18 12:03:19 --> Helper loaded: form_helper
INFO - 2016-11-18 12:03:19 --> Database Driver Class Initialized
INFO - 2016-11-18 12:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:03:20 --> Controller Class Initialized
INFO - 2016-11-18 12:03:20 --> Model Class Initialized
INFO - 2016-11-18 12:03:20 --> Form Validation Class Initialized
INFO - 2016-11-18 12:03:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:03:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:03:20 --> Final output sent to browser
DEBUG - 2016-11-18 12:03:20 --> Total execution time: 0.4879
INFO - 2016-11-18 12:04:50 --> Config Class Initialized
INFO - 2016-11-18 12:04:50 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:04:50 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:04:50 --> Utf8 Class Initialized
INFO - 2016-11-18 12:04:50 --> URI Class Initialized
DEBUG - 2016-11-18 12:04:50 --> No URI present. Default controller set.
INFO - 2016-11-18 12:04:50 --> Router Class Initialized
INFO - 2016-11-18 12:04:50 --> Output Class Initialized
INFO - 2016-11-18 12:04:50 --> Security Class Initialized
DEBUG - 2016-11-18 12:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:04:50 --> Input Class Initialized
INFO - 2016-11-18 12:04:50 --> Language Class Initialized
INFO - 2016-11-18 12:04:50 --> Loader Class Initialized
INFO - 2016-11-18 12:04:50 --> Helper loaded: url_helper
INFO - 2016-11-18 12:04:50 --> Helper loaded: form_helper
INFO - 2016-11-18 12:04:50 --> Database Driver Class Initialized
INFO - 2016-11-18 12:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:04:50 --> Controller Class Initialized
INFO - 2016-11-18 12:04:50 --> Model Class Initialized
INFO - 2016-11-18 12:04:50 --> Model Class Initialized
INFO - 2016-11-18 12:04:50 --> Model Class Initialized
INFO - 2016-11-18 12:04:50 --> Model Class Initialized
INFO - 2016-11-18 12:04:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:04:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:04:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:04:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:04:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:04:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:04:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:04:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:04:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:04:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:04:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:04:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:04:51 --> Final output sent to browser
DEBUG - 2016-11-18 12:04:51 --> Total execution time: 0.6163
INFO - 2016-11-18 12:05:02 --> Config Class Initialized
INFO - 2016-11-18 12:05:02 --> Config Class Initialized
INFO - 2016-11-18 12:05:02 --> Hooks Class Initialized
INFO - 2016-11-18 12:05:02 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:05:02 --> UTF-8 Support Enabled
DEBUG - 2016-11-18 12:05:03 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:05:03 --> Utf8 Class Initialized
INFO - 2016-11-18 12:05:03 --> Utf8 Class Initialized
INFO - 2016-11-18 12:05:03 --> URI Class Initialized
INFO - 2016-11-18 12:05:03 --> URI Class Initialized
INFO - 2016-11-18 12:05:03 --> Router Class Initialized
INFO - 2016-11-18 12:05:03 --> Router Class Initialized
INFO - 2016-11-18 12:05:03 --> Output Class Initialized
INFO - 2016-11-18 12:05:03 --> Output Class Initialized
INFO - 2016-11-18 12:05:03 --> Security Class Initialized
INFO - 2016-11-18 12:05:03 --> Security Class Initialized
DEBUG - 2016-11-18 12:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-18 12:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:05:03 --> Input Class Initialized
INFO - 2016-11-18 12:05:03 --> Input Class Initialized
INFO - 2016-11-18 12:05:03 --> Language Class Initialized
INFO - 2016-11-18 12:05:03 --> Language Class Initialized
INFO - 2016-11-18 12:05:03 --> Loader Class Initialized
INFO - 2016-11-18 12:05:03 --> Loader Class Initialized
INFO - 2016-11-18 12:05:03 --> Helper loaded: url_helper
INFO - 2016-11-18 12:05:03 --> Helper loaded: url_helper
INFO - 2016-11-18 12:05:03 --> Helper loaded: form_helper
INFO - 2016-11-18 12:05:03 --> Helper loaded: form_helper
INFO - 2016-11-18 12:05:03 --> Database Driver Class Initialized
INFO - 2016-11-18 12:05:03 --> Database Driver Class Initialized
INFO - 2016-11-18 12:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:05:03 --> Controller Class Initialized
INFO - 2016-11-18 12:05:03 --> Model Class Initialized
INFO - 2016-11-18 12:05:03 --> Form Validation Class Initialized
INFO - 2016-11-18 12:05:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:05:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:05:03 --> Final output sent to browser
DEBUG - 2016-11-18 12:05:03 --> Total execution time: 0.6910
INFO - 2016-11-18 12:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:05:03 --> Controller Class Initialized
INFO - 2016-11-18 12:05:03 --> Model Class Initialized
INFO - 2016-11-18 12:05:03 --> Form Validation Class Initialized
INFO - 2016-11-18 12:05:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:05:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:05:03 --> Final output sent to browser
DEBUG - 2016-11-18 12:05:04 --> Total execution time: 1.0567
INFO - 2016-11-18 12:05:06 --> Config Class Initialized
INFO - 2016-11-18 12:05:06 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:05:07 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:05:07 --> Utf8 Class Initialized
INFO - 2016-11-18 12:05:07 --> URI Class Initialized
DEBUG - 2016-11-18 12:05:07 --> No URI present. Default controller set.
INFO - 2016-11-18 12:05:07 --> Router Class Initialized
INFO - 2016-11-18 12:05:07 --> Output Class Initialized
INFO - 2016-11-18 12:05:07 --> Security Class Initialized
DEBUG - 2016-11-18 12:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:05:07 --> Input Class Initialized
INFO - 2016-11-18 12:05:07 --> Language Class Initialized
INFO - 2016-11-18 12:05:07 --> Loader Class Initialized
INFO - 2016-11-18 12:05:07 --> Helper loaded: url_helper
INFO - 2016-11-18 12:05:07 --> Helper loaded: form_helper
INFO - 2016-11-18 12:05:07 --> Database Driver Class Initialized
INFO - 2016-11-18 12:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:05:07 --> Controller Class Initialized
INFO - 2016-11-18 12:05:07 --> Model Class Initialized
INFO - 2016-11-18 12:05:07 --> Model Class Initialized
INFO - 2016-11-18 12:05:07 --> Model Class Initialized
INFO - 2016-11-18 12:05:07 --> Model Class Initialized
INFO - 2016-11-18 12:05:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:05:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:05:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:05:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:05:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:05:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:05:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:05:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:05:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:05:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:05:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:05:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:05:07 --> Final output sent to browser
DEBUG - 2016-11-18 12:05:07 --> Total execution time: 0.6172
INFO - 2016-11-18 12:05:15 --> Config Class Initialized
INFO - 2016-11-18 12:05:15 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:05:15 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:05:15 --> Utf8 Class Initialized
INFO - 2016-11-18 12:05:15 --> URI Class Initialized
DEBUG - 2016-11-18 12:05:15 --> No URI present. Default controller set.
INFO - 2016-11-18 12:05:15 --> Router Class Initialized
INFO - 2016-11-18 12:05:15 --> Output Class Initialized
INFO - 2016-11-18 12:05:15 --> Security Class Initialized
DEBUG - 2016-11-18 12:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:05:16 --> Input Class Initialized
INFO - 2016-11-18 12:05:16 --> Language Class Initialized
INFO - 2016-11-18 12:05:16 --> Loader Class Initialized
INFO - 2016-11-18 12:05:16 --> Helper loaded: url_helper
INFO - 2016-11-18 12:05:16 --> Helper loaded: form_helper
INFO - 2016-11-18 12:05:16 --> Database Driver Class Initialized
INFO - 2016-11-18 12:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:05:16 --> Controller Class Initialized
INFO - 2016-11-18 12:05:16 --> Model Class Initialized
INFO - 2016-11-18 12:05:16 --> Model Class Initialized
INFO - 2016-11-18 12:05:16 --> Model Class Initialized
INFO - 2016-11-18 12:05:16 --> Model Class Initialized
INFO - 2016-11-18 12:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:05:16 --> Final output sent to browser
DEBUG - 2016-11-18 12:05:16 --> Total execution time: 0.6484
INFO - 2016-11-18 12:05:28 --> Config Class Initialized
INFO - 2016-11-18 12:05:28 --> Config Class Initialized
INFO - 2016-11-18 12:05:28 --> Hooks Class Initialized
INFO - 2016-11-18 12:05:28 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:05:28 --> UTF-8 Support Enabled
DEBUG - 2016-11-18 12:05:28 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:05:28 --> Utf8 Class Initialized
INFO - 2016-11-18 12:05:28 --> Utf8 Class Initialized
INFO - 2016-11-18 12:05:28 --> URI Class Initialized
INFO - 2016-11-18 12:05:28 --> URI Class Initialized
INFO - 2016-11-18 12:05:28 --> Router Class Initialized
INFO - 2016-11-18 12:05:28 --> Router Class Initialized
INFO - 2016-11-18 12:05:28 --> Output Class Initialized
INFO - 2016-11-18 12:05:28 --> Output Class Initialized
INFO - 2016-11-18 12:05:28 --> Security Class Initialized
INFO - 2016-11-18 12:05:28 --> Security Class Initialized
DEBUG - 2016-11-18 12:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-18 12:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:05:28 --> Input Class Initialized
INFO - 2016-11-18 12:05:28 --> Input Class Initialized
INFO - 2016-11-18 12:05:28 --> Language Class Initialized
INFO - 2016-11-18 12:05:28 --> Language Class Initialized
INFO - 2016-11-18 12:05:28 --> Loader Class Initialized
INFO - 2016-11-18 12:05:28 --> Loader Class Initialized
INFO - 2016-11-18 12:05:28 --> Helper loaded: url_helper
INFO - 2016-11-18 12:05:28 --> Helper loaded: url_helper
INFO - 2016-11-18 12:05:28 --> Helper loaded: form_helper
INFO - 2016-11-18 12:05:28 --> Helper loaded: form_helper
INFO - 2016-11-18 12:05:28 --> Database Driver Class Initialized
INFO - 2016-11-18 12:05:28 --> Database Driver Class Initialized
INFO - 2016-11-18 12:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:05:28 --> Controller Class Initialized
INFO - 2016-11-18 12:05:28 --> Model Class Initialized
INFO - 2016-11-18 12:05:28 --> Form Validation Class Initialized
INFO - 2016-11-18 12:05:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:05:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:05:28 --> Final output sent to browser
DEBUG - 2016-11-18 12:05:28 --> Total execution time: 0.7189
INFO - 2016-11-18 12:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:05:28 --> Controller Class Initialized
INFO - 2016-11-18 12:05:29 --> Model Class Initialized
INFO - 2016-11-18 12:05:29 --> Form Validation Class Initialized
INFO - 2016-11-18 12:05:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:05:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:05:29 --> Final output sent to browser
DEBUG - 2016-11-18 12:05:29 --> Total execution time: 1.0607
INFO - 2016-11-18 12:05:35 --> Config Class Initialized
INFO - 2016-11-18 12:05:35 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:05:35 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:05:35 --> Utf8 Class Initialized
INFO - 2016-11-18 12:05:35 --> URI Class Initialized
DEBUG - 2016-11-18 12:05:35 --> No URI present. Default controller set.
INFO - 2016-11-18 12:05:35 --> Router Class Initialized
INFO - 2016-11-18 12:05:35 --> Output Class Initialized
INFO - 2016-11-18 12:05:35 --> Security Class Initialized
DEBUG - 2016-11-18 12:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:05:35 --> Input Class Initialized
INFO - 2016-11-18 12:05:35 --> Language Class Initialized
INFO - 2016-11-18 12:05:35 --> Loader Class Initialized
INFO - 2016-11-18 12:05:35 --> Helper loaded: url_helper
INFO - 2016-11-18 12:05:35 --> Helper loaded: form_helper
INFO - 2016-11-18 12:05:35 --> Database Driver Class Initialized
INFO - 2016-11-18 12:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:05:35 --> Controller Class Initialized
INFO - 2016-11-18 12:05:35 --> Model Class Initialized
INFO - 2016-11-18 12:05:35 --> Model Class Initialized
INFO - 2016-11-18 12:05:35 --> Model Class Initialized
INFO - 2016-11-18 12:05:35 --> Model Class Initialized
INFO - 2016-11-18 12:05:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:05:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:05:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:05:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:05:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:05:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:05:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:05:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:05:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:05:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:05:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:05:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:05:36 --> Final output sent to browser
DEBUG - 2016-11-18 12:05:36 --> Total execution time: 0.6189
INFO - 2016-11-18 12:14:13 --> Config Class Initialized
INFO - 2016-11-18 12:14:13 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:14:13 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:14:13 --> Utf8 Class Initialized
INFO - 2016-11-18 12:14:13 --> URI Class Initialized
DEBUG - 2016-11-18 12:14:13 --> No URI present. Default controller set.
INFO - 2016-11-18 12:14:13 --> Router Class Initialized
INFO - 2016-11-18 12:14:13 --> Output Class Initialized
INFO - 2016-11-18 12:14:13 --> Security Class Initialized
DEBUG - 2016-11-18 12:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:14:13 --> Input Class Initialized
INFO - 2016-11-18 12:14:13 --> Language Class Initialized
INFO - 2016-11-18 12:14:13 --> Loader Class Initialized
INFO - 2016-11-18 12:14:13 --> Helper loaded: url_helper
INFO - 2016-11-18 12:14:13 --> Helper loaded: form_helper
INFO - 2016-11-18 12:14:13 --> Database Driver Class Initialized
INFO - 2016-11-18 12:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:14:13 --> Controller Class Initialized
INFO - 2016-11-18 12:14:13 --> Model Class Initialized
INFO - 2016-11-18 12:14:13 --> Model Class Initialized
INFO - 2016-11-18 12:14:13 --> Model Class Initialized
INFO - 2016-11-18 12:14:13 --> Model Class Initialized
INFO - 2016-11-18 12:14:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:14:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:14:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:14:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:14:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:14:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:14:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:14:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:14:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:14:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:14:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:14:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:14:14 --> Final output sent to browser
DEBUG - 2016-11-18 12:14:14 --> Total execution time: 0.6305
INFO - 2016-11-18 12:14:25 --> Config Class Initialized
INFO - 2016-11-18 12:14:25 --> Config Class Initialized
INFO - 2016-11-18 12:14:25 --> Hooks Class Initialized
INFO - 2016-11-18 12:14:25 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:14:25 --> UTF-8 Support Enabled
DEBUG - 2016-11-18 12:14:25 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:14:25 --> Utf8 Class Initialized
INFO - 2016-11-18 12:14:25 --> Utf8 Class Initialized
INFO - 2016-11-18 12:14:25 --> URI Class Initialized
INFO - 2016-11-18 12:14:25 --> URI Class Initialized
INFO - 2016-11-18 12:14:25 --> Router Class Initialized
INFO - 2016-11-18 12:14:25 --> Router Class Initialized
INFO - 2016-11-18 12:14:25 --> Output Class Initialized
INFO - 2016-11-18 12:14:25 --> Output Class Initialized
INFO - 2016-11-18 12:14:25 --> Security Class Initialized
INFO - 2016-11-18 12:14:25 --> Security Class Initialized
DEBUG - 2016-11-18 12:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-18 12:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:14:25 --> Input Class Initialized
INFO - 2016-11-18 12:14:25 --> Input Class Initialized
INFO - 2016-11-18 12:14:25 --> Language Class Initialized
INFO - 2016-11-18 12:14:25 --> Language Class Initialized
INFO - 2016-11-18 12:14:25 --> Loader Class Initialized
INFO - 2016-11-18 12:14:25 --> Loader Class Initialized
INFO - 2016-11-18 12:14:25 --> Helper loaded: url_helper
INFO - 2016-11-18 12:14:25 --> Helper loaded: url_helper
INFO - 2016-11-18 12:14:25 --> Helper loaded: form_helper
INFO - 2016-11-18 12:14:25 --> Helper loaded: form_helper
INFO - 2016-11-18 12:14:25 --> Database Driver Class Initialized
INFO - 2016-11-18 12:14:25 --> Database Driver Class Initialized
INFO - 2016-11-18 12:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:14:25 --> Controller Class Initialized
INFO - 2016-11-18 12:14:25 --> Model Class Initialized
INFO - 2016-11-18 12:14:25 --> Form Validation Class Initialized
INFO - 2016-11-18 12:14:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:14:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:14:25 --> Final output sent to browser
DEBUG - 2016-11-18 12:14:25 --> Total execution time: 0.6866
INFO - 2016-11-18 12:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:14:25 --> Controller Class Initialized
INFO - 2016-11-18 12:14:26 --> Model Class Initialized
INFO - 2016-11-18 12:14:26 --> Form Validation Class Initialized
INFO - 2016-11-18 12:14:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:14:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:14:26 --> Final output sent to browser
DEBUG - 2016-11-18 12:14:26 --> Total execution time: 0.9951
INFO - 2016-11-18 12:14:31 --> Config Class Initialized
INFO - 2016-11-18 12:14:31 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:14:31 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:14:31 --> Utf8 Class Initialized
INFO - 2016-11-18 12:14:31 --> URI Class Initialized
DEBUG - 2016-11-18 12:14:31 --> No URI present. Default controller set.
INFO - 2016-11-18 12:14:31 --> Router Class Initialized
INFO - 2016-11-18 12:14:31 --> Output Class Initialized
INFO - 2016-11-18 12:14:31 --> Security Class Initialized
DEBUG - 2016-11-18 12:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:14:31 --> Input Class Initialized
INFO - 2016-11-18 12:14:31 --> Language Class Initialized
INFO - 2016-11-18 12:14:31 --> Loader Class Initialized
INFO - 2016-11-18 12:14:32 --> Helper loaded: url_helper
INFO - 2016-11-18 12:14:32 --> Helper loaded: form_helper
INFO - 2016-11-18 12:14:32 --> Database Driver Class Initialized
INFO - 2016-11-18 12:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:14:32 --> Controller Class Initialized
INFO - 2016-11-18 12:14:32 --> Model Class Initialized
INFO - 2016-11-18 12:14:32 --> Model Class Initialized
INFO - 2016-11-18 12:14:32 --> Model Class Initialized
INFO - 2016-11-18 12:14:32 --> Model Class Initialized
INFO - 2016-11-18 12:14:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:14:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:14:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:14:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:14:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:14:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:14:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:14:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:14:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:14:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:14:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:14:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:14:32 --> Final output sent to browser
DEBUG - 2016-11-18 12:14:32 --> Total execution time: 0.6545
INFO - 2016-11-18 12:15:12 --> Config Class Initialized
INFO - 2016-11-18 12:15:12 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:15:12 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:15:12 --> Utf8 Class Initialized
INFO - 2016-11-18 12:15:12 --> URI Class Initialized
DEBUG - 2016-11-18 12:15:12 --> No URI present. Default controller set.
INFO - 2016-11-18 12:15:12 --> Router Class Initialized
INFO - 2016-11-18 12:15:12 --> Output Class Initialized
INFO - 2016-11-18 12:15:12 --> Security Class Initialized
DEBUG - 2016-11-18 12:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:15:12 --> Input Class Initialized
INFO - 2016-11-18 12:15:12 --> Language Class Initialized
INFO - 2016-11-18 12:15:12 --> Loader Class Initialized
INFO - 2016-11-18 12:15:12 --> Helper loaded: url_helper
INFO - 2016-11-18 12:15:12 --> Helper loaded: form_helper
INFO - 2016-11-18 12:15:12 --> Database Driver Class Initialized
INFO - 2016-11-18 12:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:15:12 --> Controller Class Initialized
INFO - 2016-11-18 12:15:12 --> Model Class Initialized
INFO - 2016-11-18 12:15:13 --> Model Class Initialized
INFO - 2016-11-18 12:15:13 --> Model Class Initialized
INFO - 2016-11-18 12:15:13 --> Model Class Initialized
INFO - 2016-11-18 12:15:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:15:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:15:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:15:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:15:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:15:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:15:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:15:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:15:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:15:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:15:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:15:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:15:13 --> Final output sent to browser
DEBUG - 2016-11-18 12:15:13 --> Total execution time: 0.6429
INFO - 2016-11-18 12:15:33 --> Config Class Initialized
INFO - 2016-11-18 12:15:33 --> Hooks Class Initialized
INFO - 2016-11-18 12:15:33 --> Config Class Initialized
INFO - 2016-11-18 12:15:33 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:15:33 --> UTF-8 Support Enabled
DEBUG - 2016-11-18 12:15:33 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:15:33 --> Utf8 Class Initialized
INFO - 2016-11-18 12:15:33 --> Utf8 Class Initialized
INFO - 2016-11-18 12:15:33 --> URI Class Initialized
INFO - 2016-11-18 12:15:33 --> URI Class Initialized
INFO - 2016-11-18 12:15:33 --> Router Class Initialized
INFO - 2016-11-18 12:15:33 --> Router Class Initialized
INFO - 2016-11-18 12:15:33 --> Output Class Initialized
INFO - 2016-11-18 12:15:33 --> Output Class Initialized
INFO - 2016-11-18 12:15:33 --> Security Class Initialized
INFO - 2016-11-18 12:15:33 --> Security Class Initialized
DEBUG - 2016-11-18 12:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-18 12:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:15:33 --> Input Class Initialized
INFO - 2016-11-18 12:15:33 --> Input Class Initialized
INFO - 2016-11-18 12:15:34 --> Language Class Initialized
INFO - 2016-11-18 12:15:34 --> Language Class Initialized
INFO - 2016-11-18 12:15:34 --> Loader Class Initialized
INFO - 2016-11-18 12:15:34 --> Loader Class Initialized
INFO - 2016-11-18 12:15:34 --> Helper loaded: url_helper
INFO - 2016-11-18 12:15:34 --> Helper loaded: url_helper
INFO - 2016-11-18 12:15:34 --> Helper loaded: form_helper
INFO - 2016-11-18 12:15:34 --> Helper loaded: form_helper
INFO - 2016-11-18 12:15:34 --> Database Driver Class Initialized
INFO - 2016-11-18 12:15:34 --> Database Driver Class Initialized
INFO - 2016-11-18 12:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:15:34 --> Controller Class Initialized
INFO - 2016-11-18 12:15:34 --> Model Class Initialized
INFO - 2016-11-18 12:15:34 --> Form Validation Class Initialized
INFO - 2016-11-18 12:15:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:15:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:15:34 --> Final output sent to browser
DEBUG - 2016-11-18 12:15:34 --> Total execution time: 0.6915
INFO - 2016-11-18 12:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:15:34 --> Controller Class Initialized
INFO - 2016-11-18 12:15:34 --> Model Class Initialized
INFO - 2016-11-18 12:15:34 --> Form Validation Class Initialized
INFO - 2016-11-18 12:15:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:15:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:15:34 --> Final output sent to browser
DEBUG - 2016-11-18 12:15:34 --> Total execution time: 1.0926
INFO - 2016-11-18 12:15:38 --> Config Class Initialized
INFO - 2016-11-18 12:15:38 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:15:38 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:15:38 --> Utf8 Class Initialized
INFO - 2016-11-18 12:15:38 --> URI Class Initialized
DEBUG - 2016-11-18 12:15:38 --> No URI present. Default controller set.
INFO - 2016-11-18 12:15:38 --> Router Class Initialized
INFO - 2016-11-18 12:15:38 --> Output Class Initialized
INFO - 2016-11-18 12:15:38 --> Security Class Initialized
DEBUG - 2016-11-18 12:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:15:38 --> Input Class Initialized
INFO - 2016-11-18 12:15:38 --> Language Class Initialized
INFO - 2016-11-18 12:15:38 --> Loader Class Initialized
INFO - 2016-11-18 12:15:38 --> Helper loaded: url_helper
INFO - 2016-11-18 12:15:38 --> Helper loaded: form_helper
INFO - 2016-11-18 12:15:38 --> Database Driver Class Initialized
INFO - 2016-11-18 12:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:15:38 --> Controller Class Initialized
INFO - 2016-11-18 12:15:38 --> Model Class Initialized
INFO - 2016-11-18 12:15:38 --> Model Class Initialized
INFO - 2016-11-18 12:15:38 --> Model Class Initialized
INFO - 2016-11-18 12:15:38 --> Model Class Initialized
INFO - 2016-11-18 12:15:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:15:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:15:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:15:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:15:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:15:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:15:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:15:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:15:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:15:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:15:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:15:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:15:38 --> Final output sent to browser
DEBUG - 2016-11-18 12:15:38 --> Total execution time: 0.6412
INFO - 2016-11-18 12:15:52 --> Config Class Initialized
INFO - 2016-11-18 12:15:52 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:15:52 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:15:52 --> Utf8 Class Initialized
INFO - 2016-11-18 12:15:52 --> URI Class Initialized
DEBUG - 2016-11-18 12:15:52 --> No URI present. Default controller set.
INFO - 2016-11-18 12:15:52 --> Router Class Initialized
INFO - 2016-11-18 12:15:52 --> Output Class Initialized
INFO - 2016-11-18 12:15:52 --> Security Class Initialized
DEBUG - 2016-11-18 12:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:15:52 --> Input Class Initialized
INFO - 2016-11-18 12:15:52 --> Language Class Initialized
INFO - 2016-11-18 12:15:52 --> Loader Class Initialized
INFO - 2016-11-18 12:15:52 --> Helper loaded: url_helper
INFO - 2016-11-18 12:15:52 --> Helper loaded: form_helper
INFO - 2016-11-18 12:15:52 --> Database Driver Class Initialized
INFO - 2016-11-18 12:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:15:52 --> Controller Class Initialized
INFO - 2016-11-18 12:15:52 --> Model Class Initialized
INFO - 2016-11-18 12:15:52 --> Model Class Initialized
INFO - 2016-11-18 12:15:52 --> Model Class Initialized
INFO - 2016-11-18 12:15:52 --> Model Class Initialized
INFO - 2016-11-18 12:15:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:15:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:15:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:15:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:15:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:15:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:15:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:15:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:15:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:15:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:15:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:15:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:15:53 --> Final output sent to browser
DEBUG - 2016-11-18 12:15:53 --> Total execution time: 0.6513
INFO - 2016-11-18 12:18:03 --> Config Class Initialized
INFO - 2016-11-18 12:18:03 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:18:03 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:18:03 --> Utf8 Class Initialized
INFO - 2016-11-18 12:18:03 --> URI Class Initialized
DEBUG - 2016-11-18 12:18:03 --> No URI present. Default controller set.
INFO - 2016-11-18 12:18:03 --> Router Class Initialized
INFO - 2016-11-18 12:18:03 --> Output Class Initialized
INFO - 2016-11-18 12:18:03 --> Security Class Initialized
DEBUG - 2016-11-18 12:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:18:03 --> Input Class Initialized
INFO - 2016-11-18 12:18:03 --> Language Class Initialized
INFO - 2016-11-18 12:18:03 --> Loader Class Initialized
INFO - 2016-11-18 12:18:03 --> Helper loaded: url_helper
INFO - 2016-11-18 12:18:04 --> Helper loaded: form_helper
INFO - 2016-11-18 12:18:04 --> Database Driver Class Initialized
INFO - 2016-11-18 12:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:18:04 --> Controller Class Initialized
INFO - 2016-11-18 12:18:04 --> Model Class Initialized
INFO - 2016-11-18 12:18:04 --> Model Class Initialized
INFO - 2016-11-18 12:18:04 --> Model Class Initialized
INFO - 2016-11-18 12:18:04 --> Model Class Initialized
INFO - 2016-11-18 12:18:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:18:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:18:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:18:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:18:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:18:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:18:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:18:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:18:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:18:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:18:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:18:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:18:04 --> Final output sent to browser
DEBUG - 2016-11-18 12:18:04 --> Total execution time: 0.6978
INFO - 2016-11-18 12:19:31 --> Config Class Initialized
INFO - 2016-11-18 12:19:31 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:19:31 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:19:31 --> Utf8 Class Initialized
INFO - 2016-11-18 12:19:31 --> URI Class Initialized
INFO - 2016-11-18 12:19:31 --> Router Class Initialized
INFO - 2016-11-18 12:19:31 --> Output Class Initialized
INFO - 2016-11-18 12:19:31 --> Security Class Initialized
DEBUG - 2016-11-18 12:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:19:31 --> Input Class Initialized
INFO - 2016-11-18 12:19:31 --> Language Class Initialized
INFO - 2016-11-18 12:19:31 --> Loader Class Initialized
INFO - 2016-11-18 12:19:31 --> Helper loaded: url_helper
INFO - 2016-11-18 12:19:32 --> Helper loaded: form_helper
INFO - 2016-11-18 12:19:32 --> Database Driver Class Initialized
INFO - 2016-11-18 12:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:19:32 --> Controller Class Initialized
INFO - 2016-11-18 12:19:32 --> Model Class Initialized
INFO - 2016-11-18 12:19:32 --> Model Class Initialized
INFO - 2016-11-18 12:19:32 --> Model Class Initialized
INFO - 2016-11-18 12:19:32 --> Model Class Initialized
DEBUG - 2016-11-18 12:19:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-18 12:19:32 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-18 12:19:32 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-18 12:19:32 --> Config Class Initialized
INFO - 2016-11-18 12:19:32 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:19:32 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:19:32 --> Utf8 Class Initialized
INFO - 2016-11-18 12:19:32 --> URI Class Initialized
DEBUG - 2016-11-18 12:19:32 --> No URI present. Default controller set.
INFO - 2016-11-18 12:19:32 --> Router Class Initialized
INFO - 2016-11-18 12:19:32 --> Output Class Initialized
INFO - 2016-11-18 12:19:32 --> Security Class Initialized
DEBUG - 2016-11-18 12:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:19:32 --> Input Class Initialized
INFO - 2016-11-18 12:19:32 --> Language Class Initialized
INFO - 2016-11-18 12:19:32 --> Loader Class Initialized
INFO - 2016-11-18 12:19:32 --> Helper loaded: url_helper
INFO - 2016-11-18 12:19:32 --> Helper loaded: form_helper
INFO - 2016-11-18 12:19:32 --> Database Driver Class Initialized
INFO - 2016-11-18 12:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:19:32 --> Controller Class Initialized
INFO - 2016-11-18 12:19:32 --> Model Class Initialized
INFO - 2016-11-18 12:19:32 --> Model Class Initialized
INFO - 2016-11-18 12:19:32 --> Model Class Initialized
INFO - 2016-11-18 12:19:32 --> Model Class Initialized
INFO - 2016-11-18 12:19:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:19:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 12:19:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:19:32 --> Final output sent to browser
DEBUG - 2016-11-18 12:19:32 --> Total execution time: 0.4442
INFO - 2016-11-18 12:19:47 --> Config Class Initialized
INFO - 2016-11-18 12:19:47 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:19:47 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:19:47 --> Utf8 Class Initialized
INFO - 2016-11-18 12:19:47 --> URI Class Initialized
INFO - 2016-11-18 12:19:47 --> Router Class Initialized
INFO - 2016-11-18 12:19:47 --> Output Class Initialized
INFO - 2016-11-18 12:19:47 --> Security Class Initialized
DEBUG - 2016-11-18 12:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:19:47 --> Input Class Initialized
INFO - 2016-11-18 12:19:47 --> Language Class Initialized
INFO - 2016-11-18 12:19:47 --> Loader Class Initialized
INFO - 2016-11-18 12:19:47 --> Helper loaded: url_helper
INFO - 2016-11-18 12:19:47 --> Helper loaded: form_helper
INFO - 2016-11-18 12:19:47 --> Database Driver Class Initialized
INFO - 2016-11-18 12:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:19:47 --> Controller Class Initialized
INFO - 2016-11-18 12:19:47 --> Model Class Initialized
INFO - 2016-11-18 12:19:47 --> Model Class Initialized
INFO - 2016-11-18 12:19:47 --> Model Class Initialized
INFO - 2016-11-18 12:19:47 --> Model Class Initialized
DEBUG - 2016-11-18 12:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-18 12:19:47 --> Model Class Initialized
INFO - 2016-11-18 12:19:47 --> Final output sent to browser
DEBUG - 2016-11-18 12:19:47 --> Total execution time: 0.4094
INFO - 2016-11-18 12:19:47 --> Config Class Initialized
INFO - 2016-11-18 12:19:47 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:19:47 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:19:48 --> Utf8 Class Initialized
INFO - 2016-11-18 12:19:48 --> URI Class Initialized
DEBUG - 2016-11-18 12:19:48 --> No URI present. Default controller set.
INFO - 2016-11-18 12:19:48 --> Router Class Initialized
INFO - 2016-11-18 12:19:48 --> Output Class Initialized
INFO - 2016-11-18 12:19:48 --> Security Class Initialized
DEBUG - 2016-11-18 12:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:19:48 --> Input Class Initialized
INFO - 2016-11-18 12:19:48 --> Language Class Initialized
INFO - 2016-11-18 12:19:48 --> Loader Class Initialized
INFO - 2016-11-18 12:19:48 --> Helper loaded: url_helper
INFO - 2016-11-18 12:19:48 --> Helper loaded: form_helper
INFO - 2016-11-18 12:19:48 --> Database Driver Class Initialized
INFO - 2016-11-18 12:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:19:48 --> Controller Class Initialized
INFO - 2016-11-18 12:19:48 --> Model Class Initialized
INFO - 2016-11-18 12:19:48 --> Model Class Initialized
INFO - 2016-11-18 12:19:48 --> Model Class Initialized
INFO - 2016-11-18 12:19:48 --> Model Class Initialized
INFO - 2016-11-18 12:19:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:19:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:19:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:19:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:19:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:19:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:19:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:19:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:19:48 --> Final output sent to browser
DEBUG - 2016-11-18 12:19:48 --> Total execution time: 0.5565
INFO - 2016-11-18 12:20:00 --> Config Class Initialized
INFO - 2016-11-18 12:20:00 --> Config Class Initialized
INFO - 2016-11-18 12:20:00 --> Hooks Class Initialized
INFO - 2016-11-18 12:20:00 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:20:00 --> UTF-8 Support Enabled
DEBUG - 2016-11-18 12:20:00 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:20:00 --> Utf8 Class Initialized
INFO - 2016-11-18 12:20:00 --> Utf8 Class Initialized
INFO - 2016-11-18 12:20:00 --> URI Class Initialized
INFO - 2016-11-18 12:20:00 --> URI Class Initialized
INFO - 2016-11-18 12:20:00 --> Router Class Initialized
INFO - 2016-11-18 12:20:00 --> Router Class Initialized
INFO - 2016-11-18 12:20:00 --> Output Class Initialized
INFO - 2016-11-18 12:20:00 --> Output Class Initialized
INFO - 2016-11-18 12:20:00 --> Security Class Initialized
INFO - 2016-11-18 12:20:01 --> Security Class Initialized
DEBUG - 2016-11-18 12:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-18 12:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:20:01 --> Input Class Initialized
INFO - 2016-11-18 12:20:01 --> Input Class Initialized
INFO - 2016-11-18 12:20:01 --> Language Class Initialized
INFO - 2016-11-18 12:20:01 --> Language Class Initialized
INFO - 2016-11-18 12:20:01 --> Loader Class Initialized
INFO - 2016-11-18 12:20:01 --> Loader Class Initialized
INFO - 2016-11-18 12:20:01 --> Helper loaded: url_helper
INFO - 2016-11-18 12:20:01 --> Helper loaded: url_helper
INFO - 2016-11-18 12:20:01 --> Helper loaded: form_helper
INFO - 2016-11-18 12:20:01 --> Helper loaded: form_helper
INFO - 2016-11-18 12:20:01 --> Database Driver Class Initialized
INFO - 2016-11-18 12:20:01 --> Database Driver Class Initialized
INFO - 2016-11-18 12:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:20:01 --> Controller Class Initialized
INFO - 2016-11-18 12:20:01 --> Model Class Initialized
INFO - 2016-11-18 12:20:01 --> Form Validation Class Initialized
INFO - 2016-11-18 12:20:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:20:01 --> Final output sent to browser
DEBUG - 2016-11-18 12:20:01 --> Total execution time: 0.5784
INFO - 2016-11-18 12:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:20:01 --> Controller Class Initialized
INFO - 2016-11-18 12:20:01 --> Model Class Initialized
INFO - 2016-11-18 12:20:01 --> Form Validation Class Initialized
INFO - 2016-11-18 12:20:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:20:01 --> Final output sent to browser
DEBUG - 2016-11-18 12:20:01 --> Total execution time: 0.7468
INFO - 2016-11-18 12:20:11 --> Config Class Initialized
INFO - 2016-11-18 12:20:11 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:20:11 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:20:11 --> Utf8 Class Initialized
INFO - 2016-11-18 12:20:11 --> URI Class Initialized
DEBUG - 2016-11-18 12:20:11 --> No URI present. Default controller set.
INFO - 2016-11-18 12:20:11 --> Router Class Initialized
INFO - 2016-11-18 12:20:11 --> Output Class Initialized
INFO - 2016-11-18 12:20:11 --> Security Class Initialized
DEBUG - 2016-11-18 12:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:20:11 --> Input Class Initialized
INFO - 2016-11-18 12:20:11 --> Language Class Initialized
INFO - 2016-11-18 12:20:11 --> Loader Class Initialized
INFO - 2016-11-18 12:20:11 --> Helper loaded: url_helper
INFO - 2016-11-18 12:20:11 --> Helper loaded: form_helper
INFO - 2016-11-18 12:20:11 --> Database Driver Class Initialized
INFO - 2016-11-18 12:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:20:11 --> Controller Class Initialized
INFO - 2016-11-18 12:20:11 --> Model Class Initialized
INFO - 2016-11-18 12:20:11 --> Model Class Initialized
INFO - 2016-11-18 12:20:11 --> Model Class Initialized
INFO - 2016-11-18 12:20:11 --> Model Class Initialized
INFO - 2016-11-18 12:20:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:20:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:20:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:20:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:20:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:20:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:20:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:20:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:20:12 --> Final output sent to browser
DEBUG - 2016-11-18 12:20:12 --> Total execution time: 0.5899
INFO - 2016-11-18 12:20:26 --> Config Class Initialized
INFO - 2016-11-18 12:20:26 --> Config Class Initialized
INFO - 2016-11-18 12:20:26 --> Hooks Class Initialized
INFO - 2016-11-18 12:20:26 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:20:26 --> UTF-8 Support Enabled
DEBUG - 2016-11-18 12:20:27 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:20:27 --> Utf8 Class Initialized
INFO - 2016-11-18 12:20:27 --> Utf8 Class Initialized
INFO - 2016-11-18 12:20:27 --> URI Class Initialized
INFO - 2016-11-18 12:20:27 --> URI Class Initialized
INFO - 2016-11-18 12:20:27 --> Router Class Initialized
INFO - 2016-11-18 12:20:27 --> Router Class Initialized
INFO - 2016-11-18 12:20:27 --> Output Class Initialized
INFO - 2016-11-18 12:20:27 --> Output Class Initialized
INFO - 2016-11-18 12:20:27 --> Security Class Initialized
INFO - 2016-11-18 12:20:27 --> Security Class Initialized
DEBUG - 2016-11-18 12:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-18 12:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:20:27 --> Input Class Initialized
INFO - 2016-11-18 12:20:27 --> Input Class Initialized
INFO - 2016-11-18 12:20:27 --> Language Class Initialized
INFO - 2016-11-18 12:20:27 --> Language Class Initialized
INFO - 2016-11-18 12:20:27 --> Loader Class Initialized
INFO - 2016-11-18 12:20:27 --> Loader Class Initialized
INFO - 2016-11-18 12:20:27 --> Helper loaded: url_helper
INFO - 2016-11-18 12:20:27 --> Helper loaded: url_helper
INFO - 2016-11-18 12:20:27 --> Helper loaded: form_helper
INFO - 2016-11-18 12:20:27 --> Helper loaded: form_helper
INFO - 2016-11-18 12:20:27 --> Database Driver Class Initialized
INFO - 2016-11-18 12:20:27 --> Database Driver Class Initialized
INFO - 2016-11-18 12:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:20:27 --> Controller Class Initialized
INFO - 2016-11-18 12:20:27 --> Model Class Initialized
INFO - 2016-11-18 12:20:27 --> Form Validation Class Initialized
INFO - 2016-11-18 12:20:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:20:27 --> Final output sent to browser
DEBUG - 2016-11-18 12:20:27 --> Total execution time: 0.6201
INFO - 2016-11-18 12:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:20:27 --> Controller Class Initialized
INFO - 2016-11-18 12:20:27 --> Model Class Initialized
INFO - 2016-11-18 12:20:27 --> Form Validation Class Initialized
INFO - 2016-11-18 12:20:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:20:27 --> Final output sent to browser
DEBUG - 2016-11-18 12:20:27 --> Total execution time: 0.7696
INFO - 2016-11-18 12:20:29 --> Config Class Initialized
INFO - 2016-11-18 12:20:29 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:20:29 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:20:29 --> Utf8 Class Initialized
INFO - 2016-11-18 12:20:29 --> URI Class Initialized
DEBUG - 2016-11-18 12:20:29 --> No URI present. Default controller set.
INFO - 2016-11-18 12:20:29 --> Router Class Initialized
INFO - 2016-11-18 12:20:29 --> Output Class Initialized
INFO - 2016-11-18 12:20:29 --> Security Class Initialized
DEBUG - 2016-11-18 12:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:20:29 --> Input Class Initialized
INFO - 2016-11-18 12:20:29 --> Language Class Initialized
INFO - 2016-11-18 12:20:29 --> Loader Class Initialized
INFO - 2016-11-18 12:20:29 --> Helper loaded: url_helper
INFO - 2016-11-18 12:20:29 --> Helper loaded: form_helper
INFO - 2016-11-18 12:20:29 --> Database Driver Class Initialized
INFO - 2016-11-18 12:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:20:29 --> Controller Class Initialized
INFO - 2016-11-18 12:20:29 --> Model Class Initialized
INFO - 2016-11-18 12:20:29 --> Model Class Initialized
INFO - 2016-11-18 12:20:29 --> Model Class Initialized
INFO - 2016-11-18 12:20:29 --> Model Class Initialized
INFO - 2016-11-18 12:20:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:20:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:20:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:20:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:20:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:20:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:20:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:20:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:20:30 --> Final output sent to browser
DEBUG - 2016-11-18 12:20:30 --> Total execution time: 0.6522
INFO - 2016-11-18 12:20:36 --> Config Class Initialized
INFO - 2016-11-18 12:20:36 --> Config Class Initialized
INFO - 2016-11-18 12:20:36 --> Hooks Class Initialized
INFO - 2016-11-18 12:20:36 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:20:36 --> UTF-8 Support Enabled
DEBUG - 2016-11-18 12:20:36 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:20:36 --> Utf8 Class Initialized
INFO - 2016-11-18 12:20:36 --> Utf8 Class Initialized
INFO - 2016-11-18 12:20:36 --> URI Class Initialized
INFO - 2016-11-18 12:20:36 --> URI Class Initialized
INFO - 2016-11-18 12:20:36 --> Router Class Initialized
INFO - 2016-11-18 12:20:36 --> Router Class Initialized
INFO - 2016-11-18 12:20:36 --> Output Class Initialized
INFO - 2016-11-18 12:20:36 --> Output Class Initialized
INFO - 2016-11-18 12:20:36 --> Security Class Initialized
INFO - 2016-11-18 12:20:36 --> Security Class Initialized
DEBUG - 2016-11-18 12:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-18 12:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:20:36 --> Input Class Initialized
INFO - 2016-11-18 12:20:36 --> Input Class Initialized
INFO - 2016-11-18 12:20:36 --> Language Class Initialized
INFO - 2016-11-18 12:20:36 --> Language Class Initialized
INFO - 2016-11-18 12:20:36 --> Loader Class Initialized
INFO - 2016-11-18 12:20:36 --> Loader Class Initialized
INFO - 2016-11-18 12:20:36 --> Helper loaded: url_helper
INFO - 2016-11-18 12:20:36 --> Helper loaded: url_helper
INFO - 2016-11-18 12:20:36 --> Helper loaded: form_helper
INFO - 2016-11-18 12:20:36 --> Helper loaded: form_helper
INFO - 2016-11-18 12:20:36 --> Database Driver Class Initialized
INFO - 2016-11-18 12:20:36 --> Database Driver Class Initialized
INFO - 2016-11-18 12:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:20:36 --> Controller Class Initialized
INFO - 2016-11-18 12:20:36 --> Model Class Initialized
INFO - 2016-11-18 12:20:36 --> Form Validation Class Initialized
INFO - 2016-11-18 12:20:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:20:36 --> Final output sent to browser
DEBUG - 2016-11-18 12:20:36 --> Total execution time: 0.5651
INFO - 2016-11-18 12:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:20:36 --> Controller Class Initialized
INFO - 2016-11-18 12:20:36 --> Model Class Initialized
INFO - 2016-11-18 12:20:36 --> Form Validation Class Initialized
INFO - 2016-11-18 12:20:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:20:36 --> Final output sent to browser
DEBUG - 2016-11-18 12:20:36 --> Total execution time: 0.7269
INFO - 2016-11-18 12:20:38 --> Config Class Initialized
INFO - 2016-11-18 12:20:38 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:20:38 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:20:38 --> Utf8 Class Initialized
INFO - 2016-11-18 12:20:38 --> URI Class Initialized
DEBUG - 2016-11-18 12:20:38 --> No URI present. Default controller set.
INFO - 2016-11-18 12:20:38 --> Router Class Initialized
INFO - 2016-11-18 12:20:38 --> Output Class Initialized
INFO - 2016-11-18 12:20:38 --> Security Class Initialized
DEBUG - 2016-11-18 12:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:20:38 --> Input Class Initialized
INFO - 2016-11-18 12:20:38 --> Language Class Initialized
INFO - 2016-11-18 12:20:39 --> Loader Class Initialized
INFO - 2016-11-18 12:20:39 --> Helper loaded: url_helper
INFO - 2016-11-18 12:20:39 --> Helper loaded: form_helper
INFO - 2016-11-18 12:20:39 --> Database Driver Class Initialized
INFO - 2016-11-18 12:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:20:39 --> Controller Class Initialized
INFO - 2016-11-18 12:20:39 --> Model Class Initialized
INFO - 2016-11-18 12:20:39 --> Model Class Initialized
INFO - 2016-11-18 12:20:39 --> Model Class Initialized
INFO - 2016-11-18 12:20:39 --> Model Class Initialized
INFO - 2016-11-18 12:20:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:20:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:20:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:20:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:20:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:20:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:20:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:20:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:20:39 --> Final output sent to browser
DEBUG - 2016-11-18 12:20:39 --> Total execution time: 0.6195
INFO - 2016-11-18 12:21:56 --> Config Class Initialized
INFO - 2016-11-18 12:21:56 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:21:56 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:21:56 --> Utf8 Class Initialized
INFO - 2016-11-18 12:21:56 --> URI Class Initialized
DEBUG - 2016-11-18 12:21:56 --> No URI present. Default controller set.
INFO - 2016-11-18 12:21:56 --> Router Class Initialized
INFO - 2016-11-18 12:21:56 --> Output Class Initialized
INFO - 2016-11-18 12:21:56 --> Security Class Initialized
DEBUG - 2016-11-18 12:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:21:56 --> Input Class Initialized
INFO - 2016-11-18 12:21:56 --> Language Class Initialized
INFO - 2016-11-18 12:21:56 --> Loader Class Initialized
INFO - 2016-11-18 12:21:56 --> Helper loaded: url_helper
INFO - 2016-11-18 12:21:56 --> Helper loaded: form_helper
INFO - 2016-11-18 12:21:56 --> Database Driver Class Initialized
INFO - 2016-11-18 12:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:21:56 --> Controller Class Initialized
INFO - 2016-11-18 12:21:56 --> Model Class Initialized
INFO - 2016-11-18 12:21:56 --> Model Class Initialized
INFO - 2016-11-18 12:21:56 --> Model Class Initialized
INFO - 2016-11-18 12:21:56 --> Model Class Initialized
INFO - 2016-11-18 12:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:21:56 --> Final output sent to browser
DEBUG - 2016-11-18 12:21:56 --> Total execution time: 0.6193
INFO - 2016-11-18 12:21:58 --> Config Class Initialized
INFO - 2016-11-18 12:21:58 --> Config Class Initialized
INFO - 2016-11-18 12:21:58 --> Config Class Initialized
INFO - 2016-11-18 12:21:58 --> Hooks Class Initialized
INFO - 2016-11-18 12:21:58 --> Hooks Class Initialized
INFO - 2016-11-18 12:21:58 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:21:58 --> UTF-8 Support Enabled
DEBUG - 2016-11-18 12:21:58 --> UTF-8 Support Enabled
DEBUG - 2016-11-18 12:21:58 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:21:58 --> Utf8 Class Initialized
INFO - 2016-11-18 12:21:58 --> Utf8 Class Initialized
INFO - 2016-11-18 12:21:58 --> Utf8 Class Initialized
INFO - 2016-11-18 12:21:58 --> URI Class Initialized
INFO - 2016-11-18 12:21:58 --> URI Class Initialized
INFO - 2016-11-18 12:21:58 --> URI Class Initialized
INFO - 2016-11-18 12:21:58 --> Router Class Initialized
INFO - 2016-11-18 12:21:58 --> Router Class Initialized
INFO - 2016-11-18 12:21:58 --> Router Class Initialized
INFO - 2016-11-18 12:21:58 --> Output Class Initialized
INFO - 2016-11-18 12:21:58 --> Output Class Initialized
INFO - 2016-11-18 12:21:58 --> Output Class Initialized
INFO - 2016-11-18 12:21:58 --> Security Class Initialized
INFO - 2016-11-18 12:21:58 --> Security Class Initialized
INFO - 2016-11-18 12:21:58 --> Security Class Initialized
DEBUG - 2016-11-18 12:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-18 12:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-18 12:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:21:58 --> Input Class Initialized
INFO - 2016-11-18 12:21:58 --> Input Class Initialized
INFO - 2016-11-18 12:21:58 --> Input Class Initialized
INFO - 2016-11-18 12:21:58 --> Language Class Initialized
INFO - 2016-11-18 12:21:58 --> Language Class Initialized
INFO - 2016-11-18 12:21:58 --> Language Class Initialized
INFO - 2016-11-18 12:21:58 --> Loader Class Initialized
INFO - 2016-11-18 12:21:58 --> Loader Class Initialized
INFO - 2016-11-18 12:21:58 --> Loader Class Initialized
INFO - 2016-11-18 12:21:58 --> Helper loaded: url_helper
INFO - 2016-11-18 12:21:58 --> Helper loaded: url_helper
INFO - 2016-11-18 12:21:58 --> Helper loaded: url_helper
INFO - 2016-11-18 12:21:58 --> Helper loaded: form_helper
INFO - 2016-11-18 12:21:58 --> Helper loaded: form_helper
INFO - 2016-11-18 12:21:58 --> Helper loaded: form_helper
INFO - 2016-11-18 12:21:58 --> Database Driver Class Initialized
INFO - 2016-11-18 12:21:58 --> Database Driver Class Initialized
INFO - 2016-11-18 12:21:58 --> Database Driver Class Initialized
INFO - 2016-11-18 12:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:21:58 --> Controller Class Initialized
INFO - 2016-11-18 12:21:58 --> Model Class Initialized
INFO - 2016-11-18 12:21:58 --> Form Validation Class Initialized
INFO - 2016-11-18 12:21:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:21:58 --> Final output sent to browser
DEBUG - 2016-11-18 12:21:58 --> Total execution time: 0.6298
INFO - 2016-11-18 12:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:21:59 --> Controller Class Initialized
INFO - 2016-11-18 12:21:59 --> Model Class Initialized
INFO - 2016-11-18 12:21:59 --> Form Validation Class Initialized
INFO - 2016-11-18 12:21:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:21:59 --> Final output sent to browser
DEBUG - 2016-11-18 12:21:59 --> Total execution time: 0.7887
INFO - 2016-11-18 12:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:21:59 --> Controller Class Initialized
INFO - 2016-11-18 12:21:59 --> Model Class Initialized
INFO - 2016-11-18 12:21:59 --> Form Validation Class Initialized
INFO - 2016-11-18 12:21:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:21:59 --> Final output sent to browser
DEBUG - 2016-11-18 12:21:59 --> Total execution time: 0.9193
INFO - 2016-11-18 12:22:03 --> Config Class Initialized
INFO - 2016-11-18 12:22:03 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:22:03 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:22:03 --> Utf8 Class Initialized
INFO - 2016-11-18 12:22:03 --> URI Class Initialized
DEBUG - 2016-11-18 12:22:03 --> No URI present. Default controller set.
INFO - 2016-11-18 12:22:03 --> Router Class Initialized
INFO - 2016-11-18 12:22:03 --> Output Class Initialized
INFO - 2016-11-18 12:22:03 --> Security Class Initialized
DEBUG - 2016-11-18 12:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:22:03 --> Input Class Initialized
INFO - 2016-11-18 12:22:03 --> Language Class Initialized
INFO - 2016-11-18 12:22:03 --> Loader Class Initialized
INFO - 2016-11-18 12:22:03 --> Helper loaded: url_helper
INFO - 2016-11-18 12:22:03 --> Helper loaded: form_helper
INFO - 2016-11-18 12:22:04 --> Database Driver Class Initialized
INFO - 2016-11-18 12:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:22:04 --> Controller Class Initialized
INFO - 2016-11-18 12:22:04 --> Model Class Initialized
INFO - 2016-11-18 12:22:04 --> Model Class Initialized
INFO - 2016-11-18 12:22:04 --> Model Class Initialized
INFO - 2016-11-18 12:22:04 --> Model Class Initialized
INFO - 2016-11-18 12:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:22:04 --> Final output sent to browser
DEBUG - 2016-11-18 12:22:04 --> Total execution time: 0.6286
INFO - 2016-11-18 12:22:29 --> Config Class Initialized
INFO - 2016-11-18 12:22:29 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:22:29 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:22:29 --> Utf8 Class Initialized
INFO - 2016-11-18 12:22:29 --> URI Class Initialized
DEBUG - 2016-11-18 12:22:29 --> No URI present. Default controller set.
INFO - 2016-11-18 12:22:29 --> Router Class Initialized
INFO - 2016-11-18 12:22:29 --> Output Class Initialized
INFO - 2016-11-18 12:22:29 --> Security Class Initialized
DEBUG - 2016-11-18 12:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:22:29 --> Input Class Initialized
INFO - 2016-11-18 12:22:29 --> Language Class Initialized
INFO - 2016-11-18 12:22:29 --> Loader Class Initialized
INFO - 2016-11-18 12:22:29 --> Helper loaded: url_helper
INFO - 2016-11-18 12:22:29 --> Helper loaded: form_helper
INFO - 2016-11-18 12:22:29 --> Database Driver Class Initialized
INFO - 2016-11-18 12:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:22:29 --> Controller Class Initialized
INFO - 2016-11-18 12:22:29 --> Model Class Initialized
INFO - 2016-11-18 12:22:29 --> Model Class Initialized
INFO - 2016-11-18 12:22:29 --> Model Class Initialized
INFO - 2016-11-18 12:22:29 --> Model Class Initialized
INFO - 2016-11-18 12:22:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:22:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:22:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:22:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:22:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:22:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:22:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:22:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:22:29 --> Final output sent to browser
DEBUG - 2016-11-18 12:22:29 --> Total execution time: 0.6118
INFO - 2016-11-18 12:22:31 --> Config Class Initialized
INFO - 2016-11-18 12:22:31 --> Config Class Initialized
INFO - 2016-11-18 12:22:31 --> Hooks Class Initialized
INFO - 2016-11-18 12:22:31 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:22:31 --> UTF-8 Support Enabled
DEBUG - 2016-11-18 12:22:31 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:22:31 --> Utf8 Class Initialized
INFO - 2016-11-18 12:22:31 --> Utf8 Class Initialized
INFO - 2016-11-18 12:22:31 --> URI Class Initialized
INFO - 2016-11-18 12:22:31 --> URI Class Initialized
INFO - 2016-11-18 12:22:31 --> Router Class Initialized
INFO - 2016-11-18 12:22:31 --> Router Class Initialized
INFO - 2016-11-18 12:22:31 --> Output Class Initialized
INFO - 2016-11-18 12:22:31 --> Output Class Initialized
INFO - 2016-11-18 12:22:31 --> Security Class Initialized
INFO - 2016-11-18 12:22:32 --> Security Class Initialized
DEBUG - 2016-11-18 12:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-18 12:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:22:32 --> Input Class Initialized
INFO - 2016-11-18 12:22:32 --> Input Class Initialized
INFO - 2016-11-18 12:22:32 --> Language Class Initialized
INFO - 2016-11-18 12:22:32 --> Language Class Initialized
INFO - 2016-11-18 12:22:32 --> Loader Class Initialized
INFO - 2016-11-18 12:22:32 --> Loader Class Initialized
INFO - 2016-11-18 12:22:32 --> Helper loaded: url_helper
INFO - 2016-11-18 12:22:32 --> Helper loaded: url_helper
INFO - 2016-11-18 12:22:32 --> Helper loaded: form_helper
INFO - 2016-11-18 12:22:32 --> Helper loaded: form_helper
INFO - 2016-11-18 12:22:32 --> Database Driver Class Initialized
INFO - 2016-11-18 12:22:32 --> Database Driver Class Initialized
INFO - 2016-11-18 12:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:22:32 --> Controller Class Initialized
INFO - 2016-11-18 12:22:32 --> Model Class Initialized
INFO - 2016-11-18 12:22:32 --> Form Validation Class Initialized
INFO - 2016-11-18 12:22:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:22:32 --> Final output sent to browser
DEBUG - 2016-11-18 12:22:32 --> Total execution time: 0.5860
INFO - 2016-11-18 12:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:22:32 --> Controller Class Initialized
INFO - 2016-11-18 12:22:32 --> Model Class Initialized
INFO - 2016-11-18 12:22:32 --> Form Validation Class Initialized
INFO - 2016-11-18 12:22:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:22:32 --> Final output sent to browser
DEBUG - 2016-11-18 12:22:32 --> Total execution time: 0.7364
INFO - 2016-11-18 12:22:34 --> Config Class Initialized
INFO - 2016-11-18 12:22:34 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:22:34 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:22:34 --> Utf8 Class Initialized
INFO - 2016-11-18 12:22:34 --> URI Class Initialized
DEBUG - 2016-11-18 12:22:34 --> No URI present. Default controller set.
INFO - 2016-11-18 12:22:34 --> Router Class Initialized
INFO - 2016-11-18 12:22:34 --> Output Class Initialized
INFO - 2016-11-18 12:22:34 --> Security Class Initialized
DEBUG - 2016-11-18 12:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:22:34 --> Input Class Initialized
INFO - 2016-11-18 12:22:34 --> Language Class Initialized
INFO - 2016-11-18 12:22:34 --> Loader Class Initialized
INFO - 2016-11-18 12:22:34 --> Helper loaded: url_helper
INFO - 2016-11-18 12:22:34 --> Helper loaded: form_helper
INFO - 2016-11-18 12:22:34 --> Database Driver Class Initialized
INFO - 2016-11-18 12:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:22:35 --> Controller Class Initialized
INFO - 2016-11-18 12:22:35 --> Model Class Initialized
INFO - 2016-11-18 12:22:35 --> Model Class Initialized
INFO - 2016-11-18 12:22:35 --> Model Class Initialized
INFO - 2016-11-18 12:22:35 --> Model Class Initialized
INFO - 2016-11-18 12:22:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:22:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:22:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:22:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:22:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:22:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:22:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:22:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:22:35 --> Final output sent to browser
DEBUG - 2016-11-18 12:22:35 --> Total execution time: 0.6531
INFO - 2016-11-18 12:23:56 --> Config Class Initialized
INFO - 2016-11-18 12:23:56 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:23:56 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:23:56 --> Utf8 Class Initialized
INFO - 2016-11-18 12:23:57 --> URI Class Initialized
DEBUG - 2016-11-18 12:23:57 --> No URI present. Default controller set.
INFO - 2016-11-18 12:23:57 --> Router Class Initialized
INFO - 2016-11-18 12:23:57 --> Output Class Initialized
INFO - 2016-11-18 12:23:57 --> Security Class Initialized
DEBUG - 2016-11-18 12:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:23:57 --> Input Class Initialized
INFO - 2016-11-18 12:23:57 --> Language Class Initialized
INFO - 2016-11-18 12:23:57 --> Loader Class Initialized
INFO - 2016-11-18 12:23:57 --> Helper loaded: url_helper
INFO - 2016-11-18 12:23:57 --> Helper loaded: form_helper
INFO - 2016-11-18 12:23:57 --> Database Driver Class Initialized
INFO - 2016-11-18 12:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:23:57 --> Controller Class Initialized
INFO - 2016-11-18 12:23:57 --> Model Class Initialized
INFO - 2016-11-18 12:23:57 --> Model Class Initialized
INFO - 2016-11-18 12:23:57 --> Model Class Initialized
INFO - 2016-11-18 12:23:57 --> Model Class Initialized
INFO - 2016-11-18 12:23:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:23:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:23:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:23:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:23:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:23:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:23:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:23:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:23:57 --> Final output sent to browser
DEBUG - 2016-11-18 12:23:57 --> Total execution time: 0.6151
INFO - 2016-11-18 12:23:59 --> Config Class Initialized
INFO - 2016-11-18 12:23:59 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:23:59 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:23:59 --> Utf8 Class Initialized
INFO - 2016-11-18 12:23:59 --> URI Class Initialized
INFO - 2016-11-18 12:23:59 --> Router Class Initialized
INFO - 2016-11-18 12:23:59 --> Output Class Initialized
INFO - 2016-11-18 12:23:59 --> Security Class Initialized
DEBUG - 2016-11-18 12:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:23:59 --> Input Class Initialized
INFO - 2016-11-18 12:23:59 --> Language Class Initialized
INFO - 2016-11-18 12:24:00 --> Loader Class Initialized
INFO - 2016-11-18 12:24:00 --> Helper loaded: url_helper
INFO - 2016-11-18 12:24:00 --> Helper loaded: form_helper
INFO - 2016-11-18 12:24:00 --> Database Driver Class Initialized
INFO - 2016-11-18 12:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:24:00 --> Controller Class Initialized
INFO - 2016-11-18 12:24:00 --> Model Class Initialized
INFO - 2016-11-18 12:24:00 --> Form Validation Class Initialized
INFO - 2016-11-18 12:24:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:24:00 --> Final output sent to browser
DEBUG - 2016-11-18 12:24:00 --> Total execution time: 0.3536
INFO - 2016-11-18 12:24:03 --> Config Class Initialized
INFO - 2016-11-18 12:24:03 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:24:03 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:24:03 --> Utf8 Class Initialized
INFO - 2016-11-18 12:24:03 --> URI Class Initialized
DEBUG - 2016-11-18 12:24:03 --> No URI present. Default controller set.
INFO - 2016-11-18 12:24:03 --> Router Class Initialized
INFO - 2016-11-18 12:24:03 --> Output Class Initialized
INFO - 2016-11-18 12:24:03 --> Security Class Initialized
DEBUG - 2016-11-18 12:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:24:03 --> Input Class Initialized
INFO - 2016-11-18 12:24:03 --> Language Class Initialized
INFO - 2016-11-18 12:24:03 --> Loader Class Initialized
INFO - 2016-11-18 12:24:03 --> Helper loaded: url_helper
INFO - 2016-11-18 12:24:03 --> Helper loaded: form_helper
INFO - 2016-11-18 12:24:03 --> Database Driver Class Initialized
INFO - 2016-11-18 12:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:24:03 --> Controller Class Initialized
INFO - 2016-11-18 12:24:03 --> Model Class Initialized
INFO - 2016-11-18 12:24:03 --> Model Class Initialized
INFO - 2016-11-18 12:24:03 --> Model Class Initialized
INFO - 2016-11-18 12:24:03 --> Model Class Initialized
INFO - 2016-11-18 12:24:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:24:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:24:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:24:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:24:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:24:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:24:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:24:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:24:04 --> Final output sent to browser
DEBUG - 2016-11-18 12:24:04 --> Total execution time: 0.6327
INFO - 2016-11-18 12:24:06 --> Config Class Initialized
INFO - 2016-11-18 12:24:06 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:24:06 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:24:06 --> Utf8 Class Initialized
INFO - 2016-11-18 12:24:06 --> URI Class Initialized
INFO - 2016-11-18 12:24:06 --> Router Class Initialized
INFO - 2016-11-18 12:24:06 --> Output Class Initialized
INFO - 2016-11-18 12:24:06 --> Security Class Initialized
DEBUG - 2016-11-18 12:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:24:06 --> Input Class Initialized
INFO - 2016-11-18 12:24:06 --> Language Class Initialized
INFO - 2016-11-18 12:24:06 --> Loader Class Initialized
INFO - 2016-11-18 12:24:06 --> Helper loaded: url_helper
INFO - 2016-11-18 12:24:06 --> Helper loaded: form_helper
INFO - 2016-11-18 12:24:06 --> Database Driver Class Initialized
INFO - 2016-11-18 12:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:24:06 --> Controller Class Initialized
INFO - 2016-11-18 12:24:06 --> Model Class Initialized
INFO - 2016-11-18 12:24:06 --> Form Validation Class Initialized
INFO - 2016-11-18 12:24:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:24:06 --> Final output sent to browser
DEBUG - 2016-11-18 12:24:06 --> Total execution time: 0.3515
INFO - 2016-11-18 12:24:26 --> Config Class Initialized
INFO - 2016-11-18 12:24:26 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:24:26 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:24:26 --> Utf8 Class Initialized
INFO - 2016-11-18 12:24:26 --> URI Class Initialized
DEBUG - 2016-11-18 12:24:26 --> No URI present. Default controller set.
INFO - 2016-11-18 12:24:26 --> Router Class Initialized
INFO - 2016-11-18 12:24:26 --> Output Class Initialized
INFO - 2016-11-18 12:24:26 --> Security Class Initialized
DEBUG - 2016-11-18 12:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:24:26 --> Input Class Initialized
INFO - 2016-11-18 12:24:26 --> Language Class Initialized
INFO - 2016-11-18 12:24:26 --> Loader Class Initialized
INFO - 2016-11-18 12:24:26 --> Helper loaded: url_helper
INFO - 2016-11-18 12:24:26 --> Helper loaded: form_helper
INFO - 2016-11-18 12:24:26 --> Database Driver Class Initialized
INFO - 2016-11-18 12:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:24:26 --> Controller Class Initialized
INFO - 2016-11-18 12:24:26 --> Model Class Initialized
INFO - 2016-11-18 12:24:26 --> Model Class Initialized
INFO - 2016-11-18 12:24:26 --> Model Class Initialized
INFO - 2016-11-18 12:24:26 --> Model Class Initialized
INFO - 2016-11-18 12:24:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:24:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:24:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:24:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:24:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:24:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:24:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:24:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:24:26 --> Final output sent to browser
DEBUG - 2016-11-18 12:24:26 --> Total execution time: 0.6380
INFO - 2016-11-18 12:24:30 --> Config Class Initialized
INFO - 2016-11-18 12:24:30 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:24:30 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:24:30 --> Utf8 Class Initialized
INFO - 2016-11-18 12:24:30 --> URI Class Initialized
INFO - 2016-11-18 12:24:30 --> Router Class Initialized
INFO - 2016-11-18 12:24:30 --> Output Class Initialized
INFO - 2016-11-18 12:24:30 --> Security Class Initialized
DEBUG - 2016-11-18 12:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:24:30 --> Input Class Initialized
INFO - 2016-11-18 12:24:30 --> Language Class Initialized
INFO - 2016-11-18 12:24:30 --> Loader Class Initialized
INFO - 2016-11-18 12:24:30 --> Helper loaded: url_helper
INFO - 2016-11-18 12:24:30 --> Helper loaded: form_helper
INFO - 2016-11-18 12:24:30 --> Database Driver Class Initialized
INFO - 2016-11-18 12:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:24:30 --> Controller Class Initialized
INFO - 2016-11-18 12:24:30 --> Model Class Initialized
INFO - 2016-11-18 12:24:30 --> Form Validation Class Initialized
INFO - 2016-11-18 12:24:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:24:30 --> Final output sent to browser
DEBUG - 2016-11-18 12:24:30 --> Total execution time: 0.3581
INFO - 2016-11-18 12:24:43 --> Config Class Initialized
INFO - 2016-11-18 12:24:43 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:24:43 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:24:43 --> Utf8 Class Initialized
INFO - 2016-11-18 12:24:43 --> URI Class Initialized
INFO - 2016-11-18 12:24:43 --> Router Class Initialized
INFO - 2016-11-18 12:24:43 --> Output Class Initialized
INFO - 2016-11-18 12:24:43 --> Security Class Initialized
DEBUG - 2016-11-18 12:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:24:43 --> Input Class Initialized
INFO - 2016-11-18 12:24:43 --> Language Class Initialized
INFO - 2016-11-18 12:24:43 --> Loader Class Initialized
INFO - 2016-11-18 12:24:43 --> Helper loaded: url_helper
INFO - 2016-11-18 12:24:43 --> Helper loaded: form_helper
INFO - 2016-11-18 12:24:43 --> Database Driver Class Initialized
INFO - 2016-11-18 12:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:24:43 --> Controller Class Initialized
INFO - 2016-11-18 12:24:43 --> Model Class Initialized
INFO - 2016-11-18 12:24:43 --> Form Validation Class Initialized
INFO - 2016-11-18 12:24:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:24:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:24:43 --> Final output sent to browser
DEBUG - 2016-11-18 12:24:43 --> Total execution time: 0.5237
INFO - 2016-11-18 12:24:50 --> Config Class Initialized
INFO - 2016-11-18 12:24:50 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:24:50 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:24:50 --> Utf8 Class Initialized
INFO - 2016-11-18 12:24:50 --> URI Class Initialized
INFO - 2016-11-18 12:24:50 --> Router Class Initialized
INFO - 2016-11-18 12:24:50 --> Output Class Initialized
INFO - 2016-11-18 12:24:50 --> Security Class Initialized
DEBUG - 2016-11-18 12:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:24:50 --> Input Class Initialized
INFO - 2016-11-18 12:24:50 --> Language Class Initialized
INFO - 2016-11-18 12:24:50 --> Loader Class Initialized
INFO - 2016-11-18 12:24:50 --> Helper loaded: url_helper
INFO - 2016-11-18 12:24:50 --> Helper loaded: form_helper
INFO - 2016-11-18 12:24:50 --> Database Driver Class Initialized
INFO - 2016-11-18 12:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:24:50 --> Controller Class Initialized
INFO - 2016-11-18 12:24:50 --> Model Class Initialized
INFO - 2016-11-18 12:24:50 --> Model Class Initialized
INFO - 2016-11-18 12:24:50 --> Model Class Initialized
INFO - 2016-11-18 12:24:50 --> Model Class Initialized
DEBUG - 2016-11-18 12:24:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-18 12:24:50 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-18 12:24:50 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-18 12:24:50 --> Config Class Initialized
INFO - 2016-11-18 12:24:50 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:24:50 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:24:50 --> Utf8 Class Initialized
INFO - 2016-11-18 12:24:50 --> URI Class Initialized
DEBUG - 2016-11-18 12:24:50 --> No URI present. Default controller set.
INFO - 2016-11-18 12:24:50 --> Router Class Initialized
INFO - 2016-11-18 12:24:50 --> Output Class Initialized
INFO - 2016-11-18 12:24:50 --> Security Class Initialized
DEBUG - 2016-11-18 12:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:24:50 --> Input Class Initialized
INFO - 2016-11-18 12:24:50 --> Language Class Initialized
INFO - 2016-11-18 12:24:50 --> Loader Class Initialized
INFO - 2016-11-18 12:24:50 --> Helper loaded: url_helper
INFO - 2016-11-18 12:24:50 --> Helper loaded: form_helper
INFO - 2016-11-18 12:24:50 --> Database Driver Class Initialized
INFO - 2016-11-18 12:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:24:50 --> Controller Class Initialized
INFO - 2016-11-18 12:24:50 --> Model Class Initialized
INFO - 2016-11-18 12:24:50 --> Model Class Initialized
INFO - 2016-11-18 12:24:50 --> Model Class Initialized
INFO - 2016-11-18 12:24:50 --> Model Class Initialized
INFO - 2016-11-18 12:24:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:24:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 12:24:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:24:50 --> Final output sent to browser
DEBUG - 2016-11-18 12:24:50 --> Total execution time: 0.4843
INFO - 2016-11-18 12:24:58 --> Config Class Initialized
INFO - 2016-11-18 12:24:58 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:24:58 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:24:58 --> Utf8 Class Initialized
INFO - 2016-11-18 12:24:58 --> URI Class Initialized
INFO - 2016-11-18 12:24:58 --> Router Class Initialized
INFO - 2016-11-18 12:24:58 --> Output Class Initialized
INFO - 2016-11-18 12:24:58 --> Security Class Initialized
DEBUG - 2016-11-18 12:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:24:58 --> Input Class Initialized
INFO - 2016-11-18 12:24:58 --> Language Class Initialized
INFO - 2016-11-18 12:24:58 --> Loader Class Initialized
INFO - 2016-11-18 12:24:58 --> Helper loaded: url_helper
INFO - 2016-11-18 12:24:58 --> Helper loaded: form_helper
INFO - 2016-11-18 12:24:58 --> Database Driver Class Initialized
INFO - 2016-11-18 12:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:24:58 --> Controller Class Initialized
INFO - 2016-11-18 12:24:58 --> Model Class Initialized
INFO - 2016-11-18 12:24:58 --> Model Class Initialized
INFO - 2016-11-18 12:24:58 --> Model Class Initialized
INFO - 2016-11-18 12:24:58 --> Model Class Initialized
DEBUG - 2016-11-18 12:24:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-18 12:24:58 --> Model Class Initialized
INFO - 2016-11-18 12:24:58 --> Final output sent to browser
DEBUG - 2016-11-18 12:24:58 --> Total execution time: 0.4349
INFO - 2016-11-18 12:24:58 --> Config Class Initialized
INFO - 2016-11-18 12:24:58 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:24:58 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:24:58 --> Utf8 Class Initialized
INFO - 2016-11-18 12:24:58 --> URI Class Initialized
DEBUG - 2016-11-18 12:24:58 --> No URI present. Default controller set.
INFO - 2016-11-18 12:24:58 --> Router Class Initialized
INFO - 2016-11-18 12:24:58 --> Output Class Initialized
INFO - 2016-11-18 12:24:58 --> Security Class Initialized
DEBUG - 2016-11-18 12:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:24:58 --> Input Class Initialized
INFO - 2016-11-18 12:24:58 --> Language Class Initialized
INFO - 2016-11-18 12:24:58 --> Loader Class Initialized
INFO - 2016-11-18 12:24:58 --> Helper loaded: url_helper
INFO - 2016-11-18 12:24:58 --> Helper loaded: form_helper
INFO - 2016-11-18 12:24:58 --> Database Driver Class Initialized
INFO - 2016-11-18 12:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:24:58 --> Controller Class Initialized
INFO - 2016-11-18 12:24:59 --> Model Class Initialized
INFO - 2016-11-18 12:24:59 --> Model Class Initialized
INFO - 2016-11-18 12:24:59 --> Model Class Initialized
INFO - 2016-11-18 12:24:59 --> Model Class Initialized
INFO - 2016-11-18 12:24:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:24:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:24:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:24:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:24:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:24:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:24:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:24:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:24:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:24:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:24:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:24:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:24:59 --> Final output sent to browser
DEBUG - 2016-11-18 12:24:59 --> Total execution time: 0.6690
INFO - 2016-11-18 12:25:05 --> Config Class Initialized
INFO - 2016-11-18 12:25:05 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:25:05 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:25:05 --> Utf8 Class Initialized
INFO - 2016-11-18 12:25:05 --> URI Class Initialized
INFO - 2016-11-18 12:25:05 --> Router Class Initialized
INFO - 2016-11-18 12:25:05 --> Output Class Initialized
INFO - 2016-11-18 12:25:05 --> Security Class Initialized
DEBUG - 2016-11-18 12:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:25:05 --> Input Class Initialized
INFO - 2016-11-18 12:25:05 --> Language Class Initialized
INFO - 2016-11-18 12:25:05 --> Loader Class Initialized
INFO - 2016-11-18 12:25:05 --> Helper loaded: url_helper
INFO - 2016-11-18 12:25:05 --> Helper loaded: form_helper
INFO - 2016-11-18 12:25:05 --> Database Driver Class Initialized
INFO - 2016-11-18 12:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:25:05 --> Controller Class Initialized
INFO - 2016-11-18 12:25:05 --> Model Class Initialized
INFO - 2016-11-18 12:25:05 --> Form Validation Class Initialized
INFO - 2016-11-18 12:25:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:25:05 --> Final output sent to browser
DEBUG - 2016-11-18 12:25:05 --> Total execution time: 0.3629
INFO - 2016-11-18 12:25:19 --> Config Class Initialized
INFO - 2016-11-18 12:25:19 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:25:19 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:25:19 --> Utf8 Class Initialized
INFO - 2016-11-18 12:25:19 --> URI Class Initialized
INFO - 2016-11-18 12:25:19 --> Router Class Initialized
INFO - 2016-11-18 12:25:19 --> Output Class Initialized
INFO - 2016-11-18 12:25:19 --> Security Class Initialized
DEBUG - 2016-11-18 12:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:25:19 --> Input Class Initialized
INFO - 2016-11-18 12:25:19 --> Language Class Initialized
INFO - 2016-11-18 12:25:19 --> Loader Class Initialized
INFO - 2016-11-18 12:25:19 --> Helper loaded: url_helper
INFO - 2016-11-18 12:25:19 --> Helper loaded: form_helper
INFO - 2016-11-18 12:25:19 --> Database Driver Class Initialized
INFO - 2016-11-18 12:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:25:19 --> Controller Class Initialized
INFO - 2016-11-18 12:25:19 --> Model Class Initialized
INFO - 2016-11-18 12:25:19 --> Form Validation Class Initialized
INFO - 2016-11-18 12:25:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:25:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:25:19 --> Final output sent to browser
DEBUG - 2016-11-18 12:25:19 --> Total execution time: 0.5198
INFO - 2016-11-18 12:25:24 --> Config Class Initialized
INFO - 2016-11-18 12:25:24 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:25:25 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:25:25 --> Utf8 Class Initialized
INFO - 2016-11-18 12:25:25 --> URI Class Initialized
DEBUG - 2016-11-18 12:25:25 --> No URI present. Default controller set.
INFO - 2016-11-18 12:25:25 --> Router Class Initialized
INFO - 2016-11-18 12:25:25 --> Output Class Initialized
INFO - 2016-11-18 12:25:25 --> Security Class Initialized
DEBUG - 2016-11-18 12:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:25:25 --> Input Class Initialized
INFO - 2016-11-18 12:25:25 --> Language Class Initialized
INFO - 2016-11-18 12:25:25 --> Loader Class Initialized
INFO - 2016-11-18 12:25:25 --> Helper loaded: url_helper
INFO - 2016-11-18 12:25:25 --> Helper loaded: form_helper
INFO - 2016-11-18 12:25:25 --> Database Driver Class Initialized
INFO - 2016-11-18 12:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:25:25 --> Controller Class Initialized
INFO - 2016-11-18 12:25:25 --> Model Class Initialized
INFO - 2016-11-18 12:25:25 --> Model Class Initialized
INFO - 2016-11-18 12:25:25 --> Model Class Initialized
INFO - 2016-11-18 12:25:25 --> Model Class Initialized
INFO - 2016-11-18 12:25:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:25:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:25:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:25:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:25:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:25:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:25:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:25:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:25:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:25:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:25:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:25:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:25:25 --> Final output sent to browser
DEBUG - 2016-11-18 12:25:25 --> Total execution time: 0.7377
INFO - 2016-11-18 12:25:56 --> Config Class Initialized
INFO - 2016-11-18 12:25:56 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:25:56 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:25:56 --> Utf8 Class Initialized
INFO - 2016-11-18 12:25:56 --> URI Class Initialized
DEBUG - 2016-11-18 12:25:56 --> No URI present. Default controller set.
INFO - 2016-11-18 12:25:56 --> Router Class Initialized
INFO - 2016-11-18 12:25:56 --> Output Class Initialized
INFO - 2016-11-18 12:25:56 --> Security Class Initialized
DEBUG - 2016-11-18 12:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:25:56 --> Input Class Initialized
INFO - 2016-11-18 12:25:56 --> Language Class Initialized
INFO - 2016-11-18 12:25:56 --> Loader Class Initialized
INFO - 2016-11-18 12:25:56 --> Helper loaded: url_helper
INFO - 2016-11-18 12:25:56 --> Helper loaded: form_helper
INFO - 2016-11-18 12:25:56 --> Database Driver Class Initialized
INFO - 2016-11-18 12:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:25:56 --> Controller Class Initialized
INFO - 2016-11-18 12:25:56 --> Model Class Initialized
INFO - 2016-11-18 12:25:56 --> Model Class Initialized
INFO - 2016-11-18 12:25:56 --> Model Class Initialized
INFO - 2016-11-18 12:25:56 --> Model Class Initialized
INFO - 2016-11-18 12:25:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:25:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:25:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:25:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:25:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:25:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:25:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:25:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:25:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:25:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:25:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:25:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:25:56 --> Final output sent to browser
DEBUG - 2016-11-18 12:25:57 --> Total execution time: 0.7130
INFO - 2016-11-18 12:26:05 --> Config Class Initialized
INFO - 2016-11-18 12:26:05 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:26:05 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:26:05 --> Utf8 Class Initialized
INFO - 2016-11-18 12:26:05 --> URI Class Initialized
INFO - 2016-11-18 12:26:05 --> Router Class Initialized
INFO - 2016-11-18 12:26:05 --> Output Class Initialized
INFO - 2016-11-18 12:26:05 --> Security Class Initialized
DEBUG - 2016-11-18 12:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:26:05 --> Input Class Initialized
INFO - 2016-11-18 12:26:05 --> Language Class Initialized
INFO - 2016-11-18 12:26:05 --> Loader Class Initialized
INFO - 2016-11-18 12:26:05 --> Helper loaded: url_helper
INFO - 2016-11-18 12:26:05 --> Helper loaded: form_helper
INFO - 2016-11-18 12:26:05 --> Database Driver Class Initialized
INFO - 2016-11-18 12:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:26:05 --> Controller Class Initialized
INFO - 2016-11-18 12:26:05 --> Model Class Initialized
INFO - 2016-11-18 12:26:05 --> Form Validation Class Initialized
INFO - 2016-11-18 12:26:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:26:05 --> Final output sent to browser
DEBUG - 2016-11-18 12:26:05 --> Total execution time: 0.3772
INFO - 2016-11-18 12:26:16 --> Config Class Initialized
INFO - 2016-11-18 12:26:16 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:26:16 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:26:16 --> Utf8 Class Initialized
INFO - 2016-11-18 12:26:16 --> URI Class Initialized
DEBUG - 2016-11-18 12:26:16 --> No URI present. Default controller set.
INFO - 2016-11-18 12:26:16 --> Router Class Initialized
INFO - 2016-11-18 12:26:16 --> Output Class Initialized
INFO - 2016-11-18 12:26:16 --> Security Class Initialized
DEBUG - 2016-11-18 12:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:26:16 --> Input Class Initialized
INFO - 2016-11-18 12:26:16 --> Language Class Initialized
INFO - 2016-11-18 12:26:16 --> Loader Class Initialized
INFO - 2016-11-18 12:26:16 --> Helper loaded: url_helper
INFO - 2016-11-18 12:26:16 --> Helper loaded: form_helper
INFO - 2016-11-18 12:26:16 --> Database Driver Class Initialized
INFO - 2016-11-18 12:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:26:16 --> Controller Class Initialized
INFO - 2016-11-18 12:26:16 --> Model Class Initialized
INFO - 2016-11-18 12:26:16 --> Model Class Initialized
INFO - 2016-11-18 12:26:16 --> Model Class Initialized
INFO - 2016-11-18 12:26:16 --> Model Class Initialized
INFO - 2016-11-18 12:26:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:26:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:26:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:26:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:26:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:26:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:26:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:26:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:26:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:26:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:26:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:26:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:26:16 --> Final output sent to browser
DEBUG - 2016-11-18 12:26:16 --> Total execution time: 0.6832
INFO - 2016-11-18 12:26:39 --> Config Class Initialized
INFO - 2016-11-18 12:26:39 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:26:39 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:26:39 --> Utf8 Class Initialized
INFO - 2016-11-18 12:26:39 --> URI Class Initialized
DEBUG - 2016-11-18 12:26:39 --> No URI present. Default controller set.
INFO - 2016-11-18 12:26:39 --> Router Class Initialized
INFO - 2016-11-18 12:26:39 --> Output Class Initialized
INFO - 2016-11-18 12:26:39 --> Security Class Initialized
DEBUG - 2016-11-18 12:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:26:39 --> Input Class Initialized
INFO - 2016-11-18 12:26:39 --> Language Class Initialized
INFO - 2016-11-18 12:26:39 --> Loader Class Initialized
INFO - 2016-11-18 12:26:39 --> Helper loaded: url_helper
INFO - 2016-11-18 12:26:39 --> Helper loaded: form_helper
INFO - 2016-11-18 12:26:39 --> Database Driver Class Initialized
INFO - 2016-11-18 12:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:26:39 --> Controller Class Initialized
INFO - 2016-11-18 12:26:39 --> Model Class Initialized
INFO - 2016-11-18 12:26:39 --> Model Class Initialized
INFO - 2016-11-18 12:26:39 --> Model Class Initialized
INFO - 2016-11-18 12:26:39 --> Model Class Initialized
INFO - 2016-11-18 12:26:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:26:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:26:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:26:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:26:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:26:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:26:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:26:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:26:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:26:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:26:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:26:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:26:40 --> Final output sent to browser
DEBUG - 2016-11-18 12:26:40 --> Total execution time: 0.7018
INFO - 2016-11-18 12:38:12 --> Config Class Initialized
INFO - 2016-11-18 12:38:12 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:38:12 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:38:12 --> Utf8 Class Initialized
INFO - 2016-11-18 12:38:12 --> URI Class Initialized
DEBUG - 2016-11-18 12:38:12 --> No URI present. Default controller set.
INFO - 2016-11-18 12:38:12 --> Router Class Initialized
INFO - 2016-11-18 12:38:12 --> Output Class Initialized
INFO - 2016-11-18 12:38:13 --> Security Class Initialized
DEBUG - 2016-11-18 12:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:38:13 --> Input Class Initialized
INFO - 2016-11-18 12:38:13 --> Language Class Initialized
INFO - 2016-11-18 12:38:13 --> Loader Class Initialized
INFO - 2016-11-18 12:38:13 --> Helper loaded: url_helper
INFO - 2016-11-18 12:38:13 --> Helper loaded: form_helper
INFO - 2016-11-18 12:38:13 --> Database Driver Class Initialized
INFO - 2016-11-18 12:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:38:13 --> Controller Class Initialized
INFO - 2016-11-18 12:38:13 --> Model Class Initialized
INFO - 2016-11-18 12:38:13 --> Model Class Initialized
INFO - 2016-11-18 12:38:13 --> Model Class Initialized
INFO - 2016-11-18 12:38:13 --> Model Class Initialized
INFO - 2016-11-18 12:38:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:38:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:38:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:38:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:38:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:38:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:38:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:38:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:38:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:38:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:38:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:38:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:38:14 --> Final output sent to browser
DEBUG - 2016-11-18 12:38:14 --> Total execution time: 1.8922
INFO - 2016-11-18 12:38:24 --> Config Class Initialized
INFO - 2016-11-18 12:38:24 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:38:24 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:38:25 --> Utf8 Class Initialized
INFO - 2016-11-18 12:38:25 --> URI Class Initialized
INFO - 2016-11-18 12:38:25 --> Router Class Initialized
INFO - 2016-11-18 12:38:25 --> Output Class Initialized
INFO - 2016-11-18 12:38:25 --> Security Class Initialized
DEBUG - 2016-11-18 12:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:38:25 --> Input Class Initialized
INFO - 2016-11-18 12:38:25 --> Language Class Initialized
INFO - 2016-11-18 12:38:25 --> Loader Class Initialized
INFO - 2016-11-18 12:38:25 --> Helper loaded: url_helper
INFO - 2016-11-18 12:38:25 --> Helper loaded: form_helper
INFO - 2016-11-18 12:38:25 --> Database Driver Class Initialized
INFO - 2016-11-18 12:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:38:25 --> Controller Class Initialized
INFO - 2016-11-18 12:38:25 --> Model Class Initialized
INFO - 2016-11-18 12:38:25 --> Form Validation Class Initialized
INFO - 2016-11-18 12:38:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:38:25 --> Final output sent to browser
DEBUG - 2016-11-18 12:38:25 --> Total execution time: 0.4143
INFO - 2016-11-18 12:38:30 --> Config Class Initialized
INFO - 2016-11-18 12:38:30 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:38:30 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:38:30 --> Utf8 Class Initialized
INFO - 2016-11-18 12:38:30 --> URI Class Initialized
INFO - 2016-11-18 12:38:30 --> Router Class Initialized
INFO - 2016-11-18 12:38:30 --> Output Class Initialized
INFO - 2016-11-18 12:38:30 --> Security Class Initialized
DEBUG - 2016-11-18 12:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:38:30 --> Input Class Initialized
INFO - 2016-11-18 12:38:30 --> Language Class Initialized
INFO - 2016-11-18 12:38:30 --> Loader Class Initialized
INFO - 2016-11-18 12:38:30 --> Helper loaded: url_helper
INFO - 2016-11-18 12:38:30 --> Helper loaded: form_helper
INFO - 2016-11-18 12:38:30 --> Database Driver Class Initialized
INFO - 2016-11-18 12:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:38:30 --> Controller Class Initialized
INFO - 2016-11-18 12:38:30 --> Model Class Initialized
INFO - 2016-11-18 12:38:30 --> Model Class Initialized
INFO - 2016-11-18 12:38:30 --> Model Class Initialized
INFO - 2016-11-18 12:38:30 --> Model Class Initialized
DEBUG - 2016-11-18 12:38:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-18 12:38:30 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-18 12:38:30 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-18 12:38:30 --> Config Class Initialized
INFO - 2016-11-18 12:38:30 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:38:30 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:38:30 --> Utf8 Class Initialized
INFO - 2016-11-18 12:38:30 --> URI Class Initialized
DEBUG - 2016-11-18 12:38:30 --> No URI present. Default controller set.
INFO - 2016-11-18 12:38:30 --> Router Class Initialized
INFO - 2016-11-18 12:38:30 --> Output Class Initialized
INFO - 2016-11-18 12:38:31 --> Security Class Initialized
DEBUG - 2016-11-18 12:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:38:31 --> Input Class Initialized
INFO - 2016-11-18 12:38:31 --> Language Class Initialized
INFO - 2016-11-18 12:38:31 --> Loader Class Initialized
INFO - 2016-11-18 12:38:31 --> Helper loaded: url_helper
INFO - 2016-11-18 12:38:31 --> Helper loaded: form_helper
INFO - 2016-11-18 12:38:31 --> Database Driver Class Initialized
INFO - 2016-11-18 12:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:38:31 --> Controller Class Initialized
INFO - 2016-11-18 12:38:31 --> Model Class Initialized
INFO - 2016-11-18 12:38:31 --> Model Class Initialized
INFO - 2016-11-18 12:38:31 --> Model Class Initialized
INFO - 2016-11-18 12:38:31 --> Model Class Initialized
INFO - 2016-11-18 12:38:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:38:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 12:38:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:38:31 --> Final output sent to browser
DEBUG - 2016-11-18 12:38:31 --> Total execution time: 0.5414
INFO - 2016-11-18 12:38:52 --> Config Class Initialized
INFO - 2016-11-18 12:38:52 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:38:52 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:38:52 --> Utf8 Class Initialized
INFO - 2016-11-18 12:38:52 --> URI Class Initialized
INFO - 2016-11-18 12:38:52 --> Router Class Initialized
INFO - 2016-11-18 12:38:52 --> Output Class Initialized
INFO - 2016-11-18 12:38:52 --> Security Class Initialized
DEBUG - 2016-11-18 12:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:38:52 --> Input Class Initialized
INFO - 2016-11-18 12:38:52 --> Language Class Initialized
INFO - 2016-11-18 12:38:52 --> Loader Class Initialized
INFO - 2016-11-18 12:38:52 --> Helper loaded: url_helper
INFO - 2016-11-18 12:38:52 --> Helper loaded: form_helper
INFO - 2016-11-18 12:38:52 --> Database Driver Class Initialized
INFO - 2016-11-18 12:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:38:52 --> Controller Class Initialized
INFO - 2016-11-18 12:38:52 --> Model Class Initialized
INFO - 2016-11-18 12:38:52 --> Model Class Initialized
INFO - 2016-11-18 12:38:52 --> Model Class Initialized
INFO - 2016-11-18 12:38:52 --> Model Class Initialized
DEBUG - 2016-11-18 12:38:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-18 12:38:52 --> Model Class Initialized
INFO - 2016-11-18 12:38:52 --> Final output sent to browser
DEBUG - 2016-11-18 12:38:52 --> Total execution time: 0.4507
INFO - 2016-11-18 12:38:53 --> Config Class Initialized
INFO - 2016-11-18 12:38:53 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:38:53 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:38:53 --> Utf8 Class Initialized
INFO - 2016-11-18 12:38:53 --> URI Class Initialized
DEBUG - 2016-11-18 12:38:53 --> No URI present. Default controller set.
INFO - 2016-11-18 12:38:53 --> Router Class Initialized
INFO - 2016-11-18 12:38:53 --> Output Class Initialized
INFO - 2016-11-18 12:38:53 --> Security Class Initialized
DEBUG - 2016-11-18 12:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:38:53 --> Input Class Initialized
INFO - 2016-11-18 12:38:53 --> Language Class Initialized
INFO - 2016-11-18 12:38:53 --> Loader Class Initialized
INFO - 2016-11-18 12:38:53 --> Helper loaded: url_helper
INFO - 2016-11-18 12:38:53 --> Helper loaded: form_helper
INFO - 2016-11-18 12:38:53 --> Database Driver Class Initialized
INFO - 2016-11-18 12:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:38:53 --> Controller Class Initialized
INFO - 2016-11-18 12:38:53 --> Model Class Initialized
INFO - 2016-11-18 12:38:53 --> Model Class Initialized
INFO - 2016-11-18 12:38:53 --> Model Class Initialized
INFO - 2016-11-18 12:38:53 --> Model Class Initialized
INFO - 2016-11-18 12:38:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:38:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:38:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:38:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:38:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:38:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:38:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:38:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:38:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:38:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:38:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:38:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:38:53 --> Final output sent to browser
DEBUG - 2016-11-18 12:38:53 --> Total execution time: 0.6469
INFO - 2016-11-18 12:38:57 --> Config Class Initialized
INFO - 2016-11-18 12:38:57 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:38:57 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:38:57 --> Utf8 Class Initialized
INFO - 2016-11-18 12:38:57 --> URI Class Initialized
INFO - 2016-11-18 12:38:57 --> Router Class Initialized
INFO - 2016-11-18 12:38:57 --> Output Class Initialized
INFO - 2016-11-18 12:38:57 --> Security Class Initialized
DEBUG - 2016-11-18 12:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:38:57 --> Input Class Initialized
INFO - 2016-11-18 12:38:57 --> Language Class Initialized
INFO - 2016-11-18 12:38:57 --> Loader Class Initialized
INFO - 2016-11-18 12:38:57 --> Helper loaded: url_helper
INFO - 2016-11-18 12:38:57 --> Helper loaded: form_helper
INFO - 2016-11-18 12:38:57 --> Database Driver Class Initialized
INFO - 2016-11-18 12:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:38:57 --> Controller Class Initialized
INFO - 2016-11-18 12:38:57 --> Model Class Initialized
INFO - 2016-11-18 12:38:57 --> Form Validation Class Initialized
INFO - 2016-11-18 12:38:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:38:57 --> Final output sent to browser
DEBUG - 2016-11-18 12:38:57 --> Total execution time: 0.3568
INFO - 2016-11-18 12:39:07 --> Config Class Initialized
INFO - 2016-11-18 12:39:07 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:39:07 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:39:07 --> Utf8 Class Initialized
INFO - 2016-11-18 12:39:07 --> URI Class Initialized
INFO - 2016-11-18 12:39:07 --> Router Class Initialized
INFO - 2016-11-18 12:39:07 --> Output Class Initialized
INFO - 2016-11-18 12:39:07 --> Security Class Initialized
DEBUG - 2016-11-18 12:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:39:07 --> Input Class Initialized
INFO - 2016-11-18 12:39:07 --> Language Class Initialized
INFO - 2016-11-18 12:39:07 --> Loader Class Initialized
INFO - 2016-11-18 12:39:07 --> Helper loaded: url_helper
INFO - 2016-11-18 12:39:07 --> Helper loaded: form_helper
INFO - 2016-11-18 12:39:07 --> Database Driver Class Initialized
INFO - 2016-11-18 12:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:39:07 --> Controller Class Initialized
INFO - 2016-11-18 12:39:07 --> Model Class Initialized
INFO - 2016-11-18 12:39:07 --> Form Validation Class Initialized
INFO - 2016-11-18 12:39:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:39:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:39:07 --> Final output sent to browser
DEBUG - 2016-11-18 12:39:07 --> Total execution time: 0.5153
INFO - 2016-11-18 12:39:35 --> Config Class Initialized
INFO - 2016-11-18 12:39:35 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:39:35 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:39:35 --> Utf8 Class Initialized
INFO - 2016-11-18 12:39:35 --> URI Class Initialized
INFO - 2016-11-18 12:39:35 --> Router Class Initialized
INFO - 2016-11-18 12:39:35 --> Output Class Initialized
INFO - 2016-11-18 12:39:35 --> Security Class Initialized
DEBUG - 2016-11-18 12:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:39:35 --> Input Class Initialized
INFO - 2016-11-18 12:39:35 --> Language Class Initialized
INFO - 2016-11-18 12:39:35 --> Loader Class Initialized
INFO - 2016-11-18 12:39:35 --> Helper loaded: url_helper
INFO - 2016-11-18 12:39:35 --> Helper loaded: form_helper
INFO - 2016-11-18 12:39:35 --> Database Driver Class Initialized
INFO - 2016-11-18 12:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:39:35 --> Controller Class Initialized
INFO - 2016-11-18 12:39:35 --> Model Class Initialized
INFO - 2016-11-18 12:39:35 --> Form Validation Class Initialized
INFO - 2016-11-18 12:39:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:39:35 --> Final output sent to browser
DEBUG - 2016-11-18 12:39:35 --> Total execution time: 0.4251
INFO - 2016-11-18 12:39:48 --> Config Class Initialized
INFO - 2016-11-18 12:39:48 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:39:48 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:39:48 --> Utf8 Class Initialized
INFO - 2016-11-18 12:39:48 --> URI Class Initialized
INFO - 2016-11-18 12:39:48 --> Router Class Initialized
INFO - 2016-11-18 12:39:48 --> Output Class Initialized
INFO - 2016-11-18 12:39:48 --> Security Class Initialized
DEBUG - 2016-11-18 12:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:39:48 --> Input Class Initialized
INFO - 2016-11-18 12:39:48 --> Language Class Initialized
INFO - 2016-11-18 12:39:48 --> Loader Class Initialized
INFO - 2016-11-18 12:39:48 --> Helper loaded: url_helper
INFO - 2016-11-18 12:39:48 --> Helper loaded: form_helper
INFO - 2016-11-18 12:39:48 --> Database Driver Class Initialized
INFO - 2016-11-18 12:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:39:48 --> Controller Class Initialized
INFO - 2016-11-18 12:39:48 --> Model Class Initialized
INFO - 2016-11-18 12:39:48 --> Form Validation Class Initialized
INFO - 2016-11-18 12:39:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:39:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:39:49 --> Final output sent to browser
DEBUG - 2016-11-18 12:39:49 --> Total execution time: 0.5147
INFO - 2016-11-18 12:39:54 --> Config Class Initialized
INFO - 2016-11-18 12:39:54 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:39:54 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:39:54 --> Utf8 Class Initialized
INFO - 2016-11-18 12:39:54 --> URI Class Initialized
DEBUG - 2016-11-18 12:39:54 --> No URI present. Default controller set.
INFO - 2016-11-18 12:39:54 --> Router Class Initialized
INFO - 2016-11-18 12:39:54 --> Output Class Initialized
INFO - 2016-11-18 12:39:54 --> Security Class Initialized
DEBUG - 2016-11-18 12:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:39:54 --> Input Class Initialized
INFO - 2016-11-18 12:39:54 --> Language Class Initialized
INFO - 2016-11-18 12:39:54 --> Loader Class Initialized
INFO - 2016-11-18 12:39:54 --> Helper loaded: url_helper
INFO - 2016-11-18 12:39:54 --> Helper loaded: form_helper
INFO - 2016-11-18 12:39:54 --> Database Driver Class Initialized
INFO - 2016-11-18 12:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:39:54 --> Controller Class Initialized
INFO - 2016-11-18 12:39:54 --> Model Class Initialized
INFO - 2016-11-18 12:39:54 --> Model Class Initialized
INFO - 2016-11-18 12:39:54 --> Model Class Initialized
INFO - 2016-11-18 12:39:54 --> Model Class Initialized
INFO - 2016-11-18 12:39:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:39:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:39:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:39:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:39:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:39:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:39:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:39:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:39:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:39:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:39:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:39:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:39:54 --> Final output sent to browser
DEBUG - 2016-11-18 12:39:54 --> Total execution time: 0.7278
INFO - 2016-11-18 12:40:05 --> Config Class Initialized
INFO - 2016-11-18 12:40:05 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:40:05 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:40:05 --> Utf8 Class Initialized
INFO - 2016-11-18 12:40:05 --> URI Class Initialized
INFO - 2016-11-18 12:40:05 --> Router Class Initialized
INFO - 2016-11-18 12:40:05 --> Output Class Initialized
INFO - 2016-11-18 12:40:05 --> Security Class Initialized
DEBUG - 2016-11-18 12:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:40:05 --> Input Class Initialized
INFO - 2016-11-18 12:40:05 --> Language Class Initialized
INFO - 2016-11-18 12:40:05 --> Loader Class Initialized
INFO - 2016-11-18 12:40:05 --> Helper loaded: url_helper
INFO - 2016-11-18 12:40:05 --> Helper loaded: form_helper
INFO - 2016-11-18 12:40:05 --> Database Driver Class Initialized
INFO - 2016-11-18 12:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:40:06 --> Controller Class Initialized
INFO - 2016-11-18 12:40:06 --> Model Class Initialized
INFO - 2016-11-18 12:40:06 --> Model Class Initialized
INFO - 2016-11-18 12:40:06 --> Model Class Initialized
INFO - 2016-11-18 12:40:06 --> Model Class Initialized
DEBUG - 2016-11-18 12:40:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-18 12:40:06 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-18 12:40:06 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-18 12:40:06 --> Config Class Initialized
INFO - 2016-11-18 12:40:06 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:40:06 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:40:06 --> Utf8 Class Initialized
INFO - 2016-11-18 12:40:06 --> URI Class Initialized
DEBUG - 2016-11-18 12:40:06 --> No URI present. Default controller set.
INFO - 2016-11-18 12:40:06 --> Router Class Initialized
INFO - 2016-11-18 12:40:06 --> Output Class Initialized
INFO - 2016-11-18 12:40:06 --> Security Class Initialized
DEBUG - 2016-11-18 12:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:40:06 --> Input Class Initialized
INFO - 2016-11-18 12:40:06 --> Language Class Initialized
INFO - 2016-11-18 12:40:06 --> Loader Class Initialized
INFO - 2016-11-18 12:40:06 --> Helper loaded: url_helper
INFO - 2016-11-18 12:40:06 --> Helper loaded: form_helper
INFO - 2016-11-18 12:40:06 --> Database Driver Class Initialized
INFO - 2016-11-18 12:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:40:06 --> Controller Class Initialized
INFO - 2016-11-18 12:40:06 --> Model Class Initialized
INFO - 2016-11-18 12:40:06 --> Model Class Initialized
INFO - 2016-11-18 12:40:06 --> Model Class Initialized
INFO - 2016-11-18 12:40:06 --> Model Class Initialized
INFO - 2016-11-18 12:40:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:40:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 12:40:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:40:06 --> Final output sent to browser
DEBUG - 2016-11-18 12:40:06 --> Total execution time: 0.5660
INFO - 2016-11-18 12:40:14 --> Config Class Initialized
INFO - 2016-11-18 12:40:14 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:40:14 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:40:14 --> Utf8 Class Initialized
INFO - 2016-11-18 12:40:14 --> URI Class Initialized
INFO - 2016-11-18 12:40:14 --> Router Class Initialized
INFO - 2016-11-18 12:40:14 --> Output Class Initialized
INFO - 2016-11-18 12:40:14 --> Security Class Initialized
DEBUG - 2016-11-18 12:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:40:14 --> Input Class Initialized
INFO - 2016-11-18 12:40:14 --> Language Class Initialized
INFO - 2016-11-18 12:40:14 --> Loader Class Initialized
INFO - 2016-11-18 12:40:14 --> Helper loaded: url_helper
INFO - 2016-11-18 12:40:14 --> Helper loaded: form_helper
INFO - 2016-11-18 12:40:14 --> Database Driver Class Initialized
INFO - 2016-11-18 12:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:40:14 --> Controller Class Initialized
INFO - 2016-11-18 12:40:14 --> Model Class Initialized
INFO - 2016-11-18 12:40:14 --> Model Class Initialized
INFO - 2016-11-18 12:40:14 --> Model Class Initialized
INFO - 2016-11-18 12:40:14 --> Model Class Initialized
DEBUG - 2016-11-18 12:40:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-18 12:40:14 --> Model Class Initialized
INFO - 2016-11-18 12:40:14 --> Final output sent to browser
DEBUG - 2016-11-18 12:40:14 --> Total execution time: 0.4213
INFO - 2016-11-18 12:40:14 --> Config Class Initialized
INFO - 2016-11-18 12:40:14 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:40:14 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:40:14 --> Utf8 Class Initialized
INFO - 2016-11-18 12:40:14 --> URI Class Initialized
DEBUG - 2016-11-18 12:40:15 --> No URI present. Default controller set.
INFO - 2016-11-18 12:40:15 --> Router Class Initialized
INFO - 2016-11-18 12:40:15 --> Output Class Initialized
INFO - 2016-11-18 12:40:15 --> Security Class Initialized
DEBUG - 2016-11-18 12:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:40:15 --> Input Class Initialized
INFO - 2016-11-18 12:40:15 --> Language Class Initialized
INFO - 2016-11-18 12:40:15 --> Loader Class Initialized
INFO - 2016-11-18 12:40:15 --> Helper loaded: url_helper
INFO - 2016-11-18 12:40:15 --> Helper loaded: form_helper
INFO - 2016-11-18 12:40:15 --> Database Driver Class Initialized
INFO - 2016-11-18 12:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:40:15 --> Controller Class Initialized
INFO - 2016-11-18 12:40:15 --> Model Class Initialized
INFO - 2016-11-18 12:40:15 --> Model Class Initialized
INFO - 2016-11-18 12:40:15 --> Model Class Initialized
INFO - 2016-11-18 12:40:15 --> Model Class Initialized
INFO - 2016-11-18 12:40:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:40:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:40:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:40:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-18 12:40:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-18 12:40:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-18 12:40:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 12:40:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-18 12:40:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-18 12:40:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:40:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:40:15 --> Final output sent to browser
DEBUG - 2016-11-18 12:40:15 --> Total execution time: 0.7544
INFO - 2016-11-18 12:40:20 --> Config Class Initialized
INFO - 2016-11-18 12:40:20 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:40:20 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:40:20 --> Utf8 Class Initialized
INFO - 2016-11-18 12:40:20 --> URI Class Initialized
INFO - 2016-11-18 12:40:20 --> Router Class Initialized
INFO - 2016-11-18 12:40:20 --> Output Class Initialized
INFO - 2016-11-18 12:40:20 --> Security Class Initialized
DEBUG - 2016-11-18 12:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:40:20 --> Input Class Initialized
INFO - 2016-11-18 12:40:20 --> Language Class Initialized
INFO - 2016-11-18 12:40:20 --> Loader Class Initialized
INFO - 2016-11-18 12:40:20 --> Helper loaded: url_helper
INFO - 2016-11-18 12:40:20 --> Helper loaded: form_helper
INFO - 2016-11-18 12:40:20 --> Database Driver Class Initialized
INFO - 2016-11-18 12:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:40:20 --> Controller Class Initialized
INFO - 2016-11-18 12:40:20 --> Model Class Initialized
INFO - 2016-11-18 12:40:20 --> Form Validation Class Initialized
INFO - 2016-11-18 12:40:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:40:20 --> Final output sent to browser
DEBUG - 2016-11-18 12:40:20 --> Total execution time: 0.4324
INFO - 2016-11-18 12:40:52 --> Config Class Initialized
INFO - 2016-11-18 12:40:52 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:40:52 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:40:52 --> Utf8 Class Initialized
INFO - 2016-11-18 12:40:52 --> URI Class Initialized
INFO - 2016-11-18 12:40:52 --> Router Class Initialized
INFO - 2016-11-18 12:40:52 --> Output Class Initialized
INFO - 2016-11-18 12:40:52 --> Security Class Initialized
DEBUG - 2016-11-18 12:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:40:52 --> Input Class Initialized
INFO - 2016-11-18 12:40:52 --> Language Class Initialized
INFO - 2016-11-18 12:40:52 --> Loader Class Initialized
INFO - 2016-11-18 12:40:52 --> Helper loaded: url_helper
INFO - 2016-11-18 12:40:52 --> Helper loaded: form_helper
INFO - 2016-11-18 12:40:52 --> Database Driver Class Initialized
INFO - 2016-11-18 12:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:40:52 --> Controller Class Initialized
INFO - 2016-11-18 12:40:52 --> Model Class Initialized
INFO - 2016-11-18 12:40:52 --> Form Validation Class Initialized
INFO - 2016-11-18 12:40:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:40:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 12:40:53 --> Final output sent to browser
DEBUG - 2016-11-18 12:40:53 --> Total execution time: 0.5490
INFO - 2016-11-18 12:41:07 --> Config Class Initialized
INFO - 2016-11-18 12:41:07 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:41:07 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:41:07 --> Utf8 Class Initialized
INFO - 2016-11-18 12:41:07 --> URI Class Initialized
DEBUG - 2016-11-18 12:41:07 --> No URI present. Default controller set.
INFO - 2016-11-18 12:41:07 --> Router Class Initialized
INFO - 2016-11-18 12:41:07 --> Output Class Initialized
INFO - 2016-11-18 12:41:07 --> Security Class Initialized
DEBUG - 2016-11-18 12:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:41:07 --> Input Class Initialized
INFO - 2016-11-18 12:41:07 --> Language Class Initialized
INFO - 2016-11-18 12:41:07 --> Loader Class Initialized
INFO - 2016-11-18 12:41:07 --> Helper loaded: url_helper
INFO - 2016-11-18 12:41:07 --> Helper loaded: form_helper
INFO - 2016-11-18 12:41:07 --> Database Driver Class Initialized
INFO - 2016-11-18 12:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:41:07 --> Controller Class Initialized
INFO - 2016-11-18 12:41:07 --> Model Class Initialized
INFO - 2016-11-18 12:41:07 --> Model Class Initialized
INFO - 2016-11-18 12:41:07 --> Model Class Initialized
INFO - 2016-11-18 12:41:07 --> Model Class Initialized
INFO - 2016-11-18 12:41:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:41:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:41:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:41:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-18 12:41:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-18 12:41:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-18 12:41:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 12:41:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-18 12:41:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-18 12:41:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:41:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:41:07 --> Final output sent to browser
DEBUG - 2016-11-18 12:41:07 --> Total execution time: 0.7117
INFO - 2016-11-18 12:42:41 --> Config Class Initialized
INFO - 2016-11-18 12:42:41 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:42:41 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:42:41 --> Utf8 Class Initialized
INFO - 2016-11-18 12:42:41 --> URI Class Initialized
DEBUG - 2016-11-18 12:42:41 --> No URI present. Default controller set.
INFO - 2016-11-18 12:42:41 --> Router Class Initialized
INFO - 2016-11-18 12:42:41 --> Output Class Initialized
INFO - 2016-11-18 12:42:41 --> Security Class Initialized
DEBUG - 2016-11-18 12:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:42:41 --> Input Class Initialized
INFO - 2016-11-18 12:42:41 --> Language Class Initialized
INFO - 2016-11-18 12:42:41 --> Loader Class Initialized
INFO - 2016-11-18 12:42:41 --> Helper loaded: url_helper
INFO - 2016-11-18 12:42:41 --> Helper loaded: form_helper
INFO - 2016-11-18 12:42:41 --> Database Driver Class Initialized
INFO - 2016-11-18 12:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:42:41 --> Controller Class Initialized
INFO - 2016-11-18 12:42:41 --> Model Class Initialized
INFO - 2016-11-18 12:42:41 --> Model Class Initialized
INFO - 2016-11-18 12:42:41 --> Model Class Initialized
INFO - 2016-11-18 12:42:41 --> Model Class Initialized
INFO - 2016-11-18 12:42:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:42:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:42:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:42:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-18 12:42:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-18 12:42:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-18 12:42:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 12:42:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-18 12:42:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-18 12:42:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:42:42 --> Final output sent to browser
DEBUG - 2016-11-18 12:42:42 --> Total execution time: 0.7219
INFO - 2016-11-18 12:42:55 --> Config Class Initialized
INFO - 2016-11-18 12:42:55 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:42:55 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:42:55 --> Utf8 Class Initialized
INFO - 2016-11-18 12:42:55 --> URI Class Initialized
INFO - 2016-11-18 12:42:55 --> Router Class Initialized
INFO - 2016-11-18 12:42:55 --> Output Class Initialized
INFO - 2016-11-18 12:42:55 --> Security Class Initialized
DEBUG - 2016-11-18 12:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:42:55 --> Input Class Initialized
INFO - 2016-11-18 12:42:55 --> Language Class Initialized
INFO - 2016-11-18 12:42:55 --> Loader Class Initialized
INFO - 2016-11-18 12:42:55 --> Helper loaded: url_helper
INFO - 2016-11-18 12:42:55 --> Helper loaded: form_helper
INFO - 2016-11-18 12:42:55 --> Database Driver Class Initialized
INFO - 2016-11-18 12:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:42:55 --> Controller Class Initialized
INFO - 2016-11-18 12:42:55 --> Model Class Initialized
INFO - 2016-11-18 12:42:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 12:42:56 --> Final output sent to browser
DEBUG - 2016-11-18 12:42:56 --> Total execution time: 0.4822
INFO - 2016-11-18 12:42:57 --> Config Class Initialized
INFO - 2016-11-18 12:42:57 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:42:58 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:42:58 --> Utf8 Class Initialized
INFO - 2016-11-18 12:42:58 --> URI Class Initialized
DEBUG - 2016-11-18 12:42:58 --> No URI present. Default controller set.
INFO - 2016-11-18 12:42:58 --> Router Class Initialized
INFO - 2016-11-18 12:42:58 --> Output Class Initialized
INFO - 2016-11-18 12:42:58 --> Security Class Initialized
DEBUG - 2016-11-18 12:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:42:58 --> Input Class Initialized
INFO - 2016-11-18 12:42:58 --> Language Class Initialized
INFO - 2016-11-18 12:42:58 --> Loader Class Initialized
INFO - 2016-11-18 12:42:58 --> Helper loaded: url_helper
INFO - 2016-11-18 12:42:58 --> Helper loaded: form_helper
INFO - 2016-11-18 12:42:58 --> Database Driver Class Initialized
INFO - 2016-11-18 12:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:42:58 --> Controller Class Initialized
INFO - 2016-11-18 12:42:58 --> Model Class Initialized
INFO - 2016-11-18 12:42:58 --> Model Class Initialized
INFO - 2016-11-18 12:42:58 --> Model Class Initialized
INFO - 2016-11-18 12:42:58 --> Model Class Initialized
INFO - 2016-11-18 12:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-18 12:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-18 12:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-18 12:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 12:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-18 12:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-18 12:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:42:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:42:58 --> Final output sent to browser
DEBUG - 2016-11-18 12:42:58 --> Total execution time: 0.6870
INFO - 2016-11-18 12:43:42 --> Config Class Initialized
INFO - 2016-11-18 12:43:42 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:43:42 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:43:43 --> Utf8 Class Initialized
INFO - 2016-11-18 12:43:43 --> URI Class Initialized
INFO - 2016-11-18 12:43:43 --> Router Class Initialized
INFO - 2016-11-18 12:43:43 --> Output Class Initialized
INFO - 2016-11-18 12:43:43 --> Security Class Initialized
DEBUG - 2016-11-18 12:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:43:43 --> Input Class Initialized
INFO - 2016-11-18 12:43:43 --> Language Class Initialized
INFO - 2016-11-18 12:43:43 --> Loader Class Initialized
INFO - 2016-11-18 12:43:43 --> Helper loaded: url_helper
INFO - 2016-11-18 12:43:43 --> Helper loaded: form_helper
INFO - 2016-11-18 12:43:43 --> Database Driver Class Initialized
INFO - 2016-11-18 12:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:43:43 --> Controller Class Initialized
INFO - 2016-11-18 12:43:43 --> Model Class Initialized
INFO - 2016-11-18 12:43:43 --> Model Class Initialized
INFO - 2016-11-18 12:43:43 --> Model Class Initialized
INFO - 2016-11-18 12:43:43 --> Model Class Initialized
DEBUG - 2016-11-18 12:43:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-18 12:43:43 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-18 12:43:43 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-18 12:43:43 --> Config Class Initialized
INFO - 2016-11-18 12:43:43 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:43:43 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:43:43 --> Utf8 Class Initialized
INFO - 2016-11-18 12:43:43 --> URI Class Initialized
DEBUG - 2016-11-18 12:43:43 --> No URI present. Default controller set.
INFO - 2016-11-18 12:43:43 --> Router Class Initialized
INFO - 2016-11-18 12:43:43 --> Output Class Initialized
INFO - 2016-11-18 12:43:43 --> Security Class Initialized
DEBUG - 2016-11-18 12:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:43:43 --> Input Class Initialized
INFO - 2016-11-18 12:43:43 --> Language Class Initialized
INFO - 2016-11-18 12:43:43 --> Loader Class Initialized
INFO - 2016-11-18 12:43:43 --> Helper loaded: url_helper
INFO - 2016-11-18 12:43:43 --> Helper loaded: form_helper
INFO - 2016-11-18 12:43:43 --> Database Driver Class Initialized
INFO - 2016-11-18 12:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:43:43 --> Controller Class Initialized
INFO - 2016-11-18 12:43:43 --> Model Class Initialized
INFO - 2016-11-18 12:43:43 --> Model Class Initialized
INFO - 2016-11-18 12:43:43 --> Model Class Initialized
INFO - 2016-11-18 12:43:43 --> Model Class Initialized
INFO - 2016-11-18 12:43:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:43:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 12:43:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:43:43 --> Final output sent to browser
DEBUG - 2016-11-18 12:43:44 --> Total execution time: 0.5181
INFO - 2016-11-18 12:44:20 --> Config Class Initialized
INFO - 2016-11-18 12:44:20 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:44:20 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:44:20 --> Utf8 Class Initialized
INFO - 2016-11-18 12:44:20 --> URI Class Initialized
INFO - 2016-11-18 12:44:20 --> Router Class Initialized
INFO - 2016-11-18 12:44:20 --> Output Class Initialized
INFO - 2016-11-18 12:44:20 --> Security Class Initialized
DEBUG - 2016-11-18 12:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:44:20 --> Input Class Initialized
INFO - 2016-11-18 12:44:20 --> Language Class Initialized
INFO - 2016-11-18 12:44:20 --> Loader Class Initialized
INFO - 2016-11-18 12:44:20 --> Helper loaded: url_helper
INFO - 2016-11-18 12:44:20 --> Helper loaded: form_helper
INFO - 2016-11-18 12:44:20 --> Database Driver Class Initialized
INFO - 2016-11-18 12:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:44:20 --> Controller Class Initialized
INFO - 2016-11-18 12:44:20 --> Model Class Initialized
INFO - 2016-11-18 12:44:20 --> Model Class Initialized
INFO - 2016-11-18 12:44:21 --> Model Class Initialized
INFO - 2016-11-18 12:44:21 --> Model Class Initialized
DEBUG - 2016-11-18 12:44:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-18 12:44:21 --> Model Class Initialized
INFO - 2016-11-18 12:44:21 --> Final output sent to browser
DEBUG - 2016-11-18 12:44:21 --> Total execution time: 0.4550
INFO - 2016-11-18 12:44:21 --> Config Class Initialized
INFO - 2016-11-18 12:44:21 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:44:21 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:44:21 --> Utf8 Class Initialized
INFO - 2016-11-18 12:44:21 --> URI Class Initialized
DEBUG - 2016-11-18 12:44:21 --> No URI present. Default controller set.
INFO - 2016-11-18 12:44:21 --> Router Class Initialized
INFO - 2016-11-18 12:44:21 --> Output Class Initialized
INFO - 2016-11-18 12:44:21 --> Security Class Initialized
DEBUG - 2016-11-18 12:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:44:21 --> Input Class Initialized
INFO - 2016-11-18 12:44:21 --> Language Class Initialized
INFO - 2016-11-18 12:44:21 --> Loader Class Initialized
INFO - 2016-11-18 12:44:21 --> Helper loaded: url_helper
INFO - 2016-11-18 12:44:21 --> Helper loaded: form_helper
INFO - 2016-11-18 12:44:21 --> Database Driver Class Initialized
INFO - 2016-11-18 12:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:44:21 --> Controller Class Initialized
INFO - 2016-11-18 12:44:21 --> Model Class Initialized
INFO - 2016-11-18 12:44:21 --> Model Class Initialized
INFO - 2016-11-18 12:44:21 --> Model Class Initialized
INFO - 2016-11-18 12:44:21 --> Model Class Initialized
INFO - 2016-11-18 12:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:44:21 --> Final output sent to browser
DEBUG - 2016-11-18 12:44:21 --> Total execution time: 0.6792
INFO - 2016-11-18 12:44:44 --> Config Class Initialized
INFO - 2016-11-18 12:44:44 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:44:44 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:44:44 --> Utf8 Class Initialized
INFO - 2016-11-18 12:44:44 --> URI Class Initialized
DEBUG - 2016-11-18 12:44:44 --> No URI present. Default controller set.
INFO - 2016-11-18 12:44:44 --> Router Class Initialized
INFO - 2016-11-18 12:44:44 --> Output Class Initialized
INFO - 2016-11-18 12:44:44 --> Security Class Initialized
DEBUG - 2016-11-18 12:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:44:44 --> Input Class Initialized
INFO - 2016-11-18 12:44:44 --> Language Class Initialized
INFO - 2016-11-18 12:44:44 --> Loader Class Initialized
INFO - 2016-11-18 12:44:44 --> Helper loaded: url_helper
INFO - 2016-11-18 12:44:44 --> Helper loaded: form_helper
INFO - 2016-11-18 12:44:44 --> Database Driver Class Initialized
INFO - 2016-11-18 12:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:44:44 --> Controller Class Initialized
INFO - 2016-11-18 12:44:44 --> Model Class Initialized
INFO - 2016-11-18 12:44:44 --> Model Class Initialized
INFO - 2016-11-18 12:44:44 --> Model Class Initialized
INFO - 2016-11-18 12:44:44 --> Model Class Initialized
INFO - 2016-11-18 12:44:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:44:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:44:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:44:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:44:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:44:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:44:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:44:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:44:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:44:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:44:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:44:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:44:45 --> Final output sent to browser
DEBUG - 2016-11-18 12:44:45 --> Total execution time: 0.7288
INFO - 2016-11-18 12:44:54 --> Config Class Initialized
INFO - 2016-11-18 12:44:55 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:44:55 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:44:55 --> Utf8 Class Initialized
INFO - 2016-11-18 12:44:55 --> URI Class Initialized
INFO - 2016-11-18 12:44:55 --> Router Class Initialized
INFO - 2016-11-18 12:44:55 --> Output Class Initialized
INFO - 2016-11-18 12:44:55 --> Security Class Initialized
DEBUG - 2016-11-18 12:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:44:55 --> Input Class Initialized
INFO - 2016-11-18 12:44:55 --> Language Class Initialized
INFO - 2016-11-18 12:44:55 --> Loader Class Initialized
INFO - 2016-11-18 12:44:55 --> Helper loaded: url_helper
INFO - 2016-11-18 12:44:55 --> Helper loaded: form_helper
INFO - 2016-11-18 12:44:55 --> Database Driver Class Initialized
INFO - 2016-11-18 12:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:44:55 --> Controller Class Initialized
INFO - 2016-11-18 12:44:55 --> Model Class Initialized
INFO - 2016-11-18 12:44:55 --> Form Validation Class Initialized
INFO - 2016-11-18 12:44:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:44:55 --> Final output sent to browser
DEBUG - 2016-11-18 12:44:55 --> Total execution time: 0.3696
INFO - 2016-11-18 12:45:00 --> Config Class Initialized
INFO - 2016-11-18 12:45:00 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:45:00 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:45:00 --> Utf8 Class Initialized
INFO - 2016-11-18 12:45:00 --> URI Class Initialized
INFO - 2016-11-18 12:45:00 --> Router Class Initialized
INFO - 2016-11-18 12:45:00 --> Output Class Initialized
INFO - 2016-11-18 12:45:00 --> Security Class Initialized
DEBUG - 2016-11-18 12:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:45:00 --> Input Class Initialized
INFO - 2016-11-18 12:45:00 --> Language Class Initialized
INFO - 2016-11-18 12:45:00 --> Loader Class Initialized
INFO - 2016-11-18 12:45:00 --> Helper loaded: url_helper
INFO - 2016-11-18 12:45:00 --> Helper loaded: form_helper
INFO - 2016-11-18 12:45:00 --> Database Driver Class Initialized
INFO - 2016-11-18 12:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:45:00 --> Controller Class Initialized
INFO - 2016-11-18 12:45:00 --> Model Class Initialized
INFO - 2016-11-18 12:45:00 --> Form Validation Class Initialized
INFO - 2016-11-18 12:45:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 12:45:00 --> Final output sent to browser
DEBUG - 2016-11-18 12:45:00 --> Total execution time: 0.3762
INFO - 2016-11-18 12:45:40 --> Config Class Initialized
INFO - 2016-11-18 12:45:40 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:45:40 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:45:40 --> Utf8 Class Initialized
INFO - 2016-11-18 12:45:40 --> URI Class Initialized
DEBUG - 2016-11-18 12:45:40 --> No URI present. Default controller set.
INFO - 2016-11-18 12:45:40 --> Router Class Initialized
INFO - 2016-11-18 12:45:40 --> Output Class Initialized
INFO - 2016-11-18 12:45:40 --> Security Class Initialized
DEBUG - 2016-11-18 12:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:45:41 --> Input Class Initialized
INFO - 2016-11-18 12:45:41 --> Language Class Initialized
INFO - 2016-11-18 12:45:41 --> Loader Class Initialized
INFO - 2016-11-18 12:45:41 --> Helper loaded: url_helper
INFO - 2016-11-18 12:45:41 --> Helper loaded: form_helper
INFO - 2016-11-18 12:45:41 --> Database Driver Class Initialized
INFO - 2016-11-18 12:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:45:41 --> Controller Class Initialized
INFO - 2016-11-18 12:45:41 --> Model Class Initialized
INFO - 2016-11-18 12:45:41 --> Model Class Initialized
INFO - 2016-11-18 12:45:41 --> Model Class Initialized
INFO - 2016-11-18 12:45:41 --> Model Class Initialized
INFO - 2016-11-18 12:45:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:45:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:45:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:45:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:45:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:45:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:45:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:45:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:45:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:45:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:45:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:45:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:45:41 --> Final output sent to browser
DEBUG - 2016-11-18 12:45:41 --> Total execution time: 0.7311
INFO - 2016-11-18 12:46:28 --> Config Class Initialized
INFO - 2016-11-18 12:46:28 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:46:28 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:46:28 --> Utf8 Class Initialized
INFO - 2016-11-18 12:46:28 --> URI Class Initialized
DEBUG - 2016-11-18 12:46:28 --> No URI present. Default controller set.
INFO - 2016-11-18 12:46:28 --> Router Class Initialized
INFO - 2016-11-18 12:46:28 --> Output Class Initialized
INFO - 2016-11-18 12:46:28 --> Security Class Initialized
DEBUG - 2016-11-18 12:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:46:28 --> Input Class Initialized
INFO - 2016-11-18 12:46:28 --> Language Class Initialized
INFO - 2016-11-18 12:46:28 --> Loader Class Initialized
INFO - 2016-11-18 12:46:28 --> Helper loaded: url_helper
INFO - 2016-11-18 12:46:28 --> Helper loaded: form_helper
INFO - 2016-11-18 12:46:28 --> Database Driver Class Initialized
INFO - 2016-11-18 12:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:46:28 --> Controller Class Initialized
INFO - 2016-11-18 12:46:28 --> Model Class Initialized
INFO - 2016-11-18 12:46:28 --> Model Class Initialized
INFO - 2016-11-18 12:46:28 --> Model Class Initialized
INFO - 2016-11-18 12:46:28 --> Model Class Initialized
INFO - 2016-11-18 12:46:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:46:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:46:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:46:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:46:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:46:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:46:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:46:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:46:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:46:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:46:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:46:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:46:29 --> Final output sent to browser
DEBUG - 2016-11-18 12:46:29 --> Total execution time: 0.7414
INFO - 2016-11-18 12:48:48 --> Config Class Initialized
INFO - 2016-11-18 12:48:48 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:48:48 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:48:48 --> Utf8 Class Initialized
INFO - 2016-11-18 12:48:48 --> URI Class Initialized
INFO - 2016-11-18 12:48:48 --> Router Class Initialized
INFO - 2016-11-18 12:48:48 --> Output Class Initialized
INFO - 2016-11-18 12:48:48 --> Security Class Initialized
DEBUG - 2016-11-18 12:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:48:48 --> Input Class Initialized
INFO - 2016-11-18 12:48:48 --> Language Class Initialized
INFO - 2016-11-18 12:48:48 --> Loader Class Initialized
INFO - 2016-11-18 12:48:48 --> Helper loaded: url_helper
INFO - 2016-11-18 12:48:49 --> Helper loaded: form_helper
INFO - 2016-11-18 12:48:49 --> Database Driver Class Initialized
INFO - 2016-11-18 12:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:48:49 --> Controller Class Initialized
INFO - 2016-11-18 12:48:49 --> Model Class Initialized
INFO - 2016-11-18 12:48:49 --> Form Validation Class Initialized
INFO - 2016-11-18 12:48:49 --> Final output sent to browser
DEBUG - 2016-11-18 12:48:49 --> Total execution time: 0.3620
INFO - 2016-11-18 12:48:54 --> Config Class Initialized
INFO - 2016-11-18 12:48:54 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:48:54 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:48:54 --> Utf8 Class Initialized
INFO - 2016-11-18 12:48:54 --> URI Class Initialized
DEBUG - 2016-11-18 12:48:54 --> No URI present. Default controller set.
INFO - 2016-11-18 12:48:54 --> Router Class Initialized
INFO - 2016-11-18 12:48:54 --> Output Class Initialized
INFO - 2016-11-18 12:48:54 --> Security Class Initialized
DEBUG - 2016-11-18 12:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:48:55 --> Input Class Initialized
INFO - 2016-11-18 12:48:55 --> Language Class Initialized
INFO - 2016-11-18 12:48:55 --> Loader Class Initialized
INFO - 2016-11-18 12:48:55 --> Helper loaded: url_helper
INFO - 2016-11-18 12:48:55 --> Helper loaded: form_helper
INFO - 2016-11-18 12:48:55 --> Database Driver Class Initialized
INFO - 2016-11-18 12:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:48:55 --> Controller Class Initialized
INFO - 2016-11-18 12:48:55 --> Model Class Initialized
INFO - 2016-11-18 12:48:55 --> Model Class Initialized
INFO - 2016-11-18 12:48:55 --> Model Class Initialized
INFO - 2016-11-18 12:48:55 --> Model Class Initialized
INFO - 2016-11-18 12:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:48:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:48:55 --> Final output sent to browser
DEBUG - 2016-11-18 12:48:55 --> Total execution time: 0.7376
INFO - 2016-11-18 12:49:21 --> Config Class Initialized
INFO - 2016-11-18 12:49:21 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:49:21 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:49:21 --> Utf8 Class Initialized
INFO - 2016-11-18 12:49:21 --> URI Class Initialized
DEBUG - 2016-11-18 12:49:21 --> No URI present. Default controller set.
INFO - 2016-11-18 12:49:21 --> Router Class Initialized
INFO - 2016-11-18 12:49:21 --> Output Class Initialized
INFO - 2016-11-18 12:49:21 --> Security Class Initialized
DEBUG - 2016-11-18 12:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:49:21 --> Input Class Initialized
INFO - 2016-11-18 12:49:21 --> Language Class Initialized
INFO - 2016-11-18 12:49:21 --> Loader Class Initialized
INFO - 2016-11-18 12:49:21 --> Helper loaded: url_helper
INFO - 2016-11-18 12:49:21 --> Helper loaded: form_helper
INFO - 2016-11-18 12:49:21 --> Database Driver Class Initialized
INFO - 2016-11-18 12:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:49:21 --> Controller Class Initialized
INFO - 2016-11-18 12:49:21 --> Model Class Initialized
INFO - 2016-11-18 12:49:21 --> Model Class Initialized
INFO - 2016-11-18 12:49:21 --> Model Class Initialized
INFO - 2016-11-18 12:49:21 --> Model Class Initialized
INFO - 2016-11-18 12:49:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:49:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:49:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:49:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:49:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:49:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:49:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:49:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:49:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:49:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:49:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:49:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:49:22 --> Final output sent to browser
DEBUG - 2016-11-18 12:49:22 --> Total execution time: 0.7406
INFO - 2016-11-18 12:49:33 --> Config Class Initialized
INFO - 2016-11-18 12:49:33 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:49:33 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:49:33 --> Utf8 Class Initialized
INFO - 2016-11-18 12:49:33 --> URI Class Initialized
DEBUG - 2016-11-18 12:49:33 --> No URI present. Default controller set.
INFO - 2016-11-18 12:49:33 --> Router Class Initialized
INFO - 2016-11-18 12:49:33 --> Output Class Initialized
INFO - 2016-11-18 12:49:33 --> Security Class Initialized
DEBUG - 2016-11-18 12:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:49:33 --> Input Class Initialized
INFO - 2016-11-18 12:49:33 --> Language Class Initialized
INFO - 2016-11-18 12:49:33 --> Loader Class Initialized
INFO - 2016-11-18 12:49:33 --> Helper loaded: url_helper
INFO - 2016-11-18 12:49:33 --> Helper loaded: form_helper
INFO - 2016-11-18 12:49:33 --> Database Driver Class Initialized
INFO - 2016-11-18 12:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:49:33 --> Controller Class Initialized
INFO - 2016-11-18 12:49:33 --> Model Class Initialized
INFO - 2016-11-18 12:49:33 --> Model Class Initialized
INFO - 2016-11-18 12:49:33 --> Model Class Initialized
INFO - 2016-11-18 12:49:33 --> Model Class Initialized
INFO - 2016-11-18 12:49:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:49:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:49:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:49:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:49:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:49:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:49:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:49:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:49:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:49:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:49:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:49:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:49:33 --> Final output sent to browser
DEBUG - 2016-11-18 12:49:33 --> Total execution time: 0.8154
INFO - 2016-11-18 12:51:38 --> Config Class Initialized
INFO - 2016-11-18 12:51:38 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:51:38 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:51:38 --> Utf8 Class Initialized
INFO - 2016-11-18 12:51:38 --> URI Class Initialized
DEBUG - 2016-11-18 12:51:38 --> No URI present. Default controller set.
INFO - 2016-11-18 12:51:38 --> Router Class Initialized
INFO - 2016-11-18 12:51:38 --> Output Class Initialized
INFO - 2016-11-18 12:51:38 --> Security Class Initialized
DEBUG - 2016-11-18 12:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:51:38 --> Input Class Initialized
INFO - 2016-11-18 12:51:38 --> Language Class Initialized
INFO - 2016-11-18 12:51:38 --> Loader Class Initialized
INFO - 2016-11-18 12:51:38 --> Helper loaded: url_helper
INFO - 2016-11-18 12:51:38 --> Helper loaded: form_helper
INFO - 2016-11-18 12:51:38 --> Database Driver Class Initialized
INFO - 2016-11-18 12:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:51:38 --> Controller Class Initialized
INFO - 2016-11-18 12:51:38 --> Model Class Initialized
INFO - 2016-11-18 12:51:38 --> Model Class Initialized
INFO - 2016-11-18 12:51:38 --> Model Class Initialized
INFO - 2016-11-18 12:51:38 --> Model Class Initialized
INFO - 2016-11-18 12:51:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:51:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:51:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:51:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:51:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:51:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:51:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:51:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:51:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:51:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:51:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:51:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:51:39 --> Final output sent to browser
DEBUG - 2016-11-18 12:51:39 --> Total execution time: 0.7582
INFO - 2016-11-18 12:52:16 --> Config Class Initialized
INFO - 2016-11-18 12:52:16 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:52:16 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:52:16 --> Utf8 Class Initialized
INFO - 2016-11-18 12:52:16 --> URI Class Initialized
DEBUG - 2016-11-18 12:52:16 --> No URI present. Default controller set.
INFO - 2016-11-18 12:52:16 --> Router Class Initialized
INFO - 2016-11-18 12:52:16 --> Output Class Initialized
INFO - 2016-11-18 12:52:16 --> Security Class Initialized
DEBUG - 2016-11-18 12:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:52:16 --> Input Class Initialized
INFO - 2016-11-18 12:52:16 --> Language Class Initialized
INFO - 2016-11-18 12:52:16 --> Loader Class Initialized
INFO - 2016-11-18 12:52:16 --> Helper loaded: url_helper
INFO - 2016-11-18 12:52:16 --> Helper loaded: form_helper
INFO - 2016-11-18 12:52:16 --> Database Driver Class Initialized
INFO - 2016-11-18 12:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:52:16 --> Controller Class Initialized
INFO - 2016-11-18 12:52:16 --> Model Class Initialized
INFO - 2016-11-18 12:52:16 --> Model Class Initialized
INFO - 2016-11-18 12:52:16 --> Model Class Initialized
INFO - 2016-11-18 12:52:16 --> Model Class Initialized
INFO - 2016-11-18 12:52:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:52:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:52:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:52:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:52:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:52:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:52:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:52:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:52:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:52:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:52:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:52:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:52:17 --> Final output sent to browser
DEBUG - 2016-11-18 12:52:17 --> Total execution time: 0.7230
INFO - 2016-11-18 12:56:35 --> Config Class Initialized
INFO - 2016-11-18 12:56:36 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:56:36 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:56:36 --> Utf8 Class Initialized
INFO - 2016-11-18 12:56:36 --> URI Class Initialized
DEBUG - 2016-11-18 12:56:36 --> No URI present. Default controller set.
INFO - 2016-11-18 12:56:36 --> Router Class Initialized
INFO - 2016-11-18 12:56:36 --> Output Class Initialized
INFO - 2016-11-18 12:56:36 --> Security Class Initialized
DEBUG - 2016-11-18 12:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:56:36 --> Input Class Initialized
INFO - 2016-11-18 12:56:36 --> Language Class Initialized
INFO - 2016-11-18 12:56:36 --> Loader Class Initialized
INFO - 2016-11-18 12:56:36 --> Helper loaded: url_helper
INFO - 2016-11-18 12:56:36 --> Helper loaded: form_helper
INFO - 2016-11-18 12:56:36 --> Database Driver Class Initialized
INFO - 2016-11-18 12:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:56:36 --> Controller Class Initialized
INFO - 2016-11-18 12:56:36 --> Model Class Initialized
INFO - 2016-11-18 12:56:36 --> Model Class Initialized
INFO - 2016-11-18 12:56:36 --> Model Class Initialized
INFO - 2016-11-18 12:56:36 --> Model Class Initialized
INFO - 2016-11-18 12:56:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:56:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:56:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:56:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:56:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:56:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:56:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:56:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:56:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:56:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:56:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:56:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:56:36 --> Final output sent to browser
DEBUG - 2016-11-18 12:56:36 --> Total execution time: 0.8246
INFO - 2016-11-18 12:57:51 --> Config Class Initialized
INFO - 2016-11-18 12:57:51 --> Hooks Class Initialized
DEBUG - 2016-11-18 12:57:51 --> UTF-8 Support Enabled
INFO - 2016-11-18 12:57:51 --> Utf8 Class Initialized
INFO - 2016-11-18 12:57:51 --> URI Class Initialized
DEBUG - 2016-11-18 12:57:51 --> No URI present. Default controller set.
INFO - 2016-11-18 12:57:51 --> Router Class Initialized
INFO - 2016-11-18 12:57:51 --> Output Class Initialized
INFO - 2016-11-18 12:57:51 --> Security Class Initialized
DEBUG - 2016-11-18 12:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 12:57:51 --> Input Class Initialized
INFO - 2016-11-18 12:57:51 --> Language Class Initialized
INFO - 2016-11-18 12:57:51 --> Loader Class Initialized
INFO - 2016-11-18 12:57:51 --> Helper loaded: url_helper
INFO - 2016-11-18 12:57:51 --> Helper loaded: form_helper
INFO - 2016-11-18 12:57:51 --> Database Driver Class Initialized
INFO - 2016-11-18 12:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 12:57:51 --> Controller Class Initialized
INFO - 2016-11-18 12:57:51 --> Model Class Initialized
INFO - 2016-11-18 12:57:51 --> Model Class Initialized
INFO - 2016-11-18 12:57:51 --> Model Class Initialized
INFO - 2016-11-18 12:57:51 --> Model Class Initialized
INFO - 2016-11-18 12:57:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 12:57:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 12:57:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 12:57:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 12:57:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 12:57:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 12:57:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 12:57:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 12:57:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 12:57:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 12:57:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 12:57:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 12:57:52 --> Final output sent to browser
DEBUG - 2016-11-18 12:57:52 --> Total execution time: 0.8528
INFO - 2016-11-18 13:01:26 --> Config Class Initialized
INFO - 2016-11-18 13:01:26 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:01:26 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:01:26 --> Utf8 Class Initialized
INFO - 2016-11-18 13:01:26 --> URI Class Initialized
DEBUG - 2016-11-18 13:01:26 --> No URI present. Default controller set.
INFO - 2016-11-18 13:01:26 --> Router Class Initialized
INFO - 2016-11-18 13:01:26 --> Output Class Initialized
INFO - 2016-11-18 13:01:26 --> Security Class Initialized
DEBUG - 2016-11-18 13:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:01:26 --> Input Class Initialized
INFO - 2016-11-18 13:01:26 --> Language Class Initialized
INFO - 2016-11-18 13:01:26 --> Loader Class Initialized
INFO - 2016-11-18 13:01:26 --> Helper loaded: url_helper
INFO - 2016-11-18 13:01:26 --> Helper loaded: form_helper
INFO - 2016-11-18 13:01:26 --> Database Driver Class Initialized
INFO - 2016-11-18 13:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:01:26 --> Controller Class Initialized
INFO - 2016-11-18 13:01:26 --> Model Class Initialized
INFO - 2016-11-18 13:01:26 --> Model Class Initialized
INFO - 2016-11-18 13:01:26 --> Model Class Initialized
INFO - 2016-11-18 13:01:26 --> Model Class Initialized
INFO - 2016-11-18 13:01:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 13:01:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 13:01:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 13:01:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 13:01:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 13:01:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 13:01:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:01:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 13:01:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 13:01:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 13:01:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 13:01:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 13:01:27 --> Final output sent to browser
DEBUG - 2016-11-18 13:01:27 --> Total execution time: 0.6956
INFO - 2016-11-18 13:06:14 --> Config Class Initialized
INFO - 2016-11-18 13:06:14 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:06:14 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:06:14 --> Utf8 Class Initialized
INFO - 2016-11-18 13:06:14 --> URI Class Initialized
DEBUG - 2016-11-18 13:06:14 --> No URI present. Default controller set.
INFO - 2016-11-18 13:06:14 --> Router Class Initialized
INFO - 2016-11-18 13:06:14 --> Output Class Initialized
INFO - 2016-11-18 13:06:14 --> Security Class Initialized
DEBUG - 2016-11-18 13:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:06:14 --> Input Class Initialized
INFO - 2016-11-18 13:06:14 --> Language Class Initialized
INFO - 2016-11-18 13:06:14 --> Loader Class Initialized
INFO - 2016-11-18 13:06:14 --> Helper loaded: url_helper
INFO - 2016-11-18 13:06:14 --> Helper loaded: form_helper
INFO - 2016-11-18 13:06:14 --> Database Driver Class Initialized
INFO - 2016-11-18 13:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:06:14 --> Controller Class Initialized
INFO - 2016-11-18 13:06:14 --> Model Class Initialized
INFO - 2016-11-18 13:06:14 --> Model Class Initialized
INFO - 2016-11-18 13:06:14 --> Model Class Initialized
INFO - 2016-11-18 13:06:15 --> Model Class Initialized
INFO - 2016-11-18 13:06:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 13:06:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 13:06:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 13:06:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 13:06:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 13:06:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 13:06:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:06:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 13:06:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 13:06:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 13:06:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 13:06:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 13:06:15 --> Final output sent to browser
DEBUG - 2016-11-18 13:06:15 --> Total execution time: 0.7092
INFO - 2016-11-18 13:06:56 --> Config Class Initialized
INFO - 2016-11-18 13:06:56 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:06:56 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:06:56 --> Utf8 Class Initialized
INFO - 2016-11-18 13:06:56 --> URI Class Initialized
DEBUG - 2016-11-18 13:06:56 --> No URI present. Default controller set.
INFO - 2016-11-18 13:06:56 --> Router Class Initialized
INFO - 2016-11-18 13:06:56 --> Output Class Initialized
INFO - 2016-11-18 13:06:56 --> Security Class Initialized
DEBUG - 2016-11-18 13:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:06:56 --> Input Class Initialized
INFO - 2016-11-18 13:06:57 --> Language Class Initialized
INFO - 2016-11-18 13:06:57 --> Loader Class Initialized
INFO - 2016-11-18 13:06:57 --> Helper loaded: url_helper
INFO - 2016-11-18 13:06:57 --> Helper loaded: form_helper
INFO - 2016-11-18 13:06:57 --> Database Driver Class Initialized
INFO - 2016-11-18 13:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:06:57 --> Controller Class Initialized
INFO - 2016-11-18 13:06:57 --> Model Class Initialized
INFO - 2016-11-18 13:06:57 --> Model Class Initialized
INFO - 2016-11-18 13:06:57 --> Model Class Initialized
INFO - 2016-11-18 13:06:57 --> Model Class Initialized
INFO - 2016-11-18 13:06:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 13:06:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 13:06:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 13:06:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 13:06:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 13:06:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 13:06:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:06:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 13:06:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 13:06:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 13:06:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 13:06:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 13:06:57 --> Final output sent to browser
DEBUG - 2016-11-18 13:06:57 --> Total execution time: 0.6975
INFO - 2016-11-18 13:07:06 --> Config Class Initialized
INFO - 2016-11-18 13:07:06 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:07:06 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:07:06 --> Utf8 Class Initialized
INFO - 2016-11-18 13:07:06 --> URI Class Initialized
DEBUG - 2016-11-18 13:07:06 --> No URI present. Default controller set.
INFO - 2016-11-18 13:07:06 --> Router Class Initialized
INFO - 2016-11-18 13:07:06 --> Output Class Initialized
INFO - 2016-11-18 13:07:06 --> Security Class Initialized
DEBUG - 2016-11-18 13:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:07:06 --> Input Class Initialized
INFO - 2016-11-18 13:07:06 --> Language Class Initialized
INFO - 2016-11-18 13:07:06 --> Loader Class Initialized
INFO - 2016-11-18 13:07:06 --> Helper loaded: url_helper
INFO - 2016-11-18 13:07:06 --> Helper loaded: form_helper
INFO - 2016-11-18 13:07:06 --> Database Driver Class Initialized
INFO - 2016-11-18 13:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:07:06 --> Controller Class Initialized
INFO - 2016-11-18 13:07:06 --> Model Class Initialized
INFO - 2016-11-18 13:07:06 --> Model Class Initialized
INFO - 2016-11-18 13:07:06 --> Model Class Initialized
INFO - 2016-11-18 13:07:06 --> Model Class Initialized
INFO - 2016-11-18 13:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 13:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 13:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 13:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 13:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 13:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 13:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 13:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 13:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 13:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 13:07:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 13:07:06 --> Final output sent to browser
DEBUG - 2016-11-18 13:07:06 --> Total execution time: 0.7178
INFO - 2016-11-18 13:08:15 --> Config Class Initialized
INFO - 2016-11-18 13:08:15 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:08:15 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:08:15 --> Utf8 Class Initialized
INFO - 2016-11-18 13:08:15 --> URI Class Initialized
DEBUG - 2016-11-18 13:08:15 --> No URI present. Default controller set.
INFO - 2016-11-18 13:08:15 --> Router Class Initialized
INFO - 2016-11-18 13:08:15 --> Output Class Initialized
INFO - 2016-11-18 13:08:15 --> Security Class Initialized
DEBUG - 2016-11-18 13:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:08:15 --> Input Class Initialized
INFO - 2016-11-18 13:08:15 --> Language Class Initialized
INFO - 2016-11-18 13:08:15 --> Loader Class Initialized
INFO - 2016-11-18 13:08:15 --> Helper loaded: url_helper
INFO - 2016-11-18 13:08:15 --> Helper loaded: form_helper
INFO - 2016-11-18 13:08:15 --> Database Driver Class Initialized
INFO - 2016-11-18 13:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:08:15 --> Controller Class Initialized
INFO - 2016-11-18 13:08:15 --> Model Class Initialized
INFO - 2016-11-18 13:08:16 --> Model Class Initialized
INFO - 2016-11-18 13:08:16 --> Model Class Initialized
INFO - 2016-11-18 13:08:16 --> Model Class Initialized
INFO - 2016-11-18 13:08:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 13:08:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 13:08:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 13:08:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 13:08:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 13:08:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 13:08:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:08:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 13:08:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 13:08:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 13:08:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 13:08:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 13:08:16 --> Final output sent to browser
DEBUG - 2016-11-18 13:08:16 --> Total execution time: 0.8788
INFO - 2016-11-18 13:08:24 --> Config Class Initialized
INFO - 2016-11-18 13:08:24 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:08:24 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:08:24 --> Utf8 Class Initialized
INFO - 2016-11-18 13:08:24 --> URI Class Initialized
DEBUG - 2016-11-18 13:08:24 --> No URI present. Default controller set.
INFO - 2016-11-18 13:08:24 --> Router Class Initialized
INFO - 2016-11-18 13:08:24 --> Output Class Initialized
INFO - 2016-11-18 13:08:24 --> Security Class Initialized
DEBUG - 2016-11-18 13:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:08:24 --> Input Class Initialized
INFO - 2016-11-18 13:08:24 --> Language Class Initialized
INFO - 2016-11-18 13:08:24 --> Loader Class Initialized
INFO - 2016-11-18 13:08:24 --> Helper loaded: url_helper
INFO - 2016-11-18 13:08:24 --> Helper loaded: form_helper
INFO - 2016-11-18 13:08:24 --> Database Driver Class Initialized
INFO - 2016-11-18 13:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:08:24 --> Controller Class Initialized
INFO - 2016-11-18 13:08:24 --> Model Class Initialized
INFO - 2016-11-18 13:08:24 --> Model Class Initialized
INFO - 2016-11-18 13:08:24 --> Model Class Initialized
INFO - 2016-11-18 13:08:24 --> Model Class Initialized
INFO - 2016-11-18 13:08:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 13:08:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 13:08:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 13:08:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 13:08:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 13:08:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 13:08:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:08:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 13:08:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 13:08:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 13:08:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 13:08:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 13:08:24 --> Final output sent to browser
DEBUG - 2016-11-18 13:08:24 --> Total execution time: 0.7309
INFO - 2016-11-18 13:08:48 --> Config Class Initialized
INFO - 2016-11-18 13:08:48 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:08:48 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:08:48 --> Utf8 Class Initialized
INFO - 2016-11-18 13:08:48 --> URI Class Initialized
DEBUG - 2016-11-18 13:08:48 --> No URI present. Default controller set.
INFO - 2016-11-18 13:08:48 --> Router Class Initialized
INFO - 2016-11-18 13:08:48 --> Output Class Initialized
INFO - 2016-11-18 13:08:48 --> Security Class Initialized
DEBUG - 2016-11-18 13:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:08:48 --> Input Class Initialized
INFO - 2016-11-18 13:08:48 --> Language Class Initialized
INFO - 2016-11-18 13:08:48 --> Loader Class Initialized
INFO - 2016-11-18 13:08:48 --> Helper loaded: url_helper
INFO - 2016-11-18 13:08:48 --> Helper loaded: form_helper
INFO - 2016-11-18 13:08:48 --> Database Driver Class Initialized
INFO - 2016-11-18 13:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:08:48 --> Controller Class Initialized
INFO - 2016-11-18 13:08:48 --> Model Class Initialized
INFO - 2016-11-18 13:08:48 --> Model Class Initialized
INFO - 2016-11-18 13:08:48 --> Model Class Initialized
INFO - 2016-11-18 13:08:48 --> Model Class Initialized
INFO - 2016-11-18 13:08:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 13:08:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 13:08:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 13:08:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 13:08:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 13:08:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 13:08:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:08:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 13:08:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 13:08:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 13:08:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 13:08:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 13:08:48 --> Final output sent to browser
DEBUG - 2016-11-18 13:08:48 --> Total execution time: 0.7202
INFO - 2016-11-18 13:09:45 --> Config Class Initialized
INFO - 2016-11-18 13:09:45 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:09:45 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:09:45 --> Utf8 Class Initialized
INFO - 2016-11-18 13:09:45 --> URI Class Initialized
DEBUG - 2016-11-18 13:09:45 --> No URI present. Default controller set.
INFO - 2016-11-18 13:09:45 --> Router Class Initialized
INFO - 2016-11-18 13:09:45 --> Output Class Initialized
INFO - 2016-11-18 13:09:45 --> Security Class Initialized
DEBUG - 2016-11-18 13:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:09:45 --> Input Class Initialized
INFO - 2016-11-18 13:09:45 --> Language Class Initialized
INFO - 2016-11-18 13:09:45 --> Loader Class Initialized
INFO - 2016-11-18 13:09:45 --> Helper loaded: url_helper
INFO - 2016-11-18 13:09:45 --> Helper loaded: form_helper
INFO - 2016-11-18 13:09:45 --> Database Driver Class Initialized
INFO - 2016-11-18 13:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:09:45 --> Controller Class Initialized
INFO - 2016-11-18 13:09:45 --> Model Class Initialized
INFO - 2016-11-18 13:09:45 --> Model Class Initialized
INFO - 2016-11-18 13:09:45 --> Model Class Initialized
INFO - 2016-11-18 13:09:45 --> Model Class Initialized
INFO - 2016-11-18 13:09:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 13:09:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 13:09:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 13:09:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 13:09:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 13:09:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 13:09:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:09:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 13:09:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 13:09:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 13:09:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 13:09:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 13:09:46 --> Final output sent to browser
DEBUG - 2016-11-18 13:09:46 --> Total execution time: 0.6987
INFO - 2016-11-18 13:11:03 --> Config Class Initialized
INFO - 2016-11-18 13:11:03 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:11:03 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:11:03 --> Utf8 Class Initialized
INFO - 2016-11-18 13:11:03 --> URI Class Initialized
DEBUG - 2016-11-18 13:11:03 --> No URI present. Default controller set.
INFO - 2016-11-18 13:11:03 --> Router Class Initialized
INFO - 2016-11-18 13:11:03 --> Output Class Initialized
INFO - 2016-11-18 13:11:03 --> Security Class Initialized
DEBUG - 2016-11-18 13:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:11:03 --> Input Class Initialized
INFO - 2016-11-18 13:11:03 --> Language Class Initialized
INFO - 2016-11-18 13:11:03 --> Loader Class Initialized
INFO - 2016-11-18 13:11:03 --> Helper loaded: url_helper
INFO - 2016-11-18 13:11:03 --> Helper loaded: form_helper
INFO - 2016-11-18 13:11:03 --> Database Driver Class Initialized
INFO - 2016-11-18 13:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:11:03 --> Controller Class Initialized
INFO - 2016-11-18 13:11:03 --> Model Class Initialized
INFO - 2016-11-18 13:11:03 --> Model Class Initialized
INFO - 2016-11-18 13:11:03 --> Model Class Initialized
INFO - 2016-11-18 13:11:03 --> Model Class Initialized
INFO - 2016-11-18 13:11:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 13:11:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 13:11:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 13:11:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 13:11:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 13:11:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 13:11:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:11:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 13:11:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 13:11:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 13:11:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 13:11:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 13:11:03 --> Final output sent to browser
DEBUG - 2016-11-18 13:11:03 --> Total execution time: 0.7785
INFO - 2016-11-18 13:11:19 --> Config Class Initialized
INFO - 2016-11-18 13:11:19 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:11:19 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:11:19 --> Utf8 Class Initialized
INFO - 2016-11-18 13:11:19 --> URI Class Initialized
INFO - 2016-11-18 13:11:19 --> Router Class Initialized
INFO - 2016-11-18 13:11:19 --> Output Class Initialized
INFO - 2016-11-18 13:11:19 --> Security Class Initialized
DEBUG - 2016-11-18 13:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:11:19 --> Input Class Initialized
INFO - 2016-11-18 13:11:19 --> Language Class Initialized
INFO - 2016-11-18 13:11:19 --> Loader Class Initialized
INFO - 2016-11-18 13:11:19 --> Helper loaded: url_helper
INFO - 2016-11-18 13:11:19 --> Helper loaded: form_helper
INFO - 2016-11-18 13:11:19 --> Database Driver Class Initialized
INFO - 2016-11-18 13:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:11:20 --> Controller Class Initialized
INFO - 2016-11-18 13:11:20 --> Model Class Initialized
INFO - 2016-11-18 13:11:20 --> Form Validation Class Initialized
INFO - 2016-11-18 13:11:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 13:11:20 --> Final output sent to browser
DEBUG - 2016-11-18 13:11:20 --> Total execution time: 0.4204
INFO - 2016-11-18 13:11:33 --> Config Class Initialized
INFO - 2016-11-18 13:11:33 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:11:33 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:11:33 --> Utf8 Class Initialized
INFO - 2016-11-18 13:11:33 --> URI Class Initialized
INFO - 2016-11-18 13:11:34 --> Router Class Initialized
INFO - 2016-11-18 13:11:34 --> Output Class Initialized
INFO - 2016-11-18 13:11:34 --> Security Class Initialized
DEBUG - 2016-11-18 13:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:11:34 --> Input Class Initialized
INFO - 2016-11-18 13:11:34 --> Language Class Initialized
INFO - 2016-11-18 13:11:34 --> Loader Class Initialized
INFO - 2016-11-18 13:11:34 --> Helper loaded: url_helper
INFO - 2016-11-18 13:11:34 --> Helper loaded: form_helper
INFO - 2016-11-18 13:11:34 --> Database Driver Class Initialized
INFO - 2016-11-18 13:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:11:34 --> Controller Class Initialized
INFO - 2016-11-18 13:11:34 --> Model Class Initialized
INFO - 2016-11-18 13:11:34 --> Form Validation Class Initialized
INFO - 2016-11-18 13:11:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 13:11:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 13:11:34 --> Final output sent to browser
DEBUG - 2016-11-18 13:11:34 --> Total execution time: 0.5044
INFO - 2016-11-18 13:12:03 --> Config Class Initialized
INFO - 2016-11-18 13:12:03 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:12:04 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:12:04 --> Utf8 Class Initialized
INFO - 2016-11-18 13:12:04 --> URI Class Initialized
DEBUG - 2016-11-18 13:12:04 --> No URI present. Default controller set.
INFO - 2016-11-18 13:12:04 --> Router Class Initialized
INFO - 2016-11-18 13:12:04 --> Output Class Initialized
INFO - 2016-11-18 13:12:04 --> Security Class Initialized
DEBUG - 2016-11-18 13:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:12:04 --> Input Class Initialized
INFO - 2016-11-18 13:12:04 --> Language Class Initialized
INFO - 2016-11-18 13:12:04 --> Loader Class Initialized
INFO - 2016-11-18 13:12:04 --> Helper loaded: url_helper
INFO - 2016-11-18 13:12:04 --> Helper loaded: form_helper
INFO - 2016-11-18 13:12:04 --> Database Driver Class Initialized
INFO - 2016-11-18 13:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:12:04 --> Controller Class Initialized
INFO - 2016-11-18 13:12:04 --> Model Class Initialized
INFO - 2016-11-18 13:12:04 --> Model Class Initialized
INFO - 2016-11-18 13:12:04 --> Model Class Initialized
INFO - 2016-11-18 13:12:04 --> Model Class Initialized
INFO - 2016-11-18 13:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 13:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 13:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 13:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 13:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 13:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 13:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 13:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 13:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 13:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 13:12:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 13:12:04 --> Final output sent to browser
DEBUG - 2016-11-18 13:12:04 --> Total execution time: 0.7424
INFO - 2016-11-18 13:12:28 --> Config Class Initialized
INFO - 2016-11-18 13:12:28 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:12:28 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:12:28 --> Utf8 Class Initialized
INFO - 2016-11-18 13:12:28 --> URI Class Initialized
DEBUG - 2016-11-18 13:12:28 --> No URI present. Default controller set.
INFO - 2016-11-18 13:12:28 --> Router Class Initialized
INFO - 2016-11-18 13:12:28 --> Output Class Initialized
INFO - 2016-11-18 13:12:28 --> Security Class Initialized
DEBUG - 2016-11-18 13:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:12:28 --> Input Class Initialized
INFO - 2016-11-18 13:12:28 --> Language Class Initialized
INFO - 2016-11-18 13:12:28 --> Loader Class Initialized
INFO - 2016-11-18 13:12:28 --> Helper loaded: url_helper
INFO - 2016-11-18 13:12:28 --> Helper loaded: form_helper
INFO - 2016-11-18 13:12:28 --> Database Driver Class Initialized
INFO - 2016-11-18 13:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:12:28 --> Controller Class Initialized
INFO - 2016-11-18 13:12:28 --> Model Class Initialized
INFO - 2016-11-18 13:12:28 --> Model Class Initialized
INFO - 2016-11-18 13:12:28 --> Model Class Initialized
INFO - 2016-11-18 13:12:28 --> Model Class Initialized
INFO - 2016-11-18 13:12:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 13:12:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 13:12:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 13:12:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 13:12:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 13:12:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 13:12:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:12:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 13:12:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 13:12:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 13:12:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 13:12:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 13:12:28 --> Final output sent to browser
DEBUG - 2016-11-18 13:12:28 --> Total execution time: 0.7003
INFO - 2016-11-18 13:12:46 --> Config Class Initialized
INFO - 2016-11-18 13:12:46 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:12:46 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:12:46 --> Utf8 Class Initialized
INFO - 2016-11-18 13:12:46 --> URI Class Initialized
DEBUG - 2016-11-18 13:12:46 --> No URI present. Default controller set.
INFO - 2016-11-18 13:12:46 --> Router Class Initialized
INFO - 2016-11-18 13:12:46 --> Output Class Initialized
INFO - 2016-11-18 13:12:46 --> Security Class Initialized
DEBUG - 2016-11-18 13:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:12:46 --> Input Class Initialized
INFO - 2016-11-18 13:12:46 --> Language Class Initialized
INFO - 2016-11-18 13:12:46 --> Loader Class Initialized
INFO - 2016-11-18 13:12:46 --> Helper loaded: url_helper
INFO - 2016-11-18 13:12:46 --> Helper loaded: form_helper
INFO - 2016-11-18 13:12:46 --> Database Driver Class Initialized
INFO - 2016-11-18 13:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:12:46 --> Controller Class Initialized
INFO - 2016-11-18 13:12:47 --> Model Class Initialized
INFO - 2016-11-18 13:12:47 --> Model Class Initialized
INFO - 2016-11-18 13:12:47 --> Model Class Initialized
INFO - 2016-11-18 13:12:47 --> Model Class Initialized
INFO - 2016-11-18 13:12:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 13:12:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 13:12:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 13:12:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 13:12:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 13:12:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 13:12:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:12:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 13:12:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 13:12:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 13:12:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 13:12:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 13:12:47 --> Final output sent to browser
DEBUG - 2016-11-18 13:12:47 --> Total execution time: 0.7164
INFO - 2016-11-18 13:13:08 --> Config Class Initialized
INFO - 2016-11-18 13:13:08 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:13:08 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:13:08 --> Utf8 Class Initialized
INFO - 2016-11-18 13:13:08 --> URI Class Initialized
DEBUG - 2016-11-18 13:13:08 --> No URI present. Default controller set.
INFO - 2016-11-18 13:13:08 --> Router Class Initialized
INFO - 2016-11-18 13:13:08 --> Output Class Initialized
INFO - 2016-11-18 13:13:08 --> Security Class Initialized
DEBUG - 2016-11-18 13:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:13:09 --> Input Class Initialized
INFO - 2016-11-18 13:13:09 --> Language Class Initialized
INFO - 2016-11-18 13:13:09 --> Loader Class Initialized
INFO - 2016-11-18 13:13:09 --> Helper loaded: url_helper
INFO - 2016-11-18 13:13:09 --> Helper loaded: form_helper
INFO - 2016-11-18 13:13:09 --> Database Driver Class Initialized
INFO - 2016-11-18 13:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:13:09 --> Controller Class Initialized
INFO - 2016-11-18 13:13:09 --> Model Class Initialized
INFO - 2016-11-18 13:13:09 --> Model Class Initialized
INFO - 2016-11-18 13:13:09 --> Model Class Initialized
INFO - 2016-11-18 13:13:09 --> Model Class Initialized
INFO - 2016-11-18 13:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 13:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 13:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 13:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 13:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 13:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 13:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 13:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 13:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 13:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 13:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 13:13:09 --> Final output sent to browser
DEBUG - 2016-11-18 13:13:09 --> Total execution time: 0.7891
INFO - 2016-11-18 13:13:17 --> Config Class Initialized
INFO - 2016-11-18 13:13:17 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:13:17 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:13:17 --> Utf8 Class Initialized
INFO - 2016-11-18 13:13:17 --> URI Class Initialized
DEBUG - 2016-11-18 13:13:17 --> No URI present. Default controller set.
INFO - 2016-11-18 13:13:17 --> Router Class Initialized
INFO - 2016-11-18 13:13:17 --> Output Class Initialized
INFO - 2016-11-18 13:13:17 --> Security Class Initialized
DEBUG - 2016-11-18 13:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:13:17 --> Input Class Initialized
INFO - 2016-11-18 13:13:17 --> Language Class Initialized
INFO - 2016-11-18 13:13:17 --> Loader Class Initialized
INFO - 2016-11-18 13:13:17 --> Helper loaded: url_helper
INFO - 2016-11-18 13:13:17 --> Helper loaded: form_helper
INFO - 2016-11-18 13:13:17 --> Database Driver Class Initialized
INFO - 2016-11-18 13:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:13:17 --> Controller Class Initialized
INFO - 2016-11-18 13:13:17 --> Model Class Initialized
INFO - 2016-11-18 13:13:17 --> Model Class Initialized
INFO - 2016-11-18 13:13:17 --> Model Class Initialized
INFO - 2016-11-18 13:13:17 --> Model Class Initialized
INFO - 2016-11-18 13:13:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 13:13:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 13:13:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 13:13:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 13:13:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 13:13:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 13:13:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:13:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 13:13:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 13:13:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 13:13:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 13:13:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 13:13:18 --> Final output sent to browser
DEBUG - 2016-11-18 13:13:18 --> Total execution time: 0.7503
INFO - 2016-11-18 13:14:16 --> Config Class Initialized
INFO - 2016-11-18 13:14:16 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:14:16 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:14:16 --> Utf8 Class Initialized
INFO - 2016-11-18 13:14:16 --> URI Class Initialized
DEBUG - 2016-11-18 13:14:16 --> No URI present. Default controller set.
INFO - 2016-11-18 13:14:16 --> Router Class Initialized
INFO - 2016-11-18 13:14:16 --> Output Class Initialized
INFO - 2016-11-18 13:14:16 --> Security Class Initialized
DEBUG - 2016-11-18 13:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:14:16 --> Input Class Initialized
INFO - 2016-11-18 13:14:16 --> Language Class Initialized
INFO - 2016-11-18 13:14:16 --> Loader Class Initialized
INFO - 2016-11-18 13:14:16 --> Helper loaded: url_helper
INFO - 2016-11-18 13:14:16 --> Helper loaded: form_helper
INFO - 2016-11-18 13:14:16 --> Database Driver Class Initialized
INFO - 2016-11-18 13:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:14:16 --> Controller Class Initialized
INFO - 2016-11-18 13:14:16 --> Model Class Initialized
INFO - 2016-11-18 13:14:16 --> Model Class Initialized
INFO - 2016-11-18 13:14:16 --> Model Class Initialized
INFO - 2016-11-18 13:14:16 --> Model Class Initialized
INFO - 2016-11-18 13:14:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 13:14:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 13:14:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 13:14:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 13:14:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 13:14:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 13:14:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:14:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 13:14:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 13:14:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 13:14:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 13:14:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 13:14:17 --> Final output sent to browser
DEBUG - 2016-11-18 13:14:17 --> Total execution time: 0.7567
INFO - 2016-11-18 13:14:32 --> Config Class Initialized
INFO - 2016-11-18 13:14:32 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:14:32 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:14:33 --> Utf8 Class Initialized
INFO - 2016-11-18 13:14:33 --> URI Class Initialized
INFO - 2016-11-18 13:14:33 --> Router Class Initialized
INFO - 2016-11-18 13:14:33 --> Output Class Initialized
INFO - 2016-11-18 13:14:33 --> Security Class Initialized
DEBUG - 2016-11-18 13:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:14:33 --> Input Class Initialized
INFO - 2016-11-18 13:14:33 --> Language Class Initialized
INFO - 2016-11-18 13:14:33 --> Loader Class Initialized
INFO - 2016-11-18 13:14:33 --> Helper loaded: url_helper
INFO - 2016-11-18 13:14:33 --> Helper loaded: form_helper
INFO - 2016-11-18 13:14:33 --> Database Driver Class Initialized
INFO - 2016-11-18 13:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:14:33 --> Controller Class Initialized
INFO - 2016-11-18 13:14:33 --> Model Class Initialized
INFO - 2016-11-18 13:14:33 --> Form Validation Class Initialized
ERROR - 2016-11-18 13:14:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:34 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:34 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:34 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:34 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:34 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:34 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:34 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:34 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:14:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-18 13:14:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:14:34 --> Final output sent to browser
DEBUG - 2016-11-18 13:14:34 --> Total execution time: 1.4309
INFO - 2016-11-18 13:14:45 --> Config Class Initialized
INFO - 2016-11-18 13:14:45 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:14:45 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:14:45 --> Utf8 Class Initialized
INFO - 2016-11-18 13:14:45 --> URI Class Initialized
DEBUG - 2016-11-18 13:14:45 --> No URI present. Default controller set.
INFO - 2016-11-18 13:14:45 --> Router Class Initialized
INFO - 2016-11-18 13:14:45 --> Output Class Initialized
INFO - 2016-11-18 13:14:45 --> Security Class Initialized
DEBUG - 2016-11-18 13:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:14:45 --> Input Class Initialized
INFO - 2016-11-18 13:14:45 --> Language Class Initialized
INFO - 2016-11-18 13:14:45 --> Loader Class Initialized
INFO - 2016-11-18 13:14:45 --> Helper loaded: url_helper
INFO - 2016-11-18 13:14:45 --> Helper loaded: form_helper
INFO - 2016-11-18 13:14:46 --> Database Driver Class Initialized
INFO - 2016-11-18 13:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:14:46 --> Controller Class Initialized
INFO - 2016-11-18 13:14:46 --> Model Class Initialized
INFO - 2016-11-18 13:14:46 --> Model Class Initialized
INFO - 2016-11-18 13:14:46 --> Model Class Initialized
INFO - 2016-11-18 13:14:46 --> Model Class Initialized
INFO - 2016-11-18 13:14:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 13:14:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 13:14:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 13:14:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 13:14:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 13:14:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 13:14:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:14:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 13:14:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 13:14:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 13:14:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 13:14:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 13:14:46 --> Final output sent to browser
DEBUG - 2016-11-18 13:14:46 --> Total execution time: 0.7608
INFO - 2016-11-18 13:15:29 --> Config Class Initialized
INFO - 2016-11-18 13:15:29 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:15:29 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:15:29 --> Utf8 Class Initialized
INFO - 2016-11-18 13:15:29 --> URI Class Initialized
DEBUG - 2016-11-18 13:15:29 --> No URI present. Default controller set.
INFO - 2016-11-18 13:15:29 --> Router Class Initialized
INFO - 2016-11-18 13:15:29 --> Output Class Initialized
INFO - 2016-11-18 13:15:29 --> Security Class Initialized
DEBUG - 2016-11-18 13:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:15:29 --> Input Class Initialized
INFO - 2016-11-18 13:15:29 --> Language Class Initialized
INFO - 2016-11-18 13:15:29 --> Loader Class Initialized
INFO - 2016-11-18 13:15:29 --> Helper loaded: url_helper
INFO - 2016-11-18 13:15:29 --> Helper loaded: form_helper
INFO - 2016-11-18 13:15:29 --> Database Driver Class Initialized
INFO - 2016-11-18 13:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:15:29 --> Controller Class Initialized
INFO - 2016-11-18 13:15:29 --> Model Class Initialized
INFO - 2016-11-18 13:15:29 --> Model Class Initialized
INFO - 2016-11-18 13:15:29 --> Model Class Initialized
INFO - 2016-11-18 13:15:29 --> Model Class Initialized
INFO - 2016-11-18 13:15:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 13:15:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 13:15:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 13:15:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 13:15:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 13:15:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 13:15:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:15:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 13:15:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 13:15:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 13:15:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 13:15:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 13:15:30 --> Final output sent to browser
DEBUG - 2016-11-18 13:15:30 --> Total execution time: 0.8087
INFO - 2016-11-18 13:15:41 --> Config Class Initialized
INFO - 2016-11-18 13:15:41 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:15:42 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:15:42 --> Utf8 Class Initialized
INFO - 2016-11-18 13:15:42 --> URI Class Initialized
INFO - 2016-11-18 13:15:42 --> Router Class Initialized
INFO - 2016-11-18 13:15:42 --> Output Class Initialized
INFO - 2016-11-18 13:15:42 --> Security Class Initialized
DEBUG - 2016-11-18 13:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:15:42 --> Input Class Initialized
INFO - 2016-11-18 13:15:42 --> Language Class Initialized
INFO - 2016-11-18 13:15:42 --> Loader Class Initialized
INFO - 2016-11-18 13:15:42 --> Helper loaded: url_helper
INFO - 2016-11-18 13:15:42 --> Helper loaded: form_helper
INFO - 2016-11-18 13:15:42 --> Database Driver Class Initialized
INFO - 2016-11-18 13:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:15:42 --> Controller Class Initialized
INFO - 2016-11-18 13:15:42 --> Model Class Initialized
INFO - 2016-11-18 13:15:42 --> Form Validation Class Initialized
ERROR - 2016-11-18 13:15:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:43 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:43 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:43 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:43 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:43 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:43 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:43 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:43 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:43 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:43 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:15:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-18 13:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:15:43 --> Final output sent to browser
DEBUG - 2016-11-18 13:15:43 --> Total execution time: 1.4733
INFO - 2016-11-18 13:15:43 --> Config Class Initialized
INFO - 2016-11-18 13:15:43 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:15:43 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:15:43 --> Utf8 Class Initialized
INFO - 2016-11-18 13:15:43 --> URI Class Initialized
DEBUG - 2016-11-18 13:15:43 --> No URI present. Default controller set.
INFO - 2016-11-18 13:15:43 --> Router Class Initialized
INFO - 2016-11-18 13:15:43 --> Output Class Initialized
INFO - 2016-11-18 13:15:43 --> Security Class Initialized
DEBUG - 2016-11-18 13:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:15:43 --> Input Class Initialized
INFO - 2016-11-18 13:15:43 --> Language Class Initialized
INFO - 2016-11-18 13:15:43 --> Loader Class Initialized
INFO - 2016-11-18 13:15:43 --> Helper loaded: url_helper
INFO - 2016-11-18 13:15:43 --> Helper loaded: form_helper
INFO - 2016-11-18 13:15:43 --> Database Driver Class Initialized
INFO - 2016-11-18 13:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:15:43 --> Controller Class Initialized
INFO - 2016-11-18 13:15:43 --> Model Class Initialized
INFO - 2016-11-18 13:15:43 --> Model Class Initialized
INFO - 2016-11-18 13:15:43 --> Model Class Initialized
INFO - 2016-11-18 13:15:43 --> Model Class Initialized
INFO - 2016-11-18 13:15:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 13:15:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 13:15:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 13:15:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 13:15:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 13:15:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 13:15:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:15:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 13:15:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 13:15:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 13:15:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 13:15:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 13:15:44 --> Final output sent to browser
DEBUG - 2016-11-18 13:15:44 --> Total execution time: 0.7447
INFO - 2016-11-18 13:16:17 --> Config Class Initialized
INFO - 2016-11-18 13:16:17 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:16:17 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:16:17 --> Utf8 Class Initialized
INFO - 2016-11-18 13:16:17 --> URI Class Initialized
DEBUG - 2016-11-18 13:16:17 --> No URI present. Default controller set.
INFO - 2016-11-18 13:16:17 --> Router Class Initialized
INFO - 2016-11-18 13:16:17 --> Output Class Initialized
INFO - 2016-11-18 13:16:17 --> Security Class Initialized
DEBUG - 2016-11-18 13:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:16:17 --> Input Class Initialized
INFO - 2016-11-18 13:16:17 --> Language Class Initialized
INFO - 2016-11-18 13:16:17 --> Loader Class Initialized
INFO - 2016-11-18 13:16:17 --> Helper loaded: url_helper
INFO - 2016-11-18 13:16:17 --> Helper loaded: form_helper
INFO - 2016-11-18 13:16:17 --> Database Driver Class Initialized
INFO - 2016-11-18 13:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:16:18 --> Controller Class Initialized
INFO - 2016-11-18 13:16:18 --> Model Class Initialized
INFO - 2016-11-18 13:16:18 --> Model Class Initialized
INFO - 2016-11-18 13:16:18 --> Model Class Initialized
INFO - 2016-11-18 13:16:18 --> Model Class Initialized
INFO - 2016-11-18 13:16:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 13:16:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 13:16:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 13:16:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 13:16:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 13:16:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 13:16:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:16:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 13:16:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 13:16:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 13:16:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 13:16:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 13:16:18 --> Final output sent to browser
DEBUG - 2016-11-18 13:16:18 --> Total execution time: 0.7771
INFO - 2016-11-18 13:16:37 --> Config Class Initialized
INFO - 2016-11-18 13:16:37 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:16:37 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:16:37 --> Utf8 Class Initialized
INFO - 2016-11-18 13:16:37 --> URI Class Initialized
INFO - 2016-11-18 13:16:37 --> Router Class Initialized
INFO - 2016-11-18 13:16:37 --> Output Class Initialized
INFO - 2016-11-18 13:16:37 --> Security Class Initialized
DEBUG - 2016-11-18 13:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:16:37 --> Input Class Initialized
INFO - 2016-11-18 13:16:37 --> Language Class Initialized
INFO - 2016-11-18 13:16:37 --> Loader Class Initialized
INFO - 2016-11-18 13:16:37 --> Helper loaded: url_helper
INFO - 2016-11-18 13:16:37 --> Helper loaded: form_helper
INFO - 2016-11-18 13:16:37 --> Database Driver Class Initialized
INFO - 2016-11-18 13:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:16:37 --> Controller Class Initialized
INFO - 2016-11-18 13:16:38 --> Model Class Initialized
INFO - 2016-11-18 13:16:38 --> Form Validation Class Initialized
ERROR - 2016-11-18 13:16:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 13:16:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-18 13:16:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:16:39 --> Final output sent to browser
DEBUG - 2016-11-18 13:16:39 --> Total execution time: 1.4926
INFO - 2016-11-18 13:16:39 --> Config Class Initialized
INFO - 2016-11-18 13:16:39 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:16:39 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:16:39 --> Utf8 Class Initialized
INFO - 2016-11-18 13:16:39 --> URI Class Initialized
DEBUG - 2016-11-18 13:16:39 --> No URI present. Default controller set.
INFO - 2016-11-18 13:16:39 --> Router Class Initialized
INFO - 2016-11-18 13:16:39 --> Output Class Initialized
INFO - 2016-11-18 13:16:39 --> Security Class Initialized
DEBUG - 2016-11-18 13:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:16:39 --> Input Class Initialized
INFO - 2016-11-18 13:16:39 --> Language Class Initialized
INFO - 2016-11-18 13:16:39 --> Loader Class Initialized
INFO - 2016-11-18 13:16:39 --> Helper loaded: url_helper
INFO - 2016-11-18 13:16:39 --> Helper loaded: form_helper
INFO - 2016-11-18 13:16:39 --> Database Driver Class Initialized
INFO - 2016-11-18 13:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:16:39 --> Controller Class Initialized
INFO - 2016-11-18 13:16:39 --> Model Class Initialized
INFO - 2016-11-18 13:16:39 --> Model Class Initialized
INFO - 2016-11-18 13:16:39 --> Model Class Initialized
INFO - 2016-11-18 13:16:39 --> Model Class Initialized
INFO - 2016-11-18 13:16:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 13:16:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 13:16:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 13:16:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 13:16:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 13:16:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 13:16:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:16:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 13:16:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 13:16:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 13:16:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 13:16:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 13:16:40 --> Final output sent to browser
DEBUG - 2016-11-18 13:16:40 --> Total execution time: 1.0093
INFO - 2016-11-18 13:17:54 --> Config Class Initialized
INFO - 2016-11-18 13:17:54 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:17:54 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:17:54 --> Utf8 Class Initialized
INFO - 2016-11-18 13:17:54 --> URI Class Initialized
DEBUG - 2016-11-18 13:17:54 --> No URI present. Default controller set.
INFO - 2016-11-18 13:17:54 --> Router Class Initialized
INFO - 2016-11-18 13:17:54 --> Output Class Initialized
INFO - 2016-11-18 13:17:54 --> Security Class Initialized
DEBUG - 2016-11-18 13:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:17:55 --> Input Class Initialized
INFO - 2016-11-18 13:17:55 --> Language Class Initialized
INFO - 2016-11-18 13:17:55 --> Loader Class Initialized
INFO - 2016-11-18 13:17:55 --> Helper loaded: url_helper
INFO - 2016-11-18 13:17:55 --> Helper loaded: form_helper
INFO - 2016-11-18 13:17:55 --> Database Driver Class Initialized
INFO - 2016-11-18 13:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:17:55 --> Controller Class Initialized
INFO - 2016-11-18 13:17:55 --> Model Class Initialized
INFO - 2016-11-18 13:17:55 --> Model Class Initialized
INFO - 2016-11-18 13:17:55 --> Model Class Initialized
INFO - 2016-11-18 13:17:55 --> Model Class Initialized
INFO - 2016-11-18 13:17:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 13:17:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 13:17:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 13:17:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 13:17:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 13:17:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 13:17:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:17:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 13:17:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 13:17:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 13:17:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 13:17:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 13:17:55 --> Final output sent to browser
DEBUG - 2016-11-18 13:17:55 --> Total execution time: 0.8264
INFO - 2016-11-18 13:18:13 --> Config Class Initialized
INFO - 2016-11-18 13:18:13 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:18:13 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:18:13 --> Utf8 Class Initialized
INFO - 2016-11-18 13:18:13 --> URI Class Initialized
DEBUG - 2016-11-18 13:18:13 --> No URI present. Default controller set.
INFO - 2016-11-18 13:18:13 --> Router Class Initialized
INFO - 2016-11-18 13:18:13 --> Output Class Initialized
INFO - 2016-11-18 13:18:13 --> Security Class Initialized
DEBUG - 2016-11-18 13:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:18:13 --> Input Class Initialized
INFO - 2016-11-18 13:18:13 --> Language Class Initialized
INFO - 2016-11-18 13:18:13 --> Loader Class Initialized
INFO - 2016-11-18 13:18:13 --> Helper loaded: url_helper
INFO - 2016-11-18 13:18:13 --> Helper loaded: form_helper
INFO - 2016-11-18 13:18:13 --> Database Driver Class Initialized
INFO - 2016-11-18 13:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:18:13 --> Controller Class Initialized
INFO - 2016-11-18 13:18:13 --> Model Class Initialized
INFO - 2016-11-18 13:18:13 --> Model Class Initialized
INFO - 2016-11-18 13:18:13 --> Model Class Initialized
INFO - 2016-11-18 13:18:13 --> Model Class Initialized
INFO - 2016-11-18 13:18:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 13:18:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 13:18:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 13:18:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 13:18:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 13:18:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 13:18:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:18:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 13:18:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 13:18:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 13:18:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 13:18:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 13:18:14 --> Final output sent to browser
DEBUG - 2016-11-18 13:18:14 --> Total execution time: 0.8075
INFO - 2016-11-18 13:18:59 --> Config Class Initialized
INFO - 2016-11-18 13:18:59 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:18:59 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:18:59 --> Utf8 Class Initialized
INFO - 2016-11-18 13:18:59 --> URI Class Initialized
INFO - 2016-11-18 13:18:59 --> Router Class Initialized
INFO - 2016-11-18 13:18:59 --> Output Class Initialized
INFO - 2016-11-18 13:18:59 --> Security Class Initialized
DEBUG - 2016-11-18 13:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:18:59 --> Input Class Initialized
INFO - 2016-11-18 13:18:59 --> Language Class Initialized
INFO - 2016-11-18 13:18:59 --> Loader Class Initialized
INFO - 2016-11-18 13:18:59 --> Helper loaded: url_helper
INFO - 2016-11-18 13:18:59 --> Helper loaded: form_helper
INFO - 2016-11-18 13:18:59 --> Database Driver Class Initialized
INFO - 2016-11-18 13:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:18:59 --> Controller Class Initialized
INFO - 2016-11-18 13:18:59 --> Model Class Initialized
INFO - 2016-11-18 13:18:59 --> Form Validation Class Initialized
INFO - 2016-11-18 13:18:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 13:18:59 --> Final output sent to browser
DEBUG - 2016-11-18 13:18:59 --> Total execution time: 0.4155
INFO - 2016-11-18 13:19:32 --> Config Class Initialized
INFO - 2016-11-18 13:19:32 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:19:32 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:19:32 --> Utf8 Class Initialized
INFO - 2016-11-18 13:19:32 --> URI Class Initialized
INFO - 2016-11-18 13:19:32 --> Router Class Initialized
INFO - 2016-11-18 13:19:32 --> Output Class Initialized
INFO - 2016-11-18 13:19:32 --> Security Class Initialized
DEBUG - 2016-11-18 13:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:19:32 --> Input Class Initialized
INFO - 2016-11-18 13:19:32 --> Language Class Initialized
INFO - 2016-11-18 13:19:32 --> Loader Class Initialized
INFO - 2016-11-18 13:19:32 --> Helper loaded: url_helper
INFO - 2016-11-18 13:19:32 --> Helper loaded: form_helper
INFO - 2016-11-18 13:19:32 --> Database Driver Class Initialized
INFO - 2016-11-18 13:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:19:32 --> Controller Class Initialized
INFO - 2016-11-18 13:19:32 --> Model Class Initialized
INFO - 2016-11-18 13:19:32 --> Form Validation Class Initialized
INFO - 2016-11-18 13:19:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 13:19:32 --> Final output sent to browser
DEBUG - 2016-11-18 13:19:32 --> Total execution time: 0.4180
INFO - 2016-11-18 13:22:09 --> Config Class Initialized
INFO - 2016-11-18 13:22:09 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:22:09 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:22:09 --> Utf8 Class Initialized
INFO - 2016-11-18 13:22:09 --> URI Class Initialized
DEBUG - 2016-11-18 13:22:09 --> No URI present. Default controller set.
INFO - 2016-11-18 13:22:09 --> Router Class Initialized
INFO - 2016-11-18 13:22:09 --> Output Class Initialized
INFO - 2016-11-18 13:22:09 --> Security Class Initialized
DEBUG - 2016-11-18 13:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:22:09 --> Input Class Initialized
INFO - 2016-11-18 13:22:09 --> Language Class Initialized
INFO - 2016-11-18 13:22:09 --> Loader Class Initialized
INFO - 2016-11-18 13:22:09 --> Helper loaded: url_helper
INFO - 2016-11-18 13:22:09 --> Helper loaded: form_helper
INFO - 2016-11-18 13:22:09 --> Database Driver Class Initialized
INFO - 2016-11-18 13:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:22:10 --> Controller Class Initialized
INFO - 2016-11-18 13:22:10 --> Model Class Initialized
INFO - 2016-11-18 13:22:10 --> Model Class Initialized
INFO - 2016-11-18 13:22:10 --> Model Class Initialized
INFO - 2016-11-18 13:22:10 --> Model Class Initialized
INFO - 2016-11-18 13:22:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 13:22:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 13:22:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 13:22:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 13:22:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 13:22:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 13:22:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:22:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 13:22:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 13:22:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 13:22:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 13:22:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 13:22:10 --> Final output sent to browser
DEBUG - 2016-11-18 13:22:10 --> Total execution time: 0.8190
INFO - 2016-11-18 13:29:25 --> Config Class Initialized
INFO - 2016-11-18 13:29:25 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:29:25 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:29:25 --> Utf8 Class Initialized
INFO - 2016-11-18 13:29:25 --> URI Class Initialized
DEBUG - 2016-11-18 13:29:25 --> No URI present. Default controller set.
INFO - 2016-11-18 13:29:25 --> Router Class Initialized
INFO - 2016-11-18 13:29:25 --> Output Class Initialized
INFO - 2016-11-18 13:29:25 --> Security Class Initialized
DEBUG - 2016-11-18 13:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:29:25 --> Input Class Initialized
INFO - 2016-11-18 13:29:25 --> Language Class Initialized
INFO - 2016-11-18 13:29:25 --> Loader Class Initialized
INFO - 2016-11-18 13:29:25 --> Helper loaded: url_helper
INFO - 2016-11-18 13:29:25 --> Helper loaded: form_helper
INFO - 2016-11-18 13:29:25 --> Database Driver Class Initialized
INFO - 2016-11-18 13:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:29:25 --> Controller Class Initialized
INFO - 2016-11-18 13:29:25 --> Model Class Initialized
INFO - 2016-11-18 13:29:25 --> Model Class Initialized
INFO - 2016-11-18 13:29:25 --> Model Class Initialized
INFO - 2016-11-18 13:29:25 --> Model Class Initialized
INFO - 2016-11-18 13:29:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 13:29:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 13:29:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 13:29:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 13:29:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 13:29:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 13:29:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 13:29:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 13:29:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 13:29:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 13:29:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 13:29:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 13:29:25 --> Final output sent to browser
DEBUG - 2016-11-18 13:29:25 --> Total execution time: 0.8032
INFO - 2016-11-18 13:30:43 --> Config Class Initialized
INFO - 2016-11-18 13:30:43 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:30:43 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:30:43 --> Utf8 Class Initialized
INFO - 2016-11-18 13:30:43 --> URI Class Initialized
INFO - 2016-11-18 13:30:43 --> Router Class Initialized
INFO - 2016-11-18 13:30:43 --> Output Class Initialized
INFO - 2016-11-18 13:30:43 --> Security Class Initialized
DEBUG - 2016-11-18 13:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:30:43 --> Input Class Initialized
INFO - 2016-11-18 13:30:43 --> Language Class Initialized
INFO - 2016-11-18 13:30:43 --> Loader Class Initialized
INFO - 2016-11-18 13:30:43 --> Helper loaded: url_helper
INFO - 2016-11-18 13:30:43 --> Helper loaded: form_helper
INFO - 2016-11-18 13:30:43 --> Database Driver Class Initialized
INFO - 2016-11-18 13:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:30:43 --> Controller Class Initialized
INFO - 2016-11-18 13:30:43 --> Model Class Initialized
INFO - 2016-11-18 13:30:43 --> Model Class Initialized
INFO - 2016-11-18 13:30:43 --> Model Class Initialized
INFO - 2016-11-18 13:30:43 --> Model Class Initialized
DEBUG - 2016-11-18 13:30:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-18 13:30:43 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-18 13:30:43 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-18 13:30:43 --> Config Class Initialized
INFO - 2016-11-18 13:30:43 --> Hooks Class Initialized
DEBUG - 2016-11-18 13:30:43 --> UTF-8 Support Enabled
INFO - 2016-11-18 13:30:43 --> Utf8 Class Initialized
INFO - 2016-11-18 13:30:43 --> URI Class Initialized
DEBUG - 2016-11-18 13:30:43 --> No URI present. Default controller set.
INFO - 2016-11-18 13:30:43 --> Router Class Initialized
INFO - 2016-11-18 13:30:43 --> Output Class Initialized
INFO - 2016-11-18 13:30:43 --> Security Class Initialized
DEBUG - 2016-11-18 13:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 13:30:43 --> Input Class Initialized
INFO - 2016-11-18 13:30:43 --> Language Class Initialized
INFO - 2016-11-18 13:30:43 --> Loader Class Initialized
INFO - 2016-11-18 13:30:43 --> Helper loaded: url_helper
INFO - 2016-11-18 13:30:43 --> Helper loaded: form_helper
INFO - 2016-11-18 13:30:43 --> Database Driver Class Initialized
INFO - 2016-11-18 13:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 13:30:44 --> Controller Class Initialized
INFO - 2016-11-18 13:30:44 --> Model Class Initialized
INFO - 2016-11-18 13:30:44 --> Model Class Initialized
INFO - 2016-11-18 13:30:44 --> Model Class Initialized
INFO - 2016-11-18 13:30:44 --> Model Class Initialized
INFO - 2016-11-18 13:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 13:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 13:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 13:30:44 --> Final output sent to browser
DEBUG - 2016-11-18 13:30:44 --> Total execution time: 0.5467
INFO - 2016-11-18 14:22:39 --> Config Class Initialized
INFO - 2016-11-18 14:22:39 --> Hooks Class Initialized
DEBUG - 2016-11-18 14:22:40 --> UTF-8 Support Enabled
INFO - 2016-11-18 14:22:40 --> Utf8 Class Initialized
INFO - 2016-11-18 14:22:40 --> URI Class Initialized
DEBUG - 2016-11-18 14:22:40 --> No URI present. Default controller set.
INFO - 2016-11-18 14:22:40 --> Router Class Initialized
INFO - 2016-11-18 14:22:40 --> Output Class Initialized
INFO - 2016-11-18 14:22:40 --> Security Class Initialized
DEBUG - 2016-11-18 14:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 14:22:40 --> Input Class Initialized
INFO - 2016-11-18 14:22:40 --> Language Class Initialized
INFO - 2016-11-18 14:22:40 --> Loader Class Initialized
INFO - 2016-11-18 14:22:40 --> Helper loaded: url_helper
INFO - 2016-11-18 14:22:40 --> Helper loaded: form_helper
INFO - 2016-11-18 14:22:41 --> Database Driver Class Initialized
INFO - 2016-11-18 14:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 14:22:41 --> Controller Class Initialized
INFO - 2016-11-18 14:22:41 --> Model Class Initialized
INFO - 2016-11-18 14:22:41 --> Model Class Initialized
INFO - 2016-11-18 14:22:41 --> Model Class Initialized
INFO - 2016-11-18 14:22:41 --> Model Class Initialized
INFO - 2016-11-18 14:22:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 14:22:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 14:22:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 14:22:41 --> Final output sent to browser
DEBUG - 2016-11-18 14:22:41 --> Total execution time: 1.9236
INFO - 2016-11-18 14:22:43 --> Config Class Initialized
INFO - 2016-11-18 14:22:43 --> Hooks Class Initialized
DEBUG - 2016-11-18 14:22:43 --> UTF-8 Support Enabled
INFO - 2016-11-18 14:22:43 --> Utf8 Class Initialized
INFO - 2016-11-18 14:22:43 --> URI Class Initialized
DEBUG - 2016-11-18 14:22:43 --> No URI present. Default controller set.
INFO - 2016-11-18 14:22:43 --> Router Class Initialized
INFO - 2016-11-18 14:22:43 --> Output Class Initialized
INFO - 2016-11-18 14:22:43 --> Security Class Initialized
DEBUG - 2016-11-18 14:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 14:22:43 --> Input Class Initialized
INFO - 2016-11-18 14:22:43 --> Language Class Initialized
INFO - 2016-11-18 14:22:44 --> Loader Class Initialized
INFO - 2016-11-18 14:22:44 --> Helper loaded: url_helper
INFO - 2016-11-18 14:22:44 --> Helper loaded: form_helper
INFO - 2016-11-18 14:22:44 --> Database Driver Class Initialized
INFO - 2016-11-18 14:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 14:22:44 --> Controller Class Initialized
INFO - 2016-11-18 14:22:44 --> Model Class Initialized
INFO - 2016-11-18 14:22:44 --> Model Class Initialized
INFO - 2016-11-18 14:22:44 --> Model Class Initialized
INFO - 2016-11-18 14:22:44 --> Model Class Initialized
INFO - 2016-11-18 14:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 14:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 14:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 14:22:44 --> Final output sent to browser
DEBUG - 2016-11-18 14:22:44 --> Total execution time: 0.6207
INFO - 2016-11-18 14:22:59 --> Config Class Initialized
INFO - 2016-11-18 14:22:59 --> Hooks Class Initialized
DEBUG - 2016-11-18 14:22:59 --> UTF-8 Support Enabled
INFO - 2016-11-18 14:22:59 --> Utf8 Class Initialized
INFO - 2016-11-18 14:22:59 --> URI Class Initialized
INFO - 2016-11-18 14:22:59 --> Router Class Initialized
INFO - 2016-11-18 14:22:59 --> Output Class Initialized
INFO - 2016-11-18 14:22:59 --> Security Class Initialized
DEBUG - 2016-11-18 14:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 14:22:59 --> Input Class Initialized
INFO - 2016-11-18 14:22:59 --> Language Class Initialized
INFO - 2016-11-18 14:22:59 --> Loader Class Initialized
INFO - 2016-11-18 14:22:59 --> Helper loaded: url_helper
INFO - 2016-11-18 14:22:59 --> Helper loaded: form_helper
INFO - 2016-11-18 14:22:59 --> Database Driver Class Initialized
INFO - 2016-11-18 14:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 14:23:00 --> Controller Class Initialized
INFO - 2016-11-18 14:23:00 --> Model Class Initialized
INFO - 2016-11-18 14:23:00 --> Model Class Initialized
INFO - 2016-11-18 14:23:00 --> Model Class Initialized
INFO - 2016-11-18 14:23:00 --> Model Class Initialized
DEBUG - 2016-11-18 14:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-18 14:23:00 --> Model Class Initialized
INFO - 2016-11-18 14:23:00 --> Final output sent to browser
DEBUG - 2016-11-18 14:23:00 --> Total execution time: 0.5615
INFO - 2016-11-18 14:23:00 --> Config Class Initialized
INFO - 2016-11-18 14:23:00 --> Hooks Class Initialized
DEBUG - 2016-11-18 14:23:00 --> UTF-8 Support Enabled
INFO - 2016-11-18 14:23:00 --> Utf8 Class Initialized
INFO - 2016-11-18 14:23:00 --> URI Class Initialized
DEBUG - 2016-11-18 14:23:00 --> No URI present. Default controller set.
INFO - 2016-11-18 14:23:00 --> Router Class Initialized
INFO - 2016-11-18 14:23:00 --> Output Class Initialized
INFO - 2016-11-18 14:23:00 --> Security Class Initialized
DEBUG - 2016-11-18 14:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 14:23:00 --> Input Class Initialized
INFO - 2016-11-18 14:23:00 --> Language Class Initialized
INFO - 2016-11-18 14:23:00 --> Loader Class Initialized
INFO - 2016-11-18 14:23:00 --> Helper loaded: url_helper
INFO - 2016-11-18 14:23:00 --> Helper loaded: form_helper
INFO - 2016-11-18 14:23:00 --> Database Driver Class Initialized
INFO - 2016-11-18 14:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 14:23:00 --> Controller Class Initialized
INFO - 2016-11-18 14:23:00 --> Model Class Initialized
INFO - 2016-11-18 14:23:00 --> Model Class Initialized
INFO - 2016-11-18 14:23:00 --> Model Class Initialized
INFO - 2016-11-18 14:23:00 --> Model Class Initialized
INFO - 2016-11-18 14:23:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 14:23:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 14:23:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 14:23:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-18 14:23:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-18 14:23:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-18 14:23:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 14:23:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-18 14:23:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-18 14:23:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 14:23:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 14:23:01 --> Final output sent to browser
DEBUG - 2016-11-18 14:23:01 --> Total execution time: 1.2431
INFO - 2016-11-18 14:23:04 --> Config Class Initialized
INFO - 2016-11-18 14:23:04 --> Hooks Class Initialized
DEBUG - 2016-11-18 14:23:04 --> UTF-8 Support Enabled
INFO - 2016-11-18 14:23:04 --> Utf8 Class Initialized
INFO - 2016-11-18 14:23:04 --> URI Class Initialized
DEBUG - 2016-11-18 14:23:04 --> No URI present. Default controller set.
INFO - 2016-11-18 14:23:04 --> Router Class Initialized
INFO - 2016-11-18 14:23:04 --> Output Class Initialized
INFO - 2016-11-18 14:23:04 --> Security Class Initialized
DEBUG - 2016-11-18 14:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 14:23:04 --> Input Class Initialized
INFO - 2016-11-18 14:23:04 --> Language Class Initialized
INFO - 2016-11-18 14:23:04 --> Loader Class Initialized
INFO - 2016-11-18 14:23:04 --> Helper loaded: url_helper
INFO - 2016-11-18 14:23:04 --> Helper loaded: form_helper
INFO - 2016-11-18 14:23:04 --> Database Driver Class Initialized
INFO - 2016-11-18 14:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 14:23:04 --> Controller Class Initialized
INFO - 2016-11-18 14:23:04 --> Model Class Initialized
INFO - 2016-11-18 14:23:04 --> Model Class Initialized
INFO - 2016-11-18 14:23:04 --> Model Class Initialized
INFO - 2016-11-18 14:23:04 --> Model Class Initialized
INFO - 2016-11-18 14:23:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 14:23:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 14:23:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 14:23:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-18 14:23:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-18 14:23:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-18 14:23:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 14:23:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-18 14:23:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-18 14:23:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 14:23:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 14:23:04 --> Final output sent to browser
DEBUG - 2016-11-18 14:23:04 --> Total execution time: 0.7715
INFO - 2016-11-18 14:23:19 --> Config Class Initialized
INFO - 2016-11-18 14:23:19 --> Hooks Class Initialized
DEBUG - 2016-11-18 14:23:19 --> UTF-8 Support Enabled
INFO - 2016-11-18 14:23:19 --> Utf8 Class Initialized
INFO - 2016-11-18 14:23:19 --> URI Class Initialized
DEBUG - 2016-11-18 14:23:19 --> No URI present. Default controller set.
INFO - 2016-11-18 14:23:19 --> Router Class Initialized
INFO - 2016-11-18 14:23:19 --> Output Class Initialized
INFO - 2016-11-18 14:23:19 --> Security Class Initialized
DEBUG - 2016-11-18 14:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 14:23:19 --> Input Class Initialized
INFO - 2016-11-18 14:23:19 --> Language Class Initialized
INFO - 2016-11-18 14:23:19 --> Loader Class Initialized
INFO - 2016-11-18 14:23:19 --> Helper loaded: url_helper
INFO - 2016-11-18 14:23:19 --> Helper loaded: form_helper
INFO - 2016-11-18 14:23:19 --> Database Driver Class Initialized
INFO - 2016-11-18 14:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 14:23:19 --> Controller Class Initialized
INFO - 2016-11-18 14:23:19 --> Model Class Initialized
INFO - 2016-11-18 14:23:19 --> Model Class Initialized
INFO - 2016-11-18 14:23:19 --> Model Class Initialized
INFO - 2016-11-18 14:23:19 --> Model Class Initialized
INFO - 2016-11-18 14:23:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 14:23:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 14:23:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 14:23:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-18 14:23:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-18 14:23:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-18 14:23:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-18 14:23:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-18 14:23:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-18 14:23:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 14:23:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 14:23:20 --> Final output sent to browser
DEBUG - 2016-11-18 14:23:20 --> Total execution time: 0.8256
INFO - 2016-11-18 14:23:28 --> Config Class Initialized
INFO - 2016-11-18 14:23:28 --> Hooks Class Initialized
DEBUG - 2016-11-18 14:23:28 --> UTF-8 Support Enabled
INFO - 2016-11-18 14:23:28 --> Utf8 Class Initialized
INFO - 2016-11-18 14:23:28 --> URI Class Initialized
INFO - 2016-11-18 14:23:28 --> Router Class Initialized
INFO - 2016-11-18 14:23:28 --> Output Class Initialized
INFO - 2016-11-18 14:23:28 --> Security Class Initialized
DEBUG - 2016-11-18 14:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 14:23:28 --> Input Class Initialized
INFO - 2016-11-18 14:23:28 --> Language Class Initialized
INFO - 2016-11-18 14:23:28 --> Loader Class Initialized
INFO - 2016-11-18 14:23:28 --> Helper loaded: url_helper
INFO - 2016-11-18 14:23:28 --> Helper loaded: form_helper
INFO - 2016-11-18 14:23:28 --> Database Driver Class Initialized
INFO - 2016-11-18 14:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 14:23:29 --> Controller Class Initialized
INFO - 2016-11-18 14:23:29 --> Model Class Initialized
INFO - 2016-11-18 14:23:29 --> Form Validation Class Initialized
INFO - 2016-11-18 14:23:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 14:23:29 --> Final output sent to browser
DEBUG - 2016-11-18 14:23:29 --> Total execution time: 0.5519
INFO - 2016-11-18 14:23:38 --> Config Class Initialized
INFO - 2016-11-18 14:23:38 --> Hooks Class Initialized
DEBUG - 2016-11-18 14:23:38 --> UTF-8 Support Enabled
INFO - 2016-11-18 14:23:38 --> Utf8 Class Initialized
INFO - 2016-11-18 14:23:38 --> URI Class Initialized
INFO - 2016-11-18 14:23:38 --> Router Class Initialized
INFO - 2016-11-18 14:23:38 --> Output Class Initialized
INFO - 2016-11-18 14:23:38 --> Security Class Initialized
DEBUG - 2016-11-18 14:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 14:23:38 --> Input Class Initialized
INFO - 2016-11-18 14:23:38 --> Language Class Initialized
INFO - 2016-11-18 14:23:38 --> Loader Class Initialized
INFO - 2016-11-18 14:23:38 --> Helper loaded: url_helper
INFO - 2016-11-18 14:23:38 --> Helper loaded: form_helper
INFO - 2016-11-18 14:23:38 --> Database Driver Class Initialized
INFO - 2016-11-18 14:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 14:23:38 --> Controller Class Initialized
INFO - 2016-11-18 14:23:38 --> Model Class Initialized
INFO - 2016-11-18 14:23:38 --> Form Validation Class Initialized
INFO - 2016-11-18 14:23:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 14:23:38 --> Final output sent to browser
DEBUG - 2016-11-18 14:23:38 --> Total execution time: 0.4640
INFO - 2016-11-18 14:23:53 --> Config Class Initialized
INFO - 2016-11-18 14:23:53 --> Hooks Class Initialized
DEBUG - 2016-11-18 14:23:53 --> UTF-8 Support Enabled
INFO - 2016-11-18 14:23:53 --> Utf8 Class Initialized
INFO - 2016-11-18 14:23:53 --> URI Class Initialized
INFO - 2016-11-18 14:23:53 --> Router Class Initialized
INFO - 2016-11-18 14:23:53 --> Output Class Initialized
INFO - 2016-11-18 14:23:53 --> Security Class Initialized
DEBUG - 2016-11-18 14:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 14:23:53 --> Input Class Initialized
INFO - 2016-11-18 14:23:53 --> Language Class Initialized
INFO - 2016-11-18 14:23:53 --> Loader Class Initialized
INFO - 2016-11-18 14:23:53 --> Helper loaded: url_helper
INFO - 2016-11-18 14:23:53 --> Helper loaded: form_helper
INFO - 2016-11-18 14:23:53 --> Database Driver Class Initialized
INFO - 2016-11-18 14:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 14:23:53 --> Controller Class Initialized
INFO - 2016-11-18 14:23:53 --> Model Class Initialized
INFO - 2016-11-18 14:23:53 --> Model Class Initialized
INFO - 2016-11-18 14:23:53 --> Model Class Initialized
INFO - 2016-11-18 14:23:53 --> Model Class Initialized
DEBUG - 2016-11-18 14:23:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-18 14:23:53 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-18 14:23:53 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-18 14:23:53 --> Config Class Initialized
INFO - 2016-11-18 14:23:53 --> Hooks Class Initialized
DEBUG - 2016-11-18 14:23:53 --> UTF-8 Support Enabled
INFO - 2016-11-18 14:23:53 --> Utf8 Class Initialized
INFO - 2016-11-18 14:23:53 --> URI Class Initialized
DEBUG - 2016-11-18 14:23:53 --> No URI present. Default controller set.
INFO - 2016-11-18 14:23:53 --> Router Class Initialized
INFO - 2016-11-18 14:23:53 --> Output Class Initialized
INFO - 2016-11-18 14:23:53 --> Security Class Initialized
DEBUG - 2016-11-18 14:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 14:23:54 --> Input Class Initialized
INFO - 2016-11-18 14:23:54 --> Language Class Initialized
INFO - 2016-11-18 14:23:54 --> Loader Class Initialized
INFO - 2016-11-18 14:23:54 --> Helper loaded: url_helper
INFO - 2016-11-18 14:23:54 --> Helper loaded: form_helper
INFO - 2016-11-18 14:23:54 --> Database Driver Class Initialized
INFO - 2016-11-18 14:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 14:23:54 --> Controller Class Initialized
INFO - 2016-11-18 14:23:54 --> Model Class Initialized
INFO - 2016-11-18 14:23:54 --> Model Class Initialized
INFO - 2016-11-18 14:23:54 --> Model Class Initialized
INFO - 2016-11-18 14:23:54 --> Model Class Initialized
INFO - 2016-11-18 14:23:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 14:23:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 14:23:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 14:23:54 --> Final output sent to browser
DEBUG - 2016-11-18 14:23:54 --> Total execution time: 0.5546
INFO - 2016-11-18 14:33:34 --> Config Class Initialized
INFO - 2016-11-18 14:33:34 --> Hooks Class Initialized
DEBUG - 2016-11-18 14:33:34 --> UTF-8 Support Enabled
INFO - 2016-11-18 14:33:34 --> Utf8 Class Initialized
INFO - 2016-11-18 14:33:34 --> URI Class Initialized
DEBUG - 2016-11-18 14:33:34 --> No URI present. Default controller set.
INFO - 2016-11-18 14:33:34 --> Router Class Initialized
INFO - 2016-11-18 14:33:34 --> Output Class Initialized
INFO - 2016-11-18 14:33:34 --> Security Class Initialized
DEBUG - 2016-11-18 14:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 14:33:34 --> Input Class Initialized
INFO - 2016-11-18 14:33:34 --> Language Class Initialized
INFO - 2016-11-18 14:33:34 --> Loader Class Initialized
INFO - 2016-11-18 14:33:34 --> Helper loaded: url_helper
INFO - 2016-11-18 14:33:34 --> Helper loaded: form_helper
INFO - 2016-11-18 14:33:34 --> Database Driver Class Initialized
INFO - 2016-11-18 14:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 14:33:34 --> Controller Class Initialized
INFO - 2016-11-18 14:33:34 --> Model Class Initialized
INFO - 2016-11-18 14:33:34 --> Model Class Initialized
INFO - 2016-11-18 14:33:34 --> Model Class Initialized
INFO - 2016-11-18 14:33:34 --> Model Class Initialized
INFO - 2016-11-18 14:33:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 14:33:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 14:33:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 14:33:34 --> Final output sent to browser
DEBUG - 2016-11-18 14:33:34 --> Total execution time: 0.6907
INFO - 2016-11-18 14:34:16 --> Config Class Initialized
INFO - 2016-11-18 14:34:16 --> Hooks Class Initialized
DEBUG - 2016-11-18 14:34:16 --> UTF-8 Support Enabled
INFO - 2016-11-18 14:34:16 --> Utf8 Class Initialized
INFO - 2016-11-18 14:34:16 --> URI Class Initialized
INFO - 2016-11-18 14:34:16 --> Router Class Initialized
INFO - 2016-11-18 14:34:16 --> Output Class Initialized
INFO - 2016-11-18 14:34:16 --> Security Class Initialized
DEBUG - 2016-11-18 14:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 14:34:16 --> Input Class Initialized
INFO - 2016-11-18 14:34:16 --> Language Class Initialized
INFO - 2016-11-18 14:34:16 --> Loader Class Initialized
INFO - 2016-11-18 14:34:16 --> Helper loaded: url_helper
INFO - 2016-11-18 14:34:16 --> Helper loaded: form_helper
INFO - 2016-11-18 14:34:16 --> Database Driver Class Initialized
INFO - 2016-11-18 14:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 14:34:16 --> Controller Class Initialized
INFO - 2016-11-18 14:34:16 --> Model Class Initialized
INFO - 2016-11-18 14:34:16 --> Model Class Initialized
INFO - 2016-11-18 14:34:16 --> Model Class Initialized
INFO - 2016-11-18 14:34:16 --> Model Class Initialized
DEBUG - 2016-11-18 14:34:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-18 14:34:16 --> Model Class Initialized
INFO - 2016-11-18 14:34:16 --> Final output sent to browser
DEBUG - 2016-11-18 14:34:16 --> Total execution time: 0.5357
INFO - 2016-11-18 14:34:16 --> Config Class Initialized
INFO - 2016-11-18 14:34:16 --> Hooks Class Initialized
DEBUG - 2016-11-18 14:34:16 --> UTF-8 Support Enabled
INFO - 2016-11-18 14:34:16 --> Utf8 Class Initialized
INFO - 2016-11-18 14:34:16 --> URI Class Initialized
DEBUG - 2016-11-18 14:34:16 --> No URI present. Default controller set.
INFO - 2016-11-18 14:34:17 --> Router Class Initialized
INFO - 2016-11-18 14:34:17 --> Output Class Initialized
INFO - 2016-11-18 14:34:17 --> Security Class Initialized
DEBUG - 2016-11-18 14:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 14:34:17 --> Input Class Initialized
INFO - 2016-11-18 14:34:17 --> Language Class Initialized
INFO - 2016-11-18 14:34:17 --> Loader Class Initialized
INFO - 2016-11-18 14:34:17 --> Helper loaded: url_helper
INFO - 2016-11-18 14:34:17 --> Helper loaded: form_helper
INFO - 2016-11-18 14:34:17 --> Database Driver Class Initialized
INFO - 2016-11-18 14:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 14:34:17 --> Controller Class Initialized
INFO - 2016-11-18 14:34:17 --> Model Class Initialized
INFO - 2016-11-18 14:34:17 --> Model Class Initialized
INFO - 2016-11-18 14:34:17 --> Model Class Initialized
INFO - 2016-11-18 14:34:17 --> Model Class Initialized
INFO - 2016-11-18 14:34:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 14:34:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 14:34:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 14:34:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 14:34:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 14:34:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 14:34:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 14:34:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 14:34:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 14:34:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 14:34:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 14:34:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 14:34:17 --> Final output sent to browser
DEBUG - 2016-11-18 14:34:17 --> Total execution time: 0.9536
INFO - 2016-11-18 14:34:19 --> Config Class Initialized
INFO - 2016-11-18 14:34:19 --> Hooks Class Initialized
DEBUG - 2016-11-18 14:34:19 --> UTF-8 Support Enabled
INFO - 2016-11-18 14:34:19 --> Utf8 Class Initialized
INFO - 2016-11-18 14:34:19 --> URI Class Initialized
DEBUG - 2016-11-18 14:34:19 --> No URI present. Default controller set.
INFO - 2016-11-18 14:34:19 --> Router Class Initialized
INFO - 2016-11-18 14:34:20 --> Output Class Initialized
INFO - 2016-11-18 14:34:20 --> Security Class Initialized
DEBUG - 2016-11-18 14:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 14:34:20 --> Input Class Initialized
INFO - 2016-11-18 14:34:20 --> Language Class Initialized
INFO - 2016-11-18 14:34:20 --> Loader Class Initialized
INFO - 2016-11-18 14:34:20 --> Helper loaded: url_helper
INFO - 2016-11-18 14:34:20 --> Helper loaded: form_helper
INFO - 2016-11-18 14:34:20 --> Database Driver Class Initialized
INFO - 2016-11-18 14:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 14:34:20 --> Controller Class Initialized
INFO - 2016-11-18 14:34:20 --> Model Class Initialized
INFO - 2016-11-18 14:34:20 --> Model Class Initialized
INFO - 2016-11-18 14:34:20 --> Model Class Initialized
INFO - 2016-11-18 14:34:20 --> Model Class Initialized
INFO - 2016-11-18 14:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 14:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 14:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 14:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 14:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 14:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 14:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 14:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 14:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 14:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 14:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 14:34:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 14:34:20 --> Final output sent to browser
DEBUG - 2016-11-18 14:34:20 --> Total execution time: 0.8965
INFO - 2016-11-18 14:41:08 --> Config Class Initialized
INFO - 2016-11-18 14:41:08 --> Hooks Class Initialized
DEBUG - 2016-11-18 14:41:08 --> UTF-8 Support Enabled
INFO - 2016-11-18 14:41:08 --> Utf8 Class Initialized
INFO - 2016-11-18 14:41:08 --> URI Class Initialized
DEBUG - 2016-11-18 14:41:08 --> No URI present. Default controller set.
INFO - 2016-11-18 14:41:08 --> Router Class Initialized
INFO - 2016-11-18 14:41:08 --> Output Class Initialized
INFO - 2016-11-18 14:41:08 --> Security Class Initialized
DEBUG - 2016-11-18 14:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 14:41:08 --> Input Class Initialized
INFO - 2016-11-18 14:41:08 --> Language Class Initialized
INFO - 2016-11-18 14:41:08 --> Loader Class Initialized
INFO - 2016-11-18 14:41:08 --> Helper loaded: url_helper
INFO - 2016-11-18 14:41:08 --> Helper loaded: form_helper
INFO - 2016-11-18 14:41:08 --> Database Driver Class Initialized
INFO - 2016-11-18 14:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 14:41:08 --> Controller Class Initialized
INFO - 2016-11-18 14:41:08 --> Model Class Initialized
INFO - 2016-11-18 14:41:08 --> Model Class Initialized
INFO - 2016-11-18 14:41:08 --> Model Class Initialized
INFO - 2016-11-18 14:41:08 --> Model Class Initialized
INFO - 2016-11-18 14:41:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 14:41:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 14:41:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 14:41:08 --> Final output sent to browser
DEBUG - 2016-11-18 14:41:08 --> Total execution time: 0.5645
INFO - 2016-11-18 14:41:22 --> Config Class Initialized
INFO - 2016-11-18 14:41:22 --> Hooks Class Initialized
DEBUG - 2016-11-18 14:41:22 --> UTF-8 Support Enabled
INFO - 2016-11-18 14:41:22 --> Utf8 Class Initialized
INFO - 2016-11-18 14:41:22 --> URI Class Initialized
INFO - 2016-11-18 14:41:22 --> Router Class Initialized
INFO - 2016-11-18 14:41:22 --> Output Class Initialized
INFO - 2016-11-18 14:41:22 --> Security Class Initialized
DEBUG - 2016-11-18 14:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 14:41:22 --> Input Class Initialized
INFO - 2016-11-18 14:41:22 --> Language Class Initialized
INFO - 2016-11-18 14:41:22 --> Loader Class Initialized
INFO - 2016-11-18 14:41:22 --> Helper loaded: url_helper
INFO - 2016-11-18 14:41:22 --> Helper loaded: form_helper
INFO - 2016-11-18 14:41:22 --> Database Driver Class Initialized
INFO - 2016-11-18 14:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 14:41:22 --> Controller Class Initialized
INFO - 2016-11-18 14:41:22 --> Model Class Initialized
INFO - 2016-11-18 14:41:22 --> Model Class Initialized
INFO - 2016-11-18 14:41:22 --> Model Class Initialized
INFO - 2016-11-18 14:41:22 --> Model Class Initialized
DEBUG - 2016-11-18 14:41:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-18 14:41:22 --> Model Class Initialized
INFO - 2016-11-18 14:41:22 --> Final output sent to browser
DEBUG - 2016-11-18 14:41:22 --> Total execution time: 0.5461
INFO - 2016-11-18 14:41:22 --> Config Class Initialized
INFO - 2016-11-18 14:41:22 --> Hooks Class Initialized
DEBUG - 2016-11-18 14:41:22 --> UTF-8 Support Enabled
INFO - 2016-11-18 14:41:22 --> Utf8 Class Initialized
INFO - 2016-11-18 14:41:22 --> URI Class Initialized
DEBUG - 2016-11-18 14:41:22 --> No URI present. Default controller set.
INFO - 2016-11-18 14:41:22 --> Router Class Initialized
INFO - 2016-11-18 14:41:22 --> Output Class Initialized
INFO - 2016-11-18 14:41:22 --> Security Class Initialized
DEBUG - 2016-11-18 14:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 14:41:22 --> Input Class Initialized
INFO - 2016-11-18 14:41:22 --> Language Class Initialized
INFO - 2016-11-18 14:41:23 --> Loader Class Initialized
INFO - 2016-11-18 14:41:23 --> Helper loaded: url_helper
INFO - 2016-11-18 14:41:23 --> Helper loaded: form_helper
INFO - 2016-11-18 14:41:23 --> Database Driver Class Initialized
INFO - 2016-11-18 14:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 14:41:23 --> Controller Class Initialized
INFO - 2016-11-18 14:41:23 --> Model Class Initialized
INFO - 2016-11-18 14:41:23 --> Model Class Initialized
INFO - 2016-11-18 14:41:23 --> Model Class Initialized
INFO - 2016-11-18 14:41:23 --> Model Class Initialized
INFO - 2016-11-18 14:41:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 14:41:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 14:41:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 14:41:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 14:41:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 14:41:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 14:41:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 14:41:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 14:41:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 14:41:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 14:41:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 14:41:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 14:41:23 --> Final output sent to browser
DEBUG - 2016-11-18 14:41:23 --> Total execution time: 0.9664
INFO - 2016-11-18 14:41:25 --> Config Class Initialized
INFO - 2016-11-18 14:41:25 --> Hooks Class Initialized
DEBUG - 2016-11-18 14:41:25 --> UTF-8 Support Enabled
INFO - 2016-11-18 14:41:25 --> Utf8 Class Initialized
INFO - 2016-11-18 14:41:25 --> URI Class Initialized
DEBUG - 2016-11-18 14:41:25 --> No URI present. Default controller set.
INFO - 2016-11-18 14:41:25 --> Router Class Initialized
INFO - 2016-11-18 14:41:25 --> Output Class Initialized
INFO - 2016-11-18 14:41:25 --> Security Class Initialized
DEBUG - 2016-11-18 14:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 14:41:25 --> Input Class Initialized
INFO - 2016-11-18 14:41:25 --> Language Class Initialized
INFO - 2016-11-18 14:41:25 --> Loader Class Initialized
INFO - 2016-11-18 14:41:25 --> Helper loaded: url_helper
INFO - 2016-11-18 14:41:25 --> Helper loaded: form_helper
INFO - 2016-11-18 14:41:25 --> Database Driver Class Initialized
INFO - 2016-11-18 14:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 14:41:26 --> Controller Class Initialized
INFO - 2016-11-18 14:41:26 --> Model Class Initialized
INFO - 2016-11-18 14:41:26 --> Model Class Initialized
INFO - 2016-11-18 14:41:26 --> Model Class Initialized
INFO - 2016-11-18 14:41:26 --> Model Class Initialized
INFO - 2016-11-18 14:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 14:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 14:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 14:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 14:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 14:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 14:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 14:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 14:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 14:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 14:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 14:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 14:41:26 --> Final output sent to browser
DEBUG - 2016-11-18 14:41:26 --> Total execution time: 0.8322
INFO - 2016-11-18 14:41:39 --> Config Class Initialized
INFO - 2016-11-18 14:41:39 --> Hooks Class Initialized
DEBUG - 2016-11-18 14:41:39 --> UTF-8 Support Enabled
INFO - 2016-11-18 14:41:39 --> Utf8 Class Initialized
INFO - 2016-11-18 14:41:39 --> URI Class Initialized
INFO - 2016-11-18 14:41:39 --> Router Class Initialized
INFO - 2016-11-18 14:41:39 --> Output Class Initialized
INFO - 2016-11-18 14:41:39 --> Security Class Initialized
DEBUG - 2016-11-18 14:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 14:41:39 --> Input Class Initialized
INFO - 2016-11-18 14:41:39 --> Language Class Initialized
INFO - 2016-11-18 14:41:39 --> Loader Class Initialized
INFO - 2016-11-18 14:41:39 --> Helper loaded: url_helper
INFO - 2016-11-18 14:41:39 --> Helper loaded: form_helper
INFO - 2016-11-18 14:41:39 --> Database Driver Class Initialized
INFO - 2016-11-18 14:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 14:41:39 --> Controller Class Initialized
INFO - 2016-11-18 14:41:39 --> Model Class Initialized
INFO - 2016-11-18 14:41:39 --> Form Validation Class Initialized
ERROR - 2016-11-18 14:41:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 14:41:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 14:41:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 14:41:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 14:41:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 14:41:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 14:41:39 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 14:41:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-18 14:41:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 14:41:40 --> Final output sent to browser
DEBUG - 2016-11-18 14:41:40 --> Total execution time: 0.8070
INFO - 2016-11-18 14:41:40 --> Config Class Initialized
INFO - 2016-11-18 14:41:40 --> Hooks Class Initialized
DEBUG - 2016-11-18 14:41:40 --> UTF-8 Support Enabled
INFO - 2016-11-18 14:41:40 --> Utf8 Class Initialized
INFO - 2016-11-18 14:41:40 --> URI Class Initialized
DEBUG - 2016-11-18 14:41:40 --> No URI present. Default controller set.
INFO - 2016-11-18 14:41:40 --> Router Class Initialized
INFO - 2016-11-18 14:41:40 --> Output Class Initialized
INFO - 2016-11-18 14:41:40 --> Security Class Initialized
DEBUG - 2016-11-18 14:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 14:41:40 --> Input Class Initialized
INFO - 2016-11-18 14:41:40 --> Language Class Initialized
INFO - 2016-11-18 14:41:40 --> Loader Class Initialized
INFO - 2016-11-18 14:41:40 --> Helper loaded: url_helper
INFO - 2016-11-18 14:41:40 --> Helper loaded: form_helper
INFO - 2016-11-18 14:41:40 --> Database Driver Class Initialized
INFO - 2016-11-18 14:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 14:41:40 --> Controller Class Initialized
INFO - 2016-11-18 14:41:40 --> Model Class Initialized
INFO - 2016-11-18 14:41:40 --> Model Class Initialized
INFO - 2016-11-18 14:41:40 --> Model Class Initialized
INFO - 2016-11-18 14:41:40 --> Model Class Initialized
INFO - 2016-11-18 14:41:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 14:41:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 14:41:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 14:41:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 14:41:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 14:41:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 14:41:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 14:41:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 14:41:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 14:41:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 14:41:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 14:41:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 14:41:40 --> Final output sent to browser
DEBUG - 2016-11-18 14:41:40 --> Total execution time: 0.7774
INFO - 2016-11-18 14:43:49 --> Config Class Initialized
INFO - 2016-11-18 14:43:49 --> Hooks Class Initialized
DEBUG - 2016-11-18 14:43:49 --> UTF-8 Support Enabled
INFO - 2016-11-18 14:43:49 --> Utf8 Class Initialized
INFO - 2016-11-18 14:43:49 --> URI Class Initialized
INFO - 2016-11-18 14:43:49 --> Router Class Initialized
INFO - 2016-11-18 14:43:49 --> Output Class Initialized
INFO - 2016-11-18 14:43:49 --> Security Class Initialized
DEBUG - 2016-11-18 14:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 14:43:49 --> Input Class Initialized
INFO - 2016-11-18 14:43:49 --> Language Class Initialized
INFO - 2016-11-18 14:43:49 --> Loader Class Initialized
INFO - 2016-11-18 14:43:49 --> Helper loaded: url_helper
INFO - 2016-11-18 14:43:49 --> Helper loaded: form_helper
INFO - 2016-11-18 14:43:49 --> Database Driver Class Initialized
INFO - 2016-11-18 14:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 14:43:49 --> Controller Class Initialized
INFO - 2016-11-18 14:43:49 --> Model Class Initialized
INFO - 2016-11-18 14:43:49 --> Model Class Initialized
INFO - 2016-11-18 14:43:49 --> Model Class Initialized
INFO - 2016-11-18 14:43:49 --> Model Class Initialized
DEBUG - 2016-11-18 14:43:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-18 14:43:49 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-18 14:43:49 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-18 14:43:49 --> Config Class Initialized
INFO - 2016-11-18 14:43:49 --> Hooks Class Initialized
DEBUG - 2016-11-18 14:43:49 --> UTF-8 Support Enabled
INFO - 2016-11-18 14:43:49 --> Utf8 Class Initialized
INFO - 2016-11-18 14:43:49 --> URI Class Initialized
DEBUG - 2016-11-18 14:43:49 --> No URI present. Default controller set.
INFO - 2016-11-18 14:43:49 --> Router Class Initialized
INFO - 2016-11-18 14:43:49 --> Output Class Initialized
INFO - 2016-11-18 14:43:49 --> Security Class Initialized
DEBUG - 2016-11-18 14:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 14:43:49 --> Input Class Initialized
INFO - 2016-11-18 14:43:49 --> Language Class Initialized
INFO - 2016-11-18 14:43:49 --> Loader Class Initialized
INFO - 2016-11-18 14:43:49 --> Helper loaded: url_helper
INFO - 2016-11-18 14:43:50 --> Helper loaded: form_helper
INFO - 2016-11-18 14:43:50 --> Database Driver Class Initialized
INFO - 2016-11-18 14:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 14:43:50 --> Controller Class Initialized
INFO - 2016-11-18 14:43:50 --> Model Class Initialized
INFO - 2016-11-18 14:43:50 --> Model Class Initialized
INFO - 2016-11-18 14:43:50 --> Model Class Initialized
INFO - 2016-11-18 14:43:50 --> Model Class Initialized
INFO - 2016-11-18 14:43:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 14:43:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 14:43:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 14:43:50 --> Final output sent to browser
DEBUG - 2016-11-18 14:43:50 --> Total execution time: 0.5795
INFO - 2016-11-18 22:17:03 --> Config Class Initialized
INFO - 2016-11-18 22:17:03 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:17:03 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:17:03 --> Utf8 Class Initialized
INFO - 2016-11-18 22:17:04 --> URI Class Initialized
DEBUG - 2016-11-18 22:17:04 --> No URI present. Default controller set.
INFO - 2016-11-18 22:17:04 --> Router Class Initialized
INFO - 2016-11-18 22:17:04 --> Output Class Initialized
INFO - 2016-11-18 22:17:04 --> Security Class Initialized
DEBUG - 2016-11-18 22:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:17:04 --> Input Class Initialized
INFO - 2016-11-18 22:17:04 --> Language Class Initialized
INFO - 2016-11-18 22:17:04 --> Loader Class Initialized
INFO - 2016-11-18 22:17:04 --> Helper loaded: url_helper
INFO - 2016-11-18 22:17:04 --> Helper loaded: form_helper
INFO - 2016-11-18 22:17:04 --> Database Driver Class Initialized
INFO - 2016-11-18 22:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:17:04 --> Controller Class Initialized
INFO - 2016-11-18 22:17:05 --> Model Class Initialized
INFO - 2016-11-18 22:17:05 --> Model Class Initialized
INFO - 2016-11-18 22:17:05 --> Model Class Initialized
INFO - 2016-11-18 22:17:05 --> Model Class Initialized
INFO - 2016-11-18 22:17:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:17:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 22:17:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:17:05 --> Final output sent to browser
DEBUG - 2016-11-18 22:17:05 --> Total execution time: 1.3859
INFO - 2016-11-18 22:17:21 --> Config Class Initialized
INFO - 2016-11-18 22:17:21 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:17:21 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:17:21 --> Utf8 Class Initialized
INFO - 2016-11-18 22:17:21 --> URI Class Initialized
INFO - 2016-11-18 22:17:21 --> Router Class Initialized
INFO - 2016-11-18 22:17:21 --> Output Class Initialized
INFO - 2016-11-18 22:17:22 --> Security Class Initialized
DEBUG - 2016-11-18 22:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:17:22 --> Input Class Initialized
INFO - 2016-11-18 22:17:22 --> Language Class Initialized
INFO - 2016-11-18 22:17:22 --> Loader Class Initialized
INFO - 2016-11-18 22:17:22 --> Helper loaded: url_helper
INFO - 2016-11-18 22:17:22 --> Helper loaded: form_helper
INFO - 2016-11-18 22:17:22 --> Database Driver Class Initialized
INFO - 2016-11-18 22:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:17:22 --> Controller Class Initialized
INFO - 2016-11-18 22:17:22 --> Model Class Initialized
INFO - 2016-11-18 22:17:22 --> Model Class Initialized
INFO - 2016-11-18 22:17:22 --> Model Class Initialized
INFO - 2016-11-18 22:17:22 --> Model Class Initialized
DEBUG - 2016-11-18 22:17:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-18 22:17:22 --> Model Class Initialized
INFO - 2016-11-18 22:17:22 --> Final output sent to browser
DEBUG - 2016-11-18 22:17:22 --> Total execution time: 0.7317
INFO - 2016-11-18 22:17:22 --> Config Class Initialized
INFO - 2016-11-18 22:17:22 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:17:22 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:17:22 --> Utf8 Class Initialized
INFO - 2016-11-18 22:17:22 --> URI Class Initialized
DEBUG - 2016-11-18 22:17:22 --> No URI present. Default controller set.
INFO - 2016-11-18 22:17:22 --> Router Class Initialized
INFO - 2016-11-18 22:17:22 --> Output Class Initialized
INFO - 2016-11-18 22:17:22 --> Security Class Initialized
DEBUG - 2016-11-18 22:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:17:22 --> Input Class Initialized
INFO - 2016-11-18 22:17:22 --> Language Class Initialized
INFO - 2016-11-18 22:17:22 --> Loader Class Initialized
INFO - 2016-11-18 22:17:22 --> Helper loaded: url_helper
INFO - 2016-11-18 22:17:22 --> Helper loaded: form_helper
INFO - 2016-11-18 22:17:22 --> Database Driver Class Initialized
INFO - 2016-11-18 22:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:17:23 --> Controller Class Initialized
INFO - 2016-11-18 22:17:23 --> Model Class Initialized
INFO - 2016-11-18 22:17:23 --> Model Class Initialized
INFO - 2016-11-18 22:17:23 --> Model Class Initialized
INFO - 2016-11-18 22:17:23 --> Model Class Initialized
INFO - 2016-11-18 22:17:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:17:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:17:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:17:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:17:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:17:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:17:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:17:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:17:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:17:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:17:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:17:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:17:23 --> Final output sent to browser
DEBUG - 2016-11-18 22:17:24 --> Total execution time: 1.3335
INFO - 2016-11-18 22:17:43 --> Config Class Initialized
INFO - 2016-11-18 22:17:43 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:17:43 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:17:43 --> Utf8 Class Initialized
INFO - 2016-11-18 22:17:43 --> URI Class Initialized
INFO - 2016-11-18 22:17:43 --> Router Class Initialized
INFO - 2016-11-18 22:17:43 --> Output Class Initialized
INFO - 2016-11-18 22:17:43 --> Security Class Initialized
DEBUG - 2016-11-18 22:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:17:43 --> Input Class Initialized
INFO - 2016-11-18 22:17:43 --> Language Class Initialized
INFO - 2016-11-18 22:17:43 --> Loader Class Initialized
INFO - 2016-11-18 22:17:43 --> Helper loaded: url_helper
INFO - 2016-11-18 22:17:43 --> Helper loaded: form_helper
INFO - 2016-11-18 22:17:43 --> Database Driver Class Initialized
INFO - 2016-11-18 22:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:17:43 --> Controller Class Initialized
INFO - 2016-11-18 22:17:43 --> Model Class Initialized
INFO - 2016-11-18 22:17:43 --> Form Validation Class Initialized
INFO - 2016-11-18 22:17:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 22:17:43 --> Final output sent to browser
DEBUG - 2016-11-18 22:17:44 --> Total execution time: 0.4482
INFO - 2016-11-18 22:17:55 --> Config Class Initialized
INFO - 2016-11-18 22:17:55 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:17:55 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:17:55 --> Utf8 Class Initialized
INFO - 2016-11-18 22:17:55 --> URI Class Initialized
INFO - 2016-11-18 22:17:55 --> Router Class Initialized
INFO - 2016-11-18 22:17:55 --> Output Class Initialized
INFO - 2016-11-18 22:17:55 --> Security Class Initialized
DEBUG - 2016-11-18 22:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:17:55 --> Input Class Initialized
INFO - 2016-11-18 22:17:55 --> Language Class Initialized
INFO - 2016-11-18 22:17:55 --> Loader Class Initialized
INFO - 2016-11-18 22:17:55 --> Helper loaded: url_helper
INFO - 2016-11-18 22:17:55 --> Helper loaded: form_helper
INFO - 2016-11-18 22:17:55 --> Database Driver Class Initialized
INFO - 2016-11-18 22:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:17:55 --> Controller Class Initialized
INFO - 2016-11-18 22:17:55 --> Model Class Initialized
INFO - 2016-11-18 22:17:55 --> Form Validation Class Initialized
INFO - 2016-11-18 22:17:55 --> Final output sent to browser
DEBUG - 2016-11-18 22:17:55 --> Total execution time: 0.4242
INFO - 2016-11-18 22:17:55 --> Config Class Initialized
INFO - 2016-11-18 22:17:56 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:17:56 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:17:56 --> Utf8 Class Initialized
INFO - 2016-11-18 22:17:56 --> URI Class Initialized
DEBUG - 2016-11-18 22:17:56 --> No URI present. Default controller set.
INFO - 2016-11-18 22:17:56 --> Router Class Initialized
INFO - 2016-11-18 22:17:56 --> Output Class Initialized
INFO - 2016-11-18 22:17:56 --> Security Class Initialized
DEBUG - 2016-11-18 22:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:17:56 --> Input Class Initialized
INFO - 2016-11-18 22:17:56 --> Language Class Initialized
INFO - 2016-11-18 22:17:56 --> Loader Class Initialized
INFO - 2016-11-18 22:17:56 --> Helper loaded: url_helper
INFO - 2016-11-18 22:17:56 --> Helper loaded: form_helper
INFO - 2016-11-18 22:17:56 --> Database Driver Class Initialized
INFO - 2016-11-18 22:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:17:56 --> Controller Class Initialized
INFO - 2016-11-18 22:17:56 --> Model Class Initialized
INFO - 2016-11-18 22:17:56 --> Model Class Initialized
INFO - 2016-11-18 22:17:56 --> Model Class Initialized
INFO - 2016-11-18 22:17:56 --> Model Class Initialized
INFO - 2016-11-18 22:17:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:17:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:17:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:17:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:17:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:17:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:17:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:17:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:17:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:17:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:17:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:17:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:17:56 --> Final output sent to browser
DEBUG - 2016-11-18 22:17:56 --> Total execution time: 0.7851
INFO - 2016-11-18 22:18:09 --> Config Class Initialized
INFO - 2016-11-18 22:18:09 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:18:09 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:18:09 --> Utf8 Class Initialized
INFO - 2016-11-18 22:18:09 --> URI Class Initialized
INFO - 2016-11-18 22:18:09 --> Router Class Initialized
INFO - 2016-11-18 22:18:09 --> Output Class Initialized
INFO - 2016-11-18 22:18:09 --> Security Class Initialized
DEBUG - 2016-11-18 22:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:18:09 --> Input Class Initialized
INFO - 2016-11-18 22:18:09 --> Language Class Initialized
INFO - 2016-11-18 22:18:09 --> Loader Class Initialized
INFO - 2016-11-18 22:18:09 --> Helper loaded: url_helper
INFO - 2016-11-18 22:18:09 --> Helper loaded: form_helper
INFO - 2016-11-18 22:18:09 --> Database Driver Class Initialized
INFO - 2016-11-18 22:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:18:09 --> Controller Class Initialized
INFO - 2016-11-18 22:18:09 --> Model Class Initialized
INFO - 2016-11-18 22:18:09 --> Form Validation Class Initialized
INFO - 2016-11-18 22:18:10 --> Final output sent to browser
DEBUG - 2016-11-18 22:18:10 --> Total execution time: 0.4139
INFO - 2016-11-18 22:18:10 --> Config Class Initialized
INFO - 2016-11-18 22:18:10 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:18:10 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:18:10 --> Utf8 Class Initialized
INFO - 2016-11-18 22:18:10 --> URI Class Initialized
DEBUG - 2016-11-18 22:18:10 --> No URI present. Default controller set.
INFO - 2016-11-18 22:18:10 --> Router Class Initialized
INFO - 2016-11-18 22:18:10 --> Output Class Initialized
INFO - 2016-11-18 22:18:10 --> Security Class Initialized
DEBUG - 2016-11-18 22:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:18:10 --> Input Class Initialized
INFO - 2016-11-18 22:18:10 --> Language Class Initialized
INFO - 2016-11-18 22:18:10 --> Loader Class Initialized
INFO - 2016-11-18 22:18:10 --> Helper loaded: url_helper
INFO - 2016-11-18 22:18:10 --> Helper loaded: form_helper
INFO - 2016-11-18 22:18:10 --> Database Driver Class Initialized
INFO - 2016-11-18 22:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:18:10 --> Controller Class Initialized
INFO - 2016-11-18 22:18:10 --> Model Class Initialized
INFO - 2016-11-18 22:18:10 --> Model Class Initialized
INFO - 2016-11-18 22:18:10 --> Model Class Initialized
INFO - 2016-11-18 22:18:10 --> Model Class Initialized
INFO - 2016-11-18 22:18:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:18:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:18:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:18:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:18:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:18:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:18:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:18:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:18:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:18:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:18:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:18:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:18:10 --> Final output sent to browser
DEBUG - 2016-11-18 22:18:10 --> Total execution time: 0.7874
INFO - 2016-11-18 22:21:44 --> Config Class Initialized
INFO - 2016-11-18 22:21:44 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:21:44 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:21:44 --> Utf8 Class Initialized
INFO - 2016-11-18 22:21:44 --> URI Class Initialized
DEBUG - 2016-11-18 22:21:44 --> No URI present. Default controller set.
INFO - 2016-11-18 22:21:44 --> Router Class Initialized
INFO - 2016-11-18 22:21:44 --> Output Class Initialized
INFO - 2016-11-18 22:21:45 --> Security Class Initialized
DEBUG - 2016-11-18 22:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:21:45 --> Input Class Initialized
INFO - 2016-11-18 22:21:45 --> Language Class Initialized
INFO - 2016-11-18 22:21:45 --> Loader Class Initialized
INFO - 2016-11-18 22:21:45 --> Helper loaded: url_helper
INFO - 2016-11-18 22:21:45 --> Helper loaded: form_helper
INFO - 2016-11-18 22:21:45 --> Database Driver Class Initialized
INFO - 2016-11-18 22:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:21:45 --> Controller Class Initialized
INFO - 2016-11-18 22:21:45 --> Model Class Initialized
INFO - 2016-11-18 22:21:45 --> Model Class Initialized
INFO - 2016-11-18 22:21:45 --> Model Class Initialized
INFO - 2016-11-18 22:21:45 --> Model Class Initialized
INFO - 2016-11-18 22:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:21:45 --> Final output sent to browser
DEBUG - 2016-11-18 22:21:45 --> Total execution time: 0.8429
INFO - 2016-11-18 22:21:53 --> Config Class Initialized
INFO - 2016-11-18 22:21:54 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:21:54 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:21:54 --> Utf8 Class Initialized
INFO - 2016-11-18 22:21:54 --> URI Class Initialized
INFO - 2016-11-18 22:21:54 --> Router Class Initialized
INFO - 2016-11-18 22:21:54 --> Output Class Initialized
INFO - 2016-11-18 22:21:54 --> Security Class Initialized
DEBUG - 2016-11-18 22:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:21:54 --> Input Class Initialized
INFO - 2016-11-18 22:21:54 --> Language Class Initialized
INFO - 2016-11-18 22:21:54 --> Loader Class Initialized
INFO - 2016-11-18 22:21:54 --> Helper loaded: url_helper
INFO - 2016-11-18 22:21:54 --> Helper loaded: form_helper
INFO - 2016-11-18 22:21:54 --> Database Driver Class Initialized
INFO - 2016-11-18 22:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:21:54 --> Controller Class Initialized
INFO - 2016-11-18 22:21:54 --> Model Class Initialized
INFO - 2016-11-18 22:21:54 --> Form Validation Class Initialized
ERROR - 2016-11-18 22:21:54 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:21:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:21:54 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:21:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:21:54 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:21:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:21:54 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:21:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-18 22:21:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:21:54 --> Final output sent to browser
DEBUG - 2016-11-18 22:21:54 --> Total execution time: 0.8124
INFO - 2016-11-18 22:21:56 --> Config Class Initialized
INFO - 2016-11-18 22:21:56 --> Config Class Initialized
INFO - 2016-11-18 22:21:56 --> Hooks Class Initialized
INFO - 2016-11-18 22:21:56 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:21:56 --> UTF-8 Support Enabled
DEBUG - 2016-11-18 22:21:56 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:21:56 --> Utf8 Class Initialized
INFO - 2016-11-18 22:21:56 --> Utf8 Class Initialized
INFO - 2016-11-18 22:21:56 --> URI Class Initialized
INFO - 2016-11-18 22:21:56 --> URI Class Initialized
INFO - 2016-11-18 22:21:56 --> Router Class Initialized
DEBUG - 2016-11-18 22:21:56 --> No URI present. Default controller set.
INFO - 2016-11-18 22:21:56 --> Output Class Initialized
INFO - 2016-11-18 22:21:56 --> Router Class Initialized
INFO - 2016-11-18 22:21:56 --> Security Class Initialized
INFO - 2016-11-18 22:21:56 --> Output Class Initialized
DEBUG - 2016-11-18 22:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:21:56 --> Security Class Initialized
INFO - 2016-11-18 22:21:56 --> Input Class Initialized
INFO - 2016-11-18 22:21:56 --> Language Class Initialized
DEBUG - 2016-11-18 22:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:21:56 --> Loader Class Initialized
INFO - 2016-11-18 22:21:56 --> Input Class Initialized
INFO - 2016-11-18 22:21:56 --> Language Class Initialized
INFO - 2016-11-18 22:21:56 --> Helper loaded: url_helper
INFO - 2016-11-18 22:21:56 --> Loader Class Initialized
INFO - 2016-11-18 22:21:56 --> Helper loaded: form_helper
INFO - 2016-11-18 22:21:56 --> Helper loaded: url_helper
INFO - 2016-11-18 22:21:56 --> Database Driver Class Initialized
INFO - 2016-11-18 22:21:56 --> Helper loaded: form_helper
INFO - 2016-11-18 22:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:21:56 --> Database Driver Class Initialized
INFO - 2016-11-18 22:21:56 --> Controller Class Initialized
INFO - 2016-11-18 22:21:56 --> Model Class Initialized
INFO - 2016-11-18 22:21:56 --> Form Validation Class Initialized
ERROR - 2016-11-18 22:21:57 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:21:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:21:57 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:21:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:21:57 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:21:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:21:57 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:21:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-18 22:21:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:21:57 --> Final output sent to browser
DEBUG - 2016-11-18 22:21:57 --> Total execution time: 1.1331
INFO - 2016-11-18 22:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:21:57 --> Controller Class Initialized
INFO - 2016-11-18 22:21:57 --> Model Class Initialized
INFO - 2016-11-18 22:21:57 --> Model Class Initialized
INFO - 2016-11-18 22:21:57 --> Model Class Initialized
INFO - 2016-11-18 22:21:57 --> Model Class Initialized
INFO - 2016-11-18 22:21:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:21:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:21:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:21:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:21:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:21:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:21:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:21:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:21:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:21:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:21:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:21:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:21:57 --> Final output sent to browser
DEBUG - 2016-11-18 22:21:57 --> Total execution time: 1.5752
INFO - 2016-11-18 22:22:03 --> Config Class Initialized
INFO - 2016-11-18 22:22:03 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:22:03 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:22:03 --> Utf8 Class Initialized
INFO - 2016-11-18 22:22:03 --> URI Class Initialized
DEBUG - 2016-11-18 22:22:03 --> No URI present. Default controller set.
INFO - 2016-11-18 22:22:03 --> Router Class Initialized
INFO - 2016-11-18 22:22:03 --> Output Class Initialized
INFO - 2016-11-18 22:22:03 --> Security Class Initialized
DEBUG - 2016-11-18 22:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:22:04 --> Input Class Initialized
INFO - 2016-11-18 22:22:04 --> Language Class Initialized
INFO - 2016-11-18 22:22:04 --> Loader Class Initialized
INFO - 2016-11-18 22:22:04 --> Helper loaded: url_helper
INFO - 2016-11-18 22:22:04 --> Helper loaded: form_helper
INFO - 2016-11-18 22:22:04 --> Database Driver Class Initialized
INFO - 2016-11-18 22:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:22:04 --> Controller Class Initialized
INFO - 2016-11-18 22:22:04 --> Model Class Initialized
INFO - 2016-11-18 22:22:04 --> Model Class Initialized
INFO - 2016-11-18 22:22:04 --> Model Class Initialized
INFO - 2016-11-18 22:22:04 --> Model Class Initialized
INFO - 2016-11-18 22:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:22:04 --> Final output sent to browser
DEBUG - 2016-11-18 22:22:04 --> Total execution time: 0.9415
INFO - 2016-11-18 22:22:18 --> Config Class Initialized
INFO - 2016-11-18 22:22:18 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:22:18 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:22:18 --> Utf8 Class Initialized
INFO - 2016-11-18 22:22:18 --> URI Class Initialized
DEBUG - 2016-11-18 22:22:18 --> No URI present. Default controller set.
INFO - 2016-11-18 22:22:18 --> Router Class Initialized
INFO - 2016-11-18 22:22:18 --> Output Class Initialized
INFO - 2016-11-18 22:22:18 --> Security Class Initialized
DEBUG - 2016-11-18 22:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:22:18 --> Input Class Initialized
INFO - 2016-11-18 22:22:18 --> Language Class Initialized
INFO - 2016-11-18 22:22:18 --> Loader Class Initialized
INFO - 2016-11-18 22:22:18 --> Helper loaded: url_helper
INFO - 2016-11-18 22:22:18 --> Helper loaded: form_helper
INFO - 2016-11-18 22:22:18 --> Database Driver Class Initialized
INFO - 2016-11-18 22:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:22:18 --> Controller Class Initialized
INFO - 2016-11-18 22:22:18 --> Model Class Initialized
INFO - 2016-11-18 22:22:18 --> Model Class Initialized
INFO - 2016-11-18 22:22:18 --> Model Class Initialized
INFO - 2016-11-18 22:22:18 --> Model Class Initialized
INFO - 2016-11-18 22:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:22:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:22:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:22:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:22:19 --> Final output sent to browser
DEBUG - 2016-11-18 22:22:19 --> Total execution time: 0.9732
INFO - 2016-11-18 22:22:26 --> Config Class Initialized
INFO - 2016-11-18 22:22:26 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:22:26 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:22:26 --> Utf8 Class Initialized
INFO - 2016-11-18 22:22:26 --> URI Class Initialized
INFO - 2016-11-18 22:22:26 --> Router Class Initialized
INFO - 2016-11-18 22:22:26 --> Output Class Initialized
INFO - 2016-11-18 22:22:26 --> Security Class Initialized
DEBUG - 2016-11-18 22:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:22:26 --> Input Class Initialized
INFO - 2016-11-18 22:22:26 --> Language Class Initialized
INFO - 2016-11-18 22:22:26 --> Loader Class Initialized
INFO - 2016-11-18 22:22:26 --> Helper loaded: url_helper
INFO - 2016-11-18 22:22:26 --> Helper loaded: form_helper
INFO - 2016-11-18 22:22:26 --> Database Driver Class Initialized
INFO - 2016-11-18 22:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:22:26 --> Controller Class Initialized
INFO - 2016-11-18 22:22:26 --> Model Class Initialized
INFO - 2016-11-18 22:22:26 --> Form Validation Class Initialized
ERROR - 2016-11-18 22:22:27 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:22:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:22:27 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:22:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:22:27 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:22:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:22:27 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:22:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-18 22:22:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:22:27 --> Final output sent to browser
DEBUG - 2016-11-18 22:22:27 --> Total execution time: 0.7476
INFO - 2016-11-18 22:22:48 --> Config Class Initialized
INFO - 2016-11-18 22:22:48 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:22:48 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:22:48 --> Utf8 Class Initialized
INFO - 2016-11-18 22:22:48 --> URI Class Initialized
DEBUG - 2016-11-18 22:22:48 --> No URI present. Default controller set.
INFO - 2016-11-18 22:22:48 --> Router Class Initialized
INFO - 2016-11-18 22:22:49 --> Output Class Initialized
INFO - 2016-11-18 22:22:49 --> Security Class Initialized
DEBUG - 2016-11-18 22:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:22:49 --> Input Class Initialized
INFO - 2016-11-18 22:22:49 --> Language Class Initialized
INFO - 2016-11-18 22:22:49 --> Loader Class Initialized
INFO - 2016-11-18 22:22:49 --> Helper loaded: url_helper
INFO - 2016-11-18 22:22:49 --> Helper loaded: form_helper
INFO - 2016-11-18 22:22:49 --> Database Driver Class Initialized
INFO - 2016-11-18 22:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:22:49 --> Controller Class Initialized
INFO - 2016-11-18 22:22:49 --> Model Class Initialized
INFO - 2016-11-18 22:22:49 --> Model Class Initialized
INFO - 2016-11-18 22:22:49 --> Model Class Initialized
INFO - 2016-11-18 22:22:49 --> Model Class Initialized
INFO - 2016-11-18 22:22:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:22:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:22:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:22:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:22:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:22:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:22:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:22:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:22:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:22:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:22:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:22:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:22:49 --> Final output sent to browser
DEBUG - 2016-11-18 22:22:49 --> Total execution time: 0.9706
INFO - 2016-11-18 22:22:56 --> Config Class Initialized
INFO - 2016-11-18 22:22:56 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:22:56 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:22:56 --> Utf8 Class Initialized
INFO - 2016-11-18 22:22:56 --> URI Class Initialized
INFO - 2016-11-18 22:22:56 --> Router Class Initialized
INFO - 2016-11-18 22:22:56 --> Output Class Initialized
INFO - 2016-11-18 22:22:56 --> Security Class Initialized
DEBUG - 2016-11-18 22:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:22:56 --> Input Class Initialized
INFO - 2016-11-18 22:22:56 --> Language Class Initialized
INFO - 2016-11-18 22:22:56 --> Loader Class Initialized
INFO - 2016-11-18 22:22:56 --> Helper loaded: url_helper
INFO - 2016-11-18 22:22:56 --> Helper loaded: form_helper
INFO - 2016-11-18 22:22:56 --> Database Driver Class Initialized
INFO - 2016-11-18 22:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:22:56 --> Controller Class Initialized
INFO - 2016-11-18 22:22:56 --> Model Class Initialized
INFO - 2016-11-18 22:22:56 --> Form Validation Class Initialized
ERROR - 2016-11-18 22:22:56 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:22:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:22:56 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:22:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:22:56 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:22:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:22:56 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:22:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-18 22:22:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:22:56 --> Final output sent to browser
DEBUG - 2016-11-18 22:22:56 --> Total execution time: 0.7254
INFO - 2016-11-18 22:22:57 --> Config Class Initialized
INFO - 2016-11-18 22:22:57 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:22:57 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:22:57 --> Utf8 Class Initialized
INFO - 2016-11-18 22:22:57 --> URI Class Initialized
DEBUG - 2016-11-18 22:22:57 --> No URI present. Default controller set.
INFO - 2016-11-18 22:22:57 --> Router Class Initialized
INFO - 2016-11-18 22:22:57 --> Output Class Initialized
INFO - 2016-11-18 22:22:57 --> Security Class Initialized
DEBUG - 2016-11-18 22:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:22:57 --> Input Class Initialized
INFO - 2016-11-18 22:22:57 --> Language Class Initialized
INFO - 2016-11-18 22:22:57 --> Loader Class Initialized
INFO - 2016-11-18 22:22:57 --> Helper loaded: url_helper
INFO - 2016-11-18 22:22:57 --> Helper loaded: form_helper
INFO - 2016-11-18 22:22:57 --> Database Driver Class Initialized
INFO - 2016-11-18 22:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:22:57 --> Controller Class Initialized
INFO - 2016-11-18 22:22:57 --> Model Class Initialized
INFO - 2016-11-18 22:22:57 --> Model Class Initialized
INFO - 2016-11-18 22:22:57 --> Model Class Initialized
INFO - 2016-11-18 22:22:57 --> Model Class Initialized
INFO - 2016-11-18 22:22:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:22:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:22:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:22:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:22:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:22:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:22:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:22:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:22:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:22:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:22:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:22:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:22:57 --> Final output sent to browser
DEBUG - 2016-11-18 22:22:57 --> Total execution time: 0.8291
INFO - 2016-11-18 22:23:11 --> Config Class Initialized
INFO - 2016-11-18 22:23:12 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:23:12 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:23:12 --> Utf8 Class Initialized
INFO - 2016-11-18 22:23:12 --> URI Class Initialized
INFO - 2016-11-18 22:23:12 --> Router Class Initialized
INFO - 2016-11-18 22:23:12 --> Output Class Initialized
INFO - 2016-11-18 22:23:12 --> Security Class Initialized
DEBUG - 2016-11-18 22:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:23:12 --> Input Class Initialized
INFO - 2016-11-18 22:23:12 --> Language Class Initialized
INFO - 2016-11-18 22:23:12 --> Loader Class Initialized
INFO - 2016-11-18 22:23:12 --> Helper loaded: url_helper
INFO - 2016-11-18 22:23:12 --> Helper loaded: form_helper
INFO - 2016-11-18 22:23:12 --> Database Driver Class Initialized
INFO - 2016-11-18 22:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:23:12 --> Controller Class Initialized
INFO - 2016-11-18 22:23:12 --> Model Class Initialized
INFO - 2016-11-18 22:23:12 --> Form Validation Class Initialized
INFO - 2016-11-18 22:23:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-18 22:23:12 --> Final output sent to browser
DEBUG - 2016-11-18 22:23:12 --> Total execution time: 0.5541
INFO - 2016-11-18 22:27:55 --> Config Class Initialized
INFO - 2016-11-18 22:27:55 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:27:55 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:27:55 --> Utf8 Class Initialized
INFO - 2016-11-18 22:27:55 --> URI Class Initialized
DEBUG - 2016-11-18 22:27:55 --> No URI present. Default controller set.
INFO - 2016-11-18 22:27:55 --> Router Class Initialized
INFO - 2016-11-18 22:27:55 --> Output Class Initialized
INFO - 2016-11-18 22:27:55 --> Security Class Initialized
DEBUG - 2016-11-18 22:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:27:55 --> Input Class Initialized
INFO - 2016-11-18 22:27:55 --> Language Class Initialized
INFO - 2016-11-18 22:27:55 --> Loader Class Initialized
INFO - 2016-11-18 22:27:55 --> Helper loaded: url_helper
INFO - 2016-11-18 22:27:55 --> Helper loaded: form_helper
INFO - 2016-11-18 22:27:55 --> Database Driver Class Initialized
INFO - 2016-11-18 22:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:27:55 --> Controller Class Initialized
INFO - 2016-11-18 22:27:55 --> Model Class Initialized
INFO - 2016-11-18 22:27:55 --> Model Class Initialized
INFO - 2016-11-18 22:27:55 --> Model Class Initialized
INFO - 2016-11-18 22:27:55 --> Model Class Initialized
INFO - 2016-11-18 22:27:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:27:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:27:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:27:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:27:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:27:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:27:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:27:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:27:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:27:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:27:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:27:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:27:56 --> Final output sent to browser
DEBUG - 2016-11-18 22:27:56 --> Total execution time: 0.8922
INFO - 2016-11-18 22:28:35 --> Config Class Initialized
INFO - 2016-11-18 22:28:35 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:28:35 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:28:35 --> Utf8 Class Initialized
INFO - 2016-11-18 22:28:35 --> URI Class Initialized
DEBUG - 2016-11-18 22:28:35 --> No URI present. Default controller set.
INFO - 2016-11-18 22:28:35 --> Router Class Initialized
INFO - 2016-11-18 22:28:35 --> Output Class Initialized
INFO - 2016-11-18 22:28:35 --> Security Class Initialized
DEBUG - 2016-11-18 22:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:28:35 --> Input Class Initialized
INFO - 2016-11-18 22:28:35 --> Language Class Initialized
INFO - 2016-11-18 22:28:35 --> Loader Class Initialized
INFO - 2016-11-18 22:28:35 --> Helper loaded: url_helper
INFO - 2016-11-18 22:28:35 --> Helper loaded: form_helper
INFO - 2016-11-18 22:28:35 --> Database Driver Class Initialized
INFO - 2016-11-18 22:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:28:35 --> Controller Class Initialized
INFO - 2016-11-18 22:28:35 --> Model Class Initialized
INFO - 2016-11-18 22:28:35 --> Model Class Initialized
INFO - 2016-11-18 22:28:35 --> Model Class Initialized
INFO - 2016-11-18 22:28:35 --> Model Class Initialized
INFO - 2016-11-18 22:28:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:28:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:28:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:28:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:28:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:28:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:28:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:28:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:28:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:28:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:28:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:28:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:28:36 --> Final output sent to browser
DEBUG - 2016-11-18 22:28:36 --> Total execution time: 0.9423
INFO - 2016-11-18 22:28:50 --> Config Class Initialized
INFO - 2016-11-18 22:28:50 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:28:50 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:28:50 --> Utf8 Class Initialized
INFO - 2016-11-18 22:28:50 --> URI Class Initialized
DEBUG - 2016-11-18 22:28:50 --> No URI present. Default controller set.
INFO - 2016-11-18 22:28:50 --> Router Class Initialized
INFO - 2016-11-18 22:28:50 --> Output Class Initialized
INFO - 2016-11-18 22:28:50 --> Security Class Initialized
DEBUG - 2016-11-18 22:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:28:50 --> Input Class Initialized
INFO - 2016-11-18 22:28:50 --> Language Class Initialized
INFO - 2016-11-18 22:28:50 --> Loader Class Initialized
INFO - 2016-11-18 22:28:51 --> Helper loaded: url_helper
INFO - 2016-11-18 22:28:51 --> Helper loaded: form_helper
INFO - 2016-11-18 22:28:51 --> Database Driver Class Initialized
INFO - 2016-11-18 22:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:28:51 --> Controller Class Initialized
INFO - 2016-11-18 22:28:51 --> Model Class Initialized
INFO - 2016-11-18 22:28:51 --> Model Class Initialized
INFO - 2016-11-18 22:28:51 --> Model Class Initialized
INFO - 2016-11-18 22:28:51 --> Model Class Initialized
INFO - 2016-11-18 22:28:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:28:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:28:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:28:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:28:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:28:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:28:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:28:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:28:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:28:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:28:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:28:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:28:51 --> Final output sent to browser
DEBUG - 2016-11-18 22:28:51 --> Total execution time: 0.9483
INFO - 2016-11-18 22:29:08 --> Config Class Initialized
INFO - 2016-11-18 22:29:08 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:29:08 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:29:08 --> Utf8 Class Initialized
INFO - 2016-11-18 22:29:08 --> URI Class Initialized
DEBUG - 2016-11-18 22:29:08 --> No URI present. Default controller set.
INFO - 2016-11-18 22:29:09 --> Router Class Initialized
INFO - 2016-11-18 22:29:09 --> Output Class Initialized
INFO - 2016-11-18 22:29:09 --> Security Class Initialized
DEBUG - 2016-11-18 22:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:29:09 --> Input Class Initialized
INFO - 2016-11-18 22:29:09 --> Language Class Initialized
INFO - 2016-11-18 22:29:09 --> Loader Class Initialized
INFO - 2016-11-18 22:29:09 --> Helper loaded: url_helper
INFO - 2016-11-18 22:29:09 --> Helper loaded: form_helper
INFO - 2016-11-18 22:29:09 --> Database Driver Class Initialized
INFO - 2016-11-18 22:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:29:09 --> Controller Class Initialized
INFO - 2016-11-18 22:29:09 --> Model Class Initialized
INFO - 2016-11-18 22:29:09 --> Model Class Initialized
INFO - 2016-11-18 22:29:09 --> Model Class Initialized
INFO - 2016-11-18 22:29:09 --> Model Class Initialized
INFO - 2016-11-18 22:29:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:29:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:29:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:29:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:29:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:29:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:29:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:29:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:29:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:29:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:29:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:29:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:29:09 --> Final output sent to browser
DEBUG - 2016-11-18 22:29:09 --> Total execution time: 0.8894
INFO - 2016-11-18 22:29:19 --> Config Class Initialized
INFO - 2016-11-18 22:29:19 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:29:19 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:29:19 --> Utf8 Class Initialized
INFO - 2016-11-18 22:29:19 --> URI Class Initialized
INFO - 2016-11-18 22:29:19 --> Router Class Initialized
INFO - 2016-11-18 22:29:19 --> Output Class Initialized
INFO - 2016-11-18 22:29:19 --> Security Class Initialized
DEBUG - 2016-11-18 22:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:29:19 --> Input Class Initialized
INFO - 2016-11-18 22:29:19 --> Language Class Initialized
INFO - 2016-11-18 22:29:20 --> Loader Class Initialized
INFO - 2016-11-18 22:29:20 --> Helper loaded: url_helper
INFO - 2016-11-18 22:29:20 --> Helper loaded: form_helper
INFO - 2016-11-18 22:29:20 --> Database Driver Class Initialized
INFO - 2016-11-18 22:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:29:20 --> Controller Class Initialized
INFO - 2016-11-18 22:29:20 --> Model Class Initialized
INFO - 2016-11-18 22:29:20 --> Form Validation Class Initialized
ERROR - 2016-11-18 22:29:20 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:29:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:29:20 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:29:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:29:20 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:29:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:29:20 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:29:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-18 22:29:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:29:20 --> Final output sent to browser
DEBUG - 2016-11-18 22:29:20 --> Total execution time: 0.7162
INFO - 2016-11-18 22:29:20 --> Config Class Initialized
INFO - 2016-11-18 22:29:20 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:29:20 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:29:20 --> Utf8 Class Initialized
INFO - 2016-11-18 22:29:20 --> URI Class Initialized
DEBUG - 2016-11-18 22:29:20 --> No URI present. Default controller set.
INFO - 2016-11-18 22:29:20 --> Router Class Initialized
INFO - 2016-11-18 22:29:20 --> Output Class Initialized
INFO - 2016-11-18 22:29:20 --> Security Class Initialized
DEBUG - 2016-11-18 22:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:29:20 --> Input Class Initialized
INFO - 2016-11-18 22:29:20 --> Language Class Initialized
INFO - 2016-11-18 22:29:20 --> Loader Class Initialized
INFO - 2016-11-18 22:29:20 --> Helper loaded: url_helper
INFO - 2016-11-18 22:29:20 --> Helper loaded: form_helper
INFO - 2016-11-18 22:29:20 --> Database Driver Class Initialized
INFO - 2016-11-18 22:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:29:20 --> Controller Class Initialized
INFO - 2016-11-18 22:29:20 --> Model Class Initialized
INFO - 2016-11-18 22:29:20 --> Model Class Initialized
INFO - 2016-11-18 22:29:21 --> Model Class Initialized
INFO - 2016-11-18 22:29:21 --> Model Class Initialized
INFO - 2016-11-18 22:29:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:29:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:29:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:29:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:29:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:29:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:29:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:29:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:29:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:29:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:29:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:29:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:29:21 --> Final output sent to browser
DEBUG - 2016-11-18 22:29:21 --> Total execution time: 0.8119
INFO - 2016-11-18 22:29:59 --> Config Class Initialized
INFO - 2016-11-18 22:29:59 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:29:59 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:29:59 --> Utf8 Class Initialized
INFO - 2016-11-18 22:29:59 --> URI Class Initialized
DEBUG - 2016-11-18 22:29:59 --> No URI present. Default controller set.
INFO - 2016-11-18 22:29:59 --> Router Class Initialized
INFO - 2016-11-18 22:29:59 --> Output Class Initialized
INFO - 2016-11-18 22:29:59 --> Security Class Initialized
DEBUG - 2016-11-18 22:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:29:59 --> Input Class Initialized
INFO - 2016-11-18 22:29:59 --> Language Class Initialized
INFO - 2016-11-18 22:29:59 --> Loader Class Initialized
INFO - 2016-11-18 22:30:00 --> Helper loaded: url_helper
INFO - 2016-11-18 22:30:00 --> Helper loaded: form_helper
INFO - 2016-11-18 22:30:00 --> Database Driver Class Initialized
INFO - 2016-11-18 22:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:30:00 --> Controller Class Initialized
INFO - 2016-11-18 22:30:00 --> Model Class Initialized
INFO - 2016-11-18 22:30:00 --> Model Class Initialized
INFO - 2016-11-18 22:30:00 --> Model Class Initialized
INFO - 2016-11-18 22:30:00 --> Model Class Initialized
INFO - 2016-11-18 22:30:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:30:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:30:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:30:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:30:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:30:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:30:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:30:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:30:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:30:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:30:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:30:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:30:00 --> Final output sent to browser
DEBUG - 2016-11-18 22:30:00 --> Total execution time: 0.9016
INFO - 2016-11-18 22:30:07 --> Config Class Initialized
INFO - 2016-11-18 22:30:07 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:30:07 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:30:07 --> Utf8 Class Initialized
INFO - 2016-11-18 22:30:07 --> URI Class Initialized
INFO - 2016-11-18 22:30:08 --> Router Class Initialized
INFO - 2016-11-18 22:30:08 --> Output Class Initialized
INFO - 2016-11-18 22:30:08 --> Security Class Initialized
DEBUG - 2016-11-18 22:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:30:08 --> Input Class Initialized
INFO - 2016-11-18 22:30:08 --> Language Class Initialized
INFO - 2016-11-18 22:30:08 --> Loader Class Initialized
INFO - 2016-11-18 22:30:08 --> Helper loaded: url_helper
INFO - 2016-11-18 22:30:08 --> Helper loaded: form_helper
INFO - 2016-11-18 22:30:08 --> Database Driver Class Initialized
INFO - 2016-11-18 22:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:30:08 --> Controller Class Initialized
INFO - 2016-11-18 22:30:08 --> Model Class Initialized
INFO - 2016-11-18 22:30:08 --> Form Validation Class Initialized
ERROR - 2016-11-18 22:30:08 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:30:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:30:08 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:30:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:30:08 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:30:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:30:08 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:30:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-18 22:30:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:30:08 --> Final output sent to browser
DEBUG - 2016-11-18 22:30:08 --> Total execution time: 0.6740
INFO - 2016-11-18 22:30:08 --> Config Class Initialized
INFO - 2016-11-18 22:30:08 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:30:08 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:30:08 --> Utf8 Class Initialized
INFO - 2016-11-18 22:30:08 --> URI Class Initialized
DEBUG - 2016-11-18 22:30:08 --> No URI present. Default controller set.
INFO - 2016-11-18 22:30:08 --> Router Class Initialized
INFO - 2016-11-18 22:30:08 --> Output Class Initialized
INFO - 2016-11-18 22:30:08 --> Security Class Initialized
DEBUG - 2016-11-18 22:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:30:08 --> Input Class Initialized
INFO - 2016-11-18 22:30:08 --> Language Class Initialized
INFO - 2016-11-18 22:30:08 --> Loader Class Initialized
INFO - 2016-11-18 22:30:08 --> Helper loaded: url_helper
INFO - 2016-11-18 22:30:08 --> Helper loaded: form_helper
INFO - 2016-11-18 22:30:08 --> Database Driver Class Initialized
INFO - 2016-11-18 22:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:30:09 --> Controller Class Initialized
INFO - 2016-11-18 22:30:09 --> Model Class Initialized
INFO - 2016-11-18 22:30:09 --> Model Class Initialized
INFO - 2016-11-18 22:30:09 --> Model Class Initialized
INFO - 2016-11-18 22:30:09 --> Model Class Initialized
INFO - 2016-11-18 22:30:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:30:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:30:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:30:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:30:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:30:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:30:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:30:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:30:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:30:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:30:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:30:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:30:09 --> Final output sent to browser
DEBUG - 2016-11-18 22:30:09 --> Total execution time: 1.0228
INFO - 2016-11-18 22:30:16 --> Config Class Initialized
INFO - 2016-11-18 22:30:16 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:30:16 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:30:16 --> Utf8 Class Initialized
INFO - 2016-11-18 22:30:16 --> URI Class Initialized
INFO - 2016-11-18 22:30:16 --> Router Class Initialized
INFO - 2016-11-18 22:30:17 --> Output Class Initialized
INFO - 2016-11-18 22:30:17 --> Security Class Initialized
DEBUG - 2016-11-18 22:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:30:17 --> Input Class Initialized
INFO - 2016-11-18 22:30:17 --> Language Class Initialized
INFO - 2016-11-18 22:30:17 --> Loader Class Initialized
INFO - 2016-11-18 22:30:17 --> Helper loaded: url_helper
INFO - 2016-11-18 22:30:17 --> Helper loaded: form_helper
INFO - 2016-11-18 22:30:17 --> Database Driver Class Initialized
INFO - 2016-11-18 22:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:30:17 --> Controller Class Initialized
INFO - 2016-11-18 22:30:17 --> Model Class Initialized
INFO - 2016-11-18 22:30:17 --> Form Validation Class Initialized
ERROR - 2016-11-18 22:30:17 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:30:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:30:17 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:30:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:30:17 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:30:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:30:17 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:30:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-18 22:30:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:30:17 --> Final output sent to browser
DEBUG - 2016-11-18 22:30:17 --> Total execution time: 0.9187
INFO - 2016-11-18 22:30:17 --> Config Class Initialized
INFO - 2016-11-18 22:30:17 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:30:17 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:30:17 --> Utf8 Class Initialized
INFO - 2016-11-18 22:30:17 --> URI Class Initialized
DEBUG - 2016-11-18 22:30:17 --> No URI present. Default controller set.
INFO - 2016-11-18 22:30:18 --> Router Class Initialized
INFO - 2016-11-18 22:30:18 --> Output Class Initialized
INFO - 2016-11-18 22:30:18 --> Security Class Initialized
DEBUG - 2016-11-18 22:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:30:18 --> Input Class Initialized
INFO - 2016-11-18 22:30:18 --> Language Class Initialized
INFO - 2016-11-18 22:30:18 --> Loader Class Initialized
INFO - 2016-11-18 22:30:18 --> Helper loaded: url_helper
INFO - 2016-11-18 22:30:18 --> Helper loaded: form_helper
INFO - 2016-11-18 22:30:18 --> Database Driver Class Initialized
INFO - 2016-11-18 22:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:30:18 --> Controller Class Initialized
INFO - 2016-11-18 22:30:18 --> Model Class Initialized
INFO - 2016-11-18 22:30:18 --> Model Class Initialized
INFO - 2016-11-18 22:30:18 --> Model Class Initialized
INFO - 2016-11-18 22:30:18 --> Model Class Initialized
INFO - 2016-11-18 22:30:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:30:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:30:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:30:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:30:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:30:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:30:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:30:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:30:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:30:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:30:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:30:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:30:18 --> Final output sent to browser
DEBUG - 2016-11-18 22:30:18 --> Total execution time: 0.8590
INFO - 2016-11-18 22:32:54 --> Config Class Initialized
INFO - 2016-11-18 22:32:54 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:32:54 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:32:54 --> Utf8 Class Initialized
INFO - 2016-11-18 22:32:54 --> URI Class Initialized
DEBUG - 2016-11-18 22:32:54 --> No URI present. Default controller set.
INFO - 2016-11-18 22:32:54 --> Router Class Initialized
INFO - 2016-11-18 22:32:54 --> Output Class Initialized
INFO - 2016-11-18 22:32:54 --> Security Class Initialized
DEBUG - 2016-11-18 22:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:32:54 --> Input Class Initialized
INFO - 2016-11-18 22:32:54 --> Language Class Initialized
INFO - 2016-11-18 22:32:55 --> Loader Class Initialized
INFO - 2016-11-18 22:32:55 --> Helper loaded: url_helper
INFO - 2016-11-18 22:32:55 --> Helper loaded: form_helper
INFO - 2016-11-18 22:32:55 --> Database Driver Class Initialized
INFO - 2016-11-18 22:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:32:55 --> Controller Class Initialized
INFO - 2016-11-18 22:32:55 --> Model Class Initialized
INFO - 2016-11-18 22:32:55 --> Model Class Initialized
INFO - 2016-11-18 22:32:55 --> Model Class Initialized
INFO - 2016-11-18 22:32:55 --> Model Class Initialized
INFO - 2016-11-18 22:32:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:32:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:32:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:32:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:32:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:32:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:32:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:32:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:32:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:32:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:32:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:32:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:32:55 --> Final output sent to browser
DEBUG - 2016-11-18 22:32:55 --> Total execution time: 0.8686
INFO - 2016-11-18 22:33:23 --> Config Class Initialized
INFO - 2016-11-18 22:33:24 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:33:24 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:33:24 --> Utf8 Class Initialized
INFO - 2016-11-18 22:33:24 --> URI Class Initialized
DEBUG - 2016-11-18 22:33:24 --> No URI present. Default controller set.
INFO - 2016-11-18 22:33:24 --> Router Class Initialized
INFO - 2016-11-18 22:33:24 --> Output Class Initialized
INFO - 2016-11-18 22:33:24 --> Security Class Initialized
DEBUG - 2016-11-18 22:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:33:24 --> Input Class Initialized
INFO - 2016-11-18 22:33:24 --> Language Class Initialized
INFO - 2016-11-18 22:33:24 --> Loader Class Initialized
INFO - 2016-11-18 22:33:24 --> Helper loaded: url_helper
INFO - 2016-11-18 22:33:24 --> Helper loaded: form_helper
INFO - 2016-11-18 22:33:24 --> Database Driver Class Initialized
INFO - 2016-11-18 22:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:33:24 --> Controller Class Initialized
INFO - 2016-11-18 22:33:24 --> Model Class Initialized
INFO - 2016-11-18 22:33:24 --> Model Class Initialized
INFO - 2016-11-18 22:33:24 --> Model Class Initialized
INFO - 2016-11-18 22:33:24 --> Model Class Initialized
INFO - 2016-11-18 22:33:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:33:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:33:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:33:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:33:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:33:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:33:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:33:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:33:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:33:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:33:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:33:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:33:24 --> Final output sent to browser
DEBUG - 2016-11-18 22:33:24 --> Total execution time: 0.9325
INFO - 2016-11-18 22:33:35 --> Config Class Initialized
INFO - 2016-11-18 22:33:35 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:33:35 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:33:35 --> Utf8 Class Initialized
INFO - 2016-11-18 22:33:35 --> URI Class Initialized
INFO - 2016-11-18 22:33:35 --> Router Class Initialized
INFO - 2016-11-18 22:33:35 --> Output Class Initialized
INFO - 2016-11-18 22:33:35 --> Security Class Initialized
DEBUG - 2016-11-18 22:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:33:36 --> Input Class Initialized
INFO - 2016-11-18 22:33:36 --> Language Class Initialized
INFO - 2016-11-18 22:33:36 --> Loader Class Initialized
INFO - 2016-11-18 22:33:36 --> Helper loaded: url_helper
INFO - 2016-11-18 22:33:36 --> Helper loaded: form_helper
INFO - 2016-11-18 22:33:36 --> Database Driver Class Initialized
INFO - 2016-11-18 22:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:33:36 --> Controller Class Initialized
INFO - 2016-11-18 22:33:36 --> Model Class Initialized
INFO - 2016-11-18 22:33:36 --> Form Validation Class Initialized
ERROR - 2016-11-18 22:33:36 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:33:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:33:36 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:33:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:33:36 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:33:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:33:36 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:33:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-18 22:33:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:33:36 --> Final output sent to browser
DEBUG - 2016-11-18 22:33:36 --> Total execution time: 0.6974
INFO - 2016-11-18 22:33:36 --> Config Class Initialized
INFO - 2016-11-18 22:33:36 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:33:36 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:33:36 --> Utf8 Class Initialized
INFO - 2016-11-18 22:33:36 --> URI Class Initialized
DEBUG - 2016-11-18 22:33:36 --> No URI present. Default controller set.
INFO - 2016-11-18 22:33:36 --> Router Class Initialized
INFO - 2016-11-18 22:33:36 --> Output Class Initialized
INFO - 2016-11-18 22:33:36 --> Security Class Initialized
DEBUG - 2016-11-18 22:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:33:36 --> Input Class Initialized
INFO - 2016-11-18 22:33:36 --> Language Class Initialized
INFO - 2016-11-18 22:33:36 --> Loader Class Initialized
INFO - 2016-11-18 22:33:36 --> Helper loaded: url_helper
INFO - 2016-11-18 22:33:36 --> Helper loaded: form_helper
INFO - 2016-11-18 22:33:36 --> Database Driver Class Initialized
INFO - 2016-11-18 22:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:33:36 --> Controller Class Initialized
INFO - 2016-11-18 22:33:36 --> Model Class Initialized
INFO - 2016-11-18 22:33:37 --> Model Class Initialized
INFO - 2016-11-18 22:33:37 --> Model Class Initialized
INFO - 2016-11-18 22:33:37 --> Model Class Initialized
INFO - 2016-11-18 22:33:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:33:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:33:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:33:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:33:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:33:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:33:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:33:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:33:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:33:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:33:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:33:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:33:37 --> Final output sent to browser
DEBUG - 2016-11-18 22:33:37 --> Total execution time: 0.8202
INFO - 2016-11-18 22:34:30 --> Config Class Initialized
INFO - 2016-11-18 22:34:30 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:34:30 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:34:30 --> Utf8 Class Initialized
INFO - 2016-11-18 22:34:30 --> URI Class Initialized
DEBUG - 2016-11-18 22:34:30 --> No URI present. Default controller set.
INFO - 2016-11-18 22:34:30 --> Router Class Initialized
INFO - 2016-11-18 22:34:30 --> Output Class Initialized
INFO - 2016-11-18 22:34:30 --> Security Class Initialized
DEBUG - 2016-11-18 22:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:34:30 --> Input Class Initialized
INFO - 2016-11-18 22:34:30 --> Language Class Initialized
INFO - 2016-11-18 22:34:30 --> Loader Class Initialized
INFO - 2016-11-18 22:34:30 --> Helper loaded: url_helper
INFO - 2016-11-18 22:34:30 --> Helper loaded: form_helper
INFO - 2016-11-18 22:34:30 --> Database Driver Class Initialized
INFO - 2016-11-18 22:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:34:30 --> Controller Class Initialized
INFO - 2016-11-18 22:34:30 --> Model Class Initialized
INFO - 2016-11-18 22:34:30 --> Model Class Initialized
INFO - 2016-11-18 22:34:30 --> Model Class Initialized
INFO - 2016-11-18 22:34:30 --> Model Class Initialized
INFO - 2016-11-18 22:34:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:34:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:34:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:34:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:34:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:34:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:34:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:34:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:34:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:34:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:34:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:34:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:34:30 --> Final output sent to browser
DEBUG - 2016-11-18 22:34:31 --> Total execution time: 0.9606
INFO - 2016-11-18 22:34:45 --> Config Class Initialized
INFO - 2016-11-18 22:34:45 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:34:45 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:34:45 --> Utf8 Class Initialized
INFO - 2016-11-18 22:34:45 --> URI Class Initialized
INFO - 2016-11-18 22:34:45 --> Router Class Initialized
INFO - 2016-11-18 22:34:45 --> Output Class Initialized
INFO - 2016-11-18 22:34:45 --> Security Class Initialized
DEBUG - 2016-11-18 22:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:34:45 --> Input Class Initialized
INFO - 2016-11-18 22:34:45 --> Language Class Initialized
INFO - 2016-11-18 22:34:45 --> Loader Class Initialized
INFO - 2016-11-18 22:34:45 --> Helper loaded: url_helper
INFO - 2016-11-18 22:34:45 --> Helper loaded: form_helper
INFO - 2016-11-18 22:34:45 --> Database Driver Class Initialized
INFO - 2016-11-18 22:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:34:45 --> Controller Class Initialized
INFO - 2016-11-18 22:34:46 --> Model Class Initialized
INFO - 2016-11-18 22:34:46 --> Form Validation Class Initialized
ERROR - 2016-11-18 22:34:46 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:34:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:34:46 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:34:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:34:46 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:34:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:34:46 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:34:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-18 22:34:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:34:46 --> Final output sent to browser
DEBUG - 2016-11-18 22:34:46 --> Total execution time: 0.8713
INFO - 2016-11-18 22:34:46 --> Config Class Initialized
INFO - 2016-11-18 22:34:46 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:34:46 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:34:46 --> Utf8 Class Initialized
INFO - 2016-11-18 22:34:46 --> URI Class Initialized
DEBUG - 2016-11-18 22:34:46 --> No URI present. Default controller set.
INFO - 2016-11-18 22:34:46 --> Router Class Initialized
INFO - 2016-11-18 22:34:46 --> Output Class Initialized
INFO - 2016-11-18 22:34:46 --> Security Class Initialized
DEBUG - 2016-11-18 22:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:34:46 --> Input Class Initialized
INFO - 2016-11-18 22:34:46 --> Language Class Initialized
INFO - 2016-11-18 22:34:46 --> Loader Class Initialized
INFO - 2016-11-18 22:34:46 --> Helper loaded: url_helper
INFO - 2016-11-18 22:34:46 --> Helper loaded: form_helper
INFO - 2016-11-18 22:34:47 --> Database Driver Class Initialized
INFO - 2016-11-18 22:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:34:47 --> Controller Class Initialized
INFO - 2016-11-18 22:34:47 --> Model Class Initialized
INFO - 2016-11-18 22:34:47 --> Model Class Initialized
INFO - 2016-11-18 22:34:47 --> Model Class Initialized
INFO - 2016-11-18 22:34:47 --> Model Class Initialized
INFO - 2016-11-18 22:34:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:34:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:34:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:34:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:34:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:34:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:34:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:34:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:34:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:34:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:34:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:34:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:34:47 --> Final output sent to browser
DEBUG - 2016-11-18 22:34:47 --> Total execution time: 0.9608
INFO - 2016-11-18 22:35:26 --> Config Class Initialized
INFO - 2016-11-18 22:35:26 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:35:26 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:35:26 --> Utf8 Class Initialized
INFO - 2016-11-18 22:35:26 --> URI Class Initialized
INFO - 2016-11-18 22:35:26 --> Router Class Initialized
INFO - 2016-11-18 22:35:26 --> Output Class Initialized
INFO - 2016-11-18 22:35:26 --> Security Class Initialized
DEBUG - 2016-11-18 22:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:35:26 --> Input Class Initialized
INFO - 2016-11-18 22:35:26 --> Language Class Initialized
INFO - 2016-11-18 22:35:26 --> Loader Class Initialized
INFO - 2016-11-18 22:35:26 --> Helper loaded: url_helper
INFO - 2016-11-18 22:35:26 --> Helper loaded: form_helper
INFO - 2016-11-18 22:35:26 --> Database Driver Class Initialized
INFO - 2016-11-18 22:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:35:26 --> Controller Class Initialized
INFO - 2016-11-18 22:35:27 --> Model Class Initialized
INFO - 2016-11-18 22:35:27 --> Form Validation Class Initialized
ERROR - 2016-11-18 22:35:27 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:35:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:35:27 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:35:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:35:27 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:35:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:35:27 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:35:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-18 22:35:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:35:27 --> Final output sent to browser
DEBUG - 2016-11-18 22:35:27 --> Total execution time: 0.8517
INFO - 2016-11-18 22:35:27 --> Config Class Initialized
INFO - 2016-11-18 22:35:27 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:35:27 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:35:27 --> Utf8 Class Initialized
INFO - 2016-11-18 22:35:27 --> URI Class Initialized
DEBUG - 2016-11-18 22:35:27 --> No URI present. Default controller set.
INFO - 2016-11-18 22:35:27 --> Router Class Initialized
INFO - 2016-11-18 22:35:27 --> Output Class Initialized
INFO - 2016-11-18 22:35:27 --> Security Class Initialized
DEBUG - 2016-11-18 22:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:35:27 --> Input Class Initialized
INFO - 2016-11-18 22:35:27 --> Language Class Initialized
INFO - 2016-11-18 22:35:27 --> Loader Class Initialized
INFO - 2016-11-18 22:35:27 --> Helper loaded: url_helper
INFO - 2016-11-18 22:35:27 --> Helper loaded: form_helper
INFO - 2016-11-18 22:35:27 --> Database Driver Class Initialized
INFO - 2016-11-18 22:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:35:27 --> Controller Class Initialized
INFO - 2016-11-18 22:35:27 --> Model Class Initialized
INFO - 2016-11-18 22:35:27 --> Model Class Initialized
INFO - 2016-11-18 22:35:28 --> Model Class Initialized
INFO - 2016-11-18 22:35:28 --> Model Class Initialized
INFO - 2016-11-18 22:35:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:35:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:35:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:35:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:35:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:35:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:35:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:35:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:35:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:35:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:35:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:35:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:35:28 --> Final output sent to browser
DEBUG - 2016-11-18 22:35:28 --> Total execution time: 0.8572
INFO - 2016-11-18 22:35:42 --> Config Class Initialized
INFO - 2016-11-18 22:35:42 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:35:42 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:35:42 --> Utf8 Class Initialized
INFO - 2016-11-18 22:35:42 --> URI Class Initialized
INFO - 2016-11-18 22:35:42 --> Router Class Initialized
INFO - 2016-11-18 22:35:42 --> Output Class Initialized
INFO - 2016-11-18 22:35:42 --> Security Class Initialized
DEBUG - 2016-11-18 22:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:35:43 --> Input Class Initialized
INFO - 2016-11-18 22:35:43 --> Language Class Initialized
INFO - 2016-11-18 22:35:43 --> Loader Class Initialized
INFO - 2016-11-18 22:35:43 --> Helper loaded: url_helper
INFO - 2016-11-18 22:35:43 --> Helper loaded: form_helper
INFO - 2016-11-18 22:35:43 --> Database Driver Class Initialized
INFO - 2016-11-18 22:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:35:43 --> Controller Class Initialized
INFO - 2016-11-18 22:35:43 --> Model Class Initialized
INFO - 2016-11-18 22:35:43 --> Form Validation Class Initialized
ERROR - 2016-11-18 22:35:43 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:35:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:35:43 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:35:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:35:43 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:35:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:35:43 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-18 22:35:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-18 22:35:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:35:43 --> Final output sent to browser
DEBUG - 2016-11-18 22:35:43 --> Total execution time: 1.0428
INFO - 2016-11-18 22:35:43 --> Config Class Initialized
INFO - 2016-11-18 22:35:43 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:35:44 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:35:44 --> Utf8 Class Initialized
INFO - 2016-11-18 22:35:44 --> URI Class Initialized
DEBUG - 2016-11-18 22:35:44 --> No URI present. Default controller set.
INFO - 2016-11-18 22:35:44 --> Router Class Initialized
INFO - 2016-11-18 22:35:44 --> Output Class Initialized
INFO - 2016-11-18 22:35:44 --> Security Class Initialized
DEBUG - 2016-11-18 22:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:35:44 --> Input Class Initialized
INFO - 2016-11-18 22:35:44 --> Language Class Initialized
INFO - 2016-11-18 22:35:44 --> Loader Class Initialized
INFO - 2016-11-18 22:35:44 --> Helper loaded: url_helper
INFO - 2016-11-18 22:35:44 --> Helper loaded: form_helper
INFO - 2016-11-18 22:35:44 --> Database Driver Class Initialized
INFO - 2016-11-18 22:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:35:44 --> Controller Class Initialized
INFO - 2016-11-18 22:35:44 --> Model Class Initialized
INFO - 2016-11-18 22:35:44 --> Model Class Initialized
INFO - 2016-11-18 22:35:44 --> Model Class Initialized
INFO - 2016-11-18 22:35:44 --> Model Class Initialized
INFO - 2016-11-18 22:35:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:35:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:35:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:35:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:35:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:35:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:35:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:35:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:35:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:35:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:35:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:35:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:35:44 --> Final output sent to browser
DEBUG - 2016-11-18 22:35:44 --> Total execution time: 0.9777
INFO - 2016-11-18 22:37:01 --> Config Class Initialized
INFO - 2016-11-18 22:37:01 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:37:01 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:37:01 --> Utf8 Class Initialized
INFO - 2016-11-18 22:37:01 --> URI Class Initialized
DEBUG - 2016-11-18 22:37:01 --> No URI present. Default controller set.
INFO - 2016-11-18 22:37:01 --> Router Class Initialized
INFO - 2016-11-18 22:37:01 --> Output Class Initialized
INFO - 2016-11-18 22:37:01 --> Security Class Initialized
DEBUG - 2016-11-18 22:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:37:02 --> Input Class Initialized
INFO - 2016-11-18 22:37:02 --> Language Class Initialized
INFO - 2016-11-18 22:37:02 --> Loader Class Initialized
INFO - 2016-11-18 22:37:02 --> Helper loaded: url_helper
INFO - 2016-11-18 22:37:02 --> Helper loaded: form_helper
INFO - 2016-11-18 22:37:02 --> Database Driver Class Initialized
INFO - 2016-11-18 22:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:37:02 --> Controller Class Initialized
INFO - 2016-11-18 22:37:02 --> Model Class Initialized
INFO - 2016-11-18 22:37:02 --> Model Class Initialized
INFO - 2016-11-18 22:37:02 --> Model Class Initialized
INFO - 2016-11-18 22:37:02 --> Model Class Initialized
INFO - 2016-11-18 22:37:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:37:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:37:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:37:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:37:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:37:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:37:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:37:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:37:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:37:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:37:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:37:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:37:02 --> Final output sent to browser
DEBUG - 2016-11-18 22:37:02 --> Total execution time: 0.9198
INFO - 2016-11-18 22:37:06 --> Config Class Initialized
INFO - 2016-11-18 22:37:06 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:37:06 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:37:06 --> Utf8 Class Initialized
INFO - 2016-11-18 22:37:06 --> URI Class Initialized
INFO - 2016-11-18 22:37:06 --> Router Class Initialized
INFO - 2016-11-18 22:37:06 --> Output Class Initialized
INFO - 2016-11-18 22:37:06 --> Security Class Initialized
DEBUG - 2016-11-18 22:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:37:06 --> Input Class Initialized
INFO - 2016-11-18 22:37:06 --> Language Class Initialized
INFO - 2016-11-18 22:37:06 --> Loader Class Initialized
INFO - 2016-11-18 22:37:06 --> Helper loaded: url_helper
INFO - 2016-11-18 22:37:06 --> Helper loaded: form_helper
INFO - 2016-11-18 22:37:06 --> Database Driver Class Initialized
INFO - 2016-11-18 22:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:37:06 --> Controller Class Initialized
INFO - 2016-11-18 22:37:06 --> Model Class Initialized
INFO - 2016-11-18 22:37:06 --> Model Class Initialized
INFO - 2016-11-18 22:37:06 --> Model Class Initialized
INFO - 2016-11-18 22:37:06 --> Model Class Initialized
DEBUG - 2016-11-18 22:37:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-18 22:37:07 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-18 22:37:07 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-18 22:37:07 --> Config Class Initialized
INFO - 2016-11-18 22:37:07 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:37:07 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:37:07 --> Utf8 Class Initialized
INFO - 2016-11-18 22:37:07 --> URI Class Initialized
DEBUG - 2016-11-18 22:37:07 --> No URI present. Default controller set.
INFO - 2016-11-18 22:37:07 --> Router Class Initialized
INFO - 2016-11-18 22:37:07 --> Output Class Initialized
INFO - 2016-11-18 22:37:07 --> Security Class Initialized
DEBUG - 2016-11-18 22:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:37:07 --> Input Class Initialized
INFO - 2016-11-18 22:37:07 --> Language Class Initialized
INFO - 2016-11-18 22:37:07 --> Loader Class Initialized
INFO - 2016-11-18 22:37:07 --> Helper loaded: url_helper
INFO - 2016-11-18 22:37:07 --> Helper loaded: form_helper
INFO - 2016-11-18 22:37:07 --> Database Driver Class Initialized
INFO - 2016-11-18 22:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:37:07 --> Controller Class Initialized
INFO - 2016-11-18 22:37:07 --> Model Class Initialized
INFO - 2016-11-18 22:37:07 --> Model Class Initialized
INFO - 2016-11-18 22:37:07 --> Model Class Initialized
INFO - 2016-11-18 22:37:07 --> Model Class Initialized
INFO - 2016-11-18 22:37:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:37:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 22:37:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:37:07 --> Final output sent to browser
DEBUG - 2016-11-18 22:37:07 --> Total execution time: 0.6564
INFO - 2016-11-18 22:54:54 --> Config Class Initialized
INFO - 2016-11-18 22:54:54 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:54:54 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:54:54 --> Utf8 Class Initialized
INFO - 2016-11-18 22:54:54 --> URI Class Initialized
DEBUG - 2016-11-18 22:54:54 --> No URI present. Default controller set.
INFO - 2016-11-18 22:54:54 --> Router Class Initialized
INFO - 2016-11-18 22:54:54 --> Output Class Initialized
INFO - 2016-11-18 22:54:54 --> Security Class Initialized
DEBUG - 2016-11-18 22:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:54:54 --> Input Class Initialized
INFO - 2016-11-18 22:54:54 --> Language Class Initialized
INFO - 2016-11-18 22:54:54 --> Loader Class Initialized
INFO - 2016-11-18 22:54:54 --> Helper loaded: url_helper
INFO - 2016-11-18 22:54:54 --> Helper loaded: form_helper
INFO - 2016-11-18 22:54:54 --> Database Driver Class Initialized
INFO - 2016-11-18 22:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:54:55 --> Controller Class Initialized
INFO - 2016-11-18 22:54:55 --> Model Class Initialized
INFO - 2016-11-18 22:54:55 --> Model Class Initialized
INFO - 2016-11-18 22:54:55 --> Model Class Initialized
INFO - 2016-11-18 22:54:55 --> Model Class Initialized
INFO - 2016-11-18 22:54:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:54:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 22:54:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:54:55 --> Final output sent to browser
DEBUG - 2016-11-18 22:54:55 --> Total execution time: 0.6855
INFO - 2016-11-18 22:55:05 --> Config Class Initialized
INFO - 2016-11-18 22:55:05 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:55:05 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:55:05 --> Utf8 Class Initialized
INFO - 2016-11-18 22:55:05 --> URI Class Initialized
INFO - 2016-11-18 22:55:05 --> Router Class Initialized
INFO - 2016-11-18 22:55:05 --> Output Class Initialized
INFO - 2016-11-18 22:55:05 --> Security Class Initialized
DEBUG - 2016-11-18 22:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:55:05 --> Input Class Initialized
INFO - 2016-11-18 22:55:05 --> Language Class Initialized
INFO - 2016-11-18 22:55:05 --> Loader Class Initialized
INFO - 2016-11-18 22:55:05 --> Helper loaded: url_helper
INFO - 2016-11-18 22:55:05 --> Helper loaded: form_helper
INFO - 2016-11-18 22:55:05 --> Database Driver Class Initialized
INFO - 2016-11-18 22:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:55:05 --> Controller Class Initialized
INFO - 2016-11-18 22:55:05 --> Model Class Initialized
INFO - 2016-11-18 22:55:05 --> Model Class Initialized
INFO - 2016-11-18 22:55:05 --> Model Class Initialized
INFO - 2016-11-18 22:55:05 --> Model Class Initialized
DEBUG - 2016-11-18 22:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-18 22:55:06 --> Model Class Initialized
INFO - 2016-11-18 22:55:06 --> Final output sent to browser
DEBUG - 2016-11-18 22:55:06 --> Total execution time: 0.6711
INFO - 2016-11-18 22:55:06 --> Config Class Initialized
INFO - 2016-11-18 22:55:06 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:55:06 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:55:06 --> Utf8 Class Initialized
INFO - 2016-11-18 22:55:06 --> URI Class Initialized
DEBUG - 2016-11-18 22:55:06 --> No URI present. Default controller set.
INFO - 2016-11-18 22:55:06 --> Router Class Initialized
INFO - 2016-11-18 22:55:06 --> Output Class Initialized
INFO - 2016-11-18 22:55:06 --> Security Class Initialized
DEBUG - 2016-11-18 22:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:55:06 --> Input Class Initialized
INFO - 2016-11-18 22:55:06 --> Language Class Initialized
INFO - 2016-11-18 22:55:06 --> Loader Class Initialized
INFO - 2016-11-18 22:55:06 --> Helper loaded: url_helper
INFO - 2016-11-18 22:55:06 --> Helper loaded: form_helper
INFO - 2016-11-18 22:55:06 --> Database Driver Class Initialized
INFO - 2016-11-18 22:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:55:06 --> Controller Class Initialized
INFO - 2016-11-18 22:55:06 --> Model Class Initialized
INFO - 2016-11-18 22:55:06 --> Model Class Initialized
INFO - 2016-11-18 22:55:06 --> Model Class Initialized
INFO - 2016-11-18 22:55:06 --> Model Class Initialized
INFO - 2016-11-18 22:55:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:55:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:55:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:55:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:55:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:55:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:55:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:55:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:55:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:55:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:55:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:55:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:55:07 --> Final output sent to browser
DEBUG - 2016-11-18 22:55:07 --> Total execution time: 1.1647
INFO - 2016-11-18 22:56:19 --> Config Class Initialized
INFO - 2016-11-18 22:56:19 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:56:19 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:56:19 --> Utf8 Class Initialized
INFO - 2016-11-18 22:56:19 --> URI Class Initialized
DEBUG - 2016-11-18 22:56:19 --> No URI present. Default controller set.
INFO - 2016-11-18 22:56:19 --> Router Class Initialized
INFO - 2016-11-18 22:56:19 --> Output Class Initialized
INFO - 2016-11-18 22:56:19 --> Security Class Initialized
DEBUG - 2016-11-18 22:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:56:19 --> Input Class Initialized
INFO - 2016-11-18 22:56:19 --> Language Class Initialized
INFO - 2016-11-18 22:56:19 --> Loader Class Initialized
INFO - 2016-11-18 22:56:19 --> Helper loaded: url_helper
INFO - 2016-11-18 22:56:19 --> Helper loaded: form_helper
INFO - 2016-11-18 22:56:19 --> Database Driver Class Initialized
INFO - 2016-11-18 22:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:56:19 --> Controller Class Initialized
INFO - 2016-11-18 22:56:19 --> Model Class Initialized
INFO - 2016-11-18 22:56:19 --> Model Class Initialized
INFO - 2016-11-18 22:56:19 --> Model Class Initialized
INFO - 2016-11-18 22:56:20 --> Model Class Initialized
INFO - 2016-11-18 22:56:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:56:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 22:56:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 22:56:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 22:56:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 22:56:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 22:56:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 22:56:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 22:56:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 22:56:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 22:56:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 22:56:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:56:20 --> Final output sent to browser
DEBUG - 2016-11-18 22:56:20 --> Total execution time: 0.9519
INFO - 2016-11-18 22:58:02 --> Config Class Initialized
INFO - 2016-11-18 22:58:02 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:58:02 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:58:02 --> Utf8 Class Initialized
INFO - 2016-11-18 22:58:02 --> URI Class Initialized
INFO - 2016-11-18 22:58:02 --> Router Class Initialized
INFO - 2016-11-18 22:58:02 --> Output Class Initialized
INFO - 2016-11-18 22:58:02 --> Security Class Initialized
DEBUG - 2016-11-18 22:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:58:02 --> Input Class Initialized
INFO - 2016-11-18 22:58:02 --> Language Class Initialized
INFO - 2016-11-18 22:58:02 --> Loader Class Initialized
INFO - 2016-11-18 22:58:02 --> Helper loaded: url_helper
INFO - 2016-11-18 22:58:02 --> Helper loaded: form_helper
INFO - 2016-11-18 22:58:02 --> Database Driver Class Initialized
INFO - 2016-11-18 22:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:58:02 --> Controller Class Initialized
INFO - 2016-11-18 22:58:02 --> Model Class Initialized
INFO - 2016-11-18 22:58:02 --> Model Class Initialized
INFO - 2016-11-18 22:58:02 --> Model Class Initialized
INFO - 2016-11-18 22:58:02 --> Model Class Initialized
DEBUG - 2016-11-18 22:58:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-18 22:58:03 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-18 22:58:03 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-18 22:58:03 --> Config Class Initialized
INFO - 2016-11-18 22:58:03 --> Hooks Class Initialized
DEBUG - 2016-11-18 22:58:03 --> UTF-8 Support Enabled
INFO - 2016-11-18 22:58:03 --> Utf8 Class Initialized
INFO - 2016-11-18 22:58:03 --> URI Class Initialized
DEBUG - 2016-11-18 22:58:03 --> No URI present. Default controller set.
INFO - 2016-11-18 22:58:03 --> Router Class Initialized
INFO - 2016-11-18 22:58:03 --> Output Class Initialized
INFO - 2016-11-18 22:58:03 --> Security Class Initialized
DEBUG - 2016-11-18 22:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 22:58:03 --> Input Class Initialized
INFO - 2016-11-18 22:58:03 --> Language Class Initialized
INFO - 2016-11-18 22:58:03 --> Loader Class Initialized
INFO - 2016-11-18 22:58:03 --> Helper loaded: url_helper
INFO - 2016-11-18 22:58:03 --> Helper loaded: form_helper
INFO - 2016-11-18 22:58:03 --> Database Driver Class Initialized
INFO - 2016-11-18 22:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 22:58:03 --> Controller Class Initialized
INFO - 2016-11-18 22:58:03 --> Model Class Initialized
INFO - 2016-11-18 22:58:03 --> Model Class Initialized
INFO - 2016-11-18 22:58:03 --> Model Class Initialized
INFO - 2016-11-18 22:58:03 --> Model Class Initialized
INFO - 2016-11-18 22:58:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 22:58:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 22:58:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 22:58:03 --> Final output sent to browser
DEBUG - 2016-11-18 22:58:03 --> Total execution time: 0.6670
INFO - 2016-11-18 23:10:55 --> Config Class Initialized
INFO - 2016-11-18 23:10:55 --> Hooks Class Initialized
DEBUG - 2016-11-18 23:10:55 --> UTF-8 Support Enabled
INFO - 2016-11-18 23:10:55 --> Utf8 Class Initialized
INFO - 2016-11-18 23:10:55 --> URI Class Initialized
DEBUG - 2016-11-18 23:10:55 --> No URI present. Default controller set.
INFO - 2016-11-18 23:10:55 --> Router Class Initialized
INFO - 2016-11-18 23:10:55 --> Output Class Initialized
INFO - 2016-11-18 23:10:55 --> Security Class Initialized
DEBUG - 2016-11-18 23:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 23:10:55 --> Input Class Initialized
INFO - 2016-11-18 23:10:55 --> Language Class Initialized
INFO - 2016-11-18 23:10:55 --> Loader Class Initialized
INFO - 2016-11-18 23:10:55 --> Helper loaded: url_helper
INFO - 2016-11-18 23:10:55 --> Helper loaded: form_helper
INFO - 2016-11-18 23:10:55 --> Database Driver Class Initialized
INFO - 2016-11-18 23:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 23:10:55 --> Controller Class Initialized
INFO - 2016-11-18 23:10:55 --> Model Class Initialized
INFO - 2016-11-18 23:10:55 --> Model Class Initialized
INFO - 2016-11-18 23:10:55 --> Model Class Initialized
INFO - 2016-11-18 23:10:55 --> Model Class Initialized
INFO - 2016-11-18 23:10:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 23:10:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 23:10:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 23:10:56 --> Final output sent to browser
DEBUG - 2016-11-18 23:10:56 --> Total execution time: 0.7365
INFO - 2016-11-18 23:15:45 --> Config Class Initialized
INFO - 2016-11-18 23:15:45 --> Hooks Class Initialized
DEBUG - 2016-11-18 23:15:45 --> UTF-8 Support Enabled
INFO - 2016-11-18 23:15:45 --> Utf8 Class Initialized
INFO - 2016-11-18 23:15:45 --> URI Class Initialized
DEBUG - 2016-11-18 23:15:45 --> No URI present. Default controller set.
INFO - 2016-11-18 23:15:45 --> Router Class Initialized
INFO - 2016-11-18 23:15:45 --> Output Class Initialized
INFO - 2016-11-18 23:15:45 --> Security Class Initialized
DEBUG - 2016-11-18 23:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 23:15:45 --> Input Class Initialized
INFO - 2016-11-18 23:15:45 --> Language Class Initialized
INFO - 2016-11-18 23:15:45 --> Loader Class Initialized
INFO - 2016-11-18 23:15:45 --> Helper loaded: url_helper
INFO - 2016-11-18 23:15:45 --> Helper loaded: form_helper
INFO - 2016-11-18 23:15:45 --> Database Driver Class Initialized
INFO - 2016-11-18 23:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 23:15:45 --> Controller Class Initialized
INFO - 2016-11-18 23:15:45 --> Model Class Initialized
INFO - 2016-11-18 23:15:45 --> Model Class Initialized
INFO - 2016-11-18 23:15:45 --> Model Class Initialized
INFO - 2016-11-18 23:15:45 --> Model Class Initialized
INFO - 2016-11-18 23:15:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 23:15:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 23:15:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 23:15:46 --> Final output sent to browser
DEBUG - 2016-11-18 23:15:46 --> Total execution time: 0.7159
INFO - 2016-11-18 23:15:57 --> Config Class Initialized
INFO - 2016-11-18 23:15:57 --> Hooks Class Initialized
DEBUG - 2016-11-18 23:15:57 --> UTF-8 Support Enabled
INFO - 2016-11-18 23:15:57 --> Utf8 Class Initialized
INFO - 2016-11-18 23:15:57 --> URI Class Initialized
INFO - 2016-11-18 23:15:57 --> Router Class Initialized
INFO - 2016-11-18 23:15:57 --> Output Class Initialized
INFO - 2016-11-18 23:15:57 --> Security Class Initialized
DEBUG - 2016-11-18 23:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 23:15:58 --> Input Class Initialized
INFO - 2016-11-18 23:15:58 --> Language Class Initialized
INFO - 2016-11-18 23:15:58 --> Loader Class Initialized
INFO - 2016-11-18 23:15:58 --> Helper loaded: url_helper
INFO - 2016-11-18 23:15:58 --> Helper loaded: form_helper
INFO - 2016-11-18 23:15:58 --> Database Driver Class Initialized
INFO - 2016-11-18 23:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 23:15:58 --> Controller Class Initialized
INFO - 2016-11-18 23:15:58 --> Model Class Initialized
INFO - 2016-11-18 23:15:58 --> Model Class Initialized
INFO - 2016-11-18 23:15:58 --> Model Class Initialized
INFO - 2016-11-18 23:15:58 --> Model Class Initialized
DEBUG - 2016-11-18 23:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-18 23:15:58 --> Model Class Initialized
INFO - 2016-11-18 23:15:58 --> Final output sent to browser
DEBUG - 2016-11-18 23:15:58 --> Total execution time: 0.6298
INFO - 2016-11-18 23:15:58 --> Config Class Initialized
INFO - 2016-11-18 23:15:58 --> Hooks Class Initialized
DEBUG - 2016-11-18 23:15:58 --> UTF-8 Support Enabled
INFO - 2016-11-18 23:15:58 --> Utf8 Class Initialized
INFO - 2016-11-18 23:15:58 --> URI Class Initialized
DEBUG - 2016-11-18 23:15:58 --> No URI present. Default controller set.
INFO - 2016-11-18 23:15:58 --> Router Class Initialized
INFO - 2016-11-18 23:15:58 --> Output Class Initialized
INFO - 2016-11-18 23:15:58 --> Security Class Initialized
DEBUG - 2016-11-18 23:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 23:15:58 --> Input Class Initialized
INFO - 2016-11-18 23:15:58 --> Language Class Initialized
INFO - 2016-11-18 23:15:58 --> Loader Class Initialized
INFO - 2016-11-18 23:15:58 --> Helper loaded: url_helper
INFO - 2016-11-18 23:15:58 --> Helper loaded: form_helper
INFO - 2016-11-18 23:15:58 --> Database Driver Class Initialized
INFO - 2016-11-18 23:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 23:15:59 --> Controller Class Initialized
INFO - 2016-11-18 23:15:59 --> Model Class Initialized
INFO - 2016-11-18 23:15:59 --> Model Class Initialized
INFO - 2016-11-18 23:15:59 --> Model Class Initialized
INFO - 2016-11-18 23:15:59 --> Model Class Initialized
INFO - 2016-11-18 23:15:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 23:15:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 23:15:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 23:15:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 23:15:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 23:15:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 23:15:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 23:15:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 23:15:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 23:15:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 23:15:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 23:15:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 23:15:59 --> Final output sent to browser
DEBUG - 2016-11-18 23:15:59 --> Total execution time: 0.9672
INFO - 2016-11-18 23:16:12 --> Config Class Initialized
INFO - 2016-11-18 23:16:12 --> Hooks Class Initialized
DEBUG - 2016-11-18 23:16:12 --> UTF-8 Support Enabled
INFO - 2016-11-18 23:16:12 --> Utf8 Class Initialized
INFO - 2016-11-18 23:16:12 --> URI Class Initialized
INFO - 2016-11-18 23:16:12 --> Router Class Initialized
INFO - 2016-11-18 23:16:12 --> Output Class Initialized
INFO - 2016-11-18 23:16:12 --> Security Class Initialized
DEBUG - 2016-11-18 23:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 23:16:12 --> Input Class Initialized
INFO - 2016-11-18 23:16:12 --> Language Class Initialized
INFO - 2016-11-18 23:16:12 --> Loader Class Initialized
INFO - 2016-11-18 23:16:12 --> Helper loaded: url_helper
INFO - 2016-11-18 23:16:12 --> Helper loaded: form_helper
INFO - 2016-11-18 23:16:12 --> Database Driver Class Initialized
INFO - 2016-11-18 23:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 23:16:12 --> Controller Class Initialized
INFO - 2016-11-18 23:16:12 --> Model Class Initialized
INFO - 2016-11-18 23:16:12 --> Model Class Initialized
INFO - 2016-11-18 23:16:12 --> Model Class Initialized
INFO - 2016-11-18 23:16:12 --> Model Class Initialized
DEBUG - 2016-11-18 23:16:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-18 23:16:13 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-18 23:16:13 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-18 23:16:13 --> Config Class Initialized
INFO - 2016-11-18 23:16:13 --> Hooks Class Initialized
DEBUG - 2016-11-18 23:16:13 --> UTF-8 Support Enabled
INFO - 2016-11-18 23:16:13 --> Utf8 Class Initialized
INFO - 2016-11-18 23:16:13 --> URI Class Initialized
DEBUG - 2016-11-18 23:16:13 --> No URI present. Default controller set.
INFO - 2016-11-18 23:16:13 --> Router Class Initialized
INFO - 2016-11-18 23:16:13 --> Output Class Initialized
INFO - 2016-11-18 23:16:13 --> Security Class Initialized
DEBUG - 2016-11-18 23:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 23:16:13 --> Input Class Initialized
INFO - 2016-11-18 23:16:13 --> Language Class Initialized
INFO - 2016-11-18 23:16:13 --> Loader Class Initialized
INFO - 2016-11-18 23:16:13 --> Helper loaded: url_helper
INFO - 2016-11-18 23:16:13 --> Helper loaded: form_helper
INFO - 2016-11-18 23:16:13 --> Database Driver Class Initialized
INFO - 2016-11-18 23:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 23:16:13 --> Controller Class Initialized
INFO - 2016-11-18 23:16:13 --> Model Class Initialized
INFO - 2016-11-18 23:16:13 --> Model Class Initialized
INFO - 2016-11-18 23:16:13 --> Model Class Initialized
INFO - 2016-11-18 23:16:13 --> Model Class Initialized
INFO - 2016-11-18 23:16:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 23:16:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 23:16:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 23:16:13 --> Final output sent to browser
DEBUG - 2016-11-18 23:16:13 --> Total execution time: 0.7267
INFO - 2016-11-18 23:24:40 --> Config Class Initialized
INFO - 2016-11-18 23:24:40 --> Hooks Class Initialized
DEBUG - 2016-11-18 23:24:41 --> UTF-8 Support Enabled
INFO - 2016-11-18 23:24:41 --> Utf8 Class Initialized
INFO - 2016-11-18 23:24:41 --> URI Class Initialized
DEBUG - 2016-11-18 23:24:41 --> No URI present. Default controller set.
INFO - 2016-11-18 23:24:41 --> Router Class Initialized
INFO - 2016-11-18 23:24:41 --> Output Class Initialized
INFO - 2016-11-18 23:24:41 --> Security Class Initialized
DEBUG - 2016-11-18 23:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 23:24:41 --> Input Class Initialized
INFO - 2016-11-18 23:24:41 --> Language Class Initialized
INFO - 2016-11-18 23:24:41 --> Loader Class Initialized
INFO - 2016-11-18 23:24:41 --> Helper loaded: url_helper
INFO - 2016-11-18 23:24:42 --> Helper loaded: form_helper
INFO - 2016-11-18 23:24:42 --> Database Driver Class Initialized
INFO - 2016-11-18 23:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 23:24:42 --> Controller Class Initialized
INFO - 2016-11-18 23:24:42 --> Model Class Initialized
INFO - 2016-11-18 23:24:42 --> Model Class Initialized
INFO - 2016-11-18 23:24:42 --> Model Class Initialized
INFO - 2016-11-18 23:24:42 --> Model Class Initialized
INFO - 2016-11-18 23:24:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 23:24:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-18 23:24:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 23:24:43 --> Final output sent to browser
DEBUG - 2016-11-18 23:24:43 --> Total execution time: 2.2855
INFO - 2016-11-18 23:26:22 --> Config Class Initialized
INFO - 2016-11-18 23:26:22 --> Hooks Class Initialized
DEBUG - 2016-11-18 23:26:22 --> UTF-8 Support Enabled
INFO - 2016-11-18 23:26:22 --> Utf8 Class Initialized
INFO - 2016-11-18 23:26:22 --> URI Class Initialized
INFO - 2016-11-18 23:26:22 --> Router Class Initialized
INFO - 2016-11-18 23:26:22 --> Output Class Initialized
INFO - 2016-11-18 23:26:22 --> Security Class Initialized
DEBUG - 2016-11-18 23:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 23:26:22 --> Input Class Initialized
INFO - 2016-11-18 23:26:22 --> Language Class Initialized
INFO - 2016-11-18 23:26:22 --> Loader Class Initialized
INFO - 2016-11-18 23:26:22 --> Helper loaded: url_helper
INFO - 2016-11-18 23:26:22 --> Helper loaded: form_helper
INFO - 2016-11-18 23:26:22 --> Database Driver Class Initialized
INFO - 2016-11-18 23:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 23:26:23 --> Controller Class Initialized
INFO - 2016-11-18 23:26:23 --> Model Class Initialized
INFO - 2016-11-18 23:26:23 --> Model Class Initialized
INFO - 2016-11-18 23:26:23 --> Model Class Initialized
INFO - 2016-11-18 23:26:23 --> Model Class Initialized
DEBUG - 2016-11-18 23:26:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-18 23:26:23 --> Model Class Initialized
INFO - 2016-11-18 23:26:23 --> Final output sent to browser
DEBUG - 2016-11-18 23:26:23 --> Total execution time: 0.9465
INFO - 2016-11-18 23:26:23 --> Config Class Initialized
INFO - 2016-11-18 23:26:23 --> Hooks Class Initialized
DEBUG - 2016-11-18 23:26:23 --> UTF-8 Support Enabled
INFO - 2016-11-18 23:26:23 --> Utf8 Class Initialized
INFO - 2016-11-18 23:26:23 --> URI Class Initialized
DEBUG - 2016-11-18 23:26:23 --> No URI present. Default controller set.
INFO - 2016-11-18 23:26:23 --> Router Class Initialized
INFO - 2016-11-18 23:26:23 --> Output Class Initialized
INFO - 2016-11-18 23:26:23 --> Security Class Initialized
DEBUG - 2016-11-18 23:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 23:26:23 --> Input Class Initialized
INFO - 2016-11-18 23:26:23 --> Language Class Initialized
INFO - 2016-11-18 23:26:23 --> Loader Class Initialized
INFO - 2016-11-18 23:26:23 --> Helper loaded: url_helper
INFO - 2016-11-18 23:26:23 --> Helper loaded: form_helper
INFO - 2016-11-18 23:26:23 --> Database Driver Class Initialized
INFO - 2016-11-18 23:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 23:26:23 --> Controller Class Initialized
INFO - 2016-11-18 23:26:23 --> Model Class Initialized
INFO - 2016-11-18 23:26:23 --> Model Class Initialized
INFO - 2016-11-18 23:26:23 --> Model Class Initialized
INFO - 2016-11-18 23:26:23 --> Model Class Initialized
INFO - 2016-11-18 23:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 23:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 23:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 23:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 23:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 23:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 23:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 23:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 23:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 23:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 23:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 23:26:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 23:26:24 --> Final output sent to browser
DEBUG - 2016-11-18 23:26:24 --> Total execution time: 1.0438
INFO - 2016-11-18 23:31:43 --> Config Class Initialized
INFO - 2016-11-18 23:31:43 --> Hooks Class Initialized
DEBUG - 2016-11-18 23:31:43 --> UTF-8 Support Enabled
INFO - 2016-11-18 23:31:43 --> Utf8 Class Initialized
INFO - 2016-11-18 23:31:43 --> URI Class Initialized
DEBUG - 2016-11-18 23:31:44 --> No URI present. Default controller set.
INFO - 2016-11-18 23:31:44 --> Router Class Initialized
INFO - 2016-11-18 23:31:44 --> Output Class Initialized
INFO - 2016-11-18 23:31:44 --> Security Class Initialized
DEBUG - 2016-11-18 23:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 23:31:44 --> Input Class Initialized
INFO - 2016-11-18 23:31:44 --> Language Class Initialized
INFO - 2016-11-18 23:31:44 --> Loader Class Initialized
INFO - 2016-11-18 23:31:44 --> Helper loaded: url_helper
INFO - 2016-11-18 23:31:44 --> Helper loaded: form_helper
INFO - 2016-11-18 23:31:44 --> Database Driver Class Initialized
INFO - 2016-11-18 23:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 23:31:44 --> Controller Class Initialized
INFO - 2016-11-18 23:31:44 --> Model Class Initialized
INFO - 2016-11-18 23:31:44 --> Model Class Initialized
INFO - 2016-11-18 23:31:44 --> Model Class Initialized
INFO - 2016-11-18 23:31:44 --> Model Class Initialized
INFO - 2016-11-18 23:31:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 23:31:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 23:31:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 23:31:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 23:31:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 23:31:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 23:31:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 23:31:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 23:31:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 23:31:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 23:31:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 23:31:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 23:31:44 --> Final output sent to browser
DEBUG - 2016-11-18 23:31:44 --> Total execution time: 0.9802
INFO - 2016-11-18 23:40:20 --> Config Class Initialized
INFO - 2016-11-18 23:40:21 --> Hooks Class Initialized
DEBUG - 2016-11-18 23:40:21 --> UTF-8 Support Enabled
INFO - 2016-11-18 23:40:21 --> Utf8 Class Initialized
INFO - 2016-11-18 23:40:21 --> URI Class Initialized
DEBUG - 2016-11-18 23:40:21 --> No URI present. Default controller set.
INFO - 2016-11-18 23:40:21 --> Router Class Initialized
INFO - 2016-11-18 23:40:21 --> Output Class Initialized
INFO - 2016-11-18 23:40:21 --> Security Class Initialized
DEBUG - 2016-11-18 23:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 23:40:21 --> Input Class Initialized
INFO - 2016-11-18 23:40:21 --> Language Class Initialized
INFO - 2016-11-18 23:40:21 --> Loader Class Initialized
INFO - 2016-11-18 23:40:21 --> Helper loaded: url_helper
INFO - 2016-11-18 23:40:21 --> Helper loaded: form_helper
INFO - 2016-11-18 23:40:21 --> Database Driver Class Initialized
INFO - 2016-11-18 23:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 23:40:21 --> Controller Class Initialized
INFO - 2016-11-18 23:40:21 --> Model Class Initialized
INFO - 2016-11-18 23:40:21 --> Model Class Initialized
INFO - 2016-11-18 23:40:21 --> Model Class Initialized
INFO - 2016-11-18 23:40:21 --> Model Class Initialized
INFO - 2016-11-18 23:40:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 23:40:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 23:40:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 23:40:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 23:40:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 23:40:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 23:40:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 23:40:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 23:40:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 23:40:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 23:40:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 23:40:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 23:40:21 --> Final output sent to browser
DEBUG - 2016-11-18 23:40:21 --> Total execution time: 0.9087
INFO - 2016-11-18 23:54:26 --> Config Class Initialized
INFO - 2016-11-18 23:54:26 --> Hooks Class Initialized
DEBUG - 2016-11-18 23:54:26 --> UTF-8 Support Enabled
INFO - 2016-11-18 23:54:26 --> Utf8 Class Initialized
INFO - 2016-11-18 23:54:26 --> URI Class Initialized
DEBUG - 2016-11-18 23:54:26 --> No URI present. Default controller set.
INFO - 2016-11-18 23:54:26 --> Router Class Initialized
INFO - 2016-11-18 23:54:26 --> Output Class Initialized
INFO - 2016-11-18 23:54:26 --> Security Class Initialized
DEBUG - 2016-11-18 23:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-18 23:54:26 --> Input Class Initialized
INFO - 2016-11-18 23:54:26 --> Language Class Initialized
INFO - 2016-11-18 23:54:26 --> Loader Class Initialized
INFO - 2016-11-18 23:54:26 --> Helper loaded: url_helper
INFO - 2016-11-18 23:54:26 --> Helper loaded: form_helper
INFO - 2016-11-18 23:54:26 --> Database Driver Class Initialized
INFO - 2016-11-18 23:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-18 23:54:26 --> Controller Class Initialized
INFO - 2016-11-18 23:54:26 --> Model Class Initialized
INFO - 2016-11-18 23:54:26 --> Model Class Initialized
INFO - 2016-11-18 23:54:26 --> Model Class Initialized
INFO - 2016-11-18 23:54:26 --> Model Class Initialized
INFO - 2016-11-18 23:54:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-18 23:54:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-18 23:54:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-18 23:54:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-18 23:54:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-18 23:54:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-18 23:54:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-18 23:54:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-18 23:54:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-18 23:54:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-18 23:54:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-18 23:54:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-18 23:54:27 --> Final output sent to browser
DEBUG - 2016-11-18 23:54:27 --> Total execution time: 0.9484
