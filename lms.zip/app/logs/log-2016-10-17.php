<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-17 09:56:42 --> Config Class Initialized
INFO - 2016-10-17 09:56:42 --> Hooks Class Initialized
DEBUG - 2016-10-17 09:56:42 --> UTF-8 Support Enabled
INFO - 2016-10-17 09:56:42 --> Utf8 Class Initialized
INFO - 2016-10-17 09:56:42 --> URI Class Initialized
DEBUG - 2016-10-17 09:56:42 --> No URI present. Default controller set.
INFO - 2016-10-17 09:56:42 --> Router Class Initialized
INFO - 2016-10-17 09:56:42 --> Output Class Initialized
INFO - 2016-10-17 09:56:42 --> Security Class Initialized
DEBUG - 2016-10-17 09:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 09:56:42 --> Input Class Initialized
INFO - 2016-10-17 09:56:42 --> Language Class Initialized
INFO - 2016-10-17 09:56:42 --> Loader Class Initialized
INFO - 2016-10-17 09:56:42 --> Helper loaded: url_helper
INFO - 2016-10-17 09:56:42 --> Helper loaded: form_helper
INFO - 2016-10-17 09:56:42 --> Database Driver Class Initialized
ERROR - 2016-10-17 09:56:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 09:56:42 --> Unable to connect to the database
INFO - 2016-10-17 09:56:42 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-17 09:57:09 --> Config Class Initialized
INFO - 2016-10-17 09:57:09 --> Hooks Class Initialized
DEBUG - 2016-10-17 09:57:09 --> UTF-8 Support Enabled
INFO - 2016-10-17 09:57:09 --> Utf8 Class Initialized
INFO - 2016-10-17 09:57:09 --> URI Class Initialized
DEBUG - 2016-10-17 09:57:09 --> No URI present. Default controller set.
INFO - 2016-10-17 09:57:09 --> Router Class Initialized
INFO - 2016-10-17 09:57:09 --> Output Class Initialized
INFO - 2016-10-17 09:57:09 --> Security Class Initialized
DEBUG - 2016-10-17 09:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 09:57:09 --> Input Class Initialized
INFO - 2016-10-17 09:57:09 --> Language Class Initialized
INFO - 2016-10-17 09:57:09 --> Loader Class Initialized
INFO - 2016-10-17 09:57:09 --> Helper loaded: url_helper
INFO - 2016-10-17 09:57:09 --> Helper loaded: form_helper
INFO - 2016-10-17 09:57:09 --> Database Driver Class Initialized
ERROR - 2016-10-17 09:57:09 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 120
ERROR - 2016-10-17 09:57:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 09:57:09 --> Unable to connect to the database
INFO - 2016-10-17 09:57:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-17 09:57:10 --> Config Class Initialized
INFO - 2016-10-17 09:57:10 --> Hooks Class Initialized
DEBUG - 2016-10-17 09:57:10 --> UTF-8 Support Enabled
INFO - 2016-10-17 09:57:10 --> Utf8 Class Initialized
INFO - 2016-10-17 09:57:10 --> URI Class Initialized
DEBUG - 2016-10-17 09:57:10 --> No URI present. Default controller set.
INFO - 2016-10-17 09:57:10 --> Router Class Initialized
INFO - 2016-10-17 09:57:10 --> Output Class Initialized
INFO - 2016-10-17 09:57:10 --> Security Class Initialized
DEBUG - 2016-10-17 09:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 09:57:10 --> Input Class Initialized
INFO - 2016-10-17 09:57:10 --> Language Class Initialized
INFO - 2016-10-17 09:57:10 --> Loader Class Initialized
INFO - 2016-10-17 09:57:10 --> Helper loaded: url_helper
INFO - 2016-10-17 09:57:10 --> Helper loaded: form_helper
INFO - 2016-10-17 09:57:10 --> Database Driver Class Initialized
ERROR - 2016-10-17 09:57:10 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 120
ERROR - 2016-10-17 09:57:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 09:57:10 --> Unable to connect to the database
INFO - 2016-10-17 09:57:10 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-17 09:57:25 --> Config Class Initialized
INFO - 2016-10-17 09:57:25 --> Hooks Class Initialized
DEBUG - 2016-10-17 09:57:25 --> UTF-8 Support Enabled
INFO - 2016-10-17 09:57:25 --> Utf8 Class Initialized
INFO - 2016-10-17 09:57:25 --> URI Class Initialized
DEBUG - 2016-10-17 09:57:25 --> No URI present. Default controller set.
INFO - 2016-10-17 09:57:25 --> Router Class Initialized
INFO - 2016-10-17 09:57:25 --> Output Class Initialized
INFO - 2016-10-17 09:57:25 --> Security Class Initialized
DEBUG - 2016-10-17 09:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 09:57:25 --> Input Class Initialized
INFO - 2016-10-17 09:57:25 --> Language Class Initialized
INFO - 2016-10-17 09:57:25 --> Loader Class Initialized
INFO - 2016-10-17 09:57:25 --> Helper loaded: url_helper
INFO - 2016-10-17 09:57:25 --> Helper loaded: form_helper
INFO - 2016-10-17 09:57:25 --> Database Driver Class Initialized
ERROR - 2016-10-17 09:57:25 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 120
ERROR - 2016-10-17 09:57:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 09:57:25 --> Unable to connect to the database
INFO - 2016-10-17 09:57:25 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-17 09:57:26 --> Config Class Initialized
INFO - 2016-10-17 09:57:26 --> Hooks Class Initialized
DEBUG - 2016-10-17 09:57:26 --> UTF-8 Support Enabled
INFO - 2016-10-17 09:57:26 --> Utf8 Class Initialized
INFO - 2016-10-17 09:57:26 --> URI Class Initialized
DEBUG - 2016-10-17 09:57:26 --> No URI present. Default controller set.
INFO - 2016-10-17 09:57:26 --> Router Class Initialized
INFO - 2016-10-17 09:57:26 --> Output Class Initialized
INFO - 2016-10-17 09:57:26 --> Security Class Initialized
DEBUG - 2016-10-17 09:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 09:57:26 --> Input Class Initialized
INFO - 2016-10-17 09:57:26 --> Language Class Initialized
INFO - 2016-10-17 09:57:26 --> Loader Class Initialized
INFO - 2016-10-17 09:57:26 --> Helper loaded: url_helper
INFO - 2016-10-17 09:57:26 --> Helper loaded: form_helper
INFO - 2016-10-17 09:57:26 --> Database Driver Class Initialized
ERROR - 2016-10-17 09:57:26 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 120
ERROR - 2016-10-17 09:57:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 09:57:26 --> Unable to connect to the database
INFO - 2016-10-17 09:57:26 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-17 09:58:16 --> Config Class Initialized
INFO - 2016-10-17 09:58:16 --> Hooks Class Initialized
DEBUG - 2016-10-17 09:58:16 --> UTF-8 Support Enabled
INFO - 2016-10-17 09:58:16 --> Utf8 Class Initialized
INFO - 2016-10-17 09:58:16 --> URI Class Initialized
DEBUG - 2016-10-17 09:58:16 --> No URI present. Default controller set.
INFO - 2016-10-17 09:58:16 --> Router Class Initialized
INFO - 2016-10-17 09:58:16 --> Output Class Initialized
INFO - 2016-10-17 09:58:16 --> Security Class Initialized
DEBUG - 2016-10-17 09:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 09:58:16 --> Input Class Initialized
INFO - 2016-10-17 09:58:16 --> Language Class Initialized
INFO - 2016-10-17 09:58:16 --> Loader Class Initialized
INFO - 2016-10-17 09:58:16 --> Helper loaded: url_helper
INFO - 2016-10-17 09:58:16 --> Helper loaded: form_helper
INFO - 2016-10-17 09:58:16 --> Database Driver Class Initialized
ERROR - 2016-10-17 09:58:16 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 120
ERROR - 2016-10-17 09:58:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 09:58:16 --> Unable to connect to the database
INFO - 2016-10-17 09:58:16 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-17 09:59:08 --> Config Class Initialized
INFO - 2016-10-17 09:59:08 --> Hooks Class Initialized
DEBUG - 2016-10-17 09:59:08 --> UTF-8 Support Enabled
INFO - 2016-10-17 09:59:08 --> Utf8 Class Initialized
INFO - 2016-10-17 09:59:08 --> URI Class Initialized
DEBUG - 2016-10-17 09:59:08 --> No URI present. Default controller set.
INFO - 2016-10-17 09:59:08 --> Router Class Initialized
INFO - 2016-10-17 09:59:08 --> Output Class Initialized
INFO - 2016-10-17 09:59:08 --> Security Class Initialized
DEBUG - 2016-10-17 09:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 09:59:08 --> Input Class Initialized
INFO - 2016-10-17 09:59:08 --> Language Class Initialized
INFO - 2016-10-17 09:59:08 --> Loader Class Initialized
INFO - 2016-10-17 09:59:08 --> Controller Class Initialized
INFO - 2016-10-17 09:59:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/welcome_message.php
INFO - 2016-10-17 09:59:08 --> Final output sent to browser
DEBUG - 2016-10-17 09:59:08 --> Total execution time: 0.0045
INFO - 2016-10-17 10:10:38 --> Config Class Initialized
INFO - 2016-10-17 10:10:38 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:10:38 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:10:38 --> Utf8 Class Initialized
INFO - 2016-10-17 10:10:38 --> URI Class Initialized
DEBUG - 2016-10-17 10:10:38 --> No URI present. Default controller set.
INFO - 2016-10-17 10:10:38 --> Router Class Initialized
INFO - 2016-10-17 10:10:38 --> Output Class Initialized
INFO - 2016-10-17 10:10:38 --> Security Class Initialized
DEBUG - 2016-10-17 10:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:10:38 --> Input Class Initialized
INFO - 2016-10-17 10:10:38 --> Language Class Initialized
INFO - 2016-10-17 10:10:38 --> Loader Class Initialized
INFO - 2016-10-17 10:10:38 --> Controller Class Initialized
INFO - 2016-10-17 10:10:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/welcome_message.php
INFO - 2016-10-17 10:10:38 --> Final output sent to browser
DEBUG - 2016-10-17 10:10:38 --> Total execution time: 0.0022
INFO - 2016-10-17 10:19:33 --> Config Class Initialized
INFO - 2016-10-17 10:19:33 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:19:33 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:19:33 --> Utf8 Class Initialized
INFO - 2016-10-17 10:19:33 --> URI Class Initialized
DEBUG - 2016-10-17 10:19:33 --> No URI present. Default controller set.
INFO - 2016-10-17 10:19:33 --> Router Class Initialized
INFO - 2016-10-17 10:19:33 --> Output Class Initialized
INFO - 2016-10-17 10:19:33 --> Security Class Initialized
DEBUG - 2016-10-17 10:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:19:33 --> Input Class Initialized
INFO - 2016-10-17 10:19:33 --> Language Class Initialized
INFO - 2016-10-17 10:19:33 --> Loader Class Initialized
INFO - 2016-10-17 10:19:33 --> Controller Class Initialized
ERROR - 2016-10-17 10:19:33 --> Severity: Error --> Call to undefined function base_url() /var/www/html/ramotlonyane_modise/LMS/app/views/header.php 10
INFO - 2016-10-17 10:20:17 --> Config Class Initialized
INFO - 2016-10-17 10:20:17 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:20:17 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:20:17 --> Utf8 Class Initialized
INFO - 2016-10-17 10:20:17 --> URI Class Initialized
DEBUG - 2016-10-17 10:20:17 --> No URI present. Default controller set.
INFO - 2016-10-17 10:20:17 --> Router Class Initialized
INFO - 2016-10-17 10:20:17 --> Output Class Initialized
INFO - 2016-10-17 10:20:17 --> Security Class Initialized
DEBUG - 2016-10-17 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:20:17 --> Input Class Initialized
INFO - 2016-10-17 10:20:17 --> Language Class Initialized
INFO - 2016-10-17 10:20:17 --> Loader Class Initialized
INFO - 2016-10-17 10:20:17 --> Helper loaded: url_helper
INFO - 2016-10-17 10:20:17 --> Controller Class Initialized
INFO - 2016-10-17 10:20:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:20:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:20:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:20:17 --> Final output sent to browser
DEBUG - 2016-10-17 10:20:17 --> Total execution time: 0.0027
INFO - 2016-10-17 10:21:02 --> Config Class Initialized
INFO - 2016-10-17 10:21:02 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:21:02 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:21:02 --> Utf8 Class Initialized
INFO - 2016-10-17 10:21:02 --> URI Class Initialized
DEBUG - 2016-10-17 10:21:02 --> No URI present. Default controller set.
INFO - 2016-10-17 10:21:02 --> Router Class Initialized
INFO - 2016-10-17 10:21:02 --> Output Class Initialized
INFO - 2016-10-17 10:21:02 --> Security Class Initialized
DEBUG - 2016-10-17 10:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:21:02 --> Input Class Initialized
INFO - 2016-10-17 10:21:02 --> Language Class Initialized
INFO - 2016-10-17 10:21:02 --> Loader Class Initialized
INFO - 2016-10-17 10:21:02 --> Helper loaded: url_helper
INFO - 2016-10-17 10:21:02 --> Controller Class Initialized
INFO - 2016-10-17 10:21:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:21:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:21:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:21:02 --> Final output sent to browser
DEBUG - 2016-10-17 10:21:02 --> Total execution time: 0.0024
INFO - 2016-10-17 10:22:19 --> Config Class Initialized
INFO - 2016-10-17 10:22:19 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:22:19 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:22:19 --> Utf8 Class Initialized
INFO - 2016-10-17 10:22:19 --> URI Class Initialized
DEBUG - 2016-10-17 10:22:19 --> No URI present. Default controller set.
INFO - 2016-10-17 10:22:19 --> Router Class Initialized
INFO - 2016-10-17 10:22:19 --> Output Class Initialized
INFO - 2016-10-17 10:22:19 --> Security Class Initialized
DEBUG - 2016-10-17 10:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:22:19 --> Input Class Initialized
INFO - 2016-10-17 10:22:19 --> Language Class Initialized
INFO - 2016-10-17 10:22:19 --> Loader Class Initialized
INFO - 2016-10-17 10:22:19 --> Helper loaded: url_helper
INFO - 2016-10-17 10:22:19 --> Controller Class Initialized
INFO - 2016-10-17 10:22:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:22:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:22:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:22:19 --> Final output sent to browser
DEBUG - 2016-10-17 10:22:19 --> Total execution time: 0.0027
INFO - 2016-10-17 10:22:37 --> Config Class Initialized
INFO - 2016-10-17 10:22:37 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:22:37 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:22:37 --> Utf8 Class Initialized
INFO - 2016-10-17 10:22:37 --> URI Class Initialized
DEBUG - 2016-10-17 10:22:37 --> No URI present. Default controller set.
INFO - 2016-10-17 10:22:37 --> Router Class Initialized
INFO - 2016-10-17 10:22:37 --> Output Class Initialized
INFO - 2016-10-17 10:22:37 --> Security Class Initialized
DEBUG - 2016-10-17 10:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:22:37 --> Input Class Initialized
INFO - 2016-10-17 10:22:37 --> Language Class Initialized
INFO - 2016-10-17 10:22:37 --> Loader Class Initialized
INFO - 2016-10-17 10:22:37 --> Helper loaded: url_helper
INFO - 2016-10-17 10:22:37 --> Controller Class Initialized
INFO - 2016-10-17 10:22:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:22:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:22:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:22:37 --> Final output sent to browser
DEBUG - 2016-10-17 10:22:37 --> Total execution time: 0.0021
INFO - 2016-10-17 10:24:05 --> Config Class Initialized
INFO - 2016-10-17 10:24:05 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:24:05 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:24:05 --> Utf8 Class Initialized
INFO - 2016-10-17 10:24:05 --> URI Class Initialized
DEBUG - 2016-10-17 10:24:05 --> No URI present. Default controller set.
INFO - 2016-10-17 10:24:05 --> Router Class Initialized
INFO - 2016-10-17 10:24:05 --> Output Class Initialized
INFO - 2016-10-17 10:24:05 --> Security Class Initialized
DEBUG - 2016-10-17 10:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:24:05 --> Input Class Initialized
INFO - 2016-10-17 10:24:05 --> Language Class Initialized
INFO - 2016-10-17 10:24:05 --> Loader Class Initialized
INFO - 2016-10-17 10:24:05 --> Helper loaded: url_helper
INFO - 2016-10-17 10:24:05 --> Controller Class Initialized
INFO - 2016-10-17 10:24:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:24:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:24:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:24:05 --> Final output sent to browser
DEBUG - 2016-10-17 10:24:05 --> Total execution time: 0.0028
INFO - 2016-10-17 10:25:53 --> Config Class Initialized
INFO - 2016-10-17 10:25:53 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:25:53 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:25:53 --> Utf8 Class Initialized
INFO - 2016-10-17 10:25:53 --> URI Class Initialized
DEBUG - 2016-10-17 10:25:53 --> No URI present. Default controller set.
INFO - 2016-10-17 10:25:53 --> Router Class Initialized
INFO - 2016-10-17 10:25:53 --> Output Class Initialized
INFO - 2016-10-17 10:25:53 --> Security Class Initialized
DEBUG - 2016-10-17 10:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:25:53 --> Input Class Initialized
INFO - 2016-10-17 10:25:53 --> Language Class Initialized
INFO - 2016-10-17 10:25:53 --> Loader Class Initialized
INFO - 2016-10-17 10:25:53 --> Helper loaded: url_helper
INFO - 2016-10-17 10:25:53 --> Controller Class Initialized
INFO - 2016-10-17 10:25:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:25:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:25:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:25:53 --> Final output sent to browser
DEBUG - 2016-10-17 10:25:53 --> Total execution time: 0.0023
INFO - 2016-10-17 10:25:55 --> Config Class Initialized
INFO - 2016-10-17 10:25:55 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:25:55 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:25:55 --> Utf8 Class Initialized
INFO - 2016-10-17 10:25:55 --> URI Class Initialized
DEBUG - 2016-10-17 10:25:55 --> No URI present. Default controller set.
INFO - 2016-10-17 10:25:55 --> Router Class Initialized
INFO - 2016-10-17 10:25:55 --> Output Class Initialized
INFO - 2016-10-17 10:25:55 --> Security Class Initialized
DEBUG - 2016-10-17 10:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:25:55 --> Input Class Initialized
INFO - 2016-10-17 10:25:55 --> Language Class Initialized
INFO - 2016-10-17 10:25:55 --> Loader Class Initialized
INFO - 2016-10-17 10:25:55 --> Helper loaded: url_helper
INFO - 2016-10-17 10:25:55 --> Controller Class Initialized
INFO - 2016-10-17 10:25:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:25:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:25:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:25:55 --> Final output sent to browser
DEBUG - 2016-10-17 10:25:55 --> Total execution time: 0.0021
INFO - 2016-10-17 10:26:12 --> Config Class Initialized
INFO - 2016-10-17 10:26:12 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:26:12 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:26:12 --> Utf8 Class Initialized
INFO - 2016-10-17 10:26:12 --> URI Class Initialized
DEBUG - 2016-10-17 10:26:12 --> No URI present. Default controller set.
INFO - 2016-10-17 10:26:12 --> Router Class Initialized
INFO - 2016-10-17 10:26:12 --> Output Class Initialized
INFO - 2016-10-17 10:26:12 --> Security Class Initialized
DEBUG - 2016-10-17 10:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:26:12 --> Input Class Initialized
INFO - 2016-10-17 10:26:12 --> Language Class Initialized
INFO - 2016-10-17 10:26:12 --> Loader Class Initialized
INFO - 2016-10-17 10:26:12 --> Helper loaded: url_helper
INFO - 2016-10-17 10:26:12 --> Controller Class Initialized
INFO - 2016-10-17 10:26:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:26:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:26:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:26:12 --> Final output sent to browser
DEBUG - 2016-10-17 10:26:12 --> Total execution time: 0.0047
INFO - 2016-10-17 10:26:12 --> Config Class Initialized
INFO - 2016-10-17 10:26:12 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:26:12 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:26:12 --> Utf8 Class Initialized
INFO - 2016-10-17 10:26:12 --> URI Class Initialized
DEBUG - 2016-10-17 10:26:12 --> No URI present. Default controller set.
INFO - 2016-10-17 10:26:12 --> Router Class Initialized
INFO - 2016-10-17 10:26:12 --> Output Class Initialized
INFO - 2016-10-17 10:26:12 --> Security Class Initialized
DEBUG - 2016-10-17 10:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:26:12 --> Input Class Initialized
INFO - 2016-10-17 10:26:12 --> Language Class Initialized
INFO - 2016-10-17 10:26:12 --> Loader Class Initialized
INFO - 2016-10-17 10:26:12 --> Helper loaded: url_helper
INFO - 2016-10-17 10:26:12 --> Controller Class Initialized
INFO - 2016-10-17 10:26:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:26:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:26:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:26:12 --> Final output sent to browser
DEBUG - 2016-10-17 10:26:12 --> Total execution time: 0.0017
INFO - 2016-10-17 10:26:12 --> Config Class Initialized
INFO - 2016-10-17 10:26:12 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:26:12 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:26:12 --> Utf8 Class Initialized
INFO - 2016-10-17 10:26:12 --> URI Class Initialized
DEBUG - 2016-10-17 10:26:12 --> No URI present. Default controller set.
INFO - 2016-10-17 10:26:12 --> Router Class Initialized
INFO - 2016-10-17 10:26:12 --> Output Class Initialized
INFO - 2016-10-17 10:26:12 --> Security Class Initialized
DEBUG - 2016-10-17 10:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:26:12 --> Input Class Initialized
INFO - 2016-10-17 10:26:12 --> Language Class Initialized
INFO - 2016-10-17 10:26:12 --> Loader Class Initialized
INFO - 2016-10-17 10:26:12 --> Helper loaded: url_helper
INFO - 2016-10-17 10:26:12 --> Controller Class Initialized
INFO - 2016-10-17 10:26:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:26:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:26:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:26:12 --> Final output sent to browser
DEBUG - 2016-10-17 10:26:12 --> Total execution time: 0.0017
INFO - 2016-10-17 10:26:13 --> Config Class Initialized
INFO - 2016-10-17 10:26:13 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:26:13 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:26:13 --> Utf8 Class Initialized
INFO - 2016-10-17 10:26:13 --> URI Class Initialized
DEBUG - 2016-10-17 10:26:13 --> No URI present. Default controller set.
INFO - 2016-10-17 10:26:13 --> Router Class Initialized
INFO - 2016-10-17 10:26:13 --> Output Class Initialized
INFO - 2016-10-17 10:26:13 --> Security Class Initialized
DEBUG - 2016-10-17 10:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:26:13 --> Input Class Initialized
INFO - 2016-10-17 10:26:13 --> Language Class Initialized
INFO - 2016-10-17 10:26:13 --> Loader Class Initialized
INFO - 2016-10-17 10:26:13 --> Helper loaded: url_helper
INFO - 2016-10-17 10:26:13 --> Controller Class Initialized
INFO - 2016-10-17 10:26:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:26:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:26:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:26:13 --> Final output sent to browser
DEBUG - 2016-10-17 10:26:13 --> Total execution time: 0.0016
INFO - 2016-10-17 10:26:13 --> Config Class Initialized
INFO - 2016-10-17 10:26:13 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:26:13 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:26:13 --> Utf8 Class Initialized
INFO - 2016-10-17 10:26:13 --> URI Class Initialized
DEBUG - 2016-10-17 10:26:13 --> No URI present. Default controller set.
INFO - 2016-10-17 10:26:13 --> Router Class Initialized
INFO - 2016-10-17 10:26:13 --> Output Class Initialized
INFO - 2016-10-17 10:26:13 --> Security Class Initialized
DEBUG - 2016-10-17 10:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:26:13 --> Input Class Initialized
INFO - 2016-10-17 10:26:13 --> Language Class Initialized
INFO - 2016-10-17 10:26:13 --> Loader Class Initialized
INFO - 2016-10-17 10:26:13 --> Helper loaded: url_helper
INFO - 2016-10-17 10:26:13 --> Controller Class Initialized
INFO - 2016-10-17 10:26:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:26:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:26:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:26:13 --> Final output sent to browser
DEBUG - 2016-10-17 10:26:13 --> Total execution time: 0.0018
INFO - 2016-10-17 10:26:33 --> Config Class Initialized
INFO - 2016-10-17 10:26:33 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:26:33 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:26:33 --> Utf8 Class Initialized
INFO - 2016-10-17 10:26:33 --> URI Class Initialized
DEBUG - 2016-10-17 10:26:33 --> No URI present. Default controller set.
INFO - 2016-10-17 10:26:33 --> Router Class Initialized
INFO - 2016-10-17 10:26:33 --> Output Class Initialized
INFO - 2016-10-17 10:26:33 --> Security Class Initialized
DEBUG - 2016-10-17 10:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:26:33 --> Input Class Initialized
INFO - 2016-10-17 10:26:33 --> Language Class Initialized
INFO - 2016-10-17 10:26:33 --> Loader Class Initialized
INFO - 2016-10-17 10:26:33 --> Helper loaded: url_helper
INFO - 2016-10-17 10:26:33 --> Controller Class Initialized
INFO - 2016-10-17 10:26:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:26:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:26:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:26:33 --> Final output sent to browser
DEBUG - 2016-10-17 10:26:33 --> Total execution time: 0.0021
INFO - 2016-10-17 10:26:36 --> Config Class Initialized
INFO - 2016-10-17 10:26:36 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:26:36 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:26:36 --> Utf8 Class Initialized
INFO - 2016-10-17 10:26:36 --> URI Class Initialized
DEBUG - 2016-10-17 10:26:36 --> No URI present. Default controller set.
INFO - 2016-10-17 10:26:36 --> Router Class Initialized
INFO - 2016-10-17 10:26:36 --> Output Class Initialized
INFO - 2016-10-17 10:26:36 --> Security Class Initialized
DEBUG - 2016-10-17 10:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:26:36 --> Input Class Initialized
INFO - 2016-10-17 10:26:36 --> Language Class Initialized
INFO - 2016-10-17 10:26:36 --> Loader Class Initialized
INFO - 2016-10-17 10:26:36 --> Helper loaded: url_helper
INFO - 2016-10-17 10:26:36 --> Controller Class Initialized
INFO - 2016-10-17 10:26:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:26:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:26:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:26:36 --> Final output sent to browser
DEBUG - 2016-10-17 10:26:36 --> Total execution time: 0.0019
INFO - 2016-10-17 10:27:04 --> Config Class Initialized
INFO - 2016-10-17 10:27:04 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:27:04 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:27:04 --> Utf8 Class Initialized
INFO - 2016-10-17 10:27:04 --> URI Class Initialized
DEBUG - 2016-10-17 10:27:04 --> No URI present. Default controller set.
INFO - 2016-10-17 10:27:04 --> Router Class Initialized
INFO - 2016-10-17 10:27:04 --> Output Class Initialized
INFO - 2016-10-17 10:27:04 --> Security Class Initialized
DEBUG - 2016-10-17 10:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:27:04 --> Input Class Initialized
INFO - 2016-10-17 10:27:04 --> Language Class Initialized
INFO - 2016-10-17 10:27:04 --> Loader Class Initialized
INFO - 2016-10-17 10:27:04 --> Helper loaded: url_helper
INFO - 2016-10-17 10:27:04 --> Controller Class Initialized
INFO - 2016-10-17 10:27:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:27:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:27:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:27:04 --> Final output sent to browser
DEBUG - 2016-10-17 10:27:04 --> Total execution time: 0.0024
INFO - 2016-10-17 10:30:42 --> Config Class Initialized
INFO - 2016-10-17 10:30:42 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:30:42 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:30:42 --> Utf8 Class Initialized
INFO - 2016-10-17 10:30:42 --> URI Class Initialized
DEBUG - 2016-10-17 10:30:42 --> No URI present. Default controller set.
INFO - 2016-10-17 10:30:42 --> Router Class Initialized
INFO - 2016-10-17 10:30:42 --> Output Class Initialized
INFO - 2016-10-17 10:30:42 --> Security Class Initialized
DEBUG - 2016-10-17 10:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:30:42 --> Input Class Initialized
INFO - 2016-10-17 10:30:42 --> Language Class Initialized
INFO - 2016-10-17 10:30:42 --> Loader Class Initialized
INFO - 2016-10-17 10:30:42 --> Helper loaded: url_helper
INFO - 2016-10-17 10:30:42 --> Controller Class Initialized
INFO - 2016-10-17 10:30:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:30:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:30:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:30:42 --> Final output sent to browser
DEBUG - 2016-10-17 10:30:42 --> Total execution time: 0.0028
INFO - 2016-10-17 10:31:20 --> Config Class Initialized
INFO - 2016-10-17 10:31:20 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:31:20 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:31:20 --> Utf8 Class Initialized
INFO - 2016-10-17 10:31:20 --> URI Class Initialized
DEBUG - 2016-10-17 10:31:20 --> No URI present. Default controller set.
INFO - 2016-10-17 10:31:20 --> Router Class Initialized
INFO - 2016-10-17 10:31:20 --> Output Class Initialized
INFO - 2016-10-17 10:31:20 --> Security Class Initialized
DEBUG - 2016-10-17 10:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:31:20 --> Input Class Initialized
INFO - 2016-10-17 10:31:20 --> Language Class Initialized
INFO - 2016-10-17 10:31:20 --> Loader Class Initialized
INFO - 2016-10-17 10:31:20 --> Helper loaded: url_helper
INFO - 2016-10-17 10:31:20 --> Controller Class Initialized
INFO - 2016-10-17 10:31:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:31:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:31:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:31:20 --> Final output sent to browser
DEBUG - 2016-10-17 10:31:20 --> Total execution time: 0.0045
INFO - 2016-10-17 10:31:20 --> Config Class Initialized
INFO - 2016-10-17 10:31:20 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:31:20 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:31:20 --> Utf8 Class Initialized
INFO - 2016-10-17 10:31:20 --> URI Class Initialized
DEBUG - 2016-10-17 10:31:20 --> No URI present. Default controller set.
INFO - 2016-10-17 10:31:20 --> Router Class Initialized
INFO - 2016-10-17 10:31:20 --> Output Class Initialized
INFO - 2016-10-17 10:31:20 --> Security Class Initialized
DEBUG - 2016-10-17 10:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:31:20 --> Input Class Initialized
INFO - 2016-10-17 10:31:20 --> Language Class Initialized
INFO - 2016-10-17 10:31:20 --> Loader Class Initialized
INFO - 2016-10-17 10:31:20 --> Helper loaded: url_helper
INFO - 2016-10-17 10:31:20 --> Controller Class Initialized
INFO - 2016-10-17 10:31:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:31:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:31:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:31:20 --> Final output sent to browser
DEBUG - 2016-10-17 10:31:20 --> Total execution time: 0.0043
INFO - 2016-10-17 10:33:55 --> Config Class Initialized
INFO - 2016-10-17 10:33:55 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:33:55 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:33:55 --> Utf8 Class Initialized
INFO - 2016-10-17 10:33:55 --> URI Class Initialized
DEBUG - 2016-10-17 10:33:55 --> No URI present. Default controller set.
INFO - 2016-10-17 10:33:55 --> Router Class Initialized
INFO - 2016-10-17 10:33:55 --> Output Class Initialized
INFO - 2016-10-17 10:33:55 --> Security Class Initialized
DEBUG - 2016-10-17 10:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:33:55 --> Input Class Initialized
INFO - 2016-10-17 10:33:55 --> Language Class Initialized
INFO - 2016-10-17 10:33:55 --> Loader Class Initialized
INFO - 2016-10-17 10:33:55 --> Helper loaded: url_helper
INFO - 2016-10-17 10:33:55 --> Controller Class Initialized
INFO - 2016-10-17 10:33:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:33:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:33:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:33:55 --> Final output sent to browser
DEBUG - 2016-10-17 10:33:55 --> Total execution time: 0.0022
INFO - 2016-10-17 10:34:14 --> Config Class Initialized
INFO - 2016-10-17 10:34:14 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:34:14 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:34:14 --> Utf8 Class Initialized
INFO - 2016-10-17 10:34:14 --> URI Class Initialized
DEBUG - 2016-10-17 10:34:14 --> No URI present. Default controller set.
INFO - 2016-10-17 10:34:14 --> Router Class Initialized
INFO - 2016-10-17 10:34:14 --> Output Class Initialized
INFO - 2016-10-17 10:34:14 --> Security Class Initialized
DEBUG - 2016-10-17 10:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:34:14 --> Input Class Initialized
INFO - 2016-10-17 10:34:14 --> Language Class Initialized
INFO - 2016-10-17 10:34:14 --> Loader Class Initialized
INFO - 2016-10-17 10:34:14 --> Helper loaded: url_helper
INFO - 2016-10-17 10:34:14 --> Controller Class Initialized
INFO - 2016-10-17 10:34:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:34:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:34:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:34:14 --> Final output sent to browser
DEBUG - 2016-10-17 10:34:14 --> Total execution time: 0.0023
INFO - 2016-10-17 10:38:56 --> Config Class Initialized
INFO - 2016-10-17 10:38:56 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:38:56 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:38:56 --> Utf8 Class Initialized
INFO - 2016-10-17 10:38:56 --> URI Class Initialized
DEBUG - 2016-10-17 10:38:56 --> No URI present. Default controller set.
INFO - 2016-10-17 10:38:56 --> Router Class Initialized
INFO - 2016-10-17 10:38:56 --> Output Class Initialized
INFO - 2016-10-17 10:38:56 --> Security Class Initialized
DEBUG - 2016-10-17 10:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:38:56 --> Input Class Initialized
INFO - 2016-10-17 10:38:56 --> Language Class Initialized
INFO - 2016-10-17 10:38:56 --> Loader Class Initialized
INFO - 2016-10-17 10:38:56 --> Helper loaded: url_helper
INFO - 2016-10-17 10:38:56 --> Database Driver Class Initialized
ERROR - 2016-10-17 10:38:56 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 10:38:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 10:38:56 --> Unable to connect to the database
INFO - 2016-10-17 10:38:56 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-17 10:39:00 --> Config Class Initialized
INFO - 2016-10-17 10:39:00 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:39:00 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:39:00 --> Utf8 Class Initialized
INFO - 2016-10-17 10:39:00 --> URI Class Initialized
DEBUG - 2016-10-17 10:39:00 --> No URI present. Default controller set.
INFO - 2016-10-17 10:39:00 --> Router Class Initialized
INFO - 2016-10-17 10:39:00 --> Output Class Initialized
INFO - 2016-10-17 10:39:00 --> Security Class Initialized
DEBUG - 2016-10-17 10:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:39:00 --> Input Class Initialized
INFO - 2016-10-17 10:39:00 --> Language Class Initialized
INFO - 2016-10-17 10:39:00 --> Loader Class Initialized
INFO - 2016-10-17 10:39:00 --> Helper loaded: url_helper
INFO - 2016-10-17 10:39:00 --> Database Driver Class Initialized
ERROR - 2016-10-17 10:39:00 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 10:39:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 10:39:00 --> Unable to connect to the database
INFO - 2016-10-17 10:39:00 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-17 10:39:26 --> Config Class Initialized
INFO - 2016-10-17 10:39:26 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:39:26 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:39:26 --> Utf8 Class Initialized
INFO - 2016-10-17 10:39:26 --> URI Class Initialized
DEBUG - 2016-10-17 10:39:26 --> No URI present. Default controller set.
INFO - 2016-10-17 10:39:26 --> Router Class Initialized
INFO - 2016-10-17 10:39:26 --> Output Class Initialized
INFO - 2016-10-17 10:39:26 --> Security Class Initialized
DEBUG - 2016-10-17 10:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:39:26 --> Input Class Initialized
INFO - 2016-10-17 10:39:26 --> Language Class Initialized
INFO - 2016-10-17 10:39:26 --> Loader Class Initialized
INFO - 2016-10-17 10:39:26 --> Helper loaded: url_helper
INFO - 2016-10-17 10:39:26 --> Helper loaded: form_helper
INFO - 2016-10-17 10:39:26 --> Database Driver Class Initialized
ERROR - 2016-10-17 10:39:26 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 10:39:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 10:39:26 --> Unable to connect to the database
INFO - 2016-10-17 10:39:26 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-17 10:39:50 --> Config Class Initialized
INFO - 2016-10-17 10:39:50 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:39:50 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:39:50 --> Utf8 Class Initialized
INFO - 2016-10-17 10:39:50 --> URI Class Initialized
DEBUG - 2016-10-17 10:39:50 --> No URI present. Default controller set.
INFO - 2016-10-17 10:39:50 --> Router Class Initialized
INFO - 2016-10-17 10:39:50 --> Output Class Initialized
INFO - 2016-10-17 10:39:50 --> Security Class Initialized
DEBUG - 2016-10-17 10:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:39:50 --> Input Class Initialized
INFO - 2016-10-17 10:39:50 --> Language Class Initialized
INFO - 2016-10-17 10:39:50 --> Loader Class Initialized
INFO - 2016-10-17 10:39:50 --> Helper loaded: url_helper
INFO - 2016-10-17 10:39:50 --> Helper loaded: form_helper
INFO - 2016-10-17 10:39:50 --> Database Driver Class Initialized
ERROR - 2016-10-17 10:39:50 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 10:39:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 10:39:50 --> Unable to connect to the database
INFO - 2016-10-17 10:39:50 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-17 10:40:09 --> Config Class Initialized
INFO - 2016-10-17 10:40:09 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:40:09 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:40:09 --> Utf8 Class Initialized
INFO - 2016-10-17 10:40:09 --> URI Class Initialized
DEBUG - 2016-10-17 10:40:09 --> No URI present. Default controller set.
INFO - 2016-10-17 10:40:09 --> Router Class Initialized
INFO - 2016-10-17 10:40:09 --> Output Class Initialized
INFO - 2016-10-17 10:40:09 --> Security Class Initialized
DEBUG - 2016-10-17 10:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:40:09 --> Input Class Initialized
INFO - 2016-10-17 10:40:09 --> Language Class Initialized
INFO - 2016-10-17 10:40:09 --> Loader Class Initialized
INFO - 2016-10-17 10:40:09 --> Helper loaded: url_helper
INFO - 2016-10-17 10:40:09 --> Helper loaded: form_helper
INFO - 2016-10-17 10:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 10:40:09 --> Controller Class Initialized
INFO - 2016-10-17 10:40:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:40:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:40:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:40:09 --> Final output sent to browser
DEBUG - 2016-10-17 10:40:09 --> Total execution time: 0.0055
INFO - 2016-10-17 10:45:25 --> Config Class Initialized
INFO - 2016-10-17 10:45:25 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:45:25 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:45:25 --> Utf8 Class Initialized
INFO - 2016-10-17 10:45:25 --> URI Class Initialized
DEBUG - 2016-10-17 10:45:25 --> No URI present. Default controller set.
INFO - 2016-10-17 10:45:25 --> Router Class Initialized
INFO - 2016-10-17 10:45:25 --> Output Class Initialized
INFO - 2016-10-17 10:45:25 --> Security Class Initialized
DEBUG - 2016-10-17 10:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:45:25 --> Input Class Initialized
INFO - 2016-10-17 10:45:25 --> Language Class Initialized
INFO - 2016-10-17 10:45:25 --> Loader Class Initialized
INFO - 2016-10-17 10:45:25 --> Helper loaded: url_helper
INFO - 2016-10-17 10:45:25 --> Helper loaded: form_helper
INFO - 2016-10-17 10:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 10:45:25 --> Controller Class Initialized
INFO - 2016-10-17 10:45:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:45:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:45:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:45:25 --> Final output sent to browser
DEBUG - 2016-10-17 10:45:25 --> Total execution time: 0.0034
ERROR - 2016-10-17 10:45:25 --> Severity: Warning --> fopen(127.0.0.1:11211?persistent/ci_sessioncd3c76f2266984cc11f20f76793b3e4baede0fe8): failed to open stream: No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2016-10-17 10:45:25 --> Session: File '127.0.0.1:11211?persistent/ci_sessioncd3c76f2266984cc11f20f76793b3e4baede0fe8' doesn't exist and cannot be created.
ERROR - 2016-10-17 10:45:25 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 10:47:46 --> Config Class Initialized
INFO - 2016-10-17 10:47:46 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:47:46 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:47:46 --> Utf8 Class Initialized
INFO - 2016-10-17 10:47:46 --> URI Class Initialized
DEBUG - 2016-10-17 10:47:46 --> No URI present. Default controller set.
INFO - 2016-10-17 10:47:46 --> Router Class Initialized
INFO - 2016-10-17 10:47:46 --> Output Class Initialized
INFO - 2016-10-17 10:47:46 --> Security Class Initialized
DEBUG - 2016-10-17 10:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:47:46 --> Input Class Initialized
INFO - 2016-10-17 10:47:46 --> Language Class Initialized
INFO - 2016-10-17 10:47:46 --> Loader Class Initialized
INFO - 2016-10-17 10:47:46 --> Helper loaded: url_helper
INFO - 2016-10-17 10:47:46 --> Helper loaded: form_helper
INFO - 2016-10-17 10:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 10:47:46 --> Controller Class Initialized
INFO - 2016-10-17 10:47:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:47:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:47:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:47:46 --> Final output sent to browser
DEBUG - 2016-10-17 10:47:46 --> Total execution time: 0.0061
INFO - 2016-10-17 10:51:16 --> Config Class Initialized
INFO - 2016-10-17 10:51:16 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:51:16 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:51:16 --> Utf8 Class Initialized
INFO - 2016-10-17 10:51:16 --> URI Class Initialized
DEBUG - 2016-10-17 10:51:16 --> No URI present. Default controller set.
INFO - 2016-10-17 10:51:16 --> Router Class Initialized
INFO - 2016-10-17 10:51:16 --> Output Class Initialized
INFO - 2016-10-17 10:51:16 --> Security Class Initialized
DEBUG - 2016-10-17 10:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:51:16 --> Input Class Initialized
INFO - 2016-10-17 10:51:16 --> Language Class Initialized
INFO - 2016-10-17 10:51:16 --> Loader Class Initialized
INFO - 2016-10-17 10:51:16 --> Helper loaded: url_helper
INFO - 2016-10-17 10:51:16 --> Helper loaded: form_helper
INFO - 2016-10-17 10:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 10:51:16 --> Controller Class Initialized
INFO - 2016-10-17 10:51:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:51:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:51:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:51:16 --> Final output sent to browser
DEBUG - 2016-10-17 10:51:16 --> Total execution time: 0.0030
ERROR - 2016-10-17 10:51:16 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_sessioncd3c76f2266984cc11f20f76793b3e4baede0fe8 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 10:51:16 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 10:54:51 --> Config Class Initialized
INFO - 2016-10-17 10:54:51 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:54:51 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:54:51 --> Utf8 Class Initialized
INFO - 2016-10-17 10:54:51 --> URI Class Initialized
DEBUG - 2016-10-17 10:54:51 --> No URI present. Default controller set.
INFO - 2016-10-17 10:54:51 --> Router Class Initialized
INFO - 2016-10-17 10:54:51 --> Output Class Initialized
INFO - 2016-10-17 10:54:51 --> Security Class Initialized
DEBUG - 2016-10-17 10:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:54:51 --> Input Class Initialized
INFO - 2016-10-17 10:54:51 --> Language Class Initialized
INFO - 2016-10-17 10:54:51 --> Loader Class Initialized
INFO - 2016-10-17 10:54:51 --> Helper loaded: url_helper
INFO - 2016-10-17 10:54:51 --> Helper loaded: form_helper
INFO - 2016-10-17 10:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 10:54:51 --> Controller Class Initialized
INFO - 2016-10-17 10:54:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:54:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:54:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:54:51 --> Final output sent to browser
DEBUG - 2016-10-17 10:54:51 --> Total execution time: 0.0025
ERROR - 2016-10-17 10:54:51 --> Severity: Warning --> fopen(127.0.0.1:11211?persistent/ci_sessione5c960c8e7eb7a9388c79198affebdc494c45010): failed to open stream: No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2016-10-17 10:54:51 --> Session: File '127.0.0.1:11211?persistent/ci_sessione5c960c8e7eb7a9388c79198affebdc494c45010' doesn't exist and cannot be created.
ERROR - 2016-10-17 10:54:51 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 10:54:55 --> Config Class Initialized
INFO - 2016-10-17 10:54:55 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:54:55 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:54:55 --> Utf8 Class Initialized
INFO - 2016-10-17 10:54:55 --> URI Class Initialized
INFO - 2016-10-17 10:54:55 --> Router Class Initialized
INFO - 2016-10-17 10:54:55 --> Output Class Initialized
INFO - 2016-10-17 10:54:55 --> Security Class Initialized
DEBUG - 2016-10-17 10:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:54:55 --> Input Class Initialized
INFO - 2016-10-17 10:54:55 --> Language Class Initialized
INFO - 2016-10-17 10:54:55 --> Loader Class Initialized
INFO - 2016-10-17 10:54:55 --> Helper loaded: url_helper
INFO - 2016-10-17 10:54:55 --> Helper loaded: form_helper
INFO - 2016-10-17 10:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 10:54:55 --> Controller Class Initialized
INFO - 2016-10-17 10:54:55 --> Form Validation Class Initialized
INFO - 2016-10-17 10:54:55 --> Final output sent to browser
DEBUG - 2016-10-17 10:54:55 --> Total execution time: 0.0047
INFO - 2016-10-17 10:55:03 --> Config Class Initialized
INFO - 2016-10-17 10:55:03 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:55:03 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:55:03 --> Utf8 Class Initialized
INFO - 2016-10-17 10:55:03 --> URI Class Initialized
DEBUG - 2016-10-17 10:55:03 --> No URI present. Default controller set.
INFO - 2016-10-17 10:55:03 --> Router Class Initialized
INFO - 2016-10-17 10:55:03 --> Output Class Initialized
INFO - 2016-10-17 10:55:03 --> Security Class Initialized
DEBUG - 2016-10-17 10:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:55:03 --> Input Class Initialized
INFO - 2016-10-17 10:55:03 --> Language Class Initialized
INFO - 2016-10-17 10:55:03 --> Loader Class Initialized
INFO - 2016-10-17 10:55:03 --> Helper loaded: url_helper
INFO - 2016-10-17 10:55:03 --> Helper loaded: form_helper
INFO - 2016-10-17 10:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 10:55:03 --> Controller Class Initialized
INFO - 2016-10-17 10:55:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:55:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:55:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:55:03 --> Final output sent to browser
DEBUG - 2016-10-17 10:55:03 --> Total execution time: 0.0048
ERROR - 2016-10-17 10:55:03 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_sessione5c960c8e7eb7a9388c79198affebdc494c45010 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 10:55:03 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 10:55:04 --> Config Class Initialized
INFO - 2016-10-17 10:55:04 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:55:04 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:55:04 --> Utf8 Class Initialized
INFO - 2016-10-17 10:55:04 --> URI Class Initialized
DEBUG - 2016-10-17 10:55:04 --> No URI present. Default controller set.
INFO - 2016-10-17 10:55:04 --> Router Class Initialized
INFO - 2016-10-17 10:55:04 --> Output Class Initialized
INFO - 2016-10-17 10:55:04 --> Security Class Initialized
DEBUG - 2016-10-17 10:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:55:04 --> Input Class Initialized
INFO - 2016-10-17 10:55:04 --> Language Class Initialized
INFO - 2016-10-17 10:55:04 --> Loader Class Initialized
INFO - 2016-10-17 10:55:04 --> Helper loaded: url_helper
INFO - 2016-10-17 10:55:04 --> Helper loaded: form_helper
INFO - 2016-10-17 10:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 10:55:04 --> Controller Class Initialized
INFO - 2016-10-17 10:55:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:55:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:55:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:55:04 --> Final output sent to browser
DEBUG - 2016-10-17 10:55:04 --> Total execution time: 0.0026
ERROR - 2016-10-17 10:55:04 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_sessione5c960c8e7eb7a9388c79198affebdc494c45010 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 10:55:04 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 10:56:26 --> Config Class Initialized
INFO - 2016-10-17 10:56:26 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:56:26 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:56:26 --> Utf8 Class Initialized
INFO - 2016-10-17 10:56:26 --> URI Class Initialized
DEBUG - 2016-10-17 10:56:26 --> No URI present. Default controller set.
INFO - 2016-10-17 10:56:26 --> Router Class Initialized
INFO - 2016-10-17 10:56:26 --> Output Class Initialized
INFO - 2016-10-17 10:56:26 --> Security Class Initialized
DEBUG - 2016-10-17 10:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:56:26 --> Input Class Initialized
INFO - 2016-10-17 10:56:26 --> Language Class Initialized
INFO - 2016-10-17 10:56:26 --> Loader Class Initialized
INFO - 2016-10-17 10:56:26 --> Helper loaded: url_helper
INFO - 2016-10-17 10:56:26 --> Helper loaded: form_helper
INFO - 2016-10-17 10:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 10:56:26 --> Controller Class Initialized
INFO - 2016-10-17 10:56:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:56:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:56:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:56:26 --> Final output sent to browser
DEBUG - 2016-10-17 10:56:26 --> Total execution time: 0.0031
ERROR - 2016-10-17 10:56:26 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_sessione5c960c8e7eb7a9388c79198affebdc494c45010 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 10:56:26 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 10:56:34 --> Config Class Initialized
INFO - 2016-10-17 10:56:34 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:56:34 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:56:34 --> Utf8 Class Initialized
INFO - 2016-10-17 10:56:34 --> URI Class Initialized
DEBUG - 2016-10-17 10:56:34 --> No URI present. Default controller set.
INFO - 2016-10-17 10:56:34 --> Router Class Initialized
INFO - 2016-10-17 10:56:34 --> Output Class Initialized
INFO - 2016-10-17 10:56:34 --> Security Class Initialized
DEBUG - 2016-10-17 10:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:56:34 --> Input Class Initialized
INFO - 2016-10-17 10:56:34 --> Language Class Initialized
INFO - 2016-10-17 10:56:34 --> Loader Class Initialized
INFO - 2016-10-17 10:56:34 --> Helper loaded: url_helper
INFO - 2016-10-17 10:56:34 --> Helper loaded: form_helper
INFO - 2016-10-17 10:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 10:56:34 --> Controller Class Initialized
INFO - 2016-10-17 10:56:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:56:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:56:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:56:34 --> Final output sent to browser
DEBUG - 2016-10-17 10:56:34 --> Total execution time: 0.0052
ERROR - 2016-10-17 10:56:34 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_sessione5c960c8e7eb7a9388c79198affebdc494c45010 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 10:56:34 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 10:57:29 --> Config Class Initialized
INFO - 2016-10-17 10:57:29 --> Hooks Class Initialized
DEBUG - 2016-10-17 10:57:29 --> UTF-8 Support Enabled
INFO - 2016-10-17 10:57:29 --> Utf8 Class Initialized
INFO - 2016-10-17 10:57:29 --> URI Class Initialized
DEBUG - 2016-10-17 10:57:29 --> No URI present. Default controller set.
INFO - 2016-10-17 10:57:29 --> Router Class Initialized
INFO - 2016-10-17 10:57:29 --> Output Class Initialized
INFO - 2016-10-17 10:57:29 --> Security Class Initialized
DEBUG - 2016-10-17 10:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 10:57:29 --> Input Class Initialized
INFO - 2016-10-17 10:57:29 --> Language Class Initialized
INFO - 2016-10-17 10:57:29 --> Loader Class Initialized
INFO - 2016-10-17 10:57:29 --> Helper loaded: url_helper
INFO - 2016-10-17 10:57:29 --> Helper loaded: form_helper
INFO - 2016-10-17 10:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 10:57:29 --> Controller Class Initialized
INFO - 2016-10-17 10:57:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 10:57:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 10:57:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 10:57:29 --> Final output sent to browser
DEBUG - 2016-10-17 10:57:29 --> Total execution time: 0.0029
ERROR - 2016-10-17 10:57:29 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_sessione5c960c8e7eb7a9388c79198affebdc494c45010 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 10:57:29 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 11:20:04 --> Config Class Initialized
INFO - 2016-10-17 11:20:04 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:20:04 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:20:04 --> Utf8 Class Initialized
INFO - 2016-10-17 11:20:04 --> URI Class Initialized
DEBUG - 2016-10-17 11:20:04 --> No URI present. Default controller set.
INFO - 2016-10-17 11:20:04 --> Router Class Initialized
INFO - 2016-10-17 11:20:04 --> Output Class Initialized
INFO - 2016-10-17 11:20:04 --> Security Class Initialized
DEBUG - 2016-10-17 11:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:20:04 --> Input Class Initialized
INFO - 2016-10-17 11:20:04 --> Language Class Initialized
INFO - 2016-10-17 11:20:04 --> Loader Class Initialized
INFO - 2016-10-17 11:20:04 --> Helper loaded: url_helper
INFO - 2016-10-17 11:20:04 --> Helper loaded: form_helper
INFO - 2016-10-17 11:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:20:04 --> Controller Class Initialized
INFO - 2016-10-17 11:20:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:20:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:20:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:20:04 --> Final output sent to browser
DEBUG - 2016-10-17 11:20:04 --> Total execution time: 0.0057
ERROR - 2016-10-17 11:20:04 --> Severity: Warning --> fopen(127.0.0.1:11211?persistent/ci_session583f200983e6a70de18edfe444e8c35235b94846): failed to open stream: No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2016-10-17 11:20:04 --> Session: File '127.0.0.1:11211?persistent/ci_session583f200983e6a70de18edfe444e8c35235b94846' doesn't exist and cannot be created.
ERROR - 2016-10-17 11:20:04 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 11:20:07 --> Config Class Initialized
INFO - 2016-10-17 11:20:07 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:20:07 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:20:07 --> Utf8 Class Initialized
INFO - 2016-10-17 11:20:07 --> URI Class Initialized
DEBUG - 2016-10-17 11:20:07 --> No URI present. Default controller set.
INFO - 2016-10-17 11:20:07 --> Router Class Initialized
INFO - 2016-10-17 11:20:07 --> Output Class Initialized
INFO - 2016-10-17 11:20:07 --> Security Class Initialized
DEBUG - 2016-10-17 11:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:20:07 --> Input Class Initialized
INFO - 2016-10-17 11:20:07 --> Language Class Initialized
INFO - 2016-10-17 11:20:07 --> Loader Class Initialized
INFO - 2016-10-17 11:20:07 --> Helper loaded: url_helper
INFO - 2016-10-17 11:20:07 --> Helper loaded: form_helper
INFO - 2016-10-17 11:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:20:07 --> Controller Class Initialized
INFO - 2016-10-17 11:20:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:20:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:20:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:20:07 --> Final output sent to browser
DEBUG - 2016-10-17 11:20:07 --> Total execution time: 0.0032
INFO - 2016-10-17 11:20:09 --> Config Class Initialized
INFO - 2016-10-17 11:20:09 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:20:09 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:20:09 --> Utf8 Class Initialized
INFO - 2016-10-17 11:20:09 --> URI Class Initialized
DEBUG - 2016-10-17 11:20:09 --> No URI present. Default controller set.
INFO - 2016-10-17 11:20:09 --> Router Class Initialized
INFO - 2016-10-17 11:20:09 --> Output Class Initialized
INFO - 2016-10-17 11:20:09 --> Security Class Initialized
DEBUG - 2016-10-17 11:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:20:09 --> Input Class Initialized
INFO - 2016-10-17 11:20:09 --> Language Class Initialized
INFO - 2016-10-17 11:20:09 --> Loader Class Initialized
INFO - 2016-10-17 11:20:09 --> Helper loaded: url_helper
INFO - 2016-10-17 11:20:09 --> Helper loaded: form_helper
INFO - 2016-10-17 11:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:20:09 --> Controller Class Initialized
INFO - 2016-10-17 11:20:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:20:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:20:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:20:09 --> Final output sent to browser
DEBUG - 2016-10-17 11:20:09 --> Total execution time: 0.0022
ERROR - 2016-10-17 11:20:09 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session583f200983e6a70de18edfe444e8c35235b94846 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 11:20:09 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 11:20:09 --> Config Class Initialized
INFO - 2016-10-17 11:20:09 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:20:09 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:20:09 --> Utf8 Class Initialized
INFO - 2016-10-17 11:20:09 --> URI Class Initialized
DEBUG - 2016-10-17 11:20:09 --> No URI present. Default controller set.
INFO - 2016-10-17 11:20:09 --> Router Class Initialized
INFO - 2016-10-17 11:20:09 --> Output Class Initialized
INFO - 2016-10-17 11:20:09 --> Security Class Initialized
DEBUG - 2016-10-17 11:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:20:09 --> Input Class Initialized
INFO - 2016-10-17 11:20:09 --> Language Class Initialized
INFO - 2016-10-17 11:20:09 --> Loader Class Initialized
INFO - 2016-10-17 11:20:09 --> Helper loaded: url_helper
INFO - 2016-10-17 11:20:09 --> Helper loaded: form_helper
INFO - 2016-10-17 11:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:20:09 --> Controller Class Initialized
INFO - 2016-10-17 11:20:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:20:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:20:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:20:09 --> Final output sent to browser
DEBUG - 2016-10-17 11:20:09 --> Total execution time: 0.0021
ERROR - 2016-10-17 11:20:09 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session583f200983e6a70de18edfe444e8c35235b94846 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 11:20:09 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 11:20:09 --> Config Class Initialized
INFO - 2016-10-17 11:20:09 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:20:09 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:20:09 --> Utf8 Class Initialized
INFO - 2016-10-17 11:20:09 --> URI Class Initialized
DEBUG - 2016-10-17 11:20:09 --> No URI present. Default controller set.
INFO - 2016-10-17 11:20:09 --> Router Class Initialized
INFO - 2016-10-17 11:20:09 --> Output Class Initialized
INFO - 2016-10-17 11:20:09 --> Security Class Initialized
DEBUG - 2016-10-17 11:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:20:09 --> Input Class Initialized
INFO - 2016-10-17 11:20:09 --> Language Class Initialized
INFO - 2016-10-17 11:20:09 --> Loader Class Initialized
INFO - 2016-10-17 11:20:09 --> Helper loaded: url_helper
INFO - 2016-10-17 11:20:09 --> Helper loaded: form_helper
INFO - 2016-10-17 11:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:20:09 --> Controller Class Initialized
INFO - 2016-10-17 11:20:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:20:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:20:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:20:09 --> Final output sent to browser
DEBUG - 2016-10-17 11:20:09 --> Total execution time: 0.0019
ERROR - 2016-10-17 11:20:09 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session583f200983e6a70de18edfe444e8c35235b94846 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 11:20:09 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 11:20:10 --> Config Class Initialized
INFO - 2016-10-17 11:20:10 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:20:10 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:20:10 --> Utf8 Class Initialized
INFO - 2016-10-17 11:20:10 --> URI Class Initialized
DEBUG - 2016-10-17 11:20:10 --> No URI present. Default controller set.
INFO - 2016-10-17 11:20:10 --> Router Class Initialized
INFO - 2016-10-17 11:20:10 --> Output Class Initialized
INFO - 2016-10-17 11:20:10 --> Security Class Initialized
DEBUG - 2016-10-17 11:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:20:10 --> Input Class Initialized
INFO - 2016-10-17 11:20:10 --> Language Class Initialized
INFO - 2016-10-17 11:20:10 --> Loader Class Initialized
INFO - 2016-10-17 11:20:10 --> Helper loaded: url_helper
INFO - 2016-10-17 11:20:10 --> Helper loaded: form_helper
INFO - 2016-10-17 11:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:20:10 --> Controller Class Initialized
INFO - 2016-10-17 11:20:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:20:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:20:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:20:10 --> Final output sent to browser
DEBUG - 2016-10-17 11:20:10 --> Total execution time: 0.0023
ERROR - 2016-10-17 11:20:10 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session583f200983e6a70de18edfe444e8c35235b94846 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 11:20:10 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 11:22:57 --> Config Class Initialized
INFO - 2016-10-17 11:22:57 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:22:57 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:22:57 --> Utf8 Class Initialized
INFO - 2016-10-17 11:22:57 --> URI Class Initialized
DEBUG - 2016-10-17 11:22:57 --> No URI present. Default controller set.
INFO - 2016-10-17 11:22:57 --> Router Class Initialized
INFO - 2016-10-17 11:22:57 --> Output Class Initialized
INFO - 2016-10-17 11:22:57 --> Security Class Initialized
DEBUG - 2016-10-17 11:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:22:57 --> Input Class Initialized
INFO - 2016-10-17 11:22:57 --> Language Class Initialized
INFO - 2016-10-17 11:22:57 --> Loader Class Initialized
INFO - 2016-10-17 11:22:57 --> Helper loaded: url_helper
INFO - 2016-10-17 11:22:57 --> Helper loaded: form_helper
INFO - 2016-10-17 11:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:22:57 --> Controller Class Initialized
INFO - 2016-10-17 11:22:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:22:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:22:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:22:57 --> Final output sent to browser
DEBUG - 2016-10-17 11:22:57 --> Total execution time: 0.0030
ERROR - 2016-10-17 11:22:57 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session583f200983e6a70de18edfe444e8c35235b94846 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 11:22:57 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 11:22:58 --> Config Class Initialized
INFO - 2016-10-17 11:22:58 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:22:58 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:22:58 --> Utf8 Class Initialized
INFO - 2016-10-17 11:22:58 --> URI Class Initialized
DEBUG - 2016-10-17 11:22:58 --> No URI present. Default controller set.
INFO - 2016-10-17 11:22:58 --> Router Class Initialized
INFO - 2016-10-17 11:22:58 --> Output Class Initialized
INFO - 2016-10-17 11:22:58 --> Security Class Initialized
DEBUG - 2016-10-17 11:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:22:58 --> Input Class Initialized
INFO - 2016-10-17 11:22:58 --> Language Class Initialized
INFO - 2016-10-17 11:22:58 --> Loader Class Initialized
INFO - 2016-10-17 11:22:58 --> Helper loaded: url_helper
INFO - 2016-10-17 11:22:58 --> Helper loaded: form_helper
INFO - 2016-10-17 11:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:22:58 --> Controller Class Initialized
INFO - 2016-10-17 11:22:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:22:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:22:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:22:58 --> Final output sent to browser
DEBUG - 2016-10-17 11:22:58 --> Total execution time: 0.0022
ERROR - 2016-10-17 11:22:58 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session583f200983e6a70de18edfe444e8c35235b94846 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 11:22:58 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 11:22:59 --> Config Class Initialized
INFO - 2016-10-17 11:22:59 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:22:59 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:22:59 --> Utf8 Class Initialized
INFO - 2016-10-17 11:22:59 --> URI Class Initialized
DEBUG - 2016-10-17 11:22:59 --> No URI present. Default controller set.
INFO - 2016-10-17 11:22:59 --> Router Class Initialized
INFO - 2016-10-17 11:22:59 --> Output Class Initialized
INFO - 2016-10-17 11:22:59 --> Security Class Initialized
DEBUG - 2016-10-17 11:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:22:59 --> Input Class Initialized
INFO - 2016-10-17 11:22:59 --> Language Class Initialized
INFO - 2016-10-17 11:22:59 --> Loader Class Initialized
INFO - 2016-10-17 11:22:59 --> Helper loaded: url_helper
INFO - 2016-10-17 11:22:59 --> Helper loaded: form_helper
INFO - 2016-10-17 11:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:22:59 --> Controller Class Initialized
INFO - 2016-10-17 11:22:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:22:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:22:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:22:59 --> Final output sent to browser
DEBUG - 2016-10-17 11:22:59 --> Total execution time: 0.0026
ERROR - 2016-10-17 11:22:59 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session583f200983e6a70de18edfe444e8c35235b94846 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 11:22:59 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 11:22:59 --> Config Class Initialized
INFO - 2016-10-17 11:22:59 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:22:59 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:22:59 --> Utf8 Class Initialized
INFO - 2016-10-17 11:22:59 --> URI Class Initialized
DEBUG - 2016-10-17 11:22:59 --> No URI present. Default controller set.
INFO - 2016-10-17 11:22:59 --> Router Class Initialized
INFO - 2016-10-17 11:22:59 --> Output Class Initialized
INFO - 2016-10-17 11:22:59 --> Security Class Initialized
DEBUG - 2016-10-17 11:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:22:59 --> Input Class Initialized
INFO - 2016-10-17 11:22:59 --> Language Class Initialized
INFO - 2016-10-17 11:22:59 --> Loader Class Initialized
INFO - 2016-10-17 11:22:59 --> Helper loaded: url_helper
INFO - 2016-10-17 11:22:59 --> Helper loaded: form_helper
INFO - 2016-10-17 11:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:22:59 --> Controller Class Initialized
INFO - 2016-10-17 11:22:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:22:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:22:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:22:59 --> Final output sent to browser
DEBUG - 2016-10-17 11:22:59 --> Total execution time: 0.0022
ERROR - 2016-10-17 11:22:59 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session583f200983e6a70de18edfe444e8c35235b94846 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 11:22:59 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 11:24:40 --> Config Class Initialized
INFO - 2016-10-17 11:24:40 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:24:40 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:24:40 --> Utf8 Class Initialized
INFO - 2016-10-17 11:24:40 --> URI Class Initialized
DEBUG - 2016-10-17 11:24:40 --> No URI present. Default controller set.
INFO - 2016-10-17 11:24:40 --> Router Class Initialized
INFO - 2016-10-17 11:24:40 --> Output Class Initialized
INFO - 2016-10-17 11:24:40 --> Security Class Initialized
DEBUG - 2016-10-17 11:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:24:40 --> Input Class Initialized
INFO - 2016-10-17 11:24:40 --> Language Class Initialized
INFO - 2016-10-17 11:24:40 --> Loader Class Initialized
INFO - 2016-10-17 11:24:40 --> Helper loaded: url_helper
INFO - 2016-10-17 11:24:40 --> Helper loaded: form_helper
INFO - 2016-10-17 11:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:24:40 --> Controller Class Initialized
INFO - 2016-10-17 11:24:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:24:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:24:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:24:40 --> Final output sent to browser
DEBUG - 2016-10-17 11:24:40 --> Total execution time: 0.0030
ERROR - 2016-10-17 11:24:40 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session583f200983e6a70de18edfe444e8c35235b94846 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 11:24:40 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 11:27:08 --> Config Class Initialized
INFO - 2016-10-17 11:27:08 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:27:08 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:27:08 --> Utf8 Class Initialized
INFO - 2016-10-17 11:27:08 --> URI Class Initialized
DEBUG - 2016-10-17 11:27:08 --> No URI present. Default controller set.
INFO - 2016-10-17 11:27:08 --> Router Class Initialized
INFO - 2016-10-17 11:27:08 --> Output Class Initialized
INFO - 2016-10-17 11:27:08 --> Security Class Initialized
DEBUG - 2016-10-17 11:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:27:08 --> Input Class Initialized
INFO - 2016-10-17 11:27:08 --> Language Class Initialized
INFO - 2016-10-17 11:27:08 --> Loader Class Initialized
INFO - 2016-10-17 11:27:08 --> Helper loaded: url_helper
INFO - 2016-10-17 11:27:08 --> Helper loaded: form_helper
INFO - 2016-10-17 11:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:27:08 --> Controller Class Initialized
INFO - 2016-10-17 11:27:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:27:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:27:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:27:08 --> Final output sent to browser
DEBUG - 2016-10-17 11:27:08 --> Total execution time: 0.0033
ERROR - 2016-10-17 11:27:08 --> Severity: Warning --> fopen(127.0.0.1:11211?persistent/ci_session0048f7851a29212cdf8c9f5b772edc7f38b16779): failed to open stream: No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2016-10-17 11:27:08 --> Session: File '127.0.0.1:11211?persistent/ci_session0048f7851a29212cdf8c9f5b772edc7f38b16779' doesn't exist and cannot be created.
ERROR - 2016-10-17 11:27:08 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 11:27:29 --> Config Class Initialized
INFO - 2016-10-17 11:27:29 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:27:29 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:27:29 --> Utf8 Class Initialized
INFO - 2016-10-17 11:27:29 --> URI Class Initialized
DEBUG - 2016-10-17 11:27:29 --> No URI present. Default controller set.
INFO - 2016-10-17 11:27:29 --> Router Class Initialized
INFO - 2016-10-17 11:27:29 --> Output Class Initialized
INFO - 2016-10-17 11:27:29 --> Security Class Initialized
DEBUG - 2016-10-17 11:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:27:29 --> Input Class Initialized
INFO - 2016-10-17 11:27:29 --> Language Class Initialized
INFO - 2016-10-17 11:27:29 --> Loader Class Initialized
INFO - 2016-10-17 11:27:29 --> Helper loaded: url_helper
INFO - 2016-10-17 11:27:29 --> Helper loaded: form_helper
INFO - 2016-10-17 11:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:27:29 --> Controller Class Initialized
INFO - 2016-10-17 11:27:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:27:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:27:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:27:29 --> Final output sent to browser
DEBUG - 2016-10-17 11:27:29 --> Total execution time: 0.0025
INFO - 2016-10-17 11:30:15 --> Config Class Initialized
INFO - 2016-10-17 11:30:15 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:30:15 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:30:15 --> Utf8 Class Initialized
INFO - 2016-10-17 11:30:15 --> URI Class Initialized
DEBUG - 2016-10-17 11:30:15 --> No URI present. Default controller set.
INFO - 2016-10-17 11:30:15 --> Router Class Initialized
INFO - 2016-10-17 11:30:15 --> Output Class Initialized
INFO - 2016-10-17 11:30:15 --> Security Class Initialized
DEBUG - 2016-10-17 11:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:30:15 --> Input Class Initialized
INFO - 2016-10-17 11:30:15 --> Language Class Initialized
INFO - 2016-10-17 11:30:15 --> Loader Class Initialized
INFO - 2016-10-17 11:30:15 --> Helper loaded: url_helper
INFO - 2016-10-17 11:30:15 --> Helper loaded: form_helper
INFO - 2016-10-17 11:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:30:15 --> Controller Class Initialized
INFO - 2016-10-17 11:30:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:30:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:30:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:30:15 --> Final output sent to browser
DEBUG - 2016-10-17 11:30:15 --> Total execution time: 0.0058
ERROR - 2016-10-17 11:30:15 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session0048f7851a29212cdf8c9f5b772edc7f38b16779 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 11:30:15 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 11:30:23 --> Config Class Initialized
INFO - 2016-10-17 11:30:23 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:30:23 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:30:23 --> Utf8 Class Initialized
INFO - 2016-10-17 11:30:23 --> URI Class Initialized
DEBUG - 2016-10-17 11:30:23 --> No URI present. Default controller set.
INFO - 2016-10-17 11:30:23 --> Router Class Initialized
INFO - 2016-10-17 11:30:23 --> Output Class Initialized
INFO - 2016-10-17 11:30:23 --> Security Class Initialized
DEBUG - 2016-10-17 11:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:30:23 --> Input Class Initialized
INFO - 2016-10-17 11:30:23 --> Language Class Initialized
INFO - 2016-10-17 11:30:23 --> Loader Class Initialized
INFO - 2016-10-17 11:30:23 --> Helper loaded: url_helper
INFO - 2016-10-17 11:30:23 --> Helper loaded: form_helper
INFO - 2016-10-17 11:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:30:23 --> Controller Class Initialized
INFO - 2016-10-17 11:30:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:30:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:30:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:30:23 --> Final output sent to browser
DEBUG - 2016-10-17 11:30:23 --> Total execution time: 0.0027
ERROR - 2016-10-17 11:30:23 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session0048f7851a29212cdf8c9f5b772edc7f38b16779 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 11:30:23 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 11:30:48 --> Config Class Initialized
INFO - 2016-10-17 11:30:48 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:30:48 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:30:48 --> Utf8 Class Initialized
INFO - 2016-10-17 11:30:48 --> URI Class Initialized
DEBUG - 2016-10-17 11:30:48 --> No URI present. Default controller set.
INFO - 2016-10-17 11:30:48 --> Router Class Initialized
INFO - 2016-10-17 11:30:48 --> Output Class Initialized
INFO - 2016-10-17 11:30:48 --> Security Class Initialized
DEBUG - 2016-10-17 11:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:30:48 --> Input Class Initialized
INFO - 2016-10-17 11:30:48 --> Language Class Initialized
INFO - 2016-10-17 11:30:48 --> Loader Class Initialized
INFO - 2016-10-17 11:30:48 --> Helper loaded: url_helper
INFO - 2016-10-17 11:30:48 --> Helper loaded: form_helper
INFO - 2016-10-17 11:30:48 --> Database Driver Class Initialized
ERROR - 2016-10-17 11:30:48 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 11:30:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 11:30:48 --> Unable to connect to the database
INFO - 2016-10-17 11:30:48 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-17 11:30:58 --> Config Class Initialized
INFO - 2016-10-17 11:30:58 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:30:58 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:30:58 --> Utf8 Class Initialized
INFO - 2016-10-17 11:30:58 --> URI Class Initialized
DEBUG - 2016-10-17 11:30:58 --> No URI present. Default controller set.
INFO - 2016-10-17 11:30:58 --> Router Class Initialized
INFO - 2016-10-17 11:30:58 --> Output Class Initialized
INFO - 2016-10-17 11:30:58 --> Security Class Initialized
DEBUG - 2016-10-17 11:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:30:58 --> Input Class Initialized
INFO - 2016-10-17 11:30:58 --> Language Class Initialized
INFO - 2016-10-17 11:30:58 --> Loader Class Initialized
INFO - 2016-10-17 11:30:58 --> Helper loaded: url_helper
INFO - 2016-10-17 11:30:58 --> Helper loaded: form_helper
INFO - 2016-10-17 11:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:30:58 --> Controller Class Initialized
INFO - 2016-10-17 11:30:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:30:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:30:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:30:58 --> Final output sent to browser
DEBUG - 2016-10-17 11:30:58 --> Total execution time: 0.0029
ERROR - 2016-10-17 11:30:58 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session0048f7851a29212cdf8c9f5b772edc7f38b16779 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 11:30:58 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 11:36:19 --> Config Class Initialized
INFO - 2016-10-17 11:36:19 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:36:19 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:36:19 --> Utf8 Class Initialized
INFO - 2016-10-17 11:36:19 --> URI Class Initialized
DEBUG - 2016-10-17 11:36:19 --> No URI present. Default controller set.
INFO - 2016-10-17 11:36:19 --> Router Class Initialized
INFO - 2016-10-17 11:36:19 --> Output Class Initialized
INFO - 2016-10-17 11:36:19 --> Security Class Initialized
DEBUG - 2016-10-17 11:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:36:19 --> Input Class Initialized
INFO - 2016-10-17 11:36:19 --> Language Class Initialized
INFO - 2016-10-17 11:36:19 --> Loader Class Initialized
INFO - 2016-10-17 11:36:19 --> Helper loaded: url_helper
INFO - 2016-10-17 11:36:19 --> Helper loaded: form_helper
INFO - 2016-10-17 11:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:36:19 --> Controller Class Initialized
INFO - 2016-10-17 11:36:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:36:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:36:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:36:19 --> Final output sent to browser
DEBUG - 2016-10-17 11:36:19 --> Total execution time: 0.0034
ERROR - 2016-10-17 11:36:19 --> Severity: Warning --> fopen(127.0.0.1:11211?persistent/ci_session96c5a6e6251b1770aeba5e60607a09d8aa483fa1): failed to open stream: No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2016-10-17 11:36:19 --> Session: File '127.0.0.1:11211?persistent/ci_session96c5a6e6251b1770aeba5e60607a09d8aa483fa1' doesn't exist and cannot be created.
ERROR - 2016-10-17 11:36:19 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 11:45:22 --> Config Class Initialized
INFO - 2016-10-17 11:45:22 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:45:22 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:45:22 --> Utf8 Class Initialized
INFO - 2016-10-17 11:45:22 --> URI Class Initialized
DEBUG - 2016-10-17 11:45:22 --> No URI present. Default controller set.
INFO - 2016-10-17 11:45:22 --> Router Class Initialized
INFO - 2016-10-17 11:45:22 --> Output Class Initialized
INFO - 2016-10-17 11:45:22 --> Security Class Initialized
DEBUG - 2016-10-17 11:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:45:22 --> Input Class Initialized
INFO - 2016-10-17 11:45:22 --> Language Class Initialized
INFO - 2016-10-17 11:45:22 --> Loader Class Initialized
INFO - 2016-10-17 11:45:22 --> Helper loaded: url_helper
INFO - 2016-10-17 11:45:22 --> Helper loaded: form_helper
INFO - 2016-10-17 11:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:45:22 --> Controller Class Initialized
INFO - 2016-10-17 11:45:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:45:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:45:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:45:22 --> Final output sent to browser
DEBUG - 2016-10-17 11:45:22 --> Total execution time: 0.0059
INFO - 2016-10-17 11:45:23 --> Config Class Initialized
INFO - 2016-10-17 11:45:23 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:45:23 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:45:23 --> Utf8 Class Initialized
INFO - 2016-10-17 11:45:23 --> URI Class Initialized
DEBUG - 2016-10-17 11:45:23 --> No URI present. Default controller set.
INFO - 2016-10-17 11:45:23 --> Router Class Initialized
INFO - 2016-10-17 11:45:23 --> Output Class Initialized
INFO - 2016-10-17 11:45:23 --> Security Class Initialized
DEBUG - 2016-10-17 11:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:45:23 --> Input Class Initialized
INFO - 2016-10-17 11:45:23 --> Language Class Initialized
INFO - 2016-10-17 11:45:23 --> Loader Class Initialized
INFO - 2016-10-17 11:45:23 --> Helper loaded: url_helper
INFO - 2016-10-17 11:45:23 --> Helper loaded: form_helper
INFO - 2016-10-17 11:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:45:23 --> Controller Class Initialized
INFO - 2016-10-17 11:45:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:45:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:45:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:45:23 --> Final output sent to browser
DEBUG - 2016-10-17 11:45:23 --> Total execution time: 0.0049
ERROR - 2016-10-17 11:45:23 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session96c5a6e6251b1770aeba5e60607a09d8aa483fa1 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 11:45:23 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 11:48:42 --> Config Class Initialized
INFO - 2016-10-17 11:48:42 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:48:42 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:48:42 --> Utf8 Class Initialized
INFO - 2016-10-17 11:48:42 --> URI Class Initialized
DEBUG - 2016-10-17 11:48:42 --> No URI present. Default controller set.
INFO - 2016-10-17 11:48:42 --> Router Class Initialized
INFO - 2016-10-17 11:48:42 --> Output Class Initialized
INFO - 2016-10-17 11:48:42 --> Security Class Initialized
DEBUG - 2016-10-17 11:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:48:42 --> Input Class Initialized
INFO - 2016-10-17 11:48:42 --> Language Class Initialized
INFO - 2016-10-17 11:48:42 --> Loader Class Initialized
INFO - 2016-10-17 11:48:42 --> Helper loaded: url_helper
INFO - 2016-10-17 11:48:42 --> Helper loaded: form_helper
INFO - 2016-10-17 11:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:48:42 --> Controller Class Initialized
INFO - 2016-10-17 11:48:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:48:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:48:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:48:42 --> Final output sent to browser
DEBUG - 2016-10-17 11:48:42 --> Total execution time: 0.0055
ERROR - 2016-10-17 11:48:42 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session96c5a6e6251b1770aeba5e60607a09d8aa483fa1 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 11:48:42 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 11:49:30 --> Config Class Initialized
INFO - 2016-10-17 11:49:30 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:49:30 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:49:30 --> Utf8 Class Initialized
INFO - 2016-10-17 11:49:30 --> URI Class Initialized
DEBUG - 2016-10-17 11:49:30 --> No URI present. Default controller set.
INFO - 2016-10-17 11:49:30 --> Router Class Initialized
INFO - 2016-10-17 11:49:30 --> Output Class Initialized
INFO - 2016-10-17 11:49:30 --> Security Class Initialized
DEBUG - 2016-10-17 11:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:49:30 --> Input Class Initialized
INFO - 2016-10-17 11:49:30 --> Language Class Initialized
INFO - 2016-10-17 11:49:30 --> Loader Class Initialized
INFO - 2016-10-17 11:49:30 --> Helper loaded: url_helper
INFO - 2016-10-17 11:49:30 --> Helper loaded: form_helper
INFO - 2016-10-17 11:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:49:30 --> Controller Class Initialized
INFO - 2016-10-17 11:49:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:49:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:49:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:49:30 --> Final output sent to browser
DEBUG - 2016-10-17 11:49:30 --> Total execution time: 0.0055
ERROR - 2016-10-17 11:49:30 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session96c5a6e6251b1770aeba5e60607a09d8aa483fa1 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 11:49:30 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 11:50:10 --> Config Class Initialized
INFO - 2016-10-17 11:50:10 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:50:10 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:50:10 --> Utf8 Class Initialized
INFO - 2016-10-17 11:50:10 --> URI Class Initialized
DEBUG - 2016-10-17 11:50:10 --> No URI present. Default controller set.
INFO - 2016-10-17 11:50:10 --> Router Class Initialized
INFO - 2016-10-17 11:50:10 --> Output Class Initialized
INFO - 2016-10-17 11:50:10 --> Security Class Initialized
DEBUG - 2016-10-17 11:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:50:10 --> Input Class Initialized
INFO - 2016-10-17 11:50:10 --> Language Class Initialized
INFO - 2016-10-17 11:50:10 --> Loader Class Initialized
INFO - 2016-10-17 11:50:10 --> Helper loaded: url_helper
INFO - 2016-10-17 11:50:10 --> Helper loaded: form_helper
INFO - 2016-10-17 11:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:50:10 --> Controller Class Initialized
INFO - 2016-10-17 11:50:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:50:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:50:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:50:10 --> Final output sent to browser
DEBUG - 2016-10-17 11:50:10 --> Total execution time: 0.0057
ERROR - 2016-10-17 11:50:10 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session96c5a6e6251b1770aeba5e60607a09d8aa483fa1 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 11:50:10 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 11:51:52 --> Config Class Initialized
INFO - 2016-10-17 11:51:52 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:51:52 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:51:52 --> Utf8 Class Initialized
INFO - 2016-10-17 11:51:52 --> URI Class Initialized
DEBUG - 2016-10-17 11:51:52 --> No URI present. Default controller set.
INFO - 2016-10-17 11:51:52 --> Router Class Initialized
INFO - 2016-10-17 11:51:52 --> Output Class Initialized
INFO - 2016-10-17 11:51:52 --> Security Class Initialized
DEBUG - 2016-10-17 11:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:51:52 --> Input Class Initialized
INFO - 2016-10-17 11:51:52 --> Language Class Initialized
INFO - 2016-10-17 11:51:52 --> Loader Class Initialized
INFO - 2016-10-17 11:51:52 --> Helper loaded: url_helper
INFO - 2016-10-17 11:51:52 --> Helper loaded: form_helper
INFO - 2016-10-17 11:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:51:52 --> Controller Class Initialized
INFO - 2016-10-17 11:51:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:51:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:51:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:51:52 --> Final output sent to browser
DEBUG - 2016-10-17 11:51:52 --> Total execution time: 0.0051
ERROR - 2016-10-17 11:51:52 --> Severity: Warning --> fopen(127.0.0.1:11211?persistent/ci_session2f136347e6d8b3efaf202c0a245f54aabe73fac7): failed to open stream: No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2016-10-17 11:51:52 --> Session: File '127.0.0.1:11211?persistent/ci_session2f136347e6d8b3efaf202c0a245f54aabe73fac7' doesn't exist and cannot be created.
ERROR - 2016-10-17 11:51:52 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 11:54:08 --> Config Class Initialized
INFO - 2016-10-17 11:54:08 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:54:08 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:54:08 --> Utf8 Class Initialized
INFO - 2016-10-17 11:54:08 --> URI Class Initialized
DEBUG - 2016-10-17 11:54:08 --> No URI present. Default controller set.
INFO - 2016-10-17 11:54:08 --> Router Class Initialized
INFO - 2016-10-17 11:54:08 --> Output Class Initialized
INFO - 2016-10-17 11:54:08 --> Security Class Initialized
DEBUG - 2016-10-17 11:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:54:08 --> Input Class Initialized
INFO - 2016-10-17 11:54:08 --> Language Class Initialized
INFO - 2016-10-17 11:54:08 --> Loader Class Initialized
INFO - 2016-10-17 11:54:08 --> Helper loaded: url_helper
INFO - 2016-10-17 11:54:08 --> Helper loaded: form_helper
INFO - 2016-10-17 11:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:54:08 --> Controller Class Initialized
INFO - 2016-10-17 11:54:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:54:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:54:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:54:08 --> Final output sent to browser
DEBUG - 2016-10-17 11:54:08 --> Total execution time: 0.0030
INFO - 2016-10-17 11:54:09 --> Config Class Initialized
INFO - 2016-10-17 11:54:09 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:54:09 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:54:09 --> Utf8 Class Initialized
INFO - 2016-10-17 11:54:09 --> URI Class Initialized
DEBUG - 2016-10-17 11:54:09 --> No URI present. Default controller set.
INFO - 2016-10-17 11:54:09 --> Router Class Initialized
INFO - 2016-10-17 11:54:09 --> Output Class Initialized
INFO - 2016-10-17 11:54:09 --> Security Class Initialized
DEBUG - 2016-10-17 11:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:54:09 --> Input Class Initialized
INFO - 2016-10-17 11:54:09 --> Language Class Initialized
INFO - 2016-10-17 11:54:09 --> Loader Class Initialized
INFO - 2016-10-17 11:54:09 --> Helper loaded: url_helper
INFO - 2016-10-17 11:54:09 --> Helper loaded: form_helper
INFO - 2016-10-17 11:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:54:09 --> Controller Class Initialized
INFO - 2016-10-17 11:54:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:54:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:54:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:54:09 --> Final output sent to browser
DEBUG - 2016-10-17 11:54:09 --> Total execution time: 0.0054
ERROR - 2016-10-17 11:54:09 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session2f136347e6d8b3efaf202c0a245f54aabe73fac7 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 11:54:09 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 11:55:17 --> Config Class Initialized
INFO - 2016-10-17 11:55:17 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:55:17 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:55:17 --> Utf8 Class Initialized
INFO - 2016-10-17 11:55:17 --> URI Class Initialized
DEBUG - 2016-10-17 11:55:17 --> No URI present. Default controller set.
INFO - 2016-10-17 11:55:17 --> Router Class Initialized
INFO - 2016-10-17 11:55:17 --> Output Class Initialized
INFO - 2016-10-17 11:55:17 --> Security Class Initialized
DEBUG - 2016-10-17 11:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:55:17 --> Input Class Initialized
INFO - 2016-10-17 11:55:17 --> Language Class Initialized
INFO - 2016-10-17 11:55:17 --> Loader Class Initialized
INFO - 2016-10-17 11:55:17 --> Helper loaded: url_helper
INFO - 2016-10-17 11:55:17 --> Helper loaded: form_helper
INFO - 2016-10-17 11:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:55:17 --> Controller Class Initialized
INFO - 2016-10-17 11:55:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:55:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:55:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:55:17 --> Final output sent to browser
DEBUG - 2016-10-17 11:55:17 --> Total execution time: 0.0030
ERROR - 2016-10-17 11:55:17 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session2f136347e6d8b3efaf202c0a245f54aabe73fac7 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 11:55:17 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 11:55:18 --> Config Class Initialized
INFO - 2016-10-17 11:55:18 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:55:18 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:55:18 --> Utf8 Class Initialized
INFO - 2016-10-17 11:55:18 --> URI Class Initialized
DEBUG - 2016-10-17 11:55:18 --> No URI present. Default controller set.
INFO - 2016-10-17 11:55:18 --> Router Class Initialized
INFO - 2016-10-17 11:55:18 --> Output Class Initialized
INFO - 2016-10-17 11:55:18 --> Security Class Initialized
DEBUG - 2016-10-17 11:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:55:18 --> Input Class Initialized
INFO - 2016-10-17 11:55:18 --> Language Class Initialized
INFO - 2016-10-17 11:55:18 --> Loader Class Initialized
INFO - 2016-10-17 11:55:18 --> Helper loaded: url_helper
INFO - 2016-10-17 11:55:18 --> Helper loaded: form_helper
INFO - 2016-10-17 11:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:55:18 --> Controller Class Initialized
INFO - 2016-10-17 11:55:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:55:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:55:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:55:18 --> Final output sent to browser
DEBUG - 2016-10-17 11:55:18 --> Total execution time: 0.0023
ERROR - 2016-10-17 11:55:18 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session2f136347e6d8b3efaf202c0a245f54aabe73fac7 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 11:55:18 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 11:56:29 --> Config Class Initialized
INFO - 2016-10-17 11:56:29 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:56:29 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:56:29 --> Utf8 Class Initialized
INFO - 2016-10-17 11:56:29 --> URI Class Initialized
DEBUG - 2016-10-17 11:56:29 --> No URI present. Default controller set.
INFO - 2016-10-17 11:56:29 --> Router Class Initialized
INFO - 2016-10-17 11:56:29 --> Output Class Initialized
INFO - 2016-10-17 11:56:29 --> Security Class Initialized
DEBUG - 2016-10-17 11:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:56:29 --> Input Class Initialized
INFO - 2016-10-17 11:56:29 --> Language Class Initialized
INFO - 2016-10-17 11:56:29 --> Loader Class Initialized
INFO - 2016-10-17 11:56:29 --> Helper loaded: url_helper
INFO - 2016-10-17 11:56:29 --> Helper loaded: form_helper
INFO - 2016-10-17 11:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:56:29 --> Controller Class Initialized
INFO - 2016-10-17 11:56:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 11:56:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 11:56:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 11:56:29 --> Final output sent to browser
DEBUG - 2016-10-17 11:56:29 --> Total execution time: 0.0028
ERROR - 2016-10-17 11:56:29 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session2f136347e6d8b3efaf202c0a245f54aabe73fac7 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 11:56:29 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 12:08:39 --> Config Class Initialized
INFO - 2016-10-17 12:08:39 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:08:39 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:08:39 --> Utf8 Class Initialized
INFO - 2016-10-17 12:08:39 --> URI Class Initialized
DEBUG - 2016-10-17 12:08:39 --> No URI present. Default controller set.
INFO - 2016-10-17 12:08:39 --> Router Class Initialized
INFO - 2016-10-17 12:08:39 --> Output Class Initialized
INFO - 2016-10-17 12:08:39 --> Security Class Initialized
DEBUG - 2016-10-17 12:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:08:39 --> Input Class Initialized
INFO - 2016-10-17 12:08:39 --> Language Class Initialized
INFO - 2016-10-17 12:08:39 --> Loader Class Initialized
INFO - 2016-10-17 12:08:39 --> Helper loaded: url_helper
INFO - 2016-10-17 12:08:39 --> Helper loaded: form_helper
INFO - 2016-10-17 12:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:08:39 --> Controller Class Initialized
INFO - 2016-10-17 12:08:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:08:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:08:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:08:39 --> Final output sent to browser
DEBUG - 2016-10-17 12:08:39 --> Total execution time: 0.0037
ERROR - 2016-10-17 12:08:39 --> Severity: Warning --> fopen(127.0.0.1:11211?persistent/ci_session3836f82e827335badb64db79b984043b038dabd5): failed to open stream: No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2016-10-17 12:08:39 --> Session: File '127.0.0.1:11211?persistent/ci_session3836f82e827335badb64db79b984043b038dabd5' doesn't exist and cannot be created.
ERROR - 2016-10-17 12:08:39 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 12:10:26 --> Config Class Initialized
INFO - 2016-10-17 12:10:26 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:10:26 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:10:26 --> Utf8 Class Initialized
INFO - 2016-10-17 12:10:26 --> URI Class Initialized
DEBUG - 2016-10-17 12:10:26 --> No URI present. Default controller set.
INFO - 2016-10-17 12:10:26 --> Router Class Initialized
INFO - 2016-10-17 12:10:26 --> Output Class Initialized
INFO - 2016-10-17 12:10:26 --> Security Class Initialized
DEBUG - 2016-10-17 12:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:10:26 --> Input Class Initialized
INFO - 2016-10-17 12:10:26 --> Language Class Initialized
INFO - 2016-10-17 12:10:26 --> Loader Class Initialized
INFO - 2016-10-17 12:10:26 --> Helper loaded: url_helper
INFO - 2016-10-17 12:10:26 --> Helper loaded: form_helper
INFO - 2016-10-17 12:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:10:26 --> Controller Class Initialized
INFO - 2016-10-17 12:10:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:10:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:10:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:10:26 --> Final output sent to browser
DEBUG - 2016-10-17 12:10:26 --> Total execution time: 0.0050
INFO - 2016-10-17 12:10:27 --> Config Class Initialized
INFO - 2016-10-17 12:10:27 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:10:27 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:10:27 --> Utf8 Class Initialized
INFO - 2016-10-17 12:10:27 --> URI Class Initialized
DEBUG - 2016-10-17 12:10:27 --> No URI present. Default controller set.
INFO - 2016-10-17 12:10:27 --> Router Class Initialized
INFO - 2016-10-17 12:10:27 --> Output Class Initialized
INFO - 2016-10-17 12:10:27 --> Security Class Initialized
DEBUG - 2016-10-17 12:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:10:27 --> Input Class Initialized
INFO - 2016-10-17 12:10:27 --> Language Class Initialized
INFO - 2016-10-17 12:10:27 --> Loader Class Initialized
INFO - 2016-10-17 12:10:27 --> Helper loaded: url_helper
INFO - 2016-10-17 12:10:27 --> Helper loaded: form_helper
INFO - 2016-10-17 12:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:10:27 --> Controller Class Initialized
INFO - 2016-10-17 12:10:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:10:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:10:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:10:27 --> Final output sent to browser
DEBUG - 2016-10-17 12:10:27 --> Total execution time: 0.0030
ERROR - 2016-10-17 12:10:27 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session3836f82e827335badb64db79b984043b038dabd5 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 12:10:27 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 12:11:08 --> Config Class Initialized
INFO - 2016-10-17 12:11:08 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:11:08 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:11:08 --> Utf8 Class Initialized
INFO - 2016-10-17 12:11:08 --> URI Class Initialized
DEBUG - 2016-10-17 12:11:08 --> No URI present. Default controller set.
INFO - 2016-10-17 12:11:08 --> Router Class Initialized
INFO - 2016-10-17 12:11:08 --> Output Class Initialized
INFO - 2016-10-17 12:11:08 --> Security Class Initialized
DEBUG - 2016-10-17 12:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:11:08 --> Input Class Initialized
INFO - 2016-10-17 12:11:08 --> Language Class Initialized
INFO - 2016-10-17 12:11:08 --> Loader Class Initialized
INFO - 2016-10-17 12:11:08 --> Helper loaded: url_helper
INFO - 2016-10-17 12:11:08 --> Helper loaded: form_helper
INFO - 2016-10-17 12:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:11:08 --> Controller Class Initialized
INFO - 2016-10-17 12:11:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:11:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:11:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:11:08 --> Final output sent to browser
DEBUG - 2016-10-17 12:11:08 --> Total execution time: 0.0049
ERROR - 2016-10-17 12:11:08 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session3836f82e827335badb64db79b984043b038dabd5 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 12:11:08 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 12:17:20 --> Config Class Initialized
INFO - 2016-10-17 12:17:20 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:17:20 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:17:20 --> Utf8 Class Initialized
INFO - 2016-10-17 12:17:20 --> URI Class Initialized
DEBUG - 2016-10-17 12:17:20 --> No URI present. Default controller set.
INFO - 2016-10-17 12:17:20 --> Router Class Initialized
INFO - 2016-10-17 12:17:20 --> Output Class Initialized
INFO - 2016-10-17 12:17:20 --> Security Class Initialized
DEBUG - 2016-10-17 12:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:17:20 --> Input Class Initialized
INFO - 2016-10-17 12:17:20 --> Language Class Initialized
INFO - 2016-10-17 12:17:20 --> Loader Class Initialized
INFO - 2016-10-17 12:17:20 --> Helper loaded: url_helper
INFO - 2016-10-17 12:17:20 --> Helper loaded: form_helper
INFO - 2016-10-17 12:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:17:20 --> Controller Class Initialized
INFO - 2016-10-17 12:17:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:17:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:17:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:17:20 --> Final output sent to browser
DEBUG - 2016-10-17 12:17:20 --> Total execution time: 0.0032
ERROR - 2016-10-17 12:17:20 --> Severity: Warning --> fopen(127.0.0.1:11211?persistent/ci_session2a25a502f16ceca55ac3904c31504e64b8cc2a4f): failed to open stream: No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2016-10-17 12:17:20 --> Session: File '127.0.0.1:11211?persistent/ci_session2a25a502f16ceca55ac3904c31504e64b8cc2a4f' doesn't exist and cannot be created.
ERROR - 2016-10-17 12:17:20 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 12:17:21 --> Config Class Initialized
INFO - 2016-10-17 12:17:21 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:17:21 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:17:21 --> Utf8 Class Initialized
INFO - 2016-10-17 12:17:21 --> URI Class Initialized
DEBUG - 2016-10-17 12:17:21 --> No URI present. Default controller set.
INFO - 2016-10-17 12:17:21 --> Router Class Initialized
INFO - 2016-10-17 12:17:21 --> Output Class Initialized
INFO - 2016-10-17 12:17:21 --> Security Class Initialized
DEBUG - 2016-10-17 12:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:17:21 --> Input Class Initialized
INFO - 2016-10-17 12:17:21 --> Language Class Initialized
INFO - 2016-10-17 12:17:21 --> Loader Class Initialized
INFO - 2016-10-17 12:17:21 --> Helper loaded: url_helper
INFO - 2016-10-17 12:17:21 --> Helper loaded: form_helper
INFO - 2016-10-17 12:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:17:21 --> Controller Class Initialized
INFO - 2016-10-17 12:17:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:17:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:17:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:17:21 --> Final output sent to browser
DEBUG - 2016-10-17 12:17:21 --> Total execution time: 0.0027
INFO - 2016-10-17 12:17:23 --> Config Class Initialized
INFO - 2016-10-17 12:17:23 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:17:23 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:17:23 --> Utf8 Class Initialized
INFO - 2016-10-17 12:17:23 --> URI Class Initialized
DEBUG - 2016-10-17 12:17:23 --> No URI present. Default controller set.
INFO - 2016-10-17 12:17:23 --> Router Class Initialized
INFO - 2016-10-17 12:17:23 --> Output Class Initialized
INFO - 2016-10-17 12:17:23 --> Security Class Initialized
DEBUG - 2016-10-17 12:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:17:23 --> Input Class Initialized
INFO - 2016-10-17 12:17:23 --> Language Class Initialized
INFO - 2016-10-17 12:17:23 --> Loader Class Initialized
INFO - 2016-10-17 12:17:23 --> Helper loaded: url_helper
INFO - 2016-10-17 12:17:23 --> Helper loaded: form_helper
INFO - 2016-10-17 12:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:17:23 --> Controller Class Initialized
INFO - 2016-10-17 12:17:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:17:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:17:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:17:23 --> Final output sent to browser
DEBUG - 2016-10-17 12:17:23 --> Total execution time: 0.0022
ERROR - 2016-10-17 12:17:23 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session2a25a502f16ceca55ac3904c31504e64b8cc2a4f because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 12:17:23 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 12:21:56 --> Config Class Initialized
INFO - 2016-10-17 12:21:56 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:21:56 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:21:56 --> Utf8 Class Initialized
INFO - 2016-10-17 12:21:56 --> URI Class Initialized
DEBUG - 2016-10-17 12:21:56 --> No URI present. Default controller set.
INFO - 2016-10-17 12:21:56 --> Router Class Initialized
INFO - 2016-10-17 12:21:56 --> Output Class Initialized
INFO - 2016-10-17 12:21:56 --> Security Class Initialized
DEBUG - 2016-10-17 12:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:21:56 --> Input Class Initialized
INFO - 2016-10-17 12:21:56 --> Language Class Initialized
INFO - 2016-10-17 12:21:56 --> Loader Class Initialized
INFO - 2016-10-17 12:21:56 --> Helper loaded: url_helper
INFO - 2016-10-17 12:21:56 --> Helper loaded: form_helper
INFO - 2016-10-17 12:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:21:56 --> Controller Class Initialized
INFO - 2016-10-17 12:21:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:21:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:21:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:21:56 --> Final output sent to browser
DEBUG - 2016-10-17 12:21:56 --> Total execution time: 0.0028
ERROR - 2016-10-17 12:21:56 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session2a25a502f16ceca55ac3904c31504e64b8cc2a4f because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 12:21:56 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 12:21:58 --> Config Class Initialized
INFO - 2016-10-17 12:21:58 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:21:58 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:21:58 --> Utf8 Class Initialized
INFO - 2016-10-17 12:21:58 --> URI Class Initialized
DEBUG - 2016-10-17 12:21:58 --> No URI present. Default controller set.
INFO - 2016-10-17 12:21:58 --> Router Class Initialized
INFO - 2016-10-17 12:21:58 --> Output Class Initialized
INFO - 2016-10-17 12:21:58 --> Security Class Initialized
DEBUG - 2016-10-17 12:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:21:58 --> Input Class Initialized
INFO - 2016-10-17 12:21:58 --> Language Class Initialized
INFO - 2016-10-17 12:21:58 --> Loader Class Initialized
INFO - 2016-10-17 12:21:58 --> Helper loaded: url_helper
INFO - 2016-10-17 12:21:58 --> Helper loaded: form_helper
INFO - 2016-10-17 12:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:21:58 --> Controller Class Initialized
INFO - 2016-10-17 12:21:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:21:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:21:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:21:58 --> Final output sent to browser
DEBUG - 2016-10-17 12:21:58 --> Total execution time: 0.0026
ERROR - 2016-10-17 12:21:58 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session2a25a502f16ceca55ac3904c31504e64b8cc2a4f because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 12:21:58 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 12:23:38 --> Config Class Initialized
INFO - 2016-10-17 12:23:38 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:23:38 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:23:38 --> Utf8 Class Initialized
INFO - 2016-10-17 12:23:38 --> URI Class Initialized
DEBUG - 2016-10-17 12:23:38 --> No URI present. Default controller set.
INFO - 2016-10-17 12:23:38 --> Router Class Initialized
INFO - 2016-10-17 12:23:38 --> Output Class Initialized
INFO - 2016-10-17 12:23:38 --> Security Class Initialized
DEBUG - 2016-10-17 12:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:23:38 --> Input Class Initialized
INFO - 2016-10-17 12:23:38 --> Language Class Initialized
INFO - 2016-10-17 12:23:38 --> Loader Class Initialized
INFO - 2016-10-17 12:23:38 --> Helper loaded: url_helper
INFO - 2016-10-17 12:23:38 --> Helper loaded: form_helper
INFO - 2016-10-17 12:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:23:38 --> Controller Class Initialized
INFO - 2016-10-17 12:23:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:23:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:23:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:23:38 --> Final output sent to browser
DEBUG - 2016-10-17 12:23:38 --> Total execution time: 0.0056
ERROR - 2016-10-17 12:23:38 --> Severity: Warning --> fopen(127.0.0.1:11211?persistent/ci_sessiona9a627390b1f0cb4344567c90d5946b1b68142f8): failed to open stream: No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2016-10-17 12:23:38 --> Session: File '127.0.0.1:11211?persistent/ci_sessiona9a627390b1f0cb4344567c90d5946b1b68142f8' doesn't exist and cannot be created.
ERROR - 2016-10-17 12:23:38 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 12:23:41 --> Config Class Initialized
INFO - 2016-10-17 12:23:41 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:23:41 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:23:41 --> Utf8 Class Initialized
INFO - 2016-10-17 12:23:41 --> URI Class Initialized
INFO - 2016-10-17 12:23:41 --> Router Class Initialized
INFO - 2016-10-17 12:23:41 --> Output Class Initialized
INFO - 2016-10-17 12:23:41 --> Security Class Initialized
DEBUG - 2016-10-17 12:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:23:41 --> Input Class Initialized
INFO - 2016-10-17 12:23:41 --> Language Class Initialized
INFO - 2016-10-17 12:23:41 --> Loader Class Initialized
INFO - 2016-10-17 12:23:41 --> Helper loaded: url_helper
INFO - 2016-10-17 12:23:41 --> Helper loaded: form_helper
INFO - 2016-10-17 12:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:23:41 --> Controller Class Initialized
INFO - 2016-10-17 12:23:54 --> Config Class Initialized
INFO - 2016-10-17 12:23:54 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:23:54 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:23:54 --> Utf8 Class Initialized
INFO - 2016-10-17 12:23:54 --> URI Class Initialized
DEBUG - 2016-10-17 12:23:54 --> No URI present. Default controller set.
INFO - 2016-10-17 12:23:54 --> Router Class Initialized
INFO - 2016-10-17 12:23:54 --> Output Class Initialized
INFO - 2016-10-17 12:23:54 --> Security Class Initialized
DEBUG - 2016-10-17 12:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:23:54 --> Input Class Initialized
INFO - 2016-10-17 12:23:54 --> Language Class Initialized
INFO - 2016-10-17 12:23:54 --> Loader Class Initialized
INFO - 2016-10-17 12:23:54 --> Helper loaded: url_helper
INFO - 2016-10-17 12:23:54 --> Helper loaded: form_helper
INFO - 2016-10-17 12:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:23:54 --> Controller Class Initialized
INFO - 2016-10-17 12:23:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:23:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:23:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:23:54 --> Final output sent to browser
DEBUG - 2016-10-17 12:23:54 --> Total execution time: 0.0028
INFO - 2016-10-17 12:23:57 --> Config Class Initialized
INFO - 2016-10-17 12:23:57 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:23:57 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:23:57 --> Utf8 Class Initialized
INFO - 2016-10-17 12:23:57 --> URI Class Initialized
INFO - 2016-10-17 12:23:57 --> Router Class Initialized
INFO - 2016-10-17 12:23:57 --> Output Class Initialized
INFO - 2016-10-17 12:23:57 --> Security Class Initialized
DEBUG - 2016-10-17 12:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:23:57 --> Input Class Initialized
INFO - 2016-10-17 12:23:57 --> Language Class Initialized
INFO - 2016-10-17 12:23:57 --> Loader Class Initialized
INFO - 2016-10-17 12:23:57 --> Helper loaded: url_helper
INFO - 2016-10-17 12:23:57 --> Helper loaded: form_helper
INFO - 2016-10-17 12:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:23:57 --> Controller Class Initialized
ERROR - 2016-10-17 12:23:57 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_sessiona9a627390b1f0cb4344567c90d5946b1b68142f8 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 12:23:57 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 12:24:06 --> Config Class Initialized
INFO - 2016-10-17 12:24:06 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:24:06 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:24:06 --> Utf8 Class Initialized
INFO - 2016-10-17 12:24:06 --> URI Class Initialized
DEBUG - 2016-10-17 12:24:06 --> No URI present. Default controller set.
INFO - 2016-10-17 12:24:06 --> Router Class Initialized
INFO - 2016-10-17 12:24:06 --> Output Class Initialized
INFO - 2016-10-17 12:24:06 --> Security Class Initialized
DEBUG - 2016-10-17 12:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:24:06 --> Input Class Initialized
INFO - 2016-10-17 12:24:06 --> Language Class Initialized
INFO - 2016-10-17 12:24:06 --> Loader Class Initialized
INFO - 2016-10-17 12:24:06 --> Helper loaded: url_helper
INFO - 2016-10-17 12:24:06 --> Helper loaded: form_helper
INFO - 2016-10-17 12:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:24:06 --> Controller Class Initialized
INFO - 2016-10-17 12:24:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:24:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:24:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:24:06 --> Final output sent to browser
DEBUG - 2016-10-17 12:24:06 --> Total execution time: 0.0049
ERROR - 2016-10-17 12:24:06 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_sessiona9a627390b1f0cb4344567c90d5946b1b68142f8 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 12:24:06 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 12:26:45 --> Config Class Initialized
INFO - 2016-10-17 12:26:45 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:26:45 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:26:45 --> Utf8 Class Initialized
INFO - 2016-10-17 12:26:45 --> URI Class Initialized
DEBUG - 2016-10-17 12:26:45 --> No URI present. Default controller set.
INFO - 2016-10-17 12:26:45 --> Router Class Initialized
INFO - 2016-10-17 12:26:45 --> Output Class Initialized
INFO - 2016-10-17 12:26:45 --> Security Class Initialized
DEBUG - 2016-10-17 12:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:26:45 --> Input Class Initialized
INFO - 2016-10-17 12:26:45 --> Language Class Initialized
INFO - 2016-10-17 12:26:45 --> Loader Class Initialized
INFO - 2016-10-17 12:26:45 --> Helper loaded: url_helper
INFO - 2016-10-17 12:26:45 --> Helper loaded: form_helper
INFO - 2016-10-17 12:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:26:45 --> Controller Class Initialized
INFO - 2016-10-17 12:26:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:26:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:26:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:26:45 --> Final output sent to browser
DEBUG - 2016-10-17 12:26:45 --> Total execution time: 0.0054
ERROR - 2016-10-17 12:26:45 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_sessiona9a627390b1f0cb4344567c90d5946b1b68142f8 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 12:26:45 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 12:26:53 --> Config Class Initialized
INFO - 2016-10-17 12:26:53 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:26:53 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:26:53 --> Utf8 Class Initialized
INFO - 2016-10-17 12:26:53 --> URI Class Initialized
DEBUG - 2016-10-17 12:26:53 --> No URI present. Default controller set.
INFO - 2016-10-17 12:26:53 --> Router Class Initialized
INFO - 2016-10-17 12:26:53 --> Output Class Initialized
INFO - 2016-10-17 12:26:53 --> Security Class Initialized
DEBUG - 2016-10-17 12:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:26:53 --> Input Class Initialized
INFO - 2016-10-17 12:26:53 --> Language Class Initialized
INFO - 2016-10-17 12:26:53 --> Loader Class Initialized
INFO - 2016-10-17 12:26:53 --> Helper loaded: url_helper
INFO - 2016-10-17 12:26:53 --> Helper loaded: form_helper
INFO - 2016-10-17 12:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:26:53 --> Controller Class Initialized
INFO - 2016-10-17 12:26:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:26:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:26:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:26:53 --> Final output sent to browser
DEBUG - 2016-10-17 12:26:53 --> Total execution time: 0.0023
ERROR - 2016-10-17 12:26:53 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_sessiona9a627390b1f0cb4344567c90d5946b1b68142f8 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 12:26:53 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 12:26:59 --> Config Class Initialized
INFO - 2016-10-17 12:26:59 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:26:59 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:26:59 --> Utf8 Class Initialized
INFO - 2016-10-17 12:26:59 --> URI Class Initialized
INFO - 2016-10-17 12:26:59 --> Router Class Initialized
INFO - 2016-10-17 12:26:59 --> Output Class Initialized
INFO - 2016-10-17 12:26:59 --> Security Class Initialized
DEBUG - 2016-10-17 12:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:26:59 --> Input Class Initialized
INFO - 2016-10-17 12:26:59 --> Language Class Initialized
INFO - 2016-10-17 12:26:59 --> Loader Class Initialized
INFO - 2016-10-17 12:26:59 --> Helper loaded: url_helper
INFO - 2016-10-17 12:26:59 --> Helper loaded: form_helper
INFO - 2016-10-17 12:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:26:59 --> Controller Class Initialized
ERROR - 2016-10-17 12:26:59 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_sessiona9a627390b1f0cb4344567c90d5946b1b68142f8 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 12:26:59 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 12:27:14 --> Config Class Initialized
INFO - 2016-10-17 12:27:14 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:27:14 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:27:14 --> Utf8 Class Initialized
INFO - 2016-10-17 12:27:14 --> URI Class Initialized
INFO - 2016-10-17 12:27:14 --> Router Class Initialized
INFO - 2016-10-17 12:27:14 --> Output Class Initialized
INFO - 2016-10-17 12:27:14 --> Security Class Initialized
DEBUG - 2016-10-17 12:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:27:14 --> Input Class Initialized
INFO - 2016-10-17 12:27:14 --> Language Class Initialized
INFO - 2016-10-17 12:27:14 --> Loader Class Initialized
INFO - 2016-10-17 12:27:14 --> Helper loaded: url_helper
INFO - 2016-10-17 12:27:14 --> Helper loaded: form_helper
INFO - 2016-10-17 12:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:27:14 --> Controller Class Initialized
INFO - 2016-10-17 12:27:14 --> Form Validation Class Initialized
INFO - 2016-10-17 12:27:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-17 12:27:14 --> Model Class Initialized
ERROR - 2016-10-17 12:27:14 --> Severity: Notice --> Undefined property: Auth::$db /var/www/html/ramotlonyane_modise/LMS/sys/core/Model.php 77
ERROR - 2016-10-17 12:27:14 --> Severity: Error --> Call to a member function where() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/models/Auth_model.php 10
ERROR - 2016-10-17 12:27:14 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_sessiona9a627390b1f0cb4344567c90d5946b1b68142f8 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 12:27:14 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 12:31:20 --> Config Class Initialized
INFO - 2016-10-17 12:31:20 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:31:20 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:31:20 --> Utf8 Class Initialized
INFO - 2016-10-17 12:31:20 --> URI Class Initialized
DEBUG - 2016-10-17 12:31:20 --> No URI present. Default controller set.
INFO - 2016-10-17 12:31:20 --> Router Class Initialized
INFO - 2016-10-17 12:31:20 --> Output Class Initialized
INFO - 2016-10-17 12:31:20 --> Security Class Initialized
DEBUG - 2016-10-17 12:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:31:20 --> Input Class Initialized
INFO - 2016-10-17 12:31:20 --> Language Class Initialized
ERROR - 2016-10-17 12:31:20 --> Severity: Parsing Error --> syntax error, unexpected '!' /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 83
INFO - 2016-10-17 12:31:37 --> Config Class Initialized
INFO - 2016-10-17 12:31:37 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:31:37 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:31:37 --> Utf8 Class Initialized
INFO - 2016-10-17 12:31:37 --> URI Class Initialized
DEBUG - 2016-10-17 12:31:37 --> No URI present. Default controller set.
INFO - 2016-10-17 12:31:37 --> Router Class Initialized
INFO - 2016-10-17 12:31:37 --> Output Class Initialized
INFO - 2016-10-17 12:31:37 --> Security Class Initialized
DEBUG - 2016-10-17 12:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:31:37 --> Input Class Initialized
INFO - 2016-10-17 12:31:37 --> Language Class Initialized
INFO - 2016-10-17 12:31:37 --> Loader Class Initialized
INFO - 2016-10-17 12:31:37 --> Helper loaded: url_helper
INFO - 2016-10-17 12:31:37 --> Helper loaded: form_helper
INFO - 2016-10-17 12:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:31:37 --> Controller Class Initialized
INFO - 2016-10-17 12:31:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:31:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:31:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:31:37 --> Final output sent to browser
DEBUG - 2016-10-17 12:31:37 --> Total execution time: 0.0031
ERROR - 2016-10-17 12:31:37 --> Severity: Warning --> fopen(127.0.0.1:11211?persistent/ci_session5ac42a15eef241231fb7c6a65d4f329e00bb34c6): failed to open stream: No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2016-10-17 12:31:37 --> Session: File '127.0.0.1:11211?persistent/ci_session5ac42a15eef241231fb7c6a65d4f329e00bb34c6' doesn't exist and cannot be created.
ERROR - 2016-10-17 12:31:37 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 12:31:40 --> Config Class Initialized
INFO - 2016-10-17 12:31:40 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:31:40 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:31:40 --> Utf8 Class Initialized
INFO - 2016-10-17 12:31:40 --> URI Class Initialized
INFO - 2016-10-17 12:31:40 --> Router Class Initialized
INFO - 2016-10-17 12:31:40 --> Output Class Initialized
INFO - 2016-10-17 12:31:40 --> Security Class Initialized
DEBUG - 2016-10-17 12:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:31:40 --> Input Class Initialized
INFO - 2016-10-17 12:31:40 --> Language Class Initialized
INFO - 2016-10-17 12:31:40 --> Loader Class Initialized
INFO - 2016-10-17 12:31:40 --> Helper loaded: url_helper
INFO - 2016-10-17 12:31:40 --> Helper loaded: form_helper
INFO - 2016-10-17 12:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:31:40 --> Controller Class Initialized
INFO - 2016-10-17 12:31:40 --> Form Validation Class Initialized
INFO - 2016-10-17 12:31:40 --> Final output sent to browser
DEBUG - 2016-10-17 12:31:40 --> Total execution time: 0.0027
INFO - 2016-10-17 12:32:04 --> Config Class Initialized
INFO - 2016-10-17 12:32:04 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:32:04 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:32:04 --> Utf8 Class Initialized
INFO - 2016-10-17 12:32:04 --> URI Class Initialized
DEBUG - 2016-10-17 12:32:04 --> No URI present. Default controller set.
INFO - 2016-10-17 12:32:04 --> Router Class Initialized
INFO - 2016-10-17 12:32:04 --> Output Class Initialized
INFO - 2016-10-17 12:32:04 --> Security Class Initialized
DEBUG - 2016-10-17 12:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:32:04 --> Input Class Initialized
INFO - 2016-10-17 12:32:04 --> Language Class Initialized
INFO - 2016-10-17 12:32:04 --> Loader Class Initialized
INFO - 2016-10-17 12:32:04 --> Helper loaded: url_helper
INFO - 2016-10-17 12:32:04 --> Helper loaded: form_helper
INFO - 2016-10-17 12:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:32:04 --> Controller Class Initialized
INFO - 2016-10-17 12:32:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:32:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:32:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:32:04 --> Final output sent to browser
DEBUG - 2016-10-17 12:32:04 --> Total execution time: 0.0027
INFO - 2016-10-17 12:32:06 --> Config Class Initialized
INFO - 2016-10-17 12:32:06 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:32:06 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:32:06 --> Utf8 Class Initialized
INFO - 2016-10-17 12:32:06 --> URI Class Initialized
INFO - 2016-10-17 12:32:06 --> Router Class Initialized
INFO - 2016-10-17 12:32:06 --> Output Class Initialized
INFO - 2016-10-17 12:32:06 --> Security Class Initialized
DEBUG - 2016-10-17 12:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:32:06 --> Input Class Initialized
INFO - 2016-10-17 12:32:06 --> Language Class Initialized
INFO - 2016-10-17 12:32:06 --> Loader Class Initialized
INFO - 2016-10-17 12:32:06 --> Helper loaded: url_helper
INFO - 2016-10-17 12:32:06 --> Helper loaded: form_helper
INFO - 2016-10-17 12:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:32:06 --> Controller Class Initialized
INFO - 2016-10-17 12:32:06 --> Form Validation Class Initialized
INFO - 2016-10-17 12:32:06 --> Final output sent to browser
DEBUG - 2016-10-17 12:32:06 --> Total execution time: 0.0026
ERROR - 2016-10-17 12:32:06 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session5ac42a15eef241231fb7c6a65d4f329e00bb34c6 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 12:32:06 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 12:32:55 --> Config Class Initialized
INFO - 2016-10-17 12:32:55 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:32:55 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:32:55 --> Utf8 Class Initialized
INFO - 2016-10-17 12:32:55 --> URI Class Initialized
INFO - 2016-10-17 12:32:55 --> Router Class Initialized
INFO - 2016-10-17 12:32:55 --> Output Class Initialized
INFO - 2016-10-17 12:32:55 --> Security Class Initialized
DEBUG - 2016-10-17 12:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:32:55 --> Input Class Initialized
INFO - 2016-10-17 12:32:55 --> Language Class Initialized
INFO - 2016-10-17 12:32:55 --> Loader Class Initialized
INFO - 2016-10-17 12:32:55 --> Helper loaded: url_helper
INFO - 2016-10-17 12:32:55 --> Helper loaded: form_helper
INFO - 2016-10-17 12:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:32:55 --> Controller Class Initialized
INFO - 2016-10-17 12:32:55 --> Form Validation Class Initialized
ERROR - 2016-10-17 12:32:55 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session5ac42a15eef241231fb7c6a65d4f329e00bb34c6 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 12:32:55 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 12:32:57 --> Config Class Initialized
INFO - 2016-10-17 12:32:57 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:32:57 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:32:57 --> Utf8 Class Initialized
INFO - 2016-10-17 12:32:57 --> URI Class Initialized
DEBUG - 2016-10-17 12:32:57 --> No URI present. Default controller set.
INFO - 2016-10-17 12:32:57 --> Router Class Initialized
INFO - 2016-10-17 12:32:57 --> Output Class Initialized
INFO - 2016-10-17 12:32:57 --> Security Class Initialized
DEBUG - 2016-10-17 12:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:32:57 --> Input Class Initialized
INFO - 2016-10-17 12:32:57 --> Language Class Initialized
INFO - 2016-10-17 12:32:57 --> Loader Class Initialized
INFO - 2016-10-17 12:32:57 --> Helper loaded: url_helper
INFO - 2016-10-17 12:32:57 --> Helper loaded: form_helper
INFO - 2016-10-17 12:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:32:57 --> Controller Class Initialized
INFO - 2016-10-17 12:32:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:32:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:32:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:32:57 --> Final output sent to browser
DEBUG - 2016-10-17 12:32:57 --> Total execution time: 0.0024
ERROR - 2016-10-17 12:32:57 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session5ac42a15eef241231fb7c6a65d4f329e00bb34c6 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 12:32:57 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 12:33:02 --> Config Class Initialized
INFO - 2016-10-17 12:33:02 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:33:02 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:33:02 --> Utf8 Class Initialized
INFO - 2016-10-17 12:33:02 --> URI Class Initialized
INFO - 2016-10-17 12:33:02 --> Router Class Initialized
INFO - 2016-10-17 12:33:02 --> Output Class Initialized
INFO - 2016-10-17 12:33:02 --> Security Class Initialized
DEBUG - 2016-10-17 12:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:33:02 --> Input Class Initialized
INFO - 2016-10-17 12:33:02 --> Language Class Initialized
INFO - 2016-10-17 12:33:02 --> Loader Class Initialized
INFO - 2016-10-17 12:33:02 --> Helper loaded: url_helper
INFO - 2016-10-17 12:33:02 --> Helper loaded: form_helper
INFO - 2016-10-17 12:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:33:02 --> Controller Class Initialized
INFO - 2016-10-17 12:33:02 --> Form Validation Class Initialized
ERROR - 2016-10-17 12:33:02 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session5ac42a15eef241231fb7c6a65d4f329e00bb34c6 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 12:33:02 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 12:33:14 --> Config Class Initialized
INFO - 2016-10-17 12:33:14 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:33:14 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:33:14 --> Utf8 Class Initialized
INFO - 2016-10-17 12:33:14 --> URI Class Initialized
DEBUG - 2016-10-17 12:33:14 --> No URI present. Default controller set.
INFO - 2016-10-17 12:33:14 --> Router Class Initialized
INFO - 2016-10-17 12:33:14 --> Output Class Initialized
INFO - 2016-10-17 12:33:14 --> Security Class Initialized
DEBUG - 2016-10-17 12:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:33:14 --> Input Class Initialized
INFO - 2016-10-17 12:33:14 --> Language Class Initialized
INFO - 2016-10-17 12:33:14 --> Loader Class Initialized
INFO - 2016-10-17 12:33:14 --> Helper loaded: url_helper
INFO - 2016-10-17 12:33:14 --> Helper loaded: form_helper
INFO - 2016-10-17 12:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:33:14 --> Controller Class Initialized
INFO - 2016-10-17 12:33:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:33:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:33:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:33:14 --> Final output sent to browser
DEBUG - 2016-10-17 12:33:14 --> Total execution time: 0.0023
ERROR - 2016-10-17 12:33:14 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session5ac42a15eef241231fb7c6a65d4f329e00bb34c6 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 12:33:14 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 12:33:17 --> Config Class Initialized
INFO - 2016-10-17 12:33:17 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:33:17 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:33:17 --> Utf8 Class Initialized
INFO - 2016-10-17 12:33:17 --> URI Class Initialized
INFO - 2016-10-17 12:33:17 --> Router Class Initialized
INFO - 2016-10-17 12:33:17 --> Output Class Initialized
INFO - 2016-10-17 12:33:17 --> Security Class Initialized
DEBUG - 2016-10-17 12:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:33:17 --> Input Class Initialized
INFO - 2016-10-17 12:33:17 --> Language Class Initialized
INFO - 2016-10-17 12:33:17 --> Loader Class Initialized
INFO - 2016-10-17 12:33:17 --> Helper loaded: url_helper
INFO - 2016-10-17 12:33:17 --> Helper loaded: form_helper
INFO - 2016-10-17 12:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:33:17 --> Controller Class Initialized
INFO - 2016-10-17 12:33:17 --> Form Validation Class Initialized
ERROR - 2016-10-17 12:33:17 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session5ac42a15eef241231fb7c6a65d4f329e00bb34c6 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 12:33:17 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 12:34:21 --> Config Class Initialized
INFO - 2016-10-17 12:34:21 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:34:21 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:34:21 --> Utf8 Class Initialized
INFO - 2016-10-17 12:34:21 --> URI Class Initialized
DEBUG - 2016-10-17 12:34:21 --> No URI present. Default controller set.
INFO - 2016-10-17 12:34:21 --> Router Class Initialized
INFO - 2016-10-17 12:34:21 --> Output Class Initialized
INFO - 2016-10-17 12:34:21 --> Security Class Initialized
DEBUG - 2016-10-17 12:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:34:21 --> Input Class Initialized
INFO - 2016-10-17 12:34:21 --> Language Class Initialized
INFO - 2016-10-17 12:34:21 --> Loader Class Initialized
INFO - 2016-10-17 12:34:21 --> Helper loaded: url_helper
INFO - 2016-10-17 12:34:21 --> Helper loaded: form_helper
INFO - 2016-10-17 12:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:34:21 --> Controller Class Initialized
INFO - 2016-10-17 12:34:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:34:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:34:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:34:21 --> Final output sent to browser
DEBUG - 2016-10-17 12:34:21 --> Total execution time: 0.0025
ERROR - 2016-10-17 12:34:21 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session5ac42a15eef241231fb7c6a65d4f329e00bb34c6 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 12:34:21 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 12:34:23 --> Config Class Initialized
INFO - 2016-10-17 12:34:23 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:34:23 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:34:23 --> Utf8 Class Initialized
INFO - 2016-10-17 12:34:23 --> URI Class Initialized
DEBUG - 2016-10-17 12:34:23 --> No URI present. Default controller set.
INFO - 2016-10-17 12:34:23 --> Router Class Initialized
INFO - 2016-10-17 12:34:23 --> Output Class Initialized
INFO - 2016-10-17 12:34:23 --> Security Class Initialized
DEBUG - 2016-10-17 12:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:34:23 --> Input Class Initialized
INFO - 2016-10-17 12:34:23 --> Language Class Initialized
INFO - 2016-10-17 12:34:23 --> Loader Class Initialized
INFO - 2016-10-17 12:34:23 --> Helper loaded: url_helper
INFO - 2016-10-17 12:34:23 --> Helper loaded: form_helper
INFO - 2016-10-17 12:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:34:23 --> Controller Class Initialized
INFO - 2016-10-17 12:34:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:34:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:34:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:34:23 --> Final output sent to browser
DEBUG - 2016-10-17 12:34:23 --> Total execution time: 0.0028
ERROR - 2016-10-17 12:34:23 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session5ac42a15eef241231fb7c6a65d4f329e00bb34c6 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 12:34:23 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 12:34:24 --> Config Class Initialized
INFO - 2016-10-17 12:34:24 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:34:24 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:34:24 --> Utf8 Class Initialized
INFO - 2016-10-17 12:34:24 --> URI Class Initialized
DEBUG - 2016-10-17 12:34:24 --> No URI present. Default controller set.
INFO - 2016-10-17 12:34:24 --> Router Class Initialized
INFO - 2016-10-17 12:34:24 --> Output Class Initialized
INFO - 2016-10-17 12:34:24 --> Security Class Initialized
DEBUG - 2016-10-17 12:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:34:24 --> Input Class Initialized
INFO - 2016-10-17 12:34:24 --> Language Class Initialized
INFO - 2016-10-17 12:34:24 --> Loader Class Initialized
INFO - 2016-10-17 12:34:24 --> Helper loaded: url_helper
INFO - 2016-10-17 12:34:24 --> Helper loaded: form_helper
INFO - 2016-10-17 12:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:34:24 --> Controller Class Initialized
INFO - 2016-10-17 12:34:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:34:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:34:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:34:24 --> Final output sent to browser
DEBUG - 2016-10-17 12:34:24 --> Total execution time: 0.0023
ERROR - 2016-10-17 12:34:24 --> Severity: Warning --> touch(): Unable to create file 127.0.0.1:11211?persistent/ci_session5ac42a15eef241231fb7c6a65d4f329e00bb34c6 because No such file or directory /var/www/html/ramotlonyane_modise/LMS/sys/libraries/Session/drivers/Session_files_driver.php 238
ERROR - 2016-10-17 12:34:24 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (127.0.0.1:11211?persistent) Unknown 0
INFO - 2016-10-17 12:36:18 --> Config Class Initialized
INFO - 2016-10-17 12:36:18 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:36:18 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:36:18 --> Utf8 Class Initialized
INFO - 2016-10-17 12:36:18 --> URI Class Initialized
DEBUG - 2016-10-17 12:36:18 --> No URI present. Default controller set.
INFO - 2016-10-17 12:36:18 --> Router Class Initialized
INFO - 2016-10-17 12:36:18 --> Output Class Initialized
INFO - 2016-10-17 12:36:18 --> Security Class Initialized
DEBUG - 2016-10-17 12:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:36:18 --> Input Class Initialized
INFO - 2016-10-17 12:36:18 --> Language Class Initialized
INFO - 2016-10-17 12:36:18 --> Loader Class Initialized
INFO - 2016-10-17 12:36:18 --> Helper loaded: url_helper
INFO - 2016-10-17 12:36:18 --> Helper loaded: form_helper
INFO - 2016-10-17 12:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:36:18 --> Controller Class Initialized
INFO - 2016-10-17 12:36:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:36:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:36:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:36:18 --> Final output sent to browser
DEBUG - 2016-10-17 12:36:18 --> Total execution time: 0.0033
INFO - 2016-10-17 12:36:20 --> Config Class Initialized
INFO - 2016-10-17 12:36:20 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:36:20 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:36:20 --> Utf8 Class Initialized
INFO - 2016-10-17 12:36:20 --> URI Class Initialized
INFO - 2016-10-17 12:36:20 --> Router Class Initialized
INFO - 2016-10-17 12:36:20 --> Output Class Initialized
INFO - 2016-10-17 12:36:20 --> Security Class Initialized
DEBUG - 2016-10-17 12:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:36:20 --> Input Class Initialized
INFO - 2016-10-17 12:36:20 --> Language Class Initialized
INFO - 2016-10-17 12:36:20 --> Loader Class Initialized
INFO - 2016-10-17 12:36:20 --> Helper loaded: url_helper
INFO - 2016-10-17 12:36:20 --> Helper loaded: form_helper
INFO - 2016-10-17 12:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:36:20 --> Controller Class Initialized
INFO - 2016-10-17 12:36:20 --> Form Validation Class Initialized
INFO - 2016-10-17 12:36:25 --> Config Class Initialized
INFO - 2016-10-17 12:36:25 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:36:25 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:36:25 --> Utf8 Class Initialized
INFO - 2016-10-17 12:36:25 --> URI Class Initialized
INFO - 2016-10-17 12:36:25 --> Router Class Initialized
INFO - 2016-10-17 12:36:25 --> Output Class Initialized
INFO - 2016-10-17 12:36:25 --> Security Class Initialized
DEBUG - 2016-10-17 12:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:36:25 --> Input Class Initialized
INFO - 2016-10-17 12:36:25 --> Language Class Initialized
INFO - 2016-10-17 12:36:25 --> Loader Class Initialized
INFO - 2016-10-17 12:36:25 --> Helper loaded: url_helper
INFO - 2016-10-17 12:36:25 --> Helper loaded: form_helper
INFO - 2016-10-17 12:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:36:25 --> Controller Class Initialized
INFO - 2016-10-17 12:36:25 --> Form Validation Class Initialized
INFO - 2016-10-17 12:36:32 --> Config Class Initialized
INFO - 2016-10-17 12:36:32 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:36:32 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:36:32 --> Utf8 Class Initialized
INFO - 2016-10-17 12:36:32 --> URI Class Initialized
INFO - 2016-10-17 12:36:32 --> Router Class Initialized
INFO - 2016-10-17 12:36:32 --> Output Class Initialized
INFO - 2016-10-17 12:36:32 --> Security Class Initialized
DEBUG - 2016-10-17 12:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:36:32 --> Input Class Initialized
INFO - 2016-10-17 12:36:32 --> Language Class Initialized
INFO - 2016-10-17 12:36:32 --> Loader Class Initialized
INFO - 2016-10-17 12:36:32 --> Helper loaded: url_helper
INFO - 2016-10-17 12:36:32 --> Helper loaded: form_helper
INFO - 2016-10-17 12:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:36:32 --> Controller Class Initialized
INFO - 2016-10-17 12:36:32 --> Form Validation Class Initialized
INFO - 2016-10-17 12:36:32 --> Final output sent to browser
DEBUG - 2016-10-17 12:36:32 --> Total execution time: 0.0029
INFO - 2016-10-17 12:37:54 --> Config Class Initialized
INFO - 2016-10-17 12:37:54 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:37:54 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:37:54 --> Utf8 Class Initialized
INFO - 2016-10-17 12:37:54 --> URI Class Initialized
DEBUG - 2016-10-17 12:37:54 --> No URI present. Default controller set.
INFO - 2016-10-17 12:37:54 --> Router Class Initialized
INFO - 2016-10-17 12:37:54 --> Output Class Initialized
INFO - 2016-10-17 12:37:54 --> Security Class Initialized
DEBUG - 2016-10-17 12:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:37:54 --> Input Class Initialized
INFO - 2016-10-17 12:37:54 --> Language Class Initialized
INFO - 2016-10-17 12:37:54 --> Loader Class Initialized
INFO - 2016-10-17 12:37:54 --> Helper loaded: url_helper
INFO - 2016-10-17 12:37:54 --> Helper loaded: form_helper
INFO - 2016-10-17 12:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:37:54 --> Controller Class Initialized
INFO - 2016-10-17 12:37:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:37:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:37:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:37:54 --> Final output sent to browser
DEBUG - 2016-10-17 12:37:54 --> Total execution time: 0.0030
INFO - 2016-10-17 12:37:55 --> Config Class Initialized
INFO - 2016-10-17 12:37:55 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:37:55 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:37:55 --> Utf8 Class Initialized
INFO - 2016-10-17 12:37:55 --> URI Class Initialized
INFO - 2016-10-17 12:37:55 --> Router Class Initialized
INFO - 2016-10-17 12:37:55 --> Output Class Initialized
INFO - 2016-10-17 12:37:55 --> Security Class Initialized
DEBUG - 2016-10-17 12:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:37:55 --> Input Class Initialized
INFO - 2016-10-17 12:37:55 --> Language Class Initialized
INFO - 2016-10-17 12:37:55 --> Loader Class Initialized
INFO - 2016-10-17 12:37:55 --> Helper loaded: url_helper
INFO - 2016-10-17 12:37:55 --> Helper loaded: form_helper
INFO - 2016-10-17 12:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:37:55 --> Controller Class Initialized
INFO - 2016-10-17 12:37:55 --> Form Validation Class Initialized
INFO - 2016-10-17 12:37:55 --> Model Class Initialized
ERROR - 2016-10-17 12:37:55 --> Severity: Notice --> Undefined property: Auth::$db /var/www/html/ramotlonyane_modise/LMS/sys/core/Model.php 77
ERROR - 2016-10-17 12:37:55 --> Severity: Error --> Call to a member function where() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/models/Auth_model.php 10
INFO - 2016-10-17 12:38:25 --> Config Class Initialized
INFO - 2016-10-17 12:38:25 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:38:25 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:38:25 --> Utf8 Class Initialized
INFO - 2016-10-17 12:38:25 --> URI Class Initialized
DEBUG - 2016-10-17 12:38:25 --> No URI present. Default controller set.
INFO - 2016-10-17 12:38:25 --> Router Class Initialized
INFO - 2016-10-17 12:38:25 --> Output Class Initialized
INFO - 2016-10-17 12:38:25 --> Security Class Initialized
DEBUG - 2016-10-17 12:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:38:25 --> Input Class Initialized
INFO - 2016-10-17 12:38:25 --> Language Class Initialized
INFO - 2016-10-17 12:38:25 --> Loader Class Initialized
INFO - 2016-10-17 12:38:25 --> Helper loaded: url_helper
INFO - 2016-10-17 12:38:25 --> Helper loaded: form_helper
INFO - 2016-10-17 12:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:38:25 --> Controller Class Initialized
INFO - 2016-10-17 12:38:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:38:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:38:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:38:25 --> Final output sent to browser
DEBUG - 2016-10-17 12:38:25 --> Total execution time: 0.0028
INFO - 2016-10-17 12:38:26 --> Config Class Initialized
INFO - 2016-10-17 12:38:26 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:38:26 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:38:26 --> Utf8 Class Initialized
INFO - 2016-10-17 12:38:26 --> URI Class Initialized
INFO - 2016-10-17 12:38:26 --> Router Class Initialized
INFO - 2016-10-17 12:38:26 --> Output Class Initialized
INFO - 2016-10-17 12:38:26 --> Security Class Initialized
DEBUG - 2016-10-17 12:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:38:26 --> Input Class Initialized
INFO - 2016-10-17 12:38:26 --> Language Class Initialized
INFO - 2016-10-17 12:38:26 --> Loader Class Initialized
INFO - 2016-10-17 12:38:26 --> Helper loaded: url_helper
INFO - 2016-10-17 12:38:26 --> Helper loaded: form_helper
INFO - 2016-10-17 12:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:38:26 --> Controller Class Initialized
INFO - 2016-10-17 12:38:26 --> Form Validation Class Initialized
INFO - 2016-10-17 12:38:26 --> Model Class Initialized
ERROR - 2016-10-17 12:38:26 --> Severity: Notice --> Undefined property: Auth::$db /var/www/html/ramotlonyane_modise/LMS/sys/core/Model.php 77
ERROR - 2016-10-17 12:38:26 --> Severity: Error --> Call to a member function where() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/models/Auth_model.php 10
INFO - 2016-10-17 12:39:06 --> Config Class Initialized
INFO - 2016-10-17 12:39:06 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:39:06 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:39:06 --> Utf8 Class Initialized
INFO - 2016-10-17 12:39:06 --> URI Class Initialized
INFO - 2016-10-17 12:39:06 --> Router Class Initialized
INFO - 2016-10-17 12:39:06 --> Output Class Initialized
INFO - 2016-10-17 12:39:06 --> Security Class Initialized
DEBUG - 2016-10-17 12:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:39:06 --> Input Class Initialized
INFO - 2016-10-17 12:39:06 --> Language Class Initialized
INFO - 2016-10-17 12:39:06 --> Loader Class Initialized
INFO - 2016-10-17 12:39:06 --> Helper loaded: url_helper
INFO - 2016-10-17 12:39:06 --> Helper loaded: form_helper
INFO - 2016-10-17 12:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:39:06 --> Controller Class Initialized
INFO - 2016-10-17 12:39:06 --> Form Validation Class Initialized
INFO - 2016-10-17 12:39:06 --> Model Class Initialized
INFO - 2016-10-17 12:39:06 --> Final output sent to browser
DEBUG - 2016-10-17 12:39:06 --> Total execution time: 0.0026
INFO - 2016-10-17 12:41:04 --> Config Class Initialized
INFO - 2016-10-17 12:41:04 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:41:04 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:41:04 --> Utf8 Class Initialized
INFO - 2016-10-17 12:41:04 --> URI Class Initialized
INFO - 2016-10-17 12:41:04 --> Router Class Initialized
INFO - 2016-10-17 12:41:04 --> Output Class Initialized
INFO - 2016-10-17 12:41:04 --> Security Class Initialized
DEBUG - 2016-10-17 12:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:41:04 --> Input Class Initialized
INFO - 2016-10-17 12:41:04 --> Language Class Initialized
INFO - 2016-10-17 12:41:04 --> Loader Class Initialized
INFO - 2016-10-17 12:41:04 --> Helper loaded: url_helper
INFO - 2016-10-17 12:41:04 --> Helper loaded: form_helper
INFO - 2016-10-17 12:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:41:04 --> Controller Class Initialized
INFO - 2016-10-17 12:41:04 --> Form Validation Class Initialized
INFO - 2016-10-17 12:41:04 --> Model Class Initialized
ERROR - 2016-10-17 12:41:04 --> Severity: Notice --> Undefined property: Auth::$db /var/www/html/ramotlonyane_modise/LMS/sys/core/Model.php 77
ERROR - 2016-10-17 12:41:04 --> Severity: Error --> Call to a member function get() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/models/Auth_model.php 11
INFO - 2016-10-17 12:41:42 --> Config Class Initialized
INFO - 2016-10-17 12:41:42 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:41:42 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:41:42 --> Utf8 Class Initialized
INFO - 2016-10-17 12:41:42 --> URI Class Initialized
DEBUG - 2016-10-17 12:41:42 --> No URI present. Default controller set.
INFO - 2016-10-17 12:41:42 --> Router Class Initialized
INFO - 2016-10-17 12:41:42 --> Output Class Initialized
INFO - 2016-10-17 12:41:42 --> Security Class Initialized
DEBUG - 2016-10-17 12:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:41:42 --> Input Class Initialized
INFO - 2016-10-17 12:41:42 --> Language Class Initialized
INFO - 2016-10-17 12:41:42 --> Loader Class Initialized
INFO - 2016-10-17 12:41:42 --> Helper loaded: url_helper
INFO - 2016-10-17 12:41:42 --> Helper loaded: form_helper
INFO - 2016-10-17 12:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:41:42 --> Controller Class Initialized
INFO - 2016-10-17 12:41:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:41:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:41:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:41:42 --> Final output sent to browser
DEBUG - 2016-10-17 12:41:42 --> Total execution time: 0.0027
INFO - 2016-10-17 12:41:46 --> Config Class Initialized
INFO - 2016-10-17 12:41:46 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:41:46 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:41:46 --> Utf8 Class Initialized
INFO - 2016-10-17 12:41:46 --> URI Class Initialized
INFO - 2016-10-17 12:41:46 --> Router Class Initialized
INFO - 2016-10-17 12:41:46 --> Output Class Initialized
INFO - 2016-10-17 12:41:46 --> Security Class Initialized
DEBUG - 2016-10-17 12:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:41:46 --> Input Class Initialized
INFO - 2016-10-17 12:41:46 --> Language Class Initialized
INFO - 2016-10-17 12:41:46 --> Loader Class Initialized
INFO - 2016-10-17 12:41:46 --> Helper loaded: url_helper
INFO - 2016-10-17 12:41:46 --> Helper loaded: form_helper
INFO - 2016-10-17 12:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:41:46 --> Controller Class Initialized
INFO - 2016-10-17 12:41:46 --> Form Validation Class Initialized
INFO - 2016-10-17 12:41:46 --> Model Class Initialized
ERROR - 2016-10-17 12:41:46 --> Severity: Notice --> Undefined property: Auth::$db /var/www/html/ramotlonyane_modise/LMS/sys/core/Model.php 77
ERROR - 2016-10-17 12:41:46 --> Severity: Error --> Call to a member function get() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/models/Auth_model.php 11
INFO - 2016-10-17 12:42:59 --> Config Class Initialized
INFO - 2016-10-17 12:42:59 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:42:59 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:42:59 --> Utf8 Class Initialized
INFO - 2016-10-17 12:42:59 --> URI Class Initialized
DEBUG - 2016-10-17 12:42:59 --> No URI present. Default controller set.
INFO - 2016-10-17 12:42:59 --> Router Class Initialized
INFO - 2016-10-17 12:42:59 --> Output Class Initialized
INFO - 2016-10-17 12:42:59 --> Security Class Initialized
DEBUG - 2016-10-17 12:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:42:59 --> Input Class Initialized
INFO - 2016-10-17 12:42:59 --> Language Class Initialized
INFO - 2016-10-17 12:42:59 --> Loader Class Initialized
INFO - 2016-10-17 12:42:59 --> Helper loaded: url_helper
INFO - 2016-10-17 12:42:59 --> Helper loaded: form_helper
INFO - 2016-10-17 12:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:42:59 --> Controller Class Initialized
INFO - 2016-10-17 12:42:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:42:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:42:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:42:59 --> Final output sent to browser
DEBUG - 2016-10-17 12:42:59 --> Total execution time: 0.0030
INFO - 2016-10-17 12:43:00 --> Config Class Initialized
INFO - 2016-10-17 12:43:00 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:43:00 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:43:00 --> Utf8 Class Initialized
INFO - 2016-10-17 12:43:00 --> URI Class Initialized
INFO - 2016-10-17 12:43:00 --> Router Class Initialized
INFO - 2016-10-17 12:43:00 --> Output Class Initialized
INFO - 2016-10-17 12:43:00 --> Security Class Initialized
DEBUG - 2016-10-17 12:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:43:00 --> Input Class Initialized
INFO - 2016-10-17 12:43:00 --> Language Class Initialized
INFO - 2016-10-17 12:43:00 --> Loader Class Initialized
INFO - 2016-10-17 12:43:00 --> Helper loaded: url_helper
INFO - 2016-10-17 12:43:00 --> Helper loaded: form_helper
INFO - 2016-10-17 12:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:43:00 --> Controller Class Initialized
INFO - 2016-10-17 12:43:00 --> Form Validation Class Initialized
INFO - 2016-10-17 12:43:00 --> Database Driver Class Initialized
ERROR - 2016-10-17 12:43:00 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 12:43:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 12:43:00 --> Unable to connect to the database
INFO - 2016-10-17 12:43:00 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-17 12:44:26 --> Config Class Initialized
INFO - 2016-10-17 12:44:26 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:44:26 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:44:26 --> Utf8 Class Initialized
INFO - 2016-10-17 12:44:26 --> URI Class Initialized
DEBUG - 2016-10-17 12:44:26 --> No URI present. Default controller set.
INFO - 2016-10-17 12:44:26 --> Router Class Initialized
INFO - 2016-10-17 12:44:26 --> Output Class Initialized
INFO - 2016-10-17 12:44:26 --> Security Class Initialized
DEBUG - 2016-10-17 12:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:44:26 --> Input Class Initialized
INFO - 2016-10-17 12:44:26 --> Language Class Initialized
INFO - 2016-10-17 12:44:26 --> Loader Class Initialized
INFO - 2016-10-17 12:44:26 --> Helper loaded: url_helper
INFO - 2016-10-17 12:44:26 --> Helper loaded: form_helper
INFO - 2016-10-17 12:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:44:26 --> Controller Class Initialized
INFO - 2016-10-17 12:44:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:44:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:44:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:44:26 --> Final output sent to browser
DEBUG - 2016-10-17 12:44:26 --> Total execution time: 0.0024
INFO - 2016-10-17 12:44:30 --> Config Class Initialized
INFO - 2016-10-17 12:44:30 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:44:30 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:44:30 --> Utf8 Class Initialized
INFO - 2016-10-17 12:44:30 --> URI Class Initialized
INFO - 2016-10-17 12:44:30 --> Router Class Initialized
INFO - 2016-10-17 12:44:30 --> Output Class Initialized
INFO - 2016-10-17 12:44:30 --> Security Class Initialized
DEBUG - 2016-10-17 12:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:44:30 --> Input Class Initialized
INFO - 2016-10-17 12:44:30 --> Language Class Initialized
INFO - 2016-10-17 12:44:30 --> Loader Class Initialized
INFO - 2016-10-17 12:44:30 --> Helper loaded: url_helper
INFO - 2016-10-17 12:44:30 --> Helper loaded: form_helper
INFO - 2016-10-17 12:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:44:30 --> Controller Class Initialized
INFO - 2016-10-17 12:44:30 --> Form Validation Class Initialized
INFO - 2016-10-17 12:44:30 --> Database Driver Class Initialized
ERROR - 2016-10-17 12:44:30 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 12:44:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 12:44:30 --> Unable to connect to the database
INFO - 2016-10-17 12:44:30 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-17 12:47:55 --> Config Class Initialized
INFO - 2016-10-17 12:47:55 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:47:55 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:47:55 --> Utf8 Class Initialized
INFO - 2016-10-17 12:47:55 --> URI Class Initialized
INFO - 2016-10-17 12:47:55 --> Router Class Initialized
INFO - 2016-10-17 12:47:55 --> Output Class Initialized
INFO - 2016-10-17 12:47:55 --> Security Class Initialized
DEBUG - 2016-10-17 12:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:47:55 --> Input Class Initialized
INFO - 2016-10-17 12:47:55 --> Language Class Initialized
ERROR - 2016-10-17 12:47:55 --> 404 Page Not Found: Index/dashboard
INFO - 2016-10-17 12:50:57 --> Config Class Initialized
INFO - 2016-10-17 12:50:57 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:50:57 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:50:57 --> Utf8 Class Initialized
INFO - 2016-10-17 12:50:57 --> URI Class Initialized
INFO - 2016-10-17 12:50:57 --> Router Class Initialized
INFO - 2016-10-17 12:50:57 --> Output Class Initialized
INFO - 2016-10-17 12:50:57 --> Security Class Initialized
DEBUG - 2016-10-17 12:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:50:57 --> Input Class Initialized
INFO - 2016-10-17 12:50:57 --> Language Class Initialized
INFO - 2016-10-17 12:50:57 --> Loader Class Initialized
INFO - 2016-10-17 12:50:57 --> Helper loaded: url_helper
INFO - 2016-10-17 12:50:57 --> Helper loaded: form_helper
INFO - 2016-10-17 12:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:50:57 --> Controller Class Initialized
INFO - 2016-10-17 12:50:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:50:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 12:50:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 12:50:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:50:57 --> Final output sent to browser
DEBUG - 2016-10-17 12:50:57 --> Total execution time: 0.0034
INFO - 2016-10-17 12:51:41 --> Config Class Initialized
INFO - 2016-10-17 12:51:41 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:51:41 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:51:41 --> Utf8 Class Initialized
INFO - 2016-10-17 12:51:41 --> URI Class Initialized
INFO - 2016-10-17 12:51:41 --> Router Class Initialized
INFO - 2016-10-17 12:51:41 --> Output Class Initialized
INFO - 2016-10-17 12:51:41 --> Security Class Initialized
DEBUG - 2016-10-17 12:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:51:41 --> Input Class Initialized
INFO - 2016-10-17 12:51:41 --> Language Class Initialized
ERROR - 2016-10-17 12:51:41 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 46
INFO - 2016-10-17 12:51:49 --> Config Class Initialized
INFO - 2016-10-17 12:51:49 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:51:49 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:51:49 --> Utf8 Class Initialized
INFO - 2016-10-17 12:51:49 --> URI Class Initialized
INFO - 2016-10-17 12:51:49 --> Router Class Initialized
INFO - 2016-10-17 12:51:49 --> Output Class Initialized
INFO - 2016-10-17 12:51:49 --> Security Class Initialized
DEBUG - 2016-10-17 12:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:51:49 --> Input Class Initialized
INFO - 2016-10-17 12:51:49 --> Language Class Initialized
INFO - 2016-10-17 12:51:49 --> Loader Class Initialized
INFO - 2016-10-17 12:51:49 --> Helper loaded: url_helper
INFO - 2016-10-17 12:51:49 --> Helper loaded: form_helper
INFO - 2016-10-17 12:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:51:49 --> Controller Class Initialized
INFO - 2016-10-17 12:51:49 --> Final output sent to browser
DEBUG - 2016-10-17 12:51:49 --> Total execution time: 0.0028
INFO - 2016-10-17 12:52:13 --> Config Class Initialized
INFO - 2016-10-17 12:52:13 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:52:13 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:52:13 --> Utf8 Class Initialized
INFO - 2016-10-17 12:52:13 --> URI Class Initialized
INFO - 2016-10-17 12:52:13 --> Router Class Initialized
INFO - 2016-10-17 12:52:13 --> Output Class Initialized
INFO - 2016-10-17 12:52:13 --> Security Class Initialized
DEBUG - 2016-10-17 12:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:52:13 --> Input Class Initialized
INFO - 2016-10-17 12:52:13 --> Language Class Initialized
INFO - 2016-10-17 12:52:13 --> Loader Class Initialized
INFO - 2016-10-17 12:52:13 --> Helper loaded: url_helper
INFO - 2016-10-17 12:52:13 --> Helper loaded: form_helper
INFO - 2016-10-17 12:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:52:13 --> Controller Class Initialized
INFO - 2016-10-17 12:52:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:52:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:52:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:52:13 --> Final output sent to browser
DEBUG - 2016-10-17 12:52:13 --> Total execution time: 0.0030
INFO - 2016-10-17 12:52:50 --> Config Class Initialized
INFO - 2016-10-17 12:52:50 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:52:50 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:52:50 --> Utf8 Class Initialized
INFO - 2016-10-17 12:52:50 --> URI Class Initialized
INFO - 2016-10-17 12:52:50 --> Router Class Initialized
INFO - 2016-10-17 12:52:50 --> Output Class Initialized
INFO - 2016-10-17 12:52:50 --> Security Class Initialized
DEBUG - 2016-10-17 12:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:52:50 --> Input Class Initialized
INFO - 2016-10-17 12:52:50 --> Language Class Initialized
ERROR - 2016-10-17 12:52:50 --> 404 Page Not Found: Auth/dashboard
INFO - 2016-10-17 12:52:52 --> Config Class Initialized
INFO - 2016-10-17 12:52:52 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:52:52 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:52:52 --> Utf8 Class Initialized
INFO - 2016-10-17 12:52:52 --> URI Class Initialized
DEBUG - 2016-10-17 12:52:52 --> No URI present. Default controller set.
INFO - 2016-10-17 12:52:52 --> Router Class Initialized
INFO - 2016-10-17 12:52:52 --> Output Class Initialized
INFO - 2016-10-17 12:52:52 --> Security Class Initialized
DEBUG - 2016-10-17 12:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:52:52 --> Input Class Initialized
INFO - 2016-10-17 12:52:52 --> Language Class Initialized
INFO - 2016-10-17 12:52:52 --> Loader Class Initialized
INFO - 2016-10-17 12:52:52 --> Helper loaded: url_helper
INFO - 2016-10-17 12:52:52 --> Helper loaded: form_helper
INFO - 2016-10-17 12:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:52:52 --> Controller Class Initialized
INFO - 2016-10-17 12:52:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:52:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:52:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:52:52 --> Final output sent to browser
DEBUG - 2016-10-17 12:52:52 --> Total execution time: 0.0025
INFO - 2016-10-17 12:52:54 --> Config Class Initialized
INFO - 2016-10-17 12:52:54 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:52:54 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:52:54 --> Utf8 Class Initialized
INFO - 2016-10-17 12:52:54 --> URI Class Initialized
INFO - 2016-10-17 12:52:54 --> Router Class Initialized
INFO - 2016-10-17 12:52:54 --> Output Class Initialized
INFO - 2016-10-17 12:52:54 --> Security Class Initialized
DEBUG - 2016-10-17 12:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:52:54 --> Input Class Initialized
INFO - 2016-10-17 12:52:54 --> Language Class Initialized
INFO - 2016-10-17 12:52:54 --> Loader Class Initialized
INFO - 2016-10-17 12:52:54 --> Helper loaded: url_helper
INFO - 2016-10-17 12:52:54 --> Helper loaded: form_helper
INFO - 2016-10-17 12:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:52:54 --> Controller Class Initialized
INFO - 2016-10-17 12:52:54 --> Form Validation Class Initialized
INFO - 2016-10-17 12:52:54 --> Database Driver Class Initialized
ERROR - 2016-10-17 12:52:54 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 12:52:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 12:52:54 --> Unable to connect to the database
INFO - 2016-10-17 12:52:54 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-17 12:53:15 --> Config Class Initialized
INFO - 2016-10-17 12:53:15 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:53:15 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:53:15 --> Utf8 Class Initialized
INFO - 2016-10-17 12:53:15 --> URI Class Initialized
DEBUG - 2016-10-17 12:53:15 --> No URI present. Default controller set.
INFO - 2016-10-17 12:53:15 --> Router Class Initialized
INFO - 2016-10-17 12:53:15 --> Output Class Initialized
INFO - 2016-10-17 12:53:15 --> Security Class Initialized
DEBUG - 2016-10-17 12:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:53:15 --> Input Class Initialized
INFO - 2016-10-17 12:53:15 --> Language Class Initialized
INFO - 2016-10-17 12:53:15 --> Loader Class Initialized
INFO - 2016-10-17 12:53:15 --> Helper loaded: url_helper
INFO - 2016-10-17 12:53:15 --> Helper loaded: form_helper
INFO - 2016-10-17 12:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:53:15 --> Controller Class Initialized
INFO - 2016-10-17 12:53:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:53:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:53:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:53:15 --> Final output sent to browser
DEBUG - 2016-10-17 12:53:15 --> Total execution time: 0.0052
INFO - 2016-10-17 12:53:17 --> Config Class Initialized
INFO - 2016-10-17 12:53:17 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:53:17 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:53:17 --> Utf8 Class Initialized
INFO - 2016-10-17 12:53:17 --> URI Class Initialized
INFO - 2016-10-17 12:53:17 --> Router Class Initialized
INFO - 2016-10-17 12:53:17 --> Output Class Initialized
INFO - 2016-10-17 12:53:17 --> Security Class Initialized
DEBUG - 2016-10-17 12:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:53:17 --> Input Class Initialized
INFO - 2016-10-17 12:53:17 --> Language Class Initialized
INFO - 2016-10-17 12:53:17 --> Loader Class Initialized
INFO - 2016-10-17 12:53:17 --> Helper loaded: url_helper
INFO - 2016-10-17 12:53:17 --> Helper loaded: form_helper
INFO - 2016-10-17 12:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:53:17 --> Controller Class Initialized
INFO - 2016-10-17 12:53:17 --> Form Validation Class Initialized
INFO - 2016-10-17 12:53:17 --> Database Driver Class Initialized
ERROR - 2016-10-17 12:53:17 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 12:53:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 12:53:17 --> Unable to connect to the database
INFO - 2016-10-17 12:53:17 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-17 12:53:32 --> Config Class Initialized
INFO - 2016-10-17 12:53:32 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:53:32 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:53:32 --> Utf8 Class Initialized
INFO - 2016-10-17 12:53:32 --> URI Class Initialized
INFO - 2016-10-17 12:53:32 --> Router Class Initialized
INFO - 2016-10-17 12:53:32 --> Output Class Initialized
INFO - 2016-10-17 12:53:32 --> Security Class Initialized
DEBUG - 2016-10-17 12:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:53:32 --> Input Class Initialized
INFO - 2016-10-17 12:53:32 --> Language Class Initialized
INFO - 2016-10-17 12:53:32 --> Loader Class Initialized
INFO - 2016-10-17 12:53:32 --> Helper loaded: url_helper
INFO - 2016-10-17 12:53:32 --> Helper loaded: form_helper
INFO - 2016-10-17 12:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:53:32 --> Controller Class Initialized
INFO - 2016-10-17 12:53:32 --> Form Validation Class Initialized
INFO - 2016-10-17 12:53:32 --> Final output sent to browser
DEBUG - 2016-10-17 12:53:32 --> Total execution time: 0.0024
INFO - 2016-10-17 12:53:32 --> Config Class Initialized
INFO - 2016-10-17 12:53:32 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:53:32 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:53:32 --> Utf8 Class Initialized
INFO - 2016-10-17 12:53:32 --> URI Class Initialized
DEBUG - 2016-10-17 12:53:32 --> No URI present. Default controller set.
INFO - 2016-10-17 12:53:32 --> Router Class Initialized
INFO - 2016-10-17 12:53:32 --> Output Class Initialized
INFO - 2016-10-17 12:53:32 --> Security Class Initialized
DEBUG - 2016-10-17 12:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:53:32 --> Input Class Initialized
INFO - 2016-10-17 12:53:32 --> Language Class Initialized
INFO - 2016-10-17 12:53:32 --> Loader Class Initialized
INFO - 2016-10-17 12:53:32 --> Helper loaded: url_helper
INFO - 2016-10-17 12:53:32 --> Helper loaded: form_helper
INFO - 2016-10-17 12:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:53:32 --> Controller Class Initialized
INFO - 2016-10-17 12:53:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:53:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:53:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:53:32 --> Final output sent to browser
DEBUG - 2016-10-17 12:53:32 --> Total execution time: 0.0021
INFO - 2016-10-17 12:53:36 --> Config Class Initialized
INFO - 2016-10-17 12:53:36 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:53:36 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:53:36 --> Utf8 Class Initialized
INFO - 2016-10-17 12:53:36 --> URI Class Initialized
INFO - 2016-10-17 12:53:36 --> Router Class Initialized
INFO - 2016-10-17 12:53:36 --> Output Class Initialized
INFO - 2016-10-17 12:53:36 --> Security Class Initialized
DEBUG - 2016-10-17 12:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:53:36 --> Input Class Initialized
INFO - 2016-10-17 12:53:36 --> Language Class Initialized
INFO - 2016-10-17 12:53:36 --> Loader Class Initialized
INFO - 2016-10-17 12:53:36 --> Helper loaded: url_helper
INFO - 2016-10-17 12:53:36 --> Helper loaded: form_helper
INFO - 2016-10-17 12:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:53:36 --> Controller Class Initialized
INFO - 2016-10-17 12:53:36 --> Form Validation Class Initialized
INFO - 2016-10-17 12:53:36 --> Final output sent to browser
DEBUG - 2016-10-17 12:53:36 --> Total execution time: 0.0026
INFO - 2016-10-17 12:53:36 --> Config Class Initialized
INFO - 2016-10-17 12:53:36 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:53:36 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:53:36 --> Utf8 Class Initialized
INFO - 2016-10-17 12:53:36 --> URI Class Initialized
DEBUG - 2016-10-17 12:53:36 --> No URI present. Default controller set.
INFO - 2016-10-17 12:53:36 --> Router Class Initialized
INFO - 2016-10-17 12:53:36 --> Output Class Initialized
INFO - 2016-10-17 12:53:36 --> Security Class Initialized
DEBUG - 2016-10-17 12:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:53:36 --> Input Class Initialized
INFO - 2016-10-17 12:53:36 --> Language Class Initialized
INFO - 2016-10-17 12:53:36 --> Loader Class Initialized
INFO - 2016-10-17 12:53:36 --> Helper loaded: url_helper
INFO - 2016-10-17 12:53:36 --> Helper loaded: form_helper
INFO - 2016-10-17 12:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:53:36 --> Controller Class Initialized
INFO - 2016-10-17 12:53:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:53:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:53:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:53:36 --> Final output sent to browser
DEBUG - 2016-10-17 12:53:36 --> Total execution time: 0.0020
INFO - 2016-10-17 12:54:40 --> Config Class Initialized
INFO - 2016-10-17 12:54:40 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:54:40 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:54:40 --> Utf8 Class Initialized
INFO - 2016-10-17 12:54:40 --> URI Class Initialized
DEBUG - 2016-10-17 12:54:40 --> No URI present. Default controller set.
INFO - 2016-10-17 12:54:40 --> Router Class Initialized
INFO - 2016-10-17 12:54:40 --> Output Class Initialized
INFO - 2016-10-17 12:54:40 --> Security Class Initialized
DEBUG - 2016-10-17 12:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:54:40 --> Input Class Initialized
INFO - 2016-10-17 12:54:40 --> Language Class Initialized
INFO - 2016-10-17 12:54:40 --> Loader Class Initialized
INFO - 2016-10-17 12:54:40 --> Helper loaded: url_helper
INFO - 2016-10-17 12:54:40 --> Helper loaded: form_helper
INFO - 2016-10-17 12:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:54:40 --> Controller Class Initialized
INFO - 2016-10-17 12:54:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:54:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:54:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:54:40 --> Final output sent to browser
DEBUG - 2016-10-17 12:54:40 --> Total execution time: 0.0054
INFO - 2016-10-17 12:54:48 --> Config Class Initialized
INFO - 2016-10-17 12:54:48 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:54:48 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:54:48 --> Utf8 Class Initialized
INFO - 2016-10-17 12:54:48 --> URI Class Initialized
INFO - 2016-10-17 12:54:48 --> Router Class Initialized
INFO - 2016-10-17 12:54:48 --> Output Class Initialized
INFO - 2016-10-17 12:54:48 --> Security Class Initialized
DEBUG - 2016-10-17 12:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:54:48 --> Input Class Initialized
INFO - 2016-10-17 12:54:48 --> Language Class Initialized
INFO - 2016-10-17 12:54:48 --> Loader Class Initialized
INFO - 2016-10-17 12:54:48 --> Helper loaded: url_helper
INFO - 2016-10-17 12:54:48 --> Helper loaded: form_helper
INFO - 2016-10-17 12:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:54:48 --> Controller Class Initialized
INFO - 2016-10-17 12:54:48 --> Form Validation Class Initialized
INFO - 2016-10-17 12:54:48 --> Final output sent to browser
DEBUG - 2016-10-17 12:54:48 --> Total execution time: 0.0022
INFO - 2016-10-17 12:54:48 --> Config Class Initialized
INFO - 2016-10-17 12:54:48 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:54:48 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:54:48 --> Utf8 Class Initialized
INFO - 2016-10-17 12:54:48 --> URI Class Initialized
DEBUG - 2016-10-17 12:54:48 --> No URI present. Default controller set.
INFO - 2016-10-17 12:54:48 --> Router Class Initialized
INFO - 2016-10-17 12:54:48 --> Output Class Initialized
INFO - 2016-10-17 12:54:48 --> Security Class Initialized
DEBUG - 2016-10-17 12:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:54:48 --> Input Class Initialized
INFO - 2016-10-17 12:54:48 --> Language Class Initialized
INFO - 2016-10-17 12:54:48 --> Loader Class Initialized
INFO - 2016-10-17 12:54:48 --> Helper loaded: url_helper
INFO - 2016-10-17 12:54:48 --> Helper loaded: form_helper
INFO - 2016-10-17 12:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:54:48 --> Controller Class Initialized
INFO - 2016-10-17 12:54:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:54:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:54:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:54:48 --> Final output sent to browser
DEBUG - 2016-10-17 12:54:48 --> Total execution time: 0.0019
INFO - 2016-10-17 12:55:14 --> Config Class Initialized
INFO - 2016-10-17 12:55:14 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:55:14 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:55:14 --> Utf8 Class Initialized
INFO - 2016-10-17 12:55:14 --> URI Class Initialized
DEBUG - 2016-10-17 12:55:14 --> No URI present. Default controller set.
INFO - 2016-10-17 12:55:14 --> Router Class Initialized
INFO - 2016-10-17 12:55:14 --> Output Class Initialized
INFO - 2016-10-17 12:55:14 --> Security Class Initialized
DEBUG - 2016-10-17 12:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:55:14 --> Input Class Initialized
INFO - 2016-10-17 12:55:14 --> Language Class Initialized
INFO - 2016-10-17 12:55:14 --> Loader Class Initialized
INFO - 2016-10-17 12:55:14 --> Helper loaded: url_helper
INFO - 2016-10-17 12:55:14 --> Helper loaded: form_helper
INFO - 2016-10-17 12:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:55:14 --> Controller Class Initialized
INFO - 2016-10-17 12:55:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:55:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:55:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:55:14 --> Final output sent to browser
DEBUG - 2016-10-17 12:55:14 --> Total execution time: 0.0051
INFO - 2016-10-17 12:55:18 --> Config Class Initialized
INFO - 2016-10-17 12:55:18 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:55:18 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:55:18 --> Utf8 Class Initialized
INFO - 2016-10-17 12:55:18 --> URI Class Initialized
INFO - 2016-10-17 12:55:18 --> Router Class Initialized
INFO - 2016-10-17 12:55:18 --> Output Class Initialized
INFO - 2016-10-17 12:55:18 --> Security Class Initialized
DEBUG - 2016-10-17 12:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:55:18 --> Input Class Initialized
INFO - 2016-10-17 12:55:18 --> Language Class Initialized
INFO - 2016-10-17 12:55:18 --> Loader Class Initialized
INFO - 2016-10-17 12:55:18 --> Helper loaded: url_helper
INFO - 2016-10-17 12:55:18 --> Helper loaded: form_helper
INFO - 2016-10-17 12:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:55:18 --> Controller Class Initialized
INFO - 2016-10-17 12:55:18 --> Form Validation Class Initialized
INFO - 2016-10-17 12:55:18 --> Final output sent to browser
DEBUG - 2016-10-17 12:55:18 --> Total execution time: 0.0054
INFO - 2016-10-17 12:55:18 --> Config Class Initialized
INFO - 2016-10-17 12:55:18 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:55:18 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:55:18 --> Utf8 Class Initialized
INFO - 2016-10-17 12:55:18 --> URI Class Initialized
DEBUG - 2016-10-17 12:55:18 --> No URI present. Default controller set.
INFO - 2016-10-17 12:55:18 --> Router Class Initialized
INFO - 2016-10-17 12:55:18 --> Output Class Initialized
INFO - 2016-10-17 12:55:18 --> Security Class Initialized
DEBUG - 2016-10-17 12:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:55:18 --> Input Class Initialized
INFO - 2016-10-17 12:55:18 --> Language Class Initialized
INFO - 2016-10-17 12:55:18 --> Loader Class Initialized
INFO - 2016-10-17 12:55:18 --> Helper loaded: url_helper
INFO - 2016-10-17 12:55:18 --> Helper loaded: form_helper
INFO - 2016-10-17 12:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:55:18 --> Controller Class Initialized
INFO - 2016-10-17 12:55:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:55:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:55:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:55:18 --> Final output sent to browser
DEBUG - 2016-10-17 12:55:18 --> Total execution time: 0.0023
INFO - 2016-10-17 12:55:26 --> Config Class Initialized
INFO - 2016-10-17 12:55:26 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:55:26 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:55:26 --> Utf8 Class Initialized
INFO - 2016-10-17 12:55:26 --> URI Class Initialized
DEBUG - 2016-10-17 12:55:26 --> No URI present. Default controller set.
INFO - 2016-10-17 12:55:26 --> Router Class Initialized
INFO - 2016-10-17 12:55:26 --> Output Class Initialized
INFO - 2016-10-17 12:55:26 --> Security Class Initialized
DEBUG - 2016-10-17 12:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:55:26 --> Input Class Initialized
INFO - 2016-10-17 12:55:26 --> Language Class Initialized
INFO - 2016-10-17 12:55:26 --> Loader Class Initialized
INFO - 2016-10-17 12:55:26 --> Helper loaded: url_helper
INFO - 2016-10-17 12:55:26 --> Helper loaded: form_helper
INFO - 2016-10-17 12:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:55:26 --> Controller Class Initialized
INFO - 2016-10-17 12:55:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:55:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:55:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:55:26 --> Final output sent to browser
DEBUG - 2016-10-17 12:55:26 --> Total execution time: 0.0049
INFO - 2016-10-17 12:57:32 --> Config Class Initialized
INFO - 2016-10-17 12:57:32 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:57:32 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:57:32 --> Utf8 Class Initialized
INFO - 2016-10-17 12:57:32 --> URI Class Initialized
DEBUG - 2016-10-17 12:57:32 --> No URI present. Default controller set.
INFO - 2016-10-17 12:57:32 --> Router Class Initialized
INFO - 2016-10-17 12:57:32 --> Output Class Initialized
INFO - 2016-10-17 12:57:32 --> Security Class Initialized
DEBUG - 2016-10-17 12:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:57:32 --> Input Class Initialized
INFO - 2016-10-17 12:57:32 --> Language Class Initialized
INFO - 2016-10-17 12:57:32 --> Loader Class Initialized
INFO - 2016-10-17 12:57:32 --> Helper loaded: url_helper
INFO - 2016-10-17 12:57:32 --> Helper loaded: form_helper
INFO - 2016-10-17 12:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:57:32 --> Controller Class Initialized
INFO - 2016-10-17 12:57:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:57:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:57:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:57:32 --> Final output sent to browser
DEBUG - 2016-10-17 12:57:32 --> Total execution time: 0.0064
INFO - 2016-10-17 12:57:36 --> Config Class Initialized
INFO - 2016-10-17 12:57:36 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:57:36 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:57:36 --> Utf8 Class Initialized
INFO - 2016-10-17 12:57:36 --> URI Class Initialized
INFO - 2016-10-17 12:57:36 --> Router Class Initialized
INFO - 2016-10-17 12:57:36 --> Output Class Initialized
INFO - 2016-10-17 12:57:36 --> Security Class Initialized
DEBUG - 2016-10-17 12:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:57:36 --> Input Class Initialized
INFO - 2016-10-17 12:57:36 --> Language Class Initialized
INFO - 2016-10-17 12:57:36 --> Loader Class Initialized
INFO - 2016-10-17 12:57:36 --> Helper loaded: url_helper
INFO - 2016-10-17 12:57:36 --> Helper loaded: form_helper
INFO - 2016-10-17 12:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:57:36 --> Controller Class Initialized
INFO - 2016-10-17 12:57:36 --> Form Validation Class Initialized
INFO - 2016-10-17 12:57:36 --> Final output sent to browser
DEBUG - 2016-10-17 12:57:36 --> Total execution time: 0.0024
INFO - 2016-10-17 12:57:36 --> Config Class Initialized
INFO - 2016-10-17 12:57:36 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:57:36 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:57:36 --> Utf8 Class Initialized
INFO - 2016-10-17 12:57:36 --> URI Class Initialized
DEBUG - 2016-10-17 12:57:36 --> No URI present. Default controller set.
INFO - 2016-10-17 12:57:36 --> Router Class Initialized
INFO - 2016-10-17 12:57:36 --> Output Class Initialized
INFO - 2016-10-17 12:57:36 --> Security Class Initialized
DEBUG - 2016-10-17 12:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:57:36 --> Input Class Initialized
INFO - 2016-10-17 12:57:36 --> Language Class Initialized
INFO - 2016-10-17 12:57:36 --> Loader Class Initialized
INFO - 2016-10-17 12:57:36 --> Helper loaded: url_helper
INFO - 2016-10-17 12:57:36 --> Helper loaded: form_helper
INFO - 2016-10-17 12:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:57:36 --> Controller Class Initialized
INFO - 2016-10-17 12:57:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:57:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:57:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:57:36 --> Final output sent to browser
DEBUG - 2016-10-17 12:57:36 --> Total execution time: 0.0019
INFO - 2016-10-17 12:59:09 --> Config Class Initialized
INFO - 2016-10-17 12:59:09 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:59:09 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:59:09 --> Utf8 Class Initialized
INFO - 2016-10-17 12:59:09 --> URI Class Initialized
DEBUG - 2016-10-17 12:59:09 --> No URI present. Default controller set.
INFO - 2016-10-17 12:59:09 --> Router Class Initialized
INFO - 2016-10-17 12:59:09 --> Output Class Initialized
INFO - 2016-10-17 12:59:09 --> Security Class Initialized
DEBUG - 2016-10-17 12:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:59:09 --> Input Class Initialized
INFO - 2016-10-17 12:59:09 --> Language Class Initialized
INFO - 2016-10-17 12:59:09 --> Loader Class Initialized
INFO - 2016-10-17 12:59:09 --> Helper loaded: url_helper
INFO - 2016-10-17 12:59:09 --> Helper loaded: form_helper
INFO - 2016-10-17 12:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:59:09 --> Controller Class Initialized
INFO - 2016-10-17 12:59:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 12:59:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 12:59:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 12:59:09 --> Final output sent to browser
DEBUG - 2016-10-17 12:59:09 --> Total execution time: 0.0049
INFO - 2016-10-17 13:00:26 --> Config Class Initialized
INFO - 2016-10-17 13:00:26 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:00:26 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:00:26 --> Utf8 Class Initialized
INFO - 2016-10-17 13:00:26 --> URI Class Initialized
DEBUG - 2016-10-17 13:00:26 --> No URI present. Default controller set.
INFO - 2016-10-17 13:00:26 --> Router Class Initialized
INFO - 2016-10-17 13:00:26 --> Output Class Initialized
INFO - 2016-10-17 13:00:26 --> Security Class Initialized
DEBUG - 2016-10-17 13:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:00:26 --> Input Class Initialized
INFO - 2016-10-17 13:00:26 --> Language Class Initialized
INFO - 2016-10-17 13:00:26 --> Loader Class Initialized
INFO - 2016-10-17 13:00:26 --> Helper loaded: url_helper
INFO - 2016-10-17 13:00:26 --> Helper loaded: form_helper
INFO - 2016-10-17 13:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:00:26 --> Controller Class Initialized
INFO - 2016-10-17 13:00:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:00:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:00:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:00:26 --> Final output sent to browser
DEBUG - 2016-10-17 13:00:26 --> Total execution time: 0.0028
INFO - 2016-10-17 13:00:36 --> Config Class Initialized
INFO - 2016-10-17 13:00:36 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:00:36 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:00:36 --> Utf8 Class Initialized
INFO - 2016-10-17 13:00:36 --> URI Class Initialized
INFO - 2016-10-17 13:00:36 --> Router Class Initialized
INFO - 2016-10-17 13:00:36 --> Output Class Initialized
INFO - 2016-10-17 13:00:36 --> Security Class Initialized
DEBUG - 2016-10-17 13:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:00:36 --> Input Class Initialized
INFO - 2016-10-17 13:00:36 --> Language Class Initialized
INFO - 2016-10-17 13:00:36 --> Loader Class Initialized
INFO - 2016-10-17 13:00:36 --> Helper loaded: url_helper
INFO - 2016-10-17 13:00:36 --> Helper loaded: form_helper
INFO - 2016-10-17 13:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:00:36 --> Controller Class Initialized
INFO - 2016-10-17 13:00:36 --> Form Validation Class Initialized
INFO - 2016-10-17 13:00:36 --> Final output sent to browser
DEBUG - 2016-10-17 13:00:36 --> Total execution time: 0.0028
INFO - 2016-10-17 13:00:36 --> Config Class Initialized
INFO - 2016-10-17 13:00:36 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:00:36 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:00:36 --> Utf8 Class Initialized
INFO - 2016-10-17 13:00:36 --> URI Class Initialized
DEBUG - 2016-10-17 13:00:36 --> No URI present. Default controller set.
INFO - 2016-10-17 13:00:36 --> Router Class Initialized
INFO - 2016-10-17 13:00:36 --> Output Class Initialized
INFO - 2016-10-17 13:00:36 --> Security Class Initialized
DEBUG - 2016-10-17 13:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:00:36 --> Input Class Initialized
INFO - 2016-10-17 13:00:36 --> Language Class Initialized
INFO - 2016-10-17 13:00:36 --> Loader Class Initialized
INFO - 2016-10-17 13:00:36 --> Helper loaded: url_helper
INFO - 2016-10-17 13:00:36 --> Helper loaded: form_helper
INFO - 2016-10-17 13:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:00:36 --> Controller Class Initialized
INFO - 2016-10-17 13:00:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:00:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:00:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:00:36 --> Final output sent to browser
DEBUG - 2016-10-17 13:00:36 --> Total execution time: 0.0021
INFO - 2016-10-17 13:05:49 --> Config Class Initialized
INFO - 2016-10-17 13:05:49 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:05:49 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:05:49 --> Utf8 Class Initialized
INFO - 2016-10-17 13:05:49 --> URI Class Initialized
DEBUG - 2016-10-17 13:05:49 --> No URI present. Default controller set.
INFO - 2016-10-17 13:05:49 --> Router Class Initialized
INFO - 2016-10-17 13:05:49 --> Output Class Initialized
INFO - 2016-10-17 13:05:49 --> Security Class Initialized
DEBUG - 2016-10-17 13:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:05:49 --> Input Class Initialized
INFO - 2016-10-17 13:05:49 --> Language Class Initialized
INFO - 2016-10-17 13:05:49 --> Loader Class Initialized
INFO - 2016-10-17 13:05:49 --> Helper loaded: url_helper
INFO - 2016-10-17 13:05:49 --> Helper loaded: form_helper
INFO - 2016-10-17 13:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:05:49 --> Controller Class Initialized
INFO - 2016-10-17 13:05:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:05:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:05:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:05:49 --> Final output sent to browser
DEBUG - 2016-10-17 13:05:49 --> Total execution time: 0.0036
INFO - 2016-10-17 13:07:17 --> Config Class Initialized
INFO - 2016-10-17 13:07:17 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:07:17 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:07:17 --> Utf8 Class Initialized
INFO - 2016-10-17 13:07:17 --> URI Class Initialized
DEBUG - 2016-10-17 13:07:17 --> No URI present. Default controller set.
INFO - 2016-10-17 13:07:17 --> Router Class Initialized
INFO - 2016-10-17 13:07:17 --> Output Class Initialized
INFO - 2016-10-17 13:07:17 --> Security Class Initialized
DEBUG - 2016-10-17 13:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:07:17 --> Input Class Initialized
INFO - 2016-10-17 13:07:17 --> Language Class Initialized
INFO - 2016-10-17 13:07:17 --> Loader Class Initialized
INFO - 2016-10-17 13:07:17 --> Helper loaded: url_helper
INFO - 2016-10-17 13:07:17 --> Helper loaded: form_helper
INFO - 2016-10-17 13:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:07:17 --> Controller Class Initialized
INFO - 2016-10-17 13:07:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:07:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:07:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:07:17 --> Final output sent to browser
DEBUG - 2016-10-17 13:07:17 --> Total execution time: 0.0040
INFO - 2016-10-17 13:07:23 --> Config Class Initialized
INFO - 2016-10-17 13:07:23 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:07:23 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:07:23 --> Utf8 Class Initialized
INFO - 2016-10-17 13:07:23 --> URI Class Initialized
INFO - 2016-10-17 13:07:23 --> Router Class Initialized
INFO - 2016-10-17 13:07:23 --> Output Class Initialized
INFO - 2016-10-17 13:07:23 --> Security Class Initialized
DEBUG - 2016-10-17 13:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:07:23 --> Input Class Initialized
INFO - 2016-10-17 13:07:23 --> Language Class Initialized
INFO - 2016-10-17 13:07:23 --> Loader Class Initialized
INFO - 2016-10-17 13:07:23 --> Helper loaded: url_helper
INFO - 2016-10-17 13:07:23 --> Helper loaded: form_helper
INFO - 2016-10-17 13:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:07:23 --> Controller Class Initialized
INFO - 2016-10-17 13:07:23 --> Form Validation Class Initialized
INFO - 2016-10-17 13:07:23 --> Database Driver Class Initialized
ERROR - 2016-10-17 13:07:23 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 13:07:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 13:07:23 --> Unable to connect to the database
INFO - 2016-10-17 13:07:23 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-17 13:07:55 --> Config Class Initialized
INFO - 2016-10-17 13:07:55 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:07:55 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:07:55 --> Utf8 Class Initialized
INFO - 2016-10-17 13:07:55 --> URI Class Initialized
DEBUG - 2016-10-17 13:07:55 --> No URI present. Default controller set.
INFO - 2016-10-17 13:07:55 --> Router Class Initialized
INFO - 2016-10-17 13:07:55 --> Output Class Initialized
INFO - 2016-10-17 13:07:55 --> Security Class Initialized
DEBUG - 2016-10-17 13:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:07:55 --> Input Class Initialized
INFO - 2016-10-17 13:07:55 --> Language Class Initialized
INFO - 2016-10-17 13:07:55 --> Loader Class Initialized
INFO - 2016-10-17 13:07:55 --> Helper loaded: url_helper
INFO - 2016-10-17 13:07:55 --> Helper loaded: form_helper
INFO - 2016-10-17 13:07:55 --> Database Driver Class Initialized
ERROR - 2016-10-17 13:07:55 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 13:07:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-17 13:07:55 --> Unable to connect to the database
INFO - 2016-10-17 13:07:55 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-17 13:09:29 --> Config Class Initialized
INFO - 2016-10-17 13:09:29 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:09:29 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:09:29 --> Utf8 Class Initialized
INFO - 2016-10-17 13:09:29 --> URI Class Initialized
DEBUG - 2016-10-17 13:09:29 --> No URI present. Default controller set.
INFO - 2016-10-17 13:09:29 --> Router Class Initialized
INFO - 2016-10-17 13:09:29 --> Output Class Initialized
INFO - 2016-10-17 13:09:29 --> Security Class Initialized
DEBUG - 2016-10-17 13:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:09:29 --> Input Class Initialized
INFO - 2016-10-17 13:09:29 --> Language Class Initialized
INFO - 2016-10-17 13:09:29 --> Loader Class Initialized
INFO - 2016-10-17 13:09:29 --> Helper loaded: url_helper
INFO - 2016-10-17 13:09:29 --> Helper loaded: form_helper
INFO - 2016-10-17 13:09:29 --> Database Driver Class Initialized
INFO - 2016-10-17 13:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:09:29 --> Controller Class Initialized
INFO - 2016-10-17 13:09:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:09:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:09:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:09:29 --> Final output sent to browser
DEBUG - 2016-10-17 13:09:29 --> Total execution time: 0.0058
INFO - 2016-10-17 13:09:38 --> Config Class Initialized
INFO - 2016-10-17 13:09:38 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:09:38 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:09:38 --> Utf8 Class Initialized
INFO - 2016-10-17 13:09:38 --> URI Class Initialized
INFO - 2016-10-17 13:09:38 --> Router Class Initialized
INFO - 2016-10-17 13:09:38 --> Output Class Initialized
INFO - 2016-10-17 13:09:38 --> Security Class Initialized
DEBUG - 2016-10-17 13:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:09:38 --> Input Class Initialized
INFO - 2016-10-17 13:09:38 --> Language Class Initialized
INFO - 2016-10-17 13:09:38 --> Loader Class Initialized
INFO - 2016-10-17 13:09:38 --> Helper loaded: url_helper
INFO - 2016-10-17 13:09:38 --> Helper loaded: form_helper
INFO - 2016-10-17 13:09:38 --> Database Driver Class Initialized
INFO - 2016-10-17 13:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:09:38 --> Controller Class Initialized
INFO - 2016-10-17 13:09:38 --> Form Validation Class Initialized
INFO - 2016-10-17 13:09:38 --> Model Class Initialized
INFO - 2016-10-17 13:09:38 --> Final output sent to browser
DEBUG - 2016-10-17 13:09:38 --> Total execution time: 0.0069
INFO - 2016-10-17 13:10:21 --> Config Class Initialized
INFO - 2016-10-17 13:10:21 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:10:21 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:10:21 --> Utf8 Class Initialized
INFO - 2016-10-17 13:10:21 --> URI Class Initialized
DEBUG - 2016-10-17 13:10:21 --> No URI present. Default controller set.
INFO - 2016-10-17 13:10:21 --> Router Class Initialized
INFO - 2016-10-17 13:10:21 --> Output Class Initialized
INFO - 2016-10-17 13:10:21 --> Security Class Initialized
DEBUG - 2016-10-17 13:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:10:21 --> Input Class Initialized
INFO - 2016-10-17 13:10:21 --> Language Class Initialized
INFO - 2016-10-17 13:10:21 --> Loader Class Initialized
INFO - 2016-10-17 13:10:21 --> Helper loaded: url_helper
INFO - 2016-10-17 13:10:21 --> Helper loaded: form_helper
INFO - 2016-10-17 13:10:21 --> Database Driver Class Initialized
INFO - 2016-10-17 13:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:10:21 --> Controller Class Initialized
INFO - 2016-10-17 13:10:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:10:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:10:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:10:21 --> Final output sent to browser
DEBUG - 2016-10-17 13:10:21 --> Total execution time: 0.0046
INFO - 2016-10-17 13:10:26 --> Config Class Initialized
INFO - 2016-10-17 13:10:26 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:10:26 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:10:26 --> Utf8 Class Initialized
INFO - 2016-10-17 13:10:26 --> URI Class Initialized
INFO - 2016-10-17 13:10:26 --> Router Class Initialized
INFO - 2016-10-17 13:10:26 --> Output Class Initialized
INFO - 2016-10-17 13:10:26 --> Security Class Initialized
DEBUG - 2016-10-17 13:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:10:26 --> Input Class Initialized
INFO - 2016-10-17 13:10:26 --> Language Class Initialized
INFO - 2016-10-17 13:10:26 --> Loader Class Initialized
INFO - 2016-10-17 13:10:26 --> Helper loaded: url_helper
INFO - 2016-10-17 13:10:26 --> Helper loaded: form_helper
INFO - 2016-10-17 13:10:26 --> Database Driver Class Initialized
INFO - 2016-10-17 13:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:10:26 --> Controller Class Initialized
INFO - 2016-10-17 13:10:26 --> Form Validation Class Initialized
INFO - 2016-10-17 13:10:26 --> Model Class Initialized
INFO - 2016-10-17 13:10:26 --> Final output sent to browser
DEBUG - 2016-10-17 13:10:26 --> Total execution time: 0.0057
INFO - 2016-10-17 13:12:18 --> Config Class Initialized
INFO - 2016-10-17 13:12:18 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:12:18 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:12:18 --> Utf8 Class Initialized
INFO - 2016-10-17 13:12:18 --> URI Class Initialized
DEBUG - 2016-10-17 13:12:18 --> No URI present. Default controller set.
INFO - 2016-10-17 13:12:18 --> Router Class Initialized
INFO - 2016-10-17 13:12:18 --> Output Class Initialized
INFO - 2016-10-17 13:12:18 --> Security Class Initialized
DEBUG - 2016-10-17 13:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:12:18 --> Input Class Initialized
INFO - 2016-10-17 13:12:18 --> Language Class Initialized
INFO - 2016-10-17 13:12:18 --> Loader Class Initialized
INFO - 2016-10-17 13:12:18 --> Helper loaded: url_helper
INFO - 2016-10-17 13:12:18 --> Helper loaded: form_helper
INFO - 2016-10-17 13:12:18 --> Database Driver Class Initialized
INFO - 2016-10-17 13:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:12:18 --> Controller Class Initialized
INFO - 2016-10-17 13:12:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:12:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:12:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:12:18 --> Final output sent to browser
DEBUG - 2016-10-17 13:12:18 --> Total execution time: 0.0089
INFO - 2016-10-17 13:12:22 --> Config Class Initialized
INFO - 2016-10-17 13:12:22 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:12:22 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:12:22 --> Utf8 Class Initialized
INFO - 2016-10-17 13:12:22 --> URI Class Initialized
INFO - 2016-10-17 13:12:22 --> Router Class Initialized
INFO - 2016-10-17 13:12:22 --> Output Class Initialized
INFO - 2016-10-17 13:12:22 --> Security Class Initialized
DEBUG - 2016-10-17 13:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:12:22 --> Input Class Initialized
INFO - 2016-10-17 13:12:22 --> Language Class Initialized
INFO - 2016-10-17 13:12:22 --> Loader Class Initialized
INFO - 2016-10-17 13:12:22 --> Helper loaded: url_helper
INFO - 2016-10-17 13:12:22 --> Helper loaded: form_helper
INFO - 2016-10-17 13:12:22 --> Database Driver Class Initialized
INFO - 2016-10-17 13:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:12:22 --> Controller Class Initialized
INFO - 2016-10-17 13:12:22 --> Form Validation Class Initialized
INFO - 2016-10-17 13:12:22 --> Model Class Initialized
INFO - 2016-10-17 13:12:22 --> Final output sent to browser
DEBUG - 2016-10-17 13:12:22 --> Total execution time: 0.0083
INFO - 2016-10-17 13:13:03 --> Config Class Initialized
INFO - 2016-10-17 13:13:03 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:13:03 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:13:03 --> Utf8 Class Initialized
INFO - 2016-10-17 13:13:03 --> URI Class Initialized
DEBUG - 2016-10-17 13:13:03 --> No URI present. Default controller set.
INFO - 2016-10-17 13:13:03 --> Router Class Initialized
INFO - 2016-10-17 13:13:03 --> Output Class Initialized
INFO - 2016-10-17 13:13:03 --> Security Class Initialized
DEBUG - 2016-10-17 13:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:13:03 --> Input Class Initialized
INFO - 2016-10-17 13:13:03 --> Language Class Initialized
INFO - 2016-10-17 13:13:03 --> Loader Class Initialized
INFO - 2016-10-17 13:13:03 --> Helper loaded: url_helper
INFO - 2016-10-17 13:13:03 --> Helper loaded: form_helper
INFO - 2016-10-17 13:13:03 --> Database Driver Class Initialized
INFO - 2016-10-17 13:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:13:03 --> Controller Class Initialized
INFO - 2016-10-17 13:13:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:13:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:13:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:13:03 --> Final output sent to browser
DEBUG - 2016-10-17 13:13:03 --> Total execution time: 0.0052
INFO - 2016-10-17 13:13:09 --> Config Class Initialized
INFO - 2016-10-17 13:13:09 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:13:09 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:13:09 --> Utf8 Class Initialized
INFO - 2016-10-17 13:13:09 --> URI Class Initialized
INFO - 2016-10-17 13:13:09 --> Router Class Initialized
INFO - 2016-10-17 13:13:09 --> Output Class Initialized
INFO - 2016-10-17 13:13:09 --> Security Class Initialized
DEBUG - 2016-10-17 13:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:13:09 --> Input Class Initialized
INFO - 2016-10-17 13:13:09 --> Language Class Initialized
INFO - 2016-10-17 13:13:09 --> Loader Class Initialized
INFO - 2016-10-17 13:13:09 --> Helper loaded: url_helper
INFO - 2016-10-17 13:13:09 --> Helper loaded: form_helper
INFO - 2016-10-17 13:13:09 --> Database Driver Class Initialized
INFO - 2016-10-17 13:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:13:09 --> Controller Class Initialized
INFO - 2016-10-17 13:13:09 --> Form Validation Class Initialized
INFO - 2016-10-17 13:13:09 --> Model Class Initialized
INFO - 2016-10-17 13:13:09 --> Final output sent to browser
DEBUG - 2016-10-17 13:13:09 --> Total execution time: 0.0056
INFO - 2016-10-17 13:16:12 --> Config Class Initialized
INFO - 2016-10-17 13:16:12 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:16:12 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:16:12 --> Utf8 Class Initialized
INFO - 2016-10-17 13:16:12 --> URI Class Initialized
DEBUG - 2016-10-17 13:16:12 --> No URI present. Default controller set.
INFO - 2016-10-17 13:16:12 --> Router Class Initialized
INFO - 2016-10-17 13:16:12 --> Output Class Initialized
INFO - 2016-10-17 13:16:12 --> Security Class Initialized
DEBUG - 2016-10-17 13:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:16:12 --> Input Class Initialized
INFO - 2016-10-17 13:16:12 --> Language Class Initialized
INFO - 2016-10-17 13:16:12 --> Loader Class Initialized
INFO - 2016-10-17 13:16:12 --> Helper loaded: url_helper
INFO - 2016-10-17 13:16:12 --> Helper loaded: form_helper
INFO - 2016-10-17 13:16:12 --> Database Driver Class Initialized
INFO - 2016-10-17 13:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:16:12 --> Controller Class Initialized
INFO - 2016-10-17 13:16:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:16:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:16:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:16:12 --> Final output sent to browser
DEBUG - 2016-10-17 13:16:12 --> Total execution time: 0.0059
INFO - 2016-10-17 13:16:38 --> Config Class Initialized
INFO - 2016-10-17 13:16:38 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:16:38 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:16:38 --> Utf8 Class Initialized
INFO - 2016-10-17 13:16:38 --> URI Class Initialized
DEBUG - 2016-10-17 13:16:38 --> No URI present. Default controller set.
INFO - 2016-10-17 13:16:38 --> Router Class Initialized
INFO - 2016-10-17 13:16:38 --> Output Class Initialized
INFO - 2016-10-17 13:16:38 --> Security Class Initialized
DEBUG - 2016-10-17 13:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:16:38 --> Input Class Initialized
INFO - 2016-10-17 13:16:38 --> Language Class Initialized
INFO - 2016-10-17 13:16:38 --> Loader Class Initialized
INFO - 2016-10-17 13:16:38 --> Helper loaded: url_helper
INFO - 2016-10-17 13:16:38 --> Helper loaded: form_helper
INFO - 2016-10-17 13:16:38 --> Database Driver Class Initialized
INFO - 2016-10-17 13:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:16:38 --> Controller Class Initialized
INFO - 2016-10-17 13:16:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:16:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:16:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:16:38 --> Final output sent to browser
DEBUG - 2016-10-17 13:16:38 --> Total execution time: 0.0051
INFO - 2016-10-17 13:21:00 --> Config Class Initialized
INFO - 2016-10-17 13:21:00 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:21:00 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:21:00 --> Utf8 Class Initialized
INFO - 2016-10-17 13:21:00 --> URI Class Initialized
DEBUG - 2016-10-17 13:21:00 --> No URI present. Default controller set.
INFO - 2016-10-17 13:21:00 --> Router Class Initialized
INFO - 2016-10-17 13:21:00 --> Output Class Initialized
INFO - 2016-10-17 13:21:00 --> Security Class Initialized
DEBUG - 2016-10-17 13:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:21:00 --> Input Class Initialized
INFO - 2016-10-17 13:21:00 --> Language Class Initialized
INFO - 2016-10-17 13:21:00 --> Loader Class Initialized
INFO - 2016-10-17 13:21:00 --> Helper loaded: url_helper
INFO - 2016-10-17 13:21:00 --> Helper loaded: form_helper
INFO - 2016-10-17 13:21:00 --> Database Driver Class Initialized
INFO - 2016-10-17 13:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:21:00 --> Controller Class Initialized
INFO - 2016-10-17 13:21:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:21:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:21:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:21:00 --> Final output sent to browser
DEBUG - 2016-10-17 13:21:00 --> Total execution time: 0.0059
INFO - 2016-10-17 13:21:53 --> Config Class Initialized
INFO - 2016-10-17 13:21:53 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:21:53 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:21:53 --> Utf8 Class Initialized
INFO - 2016-10-17 13:21:53 --> URI Class Initialized
DEBUG - 2016-10-17 13:21:53 --> No URI present. Default controller set.
INFO - 2016-10-17 13:21:53 --> Router Class Initialized
INFO - 2016-10-17 13:21:53 --> Output Class Initialized
INFO - 2016-10-17 13:21:53 --> Security Class Initialized
DEBUG - 2016-10-17 13:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:21:53 --> Input Class Initialized
INFO - 2016-10-17 13:21:53 --> Language Class Initialized
INFO - 2016-10-17 13:21:53 --> Loader Class Initialized
INFO - 2016-10-17 13:21:53 --> Helper loaded: url_helper
INFO - 2016-10-17 13:21:53 --> Helper loaded: form_helper
INFO - 2016-10-17 13:21:53 --> Database Driver Class Initialized
INFO - 2016-10-17 13:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:21:53 --> Controller Class Initialized
INFO - 2016-10-17 13:21:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:21:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:21:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:21:53 --> Final output sent to browser
DEBUG - 2016-10-17 13:21:53 --> Total execution time: 0.0060
INFO - 2016-10-17 13:22:40 --> Config Class Initialized
INFO - 2016-10-17 13:22:40 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:22:40 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:22:40 --> Utf8 Class Initialized
INFO - 2016-10-17 13:22:40 --> URI Class Initialized
DEBUG - 2016-10-17 13:22:40 --> No URI present. Default controller set.
INFO - 2016-10-17 13:22:40 --> Router Class Initialized
INFO - 2016-10-17 13:22:40 --> Output Class Initialized
INFO - 2016-10-17 13:22:40 --> Security Class Initialized
DEBUG - 2016-10-17 13:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:22:40 --> Input Class Initialized
INFO - 2016-10-17 13:22:40 --> Language Class Initialized
INFO - 2016-10-17 13:22:40 --> Loader Class Initialized
INFO - 2016-10-17 13:22:40 --> Helper loaded: url_helper
INFO - 2016-10-17 13:22:40 --> Helper loaded: form_helper
INFO - 2016-10-17 13:22:40 --> Database Driver Class Initialized
INFO - 2016-10-17 13:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:22:40 --> Controller Class Initialized
INFO - 2016-10-17 13:22:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:22:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:22:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:22:40 --> Final output sent to browser
DEBUG - 2016-10-17 13:22:40 --> Total execution time: 0.0055
INFO - 2016-10-17 13:25:19 --> Config Class Initialized
INFO - 2016-10-17 13:25:19 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:25:19 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:25:19 --> Utf8 Class Initialized
INFO - 2016-10-17 13:25:19 --> URI Class Initialized
DEBUG - 2016-10-17 13:25:19 --> No URI present. Default controller set.
INFO - 2016-10-17 13:25:19 --> Router Class Initialized
INFO - 2016-10-17 13:25:19 --> Output Class Initialized
INFO - 2016-10-17 13:25:19 --> Security Class Initialized
DEBUG - 2016-10-17 13:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:25:19 --> Input Class Initialized
INFO - 2016-10-17 13:25:19 --> Language Class Initialized
INFO - 2016-10-17 13:25:19 --> Loader Class Initialized
INFO - 2016-10-17 13:25:19 --> Helper loaded: url_helper
INFO - 2016-10-17 13:25:19 --> Helper loaded: form_helper
INFO - 2016-10-17 13:25:19 --> Database Driver Class Initialized
INFO - 2016-10-17 13:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:25:19 --> Controller Class Initialized
INFO - 2016-10-17 13:25:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:25:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:25:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:25:19 --> Final output sent to browser
DEBUG - 2016-10-17 13:25:19 --> Total execution time: 0.0058
INFO - 2016-10-17 13:25:19 --> Config Class Initialized
INFO - 2016-10-17 13:25:19 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:25:19 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:25:19 --> Utf8 Class Initialized
INFO - 2016-10-17 13:25:19 --> URI Class Initialized
DEBUG - 2016-10-17 13:25:19 --> No URI present. Default controller set.
INFO - 2016-10-17 13:25:19 --> Router Class Initialized
INFO - 2016-10-17 13:25:19 --> Output Class Initialized
INFO - 2016-10-17 13:25:19 --> Security Class Initialized
DEBUG - 2016-10-17 13:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:25:19 --> Input Class Initialized
INFO - 2016-10-17 13:25:19 --> Language Class Initialized
INFO - 2016-10-17 13:25:19 --> Loader Class Initialized
INFO - 2016-10-17 13:25:19 --> Helper loaded: url_helper
INFO - 2016-10-17 13:25:19 --> Helper loaded: form_helper
INFO - 2016-10-17 13:25:19 --> Database Driver Class Initialized
INFO - 2016-10-17 13:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:25:19 --> Controller Class Initialized
INFO - 2016-10-17 13:25:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:25:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:25:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:25:19 --> Final output sent to browser
DEBUG - 2016-10-17 13:25:19 --> Total execution time: 0.0047
INFO - 2016-10-17 13:25:19 --> Config Class Initialized
INFO - 2016-10-17 13:25:19 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:25:19 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:25:19 --> Utf8 Class Initialized
INFO - 2016-10-17 13:25:19 --> URI Class Initialized
DEBUG - 2016-10-17 13:25:19 --> No URI present. Default controller set.
INFO - 2016-10-17 13:25:19 --> Router Class Initialized
INFO - 2016-10-17 13:25:19 --> Output Class Initialized
INFO - 2016-10-17 13:25:19 --> Security Class Initialized
DEBUG - 2016-10-17 13:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:25:19 --> Input Class Initialized
INFO - 2016-10-17 13:25:19 --> Language Class Initialized
INFO - 2016-10-17 13:25:19 --> Loader Class Initialized
INFO - 2016-10-17 13:25:19 --> Helper loaded: url_helper
INFO - 2016-10-17 13:25:19 --> Helper loaded: form_helper
INFO - 2016-10-17 13:25:19 --> Database Driver Class Initialized
INFO - 2016-10-17 13:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:25:19 --> Controller Class Initialized
INFO - 2016-10-17 13:25:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:25:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:25:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:25:19 --> Final output sent to browser
DEBUG - 2016-10-17 13:25:19 --> Total execution time: 0.0041
INFO - 2016-10-17 13:25:19 --> Config Class Initialized
INFO - 2016-10-17 13:25:19 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:25:19 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:25:19 --> Utf8 Class Initialized
INFO - 2016-10-17 13:25:19 --> URI Class Initialized
DEBUG - 2016-10-17 13:25:19 --> No URI present. Default controller set.
INFO - 2016-10-17 13:25:19 --> Router Class Initialized
INFO - 2016-10-17 13:25:19 --> Output Class Initialized
INFO - 2016-10-17 13:25:19 --> Security Class Initialized
DEBUG - 2016-10-17 13:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:25:19 --> Input Class Initialized
INFO - 2016-10-17 13:25:19 --> Language Class Initialized
INFO - 2016-10-17 13:25:19 --> Loader Class Initialized
INFO - 2016-10-17 13:25:19 --> Helper loaded: url_helper
INFO - 2016-10-17 13:25:19 --> Helper loaded: form_helper
INFO - 2016-10-17 13:25:19 --> Database Driver Class Initialized
INFO - 2016-10-17 13:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:25:19 --> Controller Class Initialized
INFO - 2016-10-17 13:25:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:25:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:25:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:25:19 --> Final output sent to browser
DEBUG - 2016-10-17 13:25:19 --> Total execution time: 0.0047
INFO - 2016-10-17 13:25:43 --> Config Class Initialized
INFO - 2016-10-17 13:25:43 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:25:43 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:25:43 --> Utf8 Class Initialized
INFO - 2016-10-17 13:25:43 --> URI Class Initialized
DEBUG - 2016-10-17 13:25:43 --> No URI present. Default controller set.
INFO - 2016-10-17 13:25:43 --> Router Class Initialized
INFO - 2016-10-17 13:25:43 --> Output Class Initialized
INFO - 2016-10-17 13:25:43 --> Security Class Initialized
DEBUG - 2016-10-17 13:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:25:43 --> Input Class Initialized
INFO - 2016-10-17 13:25:43 --> Language Class Initialized
INFO - 2016-10-17 13:25:43 --> Loader Class Initialized
INFO - 2016-10-17 13:25:43 --> Helper loaded: url_helper
INFO - 2016-10-17 13:25:43 --> Helper loaded: form_helper
INFO - 2016-10-17 13:25:43 --> Database Driver Class Initialized
INFO - 2016-10-17 13:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:25:43 --> Controller Class Initialized
INFO - 2016-10-17 13:25:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:25:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:25:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:25:43 --> Final output sent to browser
DEBUG - 2016-10-17 13:25:43 --> Total execution time: 0.0054
INFO - 2016-10-17 13:25:44 --> Config Class Initialized
INFO - 2016-10-17 13:25:44 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:25:44 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:25:44 --> Utf8 Class Initialized
INFO - 2016-10-17 13:25:44 --> URI Class Initialized
DEBUG - 2016-10-17 13:25:44 --> No URI present. Default controller set.
INFO - 2016-10-17 13:25:44 --> Router Class Initialized
INFO - 2016-10-17 13:25:44 --> Output Class Initialized
INFO - 2016-10-17 13:25:44 --> Security Class Initialized
DEBUG - 2016-10-17 13:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:25:44 --> Input Class Initialized
INFO - 2016-10-17 13:25:44 --> Language Class Initialized
INFO - 2016-10-17 13:25:44 --> Loader Class Initialized
INFO - 2016-10-17 13:25:44 --> Helper loaded: url_helper
INFO - 2016-10-17 13:25:44 --> Helper loaded: form_helper
INFO - 2016-10-17 13:25:44 --> Database Driver Class Initialized
INFO - 2016-10-17 13:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:25:44 --> Controller Class Initialized
INFO - 2016-10-17 13:25:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:25:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:25:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:25:44 --> Final output sent to browser
DEBUG - 2016-10-17 13:25:44 --> Total execution time: 0.0043
INFO - 2016-10-17 13:25:44 --> Config Class Initialized
INFO - 2016-10-17 13:25:44 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:25:44 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:25:44 --> Utf8 Class Initialized
INFO - 2016-10-17 13:25:44 --> URI Class Initialized
DEBUG - 2016-10-17 13:25:44 --> No URI present. Default controller set.
INFO - 2016-10-17 13:25:44 --> Router Class Initialized
INFO - 2016-10-17 13:25:44 --> Output Class Initialized
INFO - 2016-10-17 13:25:44 --> Security Class Initialized
DEBUG - 2016-10-17 13:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:25:44 --> Input Class Initialized
INFO - 2016-10-17 13:25:44 --> Language Class Initialized
INFO - 2016-10-17 13:25:44 --> Loader Class Initialized
INFO - 2016-10-17 13:25:44 --> Helper loaded: url_helper
INFO - 2016-10-17 13:25:44 --> Helper loaded: form_helper
INFO - 2016-10-17 13:25:44 --> Database Driver Class Initialized
INFO - 2016-10-17 13:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:25:44 --> Controller Class Initialized
INFO - 2016-10-17 13:25:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:25:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:25:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:25:44 --> Final output sent to browser
DEBUG - 2016-10-17 13:25:44 --> Total execution time: 0.0039
INFO - 2016-10-17 13:25:44 --> Config Class Initialized
INFO - 2016-10-17 13:25:44 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:25:44 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:25:44 --> Utf8 Class Initialized
INFO - 2016-10-17 13:25:44 --> URI Class Initialized
DEBUG - 2016-10-17 13:25:44 --> No URI present. Default controller set.
INFO - 2016-10-17 13:25:44 --> Router Class Initialized
INFO - 2016-10-17 13:25:44 --> Output Class Initialized
INFO - 2016-10-17 13:25:44 --> Security Class Initialized
DEBUG - 2016-10-17 13:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:25:44 --> Input Class Initialized
INFO - 2016-10-17 13:25:44 --> Language Class Initialized
INFO - 2016-10-17 13:25:44 --> Loader Class Initialized
INFO - 2016-10-17 13:25:44 --> Helper loaded: url_helper
INFO - 2016-10-17 13:25:44 --> Helper loaded: form_helper
INFO - 2016-10-17 13:25:44 --> Database Driver Class Initialized
INFO - 2016-10-17 13:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:25:44 --> Controller Class Initialized
INFO - 2016-10-17 13:25:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:25:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:25:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:25:44 --> Final output sent to browser
DEBUG - 2016-10-17 13:25:44 --> Total execution time: 0.0043
INFO - 2016-10-17 13:25:44 --> Config Class Initialized
INFO - 2016-10-17 13:25:44 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:25:44 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:25:44 --> Utf8 Class Initialized
INFO - 2016-10-17 13:25:44 --> URI Class Initialized
DEBUG - 2016-10-17 13:25:44 --> No URI present. Default controller set.
INFO - 2016-10-17 13:25:44 --> Router Class Initialized
INFO - 2016-10-17 13:25:44 --> Output Class Initialized
INFO - 2016-10-17 13:25:44 --> Security Class Initialized
DEBUG - 2016-10-17 13:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:25:44 --> Input Class Initialized
INFO - 2016-10-17 13:25:44 --> Language Class Initialized
INFO - 2016-10-17 13:25:44 --> Loader Class Initialized
INFO - 2016-10-17 13:25:44 --> Helper loaded: url_helper
INFO - 2016-10-17 13:25:44 --> Helper loaded: form_helper
INFO - 2016-10-17 13:25:44 --> Database Driver Class Initialized
INFO - 2016-10-17 13:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:25:44 --> Controller Class Initialized
INFO - 2016-10-17 13:25:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:25:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:25:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:25:44 --> Final output sent to browser
DEBUG - 2016-10-17 13:25:44 --> Total execution time: 0.0056
INFO - 2016-10-17 13:25:44 --> Config Class Initialized
INFO - 2016-10-17 13:25:44 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:25:44 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:25:44 --> Utf8 Class Initialized
INFO - 2016-10-17 13:25:44 --> URI Class Initialized
DEBUG - 2016-10-17 13:25:44 --> No URI present. Default controller set.
INFO - 2016-10-17 13:25:44 --> Router Class Initialized
INFO - 2016-10-17 13:25:44 --> Output Class Initialized
INFO - 2016-10-17 13:25:44 --> Security Class Initialized
DEBUG - 2016-10-17 13:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:25:44 --> Input Class Initialized
INFO - 2016-10-17 13:25:44 --> Language Class Initialized
INFO - 2016-10-17 13:25:44 --> Loader Class Initialized
INFO - 2016-10-17 13:25:44 --> Helper loaded: url_helper
INFO - 2016-10-17 13:25:44 --> Helper loaded: form_helper
INFO - 2016-10-17 13:25:44 --> Database Driver Class Initialized
INFO - 2016-10-17 13:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:25:44 --> Controller Class Initialized
INFO - 2016-10-17 13:25:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:25:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:25:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:25:44 --> Final output sent to browser
DEBUG - 2016-10-17 13:25:44 --> Total execution time: 0.0043
INFO - 2016-10-17 13:25:44 --> Config Class Initialized
INFO - 2016-10-17 13:25:44 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:25:44 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:25:44 --> Utf8 Class Initialized
INFO - 2016-10-17 13:25:44 --> URI Class Initialized
DEBUG - 2016-10-17 13:25:44 --> No URI present. Default controller set.
INFO - 2016-10-17 13:25:44 --> Router Class Initialized
INFO - 2016-10-17 13:25:44 --> Output Class Initialized
INFO - 2016-10-17 13:25:44 --> Security Class Initialized
DEBUG - 2016-10-17 13:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:25:44 --> Input Class Initialized
INFO - 2016-10-17 13:25:44 --> Language Class Initialized
INFO - 2016-10-17 13:25:44 --> Loader Class Initialized
INFO - 2016-10-17 13:25:44 --> Helper loaded: url_helper
INFO - 2016-10-17 13:25:44 --> Helper loaded: form_helper
INFO - 2016-10-17 13:25:44 --> Database Driver Class Initialized
INFO - 2016-10-17 13:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:25:44 --> Controller Class Initialized
INFO - 2016-10-17 13:25:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:25:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:25:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:25:44 --> Final output sent to browser
DEBUG - 2016-10-17 13:25:44 --> Total execution time: 0.0041
INFO - 2016-10-17 13:25:45 --> Config Class Initialized
INFO - 2016-10-17 13:25:45 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:25:45 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:25:45 --> Utf8 Class Initialized
INFO - 2016-10-17 13:25:45 --> URI Class Initialized
DEBUG - 2016-10-17 13:25:45 --> No URI present. Default controller set.
INFO - 2016-10-17 13:25:45 --> Router Class Initialized
INFO - 2016-10-17 13:25:45 --> Output Class Initialized
INFO - 2016-10-17 13:25:45 --> Security Class Initialized
DEBUG - 2016-10-17 13:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:25:45 --> Input Class Initialized
INFO - 2016-10-17 13:25:45 --> Language Class Initialized
INFO - 2016-10-17 13:25:45 --> Loader Class Initialized
INFO - 2016-10-17 13:25:45 --> Helper loaded: url_helper
INFO - 2016-10-17 13:25:45 --> Helper loaded: form_helper
INFO - 2016-10-17 13:25:45 --> Database Driver Class Initialized
INFO - 2016-10-17 13:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:25:45 --> Controller Class Initialized
INFO - 2016-10-17 13:25:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:25:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:25:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:25:45 --> Final output sent to browser
DEBUG - 2016-10-17 13:25:45 --> Total execution time: 0.0043
INFO - 2016-10-17 13:28:35 --> Config Class Initialized
INFO - 2016-10-17 13:28:35 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:28:35 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:28:35 --> Utf8 Class Initialized
INFO - 2016-10-17 13:28:35 --> URI Class Initialized
DEBUG - 2016-10-17 13:28:35 --> No URI present. Default controller set.
INFO - 2016-10-17 13:28:35 --> Router Class Initialized
INFO - 2016-10-17 13:28:35 --> Output Class Initialized
INFO - 2016-10-17 13:28:35 --> Security Class Initialized
DEBUG - 2016-10-17 13:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:28:35 --> Input Class Initialized
INFO - 2016-10-17 13:28:35 --> Language Class Initialized
INFO - 2016-10-17 13:28:35 --> Loader Class Initialized
INFO - 2016-10-17 13:28:35 --> Helper loaded: url_helper
INFO - 2016-10-17 13:28:35 --> Helper loaded: form_helper
INFO - 2016-10-17 13:28:35 --> Database Driver Class Initialized
INFO - 2016-10-17 13:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:28:35 --> Controller Class Initialized
INFO - 2016-10-17 13:28:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:28:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:28:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:28:35 --> Final output sent to browser
DEBUG - 2016-10-17 13:28:35 --> Total execution time: 0.0052
INFO - 2016-10-17 13:28:36 --> Config Class Initialized
INFO - 2016-10-17 13:28:36 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:28:36 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:28:36 --> Utf8 Class Initialized
INFO - 2016-10-17 13:28:36 --> URI Class Initialized
INFO - 2016-10-17 13:28:36 --> Router Class Initialized
INFO - 2016-10-17 13:28:36 --> Output Class Initialized
INFO - 2016-10-17 13:28:36 --> Security Class Initialized
DEBUG - 2016-10-17 13:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:28:36 --> Input Class Initialized
INFO - 2016-10-17 13:28:36 --> Language Class Initialized
INFO - 2016-10-17 13:28:36 --> Loader Class Initialized
INFO - 2016-10-17 13:28:36 --> Helper loaded: url_helper
INFO - 2016-10-17 13:28:36 --> Helper loaded: form_helper
INFO - 2016-10-17 13:28:36 --> Database Driver Class Initialized
INFO - 2016-10-17 13:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:28:36 --> Controller Class Initialized
INFO - 2016-10-17 13:28:36 --> Form Validation Class Initialized
INFO - 2016-10-17 13:28:36 --> Config Class Initialized
INFO - 2016-10-17 13:28:36 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:28:36 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:28:36 --> Utf8 Class Initialized
INFO - 2016-10-17 13:28:36 --> URI Class Initialized
DEBUG - 2016-10-17 13:28:36 --> No URI present. Default controller set.
INFO - 2016-10-17 13:28:36 --> Router Class Initialized
INFO - 2016-10-17 13:28:36 --> Output Class Initialized
INFO - 2016-10-17 13:28:36 --> Security Class Initialized
DEBUG - 2016-10-17 13:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:28:36 --> Input Class Initialized
INFO - 2016-10-17 13:28:36 --> Language Class Initialized
INFO - 2016-10-17 13:28:36 --> Loader Class Initialized
INFO - 2016-10-17 13:28:36 --> Helper loaded: url_helper
INFO - 2016-10-17 13:28:36 --> Helper loaded: form_helper
INFO - 2016-10-17 13:28:36 --> Database Driver Class Initialized
INFO - 2016-10-17 13:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:28:36 --> Controller Class Initialized
INFO - 2016-10-17 13:28:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:28:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:28:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:28:36 --> Final output sent to browser
DEBUG - 2016-10-17 13:28:36 --> Total execution time: 0.0042
INFO - 2016-10-17 13:28:37 --> Config Class Initialized
INFO - 2016-10-17 13:28:37 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:28:37 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:28:37 --> Utf8 Class Initialized
INFO - 2016-10-17 13:28:37 --> URI Class Initialized
INFO - 2016-10-17 13:28:37 --> Router Class Initialized
INFO - 2016-10-17 13:28:37 --> Output Class Initialized
INFO - 2016-10-17 13:28:37 --> Security Class Initialized
DEBUG - 2016-10-17 13:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:28:37 --> Input Class Initialized
INFO - 2016-10-17 13:28:37 --> Language Class Initialized
INFO - 2016-10-17 13:28:37 --> Loader Class Initialized
INFO - 2016-10-17 13:28:37 --> Helper loaded: url_helper
INFO - 2016-10-17 13:28:37 --> Helper loaded: form_helper
INFO - 2016-10-17 13:28:37 --> Database Driver Class Initialized
INFO - 2016-10-17 13:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:28:37 --> Controller Class Initialized
INFO - 2016-10-17 13:28:37 --> Form Validation Class Initialized
INFO - 2016-10-17 13:28:37 --> Config Class Initialized
INFO - 2016-10-17 13:28:37 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:28:37 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:28:37 --> Utf8 Class Initialized
INFO - 2016-10-17 13:28:37 --> URI Class Initialized
DEBUG - 2016-10-17 13:28:37 --> No URI present. Default controller set.
INFO - 2016-10-17 13:28:37 --> Router Class Initialized
INFO - 2016-10-17 13:28:37 --> Output Class Initialized
INFO - 2016-10-17 13:28:37 --> Security Class Initialized
DEBUG - 2016-10-17 13:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:28:37 --> Input Class Initialized
INFO - 2016-10-17 13:28:37 --> Language Class Initialized
INFO - 2016-10-17 13:28:37 --> Loader Class Initialized
INFO - 2016-10-17 13:28:37 --> Helper loaded: url_helper
INFO - 2016-10-17 13:28:37 --> Helper loaded: form_helper
INFO - 2016-10-17 13:28:37 --> Database Driver Class Initialized
INFO - 2016-10-17 13:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:28:37 --> Controller Class Initialized
INFO - 2016-10-17 13:28:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:28:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:28:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:28:37 --> Final output sent to browser
DEBUG - 2016-10-17 13:28:37 --> Total execution time: 0.0039
INFO - 2016-10-17 13:28:38 --> Config Class Initialized
INFO - 2016-10-17 13:28:38 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:28:38 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:28:38 --> Utf8 Class Initialized
INFO - 2016-10-17 13:28:38 --> URI Class Initialized
INFO - 2016-10-17 13:28:38 --> Router Class Initialized
INFO - 2016-10-17 13:28:38 --> Output Class Initialized
INFO - 2016-10-17 13:28:38 --> Security Class Initialized
DEBUG - 2016-10-17 13:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:28:38 --> Input Class Initialized
INFO - 2016-10-17 13:28:38 --> Language Class Initialized
INFO - 2016-10-17 13:28:38 --> Loader Class Initialized
INFO - 2016-10-17 13:28:38 --> Helper loaded: url_helper
INFO - 2016-10-17 13:28:38 --> Helper loaded: form_helper
INFO - 2016-10-17 13:28:38 --> Database Driver Class Initialized
INFO - 2016-10-17 13:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:28:38 --> Controller Class Initialized
INFO - 2016-10-17 13:28:38 --> Form Validation Class Initialized
INFO - 2016-10-17 13:28:38 --> Config Class Initialized
INFO - 2016-10-17 13:28:38 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:28:38 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:28:38 --> Utf8 Class Initialized
INFO - 2016-10-17 13:28:38 --> URI Class Initialized
DEBUG - 2016-10-17 13:28:38 --> No URI present. Default controller set.
INFO - 2016-10-17 13:28:38 --> Router Class Initialized
INFO - 2016-10-17 13:28:38 --> Output Class Initialized
INFO - 2016-10-17 13:28:38 --> Security Class Initialized
DEBUG - 2016-10-17 13:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:28:38 --> Input Class Initialized
INFO - 2016-10-17 13:28:38 --> Language Class Initialized
INFO - 2016-10-17 13:28:38 --> Loader Class Initialized
INFO - 2016-10-17 13:28:38 --> Helper loaded: url_helper
INFO - 2016-10-17 13:28:38 --> Helper loaded: form_helper
INFO - 2016-10-17 13:28:38 --> Database Driver Class Initialized
INFO - 2016-10-17 13:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:28:38 --> Controller Class Initialized
INFO - 2016-10-17 13:28:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:28:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:28:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:28:38 --> Final output sent to browser
DEBUG - 2016-10-17 13:28:38 --> Total execution time: 0.0039
INFO - 2016-10-17 13:28:38 --> Config Class Initialized
INFO - 2016-10-17 13:28:38 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:28:38 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:28:38 --> Utf8 Class Initialized
INFO - 2016-10-17 13:28:38 --> URI Class Initialized
INFO - 2016-10-17 13:28:38 --> Router Class Initialized
INFO - 2016-10-17 13:28:38 --> Output Class Initialized
INFO - 2016-10-17 13:28:38 --> Security Class Initialized
DEBUG - 2016-10-17 13:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:28:38 --> Input Class Initialized
INFO - 2016-10-17 13:28:38 --> Language Class Initialized
INFO - 2016-10-17 13:28:38 --> Loader Class Initialized
INFO - 2016-10-17 13:28:38 --> Helper loaded: url_helper
INFO - 2016-10-17 13:28:38 --> Helper loaded: form_helper
INFO - 2016-10-17 13:28:38 --> Database Driver Class Initialized
INFO - 2016-10-17 13:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:28:38 --> Controller Class Initialized
INFO - 2016-10-17 13:28:38 --> Form Validation Class Initialized
INFO - 2016-10-17 13:28:38 --> Config Class Initialized
INFO - 2016-10-17 13:28:38 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:28:38 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:28:38 --> Utf8 Class Initialized
INFO - 2016-10-17 13:28:38 --> URI Class Initialized
DEBUG - 2016-10-17 13:28:38 --> No URI present. Default controller set.
INFO - 2016-10-17 13:28:38 --> Router Class Initialized
INFO - 2016-10-17 13:28:38 --> Output Class Initialized
INFO - 2016-10-17 13:28:38 --> Security Class Initialized
DEBUG - 2016-10-17 13:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:28:38 --> Input Class Initialized
INFO - 2016-10-17 13:28:38 --> Language Class Initialized
INFO - 2016-10-17 13:28:38 --> Loader Class Initialized
INFO - 2016-10-17 13:28:38 --> Helper loaded: url_helper
INFO - 2016-10-17 13:28:38 --> Helper loaded: form_helper
INFO - 2016-10-17 13:28:38 --> Database Driver Class Initialized
INFO - 2016-10-17 13:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:28:38 --> Controller Class Initialized
INFO - 2016-10-17 13:28:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:28:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:28:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:28:38 --> Final output sent to browser
DEBUG - 2016-10-17 13:28:38 --> Total execution time: 0.0038
INFO - 2016-10-17 13:34:30 --> Config Class Initialized
INFO - 2016-10-17 13:34:30 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:34:30 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:34:30 --> Utf8 Class Initialized
INFO - 2016-10-17 13:34:30 --> URI Class Initialized
DEBUG - 2016-10-17 13:34:30 --> No URI present. Default controller set.
INFO - 2016-10-17 13:34:30 --> Router Class Initialized
INFO - 2016-10-17 13:34:30 --> Output Class Initialized
INFO - 2016-10-17 13:34:30 --> Security Class Initialized
DEBUG - 2016-10-17 13:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:34:30 --> Input Class Initialized
INFO - 2016-10-17 13:34:30 --> Language Class Initialized
INFO - 2016-10-17 13:34:30 --> Loader Class Initialized
INFO - 2016-10-17 13:34:30 --> Helper loaded: url_helper
INFO - 2016-10-17 13:34:30 --> Helper loaded: form_helper
INFO - 2016-10-17 13:34:30 --> Database Driver Class Initialized
INFO - 2016-10-17 13:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:34:30 --> Controller Class Initialized
INFO - 2016-10-17 13:34:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:34:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:34:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:34:30 --> Final output sent to browser
DEBUG - 2016-10-17 13:34:30 --> Total execution time: 0.0057
INFO - 2016-10-17 13:34:38 --> Config Class Initialized
INFO - 2016-10-17 13:34:38 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:34:38 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:34:38 --> Utf8 Class Initialized
INFO - 2016-10-17 13:34:38 --> URI Class Initialized
DEBUG - 2016-10-17 13:34:39 --> No URI present. Default controller set.
INFO - 2016-10-17 13:34:39 --> Router Class Initialized
INFO - 2016-10-17 13:34:39 --> Output Class Initialized
INFO - 2016-10-17 13:34:39 --> Security Class Initialized
DEBUG - 2016-10-17 13:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:34:39 --> Input Class Initialized
INFO - 2016-10-17 13:34:39 --> Language Class Initialized
INFO - 2016-10-17 13:34:39 --> Loader Class Initialized
INFO - 2016-10-17 13:34:39 --> Helper loaded: url_helper
INFO - 2016-10-17 13:34:39 --> Helper loaded: form_helper
INFO - 2016-10-17 13:34:39 --> Database Driver Class Initialized
INFO - 2016-10-17 13:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:34:39 --> Controller Class Initialized
INFO - 2016-10-17 13:34:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:34:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:34:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:34:39 --> Final output sent to browser
DEBUG - 2016-10-17 13:34:39 --> Total execution time: 0.0054
INFO - 2016-10-17 13:35:10 --> Config Class Initialized
INFO - 2016-10-17 13:35:10 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:35:10 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:35:10 --> Utf8 Class Initialized
INFO - 2016-10-17 13:35:10 --> URI Class Initialized
DEBUG - 2016-10-17 13:35:10 --> No URI present. Default controller set.
INFO - 2016-10-17 13:35:10 --> Router Class Initialized
INFO - 2016-10-17 13:35:10 --> Output Class Initialized
INFO - 2016-10-17 13:35:10 --> Security Class Initialized
DEBUG - 2016-10-17 13:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:35:10 --> Input Class Initialized
INFO - 2016-10-17 13:35:10 --> Language Class Initialized
INFO - 2016-10-17 13:35:10 --> Loader Class Initialized
INFO - 2016-10-17 13:35:10 --> Helper loaded: url_helper
INFO - 2016-10-17 13:35:10 --> Helper loaded: form_helper
INFO - 2016-10-17 13:35:10 --> Database Driver Class Initialized
INFO - 2016-10-17 13:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:35:10 --> Controller Class Initialized
INFO - 2016-10-17 13:35:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:35:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:35:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:35:10 --> Final output sent to browser
DEBUG - 2016-10-17 13:35:10 --> Total execution time: 0.0084
INFO - 2016-10-17 13:35:14 --> Config Class Initialized
INFO - 2016-10-17 13:35:14 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:35:14 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:35:14 --> Utf8 Class Initialized
INFO - 2016-10-17 13:35:14 --> URI Class Initialized
INFO - 2016-10-17 13:35:14 --> Router Class Initialized
INFO - 2016-10-17 13:35:14 --> Output Class Initialized
INFO - 2016-10-17 13:35:14 --> Security Class Initialized
DEBUG - 2016-10-17 13:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:35:14 --> Input Class Initialized
INFO - 2016-10-17 13:35:14 --> Language Class Initialized
INFO - 2016-10-17 13:35:14 --> Loader Class Initialized
INFO - 2016-10-17 13:35:14 --> Helper loaded: url_helper
INFO - 2016-10-17 13:35:14 --> Helper loaded: form_helper
INFO - 2016-10-17 13:35:14 --> Database Driver Class Initialized
INFO - 2016-10-17 13:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:35:14 --> Controller Class Initialized
INFO - 2016-10-17 13:35:14 --> Form Validation Class Initialized
INFO - 2016-10-17 13:35:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-17 13:35:14 --> Model Class Initialized
INFO - 2016-10-17 13:35:14 --> Config Class Initialized
INFO - 2016-10-17 13:35:14 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:35:14 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:35:14 --> Utf8 Class Initialized
INFO - 2016-10-17 13:35:14 --> URI Class Initialized
DEBUG - 2016-10-17 13:35:14 --> No URI present. Default controller set.
INFO - 2016-10-17 13:35:14 --> Router Class Initialized
INFO - 2016-10-17 13:35:14 --> Output Class Initialized
INFO - 2016-10-17 13:35:14 --> Security Class Initialized
DEBUG - 2016-10-17 13:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:35:14 --> Input Class Initialized
INFO - 2016-10-17 13:35:14 --> Language Class Initialized
INFO - 2016-10-17 13:35:14 --> Loader Class Initialized
INFO - 2016-10-17 13:35:14 --> Helper loaded: url_helper
INFO - 2016-10-17 13:35:14 --> Helper loaded: form_helper
INFO - 2016-10-17 13:35:14 --> Database Driver Class Initialized
INFO - 2016-10-17 13:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:35:14 --> Controller Class Initialized
INFO - 2016-10-17 13:35:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:35:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:35:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:35:14 --> Final output sent to browser
DEBUG - 2016-10-17 13:35:14 --> Total execution time: 0.0042
INFO - 2016-10-17 13:35:15 --> Config Class Initialized
INFO - 2016-10-17 13:35:15 --> Hooks Class Initialized
DEBUG - 2016-10-17 13:35:15 --> UTF-8 Support Enabled
INFO - 2016-10-17 13:35:15 --> Utf8 Class Initialized
INFO - 2016-10-17 13:35:15 --> URI Class Initialized
DEBUG - 2016-10-17 13:35:15 --> No URI present. Default controller set.
INFO - 2016-10-17 13:35:15 --> Router Class Initialized
INFO - 2016-10-17 13:35:15 --> Output Class Initialized
INFO - 2016-10-17 13:35:15 --> Security Class Initialized
DEBUG - 2016-10-17 13:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 13:35:15 --> Input Class Initialized
INFO - 2016-10-17 13:35:15 --> Language Class Initialized
INFO - 2016-10-17 13:35:15 --> Loader Class Initialized
INFO - 2016-10-17 13:35:15 --> Helper loaded: url_helper
INFO - 2016-10-17 13:35:15 --> Helper loaded: form_helper
INFO - 2016-10-17 13:35:15 --> Database Driver Class Initialized
INFO - 2016-10-17 13:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 13:35:15 --> Controller Class Initialized
INFO - 2016-10-17 13:35:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 13:35:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 13:35:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 13:35:15 --> Final output sent to browser
DEBUG - 2016-10-17 13:35:15 --> Total execution time: 0.0048
INFO - 2016-10-17 14:36:29 --> Config Class Initialized
INFO - 2016-10-17 14:36:29 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:36:29 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:36:29 --> Utf8 Class Initialized
INFO - 2016-10-17 14:36:29 --> URI Class Initialized
DEBUG - 2016-10-17 14:36:29 --> No URI present. Default controller set.
INFO - 2016-10-17 14:36:29 --> Router Class Initialized
INFO - 2016-10-17 14:36:29 --> Output Class Initialized
INFO - 2016-10-17 14:36:29 --> Security Class Initialized
DEBUG - 2016-10-17 14:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:36:29 --> Input Class Initialized
INFO - 2016-10-17 14:36:29 --> Language Class Initialized
INFO - 2016-10-17 14:36:29 --> Loader Class Initialized
INFO - 2016-10-17 14:36:29 --> Helper loaded: url_helper
INFO - 2016-10-17 14:36:29 --> Helper loaded: form_helper
INFO - 2016-10-17 14:36:29 --> Database Driver Class Initialized
INFO - 2016-10-17 14:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:36:29 --> Controller Class Initialized
INFO - 2016-10-17 14:36:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:36:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:36:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:36:29 --> Final output sent to browser
DEBUG - 2016-10-17 14:36:29 --> Total execution time: 0.0170
INFO - 2016-10-17 14:36:41 --> Config Class Initialized
INFO - 2016-10-17 14:36:41 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:36:41 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:36:41 --> Utf8 Class Initialized
INFO - 2016-10-17 14:36:41 --> URI Class Initialized
INFO - 2016-10-17 14:36:41 --> Router Class Initialized
INFO - 2016-10-17 14:36:41 --> Output Class Initialized
INFO - 2016-10-17 14:36:41 --> Security Class Initialized
DEBUG - 2016-10-17 14:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:36:41 --> Input Class Initialized
INFO - 2016-10-17 14:36:41 --> Language Class Initialized
INFO - 2016-10-17 14:36:41 --> Loader Class Initialized
INFO - 2016-10-17 14:36:41 --> Helper loaded: url_helper
INFO - 2016-10-17 14:36:41 --> Helper loaded: form_helper
INFO - 2016-10-17 14:36:41 --> Database Driver Class Initialized
INFO - 2016-10-17 14:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:36:41 --> Controller Class Initialized
INFO - 2016-10-17 14:36:41 --> Form Validation Class Initialized
INFO - 2016-10-17 14:36:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-17 14:36:41 --> Model Class Initialized
INFO - 2016-10-17 14:36:41 --> Config Class Initialized
INFO - 2016-10-17 14:36:41 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:36:41 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:36:41 --> Utf8 Class Initialized
INFO - 2016-10-17 14:36:41 --> URI Class Initialized
DEBUG - 2016-10-17 14:36:41 --> No URI present. Default controller set.
INFO - 2016-10-17 14:36:41 --> Router Class Initialized
INFO - 2016-10-17 14:36:41 --> Output Class Initialized
INFO - 2016-10-17 14:36:41 --> Security Class Initialized
DEBUG - 2016-10-17 14:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:36:41 --> Input Class Initialized
INFO - 2016-10-17 14:36:41 --> Language Class Initialized
INFO - 2016-10-17 14:36:41 --> Loader Class Initialized
INFO - 2016-10-17 14:36:41 --> Helper loaded: url_helper
INFO - 2016-10-17 14:36:41 --> Helper loaded: form_helper
INFO - 2016-10-17 14:36:41 --> Database Driver Class Initialized
INFO - 2016-10-17 14:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:36:41 --> Controller Class Initialized
INFO - 2016-10-17 14:36:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:36:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:36:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:36:41 --> Final output sent to browser
DEBUG - 2016-10-17 14:36:41 --> Total execution time: 0.0040
INFO - 2016-10-17 14:37:44 --> Config Class Initialized
INFO - 2016-10-17 14:37:44 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:37:44 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:37:44 --> Utf8 Class Initialized
INFO - 2016-10-17 14:37:44 --> URI Class Initialized
DEBUG - 2016-10-17 14:37:44 --> No URI present. Default controller set.
INFO - 2016-10-17 14:37:44 --> Router Class Initialized
INFO - 2016-10-17 14:37:44 --> Output Class Initialized
INFO - 2016-10-17 14:37:44 --> Security Class Initialized
DEBUG - 2016-10-17 14:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:37:44 --> Input Class Initialized
INFO - 2016-10-17 14:37:44 --> Language Class Initialized
INFO - 2016-10-17 14:37:44 --> Loader Class Initialized
INFO - 2016-10-17 14:37:44 --> Helper loaded: url_helper
INFO - 2016-10-17 14:37:44 --> Helper loaded: form_helper
INFO - 2016-10-17 14:37:44 --> Database Driver Class Initialized
INFO - 2016-10-17 14:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:37:44 --> Controller Class Initialized
INFO - 2016-10-17 14:37:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:37:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:37:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:37:44 --> Final output sent to browser
DEBUG - 2016-10-17 14:37:44 --> Total execution time: 0.0064
INFO - 2016-10-17 14:38:05 --> Config Class Initialized
INFO - 2016-10-17 14:38:05 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:38:05 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:38:05 --> Utf8 Class Initialized
INFO - 2016-10-17 14:38:05 --> URI Class Initialized
DEBUG - 2016-10-17 14:38:05 --> No URI present. Default controller set.
INFO - 2016-10-17 14:38:05 --> Router Class Initialized
INFO - 2016-10-17 14:38:05 --> Output Class Initialized
INFO - 2016-10-17 14:38:05 --> Security Class Initialized
DEBUG - 2016-10-17 14:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:38:05 --> Input Class Initialized
INFO - 2016-10-17 14:38:05 --> Language Class Initialized
INFO - 2016-10-17 14:38:05 --> Loader Class Initialized
INFO - 2016-10-17 14:38:05 --> Helper loaded: url_helper
INFO - 2016-10-17 14:38:05 --> Helper loaded: form_helper
INFO - 2016-10-17 14:38:05 --> Database Driver Class Initialized
INFO - 2016-10-17 14:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:38:05 --> Controller Class Initialized
INFO - 2016-10-17 14:38:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:38:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:38:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:38:05 --> Final output sent to browser
DEBUG - 2016-10-17 14:38:05 --> Total execution time: 0.0048
INFO - 2016-10-17 14:39:06 --> Config Class Initialized
INFO - 2016-10-17 14:39:06 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:39:06 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:39:06 --> Utf8 Class Initialized
INFO - 2016-10-17 14:39:06 --> URI Class Initialized
DEBUG - 2016-10-17 14:39:06 --> No URI present. Default controller set.
INFO - 2016-10-17 14:39:06 --> Router Class Initialized
INFO - 2016-10-17 14:39:06 --> Output Class Initialized
INFO - 2016-10-17 14:39:06 --> Security Class Initialized
DEBUG - 2016-10-17 14:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:39:06 --> Input Class Initialized
INFO - 2016-10-17 14:39:06 --> Language Class Initialized
INFO - 2016-10-17 14:39:06 --> Loader Class Initialized
INFO - 2016-10-17 14:39:06 --> Helper loaded: url_helper
INFO - 2016-10-17 14:39:06 --> Helper loaded: form_helper
INFO - 2016-10-17 14:39:06 --> Database Driver Class Initialized
INFO - 2016-10-17 14:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:39:06 --> Controller Class Initialized
INFO - 2016-10-17 14:39:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:39:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:39:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:39:06 --> Final output sent to browser
DEBUG - 2016-10-17 14:39:06 --> Total execution time: 0.0068
INFO - 2016-10-17 14:39:10 --> Config Class Initialized
INFO - 2016-10-17 14:39:10 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:39:10 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:39:10 --> Utf8 Class Initialized
INFO - 2016-10-17 14:39:10 --> URI Class Initialized
INFO - 2016-10-17 14:39:10 --> Router Class Initialized
INFO - 2016-10-17 14:39:10 --> Output Class Initialized
INFO - 2016-10-17 14:39:10 --> Security Class Initialized
DEBUG - 2016-10-17 14:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:39:10 --> Input Class Initialized
INFO - 2016-10-17 14:39:10 --> Language Class Initialized
INFO - 2016-10-17 14:39:10 --> Loader Class Initialized
INFO - 2016-10-17 14:39:10 --> Helper loaded: url_helper
INFO - 2016-10-17 14:39:10 --> Helper loaded: form_helper
INFO - 2016-10-17 14:39:10 --> Database Driver Class Initialized
INFO - 2016-10-17 14:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:39:10 --> Controller Class Initialized
INFO - 2016-10-17 14:39:10 --> Form Validation Class Initialized
INFO - 2016-10-17 14:39:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-17 14:39:10 --> Model Class Initialized
INFO - 2016-10-17 14:39:10 --> Final output sent to browser
DEBUG - 2016-10-17 14:39:10 --> Total execution time: 0.0088
INFO - 2016-10-17 14:39:10 --> Config Class Initialized
INFO - 2016-10-17 14:39:10 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:39:10 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:39:10 --> Utf8 Class Initialized
INFO - 2016-10-17 14:39:10 --> URI Class Initialized
DEBUG - 2016-10-17 14:39:10 --> No URI present. Default controller set.
INFO - 2016-10-17 14:39:10 --> Router Class Initialized
INFO - 2016-10-17 14:39:10 --> Output Class Initialized
INFO - 2016-10-17 14:39:10 --> Security Class Initialized
DEBUG - 2016-10-17 14:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:39:10 --> Input Class Initialized
INFO - 2016-10-17 14:39:10 --> Language Class Initialized
INFO - 2016-10-17 14:39:10 --> Loader Class Initialized
INFO - 2016-10-17 14:39:10 --> Helper loaded: url_helper
INFO - 2016-10-17 14:39:10 --> Helper loaded: form_helper
INFO - 2016-10-17 14:39:10 --> Database Driver Class Initialized
INFO - 2016-10-17 14:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:39:10 --> Controller Class Initialized
INFO - 2016-10-17 14:39:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:39:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:39:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:39:10 --> Final output sent to browser
DEBUG - 2016-10-17 14:39:10 --> Total execution time: 0.0041
INFO - 2016-10-17 14:39:14 --> Config Class Initialized
INFO - 2016-10-17 14:39:14 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:39:14 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:39:14 --> Utf8 Class Initialized
INFO - 2016-10-17 14:39:14 --> URI Class Initialized
INFO - 2016-10-17 14:39:14 --> Router Class Initialized
INFO - 2016-10-17 14:39:14 --> Output Class Initialized
INFO - 2016-10-17 14:39:14 --> Security Class Initialized
DEBUG - 2016-10-17 14:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:39:14 --> Input Class Initialized
INFO - 2016-10-17 14:39:14 --> Language Class Initialized
INFO - 2016-10-17 14:39:14 --> Loader Class Initialized
INFO - 2016-10-17 14:39:14 --> Helper loaded: url_helper
INFO - 2016-10-17 14:39:14 --> Helper loaded: form_helper
INFO - 2016-10-17 14:39:14 --> Database Driver Class Initialized
INFO - 2016-10-17 14:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:39:14 --> Controller Class Initialized
INFO - 2016-10-17 14:39:14 --> Form Validation Class Initialized
INFO - 2016-10-17 14:39:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-17 14:39:14 --> Model Class Initialized
INFO - 2016-10-17 14:39:14 --> Final output sent to browser
DEBUG - 2016-10-17 14:39:14 --> Total execution time: 0.0053
INFO - 2016-10-17 14:39:14 --> Config Class Initialized
INFO - 2016-10-17 14:39:14 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:39:14 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:39:14 --> Utf8 Class Initialized
INFO - 2016-10-17 14:39:14 --> URI Class Initialized
DEBUG - 2016-10-17 14:39:14 --> No URI present. Default controller set.
INFO - 2016-10-17 14:39:14 --> Router Class Initialized
INFO - 2016-10-17 14:39:14 --> Output Class Initialized
INFO - 2016-10-17 14:39:14 --> Security Class Initialized
DEBUG - 2016-10-17 14:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:39:14 --> Input Class Initialized
INFO - 2016-10-17 14:39:14 --> Language Class Initialized
INFO - 2016-10-17 14:39:14 --> Loader Class Initialized
INFO - 2016-10-17 14:39:14 --> Helper loaded: url_helper
INFO - 2016-10-17 14:39:14 --> Helper loaded: form_helper
INFO - 2016-10-17 14:39:14 --> Database Driver Class Initialized
INFO - 2016-10-17 14:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:39:14 --> Controller Class Initialized
INFO - 2016-10-17 14:39:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:39:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:39:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:39:14 --> Final output sent to browser
DEBUG - 2016-10-17 14:39:14 --> Total execution time: 0.0038
INFO - 2016-10-17 14:39:21 --> Config Class Initialized
INFO - 2016-10-17 14:39:21 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:39:21 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:39:21 --> Utf8 Class Initialized
INFO - 2016-10-17 14:39:21 --> URI Class Initialized
INFO - 2016-10-17 14:39:21 --> Router Class Initialized
INFO - 2016-10-17 14:39:21 --> Output Class Initialized
INFO - 2016-10-17 14:39:21 --> Security Class Initialized
DEBUG - 2016-10-17 14:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:39:21 --> Input Class Initialized
INFO - 2016-10-17 14:39:21 --> Language Class Initialized
INFO - 2016-10-17 14:39:21 --> Loader Class Initialized
INFO - 2016-10-17 14:39:21 --> Helper loaded: url_helper
INFO - 2016-10-17 14:39:21 --> Helper loaded: form_helper
INFO - 2016-10-17 14:39:21 --> Database Driver Class Initialized
INFO - 2016-10-17 14:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:39:21 --> Controller Class Initialized
INFO - 2016-10-17 14:39:21 --> Form Validation Class Initialized
INFO - 2016-10-17 14:39:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-17 14:39:21 --> Model Class Initialized
INFO - 2016-10-17 14:39:21 --> Final output sent to browser
DEBUG - 2016-10-17 14:39:21 --> Total execution time: 0.0060
INFO - 2016-10-17 14:39:21 --> Config Class Initialized
INFO - 2016-10-17 14:39:21 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:39:21 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:39:21 --> Utf8 Class Initialized
INFO - 2016-10-17 14:39:21 --> URI Class Initialized
DEBUG - 2016-10-17 14:39:21 --> No URI present. Default controller set.
INFO - 2016-10-17 14:39:21 --> Router Class Initialized
INFO - 2016-10-17 14:39:21 --> Output Class Initialized
INFO - 2016-10-17 14:39:21 --> Security Class Initialized
DEBUG - 2016-10-17 14:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:39:21 --> Input Class Initialized
INFO - 2016-10-17 14:39:21 --> Language Class Initialized
INFO - 2016-10-17 14:39:21 --> Loader Class Initialized
INFO - 2016-10-17 14:39:21 --> Helper loaded: url_helper
INFO - 2016-10-17 14:39:21 --> Helper loaded: form_helper
INFO - 2016-10-17 14:39:21 --> Database Driver Class Initialized
INFO - 2016-10-17 14:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:39:21 --> Controller Class Initialized
INFO - 2016-10-17 14:39:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:39:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:39:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:39:21 --> Final output sent to browser
DEBUG - 2016-10-17 14:39:21 --> Total execution time: 0.0040
INFO - 2016-10-17 14:40:11 --> Config Class Initialized
INFO - 2016-10-17 14:40:11 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:40:11 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:40:11 --> Utf8 Class Initialized
INFO - 2016-10-17 14:40:11 --> URI Class Initialized
INFO - 2016-10-17 14:40:11 --> Router Class Initialized
INFO - 2016-10-17 14:40:11 --> Output Class Initialized
INFO - 2016-10-17 14:40:11 --> Security Class Initialized
DEBUG - 2016-10-17 14:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:40:11 --> Input Class Initialized
INFO - 2016-10-17 14:40:11 --> Language Class Initialized
INFO - 2016-10-17 14:40:11 --> Loader Class Initialized
INFO - 2016-10-17 14:40:11 --> Helper loaded: url_helper
INFO - 2016-10-17 14:40:11 --> Helper loaded: form_helper
INFO - 2016-10-17 14:40:11 --> Database Driver Class Initialized
INFO - 2016-10-17 14:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:40:11 --> Controller Class Initialized
INFO - 2016-10-17 14:40:11 --> Form Validation Class Initialized
INFO - 2016-10-17 14:40:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-17 14:40:11 --> Model Class Initialized
INFO - 2016-10-17 14:40:11 --> Final output sent to browser
DEBUG - 2016-10-17 14:40:11 --> Total execution time: 0.0063
INFO - 2016-10-17 14:40:11 --> Config Class Initialized
INFO - 2016-10-17 14:40:11 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:40:11 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:40:11 --> Utf8 Class Initialized
INFO - 2016-10-17 14:40:11 --> URI Class Initialized
DEBUG - 2016-10-17 14:40:11 --> No URI present. Default controller set.
INFO - 2016-10-17 14:40:11 --> Router Class Initialized
INFO - 2016-10-17 14:40:11 --> Output Class Initialized
INFO - 2016-10-17 14:40:11 --> Security Class Initialized
DEBUG - 2016-10-17 14:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:40:11 --> Input Class Initialized
INFO - 2016-10-17 14:40:11 --> Language Class Initialized
INFO - 2016-10-17 14:40:11 --> Loader Class Initialized
INFO - 2016-10-17 14:40:11 --> Helper loaded: url_helper
INFO - 2016-10-17 14:40:11 --> Helper loaded: form_helper
INFO - 2016-10-17 14:40:11 --> Database Driver Class Initialized
INFO - 2016-10-17 14:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:40:11 --> Controller Class Initialized
INFO - 2016-10-17 14:40:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:40:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:40:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:40:11 --> Final output sent to browser
DEBUG - 2016-10-17 14:40:11 --> Total execution time: 0.0039
INFO - 2016-10-17 14:41:59 --> Config Class Initialized
INFO - 2016-10-17 14:41:59 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:41:59 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:41:59 --> Utf8 Class Initialized
INFO - 2016-10-17 14:41:59 --> URI Class Initialized
INFO - 2016-10-17 14:41:59 --> Router Class Initialized
INFO - 2016-10-17 14:41:59 --> Output Class Initialized
INFO - 2016-10-17 14:41:59 --> Security Class Initialized
DEBUG - 2016-10-17 14:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:41:59 --> Input Class Initialized
INFO - 2016-10-17 14:41:59 --> Language Class Initialized
INFO - 2016-10-17 14:41:59 --> Loader Class Initialized
INFO - 2016-10-17 14:41:59 --> Helper loaded: url_helper
INFO - 2016-10-17 14:41:59 --> Helper loaded: form_helper
INFO - 2016-10-17 14:41:59 --> Database Driver Class Initialized
INFO - 2016-10-17 14:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:41:59 --> Controller Class Initialized
INFO - 2016-10-17 14:41:59 --> Form Validation Class Initialized
INFO - 2016-10-17 14:41:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-17 14:41:59 --> Model Class Initialized
INFO - 2016-10-17 14:41:59 --> Final output sent to browser
DEBUG - 2016-10-17 14:41:59 --> Total execution time: 0.0059
INFO - 2016-10-17 14:41:59 --> Config Class Initialized
INFO - 2016-10-17 14:41:59 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:41:59 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:41:59 --> Utf8 Class Initialized
INFO - 2016-10-17 14:41:59 --> URI Class Initialized
DEBUG - 2016-10-17 14:41:59 --> No URI present. Default controller set.
INFO - 2016-10-17 14:41:59 --> Router Class Initialized
INFO - 2016-10-17 14:41:59 --> Output Class Initialized
INFO - 2016-10-17 14:41:59 --> Security Class Initialized
DEBUG - 2016-10-17 14:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:41:59 --> Input Class Initialized
INFO - 2016-10-17 14:41:59 --> Language Class Initialized
INFO - 2016-10-17 14:41:59 --> Loader Class Initialized
INFO - 2016-10-17 14:41:59 --> Helper loaded: url_helper
INFO - 2016-10-17 14:41:59 --> Helper loaded: form_helper
INFO - 2016-10-17 14:41:59 --> Database Driver Class Initialized
INFO - 2016-10-17 14:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:41:59 --> Controller Class Initialized
INFO - 2016-10-17 14:41:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:41:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 14:41:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 14:41:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:41:59 --> Final output sent to browser
DEBUG - 2016-10-17 14:41:59 --> Total execution time: 0.0040
INFO - 2016-10-17 14:42:05 --> Config Class Initialized
INFO - 2016-10-17 14:42:05 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:42:05 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:42:05 --> Utf8 Class Initialized
INFO - 2016-10-17 14:42:05 --> URI Class Initialized
DEBUG - 2016-10-17 14:42:05 --> No URI present. Default controller set.
INFO - 2016-10-17 14:42:05 --> Router Class Initialized
INFO - 2016-10-17 14:42:05 --> Output Class Initialized
INFO - 2016-10-17 14:42:05 --> Security Class Initialized
DEBUG - 2016-10-17 14:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:42:05 --> Input Class Initialized
INFO - 2016-10-17 14:42:05 --> Language Class Initialized
INFO - 2016-10-17 14:42:05 --> Loader Class Initialized
INFO - 2016-10-17 14:42:05 --> Helper loaded: url_helper
INFO - 2016-10-17 14:42:05 --> Helper loaded: form_helper
INFO - 2016-10-17 14:42:05 --> Database Driver Class Initialized
INFO - 2016-10-17 14:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:42:05 --> Controller Class Initialized
INFO - 2016-10-17 14:42:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:42:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 14:42:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 14:42:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:42:05 --> Final output sent to browser
DEBUG - 2016-10-17 14:42:05 --> Total execution time: 0.0048
INFO - 2016-10-17 14:42:25 --> Config Class Initialized
INFO - 2016-10-17 14:42:25 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:42:25 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:42:25 --> Utf8 Class Initialized
INFO - 2016-10-17 14:42:25 --> URI Class Initialized
DEBUG - 2016-10-17 14:42:25 --> No URI present. Default controller set.
INFO - 2016-10-17 14:42:25 --> Router Class Initialized
INFO - 2016-10-17 14:42:25 --> Output Class Initialized
INFO - 2016-10-17 14:42:25 --> Security Class Initialized
DEBUG - 2016-10-17 14:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:42:25 --> Input Class Initialized
INFO - 2016-10-17 14:42:25 --> Language Class Initialized
INFO - 2016-10-17 14:42:25 --> Loader Class Initialized
INFO - 2016-10-17 14:42:25 --> Helper loaded: url_helper
INFO - 2016-10-17 14:42:25 --> Helper loaded: form_helper
INFO - 2016-10-17 14:42:25 --> Database Driver Class Initialized
INFO - 2016-10-17 14:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:42:25 --> Controller Class Initialized
INFO - 2016-10-17 14:42:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:42:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 14:42:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 14:42:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:42:25 --> Final output sent to browser
DEBUG - 2016-10-17 14:42:25 --> Total execution time: 0.0090
INFO - 2016-10-17 14:42:26 --> Config Class Initialized
INFO - 2016-10-17 14:42:26 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:42:26 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:42:26 --> Utf8 Class Initialized
INFO - 2016-10-17 14:42:26 --> URI Class Initialized
DEBUG - 2016-10-17 14:42:26 --> No URI present. Default controller set.
INFO - 2016-10-17 14:42:26 --> Router Class Initialized
INFO - 2016-10-17 14:42:26 --> Output Class Initialized
INFO - 2016-10-17 14:42:26 --> Security Class Initialized
DEBUG - 2016-10-17 14:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:42:26 --> Input Class Initialized
INFO - 2016-10-17 14:42:26 --> Language Class Initialized
INFO - 2016-10-17 14:42:26 --> Loader Class Initialized
INFO - 2016-10-17 14:42:26 --> Helper loaded: url_helper
INFO - 2016-10-17 14:42:26 --> Helper loaded: form_helper
INFO - 2016-10-17 14:42:26 --> Database Driver Class Initialized
INFO - 2016-10-17 14:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:42:26 --> Controller Class Initialized
INFO - 2016-10-17 14:42:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:42:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 14:42:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 14:42:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:42:26 --> Final output sent to browser
DEBUG - 2016-10-17 14:42:26 --> Total execution time: 0.0046
INFO - 2016-10-17 14:42:27 --> Config Class Initialized
INFO - 2016-10-17 14:42:27 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:42:27 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:42:27 --> Utf8 Class Initialized
INFO - 2016-10-17 14:42:27 --> URI Class Initialized
DEBUG - 2016-10-17 14:42:27 --> No URI present. Default controller set.
INFO - 2016-10-17 14:42:27 --> Router Class Initialized
INFO - 2016-10-17 14:42:27 --> Output Class Initialized
INFO - 2016-10-17 14:42:27 --> Security Class Initialized
DEBUG - 2016-10-17 14:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:42:27 --> Input Class Initialized
INFO - 2016-10-17 14:42:27 --> Language Class Initialized
INFO - 2016-10-17 14:42:27 --> Loader Class Initialized
INFO - 2016-10-17 14:42:27 --> Helper loaded: url_helper
INFO - 2016-10-17 14:42:27 --> Helper loaded: form_helper
INFO - 2016-10-17 14:42:27 --> Database Driver Class Initialized
INFO - 2016-10-17 14:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:42:27 --> Controller Class Initialized
INFO - 2016-10-17 14:42:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:42:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 14:42:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 14:42:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:42:27 --> Final output sent to browser
DEBUG - 2016-10-17 14:42:27 --> Total execution time: 0.0044
INFO - 2016-10-17 14:42:32 --> Config Class Initialized
INFO - 2016-10-17 14:42:32 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:42:32 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:42:32 --> Utf8 Class Initialized
INFO - 2016-10-17 14:42:32 --> URI Class Initialized
DEBUG - 2016-10-17 14:42:32 --> No URI present. Default controller set.
INFO - 2016-10-17 14:42:32 --> Router Class Initialized
INFO - 2016-10-17 14:42:32 --> Output Class Initialized
INFO - 2016-10-17 14:42:32 --> Security Class Initialized
DEBUG - 2016-10-17 14:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:42:32 --> Input Class Initialized
INFO - 2016-10-17 14:42:32 --> Language Class Initialized
INFO - 2016-10-17 14:42:32 --> Loader Class Initialized
INFO - 2016-10-17 14:42:32 --> Helper loaded: url_helper
INFO - 2016-10-17 14:42:32 --> Helper loaded: form_helper
INFO - 2016-10-17 14:42:32 --> Database Driver Class Initialized
INFO - 2016-10-17 14:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:42:32 --> Controller Class Initialized
INFO - 2016-10-17 14:42:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:42:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 14:42:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 14:42:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:42:32 --> Final output sent to browser
DEBUG - 2016-10-17 14:42:32 --> Total execution time: 0.0045
INFO - 2016-10-17 14:42:35 --> Config Class Initialized
INFO - 2016-10-17 14:42:35 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:42:35 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:42:35 --> Utf8 Class Initialized
INFO - 2016-10-17 14:42:35 --> URI Class Initialized
DEBUG - 2016-10-17 14:42:35 --> No URI present. Default controller set.
INFO - 2016-10-17 14:42:35 --> Router Class Initialized
INFO - 2016-10-17 14:42:35 --> Output Class Initialized
INFO - 2016-10-17 14:42:35 --> Security Class Initialized
DEBUG - 2016-10-17 14:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:42:35 --> Input Class Initialized
INFO - 2016-10-17 14:42:35 --> Language Class Initialized
INFO - 2016-10-17 14:42:35 --> Loader Class Initialized
INFO - 2016-10-17 14:42:35 --> Helper loaded: url_helper
INFO - 2016-10-17 14:42:35 --> Helper loaded: form_helper
INFO - 2016-10-17 14:42:35 --> Database Driver Class Initialized
INFO - 2016-10-17 14:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:42:35 --> Controller Class Initialized
INFO - 2016-10-17 14:42:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:42:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 14:42:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 14:42:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:42:35 --> Final output sent to browser
DEBUG - 2016-10-17 14:42:35 --> Total execution time: 0.0048
INFO - 2016-10-17 14:42:37 --> Config Class Initialized
INFO - 2016-10-17 14:42:37 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:42:37 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:42:37 --> Utf8 Class Initialized
INFO - 2016-10-17 14:42:37 --> URI Class Initialized
DEBUG - 2016-10-17 14:42:37 --> No URI present. Default controller set.
INFO - 2016-10-17 14:42:37 --> Router Class Initialized
INFO - 2016-10-17 14:42:37 --> Output Class Initialized
INFO - 2016-10-17 14:42:37 --> Security Class Initialized
DEBUG - 2016-10-17 14:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:42:37 --> Input Class Initialized
INFO - 2016-10-17 14:42:37 --> Language Class Initialized
INFO - 2016-10-17 14:42:37 --> Loader Class Initialized
INFO - 2016-10-17 14:42:37 --> Helper loaded: url_helper
INFO - 2016-10-17 14:42:37 --> Helper loaded: form_helper
INFO - 2016-10-17 14:42:37 --> Database Driver Class Initialized
INFO - 2016-10-17 14:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:42:37 --> Controller Class Initialized
INFO - 2016-10-17 14:42:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:42:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 14:42:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 14:42:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:42:37 --> Final output sent to browser
DEBUG - 2016-10-17 14:42:37 --> Total execution time: 0.0047
INFO - 2016-10-17 14:42:38 --> Config Class Initialized
INFO - 2016-10-17 14:42:38 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:42:38 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:42:38 --> Utf8 Class Initialized
INFO - 2016-10-17 14:42:38 --> URI Class Initialized
DEBUG - 2016-10-17 14:42:38 --> No URI present. Default controller set.
INFO - 2016-10-17 14:42:38 --> Router Class Initialized
INFO - 2016-10-17 14:42:38 --> Output Class Initialized
INFO - 2016-10-17 14:42:38 --> Security Class Initialized
DEBUG - 2016-10-17 14:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:42:38 --> Input Class Initialized
INFO - 2016-10-17 14:42:38 --> Language Class Initialized
INFO - 2016-10-17 14:42:38 --> Loader Class Initialized
INFO - 2016-10-17 14:42:38 --> Helper loaded: url_helper
INFO - 2016-10-17 14:42:38 --> Helper loaded: form_helper
INFO - 2016-10-17 14:42:38 --> Database Driver Class Initialized
INFO - 2016-10-17 14:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:42:38 --> Controller Class Initialized
INFO - 2016-10-17 14:42:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:42:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 14:42:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 14:42:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:42:38 --> Final output sent to browser
DEBUG - 2016-10-17 14:42:38 --> Total execution time: 0.0044
INFO - 2016-10-17 14:42:38 --> Config Class Initialized
INFO - 2016-10-17 14:42:38 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:42:38 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:42:38 --> Utf8 Class Initialized
INFO - 2016-10-17 14:42:38 --> URI Class Initialized
INFO - 2016-10-17 14:42:38 --> Router Class Initialized
INFO - 2016-10-17 14:42:38 --> Output Class Initialized
INFO - 2016-10-17 14:42:38 --> Security Class Initialized
DEBUG - 2016-10-17 14:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:42:38 --> Input Class Initialized
INFO - 2016-10-17 14:42:38 --> Language Class Initialized
ERROR - 2016-10-17 14:42:38 --> 404 Page Not Found: Auth/dashboard
INFO - 2016-10-17 14:42:38 --> Config Class Initialized
INFO - 2016-10-17 14:42:38 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:42:38 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:42:38 --> Utf8 Class Initialized
INFO - 2016-10-17 14:42:38 --> URI Class Initialized
INFO - 2016-10-17 14:42:38 --> Router Class Initialized
INFO - 2016-10-17 14:42:38 --> Output Class Initialized
INFO - 2016-10-17 14:42:38 --> Security Class Initialized
DEBUG - 2016-10-17 14:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:42:38 --> Input Class Initialized
INFO - 2016-10-17 14:42:38 --> Language Class Initialized
ERROR - 2016-10-17 14:42:38 --> 404 Page Not Found: Index/dashboard
INFO - 2016-10-17 14:42:38 --> Config Class Initialized
INFO - 2016-10-17 14:42:38 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:42:38 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:42:38 --> Utf8 Class Initialized
INFO - 2016-10-17 14:42:38 --> URI Class Initialized
DEBUG - 2016-10-17 14:42:38 --> No URI present. Default controller set.
INFO - 2016-10-17 14:42:38 --> Router Class Initialized
INFO - 2016-10-17 14:42:38 --> Output Class Initialized
INFO - 2016-10-17 14:42:38 --> Security Class Initialized
DEBUG - 2016-10-17 14:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:42:38 --> Input Class Initialized
INFO - 2016-10-17 14:42:38 --> Language Class Initialized
INFO - 2016-10-17 14:42:38 --> Loader Class Initialized
INFO - 2016-10-17 14:42:38 --> Helper loaded: url_helper
INFO - 2016-10-17 14:42:38 --> Helper loaded: form_helper
INFO - 2016-10-17 14:42:38 --> Database Driver Class Initialized
INFO - 2016-10-17 14:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:42:38 --> Controller Class Initialized
INFO - 2016-10-17 14:42:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:42:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 14:42:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 14:42:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:42:38 --> Final output sent to browser
DEBUG - 2016-10-17 14:42:38 --> Total execution time: 0.0043
INFO - 2016-10-17 14:42:39 --> Config Class Initialized
INFO - 2016-10-17 14:42:39 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:42:39 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:42:39 --> Utf8 Class Initialized
INFO - 2016-10-17 14:42:39 --> URI Class Initialized
DEBUG - 2016-10-17 14:42:39 --> No URI present. Default controller set.
INFO - 2016-10-17 14:42:39 --> Router Class Initialized
INFO - 2016-10-17 14:42:39 --> Output Class Initialized
INFO - 2016-10-17 14:42:39 --> Security Class Initialized
DEBUG - 2016-10-17 14:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:42:39 --> Input Class Initialized
INFO - 2016-10-17 14:42:39 --> Language Class Initialized
INFO - 2016-10-17 14:42:39 --> Loader Class Initialized
INFO - 2016-10-17 14:42:39 --> Helper loaded: url_helper
INFO - 2016-10-17 14:42:39 --> Helper loaded: form_helper
INFO - 2016-10-17 14:42:39 --> Database Driver Class Initialized
INFO - 2016-10-17 14:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:42:39 --> Controller Class Initialized
INFO - 2016-10-17 14:42:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:42:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 14:42:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 14:42:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:42:39 --> Final output sent to browser
DEBUG - 2016-10-17 14:42:39 --> Total execution time: 0.0042
INFO - 2016-10-17 14:42:59 --> Config Class Initialized
INFO - 2016-10-17 14:42:59 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:42:59 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:42:59 --> Utf8 Class Initialized
INFO - 2016-10-17 14:42:59 --> URI Class Initialized
DEBUG - 2016-10-17 14:42:59 --> No URI present. Default controller set.
INFO - 2016-10-17 14:42:59 --> Router Class Initialized
INFO - 2016-10-17 14:42:59 --> Output Class Initialized
INFO - 2016-10-17 14:42:59 --> Security Class Initialized
DEBUG - 2016-10-17 14:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:42:59 --> Input Class Initialized
INFO - 2016-10-17 14:42:59 --> Language Class Initialized
INFO - 2016-10-17 14:42:59 --> Loader Class Initialized
INFO - 2016-10-17 14:42:59 --> Helper loaded: url_helper
INFO - 2016-10-17 14:42:59 --> Helper loaded: form_helper
INFO - 2016-10-17 14:42:59 --> Database Driver Class Initialized
INFO - 2016-10-17 14:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:42:59 --> Controller Class Initialized
INFO - 2016-10-17 14:42:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:42:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 14:42:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 14:42:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:42:59 --> Final output sent to browser
DEBUG - 2016-10-17 14:42:59 --> Total execution time: 0.0056
INFO - 2016-10-17 14:42:59 --> Config Class Initialized
INFO - 2016-10-17 14:42:59 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:42:59 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:42:59 --> Utf8 Class Initialized
INFO - 2016-10-17 14:42:59 --> URI Class Initialized
DEBUG - 2016-10-17 14:42:59 --> No URI present. Default controller set.
INFO - 2016-10-17 14:42:59 --> Router Class Initialized
INFO - 2016-10-17 14:42:59 --> Output Class Initialized
INFO - 2016-10-17 14:42:59 --> Security Class Initialized
DEBUG - 2016-10-17 14:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:42:59 --> Input Class Initialized
INFO - 2016-10-17 14:42:59 --> Language Class Initialized
INFO - 2016-10-17 14:42:59 --> Loader Class Initialized
INFO - 2016-10-17 14:42:59 --> Helper loaded: url_helper
INFO - 2016-10-17 14:42:59 --> Helper loaded: form_helper
INFO - 2016-10-17 14:42:59 --> Database Driver Class Initialized
INFO - 2016-10-17 14:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:42:59 --> Controller Class Initialized
INFO - 2016-10-17 14:42:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:42:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 14:42:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 14:42:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:42:59 --> Final output sent to browser
DEBUG - 2016-10-17 14:42:59 --> Total execution time: 0.0072
INFO - 2016-10-17 14:42:59 --> Config Class Initialized
INFO - 2016-10-17 14:42:59 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:42:59 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:42:59 --> Utf8 Class Initialized
INFO - 2016-10-17 14:42:59 --> URI Class Initialized
INFO - 2016-10-17 14:42:59 --> Router Class Initialized
INFO - 2016-10-17 14:42:59 --> Output Class Initialized
INFO - 2016-10-17 14:42:59 --> Security Class Initialized
DEBUG - 2016-10-17 14:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:42:59 --> Input Class Initialized
INFO - 2016-10-17 14:42:59 --> Language Class Initialized
ERROR - 2016-10-17 14:42:59 --> 404 Page Not Found: Index/dashboard
INFO - 2016-10-17 14:42:59 --> Config Class Initialized
INFO - 2016-10-17 14:42:59 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:42:59 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:42:59 --> Utf8 Class Initialized
INFO - 2016-10-17 14:42:59 --> URI Class Initialized
INFO - 2016-10-17 14:42:59 --> Router Class Initialized
INFO - 2016-10-17 14:42:59 --> Output Class Initialized
INFO - 2016-10-17 14:42:59 --> Security Class Initialized
DEBUG - 2016-10-17 14:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:42:59 --> Input Class Initialized
INFO - 2016-10-17 14:42:59 --> Language Class Initialized
ERROR - 2016-10-17 14:42:59 --> 404 Page Not Found: Auth/dashboard
INFO - 2016-10-17 14:43:00 --> Config Class Initialized
INFO - 2016-10-17 14:43:00 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:43:00 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:43:00 --> Utf8 Class Initialized
INFO - 2016-10-17 14:43:00 --> URI Class Initialized
DEBUG - 2016-10-17 14:43:00 --> No URI present. Default controller set.
INFO - 2016-10-17 14:43:00 --> Router Class Initialized
INFO - 2016-10-17 14:43:00 --> Output Class Initialized
INFO - 2016-10-17 14:43:00 --> Security Class Initialized
DEBUG - 2016-10-17 14:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:43:00 --> Input Class Initialized
INFO - 2016-10-17 14:43:00 --> Language Class Initialized
INFO - 2016-10-17 14:43:00 --> Loader Class Initialized
INFO - 2016-10-17 14:43:00 --> Helper loaded: url_helper
INFO - 2016-10-17 14:43:00 --> Helper loaded: form_helper
INFO - 2016-10-17 14:43:00 --> Database Driver Class Initialized
INFO - 2016-10-17 14:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:43:00 --> Controller Class Initialized
INFO - 2016-10-17 14:43:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:43:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 14:43:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 14:43:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:43:00 --> Final output sent to browser
DEBUG - 2016-10-17 14:43:00 --> Total execution time: 0.0044
INFO - 2016-10-17 14:43:09 --> Config Class Initialized
INFO - 2016-10-17 14:43:09 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:43:09 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:43:09 --> Utf8 Class Initialized
INFO - 2016-10-17 14:43:09 --> URI Class Initialized
INFO - 2016-10-17 14:43:09 --> Router Class Initialized
INFO - 2016-10-17 14:43:09 --> Output Class Initialized
INFO - 2016-10-17 14:43:09 --> Security Class Initialized
DEBUG - 2016-10-17 14:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:43:09 --> Input Class Initialized
INFO - 2016-10-17 14:43:09 --> Language Class Initialized
INFO - 2016-10-17 14:43:09 --> Loader Class Initialized
INFO - 2016-10-17 14:43:09 --> Helper loaded: url_helper
INFO - 2016-10-17 14:43:09 --> Helper loaded: form_helper
INFO - 2016-10-17 14:43:09 --> Database Driver Class Initialized
INFO - 2016-10-17 14:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:43:09 --> Controller Class Initialized
ERROR - 2016-10-17 14:43:09 --> Severity: Notice --> Undefined variable: name /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 93
ERROR - 2016-10-17 14:43:09 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 93
INFO - 2016-10-17 14:43:09 --> Config Class Initialized
INFO - 2016-10-17 14:43:09 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:43:09 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:43:09 --> Utf8 Class Initialized
INFO - 2016-10-17 14:43:09 --> URI Class Initialized
DEBUG - 2016-10-17 14:43:09 --> No URI present. Default controller set.
INFO - 2016-10-17 14:43:09 --> Router Class Initialized
INFO - 2016-10-17 14:43:09 --> Output Class Initialized
INFO - 2016-10-17 14:43:09 --> Security Class Initialized
DEBUG - 2016-10-17 14:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:43:09 --> Input Class Initialized
INFO - 2016-10-17 14:43:09 --> Language Class Initialized
INFO - 2016-10-17 14:43:09 --> Loader Class Initialized
INFO - 2016-10-17 14:43:09 --> Helper loaded: url_helper
INFO - 2016-10-17 14:43:09 --> Helper loaded: form_helper
INFO - 2016-10-17 14:43:09 --> Database Driver Class Initialized
INFO - 2016-10-17 14:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:43:09 --> Controller Class Initialized
INFO - 2016-10-17 14:43:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:43:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:43:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:43:09 --> Final output sent to browser
DEBUG - 2016-10-17 14:43:09 --> Total execution time: 0.0042
INFO - 2016-10-17 14:46:27 --> Config Class Initialized
INFO - 2016-10-17 14:46:27 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:46:27 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:46:27 --> Utf8 Class Initialized
INFO - 2016-10-17 14:46:27 --> URI Class Initialized
DEBUG - 2016-10-17 14:46:27 --> No URI present. Default controller set.
INFO - 2016-10-17 14:46:27 --> Router Class Initialized
INFO - 2016-10-17 14:46:27 --> Output Class Initialized
INFO - 2016-10-17 14:46:27 --> Security Class Initialized
DEBUG - 2016-10-17 14:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:46:27 --> Input Class Initialized
INFO - 2016-10-17 14:46:27 --> Language Class Initialized
INFO - 2016-10-17 14:46:27 --> Loader Class Initialized
INFO - 2016-10-17 14:46:27 --> Helper loaded: url_helper
INFO - 2016-10-17 14:46:27 --> Helper loaded: form_helper
INFO - 2016-10-17 14:46:27 --> Database Driver Class Initialized
INFO - 2016-10-17 14:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:46:27 --> Controller Class Initialized
INFO - 2016-10-17 14:46:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:46:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:46:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:46:27 --> Final output sent to browser
DEBUG - 2016-10-17 14:46:27 --> Total execution time: 0.0057
INFO - 2016-10-17 14:46:37 --> Config Class Initialized
INFO - 2016-10-17 14:46:37 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:46:37 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:46:37 --> Utf8 Class Initialized
INFO - 2016-10-17 14:46:37 --> URI Class Initialized
INFO - 2016-10-17 14:46:37 --> Router Class Initialized
INFO - 2016-10-17 14:46:37 --> Output Class Initialized
INFO - 2016-10-17 14:46:37 --> Security Class Initialized
DEBUG - 2016-10-17 14:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:46:37 --> Input Class Initialized
INFO - 2016-10-17 14:46:37 --> Language Class Initialized
INFO - 2016-10-17 14:46:37 --> Loader Class Initialized
INFO - 2016-10-17 14:46:37 --> Helper loaded: url_helper
INFO - 2016-10-17 14:46:37 --> Helper loaded: form_helper
INFO - 2016-10-17 14:46:37 --> Database Driver Class Initialized
INFO - 2016-10-17 14:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:46:37 --> Controller Class Initialized
INFO - 2016-10-17 14:46:37 --> Form Validation Class Initialized
INFO - 2016-10-17 14:46:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-17 14:46:37 --> Model Class Initialized
INFO - 2016-10-17 14:46:37 --> Final output sent to browser
DEBUG - 2016-10-17 14:46:37 --> Total execution time: 0.0058
INFO - 2016-10-17 14:46:37 --> Config Class Initialized
INFO - 2016-10-17 14:46:37 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:46:37 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:46:37 --> Utf8 Class Initialized
INFO - 2016-10-17 14:46:37 --> URI Class Initialized
DEBUG - 2016-10-17 14:46:37 --> No URI present. Default controller set.
INFO - 2016-10-17 14:46:37 --> Router Class Initialized
INFO - 2016-10-17 14:46:37 --> Output Class Initialized
INFO - 2016-10-17 14:46:37 --> Security Class Initialized
DEBUG - 2016-10-17 14:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:46:37 --> Input Class Initialized
INFO - 2016-10-17 14:46:37 --> Language Class Initialized
INFO - 2016-10-17 14:46:37 --> Loader Class Initialized
INFO - 2016-10-17 14:46:37 --> Helper loaded: url_helper
INFO - 2016-10-17 14:46:37 --> Helper loaded: form_helper
INFO - 2016-10-17 14:46:37 --> Database Driver Class Initialized
INFO - 2016-10-17 14:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:46:37 --> Controller Class Initialized
INFO - 2016-10-17 14:46:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:46:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 14:46:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 14:46:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:46:37 --> Final output sent to browser
DEBUG - 2016-10-17 14:46:37 --> Total execution time: 0.0042
INFO - 2016-10-17 14:47:12 --> Config Class Initialized
INFO - 2016-10-17 14:47:12 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:47:12 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:47:12 --> Utf8 Class Initialized
INFO - 2016-10-17 14:47:12 --> URI Class Initialized
INFO - 2016-10-17 14:47:12 --> Router Class Initialized
INFO - 2016-10-17 14:47:12 --> Output Class Initialized
INFO - 2016-10-17 14:47:12 --> Security Class Initialized
DEBUG - 2016-10-17 14:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:47:12 --> Input Class Initialized
INFO - 2016-10-17 14:47:12 --> Language Class Initialized
INFO - 2016-10-17 14:47:12 --> Loader Class Initialized
INFO - 2016-10-17 14:47:12 --> Helper loaded: url_helper
INFO - 2016-10-17 14:47:12 --> Helper loaded: form_helper
INFO - 2016-10-17 14:47:12 --> Database Driver Class Initialized
INFO - 2016-10-17 14:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:47:12 --> Controller Class Initialized
ERROR - 2016-10-17 14:47:12 --> Severity: Notice --> Undefined variable: name /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 93
ERROR - 2016-10-17 14:47:12 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 93
INFO - 2016-10-17 14:47:12 --> Config Class Initialized
INFO - 2016-10-17 14:47:12 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:47:12 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:47:12 --> Utf8 Class Initialized
INFO - 2016-10-17 14:47:12 --> URI Class Initialized
DEBUG - 2016-10-17 14:47:12 --> No URI present. Default controller set.
INFO - 2016-10-17 14:47:12 --> Router Class Initialized
INFO - 2016-10-17 14:47:12 --> Output Class Initialized
INFO - 2016-10-17 14:47:12 --> Security Class Initialized
DEBUG - 2016-10-17 14:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:47:12 --> Input Class Initialized
INFO - 2016-10-17 14:47:12 --> Language Class Initialized
INFO - 2016-10-17 14:47:12 --> Loader Class Initialized
INFO - 2016-10-17 14:47:12 --> Helper loaded: url_helper
INFO - 2016-10-17 14:47:12 --> Helper loaded: form_helper
INFO - 2016-10-17 14:47:12 --> Database Driver Class Initialized
INFO - 2016-10-17 14:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:47:12 --> Controller Class Initialized
INFO - 2016-10-17 14:47:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:47:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:47:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:47:12 --> Final output sent to browser
DEBUG - 2016-10-17 14:47:12 --> Total execution time: 0.0042
INFO - 2016-10-17 14:48:11 --> Config Class Initialized
INFO - 2016-10-17 14:48:11 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:48:11 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:48:11 --> Utf8 Class Initialized
INFO - 2016-10-17 14:48:11 --> URI Class Initialized
DEBUG - 2016-10-17 14:48:11 --> No URI present. Default controller set.
INFO - 2016-10-17 14:48:11 --> Router Class Initialized
INFO - 2016-10-17 14:48:11 --> Output Class Initialized
INFO - 2016-10-17 14:48:11 --> Security Class Initialized
DEBUG - 2016-10-17 14:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:48:11 --> Input Class Initialized
INFO - 2016-10-17 14:48:11 --> Language Class Initialized
INFO - 2016-10-17 14:48:11 --> Loader Class Initialized
INFO - 2016-10-17 14:48:11 --> Helper loaded: url_helper
INFO - 2016-10-17 14:48:11 --> Helper loaded: form_helper
INFO - 2016-10-17 14:48:11 --> Database Driver Class Initialized
INFO - 2016-10-17 14:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:48:11 --> Controller Class Initialized
INFO - 2016-10-17 14:48:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:48:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:48:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:48:11 --> Final output sent to browser
DEBUG - 2016-10-17 14:48:11 --> Total execution time: 0.0050
INFO - 2016-10-17 14:48:17 --> Config Class Initialized
INFO - 2016-10-17 14:48:17 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:48:17 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:48:17 --> Utf8 Class Initialized
INFO - 2016-10-17 14:48:17 --> URI Class Initialized
INFO - 2016-10-17 14:48:17 --> Router Class Initialized
INFO - 2016-10-17 14:48:17 --> Output Class Initialized
INFO - 2016-10-17 14:48:17 --> Security Class Initialized
DEBUG - 2016-10-17 14:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:48:17 --> Input Class Initialized
INFO - 2016-10-17 14:48:17 --> Language Class Initialized
INFO - 2016-10-17 14:48:17 --> Loader Class Initialized
INFO - 2016-10-17 14:48:17 --> Helper loaded: url_helper
INFO - 2016-10-17 14:48:17 --> Helper loaded: form_helper
INFO - 2016-10-17 14:48:17 --> Database Driver Class Initialized
INFO - 2016-10-17 14:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:48:17 --> Controller Class Initialized
INFO - 2016-10-17 14:48:17 --> Form Validation Class Initialized
INFO - 2016-10-17 14:48:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-17 14:48:17 --> Model Class Initialized
INFO - 2016-10-17 14:48:17 --> Final output sent to browser
DEBUG - 2016-10-17 14:48:17 --> Total execution time: 0.0055
INFO - 2016-10-17 14:48:17 --> Config Class Initialized
INFO - 2016-10-17 14:48:17 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:48:17 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:48:17 --> Utf8 Class Initialized
INFO - 2016-10-17 14:48:17 --> URI Class Initialized
DEBUG - 2016-10-17 14:48:17 --> No URI present. Default controller set.
INFO - 2016-10-17 14:48:17 --> Router Class Initialized
INFO - 2016-10-17 14:48:17 --> Output Class Initialized
INFO - 2016-10-17 14:48:17 --> Security Class Initialized
DEBUG - 2016-10-17 14:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:48:17 --> Input Class Initialized
INFO - 2016-10-17 14:48:17 --> Language Class Initialized
INFO - 2016-10-17 14:48:17 --> Loader Class Initialized
INFO - 2016-10-17 14:48:17 --> Helper loaded: url_helper
INFO - 2016-10-17 14:48:17 --> Helper loaded: form_helper
INFO - 2016-10-17 14:48:17 --> Database Driver Class Initialized
INFO - 2016-10-17 14:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:48:17 --> Controller Class Initialized
INFO - 2016-10-17 14:48:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:48:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 14:48:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 14:48:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:48:17 --> Final output sent to browser
DEBUG - 2016-10-17 14:48:17 --> Total execution time: 0.0042
INFO - 2016-10-17 14:48:18 --> Config Class Initialized
INFO - 2016-10-17 14:48:18 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:48:18 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:48:18 --> Utf8 Class Initialized
INFO - 2016-10-17 14:48:18 --> URI Class Initialized
INFO - 2016-10-17 14:48:18 --> Router Class Initialized
INFO - 2016-10-17 14:48:18 --> Output Class Initialized
INFO - 2016-10-17 14:48:18 --> Security Class Initialized
DEBUG - 2016-10-17 14:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:48:18 --> Input Class Initialized
INFO - 2016-10-17 14:48:18 --> Language Class Initialized
INFO - 2016-10-17 14:48:18 --> Loader Class Initialized
INFO - 2016-10-17 14:48:18 --> Helper loaded: url_helper
INFO - 2016-10-17 14:48:18 --> Helper loaded: form_helper
INFO - 2016-10-17 14:48:18 --> Database Driver Class Initialized
INFO - 2016-10-17 14:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:48:18 --> Controller Class Initialized
ERROR - 2016-10-17 14:48:18 --> Severity: Notice --> Undefined variable: name /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 93
ERROR - 2016-10-17 14:48:18 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 93
INFO - 2016-10-17 14:48:18 --> Config Class Initialized
INFO - 2016-10-17 14:48:18 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:48:18 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:48:18 --> Utf8 Class Initialized
INFO - 2016-10-17 14:48:18 --> URI Class Initialized
DEBUG - 2016-10-17 14:48:18 --> No URI present. Default controller set.
INFO - 2016-10-17 14:48:18 --> Router Class Initialized
INFO - 2016-10-17 14:48:18 --> Output Class Initialized
INFO - 2016-10-17 14:48:18 --> Security Class Initialized
DEBUG - 2016-10-17 14:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:48:18 --> Input Class Initialized
INFO - 2016-10-17 14:48:18 --> Language Class Initialized
INFO - 2016-10-17 14:48:18 --> Loader Class Initialized
INFO - 2016-10-17 14:48:18 --> Helper loaded: url_helper
INFO - 2016-10-17 14:48:18 --> Helper loaded: form_helper
INFO - 2016-10-17 14:48:18 --> Database Driver Class Initialized
INFO - 2016-10-17 14:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:48:18 --> Controller Class Initialized
INFO - 2016-10-17 14:48:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:48:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:48:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:48:18 --> Final output sent to browser
DEBUG - 2016-10-17 14:48:18 --> Total execution time: 0.0039
INFO - 2016-10-17 14:48:22 --> Config Class Initialized
INFO - 2016-10-17 14:48:22 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:48:22 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:48:22 --> Utf8 Class Initialized
INFO - 2016-10-17 14:48:22 --> URI Class Initialized
DEBUG - 2016-10-17 14:48:22 --> No URI present. Default controller set.
INFO - 2016-10-17 14:48:22 --> Router Class Initialized
INFO - 2016-10-17 14:48:22 --> Output Class Initialized
INFO - 2016-10-17 14:48:22 --> Security Class Initialized
DEBUG - 2016-10-17 14:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:48:22 --> Input Class Initialized
INFO - 2016-10-17 14:48:22 --> Language Class Initialized
INFO - 2016-10-17 14:48:22 --> Loader Class Initialized
INFO - 2016-10-17 14:48:22 --> Helper loaded: url_helper
INFO - 2016-10-17 14:48:22 --> Helper loaded: form_helper
INFO - 2016-10-17 14:48:22 --> Database Driver Class Initialized
INFO - 2016-10-17 14:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:48:22 --> Controller Class Initialized
INFO - 2016-10-17 14:48:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:48:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:48:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:48:22 --> Final output sent to browser
DEBUG - 2016-10-17 14:48:22 --> Total execution time: 0.0079
INFO - 2016-10-17 14:48:28 --> Config Class Initialized
INFO - 2016-10-17 14:48:28 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:48:28 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:48:28 --> Utf8 Class Initialized
INFO - 2016-10-17 14:48:28 --> URI Class Initialized
INFO - 2016-10-17 14:48:28 --> Router Class Initialized
INFO - 2016-10-17 14:48:28 --> Output Class Initialized
INFO - 2016-10-17 14:48:28 --> Security Class Initialized
DEBUG - 2016-10-17 14:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:48:28 --> Input Class Initialized
INFO - 2016-10-17 14:48:28 --> Language Class Initialized
INFO - 2016-10-17 14:48:28 --> Loader Class Initialized
INFO - 2016-10-17 14:48:28 --> Helper loaded: url_helper
INFO - 2016-10-17 14:48:28 --> Helper loaded: form_helper
INFO - 2016-10-17 14:48:28 --> Database Driver Class Initialized
INFO - 2016-10-17 14:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:48:28 --> Controller Class Initialized
INFO - 2016-10-17 14:48:28 --> Form Validation Class Initialized
INFO - 2016-10-17 14:48:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-17 14:48:28 --> Model Class Initialized
INFO - 2016-10-17 14:48:28 --> Final output sent to browser
DEBUG - 2016-10-17 14:48:28 --> Total execution time: 0.0065
INFO - 2016-10-17 14:48:28 --> Config Class Initialized
INFO - 2016-10-17 14:48:28 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:48:28 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:48:28 --> Utf8 Class Initialized
INFO - 2016-10-17 14:48:28 --> URI Class Initialized
DEBUG - 2016-10-17 14:48:28 --> No URI present. Default controller set.
INFO - 2016-10-17 14:48:28 --> Router Class Initialized
INFO - 2016-10-17 14:48:28 --> Output Class Initialized
INFO - 2016-10-17 14:48:28 --> Security Class Initialized
DEBUG - 2016-10-17 14:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:48:28 --> Input Class Initialized
INFO - 2016-10-17 14:48:28 --> Language Class Initialized
INFO - 2016-10-17 14:48:28 --> Loader Class Initialized
INFO - 2016-10-17 14:48:28 --> Helper loaded: url_helper
INFO - 2016-10-17 14:48:28 --> Helper loaded: form_helper
INFO - 2016-10-17 14:48:28 --> Database Driver Class Initialized
INFO - 2016-10-17 14:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:48:28 --> Controller Class Initialized
INFO - 2016-10-17 14:48:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:48:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 14:48:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 14:48:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:48:28 --> Final output sent to browser
DEBUG - 2016-10-17 14:48:28 --> Total execution time: 0.0042
INFO - 2016-10-17 14:48:30 --> Config Class Initialized
INFO - 2016-10-17 14:48:30 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:48:30 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:48:30 --> Utf8 Class Initialized
INFO - 2016-10-17 14:48:30 --> URI Class Initialized
INFO - 2016-10-17 14:48:30 --> Router Class Initialized
INFO - 2016-10-17 14:48:30 --> Output Class Initialized
INFO - 2016-10-17 14:48:30 --> Security Class Initialized
DEBUG - 2016-10-17 14:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:48:30 --> Input Class Initialized
INFO - 2016-10-17 14:48:30 --> Language Class Initialized
INFO - 2016-10-17 14:48:30 --> Loader Class Initialized
INFO - 2016-10-17 14:48:30 --> Helper loaded: url_helper
INFO - 2016-10-17 14:48:30 --> Helper loaded: form_helper
INFO - 2016-10-17 14:48:30 --> Database Driver Class Initialized
INFO - 2016-10-17 14:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:48:30 --> Controller Class Initialized
ERROR - 2016-10-17 14:48:30 --> Severity: Notice --> Undefined variable: name /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 93
ERROR - 2016-10-17 14:48:30 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 93
INFO - 2016-10-17 14:48:30 --> Config Class Initialized
INFO - 2016-10-17 14:48:30 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:48:30 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:48:30 --> Utf8 Class Initialized
INFO - 2016-10-17 14:48:30 --> URI Class Initialized
DEBUG - 2016-10-17 14:48:30 --> No URI present. Default controller set.
INFO - 2016-10-17 14:48:30 --> Router Class Initialized
INFO - 2016-10-17 14:48:30 --> Output Class Initialized
INFO - 2016-10-17 14:48:30 --> Security Class Initialized
DEBUG - 2016-10-17 14:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:48:30 --> Input Class Initialized
INFO - 2016-10-17 14:48:30 --> Language Class Initialized
INFO - 2016-10-17 14:48:30 --> Loader Class Initialized
INFO - 2016-10-17 14:48:30 --> Helper loaded: url_helper
INFO - 2016-10-17 14:48:30 --> Helper loaded: form_helper
INFO - 2016-10-17 14:48:30 --> Database Driver Class Initialized
INFO - 2016-10-17 14:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:48:30 --> Controller Class Initialized
INFO - 2016-10-17 14:48:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:48:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:48:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:48:30 --> Final output sent to browser
DEBUG - 2016-10-17 14:48:30 --> Total execution time: 0.0040
INFO - 2016-10-17 14:49:13 --> Config Class Initialized
INFO - 2016-10-17 14:49:13 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:49:13 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:49:13 --> Utf8 Class Initialized
INFO - 2016-10-17 14:49:13 --> URI Class Initialized
DEBUG - 2016-10-17 14:49:13 --> No URI present. Default controller set.
INFO - 2016-10-17 14:49:13 --> Router Class Initialized
INFO - 2016-10-17 14:49:13 --> Output Class Initialized
INFO - 2016-10-17 14:49:13 --> Security Class Initialized
DEBUG - 2016-10-17 14:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:49:13 --> Input Class Initialized
INFO - 2016-10-17 14:49:13 --> Language Class Initialized
INFO - 2016-10-17 14:49:13 --> Loader Class Initialized
INFO - 2016-10-17 14:49:13 --> Helper loaded: url_helper
INFO - 2016-10-17 14:49:13 --> Helper loaded: form_helper
INFO - 2016-10-17 14:49:13 --> Database Driver Class Initialized
INFO - 2016-10-17 14:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:49:13 --> Controller Class Initialized
INFO - 2016-10-17 14:49:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:49:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:49:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:49:13 --> Final output sent to browser
DEBUG - 2016-10-17 14:49:13 --> Total execution time: 0.0049
INFO - 2016-10-17 14:49:48 --> Config Class Initialized
INFO - 2016-10-17 14:49:48 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:49:48 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:49:48 --> Utf8 Class Initialized
INFO - 2016-10-17 14:49:48 --> URI Class Initialized
INFO - 2016-10-17 14:49:48 --> Router Class Initialized
INFO - 2016-10-17 14:49:48 --> Output Class Initialized
INFO - 2016-10-17 14:49:48 --> Security Class Initialized
DEBUG - 2016-10-17 14:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:49:48 --> Input Class Initialized
INFO - 2016-10-17 14:49:48 --> Language Class Initialized
INFO - 2016-10-17 14:49:48 --> Loader Class Initialized
INFO - 2016-10-17 14:49:48 --> Helper loaded: url_helper
INFO - 2016-10-17 14:49:48 --> Helper loaded: form_helper
INFO - 2016-10-17 14:49:48 --> Database Driver Class Initialized
INFO - 2016-10-17 14:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:49:48 --> Controller Class Initialized
INFO - 2016-10-17 14:49:48 --> Form Validation Class Initialized
INFO - 2016-10-17 14:49:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-17 14:49:48 --> Model Class Initialized
INFO - 2016-10-17 14:49:48 --> Final output sent to browser
DEBUG - 2016-10-17 14:49:48 --> Total execution time: 0.0054
INFO - 2016-10-17 14:49:48 --> Config Class Initialized
INFO - 2016-10-17 14:49:48 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:49:48 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:49:48 --> Utf8 Class Initialized
INFO - 2016-10-17 14:49:48 --> URI Class Initialized
DEBUG - 2016-10-17 14:49:48 --> No URI present. Default controller set.
INFO - 2016-10-17 14:49:48 --> Router Class Initialized
INFO - 2016-10-17 14:49:48 --> Output Class Initialized
INFO - 2016-10-17 14:49:48 --> Security Class Initialized
DEBUG - 2016-10-17 14:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:49:48 --> Input Class Initialized
INFO - 2016-10-17 14:49:48 --> Language Class Initialized
INFO - 2016-10-17 14:49:48 --> Loader Class Initialized
INFO - 2016-10-17 14:49:48 --> Helper loaded: url_helper
INFO - 2016-10-17 14:49:48 --> Helper loaded: form_helper
INFO - 2016-10-17 14:49:48 --> Database Driver Class Initialized
INFO - 2016-10-17 14:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:49:48 --> Controller Class Initialized
INFO - 2016-10-17 14:49:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:49:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 14:49:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 14:49:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:49:48 --> Final output sent to browser
DEBUG - 2016-10-17 14:49:48 --> Total execution time: 0.0039
INFO - 2016-10-17 14:49:52 --> Config Class Initialized
INFO - 2016-10-17 14:49:52 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:49:52 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:49:52 --> Utf8 Class Initialized
INFO - 2016-10-17 14:49:52 --> URI Class Initialized
INFO - 2016-10-17 14:49:52 --> Router Class Initialized
INFO - 2016-10-17 14:49:52 --> Output Class Initialized
INFO - 2016-10-17 14:49:52 --> Security Class Initialized
DEBUG - 2016-10-17 14:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:49:52 --> Input Class Initialized
INFO - 2016-10-17 14:49:52 --> Language Class Initialized
INFO - 2016-10-17 14:49:52 --> Loader Class Initialized
INFO - 2016-10-17 14:49:52 --> Helper loaded: url_helper
INFO - 2016-10-17 14:49:52 --> Helper loaded: form_helper
INFO - 2016-10-17 14:49:52 --> Database Driver Class Initialized
INFO - 2016-10-17 14:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:49:52 --> Controller Class Initialized
ERROR - 2016-10-17 14:49:52 --> Severity: Notice --> Undefined variable: name /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 93
ERROR - 2016-10-17 14:49:52 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 93
INFO - 2016-10-17 14:49:52 --> Config Class Initialized
INFO - 2016-10-17 14:49:52 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:49:52 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:49:52 --> Utf8 Class Initialized
INFO - 2016-10-17 14:49:52 --> URI Class Initialized
DEBUG - 2016-10-17 14:49:52 --> No URI present. Default controller set.
INFO - 2016-10-17 14:49:52 --> Router Class Initialized
INFO - 2016-10-17 14:49:52 --> Output Class Initialized
INFO - 2016-10-17 14:49:52 --> Security Class Initialized
DEBUG - 2016-10-17 14:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:49:52 --> Input Class Initialized
INFO - 2016-10-17 14:49:52 --> Language Class Initialized
INFO - 2016-10-17 14:49:52 --> Loader Class Initialized
INFO - 2016-10-17 14:49:52 --> Helper loaded: url_helper
INFO - 2016-10-17 14:49:52 --> Helper loaded: form_helper
INFO - 2016-10-17 14:49:52 --> Database Driver Class Initialized
INFO - 2016-10-17 14:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:49:52 --> Controller Class Initialized
INFO - 2016-10-17 14:49:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:49:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:49:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:49:52 --> Final output sent to browser
DEBUG - 2016-10-17 14:49:52 --> Total execution time: 0.0039
INFO - 2016-10-17 14:49:57 --> Config Class Initialized
INFO - 2016-10-17 14:49:57 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:49:57 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:49:57 --> Utf8 Class Initialized
INFO - 2016-10-17 14:49:57 --> URI Class Initialized
INFO - 2016-10-17 14:49:57 --> Router Class Initialized
INFO - 2016-10-17 14:49:57 --> Output Class Initialized
INFO - 2016-10-17 14:49:57 --> Security Class Initialized
DEBUG - 2016-10-17 14:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:49:57 --> Input Class Initialized
INFO - 2016-10-17 14:49:57 --> Language Class Initialized
INFO - 2016-10-17 14:49:57 --> Loader Class Initialized
INFO - 2016-10-17 14:49:57 --> Helper loaded: url_helper
INFO - 2016-10-17 14:49:57 --> Helper loaded: form_helper
INFO - 2016-10-17 14:49:57 --> Database Driver Class Initialized
INFO - 2016-10-17 14:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:49:57 --> Controller Class Initialized
INFO - 2016-10-17 14:49:57 --> Form Validation Class Initialized
INFO - 2016-10-17 14:49:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-17 14:49:57 --> Model Class Initialized
INFO - 2016-10-17 14:49:57 --> Final output sent to browser
DEBUG - 2016-10-17 14:49:57 --> Total execution time: 0.0080
INFO - 2016-10-17 14:49:57 --> Config Class Initialized
INFO - 2016-10-17 14:49:57 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:49:57 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:49:57 --> Utf8 Class Initialized
INFO - 2016-10-17 14:49:57 --> URI Class Initialized
DEBUG - 2016-10-17 14:49:57 --> No URI present. Default controller set.
INFO - 2016-10-17 14:49:57 --> Router Class Initialized
INFO - 2016-10-17 14:49:57 --> Output Class Initialized
INFO - 2016-10-17 14:49:57 --> Security Class Initialized
DEBUG - 2016-10-17 14:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:49:57 --> Input Class Initialized
INFO - 2016-10-17 14:49:57 --> Language Class Initialized
INFO - 2016-10-17 14:49:57 --> Loader Class Initialized
INFO - 2016-10-17 14:49:57 --> Helper loaded: url_helper
INFO - 2016-10-17 14:49:57 --> Helper loaded: form_helper
INFO - 2016-10-17 14:49:57 --> Database Driver Class Initialized
INFO - 2016-10-17 14:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:49:57 --> Controller Class Initialized
INFO - 2016-10-17 14:49:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:49:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 14:49:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 14:49:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:49:57 --> Final output sent to browser
DEBUG - 2016-10-17 14:49:57 --> Total execution time: 0.0040
INFO - 2016-10-17 14:49:59 --> Config Class Initialized
INFO - 2016-10-17 14:49:59 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:49:59 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:49:59 --> Utf8 Class Initialized
INFO - 2016-10-17 14:49:59 --> URI Class Initialized
INFO - 2016-10-17 14:49:59 --> Router Class Initialized
INFO - 2016-10-17 14:49:59 --> Output Class Initialized
INFO - 2016-10-17 14:49:59 --> Security Class Initialized
DEBUG - 2016-10-17 14:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:49:59 --> Input Class Initialized
INFO - 2016-10-17 14:49:59 --> Language Class Initialized
INFO - 2016-10-17 14:49:59 --> Loader Class Initialized
INFO - 2016-10-17 14:49:59 --> Helper loaded: url_helper
INFO - 2016-10-17 14:49:59 --> Helper loaded: form_helper
INFO - 2016-10-17 14:49:59 --> Database Driver Class Initialized
INFO - 2016-10-17 14:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:49:59 --> Controller Class Initialized
ERROR - 2016-10-17 14:49:59 --> Severity: Notice --> Undefined variable: name /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 93
ERROR - 2016-10-17 14:49:59 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 93
INFO - 2016-10-17 14:49:59 --> Config Class Initialized
INFO - 2016-10-17 14:49:59 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:49:59 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:49:59 --> Utf8 Class Initialized
INFO - 2016-10-17 14:49:59 --> URI Class Initialized
DEBUG - 2016-10-17 14:49:59 --> No URI present. Default controller set.
INFO - 2016-10-17 14:49:59 --> Router Class Initialized
INFO - 2016-10-17 14:49:59 --> Output Class Initialized
INFO - 2016-10-17 14:49:59 --> Security Class Initialized
DEBUG - 2016-10-17 14:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:49:59 --> Input Class Initialized
INFO - 2016-10-17 14:49:59 --> Language Class Initialized
INFO - 2016-10-17 14:49:59 --> Loader Class Initialized
INFO - 2016-10-17 14:49:59 --> Helper loaded: url_helper
INFO - 2016-10-17 14:49:59 --> Helper loaded: form_helper
INFO - 2016-10-17 14:49:59 --> Database Driver Class Initialized
INFO - 2016-10-17 14:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:49:59 --> Controller Class Initialized
INFO - 2016-10-17 14:49:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:49:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:49:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:49:59 --> Final output sent to browser
DEBUG - 2016-10-17 14:49:59 --> Total execution time: 0.0039
INFO - 2016-10-17 14:50:53 --> Config Class Initialized
INFO - 2016-10-17 14:50:53 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:50:53 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:50:53 --> Utf8 Class Initialized
INFO - 2016-10-17 14:50:53 --> URI Class Initialized
DEBUG - 2016-10-17 14:50:53 --> No URI present. Default controller set.
INFO - 2016-10-17 14:50:53 --> Router Class Initialized
INFO - 2016-10-17 14:50:53 --> Output Class Initialized
INFO - 2016-10-17 14:50:53 --> Security Class Initialized
DEBUG - 2016-10-17 14:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:50:53 --> Input Class Initialized
INFO - 2016-10-17 14:50:53 --> Language Class Initialized
INFO - 2016-10-17 14:50:53 --> Loader Class Initialized
INFO - 2016-10-17 14:50:53 --> Helper loaded: url_helper
INFO - 2016-10-17 14:50:53 --> Helper loaded: form_helper
INFO - 2016-10-17 14:50:53 --> Database Driver Class Initialized
INFO - 2016-10-17 14:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:50:53 --> Controller Class Initialized
INFO - 2016-10-17 14:50:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:50:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:50:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:50:53 --> Final output sent to browser
DEBUG - 2016-10-17 14:50:53 --> Total execution time: 0.0057
INFO - 2016-10-17 14:50:56 --> Config Class Initialized
INFO - 2016-10-17 14:50:56 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:50:56 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:50:56 --> Utf8 Class Initialized
INFO - 2016-10-17 14:50:56 --> URI Class Initialized
INFO - 2016-10-17 14:50:56 --> Router Class Initialized
INFO - 2016-10-17 14:50:56 --> Output Class Initialized
INFO - 2016-10-17 14:50:56 --> Security Class Initialized
DEBUG - 2016-10-17 14:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:50:56 --> Input Class Initialized
INFO - 2016-10-17 14:50:56 --> Language Class Initialized
INFO - 2016-10-17 14:50:56 --> Loader Class Initialized
INFO - 2016-10-17 14:50:56 --> Helper loaded: url_helper
INFO - 2016-10-17 14:50:56 --> Helper loaded: form_helper
INFO - 2016-10-17 14:50:56 --> Database Driver Class Initialized
INFO - 2016-10-17 14:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:50:56 --> Controller Class Initialized
INFO - 2016-10-17 14:50:56 --> Form Validation Class Initialized
INFO - 2016-10-17 14:50:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-17 14:50:56 --> Model Class Initialized
INFO - 2016-10-17 14:50:56 --> Final output sent to browser
DEBUG - 2016-10-17 14:50:56 --> Total execution time: 0.0054
INFO - 2016-10-17 14:50:56 --> Config Class Initialized
INFO - 2016-10-17 14:50:56 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:50:56 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:50:56 --> Utf8 Class Initialized
INFO - 2016-10-17 14:50:56 --> URI Class Initialized
DEBUG - 2016-10-17 14:50:56 --> No URI present. Default controller set.
INFO - 2016-10-17 14:50:56 --> Router Class Initialized
INFO - 2016-10-17 14:50:56 --> Output Class Initialized
INFO - 2016-10-17 14:50:56 --> Security Class Initialized
DEBUG - 2016-10-17 14:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:50:56 --> Input Class Initialized
INFO - 2016-10-17 14:50:56 --> Language Class Initialized
INFO - 2016-10-17 14:50:56 --> Loader Class Initialized
INFO - 2016-10-17 14:50:56 --> Helper loaded: url_helper
INFO - 2016-10-17 14:50:56 --> Helper loaded: form_helper
INFO - 2016-10-17 14:50:56 --> Database Driver Class Initialized
INFO - 2016-10-17 14:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:50:56 --> Controller Class Initialized
INFO - 2016-10-17 14:50:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:50:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 14:50:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 14:50:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:50:56 --> Final output sent to browser
DEBUG - 2016-10-17 14:50:56 --> Total execution time: 0.0045
INFO - 2016-10-17 14:51:00 --> Config Class Initialized
INFO - 2016-10-17 14:51:00 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:51:00 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:51:00 --> Utf8 Class Initialized
INFO - 2016-10-17 14:51:00 --> URI Class Initialized
INFO - 2016-10-17 14:51:00 --> Router Class Initialized
INFO - 2016-10-17 14:51:00 --> Output Class Initialized
INFO - 2016-10-17 14:51:00 --> Security Class Initialized
DEBUG - 2016-10-17 14:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:51:00 --> Input Class Initialized
INFO - 2016-10-17 14:51:00 --> Language Class Initialized
INFO - 2016-10-17 14:51:00 --> Loader Class Initialized
INFO - 2016-10-17 14:51:00 --> Helper loaded: url_helper
INFO - 2016-10-17 14:51:00 --> Helper loaded: form_helper
INFO - 2016-10-17 14:51:00 --> Database Driver Class Initialized
INFO - 2016-10-17 14:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:51:00 --> Controller Class Initialized
ERROR - 2016-10-17 14:51:00 --> Severity: Notice --> Undefined variable: name /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
ERROR - 2016-10-17 14:51:00 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
INFO - 2016-10-17 14:51:00 --> Config Class Initialized
INFO - 2016-10-17 14:51:00 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:51:00 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:51:00 --> Utf8 Class Initialized
INFO - 2016-10-17 14:51:00 --> URI Class Initialized
DEBUG - 2016-10-17 14:51:00 --> No URI present. Default controller set.
INFO - 2016-10-17 14:51:00 --> Router Class Initialized
INFO - 2016-10-17 14:51:00 --> Output Class Initialized
INFO - 2016-10-17 14:51:00 --> Security Class Initialized
DEBUG - 2016-10-17 14:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:51:00 --> Input Class Initialized
INFO - 2016-10-17 14:51:00 --> Language Class Initialized
INFO - 2016-10-17 14:51:00 --> Loader Class Initialized
INFO - 2016-10-17 14:51:00 --> Helper loaded: url_helper
INFO - 2016-10-17 14:51:00 --> Helper loaded: form_helper
INFO - 2016-10-17 14:51:00 --> Database Driver Class Initialized
INFO - 2016-10-17 14:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:51:00 --> Controller Class Initialized
INFO - 2016-10-17 14:51:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:51:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:51:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:51:00 --> Final output sent to browser
DEBUG - 2016-10-17 14:51:00 --> Total execution time: 0.0041
INFO - 2016-10-17 14:51:13 --> Config Class Initialized
INFO - 2016-10-17 14:51:13 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:51:13 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:51:13 --> Utf8 Class Initialized
INFO - 2016-10-17 14:51:13 --> URI Class Initialized
DEBUG - 2016-10-17 14:51:13 --> No URI present. Default controller set.
INFO - 2016-10-17 14:51:13 --> Router Class Initialized
INFO - 2016-10-17 14:51:13 --> Output Class Initialized
INFO - 2016-10-17 14:51:13 --> Security Class Initialized
DEBUG - 2016-10-17 14:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:51:13 --> Input Class Initialized
INFO - 2016-10-17 14:51:13 --> Language Class Initialized
INFO - 2016-10-17 14:51:13 --> Loader Class Initialized
INFO - 2016-10-17 14:51:13 --> Helper loaded: url_helper
INFO - 2016-10-17 14:51:13 --> Helper loaded: form_helper
INFO - 2016-10-17 14:51:13 --> Database Driver Class Initialized
INFO - 2016-10-17 14:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:51:13 --> Controller Class Initialized
INFO - 2016-10-17 14:51:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:51:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:51:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:51:13 --> Final output sent to browser
DEBUG - 2016-10-17 14:51:13 --> Total execution time: 0.0049
INFO - 2016-10-17 14:52:50 --> Config Class Initialized
INFO - 2016-10-17 14:52:50 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:52:50 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:52:50 --> Utf8 Class Initialized
INFO - 2016-10-17 14:52:50 --> URI Class Initialized
DEBUG - 2016-10-17 14:52:50 --> No URI present. Default controller set.
INFO - 2016-10-17 14:52:50 --> Router Class Initialized
INFO - 2016-10-17 14:52:50 --> Output Class Initialized
INFO - 2016-10-17 14:52:50 --> Security Class Initialized
DEBUG - 2016-10-17 14:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:52:50 --> Input Class Initialized
INFO - 2016-10-17 14:52:50 --> Language Class Initialized
INFO - 2016-10-17 14:52:50 --> Loader Class Initialized
INFO - 2016-10-17 14:52:50 --> Helper loaded: url_helper
INFO - 2016-10-17 14:52:50 --> Helper loaded: form_helper
INFO - 2016-10-17 14:52:50 --> Database Driver Class Initialized
INFO - 2016-10-17 14:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:52:50 --> Controller Class Initialized
INFO - 2016-10-17 14:52:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:52:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:52:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:52:50 --> Final output sent to browser
DEBUG - 2016-10-17 14:52:50 --> Total execution time: 0.0057
INFO - 2016-10-17 14:52:58 --> Config Class Initialized
INFO - 2016-10-17 14:52:58 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:52:58 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:52:58 --> Utf8 Class Initialized
INFO - 2016-10-17 14:52:58 --> URI Class Initialized
INFO - 2016-10-17 14:52:58 --> Router Class Initialized
INFO - 2016-10-17 14:52:58 --> Output Class Initialized
INFO - 2016-10-17 14:52:58 --> Security Class Initialized
DEBUG - 2016-10-17 14:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:52:58 --> Input Class Initialized
INFO - 2016-10-17 14:52:58 --> Language Class Initialized
INFO - 2016-10-17 14:52:58 --> Loader Class Initialized
INFO - 2016-10-17 14:52:58 --> Helper loaded: url_helper
INFO - 2016-10-17 14:52:58 --> Helper loaded: form_helper
INFO - 2016-10-17 14:52:58 --> Database Driver Class Initialized
INFO - 2016-10-17 14:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:52:58 --> Controller Class Initialized
INFO - 2016-10-17 14:52:58 --> Model Class Initialized
INFO - 2016-10-17 14:52:58 --> Final output sent to browser
DEBUG - 2016-10-17 14:52:58 --> Total execution time: 0.0049
INFO - 2016-10-17 14:52:58 --> Config Class Initialized
INFO - 2016-10-17 14:52:58 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:52:58 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:52:58 --> Utf8 Class Initialized
INFO - 2016-10-17 14:52:58 --> URI Class Initialized
DEBUG - 2016-10-17 14:52:58 --> No URI present. Default controller set.
INFO - 2016-10-17 14:52:58 --> Router Class Initialized
INFO - 2016-10-17 14:52:58 --> Output Class Initialized
INFO - 2016-10-17 14:52:58 --> Security Class Initialized
DEBUG - 2016-10-17 14:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:52:58 --> Input Class Initialized
INFO - 2016-10-17 14:52:58 --> Language Class Initialized
INFO - 2016-10-17 14:52:58 --> Loader Class Initialized
INFO - 2016-10-17 14:52:58 --> Helper loaded: url_helper
INFO - 2016-10-17 14:52:58 --> Helper loaded: form_helper
INFO - 2016-10-17 14:52:58 --> Database Driver Class Initialized
INFO - 2016-10-17 14:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:52:58 --> Controller Class Initialized
INFO - 2016-10-17 14:52:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:52:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 14:52:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 14:52:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:52:58 --> Final output sent to browser
DEBUG - 2016-10-17 14:52:58 --> Total execution time: 0.0038
INFO - 2016-10-17 14:53:03 --> Config Class Initialized
INFO - 2016-10-17 14:53:03 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:53:03 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:53:03 --> Utf8 Class Initialized
INFO - 2016-10-17 14:53:03 --> URI Class Initialized
INFO - 2016-10-17 14:53:03 --> Router Class Initialized
INFO - 2016-10-17 14:53:03 --> Output Class Initialized
INFO - 2016-10-17 14:53:03 --> Security Class Initialized
DEBUG - 2016-10-17 14:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:53:03 --> Input Class Initialized
INFO - 2016-10-17 14:53:03 --> Language Class Initialized
INFO - 2016-10-17 14:53:03 --> Loader Class Initialized
INFO - 2016-10-17 14:53:03 --> Helper loaded: url_helper
INFO - 2016-10-17 14:53:03 --> Helper loaded: form_helper
INFO - 2016-10-17 14:53:03 --> Database Driver Class Initialized
INFO - 2016-10-17 14:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:53:03 --> Controller Class Initialized
ERROR - 2016-10-17 14:53:03 --> Severity: Notice --> Undefined variable: name /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 91
ERROR - 2016-10-17 14:53:03 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 91
INFO - 2016-10-17 14:53:03 --> Config Class Initialized
INFO - 2016-10-17 14:53:03 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:53:03 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:53:03 --> Utf8 Class Initialized
INFO - 2016-10-17 14:53:03 --> URI Class Initialized
DEBUG - 2016-10-17 14:53:03 --> No URI present. Default controller set.
INFO - 2016-10-17 14:53:03 --> Router Class Initialized
INFO - 2016-10-17 14:53:03 --> Output Class Initialized
INFO - 2016-10-17 14:53:03 --> Security Class Initialized
DEBUG - 2016-10-17 14:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:53:03 --> Input Class Initialized
INFO - 2016-10-17 14:53:03 --> Language Class Initialized
INFO - 2016-10-17 14:53:03 --> Loader Class Initialized
INFO - 2016-10-17 14:53:03 --> Helper loaded: url_helper
INFO - 2016-10-17 14:53:03 --> Helper loaded: form_helper
INFO - 2016-10-17 14:53:03 --> Database Driver Class Initialized
INFO - 2016-10-17 14:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:53:03 --> Controller Class Initialized
INFO - 2016-10-17 14:53:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:53:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:53:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:53:03 --> Final output sent to browser
DEBUG - 2016-10-17 14:53:03 --> Total execution time: 0.0039
INFO - 2016-10-17 14:54:07 --> Config Class Initialized
INFO - 2016-10-17 14:54:07 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:54:07 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:54:07 --> Utf8 Class Initialized
INFO - 2016-10-17 14:54:07 --> URI Class Initialized
DEBUG - 2016-10-17 14:54:07 --> No URI present. Default controller set.
INFO - 2016-10-17 14:54:07 --> Router Class Initialized
INFO - 2016-10-17 14:54:07 --> Output Class Initialized
INFO - 2016-10-17 14:54:07 --> Security Class Initialized
DEBUG - 2016-10-17 14:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:54:07 --> Input Class Initialized
INFO - 2016-10-17 14:54:07 --> Language Class Initialized
INFO - 2016-10-17 14:54:07 --> Loader Class Initialized
INFO - 2016-10-17 14:54:07 --> Helper loaded: url_helper
INFO - 2016-10-17 14:54:07 --> Helper loaded: form_helper
INFO - 2016-10-17 14:54:07 --> Database Driver Class Initialized
INFO - 2016-10-17 14:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:54:07 --> Controller Class Initialized
INFO - 2016-10-17 14:54:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:54:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:54:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:54:07 --> Final output sent to browser
DEBUG - 2016-10-17 14:54:07 --> Total execution time: 0.0055
INFO - 2016-10-17 14:54:11 --> Config Class Initialized
INFO - 2016-10-17 14:54:11 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:54:11 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:54:11 --> Utf8 Class Initialized
INFO - 2016-10-17 14:54:11 --> URI Class Initialized
INFO - 2016-10-17 14:54:11 --> Router Class Initialized
INFO - 2016-10-17 14:54:11 --> Output Class Initialized
INFO - 2016-10-17 14:54:11 --> Security Class Initialized
DEBUG - 2016-10-17 14:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:54:11 --> Input Class Initialized
INFO - 2016-10-17 14:54:11 --> Language Class Initialized
INFO - 2016-10-17 14:54:11 --> Loader Class Initialized
INFO - 2016-10-17 14:54:11 --> Helper loaded: url_helper
INFO - 2016-10-17 14:54:11 --> Helper loaded: form_helper
INFO - 2016-10-17 14:54:11 --> Database Driver Class Initialized
INFO - 2016-10-17 14:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:54:11 --> Controller Class Initialized
INFO - 2016-10-17 14:54:11 --> Model Class Initialized
ERROR - 2016-10-17 14:54:11 --> Severity: Notice --> Undefined property: Auth::$auth_model /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 50
ERROR - 2016-10-17 14:54:11 --> Severity: Error --> Call to a member function validate() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 50
INFO - 2016-10-17 14:54:32 --> Config Class Initialized
INFO - 2016-10-17 14:54:32 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:54:32 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:54:32 --> Utf8 Class Initialized
INFO - 2016-10-17 14:54:32 --> URI Class Initialized
DEBUG - 2016-10-17 14:54:32 --> No URI present. Default controller set.
INFO - 2016-10-17 14:54:32 --> Router Class Initialized
INFO - 2016-10-17 14:54:32 --> Output Class Initialized
INFO - 2016-10-17 14:54:32 --> Security Class Initialized
DEBUG - 2016-10-17 14:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:54:32 --> Input Class Initialized
INFO - 2016-10-17 14:54:32 --> Language Class Initialized
INFO - 2016-10-17 14:54:32 --> Loader Class Initialized
INFO - 2016-10-17 14:54:32 --> Helper loaded: url_helper
INFO - 2016-10-17 14:54:32 --> Helper loaded: form_helper
INFO - 2016-10-17 14:54:32 --> Database Driver Class Initialized
INFO - 2016-10-17 14:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:54:32 --> Controller Class Initialized
INFO - 2016-10-17 14:54:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:54:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:54:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:54:32 --> Final output sent to browser
DEBUG - 2016-10-17 14:54:32 --> Total execution time: 0.0053
INFO - 2016-10-17 14:54:36 --> Config Class Initialized
INFO - 2016-10-17 14:54:36 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:54:36 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:54:36 --> Utf8 Class Initialized
INFO - 2016-10-17 14:54:36 --> URI Class Initialized
INFO - 2016-10-17 14:54:36 --> Router Class Initialized
INFO - 2016-10-17 14:54:36 --> Output Class Initialized
INFO - 2016-10-17 14:54:36 --> Security Class Initialized
DEBUG - 2016-10-17 14:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:54:36 --> Input Class Initialized
INFO - 2016-10-17 14:54:36 --> Language Class Initialized
INFO - 2016-10-17 14:54:36 --> Loader Class Initialized
INFO - 2016-10-17 14:54:36 --> Helper loaded: url_helper
INFO - 2016-10-17 14:54:36 --> Helper loaded: form_helper
INFO - 2016-10-17 14:54:36 --> Database Driver Class Initialized
INFO - 2016-10-17 14:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:54:36 --> Controller Class Initialized
INFO - 2016-10-17 14:54:36 --> Model Class Initialized
INFO - 2016-10-17 14:54:36 --> Final output sent to browser
DEBUG - 2016-10-17 14:54:36 --> Total execution time: 0.0052
INFO - 2016-10-17 14:54:36 --> Config Class Initialized
INFO - 2016-10-17 14:54:36 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:54:36 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:54:36 --> Utf8 Class Initialized
INFO - 2016-10-17 14:54:36 --> URI Class Initialized
DEBUG - 2016-10-17 14:54:36 --> No URI present. Default controller set.
INFO - 2016-10-17 14:54:36 --> Router Class Initialized
INFO - 2016-10-17 14:54:36 --> Output Class Initialized
INFO - 2016-10-17 14:54:36 --> Security Class Initialized
DEBUG - 2016-10-17 14:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:54:36 --> Input Class Initialized
INFO - 2016-10-17 14:54:36 --> Language Class Initialized
INFO - 2016-10-17 14:54:36 --> Loader Class Initialized
INFO - 2016-10-17 14:54:36 --> Helper loaded: url_helper
INFO - 2016-10-17 14:54:36 --> Helper loaded: form_helper
INFO - 2016-10-17 14:54:36 --> Database Driver Class Initialized
INFO - 2016-10-17 14:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:54:36 --> Controller Class Initialized
INFO - 2016-10-17 14:54:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:54:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 14:54:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 14:54:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:54:36 --> Final output sent to browser
DEBUG - 2016-10-17 14:54:36 --> Total execution time: 0.0039
INFO - 2016-10-17 14:54:37 --> Config Class Initialized
INFO - 2016-10-17 14:54:37 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:54:37 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:54:37 --> Utf8 Class Initialized
INFO - 2016-10-17 14:54:37 --> URI Class Initialized
INFO - 2016-10-17 14:54:37 --> Router Class Initialized
INFO - 2016-10-17 14:54:37 --> Output Class Initialized
INFO - 2016-10-17 14:54:37 --> Security Class Initialized
DEBUG - 2016-10-17 14:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:54:37 --> Input Class Initialized
INFO - 2016-10-17 14:54:37 --> Language Class Initialized
INFO - 2016-10-17 14:54:37 --> Loader Class Initialized
INFO - 2016-10-17 14:54:37 --> Helper loaded: url_helper
INFO - 2016-10-17 14:54:37 --> Helper loaded: form_helper
INFO - 2016-10-17 14:54:37 --> Database Driver Class Initialized
INFO - 2016-10-17 14:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:54:37 --> Controller Class Initialized
ERROR - 2016-10-17 14:54:37 --> Severity: Notice --> Undefined variable: name /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 91
ERROR - 2016-10-17 14:54:37 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 91
INFO - 2016-10-17 14:54:37 --> Config Class Initialized
INFO - 2016-10-17 14:54:37 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:54:37 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:54:37 --> Utf8 Class Initialized
INFO - 2016-10-17 14:54:37 --> URI Class Initialized
DEBUG - 2016-10-17 14:54:37 --> No URI present. Default controller set.
INFO - 2016-10-17 14:54:37 --> Router Class Initialized
INFO - 2016-10-17 14:54:37 --> Output Class Initialized
INFO - 2016-10-17 14:54:37 --> Security Class Initialized
DEBUG - 2016-10-17 14:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:54:37 --> Input Class Initialized
INFO - 2016-10-17 14:54:37 --> Language Class Initialized
INFO - 2016-10-17 14:54:37 --> Loader Class Initialized
INFO - 2016-10-17 14:54:37 --> Helper loaded: url_helper
INFO - 2016-10-17 14:54:37 --> Helper loaded: form_helper
INFO - 2016-10-17 14:54:37 --> Database Driver Class Initialized
INFO - 2016-10-17 14:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:54:37 --> Controller Class Initialized
INFO - 2016-10-17 14:54:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:54:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:54:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:54:37 --> Final output sent to browser
DEBUG - 2016-10-17 14:54:37 --> Total execution time: 0.0039
INFO - 2016-10-17 14:59:04 --> Config Class Initialized
INFO - 2016-10-17 14:59:04 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:59:04 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:59:04 --> Utf8 Class Initialized
INFO - 2016-10-17 14:59:04 --> URI Class Initialized
DEBUG - 2016-10-17 14:59:04 --> No URI present. Default controller set.
INFO - 2016-10-17 14:59:04 --> Router Class Initialized
INFO - 2016-10-17 14:59:04 --> Output Class Initialized
INFO - 2016-10-17 14:59:04 --> Security Class Initialized
DEBUG - 2016-10-17 14:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:59:04 --> Input Class Initialized
INFO - 2016-10-17 14:59:04 --> Language Class Initialized
INFO - 2016-10-17 14:59:04 --> Loader Class Initialized
INFO - 2016-10-17 14:59:04 --> Helper loaded: url_helper
INFO - 2016-10-17 14:59:04 --> Helper loaded: form_helper
INFO - 2016-10-17 14:59:04 --> Database Driver Class Initialized
INFO - 2016-10-17 14:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:59:04 --> Controller Class Initialized
INFO - 2016-10-17 14:59:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:59:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:59:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:59:04 --> Final output sent to browser
DEBUG - 2016-10-17 14:59:04 --> Total execution time: 0.0057
INFO - 2016-10-17 14:59:07 --> Config Class Initialized
INFO - 2016-10-17 14:59:07 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:59:07 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:59:07 --> Utf8 Class Initialized
INFO - 2016-10-17 14:59:07 --> URI Class Initialized
INFO - 2016-10-17 14:59:07 --> Router Class Initialized
INFO - 2016-10-17 14:59:07 --> Output Class Initialized
INFO - 2016-10-17 14:59:07 --> Security Class Initialized
DEBUG - 2016-10-17 14:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:59:07 --> Input Class Initialized
INFO - 2016-10-17 14:59:07 --> Language Class Initialized
INFO - 2016-10-17 14:59:07 --> Loader Class Initialized
INFO - 2016-10-17 14:59:07 --> Helper loaded: url_helper
INFO - 2016-10-17 14:59:07 --> Helper loaded: form_helper
INFO - 2016-10-17 14:59:07 --> Database Driver Class Initialized
INFO - 2016-10-17 14:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:59:07 --> Controller Class Initialized
INFO - 2016-10-17 14:59:07 --> Model Class Initialized
INFO - 2016-10-17 14:59:07 --> Final output sent to browser
DEBUG - 2016-10-17 14:59:07 --> Total execution time: 0.0062
INFO - 2016-10-17 14:59:14 --> Config Class Initialized
INFO - 2016-10-17 14:59:14 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:59:14 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:59:14 --> Utf8 Class Initialized
INFO - 2016-10-17 14:59:14 --> URI Class Initialized
DEBUG - 2016-10-17 14:59:14 --> No URI present. Default controller set.
INFO - 2016-10-17 14:59:14 --> Router Class Initialized
INFO - 2016-10-17 14:59:14 --> Output Class Initialized
INFO - 2016-10-17 14:59:14 --> Security Class Initialized
DEBUG - 2016-10-17 14:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:59:14 --> Input Class Initialized
INFO - 2016-10-17 14:59:14 --> Language Class Initialized
INFO - 2016-10-17 14:59:14 --> Loader Class Initialized
INFO - 2016-10-17 14:59:14 --> Helper loaded: url_helper
INFO - 2016-10-17 14:59:14 --> Helper loaded: form_helper
INFO - 2016-10-17 14:59:14 --> Database Driver Class Initialized
INFO - 2016-10-17 14:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:59:14 --> Controller Class Initialized
INFO - 2016-10-17 14:59:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 14:59:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 14:59:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 14:59:14 --> Final output sent to browser
DEBUG - 2016-10-17 14:59:14 --> Total execution time: 0.0084
INFO - 2016-10-17 15:00:03 --> Config Class Initialized
INFO - 2016-10-17 15:00:03 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:00:03 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:00:03 --> Utf8 Class Initialized
INFO - 2016-10-17 15:00:03 --> URI Class Initialized
DEBUG - 2016-10-17 15:00:03 --> No URI present. Default controller set.
INFO - 2016-10-17 15:00:03 --> Router Class Initialized
INFO - 2016-10-17 15:00:03 --> Output Class Initialized
INFO - 2016-10-17 15:00:03 --> Security Class Initialized
DEBUG - 2016-10-17 15:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:00:03 --> Input Class Initialized
INFO - 2016-10-17 15:00:03 --> Language Class Initialized
INFO - 2016-10-17 15:00:03 --> Loader Class Initialized
INFO - 2016-10-17 15:00:03 --> Helper loaded: url_helper
INFO - 2016-10-17 15:00:03 --> Helper loaded: form_helper
INFO - 2016-10-17 15:00:03 --> Database Driver Class Initialized
INFO - 2016-10-17 15:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:00:03 --> Controller Class Initialized
INFO - 2016-10-17 15:00:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:00:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:00:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:00:03 --> Final output sent to browser
DEBUG - 2016-10-17 15:00:03 --> Total execution time: 0.0083
INFO - 2016-10-17 15:00:06 --> Config Class Initialized
INFO - 2016-10-17 15:00:06 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:00:06 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:00:06 --> Utf8 Class Initialized
INFO - 2016-10-17 15:00:06 --> URI Class Initialized
INFO - 2016-10-17 15:00:06 --> Router Class Initialized
INFO - 2016-10-17 15:00:06 --> Output Class Initialized
INFO - 2016-10-17 15:00:06 --> Security Class Initialized
DEBUG - 2016-10-17 15:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:00:06 --> Input Class Initialized
INFO - 2016-10-17 15:00:06 --> Language Class Initialized
INFO - 2016-10-17 15:00:06 --> Loader Class Initialized
INFO - 2016-10-17 15:00:06 --> Helper loaded: url_helper
INFO - 2016-10-17 15:00:06 --> Helper loaded: form_helper
INFO - 2016-10-17 15:00:06 --> Database Driver Class Initialized
INFO - 2016-10-17 15:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:00:06 --> Controller Class Initialized
INFO - 2016-10-17 15:00:06 --> Model Class Initialized
INFO - 2016-10-17 15:00:06 --> Final output sent to browser
DEBUG - 2016-10-17 15:00:06 --> Total execution time: 0.0059
INFO - 2016-10-17 15:00:18 --> Config Class Initialized
INFO - 2016-10-17 15:00:18 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:00:18 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:00:18 --> Utf8 Class Initialized
INFO - 2016-10-17 15:00:18 --> URI Class Initialized
DEBUG - 2016-10-17 15:00:18 --> No URI present. Default controller set.
INFO - 2016-10-17 15:00:18 --> Router Class Initialized
INFO - 2016-10-17 15:00:18 --> Output Class Initialized
INFO - 2016-10-17 15:00:18 --> Security Class Initialized
DEBUG - 2016-10-17 15:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:00:18 --> Input Class Initialized
INFO - 2016-10-17 15:00:18 --> Language Class Initialized
INFO - 2016-10-17 15:00:18 --> Loader Class Initialized
INFO - 2016-10-17 15:00:18 --> Helper loaded: url_helper
INFO - 2016-10-17 15:00:18 --> Helper loaded: form_helper
INFO - 2016-10-17 15:00:18 --> Database Driver Class Initialized
INFO - 2016-10-17 15:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:00:18 --> Controller Class Initialized
INFO - 2016-10-17 15:00:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:00:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:00:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:00:18 --> Final output sent to browser
DEBUG - 2016-10-17 15:00:18 --> Total execution time: 0.0048
INFO - 2016-10-17 15:00:25 --> Config Class Initialized
INFO - 2016-10-17 15:00:25 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:00:25 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:00:25 --> Utf8 Class Initialized
INFO - 2016-10-17 15:00:25 --> URI Class Initialized
INFO - 2016-10-17 15:00:25 --> Router Class Initialized
INFO - 2016-10-17 15:00:25 --> Output Class Initialized
INFO - 2016-10-17 15:00:25 --> Security Class Initialized
DEBUG - 2016-10-17 15:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:00:25 --> Input Class Initialized
INFO - 2016-10-17 15:00:25 --> Language Class Initialized
INFO - 2016-10-17 15:00:25 --> Loader Class Initialized
INFO - 2016-10-17 15:00:25 --> Helper loaded: url_helper
INFO - 2016-10-17 15:00:25 --> Helper loaded: form_helper
INFO - 2016-10-17 15:00:25 --> Database Driver Class Initialized
INFO - 2016-10-17 15:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:00:26 --> Controller Class Initialized
INFO - 2016-10-17 15:00:26 --> Model Class Initialized
INFO - 2016-10-17 15:00:26 --> Final output sent to browser
DEBUG - 2016-10-17 15:00:26 --> Total execution time: 0.0056
INFO - 2016-10-17 15:00:36 --> Config Class Initialized
INFO - 2016-10-17 15:00:36 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:00:36 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:00:36 --> Utf8 Class Initialized
INFO - 2016-10-17 15:00:36 --> URI Class Initialized
DEBUG - 2016-10-17 15:00:36 --> No URI present. Default controller set.
INFO - 2016-10-17 15:00:36 --> Router Class Initialized
INFO - 2016-10-17 15:00:36 --> Output Class Initialized
INFO - 2016-10-17 15:00:36 --> Security Class Initialized
DEBUG - 2016-10-17 15:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:00:36 --> Input Class Initialized
INFO - 2016-10-17 15:00:36 --> Language Class Initialized
INFO - 2016-10-17 15:00:36 --> Loader Class Initialized
INFO - 2016-10-17 15:00:36 --> Helper loaded: url_helper
INFO - 2016-10-17 15:00:36 --> Helper loaded: form_helper
INFO - 2016-10-17 15:00:36 --> Database Driver Class Initialized
INFO - 2016-10-17 15:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:00:36 --> Controller Class Initialized
INFO - 2016-10-17 15:00:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:00:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:00:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:00:36 --> Final output sent to browser
DEBUG - 2016-10-17 15:00:36 --> Total execution time: 0.0048
INFO - 2016-10-17 15:02:37 --> Config Class Initialized
INFO - 2016-10-17 15:02:37 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:02:37 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:02:37 --> Utf8 Class Initialized
INFO - 2016-10-17 15:02:37 --> URI Class Initialized
DEBUG - 2016-10-17 15:02:37 --> No URI present. Default controller set.
INFO - 2016-10-17 15:02:37 --> Router Class Initialized
INFO - 2016-10-17 15:02:37 --> Output Class Initialized
INFO - 2016-10-17 15:02:37 --> Security Class Initialized
DEBUG - 2016-10-17 15:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:02:37 --> Input Class Initialized
INFO - 2016-10-17 15:02:37 --> Language Class Initialized
INFO - 2016-10-17 15:02:37 --> Loader Class Initialized
INFO - 2016-10-17 15:02:37 --> Helper loaded: url_helper
INFO - 2016-10-17 15:02:37 --> Helper loaded: form_helper
INFO - 2016-10-17 15:02:37 --> Database Driver Class Initialized
INFO - 2016-10-17 15:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:02:37 --> Controller Class Initialized
INFO - 2016-10-17 15:02:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:02:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:02:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:02:37 --> Final output sent to browser
DEBUG - 2016-10-17 15:02:37 --> Total execution time: 0.0056
INFO - 2016-10-17 15:02:42 --> Config Class Initialized
INFO - 2016-10-17 15:02:42 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:02:42 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:02:42 --> Utf8 Class Initialized
INFO - 2016-10-17 15:02:42 --> URI Class Initialized
INFO - 2016-10-17 15:02:42 --> Router Class Initialized
INFO - 2016-10-17 15:02:42 --> Output Class Initialized
INFO - 2016-10-17 15:02:42 --> Security Class Initialized
DEBUG - 2016-10-17 15:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:02:42 --> Input Class Initialized
INFO - 2016-10-17 15:02:42 --> Language Class Initialized
INFO - 2016-10-17 15:02:42 --> Loader Class Initialized
INFO - 2016-10-17 15:02:42 --> Helper loaded: url_helper
INFO - 2016-10-17 15:02:42 --> Helper loaded: form_helper
INFO - 2016-10-17 15:02:42 --> Database Driver Class Initialized
INFO - 2016-10-17 15:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:02:42 --> Controller Class Initialized
INFO - 2016-10-17 15:02:42 --> Model Class Initialized
INFO - 2016-10-17 15:02:42 --> Final output sent to browser
DEBUG - 2016-10-17 15:02:42 --> Total execution time: 0.0054
INFO - 2016-10-17 15:02:48 --> Config Class Initialized
INFO - 2016-10-17 15:02:48 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:02:48 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:02:48 --> Utf8 Class Initialized
INFO - 2016-10-17 15:02:48 --> URI Class Initialized
DEBUG - 2016-10-17 15:02:48 --> No URI present. Default controller set.
INFO - 2016-10-17 15:02:48 --> Router Class Initialized
INFO - 2016-10-17 15:02:48 --> Output Class Initialized
INFO - 2016-10-17 15:02:48 --> Security Class Initialized
DEBUG - 2016-10-17 15:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:02:48 --> Input Class Initialized
INFO - 2016-10-17 15:02:48 --> Language Class Initialized
INFO - 2016-10-17 15:02:48 --> Loader Class Initialized
INFO - 2016-10-17 15:02:48 --> Helper loaded: url_helper
INFO - 2016-10-17 15:02:48 --> Helper loaded: form_helper
INFO - 2016-10-17 15:02:48 --> Database Driver Class Initialized
INFO - 2016-10-17 15:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:02:48 --> Controller Class Initialized
INFO - 2016-10-17 15:02:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:02:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:02:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:02:48 --> Final output sent to browser
DEBUG - 2016-10-17 15:02:48 --> Total execution time: 0.0075
INFO - 2016-10-17 15:02:54 --> Config Class Initialized
INFO - 2016-10-17 15:02:54 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:02:54 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:02:54 --> Utf8 Class Initialized
INFO - 2016-10-17 15:02:54 --> URI Class Initialized
INFO - 2016-10-17 15:02:54 --> Router Class Initialized
INFO - 2016-10-17 15:02:54 --> Output Class Initialized
INFO - 2016-10-17 15:02:54 --> Security Class Initialized
DEBUG - 2016-10-17 15:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:02:54 --> Input Class Initialized
INFO - 2016-10-17 15:02:54 --> Language Class Initialized
INFO - 2016-10-17 15:02:54 --> Loader Class Initialized
INFO - 2016-10-17 15:02:54 --> Helper loaded: url_helper
INFO - 2016-10-17 15:02:54 --> Helper loaded: form_helper
INFO - 2016-10-17 15:02:54 --> Database Driver Class Initialized
INFO - 2016-10-17 15:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:02:54 --> Controller Class Initialized
INFO - 2016-10-17 15:02:54 --> Model Class Initialized
INFO - 2016-10-17 15:02:54 --> Final output sent to browser
DEBUG - 2016-10-17 15:02:54 --> Total execution time: 0.0049
INFO - 2016-10-17 15:05:05 --> Config Class Initialized
INFO - 2016-10-17 15:05:05 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:05:05 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:05:05 --> Utf8 Class Initialized
INFO - 2016-10-17 15:05:05 --> URI Class Initialized
DEBUG - 2016-10-17 15:05:05 --> No URI present. Default controller set.
INFO - 2016-10-17 15:05:05 --> Router Class Initialized
INFO - 2016-10-17 15:05:05 --> Output Class Initialized
INFO - 2016-10-17 15:05:05 --> Security Class Initialized
DEBUG - 2016-10-17 15:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:05:05 --> Input Class Initialized
INFO - 2016-10-17 15:05:05 --> Language Class Initialized
INFO - 2016-10-17 15:05:05 --> Loader Class Initialized
INFO - 2016-10-17 15:05:05 --> Helper loaded: url_helper
INFO - 2016-10-17 15:05:05 --> Helper loaded: form_helper
INFO - 2016-10-17 15:05:05 --> Database Driver Class Initialized
INFO - 2016-10-17 15:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:05:05 --> Controller Class Initialized
INFO - 2016-10-17 15:05:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:05:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:05:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:05:05 --> Final output sent to browser
DEBUG - 2016-10-17 15:05:05 --> Total execution time: 0.0054
INFO - 2016-10-17 15:05:29 --> Config Class Initialized
INFO - 2016-10-17 15:05:29 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:05:29 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:05:29 --> Utf8 Class Initialized
INFO - 2016-10-17 15:05:29 --> URI Class Initialized
DEBUG - 2016-10-17 15:05:29 --> No URI present. Default controller set.
INFO - 2016-10-17 15:05:29 --> Router Class Initialized
INFO - 2016-10-17 15:05:29 --> Output Class Initialized
INFO - 2016-10-17 15:05:29 --> Security Class Initialized
DEBUG - 2016-10-17 15:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:05:29 --> Input Class Initialized
INFO - 2016-10-17 15:05:29 --> Language Class Initialized
INFO - 2016-10-17 15:05:29 --> Loader Class Initialized
INFO - 2016-10-17 15:05:29 --> Helper loaded: url_helper
INFO - 2016-10-17 15:05:29 --> Helper loaded: form_helper
INFO - 2016-10-17 15:05:29 --> Database Driver Class Initialized
INFO - 2016-10-17 15:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:05:29 --> Controller Class Initialized
INFO - 2016-10-17 15:05:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:05:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:05:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:05:29 --> Final output sent to browser
DEBUG - 2016-10-17 15:05:29 --> Total execution time: 0.0051
INFO - 2016-10-17 15:05:34 --> Config Class Initialized
INFO - 2016-10-17 15:05:34 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:05:34 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:05:34 --> Utf8 Class Initialized
INFO - 2016-10-17 15:05:34 --> URI Class Initialized
INFO - 2016-10-17 15:05:34 --> Router Class Initialized
INFO - 2016-10-17 15:05:34 --> Output Class Initialized
INFO - 2016-10-17 15:05:34 --> Security Class Initialized
DEBUG - 2016-10-17 15:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:05:34 --> Input Class Initialized
INFO - 2016-10-17 15:05:34 --> Language Class Initialized
INFO - 2016-10-17 15:05:34 --> Loader Class Initialized
INFO - 2016-10-17 15:05:34 --> Helper loaded: url_helper
INFO - 2016-10-17 15:05:34 --> Helper loaded: form_helper
INFO - 2016-10-17 15:05:34 --> Database Driver Class Initialized
INFO - 2016-10-17 15:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:05:34 --> Controller Class Initialized
INFO - 2016-10-17 15:05:34 --> Model Class Initialized
INFO - 2016-10-17 15:05:34 --> Final output sent to browser
DEBUG - 2016-10-17 15:05:34 --> Total execution time: 0.0054
INFO - 2016-10-17 15:05:55 --> Config Class Initialized
INFO - 2016-10-17 15:05:55 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:05:55 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:05:55 --> Utf8 Class Initialized
INFO - 2016-10-17 15:05:55 --> URI Class Initialized
DEBUG - 2016-10-17 15:05:55 --> No URI present. Default controller set.
INFO - 2016-10-17 15:05:55 --> Router Class Initialized
INFO - 2016-10-17 15:05:55 --> Output Class Initialized
INFO - 2016-10-17 15:05:55 --> Security Class Initialized
DEBUG - 2016-10-17 15:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:05:55 --> Input Class Initialized
INFO - 2016-10-17 15:05:55 --> Language Class Initialized
INFO - 2016-10-17 15:05:55 --> Loader Class Initialized
INFO - 2016-10-17 15:05:55 --> Helper loaded: url_helper
INFO - 2016-10-17 15:05:55 --> Helper loaded: form_helper
INFO - 2016-10-17 15:05:55 --> Database Driver Class Initialized
INFO - 2016-10-17 15:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:05:55 --> Controller Class Initialized
INFO - 2016-10-17 15:05:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:05:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:05:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:05:55 --> Final output sent to browser
DEBUG - 2016-10-17 15:05:55 --> Total execution time: 0.0049
INFO - 2016-10-17 15:06:03 --> Config Class Initialized
INFO - 2016-10-17 15:06:03 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:06:03 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:06:03 --> Utf8 Class Initialized
INFO - 2016-10-17 15:06:03 --> URI Class Initialized
INFO - 2016-10-17 15:06:03 --> Router Class Initialized
INFO - 2016-10-17 15:06:03 --> Output Class Initialized
INFO - 2016-10-17 15:06:03 --> Security Class Initialized
DEBUG - 2016-10-17 15:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:06:03 --> Input Class Initialized
INFO - 2016-10-17 15:06:03 --> Language Class Initialized
INFO - 2016-10-17 15:06:03 --> Loader Class Initialized
INFO - 2016-10-17 15:06:03 --> Helper loaded: url_helper
INFO - 2016-10-17 15:06:03 --> Helper loaded: form_helper
INFO - 2016-10-17 15:06:03 --> Database Driver Class Initialized
INFO - 2016-10-17 15:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:06:03 --> Controller Class Initialized
INFO - 2016-10-17 15:06:03 --> Model Class Initialized
INFO - 2016-10-17 15:06:03 --> Final output sent to browser
DEBUG - 2016-10-17 15:06:03 --> Total execution time: 0.0052
INFO - 2016-10-17 15:07:06 --> Config Class Initialized
INFO - 2016-10-17 15:07:06 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:07:06 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:07:06 --> Utf8 Class Initialized
INFO - 2016-10-17 15:07:06 --> URI Class Initialized
DEBUG - 2016-10-17 15:07:06 --> No URI present. Default controller set.
INFO - 2016-10-17 15:07:06 --> Router Class Initialized
INFO - 2016-10-17 15:07:06 --> Output Class Initialized
INFO - 2016-10-17 15:07:06 --> Security Class Initialized
DEBUG - 2016-10-17 15:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:07:06 --> Input Class Initialized
INFO - 2016-10-17 15:07:06 --> Language Class Initialized
INFO - 2016-10-17 15:07:06 --> Loader Class Initialized
INFO - 2016-10-17 15:07:06 --> Helper loaded: url_helper
INFO - 2016-10-17 15:07:06 --> Helper loaded: form_helper
INFO - 2016-10-17 15:07:06 --> Database Driver Class Initialized
INFO - 2016-10-17 15:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:07:06 --> Controller Class Initialized
INFO - 2016-10-17 15:07:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:07:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:07:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:07:06 --> Final output sent to browser
DEBUG - 2016-10-17 15:07:06 --> Total execution time: 0.0049
INFO - 2016-10-17 15:07:12 --> Config Class Initialized
INFO - 2016-10-17 15:07:12 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:07:12 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:07:12 --> Utf8 Class Initialized
INFO - 2016-10-17 15:07:12 --> URI Class Initialized
INFO - 2016-10-17 15:07:12 --> Router Class Initialized
INFO - 2016-10-17 15:07:12 --> Output Class Initialized
INFO - 2016-10-17 15:07:12 --> Security Class Initialized
DEBUG - 2016-10-17 15:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:07:12 --> Input Class Initialized
INFO - 2016-10-17 15:07:12 --> Language Class Initialized
INFO - 2016-10-17 15:07:12 --> Loader Class Initialized
INFO - 2016-10-17 15:07:12 --> Helper loaded: url_helper
INFO - 2016-10-17 15:07:12 --> Helper loaded: form_helper
INFO - 2016-10-17 15:07:12 --> Database Driver Class Initialized
INFO - 2016-10-17 15:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:07:12 --> Controller Class Initialized
INFO - 2016-10-17 15:07:12 --> Model Class Initialized
INFO - 2016-10-17 15:07:12 --> Final output sent to browser
DEBUG - 2016-10-17 15:07:12 --> Total execution time: 0.0058
INFO - 2016-10-17 15:07:12 --> Config Class Initialized
INFO - 2016-10-17 15:07:12 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:07:12 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:07:12 --> Utf8 Class Initialized
INFO - 2016-10-17 15:07:12 --> URI Class Initialized
DEBUG - 2016-10-17 15:07:12 --> No URI present. Default controller set.
INFO - 2016-10-17 15:07:12 --> Router Class Initialized
INFO - 2016-10-17 15:07:12 --> Output Class Initialized
INFO - 2016-10-17 15:07:12 --> Security Class Initialized
DEBUG - 2016-10-17 15:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:07:12 --> Input Class Initialized
INFO - 2016-10-17 15:07:12 --> Language Class Initialized
INFO - 2016-10-17 15:07:12 --> Loader Class Initialized
INFO - 2016-10-17 15:07:12 --> Helper loaded: url_helper
INFO - 2016-10-17 15:07:12 --> Helper loaded: form_helper
INFO - 2016-10-17 15:07:12 --> Database Driver Class Initialized
INFO - 2016-10-17 15:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:07:12 --> Controller Class Initialized
INFO - 2016-10-17 15:07:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:07:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 15:07:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 15:07:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:07:12 --> Final output sent to browser
DEBUG - 2016-10-17 15:07:12 --> Total execution time: 0.0039
INFO - 2016-10-17 15:07:16 --> Config Class Initialized
INFO - 2016-10-17 15:07:16 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:07:16 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:07:16 --> Utf8 Class Initialized
INFO - 2016-10-17 15:07:16 --> URI Class Initialized
INFO - 2016-10-17 15:07:16 --> Router Class Initialized
INFO - 2016-10-17 15:07:16 --> Output Class Initialized
INFO - 2016-10-17 15:07:16 --> Security Class Initialized
DEBUG - 2016-10-17 15:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:07:16 --> Input Class Initialized
INFO - 2016-10-17 15:07:16 --> Language Class Initialized
INFO - 2016-10-17 15:07:16 --> Loader Class Initialized
INFO - 2016-10-17 15:07:16 --> Helper loaded: url_helper
INFO - 2016-10-17 15:07:16 --> Helper loaded: form_helper
INFO - 2016-10-17 15:07:16 --> Database Driver Class Initialized
INFO - 2016-10-17 15:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:07:16 --> Controller Class Initialized
ERROR - 2016-10-17 15:07:16 --> Severity: Notice --> Undefined variable: name /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
ERROR - 2016-10-17 15:07:16 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
INFO - 2016-10-17 15:07:16 --> Config Class Initialized
INFO - 2016-10-17 15:07:16 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:07:16 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:07:16 --> Utf8 Class Initialized
INFO - 2016-10-17 15:07:16 --> URI Class Initialized
DEBUG - 2016-10-17 15:07:16 --> No URI present. Default controller set.
INFO - 2016-10-17 15:07:16 --> Router Class Initialized
INFO - 2016-10-17 15:07:16 --> Output Class Initialized
INFO - 2016-10-17 15:07:16 --> Security Class Initialized
DEBUG - 2016-10-17 15:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:07:16 --> Input Class Initialized
INFO - 2016-10-17 15:07:16 --> Language Class Initialized
INFO - 2016-10-17 15:07:16 --> Loader Class Initialized
INFO - 2016-10-17 15:07:16 --> Helper loaded: url_helper
INFO - 2016-10-17 15:07:16 --> Helper loaded: form_helper
INFO - 2016-10-17 15:07:16 --> Database Driver Class Initialized
INFO - 2016-10-17 15:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:07:16 --> Controller Class Initialized
INFO - 2016-10-17 15:07:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:07:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:07:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:07:16 --> Final output sent to browser
DEBUG - 2016-10-17 15:07:16 --> Total execution time: 0.0039
INFO - 2016-10-17 15:07:22 --> Config Class Initialized
INFO - 2016-10-17 15:07:22 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:07:22 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:07:22 --> Utf8 Class Initialized
INFO - 2016-10-17 15:07:22 --> URI Class Initialized
INFO - 2016-10-17 15:07:22 --> Router Class Initialized
INFO - 2016-10-17 15:07:22 --> Output Class Initialized
INFO - 2016-10-17 15:07:22 --> Security Class Initialized
DEBUG - 2016-10-17 15:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:07:22 --> Input Class Initialized
INFO - 2016-10-17 15:07:22 --> Language Class Initialized
INFO - 2016-10-17 15:07:22 --> Loader Class Initialized
INFO - 2016-10-17 15:07:22 --> Helper loaded: url_helper
INFO - 2016-10-17 15:07:22 --> Helper loaded: form_helper
INFO - 2016-10-17 15:07:22 --> Database Driver Class Initialized
INFO - 2016-10-17 15:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:07:22 --> Controller Class Initialized
INFO - 2016-10-17 15:07:22 --> Model Class Initialized
INFO - 2016-10-17 15:07:22 --> Final output sent to browser
DEBUG - 2016-10-17 15:07:22 --> Total execution time: 0.0059
INFO - 2016-10-17 15:07:22 --> Config Class Initialized
INFO - 2016-10-17 15:07:22 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:07:22 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:07:22 --> Utf8 Class Initialized
INFO - 2016-10-17 15:07:22 --> URI Class Initialized
DEBUG - 2016-10-17 15:07:22 --> No URI present. Default controller set.
INFO - 2016-10-17 15:07:22 --> Router Class Initialized
INFO - 2016-10-17 15:07:22 --> Output Class Initialized
INFO - 2016-10-17 15:07:22 --> Security Class Initialized
DEBUG - 2016-10-17 15:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:07:22 --> Input Class Initialized
INFO - 2016-10-17 15:07:22 --> Language Class Initialized
INFO - 2016-10-17 15:07:22 --> Loader Class Initialized
INFO - 2016-10-17 15:07:22 --> Helper loaded: url_helper
INFO - 2016-10-17 15:07:22 --> Helper loaded: form_helper
INFO - 2016-10-17 15:07:22 --> Database Driver Class Initialized
INFO - 2016-10-17 15:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:07:22 --> Controller Class Initialized
INFO - 2016-10-17 15:07:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:07:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 15:07:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 15:07:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:07:22 --> Final output sent to browser
DEBUG - 2016-10-17 15:07:22 --> Total execution time: 0.0048
INFO - 2016-10-17 15:07:23 --> Config Class Initialized
INFO - 2016-10-17 15:07:23 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:07:23 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:07:23 --> Utf8 Class Initialized
INFO - 2016-10-17 15:07:23 --> URI Class Initialized
INFO - 2016-10-17 15:07:23 --> Router Class Initialized
INFO - 2016-10-17 15:07:23 --> Output Class Initialized
INFO - 2016-10-17 15:07:23 --> Security Class Initialized
DEBUG - 2016-10-17 15:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:07:23 --> Input Class Initialized
INFO - 2016-10-17 15:07:23 --> Language Class Initialized
INFO - 2016-10-17 15:07:23 --> Loader Class Initialized
INFO - 2016-10-17 15:07:23 --> Helper loaded: url_helper
INFO - 2016-10-17 15:07:23 --> Helper loaded: form_helper
INFO - 2016-10-17 15:07:23 --> Database Driver Class Initialized
INFO - 2016-10-17 15:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:07:23 --> Controller Class Initialized
ERROR - 2016-10-17 15:07:23 --> Severity: Notice --> Undefined variable: name /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
ERROR - 2016-10-17 15:07:23 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
INFO - 2016-10-17 15:07:23 --> Config Class Initialized
INFO - 2016-10-17 15:07:23 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:07:23 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:07:23 --> Utf8 Class Initialized
INFO - 2016-10-17 15:07:23 --> URI Class Initialized
DEBUG - 2016-10-17 15:07:23 --> No URI present. Default controller set.
INFO - 2016-10-17 15:07:23 --> Router Class Initialized
INFO - 2016-10-17 15:07:23 --> Output Class Initialized
INFO - 2016-10-17 15:07:23 --> Security Class Initialized
DEBUG - 2016-10-17 15:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:07:23 --> Input Class Initialized
INFO - 2016-10-17 15:07:23 --> Language Class Initialized
INFO - 2016-10-17 15:07:23 --> Loader Class Initialized
INFO - 2016-10-17 15:07:23 --> Helper loaded: url_helper
INFO - 2016-10-17 15:07:23 --> Helper loaded: form_helper
INFO - 2016-10-17 15:07:23 --> Database Driver Class Initialized
INFO - 2016-10-17 15:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:07:23 --> Controller Class Initialized
INFO - 2016-10-17 15:07:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:07:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:07:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:07:23 --> Final output sent to browser
DEBUG - 2016-10-17 15:07:23 --> Total execution time: 0.0040
INFO - 2016-10-17 15:07:27 --> Config Class Initialized
INFO - 2016-10-17 15:07:27 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:07:27 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:07:27 --> Utf8 Class Initialized
INFO - 2016-10-17 15:07:27 --> URI Class Initialized
INFO - 2016-10-17 15:07:27 --> Router Class Initialized
INFO - 2016-10-17 15:07:27 --> Output Class Initialized
INFO - 2016-10-17 15:07:27 --> Security Class Initialized
DEBUG - 2016-10-17 15:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:07:27 --> Input Class Initialized
INFO - 2016-10-17 15:07:27 --> Language Class Initialized
INFO - 2016-10-17 15:07:27 --> Loader Class Initialized
INFO - 2016-10-17 15:07:27 --> Helper loaded: url_helper
INFO - 2016-10-17 15:07:27 --> Helper loaded: form_helper
INFO - 2016-10-17 15:07:27 --> Database Driver Class Initialized
INFO - 2016-10-17 15:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:07:27 --> Controller Class Initialized
INFO - 2016-10-17 15:07:27 --> Model Class Initialized
INFO - 2016-10-17 15:07:27 --> Final output sent to browser
DEBUG - 2016-10-17 15:07:27 --> Total execution time: 0.0056
INFO - 2016-10-17 15:08:11 --> Config Class Initialized
INFO - 2016-10-17 15:08:11 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:08:11 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:08:11 --> Utf8 Class Initialized
INFO - 2016-10-17 15:08:11 --> URI Class Initialized
DEBUG - 2016-10-17 15:08:11 --> No URI present. Default controller set.
INFO - 2016-10-17 15:08:11 --> Router Class Initialized
INFO - 2016-10-17 15:08:11 --> Output Class Initialized
INFO - 2016-10-17 15:08:11 --> Security Class Initialized
DEBUG - 2016-10-17 15:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:08:11 --> Input Class Initialized
INFO - 2016-10-17 15:08:11 --> Language Class Initialized
INFO - 2016-10-17 15:08:11 --> Loader Class Initialized
INFO - 2016-10-17 15:08:11 --> Helper loaded: url_helper
INFO - 2016-10-17 15:08:11 --> Helper loaded: form_helper
INFO - 2016-10-17 15:08:11 --> Database Driver Class Initialized
INFO - 2016-10-17 15:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:08:12 --> Controller Class Initialized
INFO - 2016-10-17 15:08:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:08:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:08:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:08:12 --> Final output sent to browser
DEBUG - 2016-10-17 15:08:12 --> Total execution time: 0.0081
INFO - 2016-10-17 15:08:17 --> Config Class Initialized
INFO - 2016-10-17 15:08:17 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:08:17 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:08:17 --> Utf8 Class Initialized
INFO - 2016-10-17 15:08:17 --> URI Class Initialized
INFO - 2016-10-17 15:08:17 --> Router Class Initialized
INFO - 2016-10-17 15:08:17 --> Output Class Initialized
INFO - 2016-10-17 15:08:17 --> Security Class Initialized
DEBUG - 2016-10-17 15:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:08:17 --> Input Class Initialized
INFO - 2016-10-17 15:08:17 --> Language Class Initialized
INFO - 2016-10-17 15:08:17 --> Loader Class Initialized
INFO - 2016-10-17 15:08:17 --> Helper loaded: url_helper
INFO - 2016-10-17 15:08:17 --> Helper loaded: form_helper
INFO - 2016-10-17 15:08:17 --> Database Driver Class Initialized
INFO - 2016-10-17 15:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:08:17 --> Controller Class Initialized
INFO - 2016-10-17 15:08:17 --> Model Class Initialized
INFO - 2016-10-17 15:08:17 --> Final output sent to browser
DEBUG - 2016-10-17 15:08:17 --> Total execution time: 0.0057
INFO - 2016-10-17 15:08:19 --> Config Class Initialized
INFO - 2016-10-17 15:08:19 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:08:19 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:08:19 --> Utf8 Class Initialized
INFO - 2016-10-17 15:08:19 --> URI Class Initialized
DEBUG - 2016-10-17 15:08:19 --> No URI present. Default controller set.
INFO - 2016-10-17 15:08:19 --> Router Class Initialized
INFO - 2016-10-17 15:08:19 --> Output Class Initialized
INFO - 2016-10-17 15:08:19 --> Security Class Initialized
DEBUG - 2016-10-17 15:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:08:19 --> Input Class Initialized
INFO - 2016-10-17 15:08:19 --> Language Class Initialized
INFO - 2016-10-17 15:08:19 --> Loader Class Initialized
INFO - 2016-10-17 15:08:19 --> Helper loaded: url_helper
INFO - 2016-10-17 15:08:19 --> Helper loaded: form_helper
INFO - 2016-10-17 15:08:19 --> Database Driver Class Initialized
INFO - 2016-10-17 15:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:08:19 --> Controller Class Initialized
INFO - 2016-10-17 15:08:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:08:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:08:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:08:19 --> Final output sent to browser
DEBUG - 2016-10-17 15:08:19 --> Total execution time: 0.0045
INFO - 2016-10-17 15:08:29 --> Config Class Initialized
INFO - 2016-10-17 15:08:29 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:08:29 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:08:29 --> Utf8 Class Initialized
INFO - 2016-10-17 15:08:29 --> URI Class Initialized
INFO - 2016-10-17 15:08:29 --> Router Class Initialized
INFO - 2016-10-17 15:08:29 --> Output Class Initialized
INFO - 2016-10-17 15:08:29 --> Security Class Initialized
DEBUG - 2016-10-17 15:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:08:29 --> Input Class Initialized
INFO - 2016-10-17 15:08:29 --> Language Class Initialized
INFO - 2016-10-17 15:08:29 --> Loader Class Initialized
INFO - 2016-10-17 15:08:29 --> Helper loaded: url_helper
INFO - 2016-10-17 15:08:29 --> Helper loaded: form_helper
INFO - 2016-10-17 15:08:29 --> Database Driver Class Initialized
INFO - 2016-10-17 15:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:08:29 --> Controller Class Initialized
INFO - 2016-10-17 15:08:29 --> Model Class Initialized
INFO - 2016-10-17 15:08:29 --> Final output sent to browser
DEBUG - 2016-10-17 15:08:29 --> Total execution time: 0.0068
INFO - 2016-10-17 15:08:29 --> Config Class Initialized
INFO - 2016-10-17 15:08:29 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:08:29 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:08:29 --> Utf8 Class Initialized
INFO - 2016-10-17 15:08:29 --> URI Class Initialized
DEBUG - 2016-10-17 15:08:29 --> No URI present. Default controller set.
INFO - 2016-10-17 15:08:29 --> Router Class Initialized
INFO - 2016-10-17 15:08:29 --> Output Class Initialized
INFO - 2016-10-17 15:08:29 --> Security Class Initialized
DEBUG - 2016-10-17 15:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:08:29 --> Input Class Initialized
INFO - 2016-10-17 15:08:29 --> Language Class Initialized
INFO - 2016-10-17 15:08:29 --> Loader Class Initialized
INFO - 2016-10-17 15:08:29 --> Helper loaded: url_helper
INFO - 2016-10-17 15:08:29 --> Helper loaded: form_helper
INFO - 2016-10-17 15:08:29 --> Database Driver Class Initialized
INFO - 2016-10-17 15:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:08:29 --> Controller Class Initialized
INFO - 2016-10-17 15:08:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:08:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 15:08:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 15:08:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:08:29 --> Final output sent to browser
DEBUG - 2016-10-17 15:08:29 --> Total execution time: 0.0040
INFO - 2016-10-17 15:08:41 --> Config Class Initialized
INFO - 2016-10-17 15:08:41 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:08:41 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:08:41 --> Utf8 Class Initialized
INFO - 2016-10-17 15:08:41 --> URI Class Initialized
INFO - 2016-10-17 15:08:41 --> Router Class Initialized
INFO - 2016-10-17 15:08:41 --> Output Class Initialized
INFO - 2016-10-17 15:08:41 --> Security Class Initialized
DEBUG - 2016-10-17 15:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:08:41 --> Input Class Initialized
INFO - 2016-10-17 15:08:41 --> Language Class Initialized
INFO - 2016-10-17 15:08:41 --> Loader Class Initialized
INFO - 2016-10-17 15:08:41 --> Helper loaded: url_helper
INFO - 2016-10-17 15:08:41 --> Helper loaded: form_helper
INFO - 2016-10-17 15:08:41 --> Database Driver Class Initialized
INFO - 2016-10-17 15:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:08:41 --> Controller Class Initialized
ERROR - 2016-10-17 15:08:41 --> Severity: Notice --> Undefined variable: name /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
ERROR - 2016-10-17 15:08:41 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
INFO - 2016-10-17 15:08:41 --> Config Class Initialized
INFO - 2016-10-17 15:08:41 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:08:41 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:08:41 --> Utf8 Class Initialized
INFO - 2016-10-17 15:08:41 --> URI Class Initialized
DEBUG - 2016-10-17 15:08:41 --> No URI present. Default controller set.
INFO - 2016-10-17 15:08:41 --> Router Class Initialized
INFO - 2016-10-17 15:08:41 --> Output Class Initialized
INFO - 2016-10-17 15:08:41 --> Security Class Initialized
DEBUG - 2016-10-17 15:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:08:41 --> Input Class Initialized
INFO - 2016-10-17 15:08:41 --> Language Class Initialized
INFO - 2016-10-17 15:08:41 --> Loader Class Initialized
INFO - 2016-10-17 15:08:41 --> Helper loaded: url_helper
INFO - 2016-10-17 15:08:41 --> Helper loaded: form_helper
INFO - 2016-10-17 15:08:41 --> Database Driver Class Initialized
INFO - 2016-10-17 15:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:08:41 --> Controller Class Initialized
INFO - 2016-10-17 15:08:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:08:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:08:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:08:41 --> Final output sent to browser
DEBUG - 2016-10-17 15:08:41 --> Total execution time: 0.0040
INFO - 2016-10-17 15:08:58 --> Config Class Initialized
INFO - 2016-10-17 15:08:58 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:08:58 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:08:58 --> Utf8 Class Initialized
INFO - 2016-10-17 15:08:58 --> URI Class Initialized
INFO - 2016-10-17 15:08:58 --> Router Class Initialized
INFO - 2016-10-17 15:08:58 --> Output Class Initialized
INFO - 2016-10-17 15:08:58 --> Security Class Initialized
DEBUG - 2016-10-17 15:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:08:58 --> Input Class Initialized
INFO - 2016-10-17 15:08:58 --> Language Class Initialized
INFO - 2016-10-17 15:08:58 --> Loader Class Initialized
INFO - 2016-10-17 15:08:58 --> Helper loaded: url_helper
INFO - 2016-10-17 15:08:58 --> Helper loaded: form_helper
INFO - 2016-10-17 15:08:58 --> Database Driver Class Initialized
INFO - 2016-10-17 15:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:08:58 --> Controller Class Initialized
INFO - 2016-10-17 15:08:58 --> Model Class Initialized
INFO - 2016-10-17 15:08:58 --> Final output sent to browser
DEBUG - 2016-10-17 15:08:58 --> Total execution time: 0.0057
INFO - 2016-10-17 15:08:59 --> Config Class Initialized
INFO - 2016-10-17 15:08:59 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:08:59 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:08:59 --> Utf8 Class Initialized
INFO - 2016-10-17 15:08:59 --> URI Class Initialized
DEBUG - 2016-10-17 15:08:59 --> No URI present. Default controller set.
INFO - 2016-10-17 15:08:59 --> Router Class Initialized
INFO - 2016-10-17 15:08:59 --> Output Class Initialized
INFO - 2016-10-17 15:08:59 --> Security Class Initialized
DEBUG - 2016-10-17 15:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:08:59 --> Input Class Initialized
INFO - 2016-10-17 15:08:59 --> Language Class Initialized
INFO - 2016-10-17 15:08:59 --> Loader Class Initialized
INFO - 2016-10-17 15:08:59 --> Helper loaded: url_helper
INFO - 2016-10-17 15:08:59 --> Helper loaded: form_helper
INFO - 2016-10-17 15:08:59 --> Database Driver Class Initialized
INFO - 2016-10-17 15:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:08:59 --> Controller Class Initialized
INFO - 2016-10-17 15:08:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:08:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:08:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:08:59 --> Final output sent to browser
DEBUG - 2016-10-17 15:08:59 --> Total execution time: 0.0044
INFO - 2016-10-17 15:09:10 --> Config Class Initialized
INFO - 2016-10-17 15:09:10 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:09:10 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:09:10 --> Utf8 Class Initialized
INFO - 2016-10-17 15:09:10 --> URI Class Initialized
INFO - 2016-10-17 15:09:10 --> Router Class Initialized
INFO - 2016-10-17 15:09:10 --> Output Class Initialized
INFO - 2016-10-17 15:09:10 --> Security Class Initialized
DEBUG - 2016-10-17 15:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:09:10 --> Input Class Initialized
INFO - 2016-10-17 15:09:10 --> Language Class Initialized
INFO - 2016-10-17 15:09:10 --> Loader Class Initialized
INFO - 2016-10-17 15:09:10 --> Helper loaded: url_helper
INFO - 2016-10-17 15:09:10 --> Helper loaded: form_helper
INFO - 2016-10-17 15:09:10 --> Database Driver Class Initialized
INFO - 2016-10-17 15:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:09:10 --> Controller Class Initialized
INFO - 2016-10-17 15:09:10 --> Model Class Initialized
INFO - 2016-10-17 15:09:10 --> Final output sent to browser
DEBUG - 2016-10-17 15:09:10 --> Total execution time: 0.0050
INFO - 2016-10-17 15:09:10 --> Config Class Initialized
INFO - 2016-10-17 15:09:10 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:09:10 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:09:10 --> Utf8 Class Initialized
INFO - 2016-10-17 15:09:10 --> URI Class Initialized
DEBUG - 2016-10-17 15:09:10 --> No URI present. Default controller set.
INFO - 2016-10-17 15:09:10 --> Router Class Initialized
INFO - 2016-10-17 15:09:10 --> Output Class Initialized
INFO - 2016-10-17 15:09:10 --> Security Class Initialized
DEBUG - 2016-10-17 15:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:09:10 --> Input Class Initialized
INFO - 2016-10-17 15:09:10 --> Language Class Initialized
INFO - 2016-10-17 15:09:10 --> Loader Class Initialized
INFO - 2016-10-17 15:09:10 --> Helper loaded: url_helper
INFO - 2016-10-17 15:09:10 --> Helper loaded: form_helper
INFO - 2016-10-17 15:09:10 --> Database Driver Class Initialized
INFO - 2016-10-17 15:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:09:10 --> Controller Class Initialized
INFO - 2016-10-17 15:09:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:09:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 15:09:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 15:09:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:09:10 --> Final output sent to browser
DEBUG - 2016-10-17 15:09:10 --> Total execution time: 0.0038
INFO - 2016-10-17 15:09:18 --> Config Class Initialized
INFO - 2016-10-17 15:09:18 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:09:18 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:09:18 --> Utf8 Class Initialized
INFO - 2016-10-17 15:09:18 --> URI Class Initialized
INFO - 2016-10-17 15:09:18 --> Router Class Initialized
INFO - 2016-10-17 15:09:18 --> Output Class Initialized
INFO - 2016-10-17 15:09:18 --> Security Class Initialized
DEBUG - 2016-10-17 15:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:09:18 --> Input Class Initialized
INFO - 2016-10-17 15:09:18 --> Language Class Initialized
INFO - 2016-10-17 15:09:18 --> Loader Class Initialized
INFO - 2016-10-17 15:09:18 --> Helper loaded: url_helper
INFO - 2016-10-17 15:09:18 --> Helper loaded: form_helper
INFO - 2016-10-17 15:09:18 --> Database Driver Class Initialized
INFO - 2016-10-17 15:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:09:18 --> Controller Class Initialized
ERROR - 2016-10-17 15:09:18 --> Severity: Notice --> Undefined variable: name /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
ERROR - 2016-10-17 15:09:18 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
INFO - 2016-10-17 15:09:18 --> Config Class Initialized
INFO - 2016-10-17 15:09:18 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:09:18 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:09:18 --> Utf8 Class Initialized
INFO - 2016-10-17 15:09:18 --> URI Class Initialized
DEBUG - 2016-10-17 15:09:18 --> No URI present. Default controller set.
INFO - 2016-10-17 15:09:18 --> Router Class Initialized
INFO - 2016-10-17 15:09:18 --> Output Class Initialized
INFO - 2016-10-17 15:09:18 --> Security Class Initialized
DEBUG - 2016-10-17 15:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:09:18 --> Input Class Initialized
INFO - 2016-10-17 15:09:18 --> Language Class Initialized
INFO - 2016-10-17 15:09:18 --> Loader Class Initialized
INFO - 2016-10-17 15:09:18 --> Helper loaded: url_helper
INFO - 2016-10-17 15:09:18 --> Helper loaded: form_helper
INFO - 2016-10-17 15:09:18 --> Database Driver Class Initialized
INFO - 2016-10-17 15:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:09:18 --> Controller Class Initialized
INFO - 2016-10-17 15:09:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:09:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:09:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:09:18 --> Final output sent to browser
DEBUG - 2016-10-17 15:09:18 --> Total execution time: 0.0081
INFO - 2016-10-17 15:09:54 --> Config Class Initialized
INFO - 2016-10-17 15:09:54 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:09:54 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:09:54 --> Utf8 Class Initialized
INFO - 2016-10-17 15:09:54 --> URI Class Initialized
DEBUG - 2016-10-17 15:09:54 --> No URI present. Default controller set.
INFO - 2016-10-17 15:09:54 --> Router Class Initialized
INFO - 2016-10-17 15:09:54 --> Output Class Initialized
INFO - 2016-10-17 15:09:54 --> Security Class Initialized
DEBUG - 2016-10-17 15:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:09:54 --> Input Class Initialized
INFO - 2016-10-17 15:09:54 --> Language Class Initialized
INFO - 2016-10-17 15:09:54 --> Loader Class Initialized
INFO - 2016-10-17 15:09:54 --> Helper loaded: url_helper
INFO - 2016-10-17 15:09:54 --> Helper loaded: form_helper
INFO - 2016-10-17 15:09:54 --> Database Driver Class Initialized
INFO - 2016-10-17 15:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:09:54 --> Controller Class Initialized
INFO - 2016-10-17 15:09:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:09:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:09:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:09:54 --> Final output sent to browser
DEBUG - 2016-10-17 15:09:54 --> Total execution time: 0.0055
INFO - 2016-10-17 15:11:09 --> Config Class Initialized
INFO - 2016-10-17 15:11:09 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:11:09 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:11:09 --> Utf8 Class Initialized
INFO - 2016-10-17 15:11:09 --> URI Class Initialized
INFO - 2016-10-17 15:11:09 --> Router Class Initialized
INFO - 2016-10-17 15:11:09 --> Output Class Initialized
INFO - 2016-10-17 15:11:09 --> Security Class Initialized
DEBUG - 2016-10-17 15:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:11:09 --> Input Class Initialized
INFO - 2016-10-17 15:11:09 --> Language Class Initialized
INFO - 2016-10-17 15:11:09 --> Loader Class Initialized
INFO - 2016-10-17 15:11:09 --> Helper loaded: url_helper
INFO - 2016-10-17 15:11:09 --> Helper loaded: form_helper
INFO - 2016-10-17 15:11:09 --> Database Driver Class Initialized
INFO - 2016-10-17 15:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:11:09 --> Controller Class Initialized
INFO - 2016-10-17 15:11:09 --> Model Class Initialized
INFO - 2016-10-17 15:11:09 --> Final output sent to browser
DEBUG - 2016-10-17 15:11:09 --> Total execution time: 0.0054
INFO - 2016-10-17 15:11:09 --> Config Class Initialized
INFO - 2016-10-17 15:11:09 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:11:09 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:11:09 --> Utf8 Class Initialized
INFO - 2016-10-17 15:11:09 --> URI Class Initialized
DEBUG - 2016-10-17 15:11:09 --> No URI present. Default controller set.
INFO - 2016-10-17 15:11:09 --> Router Class Initialized
INFO - 2016-10-17 15:11:09 --> Output Class Initialized
INFO - 2016-10-17 15:11:09 --> Security Class Initialized
DEBUG - 2016-10-17 15:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:11:09 --> Input Class Initialized
INFO - 2016-10-17 15:11:09 --> Language Class Initialized
INFO - 2016-10-17 15:11:09 --> Loader Class Initialized
INFO - 2016-10-17 15:11:09 --> Helper loaded: url_helper
INFO - 2016-10-17 15:11:09 --> Helper loaded: form_helper
INFO - 2016-10-17 15:11:09 --> Database Driver Class Initialized
INFO - 2016-10-17 15:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:11:09 --> Controller Class Initialized
INFO - 2016-10-17 15:11:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:11:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 15:11:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 15:11:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:11:09 --> Final output sent to browser
DEBUG - 2016-10-17 15:11:09 --> Total execution time: 0.0042
INFO - 2016-10-17 15:11:11 --> Config Class Initialized
INFO - 2016-10-17 15:11:11 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:11:11 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:11:11 --> Utf8 Class Initialized
INFO - 2016-10-17 15:11:11 --> URI Class Initialized
INFO - 2016-10-17 15:11:11 --> Router Class Initialized
INFO - 2016-10-17 15:11:11 --> Output Class Initialized
INFO - 2016-10-17 15:11:11 --> Security Class Initialized
DEBUG - 2016-10-17 15:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:11:11 --> Input Class Initialized
INFO - 2016-10-17 15:11:11 --> Language Class Initialized
INFO - 2016-10-17 15:11:11 --> Loader Class Initialized
INFO - 2016-10-17 15:11:11 --> Helper loaded: url_helper
INFO - 2016-10-17 15:11:11 --> Helper loaded: form_helper
INFO - 2016-10-17 15:11:11 --> Database Driver Class Initialized
INFO - 2016-10-17 15:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:11:11 --> Controller Class Initialized
ERROR - 2016-10-17 15:11:11 --> Severity: Notice --> Undefined variable: name /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
ERROR - 2016-10-17 15:11:11 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
INFO - 2016-10-17 15:11:11 --> Config Class Initialized
INFO - 2016-10-17 15:11:11 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:11:11 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:11:11 --> Utf8 Class Initialized
INFO - 2016-10-17 15:11:11 --> URI Class Initialized
DEBUG - 2016-10-17 15:11:11 --> No URI present. Default controller set.
INFO - 2016-10-17 15:11:11 --> Router Class Initialized
INFO - 2016-10-17 15:11:11 --> Output Class Initialized
INFO - 2016-10-17 15:11:11 --> Security Class Initialized
DEBUG - 2016-10-17 15:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:11:11 --> Input Class Initialized
INFO - 2016-10-17 15:11:11 --> Language Class Initialized
INFO - 2016-10-17 15:11:11 --> Loader Class Initialized
INFO - 2016-10-17 15:11:11 --> Helper loaded: url_helper
INFO - 2016-10-17 15:11:11 --> Helper loaded: form_helper
INFO - 2016-10-17 15:11:11 --> Database Driver Class Initialized
INFO - 2016-10-17 15:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:11:11 --> Controller Class Initialized
INFO - 2016-10-17 15:11:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:11:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:11:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:11:11 --> Final output sent to browser
DEBUG - 2016-10-17 15:11:11 --> Total execution time: 0.0056
INFO - 2016-10-17 15:11:18 --> Config Class Initialized
INFO - 2016-10-17 15:11:18 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:11:18 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:11:18 --> Utf8 Class Initialized
INFO - 2016-10-17 15:11:18 --> URI Class Initialized
INFO - 2016-10-17 15:11:18 --> Router Class Initialized
INFO - 2016-10-17 15:11:18 --> Output Class Initialized
INFO - 2016-10-17 15:11:18 --> Security Class Initialized
DEBUG - 2016-10-17 15:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:11:18 --> Input Class Initialized
INFO - 2016-10-17 15:11:18 --> Language Class Initialized
INFO - 2016-10-17 15:11:18 --> Loader Class Initialized
INFO - 2016-10-17 15:11:18 --> Helper loaded: url_helper
INFO - 2016-10-17 15:11:18 --> Helper loaded: form_helper
INFO - 2016-10-17 15:11:18 --> Database Driver Class Initialized
INFO - 2016-10-17 15:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:11:18 --> Controller Class Initialized
INFO - 2016-10-17 15:11:18 --> Model Class Initialized
INFO - 2016-10-17 15:11:18 --> Final output sent to browser
DEBUG - 2016-10-17 15:11:18 --> Total execution time: 0.0088
INFO - 2016-10-17 15:11:56 --> Config Class Initialized
INFO - 2016-10-17 15:11:56 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:11:56 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:11:56 --> Utf8 Class Initialized
INFO - 2016-10-17 15:11:56 --> URI Class Initialized
DEBUG - 2016-10-17 15:11:56 --> No URI present. Default controller set.
INFO - 2016-10-17 15:11:56 --> Router Class Initialized
INFO - 2016-10-17 15:11:56 --> Output Class Initialized
INFO - 2016-10-17 15:11:56 --> Security Class Initialized
DEBUG - 2016-10-17 15:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:11:56 --> Input Class Initialized
INFO - 2016-10-17 15:11:56 --> Language Class Initialized
INFO - 2016-10-17 15:11:56 --> Loader Class Initialized
INFO - 2016-10-17 15:11:56 --> Helper loaded: url_helper
INFO - 2016-10-17 15:11:56 --> Helper loaded: form_helper
INFO - 2016-10-17 15:11:56 --> Database Driver Class Initialized
INFO - 2016-10-17 15:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:11:56 --> Controller Class Initialized
INFO - 2016-10-17 15:11:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:11:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:11:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:11:56 --> Final output sent to browser
DEBUG - 2016-10-17 15:11:56 --> Total execution time: 0.0049
INFO - 2016-10-17 15:16:31 --> Config Class Initialized
INFO - 2016-10-17 15:16:31 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:16:31 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:16:31 --> Utf8 Class Initialized
INFO - 2016-10-17 15:16:31 --> URI Class Initialized
DEBUG - 2016-10-17 15:16:31 --> No URI present. Default controller set.
INFO - 2016-10-17 15:16:31 --> Router Class Initialized
INFO - 2016-10-17 15:16:31 --> Output Class Initialized
INFO - 2016-10-17 15:16:31 --> Security Class Initialized
DEBUG - 2016-10-17 15:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:16:31 --> Input Class Initialized
INFO - 2016-10-17 15:16:31 --> Language Class Initialized
INFO - 2016-10-17 15:16:31 --> Loader Class Initialized
INFO - 2016-10-17 15:16:31 --> Helper loaded: url_helper
INFO - 2016-10-17 15:16:31 --> Helper loaded: form_helper
INFO - 2016-10-17 15:16:31 --> Database Driver Class Initialized
INFO - 2016-10-17 15:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:16:31 --> Controller Class Initialized
INFO - 2016-10-17 15:16:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:16:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:16:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:16:31 --> Final output sent to browser
DEBUG - 2016-10-17 15:16:31 --> Total execution time: 0.0058
INFO - 2016-10-17 15:16:35 --> Config Class Initialized
INFO - 2016-10-17 15:16:35 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:16:35 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:16:35 --> Utf8 Class Initialized
INFO - 2016-10-17 15:16:35 --> URI Class Initialized
INFO - 2016-10-17 15:16:35 --> Router Class Initialized
INFO - 2016-10-17 15:16:35 --> Output Class Initialized
INFO - 2016-10-17 15:16:35 --> Security Class Initialized
DEBUG - 2016-10-17 15:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:16:35 --> Input Class Initialized
INFO - 2016-10-17 15:16:35 --> Language Class Initialized
INFO - 2016-10-17 15:16:35 --> Loader Class Initialized
INFO - 2016-10-17 15:16:35 --> Helper loaded: url_helper
INFO - 2016-10-17 15:16:35 --> Helper loaded: form_helper
INFO - 2016-10-17 15:16:35 --> Database Driver Class Initialized
INFO - 2016-10-17 15:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:16:35 --> Controller Class Initialized
INFO - 2016-10-17 15:16:35 --> Model Class Initialized
INFO - 2016-10-17 15:16:35 --> Final output sent to browser
DEBUG - 2016-10-17 15:16:35 --> Total execution time: 0.0061
INFO - 2016-10-17 15:17:04 --> Config Class Initialized
INFO - 2016-10-17 15:17:04 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:17:04 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:17:04 --> Utf8 Class Initialized
INFO - 2016-10-17 15:17:04 --> URI Class Initialized
DEBUG - 2016-10-17 15:17:04 --> No URI present. Default controller set.
INFO - 2016-10-17 15:17:04 --> Router Class Initialized
INFO - 2016-10-17 15:17:04 --> Output Class Initialized
INFO - 2016-10-17 15:17:04 --> Security Class Initialized
DEBUG - 2016-10-17 15:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:17:04 --> Input Class Initialized
INFO - 2016-10-17 15:17:04 --> Language Class Initialized
INFO - 2016-10-17 15:17:04 --> Loader Class Initialized
INFO - 2016-10-17 15:17:04 --> Helper loaded: url_helper
INFO - 2016-10-17 15:17:04 --> Helper loaded: form_helper
INFO - 2016-10-17 15:17:04 --> Database Driver Class Initialized
INFO - 2016-10-17 15:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:17:04 --> Controller Class Initialized
INFO - 2016-10-17 15:17:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:17:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:17:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:17:04 --> Final output sent to browser
DEBUG - 2016-10-17 15:17:04 --> Total execution time: 0.0079
INFO - 2016-10-17 15:23:18 --> Config Class Initialized
INFO - 2016-10-17 15:23:18 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:23:18 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:23:18 --> Utf8 Class Initialized
INFO - 2016-10-17 15:23:18 --> URI Class Initialized
DEBUG - 2016-10-17 15:23:18 --> No URI present. Default controller set.
INFO - 2016-10-17 15:23:18 --> Router Class Initialized
INFO - 2016-10-17 15:23:18 --> Output Class Initialized
INFO - 2016-10-17 15:23:18 --> Security Class Initialized
DEBUG - 2016-10-17 15:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:23:18 --> Input Class Initialized
INFO - 2016-10-17 15:23:18 --> Language Class Initialized
INFO - 2016-10-17 15:23:18 --> Loader Class Initialized
INFO - 2016-10-17 15:23:18 --> Helper loaded: url_helper
INFO - 2016-10-17 15:23:18 --> Helper loaded: form_helper
INFO - 2016-10-17 15:23:18 --> Database Driver Class Initialized
INFO - 2016-10-17 15:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:23:18 --> Controller Class Initialized
INFO - 2016-10-17 15:23:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:23:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:23:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:23:18 --> Final output sent to browser
DEBUG - 2016-10-17 15:23:18 --> Total execution time: 0.0053
INFO - 2016-10-17 15:25:22 --> Config Class Initialized
INFO - 2016-10-17 15:25:22 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:25:22 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:25:22 --> Utf8 Class Initialized
INFO - 2016-10-17 15:25:22 --> URI Class Initialized
DEBUG - 2016-10-17 15:25:22 --> No URI present. Default controller set.
INFO - 2016-10-17 15:25:22 --> Router Class Initialized
INFO - 2016-10-17 15:25:22 --> Output Class Initialized
INFO - 2016-10-17 15:25:22 --> Security Class Initialized
DEBUG - 2016-10-17 15:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:25:22 --> Input Class Initialized
INFO - 2016-10-17 15:25:22 --> Language Class Initialized
INFO - 2016-10-17 15:25:22 --> Loader Class Initialized
INFO - 2016-10-17 15:25:22 --> Helper loaded: url_helper
INFO - 2016-10-17 15:25:22 --> Helper loaded: form_helper
INFO - 2016-10-17 15:25:22 --> Database Driver Class Initialized
INFO - 2016-10-17 15:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:25:22 --> Controller Class Initialized
INFO - 2016-10-17 15:25:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:25:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:25:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:25:22 --> Final output sent to browser
DEBUG - 2016-10-17 15:25:22 --> Total execution time: 0.0056
INFO - 2016-10-17 15:25:25 --> Config Class Initialized
INFO - 2016-10-17 15:25:25 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:25:25 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:25:25 --> Utf8 Class Initialized
INFO - 2016-10-17 15:25:25 --> URI Class Initialized
INFO - 2016-10-17 15:25:25 --> Router Class Initialized
INFO - 2016-10-17 15:25:25 --> Output Class Initialized
INFO - 2016-10-17 15:25:25 --> Security Class Initialized
DEBUG - 2016-10-17 15:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:25:25 --> Input Class Initialized
INFO - 2016-10-17 15:25:25 --> Language Class Initialized
INFO - 2016-10-17 15:25:25 --> Loader Class Initialized
INFO - 2016-10-17 15:25:25 --> Helper loaded: url_helper
INFO - 2016-10-17 15:25:25 --> Helper loaded: form_helper
INFO - 2016-10-17 15:25:26 --> Config Class Initialized
INFO - 2016-10-17 15:25:26 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:25:26 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:25:26 --> Utf8 Class Initialized
INFO - 2016-10-17 15:25:26 --> URI Class Initialized
INFO - 2016-10-17 15:25:26 --> Router Class Initialized
INFO - 2016-10-17 15:25:26 --> Output Class Initialized
INFO - 2016-10-17 15:25:26 --> Security Class Initialized
DEBUG - 2016-10-17 15:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:25:26 --> Input Class Initialized
INFO - 2016-10-17 15:25:26 --> Language Class Initialized
INFO - 2016-10-17 15:25:26 --> Loader Class Initialized
INFO - 2016-10-17 15:25:26 --> Helper loaded: url_helper
INFO - 2016-10-17 15:25:26 --> Helper loaded: form_helper
INFO - 2016-10-17 15:25:26 --> Database Driver Class Initialized
INFO - 2016-10-17 15:25:26 --> Database Driver Class Initialized
INFO - 2016-10-17 15:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:25:26 --> Controller Class Initialized
INFO - 2016-10-17 15:25:26 --> Model Class Initialized
INFO - 2016-10-17 15:25:26 --> Final output sent to browser
DEBUG - 2016-10-17 15:25:26 --> Total execution time: 0.0060
INFO - 2016-10-17 15:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:25:26 --> Controller Class Initialized
INFO - 2016-10-17 15:25:26 --> Model Class Initialized
INFO - 2016-10-17 15:25:26 --> Final output sent to browser
DEBUG - 2016-10-17 15:25:26 --> Total execution time: 0.0101
INFO - 2016-10-17 15:25:30 --> Config Class Initialized
INFO - 2016-10-17 15:25:30 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:25:30 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:25:30 --> Utf8 Class Initialized
INFO - 2016-10-17 15:25:30 --> URI Class Initialized
DEBUG - 2016-10-17 15:25:30 --> No URI present. Default controller set.
INFO - 2016-10-17 15:25:30 --> Router Class Initialized
INFO - 2016-10-17 15:25:30 --> Output Class Initialized
INFO - 2016-10-17 15:25:30 --> Security Class Initialized
DEBUG - 2016-10-17 15:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:25:30 --> Input Class Initialized
INFO - 2016-10-17 15:25:30 --> Language Class Initialized
INFO - 2016-10-17 15:25:30 --> Loader Class Initialized
INFO - 2016-10-17 15:25:30 --> Helper loaded: url_helper
INFO - 2016-10-17 15:25:30 --> Helper loaded: form_helper
INFO - 2016-10-17 15:25:30 --> Database Driver Class Initialized
INFO - 2016-10-17 15:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:25:30 --> Controller Class Initialized
INFO - 2016-10-17 15:25:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:25:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:25:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:25:30 --> Final output sent to browser
DEBUG - 2016-10-17 15:25:30 --> Total execution time: 0.0045
INFO - 2016-10-17 15:25:42 --> Config Class Initialized
INFO - 2016-10-17 15:25:42 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:25:42 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:25:42 --> Utf8 Class Initialized
INFO - 2016-10-17 15:25:42 --> URI Class Initialized
DEBUG - 2016-10-17 15:25:42 --> No URI present. Default controller set.
INFO - 2016-10-17 15:25:42 --> Router Class Initialized
INFO - 2016-10-17 15:25:42 --> Output Class Initialized
INFO - 2016-10-17 15:25:42 --> Security Class Initialized
DEBUG - 2016-10-17 15:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:25:42 --> Input Class Initialized
INFO - 2016-10-17 15:25:42 --> Language Class Initialized
INFO - 2016-10-17 15:25:42 --> Loader Class Initialized
INFO - 2016-10-17 15:25:42 --> Helper loaded: url_helper
INFO - 2016-10-17 15:25:42 --> Helper loaded: form_helper
INFO - 2016-10-17 15:25:42 --> Database Driver Class Initialized
INFO - 2016-10-17 15:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:25:42 --> Controller Class Initialized
INFO - 2016-10-17 15:25:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:25:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:25:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:25:42 --> Final output sent to browser
DEBUG - 2016-10-17 15:25:42 --> Total execution time: 0.0139
INFO - 2016-10-17 15:25:46 --> Config Class Initialized
INFO - 2016-10-17 15:25:46 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:25:46 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:25:46 --> Utf8 Class Initialized
INFO - 2016-10-17 15:25:46 --> URI Class Initialized
INFO - 2016-10-17 15:25:46 --> Router Class Initialized
INFO - 2016-10-17 15:25:46 --> Output Class Initialized
INFO - 2016-10-17 15:25:46 --> Security Class Initialized
DEBUG - 2016-10-17 15:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:25:46 --> Input Class Initialized
INFO - 2016-10-17 15:25:46 --> Language Class Initialized
INFO - 2016-10-17 15:25:46 --> Loader Class Initialized
INFO - 2016-10-17 15:25:46 --> Helper loaded: url_helper
INFO - 2016-10-17 15:25:46 --> Helper loaded: form_helper
INFO - 2016-10-17 15:25:46 --> Database Driver Class Initialized
INFO - 2016-10-17 15:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:25:46 --> Controller Class Initialized
INFO - 2016-10-17 15:25:46 --> Model Class Initialized
INFO - 2016-10-17 15:25:46 --> Final output sent to browser
DEBUG - 2016-10-17 15:25:46 --> Total execution time: 0.0055
INFO - 2016-10-17 15:25:49 --> Config Class Initialized
INFO - 2016-10-17 15:25:49 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:25:49 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:25:49 --> Utf8 Class Initialized
INFO - 2016-10-17 15:25:49 --> URI Class Initialized
DEBUG - 2016-10-17 15:25:49 --> No URI present. Default controller set.
INFO - 2016-10-17 15:25:49 --> Router Class Initialized
INFO - 2016-10-17 15:25:49 --> Output Class Initialized
INFO - 2016-10-17 15:25:49 --> Security Class Initialized
DEBUG - 2016-10-17 15:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:25:49 --> Input Class Initialized
INFO - 2016-10-17 15:25:49 --> Language Class Initialized
INFO - 2016-10-17 15:25:49 --> Loader Class Initialized
INFO - 2016-10-17 15:25:49 --> Helper loaded: url_helper
INFO - 2016-10-17 15:25:49 --> Helper loaded: form_helper
INFO - 2016-10-17 15:25:49 --> Database Driver Class Initialized
INFO - 2016-10-17 15:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:25:49 --> Controller Class Initialized
INFO - 2016-10-17 15:25:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:25:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:25:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:25:49 --> Final output sent to browser
DEBUG - 2016-10-17 15:25:49 --> Total execution time: 0.0106
INFO - 2016-10-17 15:25:54 --> Config Class Initialized
INFO - 2016-10-17 15:25:54 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:25:54 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:25:54 --> Utf8 Class Initialized
INFO - 2016-10-17 15:25:54 --> URI Class Initialized
INFO - 2016-10-17 15:25:54 --> Router Class Initialized
INFO - 2016-10-17 15:25:54 --> Output Class Initialized
INFO - 2016-10-17 15:25:54 --> Security Class Initialized
DEBUG - 2016-10-17 15:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:25:54 --> Input Class Initialized
INFO - 2016-10-17 15:25:54 --> Language Class Initialized
INFO - 2016-10-17 15:25:54 --> Loader Class Initialized
INFO - 2016-10-17 15:25:54 --> Helper loaded: url_helper
INFO - 2016-10-17 15:25:54 --> Helper loaded: form_helper
INFO - 2016-10-17 15:25:54 --> Database Driver Class Initialized
INFO - 2016-10-17 15:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:25:54 --> Controller Class Initialized
INFO - 2016-10-17 15:25:54 --> Model Class Initialized
INFO - 2016-10-17 15:25:54 --> Final output sent to browser
DEBUG - 2016-10-17 15:25:54 --> Total execution time: 0.0081
INFO - 2016-10-17 15:25:55 --> Config Class Initialized
INFO - 2016-10-17 15:25:55 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:25:55 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:25:55 --> Utf8 Class Initialized
INFO - 2016-10-17 15:25:55 --> URI Class Initialized
DEBUG - 2016-10-17 15:25:55 --> No URI present. Default controller set.
INFO - 2016-10-17 15:25:55 --> Router Class Initialized
INFO - 2016-10-17 15:25:55 --> Output Class Initialized
INFO - 2016-10-17 15:25:55 --> Security Class Initialized
DEBUG - 2016-10-17 15:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:25:55 --> Input Class Initialized
INFO - 2016-10-17 15:25:55 --> Language Class Initialized
INFO - 2016-10-17 15:25:55 --> Loader Class Initialized
INFO - 2016-10-17 15:25:55 --> Helper loaded: url_helper
INFO - 2016-10-17 15:25:55 --> Helper loaded: form_helper
INFO - 2016-10-17 15:25:55 --> Database Driver Class Initialized
INFO - 2016-10-17 15:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:25:55 --> Controller Class Initialized
INFO - 2016-10-17 15:25:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:25:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 15:25:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 15:25:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:25:55 --> Final output sent to browser
DEBUG - 2016-10-17 15:25:55 --> Total execution time: 0.0044
INFO - 2016-10-17 15:25:57 --> Config Class Initialized
INFO - 2016-10-17 15:25:57 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:25:57 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:25:57 --> Utf8 Class Initialized
INFO - 2016-10-17 15:25:57 --> URI Class Initialized
INFO - 2016-10-17 15:25:57 --> Router Class Initialized
INFO - 2016-10-17 15:25:57 --> Output Class Initialized
INFO - 2016-10-17 15:25:57 --> Security Class Initialized
DEBUG - 2016-10-17 15:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:25:57 --> Input Class Initialized
INFO - 2016-10-17 15:25:57 --> Language Class Initialized
INFO - 2016-10-17 15:25:57 --> Loader Class Initialized
INFO - 2016-10-17 15:25:57 --> Helper loaded: url_helper
INFO - 2016-10-17 15:25:57 --> Helper loaded: form_helper
INFO - 2016-10-17 15:25:57 --> Database Driver Class Initialized
INFO - 2016-10-17 15:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:25:57 --> Controller Class Initialized
ERROR - 2016-10-17 15:25:57 --> Severity: Notice --> Undefined variable: name /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
ERROR - 2016-10-17 15:25:57 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
INFO - 2016-10-17 15:25:57 --> Config Class Initialized
INFO - 2016-10-17 15:25:57 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:25:57 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:25:57 --> Utf8 Class Initialized
INFO - 2016-10-17 15:25:57 --> URI Class Initialized
DEBUG - 2016-10-17 15:25:57 --> No URI present. Default controller set.
INFO - 2016-10-17 15:25:57 --> Router Class Initialized
INFO - 2016-10-17 15:25:57 --> Output Class Initialized
INFO - 2016-10-17 15:25:57 --> Security Class Initialized
DEBUG - 2016-10-17 15:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:25:57 --> Input Class Initialized
INFO - 2016-10-17 15:25:57 --> Language Class Initialized
INFO - 2016-10-17 15:25:57 --> Loader Class Initialized
INFO - 2016-10-17 15:25:57 --> Helper loaded: url_helper
INFO - 2016-10-17 15:25:57 --> Helper loaded: form_helper
INFO - 2016-10-17 15:25:57 --> Database Driver Class Initialized
INFO - 2016-10-17 15:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:25:57 --> Controller Class Initialized
INFO - 2016-10-17 15:25:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:25:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:25:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:25:57 --> Final output sent to browser
DEBUG - 2016-10-17 15:25:57 --> Total execution time: 0.0041
INFO - 2016-10-17 15:26:25 --> Config Class Initialized
INFO - 2016-10-17 15:26:25 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:26:25 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:26:25 --> Utf8 Class Initialized
INFO - 2016-10-17 15:26:25 --> URI Class Initialized
DEBUG - 2016-10-17 15:26:25 --> No URI present. Default controller set.
INFO - 2016-10-17 15:26:25 --> Router Class Initialized
INFO - 2016-10-17 15:26:25 --> Output Class Initialized
INFO - 2016-10-17 15:26:25 --> Security Class Initialized
DEBUG - 2016-10-17 15:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:26:25 --> Input Class Initialized
INFO - 2016-10-17 15:26:25 --> Language Class Initialized
INFO - 2016-10-17 15:26:25 --> Loader Class Initialized
INFO - 2016-10-17 15:26:25 --> Helper loaded: url_helper
INFO - 2016-10-17 15:26:25 --> Helper loaded: form_helper
INFO - 2016-10-17 15:26:25 --> Database Driver Class Initialized
INFO - 2016-10-17 15:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:26:25 --> Controller Class Initialized
INFO - 2016-10-17 15:26:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:26:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:26:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:26:25 --> Final output sent to browser
DEBUG - 2016-10-17 15:26:25 --> Total execution time: 0.0050
INFO - 2016-10-17 15:36:27 --> Config Class Initialized
INFO - 2016-10-17 15:36:27 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:36:27 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:36:27 --> Utf8 Class Initialized
INFO - 2016-10-17 15:36:27 --> URI Class Initialized
DEBUG - 2016-10-17 15:36:27 --> No URI present. Default controller set.
INFO - 2016-10-17 15:36:27 --> Router Class Initialized
INFO - 2016-10-17 15:36:27 --> Output Class Initialized
INFO - 2016-10-17 15:36:27 --> Security Class Initialized
DEBUG - 2016-10-17 15:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:36:27 --> Input Class Initialized
INFO - 2016-10-17 15:36:27 --> Language Class Initialized
INFO - 2016-10-17 15:36:27 --> Loader Class Initialized
INFO - 2016-10-17 15:36:27 --> Helper loaded: url_helper
INFO - 2016-10-17 15:36:27 --> Helper loaded: form_helper
INFO - 2016-10-17 15:36:27 --> Database Driver Class Initialized
INFO - 2016-10-17 15:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:36:27 --> Controller Class Initialized
INFO - 2016-10-17 15:36:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:36:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:36:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:36:27 --> Final output sent to browser
DEBUG - 2016-10-17 15:36:27 --> Total execution time: 0.0061
INFO - 2016-10-17 15:37:06 --> Config Class Initialized
INFO - 2016-10-17 15:37:06 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:37:06 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:37:06 --> Utf8 Class Initialized
INFO - 2016-10-17 15:37:06 --> URI Class Initialized
DEBUG - 2016-10-17 15:37:06 --> No URI present. Default controller set.
INFO - 2016-10-17 15:37:06 --> Router Class Initialized
INFO - 2016-10-17 15:37:06 --> Output Class Initialized
INFO - 2016-10-17 15:37:06 --> Security Class Initialized
DEBUG - 2016-10-17 15:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:37:06 --> Input Class Initialized
INFO - 2016-10-17 15:37:06 --> Language Class Initialized
INFO - 2016-10-17 15:37:06 --> Loader Class Initialized
INFO - 2016-10-17 15:37:06 --> Helper loaded: url_helper
INFO - 2016-10-17 15:37:06 --> Helper loaded: form_helper
INFO - 2016-10-17 15:37:06 --> Database Driver Class Initialized
INFO - 2016-10-17 15:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:37:06 --> Controller Class Initialized
INFO - 2016-10-17 15:37:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:37:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:37:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:37:06 --> Final output sent to browser
DEBUG - 2016-10-17 15:37:06 --> Total execution time: 0.0085
INFO - 2016-10-17 15:37:15 --> Config Class Initialized
INFO - 2016-10-17 15:37:15 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:37:15 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:37:15 --> Utf8 Class Initialized
INFO - 2016-10-17 15:37:15 --> URI Class Initialized
INFO - 2016-10-17 15:37:15 --> Router Class Initialized
INFO - 2016-10-17 15:37:15 --> Output Class Initialized
INFO - 2016-10-17 15:37:15 --> Security Class Initialized
DEBUG - 2016-10-17 15:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:37:15 --> Input Class Initialized
INFO - 2016-10-17 15:37:15 --> Language Class Initialized
INFO - 2016-10-17 15:37:15 --> Loader Class Initialized
INFO - 2016-10-17 15:37:15 --> Helper loaded: url_helper
INFO - 2016-10-17 15:37:15 --> Helper loaded: form_helper
INFO - 2016-10-17 15:37:15 --> Database Driver Class Initialized
INFO - 2016-10-17 15:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:37:15 --> Controller Class Initialized
INFO - 2016-10-17 15:37:15 --> Model Class Initialized
INFO - 2016-10-17 15:37:15 --> Final output sent to browser
DEBUG - 2016-10-17 15:37:15 --> Total execution time: 0.0055
INFO - 2016-10-17 15:37:56 --> Config Class Initialized
INFO - 2016-10-17 15:37:56 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:37:56 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:37:56 --> Utf8 Class Initialized
INFO - 2016-10-17 15:37:56 --> URI Class Initialized
DEBUG - 2016-10-17 15:37:56 --> No URI present. Default controller set.
INFO - 2016-10-17 15:37:56 --> Router Class Initialized
INFO - 2016-10-17 15:37:56 --> Output Class Initialized
INFO - 2016-10-17 15:37:56 --> Security Class Initialized
DEBUG - 2016-10-17 15:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:37:56 --> Input Class Initialized
INFO - 2016-10-17 15:37:56 --> Language Class Initialized
INFO - 2016-10-17 15:37:56 --> Loader Class Initialized
INFO - 2016-10-17 15:37:56 --> Helper loaded: url_helper
INFO - 2016-10-17 15:37:56 --> Helper loaded: form_helper
INFO - 2016-10-17 15:37:56 --> Database Driver Class Initialized
INFO - 2016-10-17 15:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:37:56 --> Controller Class Initialized
INFO - 2016-10-17 15:37:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:37:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:37:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:37:56 --> Final output sent to browser
DEBUG - 2016-10-17 15:37:56 --> Total execution time: 0.0049
INFO - 2016-10-17 15:41:57 --> Config Class Initialized
INFO - 2016-10-17 15:41:57 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:41:57 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:41:57 --> Utf8 Class Initialized
INFO - 2016-10-17 15:41:57 --> URI Class Initialized
DEBUG - 2016-10-17 15:41:57 --> No URI present. Default controller set.
INFO - 2016-10-17 15:41:57 --> Router Class Initialized
INFO - 2016-10-17 15:41:57 --> Output Class Initialized
INFO - 2016-10-17 15:41:57 --> Security Class Initialized
DEBUG - 2016-10-17 15:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:41:57 --> Input Class Initialized
INFO - 2016-10-17 15:41:57 --> Language Class Initialized
INFO - 2016-10-17 15:41:57 --> Loader Class Initialized
INFO - 2016-10-17 15:41:57 --> Helper loaded: url_helper
INFO - 2016-10-17 15:41:57 --> Helper loaded: form_helper
INFO - 2016-10-17 15:41:57 --> Database Driver Class Initialized
INFO - 2016-10-17 15:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:41:57 --> Controller Class Initialized
INFO - 2016-10-17 15:41:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:41:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:41:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:41:57 --> Final output sent to browser
DEBUG - 2016-10-17 15:41:57 --> Total execution time: 0.0059
INFO - 2016-10-17 15:49:48 --> Config Class Initialized
INFO - 2016-10-17 15:49:48 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:49:48 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:49:48 --> Utf8 Class Initialized
INFO - 2016-10-17 15:49:48 --> URI Class Initialized
DEBUG - 2016-10-17 15:49:48 --> No URI present. Default controller set.
INFO - 2016-10-17 15:49:48 --> Router Class Initialized
INFO - 2016-10-17 15:49:48 --> Output Class Initialized
INFO - 2016-10-17 15:49:48 --> Security Class Initialized
DEBUG - 2016-10-17 15:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:49:48 --> Input Class Initialized
INFO - 2016-10-17 15:49:48 --> Language Class Initialized
INFO - 2016-10-17 15:49:48 --> Loader Class Initialized
INFO - 2016-10-17 15:49:48 --> Helper loaded: url_helper
INFO - 2016-10-17 15:49:48 --> Helper loaded: form_helper
INFO - 2016-10-17 15:49:48 --> Database Driver Class Initialized
INFO - 2016-10-17 15:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:49:48 --> Controller Class Initialized
INFO - 2016-10-17 15:49:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:49:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:49:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:49:48 --> Final output sent to browser
DEBUG - 2016-10-17 15:49:48 --> Total execution time: 0.0087
INFO - 2016-10-17 15:49:52 --> Config Class Initialized
INFO - 2016-10-17 15:49:52 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:49:52 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:49:52 --> Utf8 Class Initialized
INFO - 2016-10-17 15:49:52 --> URI Class Initialized
INFO - 2016-10-17 15:49:52 --> Router Class Initialized
INFO - 2016-10-17 15:49:52 --> Output Class Initialized
INFO - 2016-10-17 15:49:52 --> Security Class Initialized
DEBUG - 2016-10-17 15:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:49:52 --> Input Class Initialized
INFO - 2016-10-17 15:49:52 --> Language Class Initialized
INFO - 2016-10-17 15:49:52 --> Loader Class Initialized
INFO - 2016-10-17 15:49:52 --> Helper loaded: url_helper
INFO - 2016-10-17 15:49:52 --> Helper loaded: form_helper
INFO - 2016-10-17 15:49:52 --> Database Driver Class Initialized
INFO - 2016-10-17 15:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:49:52 --> Controller Class Initialized
INFO - 2016-10-17 15:49:52 --> Form Validation Class Initialized
INFO - 2016-10-17 15:49:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-17 15:49:52 --> Final output sent to browser
DEBUG - 2016-10-17 15:49:52 --> Total execution time: 0.0050
INFO - 2016-10-17 15:50:22 --> Config Class Initialized
INFO - 2016-10-17 15:50:22 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:50:22 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:50:22 --> Utf8 Class Initialized
INFO - 2016-10-17 15:50:22 --> URI Class Initialized
DEBUG - 2016-10-17 15:50:22 --> No URI present. Default controller set.
INFO - 2016-10-17 15:50:22 --> Router Class Initialized
INFO - 2016-10-17 15:50:22 --> Output Class Initialized
INFO - 2016-10-17 15:50:22 --> Security Class Initialized
DEBUG - 2016-10-17 15:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:50:22 --> Input Class Initialized
INFO - 2016-10-17 15:50:22 --> Language Class Initialized
INFO - 2016-10-17 15:50:22 --> Loader Class Initialized
INFO - 2016-10-17 15:50:22 --> Helper loaded: url_helper
INFO - 2016-10-17 15:50:22 --> Helper loaded: form_helper
INFO - 2016-10-17 15:50:22 --> Database Driver Class Initialized
INFO - 2016-10-17 15:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:50:22 --> Controller Class Initialized
INFO - 2016-10-17 15:50:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:50:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:50:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:50:22 --> Final output sent to browser
DEBUG - 2016-10-17 15:50:22 --> Total execution time: 0.0050
INFO - 2016-10-17 15:50:28 --> Config Class Initialized
INFO - 2016-10-17 15:50:28 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:50:28 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:50:28 --> Utf8 Class Initialized
INFO - 2016-10-17 15:50:28 --> URI Class Initialized
INFO - 2016-10-17 15:50:28 --> Router Class Initialized
INFO - 2016-10-17 15:50:28 --> Output Class Initialized
INFO - 2016-10-17 15:50:28 --> Security Class Initialized
DEBUG - 2016-10-17 15:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:50:28 --> Input Class Initialized
INFO - 2016-10-17 15:50:28 --> Language Class Initialized
INFO - 2016-10-17 15:50:28 --> Loader Class Initialized
INFO - 2016-10-17 15:50:28 --> Helper loaded: url_helper
INFO - 2016-10-17 15:50:28 --> Helper loaded: form_helper
INFO - 2016-10-17 15:50:28 --> Database Driver Class Initialized
INFO - 2016-10-17 15:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:50:28 --> Controller Class Initialized
INFO - 2016-10-17 15:50:28 --> Form Validation Class Initialized
INFO - 2016-10-17 15:50:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-17 15:50:28 --> Final output sent to browser
DEBUG - 2016-10-17 15:50:28 --> Total execution time: 0.0050
INFO - 2016-10-17 15:51:01 --> Config Class Initialized
INFO - 2016-10-17 15:51:01 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:51:01 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:51:01 --> Utf8 Class Initialized
INFO - 2016-10-17 15:51:01 --> URI Class Initialized
DEBUG - 2016-10-17 15:51:01 --> No URI present. Default controller set.
INFO - 2016-10-17 15:51:01 --> Router Class Initialized
INFO - 2016-10-17 15:51:01 --> Output Class Initialized
INFO - 2016-10-17 15:51:01 --> Security Class Initialized
DEBUG - 2016-10-17 15:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:51:01 --> Input Class Initialized
INFO - 2016-10-17 15:51:01 --> Language Class Initialized
INFO - 2016-10-17 15:51:01 --> Loader Class Initialized
INFO - 2016-10-17 15:51:01 --> Helper loaded: url_helper
INFO - 2016-10-17 15:51:01 --> Helper loaded: form_helper
INFO - 2016-10-17 15:51:01 --> Database Driver Class Initialized
INFO - 2016-10-17 15:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:51:01 --> Controller Class Initialized
INFO - 2016-10-17 15:51:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:51:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:51:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:51:01 --> Final output sent to browser
DEBUG - 2016-10-17 15:51:01 --> Total execution time: 0.0053
INFO - 2016-10-17 15:51:08 --> Config Class Initialized
INFO - 2016-10-17 15:51:08 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:51:08 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:51:08 --> Utf8 Class Initialized
INFO - 2016-10-17 15:51:08 --> URI Class Initialized
INFO - 2016-10-17 15:51:08 --> Router Class Initialized
INFO - 2016-10-17 15:51:08 --> Output Class Initialized
INFO - 2016-10-17 15:51:08 --> Security Class Initialized
DEBUG - 2016-10-17 15:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:51:08 --> Input Class Initialized
INFO - 2016-10-17 15:51:08 --> Language Class Initialized
INFO - 2016-10-17 15:51:08 --> Loader Class Initialized
INFO - 2016-10-17 15:51:08 --> Helper loaded: url_helper
INFO - 2016-10-17 15:51:08 --> Helper loaded: form_helper
INFO - 2016-10-17 15:51:08 --> Database Driver Class Initialized
INFO - 2016-10-17 15:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:51:08 --> Controller Class Initialized
INFO - 2016-10-17 15:51:08 --> Model Class Initialized
INFO - 2016-10-17 15:51:08 --> Final output sent to browser
DEBUG - 2016-10-17 15:51:08 --> Total execution time: 0.0054
INFO - 2016-10-17 15:51:08 --> Config Class Initialized
INFO - 2016-10-17 15:51:08 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:51:08 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:51:08 --> Utf8 Class Initialized
INFO - 2016-10-17 15:51:08 --> URI Class Initialized
DEBUG - 2016-10-17 15:51:08 --> No URI present. Default controller set.
INFO - 2016-10-17 15:51:08 --> Router Class Initialized
INFO - 2016-10-17 15:51:08 --> Output Class Initialized
INFO - 2016-10-17 15:51:08 --> Security Class Initialized
DEBUG - 2016-10-17 15:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:51:08 --> Input Class Initialized
INFO - 2016-10-17 15:51:08 --> Language Class Initialized
INFO - 2016-10-17 15:51:08 --> Loader Class Initialized
INFO - 2016-10-17 15:51:08 --> Helper loaded: url_helper
INFO - 2016-10-17 15:51:08 --> Helper loaded: form_helper
INFO - 2016-10-17 15:51:08 --> Database Driver Class Initialized
INFO - 2016-10-17 15:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:51:08 --> Controller Class Initialized
INFO - 2016-10-17 15:51:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:51:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 15:51:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 15:51:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:51:08 --> Final output sent to browser
DEBUG - 2016-10-17 15:51:08 --> Total execution time: 0.0039
INFO - 2016-10-17 15:51:11 --> Config Class Initialized
INFO - 2016-10-17 15:51:11 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:51:11 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:51:11 --> Utf8 Class Initialized
INFO - 2016-10-17 15:51:11 --> URI Class Initialized
INFO - 2016-10-17 15:51:11 --> Router Class Initialized
INFO - 2016-10-17 15:51:11 --> Output Class Initialized
INFO - 2016-10-17 15:51:11 --> Security Class Initialized
DEBUG - 2016-10-17 15:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:51:11 --> Input Class Initialized
INFO - 2016-10-17 15:51:11 --> Language Class Initialized
INFO - 2016-10-17 15:51:11 --> Loader Class Initialized
INFO - 2016-10-17 15:51:11 --> Helper loaded: url_helper
INFO - 2016-10-17 15:51:11 --> Helper loaded: form_helper
INFO - 2016-10-17 15:51:11 --> Database Driver Class Initialized
INFO - 2016-10-17 15:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:51:11 --> Controller Class Initialized
ERROR - 2016-10-17 15:51:11 --> Severity: Notice --> Undefined variable: name /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
ERROR - 2016-10-17 15:51:11 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
INFO - 2016-10-17 15:51:11 --> Config Class Initialized
INFO - 2016-10-17 15:51:11 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:51:11 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:51:11 --> Utf8 Class Initialized
INFO - 2016-10-17 15:51:11 --> URI Class Initialized
DEBUG - 2016-10-17 15:51:11 --> No URI present. Default controller set.
INFO - 2016-10-17 15:51:11 --> Router Class Initialized
INFO - 2016-10-17 15:51:11 --> Output Class Initialized
INFO - 2016-10-17 15:51:11 --> Security Class Initialized
DEBUG - 2016-10-17 15:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:51:11 --> Input Class Initialized
INFO - 2016-10-17 15:51:11 --> Language Class Initialized
INFO - 2016-10-17 15:51:11 --> Loader Class Initialized
INFO - 2016-10-17 15:51:11 --> Helper loaded: url_helper
INFO - 2016-10-17 15:51:11 --> Helper loaded: form_helper
INFO - 2016-10-17 15:51:11 --> Database Driver Class Initialized
INFO - 2016-10-17 15:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:51:11 --> Controller Class Initialized
INFO - 2016-10-17 15:51:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:51:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:51:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:51:11 --> Final output sent to browser
DEBUG - 2016-10-17 15:51:11 --> Total execution time: 0.0043
INFO - 2016-10-17 15:51:14 --> Config Class Initialized
INFO - 2016-10-17 15:51:14 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:51:14 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:51:14 --> Utf8 Class Initialized
INFO - 2016-10-17 15:51:14 --> URI Class Initialized
INFO - 2016-10-17 15:51:14 --> Router Class Initialized
INFO - 2016-10-17 15:51:14 --> Output Class Initialized
INFO - 2016-10-17 15:51:14 --> Security Class Initialized
DEBUG - 2016-10-17 15:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:51:14 --> Input Class Initialized
INFO - 2016-10-17 15:51:14 --> Language Class Initialized
INFO - 2016-10-17 15:51:14 --> Loader Class Initialized
INFO - 2016-10-17 15:51:14 --> Helper loaded: url_helper
INFO - 2016-10-17 15:51:14 --> Helper loaded: form_helper
INFO - 2016-10-17 15:51:14 --> Database Driver Class Initialized
INFO - 2016-10-17 15:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:51:14 --> Controller Class Initialized
INFO - 2016-10-17 15:51:14 --> Model Class Initialized
INFO - 2016-10-17 15:51:14 --> Final output sent to browser
DEBUG - 2016-10-17 15:51:14 --> Total execution time: 0.0052
INFO - 2016-10-17 15:51:29 --> Config Class Initialized
INFO - 2016-10-17 15:51:29 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:51:29 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:51:29 --> Utf8 Class Initialized
INFO - 2016-10-17 15:51:29 --> URI Class Initialized
DEBUG - 2016-10-17 15:51:29 --> No URI present. Default controller set.
INFO - 2016-10-17 15:51:29 --> Router Class Initialized
INFO - 2016-10-17 15:51:29 --> Output Class Initialized
INFO - 2016-10-17 15:51:29 --> Security Class Initialized
DEBUG - 2016-10-17 15:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:51:29 --> Input Class Initialized
INFO - 2016-10-17 15:51:29 --> Language Class Initialized
INFO - 2016-10-17 15:51:29 --> Loader Class Initialized
INFO - 2016-10-17 15:51:29 --> Helper loaded: url_helper
INFO - 2016-10-17 15:51:29 --> Helper loaded: form_helper
INFO - 2016-10-17 15:51:29 --> Database Driver Class Initialized
INFO - 2016-10-17 15:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:51:29 --> Controller Class Initialized
INFO - 2016-10-17 15:51:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:51:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:51:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:51:29 --> Final output sent to browser
DEBUG - 2016-10-17 15:51:29 --> Total execution time: 0.0086
INFO - 2016-10-17 15:52:13 --> Config Class Initialized
INFO - 2016-10-17 15:52:13 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:52:13 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:52:13 --> Utf8 Class Initialized
INFO - 2016-10-17 15:52:13 --> URI Class Initialized
DEBUG - 2016-10-17 15:52:13 --> No URI present. Default controller set.
INFO - 2016-10-17 15:52:13 --> Router Class Initialized
INFO - 2016-10-17 15:52:13 --> Output Class Initialized
INFO - 2016-10-17 15:52:13 --> Security Class Initialized
DEBUG - 2016-10-17 15:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:52:13 --> Input Class Initialized
INFO - 2016-10-17 15:52:13 --> Language Class Initialized
INFO - 2016-10-17 15:52:13 --> Loader Class Initialized
INFO - 2016-10-17 15:52:13 --> Helper loaded: url_helper
INFO - 2016-10-17 15:52:13 --> Helper loaded: form_helper
INFO - 2016-10-17 15:52:13 --> Database Driver Class Initialized
INFO - 2016-10-17 15:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:52:13 --> Controller Class Initialized
INFO - 2016-10-17 15:52:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 15:52:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 15:52:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 15:52:13 --> Final output sent to browser
DEBUG - 2016-10-17 15:52:13 --> Total execution time: 0.0049
INFO - 2016-10-17 16:00:18 --> Config Class Initialized
INFO - 2016-10-17 16:00:18 --> Hooks Class Initialized
DEBUG - 2016-10-17 16:00:18 --> UTF-8 Support Enabled
INFO - 2016-10-17 16:00:18 --> Utf8 Class Initialized
INFO - 2016-10-17 16:00:18 --> URI Class Initialized
DEBUG - 2016-10-17 16:00:18 --> No URI present. Default controller set.
INFO - 2016-10-17 16:00:18 --> Router Class Initialized
INFO - 2016-10-17 16:00:18 --> Output Class Initialized
INFO - 2016-10-17 16:00:18 --> Security Class Initialized
DEBUG - 2016-10-17 16:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 16:00:18 --> Input Class Initialized
INFO - 2016-10-17 16:00:18 --> Language Class Initialized
INFO - 2016-10-17 16:00:18 --> Loader Class Initialized
INFO - 2016-10-17 16:00:18 --> Helper loaded: url_helper
INFO - 2016-10-17 16:00:18 --> Helper loaded: form_helper
INFO - 2016-10-17 16:00:18 --> Database Driver Class Initialized
INFO - 2016-10-17 16:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 16:00:18 --> Controller Class Initialized
INFO - 2016-10-17 16:00:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 16:00:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 16:00:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 16:00:18 --> Final output sent to browser
DEBUG - 2016-10-17 16:00:18 --> Total execution time: 0.0058
INFO - 2016-10-17 16:00:30 --> Config Class Initialized
INFO - 2016-10-17 16:00:30 --> Hooks Class Initialized
DEBUG - 2016-10-17 16:00:30 --> UTF-8 Support Enabled
INFO - 2016-10-17 16:00:30 --> Utf8 Class Initialized
INFO - 2016-10-17 16:00:30 --> URI Class Initialized
DEBUG - 2016-10-17 16:00:30 --> No URI present. Default controller set.
INFO - 2016-10-17 16:00:30 --> Router Class Initialized
INFO - 2016-10-17 16:00:30 --> Output Class Initialized
INFO - 2016-10-17 16:00:30 --> Security Class Initialized
DEBUG - 2016-10-17 16:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 16:00:30 --> Input Class Initialized
INFO - 2016-10-17 16:00:30 --> Language Class Initialized
INFO - 2016-10-17 16:00:30 --> Loader Class Initialized
INFO - 2016-10-17 16:00:30 --> Helper loaded: url_helper
INFO - 2016-10-17 16:00:30 --> Helper loaded: form_helper
INFO - 2016-10-17 16:00:30 --> Database Driver Class Initialized
INFO - 2016-10-17 16:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 16:00:30 --> Controller Class Initialized
INFO - 2016-10-17 16:00:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 16:00:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 16:00:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 16:00:30 --> Final output sent to browser
DEBUG - 2016-10-17 16:00:30 --> Total execution time: 0.0078
INFO - 2016-10-17 16:13:41 --> Config Class Initialized
INFO - 2016-10-17 16:13:41 --> Hooks Class Initialized
DEBUG - 2016-10-17 16:13:41 --> UTF-8 Support Enabled
INFO - 2016-10-17 16:13:41 --> Utf8 Class Initialized
INFO - 2016-10-17 16:13:41 --> URI Class Initialized
DEBUG - 2016-10-17 16:13:41 --> No URI present. Default controller set.
INFO - 2016-10-17 16:13:41 --> Router Class Initialized
INFO - 2016-10-17 16:13:41 --> Output Class Initialized
INFO - 2016-10-17 16:13:41 --> Security Class Initialized
DEBUG - 2016-10-17 16:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 16:13:41 --> Input Class Initialized
INFO - 2016-10-17 16:13:41 --> Language Class Initialized
INFO - 2016-10-17 16:13:41 --> Loader Class Initialized
INFO - 2016-10-17 16:13:41 --> Helper loaded: url_helper
INFO - 2016-10-17 16:13:41 --> Helper loaded: form_helper
INFO - 2016-10-17 16:13:41 --> Database Driver Class Initialized
INFO - 2016-10-17 16:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 16:13:41 --> Controller Class Initialized
INFO - 2016-10-17 16:13:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 16:13:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 16:13:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 16:13:41 --> Final output sent to browser
DEBUG - 2016-10-17 16:13:41 --> Total execution time: 0.0059
INFO - 2016-10-17 16:16:53 --> Config Class Initialized
INFO - 2016-10-17 16:16:53 --> Hooks Class Initialized
DEBUG - 2016-10-17 16:16:53 --> UTF-8 Support Enabled
INFO - 2016-10-17 16:16:53 --> Utf8 Class Initialized
INFO - 2016-10-17 16:16:53 --> URI Class Initialized
DEBUG - 2016-10-17 16:16:53 --> No URI present. Default controller set.
INFO - 2016-10-17 16:16:53 --> Router Class Initialized
INFO - 2016-10-17 16:16:53 --> Output Class Initialized
INFO - 2016-10-17 16:16:53 --> Security Class Initialized
DEBUG - 2016-10-17 16:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 16:16:53 --> Input Class Initialized
INFO - 2016-10-17 16:16:53 --> Language Class Initialized
INFO - 2016-10-17 16:16:53 --> Loader Class Initialized
INFO - 2016-10-17 16:16:53 --> Helper loaded: url_helper
INFO - 2016-10-17 16:16:53 --> Helper loaded: form_helper
INFO - 2016-10-17 16:16:53 --> Database Driver Class Initialized
INFO - 2016-10-17 16:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 16:16:53 --> Controller Class Initialized
INFO - 2016-10-17 16:16:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 16:16:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 16:16:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 16:16:53 --> Final output sent to browser
DEBUG - 2016-10-17 16:16:53 --> Total execution time: 0.0077
INFO - 2016-10-17 16:17:15 --> Config Class Initialized
INFO - 2016-10-17 16:17:15 --> Hooks Class Initialized
DEBUG - 2016-10-17 16:17:15 --> UTF-8 Support Enabled
INFO - 2016-10-17 16:17:15 --> Utf8 Class Initialized
INFO - 2016-10-17 16:17:15 --> URI Class Initialized
INFO - 2016-10-17 16:17:15 --> Router Class Initialized
INFO - 2016-10-17 16:17:15 --> Output Class Initialized
INFO - 2016-10-17 16:17:15 --> Security Class Initialized
DEBUG - 2016-10-17 16:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 16:17:15 --> Input Class Initialized
INFO - 2016-10-17 16:17:15 --> Language Class Initialized
INFO - 2016-10-17 16:17:15 --> Loader Class Initialized
INFO - 2016-10-17 16:17:15 --> Helper loaded: url_helper
INFO - 2016-10-17 16:17:15 --> Helper loaded: form_helper
INFO - 2016-10-17 16:17:15 --> Database Driver Class Initialized
INFO - 2016-10-17 16:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 16:17:15 --> Controller Class Initialized
INFO - 2016-10-17 16:17:15 --> Model Class Initialized
INFO - 2016-10-17 16:17:15 --> Final output sent to browser
DEBUG - 2016-10-17 16:17:15 --> Total execution time: 0.0081
INFO - 2016-10-17 16:17:22 --> Config Class Initialized
INFO - 2016-10-17 16:17:22 --> Hooks Class Initialized
DEBUG - 2016-10-17 16:17:22 --> UTF-8 Support Enabled
INFO - 2016-10-17 16:17:22 --> Utf8 Class Initialized
INFO - 2016-10-17 16:17:22 --> URI Class Initialized
DEBUG - 2016-10-17 16:17:22 --> No URI present. Default controller set.
INFO - 2016-10-17 16:17:22 --> Router Class Initialized
INFO - 2016-10-17 16:17:22 --> Output Class Initialized
INFO - 2016-10-17 16:17:22 --> Security Class Initialized
DEBUG - 2016-10-17 16:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 16:17:22 --> Input Class Initialized
INFO - 2016-10-17 16:17:22 --> Language Class Initialized
INFO - 2016-10-17 16:17:22 --> Loader Class Initialized
INFO - 2016-10-17 16:17:22 --> Helper loaded: url_helper
INFO - 2016-10-17 16:17:22 --> Helper loaded: form_helper
INFO - 2016-10-17 16:17:22 --> Database Driver Class Initialized
INFO - 2016-10-17 16:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 16:17:22 --> Controller Class Initialized
INFO - 2016-10-17 16:17:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 16:17:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 16:17:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 16:17:22 --> Final output sent to browser
DEBUG - 2016-10-17 16:17:22 --> Total execution time: 0.0048
INFO - 2016-10-17 17:12:34 --> Config Class Initialized
INFO - 2016-10-17 17:12:34 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:12:34 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:12:34 --> Utf8 Class Initialized
INFO - 2016-10-17 17:12:34 --> URI Class Initialized
DEBUG - 2016-10-17 17:12:34 --> No URI present. Default controller set.
INFO - 2016-10-17 17:12:34 --> Router Class Initialized
INFO - 2016-10-17 17:12:34 --> Output Class Initialized
INFO - 2016-10-17 17:12:34 --> Security Class Initialized
DEBUG - 2016-10-17 17:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:12:34 --> Input Class Initialized
INFO - 2016-10-17 17:12:34 --> Language Class Initialized
INFO - 2016-10-17 17:12:34 --> Loader Class Initialized
INFO - 2016-10-17 17:12:34 --> Helper loaded: url_helper
INFO - 2016-10-17 17:12:34 --> Helper loaded: form_helper
INFO - 2016-10-17 17:12:34 --> Database Driver Class Initialized
INFO - 2016-10-17 17:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:12:34 --> Controller Class Initialized
INFO - 2016-10-17 17:12:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:12:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 17:12:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:12:34 --> Final output sent to browser
DEBUG - 2016-10-17 17:12:34 --> Total execution time: 0.0053
INFO - 2016-10-17 17:12:49 --> Config Class Initialized
INFO - 2016-10-17 17:12:49 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:12:49 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:12:49 --> Utf8 Class Initialized
INFO - 2016-10-17 17:12:49 --> URI Class Initialized
DEBUG - 2016-10-17 17:12:49 --> No URI present. Default controller set.
INFO - 2016-10-17 17:12:49 --> Router Class Initialized
INFO - 2016-10-17 17:12:49 --> Output Class Initialized
INFO - 2016-10-17 17:12:49 --> Security Class Initialized
DEBUG - 2016-10-17 17:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:12:49 --> Input Class Initialized
INFO - 2016-10-17 17:12:49 --> Language Class Initialized
INFO - 2016-10-17 17:12:49 --> Loader Class Initialized
INFO - 2016-10-17 17:12:49 --> Helper loaded: url_helper
INFO - 2016-10-17 17:12:49 --> Helper loaded: form_helper
INFO - 2016-10-17 17:12:49 --> Database Driver Class Initialized
INFO - 2016-10-17 17:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:12:49 --> Controller Class Initialized
INFO - 2016-10-17 17:12:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:12:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 17:12:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:12:49 --> Final output sent to browser
DEBUG - 2016-10-17 17:12:49 --> Total execution time: 0.0077
INFO - 2016-10-17 17:14:28 --> Config Class Initialized
INFO - 2016-10-17 17:14:28 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:14:28 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:14:28 --> Utf8 Class Initialized
INFO - 2016-10-17 17:14:28 --> URI Class Initialized
INFO - 2016-10-17 17:14:28 --> Router Class Initialized
INFO - 2016-10-17 17:14:28 --> Output Class Initialized
INFO - 2016-10-17 17:14:28 --> Security Class Initialized
DEBUG - 2016-10-17 17:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:14:28 --> Input Class Initialized
INFO - 2016-10-17 17:14:28 --> Language Class Initialized
INFO - 2016-10-17 17:14:28 --> Loader Class Initialized
INFO - 2016-10-17 17:14:28 --> Helper loaded: url_helper
INFO - 2016-10-17 17:14:28 --> Helper loaded: form_helper
INFO - 2016-10-17 17:14:28 --> Database Driver Class Initialized
INFO - 2016-10-17 17:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:14:28 --> Controller Class Initialized
INFO - 2016-10-17 17:14:28 --> Model Class Initialized
INFO - 2016-10-17 17:14:28 --> Final output sent to browser
DEBUG - 2016-10-17 17:14:28 --> Total execution time: 0.0062
INFO - 2016-10-17 17:15:06 --> Config Class Initialized
INFO - 2016-10-17 17:15:06 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:15:06 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:15:06 --> Utf8 Class Initialized
INFO - 2016-10-17 17:15:06 --> URI Class Initialized
DEBUG - 2016-10-17 17:15:06 --> No URI present. Default controller set.
INFO - 2016-10-17 17:15:06 --> Router Class Initialized
INFO - 2016-10-17 17:15:06 --> Output Class Initialized
INFO - 2016-10-17 17:15:06 --> Security Class Initialized
DEBUG - 2016-10-17 17:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:15:06 --> Input Class Initialized
INFO - 2016-10-17 17:15:06 --> Language Class Initialized
INFO - 2016-10-17 17:15:06 --> Loader Class Initialized
INFO - 2016-10-17 17:15:06 --> Helper loaded: url_helper
INFO - 2016-10-17 17:15:06 --> Helper loaded: form_helper
INFO - 2016-10-17 17:15:06 --> Database Driver Class Initialized
INFO - 2016-10-17 17:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:15:06 --> Controller Class Initialized
INFO - 2016-10-17 17:15:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:15:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 17:15:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:15:06 --> Final output sent to browser
DEBUG - 2016-10-17 17:15:06 --> Total execution time: 0.0059
INFO - 2016-10-17 17:15:11 --> Config Class Initialized
INFO - 2016-10-17 17:15:11 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:15:11 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:15:11 --> Utf8 Class Initialized
INFO - 2016-10-17 17:15:11 --> URI Class Initialized
INFO - 2016-10-17 17:15:11 --> Router Class Initialized
INFO - 2016-10-17 17:15:11 --> Output Class Initialized
INFO - 2016-10-17 17:15:11 --> Security Class Initialized
DEBUG - 2016-10-17 17:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:15:11 --> Input Class Initialized
INFO - 2016-10-17 17:15:11 --> Language Class Initialized
INFO - 2016-10-17 17:15:11 --> Loader Class Initialized
INFO - 2016-10-17 17:15:11 --> Helper loaded: url_helper
INFO - 2016-10-17 17:15:11 --> Helper loaded: form_helper
INFO - 2016-10-17 17:15:11 --> Database Driver Class Initialized
INFO - 2016-10-17 17:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:15:11 --> Controller Class Initialized
INFO - 2016-10-17 17:15:11 --> Model Class Initialized
INFO - 2016-10-17 17:15:11 --> Final output sent to browser
DEBUG - 2016-10-17 17:15:11 --> Total execution time: 0.0053
INFO - 2016-10-17 17:20:35 --> Config Class Initialized
INFO - 2016-10-17 17:20:35 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:20:35 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:20:35 --> Utf8 Class Initialized
INFO - 2016-10-17 17:20:35 --> URI Class Initialized
DEBUG - 2016-10-17 17:20:35 --> No URI present. Default controller set.
INFO - 2016-10-17 17:20:35 --> Router Class Initialized
INFO - 2016-10-17 17:20:35 --> Output Class Initialized
INFO - 2016-10-17 17:20:35 --> Security Class Initialized
DEBUG - 2016-10-17 17:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:20:35 --> Input Class Initialized
INFO - 2016-10-17 17:20:35 --> Language Class Initialized
INFO - 2016-10-17 17:20:35 --> Loader Class Initialized
INFO - 2016-10-17 17:20:35 --> Helper loaded: url_helper
INFO - 2016-10-17 17:20:35 --> Helper loaded: form_helper
INFO - 2016-10-17 17:20:35 --> Database Driver Class Initialized
INFO - 2016-10-17 17:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:20:35 --> Controller Class Initialized
INFO - 2016-10-17 17:20:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:20:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 17:20:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:20:35 --> Final output sent to browser
DEBUG - 2016-10-17 17:20:35 --> Total execution time: 0.0050
INFO - 2016-10-17 17:21:26 --> Config Class Initialized
INFO - 2016-10-17 17:21:26 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:21:26 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:21:26 --> Utf8 Class Initialized
INFO - 2016-10-17 17:21:26 --> URI Class Initialized
DEBUG - 2016-10-17 17:21:26 --> No URI present. Default controller set.
INFO - 2016-10-17 17:21:26 --> Router Class Initialized
INFO - 2016-10-17 17:21:26 --> Output Class Initialized
INFO - 2016-10-17 17:21:26 --> Security Class Initialized
DEBUG - 2016-10-17 17:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:21:26 --> Input Class Initialized
INFO - 2016-10-17 17:21:26 --> Language Class Initialized
INFO - 2016-10-17 17:21:26 --> Loader Class Initialized
INFO - 2016-10-17 17:21:26 --> Helper loaded: url_helper
INFO - 2016-10-17 17:21:26 --> Helper loaded: form_helper
INFO - 2016-10-17 17:21:26 --> Database Driver Class Initialized
INFO - 2016-10-17 17:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:21:26 --> Controller Class Initialized
INFO - 2016-10-17 17:21:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:21:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 17:21:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:21:26 --> Final output sent to browser
DEBUG - 2016-10-17 17:21:26 --> Total execution time: 0.0056
INFO - 2016-10-17 17:21:30 --> Config Class Initialized
INFO - 2016-10-17 17:21:30 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:21:30 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:21:30 --> Utf8 Class Initialized
INFO - 2016-10-17 17:21:30 --> URI Class Initialized
INFO - 2016-10-17 17:21:30 --> Router Class Initialized
INFO - 2016-10-17 17:21:30 --> Output Class Initialized
INFO - 2016-10-17 17:21:30 --> Security Class Initialized
DEBUG - 2016-10-17 17:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:21:30 --> Input Class Initialized
INFO - 2016-10-17 17:21:30 --> Language Class Initialized
INFO - 2016-10-17 17:21:30 --> Loader Class Initialized
INFO - 2016-10-17 17:21:30 --> Helper loaded: url_helper
INFO - 2016-10-17 17:21:30 --> Helper loaded: form_helper
INFO - 2016-10-17 17:21:30 --> Database Driver Class Initialized
INFO - 2016-10-17 17:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:21:30 --> Controller Class Initialized
INFO - 2016-10-17 17:21:30 --> Model Class Initialized
INFO - 2016-10-17 17:21:30 --> Final output sent to browser
DEBUG - 2016-10-17 17:21:30 --> Total execution time: 0.0075
INFO - 2016-10-17 17:21:38 --> Config Class Initialized
INFO - 2016-10-17 17:21:38 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:21:38 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:21:38 --> Utf8 Class Initialized
INFO - 2016-10-17 17:21:38 --> URI Class Initialized
DEBUG - 2016-10-17 17:21:38 --> No URI present. Default controller set.
INFO - 2016-10-17 17:21:38 --> Router Class Initialized
INFO - 2016-10-17 17:21:38 --> Output Class Initialized
INFO - 2016-10-17 17:21:38 --> Security Class Initialized
DEBUG - 2016-10-17 17:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:21:38 --> Input Class Initialized
INFO - 2016-10-17 17:21:38 --> Language Class Initialized
INFO - 2016-10-17 17:21:38 --> Loader Class Initialized
INFO - 2016-10-17 17:21:38 --> Helper loaded: url_helper
INFO - 2016-10-17 17:21:38 --> Helper loaded: form_helper
INFO - 2016-10-17 17:21:38 --> Database Driver Class Initialized
INFO - 2016-10-17 17:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:21:38 --> Controller Class Initialized
INFO - 2016-10-17 17:21:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:21:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 17:21:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:21:38 --> Final output sent to browser
DEBUG - 2016-10-17 17:21:38 --> Total execution time: 0.0047
INFO - 2016-10-17 17:22:59 --> Config Class Initialized
INFO - 2016-10-17 17:22:59 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:22:59 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:22:59 --> Utf8 Class Initialized
INFO - 2016-10-17 17:22:59 --> URI Class Initialized
DEBUG - 2016-10-17 17:22:59 --> No URI present. Default controller set.
INFO - 2016-10-17 17:22:59 --> Router Class Initialized
INFO - 2016-10-17 17:22:59 --> Output Class Initialized
INFO - 2016-10-17 17:22:59 --> Security Class Initialized
DEBUG - 2016-10-17 17:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:22:59 --> Input Class Initialized
INFO - 2016-10-17 17:22:59 --> Language Class Initialized
INFO - 2016-10-17 17:22:59 --> Loader Class Initialized
INFO - 2016-10-17 17:22:59 --> Helper loaded: url_helper
INFO - 2016-10-17 17:22:59 --> Helper loaded: form_helper
INFO - 2016-10-17 17:22:59 --> Database Driver Class Initialized
INFO - 2016-10-17 17:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:22:59 --> Controller Class Initialized
INFO - 2016-10-17 17:22:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:22:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 17:22:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:22:59 --> Final output sent to browser
DEBUG - 2016-10-17 17:22:59 --> Total execution time: 0.0051
INFO - 2016-10-17 17:23:05 --> Config Class Initialized
INFO - 2016-10-17 17:23:05 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:23:05 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:23:05 --> Utf8 Class Initialized
INFO - 2016-10-17 17:23:05 --> URI Class Initialized
INFO - 2016-10-17 17:23:05 --> Router Class Initialized
INFO - 2016-10-17 17:23:05 --> Output Class Initialized
INFO - 2016-10-17 17:23:05 --> Security Class Initialized
DEBUG - 2016-10-17 17:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:23:05 --> Input Class Initialized
INFO - 2016-10-17 17:23:05 --> Language Class Initialized
INFO - 2016-10-17 17:23:05 --> Loader Class Initialized
INFO - 2016-10-17 17:23:05 --> Helper loaded: url_helper
INFO - 2016-10-17 17:23:05 --> Helper loaded: form_helper
INFO - 2016-10-17 17:23:05 --> Database Driver Class Initialized
INFO - 2016-10-17 17:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:23:05 --> Controller Class Initialized
INFO - 2016-10-17 17:23:05 --> Model Class Initialized
INFO - 2016-10-17 17:23:05 --> Final output sent to browser
DEBUG - 2016-10-17 17:23:05 --> Total execution time: 0.0057
INFO - 2016-10-17 17:23:06 --> Config Class Initialized
INFO - 2016-10-17 17:23:06 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:23:06 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:23:06 --> Utf8 Class Initialized
INFO - 2016-10-17 17:23:06 --> URI Class Initialized
DEBUG - 2016-10-17 17:23:06 --> No URI present. Default controller set.
INFO - 2016-10-17 17:23:06 --> Router Class Initialized
INFO - 2016-10-17 17:23:06 --> Output Class Initialized
INFO - 2016-10-17 17:23:06 --> Security Class Initialized
DEBUG - 2016-10-17 17:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:23:06 --> Input Class Initialized
INFO - 2016-10-17 17:23:06 --> Language Class Initialized
INFO - 2016-10-17 17:23:06 --> Loader Class Initialized
INFO - 2016-10-17 17:23:06 --> Helper loaded: url_helper
INFO - 2016-10-17 17:23:06 --> Helper loaded: form_helper
INFO - 2016-10-17 17:23:06 --> Database Driver Class Initialized
INFO - 2016-10-17 17:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:23:06 --> Controller Class Initialized
INFO - 2016-10-17 17:23:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:23:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 17:23:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:23:06 --> Final output sent to browser
DEBUG - 2016-10-17 17:23:06 --> Total execution time: 0.0049
INFO - 2016-10-17 17:25:03 --> Config Class Initialized
INFO - 2016-10-17 17:25:03 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:25:03 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:25:03 --> Utf8 Class Initialized
INFO - 2016-10-17 17:25:03 --> URI Class Initialized
DEBUG - 2016-10-17 17:25:03 --> No URI present. Default controller set.
INFO - 2016-10-17 17:25:03 --> Router Class Initialized
INFO - 2016-10-17 17:25:03 --> Output Class Initialized
INFO - 2016-10-17 17:25:03 --> Security Class Initialized
DEBUG - 2016-10-17 17:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:25:03 --> Input Class Initialized
INFO - 2016-10-17 17:25:03 --> Language Class Initialized
INFO - 2016-10-17 17:25:03 --> Loader Class Initialized
INFO - 2016-10-17 17:25:03 --> Helper loaded: url_helper
INFO - 2016-10-17 17:25:03 --> Helper loaded: form_helper
INFO - 2016-10-17 17:25:03 --> Database Driver Class Initialized
INFO - 2016-10-17 17:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:25:03 --> Controller Class Initialized
INFO - 2016-10-17 17:25:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:25:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 17:25:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:25:03 --> Final output sent to browser
DEBUG - 2016-10-17 17:25:03 --> Total execution time: 0.0050
INFO - 2016-10-17 17:25:07 --> Config Class Initialized
INFO - 2016-10-17 17:25:07 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:25:07 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:25:07 --> Utf8 Class Initialized
INFO - 2016-10-17 17:25:07 --> URI Class Initialized
DEBUG - 2016-10-17 17:25:07 --> No URI present. Default controller set.
INFO - 2016-10-17 17:25:07 --> Router Class Initialized
INFO - 2016-10-17 17:25:07 --> Output Class Initialized
INFO - 2016-10-17 17:25:07 --> Security Class Initialized
DEBUG - 2016-10-17 17:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:25:07 --> Input Class Initialized
INFO - 2016-10-17 17:25:07 --> Language Class Initialized
INFO - 2016-10-17 17:25:07 --> Loader Class Initialized
INFO - 2016-10-17 17:25:07 --> Helper loaded: url_helper
INFO - 2016-10-17 17:25:07 --> Helper loaded: form_helper
INFO - 2016-10-17 17:25:07 --> Database Driver Class Initialized
INFO - 2016-10-17 17:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:25:07 --> Controller Class Initialized
INFO - 2016-10-17 17:25:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:25:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 17:25:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:25:07 --> Final output sent to browser
DEBUG - 2016-10-17 17:25:07 --> Total execution time: 0.0050
INFO - 2016-10-17 17:26:43 --> Config Class Initialized
INFO - 2016-10-17 17:26:43 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:26:43 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:26:43 --> Utf8 Class Initialized
INFO - 2016-10-17 17:26:43 --> URI Class Initialized
DEBUG - 2016-10-17 17:26:43 --> No URI present. Default controller set.
INFO - 2016-10-17 17:26:43 --> Router Class Initialized
INFO - 2016-10-17 17:26:43 --> Output Class Initialized
INFO - 2016-10-17 17:26:43 --> Security Class Initialized
DEBUG - 2016-10-17 17:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:26:43 --> Input Class Initialized
INFO - 2016-10-17 17:26:43 --> Language Class Initialized
INFO - 2016-10-17 17:26:43 --> Loader Class Initialized
INFO - 2016-10-17 17:26:43 --> Helper loaded: url_helper
INFO - 2016-10-17 17:26:43 --> Helper loaded: form_helper
INFO - 2016-10-17 17:26:43 --> Database Driver Class Initialized
INFO - 2016-10-17 17:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:26:43 --> Controller Class Initialized
INFO - 2016-10-17 17:26:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:26:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 17:26:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:26:43 --> Final output sent to browser
DEBUG - 2016-10-17 17:26:43 --> Total execution time: 0.0083
INFO - 2016-10-17 17:26:46 --> Config Class Initialized
INFO - 2016-10-17 17:26:46 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:26:46 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:26:46 --> Utf8 Class Initialized
INFO - 2016-10-17 17:26:46 --> URI Class Initialized
INFO - 2016-10-17 17:26:46 --> Router Class Initialized
INFO - 2016-10-17 17:26:46 --> Output Class Initialized
INFO - 2016-10-17 17:26:46 --> Security Class Initialized
DEBUG - 2016-10-17 17:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:26:46 --> Input Class Initialized
INFO - 2016-10-17 17:26:46 --> Language Class Initialized
INFO - 2016-10-17 17:26:46 --> Loader Class Initialized
INFO - 2016-10-17 17:26:46 --> Helper loaded: url_helper
INFO - 2016-10-17 17:26:46 --> Helper loaded: form_helper
INFO - 2016-10-17 17:26:46 --> Database Driver Class Initialized
INFO - 2016-10-17 17:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:26:46 --> Controller Class Initialized
INFO - 2016-10-17 17:26:46 --> Model Class Initialized
INFO - 2016-10-17 17:26:46 --> Final output sent to browser
DEBUG - 2016-10-17 17:26:46 --> Total execution time: 0.0055
INFO - 2016-10-17 17:27:00 --> Config Class Initialized
INFO - 2016-10-17 17:27:00 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:27:00 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:27:00 --> Utf8 Class Initialized
INFO - 2016-10-17 17:27:00 --> URI Class Initialized
DEBUG - 2016-10-17 17:27:00 --> No URI present. Default controller set.
INFO - 2016-10-17 17:27:00 --> Router Class Initialized
INFO - 2016-10-17 17:27:00 --> Output Class Initialized
INFO - 2016-10-17 17:27:00 --> Security Class Initialized
DEBUG - 2016-10-17 17:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:27:00 --> Input Class Initialized
INFO - 2016-10-17 17:27:00 --> Language Class Initialized
INFO - 2016-10-17 17:27:00 --> Loader Class Initialized
INFO - 2016-10-17 17:27:00 --> Helper loaded: url_helper
INFO - 2016-10-17 17:27:00 --> Helper loaded: form_helper
INFO - 2016-10-17 17:27:00 --> Database Driver Class Initialized
INFO - 2016-10-17 17:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:27:00 --> Controller Class Initialized
INFO - 2016-10-17 17:27:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:27:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 17:27:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:27:00 --> Final output sent to browser
DEBUG - 2016-10-17 17:27:00 --> Total execution time: 0.0055
INFO - 2016-10-17 17:27:07 --> Config Class Initialized
INFO - 2016-10-17 17:27:07 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:27:07 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:27:07 --> Utf8 Class Initialized
INFO - 2016-10-17 17:27:07 --> URI Class Initialized
DEBUG - 2016-10-17 17:27:07 --> No URI present. Default controller set.
INFO - 2016-10-17 17:27:07 --> Router Class Initialized
INFO - 2016-10-17 17:27:07 --> Output Class Initialized
INFO - 2016-10-17 17:27:07 --> Security Class Initialized
DEBUG - 2016-10-17 17:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:27:07 --> Input Class Initialized
INFO - 2016-10-17 17:27:07 --> Language Class Initialized
INFO - 2016-10-17 17:27:07 --> Loader Class Initialized
INFO - 2016-10-17 17:27:07 --> Helper loaded: url_helper
INFO - 2016-10-17 17:27:07 --> Helper loaded: form_helper
INFO - 2016-10-17 17:27:07 --> Database Driver Class Initialized
INFO - 2016-10-17 17:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:27:07 --> Controller Class Initialized
INFO - 2016-10-17 17:27:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:27:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 17:27:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:27:07 --> Final output sent to browser
DEBUG - 2016-10-17 17:27:07 --> Total execution time: 0.0055
INFO - 2016-10-17 17:27:11 --> Config Class Initialized
INFO - 2016-10-17 17:27:11 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:27:11 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:27:11 --> Utf8 Class Initialized
INFO - 2016-10-17 17:27:11 --> URI Class Initialized
DEBUG - 2016-10-17 17:27:11 --> No URI present. Default controller set.
INFO - 2016-10-17 17:27:11 --> Router Class Initialized
INFO - 2016-10-17 17:27:11 --> Output Class Initialized
INFO - 2016-10-17 17:27:11 --> Security Class Initialized
DEBUG - 2016-10-17 17:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:27:11 --> Input Class Initialized
INFO - 2016-10-17 17:27:11 --> Language Class Initialized
INFO - 2016-10-17 17:27:11 --> Loader Class Initialized
INFO - 2016-10-17 17:27:11 --> Helper loaded: url_helper
INFO - 2016-10-17 17:27:11 --> Helper loaded: form_helper
INFO - 2016-10-17 17:27:11 --> Database Driver Class Initialized
INFO - 2016-10-17 17:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:27:11 --> Controller Class Initialized
INFO - 2016-10-17 17:27:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:27:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 17:27:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:27:11 --> Final output sent to browser
DEBUG - 2016-10-17 17:27:11 --> Total execution time: 0.0073
INFO - 2016-10-17 17:27:14 --> Config Class Initialized
INFO - 2016-10-17 17:27:14 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:27:14 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:27:14 --> Utf8 Class Initialized
INFO - 2016-10-17 17:27:14 --> URI Class Initialized
INFO - 2016-10-17 17:27:14 --> Router Class Initialized
INFO - 2016-10-17 17:27:14 --> Output Class Initialized
INFO - 2016-10-17 17:27:14 --> Security Class Initialized
DEBUG - 2016-10-17 17:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:27:14 --> Input Class Initialized
INFO - 2016-10-17 17:27:14 --> Language Class Initialized
INFO - 2016-10-17 17:27:14 --> Loader Class Initialized
INFO - 2016-10-17 17:27:14 --> Helper loaded: url_helper
INFO - 2016-10-17 17:27:14 --> Helper loaded: form_helper
INFO - 2016-10-17 17:27:14 --> Database Driver Class Initialized
INFO - 2016-10-17 17:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:27:14 --> Controller Class Initialized
INFO - 2016-10-17 17:27:14 --> Model Class Initialized
INFO - 2016-10-17 17:27:14 --> Final output sent to browser
DEBUG - 2016-10-17 17:27:14 --> Total execution time: 0.0051
INFO - 2016-10-17 17:27:30 --> Config Class Initialized
INFO - 2016-10-17 17:27:30 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:27:30 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:27:30 --> Utf8 Class Initialized
INFO - 2016-10-17 17:27:30 --> URI Class Initialized
INFO - 2016-10-17 17:27:30 --> Router Class Initialized
INFO - 2016-10-17 17:27:30 --> Output Class Initialized
INFO - 2016-10-17 17:27:30 --> Security Class Initialized
DEBUG - 2016-10-17 17:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:27:30 --> Input Class Initialized
INFO - 2016-10-17 17:27:30 --> Language Class Initialized
INFO - 2016-10-17 17:27:30 --> Loader Class Initialized
INFO - 2016-10-17 17:27:30 --> Helper loaded: url_helper
INFO - 2016-10-17 17:27:30 --> Helper loaded: form_helper
INFO - 2016-10-17 17:27:30 --> Database Driver Class Initialized
INFO - 2016-10-17 17:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:27:30 --> Controller Class Initialized
INFO - 2016-10-17 17:27:30 --> Model Class Initialized
INFO - 2016-10-17 17:27:30 --> Final output sent to browser
DEBUG - 2016-10-17 17:27:30 --> Total execution time: 0.0083
INFO - 2016-10-17 17:27:33 --> Config Class Initialized
INFO - 2016-10-17 17:27:33 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:27:33 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:27:33 --> Utf8 Class Initialized
INFO - 2016-10-17 17:27:33 --> URI Class Initialized
DEBUG - 2016-10-17 17:27:33 --> No URI present. Default controller set.
INFO - 2016-10-17 17:27:33 --> Router Class Initialized
INFO - 2016-10-17 17:27:33 --> Output Class Initialized
INFO - 2016-10-17 17:27:33 --> Security Class Initialized
DEBUG - 2016-10-17 17:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:27:33 --> Input Class Initialized
INFO - 2016-10-17 17:27:33 --> Language Class Initialized
INFO - 2016-10-17 17:27:33 --> Loader Class Initialized
INFO - 2016-10-17 17:27:33 --> Helper loaded: url_helper
INFO - 2016-10-17 17:27:33 --> Helper loaded: form_helper
INFO - 2016-10-17 17:27:33 --> Database Driver Class Initialized
INFO - 2016-10-17 17:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:27:33 --> Controller Class Initialized
INFO - 2016-10-17 17:27:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:27:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 17:27:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:27:33 --> Final output sent to browser
DEBUG - 2016-10-17 17:27:33 --> Total execution time: 0.0046
INFO - 2016-10-17 17:28:02 --> Config Class Initialized
INFO - 2016-10-17 17:28:02 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:28:02 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:28:02 --> Utf8 Class Initialized
INFO - 2016-10-17 17:28:02 --> URI Class Initialized
DEBUG - 2016-10-17 17:28:02 --> No URI present. Default controller set.
INFO - 2016-10-17 17:28:02 --> Router Class Initialized
INFO - 2016-10-17 17:28:02 --> Output Class Initialized
INFO - 2016-10-17 17:28:02 --> Security Class Initialized
DEBUG - 2016-10-17 17:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:28:02 --> Input Class Initialized
INFO - 2016-10-17 17:28:02 --> Language Class Initialized
INFO - 2016-10-17 17:28:02 --> Loader Class Initialized
INFO - 2016-10-17 17:28:02 --> Helper loaded: url_helper
INFO - 2016-10-17 17:28:02 --> Helper loaded: form_helper
INFO - 2016-10-17 17:28:02 --> Database Driver Class Initialized
INFO - 2016-10-17 17:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:28:02 --> Controller Class Initialized
INFO - 2016-10-17 17:28:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:28:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 17:28:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:28:02 --> Final output sent to browser
DEBUG - 2016-10-17 17:28:02 --> Total execution time: 0.0051
INFO - 2016-10-17 17:28:08 --> Config Class Initialized
INFO - 2016-10-17 17:28:08 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:28:08 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:28:08 --> Utf8 Class Initialized
INFO - 2016-10-17 17:28:08 --> URI Class Initialized
DEBUG - 2016-10-17 17:28:08 --> No URI present. Default controller set.
INFO - 2016-10-17 17:28:08 --> Router Class Initialized
INFO - 2016-10-17 17:28:08 --> Output Class Initialized
INFO - 2016-10-17 17:28:08 --> Security Class Initialized
DEBUG - 2016-10-17 17:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:28:08 --> Input Class Initialized
INFO - 2016-10-17 17:28:08 --> Language Class Initialized
INFO - 2016-10-17 17:28:08 --> Loader Class Initialized
INFO - 2016-10-17 17:28:08 --> Helper loaded: url_helper
INFO - 2016-10-17 17:28:08 --> Helper loaded: form_helper
INFO - 2016-10-17 17:28:08 --> Database Driver Class Initialized
INFO - 2016-10-17 17:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:28:08 --> Controller Class Initialized
INFO - 2016-10-17 17:28:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:28:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 17:28:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:28:08 --> Final output sent to browser
DEBUG - 2016-10-17 17:28:08 --> Total execution time: 0.0047
INFO - 2016-10-17 17:28:28 --> Config Class Initialized
INFO - 2016-10-17 17:28:28 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:28:28 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:28:28 --> Utf8 Class Initialized
INFO - 2016-10-17 17:28:28 --> URI Class Initialized
DEBUG - 2016-10-17 17:28:28 --> No URI present. Default controller set.
INFO - 2016-10-17 17:28:28 --> Router Class Initialized
INFO - 2016-10-17 17:28:28 --> Output Class Initialized
INFO - 2016-10-17 17:28:28 --> Security Class Initialized
DEBUG - 2016-10-17 17:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:28:28 --> Input Class Initialized
INFO - 2016-10-17 17:28:28 --> Language Class Initialized
INFO - 2016-10-17 17:28:28 --> Loader Class Initialized
INFO - 2016-10-17 17:28:28 --> Helper loaded: url_helper
INFO - 2016-10-17 17:28:28 --> Helper loaded: form_helper
INFO - 2016-10-17 17:28:28 --> Database Driver Class Initialized
INFO - 2016-10-17 17:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:28:28 --> Controller Class Initialized
INFO - 2016-10-17 17:28:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:28:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 17:28:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:28:28 --> Final output sent to browser
DEBUG - 2016-10-17 17:28:28 --> Total execution time: 0.0049
INFO - 2016-10-17 17:28:31 --> Config Class Initialized
INFO - 2016-10-17 17:28:31 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:28:31 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:28:31 --> Utf8 Class Initialized
INFO - 2016-10-17 17:28:31 --> URI Class Initialized
INFO - 2016-10-17 17:28:31 --> Router Class Initialized
INFO - 2016-10-17 17:28:31 --> Output Class Initialized
INFO - 2016-10-17 17:28:31 --> Security Class Initialized
DEBUG - 2016-10-17 17:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:28:31 --> Input Class Initialized
INFO - 2016-10-17 17:28:31 --> Language Class Initialized
INFO - 2016-10-17 17:28:31 --> Loader Class Initialized
INFO - 2016-10-17 17:28:31 --> Helper loaded: url_helper
INFO - 2016-10-17 17:28:31 --> Helper loaded: form_helper
INFO - 2016-10-17 17:28:31 --> Database Driver Class Initialized
INFO - 2016-10-17 17:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:28:31 --> Controller Class Initialized
INFO - 2016-10-17 17:28:31 --> Model Class Initialized
INFO - 2016-10-17 17:28:31 --> Final output sent to browser
DEBUG - 2016-10-17 17:28:31 --> Total execution time: 0.0051
INFO - 2016-10-17 17:28:49 --> Config Class Initialized
INFO - 2016-10-17 17:28:49 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:28:49 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:28:49 --> Utf8 Class Initialized
INFO - 2016-10-17 17:28:49 --> URI Class Initialized
DEBUG - 2016-10-17 17:28:49 --> No URI present. Default controller set.
INFO - 2016-10-17 17:28:49 --> Router Class Initialized
INFO - 2016-10-17 17:28:49 --> Output Class Initialized
INFO - 2016-10-17 17:28:49 --> Security Class Initialized
DEBUG - 2016-10-17 17:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:28:49 --> Input Class Initialized
INFO - 2016-10-17 17:28:49 --> Language Class Initialized
INFO - 2016-10-17 17:28:49 --> Loader Class Initialized
INFO - 2016-10-17 17:28:49 --> Helper loaded: url_helper
INFO - 2016-10-17 17:28:49 --> Helper loaded: form_helper
INFO - 2016-10-17 17:28:49 --> Database Driver Class Initialized
INFO - 2016-10-17 17:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:28:49 --> Controller Class Initialized
INFO - 2016-10-17 17:28:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:28:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 17:28:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:28:49 --> Final output sent to browser
DEBUG - 2016-10-17 17:28:49 --> Total execution time: 0.0052
INFO - 2016-10-17 17:28:53 --> Config Class Initialized
INFO - 2016-10-17 17:28:53 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:28:53 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:28:53 --> Utf8 Class Initialized
INFO - 2016-10-17 17:28:53 --> URI Class Initialized
INFO - 2016-10-17 17:28:53 --> Router Class Initialized
INFO - 2016-10-17 17:28:53 --> Output Class Initialized
INFO - 2016-10-17 17:28:53 --> Security Class Initialized
DEBUG - 2016-10-17 17:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:28:53 --> Input Class Initialized
INFO - 2016-10-17 17:28:53 --> Language Class Initialized
INFO - 2016-10-17 17:28:53 --> Loader Class Initialized
INFO - 2016-10-17 17:28:53 --> Helper loaded: url_helper
INFO - 2016-10-17 17:28:53 --> Helper loaded: form_helper
INFO - 2016-10-17 17:28:53 --> Database Driver Class Initialized
INFO - 2016-10-17 17:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:28:53 --> Controller Class Initialized
INFO - 2016-10-17 17:28:53 --> Model Class Initialized
INFO - 2016-10-17 17:28:53 --> Final output sent to browser
DEBUG - 2016-10-17 17:28:53 --> Total execution time: 0.0053
INFO - 2016-10-17 17:29:05 --> Config Class Initialized
INFO - 2016-10-17 17:29:05 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:29:05 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:29:05 --> Utf8 Class Initialized
INFO - 2016-10-17 17:29:05 --> URI Class Initialized
DEBUG - 2016-10-17 17:29:05 --> No URI present. Default controller set.
INFO - 2016-10-17 17:29:05 --> Router Class Initialized
INFO - 2016-10-17 17:29:05 --> Output Class Initialized
INFO - 2016-10-17 17:29:05 --> Security Class Initialized
DEBUG - 2016-10-17 17:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:29:05 --> Input Class Initialized
INFO - 2016-10-17 17:29:05 --> Language Class Initialized
INFO - 2016-10-17 17:29:05 --> Loader Class Initialized
INFO - 2016-10-17 17:29:05 --> Helper loaded: url_helper
INFO - 2016-10-17 17:29:05 --> Helper loaded: form_helper
INFO - 2016-10-17 17:29:05 --> Database Driver Class Initialized
INFO - 2016-10-17 17:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:29:05 --> Controller Class Initialized
INFO - 2016-10-17 17:29:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:29:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 17:29:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:29:05 --> Final output sent to browser
DEBUG - 2016-10-17 17:29:05 --> Total execution time: 0.0047
INFO - 2016-10-17 17:29:38 --> Config Class Initialized
INFO - 2016-10-17 17:29:38 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:29:38 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:29:38 --> Utf8 Class Initialized
INFO - 2016-10-17 17:29:38 --> URI Class Initialized
DEBUG - 2016-10-17 17:29:38 --> No URI present. Default controller set.
INFO - 2016-10-17 17:29:38 --> Router Class Initialized
INFO - 2016-10-17 17:29:38 --> Output Class Initialized
INFO - 2016-10-17 17:29:38 --> Security Class Initialized
DEBUG - 2016-10-17 17:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:29:38 --> Input Class Initialized
INFO - 2016-10-17 17:29:38 --> Language Class Initialized
INFO - 2016-10-17 17:29:38 --> Loader Class Initialized
INFO - 2016-10-17 17:29:38 --> Helper loaded: url_helper
INFO - 2016-10-17 17:29:38 --> Helper loaded: form_helper
INFO - 2016-10-17 17:29:38 --> Database Driver Class Initialized
INFO - 2016-10-17 17:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:29:38 --> Controller Class Initialized
INFO - 2016-10-17 17:29:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:29:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 17:29:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:29:38 --> Final output sent to browser
DEBUG - 2016-10-17 17:29:38 --> Total execution time: 0.0045
INFO - 2016-10-17 17:29:43 --> Config Class Initialized
INFO - 2016-10-17 17:29:43 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:29:43 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:29:43 --> Utf8 Class Initialized
INFO - 2016-10-17 17:29:43 --> URI Class Initialized
INFO - 2016-10-17 17:29:43 --> Router Class Initialized
INFO - 2016-10-17 17:29:43 --> Output Class Initialized
INFO - 2016-10-17 17:29:43 --> Security Class Initialized
DEBUG - 2016-10-17 17:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:29:43 --> Input Class Initialized
INFO - 2016-10-17 17:29:43 --> Language Class Initialized
INFO - 2016-10-17 17:29:43 --> Loader Class Initialized
INFO - 2016-10-17 17:29:43 --> Helper loaded: url_helper
INFO - 2016-10-17 17:29:43 --> Helper loaded: form_helper
INFO - 2016-10-17 17:29:43 --> Database Driver Class Initialized
INFO - 2016-10-17 17:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:29:43 --> Controller Class Initialized
INFO - 2016-10-17 17:29:43 --> Model Class Initialized
INFO - 2016-10-17 17:29:43 --> Final output sent to browser
DEBUG - 2016-10-17 17:29:43 --> Total execution time: 0.0086
INFO - 2016-10-17 17:30:03 --> Config Class Initialized
INFO - 2016-10-17 17:30:03 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:30:03 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:30:03 --> Utf8 Class Initialized
INFO - 2016-10-17 17:30:03 --> URI Class Initialized
INFO - 2016-10-17 17:30:03 --> Router Class Initialized
INFO - 2016-10-17 17:30:03 --> Output Class Initialized
INFO - 2016-10-17 17:30:03 --> Security Class Initialized
DEBUG - 2016-10-17 17:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:30:03 --> Input Class Initialized
INFO - 2016-10-17 17:30:03 --> Language Class Initialized
INFO - 2016-10-17 17:30:03 --> Loader Class Initialized
INFO - 2016-10-17 17:30:03 --> Helper loaded: url_helper
INFO - 2016-10-17 17:30:03 --> Helper loaded: form_helper
INFO - 2016-10-17 17:30:03 --> Database Driver Class Initialized
INFO - 2016-10-17 17:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:30:03 --> Controller Class Initialized
INFO - 2016-10-17 17:30:03 --> Model Class Initialized
INFO - 2016-10-17 17:30:03 --> Final output sent to browser
DEBUG - 2016-10-17 17:30:03 --> Total execution time: 0.0056
INFO - 2016-10-17 17:30:03 --> Config Class Initialized
INFO - 2016-10-17 17:30:03 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:30:03 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:30:03 --> Utf8 Class Initialized
INFO - 2016-10-17 17:30:03 --> URI Class Initialized
DEBUG - 2016-10-17 17:30:03 --> No URI present. Default controller set.
INFO - 2016-10-17 17:30:03 --> Router Class Initialized
INFO - 2016-10-17 17:30:03 --> Output Class Initialized
INFO - 2016-10-17 17:30:03 --> Security Class Initialized
DEBUG - 2016-10-17 17:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:30:03 --> Input Class Initialized
INFO - 2016-10-17 17:30:03 --> Language Class Initialized
INFO - 2016-10-17 17:30:03 --> Loader Class Initialized
INFO - 2016-10-17 17:30:03 --> Helper loaded: url_helper
INFO - 2016-10-17 17:30:03 --> Helper loaded: form_helper
INFO - 2016-10-17 17:30:03 --> Database Driver Class Initialized
INFO - 2016-10-17 17:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:30:03 --> Controller Class Initialized
INFO - 2016-10-17 17:30:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:30:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 17:30:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 17:30:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:30:03 --> Final output sent to browser
DEBUG - 2016-10-17 17:30:03 --> Total execution time: 0.0040
INFO - 2016-10-17 17:30:06 --> Config Class Initialized
INFO - 2016-10-17 17:30:06 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:30:06 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:30:06 --> Utf8 Class Initialized
INFO - 2016-10-17 17:30:06 --> URI Class Initialized
INFO - 2016-10-17 17:30:06 --> Router Class Initialized
INFO - 2016-10-17 17:30:06 --> Output Class Initialized
INFO - 2016-10-17 17:30:06 --> Security Class Initialized
DEBUG - 2016-10-17 17:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:30:06 --> Input Class Initialized
INFO - 2016-10-17 17:30:06 --> Language Class Initialized
INFO - 2016-10-17 17:30:06 --> Loader Class Initialized
INFO - 2016-10-17 17:30:06 --> Helper loaded: url_helper
INFO - 2016-10-17 17:30:06 --> Helper loaded: form_helper
INFO - 2016-10-17 17:30:06 --> Database Driver Class Initialized
INFO - 2016-10-17 17:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:30:06 --> Controller Class Initialized
ERROR - 2016-10-17 17:30:06 --> Severity: Notice --> Undefined variable: name /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
ERROR - 2016-10-17 17:30:06 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
INFO - 2016-10-17 17:30:06 --> Config Class Initialized
INFO - 2016-10-17 17:30:06 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:30:06 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:30:06 --> Utf8 Class Initialized
INFO - 2016-10-17 17:30:06 --> URI Class Initialized
DEBUG - 2016-10-17 17:30:06 --> No URI present. Default controller set.
INFO - 2016-10-17 17:30:06 --> Router Class Initialized
INFO - 2016-10-17 17:30:06 --> Output Class Initialized
INFO - 2016-10-17 17:30:06 --> Security Class Initialized
DEBUG - 2016-10-17 17:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:30:06 --> Input Class Initialized
INFO - 2016-10-17 17:30:06 --> Language Class Initialized
INFO - 2016-10-17 17:30:06 --> Loader Class Initialized
INFO - 2016-10-17 17:30:06 --> Helper loaded: url_helper
INFO - 2016-10-17 17:30:06 --> Helper loaded: form_helper
INFO - 2016-10-17 17:30:06 --> Database Driver Class Initialized
INFO - 2016-10-17 17:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:30:06 --> Controller Class Initialized
INFO - 2016-10-17 17:30:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:30:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 17:30:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:30:06 --> Final output sent to browser
DEBUG - 2016-10-17 17:30:06 --> Total execution time: 0.0046
INFO - 2016-10-17 17:42:13 --> Config Class Initialized
INFO - 2016-10-17 17:42:13 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:42:13 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:42:13 --> Utf8 Class Initialized
INFO - 2016-10-17 17:42:13 --> URI Class Initialized
DEBUG - 2016-10-17 17:42:13 --> No URI present. Default controller set.
INFO - 2016-10-17 17:42:13 --> Router Class Initialized
INFO - 2016-10-17 17:42:13 --> Output Class Initialized
INFO - 2016-10-17 17:42:13 --> Security Class Initialized
DEBUG - 2016-10-17 17:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:42:13 --> Input Class Initialized
INFO - 2016-10-17 17:42:13 --> Language Class Initialized
INFO - 2016-10-17 17:42:13 --> Loader Class Initialized
INFO - 2016-10-17 17:42:13 --> Helper loaded: url_helper
INFO - 2016-10-17 17:42:13 --> Helper loaded: form_helper
INFO - 2016-10-17 17:42:13 --> Database Driver Class Initialized
INFO - 2016-10-17 17:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:42:13 --> Controller Class Initialized
INFO - 2016-10-17 17:42:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:42:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 17:42:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:42:13 --> Final output sent to browser
DEBUG - 2016-10-17 17:42:13 --> Total execution time: 0.0090
INFO - 2016-10-17 17:42:18 --> Config Class Initialized
INFO - 2016-10-17 17:42:18 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:42:18 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:42:18 --> Utf8 Class Initialized
INFO - 2016-10-17 17:42:18 --> URI Class Initialized
INFO - 2016-10-17 17:42:18 --> Router Class Initialized
INFO - 2016-10-17 17:42:18 --> Output Class Initialized
INFO - 2016-10-17 17:42:18 --> Security Class Initialized
DEBUG - 2016-10-17 17:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:42:18 --> Input Class Initialized
INFO - 2016-10-17 17:42:18 --> Language Class Initialized
INFO - 2016-10-17 17:42:18 --> Loader Class Initialized
INFO - 2016-10-17 17:42:18 --> Helper loaded: url_helper
INFO - 2016-10-17 17:42:18 --> Helper loaded: form_helper
INFO - 2016-10-17 17:42:18 --> Database Driver Class Initialized
INFO - 2016-10-17 17:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:42:18 --> Controller Class Initialized
INFO - 2016-10-17 17:42:18 --> Model Class Initialized
INFO - 2016-10-17 17:42:18 --> Final output sent to browser
DEBUG - 2016-10-17 17:42:18 --> Total execution time: 0.0082
INFO - 2016-10-17 17:49:22 --> Config Class Initialized
INFO - 2016-10-17 17:49:22 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:49:22 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:49:22 --> Utf8 Class Initialized
INFO - 2016-10-17 17:49:22 --> URI Class Initialized
DEBUG - 2016-10-17 17:49:22 --> No URI present. Default controller set.
INFO - 2016-10-17 17:49:22 --> Router Class Initialized
INFO - 2016-10-17 17:49:22 --> Output Class Initialized
INFO - 2016-10-17 17:49:22 --> Security Class Initialized
DEBUG - 2016-10-17 17:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:49:22 --> Input Class Initialized
INFO - 2016-10-17 17:49:22 --> Language Class Initialized
INFO - 2016-10-17 17:49:22 --> Loader Class Initialized
INFO - 2016-10-17 17:49:22 --> Helper loaded: url_helper
INFO - 2016-10-17 17:49:22 --> Helper loaded: form_helper
INFO - 2016-10-17 17:49:22 --> Database Driver Class Initialized
INFO - 2016-10-17 17:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:49:22 --> Controller Class Initialized
INFO - 2016-10-17 17:49:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:49:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 17:49:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:49:22 --> Final output sent to browser
DEBUG - 2016-10-17 17:49:22 --> Total execution time: 0.0200
INFO - 2016-10-17 17:49:33 --> Config Class Initialized
INFO - 2016-10-17 17:49:33 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:49:33 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:49:33 --> Utf8 Class Initialized
INFO - 2016-10-17 17:49:33 --> URI Class Initialized
INFO - 2016-10-17 17:49:33 --> Router Class Initialized
INFO - 2016-10-17 17:49:33 --> Output Class Initialized
INFO - 2016-10-17 17:49:33 --> Security Class Initialized
DEBUG - 2016-10-17 17:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:49:33 --> Input Class Initialized
INFO - 2016-10-17 17:49:33 --> Language Class Initialized
INFO - 2016-10-17 17:49:33 --> Loader Class Initialized
INFO - 2016-10-17 17:49:33 --> Helper loaded: url_helper
INFO - 2016-10-17 17:49:33 --> Helper loaded: form_helper
INFO - 2016-10-17 17:49:33 --> Database Driver Class Initialized
INFO - 2016-10-17 17:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:49:33 --> Controller Class Initialized
INFO - 2016-10-17 17:49:33 --> Model Class Initialized
INFO - 2016-10-17 17:49:33 --> Final output sent to browser
DEBUG - 2016-10-17 17:49:33 --> Total execution time: 0.0069
INFO - 2016-10-17 17:49:40 --> Config Class Initialized
INFO - 2016-10-17 17:49:40 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:49:40 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:49:40 --> Utf8 Class Initialized
INFO - 2016-10-17 17:49:40 --> URI Class Initialized
INFO - 2016-10-17 17:49:40 --> Router Class Initialized
INFO - 2016-10-17 17:49:40 --> Output Class Initialized
INFO - 2016-10-17 17:49:40 --> Security Class Initialized
DEBUG - 2016-10-17 17:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:49:40 --> Input Class Initialized
INFO - 2016-10-17 17:49:40 --> Language Class Initialized
INFO - 2016-10-17 17:49:40 --> Loader Class Initialized
INFO - 2016-10-17 17:49:40 --> Helper loaded: url_helper
INFO - 2016-10-17 17:49:40 --> Helper loaded: form_helper
INFO - 2016-10-17 17:49:40 --> Database Driver Class Initialized
INFO - 2016-10-17 17:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:49:40 --> Controller Class Initialized
INFO - 2016-10-17 17:49:40 --> Model Class Initialized
INFO - 2016-10-17 17:49:40 --> Final output sent to browser
DEBUG - 2016-10-17 17:49:40 --> Total execution time: 0.0080
INFO - 2016-10-17 17:49:41 --> Config Class Initialized
INFO - 2016-10-17 17:49:41 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:49:41 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:49:41 --> Utf8 Class Initialized
INFO - 2016-10-17 17:49:41 --> URI Class Initialized
DEBUG - 2016-10-17 17:49:41 --> No URI present. Default controller set.
INFO - 2016-10-17 17:49:41 --> Router Class Initialized
INFO - 2016-10-17 17:49:41 --> Output Class Initialized
INFO - 2016-10-17 17:49:41 --> Security Class Initialized
DEBUG - 2016-10-17 17:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:49:41 --> Input Class Initialized
INFO - 2016-10-17 17:49:41 --> Language Class Initialized
INFO - 2016-10-17 17:49:41 --> Loader Class Initialized
INFO - 2016-10-17 17:49:41 --> Helper loaded: url_helper
INFO - 2016-10-17 17:49:41 --> Helper loaded: form_helper
INFO - 2016-10-17 17:49:41 --> Database Driver Class Initialized
INFO - 2016-10-17 17:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:49:41 --> Controller Class Initialized
INFO - 2016-10-17 17:49:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:49:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 17:49:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 17:49:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:49:41 --> Final output sent to browser
DEBUG - 2016-10-17 17:49:41 --> Total execution time: 0.0041
INFO - 2016-10-17 17:52:15 --> Config Class Initialized
INFO - 2016-10-17 17:52:15 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:52:15 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:52:15 --> Utf8 Class Initialized
INFO - 2016-10-17 17:52:15 --> URI Class Initialized
DEBUG - 2016-10-17 17:52:15 --> No URI present. Default controller set.
INFO - 2016-10-17 17:52:15 --> Router Class Initialized
INFO - 2016-10-17 17:52:15 --> Output Class Initialized
INFO - 2016-10-17 17:52:15 --> Security Class Initialized
DEBUG - 2016-10-17 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:52:15 --> Input Class Initialized
INFO - 2016-10-17 17:52:15 --> Language Class Initialized
INFO - 2016-10-17 17:52:15 --> Loader Class Initialized
INFO - 2016-10-17 17:52:15 --> Helper loaded: url_helper
INFO - 2016-10-17 17:52:15 --> Helper loaded: form_helper
INFO - 2016-10-17 17:52:15 --> Database Driver Class Initialized
INFO - 2016-10-17 17:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:52:15 --> Controller Class Initialized
INFO - 2016-10-17 17:52:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:52:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 17:52:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 17:52:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:52:15 --> Final output sent to browser
DEBUG - 2016-10-17 17:52:15 --> Total execution time: 0.0056
INFO - 2016-10-17 17:53:17 --> Config Class Initialized
INFO - 2016-10-17 17:53:17 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:53:17 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:53:17 --> Utf8 Class Initialized
INFO - 2016-10-17 17:53:17 --> URI Class Initialized
INFO - 2016-10-17 17:53:17 --> Router Class Initialized
INFO - 2016-10-17 17:53:17 --> Output Class Initialized
INFO - 2016-10-17 17:53:17 --> Security Class Initialized
DEBUG - 2016-10-17 17:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:53:17 --> Input Class Initialized
INFO - 2016-10-17 17:53:17 --> Language Class Initialized
INFO - 2016-10-17 17:53:17 --> Loader Class Initialized
INFO - 2016-10-17 17:53:17 --> Helper loaded: url_helper
INFO - 2016-10-17 17:53:17 --> Helper loaded: form_helper
INFO - 2016-10-17 17:53:17 --> Database Driver Class Initialized
INFO - 2016-10-17 17:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:53:17 --> Controller Class Initialized
ERROR - 2016-10-17 17:53:17 --> Severity: Notice --> Undefined variable: name /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
ERROR - 2016-10-17 17:53:17 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
INFO - 2016-10-17 17:53:17 --> Config Class Initialized
INFO - 2016-10-17 17:53:17 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:53:17 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:53:17 --> Utf8 Class Initialized
INFO - 2016-10-17 17:53:17 --> URI Class Initialized
DEBUG - 2016-10-17 17:53:17 --> No URI present. Default controller set.
INFO - 2016-10-17 17:53:17 --> Router Class Initialized
INFO - 2016-10-17 17:53:17 --> Output Class Initialized
INFO - 2016-10-17 17:53:17 --> Security Class Initialized
DEBUG - 2016-10-17 17:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:53:17 --> Input Class Initialized
INFO - 2016-10-17 17:53:17 --> Language Class Initialized
INFO - 2016-10-17 17:53:17 --> Loader Class Initialized
INFO - 2016-10-17 17:53:17 --> Helper loaded: url_helper
INFO - 2016-10-17 17:53:17 --> Helper loaded: form_helper
INFO - 2016-10-17 17:53:17 --> Database Driver Class Initialized
INFO - 2016-10-17 17:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:53:17 --> Controller Class Initialized
INFO - 2016-10-17 17:53:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:53:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 17:53:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:53:17 --> Final output sent to browser
DEBUG - 2016-10-17 17:53:17 --> Total execution time: 0.0044
INFO - 2016-10-17 17:53:23 --> Config Class Initialized
INFO - 2016-10-17 17:53:23 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:53:23 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:53:23 --> Utf8 Class Initialized
INFO - 2016-10-17 17:53:23 --> URI Class Initialized
INFO - 2016-10-17 17:53:23 --> Router Class Initialized
INFO - 2016-10-17 17:53:23 --> Output Class Initialized
INFO - 2016-10-17 17:53:23 --> Security Class Initialized
DEBUG - 2016-10-17 17:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:53:23 --> Input Class Initialized
INFO - 2016-10-17 17:53:23 --> Language Class Initialized
INFO - 2016-10-17 17:53:23 --> Loader Class Initialized
INFO - 2016-10-17 17:53:23 --> Helper loaded: url_helper
INFO - 2016-10-17 17:53:23 --> Helper loaded: form_helper
INFO - 2016-10-17 17:53:23 --> Database Driver Class Initialized
INFO - 2016-10-17 17:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:53:23 --> Controller Class Initialized
INFO - 2016-10-17 17:53:23 --> Model Class Initialized
INFO - 2016-10-17 17:53:23 --> Final output sent to browser
DEBUG - 2016-10-17 17:53:23 --> Total execution time: 0.0053
INFO - 2016-10-17 17:53:30 --> Config Class Initialized
INFO - 2016-10-17 17:53:30 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:53:30 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:53:30 --> Utf8 Class Initialized
INFO - 2016-10-17 17:53:30 --> URI Class Initialized
INFO - 2016-10-17 17:53:30 --> Router Class Initialized
INFO - 2016-10-17 17:53:30 --> Output Class Initialized
INFO - 2016-10-17 17:53:30 --> Security Class Initialized
DEBUG - 2016-10-17 17:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:53:30 --> Input Class Initialized
INFO - 2016-10-17 17:53:30 --> Language Class Initialized
INFO - 2016-10-17 17:53:30 --> Loader Class Initialized
INFO - 2016-10-17 17:53:30 --> Helper loaded: url_helper
INFO - 2016-10-17 17:53:30 --> Helper loaded: form_helper
INFO - 2016-10-17 17:53:30 --> Database Driver Class Initialized
INFO - 2016-10-17 17:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:53:30 --> Controller Class Initialized
INFO - 2016-10-17 17:53:30 --> Model Class Initialized
INFO - 2016-10-17 17:53:30 --> Final output sent to browser
DEBUG - 2016-10-17 17:53:30 --> Total execution time: 0.0059
INFO - 2016-10-17 17:53:38 --> Config Class Initialized
INFO - 2016-10-17 17:53:38 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:53:38 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:53:38 --> Utf8 Class Initialized
INFO - 2016-10-17 17:53:38 --> URI Class Initialized
INFO - 2016-10-17 17:53:38 --> Router Class Initialized
INFO - 2016-10-17 17:53:38 --> Output Class Initialized
INFO - 2016-10-17 17:53:38 --> Security Class Initialized
DEBUG - 2016-10-17 17:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:53:38 --> Input Class Initialized
INFO - 2016-10-17 17:53:38 --> Language Class Initialized
INFO - 2016-10-17 17:53:38 --> Loader Class Initialized
INFO - 2016-10-17 17:53:38 --> Helper loaded: url_helper
INFO - 2016-10-17 17:53:38 --> Helper loaded: form_helper
INFO - 2016-10-17 17:53:38 --> Database Driver Class Initialized
INFO - 2016-10-17 17:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:53:38 --> Controller Class Initialized
INFO - 2016-10-17 17:53:38 --> Model Class Initialized
INFO - 2016-10-17 17:53:38 --> Final output sent to browser
DEBUG - 2016-10-17 17:53:38 --> Total execution time: 0.0052
INFO - 2016-10-17 17:53:38 --> Config Class Initialized
INFO - 2016-10-17 17:53:38 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:53:38 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:53:38 --> Utf8 Class Initialized
INFO - 2016-10-17 17:53:38 --> URI Class Initialized
DEBUG - 2016-10-17 17:53:38 --> No URI present. Default controller set.
INFO - 2016-10-17 17:53:38 --> Router Class Initialized
INFO - 2016-10-17 17:53:38 --> Output Class Initialized
INFO - 2016-10-17 17:53:38 --> Security Class Initialized
DEBUG - 2016-10-17 17:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:53:38 --> Input Class Initialized
INFO - 2016-10-17 17:53:38 --> Language Class Initialized
INFO - 2016-10-17 17:53:38 --> Loader Class Initialized
INFO - 2016-10-17 17:53:38 --> Helper loaded: url_helper
INFO - 2016-10-17 17:53:38 --> Helper loaded: form_helper
INFO - 2016-10-17 17:53:38 --> Database Driver Class Initialized
INFO - 2016-10-17 17:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:53:38 --> Controller Class Initialized
INFO - 2016-10-17 17:53:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 17:53:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 17:53:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 17:53:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 17:53:38 --> Final output sent to browser
DEBUG - 2016-10-17 17:53:38 --> Total execution time: 0.0050
INFO - 2016-10-17 18:14:20 --> Config Class Initialized
INFO - 2016-10-17 18:14:20 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:14:20 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:14:20 --> Utf8 Class Initialized
INFO - 2016-10-17 18:14:20 --> URI Class Initialized
DEBUG - 2016-10-17 18:14:20 --> No URI present. Default controller set.
INFO - 2016-10-17 18:14:20 --> Router Class Initialized
INFO - 2016-10-17 18:14:20 --> Output Class Initialized
INFO - 2016-10-17 18:14:20 --> Security Class Initialized
DEBUG - 2016-10-17 18:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:14:20 --> Input Class Initialized
INFO - 2016-10-17 18:14:20 --> Language Class Initialized
INFO - 2016-10-17 18:14:20 --> Loader Class Initialized
INFO - 2016-10-17 18:14:20 --> Helper loaded: url_helper
INFO - 2016-10-17 18:14:20 --> Helper loaded: form_helper
INFO - 2016-10-17 18:14:20 --> Database Driver Class Initialized
INFO - 2016-10-17 18:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:14:20 --> Controller Class Initialized
INFO - 2016-10-17 18:14:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:14:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:14:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:14:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:14:20 --> Final output sent to browser
DEBUG - 2016-10-17 18:14:20 --> Total execution time: 0.0226
INFO - 2016-10-17 18:15:11 --> Config Class Initialized
INFO - 2016-10-17 18:15:11 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:15:11 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:15:11 --> Utf8 Class Initialized
INFO - 2016-10-17 18:15:11 --> URI Class Initialized
DEBUG - 2016-10-17 18:15:11 --> No URI present. Default controller set.
INFO - 2016-10-17 18:15:11 --> Router Class Initialized
INFO - 2016-10-17 18:15:11 --> Output Class Initialized
INFO - 2016-10-17 18:15:11 --> Security Class Initialized
DEBUG - 2016-10-17 18:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:15:11 --> Input Class Initialized
INFO - 2016-10-17 18:15:11 --> Language Class Initialized
INFO - 2016-10-17 18:15:11 --> Loader Class Initialized
INFO - 2016-10-17 18:15:11 --> Helper loaded: url_helper
INFO - 2016-10-17 18:15:11 --> Helper loaded: form_helper
INFO - 2016-10-17 18:15:11 --> Database Driver Class Initialized
INFO - 2016-10-17 18:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:15:11 --> Controller Class Initialized
INFO - 2016-10-17 18:15:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:15:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:15:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:15:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:15:11 --> Final output sent to browser
DEBUG - 2016-10-17 18:15:11 --> Total execution time: 0.0051
INFO - 2016-10-17 18:15:23 --> Config Class Initialized
INFO - 2016-10-17 18:15:23 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:15:23 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:15:23 --> Utf8 Class Initialized
INFO - 2016-10-17 18:15:23 --> URI Class Initialized
DEBUG - 2016-10-17 18:15:23 --> No URI present. Default controller set.
INFO - 2016-10-17 18:15:23 --> Router Class Initialized
INFO - 2016-10-17 18:15:23 --> Output Class Initialized
INFO - 2016-10-17 18:15:23 --> Security Class Initialized
DEBUG - 2016-10-17 18:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:15:23 --> Input Class Initialized
INFO - 2016-10-17 18:15:23 --> Language Class Initialized
INFO - 2016-10-17 18:15:23 --> Loader Class Initialized
INFO - 2016-10-17 18:15:23 --> Helper loaded: url_helper
INFO - 2016-10-17 18:15:23 --> Helper loaded: form_helper
INFO - 2016-10-17 18:15:23 --> Database Driver Class Initialized
INFO - 2016-10-17 18:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:15:23 --> Controller Class Initialized
INFO - 2016-10-17 18:15:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:15:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:15:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:15:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:15:23 --> Final output sent to browser
DEBUG - 2016-10-17 18:15:23 --> Total execution time: 0.0078
INFO - 2016-10-17 18:21:21 --> Config Class Initialized
INFO - 2016-10-17 18:21:21 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:21:21 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:21:21 --> Utf8 Class Initialized
INFO - 2016-10-17 18:21:21 --> URI Class Initialized
DEBUG - 2016-10-17 18:21:21 --> No URI present. Default controller set.
INFO - 2016-10-17 18:21:21 --> Router Class Initialized
INFO - 2016-10-17 18:21:21 --> Output Class Initialized
INFO - 2016-10-17 18:21:21 --> Security Class Initialized
DEBUG - 2016-10-17 18:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:21:21 --> Input Class Initialized
INFO - 2016-10-17 18:21:21 --> Language Class Initialized
INFO - 2016-10-17 18:21:21 --> Loader Class Initialized
INFO - 2016-10-17 18:21:21 --> Helper loaded: url_helper
INFO - 2016-10-17 18:21:21 --> Helper loaded: form_helper
INFO - 2016-10-17 18:21:21 --> Database Driver Class Initialized
INFO - 2016-10-17 18:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:21:21 --> Controller Class Initialized
INFO - 2016-10-17 18:21:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:21:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:21:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:21:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:21:21 --> Final output sent to browser
DEBUG - 2016-10-17 18:21:21 --> Total execution time: 0.0084
INFO - 2016-10-17 18:24:28 --> Config Class Initialized
INFO - 2016-10-17 18:24:28 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:24:28 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:24:28 --> Utf8 Class Initialized
INFO - 2016-10-17 18:24:28 --> URI Class Initialized
DEBUG - 2016-10-17 18:24:28 --> No URI present. Default controller set.
INFO - 2016-10-17 18:24:28 --> Router Class Initialized
INFO - 2016-10-17 18:24:28 --> Output Class Initialized
INFO - 2016-10-17 18:24:28 --> Security Class Initialized
DEBUG - 2016-10-17 18:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:24:28 --> Input Class Initialized
INFO - 2016-10-17 18:24:28 --> Language Class Initialized
INFO - 2016-10-17 18:24:28 --> Loader Class Initialized
INFO - 2016-10-17 18:24:28 --> Helper loaded: url_helper
INFO - 2016-10-17 18:24:28 --> Helper loaded: form_helper
INFO - 2016-10-17 18:24:28 --> Database Driver Class Initialized
INFO - 2016-10-17 18:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:24:28 --> Controller Class Initialized
INFO - 2016-10-17 18:24:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:24:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:24:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:24:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:24:28 --> Final output sent to browser
DEBUG - 2016-10-17 18:24:28 --> Total execution time: 0.0057
INFO - 2016-10-17 18:24:30 --> Config Class Initialized
INFO - 2016-10-17 18:24:30 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:24:30 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:24:30 --> Utf8 Class Initialized
INFO - 2016-10-17 18:24:30 --> URI Class Initialized
DEBUG - 2016-10-17 18:24:30 --> No URI present. Default controller set.
INFO - 2016-10-17 18:24:30 --> Router Class Initialized
INFO - 2016-10-17 18:24:30 --> Output Class Initialized
INFO - 2016-10-17 18:24:30 --> Security Class Initialized
DEBUG - 2016-10-17 18:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:24:30 --> Input Class Initialized
INFO - 2016-10-17 18:24:30 --> Language Class Initialized
INFO - 2016-10-17 18:24:30 --> Loader Class Initialized
INFO - 2016-10-17 18:24:30 --> Helper loaded: url_helper
INFO - 2016-10-17 18:24:30 --> Helper loaded: form_helper
INFO - 2016-10-17 18:24:30 --> Database Driver Class Initialized
INFO - 2016-10-17 18:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:24:30 --> Controller Class Initialized
INFO - 2016-10-17 18:24:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:24:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:24:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:24:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:24:30 --> Final output sent to browser
DEBUG - 2016-10-17 18:24:30 --> Total execution time: 0.0052
INFO - 2016-10-17 18:25:48 --> Config Class Initialized
INFO - 2016-10-17 18:25:48 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:25:48 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:25:48 --> Utf8 Class Initialized
INFO - 2016-10-17 18:25:48 --> URI Class Initialized
DEBUG - 2016-10-17 18:25:48 --> No URI present. Default controller set.
INFO - 2016-10-17 18:25:48 --> Router Class Initialized
INFO - 2016-10-17 18:25:48 --> Output Class Initialized
INFO - 2016-10-17 18:25:48 --> Security Class Initialized
DEBUG - 2016-10-17 18:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:25:48 --> Input Class Initialized
INFO - 2016-10-17 18:25:48 --> Language Class Initialized
INFO - 2016-10-17 18:25:48 --> Loader Class Initialized
INFO - 2016-10-17 18:25:48 --> Helper loaded: url_helper
INFO - 2016-10-17 18:25:48 --> Helper loaded: form_helper
INFO - 2016-10-17 18:25:48 --> Database Driver Class Initialized
INFO - 2016-10-17 18:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:25:48 --> Controller Class Initialized
INFO - 2016-10-17 18:25:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:25:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:25:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:25:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:25:48 --> Final output sent to browser
DEBUG - 2016-10-17 18:25:48 --> Total execution time: 0.0080
INFO - 2016-10-17 18:26:04 --> Config Class Initialized
INFO - 2016-10-17 18:26:04 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:26:04 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:26:04 --> Utf8 Class Initialized
INFO - 2016-10-17 18:26:04 --> URI Class Initialized
DEBUG - 2016-10-17 18:26:04 --> No URI present. Default controller set.
INFO - 2016-10-17 18:26:04 --> Router Class Initialized
INFO - 2016-10-17 18:26:04 --> Output Class Initialized
INFO - 2016-10-17 18:26:04 --> Security Class Initialized
DEBUG - 2016-10-17 18:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:26:04 --> Input Class Initialized
INFO - 2016-10-17 18:26:04 --> Language Class Initialized
INFO - 2016-10-17 18:26:04 --> Loader Class Initialized
INFO - 2016-10-17 18:26:04 --> Helper loaded: url_helper
INFO - 2016-10-17 18:26:04 --> Helper loaded: form_helper
INFO - 2016-10-17 18:26:04 --> Database Driver Class Initialized
INFO - 2016-10-17 18:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:26:04 --> Controller Class Initialized
INFO - 2016-10-17 18:26:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:26:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:26:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:26:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:26:04 --> Final output sent to browser
DEBUG - 2016-10-17 18:26:04 --> Total execution time: 0.0055
INFO - 2016-10-17 18:28:45 --> Config Class Initialized
INFO - 2016-10-17 18:28:45 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:28:45 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:28:45 --> Utf8 Class Initialized
INFO - 2016-10-17 18:28:45 --> URI Class Initialized
DEBUG - 2016-10-17 18:28:45 --> No URI present. Default controller set.
INFO - 2016-10-17 18:28:45 --> Router Class Initialized
INFO - 2016-10-17 18:28:45 --> Output Class Initialized
INFO - 2016-10-17 18:28:45 --> Security Class Initialized
DEBUG - 2016-10-17 18:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:28:45 --> Input Class Initialized
INFO - 2016-10-17 18:28:45 --> Language Class Initialized
INFO - 2016-10-17 18:28:45 --> Loader Class Initialized
INFO - 2016-10-17 18:28:45 --> Helper loaded: url_helper
INFO - 2016-10-17 18:28:45 --> Helper loaded: form_helper
INFO - 2016-10-17 18:28:45 --> Database Driver Class Initialized
INFO - 2016-10-17 18:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:28:45 --> Controller Class Initialized
INFO - 2016-10-17 18:28:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:28:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:28:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:28:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:28:45 --> Final output sent to browser
DEBUG - 2016-10-17 18:28:45 --> Total execution time: 0.0083
INFO - 2016-10-17 18:28:52 --> Config Class Initialized
INFO - 2016-10-17 18:28:52 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:28:52 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:28:52 --> Utf8 Class Initialized
INFO - 2016-10-17 18:28:52 --> URI Class Initialized
DEBUG - 2016-10-17 18:28:52 --> No URI present. Default controller set.
INFO - 2016-10-17 18:28:52 --> Router Class Initialized
INFO - 2016-10-17 18:28:52 --> Output Class Initialized
INFO - 2016-10-17 18:28:52 --> Security Class Initialized
DEBUG - 2016-10-17 18:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:28:52 --> Input Class Initialized
INFO - 2016-10-17 18:28:52 --> Language Class Initialized
INFO - 2016-10-17 18:28:52 --> Loader Class Initialized
INFO - 2016-10-17 18:28:52 --> Helper loaded: url_helper
INFO - 2016-10-17 18:28:52 --> Helper loaded: form_helper
INFO - 2016-10-17 18:28:52 --> Database Driver Class Initialized
INFO - 2016-10-17 18:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:28:52 --> Controller Class Initialized
INFO - 2016-10-17 18:28:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:28:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:28:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:28:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:28:52 --> Final output sent to browser
DEBUG - 2016-10-17 18:28:52 --> Total execution time: 0.0052
INFO - 2016-10-17 18:28:55 --> Config Class Initialized
INFO - 2016-10-17 18:28:55 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:28:55 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:28:55 --> Utf8 Class Initialized
INFO - 2016-10-17 18:28:55 --> URI Class Initialized
DEBUG - 2016-10-17 18:28:55 --> No URI present. Default controller set.
INFO - 2016-10-17 18:28:55 --> Router Class Initialized
INFO - 2016-10-17 18:28:55 --> Output Class Initialized
INFO - 2016-10-17 18:28:55 --> Security Class Initialized
DEBUG - 2016-10-17 18:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:28:55 --> Input Class Initialized
INFO - 2016-10-17 18:28:55 --> Language Class Initialized
INFO - 2016-10-17 18:28:55 --> Loader Class Initialized
INFO - 2016-10-17 18:28:55 --> Helper loaded: url_helper
INFO - 2016-10-17 18:28:55 --> Helper loaded: form_helper
INFO - 2016-10-17 18:28:55 --> Database Driver Class Initialized
INFO - 2016-10-17 18:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:28:55 --> Controller Class Initialized
INFO - 2016-10-17 18:28:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:28:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:28:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:28:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:28:55 --> Final output sent to browser
DEBUG - 2016-10-17 18:28:55 --> Total execution time: 0.0044
INFO - 2016-10-17 18:28:58 --> Config Class Initialized
INFO - 2016-10-17 18:28:58 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:28:58 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:28:58 --> Utf8 Class Initialized
INFO - 2016-10-17 18:28:58 --> URI Class Initialized
DEBUG - 2016-10-17 18:28:58 --> No URI present. Default controller set.
INFO - 2016-10-17 18:28:58 --> Router Class Initialized
INFO - 2016-10-17 18:28:58 --> Output Class Initialized
INFO - 2016-10-17 18:28:58 --> Security Class Initialized
DEBUG - 2016-10-17 18:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:28:58 --> Input Class Initialized
INFO - 2016-10-17 18:28:58 --> Language Class Initialized
INFO - 2016-10-17 18:28:58 --> Loader Class Initialized
INFO - 2016-10-17 18:28:58 --> Helper loaded: url_helper
INFO - 2016-10-17 18:28:58 --> Helper loaded: form_helper
INFO - 2016-10-17 18:28:58 --> Database Driver Class Initialized
INFO - 2016-10-17 18:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:28:58 --> Controller Class Initialized
INFO - 2016-10-17 18:28:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:28:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:28:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:28:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:28:58 --> Final output sent to browser
DEBUG - 2016-10-17 18:28:58 --> Total execution time: 0.0045
INFO - 2016-10-17 18:30:07 --> Config Class Initialized
INFO - 2016-10-17 18:30:07 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:30:07 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:30:07 --> Utf8 Class Initialized
INFO - 2016-10-17 18:30:07 --> URI Class Initialized
DEBUG - 2016-10-17 18:30:07 --> No URI present. Default controller set.
INFO - 2016-10-17 18:30:07 --> Router Class Initialized
INFO - 2016-10-17 18:30:07 --> Output Class Initialized
INFO - 2016-10-17 18:30:07 --> Security Class Initialized
DEBUG - 2016-10-17 18:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:30:07 --> Input Class Initialized
INFO - 2016-10-17 18:30:07 --> Language Class Initialized
INFO - 2016-10-17 18:30:07 --> Loader Class Initialized
INFO - 2016-10-17 18:30:07 --> Helper loaded: url_helper
INFO - 2016-10-17 18:30:07 --> Helper loaded: form_helper
INFO - 2016-10-17 18:30:07 --> Database Driver Class Initialized
INFO - 2016-10-17 18:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:30:07 --> Controller Class Initialized
INFO - 2016-10-17 18:30:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:30:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:30:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:30:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:30:07 --> Final output sent to browser
DEBUG - 2016-10-17 18:30:07 --> Total execution time: 0.0075
INFO - 2016-10-17 18:30:55 --> Config Class Initialized
INFO - 2016-10-17 18:30:55 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:30:55 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:30:55 --> Utf8 Class Initialized
INFO - 2016-10-17 18:30:55 --> URI Class Initialized
INFO - 2016-10-17 18:30:55 --> Router Class Initialized
INFO - 2016-10-17 18:30:55 --> Output Class Initialized
INFO - 2016-10-17 18:30:55 --> Security Class Initialized
DEBUG - 2016-10-17 18:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:30:55 --> Input Class Initialized
INFO - 2016-10-17 18:30:55 --> Language Class Initialized
ERROR - 2016-10-17 18:30:55 --> 404 Page Not Found: Leave/apply_leave.php
INFO - 2016-10-17 18:31:20 --> Config Class Initialized
INFO - 2016-10-17 18:31:20 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:31:20 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:31:20 --> Utf8 Class Initialized
INFO - 2016-10-17 18:31:20 --> URI Class Initialized
INFO - 2016-10-17 18:31:20 --> Router Class Initialized
INFO - 2016-10-17 18:31:20 --> Output Class Initialized
INFO - 2016-10-17 18:31:20 --> Security Class Initialized
DEBUG - 2016-10-17 18:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:31:20 --> Input Class Initialized
INFO - 2016-10-17 18:31:20 --> Language Class Initialized
ERROR - 2016-10-17 18:31:20 --> 404 Page Not Found: Leave/apply_leave.php
INFO - 2016-10-17 18:31:28 --> Config Class Initialized
INFO - 2016-10-17 18:31:28 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:31:28 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:31:28 --> Utf8 Class Initialized
INFO - 2016-10-17 18:31:28 --> URI Class Initialized
DEBUG - 2016-10-17 18:31:28 --> No URI present. Default controller set.
INFO - 2016-10-17 18:31:28 --> Router Class Initialized
INFO - 2016-10-17 18:31:28 --> Output Class Initialized
INFO - 2016-10-17 18:31:28 --> Security Class Initialized
DEBUG - 2016-10-17 18:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:31:28 --> Input Class Initialized
INFO - 2016-10-17 18:31:28 --> Language Class Initialized
INFO - 2016-10-17 18:31:28 --> Loader Class Initialized
INFO - 2016-10-17 18:31:28 --> Helper loaded: url_helper
INFO - 2016-10-17 18:31:28 --> Helper loaded: form_helper
INFO - 2016-10-17 18:31:28 --> Database Driver Class Initialized
INFO - 2016-10-17 18:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:31:28 --> Controller Class Initialized
INFO - 2016-10-17 18:31:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:31:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:31:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:31:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:31:28 --> Final output sent to browser
DEBUG - 2016-10-17 18:31:28 --> Total execution time: 0.0084
INFO - 2016-10-17 18:31:35 --> Config Class Initialized
INFO - 2016-10-17 18:31:35 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:31:35 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:31:35 --> Utf8 Class Initialized
INFO - 2016-10-17 18:31:35 --> URI Class Initialized
DEBUG - 2016-10-17 18:31:35 --> No URI present. Default controller set.
INFO - 2016-10-17 18:31:35 --> Router Class Initialized
INFO - 2016-10-17 18:31:35 --> Output Class Initialized
INFO - 2016-10-17 18:31:35 --> Security Class Initialized
DEBUG - 2016-10-17 18:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:31:35 --> Input Class Initialized
INFO - 2016-10-17 18:31:35 --> Language Class Initialized
INFO - 2016-10-17 18:31:35 --> Loader Class Initialized
INFO - 2016-10-17 18:31:35 --> Helper loaded: url_helper
INFO - 2016-10-17 18:31:35 --> Helper loaded: form_helper
INFO - 2016-10-17 18:31:35 --> Database Driver Class Initialized
INFO - 2016-10-17 18:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:31:35 --> Controller Class Initialized
INFO - 2016-10-17 18:31:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:31:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:31:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:31:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:31:35 --> Final output sent to browser
DEBUG - 2016-10-17 18:31:35 --> Total execution time: 0.0051
INFO - 2016-10-17 18:33:50 --> Config Class Initialized
INFO - 2016-10-17 18:33:50 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:33:50 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:33:50 --> Utf8 Class Initialized
INFO - 2016-10-17 18:33:50 --> URI Class Initialized
DEBUG - 2016-10-17 18:33:50 --> No URI present. Default controller set.
INFO - 2016-10-17 18:33:50 --> Router Class Initialized
INFO - 2016-10-17 18:33:50 --> Output Class Initialized
INFO - 2016-10-17 18:33:50 --> Security Class Initialized
DEBUG - 2016-10-17 18:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:33:50 --> Input Class Initialized
INFO - 2016-10-17 18:33:50 --> Language Class Initialized
INFO - 2016-10-17 18:33:50 --> Loader Class Initialized
INFO - 2016-10-17 18:33:50 --> Helper loaded: url_helper
INFO - 2016-10-17 18:33:50 --> Helper loaded: form_helper
INFO - 2016-10-17 18:33:50 --> Database Driver Class Initialized
INFO - 2016-10-17 18:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:33:50 --> Controller Class Initialized
INFO - 2016-10-17 18:33:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:33:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:33:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:33:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:33:50 --> Final output sent to browser
DEBUG - 2016-10-17 18:33:50 --> Total execution time: 0.0057
INFO - 2016-10-17 18:33:53 --> Config Class Initialized
INFO - 2016-10-17 18:33:53 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:33:53 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:33:53 --> Utf8 Class Initialized
INFO - 2016-10-17 18:33:53 --> URI Class Initialized
DEBUG - 2016-10-17 18:33:53 --> No URI present. Default controller set.
INFO - 2016-10-17 18:33:53 --> Router Class Initialized
INFO - 2016-10-17 18:33:53 --> Output Class Initialized
INFO - 2016-10-17 18:33:53 --> Security Class Initialized
DEBUG - 2016-10-17 18:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:33:53 --> Input Class Initialized
INFO - 2016-10-17 18:33:53 --> Language Class Initialized
INFO - 2016-10-17 18:33:53 --> Loader Class Initialized
INFO - 2016-10-17 18:33:53 --> Helper loaded: url_helper
INFO - 2016-10-17 18:33:53 --> Helper loaded: form_helper
INFO - 2016-10-17 18:33:53 --> Database Driver Class Initialized
INFO - 2016-10-17 18:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:33:53 --> Controller Class Initialized
INFO - 2016-10-17 18:33:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:33:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:33:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:33:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:33:53 --> Final output sent to browser
DEBUG - 2016-10-17 18:33:53 --> Total execution time: 0.0051
INFO - 2016-10-17 18:33:55 --> Config Class Initialized
INFO - 2016-10-17 18:33:55 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:33:55 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:33:55 --> Utf8 Class Initialized
INFO - 2016-10-17 18:33:55 --> URI Class Initialized
DEBUG - 2016-10-17 18:33:55 --> No URI present. Default controller set.
INFO - 2016-10-17 18:33:55 --> Router Class Initialized
INFO - 2016-10-17 18:33:55 --> Output Class Initialized
INFO - 2016-10-17 18:33:55 --> Security Class Initialized
DEBUG - 2016-10-17 18:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:33:55 --> Input Class Initialized
INFO - 2016-10-17 18:33:55 --> Language Class Initialized
INFO - 2016-10-17 18:33:55 --> Loader Class Initialized
INFO - 2016-10-17 18:33:55 --> Helper loaded: url_helper
INFO - 2016-10-17 18:33:55 --> Helper loaded: form_helper
INFO - 2016-10-17 18:33:55 --> Database Driver Class Initialized
INFO - 2016-10-17 18:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:33:55 --> Controller Class Initialized
INFO - 2016-10-17 18:33:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:33:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:33:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:33:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:33:55 --> Final output sent to browser
DEBUG - 2016-10-17 18:33:55 --> Total execution time: 0.0045
INFO - 2016-10-17 18:33:57 --> Config Class Initialized
INFO - 2016-10-17 18:33:57 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:33:57 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:33:57 --> Utf8 Class Initialized
INFO - 2016-10-17 18:33:57 --> URI Class Initialized
DEBUG - 2016-10-17 18:33:57 --> No URI present. Default controller set.
INFO - 2016-10-17 18:33:57 --> Router Class Initialized
INFO - 2016-10-17 18:33:57 --> Output Class Initialized
INFO - 2016-10-17 18:33:57 --> Security Class Initialized
DEBUG - 2016-10-17 18:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:33:57 --> Input Class Initialized
INFO - 2016-10-17 18:33:57 --> Language Class Initialized
INFO - 2016-10-17 18:33:57 --> Loader Class Initialized
INFO - 2016-10-17 18:33:57 --> Helper loaded: url_helper
INFO - 2016-10-17 18:33:57 --> Helper loaded: form_helper
INFO - 2016-10-17 18:33:57 --> Database Driver Class Initialized
INFO - 2016-10-17 18:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:33:57 --> Controller Class Initialized
INFO - 2016-10-17 18:33:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:33:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:33:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:33:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:33:57 --> Final output sent to browser
DEBUG - 2016-10-17 18:33:57 --> Total execution time: 0.0049
INFO - 2016-10-17 18:34:44 --> Config Class Initialized
INFO - 2016-10-17 18:34:44 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:34:44 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:34:44 --> Utf8 Class Initialized
INFO - 2016-10-17 18:34:44 --> URI Class Initialized
DEBUG - 2016-10-17 18:34:44 --> No URI present. Default controller set.
INFO - 2016-10-17 18:34:44 --> Router Class Initialized
INFO - 2016-10-17 18:34:44 --> Output Class Initialized
INFO - 2016-10-17 18:34:44 --> Security Class Initialized
DEBUG - 2016-10-17 18:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:34:44 --> Input Class Initialized
INFO - 2016-10-17 18:34:44 --> Language Class Initialized
INFO - 2016-10-17 18:34:44 --> Loader Class Initialized
INFO - 2016-10-17 18:34:44 --> Helper loaded: url_helper
INFO - 2016-10-17 18:34:44 --> Helper loaded: form_helper
INFO - 2016-10-17 18:34:44 --> Database Driver Class Initialized
INFO - 2016-10-17 18:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:34:44 --> Controller Class Initialized
INFO - 2016-10-17 18:34:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:34:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:34:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:34:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:34:44 --> Final output sent to browser
DEBUG - 2016-10-17 18:34:44 --> Total execution time: 0.0055
INFO - 2016-10-17 18:34:52 --> Config Class Initialized
INFO - 2016-10-17 18:34:52 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:34:52 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:34:52 --> Utf8 Class Initialized
INFO - 2016-10-17 18:34:52 --> URI Class Initialized
DEBUG - 2016-10-17 18:34:52 --> No URI present. Default controller set.
INFO - 2016-10-17 18:34:52 --> Router Class Initialized
INFO - 2016-10-17 18:34:52 --> Output Class Initialized
INFO - 2016-10-17 18:34:52 --> Security Class Initialized
DEBUG - 2016-10-17 18:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:34:52 --> Input Class Initialized
INFO - 2016-10-17 18:34:52 --> Language Class Initialized
INFO - 2016-10-17 18:34:52 --> Loader Class Initialized
INFO - 2016-10-17 18:34:52 --> Helper loaded: url_helper
INFO - 2016-10-17 18:34:52 --> Helper loaded: form_helper
INFO - 2016-10-17 18:34:52 --> Database Driver Class Initialized
INFO - 2016-10-17 18:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:34:52 --> Controller Class Initialized
INFO - 2016-10-17 18:34:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:34:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:34:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:34:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:34:52 --> Final output sent to browser
DEBUG - 2016-10-17 18:34:52 --> Total execution time: 0.0052
INFO - 2016-10-17 18:34:57 --> Config Class Initialized
INFO - 2016-10-17 18:34:57 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:34:57 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:34:57 --> Utf8 Class Initialized
INFO - 2016-10-17 18:34:57 --> URI Class Initialized
DEBUG - 2016-10-17 18:34:57 --> No URI present. Default controller set.
INFO - 2016-10-17 18:34:57 --> Router Class Initialized
INFO - 2016-10-17 18:34:57 --> Output Class Initialized
INFO - 2016-10-17 18:34:57 --> Security Class Initialized
DEBUG - 2016-10-17 18:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:34:57 --> Input Class Initialized
INFO - 2016-10-17 18:34:57 --> Language Class Initialized
INFO - 2016-10-17 18:34:57 --> Loader Class Initialized
INFO - 2016-10-17 18:34:57 --> Helper loaded: url_helper
INFO - 2016-10-17 18:34:57 --> Helper loaded: form_helper
INFO - 2016-10-17 18:34:57 --> Database Driver Class Initialized
INFO - 2016-10-17 18:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:34:57 --> Controller Class Initialized
INFO - 2016-10-17 18:34:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:34:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:34:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:34:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:34:57 --> Final output sent to browser
DEBUG - 2016-10-17 18:34:57 --> Total execution time: 0.0047
INFO - 2016-10-17 18:37:11 --> Config Class Initialized
INFO - 2016-10-17 18:37:11 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:37:11 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:37:11 --> Utf8 Class Initialized
INFO - 2016-10-17 18:37:11 --> URI Class Initialized
DEBUG - 2016-10-17 18:37:11 --> No URI present. Default controller set.
INFO - 2016-10-17 18:37:11 --> Router Class Initialized
INFO - 2016-10-17 18:37:11 --> Output Class Initialized
INFO - 2016-10-17 18:37:11 --> Security Class Initialized
DEBUG - 2016-10-17 18:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:37:11 --> Input Class Initialized
INFO - 2016-10-17 18:37:11 --> Language Class Initialized
INFO - 2016-10-17 18:37:11 --> Loader Class Initialized
INFO - 2016-10-17 18:37:11 --> Helper loaded: url_helper
INFO - 2016-10-17 18:37:11 --> Helper loaded: form_helper
INFO - 2016-10-17 18:37:11 --> Database Driver Class Initialized
INFO - 2016-10-17 18:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:37:11 --> Controller Class Initialized
INFO - 2016-10-17 18:37:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:37:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:37:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:37:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:37:11 --> Final output sent to browser
DEBUG - 2016-10-17 18:37:11 --> Total execution time: 0.0060
INFO - 2016-10-17 18:37:29 --> Config Class Initialized
INFO - 2016-10-17 18:37:29 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:37:29 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:37:29 --> Utf8 Class Initialized
INFO - 2016-10-17 18:37:29 --> URI Class Initialized
DEBUG - 2016-10-17 18:37:29 --> No URI present. Default controller set.
INFO - 2016-10-17 18:37:29 --> Router Class Initialized
INFO - 2016-10-17 18:37:29 --> Output Class Initialized
INFO - 2016-10-17 18:37:29 --> Security Class Initialized
DEBUG - 2016-10-17 18:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:37:29 --> Input Class Initialized
INFO - 2016-10-17 18:37:29 --> Language Class Initialized
INFO - 2016-10-17 18:37:29 --> Loader Class Initialized
INFO - 2016-10-17 18:37:29 --> Helper loaded: url_helper
INFO - 2016-10-17 18:37:29 --> Helper loaded: form_helper
INFO - 2016-10-17 18:37:29 --> Database Driver Class Initialized
INFO - 2016-10-17 18:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:37:29 --> Controller Class Initialized
INFO - 2016-10-17 18:37:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:37:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:37:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:37:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:37:29 --> Final output sent to browser
DEBUG - 2016-10-17 18:37:29 --> Total execution time: 0.0055
INFO - 2016-10-17 18:37:51 --> Config Class Initialized
INFO - 2016-10-17 18:37:51 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:37:51 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:37:51 --> Utf8 Class Initialized
INFO - 2016-10-17 18:37:51 --> URI Class Initialized
DEBUG - 2016-10-17 18:37:51 --> No URI present. Default controller set.
INFO - 2016-10-17 18:37:51 --> Router Class Initialized
INFO - 2016-10-17 18:37:51 --> Output Class Initialized
INFO - 2016-10-17 18:37:51 --> Security Class Initialized
DEBUG - 2016-10-17 18:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:37:51 --> Input Class Initialized
INFO - 2016-10-17 18:37:51 --> Language Class Initialized
INFO - 2016-10-17 18:37:51 --> Loader Class Initialized
INFO - 2016-10-17 18:37:51 --> Helper loaded: url_helper
INFO - 2016-10-17 18:37:51 --> Helper loaded: form_helper
INFO - 2016-10-17 18:37:51 --> Database Driver Class Initialized
INFO - 2016-10-17 18:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:37:51 --> Controller Class Initialized
INFO - 2016-10-17 18:37:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:37:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:37:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:37:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:37:51 --> Final output sent to browser
DEBUG - 2016-10-17 18:37:51 --> Total execution time: 0.0064
INFO - 2016-10-17 18:38:05 --> Config Class Initialized
INFO - 2016-10-17 18:38:05 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:38:05 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:38:05 --> Utf8 Class Initialized
INFO - 2016-10-17 18:38:05 --> URI Class Initialized
DEBUG - 2016-10-17 18:38:05 --> No URI present. Default controller set.
INFO - 2016-10-17 18:38:05 --> Router Class Initialized
INFO - 2016-10-17 18:38:05 --> Output Class Initialized
INFO - 2016-10-17 18:38:05 --> Security Class Initialized
DEBUG - 2016-10-17 18:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:38:05 --> Input Class Initialized
INFO - 2016-10-17 18:38:05 --> Language Class Initialized
INFO - 2016-10-17 18:38:05 --> Loader Class Initialized
INFO - 2016-10-17 18:38:05 --> Helper loaded: url_helper
INFO - 2016-10-17 18:38:05 --> Helper loaded: form_helper
INFO - 2016-10-17 18:38:05 --> Database Driver Class Initialized
INFO - 2016-10-17 18:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:38:05 --> Controller Class Initialized
INFO - 2016-10-17 18:38:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:38:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:38:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:38:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:38:05 --> Final output sent to browser
DEBUG - 2016-10-17 18:38:05 --> Total execution time: 0.0058
INFO - 2016-10-17 18:39:03 --> Config Class Initialized
INFO - 2016-10-17 18:39:03 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:39:03 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:39:03 --> Utf8 Class Initialized
INFO - 2016-10-17 18:39:03 --> URI Class Initialized
DEBUG - 2016-10-17 18:39:03 --> No URI present. Default controller set.
INFO - 2016-10-17 18:39:03 --> Router Class Initialized
INFO - 2016-10-17 18:39:03 --> Output Class Initialized
INFO - 2016-10-17 18:39:03 --> Security Class Initialized
DEBUG - 2016-10-17 18:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:39:03 --> Input Class Initialized
INFO - 2016-10-17 18:39:03 --> Language Class Initialized
INFO - 2016-10-17 18:39:03 --> Loader Class Initialized
INFO - 2016-10-17 18:39:03 --> Helper loaded: url_helper
INFO - 2016-10-17 18:39:03 --> Helper loaded: form_helper
INFO - 2016-10-17 18:39:03 --> Database Driver Class Initialized
INFO - 2016-10-17 18:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:39:03 --> Controller Class Initialized
INFO - 2016-10-17 18:39:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:39:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:39:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:39:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:39:03 --> Final output sent to browser
DEBUG - 2016-10-17 18:39:03 --> Total execution time: 0.0051
INFO - 2016-10-17 18:39:26 --> Config Class Initialized
INFO - 2016-10-17 18:39:26 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:39:26 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:39:26 --> Utf8 Class Initialized
INFO - 2016-10-17 18:39:26 --> URI Class Initialized
DEBUG - 2016-10-17 18:39:26 --> No URI present. Default controller set.
INFO - 2016-10-17 18:39:26 --> Router Class Initialized
INFO - 2016-10-17 18:39:26 --> Output Class Initialized
INFO - 2016-10-17 18:39:26 --> Security Class Initialized
DEBUG - 2016-10-17 18:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:39:26 --> Input Class Initialized
INFO - 2016-10-17 18:39:26 --> Language Class Initialized
INFO - 2016-10-17 18:39:26 --> Loader Class Initialized
INFO - 2016-10-17 18:39:26 --> Helper loaded: url_helper
INFO - 2016-10-17 18:39:26 --> Helper loaded: form_helper
INFO - 2016-10-17 18:39:26 --> Database Driver Class Initialized
INFO - 2016-10-17 18:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:39:26 --> Controller Class Initialized
INFO - 2016-10-17 18:39:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:39:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:39:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:39:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:39:26 --> Final output sent to browser
DEBUG - 2016-10-17 18:39:26 --> Total execution time: 0.0080
INFO - 2016-10-17 18:39:34 --> Config Class Initialized
INFO - 2016-10-17 18:39:34 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:39:34 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:39:34 --> Utf8 Class Initialized
INFO - 2016-10-17 18:39:34 --> URI Class Initialized
DEBUG - 2016-10-17 18:39:34 --> No URI present. Default controller set.
INFO - 2016-10-17 18:39:34 --> Router Class Initialized
INFO - 2016-10-17 18:39:34 --> Output Class Initialized
INFO - 2016-10-17 18:39:34 --> Security Class Initialized
DEBUG - 2016-10-17 18:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:39:34 --> Input Class Initialized
INFO - 2016-10-17 18:39:34 --> Language Class Initialized
INFO - 2016-10-17 18:39:34 --> Loader Class Initialized
INFO - 2016-10-17 18:39:34 --> Helper loaded: url_helper
INFO - 2016-10-17 18:39:34 --> Helper loaded: form_helper
INFO - 2016-10-17 18:39:34 --> Database Driver Class Initialized
INFO - 2016-10-17 18:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:39:34 --> Controller Class Initialized
INFO - 2016-10-17 18:39:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:39:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:39:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:39:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:39:34 --> Final output sent to browser
DEBUG - 2016-10-17 18:39:34 --> Total execution time: 0.0052
INFO - 2016-10-17 18:39:50 --> Config Class Initialized
INFO - 2016-10-17 18:39:50 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:39:50 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:39:50 --> Utf8 Class Initialized
INFO - 2016-10-17 18:39:50 --> URI Class Initialized
DEBUG - 2016-10-17 18:39:50 --> No URI present. Default controller set.
INFO - 2016-10-17 18:39:50 --> Router Class Initialized
INFO - 2016-10-17 18:39:50 --> Output Class Initialized
INFO - 2016-10-17 18:39:50 --> Security Class Initialized
DEBUG - 2016-10-17 18:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:39:50 --> Input Class Initialized
INFO - 2016-10-17 18:39:50 --> Language Class Initialized
INFO - 2016-10-17 18:39:50 --> Loader Class Initialized
INFO - 2016-10-17 18:39:50 --> Helper loaded: url_helper
INFO - 2016-10-17 18:39:50 --> Helper loaded: form_helper
INFO - 2016-10-17 18:39:50 --> Database Driver Class Initialized
INFO - 2016-10-17 18:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:39:50 --> Controller Class Initialized
INFO - 2016-10-17 18:39:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:39:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:39:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:39:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:39:50 --> Final output sent to browser
DEBUG - 2016-10-17 18:39:50 --> Total execution time: 0.0050
INFO - 2016-10-17 18:40:39 --> Config Class Initialized
INFO - 2016-10-17 18:40:39 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:40:39 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:40:39 --> Utf8 Class Initialized
INFO - 2016-10-17 18:40:39 --> URI Class Initialized
DEBUG - 2016-10-17 18:40:39 --> No URI present. Default controller set.
INFO - 2016-10-17 18:40:39 --> Router Class Initialized
INFO - 2016-10-17 18:40:39 --> Output Class Initialized
INFO - 2016-10-17 18:40:39 --> Security Class Initialized
DEBUG - 2016-10-17 18:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:40:39 --> Input Class Initialized
INFO - 2016-10-17 18:40:39 --> Language Class Initialized
INFO - 2016-10-17 18:40:39 --> Loader Class Initialized
INFO - 2016-10-17 18:40:39 --> Helper loaded: url_helper
INFO - 2016-10-17 18:40:39 --> Helper loaded: form_helper
INFO - 2016-10-17 18:40:39 --> Database Driver Class Initialized
INFO - 2016-10-17 18:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:40:39 --> Controller Class Initialized
INFO - 2016-10-17 18:40:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:40:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:40:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:40:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:40:39 --> Final output sent to browser
DEBUG - 2016-10-17 18:40:39 --> Total execution time: 0.0053
INFO - 2016-10-17 18:43:02 --> Config Class Initialized
INFO - 2016-10-17 18:43:02 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:43:02 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:43:02 --> Utf8 Class Initialized
INFO - 2016-10-17 18:43:02 --> URI Class Initialized
DEBUG - 2016-10-17 18:43:02 --> No URI present. Default controller set.
INFO - 2016-10-17 18:43:02 --> Router Class Initialized
INFO - 2016-10-17 18:43:02 --> Output Class Initialized
INFO - 2016-10-17 18:43:02 --> Security Class Initialized
DEBUG - 2016-10-17 18:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:43:02 --> Input Class Initialized
INFO - 2016-10-17 18:43:02 --> Language Class Initialized
INFO - 2016-10-17 18:43:02 --> Loader Class Initialized
INFO - 2016-10-17 18:43:02 --> Helper loaded: url_helper
INFO - 2016-10-17 18:43:02 --> Helper loaded: form_helper
INFO - 2016-10-17 18:43:02 --> Database Driver Class Initialized
INFO - 2016-10-17 18:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:43:02 --> Controller Class Initialized
INFO - 2016-10-17 18:43:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:43:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:43:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:43:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:43:02 --> Final output sent to browser
DEBUG - 2016-10-17 18:43:02 --> Total execution time: 0.0052
INFO - 2016-10-17 18:43:21 --> Config Class Initialized
INFO - 2016-10-17 18:43:21 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:43:21 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:43:21 --> Utf8 Class Initialized
INFO - 2016-10-17 18:43:21 --> URI Class Initialized
DEBUG - 2016-10-17 18:43:21 --> No URI present. Default controller set.
INFO - 2016-10-17 18:43:21 --> Router Class Initialized
INFO - 2016-10-17 18:43:21 --> Output Class Initialized
INFO - 2016-10-17 18:43:21 --> Security Class Initialized
DEBUG - 2016-10-17 18:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:43:21 --> Input Class Initialized
INFO - 2016-10-17 18:43:21 --> Language Class Initialized
INFO - 2016-10-17 18:43:21 --> Loader Class Initialized
INFO - 2016-10-17 18:43:21 --> Helper loaded: url_helper
INFO - 2016-10-17 18:43:21 --> Helper loaded: form_helper
INFO - 2016-10-17 18:43:21 --> Database Driver Class Initialized
INFO - 2016-10-17 18:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:43:21 --> Controller Class Initialized
INFO - 2016-10-17 18:43:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:43:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:43:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:43:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:43:21 --> Final output sent to browser
DEBUG - 2016-10-17 18:43:21 --> Total execution time: 0.0048
INFO - 2016-10-17 18:45:21 --> Config Class Initialized
INFO - 2016-10-17 18:45:21 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:45:21 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:45:21 --> Utf8 Class Initialized
INFO - 2016-10-17 18:45:21 --> URI Class Initialized
DEBUG - 2016-10-17 18:45:21 --> No URI present. Default controller set.
INFO - 2016-10-17 18:45:21 --> Router Class Initialized
INFO - 2016-10-17 18:45:21 --> Output Class Initialized
INFO - 2016-10-17 18:45:21 --> Security Class Initialized
DEBUG - 2016-10-17 18:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:45:21 --> Input Class Initialized
INFO - 2016-10-17 18:45:21 --> Language Class Initialized
INFO - 2016-10-17 18:45:21 --> Loader Class Initialized
INFO - 2016-10-17 18:45:21 --> Helper loaded: url_helper
INFO - 2016-10-17 18:45:21 --> Helper loaded: form_helper
INFO - 2016-10-17 18:45:21 --> Database Driver Class Initialized
INFO - 2016-10-17 18:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:45:21 --> Controller Class Initialized
INFO - 2016-10-17 18:45:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:45:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:45:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:45:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:45:21 --> Final output sent to browser
DEBUG - 2016-10-17 18:45:21 --> Total execution time: 0.0054
INFO - 2016-10-17 18:46:18 --> Config Class Initialized
INFO - 2016-10-17 18:46:18 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:46:18 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:46:18 --> Utf8 Class Initialized
INFO - 2016-10-17 18:46:18 --> URI Class Initialized
DEBUG - 2016-10-17 18:46:18 --> No URI present. Default controller set.
INFO - 2016-10-17 18:46:18 --> Router Class Initialized
INFO - 2016-10-17 18:46:18 --> Output Class Initialized
INFO - 2016-10-17 18:46:18 --> Security Class Initialized
DEBUG - 2016-10-17 18:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:46:18 --> Input Class Initialized
INFO - 2016-10-17 18:46:18 --> Language Class Initialized
INFO - 2016-10-17 18:46:18 --> Loader Class Initialized
INFO - 2016-10-17 18:46:18 --> Helper loaded: url_helper
INFO - 2016-10-17 18:46:18 --> Helper loaded: form_helper
INFO - 2016-10-17 18:46:18 --> Database Driver Class Initialized
INFO - 2016-10-17 18:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:46:18 --> Controller Class Initialized
INFO - 2016-10-17 18:46:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:46:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:46:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:46:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:46:18 --> Final output sent to browser
DEBUG - 2016-10-17 18:46:18 --> Total execution time: 0.0079
INFO - 2016-10-17 18:46:34 --> Config Class Initialized
INFO - 2016-10-17 18:46:34 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:46:34 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:46:34 --> Utf8 Class Initialized
INFO - 2016-10-17 18:46:34 --> URI Class Initialized
INFO - 2016-10-17 18:46:34 --> Router Class Initialized
INFO - 2016-10-17 18:46:34 --> Output Class Initialized
INFO - 2016-10-17 18:46:34 --> Security Class Initialized
DEBUG - 2016-10-17 18:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:46:34 --> Input Class Initialized
INFO - 2016-10-17 18:46:34 --> Language Class Initialized
INFO - 2016-10-17 18:46:34 --> Loader Class Initialized
INFO - 2016-10-17 18:46:34 --> Helper loaded: url_helper
INFO - 2016-10-17 18:46:34 --> Helper loaded: form_helper
INFO - 2016-10-17 18:46:34 --> Database Driver Class Initialized
INFO - 2016-10-17 18:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:46:34 --> Controller Class Initialized
ERROR - 2016-10-17 18:46:34 --> Severity: Notice --> Undefined variable: name /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
ERROR - 2016-10-17 18:46:34 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
INFO - 2016-10-17 18:46:34 --> Config Class Initialized
INFO - 2016-10-17 18:46:34 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:46:34 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:46:34 --> Utf8 Class Initialized
INFO - 2016-10-17 18:46:34 --> URI Class Initialized
DEBUG - 2016-10-17 18:46:34 --> No URI present. Default controller set.
INFO - 2016-10-17 18:46:34 --> Router Class Initialized
INFO - 2016-10-17 18:46:34 --> Output Class Initialized
INFO - 2016-10-17 18:46:34 --> Security Class Initialized
DEBUG - 2016-10-17 18:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:46:34 --> Input Class Initialized
INFO - 2016-10-17 18:46:34 --> Language Class Initialized
INFO - 2016-10-17 18:46:34 --> Loader Class Initialized
INFO - 2016-10-17 18:46:34 --> Helper loaded: url_helper
INFO - 2016-10-17 18:46:34 --> Helper loaded: form_helper
INFO - 2016-10-17 18:46:34 --> Database Driver Class Initialized
INFO - 2016-10-17 18:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:46:34 --> Controller Class Initialized
INFO - 2016-10-17 18:46:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:46:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-17 18:46:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:46:34 --> Final output sent to browser
DEBUG - 2016-10-17 18:46:34 --> Total execution time: 0.0041
INFO - 2016-10-17 18:46:48 --> Config Class Initialized
INFO - 2016-10-17 18:46:48 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:46:48 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:46:48 --> Utf8 Class Initialized
INFO - 2016-10-17 18:46:48 --> URI Class Initialized
INFO - 2016-10-17 18:46:48 --> Router Class Initialized
INFO - 2016-10-17 18:46:48 --> Output Class Initialized
INFO - 2016-10-17 18:46:48 --> Security Class Initialized
DEBUG - 2016-10-17 18:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:46:48 --> Input Class Initialized
INFO - 2016-10-17 18:46:48 --> Language Class Initialized
INFO - 2016-10-17 18:46:48 --> Loader Class Initialized
INFO - 2016-10-17 18:46:48 --> Helper loaded: url_helper
INFO - 2016-10-17 18:46:48 --> Helper loaded: form_helper
INFO - 2016-10-17 18:46:48 --> Database Driver Class Initialized
INFO - 2016-10-17 18:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:46:48 --> Controller Class Initialized
INFO - 2016-10-17 18:46:48 --> Model Class Initialized
INFO - 2016-10-17 18:46:48 --> Final output sent to browser
DEBUG - 2016-10-17 18:46:48 --> Total execution time: 0.0084
INFO - 2016-10-17 18:46:57 --> Config Class Initialized
INFO - 2016-10-17 18:46:57 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:46:57 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:46:57 --> Utf8 Class Initialized
INFO - 2016-10-17 18:46:57 --> URI Class Initialized
INFO - 2016-10-17 18:46:57 --> Router Class Initialized
INFO - 2016-10-17 18:46:57 --> Output Class Initialized
INFO - 2016-10-17 18:46:57 --> Security Class Initialized
DEBUG - 2016-10-17 18:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:46:57 --> Input Class Initialized
INFO - 2016-10-17 18:46:57 --> Language Class Initialized
INFO - 2016-10-17 18:46:57 --> Loader Class Initialized
INFO - 2016-10-17 18:46:57 --> Helper loaded: url_helper
INFO - 2016-10-17 18:46:57 --> Helper loaded: form_helper
INFO - 2016-10-17 18:46:57 --> Database Driver Class Initialized
INFO - 2016-10-17 18:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:46:57 --> Controller Class Initialized
INFO - 2016-10-17 18:46:57 --> Model Class Initialized
INFO - 2016-10-17 18:46:57 --> Final output sent to browser
DEBUG - 2016-10-17 18:46:57 --> Total execution time: 0.0056
INFO - 2016-10-17 18:46:57 --> Config Class Initialized
INFO - 2016-10-17 18:46:57 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:46:57 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:46:57 --> Utf8 Class Initialized
INFO - 2016-10-17 18:46:57 --> URI Class Initialized
DEBUG - 2016-10-17 18:46:57 --> No URI present. Default controller set.
INFO - 2016-10-17 18:46:57 --> Router Class Initialized
INFO - 2016-10-17 18:46:57 --> Output Class Initialized
INFO - 2016-10-17 18:46:57 --> Security Class Initialized
DEBUG - 2016-10-17 18:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:46:57 --> Input Class Initialized
INFO - 2016-10-17 18:46:57 --> Language Class Initialized
INFO - 2016-10-17 18:46:57 --> Loader Class Initialized
INFO - 2016-10-17 18:46:57 --> Helper loaded: url_helper
INFO - 2016-10-17 18:46:57 --> Helper loaded: form_helper
INFO - 2016-10-17 18:46:57 --> Database Driver Class Initialized
INFO - 2016-10-17 18:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:46:57 --> Controller Class Initialized
INFO - 2016-10-17 18:46:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:46:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:46:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:46:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:46:57 --> Final output sent to browser
DEBUG - 2016-10-17 18:46:57 --> Total execution time: 0.0050
INFO - 2016-10-17 18:47:00 --> Config Class Initialized
INFO - 2016-10-17 18:47:00 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:47:00 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:47:00 --> Utf8 Class Initialized
INFO - 2016-10-17 18:47:00 --> URI Class Initialized
DEBUG - 2016-10-17 18:47:00 --> No URI present. Default controller set.
INFO - 2016-10-17 18:47:00 --> Router Class Initialized
INFO - 2016-10-17 18:47:00 --> Output Class Initialized
INFO - 2016-10-17 18:47:00 --> Security Class Initialized
DEBUG - 2016-10-17 18:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:47:00 --> Input Class Initialized
INFO - 2016-10-17 18:47:00 --> Language Class Initialized
INFO - 2016-10-17 18:47:00 --> Loader Class Initialized
INFO - 2016-10-17 18:47:00 --> Helper loaded: url_helper
INFO - 2016-10-17 18:47:00 --> Helper loaded: form_helper
INFO - 2016-10-17 18:47:00 --> Database Driver Class Initialized
INFO - 2016-10-17 18:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:47:00 --> Controller Class Initialized
INFO - 2016-10-17 18:47:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:47:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:47:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:47:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:47:00 --> Final output sent to browser
DEBUG - 2016-10-17 18:47:00 --> Total execution time: 0.0048
INFO - 2016-10-17 18:47:47 --> Config Class Initialized
INFO - 2016-10-17 18:47:47 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:47:47 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:47:47 --> Utf8 Class Initialized
INFO - 2016-10-17 18:47:47 --> URI Class Initialized
DEBUG - 2016-10-17 18:47:47 --> No URI present. Default controller set.
INFO - 2016-10-17 18:47:47 --> Router Class Initialized
INFO - 2016-10-17 18:47:47 --> Output Class Initialized
INFO - 2016-10-17 18:47:47 --> Security Class Initialized
DEBUG - 2016-10-17 18:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:47:47 --> Input Class Initialized
INFO - 2016-10-17 18:47:47 --> Language Class Initialized
INFO - 2016-10-17 18:47:47 --> Loader Class Initialized
INFO - 2016-10-17 18:47:47 --> Helper loaded: url_helper
INFO - 2016-10-17 18:47:47 --> Helper loaded: form_helper
INFO - 2016-10-17 18:47:47 --> Database Driver Class Initialized
INFO - 2016-10-17 18:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:47:47 --> Controller Class Initialized
INFO - 2016-10-17 18:47:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:47:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:47:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:47:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:47:47 --> Final output sent to browser
DEBUG - 2016-10-17 18:47:47 --> Total execution time: 0.0060
INFO - 2016-10-17 18:48:34 --> Config Class Initialized
INFO - 2016-10-17 18:48:34 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:48:34 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:48:34 --> Utf8 Class Initialized
INFO - 2016-10-17 18:48:34 --> URI Class Initialized
DEBUG - 2016-10-17 18:48:34 --> No URI present. Default controller set.
INFO - 2016-10-17 18:48:34 --> Router Class Initialized
INFO - 2016-10-17 18:48:34 --> Output Class Initialized
INFO - 2016-10-17 18:48:34 --> Security Class Initialized
DEBUG - 2016-10-17 18:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:48:34 --> Input Class Initialized
INFO - 2016-10-17 18:48:34 --> Language Class Initialized
INFO - 2016-10-17 18:48:34 --> Loader Class Initialized
INFO - 2016-10-17 18:48:34 --> Helper loaded: url_helper
INFO - 2016-10-17 18:48:34 --> Helper loaded: form_helper
INFO - 2016-10-17 18:48:34 --> Database Driver Class Initialized
INFO - 2016-10-17 18:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:48:34 --> Controller Class Initialized
INFO - 2016-10-17 18:48:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:48:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:48:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:48:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:48:34 --> Final output sent to browser
DEBUG - 2016-10-17 18:48:34 --> Total execution time: 0.0053
INFO - 2016-10-17 18:50:24 --> Config Class Initialized
INFO - 2016-10-17 18:50:24 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:50:24 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:50:24 --> Utf8 Class Initialized
INFO - 2016-10-17 18:50:24 --> URI Class Initialized
DEBUG - 2016-10-17 18:50:24 --> No URI present. Default controller set.
INFO - 2016-10-17 18:50:24 --> Router Class Initialized
INFO - 2016-10-17 18:50:24 --> Output Class Initialized
INFO - 2016-10-17 18:50:24 --> Security Class Initialized
DEBUG - 2016-10-17 18:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:50:24 --> Input Class Initialized
INFO - 2016-10-17 18:50:24 --> Language Class Initialized
INFO - 2016-10-17 18:50:24 --> Loader Class Initialized
INFO - 2016-10-17 18:50:24 --> Helper loaded: url_helper
INFO - 2016-10-17 18:50:24 --> Helper loaded: form_helper
INFO - 2016-10-17 18:50:24 --> Database Driver Class Initialized
INFO - 2016-10-17 18:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:50:24 --> Controller Class Initialized
INFO - 2016-10-17 18:50:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:50:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:50:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:50:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:50:24 --> Final output sent to browser
DEBUG - 2016-10-17 18:50:24 --> Total execution time: 0.0057
INFO - 2016-10-17 18:51:20 --> Config Class Initialized
INFO - 2016-10-17 18:51:20 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:51:20 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:51:20 --> Utf8 Class Initialized
INFO - 2016-10-17 18:51:20 --> URI Class Initialized
DEBUG - 2016-10-17 18:51:20 --> No URI present. Default controller set.
INFO - 2016-10-17 18:51:20 --> Router Class Initialized
INFO - 2016-10-17 18:51:20 --> Output Class Initialized
INFO - 2016-10-17 18:51:20 --> Security Class Initialized
DEBUG - 2016-10-17 18:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:51:20 --> Input Class Initialized
INFO - 2016-10-17 18:51:20 --> Language Class Initialized
INFO - 2016-10-17 18:51:20 --> Loader Class Initialized
INFO - 2016-10-17 18:51:20 --> Helper loaded: url_helper
INFO - 2016-10-17 18:51:20 --> Helper loaded: form_helper
INFO - 2016-10-17 18:51:20 --> Database Driver Class Initialized
INFO - 2016-10-17 18:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:51:20 --> Controller Class Initialized
INFO - 2016-10-17 18:51:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:51:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:51:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:51:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:51:20 --> Final output sent to browser
DEBUG - 2016-10-17 18:51:20 --> Total execution time: 0.0059
INFO - 2016-10-17 18:51:22 --> Config Class Initialized
INFO - 2016-10-17 18:51:22 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:51:22 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:51:22 --> Utf8 Class Initialized
INFO - 2016-10-17 18:51:22 --> URI Class Initialized
DEBUG - 2016-10-17 18:51:22 --> No URI present. Default controller set.
INFO - 2016-10-17 18:51:22 --> Router Class Initialized
INFO - 2016-10-17 18:51:22 --> Output Class Initialized
INFO - 2016-10-17 18:51:22 --> Security Class Initialized
DEBUG - 2016-10-17 18:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:51:22 --> Input Class Initialized
INFO - 2016-10-17 18:51:22 --> Language Class Initialized
INFO - 2016-10-17 18:51:22 --> Loader Class Initialized
INFO - 2016-10-17 18:51:22 --> Helper loaded: url_helper
INFO - 2016-10-17 18:51:22 --> Helper loaded: form_helper
INFO - 2016-10-17 18:51:22 --> Database Driver Class Initialized
INFO - 2016-10-17 18:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:51:22 --> Controller Class Initialized
INFO - 2016-10-17 18:51:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:51:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:51:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:51:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:51:22 --> Final output sent to browser
DEBUG - 2016-10-17 18:51:22 --> Total execution time: 0.0046
INFO - 2016-10-17 18:51:23 --> Config Class Initialized
INFO - 2016-10-17 18:51:23 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:51:23 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:51:23 --> Utf8 Class Initialized
INFO - 2016-10-17 18:51:23 --> URI Class Initialized
INFO - 2016-10-17 18:51:23 --> Router Class Initialized
INFO - 2016-10-17 18:51:23 --> Output Class Initialized
INFO - 2016-10-17 18:51:23 --> Security Class Initialized
DEBUG - 2016-10-17 18:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:51:23 --> Input Class Initialized
INFO - 2016-10-17 18:51:23 --> Language Class Initialized
INFO - 2016-10-17 18:51:23 --> Loader Class Initialized
INFO - 2016-10-17 18:51:23 --> Helper loaded: url_helper
INFO - 2016-10-17 18:51:23 --> Helper loaded: form_helper
INFO - 2016-10-17 18:51:23 --> Database Driver Class Initialized
INFO - 2016-10-17 18:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:51:23 --> Controller Class Initialized
INFO - 2016-10-17 18:51:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:51:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:51:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/home.php
INFO - 2016-10-17 18:51:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:51:23 --> Final output sent to browser
DEBUG - 2016-10-17 18:51:23 --> Total execution time: 0.0056
INFO - 2016-10-17 18:51:25 --> Config Class Initialized
INFO - 2016-10-17 18:51:25 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:51:25 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:51:25 --> Utf8 Class Initialized
INFO - 2016-10-17 18:51:25 --> URI Class Initialized
DEBUG - 2016-10-17 18:51:25 --> No URI present. Default controller set.
INFO - 2016-10-17 18:51:25 --> Router Class Initialized
INFO - 2016-10-17 18:51:25 --> Output Class Initialized
INFO - 2016-10-17 18:51:25 --> Security Class Initialized
DEBUG - 2016-10-17 18:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:51:25 --> Input Class Initialized
INFO - 2016-10-17 18:51:25 --> Language Class Initialized
INFO - 2016-10-17 18:51:25 --> Loader Class Initialized
INFO - 2016-10-17 18:51:25 --> Helper loaded: url_helper
INFO - 2016-10-17 18:51:25 --> Helper loaded: form_helper
INFO - 2016-10-17 18:51:25 --> Database Driver Class Initialized
INFO - 2016-10-17 18:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:51:25 --> Controller Class Initialized
INFO - 2016-10-17 18:51:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:51:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:51:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:51:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:51:25 --> Final output sent to browser
DEBUG - 2016-10-17 18:51:25 --> Total execution time: 0.0049
INFO - 2016-10-17 18:51:26 --> Config Class Initialized
INFO - 2016-10-17 18:51:26 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:51:26 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:51:26 --> Utf8 Class Initialized
INFO - 2016-10-17 18:51:26 --> URI Class Initialized
INFO - 2016-10-17 18:51:26 --> Router Class Initialized
INFO - 2016-10-17 18:51:26 --> Output Class Initialized
INFO - 2016-10-17 18:51:26 --> Security Class Initialized
DEBUG - 2016-10-17 18:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:51:26 --> Input Class Initialized
INFO - 2016-10-17 18:51:26 --> Language Class Initialized
INFO - 2016-10-17 18:51:26 --> Loader Class Initialized
INFO - 2016-10-17 18:51:26 --> Helper loaded: url_helper
INFO - 2016-10-17 18:51:26 --> Helper loaded: form_helper
INFO - 2016-10-17 18:51:26 --> Database Driver Class Initialized
INFO - 2016-10-17 18:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:51:26 --> Controller Class Initialized
INFO - 2016-10-17 18:51:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:51:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:51:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/home.php
INFO - 2016-10-17 18:51:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:51:26 --> Final output sent to browser
DEBUG - 2016-10-17 18:51:26 --> Total execution time: 0.0048
INFO - 2016-10-17 18:51:28 --> Config Class Initialized
INFO - 2016-10-17 18:51:28 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:51:28 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:51:28 --> Utf8 Class Initialized
INFO - 2016-10-17 18:51:28 --> URI Class Initialized
DEBUG - 2016-10-17 18:51:28 --> No URI present. Default controller set.
INFO - 2016-10-17 18:51:28 --> Router Class Initialized
INFO - 2016-10-17 18:51:28 --> Output Class Initialized
INFO - 2016-10-17 18:51:28 --> Security Class Initialized
DEBUG - 2016-10-17 18:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:51:28 --> Input Class Initialized
INFO - 2016-10-17 18:51:28 --> Language Class Initialized
INFO - 2016-10-17 18:51:28 --> Loader Class Initialized
INFO - 2016-10-17 18:51:28 --> Helper loaded: url_helper
INFO - 2016-10-17 18:51:28 --> Helper loaded: form_helper
INFO - 2016-10-17 18:51:28 --> Database Driver Class Initialized
INFO - 2016-10-17 18:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:51:28 --> Controller Class Initialized
INFO - 2016-10-17 18:51:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:51:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:51:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:51:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:51:28 --> Final output sent to browser
DEBUG - 2016-10-17 18:51:28 --> Total execution time: 0.0048
INFO - 2016-10-17 18:52:10 --> Config Class Initialized
INFO - 2016-10-17 18:52:10 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:52:10 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:52:10 --> Utf8 Class Initialized
INFO - 2016-10-17 18:52:10 --> URI Class Initialized
DEBUG - 2016-10-17 18:52:10 --> No URI present. Default controller set.
INFO - 2016-10-17 18:52:10 --> Router Class Initialized
INFO - 2016-10-17 18:52:10 --> Output Class Initialized
INFO - 2016-10-17 18:52:10 --> Security Class Initialized
DEBUG - 2016-10-17 18:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:52:10 --> Input Class Initialized
INFO - 2016-10-17 18:52:10 --> Language Class Initialized
INFO - 2016-10-17 18:52:10 --> Loader Class Initialized
INFO - 2016-10-17 18:52:10 --> Helper loaded: url_helper
INFO - 2016-10-17 18:52:10 --> Helper loaded: form_helper
INFO - 2016-10-17 18:52:10 --> Database Driver Class Initialized
INFO - 2016-10-17 18:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:52:10 --> Controller Class Initialized
INFO - 2016-10-17 18:52:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:52:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:52:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:52:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:52:10 --> Final output sent to browser
DEBUG - 2016-10-17 18:52:10 --> Total execution time: 0.0061
INFO - 2016-10-17 18:52:13 --> Config Class Initialized
INFO - 2016-10-17 18:52:13 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:52:13 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:52:13 --> Utf8 Class Initialized
INFO - 2016-10-17 18:52:13 --> URI Class Initialized
DEBUG - 2016-10-17 18:52:13 --> No URI present. Default controller set.
INFO - 2016-10-17 18:52:13 --> Router Class Initialized
INFO - 2016-10-17 18:52:13 --> Output Class Initialized
INFO - 2016-10-17 18:52:13 --> Security Class Initialized
DEBUG - 2016-10-17 18:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:52:13 --> Input Class Initialized
INFO - 2016-10-17 18:52:13 --> Language Class Initialized
INFO - 2016-10-17 18:52:13 --> Loader Class Initialized
INFO - 2016-10-17 18:52:13 --> Helper loaded: url_helper
INFO - 2016-10-17 18:52:13 --> Helper loaded: form_helper
INFO - 2016-10-17 18:52:13 --> Database Driver Class Initialized
INFO - 2016-10-17 18:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:52:13 --> Controller Class Initialized
INFO - 2016-10-17 18:52:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:52:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:52:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:52:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:52:13 --> Final output sent to browser
DEBUG - 2016-10-17 18:52:13 --> Total execution time: 0.0053
INFO - 2016-10-17 18:52:48 --> Config Class Initialized
INFO - 2016-10-17 18:52:48 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:52:48 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:52:48 --> Utf8 Class Initialized
INFO - 2016-10-17 18:52:48 --> URI Class Initialized
DEBUG - 2016-10-17 18:52:48 --> No URI present. Default controller set.
INFO - 2016-10-17 18:52:48 --> Router Class Initialized
INFO - 2016-10-17 18:52:48 --> Output Class Initialized
INFO - 2016-10-17 18:52:48 --> Security Class Initialized
DEBUG - 2016-10-17 18:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:52:48 --> Input Class Initialized
INFO - 2016-10-17 18:52:48 --> Language Class Initialized
INFO - 2016-10-17 18:52:48 --> Loader Class Initialized
INFO - 2016-10-17 18:52:48 --> Helper loaded: url_helper
INFO - 2016-10-17 18:52:48 --> Helper loaded: form_helper
INFO - 2016-10-17 18:52:48 --> Database Driver Class Initialized
INFO - 2016-10-17 18:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:52:48 --> Controller Class Initialized
INFO - 2016-10-17 18:52:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:52:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:52:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:52:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:52:48 --> Final output sent to browser
DEBUG - 2016-10-17 18:52:48 --> Total execution time: 0.0054
INFO - 2016-10-17 18:52:49 --> Config Class Initialized
INFO - 2016-10-17 18:52:49 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:52:49 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:52:49 --> Utf8 Class Initialized
INFO - 2016-10-17 18:52:49 --> URI Class Initialized
INFO - 2016-10-17 18:52:49 --> Router Class Initialized
INFO - 2016-10-17 18:52:49 --> Output Class Initialized
INFO - 2016-10-17 18:52:49 --> Security Class Initialized
DEBUG - 2016-10-17 18:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:52:49 --> Input Class Initialized
INFO - 2016-10-17 18:52:49 --> Language Class Initialized
INFO - 2016-10-17 18:52:49 --> Loader Class Initialized
INFO - 2016-10-17 18:52:49 --> Helper loaded: url_helper
INFO - 2016-10-17 18:52:49 --> Helper loaded: form_helper
INFO - 2016-10-17 18:52:49 --> Database Driver Class Initialized
INFO - 2016-10-17 18:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:52:49 --> Controller Class Initialized
INFO - 2016-10-17 18:52:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:52:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:52:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/home.php
INFO - 2016-10-17 18:52:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:52:49 --> Final output sent to browser
DEBUG - 2016-10-17 18:52:49 --> Total execution time: 0.0053
INFO - 2016-10-17 18:52:52 --> Config Class Initialized
INFO - 2016-10-17 18:52:52 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:52:52 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:52:52 --> Utf8 Class Initialized
INFO - 2016-10-17 18:52:52 --> URI Class Initialized
INFO - 2016-10-17 18:52:52 --> Router Class Initialized
INFO - 2016-10-17 18:52:52 --> Output Class Initialized
INFO - 2016-10-17 18:52:52 --> Security Class Initialized
DEBUG - 2016-10-17 18:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:52:52 --> Input Class Initialized
INFO - 2016-10-17 18:52:52 --> Language Class Initialized
INFO - 2016-10-17 18:52:52 --> Loader Class Initialized
INFO - 2016-10-17 18:52:52 --> Helper loaded: url_helper
INFO - 2016-10-17 18:52:52 --> Helper loaded: form_helper
INFO - 2016-10-17 18:52:52 --> Database Driver Class Initialized
INFO - 2016-10-17 18:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:52:52 --> Controller Class Initialized
INFO - 2016-10-17 18:52:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:52:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:52:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/home.php
INFO - 2016-10-17 18:52:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:52:52 --> Final output sent to browser
DEBUG - 2016-10-17 18:52:52 --> Total execution time: 0.0048
INFO - 2016-10-17 18:52:53 --> Config Class Initialized
INFO - 2016-10-17 18:52:53 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:52:53 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:52:53 --> Utf8 Class Initialized
INFO - 2016-10-17 18:52:53 --> URI Class Initialized
DEBUG - 2016-10-17 18:52:53 --> No URI present. Default controller set.
INFO - 2016-10-17 18:52:53 --> Router Class Initialized
INFO - 2016-10-17 18:52:53 --> Output Class Initialized
INFO - 2016-10-17 18:52:53 --> Security Class Initialized
DEBUG - 2016-10-17 18:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:52:53 --> Input Class Initialized
INFO - 2016-10-17 18:52:53 --> Language Class Initialized
INFO - 2016-10-17 18:52:53 --> Loader Class Initialized
INFO - 2016-10-17 18:52:53 --> Helper loaded: url_helper
INFO - 2016-10-17 18:52:53 --> Helper loaded: form_helper
INFO - 2016-10-17 18:52:53 --> Database Driver Class Initialized
INFO - 2016-10-17 18:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:52:53 --> Controller Class Initialized
INFO - 2016-10-17 18:52:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:52:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:52:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:52:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:52:53 --> Final output sent to browser
DEBUG - 2016-10-17 18:52:53 --> Total execution time: 0.0049
INFO - 2016-10-17 18:52:54 --> Config Class Initialized
INFO - 2016-10-17 18:52:54 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:52:54 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:52:54 --> Utf8 Class Initialized
INFO - 2016-10-17 18:52:54 --> URI Class Initialized
INFO - 2016-10-17 18:52:54 --> Router Class Initialized
INFO - 2016-10-17 18:52:54 --> Output Class Initialized
INFO - 2016-10-17 18:52:54 --> Security Class Initialized
DEBUG - 2016-10-17 18:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:52:54 --> Input Class Initialized
INFO - 2016-10-17 18:52:54 --> Language Class Initialized
INFO - 2016-10-17 18:52:54 --> Loader Class Initialized
INFO - 2016-10-17 18:52:54 --> Helper loaded: url_helper
INFO - 2016-10-17 18:52:54 --> Helper loaded: form_helper
INFO - 2016-10-17 18:52:54 --> Database Driver Class Initialized
INFO - 2016-10-17 18:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:52:54 --> Controller Class Initialized
INFO - 2016-10-17 18:52:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:52:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:52:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/leave/home.php
INFO - 2016-10-17 18:52:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:52:54 --> Final output sent to browser
DEBUG - 2016-10-17 18:52:54 --> Total execution time: 0.0047
INFO - 2016-10-17 18:52:58 --> Config Class Initialized
INFO - 2016-10-17 18:52:58 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:52:58 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:52:58 --> Utf8 Class Initialized
INFO - 2016-10-17 18:52:58 --> URI Class Initialized
DEBUG - 2016-10-17 18:52:58 --> No URI present. Default controller set.
INFO - 2016-10-17 18:52:58 --> Router Class Initialized
INFO - 2016-10-17 18:52:58 --> Output Class Initialized
INFO - 2016-10-17 18:52:58 --> Security Class Initialized
DEBUG - 2016-10-17 18:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:52:58 --> Input Class Initialized
INFO - 2016-10-17 18:52:58 --> Language Class Initialized
INFO - 2016-10-17 18:52:58 --> Loader Class Initialized
INFO - 2016-10-17 18:52:58 --> Helper loaded: url_helper
INFO - 2016-10-17 18:52:58 --> Helper loaded: form_helper
INFO - 2016-10-17 18:52:58 --> Database Driver Class Initialized
INFO - 2016-10-17 18:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:52:58 --> Controller Class Initialized
INFO - 2016-10-17 18:52:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:52:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:52:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:52:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:52:58 --> Final output sent to browser
DEBUG - 2016-10-17 18:52:58 --> Total execution time: 0.0050
INFO - 2016-10-17 18:53:40 --> Config Class Initialized
INFO - 2016-10-17 18:53:40 --> Hooks Class Initialized
DEBUG - 2016-10-17 18:53:40 --> UTF-8 Support Enabled
INFO - 2016-10-17 18:53:40 --> Utf8 Class Initialized
INFO - 2016-10-17 18:53:40 --> URI Class Initialized
DEBUG - 2016-10-17 18:53:40 --> No URI present. Default controller set.
INFO - 2016-10-17 18:53:40 --> Router Class Initialized
INFO - 2016-10-17 18:53:40 --> Output Class Initialized
INFO - 2016-10-17 18:53:40 --> Security Class Initialized
DEBUG - 2016-10-17 18:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 18:53:40 --> Input Class Initialized
INFO - 2016-10-17 18:53:40 --> Language Class Initialized
INFO - 2016-10-17 18:53:40 --> Loader Class Initialized
INFO - 2016-10-17 18:53:40 --> Helper loaded: url_helper
INFO - 2016-10-17 18:53:40 --> Helper loaded: form_helper
INFO - 2016-10-17 18:53:40 --> Database Driver Class Initialized
INFO - 2016-10-17 18:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 18:53:40 --> Controller Class Initialized
INFO - 2016-10-17 18:53:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-17 18:53:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-17 18:53:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-17 18:53:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-17 18:53:40 --> Final output sent to browser
DEBUG - 2016-10-17 18:53:40 --> Total execution time: 0.0084
